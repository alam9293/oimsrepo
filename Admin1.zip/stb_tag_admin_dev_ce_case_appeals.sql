-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_case_appeals`
--

DROP TABLE IF EXISTS `ce_case_appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_case_appeals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `appealDate` date DEFAULT NULL,
  `appealRespondByDate` date DEFAULT NULL,
  `billExpiryDate` datetime(6) DEFAULT NULL,
  `billRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `letterIssuanceDate` date DEFAULT NULL,
  `penaltyAmount` decimal(19,2) DEFAULT NULL,
  `penaltyStatusEndDate` date DEFAULT NULL,
  `penaltyStatusStartDate` date DEFAULT NULL,
  `pendingBatchJob` bit(1) NOT NULL DEFAULT b'0',
  `respondedDate` date DEFAULT NULL,
  `toEmailLetter` bit(1) NOT NULL DEFAULT b'0',
  `ceCaseDecisionId` int(11) DEFAULT NULL,
  `ceCaseInfringementId` int(11) DEFAULT NULL,
  `letterId` int(11) DEFAULT NULL,
  `letterEmailLogId` int(11) DEFAULT NULL,
  `outcomeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workflowId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgkld29hvdpro8og5pdom3ychc` (`ceCaseDecisionId`),
  KEY `FKjqgpxyyhhtu305evdmgtphhuk` (`ceCaseInfringementId`),
  KEY `FK4jrvnqvujk4hahr6dpxrqda9n` (`letterId`),
  KEY `FKkjbw1npe48kke3x57hmanaopx` (`letterEmailLogId`),
  KEY `FKhg4xhhaii1fjjct7joatracm8` (`outcomeCode`),
  KEY `FK53h5305tl5pm3c2igrk09il2o` (`paymentStatusCode`),
  KEY `FKmlp22s5hcwfvd8w8148ipbmcr` (`resultCode`),
  KEY `FKhssq3dwusbt1lugyk7my3dy1d` (`workflowId`),
  CONSTRAINT `FK4jrvnqvujk4hahr6dpxrqda9n` FOREIGN KEY (`letterId`) REFERENCES `files` (`id`),
  CONSTRAINT `FK53h5305tl5pm3c2igrk09il2o` FOREIGN KEY (`paymentStatusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKgkld29hvdpro8og5pdom3ychc` FOREIGN KEY (`ceCaseDecisionId`) REFERENCES `ce_case_decisions` (`id`),
  CONSTRAINT `FKhg4xhhaii1fjjct7joatracm8` FOREIGN KEY (`outcomeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKhssq3dwusbt1lugyk7my3dy1d` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`),
  CONSTRAINT `FKjqgpxyyhhtu305evdmgtphhuk` FOREIGN KEY (`ceCaseInfringementId`) REFERENCES `ce_case_infringements` (`id`),
  CONSTRAINT `FKkjbw1npe48kke3x57hmanaopx` FOREIGN KEY (`letterEmailLogId`) REFERENCES `email_logs` (`id`),
  CONSTRAINT `FKmlp22s5hcwfvd8w8148ipbmcr` FOREIGN KEY (`resultCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_case_appeals`
--

LOCK TABLES `ce_case_appeals` WRITE;
/*!40000 ALTER TABLE `ce_case_appeals` DISABLE KEYS */;
INSERT INTO `ce_case_appeals` VALUES (1,'stb_gabrieltww','2021-05-10 09:53:47.065204','stb_gabrieltww','2021-05-12 16:13:36.396751',1,NULL,NULL,'2020-02-18 00:00:00.000000','2001-2015-6123-9588',NULL,NULL,NULL,NULL,'\0',NULL,'\0',2879,4863,39013,NULL,'CE_OUTCOME_CAUTION','PAYREQ_N','CE_APPEAL_RESULT_NO',6468),(2,'stb_gabrieltww','2021-05-10 09:56:44.972519','stb_jasonchan','2021-05-18 17:38:45.962019',2,NULL,NULL,'2020-02-18 00:00:00.000000','2001-2015-1110-6520',NULL,NULL,NULL,NULL,'\0',NULL,'\0',2878,4862,39014,NULL,'CE_OUTCOME_CAUTION','PAYREQ_W','CE_APPEAL_RESULT_NO',6469);
/*!40000 ALTER TABLE `ce_case_appeals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:00
