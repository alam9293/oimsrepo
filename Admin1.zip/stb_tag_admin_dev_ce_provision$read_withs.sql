-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_provision$read_withs`
--

DROP TABLE IF EXISTS `ce_provision$read_withs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_provision$read_withs` (
  `ceProvisionId` int(11) NOT NULL,
  `readWithsId` int(11) NOT NULL,
  PRIMARY KEY (`ceProvisionId`,`readWithsId`),
  KEY `FKn7ykuedpqhssu67a2358checd` (`readWithsId`),
  CONSTRAINT `FKn7ykuedpqhssu67a2358checd` FOREIGN KEY (`readWithsId`) REFERENCES `ce_provisions` (`id`),
  CONSTRAINT `FKqlnkyr24w6sa55ch4uah2ch6a` FOREIGN KEY (`ceProvisionId`) REFERENCES `ce_provisions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_provision$read_withs`
--

LOCK TABLES `ce_provision$read_withs` WRITE;
/*!40000 ALTER TABLE `ce_provision$read_withs` DISABLE KEYS */;
INSERT INTO `ce_provision$read_withs` VALUES (22,3),(22,4),(1,5),(22,5),(22,8),(22,9),(22,10),(22,11),(22,12),(22,13),(22,14),(22,15),(22,16),(22,17),(22,18),(22,19),(21,27),(22,28),(22,29),(22,30),(22,31),(22,32),(22,33),(22,34),(22,35),(23,36),(23,37),(23,38),(23,39),(23,40),(23,41),(23,42),(23,43),(23,44),(23,45),(23,46),(23,47),(63,61),(64,62),(48,125),(149,125),(48,126),(149,126),(48,127),(149,127),(48,128),(149,128),(48,129),(149,129),(48,130),(66,130),(67,130),(68,130),(69,130),(70,130),(71,130),(72,130),(73,130),(74,130),(76,130),(79,130),(80,130),(103,130),(123,130),(149,130),(151,130),(152,130),(153,130),(48,131),(66,131),(67,131),(68,131),(69,131),(70,131),(71,131),(72,131),(73,131),(74,131),(76,131),(79,131),(80,131),(103,131),(123,131),(149,131),(151,131),(152,131),(153,131),(48,133),(49,133),(50,133),(51,133),(52,133),(53,133),(54,133),(55,133),(56,133),(57,133),(58,133),(59,133),(60,133),(61,133),(62,133),(63,133),(64,133),(65,133),(66,133),(67,133),(68,133),(69,133),(70,133),(71,133),(72,133),(73,133),(74,133),(75,133),(76,133),(77,133),(78,133),(79,133),(80,133),(81,133),(82,133),(83,133),(84,133),(85,133),(86,133),(87,133),(88,133),(89,133),(90,133),(91,133),(92,133),(93,133),(94,133),(95,133),(96,133),(97,133),(98,133),(99,133),(100,133),(101,133),(102,133),(103,133),(104,133),(105,133),(106,133),(107,133),(108,133),(109,133),(110,133),(111,133),(112,133),(113,133),(114,133),(115,133),(116,133),(117,133),(118,133),(119,133),(120,133),(121,133),(122,133),(123,133),(124,133),(134,133),(135,133),(136,133),(137,133),(138,133),(139,133),(140,133),(141,133),(143,133),(144,133),(145,133),(146,133),(147,133),(148,133),(149,133),(150,133),(151,133),(152,133),(153,133),(154,133),(155,133),(156,133),(157,133),(158,133),(159,133),(160,133);
/*!40000 ALTER TABLE `ce_provision$read_withs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:50
