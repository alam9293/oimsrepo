-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_check_document$files`
--

DROP TABLE IF EXISTS `ce_ta_check_document$files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_check_document$files` (
  `ceTaCheckDocumentId` int(11) NOT NULL,
  `filesId` int(11) NOT NULL,
  PRIMARY KEY (`ceTaCheckDocumentId`,`filesId`),
  KEY `FKsy7ei6cwarro6k2mni0c9lu6v` (`filesId`),
  CONSTRAINT `FK6dai5fow3cr89soa3w9ctujac` FOREIGN KEY (`ceTaCheckDocumentId`) REFERENCES `ce_ta_check_documents` (`id`),
  CONSTRAINT `FKsy7ei6cwarro6k2mni0c9lu6v` FOREIGN KEY (`filesId`) REFERENCES `files` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_check_document$files`
--

LOCK TABLES `ce_ta_check_document$files` WRITE;
/*!40000 ALTER TABLE `ce_ta_check_document$files` DISABLE KEYS */;
INSERT INTO `ce_ta_check_document$files` VALUES (2,17779),(1,17780),(3,17781),(4,17782),(4,17783),(5,17784),(5,17785),(6,17786),(6,17787),(7,17812),(8,17832),(9,17838),(10,17839),(11,17840),(12,17841),(13,18436),(14,18437),(15,18438),(15,18439),(16,18442),(16,18443),(17,18444),(17,18445),(18,18882),(19,18883),(20,18884),(21,19800),(22,19801);
/*!40000 ALTER TABLE `ce_ta_check_document$files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:36
