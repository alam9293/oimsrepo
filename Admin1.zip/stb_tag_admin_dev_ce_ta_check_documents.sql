-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_check_documents`
--

DROP TABLE IF EXISTS `ce_ta_check_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_check_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `invoiceBookingNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `noOfPax` int(11) DEFAULT NULL,
  `paymentDepositMade` decimal(19,2) DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalPrice` decimal(19,2) DEFAULT NULL,
  `ceTaCheckId` int(11) DEFAULT NULL,
  `isConsumerInformedCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqojd3q9wf4kgm678pmrua1xes` (`ceTaCheckId`),
  KEY `FKo50n7ihihrish009w6icj9mlk` (`isConsumerInformedCode`),
  CONSTRAINT `FKo50n7ihihrish009w6icj9mlk` FOREIGN KEY (`isConsumerInformedCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKqojd3q9wf4kgm678pmrua1xes` FOREIGN KEY (`ceTaCheckId`) REFERENCES `ce_ta_checks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_check_documents`
--

LOCK TABLES `ce_ta_check_documents` WRITE;
/*!40000 ALTER TABLE `ce_ta_check_documents` DISABLE KEYS */;
INSERT INTO `ce_ta_check_documents` VALUES (1,'stb_jinteckq','2019-12-09 09:43:01.988710','stb_jinteckq','2019-12-22 17:28:13.009393',3,'20191102',2,150.00,'Airport transfer',150.00,1,'FLAG_NA'),(2,'stb_jinteckq','2019-12-22 17:23:28.966193','stb_jinteckq','2019-12-22 17:28:13.014055',2,'20191101',9,1293.00,'Attraction tickets',1293.00,1,'FLAG_NA'),(3,'stb_jinteckq','2019-12-22 17:53:53.445464','stb_jinteckq','2019-12-22 17:53:53.445464',0,'SA19010',34,5100.00,'One of the inbound tour packages provided in the receipts.',5100.00,2,'FLAG_NA'),(4,'stb_jinteckq','2019-12-22 18:27:20.162390','stb_jinteckq','2019-12-22 18:27:20.162390',0,'ITHP-19-01-00128',2,6080.00,'Customers got their own travel insurance',6080.00,3,'FLAG_Y'),(5,'stb_jinteckq','2019-12-22 18:27:20.195238','stb_jinteckq','2019-12-22 18:27:20.195238',0,'JPHP-19-01-00127',1,3955.00,'Customer got her own travel insurance',3955.00,3,'FLAG_Y'),(6,'stb_jinteckq','2019-12-22 18:27:20.217227','stb_jinteckq','2019-12-22 18:27:20.217227',0,'JPHP-19-02-00109',2,5860.00,'Customers got their own travel insurance',5860.00,3,'FLAG_Y'),(7,'stb_jinteckq','2019-12-23 15:43:49.660071','stb_jinteckq','2019-12-23 15:46:14.049407',1,'SJ15117',1,969.00,'B2B air ticket',969.00,4,'FLAG_NA'),(8,'stb_jinteckq','2019-12-23 15:56:12.109367','stb_jinteckq','2019-12-23 16:17:05.051512',4,'101635',1,408.00,'Inbound accommodation',408.00,5,'FLAG_NA'),(9,'stb_jinteckq','2019-12-23 17:05:04.464961','stb_jinteckq','2019-12-23 17:11:44.653805',1,'INV2767',1,820.00,'',820.00,6,'FLAG_Y'),(10,'stb_jinteckq','2019-12-23 17:05:04.468047','stb_jinteckq','2019-12-23 17:11:44.654607',1,'INV2768',1,538.00,'',538.00,6,'FLAG_Y'),(11,'stb_jinteckq','2019-12-23 17:05:04.469246','stb_jinteckq','2019-12-23 17:11:44.655372',1,'INV2773',1,990.00,'',990.00,6,'FLAG_Y'),(12,'stb_jinteckq','2019-12-23 17:05:04.470664','stb_jinteckq','2019-12-23 17:11:44.656119',1,'INV2774',1,600.00,'',600.00,6,'FLAG_Y'),(13,'stb_jinteckq','2020-01-07 10:07:02.927703','stb_jinteckq','2020-01-07 10:15:33.303163',5,'11964',3,1247.00,'',1247.00,7,'FLAG_N'),(14,'stb_jinteckq','2020-01-07 10:07:02.952227','stb_jinteckq','2020-01-07 10:15:33.310633',5,'11963',3,357.00,'',357.00,7,'FLAG_N'),(15,'stb_jinteckq','2020-01-07 10:07:02.964230','stb_jinteckq','2020-01-07 10:15:33.311591',5,'INV-0228',3,3162.00,'',3162.00,7,'FLAG_N'),(16,'stb_jinteckq','2020-01-07 10:07:02.986228','stb_jinteckq','2020-01-07 10:15:33.312451',5,'INV-0212',1,407.00,'',407.00,7,'FLAG_N'),(17,'stb_jinteckq','2020-01-07 10:08:44.216067','stb_jinteckq','2020-01-07 10:15:33.313150',4,'INV-0198',3,1587.00,'',1587.00,7,'FLAG_N'),(18,'stb_jinteckq','2020-01-14 11:12:19.564573','stb_jinteckq','2020-01-14 11:17:41.339366',2,'HID2609',2,616.00,'',616.00,8,'FLAG_N'),(19,'stb_jinteckq','2020-01-14 11:12:19.575012','stb_jinteckq','2020-01-14 11:17:41.340224',2,'HID2590',3,2466.00,'',2466.00,8,'FLAG_N'),(20,'stb_jinteckq','2020-01-14 11:15:13.703935','stb_jinteckq','2020-01-14 11:17:41.341175',1,'HID2584',5,3997.00,'',3997.00,8,'FLAG_N'),(21,'stb_jinteckq','2020-02-05 14:01:47.648112','stb_jinteckq','2020-02-05 14:02:17.060736',1,'P0QX9W',2,375.00,'',375.00,9,'FLAG_Y'),(22,'stb_jinteckq','2020-02-05 14:01:47.657382','stb_jinteckq','2020-02-05 14:02:17.063432',1,'S89HCD',2,4208.00,'',4208.00,9,'FLAG_Y');
/*!40000 ALTER TABLE `ce_ta_check_documents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:42
