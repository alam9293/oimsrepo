-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_checks`
--

DROP TABLE IF EXISTS `ce_ta_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `checkedDate` datetime(6) DEFAULT NULL,
  `isAcknowledged` bit(1) NOT NULL DEFAULT b'0',
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `isDraft` bit(1) NOT NULL DEFAULT b'0',
  `lastAcknowledgedDate` date DEFAULT NULL,
  `licenceNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signdocId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taKeName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taKeUin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taStaffDesignation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taStaffName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressId` int(11) DEFAULT NULL,
  `addressTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auxEoUserCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ceCaseId` int(11) DEFAULT NULL,
  `ceTaCheckScheduleItemId` int(11) DEFAULT NULL,
  `eoUserId` int(11) DEFAULT NULL,
  `isCompliantCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastAcknowledgedById` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpjwvcrn91a5ydqx7i5m0f9rqn` (`addressId`),
  KEY `FKokd7ejoi4pxpnvt0g60p3fpga` (`addressTypeCode`),
  KEY `FK72t1auakdcevahe0x633ucnv2` (`auxEoUserCode`),
  KEY `FKb46wx6o8eoa0y52ipmuj0ew57` (`ceCaseId`),
  KEY `FKbq8co3h71rsuegpo2f85cxkdt` (`ceTaCheckScheduleItemId`),
  KEY `FKbqsqtetbnt5ujm5c05jypwp4w` (`eoUserId`),
  KEY `FK47qp6y6o2lrbtywungxr5lk2v` (`isCompliantCode`),
  KEY `FK9g6ygehik5avtgrn4ck3qmq9n` (`lastAcknowledgedById`),
  CONSTRAINT `FK47qp6y6o2lrbtywungxr5lk2v` FOREIGN KEY (`isCompliantCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK72t1auakdcevahe0x633ucnv2` FOREIGN KEY (`auxEoUserCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK9g6ygehik5avtgrn4ck3qmq9n` FOREIGN KEY (`lastAcknowledgedById`) REFERENCES `users` (`id`),
  CONSTRAINT `FKb46wx6o8eoa0y52ipmuj0ew57` FOREIGN KEY (`ceCaseId`) REFERENCES `ce_cases` (`id`),
  CONSTRAINT `FKbq8co3h71rsuegpo2f85cxkdt` FOREIGN KEY (`ceTaCheckScheduleItemId`) REFERENCES `ce_ta_check_schedule_items` (`id`),
  CONSTRAINT `FKbqsqtetbnt5ujm5c05jypwp4w` FOREIGN KEY (`eoUserId`) REFERENCES `users` (`id`),
  CONSTRAINT `FKokd7ejoi4pxpnvt0g60p3fpga` FOREIGN KEY (`addressTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKpjwvcrn91a5ydqx7i5m0f9rqn` FOREIGN KEY (`addressId`) REFERENCES `addresses` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_checks`
--

LOCK TABLES `ce_ta_checks` WRITE;
/*!40000 ALTER TABLE `ce_ta_checks` DISABLE KEYS */;
INSERT INTO `ce_ta_checks` VALUES (1,'stb_jinteckq','2019-12-09 09:43:01.600933','stb_deynac','2019-12-23 12:19:58.573994',9,'2019-12-22 17:28:15.012168','','\0','\0','2019-12-23','03042N','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','XFIAUTEFNRMFV0EZ0AXFNRKIGWXR3N','KE Name of 202003042T','S2020428F','Name of 202003042T','Key Executive','TA Staff 1','202003042T',29479,'TA_ADDR_OP','STB_JINTECKQ',3794,9,15,'FLAG_NA',6),(2,'stb_jinteckq','2019-12-22 17:53:53.323133','stb_deynac','2019-12-23 12:19:58.650906',4,'2019-12-22 17:53:55.460548','','\0','\0','2019-12-23','01552','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','EPVMEZW6NHMTJKKB3YY10HL0Z4PAKF','KE Name of 202001552T','S2020037D','Name of 202001552T','Key Executive','TA Staff 2','202001552T',28054,'TA_ADDR_OP','STB_JINTECKQ',3795,10,15,'FLAG_NA',6),(3,'stb_jinteckq','2019-12-22 18:27:19.946937','stb_deynac','2019-12-23 12:19:58.676528',4,'2019-12-22 18:27:38.511791','','\0','\0','2019-12-23','03001','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','PHMEDATEECMWBFNZXT48GMGTWS4RBV','KE Name of 202003001T','S2020345Z','Name of 202003001T','Key Executive','TA Staff 3','202003001T',34448,'TA_ADDR_OP','STB_JINTECKQ',3796,11,15,'FLAG_Y',6),(4,'stb_jinteckq','2019-12-23 15:43:49.571704','stb_deynac','2019-12-24 11:24:21.308446',5,'2019-12-23 15:46:18.052044','','\0','\0','2019-12-24','00679','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','FBQVESG7Y6MKUIK56NPLXDEOD5MF1F','KE Name of 202000679T','S2020438G','Name of 202000679T','Key Executive','TA Staff 4','202000679T',27402,'TA_ADDR_OP','CE_OEO_8',3798,16,15,'FLAG_NA',6),(5,'stb_jinteckq','2019-12-23 15:56:12.074015','stb_deynac','2019-12-24 11:24:21.358370',15,'2019-12-23 16:17:06.885984','','\0','\0','2019-12-24','01422','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','HYDZ6KIVAJ40ET3FU4GQACU6CM2SBF','KE Name of 202001422T','S2020769G','Name of 202001422T','Key Executive','TA Staff 5','202001422T',28163,'TA_ADDR_OP','CE_OEO_8',3799,14,15,'FLAG_NA',6),(6,'stb_jinteckq','2019-12-23 16:59:47.277599','stb_deynac','2019-12-24 11:24:21.386698',6,'2019-12-23 17:11:46.679351','','\0','\0','2019-12-24','03046','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','SENV2QAACBZB9TOL4UFC1CTO4UTRUI','KE Name of 202003046T','S2020589J','Name of 202003046T','Key Executive','TA Staff 6','202003046T',29475,'TA_ADDR_OP','CE_OEO_8',3800,12,15,'FLAG_Y',6),(7,'stb_jinteckq','2020-01-07 09:46:50.941485','stb_jinteckq','2020-01-07 10:20:04.169519',12,'2020-01-07 10:15:37.595721','\0','\0','\0',NULL,'03084','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','A3AJDGZUTHHFQBEHXWYB7HFTPJJSHO','KE Name of 202003084T','S2020086H','Name of 202003084T','Managing Director','TA Staff 7','202003084T',29304,'TA_ADDR_OP','STB_BAHARUDEENA',3923,22,15,'FLAG_N',NULL),(8,'stb_jinteckq','2020-01-14 10:58:05.176369','stb_jinteckq','2020-01-14 11:19:07.185321',9,'2020-01-14 11:17:53.010666','\0','\0','\0',NULL,'03080','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','O00YJO0EHM9QSXMFN8PCVJZL3PWO50','KE Name of 202003080T','S2020411F','Name of 202003080T','Manager','TA Staff 8','202003080T',35560,'TA_ADDR_OP','CE_OEO_7',3954,21,15,'FLAG_N',NULL),(9,'stb_jinteckq','2020-02-05 13:51:45.149884','stb_deynac','2020-02-06 15:27:30.423307',6,'2020-02-05 14:02:18.529261','','\0','\0','2020-02-06','03051','sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','OTY7NA2XDZ10GZNKBN5IINVYP4GWXU','KE Name of 202003051T','G2020313U','Name of 202003051T','Key Executive','TA Staff 9','202003051T',36038,'TA_ADDR_OP','CE_OEO_8',3997,20,15,'FLAG_Y',6);
/*!40000 ALTER TABLE `ce_ta_checks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:37
