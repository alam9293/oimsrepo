-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_field_report$classifications`
--

DROP TABLE IF EXISTS `ce_ta_field_report$classifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_field_report$classifications` (
  `ceTaFieldReportId` int(11) NOT NULL,
  `classificationsCode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ceTaFieldReportId`,`classificationsCode`),
  KEY `FKj96ly6hihketcmuu46tf88r4i` (`classificationsCode`),
  CONSTRAINT `FKei6ocff3piv9pfdr7k44emrai` FOREIGN KEY (`ceTaFieldReportId`) REFERENCES `ce_ta_field_reports` (`id`),
  CONSTRAINT `FKj96ly6hihketcmuu46tf88r4i` FOREIGN KEY (`classificationsCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_field_report$classifications`
--

LOCK TABLES `ce_ta_field_report$classifications` WRITE;
/*!40000 ALTER TABLE `ce_ta_field_report$classifications` DISABLE KEYS */;
INSERT INTO `ce_ta_field_report$classifications` VALUES (2,'CE_TA_CLASS_16'),(4,'CE_TA_CLASS_3'),(5,'CE_TA_CLASS_3'),(6,'CE_TA_CLASS_3'),(7,'CE_TA_CLASS_3'),(8,'CE_TA_CLASS_3'),(9,'CE_TA_CLASS_3'),(10,'CE_TA_CLASS_3'),(11,'CE_TA_CLASS_3'),(12,'CE_TA_CLASS_3'),(13,'CE_TA_CLASS_3'),(14,'CE_TA_CLASS_3'),(15,'CE_TA_CLASS_3'),(16,'CE_TA_CLASS_3'),(17,'CE_TA_CLASS_3'),(18,'CE_TA_CLASS_3'),(19,'CE_TA_CLASS_3'),(20,'CE_TA_CLASS_3'),(21,'CE_TA_CLASS_3'),(22,'CE_TA_CLASS_3'),(23,'CE_TA_CLASS_3'),(24,'CE_TA_CLASS_3'),(1,'CE_TA_CLASS_4'),(3,'CE_TA_CLASS_OTHERS');
/*!40000 ALTER TABLE `ce_ta_field_report$classifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:04
