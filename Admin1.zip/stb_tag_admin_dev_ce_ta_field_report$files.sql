-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_field_report$files`
--

DROP TABLE IF EXISTS `ce_ta_field_report$files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_field_report$files` (
  `ceTaFieldReportId` int(11) NOT NULL,
  `filesId` int(11) NOT NULL,
  PRIMARY KEY (`ceTaFieldReportId`,`filesId`),
  KEY `FK8key4ixcfd840iakmxxqem71e` (`filesId`),
  CONSTRAINT `FK8key4ixcfd840iakmxxqem71e` FOREIGN KEY (`filesId`) REFERENCES `files` (`id`),
  CONSTRAINT `FKq0t2tnjunqgwh5390go3ownie` FOREIGN KEY (`ceTaFieldReportId`) REFERENCES `ce_ta_field_reports` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_field_report$files`
--

LOCK TABLES `ce_ta_field_report$files` WRITE;
/*!40000 ALTER TABLE `ce_ta_field_report$files` DISABLE KEYS */;
INSERT INTO `ce_ta_field_report$files` VALUES (3,18523),(4,18803),(5,18805),(6,18807),(8,18814),(9,18818),(10,18819),(11,18966),(12,19291),(12,19292),(13,19293),(14,19304),(14,19305),(15,19311),(15,19312),(16,19733),(17,19736),(17,19737),(18,19738),(19,19740),(21,19760),(22,19761),(23,19763);
/*!40000 ALTER TABLE `ce_ta_field_report$files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:37
