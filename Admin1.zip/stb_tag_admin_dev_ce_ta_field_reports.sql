-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_field_reports`
--

DROP TABLE IF EXISTS `ce_ta_field_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_field_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `crmRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `isDraft` bit(1) NOT NULL DEFAULT b'0',
  `licenceNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otherClassification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personContactNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signdocId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taContactNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taOfficerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uinPassportNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressId` int(11) DEFAULT NULL,
  `addressTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ceCaseId` int(11) DEFAULT NULL,
  `ceTaCheckScheduleItemId` int(11) DEFAULT NULL,
  `witnessCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKet4ofaw0ns3y13nghspclx1ff` (`addressId`),
  KEY `FKahce9yg6wm891pec523608tjs` (`addressTypeCode`),
  KEY `FKp156ssik4v29h4xjmjib9y7t7` (`ceCaseId`),
  KEY `FKstjxgfeyw6inrn9dicdp5w74o` (`ceTaCheckScheduleItemId`),
  KEY `FK6w9a5i3gg89kkq2vjyp1d4kbl` (`witnessCode`),
  CONSTRAINT `FK6w9a5i3gg89kkq2vjyp1d4kbl` FOREIGN KEY (`witnessCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKahce9yg6wm891pec523608tjs` FOREIGN KEY (`addressTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKet4ofaw0ns3y13nghspclx1ff` FOREIGN KEY (`addressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKp156ssik4v29h4xjmjib9y7t7` FOREIGN KEY (`ceCaseId`) REFERENCES `ce_cases` (`id`),
  CONSTRAINT `FKstjxgfeyw6inrn9dicdp5w74o` FOREIGN KEY (`ceTaCheckScheduleItemId`) REFERENCES `ce_ta_check_schedule_items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_field_reports`
--

LOCK TABLES `ce_ta_field_reports` WRITE;
/*!40000 ALTER TABLE `ce_ta_field_reports` DISABLE KEYS */;
INSERT INTO `ce_ta_field_reports` VALUES (1,'stb_janetf','2019-12-05 11:07:45.897253','stb_janetf','2019-12-05 11:17:52.420603',2,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03098','Name of 202003098T',NULL,'90470058','STB/TA/CO/2019/00001','Key Executive, Director, Shareholder','OLVHVKJKPPUMWCWEH8UCQZOLPMDRDK','91234567','Name of 202003098T','TA Officer 1','202003098T','S2020265G',32212,'TA_ADDR_OP',3774,NULL,'STB_SEOWHWANG'),(2,'stb_janetf','2020-01-07 15:58:40.888152','stb_janetf','2020-01-07 16:02:47.180372',1,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','02433','Name of 202002433T',NULL,NULL,'STB/TA/CO/2020/00001','Director','M7GEOZ0Z9LUSSWGSJYF5YFHZMIMW7G','91234567','Name of 202002433T','TA Officer 2','202002433T','S2020520J',29031,'TA_ADDR_OP',3110,NULL,'STB_SEOWHWANG'),(3,'stb_jinteckq','2020-01-08 09:57:51.902360','stb_jinteckq','2020-01-08 09:58:13.491632',1,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','02394','Name of 202002394T','Ad hoc check for TATI in lieu of insolvency issue',NULL,'STB/TA/CO/2020/00002',NULL,'FTMT1PTXZZB7NLOLEEQRDABU0HB3P5','91234567','Name of 202002394T','TA Officer 3','202002394T',NULL,28695,'TA_ADDR_OP',3925,19,'CE_OEO_7'),(4,'stb_jinteckq','2020-01-13 13:19:57.350247','stb_jinteckq','2020-01-13 13:21:07.192120',1,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','02850','Name of 202002850T',NULL,NULL,'STB/TA/CO/2020/00003',NULL,'NRZNWZSQVCU0YHQNBFOXGKNYAD2CRZ','91234567','Name of 202002850T','TA Officer 4','202002850T',NULL,29302,'TA_ADDR_OP',3944,58,'CE_OEO_7'),(5,'stb_jinteckq','2020-01-13 13:35:33.140864','stb_jinteckq','2020-01-13 13:36:46.270946',1,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','02238','Name of 202002238T',NULL,NULL,'STB/TA/CO/2020/00004',NULL,'1WSCTT3SMGXBI58UPJX2GRDXRATDUT','91234567','Name of 202002238T','TA Officer 5','202002238T',NULL,28855,'TA_ADDR_OP',3945,57,'CE_OEO_7'),(6,'stb_jinteckq','2020-01-13 14:00:22.903477','stb_jinteckq','2020-01-13 14:01:58.821037',2,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','02219','Name of 202002219T',NULL,'98773537','STB/TA/CO/2020/00005','Manager','K8GYWGQVU7ZGEIBSEYZT1UPDUVBOLC','91234567','Name of 202002219T','TA Officer 6','202002219T',NULL,28869,'TA_ADDR_OP',3946,55,'CE_OEO_7'),(7,'stb_jinteckq','2020-01-13 14:08:00.866453','stb_jinteckq','2020-01-13 14:09:00.890856',1,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03074','Name of 202003074T',NULL,'90660997','STB/TA/CO/2020/00006','Manager','63P2WO1V4ESWPUWUXSGZ95GDAPGPCU','91234567','Name of 202003074T','TA Officer 7','202003074T',NULL,29496,'TA_ADDR_OP',3947,56,'CE_OEO_7'),(8,'stb_jinteckq','2020-01-13 14:35:11.435915','stb_jinteckq','2020-01-13 14:39:54.620565',3,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03170','Name of 202003170T',NULL,NULL,'STB/TA/CO/2020/00007',NULL,'JNY0HOUWIT0FHUMOVNXPRAZG34KQA9','91234567','Name of 202003170T','TA Officer 8','202003170T',NULL,29547,'TA_ADDR_OP',3948,59,'CE_OEO_7'),(9,'stb_jinteckq','2020-01-13 15:19:18.725625','stb_jinteckq','2020-01-13 15:20:06.162231',1,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03219','Name of 202003219T',NULL,NULL,'STB/TA/CO/2020/00008',NULL,'IGKNG6YRYNFWRXW7GZ3IZ8ASEXJQ1E','91234567','Name of 202003219T','TA Officer 9','202003219T',NULL,29246,'TA_ADDR_OP',3951,61,'CE_OEO_7'),(10,'stb_jinteckq','2020-01-13 15:27:16.028579','stb_jinteckq','2020-01-13 15:29:14.226173',2,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03150','Name of 202003150T',NULL,NULL,'STB/TA/CO/2020/00009',NULL,'YYC9NYPS5ZGCGMBCDFXFLEA8JKGVDU','91234567','Name of 202003150T','TA Officer 10','202003150T',NULL,29560,'TA_ADDR_OP',3952,60,'CE_OEO_7'),(11,'stb_jinteckq','2020-01-15 15:39:30.294448','stb_jinteckq','2020-01-15 15:49:12.984517',2,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','00509','Name of 202000509T',NULL,NULL,'STB/TA/CO/2020/00010',NULL,'SOT11I8TGYE57OYJ6RBKIJ8BUQDXCQ','91234567','Name of 202000509T','TA Officer 11','202000509T',NULL,27248,'TA_ADDR_OP',3955,62,'CE_OEO_7'),(12,'stb_jinteckq','2020-01-21 11:10:24.997614','stb_jinteckq','2020-01-21 11:16:46.136977',4,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03094','Name of 202003094T',NULL,'62616162','STB/TA/CO/2020/00011','Associate manager','Q6SONDKUCJC9WEQEY46DQ2ETWYA7L3','91234567','Name of 202003094T','TA Officer 12','202003094T',NULL,29520,'TA_ADDR_OP',3962,96,'CE_OEO_7'),(13,'stb_jinteckq','2020-01-21 11:46:07.851759','stb_jinteckq','2020-01-21 11:51:57.760170',2,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03194','Name of 202003194T',NULL,'65630544','STB/TA/CO/2020/00012','Manager','R7O3S4WSTHFOUU6XRXO8WGW11IK0MY','91234567','Name of 202003194T','TA Officer 13','202003194T',NULL,29468,'TA_ADDR_OP',3963,97,'CE_OEO_7'),(14,'stb_jinteckq','2020-01-21 12:39:55.589991','stb_jinteckq','2020-01-21 14:11:50.798937',8,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03223','Name of 202003223T',NULL,'81758070','STB/TA/CO/2020/00013','Key Executive','KTWPX0F0U1LZE6UCOQGLURRCTSXS67','91234567','Name of 202003223T','TA Officer 14','202003223T',NULL,29586,'TA_ADDR_OP',3964,91,'CE_OEO_7'),(15,'stb_jinteckq','2020-01-21 17:08:26.690950','stb_jinteckq','2020-01-21 17:14:04.142898',3,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','01930','Name of 202001930T',NULL,NULL,'STB/TA/CO/2020/00014',NULL,'890NYAOH1X9L5PWL27QX18SMHOIZW9','91234567','Name of 202001930T','TA Officer 15','202001930T',NULL,28608,'TA_ADDR_OP',3965,87,'CE_OEO_7'),(16,'stb_jinteckq','2020-02-03 11:23:29.255605','stb_jinteckq','2020-02-03 11:25:47.881096',1,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03180','Name of 202003180T',NULL,NULL,'STB/TA/CO/2020/00015',NULL,'BI77JB780IOJMWAVUQSGNLJL3YWPH8','91234567','Name of 202003180T','TA Officer 16','202003180T',NULL,21226,'TA_ADDR_OP',3986,93,'CE_OEO_9'),(17,'stb_jinteckq','2020-02-03 11:43:59.861129','stb_jinteckq','2020-02-03 11:50:34.294291',4,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03224','Name of 202003224T',NULL,NULL,'STB/TA/CO/2020/00016',NULL,'L3SFOGUAF74ER8W8AVG3MC17WJKSCM','91234567','Name of 202003224T','TA Officer 17','202003224T',NULL,28798,'TA_ADDR_OP',3987,92,'CE_OEO_9'),(18,'stb_jinteckq','2020-02-03 12:07:50.938420','stb_jinteckq','2020-02-03 12:39:08.878525',7,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','02606','Name of 202002606T',NULL,'82334706','STB/TA/CO/2020/00017','Key Executive','QJODVOCDTIP358OLEWA5PHVJQ8LCUW','91234567','Name of 202002606T','TA Officer 18','202002606T',NULL,29665,'TA_ADDR_OP',3988,90,'CE_OEO_9'),(19,'stb_jinteckq','2020-02-03 14:48:51.777299','stb_jinteckq','2020-02-03 15:02:04.646551',3,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','01371','Jessica Neo',NULL,NULL,'STB/TA/CO/2020/00018','Manager','QUPNYM2JCKYHDL4IOIA3KA2EGYNPYS','63193297 / 97420011','SISTIC.COM PTE LTD','Jessica Neo','200006659E',NULL,27909,'TA_ADDR_OP',3989,89,'CE_OEO_9'),(20,'stb_jinteckq','2020-02-03 15:57:18.539635','stb_jinteckq','2020-02-03 16:41:17.566215',5,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','01754','Name of 202001754T',NULL,NULL,'STB/TA/CO/2020/00019','Director','MB7VSMDLHLKWB6LSJBNB5UPSKXYOIL','91234567','Name of 202001754T','TA Officer 20','202001754T',NULL,28427,'TA_ADDR_OP',3990,88,'CE_OEO_9'),(21,'stb_jinteckq','2020-02-04 12:33:48.677025','stb_jinteckq','2020-02-04 12:39:20.588824',4,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03220','Name of 202003220T',NULL,NULL,'STB/TA/CO/2020/00020',NULL,'I9LTG6CPP9WVVW1O0N83BR2AKF7T2T','91234567','Name of 202003220T','TA Officer 21','202003220T',NULL,29577,'TA_ADDR_OP',3992,95,'CE_OEO_9'),(22,'stb_jinteckq','2020-02-04 12:51:37.694676','stb_jinteckq','2020-02-04 12:57:33.028708',2,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','01222','Name of 202001222T',NULL,NULL,'STB/TA/CO/2020/00021',NULL,'PRRJNT3HFLUBNE6BVBXOQG75HICGVB','91234567','Name of 202001222T','TA Officer 22','202001222T',NULL,27958,'TA_ADDR_OP',3993,94,'CE_OEO_9'),(23,'stb_jinteckq','2020-02-04 14:24:52.713268','stb_jinteckq','2020-02-04 14:34:02.765968',4,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','03097','Name of 202003097T',NULL,NULL,'STB/TA/CO/2020/00022',NULL,'UEWUHXMYKMIBAKCDGVXPTHPVBUJKPJ','91234567','Name of 202003097T','TA Officer 23','202003097T',NULL,36121,'TA_ADDR_OP',3994,86,'CE_OEO_9'),(24,'stb_jinteckq','2020-02-04 15:25:06.781039','stb_jinteckq','2020-02-04 15:56:45.475815',10,NULL,'sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text sample text','\0','\0','02223','Name of 202002223T',NULL,'98630177','STB/TA/CO/2020/00023',NULL,'KOBECMVRD6ZFVHXFPV58506TTT2WQF','91234567','Name of 202002223T','TA Officer 24','202002223T',NULL,28836,'TA_ADDR_OP',3995,85,'CE_OEO_9');
/*!40000 ALTER TABLE `ce_ta_field_reports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:43
