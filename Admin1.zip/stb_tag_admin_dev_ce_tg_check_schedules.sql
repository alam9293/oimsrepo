-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_tg_check_schedules`
--

DROP TABLE IF EXISTS `ce_tg_check_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_tg_check_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fromDate` date DEFAULT NULL,
  `toDate` date DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `workflowId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7ei9angai90olvvlyiya2h5ok` (`workflowId`),
  CONSTRAINT `FK7ei9angai90olvvlyiya2h5ok` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_tg_check_schedules`
--

LOCK TABLES `ce_tg_check_schedules` WRITE;
/*!40000 ALTER TABLE `ce_tg_check_schedules` DISABLE KEYS */;
INSERT INTO `ce_tg_check_schedules` VALUES (1,'stb_asrulfahmir','2019-12-02 16:40:49.615138','stb_asrulfahmir','2019-12-02 16:44:19.692055',1,'2019-12-02','2019-12-08',2019,4202),(2,'stb_asrulfahmir','2019-12-02 16:57:22.431329','stb_asrulfahmir','2019-12-02 16:59:43.487832',1,'2019-12-09','2019-12-15',2019,4203),(3,'stb_asrulfahmir','2019-12-11 15:16:04.844573','stb_asrulfahmir','2019-12-13 09:12:44.542709',1,'2019-12-16','2019-12-22',2019,4441),(4,'stb_asrulfahmir','2019-12-11 15:43:11.377429','stb_asrulfahmir','2019-12-19 12:18:27.279544',1,'2019-12-23','2019-12-29',2019,4497),(5,'stb_felany','2019-12-26 11:33:19.701452','stb_felany','2019-12-26 12:35:58.436943',1,'2019-12-30','2020-01-05',2019,4530),(6,'stb_asrulfahmir','2020-01-02 10:40:08.997295','stb_asrulfahmir','2020-01-02 10:52:59.428901',1,'2020-01-06','2020-01-12',2020,4553),(7,'stb_asrulfahmir','2020-01-07 18:09:41.855801','stb_asrulfahmir','2020-01-09 08:45:46.888187',1,'2020-01-13','2020-01-19',2020,4636),(8,'stb_asrulfahmir','2020-01-09 07:20:03.367589','stb_asrulfahmir','2020-01-16 23:05:42.351068',1,'2020-01-20','2020-01-26',2020,4664),(9,'stb_asrulfahmir','2020-01-09 07:24:09.669469','stb_asrulfahmir','2020-01-23 09:32:21.384103',1,'2020-01-27','2020-02-02',2020,4685),(10,'stb_asrulfahmir','2020-01-20 11:59:34.347667','stb_asrulfahmir','2020-01-30 12:16:49.861051',1,'2020-02-03','2020-02-09',2020,4700),(11,'stb_asrulfahmir','2020-02-03 09:47:18.675459','stb_mfadlyo','2020-02-07 17:36:31.397639',1,'2020-02-10','2020-02-16',2020,4720),(12,'stb_asrulfahmir','2020-02-03 09:57:04.982155','stb_mfadlyo','2020-02-13 17:58:45.608453',1,'2020-02-17','2020-02-23',2020,4733),(13,'stb_asrulfahmir','2020-02-19 12:31:15.432493','stb_noorsakinna','2020-02-24 17:04:29.887223',1,'2020-02-24','2020-03-01',2020,4779),(14,'stb_noorsakinna','2020-02-19 15:33:32.372598','stb_noorsakinna','2020-03-02 09:24:42.141402',1,'2020-03-02','2020-03-08',2020,4807),(15,'stb_noorsakinna','2020-03-06 09:45:00.921334','stb_noorsakinna','2020-03-06 11:16:42.776968',1,'2020-03-09','2020-03-15',2020,4814),(16,'stb_noorsakinna','2020-03-12 09:48:21.601336','stb_noorsakinna','2020-03-16 14:38:47.216645',1,'2020-03-16','2020-03-22',2020,4833),(17,'stb_noorsakinna','2020-03-12 11:19:53.876642','stb_noorsakinna','2020-03-23 10:22:04.757495',1,'2020-03-23','2020-03-29',2020,4839),(18,'stb_noorsakinna','2020-04-02 21:07:03.606968','stb_noorsakinna','2020-04-14 09:55:19.422130',1,'2020-03-30','2020-04-05',2020,4892),(19,'stb_noorsakinna','2020-04-02 21:10:34.607462','stb_noorsakinna','2020-04-14 09:55:44.966170',1,'2020-04-06','2020-04-12',2020,4893),(20,'stb_noorsakinna','2020-04-14 10:00:37.246047','stb_noorsakinna','2020-04-14 10:00:50.081724',1,'2020-04-13','2020-04-19',2020,4894);
/*!40000 ALTER TABLE `ce_tg_check_schedules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:01
