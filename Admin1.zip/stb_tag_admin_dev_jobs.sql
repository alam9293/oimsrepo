-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `className` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cronExpression` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` bit(1) NOT NULL DEFAULT b'0',
  `lastEndDate` datetime(6) DEFAULT NULL,
  `lastRunBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastStartDate` datetime(6) DEFAULT NULL,
  `scheduleDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastRunStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK58jql6ddp9w2e4o0xwivh62je` (`lastRunStatusCode`),
  CONSTRAINT `FK58jql6ddp9w2e4o0xwivh62je` FOREIGN KEY (`lastRunStatusCode`) REFERENCES `statuses` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 14:00:03.320778',35558,'gov.stb.tag.job.TaLicenceCreationJob','0 0 * * * ?','For creation of licence for TA Licence Creation App which Licence Fee Payment has been settled.','\0','2021-05-20 14:00:03.320376','system','2021-05-20 14:00:02.313798','Every hour of every day','JOB_SUCCESS'),(2,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 00:25:00.038747',1482,'gov.stb.tag.job.TaLicenceCessationJob','0 25 0 * * ?','For cessation of licence which TA applied in advance.','\0','2021-05-20 00:25:00.038475','system','2021-05-20 00:25:00.024774','Everyday 00:25','JOB_SUCCESS'),(3,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 02:00:19.812099',1482,'gov.stb.tag.job.AppDraftDeleteJob','0 0 2 * * ?','For deletion of draft applications created more than 90 days ago.','\0','2021-05-20 02:00:19.805369','system','2021-05-20 02:00:19.122867','Everyday 02:00','JOB_SUCCESS'),(4,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 00:30:03.189109',1478,'gov.stb.tag.job.LicenceExpiredLapsedJob','0 30 0 * * ?','For lapsing of expired licences','\0','2021-05-20 00:30:03.188807','system','2021-05-20 00:30:02.682712','Everyday 00:30','JOB_SUCCESS'),(5,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 14:30:02.069790',35546,'gov.stb.tag.job.TaBranchLicenceJob','0 30 * * * ?','For creation of licence for TA Licence branch App which Branch Licence Fee Payment has been settled.','\0','2021-05-20 14:30:02.069578','system','2021-05-20 14:30:01.980715','Every hour of every day at :30 minute','JOB_SUCCESS'),(6,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 00:01:03.637365',1484,'gov.stb.tag.job.TaAnnualFilingJob','0 1 0 * * ?','For creation of TA Annual Filing.','\0','2021-05-20 00:01:03.631809','system','2021-05-20 00:01:00.379503','Everyday 00:01','JOB_SUCCESS'),(7,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 00:30:02.493859',1482,'gov.stb.tag.job.TaLicenceTierSwitchJob','0 30 0 * * ?','For licence Tier Switch which TA applied in advance.','\0','2021-05-20 00:30:02.493593','system','2021-05-20 00:30:02.273451','Everyday 00:30','JOB_SUCCESS'),(8,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 14:30:01.892655',70438,'gov.stb.tag.job.ApplicationFileTxfAdminJob','0 0/30 * * * ?','For getting file transfer between Internet to Intranet.','\0','2021-05-20 14:30:01.881629','system','2021-05-20 14:30:00.010024','Every hour at :30 minute','JOB_WARNING'),(9,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-15 00:13:37.658635',166,'gov.stb.tag.job.StanExtractionJob','0 6 0 15 * ?','For generating stan file.','\0','2021-05-15 00:13:37.608630','system','2021-05-15 00:06:00.346156','On every month 15th 6am','JOB_SUCCESS'),(10,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-01-01 00:00:57.101886',54,'gov.stb.tag.job.GenerateRandomPasswordJob','0 0 0 1 1 ?','For generating random password to STB users (force run)','\0','2021-01-01 00:00:57.101659','system','2021-01-01 00:00:57.035687','First January 2019','JOB_SUCCESS'),(11,'SYSTEM','2019-04-26 12:45:31.000000','system','2021-05-20 06:00:16.515271',1532,'gov.stb.tag.job.TaReportGenerationJob','0 0 6 * * ?','For generating ta report file.','\0','2021-05-20 06:00:16.514700','FORCE RUN','2021-05-20 06:00:00.014036','Everyday 06:00','JOB_SUCCESS'),(12,'SYSTEM','2019-07-05 08:02:50.000000','system','2021-05-05 03:15:14.493800',68,'gov.stb.tag.job.CpfTgActiveLicenceExtractionJob','0 15 3 5 * ?','For generating cpf file for active TG.','\0','2021-05-05 03:15:14.461927','system','2021-05-05 03:15:00.239470','At 03:15:00am, on the 5th day, every month','JOB_SUCCESS'),(13,'SYSTEM','2019-07-11 16:59:26.000000','system','2019-07-12 14:00:27.188747',4,'gov.stb.tag.job.TgCourseAttendanceApplicationPatchJob','0 0 14 12 7 ?','For patching Tg Course Attendance.','\0','2019-07-12 14:00:27.061886','FORCE RUN','2019-07-12 14:00:00.609774','On every 12 July 2pm','JOB_SUCCESS'),(14,'SYSTEM','2019-07-26 01:42:43.000000','system','2021-05-20 14:00:00.032679',31286,'gov.stb.tag.job.TaLicenceRenewalJob','0 0 * * * ?','For renewal of licence for TA Licence Renewal App which Licence Fee Payment has been settled.','\0','2021-05-20 14:00:00.032365','system','2021-05-20 14:00:00.010113','Every hour of every day','JOB_SUCCESS'),(15,'SYSTEM','2019-07-26 01:42:43.000000','system','2021-05-20 14:10:00.371905',31266,'gov.stb.tag.job.FileTxfAdminJob','0 10 0/1 * * ?','For putting file to transfer from Intranet to Internet.','\0','2021-05-20 14:10:00.371448','system','2021-05-20 14:10:00.009076','Every hour at :10 minute','JOB_SUCCESS'),(16,'SYSTEM','2019-08-30 08:09:52.000000','system','2021-05-20 08:00:00.068824',1076,'gov.stb.tag.job.EmailNotificationJob','0 0 8 * *  ?','For email reminders','\0','2021-05-20 08:00:00.068557','system','2021-05-20 08:00:00.045298','Everyday 08:00','JOB_SUCCESS'),(17,'SYSTEM','2019-08-30 08:09:52.000000','system','2022-05-30 21:17:17.126484',841,'gov.stb.tag.job.TaFilingEmailNotificationJob','0 0 6 * * ?','Email reminder for TA filing submission','\0','2022-05-30 21:17:17.098595','FORCE RUN','2022-05-30 16:48:22.842458','Everyday 06:00','JOB_SUCCESS'),(18,'SYSTEM','2019-09-05 17:49:23.000000','system','2019-09-06 08:18:09.739681',2,'gov.stb.tag.job.TaOpAddressPatchJob','0 0 14 06 9 ?','For patching Ta Operating Address.','\0','2019-09-06 08:18:09.632588','FORCE RUN','2019-09-06 08:17:55.606263','On every 06 Sep 2pm','JOB_SUCCESS'),(19,'SYSTEM','2019-11-28 20:20:48.000000','system','2021-05-20 00:10:05.845108',662,'gov.stb.tag.job.CeTaskJob','0 10 0 * * ?','For creation of CE Task.','\0','2021-05-20 00:10:05.840114','system','2021-05-20 00:10:00.454961','Everyday 00:10','JOB_SUCCESS'),(20,'SYSTEM','2019-11-28 20:20:48.000000','system','2021-05-20 00:01:00.233584',1052,'gov.stb.tag.job.CeCaseSuspensionRevocationJob','0 1 0 * * ?','For suspension or revocation, lift suspension and suspension end trigger','\0','2021-05-20 00:01:00.233101','system','2021-05-20 00:01:00.039519','Everyday 00:01','JOB_SUCCESS'),(21,'SYSTEM','2019-11-28 20:20:48.000000','system','2021-05-20 00:30:08.240863',1054,'gov.stb.tag.job.CeConcludeCaseJob','1 30 0 * * ?','Batch job that auto conclude ce case','\0','2021-05-20 00:30:08.236781','system','2021-05-20 00:30:03.218100','Everyday 1:30','JOB_SUCCESS'),(22,'SYSTEM','2020-01-10 08:17:57.000000','system','2021-05-20 14:35:00.024752',23270,'gov.stb.tag.job.TaLicenceReplacementJob','0 35 * * * ?','For TA Licence Replacement licence printing.','\0','2021-05-20 14:35:00.024477','system','2021-05-20 14:35:00.009503','Every hour of every day at :35 minute','JOB_SUCCESS'),(23,'SYSTEM','2020-01-31 08:43:30.000000','system','2021-05-05 05:15:00.699315',36,'gov.stb.tag.job.CpfRequestTaActiveLicenceJob','0 15 5 5 * ?','To generate Active TA list to CPF.','\0','2021-05-05 05:15:00.689147','system','2021-05-05 05:15:00.049590','At 05:15:00am, on the 5th day of every month','JOB_SUCCESS'),(24,'SYSTEM','2020-01-31 08:43:30.000000','system','2021-05-14 05:30:29.488836',40,'gov.stb.tag.job.CpfResponseTaActiveLicenceJob','0 30 5 14 * ?','To process TA CPF arrears response file from CPF.','\0','2021-05-14 05:30:29.478561','system','2021-05-14 05:30:00.202135','At 05:30:00am, on the 14th day of every month','JOB_SUCCESS'),(25,'SYSTEM','2020-01-31 08:43:30.000000','system','2021-05-14 06:15:00.985765',38,'gov.stb.tag.job.TaCpfArrearNotificationJob','0 15 6 14 * ?','To send email notitication to officers that TA has consecutive CPF arrears.','\0','2021-05-14 06:15:00.985199','system','2021-05-14 06:15:00.050053','At 06:15:00am, on the 14th day of every month','JOB_SUCCESS'),(26,'SYSTEM','2020-01-31 08:43:30.000000','system','2021-05-20 00:20:29.482419',854,'gov.stb.tag.job.TgLicenceExpiryReminderJob','0 20 0 * * ?','To remind TG that licence is expiring soon','\0','2021-05-20 00:20:29.475859','system','2021-05-20 00:20:00.014937','Everyday 00:20','JOB_SUCCESS'),(27,'SYSTEM','2020-01-31 08:43:30.000000','system','2021-05-20 00:06:00.049630',928,'gov.stb.tag.job.EmailBroadcastJob','0 6 0 * * ?','Email Broadcast to licensee','\0','2021-05-20 00:06:00.049201','system','2021-05-20 00:06:00.013792','Everyday 00:06','JOB_SUCCESS'),(28,'SYSTEM','2020-02-28 08:18:55.000000','system','2021-05-14 05:15:01.307630',34,'gov.stb.tag.job.CpfResponseTaFileTxfJob','0 15 5 14 * ?','To get TA CPF arrears response file from CPF.','\0','2021-05-14 05:15:01.303215','system','2021-05-14 05:15:00.510001','At 05:15:00am, on the 14th day of every month','JOB_SUCCESS'),(29,'SYSTEM','2020-02-28 08:22:17.000000','system','2021-01-01 00:00:11.046994',4,'gov.stb.tag.job.EmailQliksensePasswordJob','0 0 0 1 1 ?','For emailing Qliksense password to STB users (force run)','\0','2021-01-01 00:00:11.045786','system','2021-01-01 00:00:00.056585','First January 2019','JOB_SUCCESS'),(30,'SYSTEM','2020-05-18 08:48:17.000000','system','2021-05-19 17:00:05.232384',520,'gov.stb.tag.job.EmailPendingTasksJob','0 0 17 * * 1,2,3,4,5','Email list of pending tasks to certain STB officer roles','\0','2021-05-19 17:00:05.210636','system','2021-05-19 17:00:03.536114','Every weekday 17:00','JOB_SUCCESS'),(31,'SYSTEM','2021-05-20 16:47:15.000000','system','2022-06-07 08:19:44.836543',12,'gov.stb.tag.job.TgLicenceExpiredNotificationJob','0 0 6 * * ?','To remind TG to return the expired tourist guide licence','','2022-06-07 08:19:44.832554','system','2022-06-07 08:19:44.527374','Everyday 06:00','JOB_SUCCESS'),(33,'SYSTEM	','2019-08-30 08:09:52.000000','system','2022-07-17 12:00:03.702741',11,'gov.stb.tag.job.TaFilingEmailNotificationMonthlyInfographicsJob','0 0 6 * * ?','Infographics Monthly Reminder	','','2022-07-17 12:00:03.700749','FORCE RUN',NULL,'Everyday 06:00','JOB_SUCCESS');
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:54
