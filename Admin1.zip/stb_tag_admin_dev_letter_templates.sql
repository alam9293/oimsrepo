-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `letter_templates`
--

DROP TABLE IF EXISTS `letter_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `letter_templates` (
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` bit(1) NOT NULL DEFAULT b'0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `letter_templates`
--

LOCK TABLES `letter_templates` WRITE;
/*!40000 ALTER TABLE `letter_templates` DISABLE KEYS */;
INSERT INTO `letter_templates` VALUES ('TA_SHORTFALL_LETTER','SYSTEM','2021-09-20 16:06:00.000000','SYSTEM','2021-09-20 16:06:00.000000',0,'<p>Dear ${ke_name} (Key Executive),</p><p><br></p><p><strong>MINIMUM FINANCIAL REQUIREMENTS</strong></p><p><br></p><p>Name of Licensee: ${ta_name}</p><p>UEN: ${ta_uen}</p><p>Travel Agent Licence No.: ${licence_no}</p><p><br></p><p>1. We refer to the recent submission of the licensee\'s ${shortfall_for} as at ${fye}.</p><p><br></p><p>2. The said accounts show that the licensee has a net value of ${net_value} as at ${fye}. The Board is thus cognisant that the licensee\'s net value is less than ${ta_mfr} and in contravention of Regulation 9(1AA) of the Travel Agents Regulations (\"TAR\") 2017.</p><p><br></p><p>3. Pursuant to Regulation 9(1AA) of the TAR, the Board hereby requires the licensee to provide the Board by ${rectification_due_date} with recent proof that it has rectified the net value shortfall amount of ${shortfall_amt} and that it is not in contravention of the Regulation 9(1AA) requirement. The proof required includes the latest Accounting and Corporate Regulatory Authority (ACRA) business profile (dated within last 3 months from date of this letter) and the bank deposit slip evidencing top-up of the paid-up capital.</p><p><br></p><p>4. Please provide proof of your rectification by ${rectification_due_date} in the TRUST website (https://trust.stb.gov.sg), which can be accessed by the company\'s CorpPass, to avoid the imposition of administrative action such as financial penalty, suspension or revocation.</p><p><br></p><p>5. If you have any queries, you can write to us at ${ta_support_email}</p><p><br></p><p>Thank You,</p><p><br></p><p>Travel Agent Licensing & Regulatory Review Department<br>Singapore Tourism Board</p><p><br></p><p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at ${ta_support_email} for any queries.***</p>',NULL,'','TA Shortfall Letter');
/*!40000 ALTER TABLE `letter_templates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:50
