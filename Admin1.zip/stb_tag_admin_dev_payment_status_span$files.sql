-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payment_status_span$files`
--

DROP TABLE IF EXISTS `payment_status_span$files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_status_span$files` (
  `paymentStatusSpanId` int(11) NOT NULL,
  `filesId` int(11) NOT NULL,
  PRIMARY KEY (`paymentStatusSpanId`,`filesId`),
  KEY `FKoa36ujyytrax6anps048gtm7x` (`filesId`),
  CONSTRAINT `FK8ccy6u2pboxgu5dluahjpid59` FOREIGN KEY (`paymentStatusSpanId`) REFERENCES `payment_status_spans` (`id`),
  CONSTRAINT `FKoa36ujyytrax6anps048gtm7x` FOREIGN KEY (`filesId`) REFERENCES `files` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_status_span$files`
--

LOCK TABLES `payment_status_span$files` WRITE;
/*!40000 ALTER TABLE `payment_status_span$files` DISABLE KEYS */;
INSERT INTO `payment_status_span$files` VALUES (5352,25849),(5438,25922),(5439,25923),(5589,26153),(5733,26314),(5787,26423),(6452,26914),(6930,27195),(9799,33052),(9799,33053),(9799,33054),(13367,37402),(13368,37403),(13399,37426),(13399,37427);
/*!40000 ALTER TABLE `payment_status_span$files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:50
