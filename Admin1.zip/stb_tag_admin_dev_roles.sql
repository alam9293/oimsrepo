-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `isAssignable` bit(1) NOT NULL DEFAULT b'0',
  `isConfigurable` bit(1) DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordinal` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('CNE_CO',NULL,NULL,'stb_mervynl','2021-05-11 11:37:24.293669',25,'','','C&E Compliance Officer',2),('CNE_IO',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.456679',20,'','','C&E Investigation Officer',3),('FINANCE',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.460429',20,'','','Finance',96),('HODIV',NULL,NULL,'stb_mervynl','2021-05-11 11:37:26.818055',24,'','','Head of Division',4),('SYSADM',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.483960',20,'','','System Administrator',97),('TA_AO',NULL,NULL,'stb_mervynl','2021-05-11 11:37:26.827124',24,'','','TA Approving Officer',2),('TA_CDD',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.488969',20,'\0','\0','Travel Agent Candidates',1),('TA_CNE_EO',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.490759',20,'','','TA C&E Enforcement Officer',1),('TA_HOD',NULL,NULL,'stb_mervynl','2021-05-11 11:37:26.830171',24,'','','TA Head of Department',3),('TA_PO',NULL,NULL,'stb_mervynl','2021-05-11 11:37:26.834838',24,'','','TA Processing Officer',0),('TA_PUB',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.501136',20,'\0','\0','Travel Agent Licensee',1),('TA_VIEWER',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.503127',21,'','','TA Viewer',98),('TA_VO',NULL,NULL,'stb_mervynl','2021-05-11 11:37:26.838983',25,'','','TA Verifying Officer',1),('TG_AO',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.507370',23,'','','TG Approving Officer',2),('TG_CDD',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.510486',20,'\0','\0','Tourist Guide Candidate',1),('TG_CNE_EO',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.511990',22,'','','TG C&E Enforcement Officer',1),('TG_HOD',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.514408',20,'','','TG Head of Department',3),('TG_PO',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.516562',23,'','','TG Processing Officer',1),('TG_PUB',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.519377',20,'\0','\0','Tourist Guide Licensee',1),('TG_VIEWER',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.521307',22,'','','TG Viewer',99),('TP_PUB',NULL,NULL,'stb_pangel','2021-03-29 12:25:26.524441',20,'\0','\0','Training Provider',1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:53
