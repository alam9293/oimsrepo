-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `qliksense_users`
--

DROP TABLE IF EXISTS `qliksense_users`;
/*!50001 DROP VIEW IF EXISTS `qliksense_users`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `qliksense_users` AS SELECT 
 1 AS `userid`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ce_ta_check_schedulable_items`
--

DROP TABLE IF EXISTS `ce_ta_check_schedulable_items`;
/*!50001 DROP VIEW IF EXISTS `ce_ta_check_schedulable_items`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ce_ta_check_schedulable_items` AS SELECT 
 1 AS `addressId`,
 1 AS `travelAgentId`,
 1 AS `licenceId`,
 1 AS `taBranchId`,
 1 AS `lastAaFilingId`,
 1 AS `lastAaApplicationId`,
 1 AS `lastAbprFilingId`,
 1 AS `abprSubmissionId`,
 1 AS `abprApplicationId`,
 1 AS `lastTatiCheckId`,
 1 AS `taName`,
 1 AS `uen`,
 1 AS `licenceNo`,
 1 AS `block`,
 1 AS `floorUnit`,
 1 AS `building`,
 1 AS `street`,
 1 AS `postal`,
 1 AS `premiseTypeCode`,
 1 AS `addressTypeCode`,
 1 AS `noOfReds`,
 1 AS `lastAaFilingStatusCode`,
 1 AS `lastAaFilingFyEndDate`,
 1 AS `licenceCeasedDate`,
 1 AS `licenceExpiryDate`,
 1 AS `licenceStatusCode`,
 1 AS `branchStatusCode`,
 1 AS `serviceTypeCode`,
 1 AS `lastTatiCheckIsCompliantCode`,
 1 AS `lastTatiCheckDate`,
 1 AS `lastCheckDone`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `qliksense_user_attributes`
--

DROP TABLE IF EXISTS `qliksense_user_attributes`;
/*!50001 DROP VIEW IF EXISTS `qliksense_user_attributes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `qliksense_user_attributes` AS SELECT 
 1 AS `userid`,
 1 AS `type`,
 1 AS `value`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `qliksense_users`
--

/*!50001 DROP VIEW IF EXISTS `qliksense_users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tag_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `qliksense_users` AS select `users`.`loginId` AS `userid`,`users`.`name` AS `name` from `users` where ((`users`.`typeCode` = 'USER_STB') and (`users`.`statusCode` = 'USER_A')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ce_ta_check_schedulable_items`
--

/*!50001 DROP VIEW IF EXISTS `ce_ta_check_schedulable_items`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ce_ta_check_schedulable_items` AS select `taaddr`.`addressId` AS `addressId`,`ta`.`id` AS `travelAgentId`,`lic`.`id` AS `licenceId`,`taaddr`.`branchId` AS `taBranchId`,`aafiling`.`id` AS `lastAaFilingId`,`aaapp`.`id` AS `lastAaApplicationId`,`abprfiling`.`id` AS `lastAbprFilingId`,`abpr`.`id` AS `abprSubmissionId`,`abprapp`.`id` AS `abprApplicationId`,`taaddr`.`lastTatiCheckId` AS `lastTatiCheckId`,`ta`.`name` AS `taName`,`ta`.`uen` AS `uen`,`lic`.`licenceNo` AS `licenceNo`,`taaddr`.`block` AS `block`,`taaddr`.`floorUnit` AS `floorUnit`,`taaddr`.`building` AS `building`,`taaddr`.`street` AS `street`,`taaddr`.`postal` AS `postal`,`taaddr`.`premiseTypeCode` AS `premiseTypeCode`,`taaddr`.`addressTypeCode` AS `addressTypeCode`,`aa`.`noOfReds` AS `noOfReds`,`aafiling`.`statusCode` AS `lastAaFilingStatusCode`,`aafiling`.`fyEndDate` AS `lastAaFilingFyEndDate`,`lic`.`ceasedDate` AS `licenceCeasedDate`,`lic`.`expiryDate` AS `licenceExpiryDate`,`lic`.`statusCode` AS `licenceStatusCode`,`taaddr`.`branchStatusCode` AS `branchStatusCode`,(case when ((`abpr`.`inboundOp` > 0) and (`abpr`.`outboundOp` > 0)) then 'TA_SERVICE_BOTH' when (`abpr`.`inboundOp` > 0) then 'TA_SERVICE_INBOUND' when (`abpr`.`outboundOp` > 0) then 'TA_SERVICE_OUTBOUND' end) AS `serviceTypeCode`,`taaddr`.`lastTatiCheckIsCompliantCode` AS `lastTatiCheckIsCompliantCode`,`taaddr`.`lastTatiCheckDate` AS `lastTatiCheckDate`,`taaddr`.`lastCheckDone` AS `lastCheckDone` from ((((((((((((`stb_tag_admin_dev`.`travel_agents` `ta` join `stb_tag_admin_dev`.`licences` `lic` on((`lic`.`id` = `ta`.`licenceId`))) left join (select `ta`.`id` AS `travelAgentId`,`regaddr`.`id` AS `addressId`,`regaddr`.`block` AS `block`,concat('#',concat(concat(`regaddr`.`floor`,'-'),`regaddr`.`unit`)) AS `floorUnit`,`regaddr`.`building` AS `building`,`regaddr`.`street` AS `street`,`regaddr`.`postal` AS `postal`,`regaddr`.`premiseTypeCode` AS `premiseTypeCode`,'TA_ADDR_REG' AS `addressTypeCode`,NULL AS `branchStatusCode`,NULL AS `branchId`,`ta`.`lastRegAddrTaCheckId` AS `lastTatiCheckId`,`taticheck`.`isCompliantCode` AS `lastTatiCheckIsCompliantCode`,`taticheck`.`checkedDate` AS `lastTatiCheckDate`,`ta`.`isLastRegAddrCheckDone` AS `lastCheckDone` from ((`stb_tag_admin_dev`.`travel_agents` `ta` join `stb_tag_admin_dev`.`addresses` `regaddr` on((`regaddr`.`id` = `ta`.`registeredAddressId`))) left join `stb_tag_admin_dev`.`ce_ta_checks` `taticheck` on((`taticheck`.`id` = `ta`.`lastRegAddrTaCheckId`))) where (isnull(`taticheck`.`id`) or (`taticheck`.`isDraft` = FALSE)) union select `ta`.`id` AS `travelAgentId`,`opaddr`.`id` AS `addressId`,`opaddr`.`block` AS `block`,concat('#',concat(concat(`opaddr`.`floor`,'-'),`opaddr`.`unit`)) AS `floorUnit`,`opaddr`.`building` AS `building`,`opaddr`.`street` AS `street`,`opaddr`.`postal` AS `postal`,`opaddr`.`premiseTypeCode` AS `premiseTypeCode`,'TA_ADDR_OP' AS `addressType`,NULL AS `branchStatusCode`,NULL AS `branchId`,`ta`.`lastOpAddrTaCheckId` AS `lastTatiCheckId`,`taticheck`.`isCompliantCode` AS `lastTatiCheckIsCompliantCode`,`taticheck`.`checkedDate` AS `lastTatiCheckDate`,`ta`.`isLastOpAddrCheckDone` AS `lastCheckDone` from ((`stb_tag_admin_dev`.`travel_agents` `ta` join `stb_tag_admin_dev`.`addresses` `opaddr` on((`opaddr`.`id` = `ta`.`operatingAddressId`))) left join `stb_tag_admin_dev`.`ce_ta_checks` `taticheck` on((`taticheck`.`id` = `ta`.`lastOpAddrTaCheckId`))) where (isnull(`taticheck`.`id`) or (`taticheck`.`isDraft` = FALSE)) union select `ta`.`id` AS `travelAgentId`,`braddr`.`id` AS `addressId`,`braddr`.`block` AS `block`,concat('#',concat(concat(`braddr`.`floor`,'-'),`braddr`.`unit`)) AS `floorUnit`,`braddr`.`building` AS `building`,`braddr`.`street` AS `street`,`braddr`.`postal` AS `postal`,`braddr`.`premiseTypeCode` AS `premiseTypeCode`,'TA_ADDR_BRANCH' AS `addressType`,`tab`.`statusCode` AS `branchStatusCode`,`tab`.`id` AS `branchId`,`tab`.`lastTaCheckId` AS `lastTatiCheckId`,`taticheck`.`isCompliantCode` AS `lastTatiCheckIsCompliantCode`,`taticheck`.`checkedDate` AS `lastTatiCheckDate`,`tab`.`isLastCheckDone` AS `lastCheckDone` from ((((`stb_tag_admin_dev`.`travel_agents` `ta` join `stb_tag_admin_dev`.`licences` `lic` on((`lic`.`id` = `ta`.`licenceId`))) join `stb_tag_admin_dev`.`ta_branches` `tab` on((`tab`.`licenceId` = `lic`.`id`))) join `stb_tag_admin_dev`.`addresses` `braddr` on((`braddr`.`id` = `tab`.`addressId`))) left join `stb_tag_admin_dev`.`ce_ta_checks` `taticheck` on((`taticheck`.`id` = `tab`.`lastTaCheckId`))) where (isnull(`taticheck`.`id`) or (`taticheck`.`isDraft` = FALSE))) `taaddr` on((`taaddr`.`travelAgentId` = `ta`.`id`))) left join (select `lic`.`travelAgentId` AS `travelAgentId`,max(`aafiling`.`fyEndDate`) AS `lastFyEndDate` from (`stb_tag_admin_dev`.`ta_filing_conditions` `aafiling` join `stb_tag_admin_dev`.`licences` `lic` on((`lic`.`id` = `aafiling`.`licenceId`))) where ((`aafiling`.`applicationTypeCode` = 'TA_APP_AA_SUBMISSION') and (`aafiling`.`statusCode` <> 'TA_FILING_VOID')) group by `lic`.`travelAgentId`) `lastaa` on((`lastaa`.`travelAgentId` = `ta`.`id`))) left join (select `lic`.`travelAgentId` AS `travelAgentId`,`aafiling`.`id` AS `id`,`aafiling`.`fyEndDate` AS `fyEndDate`,`aafiling`.`statusCode` AS `statusCode` from (`stb_tag_admin_dev`.`ta_filing_conditions` `aafiling` join `stb_tag_admin_dev`.`licences` `lic` on((`lic`.`id` = `aafiling`.`licenceId`))) where ((`aafiling`.`applicationTypeCode` = 'TA_APP_AA_SUBMISSION') and (`aafiling`.`statusCode` <> 'TA_FILING_VOID'))) `aafiling` on(((`aafiling`.`travelAgentId` = `ta`.`id`) and (`aafiling`.`fyEndDate` = `lastaa`.`lastFyEndDate`)))) left join `stb_tag_admin_dev`.`ta_aa_submissions` `aa` on((`aa`.`taAnnualFilingId` = `aafiling`.`id`))) left join `stb_tag_admin_dev`.`applications` `aaapp` on((`aaapp`.`id` = `aa`.`applicationId`))) left join `stb_tag_admin_dev`.`workflow_actions` `aawa` on((`aawa`.`id` = `aaapp`.`lastActionId`))) left join (select `lic`.`travelAgentId` AS `travelAgentId`,max(`abprfiling`.`fyEndDate`) AS `lastFyEndDate` from ((((`stb_tag_admin_dev`.`ta_abpr_submissions` `abpr` join `stb_tag_admin_dev`.`ta_filing_conditions` `abprfiling` on((`abprfiling`.`id` = `abpr`.`taAnnualFilingId`))) join `stb_tag_admin_dev`.`licences` `lic` on((`lic`.`id` = `abprfiling`.`licenceId`))) join `stb_tag_admin_dev`.`applications` `app` on((`app`.`id` = `abpr`.`applicationId`))) join `stb_tag_admin_dev`.`workflow_actions` `wa` on((`wa`.`id` = `app`.`lastActionId`))) where ((`app`.`isDraft` = 0) and (`wa`.`statusCode` is not null) and (`wa`.`statusCode` <> 'TA_APP_REJ') and (`abprfiling`.`statusCode` <> 'TA_FILING_VOID')) group by `lic`.`travelAgentId`) `lastabpr` on((`lastabpr`.`travelAgentId` = `ta`.`id`))) left join (select `lic`.`travelAgentId` AS `travelAgentId`,max(`abprfiling`.`id`) AS `id`,`abprfiling`.`fyEndDate` AS `fyEndDate`,`abprfiling`.`statusCode` AS `statusCode` from (`stb_tag_admin_dev`.`ta_filing_conditions` `abprfiling` join `stb_tag_admin_dev`.`licences` `lic` on((`lic`.`id` = `abprfiling`.`licenceId`))) where ((`abprfiling`.`applicationTypeCode` = 'TA_APP_ABPR_SUBMISSION') and (`abprfiling`.`statusCode` <> 'TA_FILING_VOID')) group by `abprfiling`.`fyEndDate`,`abprfiling`.`statusCode`,`lic`.`travelAgentId`) `abprfiling` on(((`abprfiling`.`travelAgentId` = `ta`.`id`) and (`abprfiling`.`fyEndDate` = `lastabpr`.`lastFyEndDate`)))) left join `stb_tag_admin_dev`.`ta_abpr_submissions` `abpr` on((`abpr`.`taAnnualFilingId` = `abprfiling`.`id`))) left join `stb_tag_admin_dev`.`applications` `abprapp` on((`abprapp`.`id` = `abpr`.`applicationId`))) left join `stb_tag_admin_dev`.`workflow_actions` `abprwa` on((`abprwa`.`id` = `abprapp`.`lastActionId`))) where ((isnull(`abprapp`.`id`) or ((`abprapp`.`isDraft` = 0) and (`abprapp`.`isDeleted` = 0))) and (isnull(`abprwa`.`id`) or (`abprwa`.`statusCode` <> 'TA_APP_REJ')) and (isnull(`aaapp`.`id`) or ((`aaapp`.`isDeleted` = 0) and (`aaapp`.`isDraft` = 0))) and (isnull(`aawa`.`id`) or (`aawa`.`statusCode` <> 'TA_APP_REJ'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `qliksense_user_attributes`
--

/*!50001 DROP VIEW IF EXISTS `qliksense_user_attributes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`tag_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `qliksense_user_attributes` AS select `users`.`loginId` AS `userid`,'departmentCode' AS `type`,`users`.`departmentCode` AS `value` from `users` where ((`users`.`typeCode` = 'USER_STB') and (`users`.`statusCode` = 'USER_A')) union select `users`.`loginId` AS `userid`,'emailAddress' AS `type`,`users`.`emailAddress` AS `value` from `users` where ((`users`.`typeCode` = 'USER_STB') and (`users`.`statusCode` = 'USER_A')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:26
