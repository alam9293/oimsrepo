-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_ke_clauses`
--

DROP TABLE IF EXISTS `ta_ke_clauses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_ke_clauses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `clause` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` bit(1) NOT NULL DEFAULT b'0',
  `isOptionsRequired` bit(1) NOT NULL DEFAULT b'0',
  `isRadioBtn` bit(1) NOT NULL DEFAULT b'0',
  `options` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `optionsToPrompt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordinal` int(11) DEFAULT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prompt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscript` varchar(700) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isNotForRenewal` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_ke_clauses`
--

LOCK TABLES `ta_ke_clauses` WRITE;
/*!40000 ALTER TABLE `ta_ke_clauses` DISABLE KEYS */;
INSERT INTO `ta_ke_clauses` VALUES (1,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'I am suitable to hold the appointment of a Key Executive<sup>1</sup>','','\0','\0',NULL,NULL,1,NULL,NULL,'<sup>1</sup>The criteria for which a person may be deemed suitable include and are not limited to:\na)	The individual is of good fame and character (e.g. should not have been responsible for this Business or another Business contravening the Travel Agents Act and Regulations).\nb)	The individual is not incapable by reason of illness, infirmity or similar cause of being involved in the management of a TA.\nc)	The individual has not been previously found unsuitable by STB for employment under a TA.','\0'),(2,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'an undischarged bankrupt or financially insolvent.','','','\0','am|am not',NULL,2,'I',NULL,NULL,'\0'),(3,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'committed any offence involving dishonesty or moral turpitude within a period of 5 years preceding the date of this declaration.','','','\0','have|have not','have',3,'I','If you have, please provide details of the offence:',NULL,'\0'),(4,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'committed any offence under the Travel Agents Act (Cap.334) or regulations thereunder ,or contravened any condition of a TA licence, within a period of 5 years preceding the date of this declaration.','','','\0','have|have not','have',4,'I','If you have, please provide details of the conviction:',NULL,''),(5,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'held a directorship or other managerial or executive position in any travel agency that has contravened any of the provisions of the Travel Agents Act (Cap.334) or regulations thereunder, or contravened any condition of a TA licence, within a period of 5 years preceding the date of this declaration.','','','\0','have|have not','have',5,'I','If you have, please provide details of the involvement:',NULL,''),(6,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'held a directorship or other managerial or executive position in any travel agency licensed under the Travel Agents Act where the licence has been suspended or revoked by the Singapore Tourism Board within a period of 5 years preceding the date of this declaration.','','','\0','have|have not','have',6,'I','If you have, please provide details of the suspension or revocation and your involvement:',NULL,''),(7,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'been found unsuitable by STB for employment under a travel agency within a period of 5 years preceding the date of this declaration.','','','\0','have|have not','have',7,'I','If you have, please provide details:',NULL,''),(8,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'a Key Executive in any other travel agency licensed under the Travel Agents Act at this time.','','','\0','am|am not','am',8,'I','If you are, please provide details:',NULL,''),(9,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'I have read and understood the Travel Agents Act (Cap.334) and Regulations thereunder.<sup>2</sup>','','\0','\0',NULL,NULL,9,NULL,NULL,'<sup>2</sup>Posted in TRUST Website <a href=\"https://trust.stb.gov.sg/site/content/tagaem/landing-page/legislation.html\" target=\"_blank\">https://trust.stb.gov.sg/site/content/tagaem/landing-page/legislation.html</a>',''),(10,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'Do any of the directors in the business or you have immediate family who is holding or have previously held the Key Executive or directorship position in another travel agency in the last 5 years?','','','','Yes|No','Yes',10,NULL,'If so, please state name, NRIC no. or FIN of the family member(s):',NULL,''),(11,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'Do any of the directors in the business or you have immediate family who held a directorship position in a business entity that has been refused a travel agent licence in the last 5 years?','','','','Yes|No','Yes',11,NULL,'If so, please state name, NRIC no. or FIN of the family member(s):',NULL,''),(12,'SYSTEM','2019-04-25 15:56:23.000000',NULL,NULL,0,'Do any of the directors in the business or you have immediate family who held the Key Executive or directorship in another travel agency which has been revoked or suspended in the last 5 years?','','','','Yes|No','Yes',12,NULL,'If so, please state name, NRIC no. or FIN of the family member(s):',NULL,'');
/*!40000 ALTER TABLE `ta_ke_clauses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:36
