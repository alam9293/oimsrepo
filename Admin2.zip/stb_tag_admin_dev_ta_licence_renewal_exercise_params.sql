-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_licence_renewal_exercise_params`
--

DROP TABLE IF EXISTS `ta_licence_renewal_exercise_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_licence_renewal_exercise_params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `isMaRequiredByUser` bit(1) DEFAULT NULL,
  `maSubmissionDueDate` date DEFAULT NULL,
  `requestedMaAsAtDate` date DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `taLicenceRenewalExerciseId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkfsqfu73jn8qygmclakfdi0ns` (`licenceId`),
  KEY `FKbd945ew6iolkiyyl34xjd3urq` (`taLicenceRenewalExerciseId`),
  CONSTRAINT `FKbd945ew6iolkiyyl34xjd3urq` FOREIGN KEY (`taLicenceRenewalExerciseId`) REFERENCES `ta_licence_renewal_exercises` (`id`),
  CONSTRAINT `FKkfsqfu73jn8qygmclakfdi0ns` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_licence_renewal_exercise_params`
--

LOCK TABLES `ta_licence_renewal_exercise_params` WRITE;
/*!40000 ALTER TABLE `ta_licence_renewal_exercise_params` DISABLE KEYS */;
INSERT INTO `ta_licence_renewal_exercise_params` VALUES (1,'stb_gabrielt','2019-07-30 18:18:51.851411','stb_gabrielt','2019-07-30 18:18:51.851411',0,'','2019-10-31','2019-06-30',2129,1),(2,'stb_gabrielt','2019-07-30 18:19:14.393045','stb_gabrielt','2019-07-30 18:19:14.393045',0,'','2019-10-31','2019-06-30',3111,1),(3,'stb_gabrielt','2019-07-30 18:24:32.532584','stb_gabrielt','2019-07-30 18:24:32.532584',0,'','2019-10-31','2019-06-30',2111,1),(4,'stb_gabrielt','2019-07-31 12:29:30.809352','stb_gabrielt','2019-07-31 12:29:30.809352',0,'','2019-10-31','2019-06-30',2662,1),(5,'stb_gabrielt','2019-07-31 12:31:32.444607','stb_gabrielt','2019-07-31 12:31:32.444607',0,'','2019-10-31','2019-06-30',2212,1),(6,'stb_gabrielt','2019-07-31 14:10:04.062570','stb_gabrielt','2019-07-31 14:10:04.062570',0,'','2019-10-31','2019-06-30',334,1),(7,'stb_gabrielt','2019-07-31 14:11:03.480607','stb_gabrielt','2019-07-31 14:11:03.480607',0,'','2019-10-31','2019-06-30',810,1),(8,'stb_gabrielt','2019-07-31 14:24:36.719139','stb_gabrielt','2019-07-31 14:24:36.719139',0,'\0',NULL,NULL,1361,1),(9,'stb_gabrielt','2019-07-31 14:29:17.423902','stb_gabrielt','2019-07-31 14:29:17.423902',0,'\0',NULL,NULL,271,1);
/*!40000 ALTER TABLE `ta_licence_renewal_exercise_params` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:08
