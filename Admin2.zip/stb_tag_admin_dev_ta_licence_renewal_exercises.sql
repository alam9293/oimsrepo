-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_licence_renewal_exercises`
--

DROP TABLE IF EXISTS `ta_licence_renewal_exercises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_licence_renewal_exercises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `baselinedDate` datetime(6) DEFAULT NULL,
  `defaultRequestedMaAsAtDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `fyeCutOffDate` date DEFAULT NULL,
  `hasBaselined` bit(1) NOT NULL DEFAULT b'0',
  `isRefreshing` bit(1) NOT NULL DEFAULT b'0',
  `refreshedDate` datetime(6) DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `workflowId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKvke9jlhbqs6ypmop1hlxxdiv` (`workflowId`),
  KEY `year` (`year`),
  CONSTRAINT `FKvke9jlhbqs6ypmop1hlxxdiv` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_licence_renewal_exercises`
--

LOCK TABLES `ta_licence_renewal_exercises` WRITE;
/*!40000 ALTER TABLE `ta_licence_renewal_exercises` DISABLE KEYS */;
INSERT INTO `ta_licence_renewal_exercises` VALUES (1,'stb_gabrielt','2019-07-29 09:05:02.687735','stb_kiansengn','2020-01-10 08:54:36.381003',347,'2019-07-31 14:45:17.390830','2019-06-30','2019-10-31','2019-03-31','','\0','2020-01-10 08:54:36.357168','2019-08-01',2019,1),(2,'stb_kiansengn','2020-01-02 08:33:31.677713','stb_jeffc','2020-01-08 10:52:24.173297',14,NULL,'2019-06-30','2019-10-31','2019-03-31','\0','\0','2020-01-08 10:52:24.168198','2019-08-01',2019,4548),(3,'stb_jeffc','2020-01-08 12:12:02.300125','stb_jeffc','2021-03-04 17:29:28.050791',79,'2020-09-01 08:05:21.608223','2020-06-30','2020-10-31','2020-03-31','','\0','2021-03-04 17:29:28.027691','2020-08-01',2020,4634),(4,'stb_kiansengn','2021-01-01 18:50:26.838990','stb_yvonnea','2022-05-07 15:11:40.036134',23,'2021-09-09 17:41:13.332913','2021-06-30','2021-10-31','2021-03-31','','\0','2022-05-07 15:11:40.025165','2021-08-01',2021,6571),(21,'stb_yvonnea','2022-05-22 23:50:17.047125','stb_yvonnea','2022-06-05 00:49:36.459734',103,NULL,'2022-06-30','2022-10-31','2022-03-31','','\0','2022-06-05 00:49:36.427756','2022-06-01',2022,6571);
/*!40000 ALTER TABLE `ta_licence_renewal_exercises` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:25
