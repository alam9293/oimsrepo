-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_licence_replacements`
--

DROP TABLE IF EXISTS `ta_licence_replacements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_licence_replacements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `billRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceReturnedDate` date DEFAULT NULL,
  `otherReason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `reasonCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3fgjw5hs4fd5tf5pqmeh8w1k5` (`applicationId`),
  KEY `FKsr3nx22gx763jdd9r2ta3k27e` (`reasonCode`),
  CONSTRAINT `FK3fgjw5hs4fd5tf5pqmeh8w1k5` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FKsr3nx22gx763jdd9r2ta3k27e` FOREIGN KEY (`reasonCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_licence_replacements`
--

LOCK TABLES `ta_licence_replacements` WRITE;
/*!40000 ALTER TABLE `ta_licence_replacements` DISABLE KEYS */;
INSERT INTO `ta_licence_replacements` VALUES (1,'G5170162W','2019-07-24 12:10:35.012483','G5170162W','2019-07-24 12:10:35.664665',1,'1907-2412-7784-3183',NULL,NULL,69773,'TA_RESN_REPLACE_L'),(2,'G5170162W','2019-07-24 12:11:31.354462','G5170162W','2019-07-24 12:11:31.354462',0,NULL,NULL,NULL,69773,'TA_RESN_REPLACE_L'),(3,'G3303615P','2019-11-25 10:20:06.219422','G3303615P','2019-11-25 10:20:06.845982',1,'1911-2510-3441-4455',NULL,'Change of Company Address',72709,'TA_RESN_REPLACE_O'),(4,'S1798551E','2019-12-05 13:57:01.387381','S1798551E','2019-12-05 13:57:02.081522',1,'1912-0513-5552-1022',NULL,'Relocation to a new unit - Change of Address',73041,'TA_RESN_REPLACE_O'),(5,'S1658093G','2020-07-24 23:48:55.204583','S1658093G','2020-07-24 23:48:55.816334',1,'2007-2423-7896-0761',NULL,'Office relocate to home office after lease end',79453,'TA_RESN_REPLACE_O'),(6,'S1355852C','2020-10-08 15:08:25.309325','S1355852C','2020-10-08 15:08:27.999457',1,'2010-0815-4071-3630',NULL,'Home office scheme ',81083,'TA_RESN_REPLACE_O'),(7,'G3840537W','2021-03-01 13:58:48.156761','G3840537W','2021-03-01 13:58:49.640901',1,'2103-0113-8065-1844',NULL,'We have restructured our business and therefore lost team members who knew where the license was displayed. We are in the process of moving office and wanted another copy to display properly ',83870,'TA_RESN_REPLACE_O'),(8,'S9376292D','2021-04-28 21:23:17.517505','S9376292D','2021-05-07 18:11:13.257242',2,'2104-2821-6941-2874',NULL,'Requesting for a new TA licence reflecting the comapny\'s new TA name & company\'s details. Please issue the licence accordingly.',84737,'TA_RESN_REPLACE_O');
/*!40000 ALTER TABLE `ta_licence_replacements` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:51
