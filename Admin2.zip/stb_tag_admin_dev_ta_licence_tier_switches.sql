-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_licence_tier_switches`
--

DROP TABLE IF EXISTS `ta_licence_tier_switches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_licence_tier_switches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `pendingSwitch` bit(1) NOT NULL DEFAULT b'0',
  `startDate` date DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `newLicenceTierCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oldLicenceTierCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbeq2u9m25452mxknrk732d5qf` (`applicationId`),
  KEY `FKst6evwdtgcp7lkxhu7gh83uem` (`newLicenceTierCode`),
  KEY `FKqjrhijw6fhwvrq6aqbd50p6r9` (`oldLicenceTierCode`),
  CONSTRAINT `FKbeq2u9m25452mxknrk732d5qf` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FKqjrhijw6fhwvrq6aqbd50p6r9` FOREIGN KEY (`oldLicenceTierCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKst6evwdtgcp7lkxhu7gh83uem` FOREIGN KEY (`newLicenceTierCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_licence_tier_switches`
--

LOCK TABLES `ta_licence_tier_switches` WRITE;
/*!40000 ALTER TABLE `ta_licence_tier_switches` DISABLE KEYS */;
INSERT INTO `ta_licence_tier_switches` VALUES (1,'S7183815C','2019-07-25 21:07:37.547611','S7183815C','2019-07-25 21:07:37.547611',0,'\0','2019-07-24',69819,'TA_TIER_G','TA_TIER_N'),(2,'S8676311G','2020-02-24 13:28:21.632045','S8676311G','2020-02-24 13:28:21.632045',0,'\0','2020-03-01',74283,'TA_TIER_G','TA_TIER_N'),(3,'S1505478F','2020-11-05 17:46:37.746328','S1505478F','2020-11-05 17:46:37.746328',0,'\0','2020-12-01',81714,'TA_TIER_N','TA_TIER_G'),(4,'S9275428F','2021-04-22 17:11:51.866963','S9275428F','2021-04-22 17:11:51.866963',0,'\0','2021-06-01',84494,'TA_TIER_G','TA_TIER_N'),(5,'202003178T-9023','2021-12-29 15:46:42.713565','202003178T-9023','2021-12-29 15:46:42.713565',0,'\0','2021-12-28',85155,'TA_TIER_G','TA_TIER_N'),(6,'202000480T-11402','2022-06-27 11:32:20.905980','202000480T-11402','2022-06-27 11:32:20.905980',0,'\0','2022-06-27',85189,'TA_TIER_N','TA_TIER_G'),(7,'202003418T-12051','2022-06-27 14:24:13.393817','202003418T-12051','2022-06-27 14:24:13.393817',0,'\0','2022-06-27',85190,'TA_TIER_N','TA_TIER_G');
/*!40000 ALTER TABLE `ta_licence_tier_switches` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:16:50
