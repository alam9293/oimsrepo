-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_net_value_rectification$ta_net_value_shortfalls`
--

DROP TABLE IF EXISTS `ta_net_value_rectification$ta_net_value_shortfalls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_net_value_rectification$ta_net_value_shortfalls` (
  `taNetValueRectificationId` int(11) NOT NULL,
  `taNetValueShortfallsId` int(11) NOT NULL,
  PRIMARY KEY (`taNetValueRectificationId`,`taNetValueShortfallsId`),
  KEY `FKaeo1u3ntn6hkyb32v295rau6h` (`taNetValueShortfallsId`),
  CONSTRAINT `FKaeo1u3ntn6hkyb32v295rau6h` FOREIGN KEY (`taNetValueShortfallsId`) REFERENCES `ta_net_value_shortfalls` (`id`),
  CONSTRAINT `FKhcyfgygynpdmuxja7uhat6rc6` FOREIGN KEY (`taNetValueRectificationId`) REFERENCES `ta_net_value_rectifications` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_net_value_rectification$ta_net_value_shortfalls`
--

LOCK TABLES `ta_net_value_rectification$ta_net_value_shortfalls` WRITE;
/*!40000 ALTER TABLE `ta_net_value_rectification$ta_net_value_shortfalls` DISABLE KEYS */;
INSERT INTO `ta_net_value_rectification$ta_net_value_shortfalls` VALUES (6,2),(10,3),(1,4),(17,5),(9,6),(23,7),(2,8),(3,9),(4,10),(12,11),(7,12),(11,13),(8,14),(14,16),(26,17),(27,18),(268,19),(54,20),(15,21),(21,22),(16,23),(60,24),(5,25),(29,26),(30,27),(255,30),(19,31),(18,32),(13,33),(25,34),(35,35),(69,36),(22,37),(44,38),(62,39),(38,41),(33,42),(36,43),(24,44),(244,45),(32,46),(20,47),(42,48),(37,50),(49,51),(28,53),(43,54),(40,55),(45,56),(31,57),(52,58),(34,59),(260,60),(41,61),(51,62),(58,63),(53,64),(59,65),(39,66),(65,68),(56,70),(57,71),(46,72),(48,73),(66,74),(55,76),(61,77),(47,78),(50,79),(67,80),(70,84),(64,85),(63,86),(75,87),(246,88),(261,90),(77,93),(79,94),(68,96),(72,97),(248,98),(242,99),(78,100),(243,101),(249,105),(71,106),(245,107),(263,108),(76,110),(74,111),(73,114),(251,115),(253,116),(247,117),(250,119),(80,120),(81,121),(82,122),(83,123),(84,125),(85,126),(86,127),(87,128),(88,129),(89,130),(90,131),(91,132),(92,133),(93,134),(94,135),(95,136),(96,137),(97,138),(98,139),(99,140),(100,141),(101,142),(102,143),(103,144),(104,145),(105,146),(106,147),(107,148),(108,149),(109,150),(110,151),(111,152),(112,153),(113,154),(114,155),(115,156),(116,157),(117,160),(118,161),(119,162),(120,164),(121,165),(122,166),(123,167),(124,168),(125,169),(126,170),(127,171),(128,172),(129,173),(130,174),(131,175),(132,176),(133,177),(134,178),(135,179),(136,180),(137,181),(138,182),(139,183),(140,184),(141,185),(142,187),(143,188),(144,189),(145,190),(146,191),(147,192),(148,194),(149,195),(150,196),(151,197),(152,198),(153,199),(154,201),(155,202),(156,203),(157,204),(158,205),(159,206),(160,207),(161,209),(162,210),(163,211),(164,212),(165,213),(166,214),(167,215),(168,216),(169,217),(170,218),(171,219),(172,220),(173,221),(174,222),(175,223),(176,224),(177,225),(178,226),(179,227),(180,228),(181,229),(182,230),(183,231),(184,232),(185,233),(186,234),(187,235),(188,236),(189,237),(190,238),(191,239),(192,240),(193,241),(194,242),(195,243),(196,244),(197,245),(198,247),(199,248),(200,251),(201,252),(202,253),(203,254),(204,255),(205,256),(206,257),(207,258),(208,259),(209,263),(210,266),(211,267),(212,269),(213,270),(214,271),(215,272),(216,273),(217,274),(218,275),(219,276),(220,280),(221,281),(222,282),(223,283),(224,284),(225,285),(226,286),(227,287),(228,288),(229,289),(230,290),(231,292),(232,293),(233,295),(234,296),(235,297),(236,298),(237,299),(238,300),(239,302),(240,304),(241,305),(257,306),(259,307),(254,312),(258,313),(252,314),(267,316),(262,318),(256,325),(265,328),(264,329),(266,332),(270,333),(269,335),(272,336),(271,340),(273,342),(274,359),(276,365),(277,373),(300,378),(314,384),(275,385),(289,387),(311,388),(279,389),(307,390),(281,397),(313,398),(278,401),(299,405),(283,410),(282,423),(280,426),(286,450),(288,452),(290,456),(294,457),(292,458),(285,459),(284,462),(287,465),(306,475),(291,481),(295,497),(293,501),(296,510),(296,511),(305,514),(298,516),(297,536),(304,543),(301,550),(309,552),(302,555),(308,556),(303,561),(310,566),(312,575),(315,584),(316,584),(317,585),(317,586),(317,587),(318,588),(323,589),(324,593);
/*!40000 ALTER TABLE `ta_net_value_rectification$ta_net_value_shortfalls` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:21
