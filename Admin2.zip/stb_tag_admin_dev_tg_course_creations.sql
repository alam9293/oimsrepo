-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_course_creations`
--

DROP TABLE IF EXISTS `tg_course_creations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_course_creations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `appropriateLevel` text COLLATE utf8mb4_unicode_ci,
  `assessment` text COLLATE utf8mb4_unicode_ci,
  `classroomHrs` decimal(19,2) DEFAULT NULL,
  `courseFee` decimal(19,2) DEFAULT NULL,
  `courseFeeNote` text COLLATE utf8mb4_unicode_ci,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `noOfHours` decimal(19,2) DEFAULT NULL,
  `objective` text COLLATE utf8mb4_unicode_ci,
  `outOfClassroomHrs` decimal(19,2) DEFAULT NULL,
  `outline` text COLLATE utf8mb4_unicode_ci,
  `ssgCourseCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `synopsis` text COLLATE utf8mb4_unicode_ci,
  `trainers` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CategoryCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `languageCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgTrainingProviderId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6fdf2jybi8lnf5o4mnev66bfm` (`CategoryCode`),
  KEY `FKo2u5k89x5oois6c6v1w2k8ate` (`applicationId`),
  KEY `FKmlt5ivjbh598ybqgtpvf9ywl9` (`languageCode`),
  KEY `FK16kgaww1x478rwaa7pq49d3yy` (`tgTrainingProviderId`),
  CONSTRAINT `FK16kgaww1x478rwaa7pq49d3yy` FOREIGN KEY (`tgTrainingProviderId`) REFERENCES `tg_training_providers` (`id`),
  CONSTRAINT `FK6fdf2jybi8lnf5o4mnev66bfm` FOREIGN KEY (`CategoryCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKmlt5ivjbh598ybqgtpvf9ywl9` FOREIGN KEY (`languageCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKo2u5k89x5oois6c6v1w2k8ate` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_course_creations`
--

LOCK TABLES `tg_course_creations` WRITE;
/*!40000 ALTER TABLE `tg_course_creations` DISABLE KEYS */;
INSERT INTO `tg_course_creations` VALUES (1,'S7819904J','2020-06-29 10:27:16.105044','S7819904J','2020-06-29 10:27:16.105044',0,NULL,'In-class activities',7.00,289.00,'','\0','Understanding Your Visitors',NULL,'<p>Tourist Guides will deepen their knowledge on visitor profiles and their demands and preferences. This knowledge will help TGs provide customised information and services and create better experiences for the visitors.</p>\n',0.00,'<p>Visitors today are becoming more distracted and demanding, and their consumption patterns shift due to technological advances. Hence, there is a need to deepen the understanding of whom our visitors are and what are their demands and preferences . This course aims to equip participants with appropriate knowledge on visitor profiles, types of visitors and the factors that influence visitor behaviour.&nbsp;</p>\n\n<p>Participants will be exposed to the following:<br />\n&bull; Analyse visitor profiles through tourism data and trends.<br />\n&bull; Examine the types of tourist based on visitor profiles.<br />\n&bull; Discuss the factors that influence visitor behaviour.<br />\n&bull; Discuss how cultural beliefs and values influence visitor decisions.<br />\n&bull; Apply Hofstede&rsquo;s Dimensions of National Culture model.</p>\n\n<p><br />\n&nbsp;</p>\n','RP-SFS-224','Visitors today are becoming more distracted and demanding, and their consumption patterns shift due to technological advances. Hence, there is a need to deepen the understanding of whom our visitors are and what are their demands and preferences . This course aims to equip participants with appropriate knowledge on visitor profiles, types of visitors and the factors that influence visitor behaviour. Furthermore, participants will be exposed to the Hofstede’s Dimensions of National Culture model, and use the model to enhance their understanding of visitor behaviour.','Edmund Poh','TG_CSE_CAT_MBS',78637,'TG_LANG_ENG',68);
/*!40000 ALTER TABLE `tg_course_creations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:20
