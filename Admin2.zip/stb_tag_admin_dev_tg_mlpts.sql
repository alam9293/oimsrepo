-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_mlpts`
--

DROP TABLE IF EXISTS `tg_mlpts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_mlpts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `mlptEndDate` date DEFAULT NULL,
  `mlptStartDate` date DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regEndDate` date DEFAULT NULL,
  `regStartDate` date DEFAULT NULL,
  `remarks` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allocationStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmaa9lqu3dt2m25s3usmok9ua6` (`allocationStatusCode`),
  CONSTRAINT `FKmaa9lqu3dt2m25s3usmok9ua6` FOREIGN KEY (`allocationStatusCode`) REFERENCES `statuses` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_mlpts`
--

LOCK TABLES `tg_mlpts` WRITE;
/*!40000 ALTER TABLE `tg_mlpts` DISABLE KEYS */;
INSERT INTO `tg_mlpts` VALUES (1,'stb_tzeserno','2019-07-29 18:12:14.106740','stb_tzeserno','2019-11-04 11:35:17.341231',2,'\0','2019-11-29','2019-11-26','November 2019 MLPT','2019-10-18','2019-09-23','','TG_MLPT_ALLOC_PUB'),(2,'stb_tzeserno','2019-09-04 11:30:15.504854','stb_tzeserno','2020-07-09 10:31:38.471349',30,'\0','2020-07-01','2020-06-11','May 2020 MLPT','2020-04-10','2020-03-16','','TG_MLPT_ALLOC_PUB'),(3,'stb_tzeserno','2019-09-04 11:32:26.009263','stb_jeremyk','2020-11-16 08:59:04.831696',4,'\0','2020-11-20','2020-11-16','November 2020 MLPT','2020-10-16','2020-09-21','','TG_MLPT_ALLOC_PUB'),(4,'stb_tzeserno','2021-01-04 09:41:01.105881','stb_tzeserno','2021-04-28 11:19:08.629061',3,'\0','2021-05-11','2021-05-04','May 2021 MLPT','2021-03-26','2021-03-01','','TG_MLPT_ALLOC_PUB'),(5,'stb_tzeserno','2021-01-04 09:42:30.768647','stb_yvonnea','2021-10-06 15:16:49.149605',1,'\0','2021-11-11','2021-11-09','November 2021 MLPT','2021-10-31','2021-09-06','','TG_MLPT_ALLOC_DRAFT'),(6,'stb_yvonnea','2021-09-08 16:26:48.734793','stb_yvonnea','2021-09-08 16:29:28.333554',1,'\0','2006-10-29','2006-10-04','Test Oct-2006','2006-09-30','2006-09-08','test','TG_MLPT_ALLOC_PUB');
/*!40000 ALTER TABLE `tg_mlpts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:04
