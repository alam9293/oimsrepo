-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_stipend$appeal_tgs`
--

DROP TABLE IF EXISTS `tg_stipend$appeal_tgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_stipend$appeal_tgs` (
  `tgStipendConfigId` int(11) NOT NULL,
  `appealTgsId` int(11) NOT NULL,
  PRIMARY KEY (`tgStipendConfigId`,`appealTgsId`),
  KEY `FK1q4ubj34flptt3oofrmcvjtwm` (`appealTgsId`),
  CONSTRAINT `FK1q4ubj34flptt3oofrmcvjtwm` FOREIGN KEY (`appealTgsId`) REFERENCES `tourist_guides` (`id`),
  CONSTRAINT `FKbbe1rm4o4wtkm4ciw3ynkg3tu` FOREIGN KEY (`tgStipendConfigId`) REFERENCES `tg_stipend_configs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_stipend$appeal_tgs`
--

LOCK TABLES `tg_stipend$appeal_tgs` WRITE;
/*!40000 ALTER TABLE `tg_stipend$appeal_tgs` DISABLE KEYS */;
INSERT INTO `tg_stipend$appeal_tgs` VALUES (2,122),(2,616),(2,618),(2,671),(2,760),(2,922),(2,929),(2,940),(2,1050),(2,1153),(2,1275),(2,1401),(2,1492),(2,1509),(2,1617),(2,1620),(2,1701),(2,1875),(2,1944),(2,2049),(2,2073),(2,2131),(2,2146),(2,2286),(2,2293),(2,2343),(2,3014),(2,3033),(2,3349),(2,3482),(2,3571),(2,3614),(2,3671),(2,3676),(2,3742),(2,3798),(2,3800),(2,3837),(2,3864),(2,3865),(2,4031),(2,4127),(2,4150),(2,4179),(2,4181),(2,4355),(2,4374),(2,4386),(2,4401),(2,4540),(2,4549),(2,4600),(2,4721),(2,4777);
/*!40000 ALTER TABLE `tg_stipend$appeal_tgs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:20
