-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_admin_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_stipend_configs`
--

DROP TABLE IF EXISTS `tg_stipend_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_stipend_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `amount` decimal(19,2) DEFAULT NULL,
  `declaration` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forAppeal` bit(1) NOT NULL DEFAULT b'0',
  `guidingLanguages` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceStartBefore` date DEFAULT NULL,
  `periodEndDate` date DEFAULT NULL,
  `periodStartDate` date DEFAULT NULL,
  `preamble` text COLLATE utf8mb4_unicode_ci,
  `supportingDocText` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_stipend_configs`
--

LOCK TABLES `tg_stipend_configs` WRITE;
/*!40000 ALTER TABLE `tg_stipend_configs` DISABLE KEYS */;
INSERT INTO `tg_stipend_configs` VALUES (1,'stb_pangel','2020-02-29 19:42:17.211073','stb_jeremyk','2020-04-28 17:53:05.612305',14,1000.00,'In submitting my application, I declare the following:\n\na.       I shall comply with all legislative requirements, codes or conditions of my TG licence.\nb.       I am a self-employed TG and I am not employed by any person or business entity.\nc.       I shall not cancel my TG licence or surrender my Singapore Citizenship or Permanent Residency status at any time before 1 May 2020.\nd.       All information provided in this application, including the banking information and the CPF extract, is true, accurate and complete to the best of my \n           knowledge.\n\nFurther, I acknowledge that STB is not obliged to approve my application or to pay out the wage support if I do not comply with any of the above declarations.\n\n\n\n','\0',NULL,'2020-09-02','2020-04-30','2020-02-29','<p>As announced on 21 Feb 2020, tourist guides will receive wage support of $1000 to help you tide over this difficult period.&nbsp; Applications will close on 30 April 2020. Submitted applications cannot be withdrawn.</p>\n\n<p>To be eligible, the tourist guide must be&nbsp;</p>\n\n<p>(a) Licensed ;</p>\n\n<p>(b) Singapore Citizen or Permanent Resident ; and</p>\n\n<p>(c) Self-employed ( not employed by any person or business entity)</p>\n','For verification of employment status, tourist guide will be required to submit a screenshot containing his/her name, NRIC number and CPF contribution history for the most recent two months.  '),(2,'stb_jeremyk','2020-03-26 10:10:28.040686','stb_jeremyk','2020-06-12 13:00:26.964932',20,1000.00,'In submitting my application, I declare the following:\n\na.       I shall comply with all legislative requirements, codes or conditions of my TG licence.\nb.       I am a self-employed TG and I am not employed by any person or business entity.\nc.       I shall not cancel my TG licence or surrender my Singapore Citizenship or Permanent Residency status at any time before 1 May 2020.\nd.       All information provided in this application, including the banking information and the CPF extract, is true, accurate and complete to the best of my \n           knowledge.\n\nFurther, I acknowledge that STB is not obliged to approve my application or to pay out the wage support if I do not comply with any of the above declarations.\n\n\n','',NULL,NULL,'2020-06-26','2020-03-26','<p>As announced on 21 Feb 2020, tourist guides will receive wage support of $1000 to help you tide over this difficult period. Submitted applications cannot be withdrawn.</p>\n\n<p>To be eligible, the tourist guide must be&nbsp;</p>\n\n<p>(a) Licensed ;</p>\n\n<p>(b) Singapore Citizen or Permanent Resident ; and</p>\n\n<p>(c) Self-employed ( not employed by any person or business entity)</p>\n','For verification of employment status, tourist guide will be required to submit a screenshot containing his/her name, NRIC number and CPF contribution history for the most recent two months.  ');
/*!40000 ALTER TABLE `tg_stipend_configs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:17:16
