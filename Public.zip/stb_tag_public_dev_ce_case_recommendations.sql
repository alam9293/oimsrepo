-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_case_recommendations`
--

DROP TABLE IF EXISTS `ce_case_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_case_recommendations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `letterIssuanceDate` date DEFAULT NULL,
  `penaltyAmount` decimal(19,2) DEFAULT NULL,
  `penaltyStatusEndDate` date DEFAULT NULL,
  `penaltyStatusStartDate` date DEFAULT NULL,
  `taggedIpCaseNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toEmailLetter` bit(1) NOT NULL DEFAULT b'0',
  `ceCaseInfringementId` int(11) DEFAULT NULL,
  `letterId` int(11) DEFAULT NULL,
  `letterEmailLogId` int(11) DEFAULT NULL,
  `outcomeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workflowId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKiwhr1gce0ght0wm9jkaqt6fne` (`ceCaseInfringementId`),
  KEY `FK28wb6i6e349p2u4p829wjemwk` (`letterId`),
  KEY `FKq4nkl5u8el5gm1a3pjffpxgvf` (`letterEmailLogId`),
  KEY `FKmlc1rulmunx3bi6eq1vsrmeh1` (`outcomeCode`),
  KEY `FKq40f80ua2xun4ify8pf78gsj3` (`workflowId`),
  CONSTRAINT `FK28wb6i6e349p2u4p829wjemwk` FOREIGN KEY (`letterId`) REFERENCES `files` (`id`),
  CONSTRAINT `FKiwhr1gce0ght0wm9jkaqt6fne` FOREIGN KEY (`ceCaseInfringementId`) REFERENCES `ce_case_infringements` (`id`),
  CONSTRAINT `FKmlc1rulmunx3bi6eq1vsrmeh1` FOREIGN KEY (`outcomeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKq40f80ua2xun4ify8pf78gsj3` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`),
  CONSTRAINT `FKq4nkl5u8el5gm1a3pjffpxgvf` FOREIGN KEY (`letterEmailLogId`) REFERENCES `email_logs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_case_recommendations`
--

LOCK TABLES `ce_case_recommendations` WRITE;
/*!40000 ALTER TABLE `ce_case_recommendations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ce_case_recommendations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:29
