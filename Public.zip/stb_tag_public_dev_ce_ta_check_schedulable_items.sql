-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_check_schedulable_items`
--

DROP TABLE IF EXISTS `ce_ta_check_schedulable_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_check_schedulable_items` (
  `addressId` int(11) NOT NULL,
  `addressTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `block` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branchStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `building` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floorUnit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastAaFilingFyEndDate` date DEFAULT NULL,
  `lastAaFilingId` int(11) DEFAULT NULL,
  `lastAaFilingStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastCheckDone` bit(1) DEFAULT NULL,
  `lastTatiCheckDate` date DEFAULT NULL,
  `lastTatiCheckId` int(11) DEFAULT NULL,
  `lastTatiCheckIsCompliantCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceCeasedDate` date DEFAULT NULL,
  `licenceExpiryDate` date DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `licenceNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `noOfReds` int(11) DEFAULT NULL,
  `postal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `premiseTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serviceTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taBranchId` int(11) DEFAULT NULL,
  `taName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `travelAgentId` int(11) DEFAULT NULL,
  `uen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`addressId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_check_schedulable_items`
--

LOCK TABLES `ce_ta_check_schedulable_items` WRITE;
/*!40000 ALTER TABLE `ce_ta_check_schedulable_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ce_ta_check_schedulable_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:25
