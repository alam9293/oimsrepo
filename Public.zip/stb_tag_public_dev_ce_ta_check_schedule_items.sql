-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_ta_check_schedule_items`
--

DROP TABLE IF EXISTS `ce_ta_check_schedule_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_ta_check_schedule_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `isApproved` bit(1) NOT NULL DEFAULT b'0',
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `isLastCheckDone` bit(1) DEFAULT NULL,
  `lastAaFilingFyEndDate` date DEFAULT NULL,
  `licenceCeasedDate` date DEFAULT NULL,
  `licenceExpiryDate` date DEFAULT NULL,
  `noOfReds` int(11) DEFAULT NULL,
  `scheduledDate` date DEFAULT NULL,
  `taName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toRevisit` bit(1) NOT NULL DEFAULT b'0',
  `addressId` int(11) DEFAULT NULL,
  `addressTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auxEoUserCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branchStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ceTaCheckScheduleId` int(11) DEFAULT NULL,
  `checkTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eoUserId` int(11) DEFAULT NULL,
  `lastAaFilingStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastApprovedCeTaCheckScheduleItemId` int(11) DEFAULT NULL,
  `lastTatiCheckId` int(11) DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `licenceStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serviceTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taBranchId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpbnhhmhjpsdgbb2hdfmavuj0k` (`addressId`),
  KEY `FKc9ivoti47nvbhqjnjlht9w3b3` (`addressTypeCode`),
  KEY `FKg1w03v6qdv6enftrbfeom2m1l` (`auxEoUserCode`),
  KEY `FK7jtsqybajs7cbpyjg9p38ny6e` (`branchStatusCode`),
  KEY `FKmlkdn43vggduas09gc30iqxkh` (`ceTaCheckScheduleId`),
  KEY `FKfe04rhu61xtpo6vmeraw5lsq2` (`checkTypeCode`),
  KEY `FK7y0h9rdy43a250ausqc2dbdnb` (`eoUserId`),
  KEY `FKr61dotcys6vvedin8t8lvi98a` (`lastAaFilingStatusCode`),
  KEY `FK3o0p2svt7chpn22eia52q1xvy` (`lastApprovedCeTaCheckScheduleItemId`),
  KEY `FKk22qs79lhue3khy7w8ytp9332` (`lastTatiCheckId`),
  KEY `FKmosm4g4ox744gbc2an37mnvq3` (`licenceId`),
  KEY `FKlck6b4qpjqnnc7who3l5bbram` (`licenceStatusCode`),
  KEY `FKn47lvikhxli31r8r7aoy3b95g` (`serviceTypeCode`),
  KEY `FK7hwc2xq43llbr3l2p9ohqer9p` (`taBranchId`),
  CONSTRAINT `FK3o0p2svt7chpn22eia52q1xvy` FOREIGN KEY (`lastApprovedCeTaCheckScheduleItemId`) REFERENCES `ce_ta_check_schedule_items` (`id`),
  CONSTRAINT `FK7hwc2xq43llbr3l2p9ohqer9p` FOREIGN KEY (`taBranchId`) REFERENCES `ta_branches` (`id`),
  CONSTRAINT `FK7jtsqybajs7cbpyjg9p38ny6e` FOREIGN KEY (`branchStatusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FK7y0h9rdy43a250ausqc2dbdnb` FOREIGN KEY (`eoUserId`) REFERENCES `users` (`id`),
  CONSTRAINT `FKc9ivoti47nvbhqjnjlht9w3b3` FOREIGN KEY (`addressTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKfe04rhu61xtpo6vmeraw5lsq2` FOREIGN KEY (`checkTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKg1w03v6qdv6enftrbfeom2m1l` FOREIGN KEY (`auxEoUserCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKk22qs79lhue3khy7w8ytp9332` FOREIGN KEY (`lastTatiCheckId`) REFERENCES `ce_ta_checks` (`id`),
  CONSTRAINT `FKlck6b4qpjqnnc7who3l5bbram` FOREIGN KEY (`licenceStatusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKmlkdn43vggduas09gc30iqxkh` FOREIGN KEY (`ceTaCheckScheduleId`) REFERENCES `ce_ta_check_schedules` (`id`),
  CONSTRAINT `FKmosm4g4ox744gbc2an37mnvq3` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`),
  CONSTRAINT `FKn47lvikhxli31r8r7aoy3b95g` FOREIGN KEY (`serviceTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKpbnhhmhjpsdgbb2hdfmavuj0k` FOREIGN KEY (`addressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKr61dotcys6vvedin8t8lvi98a` FOREIGN KEY (`lastAaFilingStatusCode`) REFERENCES `statuses` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_ta_check_schedule_items`
--

LOCK TABLES `ce_ta_check_schedule_items` WRITE;
/*!40000 ALTER TABLE `ce_ta_check_schedule_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ce_ta_check_schedule_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:57
