-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_tasks`
--

DROP TABLE IF EXISTS `ce_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `details` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forBillRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forScheduleFromDate` date DEFAULT NULL,
  `forScheduleMonth` int(11) DEFAULT NULL,
  `forScheduleToDate` date DEFAULT NULL,
  `forScheduleYear` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slaExpiryDate` date DEFAULT NULL,
  `uenUin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigneeId` int(11) DEFAULT NULL,
  `forCaseId` int(11) DEFAULT NULL,
  `forFilingConditionId` int(11) DEFAULT NULL,
  `forInfringementId` int(11) DEFAULT NULL,
  `forWorkflowId` int(11) DEFAULT NULL,
  `idTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `oicId` int(11) DEFAULT NULL,
  `statusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `typeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKle5b7pnbi8xn88q2tass0g0l2` (`assigneeId`),
  KEY `FKlnks72qdp40oplie4v8wb96x9` (`forCaseId`),
  KEY `FKmq4p3tvn9nryomvkdw0vgx5hd` (`forFilingConditionId`),
  KEY `FK69ffufyn01sbqxbwpj720fpgj` (`forInfringementId`),
  KEY `FKll2r6060b2iua1e8asqbi2kuo` (`forWorkflowId`),
  KEY `FKjsw9leh86i0hhy660xfbaauq4` (`idTypeCode`),
  KEY `FKc4yc8kp534ldhmeafbmt0prbs` (`licenceId`),
  KEY `FK8va0gu9p0igoj11hmugk8eivu` (`oicId`),
  KEY `FKai6jbucqwaunv2grjiavprjai` (`statusCode`),
  KEY `FKhs9k83f5l6p9tdmwx20sd7tb` (`typeCode`),
  CONSTRAINT `FK69ffufyn01sbqxbwpj720fpgj` FOREIGN KEY (`forInfringementId`) REFERENCES `ce_case_infringements` (`id`),
  CONSTRAINT `FK8va0gu9p0igoj11hmugk8eivu` FOREIGN KEY (`oicId`) REFERENCES `users` (`id`),
  CONSTRAINT `FKai6jbucqwaunv2grjiavprjai` FOREIGN KEY (`statusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKc4yc8kp534ldhmeafbmt0prbs` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`),
  CONSTRAINT `FKhs9k83f5l6p9tdmwx20sd7tb` FOREIGN KEY (`typeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKjsw9leh86i0hhy660xfbaauq4` FOREIGN KEY (`idTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKle5b7pnbi8xn88q2tass0g0l2` FOREIGN KEY (`assigneeId`) REFERENCES `users` (`id`),
  CONSTRAINT `FKll2r6060b2iua1e8asqbi2kuo` FOREIGN KEY (`forWorkflowId`) REFERENCES `workflows` (`id`),
  CONSTRAINT `FKlnks72qdp40oplie4v8wb96x9` FOREIGN KEY (`forCaseId`) REFERENCES `ce_cases` (`id`),
  CONSTRAINT `FKmq4p3tvn9nryomvkdw0vgx5hd` FOREIGN KEY (`forFilingConditionId`) REFERENCES `ta_filing_conditions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_tasks`
--

LOCK TABLES `ce_tasks` WRITE;
/*!40000 ALTER TABLE `ce_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ce_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:24
