-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ce_tg_field_report_tgs`
--

DROP TABLE IF EXISTS `ce_tg_field_report_tgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ce_tg_field_report_tgs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `approvedLanguages` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasValidLicence` bit(1) DEFAULT NULL,
  `isLanguageApproved` bit(1) DEFAULT NULL,
  `isLicenceDisplayed` bit(1) DEFAULT NULL,
  `isPictureTallied` bit(1) DEFAULT NULL,
  `licenceExpiryDate` date DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `noOfAntecedentRecords` int(11) DEFAULT NULL,
  `noOfTourists` int(11) DEFAULT NULL,
  `otherProvision` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passportNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicleNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ageGroupCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ceTgFieldReportId` int(11) DEFAULT NULL,
  `guidingLanguageProvidedCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `licenceStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `touristNationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKl0gdiyogibqrungjqmqw213ku` (`ageGroupCode`),
  KEY `FKf907l8ubbnbhrblxd6ifhdpxw` (`ceTgFieldReportId`),
  KEY `FKg4ro5ac9d8c0j0lm705oosmc1` (`guidingLanguageProvidedCode`),
  KEY `FKgrplxkj88si9ntkqjinlvdr72` (`licenceId`),
  KEY `FK9ouxupwwqcsm4mwkbxa9x04h6` (`licenceStatusCode`),
  KEY `FKmyawacpcalxupk8o1c1trp36f` (`nationalityCode`),
  KEY `FK7q7hqprx4j3wl8yna5ybrp160` (`touristNationalityCode`),
  CONSTRAINT `FK7q7hqprx4j3wl8yna5ybrp160` FOREIGN KEY (`touristNationalityCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK9ouxupwwqcsm4mwkbxa9x04h6` FOREIGN KEY (`licenceStatusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKf907l8ubbnbhrblxd6ifhdpxw` FOREIGN KEY (`ceTgFieldReportId`) REFERENCES `ce_tg_field_reports` (`id`),
  CONSTRAINT `FKg4ro5ac9d8c0j0lm705oosmc1` FOREIGN KEY (`guidingLanguageProvidedCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKgrplxkj88si9ntkqjinlvdr72` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`),
  CONSTRAINT `FKl0gdiyogibqrungjqmqw213ku` FOREIGN KEY (`ageGroupCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKmyawacpcalxupk8o1c1trp36f` FOREIGN KEY (`nationalityCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ce_tg_field_report_tgs`
--

LOCK TABLES `ce_tg_field_report_tgs` WRITE;
/*!40000 ALTER TABLE `ce_tg_field_report_tgs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ce_tg_field_report_tgs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:48
