-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stakeholders`
--

DROP TABLE IF EXISTS `stakeholders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stakeholders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `companyIncorporatedDate` date DEFAULT NULL,
  `companyUen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formerUin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCompany` bit(1) NOT NULL DEFAULT b'0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otherDesignation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trustId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressId` int(11) DEFAULT NULL,
  `designationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highestEduLevelCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `officeNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `residentialNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKia96t9je5spiq9my67srmrpra` (`addressId`),
  KEY `FK6ynkjbx4j7nfqrkdj7r8bem6l` (`designationCode`),
  KEY `FKrl96pnts8oa9mo5d8r41pswfq` (`highestEduLevelCode`),
  KEY `FKdmi1j4i8br00im4iirp4bn5v1` (`nationalityCode`),
  KEY `FK9i0169xvotkgu6i18tpkph0v9` (`sexCode`),
  CONSTRAINT `FK6ynkjbx4j7nfqrkdj7r8bem6l` FOREIGN KEY (`designationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK9i0169xvotkgu6i18tpkph0v9` FOREIGN KEY (`sexCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKdmi1j4i8br00im4iirp4bn5v1` FOREIGN KEY (`nationalityCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKia96t9je5spiq9my67srmrpra` FOREIGN KEY (`addressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKrl96pnts8oa9mo5d8r41pswfq` FOREIGN KEY (`highestEduLevelCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stakeholders`
--

LOCK TABLES `stakeholders` WRITE;
/*!40000 ALTER TABLE `stakeholders` DISABLE KEYS */;
/*!40000 ALTER TABLE `stakeholders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:19
