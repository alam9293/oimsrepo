-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_aa_submissions`
--

DROP TABLE IF EXISTS `ta_aa_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_aa_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `accProfitLoss` decimal(19,2) DEFAULT NULL,
  `amtOwnByDir` decimal(19,2) DEFAULT NULL,
  `bankBalance` decimal(19,2) DEFAULT NULL,
  `capital` decimal(19,2) DEFAULT NULL,
  `cashCashEquiv` decimal(19,2) DEFAULT NULL,
  `currentAssets` decimal(19,2) DEFAULT NULL,
  `currentLiabilities` decimal(19,2) DEFAULT NULL,
  `debtEquityRatio` decimal(19,2) DEFAULT NULL,
  `dividendsPaid` decimal(19,2) DEFAULT NULL,
  `grossProfitLoss` decimal(19,2) DEFAULT NULL,
  `netProfitLoss` decimal(19,2) DEFAULT NULL,
  `netProfitMargin` decimal(19,2) DEFAULT NULL,
  `netValue` decimal(19,2) DEFAULT NULL,
  `nonCurrentAssets` decimal(19,2) DEFAULT NULL,
  `nonCurrentLiabilities` decimal(19,2) DEFAULT NULL,
  `otherIncome` decimal(19,2) DEFAULT NULL,
  `profitScRatio` decimal(19,2) DEFAULT NULL,
  `quickRatio` decimal(19,2) DEFAULT NULL,
  `revenue` decimal(19,2) DEFAULT NULL,
  `totalAssets` decimal(19,2) DEFAULT NULL,
  `totalEquity` decimal(19,2) DEFAULT NULL,
  `totalLiabilities` decimal(19,2) DEFAULT NULL,
  `tradeReceivables` decimal(19,2) DEFAULT NULL,
  `tradeSecurities` decimal(19,2) DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `auditorOpinionCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taAnnualFilingId` int(11) DEFAULT NULL,
  `shortfall` decimal(19,2) DEFAULT NULL,
  `isDebtEquityRatioRed` bit(1) DEFAULT NULL,
  `isNetProfitMarginRed` bit(1) DEFAULT NULL,
  `isProfitScRatioRed` bit(1) DEFAULT NULL,
  `isQuickRatioRed` bit(1) DEFAULT NULL,
  `noOfReds` int(11) DEFAULT NULL,
  `auditorInfringementId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKc41hsgognhmf2ugn57he4gb31` (`applicationId`),
  KEY `FKmtbaiffjqkqsh3mq04glywsin` (`auditorOpinionCode`),
  KEY `FKtbgpqk2ievr6ui4v0lnxfts55` (`taAnnualFilingId`),
  KEY `FKqpm8dlat4s1i25aoh4lpnwlhq` (`auditorInfringementId`),
  CONSTRAINT `FKc41hsgognhmf2ugn57he4gb31` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FKmtbaiffjqkqsh3mq04glywsin` FOREIGN KEY (`auditorOpinionCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKqpm8dlat4s1i25aoh4lpnwlhq` FOREIGN KEY (`auditorInfringementId`) REFERENCES `ce_case_infringements` (`id`),
  CONSTRAINT `FKtbgpqk2ievr6ui4v0lnxfts55` FOREIGN KEY (`taAnnualFilingId`) REFERENCES `ta_filing_conditions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_aa_submissions`
--

LOCK TABLES `ta_aa_submissions` WRITE;
/*!40000 ALTER TABLE `ta_aa_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_aa_submissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:52
