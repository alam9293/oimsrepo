-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_abpr_submissions`
--

DROP TABLE IF EXISTS `ta_abpr_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_abpr_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `depreciation` decimal(19,2) DEFAULT NULL,
  `hasOverseasBranch` bit(1) NOT NULL DEFAULT b'0',
  `inboundFitPax` int(11) DEFAULT NULL,
  `inboundFitPaxPercent` decimal(19,2) DEFAULT NULL,
  `inboundGrpPax` int(11) DEFAULT NULL,
  `inboundGrpPaxPercent` decimal(19,2) DEFAULT NULL,
  `inboundOp` decimal(19,2) DEFAULT NULL,
  `inboundOpPercent` decimal(19,2) DEFAULT NULL,
  `indirectTax` decimal(19,2) DEFAULT NULL,
  `noOfEmployee` int(11) DEFAULT NULL,
  `operatingCost` decimal(19,2) DEFAULT NULL,
  `outboundFitPax` int(11) DEFAULT NULL,
  `outboundFitPaxPercent` decimal(19,2) DEFAULT NULL,
  `outboundGrpPax` int(11) DEFAULT NULL,
  `outboundGrpPaxPercent` decimal(19,2) DEFAULT NULL,
  `outboundOp` decimal(19,2) DEFAULT NULL,
  `outboundOpPercent` decimal(19,2) DEFAULT NULL,
  `remuneration` decimal(19,2) DEFAULT NULL,
  `trustId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `taAnnualFilingId` int(11) DEFAULT NULL,
  `isNilSubmission` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  KEY `FKme5gyq5w2tu147rh4qvb6e3w1` (`applicationId`),
  KEY `FK9n3a5sg6qpb7ewx2tn3s7pf2f` (`taAnnualFilingId`),
  CONSTRAINT `FK9n3a5sg6qpb7ewx2tn3s7pf2f` FOREIGN KEY (`taAnnualFilingId`) REFERENCES `ta_filing_conditions` (`id`),
  CONSTRAINT `FKme5gyq5w2tu147rh4qvb6e3w1` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_abpr_submissions`
--

LOCK TABLES `ta_abpr_submissions` WRITE;
/*!40000 ALTER TABLE `ta_abpr_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_abpr_submissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:45
