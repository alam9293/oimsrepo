-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_business_operations`
--

DROP TABLE IF EXISTS `ta_business_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_business_operations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `inbound` decimal(19,2) DEFAULT NULL,
  `inboundPercent` decimal(19,2) DEFAULT NULL,
  `isInboundOwned` bit(1) NOT NULL DEFAULT b'0',
  `isOutboundOwned` bit(1) NOT NULL DEFAULT b'0',
  `outbound` decimal(19,2) DEFAULT NULL,
  `outboundPercent` decimal(19,2) DEFAULT NULL,
  `trustId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newTaLicenceTierSwitchId` int(11) DEFAULT NULL,
  `serviceCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taAbprSubmissionId` int(11) DEFAULT NULL,
  `taLicenceCreationId` int(11) DEFAULT NULL,
  `taLicenceTierSwitchId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK47s0kcmrhwh96cnqaq6ngi6f4` (`newTaLicenceTierSwitchId`),
  KEY `FKlxvulw9hvi7rc2yud0ytb83iv` (`serviceCode`),
  KEY `FK27qeb1chg757pgpujtg65xxu1` (`taAbprSubmissionId`),
  KEY `FKle6n7max07uqpdcyvlrxk31c5` (`taLicenceCreationId`),
  KEY `FK8afrpxp2kt5qdrbvygewbdex0` (`taLicenceTierSwitchId`),
  CONSTRAINT `FK27qeb1chg757pgpujtg65xxu1` FOREIGN KEY (`taAbprSubmissionId`) REFERENCES `ta_abpr_submissions` (`id`),
  CONSTRAINT `FK47s0kcmrhwh96cnqaq6ngi6f4` FOREIGN KEY (`newTaLicenceTierSwitchId`) REFERENCES `ta_licence_tier_switches` (`id`),
  CONSTRAINT `FK8afrpxp2kt5qdrbvygewbdex0` FOREIGN KEY (`taLicenceTierSwitchId`) REFERENCES `ta_licence_tier_switches` (`id`),
  CONSTRAINT `FKle6n7max07uqpdcyvlrxk31c5` FOREIGN KEY (`taLicenceCreationId`) REFERENCES `ta_licence_creations` (`id`),
  CONSTRAINT `FKlxvulw9hvi7rc2yud0ytb83iv` FOREIGN KEY (`serviceCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_business_operations`
--

LOCK TABLES `ta_business_operations` WRITE;
/*!40000 ALTER TABLE `ta_business_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_business_operations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:12
