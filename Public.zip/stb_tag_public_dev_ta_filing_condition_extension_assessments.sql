-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_filing_condition_extension_assessments`
--

DROP TABLE IF EXISTS `ta_filing_condition_extension_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_filing_condition_extension_assessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `amtOwedByDirRisk` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consecutiveLossesRemarks` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpfArrearsRisk` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inboundOutboundRisk` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCurrentRatioLessRemarks` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `litigationSuitRisk` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `managerAssessment` longtext COLLATE utf8mb4_unicode_ci,
  `nonDeliveryRisk` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `riskAssessment` longtext COLLATE utf8mb4_unicode_ci,
  `salesTurnoverRisk` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shortfallExceededLossesRemarks` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assessedAaId` int(11) DEFAULT NULL,
  `assessedAa2Id` int(11) DEFAULT NULL,
  `assessedAbprId` int(11) DEFAULT NULL,
  `hasConsecutiveLossesCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasShortfallExceededCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCurrentRatioLessThanOneCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workflowId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKhom16i27uf5mc28lnei4yeiwj` (`assessedAaId`),
  KEY `FKjx47ms8x8hru5qkk7trm08dhr` (`assessedAa2Id`),
  KEY `FKjpeybewur8duqjh9v85j3lcua` (`assessedAbprId`),
  KEY `FK62f1k476mdsnswao5jb6xyntp` (`hasConsecutiveLossesCode`),
  KEY `FKjtbvfgm6edodow642lsjonm95` (`hasShortfallExceededCode`),
  KEY `FK902nykba8s7gl7vo17tnqg4yu` (`isCurrentRatioLessThanOneCode`),
  KEY `FKt1in71apgp1uvrcwvwql9sw4y` (`workflowId`),
  CONSTRAINT `FK62f1k476mdsnswao5jb6xyntp` FOREIGN KEY (`hasConsecutiveLossesCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK902nykba8s7gl7vo17tnqg4yu` FOREIGN KEY (`isCurrentRatioLessThanOneCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKhom16i27uf5mc28lnei4yeiwj` FOREIGN KEY (`assessedAaId`) REFERENCES `ta_aa_submissions` (`id`),
  CONSTRAINT `FKjpeybewur8duqjh9v85j3lcua` FOREIGN KEY (`assessedAbprId`) REFERENCES `ta_abpr_submissions` (`id`),
  CONSTRAINT `FKjtbvfgm6edodow642lsjonm95` FOREIGN KEY (`hasShortfallExceededCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKjx47ms8x8hru5qkk7trm08dhr` FOREIGN KEY (`assessedAa2Id`) REFERENCES `ta_aa_submissions` (`id`),
  CONSTRAINT `FKt1in71apgp1uvrcwvwql9sw4y` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_filing_condition_extension_assessments`
--

LOCK TABLES `ta_filing_condition_extension_assessments` WRITE;
/*!40000 ALTER TABLE `ta_filing_condition_extension_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_filing_condition_extension_assessments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:37
