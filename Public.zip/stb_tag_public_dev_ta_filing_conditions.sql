-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_filing_conditions`
--

DROP TABLE IF EXISTS `ta_filing_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_filing_conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `dueDate` date DEFAULT NULL,
  `fy` int(11) DEFAULT NULL,
  `fyEndDate` date DEFAULT NULL,
  `fyStartDate` date DEFAULT NULL,
  `remarks` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicationTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `statusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestedAsAtDate` date DEFAULT NULL,
  `lastExtensionId` int(11) DEFAULT NULL,
  `rectifiedApplicationId` int(11) DEFAULT NULL,
  `tarR141InfringementId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8kde1k9jmk4gyxfv8iqpc9wkb` (`applicationTypeCode`),
  KEY `FK3ptp6heel03pu4rchgtktdphw` (`licenceId`),
  KEY `FKd1go34s3l4ebjc5dv3m7vp2j3` (`statusCode`),
  KEY `FKo0d8t7xh35ua33u980krdpbg3` (`lastExtensionId`),
  KEY `FK27ponqqyxsmimgbymml4axnnt` (`rectifiedApplicationId`),
  KEY `FKin14o2ta2d14e0a6t9bjr9499` (`tarR141InfringementId`),
  CONSTRAINT `FK27ponqqyxsmimgbymml4axnnt` FOREIGN KEY (`rectifiedApplicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FK3ptp6heel03pu4rchgtktdphw` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`),
  CONSTRAINT `FK8kde1k9jmk4gyxfv8iqpc9wkb` FOREIGN KEY (`applicationTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKd1go34s3l4ebjc5dv3m7vp2j3` FOREIGN KEY (`statusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKin14o2ta2d14e0a6t9bjr9499` FOREIGN KEY (`tarR141InfringementId`) REFERENCES `ce_case_infringements` (`id`),
  CONSTRAINT `FKo0d8t7xh35ua33u980krdpbg3` FOREIGN KEY (`lastExtensionId`) REFERENCES `ta_filing_condition_extensions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_filing_conditions`
--

LOCK TABLES `ta_filing_conditions` WRITE;
/*!40000 ALTER TABLE `ta_filing_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_filing_conditions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:38
