-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_ke_declarations`
--

DROP TABLE IF EXISTS `ta_ke_declarations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_ke_declarations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `optionSelected` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taKeClauseId` int(11) DEFAULT NULL,
  `taKeyExecutiveId` int(11) DEFAULT NULL,
  `taKeyExecutiveApplicationId` int(11) DEFAULT NULL,
  `taLicenceRenewalId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKhudvsw2k51hptqbyna53vvk3l` (`taKeClauseId`),
  KEY `FKex95f5s6fwisa6upkyde15yoj` (`taKeyExecutiveId`),
  KEY `FKkqyfu1ckho4uv0ixt4lny2bjs` (`taKeyExecutiveApplicationId`),
  KEY `FK4ut64ihiuqb6laoboyr46jhdt` (`taLicenceRenewalId`),
  CONSTRAINT `FK4ut64ihiuqb6laoboyr46jhdt` FOREIGN KEY (`taLicenceRenewalId`) REFERENCES `ta_licence_renewals` (`id`),
  CONSTRAINT `FKex95f5s6fwisa6upkyde15yoj` FOREIGN KEY (`taKeyExecutiveId`) REFERENCES `ta_stakeholders` (`id`),
  CONSTRAINT `FKhudvsw2k51hptqbyna53vvk3l` FOREIGN KEY (`taKeClauseId`) REFERENCES `ta_ke_clauses` (`id`),
  CONSTRAINT `FKkqyfu1ckho4uv0ixt4lny2bjs` FOREIGN KEY (`taKeyExecutiveApplicationId`) REFERENCES `ta_stakeholder_applications` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_ke_declarations`
--

LOCK TABLES `ta_ke_declarations` WRITE;
/*!40000 ALTER TABLE `ta_ke_declarations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_ke_declarations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:27
