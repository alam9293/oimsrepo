-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_licence_creations`
--

DROP TABLE IF EXISTS `ta_licence_creations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_licence_creations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `appDob` date DEFAULT NULL,
  `appEmailAddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appFaxNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appFeeBillRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appMobileNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appOfficeNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appOtherDesignation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appResidentialNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appUin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `companyFormerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `companyName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentBusinessWriteUp` text COLLATE utf8mb4_unicode_ci,
  `effectiveDate` date DEFAULT NULL,
  `emailAddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fyeDate` date DEFAULT NULL,
  `inboundOpPercent` decimal(19,2) DEFAULT NULL,
  `isAppKeyExecutive` bit(1) NOT NULL DEFAULT b'0',
  `isConcluded` bit(1) NOT NULL DEFAULT b'0',
  `isEdhPopulated` bit(1) NOT NULL DEFAULT b'0',
  `isMyInfoPopulated` bit(1) NOT NULL DEFAULT b'0',
  `isOppAddSameAsRegAdd` bit(1) NOT NULL DEFAULT b'0',
  `licenceFeeBillRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outboundOpPercent` decimal(19,2) DEFAULT NULL,
  `paidUpCapital` decimal(19,2) DEFAULT NULL,
  `registrationDate` date DEFAULT NULL,
  `taBusinessWriteUp` text COLLATE utf8mb4_unicode_ci,
  `trustId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `websiteUrl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appDesignationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appNationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appSexCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `applicationModeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessConstitutionCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `establishmentStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formOfBusinessCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceTierCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operatingAddressId` int(11) DEFAULT NULL,
  `placeIncorporatedCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `principleActivitiesCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registeredAddressId` int(11) DEFAULT NULL,
  `secondaryPrincipleActivitiesCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taKeyExecutiveId` int(11) DEFAULT NULL,
  `taSegmentationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faxNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `officeNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `residentialNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessIdea` text COLLATE utf8mb4_unicode_ci,
  `competitiveEdge` text COLLATE utf8mb4_unicode_ci,
  `consumerFacingBrand` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `costProj1` decimal(19,2) DEFAULT NULL,
  `costProj2` decimal(19,2) DEFAULT NULL,
  `detailsRegardingPrevLic` text COLLATE utf8mb4_unicode_ci,
  `estTimeToProfit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `financialStrategy` text COLLATE utf8mb4_unicode_ci,
  `hasOtherBizActivities` bit(1) NOT NULL DEFAULT b'0',
  `hasTaLicBefore` bit(1) NOT NULL DEFAULT b'0',
  `mktgCommsPlan` text COLLATE utf8mb4_unicode_ci,
  `otherSalesChannel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `others` text COLLATE utf8mb4_unicode_ci,
  `partnerServideProviders` text COLLATE utf8mb4_unicode_ci,
  `percentFocusOnTaBiz` decimal(19,2) DEFAULT NULL,
  `profitLossProj1` decimal(19,2) DEFAULT NULL,
  `profitLossProj2` decimal(19,2) DEFAULT NULL,
  `relationsWithOtherTa` text COLLATE utf8mb4_unicode_ci,
  `revenueProj1` decimal(19,2) DEFAULT NULL,
  `revenueProj2` decimal(19,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKhh58e44p9kf2y4gqa87ee9gsy` (`appDesignationCode`),
  KEY `FKqgfs1yfafbg2225s5lpcsgkir` (`appNationalityCode`),
  KEY `FK8tasinrfiour7kn8gqi4ynoi0` (`appSexCode`),
  KEY `FKa8khrfd5em4l6c87yr8r4pnf9` (`applicationId`),
  KEY `FKju4r3tm4lukbgs3pmauafvyie` (`applicationModeCode`),
  KEY `FKesnfyn2xd3f9rxx94dvv55trk` (`businessConstitutionCode`),
  KEY `FK2ucdswoictlbur1fvdb6j7sbg` (`establishmentStatusCode`),
  KEY `FK4yr1qjltvl7hgaepf7j7r2q84` (`formOfBusinessCode`),
  KEY `FK47lhrlp5d1i94cooh7bijwv42` (`licenceTierCode`),
  KEY `FKdall5b8kfvdy5ti50sxtulsy9` (`operatingAddressId`),
  KEY `FKls2ifxerwol37e81mtkt9a5rm` (`placeIncorporatedCode`),
  KEY `FK1p0bng93wgh2g6m48r67983s7` (`principleActivitiesCode`),
  KEY `FKjm244pncyckhnt2vm7e0ve41f` (`registeredAddressId`),
  KEY `FKc6anfsl1tq5d7q9ac8icsm5n7` (`secondaryPrincipleActivitiesCode`),
  KEY `FK2khm1oemaowog81fcm1ybiaxc` (`taKeyExecutiveId`),
  KEY `FK1d593s8ytfocdhnqd1lx1fjdv` (`taSegmentationCode`),
  CONSTRAINT `FK1d593s8ytfocdhnqd1lx1fjdv` FOREIGN KEY (`taSegmentationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK1p0bng93wgh2g6m48r67983s7` FOREIGN KEY (`principleActivitiesCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK2khm1oemaowog81fcm1ybiaxc` FOREIGN KEY (`taKeyExecutiveId`) REFERENCES `ta_stakeholder_applications` (`id`),
  CONSTRAINT `FK2ucdswoictlbur1fvdb6j7sbg` FOREIGN KEY (`establishmentStatusCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK47lhrlp5d1i94cooh7bijwv42` FOREIGN KEY (`licenceTierCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK4yr1qjltvl7hgaepf7j7r2q84` FOREIGN KEY (`formOfBusinessCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK8tasinrfiour7kn8gqi4ynoi0` FOREIGN KEY (`appSexCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKa8khrfd5em4l6c87yr8r4pnf9` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FKc6anfsl1tq5d7q9ac8icsm5n7` FOREIGN KEY (`secondaryPrincipleActivitiesCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKdall5b8kfvdy5ti50sxtulsy9` FOREIGN KEY (`operatingAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKesnfyn2xd3f9rxx94dvv55trk` FOREIGN KEY (`businessConstitutionCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKhh58e44p9kf2y4gqa87ee9gsy` FOREIGN KEY (`appDesignationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKjm244pncyckhnt2vm7e0ve41f` FOREIGN KEY (`registeredAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKju4r3tm4lukbgs3pmauafvyie` FOREIGN KEY (`applicationModeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKls2ifxerwol37e81mtkt9a5rm` FOREIGN KEY (`placeIncorporatedCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKqgfs1yfafbg2225s5lpcsgkir` FOREIGN KEY (`appNationalityCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_licence_creations`
--

LOCK TABLES `ta_licence_creations` WRITE;
/*!40000 ALTER TABLE `ta_licence_creations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_licence_creations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:38
