-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_licence_renewal_exercise_tas`
--

DROP TABLE IF EXISTS `ta_licence_renewal_exercise_tas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_licence_renewal_exercise_tas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baselinedFye` date DEFAULT NULL,
  `baselinedKeName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `baselinedName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `baselinedOutstandingPayment` decimal(19,2) DEFAULT NULL,
  `fye` date DEFAULT NULL,
  `isMaRequired` bit(1) NOT NULL DEFAULT b'0',
  `outstandingPayment` decimal(19,2) DEFAULT NULL,
  `baselinedKeId` int(11) DEFAULT NULL,
  `exerciseEndEmailLogId` int(11) DEFAULT NULL,
  `exerciseStartEmailLogId` int(11) DEFAULT NULL,
  `keId` int(11) DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `maFilingConditionId` int(11) DEFAULT NULL,
  `taAaFilingCondition1Id` int(11) DEFAULT NULL,
  `taAaFilingCondition2Id` int(11) DEFAULT NULL,
  `taAbprFilingCondition1Id` int(11) DEFAULT NULL,
  `taAbprFilingCondition2Id` int(11) DEFAULT NULL,
  `taLicenceRenewalId` int(11) DEFAULT NULL,
  `taLicenceRenewalExerciseId` int(11) DEFAULT NULL,
  `taNetValueShortfallAa1Id` int(11) DEFAULT NULL,
  `taNetValueShortfallAa2Id` int(11) DEFAULT NULL,
  `taNetValueShortfallMa1Id` int(11) DEFAULT NULL,
  `taNetValueShortfallMa2Id` int(11) DEFAULT NULL,
  `typeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isMaVoid` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  KEY `FKrslc93e7nq436sjocbs3khdqc` (`baselinedKeId`),
  KEY `FKe21o16jye06oy4rijre4cpxkr` (`exerciseEndEmailLogId`),
  KEY `FK39idwnlex78sx4vu8xdqcivt1` (`exerciseStartEmailLogId`),
  KEY `FKr6th85mcdrk8jvb8iwll7uick` (`keId`),
  KEY `FK1efhejhufvn87p82hds3flub7` (`licenceId`),
  KEY `FKg62oegw2rled5cci05bn52rwh` (`maFilingConditionId`),
  KEY `FKnu3dytvlvp12yq3e7skwwp203` (`taAaFilingCondition1Id`),
  KEY `FK57nu0hppsqbg8oaecdcbb6gas` (`taAaFilingCondition2Id`),
  KEY `FKcv61w8sphx5gke0pr10no2t4k` (`taAbprFilingCondition1Id`),
  KEY `FK68gi2bq67xq2io8w45epk6rlq` (`taAbprFilingCondition2Id`),
  KEY `FK1p4jmrmr2qrkhwk2sfuijtd3v` (`taLicenceRenewalId`),
  KEY `FK5bi6koj7d39ffbtls1lefhnyf` (`taLicenceRenewalExerciseId`),
  KEY `FK2pckjlmi8c1ymxrbplyo2p2n8` (`taNetValueShortfallAa1Id`),
  KEY `FKljfquocycscv41aqhq36t3ppy` (`taNetValueShortfallAa2Id`),
  KEY `FKp77edi3mmdt4i87581lsw4mf2` (`taNetValueShortfallMa1Id`),
  KEY `FKasnhecb637torbcdylnh46rl3` (`taNetValueShortfallMa2Id`),
  KEY `FKq3ij9f677ongjhdq71393ct7i` (`typeCode`),
  CONSTRAINT `FK1efhejhufvn87p82hds3flub7` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`),
  CONSTRAINT `FK1p4jmrmr2qrkhwk2sfuijtd3v` FOREIGN KEY (`taLicenceRenewalId`) REFERENCES `ta_licence_renewals` (`id`),
  CONSTRAINT `FK2pckjlmi8c1ymxrbplyo2p2n8` FOREIGN KEY (`taNetValueShortfallAa1Id`) REFERENCES `ta_net_value_shortfalls` (`id`),
  CONSTRAINT `FK39idwnlex78sx4vu8xdqcivt1` FOREIGN KEY (`exerciseStartEmailLogId`) REFERENCES `email_logs` (`id`),
  CONSTRAINT `FK57nu0hppsqbg8oaecdcbb6gas` FOREIGN KEY (`taAaFilingCondition2Id`) REFERENCES `ta_filing_conditions` (`id`),
  CONSTRAINT `FK5bi6koj7d39ffbtls1lefhnyf` FOREIGN KEY (`taLicenceRenewalExerciseId`) REFERENCES `ta_licence_renewal_exercises` (`id`),
  CONSTRAINT `FK68gi2bq67xq2io8w45epk6rlq` FOREIGN KEY (`taAbprFilingCondition2Id`) REFERENCES `ta_filing_conditions` (`id`),
  CONSTRAINT `FKasnhecb637torbcdylnh46rl3` FOREIGN KEY (`taNetValueShortfallMa2Id`) REFERENCES `ta_net_value_shortfalls` (`id`),
  CONSTRAINT `FKcv61w8sphx5gke0pr10no2t4k` FOREIGN KEY (`taAbprFilingCondition1Id`) REFERENCES `ta_filing_conditions` (`id`),
  CONSTRAINT `FKe21o16jye06oy4rijre4cpxkr` FOREIGN KEY (`exerciseEndEmailLogId`) REFERENCES `email_logs` (`id`),
  CONSTRAINT `FKg62oegw2rled5cci05bn52rwh` FOREIGN KEY (`maFilingConditionId`) REFERENCES `ta_filing_conditions` (`id`),
  CONSTRAINT `FKljfquocycscv41aqhq36t3ppy` FOREIGN KEY (`taNetValueShortfallAa2Id`) REFERENCES `ta_net_value_shortfalls` (`id`),
  CONSTRAINT `FKnu3dytvlvp12yq3e7skwwp203` FOREIGN KEY (`taAaFilingCondition1Id`) REFERENCES `ta_filing_conditions` (`id`),
  CONSTRAINT `FKp77edi3mmdt4i87581lsw4mf2` FOREIGN KEY (`taNetValueShortfallMa1Id`) REFERENCES `ta_net_value_shortfalls` (`id`),
  CONSTRAINT `FKq3ij9f677ongjhdq71393ct7i` FOREIGN KEY (`typeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKr6th85mcdrk8jvb8iwll7uick` FOREIGN KEY (`keId`) REFERENCES `ta_stakeholders` (`id`),
  CONSTRAINT `FKrslc93e7nq436sjocbs3khdqc` FOREIGN KEY (`baselinedKeId`) REFERENCES `ta_stakeholders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_licence_renewal_exercise_tas`
--

LOCK TABLES `ta_licence_renewal_exercise_tas` WRITE;
/*!40000 ALTER TABLE `ta_licence_renewal_exercise_tas` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_licence_renewal_exercise_tas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:26
