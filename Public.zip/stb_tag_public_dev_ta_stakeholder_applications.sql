-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ta_stakeholder_applications`
--

DROP TABLE IF EXISTS `ta_stakeholder_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_stakeholder_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `appointedDate` date DEFAULT NULL,
  `companyIncorporatedDate` date DEFAULT NULL,
  `companyUen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formerUin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCompany` bit(1) NOT NULL DEFAULT b'0',
  `isMyInfoPopulated` bit(1) NOT NULL DEFAULT b'0',
  `joinedDate` date DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otherDesignation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resignedDate` date DEFAULT NULL,
  `sharesHeld` int(11) DEFAULT NULL,
  `uin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressId` int(11) DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `designationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highestEduLevelCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previousValueId` int(11) DEFAULT NULL,
  `roleCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taLicenceCreationId` int(11) DEFAULT NULL,
  `taStakeholderId` int(11) DEFAULT NULL,
  `typeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `officeNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `residentialNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isEdhPopulated` bit(1) NOT NULL DEFAULT b'0',
  `tarR153aInfringementId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3e0eguyd775skp0dxhaxhlt5l` (`addressId`),
  KEY `FK8dorvtfphpbo6di92ki1q3sv4` (`applicationId`),
  KEY `FKsb2w4erhlprcaf173ox06t2r` (`designationCode`),
  KEY `FK2oork00l4d1mowmsfkuof6lq` (`highestEduLevelCode`),
  KEY `FK9a4co3vu168jbxh6l6d8uk3yv` (`nationalityCode`),
  KEY `FKgsf34tn7co8wf3bijfidcbiwf` (`previousValueId`),
  KEY `FKh3khp9i12r2j2hsm76npqtyh0` (`roleCode`),
  KEY `FKlhl906fw2fr82ma2r8v9ro2pr` (`sexCode`),
  KEY `FK2j84kfjom80r0oyw3s8i6gn0o` (`taLicenceCreationId`),
  KEY `FKo8dmjay2rc2npvmoi4q6ni7a8` (`taStakeholderId`),
  KEY `FKsw89ggjwod7btlwas3r48sy69` (`typeCode`),
  KEY `FK8gdw80rhlrd3i0nu7bs0h2df0` (`tarR153aInfringementId`),
  CONSTRAINT `FK2j84kfjom80r0oyw3s8i6gn0o` FOREIGN KEY (`taLicenceCreationId`) REFERENCES `ta_licence_creations` (`id`),
  CONSTRAINT `FK2oork00l4d1mowmsfkuof6lq` FOREIGN KEY (`highestEduLevelCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK3e0eguyd775skp0dxhaxhlt5l` FOREIGN KEY (`addressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FK8dorvtfphpbo6di92ki1q3sv4` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FK8gdw80rhlrd3i0nu7bs0h2df0` FOREIGN KEY (`tarR153aInfringementId`) REFERENCES `ce_case_infringements` (`id`),
  CONSTRAINT `FK9a4co3vu168jbxh6l6d8uk3yv` FOREIGN KEY (`nationalityCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKgsf34tn7co8wf3bijfidcbiwf` FOREIGN KEY (`previousValueId`) REFERENCES `ta_stakeholder_applications` (`id`),
  CONSTRAINT `FKh3khp9i12r2j2hsm76npqtyh0` FOREIGN KEY (`roleCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKlhl906fw2fr82ma2r8v9ro2pr` FOREIGN KEY (`sexCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKo8dmjay2rc2npvmoi4q6ni7a8` FOREIGN KEY (`taStakeholderId`) REFERENCES `ta_stakeholders` (`id`),
  CONSTRAINT `FKsb2w4erhlprcaf173ox06t2r` FOREIGN KEY (`designationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKsw89ggjwod7btlwas3r48sy69` FOREIGN KEY (`typeCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta_stakeholder_applications`
--

LOCK TABLES `ta_stakeholder_applications` WRITE;
/*!40000 ALTER TABLE `ta_stakeholder_applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta_stakeholder_applications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:53
