-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_candidate_results`
--

DROP TABLE IF EXISTS `tg_candidate_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_candidate_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `examDate` date DEFAULT NULL,
  `legacyId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guidingLanguageCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selectedItineraryCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specializedAreaCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgCandidateId` int(11) DEFAULT NULL,
  `tgTrainingProviderId` int(11) DEFAULT NULL,
  `tierCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assessor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chiefAssessor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deputyChiefAssessor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `directIssuanceDate` date DEFAULT NULL,
  `isDirectIssuance` bit(1) DEFAULT NULL,
  `isForSwitchTier` bit(1) NOT NULL DEFAULT b'0',
  `billRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7gxf2ik7jxckfmbuh8y2x3ygx` (`guidingLanguageCode`),
  KEY `FK1f36k5sm2jjcp1ikj5w186pav` (`resultCode`),
  KEY `FK5lot7r4d8bqdl69ajdji8i3k1` (`selectedItineraryCode`),
  KEY `FK1ir687uyj9hhrhn051a5ll28j` (`specializedAreaCode`),
  KEY `FKr6aq28posnppptastxyunmwbb` (`tgCandidateId`),
  KEY `FKr4mv4mlx6c8roi9v9n38mn6th` (`tgTrainingProviderId`),
  KEY `FKae8nribwrgg9e5j9pko4xblbo` (`tierCode`),
  CONSTRAINT `FK1f36k5sm2jjcp1ikj5w186pav` FOREIGN KEY (`resultCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FK1ir687uyj9hhrhn051a5ll28j` FOREIGN KEY (`specializedAreaCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK5lot7r4d8bqdl69ajdji8i3k1` FOREIGN KEY (`selectedItineraryCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK7gxf2ik7jxckfmbuh8y2x3ygx` FOREIGN KEY (`guidingLanguageCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKae8nribwrgg9e5j9pko4xblbo` FOREIGN KEY (`tierCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKr4mv4mlx6c8roi9v9n38mn6th` FOREIGN KEY (`tgTrainingProviderId`) REFERENCES `tg_training_providers` (`id`),
  CONSTRAINT `FKr6aq28posnppptastxyunmwbb` FOREIGN KEY (`tgCandidateId`) REFERENCES `tg_candidates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_candidate_results`
--

LOCK TABLES `tg_candidate_results` WRITE;
/*!40000 ALTER TABLE `tg_candidate_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `tg_candidate_results` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:40
