-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_licence_creations`
--

DROP TABLE IF EXISTS `tg_licence_creations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_licence_creations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `aliasName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appFeeBillRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `emailAddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enforcementOutcome` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasConsentEmailAddress` bit(1) NOT NULL DEFAULT b'0',
  `hasConsentMobileNo` bit(1) NOT NULL DEFAULT b'0',
  `isMyInfoPopulated` bit(1) NOT NULL DEFAULT b'0',
  `mobileNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupationOther` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offenceDate` date DEFAULT NULL,
  `offenceDeclaredDate` datetime(6) DEFAULT NULL,
  `offenceType` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workpassExpiryDate` date DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `birthCountryCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highestEduLevelCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maritalStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operatingAddressId` int(11) DEFAULT NULL,
  `raceCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registeredAddressId` int(11) DEFAULT NULL,
  `residentialStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salutationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `workPassTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medisavePaymentStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKl9gh9g2l5ekn5o5r5naisx2lk` (`applicationId`),
  KEY `FKpjmd50dg8xmrp8npkabfk54lw` (`birthCountryCode`),
  KEY `FKobfqur6nau8dg6o5n2xabtx1e` (`highestEduLevelCode`),
  KEY `FKss2w9ftlynwvqkyp3l8cr04ii` (`maritalStatusCode`),
  KEY `FK95jrxgvphle7skrp1mw1tar0x` (`nationalityCode`),
  KEY `FK3gx0hugac0v0mgwaru0igx02e` (`occupationCode`),
  KEY `FKblw2d35x4ci21dapg10sclfye` (`operatingAddressId`),
  KEY `FKrjqmfmv0py8pl3r4cs0ryy7mo` (`raceCode`),
  KEY `FK40sofkf88g1ej90a0to3vsra1` (`registeredAddressId`),
  KEY `FKj3twsp9ncjqbwptn1lrqml51c` (`residentialStatusCode`),
  KEY `FKdqt6hj23atxd06pbp4js5lc4g` (`salutationCode`),
  KEY `FK2fhg5j0tupy2ritxsq3qd3plu` (`sexCode`),
  KEY `FKabc0v7ebugfldk9f02s4x83ne` (`userId`),
  KEY `FKqr2w5wdbcud1g9cunv0cnahdh` (`workPassTypeCode`),
  KEY `FKigy9ggkxwy09q7mx4hdb51861` (`medisavePaymentStatusCode`),
  CONSTRAINT `FK2fhg5j0tupy2ritxsq3qd3plu` FOREIGN KEY (`sexCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK3gx0hugac0v0mgwaru0igx02e` FOREIGN KEY (`occupationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK40sofkf88g1ej90a0to3vsra1` FOREIGN KEY (`registeredAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FK95jrxgvphle7skrp1mw1tar0x` FOREIGN KEY (`nationalityCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKabc0v7ebugfldk9f02s4x83ne` FOREIGN KEY (`userId`) REFERENCES `users` (`id`),
  CONSTRAINT `FKblw2d35x4ci21dapg10sclfye` FOREIGN KEY (`operatingAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKdqt6hj23atxd06pbp4js5lc4g` FOREIGN KEY (`salutationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKigy9ggkxwy09q7mx4hdb51861` FOREIGN KEY (`medisavePaymentStatusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKj3twsp9ncjqbwptn1lrqml51c` FOREIGN KEY (`residentialStatusCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKl9gh9g2l5ekn5o5r5naisx2lk` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FKobfqur6nau8dg6o5n2xabtx1e` FOREIGN KEY (`highestEduLevelCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKpjmd50dg8xmrp8npkabfk54lw` FOREIGN KEY (`birthCountryCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKqr2w5wdbcud1g9cunv0cnahdh` FOREIGN KEY (`workPassTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKrjqmfmv0py8pl3r4cs0ryy7mo` FOREIGN KEY (`raceCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKss2w9ftlynwvqkyp3l8cr04ii` FOREIGN KEY (`maritalStatusCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_licence_creations`
--

LOCK TABLES `tg_licence_creations` WRITE;
/*!40000 ALTER TABLE `tg_licence_creations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tg_licence_creations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:38
