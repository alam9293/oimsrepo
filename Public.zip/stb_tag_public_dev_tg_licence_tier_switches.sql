-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_licence_tier_switches`
--

DROP TABLE IF EXISTS `tg_licence_tier_switches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_licence_tier_switches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `appFeeBillRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendingSwitch` bit(1) NOT NULL DEFAULT b'0',
  `startDate` date DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `newLicenceTierCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oldLicenceTierCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specializedAreaCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgCandidateResultId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfs68kk50ehdrb61riqgyujbsd` (`applicationId`),
  KEY `FK17gr6o6bafl01ln5mt1r71ra5` (`newLicenceTierCode`),
  KEY `FKf0ohtf2ohdp5fj59md85net54` (`oldLicenceTierCode`),
  KEY `FKdngk88yfsli7u3125a92s6gxo` (`specializedAreaCode`),
  KEY `FK8prpepcvalgms9ljwmo34iyog` (`tgCandidateResultId`),
  CONSTRAINT `FK17gr6o6bafl01ln5mt1r71ra5` FOREIGN KEY (`newLicenceTierCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK8prpepcvalgms9ljwmo34iyog` FOREIGN KEY (`tgCandidateResultId`) REFERENCES `tg_candidate_results` (`id`),
  CONSTRAINT `FKdngk88yfsli7u3125a92s6gxo` FOREIGN KEY (`specializedAreaCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKf0ohtf2ohdp5fj59md85net54` FOREIGN KEY (`oldLicenceTierCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKfs68kk50ehdrb61riqgyujbsd` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_licence_tier_switches`
--

LOCK TABLES `tg_licence_tier_switches` WRITE;
/*!40000 ALTER TABLE `tg_licence_tier_switches` DISABLE KEYS */;
/*!40000 ALTER TABLE `tg_licence_tier_switches` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:09
