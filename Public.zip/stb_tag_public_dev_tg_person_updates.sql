-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tg_person_updates`
--

DROP TABLE IF EXISTS `tg_person_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg_person_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `aliasName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appFeeBillRefNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `emailAddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enforcementOutcome` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasConsentEmailAddress` bit(1) NOT NULL DEFAULT b'0',
  `hasConsentMobileNo` bit(1) NOT NULL DEFAULT b'0',
  `isMyInfoPopulated` bit(1) NOT NULL DEFAULT b'0',
  `mobileNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupationOther` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offenceDate` date DEFAULT NULL,
  `offenceDeclaredDate` datetime(6) DEFAULT NULL,
  `offenceType` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workpassExpiryDate` date DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `birthCountryCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highestEduLevelCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maritalStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operatingAddressId` int(11) DEFAULT NULL,
  `raceCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registeredAddressId` int(11) DEFAULT NULL,
  `residentialStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salutationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `workPassTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previousValueId` int(11) DEFAULT NULL,
  `photoId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1xkibgv27vpr9uh16tjg96bb3` (`applicationId`),
  KEY `FK11tb3m14ebo97n4rldkwcwekq` (`birthCountryCode`),
  KEY `FKfpyfl7ibn4xmt5eybk0banum3` (`highestEduLevelCode`),
  KEY `FK4klnuyqqvh4rfmh0wq4opxl2u` (`maritalStatusCode`),
  KEY `FK15croeslxh9orpp5clnc8ngpj` (`nationalityCode`),
  KEY `FKhl7mqf6fkurvvtujr9jybxjsx` (`occupationCode`),
  KEY `FK3x66y571pk5480bmvk72lfcmm` (`operatingAddressId`),
  KEY `FKdy45gxxmvt3noodtsxlktlwak` (`raceCode`),
  KEY `FKciyda07xoa0s9b9jqlfdci9fp` (`registeredAddressId`),
  KEY `FK30qpnp42hndc7xcm9fug6324h` (`residentialStatusCode`),
  KEY `FK91dw4c8p394guhpubawlt07em` (`salutationCode`),
  KEY `FKsjlw01uo39r0pyvcd5upufjc4` (`sexCode`),
  KEY `FKlv9r29p29y521s5t8fkcdyykq` (`userId`),
  KEY `FK86964iwpsp91sby6tjx0rgf` (`workPassTypeCode`),
  KEY `FKtdupwx3brvdy4yietpt9trouj` (`previousValueId`),
  KEY `FKaqx033rbjm84mg8v88lxxbsvg` (`photoId`),
  CONSTRAINT `FK11tb3m14ebo97n4rldkwcwekq` FOREIGN KEY (`birthCountryCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK15croeslxh9orpp5clnc8ngpj` FOREIGN KEY (`nationalityCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK1xkibgv27vpr9uh16tjg96bb3` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FK30qpnp42hndc7xcm9fug6324h` FOREIGN KEY (`residentialStatusCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK3x66y571pk5480bmvk72lfcmm` FOREIGN KEY (`operatingAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FK4klnuyqqvh4rfmh0wq4opxl2u` FOREIGN KEY (`maritalStatusCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK86964iwpsp91sby6tjx0rgf` FOREIGN KEY (`workPassTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK91dw4c8p394guhpubawlt07em` FOREIGN KEY (`salutationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKaqx033rbjm84mg8v88lxxbsvg` FOREIGN KEY (`photoId`) REFERENCES `files` (`id`),
  CONSTRAINT `FKciyda07xoa0s9b9jqlfdci9fp` FOREIGN KEY (`registeredAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKdy45gxxmvt3noodtsxlktlwak` FOREIGN KEY (`raceCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKfpyfl7ibn4xmt5eybk0banum3` FOREIGN KEY (`highestEduLevelCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKhl7mqf6fkurvvtujr9jybxjsx` FOREIGN KEY (`occupationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKlv9r29p29y521s5t8fkcdyykq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`),
  CONSTRAINT `FKsjlw01uo39r0pyvcd5upufjc4` FOREIGN KEY (`sexCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKtdupwx3brvdy4yietpt9trouj` FOREIGN KEY (`previousValueId`) REFERENCES `tg_person_updates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg_person_updates`
--

LOCK TABLES `tg_person_updates` WRITE;
/*!40000 ALTER TABLE `tg_person_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tg_person_updates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:34
