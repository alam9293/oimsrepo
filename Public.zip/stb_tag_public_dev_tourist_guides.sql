-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tourist_guides`
--

DROP TABLE IF EXISTS `tourist_guides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tourist_guides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `aliasName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `emailAddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enforcementOutcome` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formerUin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasConsentEmailAddress` bit(1) NOT NULL DEFAULT b'0',
  `hasConsentMobileNo` bit(1) NOT NULL DEFAULT b'0',
  `hasPassedOn` bit(1) NOT NULL DEFAULT b'0',
  `legacyId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobileNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupationOther` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offenceDate` date DEFAULT NULL,
  `offenceDeclaredDate` datetime(6) DEFAULT NULL,
  `offenceType` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workPassExpiryDate` date DEFAULT NULL,
  `birthCountryCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highestEduLevelCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `mailingAddressId` int(11) DEFAULT NULL,
  `maritalStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationalityCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photoId` int(11) DEFAULT NULL,
  `raceCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registeredAddressId` int(11) DEFAULT NULL,
  `residentialStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salutationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workPassTypeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasPersonUpdateAccess` bit(1) NOT NULL DEFAULT b'0',
  `isMyInfoPopulated` bit(1) NOT NULL DEFAULT b'0',
  `displayEmployerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayame` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displaySecondEmployerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displaySecondName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7u7cqsmvhhq1caq3c9pnucyon` (`birthCountryCode`),
  KEY `FKshe4y9yxgvd6crj0oom5f8rym` (`highestEduLevelCode`),
  KEY `FKdofohvodtxpuhy461p7dcqyo5` (`licenceId`),
  KEY `FKspyladhailrl3n5wqcnjcu84h` (`mailingAddressId`),
  KEY `FKnc8w7kng1gopeqps8g60w4ekm` (`maritalStatusCode`),
  KEY `FKlhpk65ab0w51kt67g1e6kkvmp` (`nationalityCode`),
  KEY `FKhqdflk1rutd0dxejkj8q2meu0` (`occupationCode`),
  KEY `FKk1n9o3npfd2uumvrk95nbdfmy` (`photoId`),
  KEY `FKh1u58efqbkau4icxmqokee8th` (`raceCode`),
  KEY `FKb1ob8y72qykln4iaibnwf4nif` (`registeredAddressId`),
  KEY `FK6pybmyuva9yfja21kaigb9q2g` (`residentialStatusCode`),
  KEY `FK4pm5xnx2b4x9p5i5m6ykfw318` (`salutationCode`),
  KEY `FK9yqkv2pu7gpq4n38x6ia8cb56` (`sexCode`),
  KEY `FKr8r64q5ajtlrnfv2k8ihvbgtl` (`workPassTypeCode`),
  CONSTRAINT `FK4pm5xnx2b4x9p5i5m6ykfw318` FOREIGN KEY (`salutationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK6pybmyuva9yfja21kaigb9q2g` FOREIGN KEY (`residentialStatusCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK7u7cqsmvhhq1caq3c9pnucyon` FOREIGN KEY (`birthCountryCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK9yqkv2pu7gpq4n38x6ia8cb56` FOREIGN KEY (`sexCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKb1ob8y72qykln4iaibnwf4nif` FOREIGN KEY (`registeredAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKdofohvodtxpuhy461p7dcqyo5` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`),
  CONSTRAINT `FKh1u58efqbkau4icxmqokee8th` FOREIGN KEY (`raceCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKhqdflk1rutd0dxejkj8q2meu0` FOREIGN KEY (`occupationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKk1n9o3npfd2uumvrk95nbdfmy` FOREIGN KEY (`photoId`) REFERENCES `files` (`id`),
  CONSTRAINT `FKlhpk65ab0w51kt67g1e6kkvmp` FOREIGN KEY (`nationalityCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKnc8w7kng1gopeqps8g60w4ekm` FOREIGN KEY (`maritalStatusCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKr8r64q5ajtlrnfv2k8ihvbgtl` FOREIGN KEY (`workPassTypeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKshe4y9yxgvd6crj0oom5f8rym` FOREIGN KEY (`highestEduLevelCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKspyladhailrl3n5wqcnjcu84h` FOREIGN KEY (`mailingAddressId`) REFERENCES `addresses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tourist_guides`
--

LOCK TABLES `tourist_guides` WRITE;
/*!40000 ALTER TABLE `tourist_guides` DISABLE KEYS */;
/*!40000 ALTER TABLE `tourist_guides` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:54
