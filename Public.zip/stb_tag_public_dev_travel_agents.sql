-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `travel_agents`
--

DROP TABLE IF EXISTS `travel_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel_agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `contactNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emailAddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formerName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fyeDate` date DEFAULT NULL,
  `incorporatedDate` date DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paidUpCapital` decimal(19,2) DEFAULT NULL,
  `uen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `websiteUrl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessConstitutionCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `establishmentStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formOfBusinessCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `incorporatedPlaceCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenceId` int(11) DEFAULT NULL,
  `operatingAddressId` int(11) DEFAULT NULL,
  `principleActivitiesCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registeredAddressId` int(11) DEFAULT NULL,
  `secondaryPrincipleActivitiesCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taSegmentationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faxNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isLastOpAddrCheckDone` bit(1) DEFAULT NULL,
  `isLastRegAddrCheckDone` bit(1) DEFAULT NULL,
  `lastOpAddrTaCheckId` int(11) DEFAULT NULL,
  `lastRegAddrTaCheckId` int(11) DEFAULT NULL,
  `displayName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayAddressId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqgcwjf8pidxhbc427x0e3rg0t` (`businessConstitutionCode`),
  KEY `FKn5avhpyd8foh3lqenojtts4wf` (`establishmentStatusCode`),
  KEY `FKswgyiwpnbowvj7kjn4c8317yo` (`formOfBusinessCode`),
  KEY `FKfodvu1y3fffqj7vtvm5gjgoxc` (`incorporatedPlaceCode`),
  KEY `FKoxw4d65dsmoks55spdhst3x72` (`licenceId`),
  KEY `FKrqbhnrk07na30e6yxw55npx7p` (`operatingAddressId`),
  KEY `FKf0arhvdlc0xrs2x1q98oap1yp` (`principleActivitiesCode`),
  KEY `FKfloea2iwhe0293i2sul4vykca` (`registeredAddressId`),
  KEY `FKcgec13jc0okxl29rk7gq1wuii` (`secondaryPrincipleActivitiesCode`),
  KEY `FK17yujfgbfy2dtj5buw4ohtvx` (`taSegmentationCode`),
  KEY `FKddrtjghrf65vj6upibq9tn0co` (`lastOpAddrTaCheckId`),
  KEY `FK8iuky3k8hlgorwxud09i2n676` (`lastRegAddrTaCheckId`),
  KEY `FKejr8fneyppl9gv028r66j70w4` (`displayAddressId`),
  CONSTRAINT `FK17yujfgbfy2dtj5buw4ohtvx` FOREIGN KEY (`taSegmentationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK8iuky3k8hlgorwxud09i2n676` FOREIGN KEY (`lastRegAddrTaCheckId`) REFERENCES `ce_ta_checks` (`id`),
  CONSTRAINT `FKcgec13jc0okxl29rk7gq1wuii` FOREIGN KEY (`secondaryPrincipleActivitiesCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKddrtjghrf65vj6upibq9tn0co` FOREIGN KEY (`lastOpAddrTaCheckId`) REFERENCES `ce_ta_checks` (`id`),
  CONSTRAINT `FKejr8fneyppl9gv028r66j70w4` FOREIGN KEY (`displayAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKf0arhvdlc0xrs2x1q98oap1yp` FOREIGN KEY (`principleActivitiesCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKfloea2iwhe0293i2sul4vykca` FOREIGN KEY (`registeredAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKfodvu1y3fffqj7vtvm5gjgoxc` FOREIGN KEY (`incorporatedPlaceCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKn5avhpyd8foh3lqenojtts4wf` FOREIGN KEY (`establishmentStatusCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKoxw4d65dsmoks55spdhst3x72` FOREIGN KEY (`licenceId`) REFERENCES `licences` (`id`),
  CONSTRAINT `FKqgcwjf8pidxhbc427x0e3rg0t` FOREIGN KEY (`businessConstitutionCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKrqbhnrk07na30e6yxw55npx7p` FOREIGN KEY (`operatingAddressId`) REFERENCES `addresses` (`id`),
  CONSTRAINT `FKswgyiwpnbowvj7kjn4c8317yo` FOREIGN KEY (`formOfBusinessCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_agents`
--

LOCK TABLES `travel_agents` WRITE;
/*!40000 ALTER TABLE `travel_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_agents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:23:28
