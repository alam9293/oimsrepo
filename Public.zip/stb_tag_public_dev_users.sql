-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `emailAddress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isLocked` bit(1) NOT NULL DEFAULT b'0',
  `lastLoginDate` datetime(6) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `loginId` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `securityQuestionAnswer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taAssigneeChars` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `securityQuestionCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgCandidateId` int(11) DEFAULT NULL,
  `tgTrainingProviderId` int(11) DEFAULT NULL,
  `touristGuideId` int(11) DEFAULT NULL,
  `travelAgentId` int(11) DEFAULT NULL,
  `typeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `departmentCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKk34nv9d37hkggj4vuc3t4jwmg` (`securityQuestionCode`),
  KEY `FKarymrxmadkdsec3ykwhyftgdc` (`statusCode`),
  KEY `FKo1y2hj1xu1xvycmtqtqnesnn9` (`tgCandidateId`),
  KEY `FK6fmf21sqkhk6p1xlihlgdu9mp` (`tgTrainingProviderId`),
  KEY `FKt07beq56vf50ecr6u2q64ar2h` (`touristGuideId`),
  KEY `FKmjvnak7epfa61g27mgiyb6fdv` (`travelAgentId`),
  KEY `FK1a3u2l7le1w7msrt0qxxk3vby` (`typeCode`),
  KEY `FK29l2swn6kwd0xk4jmsdnwu9b0` (`departmentCode`),
  CONSTRAINT `FK1a3u2l7le1w7msrt0qxxk3vby` FOREIGN KEY (`typeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK29l2swn6kwd0xk4jmsdnwu9b0` FOREIGN KEY (`departmentCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FK6fmf21sqkhk6p1xlihlgdu9mp` FOREIGN KEY (`tgTrainingProviderId`) REFERENCES `tg_training_providers` (`id`),
  CONSTRAINT `FKarymrxmadkdsec3ykwhyftgdc` FOREIGN KEY (`statusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKk34nv9d37hkggj4vuc3t4jwmg` FOREIGN KEY (`securityQuestionCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKmjvnak7epfa61g27mgiyb6fdv` FOREIGN KEY (`travelAgentId`) REFERENCES `travel_agents` (`id`),
  CONSTRAINT `FKo1y2hj1xu1xvycmtqtqnesnn9` FOREIGN KEY (`tgCandidateId`) REFERENCES `tg_candidates` (`id`),
  CONSTRAINT `FKt07beq56vf50ecr6u2q64ar2h` FOREIGN KEY (`touristGuideId`) REFERENCES `tourist_guides` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:39
