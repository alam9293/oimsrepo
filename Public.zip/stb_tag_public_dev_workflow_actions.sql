-- MySQL dump 10.13  Distrib 8.0.0-dmr, for Win64 (x86_64)
--
-- Host: localhost    Database: stb_tag_public_dev
-- ------------------------------------------------------
-- Server version	8.0.0-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `workflow_actions`
--

DROP TABLE IF EXISTS `workflow_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `externalRemarks` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internalRemarks` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  `prevStatusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roleCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statusCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actionById` int(11) DEFAULT NULL,
  `recommendationCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `typeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workflowId` int(11) DEFAULT NULL,
  `AssigneeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKau3bvulhedjb8vfbagoe3pvum` (`applicationId`),
  KEY `FKd4ehf35irpwxjp4ak22fs32pj` (`prevStatusCode`),
  KEY `FK32pvofu1jfnwxwago9e0av2hs` (`roleCode`),
  KEY `FKki6520jhcltd3o96gsgnnbfrx` (`statusCode`),
  KEY `FKs7a0lpr5d71olopuhaip5c8me` (`actionById`),
  KEY `FKhm7uh3qxvwpg3ifur1onyvxuc` (`recommendationCode`),
  KEY `FKdso4yntcuai1y7wr216op1ojx` (`typeCode`),
  KEY `FKguv9my04lgpf2us0fbq0vs1h5` (`workflowId`),
  KEY `FKhhxpi5tuodskg2thar82736yi` (`AssigneeId`),
  CONSTRAINT `FK32pvofu1jfnwxwago9e0av2hs` FOREIGN KEY (`roleCode`) REFERENCES `roles` (`code`),
  CONSTRAINT `FKau3bvulhedjb8vfbagoe3pvum` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`),
  CONSTRAINT `FKd4ehf35irpwxjp4ak22fs32pj` FOREIGN KEY (`prevStatusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKdso4yntcuai1y7wr216op1ojx` FOREIGN KEY (`typeCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKguv9my04lgpf2us0fbq0vs1h5` FOREIGN KEY (`workflowId`) REFERENCES `workflows` (`id`),
  CONSTRAINT `FKhhxpi5tuodskg2thar82736yi` FOREIGN KEY (`AssigneeId`) REFERENCES `users` (`id`),
  CONSTRAINT `FKhm7uh3qxvwpg3ifur1onyvxuc` FOREIGN KEY (`recommendationCode`) REFERENCES `types` (`code`),
  CONSTRAINT `FKki6520jhcltd3o96gsgnnbfrx` FOREIGN KEY (`statusCode`) REFERENCES `statuses` (`code`),
  CONSTRAINT `FKs7a0lpr5d71olopuhaip5c8me` FOREIGN KEY (`actionById`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_actions`
--

LOCK TABLES `workflow_actions` WRITE;
/*!40000 ALTER TABLE `workflow_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_actions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 14:22:50
