import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { distinctUntilChanged } from 'rxjs/operators';
import { environment as env } from '../environments/environment';

declare var gtag: Function;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
    constructor(
        private router: Router
    ) {
        router.events.pipe(distinctUntilChanged((previous: any, current: any) => {
            // Subscribe to any `NavigationEnd` events where the url has changed
            if (current instanceof NavigationEnd) {
                return previous.url === current.url;
            }
        })).subscribe((x: any) => {
            gtag('config', env.googleAnalyticId, { 'page_path': x.url });
        });
    }

    ngOnInit() { }

    onActivate(event) {
        window.scrollTo(0, 0);
    }
}
