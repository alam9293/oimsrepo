import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { environment as env } from '../../../environments/environment';
import * as _ from 'lodash';
import * as cnst from '../../common/constants';
import { AppUtil } from '../../common/helper/app.util';
import { AlertPromise } from 'selenium-webdriver';
import { Alert } from '../models';

@Injectable()
export class AuthPortalGuard implements CanActivate {
    _ = _;

    constructor(
        private router: Router,
        private authenticationService: AuthenticationService,
        private appUtil: AppUtil,
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser = this.authenticationService.currentUserValue;
        let dashboardTypeCode = route.firstChild.data.dashboardTypeCode;

        if (currentUser) {

            //check if route is restricted by role
            if (currentUser.selectedRole.key === cnst.CommonRoles.TA_CANDIDATE && dashboardTypeCode !== cnst.dashboardTypeCode.TACDD) {
                //role not authorised so redirect to default page
                this.router.navigate([cnst.TaApplicationUrl.TA_APP_NEW]);
                return true;
            }

            //authorised so return true
            return true;
        } else {
            console.log('Auth Guard UAT');
            // not logged in so redirect to login page with the return url
            // this.router.navigate(['/portal/login'], { queryParams: { returnUrl: state.url } });

            // if-else to allow uat to use portal login for all, and testing urls to use spcp
            if (state.url.includes("testing-iams")) {
                if (dashboardTypeCode == cnst.dashboardTypeCode.TA || dashboardTypeCode == cnst.dashboardTypeCode.TACDD || dashboardTypeCode == cnst.dashboardTypeCode.TP) {

                    this.authenticationService.storeReturnUrlInfo(dashboardTypeCode + "/" + state.url);
                    window.location.href = _.replace(env.testingIamsUrl, '${CLIENT_ID}', env.iamsClientId).replace('${LOGIN_TYPE}', 'login-cp').replace('${ACR_VALUE}', 'stb-corppass').replace('${UEN_SCOPE}', '%20uen');
                }
                else if (dashboardTypeCode == cnst.dashboardTypeCode.TG) {

                    if (state.url.includes("tg-portal")) {
                        this.authenticationService.storeReturnUrlInfo(dashboardTypeCode + "/" + state.url);
                        window.location.href = _.replace(env.testingIamsUrl, '${CLIENT_ID}', env.iamsClientId).replace('${LOGIN_TYPE}', 'login-portal').replace('${ACR_VALUE}', 'stb-portal').replace('${UEN_SCOPE}', '');
                    } else {
                        this.authenticationService.storeReturnUrlInfo(dashboardTypeCode + "/" + state.url);
                        window.location.href = _.replace(env.testingIamsUrl, '${CLIENT_ID}', env.iamsClientId).replace('${LOGIN_TYPE}', 'login-sp').replace('${ACR_VALUE}', 'stb-singpass').replace('${UEN_SCOPE}', '');
                    }
                }
                else {
                    this.appUtil.routeToHomePage();
                }

            } else {
                if (dashboardTypeCode == cnst.dashboardTypeCode.TA || dashboardTypeCode == cnst.dashboardTypeCode.TACDD || dashboardTypeCode == cnst.dashboardTypeCode.TP) {
                    this.authenticationService.storeReturnUrlInfo(dashboardTypeCode + "/" + state.url);
                    window.location.href = _.replace(env.iamsUrl, '${CLIENT_ID}', env.iamsClientId).replace('${LOGIN_TYPE}', 'login-cp').replace('${ACR_VALUE}', 'stb-corppass').replace('${UEN_SCOPE}', '%20uen');
                }
                else if (dashboardTypeCode == cnst.dashboardTypeCode.TG) {

                    if (state.url.includes("tg-portal")) {
                        this.authenticationService.storeReturnUrlInfo(dashboardTypeCode + "/" + state.url);
                        window.location.href = _.replace(env.iamsUrl, '${CLIENT_ID}', env.iamsClientId).replace('${LOGIN_TYPE}', 'login-portal').replace('${ACR_VALUE}', 'stb-portal').replace('${UEN_SCOPE}', '');
                    } else {
                        this.authenticationService.storeReturnUrlInfo(dashboardTypeCode + "/" + state.url);
                        window.location.href = _.replace(env.iamsUrl, '${CLIENT_ID}', env.iamsClientId).replace('${LOGIN_TYPE}', 'login-sp').replace('${ACR_VALUE}', 'stb-singpass').replace('${UEN_SCOPE}', '');
                    }
                }
                else {
                    this.appUtil.routeToHomePage();
                }

            }
            return false;
        }
    }

}
