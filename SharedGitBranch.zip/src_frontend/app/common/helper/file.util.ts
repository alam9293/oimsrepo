import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../constants';
import { ErrorDialogService } from '../services/errordialog.service'

@Injectable({
    providedIn: 'root'
})
export class FileUtil {

    constructor(private http: HttpClient, public errorDialogService: ErrorDialogService) { }

    export(data: any, fileName: string) {
        // const blob = new Blob([data], { type: 'application/octet-stream' });
        // var link = document.createElement('a');
        // link.href = window.URL.createObjectURL(blob);
        // link.download = fileName;
        // link.click();
        const blob = new Blob([data], { type: data.type });

        if (window.navigator.msSaveOrOpenBlob) //IE & Edge
        {
            //msSaveBlob only available for IE & Edge
            window.navigator.msSaveBlob(blob, fileName);
        }
        else //Chrome & FF
        {
            const url = window.URL.createObjectURL(blob);
            const anchor = document.createElement("a");
            anchor.href = url;
            anchor.download = fileName;
            document.body.appendChild(anchor); //For FF
            anchor.click();
            //It's better to remove the elem
            document.body.removeChild(anchor);
        }

    }


    exportToNewTab(data: any, fileName: string) {
        const blob = new Blob([data], { type: data.type });

        const url = window.URL.createObjectURL(blob);
        window.open(url, '_blank');


    }

    // formatBytes(bytes,decimals)
    formatBytes(a, b) { if (0 == a) return "0 Bytes"; var c = 1024, d = b || 2, e = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"], f = Math.floor(Math.log(a) / Math.log(c)); return parseFloat((a / Math.pow(c, f)).toFixed(d)) + " " + e[f] }

    downloadFromAdmin(fileId: number, hash): Observable<any> {
        if (fileId != null && hash != null) {
            return this.http.get<any>(cnst.apexBaseUrl + '/file/download/' + fileId + '/' + hash, { responseType: 'blob' as 'json' });
        }
    }

    download(fileId: number, hash): Observable<any> {
        if (fileId != null && hash != null) {
            return this.http.get<any>(cnst.apiBaseUrl + '/file/download/' + fileId + '/' + hash, { responseType: 'blob' as 'json' });
        }
    }

    downloadTemplate(docType) {
        this.downloadTemplateWithExt(docType, {});
    }

    downloadTemplateWithExt(docType, ext) {
        this.http.get<any>(cnst.apiBaseUrl + '/file/download-template/' + docType, { responseType: 'blob' as 'json' }).subscribe(data => {
            if (ext == 'xlsx') {
                data = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            }
            this.export(data, docType);
        });
    }

    upload(type: string, file: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildFormData(type, file);
        if (file.size <= maxFileSize) {
            return this.http.post(cnst.apiBaseUrl + '/file/upload', formData);
        }
        else {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
            });
            throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
        }
    }

    delete(deletedFiles: any) {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(deletedFiles)],
            { type: 'application/json' }
        ));
        return this.http.post(cnst.apiBaseUrl + '/file/delete', formData);
    }

    buildFormData(type, file) {

        var formDataObj = new FormData();
        formDataObj.append('docType', type);
        formDataObj.append('file', file);
        return formDataObj;
    }

    exceedMaxSize(file: any) {
        if (file.size > cnst.MAX_FILE_SIZE) {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(cnst.MAX_FILE_SIZE, 2) + "."
            });
            return true;
        }
        return false;
    }

    exceedMinSize(file: any) {
        if (file.size < cnst.MIN_FILE_SIZE) {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot be below " + this.formatBytes(cnst.MIN_FILE_SIZE, 2) + "."
            });
            return true;
        }
        return false;
    }

    checkPhotoFileExt(extension: any) {
        if (extension == 'pdf' || extension == 'doc' || extension == 'docx' || extension == 'doc' || extension == 'xls' || extension == 'xlsx') {
            this.errorDialogService.openDialog({
                reason: "Uploaded photo extension is not allowed."
            });
            return true;
        }
        return false;
    }


}
