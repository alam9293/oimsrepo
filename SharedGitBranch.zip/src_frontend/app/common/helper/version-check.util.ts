import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http'

@Injectable({
    providedIn: 'root'
})
export class VersionCheckUtil {

    constructor() { }

    public static getHeader(entityNames: string[]): {} {
        let headerValue: string = "";
        for (let entityName of entityNames) {
            headerValue += "," + entityName + "," + sessionStorage.getItem("VC-" + entityName);
        }
        if (headerValue.length > 0) {
            headerValue = headerValue.substring(1); // remove first comma
        }
        let headers = new HttpHeaders({
            "Version-Check": headerValue
        });
        return { headers: headers };
    }

    public static getHeaderForListing(entityName: string): {} {
        let headers = new HttpHeaders({
            "Version-Check-Listing": entityName + "," + sessionStorage.getItem("VCL-" + entityName)
        });
        return { headers: headers };
    }
}
