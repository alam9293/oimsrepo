import { FileDto, ListableDto } from './common';

export class TouristGuideDto {
    name: string;
    photo: FileDto;
    guidingLanguages: string;

    constructor() {
        this.photo = new FileDto();
    }
}

export class LicenceDto {
    licenceNumber: string;
    status: ListableDto;
    issueDate: Date;
    startDate: Date;
    expiryDate: Date;
    licenceTier: ListableDto;

    constructor() {
        this.status = new ListableDto();
        this.issueDate = new Date();
        this.startDate = new Date();
        this.expiryDate = new Date();
        this.licenceTier = new ListableDto();
    }
}

export class TgTrainingProviderDto {
    name: string;

    constructor() { }
}