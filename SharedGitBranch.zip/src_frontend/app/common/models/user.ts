import { ListableDto } from './common';

export class LicenseeDto {
    name: string;
    licenceNumber: string;
    status: ListableDto;
    renewalStatus: string;
}

export class User {
    id: number;
    loginId: string;
    name: string;
    licensee: LicenseeDto;
    status: ListableDto;
    selectedRole: ListableDto;
    roles: ListableDto[];
    permissions: ListableDto[];
    lastLoginDate: Date;
    token: string;
    tpPdc: boolean;
    tpMrc: boolean;
}