import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatButtonModule, MatIconModule, MatDividerModule } from '@angular/material';
import { PaymentDialogComponent } from './payment-dialog.component';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDividerModule,
        MatDialogModule,
        FlexLayoutModule
    ],
    declarations: [PaymentDialogComponent],
    exports: [PaymentDialogComponent]
})
export class PaymentDialogModule { }

