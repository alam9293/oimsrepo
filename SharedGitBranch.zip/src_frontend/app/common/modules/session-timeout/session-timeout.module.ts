import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SessionTimeoutComponent } from './session-timeout.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [SessionTimeoutComponent],
    exports: [SessionTimeoutComponent]
})
export class SessionTimeoutModule { }
