import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_SNACK_BAR_DATA } from '@angular/material';
@Component({
    selector: 'app-success-snackbar',
    templateUrl: './success-snackbar.component.html',
    styleUrls: ['./success-snackbar.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class SuccessSnackbarComponent implements OnInit {

    constructor(@Inject(MAT_SNACK_BAR_DATA) public data: any) { }

    ngOnInit() {
        if (!this.data) {
            this.data = {};
        }
    }

}
