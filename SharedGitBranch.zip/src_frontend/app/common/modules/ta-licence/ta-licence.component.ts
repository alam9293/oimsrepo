import { Component, OnInit, Input, ViewChild, Inject } from '@angular/core';
import * as dto from './ta-licence-dto';
import { DataService } from 'src/app/data.service';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MAT_DIALOG_DATA, MatDialogRef, } from '@angular/material';

@Component({
    selector: 'app-ta-licence',
    templateUrl: './ta-licence.component.html',
    styleUrls: ['./ta-licence.component.scss']
})
export class TaLicenceComponent implements OnInit {
    @Input() id: number;
    licence: dto.PeriodicElementDto;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    personnels: dto.PersonnelDetails[];
    dataSource = new MatTableDataSource(this.dataService.getLicenseePersonnelList().data);
    displayedColumns = ['name', 'nric', 'appt', 'sharesHold', 'keyExec'];

    constructor(private dataService: DataService, public dialog: MatDialog, ) { }
    app: string;
    ngOnInit() {
        this.personnels = this.dataService.getLicenseePersonnelList().data;
        this.licence = dto.MOCK_PERIODIC_ELEMENT;
        // this.dataSource = new MatTableDataSource(this.dataService.getLicenseePersonnelList().data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    }

    // openTaPersonnelDetailsDialog(id: number) {
    //     console.log("id " + id);
    //     if (id) {

    //     }
    //     const dialogRef = this.dialog.open(DialogPersonnelDetailsComponent, {
    //         data: this.data.getLicenseePersonnelDetails(id).data,
    //         //height: '600px',
    //         width: '1200px',
    //     });
    //     dialogRef.afterClosed().subscribe(result => {
    //         console.log('The dialog was closed ' + result);
    //         // this.dataSource = result;
    //     });

    // }

}
