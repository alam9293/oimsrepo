import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import { DateUtil } from '../helper/';

@Pipe({
    name: 'counterToSeconds'
})

export class counterToSecondsPipe implements PipeTransform {
    transform(value: number, format: string = ""): string {
        if (!value) return "";
        // convert to date, and set the seconds
        var dt = moment([1970, 1, 1]).second(value);
        // format it and return
        return moment(dt).format(format);
    }
}