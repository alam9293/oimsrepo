import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as cnst from '../constants';
import * as _ from 'lodash';
import { User } from '../models';
import { environment as env } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;

    constructor(private http: HttpClient) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(sessionStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    // to removed selectedLoginTypeCode
    login(loginId: string, password: string, uen: string, selectedLoginTypeCode: string) {
        let loginType = selectedLoginTypeCode === 'TAG' ? 'portal' : 'spcp';
        return this.http.post<any>(cnst.apexBaseUrl + '/users/authenticate/' + loginType, { loginId: loginId, password: password, uen: uen })
            .pipe(map(auth => {
                this.storeUserInfo(auth, selectedLoginTypeCode);    //to be changed back to "TAG"
                return auth;
            }));
    }

    mockIamsAuthorize(uin: string, uen: string) {
        return this.http.post<any>(cnst.apiBaseUrl + '/test/mock-iams-authorize' + uin + "/" + uen, null);
    }

    loginByIams(iamsAccessCode: string, dashboardTypeCode: string, loginTypeCode: string) {
        return this.http.post<any>(cnst.apiBaseUrl + '/users/authenticate-iams', { iamsAccessCode, dashboardTypeCode, loginTypeCode })
            .pipe(map(auth => {
                this.storeUserInfo(auth, loginTypeCode);
                return auth;
            }));
    }

    loginBySp(samlArtifact: string, relayState: string, dashboardTypeCode: string) {
        return this.http.post<any>(cnst.apiBaseUrl + '/users/authenticate-sp', { samlArtifact, relayState, dashboardTypeCode })
            .pipe(map(auth => {
                this.storeUserInfo(auth, "SP");
                return auth;
            }));
    }

    loginByCp(samlArtifact: string, relayState: string, dashboardTypeCode: string) {
        return this.http.post<any>(cnst.apiBaseUrl + '/users/authenticate-cp', { samlArtifact, relayState, dashboardTypeCode })
            .pipe(map(auth => {
                this.storeUserInfo(auth, "CP");
                return auth;
            }));
    }

    getCurrentUser() {
        return this.http.get<any>(cnst.apexBaseUrl + '/users/current');
    }

    extendCurrentSession() {
        return this.http.post<any>(cnst.apexBaseUrl + '/users/current/extend-session', {});
    }

    logout() {
        // remove user from local storage to log user out
        if (sessionStorage.getItem('currentUser') != null) {
            this.http.get<string>(cnst.apexBaseUrl + '/users/retrieve-current-login-iamsIdToken-and-logout', { responseType: 'text' as 'json' }).subscribe(data => {
                sessionStorage.removeItem('currentUser');
                sessionStorage.removeItem('loginTypeCode');

                //remove return url
                sessionStorage.removeItem('returnUrl');

                this.currentUserSubject.next(null);
                window.location.href = _.replace(env.iamsLogoutUrl, '${IAMS_ID_TOKEN}', data);
            });
        }

        //clearSession() if current user is null cannot be put in a else block
        //because login page run 2 times, before singpass login and after singpasslogin
    }

    clearSession() {
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('loginTypeCode');
        sessionStorage.removeItem('jwt-token');
        this.currentUserSubject.next(null);
        var data = "";
        window.location.href = _.replace(env.iamsLogoutUrl, '${IAMS_ID_TOKEN}', data);
    }

    private storeUserInfo(auth: any, loginTypeCode: string) {
        // login successful if there's a jwt token in the response
        if (auth.user && auth.auth) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            //auth.user.token = sessionStorage.getItem('jwt-token');
            sessionStorage.setItem('currentUser', JSON.stringify(auth.user));
            sessionStorage.setItem('loginTypeCode', loginTypeCode);
            this.currentUserSubject.next(auth.user);
        }
    }

    storeReturnUrlInfo(returnUrl: string) {
        sessionStorage.setItem('returnUrl', returnUrl);
    }

    isTaActive(): boolean {
        var currentUser = this.currentUserValue;
        if (currentUser) {
            return cnst.TaStatuses.ACTIVE.indexOf(currentUser.licensee.status.key) > -1;
        } else {
            return false;
        }
    }
}
