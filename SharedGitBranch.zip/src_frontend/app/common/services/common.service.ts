import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../constants';

@Injectable({
    providedIn: 'root'
})
export class CommonService {

    constructor(private http: HttpClient) { }

    //CR1206
    getAllResourcesList(searchDto: any, type: string): Observable<any> {
        return this.http.get<any>(cnst.apexPublicBaseUrlsResources + '/' + type, { params: searchDto });
    }
    /*

       getAllResourcesList(searchDto: any, type: string): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/category/get-all-categorys/' + type, { params: searchDto });
    }
    */

    getResourcesDetails(category: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/category/view/' + category);
    }

    getTypesByCategoryCode(categoryCode: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/types/' + categoryCode);
    }
    getStatusesByCategoryCode(categoryCode: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/statuses/' + categoryCode);
    }
    getAddressTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/address-types');
    }
    getCountries(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/countries');
    }
    getMaritalStatus(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/marital-statuses');
    }
    getNationalities(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/nationalities');
    }
    getPaymentTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/payment-types');
    }
    getPaymentRequestTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/payment-request-types');
    }
    getPremiseTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/premise-types');
    }
    getRaces(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/races');
    }
    getResidentialStatus(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/residential-statuses');
    }
    getEstablishmentStatus(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/establishment-statuses');
    }
    getSexes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/sexes');
    }
    getPrincipleActivities(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/principle-activities');
    }
    getFormOfBusiness(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/form-of-business');
    }
    getBusinessConstitution(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/business-constitution');
    }
    getQualifications(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/qualifications');
    }
    getOccupations(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/occupations');
    }
    getStakeholderRoles(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/stakeholder-roles');
    }
    getTaApplicationTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-application-types');
    }
    getTaApprovalTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-approval-types');
    }
    getTaFocusAreas(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-focus-areas');
    }

    getTaSegmentations(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-segmentations');
    }
    getTaFunctionActivitiesServices(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-function-activities');
    }
    getTaServices(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-services');
    }
    getTaLicenceTiers(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/ta-licence-tiers');
    }
    getTaAuditorOpinions(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/ta-auditor-opinions');
    }
    getTaCessationReasons(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-reasons-for-cessation');
    }
    getTaReplacementReasons(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-reasons-for-replacement');
    }
    getTgApplicationTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-application-types');
    }
    getTgSpecialisedAreas(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-specialised-areas');
    }
    getTgCourseTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-course-types');
    }
    getTgCourseCategoryTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-course-category-types');
    }
    getTgDocumentTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-document-types');
    }
    getTgGuidingLanguages(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-guiding-languages');
    }
    getTgDeclaredOffenceTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-declared-offence-types');
    }
    getTgLicenceTiers(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-licence-tiers');
    }
    getPaymentRequestStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/payment-request-statuses');
    }
    getPaymentTransactionStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/payment-txn-statuses');
    }
    getTaApplicationStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-application-statuses');
    }
    getTaLicenceStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-licence-statuses');
    }
    getTgApplicationStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-application-statuses');
    }
    getTgLicenceStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-licence-statuses');
    }
    getTgCourseStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-course-statuses');
    }
    getTps() {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/training-providers');
    }
    getTpsForPDC() {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/training-providers-pdc');
    }
    getUserStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/user-statuses');
    }
    populateFormDropdowns(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/form-dropdowns');
    }
    getPostalCodeAddress(postalCode: number): Observable<any> {
        let postalCodeString: string = (String(0).repeat(6) + postalCode).substr((6 * -1), 6);
        return this.http.get<any>('https://developers.onemap.sg/commonapi/search?searchVal=' + postalCodeString + '&returnGeom=N&getAddrDetails=Y&pageNum=1');
    }
    getTgTourType(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/tg-tour-type');
    }
    getTgEmpSrcType(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/tg-emp-src-type');
    }
    getCourseAttendanceTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/course-attendance-types');
    }

    getBulletins(type: string, isPrivate: boolean): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/bulletin/list/' + type + '/' + isPrivate);
    }

    getBulletinsAll(type: string): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/bulletin/list/' + type);
    }

    getBulletinDetails(bulletinId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/bulletin/view/' + bulletinId);
    }
    getSystemParameter(code) {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.commonApiUrl.COMMON_APPLICATION + '/system-parameter/' + code);
    }

    getFormList(key: string): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/formList/' + key);
    }
    checkPaymentIsWaived(paymentRequestType: string): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/check-payment-waive/' + paymentRequestType);
    }

    getTgCourseSubsidies(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/tg-course-subsidies');
    }

    getTaSalesChannels(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/common/ta-sales-channels');
    }
}
