import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../constants';

@Injectable({
    providedIn: 'root'
})
export class EdhService {

    constructor(private http: HttpClient) { }

    public getEdhEntity(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + "/edh/entity");
    }

    public getEdhEntityAppointments(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + "/edh/entity-appointments");
    }

    public getEdhEntityShareholders(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + "/edh/entity-shareholders");
    }

    public getEdhEntityFinancials(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + "/edh/entity-financials");
    }

}

