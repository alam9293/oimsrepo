import { StringifyOptions } from "querystring";

export interface ListableDto {
    key: string;
    label: string;
    data?: string;

}

export interface PersonnelOverviewDto {
    id: number,
    name: string,
    nric: string,
    appt: string,
    sharesHold: number,
    keyExec: string,

}

export class LicenseeDetails {
    id: number;
    licenceStatus: string;
    applicationStatus: string;
    licenceExpiry: string;
    submissionDate: string;
    applicationRef: string;
    licenceCompanyName: string;
}

export class LicenseeFye {
    id: number;
    currentFyeDate: string;
    newFyeDate: string;
    reason: string;
    acraBizFileName: string;
    directorsResolutionFileName: string;
}

export class PersonnelIndividualDetail {

    constructor(
        public id?: number,
        public name?: string,
        public nric?: string,
        public dob?: string,
        public gender?: string,
        public joinDate?: string,
        public roles?: string[],
        public keContact?: string,
        public keEmail?: string,
        public keHighestQualification?: string,
        public nationality?: string,
        public designation?: string,
        public otherDesignation?: string,
        public apptDate?: string,
        public sharesHold?: number,
        public sharesHoldEffectiveDate?: string,
        public block?: string,
        public streetName?: string,
        public buildingName?: string,
        public level?: string,
        public unit?: string,
        public postalCode?: string,
        public entity?: string,
        public companyName?: string,
        public uen?: string,
        public previousUen?: string,
        public formOfBusiness?: string,
        public principleActivity?: string,
        public placeIncorporated?: string,
        public statusOfEstablishment?: string,
        public paidUpCapital?: string,
        public fye?: string,
        public website?: string,
        public businessEmail?: string,
        public keyExec?: string,
        public keDeclarations?: ListableDto[],
        public keAdditionalInfo?: ListableDto[],
    ) { }
}

export class KeApplicationDetails {
    id: number;
    status: string;
    name: string;
    nric: string;
    dob: string;
    gender: string;
    nationality: string;
    designation: string;
    otherDesignation: string;
    officeNo: string;
    residentialNo: string;
    mobileNo: string;
    faxNo: string;
    applicantEmail: string;

    licenceTier: string;
    companyName: string;
    uen: string;
    formOfBusiness: string;
    taSegmentation: string;
    principleActivity: string;
    placeIncorporated: string;
    statusOfEstablishment: string;
    paidUpCapital: string;
    fye: string;
    website: string;
    businessEmail: string;

    registeredAddressPostalCode: string;
    registeredAddressBlk: string;
    registeredAddressStreet: string;
    registeredAddressBuilding: string;
    registeredAddressLevel: string;
    registeredAddressUnit: string;
    registeredAddressPremises: string;


    operatingAddressPostalCode: string;
    operatingAddressBlk: string;
    operatingAddressStreet: string;
    operatingAddressBuilding: string;
    operatingAddressLevel: string;
    operatingAddressUnit: string;
    operatingAddressPremises: string;

    ke?: PersonnelIndividualDetail;
    keDeclaration: declarationDto[];
    businessEntityDetails?: BusinessEntityDetails;
    personnel?: PersonnelOverviewDto[];

}

export interface declarationDto {
    statement: string; remarks: string; index: number;
}

export interface BusinessEntityDetails {
    licenceTier: string;
    applicationMode: string;
    companyName: string;
    uen: string;
    previousUen: string;
    formOfBusiness: string;
    taSegmentation: string;
    principleActivity: string;
    placeIncorporated: string;
    statusOfEstablishment: string;
    paidUpCapital: string;
    fye: string;
    website: string;
    businessEmail: string;
    registeredAddressType: string;
    registeredAddressPostalCode: string;
    registeredAddressBlk: string;
    registeredAddressStreet: string;
    registeredAddressBuilding: string;
    registeredAddressLevel: string;
    registeredAddressUnit: string;
    registeredAddressLine1: string;
    registeredAddressLine2: string;
    registeredAddressLine3: string;
    registeredAddressPremises: string;


    operatingAddressPostalCode: string;
    operatingAddressBlk: string;
    operatingAddressStreet: string;
    operatingAddressBuilding: string;
    operatingAddressLevel: string;
    operatingAddressUnit: string;
    operatingAddressPremises: string;
}