import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class DataService {

    constructor() { }

    getAuditorOpinions() {
        return {
            "data": [{ key: 'disclaimer', label: 'Disclaimer' },
            { key: 'adverse', label: 'Adverse' },
            { key: 'emphasisOfMatter', label: 'Emphasis of Matter' },]
        }
    }

    getKeApplicationDetails() {
        return {
            "data": {
                id: 1,
                status: 'Processing',
                name: 'John Tan',
                nric: 'S111111A',
                dob: '01-Jan-1980',
                gender: 'Male',
                nationality: 'SGP',
                designation: 'director',
                otherDesignation: '-',
                officeNo: '6666 6666',
                residentialNo: '-',
                mobileNo: '-',
                faxNo: '-',
                applicantEmail: 'elmo@wizvision.com',

                licenceTier: 'General',
                companyName: 'Charlie and the Chocolate Factory',
                uen: '546454646',
                formOfBusiness: 'Private Limited',
                taSegmentation: '-',
                principleActivity: '-',
                placeIncorporated: '-',
                statusOfEstablishment: '-',
                paidUpCapital: '500, 000',
                fye: '31-Mar',
                website: 'elmo.com',
                businessEmail: 'elmo@wizvision.com',

                registeredAddressPostalCode: '000000',
                registeredAddressBlk: '10',
                registeredAddressStreet: 'Sesame Street',
                registeredAddressBuilding: '-',
                registeredAddressLevel: '-',
                registeredAddressUnit: '-',
                registeredAddressPremises: 'Office Building',


                operatingAddressPostalCode: '000000',
                operatingAddressBlk: '10',
                operatingAddressStreet: 'Sesame Street',
                operatingAddressBuilding: '-',
                operatingAddressLevel: '-',
                operatingAddressUnit: '-',
                operatingAddressPremises: 'Office Building',

                keDeclaration: [
                    { index: 1, statement: 'I am not an undischarged bankrupt or financially insolvent.', remarks: null },
                    { index: 2, statement: 'I have committed any offence involving dishonesty or moral turpitude within a period of 5 years preceding the date of this declaration.', remarks: 'Some remarks and examples about the offence...' },
                    { index: 3, statement: 'I have not committed any offence under the Travel Agents Act (Cap.334) or regulations thereunder ,or contravened any condition of a TA licence, within a period of 5 years preceding the date of this declaration.', remarks: null },
                    { index: 4, statement: 'I have not held a directorship or other managerial or executive position in any travel agency that has contravened any of the provisions of the Travel Agents Act (Cap.334) or regulations thereunder, or contravened any condition of a TA licence, within a period of 5 years preceding the date of this declaration.', remarks: null },
                    { index: 5, statement: 'I have not held a directorship or other managerial or executive position in any travel agency licensed under the Travel Agents Act where the licence has been suspended or revoked by the Singapore Tourism Board within a period of 5 years preceding the date of this declaration.', remarks: null },
                    { index: 6, statement: 'I have not been found unsuitable by STB for employment under a travel agency within a period of 5 years preceding the date of this declaration.', remarks: null },
                    { index: 7, statement: 'I am not a Key Executive in any other travel agency licensed under the Travel Agents Act at this time.', remarks: null },
                    { index: 8, statement: 'Do any of the directors in the business or you have immediate family who is holding or have previously held the Key Executive or directorship position in another travel agency in the last 5 years? No', remarks: null },
                    { index: 9, statement: 'Do any of the directors in the business or you have immediate family who held a directorship position in a business entity that has been refused a travel agent licence in the last 5 years? No', remarks: null },
                    { index: 10, statement: 'Do any of the directors in the business or you have immediate family who held the Key Executive or directorship in another travel agency which has been revoked or suspended in the last 5 years? No', remarks: null },],

            }
        }
    }

    getLicenseeDetails() {
        return {
            "data": {
                id: 1,
                licenceStatus: 'Active',
                applicationStatus: 'Processing',
                licenceExpiry: '31-Feb-2019',
                submissionDate: '15-Nov-2018',
                applicationRef: '556899465',
                licenceCompanyName: ' Chan Brothers Travel Pte Ltd',
            }
        }
    }

    getLicenseeFyeDetails() {
        return {
            "data": {
                id: 1,
                currentFyeDate: '31-Dec',
                newFyeDate: '',
                reason: '',
                acraBizFileName: '',
                directorsResolutionFileName: '',
            }
        }
    }


    getLicenseeList() {
        return {
            "data": [{ id: 1, name: 'Condimentum Donec Corp.', uen: '53082647W', licenceNo: '1000890', applicationId: '20181001-37', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
            { id: 1, name: 'Ac Nulla Limited', uen: '52899290B', licenceNo: '1000891', applicationId: '20181001-38', submissionDate: '20-Oct-2018', status: 'Returned for Action', assignedOfficer: 'John Tan' },
            { id: 1, name: 'Et Risus Company', uen: '53174060M', licenceNo: '1000892', applicationId: '20181001-39', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
            { id: 1, name: 'Sapien Inc.', uen: '53326497M', licenceNo: '1000893', applicationId: '20181001-40', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
            { id: 1, name: 'A Magna Institute', uen: '53175575D', licenceNo: '1000894', applicationId: '20181001-41', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
            { id: 1, name: 'Quam Vel Incorporated', uen: '53334458A', licenceNo: '1000895', applicationId: '20181001-42', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
            { id: 1, name: 'ed Pharetra Felis Inc.', uen: '53312249W', licenceNo: '1000896', applicationId: '20181001-43', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
            ]
        }
    }

    getLicenseePersonnelDetails(id: number) {
        if (id = 1) {
            return {
                "data":
                {
                    id: 1,
                    name: 'John Tan',
                    nric: 'S1234567A',
                    dob: "01-Jan-1980",
                    gender: 'M',
                    joinDate: '01-Jan-2015',
                    roles: ['director', 'shareholder'],
                    keContact: '12345678',
                    keEmail: 'john@gmail.com',
                    keHighestQualification: 'Master',
                    nationality: 'ABW',
                    designation: 'Director',
                    otherDesignation: 'Key Executive',
                    apptDate: '01-Jan-2015',
                    sharesHold: 1000,
                    sharesHoldEffectiveDate: '01-Jan-2015',
                    block: '123A',
                    streetName: 'Highlands',
                    buildingName: 'ABC Building',
                    level: '32',
                    unit: '32-001',
                    postalCode: '12345',
                    entity: 'individual',
                    keyExec: 'Yes',

                }
            }
        } else if (id > 1) {
            return {
                "data":
                {
                    id: 2,
                    name: 'Sam Ong',
                    nric: 'S1234567A',
                    dob: '01-Jan-1989',
                    gender: 'M',
                    joinDate: '01-Jan-2015',
                    roles: ['partner', ''],
                    keContact: '12345678',
                    keEmail: 'john@gmail.com',
                    keHighestQualification: 'Master',
                    nationality: 'ABW',
                    designation: 'Partner',
                    otherDesignation: 'Shareholder',
                    apptDate: '01-Jan-2015',
                    sharesHold: 1000,
                    sharesHoldEffectiveDate: '01-Jan-2015',
                    block: '123A',
                    streetName: 'Highlands',
                    buildingName: 'ABC Building',
                    level: '32',
                    unit: '32-001',
                    postalCode: '12345',
                    entity: 'individual',
                    keyExec: 'No'

                }
            }
        } else {
            return {
                "data":
                {
                    id: 5,
                    name: '',
                    nric: '',
                    dob: '',
                    gender: '',
                    joinDate: '',
                    roles: [],
                    keContact: '',
                    keEmail: '',
                    keHighestQualification: '',
                    nationality: '',
                    designation: '',
                    otherDesignation: '',
                    apptDate: '',
                    sharesHold: null,
                    sharesHoldEffectiveDate: '',
                    block: '',
                    streetName: '',
                    buildingName: '',
                    level: '',
                    unit: '',
                    postalCode: '',
                    entity: 'individual',
                    keyExec: null

                }
            }
        }

    }

    getEntityList() {
        return {
            "data": [{ key: 'individual', label: 'Individual' },
            { key: 'company', label: 'Company' },]

        }
    }

    getCompanyRoleList() {
        return {
            "data": [
                { key: 'director', label: 'Director' },
                { key: 'shareholder', label: 'Shareholder' },
                { key: 'partner', label: 'Partner' },
                { key: 'manager', label: 'Manager' }]
        }
    }

    getGenderList() {
        return {
            "data": [{ key: 'M', label: 'Male', data: null },
            { key: 'F', label: 'Female', data: null },]
        }
    }

    getSubmissionStatusList() {
        return {
            "data": [{ key: 'yes', label: 'Yes', data: null },
            { key: 'no', label: 'No', data: null },
            { key: 'processing', label: 'Processing', data: null },]
        }
    }

    getNationalityList() {
        return {
            "data": [
                { key: 'ABW', label: 'Dutch (Aurba)', data: null },
                { key: 'AFG', label: 'Afghan', data: null },
                { key: 'AGO', label: 'Angolan', data: null },
                { key: 'ALB', label: 'Albanian', data: null },
                { key: 'AND', label: 'Andorran', data: null },
                { key: 'ARE', label: 'Emirati', data: null },
                { key: 'ARG', label: 'Argentinean', data: null },
                { key: 'ARM', label: 'Armenian', data: null },
                { key: 'ATG', label: 'Antiguan and Barbudan', data: null },
                { key: 'AUS', label: 'Australian', data: null },
                { key: 'AUT', label: 'Austrian', data: null },
                { key: 'AZE', label: 'Azerbaijanian', data: null },
                { key: 'BDI', label: 'Umurundi', data: null },
                { key: 'BDS', label: 'Barbadian', data: null },
                { key: 'BEL', label: 'Belgian', data: null },
                { key: 'BEN', label: 'Beninese', data: null },
                { key: 'BFA', label: 'Burkina Fasan', data: null },
                { key: 'BGD', label: 'Bangladeshi', data: null },
                { key: 'BGR', label: 'Bulgarian', data: null },
                { key: 'BHR', label: 'Bahraini', data: null },
                { key: 'BHS', label: 'Bahamian', data: null },
                { key: 'BIH', label: 'Bosnian and Herzegovinian', data: null },
                { key: 'BLR', label: 'Belarusian', data: null },
                { key: 'BLZ', label: 'Belizean', data: null },
                { key: 'BOL', label: 'Bolivian', data: null },
                { key: 'BRA', label: 'Brazilian', data: null },
                { key: 'BRU', label: 'Bruneian', data: null },
                { key: 'BTN', label: 'Bhutanese', data: null },
                { key: 'BWA', label: 'Motswana', data: null },
                { key: 'CDN', label: 'Canadian', data: null },
                { key: 'CHE', label: 'Swiss', data: null },
                { key: 'CHN', label: 'Chinese', data: null },
                { key: 'CIV', label: 'Ivorian', data: null },
                { key: 'CMR', label: 'Cameroonian', data: null },
                { key: 'COD', label: 'Congolese (Democratic Republic)', data: null },
                { key: 'COK', label: 'New Zealander (Cook Islands)', data: null },
                { key: 'COL', label: 'Colombian', data: null },
                { key: 'COM', label: 'Comorian', data: null },
                { key: 'CPV', label: 'Cape Verdeans', data: null },
                { key: 'CRI', label: 'Costa Rican', data: null },
                { key: 'CUB', label: 'Cuban', data: null },
                { key: 'CUW', label: 'Dutch (Curacao)', data: null },
                { key: 'CYP', label: 'Cypriot', data: null },
                { key: 'CZE', label: 'Czech', data: null },
                { key: 'DEU', label: 'German', data: null },
                { key: 'dfd', label: 'fsdf', data: null },
                { key: 'DJI', label: 'Djiboutian', data: null },
                { key: 'DMA', label: 'Dominican', data: null },
                { key: 'DNK', label: 'Dane', data: null },
                { key: 'DOM', label: 'Dominican (Republic)', data: null },
                { key: 'DZA', label: 'Algerian', data: null },
                { key: 'ECU', label: 'Ecuadorian', data: null },
                { key: 'EGY', label: 'Egyptian', data: null },
                { key: 'ERI', label: 'Eritrean', data: null },
                { key: 'ESP', label: 'Spanish', data: null },
                { key: 'EST', label: 'Estonian', data: null },
                { key: 'ETH', label: 'Ethiopian', data: null },
                { key: 'FIN', label: 'Finnish', data: null },
                { key: 'FJI', label: 'Fijian', data: null },
                { key: 'FRA', label: 'French', data: null },
                { key: 'FSM', label: 'Micronesian', data: null },
                { key: 'GAB', label: 'Gabonese', data: null },
                { key: 'GBR', label: 'British', data: null },
                { key: 'GEO', label: 'Georgian', data: null },
                { key: 'GHA', label: 'Ghanaian', data: null },
                { key: 'GIN', label: 'Guinean', data: null },
                { key: 'GMB', label: 'Gambian', data: null },
                { key: 'GNB', label: 'Bissau-Guinean', data: null },
                { key: 'GNQ', label: 'Equatorial Guinean', data: null },
                { key: 'GRC', label: 'Greek', data: null },
                { key: 'GRD', label: 'Grenadian', data: null },
                { key: 'GTM', label: 'Guatemalan', data: null },
                { key: 'GUY', label: 'Guyanese', data: null },
                { key: 'HKG', label: 'Hong Konger', data: null },
                { key: 'HND', label: 'Honduran', data: null },
                { key: 'HRV', label: 'Croatian', data: null },
                { key: 'HTI', label: 'Haitian', data: null },
                { key: 'HUN', label: 'Hungarian', data: null },
                { key: 'IDN', label: 'Indonesian', data: null },
                { key: 'IND', label: 'Indian', data: null },
                { key: 'IRL', label: 'Irish', data: null },
                { key: 'IRN', label: 'Iranian', data: null },
                { key: 'IRQ', label: 'Iraqi', data: null },
                { key: 'ISL', label: 'Icelander', data: null },
                { key: 'ISR', label: 'Israeli', data: null },
                { key: 'ITA', label: 'Italian', data: null },
                { key: 'JAM', label: 'Jamaican', data: null },
                { key: 'JOR', label: 'Jordanian', data: null },
                { key: 'JPN', label: 'Japanese', data: null },
                { key: 'KAZ', label: 'Kazakhstani', data: null },
                { key: 'KEN', label: 'Kenyan', data: null },
                { key: 'KGP', label: 'Kheeporean', data: null },
                { key: 'KGZ', label: 'Kyrgyzs', data: null },
                { key: 'KHM', label: 'Cambodian', data: null },
                { key: 'KIR', label: 'i-Kiribati', data: null },
                { key: 'KNA', label: 'Kittitia and Nevisian', data: null },
                { key: 'KOR', label: 'South Korean', data: null },
                { key: 'KWT', label: 'Kuwaiti', data: null },
                { key: 'LAO', label: 'Laotian', data: null },
                { key: 'LBN', label: 'Lebanese', data: null },
                { key: 'LBR', label: 'Liberian', data: null },
                { key: 'LBY', label: 'Libyan', data: null },
                { key: 'LCA', label: 'Saint Lucian', data: null },
                { key: 'LIE', label: 'Liechtensteiner', data: null },
                { key: 'LKA', label: 'Sri Lankan', data: null },
                { key: 'LSO', label: 'Mosotho', data: null },
                { key: 'LTU', label: 'Lithuanian', data: null },
                { key: 'LUX', label: 'Luxembourger', data: null },
                { key: 'LVA', label: 'Latvian', data: null },
                { key: 'MAC', label: 'Macanese', data: null },
                { key: 'MAR', label: 'Moroccan', data: null },
                { key: 'MCO', label: 'Monégasque', data: null },
                { key: 'MDA', label: 'Moldovan', data: null },
                { key: 'MDG', label: 'Madagascan', data: null },
                { key: 'MDV', label: 'Maldivian', data: null },
                { key: 'MEX', label: 'Mexican', data: null },
                { key: 'MHL', label: 'Marshallese', data: null },
                { key: 'MKD', label: 'Macedonian', data: null },
                { key: 'MLI', label: 'Malian', data: null },
                { key: 'MLT', label: 'Maltese', data: null },
                { key: 'MMR', label: 'Burmese', data: null },
                { key: 'MNE', label: 'Montenegrin', data: null },
                { key: 'MNG', label: 'Mongolian', data: null },
                { key: 'MOZ', label: 'Mozambican', data: null },
                { key: 'MRT', label: 'Mauritanian', data: null },
                { key: 'MSR', label: 'Montserratians', data: null },
                { key: 'MUS', label: 'Mauritian', data: null },
                { key: 'MWI', label: 'Malawian', data: null },
                { key: 'MYS', label: 'Malaysian', data: null },
                { key: 'NAM', label: 'Namibian', data: null },
                { key: 'NER', label: 'Nigerien', data: null },
                { key: 'NGA', label: 'Nigerian', data: null },
                { key: 'NIC', label: 'Nicaraguan', data: null },
                { key: 'NIU', label: 'New Zealander (Niue)', data: null },
                { key: 'NLD', label: 'Dutch (Netherlands)', data: null },
                { key: 'NOR', label: 'Norwayian', data: null },
                { key: 'NPL', label: 'Nepalese', data: null },
                { key: 'NRU', label: 'Nauruan', data: null },
                { key: 'NZL', label: 'New Zealander', data: null },
                { key: 'OMN', label: 'Omani', data: null },
                { key: 'OPT', label: 'Palestinian', data: null },
                { key: 'PAK', label: 'Pakistani', data: null },
                { key: 'PAN', label: 'Panamanian', data: null },
                { key: 'PER', label: 'Peruvian', data: null },
                { key: 'PHL', label: 'Filipino', data: null },
                { key: 'PLW', label: 'Palauan', data: null },
                { key: 'PNG', label: 'Papua New Guinean', data: null },
                { key: 'POL', label: 'Polish', data: null },
                { key: 'PRI', label: 'American (Puerto Rico)', data: null },
                { key: 'PRK', label: 'North Korean', data: null },
                { key: 'PRT', label: 'Portuguese', data: null },
                { key: 'PRY', label: 'Paraguayan', data: null },
                { key: 'QAT', label: 'Qatari', data: null },
                { key: 'RCA', label: 'Central African', data: null },
                { key: 'RCB', label: 'Congolese (Republic)', data: null },
                { key: 'RCH', label: 'Chilean', data: null },
                { key: 'ROU', label: 'Romanian', data: null },
                { key: 'RUS', label: 'Russian', data: null },
                { key: 'RWA', label: 'Rwandan', data: null },
                { key: 'SAU', label: 'Saudi Arabian', data: null },
                { key: 'SDN', label: 'Sudanese', data: null },
                { key: 'SEN', label: 'Senegalese', data: null },
                { key: 'SGP', label: 'Singaporean', data: null },
                { key: 'SLB', label: 'Solomon Islander', data: null },
                { key: 'SLE', label: 'Sierra Leonean', data: null },
                { key: 'SLV', label: 'Salvadoran', data: null },
                { key: 'SMR', label: 'Sammarinese', data: null },
                { key: 'SOM', label: 'Somali', data: null },
                { key: 'SRB', label: 'Serbian', data: null },
                { key: 'SSD', label: 'Sudanese (South)', data: null },
                { key: 'SSY', label: 'Yvonne', data: null },
                { key: 'STP', label: 'Sao Tomean', data: null },
                { key: 'SUR', label: 'Surinamese', data: null },
                { key: 'SVK', label: 'Slovakian', data: null },
                { key: 'SVN', label: 'Slovenian', data: null },
                { key: 'SWE', label: 'Swedish', data: null },
                { key: 'SWZ', label: 'Swazis', data: null },
                { key: 'SXM', label: 'Dutch (Sint Maarten)', data: null },
                { key: 'SYC', label: 'Seychellois', data: null },
                { key: 'SYR', label: 'Syrian', data: null },
                { key: 'TCD', label: 'Chadian', data: null },
                { key: 'TGO', label: 'Togolese', data: null },
                { key: 'THA', label: 'Thai', data: null },
                { key: 'TJK', label: 'Tajikistani', data: null },
                { key: 'TKM', label: 'Turkmenistani', data: null },
                { key: 'TLS', label: 'Timorese', data: null },
                { key: 'TON', label: 'Tongan', data: null },
                { key: 'TTO', label: 'Trinidadian and Tobagonian', data: null },
                { key: 'TUN', label: 'Tunisian', data: null },
                { key: 'TUR', label: 'Turkish', data: null },
                { key: 'TUV', label: 'Tuvaluan', data: null },
                { key: 'TWN', label: 'Taiwanese', data: null },
                { key: 'TZA', label: 'Tanzanian', data: null },
                { key: 'UGA', label: 'Ugandan', data: null },
                { key: 'UKR', label: 'Ukrainian', data: null },
                { key: 'UMI', label: 'American Islander', data: null },
                { key: 'URY', label: 'Uruguayan', data: null },
                { key: 'USA', label: 'American', data: null },
                { key: 'UZB', label: 'Uzbekistani', data: null },
                { key: 'VAT', label: 'Holy See', data: null },
                { key: 'VCT', label: 'Vincentian', data: null },
                { key: 'VEN', label: 'Venezuelan', data: null },
                { key: 'VER', label: 'Verlin', data: null },
                { key: 'VNM', label: 'Vietnamese', data: null },
                { key: 'VUT', label: 'Ni-Vanuatu', data: null },
                { key: 'WSM', label: 'Samoan', data: null },
                { key: 'XKX', label: 'Kosovars', data: null },
                { key: 'YEM', label: 'Yemeni', data: null },
                { key: 'ZAF', label: 'South African', data: null },
                { key: 'ZMB', label: 'Zambian', data: null },
                { key: 'ZWE', label: 'Zimbabwean', data: null },

            ]
        }
    }

    getAaSubmissionList() {
        return {
            "total": 12,
            "total_pages": 1,
            "data": [

                {
                    "id": 1,
                    "refYear": 2018,
                    "submissionStatus": 'Processing',
                    "fileName": '2018 Audited Accounts',
                    "supportingFileName": '2018 ACRA Bizfile',
                    "submittedDate": '10-Nov-2018',
                },
                {
                    "id": 2,
                    "refYear": 2017,
                    "submissionStatus": 'Yes',
                    "fileName": '2017 Audited Accounts',
                    "supportingFileName": '2017 ACRA Bizfile',
                    "submittedDate": '01-Dec-2017',
                },
                {
                    "id": 3,
                    "refYear": 2016,
                    "submissionStatus": 'No',
                    "fileName": '',
                    "supportingFileName": '',
                    "submittedDate": '',
                }
            ]
        };
    }

    getLicenseePersonnelList() {
        return {
            "total": 12,
            "total_pages": 1,
            "data": [

                {
                    "id": 1,
                    "name": 'John Tan',
                    "nric": 'S1234567A',
                    "appt": 'Director',
                    "sharesHold": 1000,
                    "keyExec": 'Yes',
                },
                {
                    "id": 2,
                    "name": 'Sam Ong',
                    "nric": 'S1234567B',
                    "appt": 'Partner',
                    "sharesHold": 1000,
                    "keyExec": 'No',
                },
                {
                    "id": 3,
                    "name": 'Janet Low',
                    "nric": 'S1234564T',
                    "appt": 'Shareholder',
                    "sharesHold": 1000,
                    "keyExec": 'No',
                }
            ]
        };
    }
    getApplicationBranchLicenceList() {
        return {
            "total": 12,
            "total_pages": 1,
            "data": [
                {
                    "id": 123,
                    "name": 'John Tan',
                    "nric": 'S1234567A',
                    "appt": 'Director',
                    "sharesHold": 1000,
                    "keyExec": 'Yes',
                    "address": '123 Simei Street 1',
                    "contactNumber": '12345678',
                    "status": 'Active',
                    "email": 'abc@gmail.com',
                    "documents": 'Simei_branch.pdf',
                },
                {
                    "id": 234,
                    "name": 'Sam Ong',
                    "nric": 'S1234567B',
                    "appt": 'Tour Master',
                    "sharesHold": 1000,
                    "keyExec": 'No',
                    "address": '321 Simei Street 21',
                    "contactNumber": '12345678',
                    "status": 'Active',
                    "email": 'sam@gmail.com',
                    "documents": 'Simei_branch_2.pdf',
                },/*
                {
                    "id": 345,
                    "name": 'Janet Low',
                    "nric": 'S1234564T',
                    "appt": 'A. Manager',
                    "sharesHold": 1000,
                    "keyExec": 'No',
                    "address": '345 Enuos Avenue 5',
                    "contactNumber": '12345678',
                    "status": 'Active',
                    "email": 'low@gmail.com',
                    "documents": 'agreement.pdf',
                },*/
                {
                    "id": 456,
                    "name": 'Zhang San, 张三',
                    "nric": 'S1234564T',
                    "appt": 'Manager',
                    "sharesHold": 1000,
                    "keyExec": 'No',
                    "address": '345 Clementi Avenue 5',
                    "contactNumber": '12345678',
                    "status": 'Ceased',
                    "email": 'zhangsan@gmail.com',
                    "documents": '',
                }
            ]
        };
    }
    getApplicationBranchTransactionList() {
        return {
            "total": 12,
            "total_pages": 1,
            "data": [
                {
                    "id": 1,
                    "name": 'John Tan',
                    "nric": 'S1234567A',
                    "appt": 'Director',
                    "sharesHold": 1000,
                    "keyExec": 'Yes',
                    "address": '123 Tampines Street 1',
                    "contactNumber": '12345678',
                    "status": 'N.A',
                    "fee": '40',
                    "email": 'abc@gmail.com',
                    "documents": 'Tampines_branch.pdf',
                    "transaction": 'New',

                },
                {
                    "id": 2,
                    "name": 'Sam Ong',
                    "nric": 'S1234567B',
                    "appt": 'Tour Master',
                    "sharesHold": 1000,
                    "keyExec": 'No',
                    "address": '321 Tampines Street 21',
                    "contactNumber": '12345678',
                    "status": 'N.A',
                    "fee": '',
                    "email": 'sam@gmail.com',
                    "documents": 'Tampines_branch_2.pdf',
                    "transaction": 'New',
                },
                {
                    "id": 4,
                    "name": 'Zhang San, 张三',
                    "nric": 'S1234564T',
                    "appt": 'Manager',
                    "sharesHold": 1000,
                    "keyExec": 'No',
                    "address": '345 Enuos Avenue 5',
                    "contactNumber": '12345678',
                    "fee": '',
                    "status": 'Active',
                    "email": 'zhangsan@gmail.com',
                    "documents": '',
                    "transaction": 'Cessation',
                }
            ]
        };
    }
    getPendingApprovalBranchLicenceList() {
        return {
            "data": [
                {
                    "id": '-',
                    "address": '123 Tampines Street 1',
                    "status": 'Pending Approval',
                    "documents": 'Tampines_branch.pdf',
                    "transaction": 'New',
                    "fee": '$40',
                    "old": null
                },
                {
                    "id": '-',
                    "address": '321 Tampines Street 21',
                    "status": 'Pending Approval',
                    "documents": 'Tampines_branch_2.pdf',
                    "transaction": 'New',
                    "fee": '$40',
                    "old": null
                },
                {
                    "id": '53082647',
                    "address": '345 Enuos Avenue 5',
                    "status": 'Pending Cessation',
                    "documents": '',
                    "transaction": 'Cessation',
                    "old": null,
                    "fee": null
                },
                {
                    "id": '-',
                    "address": '321 Sesame Street 21',
                    "status": 'Pending Approval',
                    "documents": 'Sesame.pdf',
                    "transaction": 'Update',
                    "fee": null,
                    "old": '56 Holland St'
                }
            ]
        };
    }
}
