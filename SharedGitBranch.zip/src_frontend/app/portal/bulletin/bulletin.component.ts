import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import * as cnst from 'src/app/common/constants';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { FileUtil, FormUtil } from '../../common/helper';
import { CommonService } from '../../common/services'
import { DomSanitizer } from '@angular/platform-browser';
import { before } from 'lodash';

declare function change(): void;
@Component({
    selector: 'app-bulletin',
    templateUrl: './bulletin.component.html',
    styleUrls: ['./bulletin.component.scss']
})
export class BulletinComponent implements OnInit {
    cnst = cnst;
    @Input() dashboardTypeCode: string;

    categoryMap = new Map();
    //categoryMapDisplay = new Map();
    //category: String[] = [];
    filter: any = {};
    resourcesTypeCode: string;

    successLink: String;
    isTg: Boolean = false;
    hasData: Boolean = false;
    @Input() showCategoryList = false;
    categoryListByCategoryId = -1;
    categoryListName = "";
    ignoreCatListingId = false;
    selectedPage = 0;
    sizePerPage = 6;

    lowerLimit = 0;
    upperLimit = 5;
    noOfPaginationTabs = 5;

    counterNoOfItems = 0;
    showNext = false;
    showPrevious = false;
    //counterCategory = 0;

    @Input() categoryListData: any = {};

    noOfPages = [];

    type = "BULLETIN_GENERAL";


    constructor(private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private fileUtil: FileUtil,
        private commonService: CommonService,
        public formUtil: FormUtil,
        private sanitizer: DomSanitizer
    ) {
    }

    filterBy(filterBy) {
        if (filterBy == this.type) {

        } else if (filterBy == "BULLETIN_GENERAL") {
            this.type = "BULLETIN_GENERAL";
        } else if (filterBy == "BULLETIN_TA") {
            this.type = "BULLETIN_TA";
        } else if (filterBy == "BULLETIN_TG") {
            this.type = "BULLETIN_TG";
        }
        this.ngOnInit();
    }

    previous() {

        this.showPrevious = false;
        this.showNext = false;
        this.lowerLimit = this.lowerLimit - this.noOfPaginationTabs;
        this.upperLimit = this.upperLimit - this.noOfPaginationTabs;

        this.selectedPage = Number(this.upperLimit);

        if (this.lowerLimit > 0 && this.lowerLimit != 0) {
            this.showPrevious = true;
        }
        if (this.noOfPages.length > this.upperLimit) {
            this.showNext = true;
        }
    }
    next() {
        this.selectedPage = Number(this.upperLimit + 1);
        this.showPrevious = false;
        this.showNext = false;
        this.lowerLimit = this.lowerLimit + this.noOfPaginationTabs;
        this.upperLimit = this.upperLimit + this.noOfPaginationTabs;
        if (this.lowerLimit > 0 && this.lowerLimit != 0) {
            this.showPrevious = true;
        }
        if (this.noOfPages.length > this.upperLimit) {
            this.showNext = true;
        }
    }
    clearFormArray = (formArray: FormArray) => {
        while (formArray.length !== 0) {
            formArray.removeAt(0)
        }
    }
    back() {
        this.clearFormArray(this.categoryList);
        this.categoryListByCategoryId = -1;
        this.categoryListName = "";
        this.ignoreCatListingId = true;
        this.ngOnInit();
    }
    selectPage(pages) {
        this.selectedPage = Number(pages);
    }

    download(fileForm) {
        //console.log('downloading');
        var fileId = fileForm.get('fileId').value,
            fileName = fileForm.get('originalFilename').value,
            fileHash = fileForm.get('hash').value;

        this.fileUtil.downloadFromAdmin(fileId, fileHash).subscribe(data => {
            this.fileUtil.exportToNewTab(data, fileName);
        });
    }


    categoryListForm = this.formBuilder.group({
        categoryList: this.formBuilder.array([])
    });

    //CategoryList
    get categoryList(): FormArray {
        return this.categoryListForm.get('categoryList') as FormArray;
    }
    buildCategoryList(categoryListData, inPage, isBulletin) {
        if (isBulletin == false) {
            var form = this.formBuilder.group({
                id: [categoryListData.id],
                categoryId: [categoryListData.categoryId],
                fileId: [categoryListData.fileId],
                ordinal: [categoryListData.ordinal],
                originalFilename: [categoryListData.originalFilename],
                hash: [categoryListData.hash],
                title: [categoryListData.title],
                effectiveDate: [categoryListData.effectiveDate],
                expiryDate: [categoryListData.expiryDate],
                inPage: [inPage],

                fileIconId: [categoryListData.fileIconId],
                originalIconFilename: [categoryListData.originalIconFilename],
                hashIcon: [categoryListData.hashIcon],
            }); this.categoryList.push(form);
        }
        else if (isBulletin == true) {
            var form = this.formBuilder.group({
                id: ['bulletin'],
                categoryId: ['bulletin'],
                fileId: [''],
                ordinal: [''],
                originalFilename: ['bulletin'],
                hash: ['assets/css/bulletinIcon.jpg'],
                title: ['Bulletin Board'],
                effectiveDate: [''],
                expiryDate: [''],
                inPage: [''],
            });
            this.categoryList.push(form);
        }
    }

    getSafeUrl(url) {
        //console.log(url);
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
    getHref(bindData) {
        var id = bindData.get('id').value;
        var title = bindData.get('title').value;
        return '/public/portal/infohub/?id=' + id + '_' + title;
    }
    getHrefBulletin(bindData) {
        return cnst.WEB_PORTAL_BULLETIN;
    }
    ngOnInit() {
        this.counterNoOfItems = 0;
        this.hasData = false;
        this.categoryList.reset();
        this.clearFormArray(this.categoryList);
        this.showCategoryList = false;
        this.noOfPages = [];
        if (this.router.url.includes("?") && this.ignoreCatListingId == false) {
            var value = this.router.url.split("?")[1];
            value = this.router.url.split("=")[1];
            var valueId = value.split("_")[0];
            var valueTitle = value.split("_")[1];
            //console.log(value);
            this.showCategoryList = true;

            this.categoryListByCategoryId = Number(valueId);
            this.categoryListName = valueTitle.replace(/%20/g, " ");
        }

        this.dashboardTypeCode = 'AEM';
        this.categoryMap.set(String(cnst.WEB_PORTAL_BULLETIN), String(cnst.WEB_PORTAL_BULLETIN));

        //console.log('load bulletin');
        //this.categoryMap.set(String(cnst.WEB_PORTAL_BULLETIN), String(cnst.WEB_PORTAL_BULLETIN));

        this.commonService.getAllResourcesList(this.filter, this.type).subscribe(data => {

            this.showNext = true;

            var JSONObject = JSON.parse(JSON.stringify(data));
            var categoryList = JSONObject["records"];
            var size = categoryList.length;
            var counterCategory = 0;
            var catListCount = 0;

            //console.log(this.categoryList);
            if (this.showCategoryList == false) {
                this.clearFormArray(this.categoryList);
                this.buildCategoryList(null, '', true);
            }
            categoryList.forEach(bindData => {
                if (this.showCategoryList == true)
                    this.hasData = true;
                counterCategory++;
                //console.log(this.showCategoryList + ' and ' + bindData.id + ' and ' + this.categoryListByCategoryId);

                this.categoryMap.set(bindData.title, bindData.id);


                if (this.showCategoryList == true && bindData.id == this.categoryListByCategoryId) {
                    var page = 1;
                    var counter = 0;
                    var itemsToShow = 0;
                    var itemsToShowCounter = 0;
                    var duplicateText = '{"categoryList":[]}';

                    bindData["categoryList"].forEach(data => {

                        itemsToShow++;
                        console.log(itemsToShow + "----" + data.effectiveDate);
                    });



                    bindData["categoryList"].forEach(data => {

                        if (null != data.fileIconId && null != data.hashIcon) {

                            this.fileUtil.downloadFromAdmin(data.fileIconId, data.hashIcon).subscribe(async data2 => {
                                catListCount++;
                                const blob = new Blob([data2], { type: 'image/jpg' });
                                //console.log(blob);
                                let objectURL = URL.createObjectURL(blob);//blob;
                                data.hashIcon = objectURL;

                                if (catListCount == itemsToShow) {
                                    bindData["categoryList"].forEach(data => {

                                        if (null != data.fileIconId && null != data.hashIcon) {


                                            let myArray = data.type.split("_");
                                            myArray.shift();
                                            let typeReference = this.type.split("_")[1];
                                            //console.log("data type " + myArray + '  type:' + this.type);
                                            if (myArray.includes(typeReference)) {


                                                counter++;
                                                itemsToShowCounter++;
                                                this.counterNoOfItems++;
                                                this.buildCategoryList(data, page, false);

                                                this.selectedPage = 1;

                                                if (counter >= (this.sizePerPage)) {

                                                    this.noOfPages.push(page);
                                                    counter = 0;
                                                    page++;
                                                }

                                                if (itemsToShowCounter == itemsToShow)
                                                    if (counter != 0 && counter < this.sizePerPage)
                                                        this.noOfPages.push(page);
                                                    else if (counter != 0 && counter % this.sizePerPage != 0)
                                                        this.noOfPages.push(page);

                                            }

                                        }



                                    }
                                    );
                                }

                            }
                            );
                        }
                    }
                    );


                }

                if (this.showCategoryList == false) {



                    if (null != bindData.fileId && null != bindData.hash) {

                        this.fileUtil.downloadFromAdmin(bindData.fileId, bindData.hash).subscribe(data => {
                            const blob = new Blob([data], { type: 'image/jpg' });
                            //console.log(blob);
                            let objectURL = URL.createObjectURL(blob);//blob;
                            //objectURL = 'data:image/jpeg;base64,' + objectURL;
                            //bindData.hash = this.sanitizer.bypassSecurityTrustUrl(objectURL);
                            bindData.hash = objectURL;
                            catListCount++;
                            if (catListCount == size) {
                                //buildDataTable(categoryList);
                                //HERE to edit
                                categoryList.forEach(bindData => {
                                    this.buildCategoryList(bindData, '', false);
                                });
                                this.dashboardTypeCode = '';
                                this.dashboardTypeCode = 'AEM';
                            }
                        });
                    }
                }
            });


        });

    }
}
