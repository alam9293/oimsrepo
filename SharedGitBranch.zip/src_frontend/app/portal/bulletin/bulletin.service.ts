import { SelectionModel } from '@angular/cdk/collections';
import { SuccessSnackbarComponent } from '../../common/modules/success-snackbar/success-snackbar.component';
import { MatTableDataSource, MatSnackBar, MatDialog } from '@angular/material';
//import { PaymentService } from '../payment.service';
import { LoaderService } from '../../common/services/loader.service';
import { PaymentDialogComponent } from '../../common/modules/payment-dialog/payment-dialog.component';
import * as cnst from '../../common/constants';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService, AlertService, MyInfoService, EdhService } from '../../common/services';
import { FormUtil } from '../../common/helper';
import { Observable } from 'rxjs';
import { DashboardTaService } from '../dashboard/dashboard-ta/dashboard-ta.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root'
})

export class BulletinComponent implements OnInit {
    dashboardTypeCode: string;
    cnst = cnst;
    resultHasRows: string = '';
    rows = new MatTableDataSource<any>();
    selection = new SelectionModel<any>(true, []);
    displayedColumns = ['select', 'billRefNo', 'refNo', 'type', 'payableAmount'];
    formAEM = this.formBuilder.group({
        billRefNo: ['', [Validators.maxLength(20), Validators.required, Validators.pattern('([0-9]{4})-([0-9]{4})-([0-9]{4})-([0-9]{4})')]],
        payerUinUen: ['', [Validators.maxLength(10), Validators.required, Validators.pattern(/^[a-zA-Z0-9]*$/)]]
    });
    formTA = this.formBuilder.group({
        fileDoc: ['']
    }, {
    }
    );
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return (this.formAEM.pristine && this.formTA.pristine);
    }
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private dashboardService: DashboardTaService,
        private formBuilder: FormBuilder,
        //private paymentService: PaymentService,
        private loaderService: LoaderService,
        private snackBar: MatSnackBar,
        public dialog: MatDialog,
        public alertService: AlertService,
        public formUtil: FormUtil) { }

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        this.preview = false;
        if (this.dashboardTypeCode === 'TA') {
            this.checkForPendingPayment();
        }
        let paymentParams = this.route.snapshot.queryParams;
        if (paymentParams) {
            this.formAEM.patchValue(paymentParams);
            this.getPaymentRequestsForPayment();
        }
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.rows.data.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.rows.data.forEach(row => this.selection.select(row));
    }


    getPaymentRequestsForPayment() {
        console.log(this.formAEM);
        this.alertService.clear();
        if (this.formAEM.valid) {
            window.scrollTo(0, 0);
            /*this.paymentService.getPaymentRequestsForPayment(this.formAEM.value).subscribe(data => {
                if (data == null) {
                    this.alertService.error(cnst.Messages.MSG_NO_RECORDS);
                } else {
                    this.rows.data = data;
                    this.data = data;
                    this.resultHasRows = data.length > 0 ? 'Y' : 'N';
                    this.selection.clear();
                    if (data && data.length > 0) {
                        this.data.forEach(data => {
                            if (data.billRefNo == this.formAEM.get('billRefNo').value) {
                                this.selection.select(data);
                            }
                        });
                    }
                }
            });*/
        } else {
            this.formAEM.markAsTouched();
            this.formUtil.markFormGroupTouched(this.formAEM);
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }

    submitPayment() {
        /*if (this.selection.selected.length < 1) {
            this.snackBar.openFromComponent(SuccessSnackbarComponent, {
                duration: 5000,
                data: { message: cnst.Messages.MSG_NO_SELECTED_RECORDS },
                panelClass: 'error-snackbar',
            });
        } else {
            let total = 0;
            let billRefNos = [];
            this.chosenItemList.forEach(row => {
                billRefNos.push(row.billRefNo);
                total += row.payableAmount;
            });
            this.formAEM.markAsPristine();
            this.formTA.markAsPristine();
            let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: total, billRefNos: billRefNos } });
            dialog.afterClosed().subscribe(result => {
                if (result.decision) {
                    let paymentType = result.type;
                    if (paymentType == cnst.PaymentTypes.PAYNOW) {
                        this.paymentService.createPayNowTxn(total, billRefNos).subscribe(txn => {
                            let payNowTxnId = txn;
                            this.paymentService.generateQrCode(total, txn).subscribe(qrCode => {
                                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: total, billRefNos: billRefNos, payNowTxnId: payNowTxnId, qrCode: qrCode } });
                                dialog.afterClosed().subscribe(result => {
                                    if (result.decision) {
                                        if (this.dashboardTypeCode === 'TA') {
                                            this.paymentService.routeToPaymentSuccessPage(true, cnst.eNets.URL_TA_RETURN, paymentType, billRefNos, '/portal/ta-make-payment', payNowTxnId);
                                        }
                                        if (this.dashboardTypeCode === 'AEM') {
                                            this.paymentService.routeToPaymentSuccessPage(true, cnst.eNets.URL_AEM_RETURN, paymentType, billRefNos, '/portal/payment-list', payNowTxnId);
                                        }
                                    }
                                });
                            });
                        });
                    } else {
                        if (this.dashboardTypeCode === 'TA') {
                            this.paymentService.initPaymentProcess(true, cnst.eNets.URL_TA_RETURN, paymentType, billRefNos, '/portal/ta-make-payment');
                        }
                        if (this.dashboardTypeCode === 'AEM') {
                            this.paymentService.initPaymentProcess(true, cnst.eNets.URL_AEM_RETURN, paymentType, billRefNos, '/portal/payment-list');
                        }
                    }


                }
            });
        }*/
    }


    //TA
    chosenItem: String;
    selectedItem: any;
    chosenItemList = [];
    preview: boolean = false;
    amountPayable: number = 0;
    data: any = [];
    previewConfirmationDialog() {
        this.alertService.clear();
        this.chosenItemList = [];
        this.amountPayable = 0;
        this.selection.selected.forEach(row => {
            this.chosenItemList.push(row);
            this.amountPayable += row.payableAmount;
        });

        if (this.chosenItemList.length > 0) {
            this.preview = true;
        } else {
            this.alertService.error(cnst.Messages.MSG_NO_SELECTED_RECORDS);
        }
        window.scrollTo(0, 0);
    }
    cancelDialog() {
        this.preview = false;
    }
    checkForPendingPayment() {
        this.dashboardService.getMyOustandingPayments().subscribe(data => {
            this.data = data;
            this.rows.data = data;
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        });
    }
}
