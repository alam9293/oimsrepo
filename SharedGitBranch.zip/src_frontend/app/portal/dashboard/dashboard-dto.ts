export interface AlertDto {
    date: string;
    refId: string;
    type: string;
    status: string;
    remarks: string;
    uri: string;
}

export const MOCK_TA_ALERTS: AlertDto[] = [
    { date: '31-Jan-2018', refId: '1214326', type: 'Licence Replacement', status: 'Returned for Action', remarks: 'Uploaded document does not reflect the necessary information.', uri: "/portal/ta-replace-licence/true" },
    { date: '05-Apr-2017', refId: '1214325', type: 'Licence Replacement', status: 'Rejected', remarks: 'Applicant requested to withdraw application.', uri: '/portal/ta-replace-licence/true' },
    { date: '31-Jan-2018', refId: '1214326', type: 'Licence Cessation', status: 'Returned for Action', remarks: 'Applicant requested to change cessation date.', uri: "/portal/ta-cease-licence" },
    { date: '05-Apr-2017', refId: '1214325', type: 'Licence Cessation', status: 'Rejected', remarks: 'Not all directors have agreed.', uri: '/portal/ta-cease-licence' },
    { date: '05-Apr-2017', refId: '1214325', type: 'Switch of Licence Tier', status: 'Rejected', remarks: 'Not eligible.', uri: '/portal/ta-switch-tier' },
    { date: '01-Apr-2017', refId: '1214324', type: 'Switch of Licence Tier', status: 'Returned for Action', remarks: 'Uploaded document does not reflect the necessary information.', uri: '/portal/ta-switch-tier' },
    { date: '28-Jan-2016', refId: '1214323', type: 'Licence Creation', status: 'Approved', remarks: '', uri: '/portal/dashboard-ta' },
];

export const MOCK_TG_ALERTS: AlertDto[] = [
    { date: '31-Jan-2018', refId: '1214326', type: 'Licence Renewal', status: 'Returned for Action', remarks: 'Uploaded document does not reflect the necessary information.', uri: '/portal/dashboard-tg' },
    { date: '05-Apr-2017', refId: '1214325', type: 'Switch of Licence Tier', status: 'Rejected', remarks: '', uri: '/portal/dashboard-tg' },
    { date: '05-Apr-2017', refId: '1214325', type: 'Switch of Licence Tier', status: 'Approved', remarks: '', uri: '/portal/dashboard-tg' },
    { date: '01-Apr-2017', refId: '1214324', type: 'Switch of Licence Tier', status: 'Returned for Action', remarks: 'Uploaded document does not reflect the necessary information.', uri: '/portal/dashboard-tg' },
    { date: '28-Jan-2016', refId: '1214323', type: 'Licence Creation', status: 'Approved', remarks: '', uri: '/portal/dashboard-tg' },
];

export interface BulletinDto {
    date: string;
    message: string;
}

export const MOCK_TA_BULLETINS: BulletinDto[] = [
    { date: '31-Oct-2018', message: 'Newly Licensed, Revoked, Suspended & Ceased TAs in September 2018' },
    { date: '09-Oct-2018', message: 'Vertical Line Pte Ltd - Revocation of Travel Agent licence' },
    { date: '02-Oct-2018', message: 'Revocation of Travel Agent Licence: Baba Travel' },
    { date: '01-Oct-2018', message: 'Switch of licence tier' },
    { date: '20-Sep-2018', message: 'LTA-STB-TP-URA Advisory: Extension of Car-Free Sunday SG to 2018 with Coach Drop / Pick Up arrangements' },
];

export const MOCK_TG_BULLETINS: BulletinDto[] = [
    { date: '31-Oct-2018', message: 'Soft Launch of Area Tourist Guide Scheme' },
    { date: '09-Oct-2018', message: 'Multi-language Proficiency Test for Licenced Tourist Guides' },
    { date: '02-Oct-2018', message: 'Delay in Restoration Works of the Merlion Statue at the Merlion Park Tenatively from 1 Oct to 9 Dec' },
    { date: '01-Oct-2018', message: 'Tourist Guide Circular 10' },
    { date: '20-Sep-2018', message: 'The Conditions of Licence Tourist Guide Must Adhere' },
];
