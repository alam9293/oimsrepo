import { Component, OnInit } from '@angular/core';
import { TgRenewalFormService } from '../../tg/tg-renewal-form/tg-renewal-form.service';
import { DashboardTgService } from './dashboard-tg.service';
import { TgRenewalHelperUtil } from '../../tg/tg-helper';
import { User, ListableDto } from '../../../common/models';
import * as numeral from 'numeral';
import * as cnst from '../../../common/constants';
import * as _ from 'lodash';
import { FormBuilder, FormGroup, AbstractControl } from '@angular/forms';
import { CommonService } from 'src/app/common/services/common.service';
import { AuthenticationService } from '../../../common/services';
import { Router, ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
declare var jQuery: any;

@Component({
    selector: 'app-dashboard-tg',
    templateUrl: './dashboard-tg.component.html',
    styleUrls: ['./dashboard-tg.component.scss']
})
export class DashboardTgComponent implements OnInit {

    currentUser: User;
    dashboard: any;
    appTypeList: any;
    cnst = cnst;
    numeral = numeral;
    licenceStatus: ListableDto = { key: "", label: "", otherLabel: "" };
    printStatus: ListableDto;
    daysLeftToExpire: number;
    noOfPendingActions: number;
    noOfPdcHoursFulfilled: number;
    noOfAssignmentsHours: number;
    licenceExpiryDate: any;
    mlptDetails: any = {};
    minItem: any = 2;
    tgBulletins: any;
    displayCssClassForNoOfPendingActions = ' ';
    displayPendingAction = 'Pending Action';
    displayCssClassForNoOfPdcHoursFulfilled = ' ';
    displayCssClassForNoOfAssignmentsHours = ' ';
    isLoading = true;
    stipendDetails: any;

    firstFormGroup: FormGroup;

    constructor(private tgRenewalFormService: TgRenewalFormService,
        private dashboardTgService: DashboardTgService,
        private tgRenewalHelperUtil: TgRenewalHelperUtil,
        private _formBuilder: FormBuilder,
        private commonService: CommonService,
        private authenticationService: AuthenticationService,
        private router: Router
    ) { }



    ngOnInit() {
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
            });
        }
        this.firstFormGroup = this._formBuilder.group({
            status: this._formBuilder.group({
                key: ['', this.tgRenewalHelperUtil.isEditable],
                label: [''],
            }),
            mrc: this.tgRenewalHelperUtil.getConditionGroup(),
            pdc: this.tgRenewalHelperUtil.getConditionGroup(),
            assignments: this.tgRenewalHelperUtil.getConditionGroup(),
            assessment: this.tgRenewalHelperUtil.getConditionGroup(),
            cpf: this.tgRenewalHelperUtil.getConditionGroup(),
            newPhoto: this.tgRenewalHelperUtil.getConditionGroup(),
            medicalReport: this.tgRenewalHelperUtil.getConditionGroup(),
            workPass: this.tgRenewalHelperUtil.getConditionGroup(),
            licenceFee: this.tgRenewalHelperUtil.getConditionGroup(),
            paymentSuccess: [false],
            renewalStatus: this._formBuilder.group({
                key: [''],
                label: ['renewal'],
                otherLabel: ['']
            }),
            hasNoAssignment: [''],
            isCurrentTgPhoto: [false],
            isRfaApp: [false]
        });

        this.tgRenewalFormService.getLicenceRenewal().subscribe(data => {
            this.firstFormGroup.patchValue(data);
            this.tgRenewalHelperUtil.loadConditions(this.firstFormGroup);
            this.isLoading = false;
        });

        this.dashboardTgService.getCountForTopNotification().subscribe(data => {
            this.printStatus = data.printStatus;
            this.licenceStatus = data.licenceStatus;
            this.daysLeftToExpire = data.daysLeftToExpire;
            this.noOfPendingActions = data.pendingApplicationCount;
            this.noOfPdcHoursFulfilled = data.pdcHoursCount;
            this.noOfAssignmentsHours = data.assignmentCount;
            if (this.daysLeftToExpire > 181) {
                this.dashboardTgService.getLicenceExpiryDate().subscribe(data => this.licenceExpiryDate = data);
            }

            if (this.noOfAssignmentsHours > 0 || this.firstFormGroup.get("hasNoAssignment").value) {
                this.displayCssClassForNoOfAssignmentsHours = ' countPositive';
            }
            if (this.noOfPdcHoursFulfilled >= 21) {
                this.displayCssClassForNoOfPdcHoursFulfilled = ' countPositive';
            }
            if (this.noOfPendingActions == 0) {
                this.displayCssClassForNoOfPendingActions = ' countPositive';
            } else if (this.noOfPendingActions > 1) {
                this.displayPendingAction = 'Pending Actions';
            }
        });

        this.commonService.getBulletinsAll(cnst.BulletinTypes.TG).subscribe(data => {
            this.tgBulletins = data;

            setTimeout(() => {
                (function ($) {
                    var min_item = 2;
                    if ($(window).width() < 768) {
                        min_item = 1;
                    }

                    $('.carousel[data-type="multi"] .item').each(function () {
                        var next = $(this).next();
                        if (!next.length) {
                            next = $(this).siblings(':first');
                        }
                        next.children(':first-child').clone().appendTo($(this));

                        // for (var i = 0; i < 2; i++) {
                        //     next = next.next();
                        //     if (!next.length) {
                        //         next = $(this).siblings(':first');
                        //     }

                        //     next.children(':first-child').clone().appendTo($(this));
                        // }
                    });

                    if ($('#carousel-bulletin').find(".carousel-inner .item").length <= min_item) {
                        $('#carousel-bulletin').attr("data-interval", false);

                        $('#carousel-bulletin').find('.left.carousel-control').hide();
                        $('#carousel-bulletin').find('.right.carousel-control').hide();
                    }

                    $('.carousel').on('slid.bs.carousel', function (e) {
                        var $this = $(this);

                        $this.children('.carousel-control').show();

                        if (min_item == 1) {

                            if ($('#' + $this.attr("id") + ' .carousel-inner .item:first').hasClass('active')) {
                                $this.children('.left.carousel-control').hide();
                                $(this).carousel('cycle');
                            }
                            else if ($('#' + $this.attr("id") + ' .carousel-inner .item:last').hasClass('active')) {
                                $this.children('.right.carousel-control').hide();
                                $(this).carousel('pause');
                            }
                        }
                        else {
                            var current_index = $(this).find('.active').index();

                            if (current_index == 0) {
                                $this.children('.left.carousel-control').hide();
                                $(this).carousel('cycle');
                            }
                            else if ((current_index + min_item) == $(this).find('.item').length) {
                                $this.children('.right.carousel-control').hide();
                                $(this).carousel('pause');
                            }
                        }
                    });
                })(jQuery);
            });
        });

        this.dashboardTgService.getMlptDetails().subscribe(data => {
            this.mlptDetails = data;
        });

        this.dashboardTgService.getStipendDetails().subscribe(data => {
            this.stipendDetails = data;
        });
    }

    // convenience getter for easy access to form fields
    get f1() { return this.firstFormGroup.controls; }

    isConditionGrey(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionGrey(condition);
    }

    isConditionGreyOnly(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionGreyOnly(condition);
    }

    isConditionGreyTemp(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionGreyTemp(condition);
    }

    isConditionHide(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionHide(condition);
    }

    routePath(condition: AbstractControl, renewalConditions: String) {
        if (this.isConditionGrey(condition)) {
            return null;
        }
        else {
            return ['/portal/tg/renewal-form', renewalConditions];
        }
    }

    getTime(time: any) {
        var time, startTime, endTime;

        if (time) {
            startTime = moment(time, 'DD-MMM-YYYY HH:mm:ss').format('HH:mm');
            endTime = moment(time, 'DD-MMM-YYYY HH:mm:ss').add(30, 'm').format('HH:mm');
            return startTime + " - " + endTime;
        } else {
            return '';
        }
    }

    onSubmit() {

        this.tgRenewalFormService.save().subscribe(data => {
            this.router.navigate([cnst.TgApplicationUrl.TG_THANK_YOU], {
                queryParams: {
                    'title': 'Return For Action',
                    'applicationNo': data.applicationNo
                }
            });
        });
    }

}
