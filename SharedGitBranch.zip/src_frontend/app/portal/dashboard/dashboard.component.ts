import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardService } from './dashboard.service'
import * as dto from './dashboard-dto';
import { DateUtil } from 'src/app/common/helper';
import { AuthenticationService, NotificationService } from '../../common/services'
import { User } from '../../common/models';
import * as cnst from '../../common/constants';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    alerts: any = [];
    licence: any;
    bulletinDataSource: MatTableDataSource<dto.BulletinDto>;
    alertsDisplayedColumns = ['date', 'typeRefId', 'status', 'remarks'];
    bulletinDisplayedColumns = ['date', 'message'];
    applicationView = "all";
    currentUser: User;
    cnst = cnst;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private dialog: MatDialog,
        private dashboardService: DashboardService,
        private notificationService: NotificationService,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
        this.loadAlerts();
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
            this.loadBulletins(this.currentUser);
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
                this.loadBulletins(this.currentUser);
            });
        }

        if (cnst.CommonRoles.TP_PUBLIC == this.currentUser.selectedRole.key) {
            if (this.currentUser.tpPdc) {
                this.router.navigate(['/portal/tp-PDC-manage']);
            } else if (this.currentUser.tpMrc) {
                this.router.navigate(['/portal/tp-MRC-manage']);
            }
        }
        this.loadLicenceDetails();

        this.alerts.paginator = this.paginator;
        this.alerts.sort = this.sort;
    }

    loadBulletins(currentUser: User) {
        if (currentUser.selectedRole.key === 'TA_PUB') {
            this.bulletinDataSource = new MatTableDataSource(dto.MOCK_TA_BULLETINS);
            this.bulletinDataSource.paginator = this.paginator;
            this.bulletinDataSource.sort = this.sort;
        } else if (currentUser.selectedRole.key === 'TG_PUB') {
            this.bulletinDataSource = new MatTableDataSource(dto.MOCK_TG_BULLETINS);
            this.bulletinDataSource.paginator = this.paginator;
            this.bulletinDataSource.sort = this.sort;
        }
    }

    loadAlerts() {
        let mergedDto = {
            'pageSize': 10,
            'startIndex': 0
        };
        this.notificationService.getAlerts(mergedDto).subscribe(data => this.alerts = data.records);
    }

    daysToExpire: number;
    loadLicenceDetails() {
        this.dashboardService.getLicence().subscribe(data => {
            this.licence = data;
            if (this.licence && this.licence.expiryDate) {
                this.daysToExpire = DateUtil.parseDate(this.licence.expiryDate).diff(DateUtil.getNow(), 'days');
            }
        });

    }
    openDialog(): void {
        const dialogRef = this.dialog.open(DialogBulletin, {
            width: '800px',
        });
    }
}

@Component({
    selector: 'dialog-bulletin',
    templateUrl: './dialog-bulletin.html',
})
export class DialogBulletin {

    constructor(
        public dialogRef: MatDialogRef<DialogBulletin>) { }

    onNoClick(): void {
        this.dialogRef.close();
    }
}
