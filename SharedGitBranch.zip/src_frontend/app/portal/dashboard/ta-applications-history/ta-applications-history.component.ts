import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatPaginator, MatSort } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../../common/services';
import { TaApplicationService } from './ta-applications-history.service';

@Component({
    selector: 'app-ta-applications-history',
    templateUrl: './ta-applications-history.component.html',
    styleUrls: ['./ta-applications-history.component.scss']
})
export class TaApplicationsHistoryComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    filter: any = {};
    applications = [];
    cnst = cnst;
    appsDisplayedColumns = ['date', 'typeRefId', 'status', 'remarks'];
    applicationStatuses: any = [];
    applicationTypes: any = [];

    constructor(
        private route: ActivatedRoute,
        private dialog: MatDialog,
        private commonService: CommonService,
        private taApplicationService: TaApplicationService,
    ) { }

    ngOnInit() {
        this.sort.direction = "desc";
        this.sort.active = "submissionDate";
        this.loadApplications();
        this.loadCommonTypes();
    }

    totalPages: number = 0;
    currentPage: number = 0;
    loadApplications() {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            'myApplications': false,
            ...this.filter
        };
        this.taApplicationService.getApplications(mergedDto).subscribe(data => {
            this.applications = data.records;
            this.paginator.length = data.total;
            this.currentPage = this.paginator.pageIndex + 1;
            this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        });
    }

    loadCommonTypes() {
        this.commonService.getTaApplicationStatuses().subscribe(data => this.applicationStatuses = data);
        this.commonService.getTaApplicationTypes().subscribe(data => this.applicationTypes = data);
    }

    nextPage() {
        if (this.currentPage < this.totalPages) {
            this.paginator.pageIndex += 1;
            this.loadApplications();
        }
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.paginator.pageIndex -= 1;
            this.loadApplications();
        }
    }

    pageSizeChange() {
        this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        if (this.currentPage > this.totalPages) {
            this.paginator.pageIndex = this.totalPages - 1;
        }
        this.loadApplications();
    }

    searchResults() {
        this.paginator.pageIndex = 0;
        this.loadApplications();
    }
}
