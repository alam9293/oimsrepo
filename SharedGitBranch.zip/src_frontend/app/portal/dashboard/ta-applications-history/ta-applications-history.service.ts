import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants'

@Injectable({
    providedIn: 'root'
})
export class TaApplicationService {

    constructor(private http: HttpClient) { }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ta/applications/history/' + applicationId);
    }

    getApplications(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ta/applications/history', { params: searchDto });
    }
}
