import { Component, OnInit, ViewChild } from '@angular/core';
import * as cnst from '../../../common/constants';
import { TaPastInfringementsListComponent } from '../ta-past-infringements-list/ta-past-infringements-list.component';

@Component({
    selector: 'app-ta-past-infringements',
    templateUrl: './ta-past-infringements.component.html',
    styleUrls: ['./ta-past-infringements.component.scss']
})
export class TaPastInfringementsComponent implements OnInit {

    @ViewChild(TaPastInfringementsListComponent) taPastInfringementsListComponent: TaPastInfringementsListComponent;

    cnst = cnst;

    constructor(
    ) { }

    ngOnInit() {

    }

    hasOutstandingPayment(): boolean {
        return this.taPastInfringementsListComponent && this.taPastInfringementsListComponent.hasOutstandingPayment;
    }
}
