import { Component, OnInit, Input, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, NotificationService } from '../../../common/services';
import { User, LicenseeDto } from '../../../common/models';
import * as cnst from '../../../common/constants';
import { AppUtil } from '../../../common/helper/app.util';
import * as _ from 'lodash';

@Component({
    selector: 'app-top-menu-ta',
    templateUrl: './top-menu-ta.component.html',
    styleUrls: ['./top-menu-ta.component.scss']
})
export class TopMenuTaComponent implements OnInit {
    @Input() dashboardTypeCode: string;
    currentUser: User;
    isMenuOpen: boolean = false;
    licensee: LicenseeDto;
    totalUnreadAlerts: Number = 0;
    cnst = cnst;
    isTaActive: boolean;
    isLicensee: boolean;

    constructor(
        private router: Router,
        private authenticationService: AuthenticationService,
        private notificationService: NotificationService,
        private appUtil: AppUtil,
    ) { }

    ngOnInit() {
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
            this.licensee = this.currentUser.licensee;
            this.checkIsLicensee();
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
                this.licensee = this.currentUser.licensee;
                this.checkIsLicensee();
            });
        }

    };
    checkIsLicensee() {
        this.isLicensee = this.licensee.licenceNumber != null;
        if (this.isLicensee) {
            this.notificationService.getTotalUnreadAlerts().subscribe(data => {
                this.totalUnreadAlerts = data;
            });
            this.notificationService.refreshUnread.subscribe(data => {
                this.totalUnreadAlerts = data;
            })
            this.isTaActive = this.authenticationService.isTaActive();
        }
    }
    onLoggedout() {
        this.authenticationService.logout();
        //   this.appUtil.routeToHomePage();
    }

    toggleMenu(event: Event) {
        this.isMenuOpen = !this.isMenuOpen;
        event.stopPropagation();
    }

    @HostListener('document:click', ['$event'])
    public documentClick(event: Event): void {
        if (this.isMenuOpen) {
            this.isMenuOpen = false;
        }
    }
}
