import { Component, OnInit, Input, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../common/services';
import { User, LicenseeDto } from '../../../common/models';
import * as cnst from '../../../common/constants';
import { AppUtil } from '../../../common/helper';
import * as _ from 'lodash';

@Component({
    selector: 'app-top-menu-tg',
    templateUrl: './top-menu-tg.component.html',
    styleUrls: ['./top-menu-tg.component.scss']
})
export class TopMenuTgComponent implements OnInit {
    @Input() dashboardTypeCode: string;
    currentUser: User;
    isMenuOpen: boolean = false;
    licensee: LicenseeDto;
    cnst = cnst;

    constructor(
        private router: Router,
        private authenticationService: AuthenticationService,
        private appUtil: AppUtil,
    ) { }

    ngOnInit() {
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
            this.licensee = this.currentUser.licensee;
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
                this.licensee = this.currentUser.licensee;
            });
        }
    };

    onLoggedout() {
        this.authenticationService.logout();
        this.appUtil.routeToHomePage();
    }

    toggleMenu(event: Event) {
        this.isMenuOpen = !this.isMenuOpen;
        event.stopPropagation();
    }

    @HostListener('document:click', ['$event'])
    public documentClick(event: Event): void {
        if (this.isMenuOpen) {
            this.isMenuOpen = false;
        }
    }

    isTaActive(status: string): Boolean {
        if (status) {
            var active_statuses = this.cnst.TaStatuses.ACTIVE;
            var isActive: boolean;
            _.forEach(active_statuses, function (value) {
                if (status === value) {
                    isActive = true;
                    return;
                }
            });
            return isActive;
        } else {
            return false;
        }
    }
}
