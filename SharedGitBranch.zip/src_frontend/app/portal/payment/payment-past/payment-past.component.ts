import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../../common/services';
import { PaymentService } from '../payment.service';
import { DateUtil } from '../../../common/helper';
@Component({
    selector: 'app-payment-past',
    templateUrl: './payment-past.component.html',
    styleUrls: ['./payment-past.component.scss']
})
export class PaymentPastComponent implements OnInit {

    constructor(
        private commonService: CommonService,
        private paymentService: PaymentService,
        private route: ActivatedRoute,
        public dateUtil: DateUtil
    ) { }

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    appsDisplayedColumns = ['date', 'id', 'billRefNos', 'payReqTypes', 'status', 'amt'];
    filter: any = {};
    txns = [];
    cnst = cnst;
    statuses: any = [];
    totalPages: number = 0;
    currentPage: number = 0;
    dashboardTypeCode: any = cnst.dashboardTypeCode.TG;
    DateUtil = DateUtil;

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        this.loadCommonTypes();
    }

    ngAfterViewInit(): void {
        this.loadTxns();
    }

    loadTxns() {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filter
        };
        this.paymentService.getPaymentTxns(mergedDto).subscribe(data => {
            this.txns = data.records;
            this.paginator.length = data.total;
            this.currentPage = this.paginator.pageIndex + 1;
            this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        });
    }

    loadCommonTypes() {
        this.commonService.getPaymentTransactionStatuses().subscribe(data => this.statuses = data);
    }

    nextPage() {
        if (this.currentPage < this.totalPages) {
            this.paginator.pageIndex += 1;
            this.loadTxns();
        }
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.paginator.pageIndex -= 1;
            this.loadTxns();
        }
    }

    pageSizeChange() {
        this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        if (this.currentPage > this.totalPages) {
            this.paginator.pageIndex = this.totalPages - 1;
        }
        this.loadTxns();
    }

    searchResults() {
        this.paginator.pageIndex = 0;
        this.loadTxns();
    }

}
