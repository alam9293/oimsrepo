import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
    selector: 'app-payment',
    templateUrl: './payment.component.html',
    styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
    successLink: String;
    isTg: Boolean = false;
    constructor(private route: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.successLink = this.route.snapshot.paramMap.get('successLink');

        if (this.route.snapshot.paramMap.has('tgType')) {
            this.isTg = true;
        } else {
            // [Verlin 08/11/2018]: To think of solution for passing in link with '/' for stateParams
            if (this.successLink == 'ta-application-payment') {
                this.successLink = 'ta-application-form/pending-payment-verification'
            }
        }
    }

    onPaymentClick() {
        this.router.navigate(['/portal/tg/application-success/' + this.route.snapshot.paramMap.get('module')]);
    }

}
