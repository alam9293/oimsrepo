// Materials
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PortalMaterialModule } from './portal.material';
import { PortalMomentModule } from './portal.moment';
import { MatDialogModule } from '@angular/material';
import { NgxCroppieModule } from 'ngx-croppie';
import { CroppieDialogComponent } from './croppie-dialog/croppie-dialog.component';
import { CroppieFormControlComponent } from './croppie-form-control/croppie-form-control.component';
// Directives
import { WizDatetimePickerDirective } from '../common/directives/wiz-datetime-picker.directive';
import { WizDatePickerDirective } from '../common/directives/wiz-date-picker.directive';
import { WizTimePickerDirective } from '../common/directives/wiz-time-picker.directive';
import { WizAuditAmountDirective } from '../common/directives/wiz-audit-amount.directive';
import { AlertComponent } from '../common/directives/alert.directive';
import { DisableControlDirective } from '../common/directives/disable-control.directive';
import { AmountRoundSeparatorDirective } from '../common/directives/amount-rounding-separator.directive';

// Pipes
import { wizDatePipe } from '../common/pipes/wiz-date.pipe';
import { counterToSecondsPipe } from '../common/pipes/counter-to-seconds.pipe';
import { KeyFilterPipe } from '../common/pipes/key-filter.pipe';

// Common Modules
import { BackModule } from '../common/modules/back/back.module';
import { StatModule } from '../common/modules/stat/stat.module';
import { InformationDialogModule } from '../common/modules/information-dialog/information-dialog.module';
import { InformationDialogComponent } from '../common/modules/information-dialog/information-dialog.component';
import { ConfirmationDialogModule } from '../common/modules/confirmation-dialog/confirmation-dialog.module';
import { ConfirmationDialogComponent } from '../common/modules/confirmation-dialog/confirmation-dialog.component';
import { SuccessSnackbarModule } from '../common/modules/success-snackbar/success-snackbar.module';
import { SuccessSnackbarComponent } from '../common/modules/success-snackbar/success-snackbar.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentListComponent } from './payment/payment-list/payment-list.component';
import { PaymentResultComponent } from './payment/payment-result/payment-result.component';
import { PaymentDialogModule } from '../common/modules/payment-dialog/payment-dialog.module';
import { PaymentDialogComponent } from '../common/modules/payment-dialog/payment-dialog.component';
import { FooterMenuModule } from '../common/modules/footer-menu/footer-menu.module';
import { SessionTimeoutModule } from '../common/modules/session-timeout/session-timeout.module';
import { ScrollToTopModule } from '../common/modules/scroll-to-top/scroll-to-top.module';
import { TopMenuModule } from '../common/modules/top-menu/top-menu.module';
import { ELicenceDialogModule } from '../common/modules/elicence-dialog/elicence-dialog.module';
import { ELicenceDialogComponent } from '../common/modules/elicence-dialog/elicence-dialog.component';
import { TaElicenceDialogModule } from '../common/modules/ta-elicence-dialog/ta-elicence-dialog.module';
import { TaElicenceDialogComponent } from '../common/modules/ta-elicence-dialog/ta-elicence-dialog.component';
import { TaElicenceRequestDialogModule } from '../common/modules/ta-elicence-request-dialog/ta-elicence-request-dialog.module';
import { TaElicenceRequestDialogComponent } from '../common/modules/ta-elicence-request-dialog/ta-elicence-request-dialog.component';
// Others
import { PortalRoutingModule } from './portal-routing.module';
import { PortalComponent } from './portal.component';
import { DashboardComponent, DialogBulletin } from './dashboard/dashboard.component';
import { DialogSessionExpiringComponent } from '../common/modules/session-timeout/session-timeout.component';
// TA
import { TopMenuTaComponent } from './menu/top-menu-ta/top-menu-ta.component';
import { DashboardTaComponent } from './dashboard/dashboard-ta/dashboard-ta.component';
import { TaPendingActionsComponent } from './dashboard/ta-pending-actions/ta-pending-actions.component';
import { TaApplicationsHistoryComponent } from './dashboard/ta-applications-history/ta-applications-history.component';
import { TaNotificationComponent } from './dashboard/ta-notification/ta-notification.component';
import { TaApplicationFormComponent, DialogPersonnel } from './ta/ta-application-form/ta-application-form.component';
import { TaApplicationSuccessComponent } from './ta/ta-application-form/ta-application-success/ta-application-success.component';
import { TaPersonnelListComponent, DialogPersonnelDetailsComponent } from './ta/ta-personnel-list/ta-personnel-list.component';
import { TaKeDeclarationComponent } from './ta/ta-ke-declaration/ta-ke-declaration.component';
import { TaBranchLicenceComponent } from './ta/ta-branch-licence/ta-branch-licence.component';
import { DialogTaCeasedBranches, DialogTaManageBranch } from './ta/ta-branch-licence/ta-manage-branch.component';

import { TaManageKeUpdateComponent } from './ta/ta-manage-ke-update/ta-manage-ke-update.component';
import { TaReplaceLicenceComponent } from './ta/ta-replace-licence/ta-replace-licence.component';
import { TaCeaseLicenceComponent } from './ta/ta-cease-licence/ta-cease-licence.component';
import { TaSwitchTierComponent, TaSwitchInfoDialog } from './ta/ta-switch-tier/ta-switch-tier.component';
import { TaChangeCompayDetailsComponent } from './ta/ta-change-compay-details/ta-change-compay-details.component';
import { TaInboundOutboundServicesComponent } from './ta/ta-inbound-outbound-services/ta-inbound-outbound-services.component';
import { TaApplicationPaymentComponent } from './ta/ta-application-form/ta-application-payment/ta-application-payment.component';

import { TaAbprSubmissionComponent } from './ta/ta-abpr-submission/ta-abpr-submission.component';
import { TaShortfallFulfilmentComponent } from './ta/ta-shortfall-fulfilment/ta-shortfall-fulfilment.component';
import { TaAaSubmissionComponent } from './ta/ta-aa-submission/ta-aa-submission.component';
import { TaChangeFyeComponent } from './ta/ta-change-fye/ta-change-fye.component';
import { TaManageKeResignComponent } from './ta/ta-manage-ke-resign/ta-manage-ke-resign.component';
import { TaManageKeAssignComponent } from './ta/ta-manage-ke-assign/ta-manage-ke-assign.component';
import { TaBulletinComponent } from './ta/ta-bulletin/ta-bulletin.component';

import { TaLicenceRenewalComponent } from './ta/ta-licence-renewal/ta-licence-renewal.component';
import { TaMaSubmissionComponent } from './ta/ta-ma-submission/ta-ma-submission.component';
import { TaPastInfringementsComponent } from './dashboard/ta-past-infringements/ta-past-infringements.component';
import { TaPastInfringementsListComponent } from './dashboard/ta-past-infringements-list/ta-past-infringements-list.component';
import { TaDocSubmissionComponent } from './ta/ta-doc-submission/ta-doc-submission.component';

import { TaElicenceRequestComponent } from './ta/ta-elicence-request/ta-elicence-request.component';

// TG
import { TopMenuTgComponent } from './menu/top-menu-tg/top-menu-tg.component';
import { SideMenuTgComponent } from './menu/side-menu-tg/side-menu-tg.component';
import { DashboardTgComponent } from './dashboard/dashboard-tg/dashboard-tg.component';
import { TgApplicationFormComponent } from './tg/tg-application-form/tg-application-form.component';
import { TgApplicationSuccessComponent } from './tg/tg-application-success/tg-application-success.component';
import { TgApplyMLPTComponent } from './tg/tg-apply-mlpt/tg-apply-mlpt.component';
import { TgRenewalFormComponent } from './tg/tg-renewal-form/tg-renewal-form.component';
import { TgRenewalPreambleComponent } from './tg/tg-renewal-preamble/tg-renewal-preamble.component';
import { TgReinstateFormComponent } from './tg/tg-reinstate-form/tg-reinstate-form.component';
import { TgLostLicenceFormComponent } from './tg/tg-lost-licence-form/tg-lost-licence-form.component';
import { TgPastInfringementComponent } from './tg/tg-past-infringement/tg-past-infringement.component';
import { TgCancelFormComponent } from './tg/tg-cancel-form/tg-cancel-form.component';
import { TgAssignmentListComponent } from './tg/tg-assignment-process/tg-assignment-list/tg-assignment-list.component';
import { TgAssignmentCreateComponent } from './tg/tg-assignment-process/tg-assignment-create/tg-assignment-create.component';
import { TgUpdateParticularsComponent } from './tg/tg-update-particulars/tg-update-particulars.component';
import { TgCoursesAttendedPdcComponent } from './tg/tg-courses-attended/tg-courses-attended-pdc/tg-courses-attended-pdc.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { TgCoursesAttendedMrcComponent } from './tg/tg-courses-attended/tg-courses-attended-mrc/tg-courses-attended-mrc.component';
import { TgThankyouComponent } from './tg/tg-thankyou/tg-thankyou.component';
import { TgBulletinComponent } from './tg/tg-bulletin/tg-bulletin.component';
import { TgSwitchTierComponent } from './tg/tg-switch-tier/tg-switch-tier.component';
import { TgRenewalDeclarationComponent } from './tg/tg-renewal-declaration/tg-renewal-declaration.component';
import { TgPendingActionsComponent } from './dashboard/tg-pending-actions/tg-pending-actions.component';
import { TgAssignmentViewComponent } from './tg/tg-assignment-process/tg-assignment-view/tg-assignment-view.component';
import { TgTrainingCalendarListComponent } from './tg/tg-training-calendar/tg-training-calendar-list/tg-training-calendar-list.component';
import { TgTrainingCalendarViewComponent } from './tg/tg-training-calendar/tg-training-calendar-view/tg-training-calendar-view.component';
import { TgTrainingCalendarTpListComponent } from './tg/tg-training-calendar/tg-training-calendar-tp-list/tg-training-calendar-tp-list.component';
import { TgTrainingCalendarTpViewComponent } from './tg/tg-training-calendar/tg-training-calendar-tp-view/tg-training-calendar-tp-view.component';
import { TgStipendFormComponent } from './tg/tg-stipend-form/tg-stipend-form.component';
//TP
import { TpPDCComponent } from './tp/tp-pdc/tp-pdc.component';
import { TpPDCManageComponent } from './tp/tp-pdc-manage/tp-pdc-manage.component';
import { TpPdcManageViewComponent } from './tp/tp-pdc-manage-view/tp-pdc-manage-view.component';
import { TpMRCComponent } from './tp/tp-mrc/tp-mrc.component';
import { TpPdcCourseNewComponent } from './tp/tp-pdc-course-new/tp-pdc-course-new.component';
import { TpMRCManageComponent } from './tp/tp-mrc-manage/tp-mrc-manage.component';
import { TpMrcManageViewComponent } from './tp/tp-mrc-manage-view/tp-mrc-manage-view.component';
import { TpPdcCourseListComponent } from './tp/tp-pdc-course/tp-pdc-course-list/tp-pdc-course-list.component';
import { TpPdcCourseViewComponent } from './tp/tp-pdc-course/tp-pdc-course-view/tp-pdc-course-view.component';
import { TpProfileManageComponent } from './tp/tp-profile-manage/tp-profile-manage.component';
import { TpCourseRenewalComponent } from './tp/tp-course-renewal/tp-course-renewal.component';
import { TpApplicationSuccessComponent } from './tp/tp-application-success/tp-application-success.component';

import { LoginComponent } from './login/login.component';
import { PaymentPastComponent } from './payment/payment-past/payment-past.component';
import { PaymentReceiptComponent } from './payment/payment-receipt/payment-receipt.component';

import { BulletinComponent } from './bulletin/bulletin.component';

// external library
import { NgxCurrencyModule } from "ngx-currency";
import { NgxPaginationModule } from 'ngx-pagination';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { UserguideComponent } from './userguide/userguide.component';
import { TouristGuideComponent } from './site/content/tagaem/landing-page/tourist-guide/tourist-guide.component';

export const customCurrencyMaskConfig = {
    align: "left",
    allowNegative: true,
    allowZero: true,
    decimal: ",",
    precision: 0,
    prefix: "S$ ",
    suffix: "",
    thousands: ",",
    nullable: true
};

@NgModule({
    imports: [
        // Materials
        CommonModule,
        FlexLayoutModule,
        FormsModule,
        ReactiveFormsModule,
        PortalMaterialModule,
        PortalMomentModule,
        MatDialogModule,
        NgxCroppieModule,
        // Common
        BackModule,
        StatModule,
        PortalRoutingModule,
        ConfirmationDialogModule,
        InformationDialogModule,
        SuccessSnackbarModule,
        PaymentDialogModule,
        SessionTimeoutModule,
        FooterMenuModule,
        TopMenuModule,
        ScrollToTopModule,
        NgxCurrencyModule.forRoot(customCurrencyMaskConfig),
        NgxPaginationModule,
        CKEditorModule,
        ELicenceDialogModule,
        TaElicenceDialogModule,
        TaElicenceRequestDialogModule,

    ],
    declarations: [
        // Others
        PortalComponent,
        DashboardComponent,
        DialogBulletin,
        PaymentComponent,
        PaymentListComponent,
        PaymentResultComponent,
        DialogSessionExpiringComponent,
        CroppieFormControlComponent,
        CroppieDialogComponent,
        // Directives
        WizDatetimePickerDirective,
        WizDatePickerDirective,
        WizTimePickerDirective,
        WizAuditAmountDirective,
        AlertComponent,
        DisableControlDirective,
        AmountRoundSeparatorDirective,
        // Pipes
        wizDatePipe,
        counterToSecondsPipe,
        KeyFilterPipe,

        // TA
        TopMenuTaComponent,
        DashboardTaComponent,
        TaApplicationsHistoryComponent,
        TaPendingActionsComponent,
        TaNotificationComponent,
        TaApplicationFormComponent,
        TaApplicationSuccessComponent,
        TaManageKeUpdateComponent,
        TaCeaseLicenceComponent,
        TaSwitchTierComponent,
        TaSwitchInfoDialog,
        TaPersonnelListComponent,
        TaKeDeclarationComponent,
        TaPersonnelListComponent,
        TaBranchLicenceComponent,
        TaAbprSubmissionComponent,
        TaShortfallFulfilmentComponent,
        DialogPersonnel,
        DialogPersonnelDetailsComponent,
        DialogTaCeasedBranches,
        DialogTaManageBranch,
        TaChangeCompayDetailsComponent,
        ThankyouComponent,
        TaReplaceLicenceComponent,
        TaAaSubmissionComponent,
        TaChangeFyeComponent,
        TaManageKeResignComponent,
        TaManageKeAssignComponent,
        TaInboundOutboundServicesComponent,
        TaBulletinComponent,
        TaLicenceRenewalComponent,
        TaMaSubmissionComponent,
        TaPastInfringementsComponent,
        TaPastInfringementsListComponent,
        TaDocSubmissionComponent,
        TaElicenceRequestComponent,

        // TG
        TopMenuTgComponent,
        DashboardTgComponent,
        SideMenuTgComponent,
        TgApplicationFormComponent,
        TgApplicationSuccessComponent,
        TgApplyMLPTComponent,
        TgReinstateFormComponent,
        TgLostLicenceFormComponent,
        TgPastInfringementComponent,
        TgCancelFormComponent,
        TgRenewalFormComponent,
        TgRenewalPreambleComponent,
        TgAssignmentListComponent,
        TgAssignmentCreateComponent,
        TgUpdateParticularsComponent,
        TgThankyouComponent,
        TgBulletinComponent,
        TgSwitchTierComponent,
        TgTrainingCalendarListComponent,
        TgTrainingCalendarViewComponent,
        TgTrainingCalendarTpListComponent,
        TgTrainingCalendarTpViewComponent,
        TgStipendFormComponent,
        //TP
        TpPDCComponent,
        TpPDCManageComponent,
        TpPdcManageViewComponent,
        TpMRCComponent,
        TpMRCManageComponent,
        TpMrcManageViewComponent,
        TpPdcCourseListComponent,
        TpPdcCourseNewComponent,
        TpPdcCourseViewComponent,
        TpProfileManageComponent,
        TpCourseRenewalComponent,
        TpApplicationSuccessComponent,

        LoginComponent,
        TaApplicationPaymentComponent,
        TgAssignmentViewComponent,
        TgCoursesAttendedPdcComponent,
        TgCoursesAttendedMrcComponent,
        TgRenewalDeclarationComponent,
        TgPendingActionsComponent,
        PaymentPastComponent,
        PaymentReceiptComponent,
        BulletinComponent,
        UserguideComponent,
        TouristGuideComponent

    ],
    entryComponents: [
        DialogBulletin,
        DialogPersonnelDetailsComponent,
        DialogPersonnel,
        DialogTaCeasedBranches,
        DialogTaManageBranch,
        ConfirmationDialogComponent,
        PaymentDialogComponent,
        InformationDialogComponent,
        SuccessSnackbarComponent,
        TaSwitchInfoDialog,
        DialogSessionExpiringComponent,
        CroppieFormControlComponent,
        CroppieDialogComponent,
        ELicenceDialogComponent,
        TaElicenceDialogComponent,
        TaElicenceRequestDialogComponent,
        BulletinComponent,
    ],
})
export class PortalModule { }
