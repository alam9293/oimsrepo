import { TouristGuideService } from './tourist-guide.services';
import * as cnst from '../../../../../../common/constants';
import { Component, OnInit} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { TouristGuideItemDto} from '../../../../../../common/models/common';
import { ResultDto} from '../../../../../../common/models/common';
import { Observable,Subject } from "rxjs";


@Component({
    selector: 'app-site',
    templateUrl: './tourist-guide.component.html',
    styleUrls: ['./tourist-guide.component.scss']
})
export class TouristGuideComponent implements OnInit {
    dashboardTypeCode: string;
    //statuscode: string;
    touristGuideStatusCodeMap: Map<string,string>;
    touristGuideLanguageMap: Map<string,string>;
    touristGuideCategoryMap: Map<string,string>;
    touristGuideAreaMap: Map<string,string>;
    cnst = cnst;
    ResultDto: ResultDto<TouristGuideItemDto>;
    touristGuides: Observable<TouristGuideItemDto[]>;
       
    p: Number = 1;
    //count: Number = 15;
    count: Number ;
    curentDisplayedPageNo1:number =1;
    curentDisplayedPageNo2:number  =15;

    totalRecords:number[];
    searchType: string;

    // Filtered Crieteria Parameter
    Licenseno: string;
    Status: string;
    Language: string;
    Category: string;
    Name: string;

    inputlicenseno:string;
    statuskeymodel:string ="ALL";
    languagekeymodel:string ="ALL";
    catogerykeymodel:string ="ALL";

    

    
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private touristGuideService: TouristGuideService,
    ) {}

    ngOnInit() {

        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        
        this.touristGuideStatusCodeMap = cnst.TouristGuideStatusCodeMap.tgStatusCodeMap;
        this.touristGuideLanguageMap = cnst.TouristGuideLanguages.tgLanguagesMap;    
        this.touristGuideCategoryMap = cnst.TouristGuideCategories.tgCategoryMap;
        this.touristGuideAreaMap = cnst.TouristGuideAreas.tgAreaMap;

        this.licensedtgfromSelectedIndex(this.curentDisplayedPageNo1);
  
    }

    getcurentDisplayedPageNo1(){
       return this.curentDisplayedPageNo1;
    }
    getcurentDisplayedPageNo2(){
        if(this.totalRecords.length<15)
        {
            return this.totalRecords.length;
        }
        else
        {
            return this.curentDisplayedPageNo2;
        }
        
     }  
    
    pageChanged(pageno:number){

        if(pageno===1)
        {
            this.curentDisplayedPageNo1 = pageno;
        }
        else
        {
            this.curentDisplayedPageNo1 = 15*(pageno-1)+1;
            this.curentDisplayedPageNo2 = 15*pageno;
        }
        this.loaddatafromselectedIndex(this.curentDisplayedPageNo1);
        return pageno;
    }

    loaddatafromselectedIndex(startindex:number)
    {
        if(this.searchType==="FilterBySearchparam")
        {
            let param1: string = this.Licenseno=="NA"?"":this.Licenseno;
            let param2: string = this.touristGuideStatusCodeMap.has(this.Status)?this.Status:"";
            let param3: string = this.touristGuideLanguageMap.has(this.Language)?this.Language:"";
            let param4: string = this.touristGuideCategoryMap.has(this.Category)?this.Category:"";
            this.filterdBySearchparamfromSelectedIndex(param1,param2,param3,param4,this.curentDisplayedPageNo1);
        }
        if(this.searchType==="FilterByName")
        {
            this.filterdByNamefromSelectedIndex(this.Name,this.curentDisplayedPageNo1);
        }
        else
        {
            this.licensedtgfromSelectedIndex(this.curentDisplayedPageNo1);         
        }
    }

    filterdBySearchparamfromSelectedIndex(param1:string,param2:string,param3:string,param4:string,startindex:number)
    {
        console.log("Going to Load Tourist Guide Based on Filtered Param and startIndex");
        this.searchType ="FilterBySearchparam";
                this.touristGuideService.getTouristGuidebyFilteredCrieteria(
                param1,param2,param3,param4,String(startindex)).subscribe(data =>{

                    this.ResultDto    =  data;
                    this.ResultDto.total = data.total;
                    this.touristGuides = this.ResultDto.records ; 
                    this.count = data.total;
                    //this.totalRecords = data.total;
                    // let i:number;
                    this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                    console.log("this.ResultDto.total"+data.total);
                    console.log("this.ResultDto.noOfPages"+data.noOfPages);
                
        });
    }

    filterdByNamefromSelectedIndex(name:string,startindex:number)
    {
        this.searchType ="FilterByName";
        console.log("Going to Load Tourist Guide Based on Name and startIndex");
        this.touristGuideService.getTouristGuidebyNameCrieteria(name,String(startindex)).subscribe(data =>{
            
                this.ResultDto    =  data;
                this.ResultDto.total = data.total;
                this.touristGuides = this.ResultDto.records ; 
                this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
                this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                console.log("this.ResultDto.total"+data.total);
                console.log("this.ResultDto.noOfPages"+data.noOfPages);      
        });
    }

    licensedtgfromSelectedIndex(startindex:number)
    {
        console.log("Going to Load Licensed Tourist Guide Based on startIndex");
            this.touristGuideService.getLicensedTouristGuideList(String(this.curentDisplayedPageNo1)).subscribe(data =>{

                this.ResultDto    =  data;
                this.ResultDto.total = data.total;
                this.touristGuides = this.ResultDto.records ; 
                this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
                this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                //console.log("this.totalRecords:"+this.totalRecords);
                console.log("this.ResultDto.total"+data.total);
                console.log("this.ResultDto.noOfPages"+data.noOfPages);    
            }); 
    }
    

    tgfilterdformbysearchcrieteria =new FormGroup({
        licenceNo:new FormControl(),
        statuskey:new FormControl(),
        languagekey:new FormControl(),
        categorykey:new FormControl()
    });

      tgfilterdformbytgName =new FormGroup({
        tgName:new FormControl()
    });

    getFilteredtgByName(getFilteredtgByName){

        console.log("getFilteredtgByName(getFilteredtgByName)");
        let tgName:string = this.tgfilterdformbytgName.get('tgName').value; 
        console.log("tgName**********"+tgName);
        console.log('/portal/touristGuidefiltered/:'+(tgName===null?"":tgName));
        this.filterdByNamefromSelectedIndex(tgName,this.curentDisplayedPageNo1);
    }

    getFilteredtgBySearchCrieteria(getFilteredtgBySearchCrieteria){

        
        console.log("getFilteredtgBySearchCrieteria(getFilteredtgBySearchCrieteria)");

        let licenseno:string  = this.tgfilterdformbysearchcrieteria.get('licenceNo').value;
        let statuskey:string  = this.tgfilterdformbysearchcrieteria.get('statuskey').value;
        let languagekey:string = this.tgfilterdformbysearchcrieteria.get('languagekey').value;
        let categorykey:string = this.tgfilterdformbysearchcrieteria.get('categorykey').value;  
        
        console.log("licenseno**********"+licenseno);
        console.log("status**********"+statuskey);
        console.log("language**********"+languagekey);
        console.log("category**********"+categorykey);
        
        let param1: string = this.Licenseno=="NA"?"":licenseno;
        let param2: string = this.touristGuideStatusCodeMap.has(statuskey)?statuskey:"";
        let param3: string = this.touristGuideLanguageMap.has(languagekey)?languagekey:"";
        let param4: string = this.touristGuideCategoryMap.has(categorykey)?categorykey:"";

        this.filterdBySearchparamfromSelectedIndex(param1,param2,param3,param4,this.curentDisplayedPageNo1);    
    }
    identify(index, item)
    {
        //console.log("index......."+index);
        //  if(index===0)
        //  return item.label;
    }

    resetDropdown()
    {
        this.inputlicenseno="";
        this.tgfilterdformbysearchcrieteria.controls['statuskey'].setValue("ALL");
        this.tgfilterdformbysearchcrieteria.controls['languagekey'].setValue("ALL");
        this.tgfilterdformbysearchcrieteria.controls['categorykey'].setValue("ALL");
    }

    changeDisplayView(viewtype:string)
    {
        if (viewtype==="cardview") 
        {
            for(let i=0;i<15;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-12");
                gridviewdiv.classList.remove("list");   //remove the class 
                parentDiv.classList.add("col-sm-4");
                gridviewdiv.classList.add("grid");   //add the class
            }
            document.getElementById("header_textid").style.display ="none";
        }
        if (viewtype==="lineview") 
        {
            for(let i=0;i<15;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-4");
                gridviewdiv.classList.remove("grid");   //remove the class
                parentDiv.classList.add("col-sm-12");
                gridviewdiv.classList.add("list");   //add the class
            }
            
            document.getElementById("header_textid").style.display ="block";
        }    
    }
      
}
