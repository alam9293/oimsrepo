export interface ApplicationDto {
    inBoundOperations: ListableDto[];
    outBoundOperations: ListableDto[];
    businessOperations: ListableDto[];
    areaOfFocus: ListableDto[];

}

export interface ListableDto {
    key: string;
    label: string;
    data: string;
}

export const NEW_APPLICATION: ApplicationDto =
{
    inBoundOperations: [{ key: null, label: null, data: null }],
    outBoundOperations: [{ key: null, label: null, data: null }],
    businessOperations: [{ key: null, label: null, data: null }],
    areaOfFocus: [{ key: null, label: null, data: null }],
};