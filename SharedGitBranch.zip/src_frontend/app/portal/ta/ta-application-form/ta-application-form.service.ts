import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaCreationService {

    constructor(private http: HttpClient) { }

    checkForPendingApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ta/creations/new');
    }

    getApp(id): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ta/creations/load/' + id);
    }

    save(application: any, triggerKe: boolean): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + '/ta/creations/save/' + triggerKe, application);
    }

    linkAppFee(appId: number, billRefNo: string): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + '/ta/creations/link-app-fee/' + appId + '/' + billRefNo, {});
    }

    savePaymentRequest(dto: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + '/ta/creations/save-payment-request', dto, { responseType: 'text' });
    }

    submit(application: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + '/ta/creations/submit', application);
    }







}
