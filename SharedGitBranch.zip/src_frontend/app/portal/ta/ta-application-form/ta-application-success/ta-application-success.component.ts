import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TaCreationService } from './../ta-application-form.service';
import * as cnst from '../../../../common/constants'

@Component({
    selector: 'app-ta-application-success',
    templateUrl: './ta-application-success.component.html',
    styleUrls: ['./ta-application-success.component.scss']
})
export class TaApplicationSuccessComponent implements OnInit {

    showAppSubmissionSuccessMessage: boolean = false;
    showAppFeeFailureMessage: boolean = false;
    showAppSubmissionFailureMessage: boolean = false;
    showLicenceFeeFailedMessage: boolean = false;
    showLicenceFeeSuccessMessage: boolean = false;
    application: any;
    cnst = cnst;
    payRefNo: any;
    paymentResult: any = { lastTxn: {} };
    showPaymentResult: boolean = true;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private service: TaCreationService,
    ) { }

    ngOnInit() {
        if (this.route.snapshot.paramMap.get('anyBillRefNo') != null) {
            if (this.route.snapshot.paramMap.get('paymentType') == 'appFee') {
                let appId = +this.route.snapshot.paramMap.get('appId');
                let billRefNo = +this.route.snapshot.paramMap.get('anyBillRefNo');
                this.service.getApp(appId).subscribe(data => {
                    this.application = data;
                    this.paymentResult = data.appFee;
                    if (this.application.appFee.statusCode == cnst.PaymentStatuses.PAYREQ_PAID) {
                        this.sanitize(this.application);
                        this.service.submit(this.application).subscribe(data => {
                            this.payRefNo = this.application.appFee.billRefNo;
                            this.showAppSubmissionSuccessMessage = true;
                        }, error => {
                            this.showAppSubmissionFailureMessage = true;
                        });
                    } else {
                        this.showAppSubmissionFailureMessage = true;

                    }
                })
            } else {
                let appId = +this.route.snapshot.paramMap.get('appId');
                this.service.getApp(appId).subscribe(data => {
                    this.application = data;
                    this.paymentResult = data.licenceFee;
                    this.payRefNo = this.application.licenceFee.billRefNo;
                    if (this.application.licenceFee.statusCode == cnst.PaymentStatuses.PAYREQ_PAID) {
                        this.showLicenceFeeSuccessMessage = true;
                    } else {
                        this.showLicenceFeeFailedMessage = true;
                    }
                })
            }

        } else {
            let appId = +this.route.snapshot.paramMap.get('appId');
            this.service.getApp(appId).subscribe(data => {
                this.application = data;
                this.showAppSubmissionSuccessMessage = true;
                this.showPaymentResult = false;
            })
        }

    }
    sanitize(application) {
        application.taKeyExecutive.involvement.taKeDeclarations.forEach(declaration => {
            declaration.clause.label = '';
            declaration.subscript = '';

        });

    }

    routeToAppPreview() {
        this.router.navigate(['/portal/ta-application-form'], { queryParams: { 'id': this.application.id, 'stepNo': 6 } });
    }

    print() {
        window.print();
    }
}
