import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, FormArray } from '@angular/forms';
import { CommonService, AlertService, AuthenticationService, EdhService, ErrorDialogService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil, ValidateEmail, ValidateAddressInput, ValidateAddressInputIncDash } from '../../../common/helper';
import { forkJoin, Observable } from 'rxjs';
import { TaChangeCompayDetailsService } from '../ta-change-compay-details/ta-change-compay-details.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TaFormHelperUtil } from '../ta-helper';

export interface ListableDto {
    key: string;
    label: string;
    data: string;
}
@Component({
    selector: 'app-ta-change-compay-details',
    templateUrl: './ta-change-compay-details.component.html',
    styleUrls: ['./ta-change-compay-details.component.scss'],
})

export class TaChangeCompayDetailsComponent implements OnInit {
    street: boolean = false;
    building: boolean = false;
    block: boolean = false;
    floor: boolean = false;
    unit: boolean = false;
    application: any = {
        applicationStatus: {},
        licenceStatus: {},
        currentDetails: {
            registeredAddress: {
                type: {},
                postal: '',
                formatted: String,
                block: String,
                street: String,
                building: String,
                unit: String,
                floor: String,
                premisesType: {}
            },
            operatingAddress: {
                postal: String,
                formatted: String,
                block: String,
                street: String,
                building: String,
                unit: String,
                floor:
                    String, premisesType: {}
            }
        },
        newDetails: {
            operatingAddress: {
                postal: String,
                block: String,
                street: String,
                building: String,
                unit: String,
                floor: String,
                premisesType: {}
            }
        }
    };
    edhData: any = { entity: { basic: {} }, appointments: {}, shareholders: {}, financials: {} };
    disable: boolean = false;
    isDataChanged: boolean = false;
    isCommonLoaded: boolean = false;
    isAppLoaded: boolean = false;
    isEdhLoaded: boolean = false;
    submitted: boolean = false;
    isTaActive: boolean = true;
    openBusinessEnitityFlag: boolean = true;
    openInboundOutboundServicesFlag: boolean = false;
    retrieveBusinessEnitityFlag: boolean = true;
    manualBusinessEnitityFlag: boolean = false;
    submittedFlag: boolean = false;
    preview: boolean = false;
    cnst = cnst;
    formBusinessEntity: FormGroup;

    countries: any = [];
    form_of_business: any = [];
    principle_activities: any = [];
    establishment_status: any = [];
    premises_types: any = [];
    business_services: any = [];
    ta_segmentation: any = [];
    address_types: any = [];
    business_constitution: any = [];

    postalCodeOAOptions = [];
    blkOAOptions = [];
    streetOAOptions = [];
    buidlingNameOAOptions = [];
    postalCodeRAOptions = [];
    blkRAOptions = [];
    streetRAOptions = [];
    buidlingNameRAOptions = [];

    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    fileForm: FormGroup;
    returnAppCode: string;
    unionMap = new Map<string, string>();

    constructor(
        private alertService: AlertService,
        public dialog: MatDialog,
        private router: Router,
        private route: ActivatedRoute,
        private formUtil: FormUtil,
        public snackBar: MatSnackBar,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private service: TaChangeCompayDetailsService,
        private authService: AuthenticationService,
        private edhService: EdhService,
        private fileUtil: FileUtil,
        private errorDialogService: ErrorDialogService,
        private taFormHelperUtil: TaFormHelperUtil
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.formBusinessEntity.pristine;
    }

    ngOnInit() {
        this.isTaActive = this.authService.isTaActive();
        this.returnAppCode = this.route.snapshot.queryParams.returnApp;
        if (!this.isTaActive) {
            setTimeout(() => this.errorDialogService.openDialog({
                reason: cnst.Messages.MSG_INVALID_ACCESS,
                routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
            }))
        }
        this.loadCommonTypes();
        this.initiateBusinessEntityForm();
        // this.retrieveBusinessEnitityFlag = false;
        // this.manualBusinessEnitityFlag = true;
        if (this.route.snapshot.paramMap.get('appId') != null) {
            this.getApplication(this.route.snapshot.paramMap.get('appId'));
        }
        else {
            this.checkForCompanyUpdateBusinessEntity();
        }

    }
    populateEmptyData() {
        this.application.newDetails.operatingAddress = { postal: '', formatted: '', block: '', street: '', building: '', unit: '', floor: '', premisesType: {}, type: {} };
        this.application.newDetails.registeredAddress = { postal: '', formatted: '', block: '', street: '', building: '', unit: '', floor: '', premisesType: {}, type: {} };
    }
    //populate into application to prevent edh codes from changes in UI
    // some hard-coded
    loadAppEdh() {

        forkJoin([
            this.edhService.getEdhEntity(),
            this.edhService.getEdhEntityFinancials(),
        ]).subscribe(data => {

            //getEdhEntity()
            if (data[0].errorMessage) {
                this.isEdhLoaded = false;
            }
            else {
                this.edhData.entity = data[0];
                if (data[0].basic.entityName) {
                    this.application.newDetails.companyName = this.edhData.entity.basic.entityName;
                    this.formBusinessEntity.get('companyName').setValue(this.edhData.entity.basic.entityName);
                }
                else {
                    this.application.newDetails.companyName = this.application.currentDetails.companyName;
                    this.formBusinessEntity.get('companyName').setValue(this.application.currentDetails.companyName);
                }
                if (data[0].basic.uen) {
                    this.application.newDetails.uen = this.edhData.entity.basic.uen;
                    this.formBusinessEntity.get('uen').setValue(this.edhData.entity.basic.uen);
                }
                else {
                    this.application.newDetails.uen = this.application.currentDetails.uen;
                    this.formBusinessEntity.get('uen').setValue(this.application.newDetails.uen);
                }
                //Hard-code and map to same as current first
                this.application.newDetails.establishmentStatus = { key: this.application.currentDetails.establishmentStatus.key, label: this.application.currentDetails.establishmentStatus.label };
                this.application.newDetails.formOfBusiness = { key: this.application.currentDetails.formOfBusiness.key, label: this.application.currentDetails.formOfBusiness.label };
                this.application.newDetails.businessConstitution = { key: this.application.currentDetails.businessConstitution.key, label: this.application.currentDetails.businessConstitution.label };

                this.application.newDetails.placeIncorporated = { key: this.application.currentDetails.placeIncorporated.key, label: this.application.currentDetails.placeIncorporated.label };
                this.application.newDetails.principleActivities = { key: this.application.currentDetails.principleActivities.key, label: this.application.currentDetails.principleActivities.label };
                this.application.newDetails.secondaryPrincipleActivities = { key: this.application.currentDetails.secondaryPrincipleActivities.key, label: this.application.currentDetails.secondaryPrincipleActivities.label };


                this.formBusinessEntity.get('formOfBusiness').get('key').setValue(this.edhData.entity.basic.entityType);
                this.formBusinessEntity.get('businessConstitution').get('key').setValue(this.edhData.entity.basic.businessConstitutionCode);
                this.formBusinessEntity.get('establishmentStatus').get('key').setValue(this.edhData.entity.basic.entityStatusCode);
                this.formBusinessEntity.get('principleActivities').get('key').setValue(this.edhData.entity.basic.primaryActivityCode);
                this.formBusinessEntity.get('secondaryPrincipleActivities').get('key').setValue(this.edhData.entity.basic.secondaryActivityCode);

                this.formBusinessEntity.get('registeredAddress').get('type').get('key').setValue(this.edhData.entity.addresses[0].type);
                if (data[0].addresses[0].type == cnst.AddressTypes.ADDR_LOCAL) {
                    this.application.newDetails.registeredAddress.block = this.edhData.entity.addresses[0].houseBlockNumber;
                    this.formBusinessEntity.get('registeredAddress').get('block').setValue(this.edhData.entity.addresses[0].houseBlockNumber);
                    this.application.newDetails.registeredAddress.building = this.edhData.entity.addresses[0].buildingName;
                    this.formBusinessEntity.get('registeredAddress').get('building').setValue(this.edhData.entity.addresses[0].buildingName);
                    this.application.newDetails.registeredAddress.floor = this.edhData.entity.addresses[0].levelNumber;
                    this.formBusinessEntity.get('registeredAddress').get('floor').setValue(this.edhData.entity.addresses[0].levelNumber);
                    this.application.newDetails.registeredAddress.postal = this.edhData.entity.addresses[0].postalCode;
                    this.formBusinessEntity.get('registeredAddress').get('postal').setValue(this.edhData.entity.addresses[0].postalCode);
                    this.application.newDetails.registeredAddress.street = this.edhData.entity.addresses[0].streetName;
                    this.formBusinessEntity.get('registeredAddress').get('street').setValue(this.edhData.entity.addresses[0].streetName);
                    this.application.newDetails.registeredAddress.unit = this.edhData.entity.addresses[0].unitNumber;
                    this.formBusinessEntity.get('registeredAddress').get('unit').setValue(this.edhData.entity.addresses[0].unitNumber);
                }
                else {
                    this.application.newDetails.registeredAddress.foreignLine1 = this.edhData.entity.addresses[0].foreignLine1;
                    this.formBusinessEntity.get('registeredAddress').get('foreignLine1').setValue(data[0].addresses[0].unformattedAddressLines[0]);
                    this.application.newDetails.registeredAddress.foreignLine2 = this.edhData.entity.addresses[0].foreignLine2;
                    this.formBusinessEntity.get('registeredAddress').get('foreignLine2').setValue(data[0].addresses[0].unformattedAddressLines[1]);
                    this.application.newDetails.registeredAddress.foreignLine3 = '';
                    this.formBusinessEntity.get('registeredAddress').get('foreignLine3').setValue('');
                }
                this.isEdhLoaded = true;
            }

            this.formBusinessEntity.get('isEdhPopulated').setValue(this.isEdhLoaded);

            //getEdhEntityFinancials
            if (this.isEdhLoaded) {
                if (data[1].errorMessage) {
                    this.alertService.clear();
                    this.isEdhLoaded = false;
                }
                else {
                    this.edhData.financials = data[1];
                    if (data[1].capitals[0]) {
                        this.application.newDetails.paidUpCapital = this.edhData.financials.capitals[0].paidUpCapitalAmount ? this.edhData.financials.capitals[0].paidUpCapitalAmount : 0;
                        this.formBusinessEntity.get('paidUpCapital').setValue(this.application.newDetails.paidUpCapital);
                    }
                    else {
                        this.application.newDetails.paidUpCapital = 0;
                        this.formBusinessEntity.get('paidUpCapital').setValue(this.application.newDetails.paidUpCapital);
                    }
                    this.isEdhLoaded = true;
                }
            }

            this.formBusinessEntity.get('isEdhPopulated').setValue(this.isEdhLoaded);

            this.formBusinessEntity.get('companyDetailsDocument').disable();
            this.formControlValueChanged();
            this.disable = true;

            if (!this.isEdhLoaded) {
                this.alertService.error(cnst.TaAlertMessages.EDH_ERROR);
                this.clearAppEdh();
            }
        });
    }

    clearAppEdh() {
        this.application.newDetails.companyName = this.application.currentDetails.companyName;
        this.formBusinessEntity.get('companyName').setValue(this.application.currentDetails.companyName);

        this.application.newDetails.uen = this.application.currentDetails.uen;
        this.formBusinessEntity.get('uen').setValue(this.application.newDetails.uen);


        this.application.newDetails.establishmentStatus = { key: this.application.currentDetails.establishmentStatus.key, label: this.application.currentDetails.establishmentStatus.label };
        this.application.newDetails.formOfBusiness = { key: this.application.currentDetails.formOfBusiness.key, label: this.application.currentDetails.formOfBusiness.label };
        this.application.newDetails.businessConstitution = { key: this.application.currentDetails.businessConstitution.key, label: this.application.currentDetails.businessConstitution.label };
        this.application.newDetails.placeIncorporated = { key: this.application.currentDetails.placeIncorporated.key, label: this.application.currentDetails.placeIncorporated.label };
        this.application.newDetails.principleActivities = { key: this.application.currentDetails.principleActivities.key, label: this.application.currentDetails.principleActivities.label };
        this.application.newDetails.secondaryPrincipleActivities = { key: this.application.currentDetails.secondaryPrincipleActivities.key, label: this.application.currentDetails.secondaryPrincipleActivities.label };
        this.formBusinessEntity.get('formOfBusiness').get('key').setValue(this.application.currentDetails.formOfBusiness.key);
        this.formBusinessEntity.get('businessConstitution').get('key').setValue(this.application.currentDetails.businessConstitution.key);
        this.formBusinessEntity.get('establishmentStatus').get('key').setValue(this.application.currentDetails.establishmentStatus.key);
        this.formBusinessEntity.get('principleActivities').get('key').setValue(this.application.currentDetails.principleActivities.key);
        this.formBusinessEntity.get('secondaryPrincipleActivities').get('key').setValue(this.application.currentDetails.principleActivities.key);

        this.application.newDetails.registeredAddress.type.key = this.application.currentDetails.registeredAddress.type.key;
        this.formBusinessEntity.get('registeredAddress').get('type').get('key').setValue(this.application.currentDetails.registeredAddress.type.key);
        if (this.application.currentDetails.registeredAddress.type.key == cnst.AddressTypes.ADDR_LOCAL) {
            this.application.newDetails.registeredAddress.block = this.application.currentDetails.registeredAddress.block;
            this.formBusinessEntity.get('registeredAddress').get('block').setValue(this.application.currentDetails.registeredAddress.block);
            this.application.newDetails.registeredAddress.building = this.application.currentDetails.registeredAddress.building;
            this.formBusinessEntity.get('registeredAddress').get('building').setValue(this.application.currentDetails.registeredAddress.building);
            this.application.newDetails.registeredAddress.floor = this.application.currentDetails.registeredAddress.floor;
            this.formBusinessEntity.get('registeredAddress').get('floor').setValue(this.application.currentDetails.registeredAddress.floor);
            this.application.newDetails.registeredAddress.postal = this.application.currentDetails.registeredAddress.postal;
            this.formBusinessEntity.get('registeredAddress').get('postal').setValue(this.application.currentDetails.registeredAddress.postal);
            this.application.newDetails.registeredAddress.street = this.application.currentDetails.registeredAddress.street;
            this.formBusinessEntity.get('registeredAddress').get('street').setValue(this.application.currentDetails.registeredAddress.street);
            this.application.newDetails.registeredAddress.unit = this.application.currentDetails.registeredAddress.unit;
            this.formBusinessEntity.get('registeredAddress').get('unit').setValue(this.application.currentDetails.registeredAddress.unit);
        }
        else {
            this.application.newDetails.registeredAddress.foreignLine1 = this.application.currentDetails.registeredAddress.foreignLine1;
            this.formBusinessEntity.get('registeredAddress').get('foreignLine1').setValue(this.application.currentDetails.registeredAddress.foreignLine1);
            this.application.newDetails.registeredAddress.foreignLine2 = this.application.currentDetails.registeredAddress.foreignLine2;
            this.formBusinessEntity.get('registeredAddress').get('foreignLine2').setValue(this.application.currentDetails.registeredAddress.foreignLine2);
            this.application.newDetails.registeredAddress.foreignLine3 = this.application.currentDetails.registeredAddress.foreignLine3;
            this.formBusinessEntity.get('registeredAddress').get('foreignLine3').setValue(this.application.currentDetails.registeredAddress.foreignLine3);
        }
        this.application.newDetails.paidUpCapital = this.application.currentDetails.paidUpCapital;
        this.formBusinessEntity.get('paidUpCapital').setValue(this.application.currentDetails.paidUpCapital);


        this.isEdhLoaded = false;
        this.formBusinessEntity.get('isEdhPopulated').setValue(this.isEdhLoaded);
        this.formBusinessEntity.get('companyDetailsDocument').enable();
        this.formControlValueChanged();
        this.disable = false;
    }

    retrieveInputBusinessEnitity() {
        this.alertService.clear();

        this.setupForm(this.application);
        if (this.application.isEdhPopulated) {
            this.disable = true;
            this.loadAppEdh();
        } else {
            this.isEdhLoaded = true;
        }
    }

    setupForm(application: any) {
        this.initiateBusinessEntityForm();

        if (!this.application.currentDetails.formOfBusiness || !this.application.currentDetails.formOfBusiness.key) {
            this.application.currentDetails.formOfBusiness = { key: '', label: '' };
        }
        if (!this.application.newDetails.formOfBusiness || !this.application.newDetails.formOfBusiness.key) {
            this.application.newDetails.formOfBusiness = { key: '', label: '' };
        }
        if (!this.application.currentDetails.businessConstitution || !this.application.currentDetails.businessConstitution.key) {
            this.application.currentDetails.businessConstitution = { key: '', label: '' };
        }
        if (!this.application.newDetails.businessConstitution || !this.application.newDetails.businessConstitution.key) {
            this.application.newDetails.businessConstitution = { key: '', label: '' };
        }
        if (!this.application.currentDetails.establishmentStatus || !this.application.currentDetails.establishmentStatus.key) {
            this.application.currentDetails.establishmentStatus = { key: '', label: '' };
        }
        if (!this.application.newDetails.establishmentStatus || !this.application.newDetails.establishmentStatus.key) {
            this.application.newDetails.establishmentStatus = { key: '', label: '' };
        }
        if (!this.application.currentDetails.principleActivities || !this.application.currentDetails.principleActivities.key) {
            this.application.currentDetails.principleActivities = { key: '', label: '' };
        }
        if (!this.application.newDetails.principleActivities || !this.application.newDetails.principleActivities.key) {
            this.application.newDetails.principleActivities = { key: '', label: '' };
        }
        if (!this.application.currentDetails.secondaryPrincipleActivities || !this.application.currentDetails.secondaryPrincipleActivities.key) {
            this.application.currentDetails.secondaryPrincipleActivities = { key: '', label: '' };
        }
        if (!this.application.newDetails.secondaryPrincipleActivities || !this.application.newDetails.secondaryPrincipleActivities.key) {
            this.application.newDetails.secondaryPrincipleActivities = { key: '', label: '' };
        }
        if (!this.application.currentDetails.placeIncorporated || !this.application.currentDetails.placeIncorporated.key) {
            this.application.currentDetails.placeIncorporated = { key: '', label: '' };
        }
        if (!this.application.newDetails.placeIncorporated || !this.application.newDetails.placeIncorporated.key) {
            this.application.newDetails.placeIncorporated = { key: '', label: '' };
        }

        if (!this.application.currentDetails.taSegmentation || !this.application.currentDetails.taSegmentation.key) {
            this.application.currentDetails.taSegmentation = { key: '', label: '' };
        }
        if (!this.application.newDetails.taSegmentation || !this.application.newDetails.taSegmentation.key) {
            this.application.newDetails.taSegmentation = { key: '', label: '' };
        }

        if (this.application.currentDetails.registeredAddress) {
            if (!this.application.currentDetails.registeredAddress.premisesType || !this.application.currentDetails.registeredAddress.premisesType.key) {
                this.application.currentDetails.registeredAddress.premisesType = { key: '', label: '' };
            }
        }

        if (this.application.newDetails.registeredAddress) {
            if (!this.application.newDetails.registeredAddress.premisesType || !this.application.newDetails.registeredAddress.premisesType.key) {
                this.application.newDetails.registeredAddress.premisesType = { key: '', label: '' };
            }
        }

        if (this.application.currentDetails.operatingAddress) {
            if (!this.application.currentDetails.operatingAddress.premisesType || !this.application.currentDetails.operatingAddress.premisesType.key) {
                this.application.currentDetails.operatingAddress.premisesType = { key: '', label: '' };
            }
        }

        if (this.application.newDetails.operatingAddress) {
            if (!this.application.newDetails.operatingAddress.premisesType || !this.application.newDetails.operatingAddress.premisesType.key) {
                this.application.newDetails.operatingAddress.premisesType = { key: '', label: '' };
            }
        }
        this.formBusinessEntity.patchValue(application);

        if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
            this.formBusinessEntity.get('companyName').setValue(application.newDetails.companyName);
            this.formBusinessEntity.get('formOfBusiness').patchValue(application.newDetails.formOfBusiness);
            this.formBusinessEntity.get('businessConstitution').patchValue(application.newDetails.businessConstitution);
            this.formBusinessEntity.get('principleActivities').patchValue(application.newDetails.principleActivities);
            this.formBusinessEntity.get('secondaryPrincipleActivities').patchValue(application.newDetails.secondaryPrincipleActivities);
            this.formBusinessEntity.get('placeIncorporated').patchValue(application.newDetails.placeIncorporated);
            this.formBusinessEntity.get('establishmentStatus').patchValue(application.newDetails.establishmentStatus);
            this.formBusinessEntity.get('paidUpCapital').setValue(application.newDetails.paidUpCapital);
            this.formBusinessEntity.get('websiteUrl').setValue(application.newDetails.websiteUrl);
            this.formBusinessEntity.get('emailAddress').setValue(application.newDetails.emailAddress);
            this.formBusinessEntity.get('contactNo').setValue(application.newDetails.contactNo);
            this.formBusinessEntity.get('faxNo').setValue(application.newDetails.faxNo);
            this.formBusinessEntity.get('registeredAddress').patchValue(application.newDetails.registeredAddress);
            this.formBusinessEntity.get('operatingAddress').patchValue(application.newDetails.operatingAddress);
            this.formBusinessEntity.get('taSegmentation').patchValue(application.newDetails.taSegmentation);
            if (application.companyDetailsDocument) {
                this.formBusinessEntity.patchValue({ companyDetailsDocument: application.companyDetailsDocument });
            }
            if (application.acra) {
                this.formBusinessEntity.patchValue({ acra: application.acra });
            }
        }
        else {
            this.formBusinessEntity.get('companyName').setValue(application.currentDetails.companyName);
            this.formBusinessEntity.get('formOfBusiness').patchValue(application.currentDetails.formOfBusiness);
            this.formBusinessEntity.get('businessConstitution').patchValue(application.currentDetails.businessConstitution);
            this.formBusinessEntity.get('principleActivities').patchValue(application.currentDetails.principleActivities);
            this.formBusinessEntity.get('secondaryPrincipleActivities').patchValue(application.currentDetails.secondaryPrincipleActivities);
            this.formBusinessEntity.get('placeIncorporated').patchValue(application.currentDetails.placeIncorporated);
            this.formBusinessEntity.get('establishmentStatus').patchValue(application.currentDetails.establishmentStatus);
            this.formBusinessEntity.get('paidUpCapital').setValue(application.currentDetails.paidUpCapital);
            this.formBusinessEntity.get('websiteUrl').setValue(application.currentDetails.websiteUrl);
            this.formBusinessEntity.get('emailAddress').setValue(application.currentDetails.emailAddress);
            this.formBusinessEntity.get('contactNo').setValue(application.currentDetails.contactNo);
            this.formBusinessEntity.get('faxNo').setValue(application.currentDetails.faxNo);
            this.formBusinessEntity.get('registeredAddress').patchValue(application.currentDetails.registeredAddress);
            this.formBusinessEntity.get('operatingAddress').patchValue(application.currentDetails.operatingAddress);
            this.formBusinessEntity.get('taSegmentation').patchValue(application.currentDetails.taSegmentation);
            this.formBusinessEntity.patchValue({ companyDetailsDocument: application.companyDetailsDocument });
            this.formBusinessEntity.patchValue({ acra: application.acra });
        }
    }
    openConfirmationBusinessEnitityDialog() {
        this.preview = true;
        this.submittedFlag = true;
    }
    operatingAddressControlValueChanged() {
        this.formBusinessEntity.get('operatingAddress').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (this.formBusinessEntity.get('isOppAddSameAsRegAdd').value == false) {
                    if (postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                        this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                            if (data) {
                                this.blkOAOptions = [];
                                this.streetOAOptions = [];
                                this.buidlingNameOAOptions = [];
                                this.postalCodeOAOptions = [];
                                var addrResults = data['results'];

                                if (addrResults.length > 0) {
                                    var blkNo = addrResults[0]['BLK_NO'].trim();
                                    var roadName = addrResults[0]['ROAD_NAME'].trim();
                                    var building = addrResults[0]['BUILDING'].trim();

                                    this.formBusinessEntity.get('operatingAddress').get('block').setValue(blkNo);
                                    this.formBusinessEntity.get('operatingAddress').get('street').setValue(roadName);
                                    this.formBusinessEntity.get('operatingAddress').get('building').setValue(building);
                                }
                                data['results'].forEach(element => {
                                    this.blkOAOptions.push(element['BLK_NO']);
                                    this.streetOAOptions.push(element['ROAD_NAME']);
                                    this.buidlingNameOAOptions.push(element['BUILDING']);
                                });
                                this.blkOAOptions = Array.from(new Set(this.blkOAOptions));
                                this.streetOAOptions = Array.from(new Set(this.streetOAOptions));
                                this.buidlingNameOAOptions = Array.from(new Set(this.buidlingNameOAOptions));
                            }
                        });
                    }
                }

            });
    }
    registeredAddressControlValueChanged() {
        this.formBusinessEntity.get('registeredAddress').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (this.manualBusinessEnitityFlag) {
                    if (postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                        this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                            if (data) {
                                this.blkRAOptions = [];
                                this.streetRAOptions = [];
                                this.buidlingNameRAOptions = [];
                                this.postalCodeRAOptions = [];
                                var addrResults = data['results'];

                                if (addrResults.length > 0) {
                                    var blkNo = addrResults[0]['BLK_NO'].trim();
                                    var roadName = addrResults[0]['ROAD_NAME'].trim();
                                    var building = addrResults[0]['BUILDING'].trim();

                                    this.formBusinessEntity.get('registeredAddress').get('block').setValue(blkNo);
                                    this.formBusinessEntity.get('registeredAddress').get('street').setValue(roadName);
                                    this.formBusinessEntity.get('registeredAddress').get('building').setValue(building);
                                }
                                data['results'].forEach(element => {
                                    this.blkRAOptions.push(element['BLK_NO']);
                                    this.streetRAOptions.push(element['ROAD_NAME']);
                                    this.buidlingNameRAOptions.push(element['BUILDING']);
                                });
                                this.blkRAOptions = Array.from(new Set(this.blkRAOptions));
                                this.streetRAOptions = Array.from(new Set(this.streetRAOptions));
                                this.buidlingNameRAOptions = Array.from(new Set(this.buidlingNameRAOptions));
                            }
                        });
                    }
                }

            });
    }

    formControlValueChanged() {
        this.formBusinessEntity.get('isOppAddSameAsRegAdd').valueChanges.subscribe(
            (isSame: any) => {
                if (isSame == true) {
                    this.formBusinessEntity.get('operatingAddress').patchValue(this.formBusinessEntity.getRawValue().registeredAddress);
                    this.street = false;
                    this.building = false;
                    this.block = false;
                    this.floor = false;
                    this.unit = false;
                    this.formBusinessEntity.get('companyDetailsDocument').disable();
                }

            });
        this.formBusinessEntity.get('isRALocal').valueChanges.subscribe(
            (isSame: any) => {
                if (isSame == false) {
                    this.formBusinessEntity.get('isOppAddSameAsRegAdd').patchValue(false);
                }

            });
        this.formBusinessEntity.get('registeredAddress').get('type').get('key').valueChanges.subscribe(
            (data: any) => {
                if (data == cnst.AddressTypes.ADDR_LOCAL) {
                    this.formBusinessEntity.get('isRALocal').patchValue(true);
                } else if (data == cnst.AddressTypes.ADDR_FOREIGN) {
                    this.formBusinessEntity.get('isRALocal').patchValue(false);
                }

            });

        this.formBusinessEntity.get('operatingAddress').get('block').valueChanges.subscribe(
            (data: any) => {
                if (this.application.currentDetails.operatingAddress.block) {
                    this.application.currentDetails.operatingAddress.block = ''
                }
                if (this.application.currentDetails.operatingAddress.block != data) {
                    this.block = true;
                }
                else {
                    this.block = false;
                }
                if (this.street || this.building || this.block || this.floor || this.unit) {
                    this.formBusinessEntity.get('companyDetailsDocument').enable();
                }
                else {
                    this.formBusinessEntity.get('companyDetailsDocument').disable();
                }

            });
        this.formBusinessEntity.get('operatingAddress').get('floor').valueChanges.subscribe(
            (data: any) => {
                if (this.application.currentDetails.operatingAddress.floor) {
                    this.application.currentDetails.operatingAddress.floor = ''
                }
                if (this.application.currentDetails.operatingAddress.floor != data) {
                    this.floor = true;
                }
                else {
                    this.floor = false;
                }
                if (this.street || this.building || this.block || this.floor || this.unit) {
                    this.formBusinessEntity.get('companyDetailsDocument').enable();
                }
                else {
                    this.formBusinessEntity.get('companyDetailsDocument').disable();
                }

            });
        this.formBusinessEntity.get('operatingAddress').get('unit').valueChanges.subscribe(
            (data: any) => {
                if (this.application.currentDetails.operatingAddress.unit) {
                    this.application.currentDetails.operatingAddress.unit = ''
                }
                if (this.application.currentDetails.operatingAddress.unit != data) {
                    this.unit = true;
                }
                else {
                    this.unit = false;
                }
                if (this.street || this.building || this.block || this.floor || this.unit) {
                    this.formBusinessEntity.get('companyDetailsDocument').enable();
                }
                else {
                    this.formBusinessEntity.get('companyDetailsDocument').disable();
                }

            });
        this.formBusinessEntity.get('operatingAddress').get('street').valueChanges.subscribe(
            (data: any) => {
                if (this.application.currentDetails.operatingAddress.street) {
                    this.application.currentDetails.operatingAddress.street = ''
                }
                if (this.application.currentDetails.operatingAddress.street != data) {
                    this.street = true;
                }
                else {
                    this.street = false;
                }
                if (this.street || this.building || this.block || this.floor || this.unit) {
                    this.formBusinessEntity.get('companyDetailsDocument').enable();
                }
                else {
                    this.formBusinessEntity.get('companyDetailsDocument').disable();
                }

            });
        this.formBusinessEntity.get('operatingAddress').get('building').valueChanges.subscribe(
            (data: any) => {
                if (this.application.currentDetails.operatingAddress.building) {
                    this.application.currentDetails.operatingAddress.building = ''
                }

                if (this.application.currentDetails.operatingAddress.building != data) {
                    this.building = true;
                }
                else {
                    this.building = false;
                }
                if (this.street || this.building || this.block || this.floor || this.unit) {
                    this.formBusinessEntity.get('companyDetailsDocument').enable();
                }
                else {
                    this.formBusinessEntity.get('companyDetailsDocument').disable();
                }

            });
        if (this.manualBusinessEnitityFlag) {
            this.operatingAddressControlValueChanged();
            this.registeredAddressControlValueChanged();
        }
        else {
            this.operatingAddressControlValueChanged();

        }
    }

    checkOperatingAddressBusinessEntity() {
        if (this.formBusinessEntity.get('isOppAddSameAsRegAdd').value) {
            this.formBusinessEntity.get('operatingAddress').get('postal').setValue(this.formBusinessEntity.get('registeredAddress').get('postal').value);
            this.formBusinessEntity.get('operatingAddress').get('block').setValue(this.formBusinessEntity.get('registeredAddress').get('block').value);
            this.formBusinessEntity.get('operatingAddress').get('street').setValue(this.formBusinessEntity.get('registeredAddress').get('street').value);
            this.formBusinessEntity.get('operatingAddress').get('building').setValue(this.formBusinessEntity.get('registeredAddress').get('building').value);
            this.formBusinessEntity.get('operatingAddress').get('floor').setValue(this.formBusinessEntity.get('registeredAddress').get('floor').value);
            this.formBusinessEntity.get('operatingAddress').get('unit').setValue(this.formBusinessEntity.get('registeredAddress').get('unit').value);
            this.formBusinessEntity.get('operatingAddress').get('foreignLine1').setValue(this.formBusinessEntity.get('registeredAddress').get('foreignLine1').value);
            this.formBusinessEntity.get('operatingAddress').get('foreignLine2').setValue(this.formBusinessEntity.get('registeredAddress').get('foreignLine2').value);
            this.formBusinessEntity.get('operatingAddress').get('foreignLine3').setValue(this.formBusinessEntity.get('registeredAddress').get('foreignLine3').value);
            this.formBusinessEntity.get('operatingAddress').get('premisesType').setValue(this.formBusinessEntity.get('registeredAddress').get('premisesType').value);
        }

        if (this.formBusinessEntity.get('operatingAddress').get('street').value != this.application.currentDetails.operatingAddress.street) {
            this.application.newDetails.operatingAddress.street = this.formBusinessEntity.get('operatingAddress').get('street').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.street = this.application.currentDetails.operatingAddress.street;
        }

        if (this.formBusinessEntity.get('operatingAddress').get('block').value != this.application.currentDetails.operatingAddress.block) {
            this.application.newDetails.operatingAddress.block = this.formBusinessEntity.get('operatingAddress').get('block').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.block = this.application.currentDetails.operatingAddress.block;
        }

        if (this.formBusinessEntity.get('operatingAddress').get('building').value != this.application.currentDetails.operatingAddress.building) {
            this.application.newDetails.operatingAddress.building = this.formBusinessEntity.get('operatingAddress').get('building').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.building = this.application.currentDetails.operatingAddress.building;
        }
        if (this.formBusinessEntity.get('operatingAddress').get('floor').value != this.application.currentDetails.operatingAddress.floor) {
            this.application.newDetails.operatingAddress.floor = this.formBusinessEntity.get('operatingAddress').get('floor').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.floor = this.application.currentDetails.operatingAddress.floor;
        }
        if (this.formBusinessEntity.get('operatingAddress').get('unit').value != this.application.currentDetails.operatingAddress.unit) {
            this.application.newDetails.operatingAddress.unit = this.formBusinessEntity.get('operatingAddress').get('unit').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.unit = this.application.currentDetails.operatingAddress.unit;
        }
        if (this.formBusinessEntity.get('operatingAddress').get('foreignLine1').value != this.application.currentDetails.operatingAddress.foreignLine1) {
            this.application.newDetails.operatingAddress.foreignLine1 = this.formBusinessEntity.get('operatingAddress').get('foreignLine1').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.foreignLine1 = this.application.currentDetails.operatingAddress.foreignLine1;
        }
        if (this.formBusinessEntity.get('operatingAddress').get('foreignLine2').value != this.application.currentDetails.operatingAddress.foreignLine2) {
            this.application.newDetails.operatingAddress.foreignLine2 = this.formBusinessEntity.get('operatingAddress').get('foreignLine2').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.foreignLine2 = this.application.currentDetails.operatingAddress.foreignLine2;
        }
        if (this.formBusinessEntity.get('operatingAddress').get('foreignLine3').value != this.application.currentDetails.operatingAddress.foreignLine3) {
            this.application.newDetails.operatingAddress.foreignLine3 = this.formBusinessEntity.get('operatingAddress').get('foreignLine3').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.foreignLine3 = this.application.currentDetails.operatingAddress.foreignLine3;
        }
        if (this.formBusinessEntity.get('operatingAddress').get('postal').value != this.application.currentDetails.operatingAddress.postal) {
            this.application.newDetails.operatingAddress.postal = this.formBusinessEntity.get('operatingAddress').get('postal').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.postal = this.application.currentDetails.operatingAddress.postal;
        }

        if (this.formBusinessEntity.get('operatingAddress').get('premisesType').get('key').value != this.application.currentDetails.operatingAddress.premisesType.key) {
            this.application.newDetails.operatingAddress.premisesType = { key: '', label: '' };
            this.application.newDetails.operatingAddress.premisesType.key = this.formBusinessEntity.get('operatingAddress').get('premisesType').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.operatingAddress.premisesType = this.application.currentDetails.operatingAddress.premisesType;
        }

    }
    onSubmitBusinessEntity() {

        this.listenTenancyDocRequiredValidator();
        this.isDataChanged = false;
        //Compare with form
        if (this.formBusinessEntity.get('companyName').value != this.application.currentDetails.companyName) {
            this.application.newDetails.companyName = this.formBusinessEntity.get('companyName').value;
            this.isDataChanged = true;
        } else {
            this.application.newDetails.companyName = this.application.currentDetails.companyName;
        }
        if (this.formBusinessEntity.get('principleActivities').get('key').value != this.application.currentDetails.principleActivities.key) {
            this.application.newDetails.principleActivities.key = this.formBusinessEntity.get('principleActivities').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.principleActivities = this.application.currentDetails.principleActivities;
        }
        // console.log('establishmentStatus');
        // console.log(this.application.currentDetails.establishmentStatus);
        // console.log(this.formBusinessEntity.get('establishmentStatus').get('key').value);
        // if ((this.application.currentDetails.establishmentStatus == null && this.formBusinessEntity.get('establishmentStatus').get('key').value) || (this.formBusinessEntity.get('establishmentStatus').get('key').value && this.formBusinessEntity.get('establishmentStatus').get('key').value != this.application.currentDetails.establishmentStatus.key)) {
        //     this.application.newDetails.establishmentStatus = { key: '', label: '' };
        //     this.application.newDetails.establishmentStatus.key = this.formBusinessEntity.get('establishmentStatus').get('key').value;
        //     this.isDataChanged = true;
        //     console.log('establishmentStatus');
        //     console.log(this.application.currentDetails.establishmentStatus);
        //     console.log(this.application.newDetails.establishmentStatus);
        // }
        // else {
        //     this.application.newDetails.establishmentStatus = this.application.currentDetails.establishmentStatus;
        // }
        if (this.formBusinessEntity.get('establishmentStatus').get('key').value != this.application.currentDetails.establishmentStatus.key) {
            this.application.newDetails.establishmentStatus.key = this.formBusinessEntity.get('establishmentStatus').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.establishmentStatus = this.application.currentDetails.establishmentStatus;
        }
        if (this.formBusinessEntity.get('secondaryPrincipleActivities').get('key').value != this.application.currentDetails.secondaryPrincipleActivities.key) {
            this.application.newDetails.secondaryPrincipleActivities.key = this.formBusinessEntity.get('secondaryPrincipleActivities').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.secondaryPrincipleActivities = this.application.currentDetails.secondaryPrincipleActivities;
        }
        if (this.formBusinessEntity.get('placeIncorporated').get('key').value != this.application.currentDetails.placeIncorporated.key) {
            this.application.newDetails.placeIncorporated = { key: '', label: '' };
            this.application.newDetails.placeIncorporated.key = this.formBusinessEntity.get('placeIncorporated').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.placeIncorporated = this.application.currentDetails.placeIncorporated;
        }

        if ((this.application.currentDetails.taSegmentation == null && this.formBusinessEntity.get('taSegmentation').get('key').value) || (this.formBusinessEntity.get('taSegmentation').get('key').value && this.formBusinessEntity.get('taSegmentation').get('key').value != this.application.currentDetails.taSegmentation.key)) {
            this.application.newDetails.taSegmentation = { key: '', label: '' };
            this.application.newDetails.taSegmentation.key = this.formBusinessEntity.get('taSegmentation').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.taSegmentation = this.application.currentDetails.taSegmentation;
        }

        // if (this.formBusinessEntity.get('taSegmentation').get('key').value && this.formBusinessEntity.get('taSegmentation').get('key').value != this.application.currentDetails.taSegmentation.key) {
        //     this.application.newDetails.taSegmentation.key = this.formBusinessEntity.get('taSegmentation').get('key').value;
        //     console.log('taSegmentation');
        //     this.isDataChanged = true;
        // }
        // else {
        //     this.application.newDetails.taSegmentation = this.application.currentDetails.taSegmentation;
        // }
        if (this.formBusinessEntity.get('formOfBusiness').get('key').value != this.application.currentDetails.formOfBusiness.key) {
            this.application.newDetails.formOfBusiness.key = this.formBusinessEntity.get('formOfBusiness').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.formOfBusiness = this.application.currentDetails.formOfBusiness;
        }

        if (this.formBusinessEntity.get('businessConstitution').get('key').value != this.application.currentDetails.businessConstitution.key) {
            this.application.newDetails.businessConstitution.key = this.formBusinessEntity.get('businessConstitution').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.businessConstitution = this.application.currentDetails.businessConstitution;
        }

        if (this.formBusinessEntity.get('paidUpCapital').value != this.application.currentDetails.paidUpCapital) {
            this.application.newDetails.paidUpCapital = this.formBusinessEntity.get('paidUpCapital').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.paidUpCapital = this.application.currentDetails.paidUpCapital;
        }

        //Business 
        if (this.formBusinessEntity.get('contactNo').value != this.application.currentDetails.contactNo) {
            this.application.newDetails.contactNo = this.formBusinessEntity.get('contactNo').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.contactNo = this.application.currentDetails.contactNo;
        }
        if (this.formBusinessEntity.get('faxNo').value != this.application.currentDetails.faxNo) {
            this.application.newDetails.faxNo = this.formBusinessEntity.get('faxNo').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.faxNo = this.application.currentDetails.faxNo;
        }
        if (this.formBusinessEntity.get('websiteUrl').value != this.application.currentDetails.websiteUrl) {
            this.application.newDetails.websiteUrl = this.formBusinessEntity.get('websiteUrl').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.websiteUrl = this.application.currentDetails.websiteUrl;
        }
        if (this.formBusinessEntity.get('emailAddress').value != this.application.currentDetails.emailAddress) {
            this.application.newDetails.emailAddress = this.formBusinessEntity.get('emailAddress').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.emailAddress = this.application.currentDetails.emailAddress;
        }

        // operatingAddress
        this.checkOperatingAddressBusinessEntity();
        // registeredAddress
        if (this.formBusinessEntity.get('registeredAddress').get('block').value != this.application.currentDetails.registeredAddress.block) {
            this.application.newDetails.registeredAddress.block = this.formBusinessEntity.get('registeredAddress').get('block').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.registeredAddress.block = this.application.currentDetails.registeredAddress.block;
        }
        if (this.formBusinessEntity.get('registeredAddress').get('street').value != this.application.currentDetails.registeredAddress.street) {
            this.application.newDetails.registeredAddress.street = this.formBusinessEntity.get('registeredAddress').get('street').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.registeredAddress.street = this.application.currentDetails.registeredAddress.street;
        }
        if (this.formBusinessEntity.get('registeredAddress').get('building').value != this.application.currentDetails.registeredAddress.building) {
            this.application.newDetails.registeredAddress.building = this.formBusinessEntity.get('registeredAddress').get('building').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.registeredAddress.building = this.application.currentDetails.registeredAddress.building;
        }
        if (this.formBusinessEntity.get('registeredAddress').get('floor').value != this.application.currentDetails.registeredAddress.floor) {
            this.application.newDetails.registeredAddress.floor = this.formBusinessEntity.get('registeredAddress').get('floor').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.registeredAddress.floor = this.application.currentDetails.registeredAddress.floor;
        }
        if (this.formBusinessEntity.get('registeredAddress').get('unit').value != this.application.currentDetails.registeredAddress.unit) {
            this.application.newDetails.registeredAddress.unit = this.formBusinessEntity.get('registeredAddress').get('unit').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.registeredAddress.unit = this.application.currentDetails.registeredAddress.unit;
        }
        if (this.formBusinessEntity.get('registeredAddress').get('postal').value != this.application.currentDetails.registeredAddress.postal) {
            this.application.newDetails.registeredAddress.postal = this.formBusinessEntity.get('registeredAddress').get('postal').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.registeredAddress.postal = this.application.currentDetails.registeredAddress.postal;
        }
        if (this.formBusinessEntity.get('registeredAddress').get('premisesType').get('key').value != this.application.currentDetails.registeredAddress.premisesType.key) {
            this.application.newDetails.registeredAddress.premisesType = { key: '', label: '' };
            this.application.newDetails.registeredAddress.premisesType.key = this.formBusinessEntity.get('registeredAddress').get('premisesType').get('key').value;
            this.isDataChanged = true;
        }
        else {
            this.application.newDetails.registeredAddress.premisesType = this.application.currentDetails.registeredAddress.premisesType;
        }
        this.application.isEdhPopulated = this.formBusinessEntity.get('isEdhPopulated').value;
        // }
        if (this.isDataChanged) {
            this.formUtil.validateAllFormControl(this.formBusinessEntity);
            if (this.street || this.building || this.block || this.floor || this.unit) {
                this.formBusinessEntity.get('companyDetailsDocument').enable();
            }
            else {
                this.formBusinessEntity.get('companyDetailsDocument').disable();
            }
            this.application.companyDetailsDocument = this.formBusinessEntity.getRawValue().companyDetailsDocument;
            this.application.acra = this.formBusinessEntity.getRawValue().acra;
            this.application.otherDocuments = this.otherDocuments.value;
            this.application.newDetails.registeredAddress.addressId = this.formBusinessEntity.get('registeredAddress').get('addressId').value;
            this.application.newDetails.operatingAddress.addressId = this.formBusinessEntity.get('operatingAddress').get('addressId').value;
            if (this.formBusinessEntity.valid) {
                this.alertService.clear();
                this.openConfirmationBusinessEnitityDialog();
            }
            else {
                this.alertService.clear();
                if (this.formBusinessEntity.get('isEdhPopulated').getError('required')) {
                    this.alertService.error("Some fields are auto-populated from ACRA and cannot be edited in TRUST. If any of these records are outdated, please update the information with ACRA.");
                } else if (this.formBusinessEntity.get('contactNo').value.length > 16) {
                    this.alertService.error("Input for business contact no. too long (Max. 16)");
                } else {
                    this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
                }

                this.formUtil.validateAllFormControl(this.formBusinessEntity);
            }
        }
        else {
            this.alertService.clear();
            this.alertService.error("Nothing to change");
        }
        window.scrollTo(0, 0);
    }
    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.setupCompanyUpdateBusinessEntity(data);
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }
    setupCompanyUpdateBusinessEntity(data: any) {
        this.application = data;
        if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_NEW) {
            this.application.newDetails.operatingAddress = { postal: '', block: '', street: '', building: '', unit: '', floor: '', premisesType: {}, type: { key: cnst.AddressTypes.ADDR_LOCAL } };
            this.application.newDetails.registeredAddress = { postal: '', block: '', street: '', building: '', unit: '', floor: '', premisesType: {}, type: { key: cnst.AddressTypes.ADDR_LOCAL } };
        }
        else if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_PENDING_PO ||
            this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_PENDING_VO ||
            this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_PENDING_AO ||
            this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_PENDING_HOD ||
            this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_PENDING_HODIV ||
            this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_APPROVED ||
            this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_REJECTED) {
            this.submitted = true;
            this.isEdhLoaded = true;
            this.disable = true;
        }
        if (!this.submitted) {
            this.retrieveInputBusinessEnitity();
        }
        if (data.otherDocuments.length > 0) {
            data.otherDocuments.forEach(item => {
                this.fileForm = this.taFormHelperUtil.initiateFileForm(this.formBuilder, item.docType === cnst.DocumentTypes.TA_DOC_OTHERS ? false : true);
                this.fileForm.patchValue(item);
                this.otherDocuments.push(this.fileForm);
            });
        }
        this.isAppLoaded = true;
    }
    checkForCompanyUpdateBusinessEntity() {
        this.service.checkForCompanyUpdateBusinessEntity().subscribe(data => {
            this.setupCompanyUpdateBusinessEntity(data);
        });
    }
    loadCommonTypes() {
        forkJoin([
            this.commonService.getCountries(),
            this.commonService.getPrincipleActivities(),
            this.commonService.getPremiseTypes(),
            this.commonService.getEstablishmentStatus(),
            this.commonService.getTaSegmentations(),
            this.commonService.getFormOfBusiness(),
            this.commonService.getAddressTypes(),
            this.commonService.getBusinessConstitution()
        ]).subscribe(data => {
            this.countries = data[0];
            this.principle_activities = data[1];
            this.premises_types = data[2];
            this.establishment_status = data[3];
            this.ta_segmentation = data[4];
            this.form_of_business = data[5];
            this.address_types = data[6];
            this.business_constitution = data[7];
            this.isCommonLoaded = true;
        });
    }

    initiateBusinessEntityForm() {
        this.formBusinessEntity = this.formBuilder.group({
            effectiveDate: [''],
            applicationMode: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            licenceTier: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            companyName: ['', [Validators.maxLength(255), Validators.required]],
            companyFormerName: [''],
            formOfBusiness: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            uen: ['', Validators.maxLength(255)],
            registrationDate: [''],
            businessConstitution: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            principleActivities: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            secondaryPrincipleActivities: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            placeIncorporated: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            establishmentStatus: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            taSegmentation: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            paidUpCapital: ['', [Validators.maxLength(255), Validators.required]],
            websiteUrl: ['', Validators.maxLength(255)],
            emailAddress: ['', Validators.compose([Validators.maxLength(320), ValidateEmail, Validators.required])],
            contactNo: ['', [Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL), Validators.required]],
            faxNo: ['', Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)],
            registeredAddress: this.formBuilder.group({
                addressId: [''],
                street: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET), ValidateAddressInputIncDash]],
                building: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING), ValidateAddressInputIncDash]],
                block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                unit: ['', ValidateAddressInputIncDash], // does not follow SGDRM as EDH returns "01/02" etc when there are multiple units
                postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                formatted: [''],
                singleLined: [''],
                singleLineAddress: [''],
                foreignLine1: [''],
                foreignLine2: [''],
                foreignLine3: [''],
                premisesType: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                type: this.formBuilder.group({
                    key: [cnst.AddressTypes.ADDR_LOCAL, Validators.required],
                    label: ['']
                }),
            }),
            operatingAddress: this.formBuilder.group({
                addressId: [''],
                street: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET), ValidateAddressInputIncDash]],
                building: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING), ValidateAddressInputIncDash]],
                block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                unit: ['', ValidateAddressInputIncDash], // does not follow SGDRM as EDH returns "01/02" etc when there are multiple units
                postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                formatted: [''],
                singleLined: [''],
                singleLineAddress: [''],
                foreignLine1: [''],
                foreignLine2: [''],
                foreignLine3: [''],
                premisesType: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                type: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
            }),
            isOppAddSameAsRegAdd: [false],
            isRALocal: [true],
            declared: [''],
            isEdhPopulated: ['', Validators.required],
            companyDetailsDocument: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: [''],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            acra: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: [''],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            otherDocuments: this.formBuilder.array([]),
            toDeleteFiles: this.formBuilder.array([
                this.formBuilder.control('')
            ]),

        });
        this.listenTenancyDocRequiredValidator();
        this.listenAcraDocRequiredValidator();
    }
    selectedFile: File;
    removeFile(obj) {
        if (obj.docType == cnst.DocumentTypes.TA_DOC_TENANCY) {
            this.formBusinessEntity.patchValue({
                companyDetailsDocument: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else if (obj.docType == cnst.DocumentTypes.TA_DOC_ACRA_BIZ) {
            this.formBusinessEntity.patchValue({
                acra: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else {
            this.otherDocuments.removeAt(obj);
        }
        if (obj.publicFileId) {
            this.adminDeletedFiles.push(obj.id);
            this.publicDeletedFiles.push(obj.publicFileId);
        }
    }
    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                if (type == cnst.DocumentTypes.TA_DOC_TENANCY) {
                    this.formBusinessEntity.patchValue({ companyDetailsDocument: data });
                } else if (type == cnst.DocumentTypes.TA_DOC_ACRA_BIZ) {
                    this.formBusinessEntity.patchValue({ acra: data });
                } else {
                    this.fileForm = this.taFormHelperUtil.initiateFileForm(this.formBuilder, false);
                    this.fileForm.patchValue(data);
                    this.otherDocuments.push(this.fileForm);
                }
            });
        }
    }
    get otherDocuments() {
        return this.formBusinessEntity.get('otherDocuments') as FormArray;
    }
    listenAcraDocRequiredValidator() {
        this.formBusinessEntity.get('isEdhPopulated').valueChanges.subscribe(
            (isEdhPopulated: any) => {
                if (!isEdhPopulated) {
                    this.formBusinessEntity.get('acra').get('originalName').setValidators([Validators.required]);
                } else {
                    this.formBusinessEntity.get('acra').get('originalName').clearValidators();
                }
                this.formBusinessEntity.get('acra').get('originalName').updateValueAndValidity();
            });

    }

    listenTenancyDocRequiredValidator() {
        if (this.formBusinessEntity.get('operatingAddress').get('postal').value != this.application.currentDetails.operatingAddress.postal) {
            this.formBusinessEntity.get('companyDetailsDocument').get('originalName').setValidators([Validators.required,]);
        } else {
            this.formBusinessEntity.get('companyDetailsDocument').get('originalName').clearValidators();
        }
        this.formBusinessEntity.get('companyDetailsDocument').get('originalName').updateValueAndValidity();
    }

    saveBusinessEntityConfirmationDialog() {

        this.service.saveBusinessEntity(this.application).subscribe(data => {
            this.service.checkForCompanyUpdateBusinessEntity().subscribe(data => {
                this.formBusinessEntity.markAsPristine();
                this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { applicationNo: data.applicationNo, returnApp: this.returnAppCode } });
            });
        })

    }

    onKeyUp(event) {
        let name = event.target.value;
        if (name != undefined && name != null && name != '') {
            this.formBusinessEntity.get('companyName').setValue(name.toUpperCase());
        }
    }
    // updateBusinessEntityConfirmationDialog() {
    //     this.service.updateBusinessEntity(this.application, this.adminDeletedFiles).subscribe(data => {
    //         this.fileUtil.delete(this.publicDeletedFiles).subscribe();
    //         this.service.checkForCompanyUpdateBusinessEntity().subscribe(data => {
    //             this.formBusinessEntity.markAsPristine();
    //             this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { 'applicationNo': data.applicationNo } });
    //         });

    //     })
    //  }
}
