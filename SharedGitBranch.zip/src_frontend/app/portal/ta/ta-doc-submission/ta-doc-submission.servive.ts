import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaDocSubmissionService {

    constructor(private http: HttpClient) { }

    checkForPendingApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ta/adhoc-filing-doc/load');
    }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ta/adhoc-filing-doc/load/' + applicationId);
    }

    save(application: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + '/ta/adhoc-filing-doc/save', application);
    }

    update(application: any, deletedList: any): Observable<any> {
        var formData = this.buildFormData(application, deletedList);
        return this.http.post(cnst.apexBaseUrl + '/ta/adhoc-filing-doc/update', formData);
    }

    buildFormData(application, deletedList) {

        var formDataObj = new FormData();
        var applicationBlob = new Blob(
            [JSON.stringify(application)],
            { type: 'application/json' }
        );
        formDataObj.append('application', applicationBlob);

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formDataObj.append('deletedFiles', deletedBlob);
        return formDataObj;
    }




}
