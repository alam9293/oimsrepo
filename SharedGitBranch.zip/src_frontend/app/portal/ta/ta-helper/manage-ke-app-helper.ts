import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { ValidateEmail } from '../../../common/helper';


@Injectable({
    providedIn: 'root'
})
export class ManageKeAppHelperUtil {

    constructor() { }

    initiateStakeholderForm(fb: FormBuilder) {
        return (fb.group({
            stakeholderId: [],
            stakeholderName: ['', [Validators.required, Validators.maxLength(255)]],
            uin: ['', [Validators.required, Validators.maxLength(255)]],
            sex: fb.group({
                key: ['', Validators.required],
                label: ['']
            }),
            nationality: fb.group({
                key: ['', Validators.required],
                label: ['']
            }),
            address: fb.group({
                street: ['', [Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)]],
                building: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
                block: ['', [Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                unit: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.UNIT), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                postal: ['', [Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                addressId: ['']
            }),
            dob: ['', Validators.required],
            contactNo: ['', [Validators.required, Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
            officeNo: ['', [Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
            residentialNo: ['', [Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
            email: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
            highestEduLevel: fb.group({
                key: ['', Validators.required],
                label: ['']
            }),
            designation: fb.group({
                key: ['', Validators.required],
                label: ['']
            }),
            otherDesignation: ['', Validators.maxLength(255)],
            scpr: []
        }))
    }

    initiateDeclarations(fb: FormBuilder, ) {
        return (new FormGroup({
            id: new FormControl(),
            selectedOption: new FormControl(''),

            // options: new FormControl(['']),
            optionsToPrompt: new FormControl(),
            prompt: new FormControl(),
            clause: fb.group({
                key: [''],
                // label: ['']
            }),
            // subscript: new FormControl(['']),
            remarks: new FormControl(),
            isOptionRequired: new FormControl(),
            isRadioButton: new FormControl(),
        }, { validators: Validators.compose([promptRequiredValidator, isOptionRequiredValidator]) }));
    }

    setDeclarations(fb: FormBuilder, taKeDeclarations: any) {
        var declareform: any;
        var declareForms: any;
        taKeDeclarations.forEach(item => {
            console.log(item);
            declareform = this.initiateDeclarations(fb);
            declareform.patchValue(item);
            declareForms.push(declareform);

        });
        return declareForms;
    }

    setMyInfoDataNewKe(stakeholderForm: FormGroup, data: any) {
        stakeholderForm.patchValue(this.setMyInfoData(stakeholderForm, data));
        stakeholderForm.get('uin').setValue(data.uinfin);
        return stakeholderForm;
    }

    setMyInfoData(stakeholderForm: FormGroup, data: any) {

        stakeholderForm.get('stakeholderName').setValue(data.name);
        stakeholderForm.get('dob').setValue(data.dob);
        stakeholderForm.get('sex').get('key').setValue(data.sex);
        stakeholderForm.get('nationality').get('key').setValue(data.nationality);
        stakeholderForm.get('designation').get('key').setValue(data.occupation);
        stakeholderForm.get('highestEduLevel').get('key').setValue(data.eduLevel);
        stakeholderForm.get('contactNo').setValue(data.mobileNo);
        stakeholderForm.get('email').setValue(data.email);
        stakeholderForm.get('scpr').setValue(data.scpr);

        if (stakeholderForm.get('scpr').value) {
            stakeholderForm.get('address').get('postal').setValue(data.regAddPostal);
            stakeholderForm.get('address').get('block').setValue(data.regAddBlock);
            stakeholderForm.get('address').get('street').setValue(data.regAddStreet);
            stakeholderForm.get('address').get('building').setValue(data.regAddBuildin);
            stakeholderForm.get('address').get('floor').setValue(data.regAddFloor);
            stakeholderForm.get('address').get('unit').setValue(data.regAddUnit);
        } else {
            stakeholderForm.get('address').get('postal').setValue(data.mailAddPostal);
            stakeholderForm.get('address').get('block').setValue(data.mailAddBlock);
            stakeholderForm.get('address').get('street').setValue(data.mailAddStreet);
            stakeholderForm.get('address').get('building').setValue(data.mailAddBuilding);
            stakeholderForm.get('address').get('floor').setValue(data.mailAddFloor);
            stakeholderForm.get('address').get('unit').setValue(data.mailAddUnit);
        }

        return stakeholderForm;
    }

    clearMyInfo(stakeholderForm: FormGroup) {
        stakeholderForm.get('contactNo').patchValue('');
        stakeholderForm.get('dob').patchValue('');
        stakeholderForm.get('email').patchValue('');
        stakeholderForm.get('otherDesignation').patchValue('');
        stakeholderForm.get('stakeholderName').patchValue('');

        stakeholderForm.get('designation').get('key').patchValue('');
        stakeholderForm.get('highestEduLevel').get('key').patchValue('');
        stakeholderForm.get('nationality').get('key').patchValue('');
        stakeholderForm.get('sex').get('key').patchValue('');

        stakeholderForm.get('address').get('block').patchValue('');
        stakeholderForm.get('address').get('building').patchValue('');
        stakeholderForm.get('address').get('floor').patchValue('');
        stakeholderForm.get('address').get('postal').patchValue('');
        stakeholderForm.get('address').get('street').patchValue('');
        stakeholderForm.get('address').get('unit').patchValue('');
        return stakeholderForm;
    }

    disableNricFile(toDisable: boolean, fileForms: FormArray) {
        fileForms.controls.forEach(c => {
            if (c.get('docType').value === cnst.DocumentTypes.TA_DOC_KE_NRIC) {
                if (toDisable) {
                    c.get('originalName').clearValidators();
                } else {
                    c.get('originalName').setValidators([Validators.required,]);
                }
                c.get('originalName').updateValueAndValidity();
            }
        });
    }

    checkNricDocRequired(prevValueStakeholderDto: any, form: FormGroup, fileForm: FormArray) {
        form.valueChanges.subscribe(
            (values: any) => {
                this.compareValueForNricDoc(values, prevValueStakeholderDto, fileForm);
            });
    }

    compareValueForNricDoc(values, prevValueStakeholderDto: any, fileForm: FormArray) {
        if (values.stakeholderName.toUpperCase() != prevValueStakeholderDto.stakeholderName.toUpperCase() || values.sex.key != prevValueStakeholderDto.sex.key ||
            values.address.postal.toUpperCase() != prevValueStakeholderDto.address.postal.toUpperCase() || values.address.block.toUpperCase() != prevValueStakeholderDto.address.block.toUpperCase() ||
            values.address.street.toUpperCase() != prevValueStakeholderDto.address.street.toUpperCase() || (values.address.building ? values.address.building.toUpperCase() : '') != (prevValueStakeholderDto.address.building ? prevValueStakeholderDto.address.building.toUpperCase() : '') ||
            (values.address.floor ? values.address.floor.toUpperCase() : '') != (prevValueStakeholderDto.address.floor ? prevValueStakeholderDto.address.floor.toUpperCase() : '') || (values.address.unit ? values.address.unit.toUpperCase() : '') != (prevValueStakeholderDto.address.unit ? prevValueStakeholderDto.address.unit.toUpperCase() : '')) {
            this.disableNricFile(false, fileForm);
        } else {
            this.disableNricFile(true, fileForm);
        }
    }

}

export const promptRequiredValidator: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
    const isOptionRequired = control.get('isOptionRequired');
    const optionsToPrompt = control.get('optionsToPrompt');
    const selectedOption = control.get('selectedOption');
    const remarks = control.get('remarks');
    return isOptionRequired && optionsToPrompt && selectedOption && isOptionRequired.value && (optionsToPrompt.value === selectedOption.value) && !remarks.value ? { 'reasonsReq': true } : null;
};

export const isOptionRequiredValidator: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
    const isOptionRequired = control.get('isOptionRequired');
    const selectedOption = control.get('selectedOption');
    return isOptionRequired && selectedOption && isOptionRequired.value && selectedOption.value == "" ? { 'selectedOptionError': true } : null;
};
