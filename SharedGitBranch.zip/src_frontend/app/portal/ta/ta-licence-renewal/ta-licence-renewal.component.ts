import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog, } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { TaLicenceRenewalService } from './ta-licence-renewal.service';
import { CommonService, AlertService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil } from '../../../common/helper';
import { FormBuilder, FormGroup, Validators, FormArray, ValidatorFn, ValidationErrors } from '@angular/forms';
import { Observable } from 'rxjs';
import { TaFormHelperUtil, ManageKeAppHelperUtil } from '../ta-helper';
import { PaymentDialogComponent } from '../../../common/modules/payment-dialog/payment-dialog.component';
import { PaymentService } from '../../payment/payment.service';
@Component({
    selector: 'app-ta-licence-renewal',
    templateUrl: './ta-licence-renewal.component.html',
    styleUrls: ['./ta-licence-renewal.component.scss']
})
export class TaLicenceRenewalComponent implements OnInit {
    constructor(private paymentService: PaymentService, private keHelper: ManageKeAppHelperUtil, public taFormHelperUtil: TaFormHelperUtil, private alertService: AlertService, private fb: FormBuilder, private commonService: CommonService, private service: TaLicenceRenewalService, private fileUtil: FileUtil, private formUtil: FormUtil, public dialog: MatDialog, private route: ActivatedRoute, private router: Router) { }
    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    application: any = { applicationStatus: {}, licenceStatus: {}, renewalChecklist: {} };
    cnst = cnst;
    checked: boolean = false;
    selectedFile: File;
    form: FormGroup;
    files: any;
    fileForm: FormGroup;
    branchForm: FormGroup;
    declareform: FormGroup;
    paymentPreview: boolean = false;

    ngOnInit() {
        this.initiateForm();
        if (this.route.snapshot.paramMap.get('appId')) {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        } else {
            this.createApp();
        }
    }

    initiateForm() {
        this.form = this.fb.group({
            id: '',
            applicationId: '',
            draft: '',
            taLicenceRenewalExerciseTaId: '',
            lateRemarks: [,],
            offlineSubmission: false,
            taKeDeclarationsForRenewal: this.fb.array([]),
            currentCompanyDetails: this.fb.group({
                effectiveDate: [],
                applicationMode: this.formUtil.listableForm,
                licenceTier: this.formUtil.listableForm,
                companyName: [],
                companyFormerName: [],
                formOfBusiness: this.formUtil.listableForm,
                businessConstitution: this.formUtil.listableForm,
                uen: [],
                registrationDate: [],
                principleActivities: this.formUtil.listableForm,
                secondaryPrincipleActivities: this.formUtil.listableForm,
                placeIncorporated: this.formUtil.listableForm,
                establishmentStatus: this.formUtil.listableForm,
                taSegmentation: this.formUtil.listableForm,
                paidUpCapital: [],
                websiteUrl: [],
                emailAddress: [],
                contactNo: [],
                fye: [],
                registeredAddress: this.formUtil.addressForm,
                operatingAddress: this.formUtil.addressForm,
            }),
            activeBranchList: this.fb.array([]),
            //  keStakeholderDto: this.keHelper.initiateStakeholderForm(this.fb),
            taKeStakeholder: this.fb.group({
                taStakeholderId: [],
                resignedDate: [],
                taKeDeclarations: this.fb.array([]),
            }),
            files: this.fb.array([]),
            toDeleteFiles: this.fb.array([
                this.fb.control('')
            ]),
        }, {});
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.application = data;
            this.setupForm(this.application);

        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

    createApp(): void {
        this.service.createApplication().subscribe(data => {
            this.application = data;
            this.setupForm(this.application);
        });
    }

    private setupForm(application: any) {
        this.initiateForm();
        this.form.patchValue(application);
        this.application.files.forEach(item => {
            var req = false;
            this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, req);
            this.fileForm.patchValue(item);
            this.fileForms.push(this.fileForm);
        });

        if (application.taKeDeclarationsForRenewal) {
            application.taKeDeclarationsForRenewal.forEach(item => {
                this.declareform = this.keHelper.initiateDeclarations(this.fb);
                this.declareform.patchValue(item);
                this.declareForms.push(this.declareform);
            });
        }
        if (application.isLate) {
            this.form.get('lateRemarks').setValidators([Validators.required, Validators.maxLength(255)]);
        } else {
            this.form.get('lateRemarks').clearValidators();
        }
        this.form.get('lateRemarks').updateValueAndValidity();

        if (!application.isKeUser && (application.applicationStatus.key === cnst.ApplicationStatuses.TA_APP_NEW || application.applicationStatus.key === cnst.ApplicationStatuses.TA_APP_RFA)) {
            this.alertService.warn("Only the Key Executive is able to submit the renewal form as the Key Executive's declaration is required for licence renewal.");
        }
    }

    get fileForms() {
        return this.form.get('files') as FormArray
    }
    get branchForms() {
        return this.form.get('activeBranchList') as FormArray
    }
    get declareForms() {
        return this.form.get('taKeDeclarationsForRenewal') as FormArray
    }


    toDeleteFile(file, index) {
        if (file.controls.originalName.value) {
            (this.form.get('toDeleteFiles') as FormArray).push(this.fb.control(file.controls.id.value));
        }
        if (file.value.docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
            this.fileForms.removeAt(index);
        } else {
            this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
        }
    }

    onPicked(input: HTMLInputElement, docType: string, index) {
        this.selectedFile = input.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(docType, this.selectedFile).subscribe(data => {
                if (docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
                    this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, false);
                    this.fileForm.patchValue(data);
                    this.fileForms.push(this.fileForm);
                } else {
                    var file: any = data;
                    if (file.originalName) {
                        this.fileForms.at(index).patchValue(file);
                    } else {
                        this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
                    }
                }
            });
        }
    }

    saveConfirmationDialog() {
        console.log(this.form);
        this.formUtil.markFormGroupTouched(this.form);
        if (this.checked && this.form.valid) {
            this.service.submit(this.form.value).subscribe(data => {
                this.form.markAsPristine();
                this.alertService.clear();
                this.service.createApplication().subscribe(data => {
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                });
            });
        } else {
            if (!this.checked) {
                alert(cnst.Messages.MSG_DECLARATION_CHECK);
            }
            if (!this.form.valid) {
                this.alertService.clear();
                this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            }
        }
    }

    previewPayment() {
        this.paymentPreview = true;
        window.scrollTo(0, 0);
    }

    makePayment() {
        let billRefNos = [];
        billRefNos.push(this.application.renewalFee.billRefNo);
        let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.application.renewalFee.payableAmount } });
        dialog.afterClosed().subscribe(result => {
            if (result.decision) {
                let paymentType = result.type;
                if (paymentType == cnst.PaymentTypes.PAYNOW) {
                    this.paymentService.createPayNowTxn(this.application.renewalFee.payableAmount, billRefNos).subscribe(txn => {
                        let payNowTxnId = txn;
                        this.paymentService.generateQrCode(this.application.renewalFee.payableAmount, txn).subscribe(qrCode => {
                            let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.application.renewalFee.payableAmount, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNos } });
                            dialog.afterClosed().subscribe(result => {
                                if (result.decision) {
                                    this.paymentService.routeToPaymentSuccessPage(true, cnst.eNets.URL_TA_RETURN, paymentType, billRefNos, cnst.TaApplicationUrl.TA_APP_RENEWAL, payNowTxnId);
                                }
                            });
                        });
                    });
                } else {
                    this.paymentService.initPaymentProcess(true, cnst.eNets.URL_TA_RETURN, paymentType, billRefNos, cnst.TaApplicationUrl.TA_APP_RENEWAL);
                }
            }
        });
    }

}
