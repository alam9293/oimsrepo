import { Component, OnInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, ValidatorFn, ValidationErrors, AbstractControl } from '@angular/forms';
import { AlertService, ErrorDialogService, AuthenticationService } from '../../../common/services';
import { TaMaSubmissionService } from './ta-ma-submission.servive';
import { FileUtil, FormUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-ta-ma-submission',
    templateUrl: './ta-ma-submission.component.html',
    styleUrls: ['./ta-ma-submission.component.scss']
})
export class TaMaSubmissionComponent implements OnInit {

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private alertService: AlertService,
        private errorDialogService: ErrorDialogService,
        private fileUtil: FileUtil,
        private formUtil: FormUtil,
        private authService: AuthenticationService,
        private service: TaMaSubmissionService
    ) { }

    application: any = { applicationStatus: {}, managementAccounts: {}, otherDocuments: [], hasMaToSubmit: true, filingDto: {} };
    appId: number;
    preview: boolean = false;
    newApplication: boolean = true;
    rfa: boolean = false;
    form: FormGroup;
    maUploadTouched = false;
    showErrorMsg = false;
    isTaActive: boolean = true;
    selectedFile: File;
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    cnst = cnst;

    ngOnInit() {
        this.buildForm();
        this.isTaActive = this.authService.isTaActive();
        if (this.route.snapshot.paramMap.get('appId')) {
            this.getApplication(this.route.snapshot.paramMap.get('appId'));
        } else {
            this.checkForPendingApplication();
            if (!this.isTaActive) {
                setTimeout(() => this.errorDialogService.openDialog({
                    reason: cnst.Messages.MSG_INVALID_ACCESS,
                    routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
                }))
            }
        }
    }

    buildForm() {
        this.form = this.formBuilder.group({
            applicationId: [''],
            capital: ['', Validators.required],
            totalAssets: ['', Validators.required],
            totalLiabilities: ['', Validators.required],
            asatDate: ['', Validators.required],
            filingDto: this.formBuilder.group({
                annualFilingId: [''],
                requestedAsAtDate: [''],
                dueDate: [''],
                typeCode: ['']
            }),
            managementAccounts: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: ['', Validators.required],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [true],
            }),
            otherDocuments: this.formBuilder.array([]),
            declared: [{ disabled: true, value: false }, Validators.requiredTrue],
            isEdit: false
        });
    }

    get otherDocuments() {
        return this.form.get('otherDocuments') as FormArray;
    }

    // convenience getter for easy access to form fields
    get f() {
        return this.form.controls;
    }

    checkForPendingApplication() {
        this.service.checkForPendingApplication().subscribe(data => {
            this.application = data;
            if (data.applicationId) {
                this.form.patchValue(data);
                this.newApplication = false;
                if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                    this.rfa = true;
                }
                if (data.otherDocuments.length > 0) {
                    data.otherDocuments.forEach(item => {
                        this.otherDocuments.push(this.formBuilder.group(item));
                    });
                }
            } else if (data.hasMaToSubmit) {
                this.form.get('filingDto').patchValue(data.filingDto);
                this.form.get('managementAccounts').patchValue(data.managementAccounts);
                this.form.markAsPristine();
            }
        });
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.rfa = false;
            this.application = data;
            this.form.patchValue(data);
            this.newApplication = false;
            if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                this.rfa = true;
            }
            if (data.otherDocuments.length > 0) {
                data.otherDocuments.forEach(item => {
                    this.otherDocuments.push(this.formBuilder.group(item));
                });
            }
        }, error => {
            this.router.navigate(['/portal/dashboard-ta']);
        })
    }

    showPreview() {
        this.alertService.clear();
        if (this.form.valid) {
            this.preview = true
            window.scrollTo(0, 0);
            this.form.controls['declared'].enable();
        } else {
            this.form.markAsTouched();
            this.formUtil.markFormGroupTouched(this.form);
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                if (type == cnst.DocumentTypes.TA_DOC_MANAGEMENT_ACCOUNTS) {
                    this.form.patchValue({ managementAccounts: data });
                } else {
                    const fileDto = this.formBuilder.group({
                        id: [],
                        publicFileId: [],
                        originalName: [],
                        processedName: [],
                        docType: [],
                        extension: [],
                        path: [],
                        size: [],
                        hash: [],
                        documentInstructions: [],
                        documentTypeLabel: [],
                        description: [],
                        readableFileSize: [],
                        hasTemplate: [],
                    });
                    fileDto.patchValue(data);
                    this.otherDocuments.push(fileDto);
                }
            });
        }
    }

    removeFile(obj, type, doc) {
        if (type == cnst.DocumentTypes.TA_DOC_MANAGEMENT_ACCOUNTS) {
            this.form.patchValue({
                managementAccounts: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else {
            this.otherDocuments.removeAt(obj);
        }
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push({ publicFileId: doc.publicFileId, hash: doc.hash });
        }
    }

    backToApplicationForm() {
        this.preview = false;
        this.form.controls['declared'].disable();
    }

    saveConfirmationDialog() {
        if (this.form.valid) {
            console.log(this.form.value);
            if (this.form.value.declared) {
                this.service.save(this.form.value).subscribe(data => {
                    this.service.checkForPendingApplication().subscribe(data => {
                        this.form.markAsPristine();
                        this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                    });
                });
            } else {
                alert(cnst.Messages.MSG_DECLARATION_CHECK)
            }

        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    updateConfirmationDialog() {
        if (this.form.valid) {
            this.service.update(this.form.value, this.adminDeletedFiles).subscribe(data => {
                this.fileUtil.delete(this.publicDeletedFiles).subscribe();
                this.service.checkForPendingApplication().subscribe(data => {
                    this.form.markAsPristine();
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                });
            });

        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }
}
