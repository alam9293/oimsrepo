import { Component, OnInit, HostListener, ViewChild, } from '@angular/core';
import { MatStepper, MatDialog, } from "@angular/material";
import { ActivatedRoute, Router } from '@angular/router'
import * as dtoCommon from 'src/app/data.dto';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { CommonService, AlertService, MyInfoService, AuthenticationService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil, DateUtil } from '../../../common/helper';
import { TaKeAssignService } from './ta-manage-ke-assign.service';
import { Observable } from 'rxjs';
import { ManageKeAppHelperUtil, TaFormHelperUtil } from '../ta-helper';
import { InformationDialogComponent } from 'src/app/common/modules/information-dialog/information-dialog.component';
//import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

@Component({
    selector: 'app-ta-manage-ke-assign',
    templateUrl: './ta-manage-ke-assign.component.html',
    styleUrls: ['./ta-manage-ke-assign.component.scss'],
    // providers: [{
    //     provide: STEPPER_GLOBAL_OPTIONS, useValue: { displayDefaultIndicatorType: false }
    // }]
})

export class TaManageKeAssignComponent implements OnInit {
    genderList: dtoCommon.ListableDto[];
    nationalityList: dtoCommon.ListableDto[];

    application: any = { applicationStatus: {}, licenceStatus: {} };
    eduList: any;
    occupationList: any;
    form: FormGroup;
    cnst = cnst;
    showForm: boolean = false;
    stakeholderDetails: any = { sex: {}, nationality: {}, highestEduLevel: {}, designation: {} };
    isLinear = false;
    selectedFile: File;
    fileForm: FormGroup;
    files: any;
    declareform: FormGroup;
    disable: false;
    myInfoNonEditableFields: string[];
    addPostal: string;
    addBlk: string;
    addSt: string;
    addBldg: string;
    addFl: string;
    addUnit: string;
    currentStep: any = 0;
    currentUserUin: string;
    @ViewChild('stepper') stepper: MatStepper;
    returnAppCode: string;
    kePendingResignation: boolean = false;
    kePendingAppointment: boolean = false;
    unionMap = new Map<string, string>();

    constructor(
        public dialog: MatDialog,
        private taFormHelperUtil: TaFormHelperUtil,
        private authenticationService: AuthenticationService,
        private keHelper: ManageKeAppHelperUtil,
        private fileUtil: FileUtil,
        public formUtil: FormUtil,
        private myInfoService: MyInfoService,
        private alertService: AlertService,
        private fb: FormBuilder,
        private router: Router,
        private service: TaKeAssignService,
        private route: ActivatedRoute,
        private commonService: CommonService,
        private dateUtil: DateUtil
    ) { }
    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    ngOnInit() {
        this.authenticationService.getCurrentUser().subscribe(data => {
            this.currentUserUin = data.loginId;
        });
        this.initiateForm();
        this.returnAppCode = this.route.snapshot.queryParams.returnApp;
        this.commonService.getSexes().subscribe(data => this.genderList = data);
        this.commonService.getNationalities().subscribe(data => this.nationalityList = data);
        this.commonService.getQualifications().subscribe(data => this.eduList = data);
        this.commonService.getOccupations().subscribe(data => this.occupationList = data);
        if (this.route.snapshot.paramMap.get('appId')) {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        } else {
            this.createTaLicence();
        }
        this.formListener();
    }

    changeKe(isKe: boolean): void {

        this.showForm = true;
        if (isKe) {
            this.newStakeholderForm.get('uin').setValue(this.currentUserUin);
            this.declareForms.enable();
            this.form.get('applicantIsKe').setValue(true);
        } else {
            this.newStakeholderForm.get('uin').setValue('');
            this.declareForms.disable();
            this.form.get('applicantIsKe').setValue(false);
            this.manualInput();
        }
    }
    // convenience getter for easy access to form fields
    get stakeholderControl() {
        return (this.form.get('stakeholderDto') as FormGroup).controls;
    }
    get fileForms() {
        return this.form.get('files') as FormArray
    }
    get stakeholderForm() {
        return this.form.get('stakeholderDto') as FormGroup
    }
    get taKeStakeholderForm() {
        return this.form.get('taKeStakeholder') as FormGroup
    }
    get taKeStakeholderControl() {
        return (this.form.get('taKeStakeholder') as FormGroup).controls;
    }
    get addressForm() {
        return this.stakeholderForm.get('address') as FormGroup
    }
    get newStakeholderForm() {
        return this.form.get('newStakeholderDto') as FormGroup
    }
    get newTaStakeholderForm() {
        return this.form.get('newTaStakeholderDto') as FormGroup
    }
    get newTaStakeholderFormControl() {
        return (this.form.get('newTaStakeholderDto') as FormGroup).controls;
    }
    get newAddressForm() {
        return this.newStakeholderForm.get('address') as FormGroup
    }
    get newAddressFormControl() {
        return (this.newStakeholderForm.get('address') as FormGroup).controls;
    }
    get newStakeholderControl() {
        return (this.form.get('newStakeholderDto') as FormGroup).controls;
    }
    get declareForms() {
        return this.form.get('taKeDeclarations') as FormArray
    }

    getCheckedValue() {
        return this.form.get('declared').value;
    }

    createTaLicence(): void {
        this.service.createTaLicenceAssignKeApplication().subscribe(data => {
            this.application = data;
            if (data.haveKe) {
                this.stakeholderDetails = data.stakeholderDto;
            }
            this.setupForm(this.application);
            this.kePendingResignation = data.taKeStakeholder ? data.taKeStakeholder.keResignedAtFutureDate : false;
            this.kePendingAppointment = data.newTaStakeholderDto ? data.newTaStakeholderDto.keAppointedAtFutureDate : false;
        });
    }

    loadAppMyInfo() {
        // this.myInfoService.getMyInfoPersonBasic().subscribe(data => {
        //     if (data.errorMessage) {
        //         this.alertService.clear();
        //         this.alertService.error(cnst.TaAlertMessages.MY_INFO_ERROR);
        //     } else {
        //         console.log(data);
        //         this.myInfoNonEditableFields = data.nonEditableFields;
        //         this.form.get('isMyInfoPopulated').setValue(true);
        //         this.keHelper.disableNricFile(true, this.fileForms);
        //         this.newStakeholderForm.patchValue(this.keHelper.setMyInfoDataNewKe(this.newStakeholderForm, data));
        //         this.formUtil.markFormGroupTouched(this.form);
        //     }
        // });
    }

    private setupForm(application: any) {
        this.initiateForm();
        this.form.patchValue(application);
        this.form.get('currentUserUin').setValue(this.currentUserUin);
        this.form.get('isMyInfoPopulated').setValue(false);
        this.mailAddress();
        if (application.applicationStatus.key != cnst.ApplicationStatuses.TA_APP_NEW) {
            this.showForm = true;
        }
        if (application.taKeDeclarations) {
            application.taKeDeclarations.forEach(item => {
                this.declareform = this.keHelper.initiateDeclarations(this.fb);
                this.declareform.patchValue(item);
                this.declareForms.push(this.declareform);
            });
        }

        if (!this.form.get('applicantIsKe').value) {
            this.declareForms.disable();
        }

        if (application.files) {
            application.files.forEach(item => {
                var req = true;
                if (cnst.DocumentTypes.TA_DOC_OTHERS === item.docType) {
                    req = false;
                }
                this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, req);
                this.fileForm.patchValue(item);
                this.fileForms.push(this.fileForm);
            });
        }
        this.formUtil.getAddressFrmPostal(this.newAddressForm);
        if (application.isMyInfoPopulated) {
            this.keHelper.disableNricFile(true, this.fileForms);
        }
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.application = data;
            this.stakeholderDetails = data.stakeholderDto;
            this.setupForm(this.application);
            this.kePendingResignation = data.taKeStakeholder ? data.taKeStakeholder.keResignedAtFutureDate : false;
            this.kePendingAppointment = data.newTaStakeholderDto ? data.newTaStakeholderDto.keAppointedAtFutureDate : false;
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

    initiateForm() {
        this.form = new FormGroup({
            currentUserUin: new FormControl('', []),
            stakeholderDto: this.fb.group({
                stakeholderId: [],
                uin: ['',],
            }),
            newStakeholderDto: this.keHelper.initiateStakeholderForm(this.fb),
            newTaStakeholderDto: this.fb.group({
                taStakeholderId: [],
                appointedDate: ['', Validators.required]
            }),
            taKeDeclarations: this.fb.array([]),

            taKeStakeholder: this.fb.group({
                taStakeholderId: [],
                resignedDate: ['', Validators.required]
            }),
            isMyInfoPopulated: new FormControl('', []),
            keAppType: new FormControl('', []),
            keAppTypeLabel: new FormControl('', []),
            taKeAppId: new FormControl('', []),
            applicationId: new FormControl('', []),
            draft: new FormControl('', []),
            haveKe: new FormControl('', []),
            needCompleteDeclaration: new FormControl('', []),
            files: this.fb.array([]),
            toDeleteFiles: this.fb.array([
                this.fb.control('')
            ]),
            applicantIsKe: new FormControl('', [
                Validators.required,
            ]),
            declared: new FormControl(''),
        }, { validators: forbiddenUinValidator });
    }

    saveConfirmationDialog() {
        if (this.getCheckedValue && this.form.valid) {
            this.service.submit(this.form.value).subscribe(data => {
                this.form.markAsPristine();
                this.alertService.clear();
                this.service.createTaLicenceAssignKeApplication().subscribe(data => {
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { applicationNo: data.applicationNo, returnApp: this.returnAppCode } });
                });
            });
        } else {
            if (!this.getCheckedValue) {
                alert(cnst.Messages.MSG_DECLARATION_CHECK);
            }
            if (!this.form.valid) {
                this.alertService.clear();
                this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            }
        }
    }

    onPicked(input: HTMLInputElement, docType: string, index) {
        this.selectedFile = input.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(docType, this.selectedFile).subscribe(data => {
                if (docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
                    this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, false);
                    this.fileForm.patchValue(data);
                    this.fileForms.push(this.fileForm);
                } else {
                    var file: any = data;
                    if (file.originalName) {
                        this.fileForms.at(index).patchValue(file);
                    } else {
                        this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
                    }
                }
            });
        }
    }

    toDeleteFile(file, index) {
        if (file.controls.originalName.value) {
            (this.form.get('toDeleteFiles') as FormArray).push(this.fb.control(file.controls.id.value));
        }
        if (file.value.docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
            this.fileForms.removeAt(index);
        } else {
            this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
        }
    }

    showPreview(stepper: MatStepper) {
        this.alertService.clear();
        console.log(this.form);
        this.formUtil.validateAllFormControl(this.form);
        if (this.form.valid) {
            stepper.next();
        } else {
            this.form.markAsTouched();
            this.formUtil.markFormGroupTouched(this.form);
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            if (this.taKeStakeholderForm.invalid) {
                this.stepper.selectedIndex = 0;
            } else if (this.newStakeholderForm.invalid || this.newTaStakeholderForm.invalid) {
                this.stepper.selectedIndex = this.application.haveKe && !this.kePendingResignation ? 1 : 0;
            } else if (this.fileForms.invalid) {
                this.stepper.selectedIndex = this.application.haveKe && !this.kePendingResignation ? 2 : 1;
            }
        }
        window.scrollTo(0, 0);
    }

    mailAddress() {
        if (this.newStakeholderForm.get('scpr')) {
            this.addPostal = cnst.MyInfoFields.REG_ADD_POSTAL;
            this.addBlk = cnst.MyInfoFields.REG_ADD_BLOCK;
            this.addSt = cnst.MyInfoFields.REG_ADD_STREET;
            this.addBldg = cnst.MyInfoFields.REG_ADD_BUILDING;
            this.addFl = cnst.MyInfoFields.REG_ADD_FLOOR;
            this.addUnit = cnst.MyInfoFields.REG_ADD_UNIT;
        } else {
            this.addPostal = cnst.MyInfoFields.MAIL_ADD_POSTAL;
            this.addBlk = cnst.MyInfoFields.MAIL_ADD_BLOCK;
            this.addSt = cnst.MyInfoFields.MAIL_ADD_STREET;
            this.addBldg = cnst.MyInfoFields.MAIL_ADD_BUILDING;
            this.addFl = cnst.MyInfoFields.MAIL_ADD_FLOOR;
            this.addUnit = cnst.MyInfoFields.MAIL_ADD_UNIT;
        }
    }

    manualInput() {
        this.keHelper.clearMyInfo(this.newStakeholderForm);
        this.form.get('isMyInfoPopulated').setValue(false);
        this.keHelper.disableNricFile(false, this.fileForms);
    }


    formListener() {
        console.log('uin');
        this.stakeholderForm.get('uin').valueChanges.subscribe(
            (uin: any) => {
                console.log(uin);
                if (uin && (uin.startsWith("T") || uin.startsWith("T"))) {
                    this.stakeholderForm.get('isMyInfoPopulated').setValue(true);
                } else {
                    this.stakeholderForm.get('isMyInfoPopulated').setValue(false);
                }
            });
    }

    isPendingTaSubmission(): boolean {
        return (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_NEW || this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA || this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_DRAFT)
    }

    openInformationDialog(msg) {
        this.dialog.open(InformationDialogComponent, { data: { content: msg } })
    }
}

export const forbiddenUinValidator: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
    const currentUin = control.get('stakeholderDto').get('uin');
    const newUin = control.get('newStakeholderDto').get('uin');
    const currentUserUin = control.get('currentUserUin');
    const applicantIsKe = control.get('applicantIsKe');
    if (currentUin.value && currentUin && newUin && currentUin.value === newUin.value) {
        return { 'forbiddenUin': true };
    } else if (newUin.value && newUin && currentUserUin && currentUserUin.value === newUin.value && !applicantIsKe.value) {
        return { 'applicantIsKe': true };
    } else {
        return null;
    }
};

