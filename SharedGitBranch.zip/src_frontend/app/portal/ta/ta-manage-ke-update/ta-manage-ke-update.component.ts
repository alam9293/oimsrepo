import { Component, OnInit, HostListener } from '@angular/core';
import { CommonService, AlertService, MyInfoService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { FileUtil, FormUtil, NumeralUtil } from '../../../common/helper';
import { ActivatedRoute, Router } from '@angular/router';
import { TaKeUpdateService } from './ta-manage-ke-update.service';
import { Observable } from 'rxjs';
import { ManageKeAppHelperUtil, TaFormHelperUtil } from '../ta-helper';
import { MatDialog, } from "@angular/material";

@Component({
    selector: 'app-ta-manage-ke-update',
    templateUrl: './ta-manage-ke-update.component.html',
    styleUrls: ['./ta-manage-ke-update.component.scss']
})
export class TaManageKeUpdateComponent implements OnInit {

    application: any = { applicationStatus: {}, licenceStatus: {}, haveKe: null };
    genderList: any;
    nationalityList: any;
    companyRoleList: any;
    eduList: any;
    occupationList: any;
    form: FormGroup;
    cnst = cnst;
    checked: boolean = false;
    preview: boolean = false;
    fileForm: FormGroup;
    selectedFile: File;
    myInfoNonEditableFields: string[];
    addPostal: string;
    addBlk: string;
    addSt: string;
    addBldg: string;
    addFl: string;
    addUnit: string;
    returnAppCode: string;
    unionMap = new Map<string, string>();

    constructor(public dialog: MatDialog, private taFormHelperUtil: TaFormHelperUtil, private keHelper: ManageKeAppHelperUtil, private myInfoService: MyInfoService, private alertService: AlertService, private fileUtil: FileUtil, private formUtil: FormUtil, private fb: FormBuilder, private router: Router, private service: TaKeUpdateService, private route: ActivatedRoute, private commonService: CommonService) { }
    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    ngOnInit() {
        this.initiateForm();
        this.returnAppCode = this.route.snapshot.queryParams.returnApp;
        if (this.route.snapshot.paramMap.get('appId')) {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        } else {
            this.createApp();
        }
        this.commonService.getSexes().subscribe(data => this.genderList = data);
        this.commonService.getNationalities().subscribe(data => this.nationalityList = data);
        this.commonService.getQualifications().subscribe(data => this.eduList = data);
        this.commonService.getOccupations().subscribe(data => this.occupationList = data);
    }

    // convenience getter for easy access to form fields
    get stakeholderControl() {
        if (this.form) {
            return (this.form.get('newStakeholderDto') as FormGroup).controls;
        }
    }

    get stakeholderForm() {
        if (this.form) {
            return this.form.get('newStakeholderDto') as FormGroup
        }
    }

    get taKeStakeholderForm() {
        if (this.form) {
            return this.form.get('taKeStakeholder') as FormGroup
        }
    }

    get addressForm() {
        if (this.form) {
            return this.stakeholderForm.get('address') as FormGroup
        }
    }
    get addressControl() {
        if (this.form) {
            return (this.stakeholderForm.get('address') as FormGroup).controls;
        }
    }
    get fileForms() {
        return this.form.get('files') as FormArray
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.application = data;
            this.setupForm(this.application);
            this.form.get('isMyInfoPopulated').setValue(false);
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

    createApp(): void {
        this.service.createTaLicenceAaApplication().subscribe(data => {
            this.application = data;
            if (data.haveKe) {
                this.setupForm(this.application);
                this.form.get('isMyInfoPopulated').setValue(false);
            }
        });
    }

    saveConfirmationDialog() {
        if (this.checked) {
            this.service.submit(this.form.value).subscribe(data => {
                this.alertService.clear();
                this.form.markAsPristine();
                this.service.createTaLicenceAaApplication().subscribe(data => {
                    this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { applicationNo: data.applicationNo, returnApp: this.returnAppCode } });
                });
                this.preview = false;
            });
        } else {
            alert(cnst.Messages.MSG_DECLARATION_CHECK);
        }
    }

    private setupForm(application: any) {
        this.initiateForm();
        this.addressForm.patchValue(application.newStakeholderDto.address);
        this.form.patchValue(application);
        this.mailAddress();
        this.application.files.forEach(item => {
            var req = true;
            if (cnst.DocumentTypes.TA_DOC_OTHERS === item.docType || cnst.DocumentTypes.TA_DOC_KE_RESIGN_LETTER === item.docType || !application.nricRequired && (item.docType != cnst.DocumentTypes.TA_DOC_KE_RESIGN_LETTER || item.docType != cnst.DocumentTypes.TA_DOC_OTHERS)) {
                req = false;
            }
            this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, req);
            this.fileForm.patchValue(item);
            this.fileForms.push(this.fileForm);
        });
        this.formUtil.getAddressFrmPostal(this.addressForm);
        if (application.applicationStatus.key === cnst.ApplicationStatuses.TA_APP_NEW) {
            this.keHelper.checkNricDocRequired(application.newStakeholderDto, this.stakeholderForm, this.fileForms);
            this.keHelper.compareValueForNricDoc(this.stakeholderForm.value, application.newStakeholderDto, this.fileForms);
        } else {
            this.keHelper.checkNricDocRequired(application.prevValueStakeholderDto, this.stakeholderForm, this.fileForms);
            this.keHelper.compareValueForNricDoc(this.stakeholderForm.value, application.prevValueStakeholderDto, this.fileForms);
        }

        // if (application.prevValueStakeholderDto) {
        //     this.keHelper.compareValueForNricDoc(this.form.value.newStakeholderDto, application.prevValueStakeholderDto, this.fileForms);
        // }
    }

    toDeleteFile(file, index) {
        if (file.controls.originalName.value) {
            (this.form.get('toDeleteFiles') as FormArray).push(this.fb.control(file.controls.id.value));
        }
        if (file.value.docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
            this.fileForms.removeAt(index);
        } else {
            this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
        }
    }

    showPreview() {
        this.alertService.clear();
        if (this.form.valid) {
            this.preview = true
            window.scrollTo(0, 0);
        } else {
            this.form.markAsTouched();
            this.formUtil.markFormGroupTouched(this.form);
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }


    initiateForm() {
        this.form = this.fb.group({
            stakeholderDto: this.fb.group({
                stakeholderId: [],
            }),
            newStakeholderDto: this.keHelper.initiateStakeholderForm(this.fb),
            taKeStakeholder: this.fb.group({
                taStakeholderId: [],

            }),
            files: this.fb.array([]),
            toDeleteFiles: this.fb.array([
                this.fb.control('')
            ]),
            keAppType: ['',],
            keAppTypeLabel: ['',],
            taKeAppId: '',
            applicationId: '',
            draft: '',
            isMyInfoPopulated: '',
        }, {});
    }

    loadAppMyInfo() {
        // this.myInfoService.getMyInfoPersonBasic().subscribe(data => {
        //     if (data.errorMessage) {
        //         this.alertService.clear();
        //         this.alertService.error(cnst.TaAlertMessages.MY_INFO_ERROR);
        //     } else {
        //         console.log(data);
        //         this.myInfoNonEditableFields = data.nonEditableFields;
        //         this.stakeholderForm.patchValue(this.keHelper.setMyInfoData(this.stakeholderForm, data));
        //         this.formUtil.markFormGroupTouched(this.form);
        //         this.form.get('isMyInfoPopulated').setValue(true);
        //         this.keHelper.disableNricFile(true, this.fileForms);
        //     }

        // });
    }

    manualInput() {
        this.stakeholderForm.patchValue(this.keHelper.clearMyInfo(this.stakeholderForm));
        this.form.get('isMyInfoPopulated').setValue(false);
        this.keHelper.disableNricFile(false, this.fileForms);
    }

    onPicked(input: HTMLInputElement, docType: string, index) {
        this.selectedFile = input.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(docType, this.selectedFile).subscribe(data => {
                if (docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
                    this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, false);
                    this.fileForm.patchValue(data);
                    this.fileForms.push(this.fileForm);
                } else {
                    var file: any = data;
                    if (file.originalName) {
                        this.fileForms.at(index).patchValue(file);
                    } else {
                        this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
                    }
                }
            });
        }
    }

    mailAddress() {
        if (this.stakeholderForm.get('scpr')) {
            this.addPostal = cnst.MyInfoFields.REG_ADD_POSTAL;
            this.addBlk = cnst.MyInfoFields.REG_ADD_BLOCK;
            this.addSt = cnst.MyInfoFields.REG_ADD_STREET;
            this.addBldg = cnst.MyInfoFields.REG_ADD_BUILDING;
            this.addFl = cnst.MyInfoFields.REG_ADD_FLOOR;
            this.addUnit = cnst.MyInfoFields.REG_ADD_UNIT;
        } else {
            this.addPostal = cnst.MyInfoFields.MAIL_ADD_POSTAL;
            this.addBlk = cnst.MyInfoFields.MAIL_ADD_BLOCK;
            this.addSt = cnst.MyInfoFields.MAIL_ADD_STREET;
            this.addBldg = cnst.MyInfoFields.MAIL_ADD_BUILDING;
            this.addFl = cnst.MyInfoFields.MAIL_ADD_FLOOR;
            this.addUnit = cnst.MyInfoFields.MAIL_ADD_UNIT;
        }
    }
}

