import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class TaKeUpdateService {

    constructor(private http: HttpClient) { }

    createTaLicenceAaApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_UPDATE_DETAILS + '/new');
    }

    submit(application: any): Observable<any> {
        if (application.applicationId) {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_UPDATE_DETAILS + '/update', application);
        } else {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_UPDATE_DETAILS + '/save', application);
        }
    }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_UPDATE_DETAILS + '/load/' + applicationId);
    }

}
