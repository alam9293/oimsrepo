import { Component, OnInit, Inject, Input, HostListener } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, ValidationErrors, ValidatorFn, FormControl } from '@angular/forms';
import { forkJoin, Observable } from 'rxjs';
import { TaPersonnelService } from './ta-personnel-list.service';
import { CommonService, AlertService, EdhService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormUtil, DateUtil, ValidateEmail, ValidateAddressInput, ValidateAddressInputIncDash } from 'src/app/common/helper';
@Component({
    selector: 'app-ta-personnel-list',
    templateUrl: './ta-personnel-list.component.html',
    styleUrls: ['./ta-personnel-list.component.scss']
})
export class TaPersonnelListComponent implements OnInit {
    @Input() id: number;
    personnelList: any;
    editMode: boolean = false;
    preview: boolean = false;
    formPersonnel: FormGroup;
    sexes: any = [];
    occupations: any = [];
    nationalities: any = [];
    qualifications: any = [];
    roles: any = [];
    address_types: any = [];
    cnst = cnst;
    returnAppCode: string;
    isEdhError: boolean = false;

    constructor(
        private alertService: AlertService,
        private service: TaPersonnelService,
        public dialog: MatDialog,
        private route: ActivatedRoute,
        private router: Router,
        private edhService: EdhService,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private formUtil: FormUtil,
    ) { }

    ngOnInit() {
        this.returnAppCode = this.route.snapshot.queryParams.returnApp;
        this.service.getPersonnelList().subscribe(data => {
            this.personnelList = data;
        });
    }

    openTaPersonnelDetailsDialog(id: number) {
        if (!this.editMode) {
            this.service.getPersonnelParticulars(id).subscribe(data => {
                this.dialog.open(DialogPersonnelDetailsComponent, {
                    data: { personnel: data, editMode: false },
                    width: '1200px',
                    disableClose: true
                });
            });
        } else {
            const dialogRef = this.dialog.open(DialogPersonnelDetailsComponent, {
                data: { personnel: this.taStakeholders.at(id), editMode: true, sexes: this.sexes, nationalities: this.nationalities, qualifications: this.qualifications, occupations: this.occupations, roles: this.roles, address_types: this.address_types, isEdhPopulated: this.formPersonnel.get('isEdhPopulated').value },
                width: '1200px',
                disableClose: true
            });

            dialogRef.afterClosed().subscribe(result => {
                for (let p of this.taStakeholders.controls) {
                    if ((this.taStakeholders.at(id).get('new').get('particulars').get('uin').value && p.get('new').get('particulars').get('uin').value == this.taStakeholders.at(id).get('new').get('particulars').get('uin').value) || (this.taStakeholders.at(id).get('new').get('particulars').get('companyUen').value && p.get('new').get('particulars').get('companyUen').value == this.taStakeholders.at(id).get('new').get('particulars').get('companyUen').value)) {
                        p.get('new').get('particulars').get('contactNo').setValue(this.taStakeholders.at(id).get('new').get('particulars').get('contactNo').value);
                        p.get('new').get('particulars').get('email').setValue(this.taStakeholders.at(id).get('new').get('particulars').get('email').value);
                        p.get('new').get('particulars').get('sex').get('key').setValue(this.taStakeholders.at(id).get('new').get('particulars').get('sex').get('key').value);
                        p.get('new').get('particulars').get('nationality').get('key').setValue(this.taStakeholders.at(id).get('new').get('particulars').get('nationality').get('key').value);
                    }
                }
            });
        }
    }

    addPersonnel() {
        let x = this.addPersonnelDtoFormControl();
        const dialogRef = this.dialog.open(DialogPersonnelDetailsComponent, {
            data: { personnel: x, editMode: true, sexes: this.sexes, nationalities: this.nationalities, qualifications: this.qualifications, occupations: this.occupations, roles: this.roles, address_types: this.address_types, isEdhPopulated: this.formPersonnel.get('isEdhPopulated').value },
            width: '1200px',
            disableClose: true
        });

        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.taStakeholders.push(x);
            }

        });
    }

    deletePersonnel(i) {
        this.taStakeholders.removeAt(i);
    }

    edit(toLoadEdh) {
        this.service.getFullPersonnelList().subscribe(data => {
            this.buildForm(data, toLoadEdh);
            this.loadCommonTypes();
        });
    }

    buildForm(data, toLoadEdh) {
        this.formPersonnel = this.formBuilder.group({
            isEdhPopulated: [toLoadEdh],
            taStakeholders: this.formBuilder.array([]),
        });
        if (data.length > 0) {
            data.forEach(row => {
                let x = this.addPersonnelDtoFormControl();
                x.get('new').patchValue(row);
                x.get('current').patchValue(row);
                this.taStakeholders.push(x);
            });
        }
        if (toLoadEdh) {
            this.loadEdh();
        }

        this.editMode = true;
    }

    addPersonnelDtoFormControl() {
        return this.formBuilder.group({
            new: this.formBuilder.group({
                particulars: this.formBuilder.group({
                    stakeholderId: [''],
                    isCompany: [''],
                    companyUen: [''],
                    companyIncorporatedDate: [''],
                    stakeholderName: ['', Validators.required],
                    uin: [''],
                    formerUin: [''],
                    dob: [''],
                    contactNo: ['', [Validators.required, Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
                    email: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
                    sex: this.formBuilder.group({
                        key: [''],
                        label: ['']
                    }),
                    nationality: this.formBuilder.group({
                        key: [''],
                        label: ['']
                    }),
                    address: this.formBuilder.group({
                        street: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET), ValidateAddressInputIncDash]],
                        building: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING), ValidateAddressInputIncDash]],
                        block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                        floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                        unit: ['', ValidateAddressInputIncDash], // does not follow SGDRM as EDH returns "01/02" etc when there are multiple units
                        postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                        foreignLine1: [''],
                        foreignLine2: [''],
                        foreignLine3: [''],
                        formatted: [''],
                        singleLined: [''],
                        type: this.formBuilder.group({
                            key: ['', Validators.required],
                            label: ['']
                        }),
                    }),
                }),
                involvement: this.formBuilder.group({
                    taStakeholderId: [''],
                    sharesHeld: ['', Validators.pattern('^[0-9 ]*$')],
                    appointedDate: ['', Validators.required],
                    resignedDate: [''],
                    role: this.formBuilder.group({
                        key: ['', Validators.required],
                        label: ['']
                    }),
                }),
            }),
            current: this.formBuilder.group({
                particulars: this.formBuilder.group({
                    stakeholderId: [''],
                    isCompany: [''],
                    companyUen: [''],
                    companyIncorporatedDate: [''],
                    stakeholderName: [''],
                    uin: [''],
                    formerUin: [''],
                    dob: [''],
                    contactNo: [''],
                    email: [''],
                    sex: this.formBuilder.group({
                        key: [''],
                        label: ['']
                    }),
                    nationality: this.formBuilder.group({
                        key: [''],
                        label: ['']
                    }),
                    address: this.formBuilder.group({
                        street: [''],
                        building: [''],
                        block: [''],
                        floor: [''],
                        unit: [''],
                        postal: [''],
                        foreignLine1: [''],
                        foreignLine2: [''],
                        foreignLine3: [''],
                        formatted: [''],
                        singleLined: [''],
                        type: this.formBuilder.group({
                            key: [''],
                            label: ['']
                        }),
                    }),
                }),
                involvement: this.formBuilder.group({
                    taStakeholderId: [''],
                    sharesHeld: [''],
                    appointedDate: [''],
                    resignedDate: [''],
                    role: this.formBuilder.group({
                        key: [''],
                        label: ['']
                    }),
                }),
            })

        }, { validator: [this.personnelUinRequiredValidator(), this.personnelUenRequiredValidator(), this.sharesheldRequiredValidator(), this.shAddRequiredValidator()] })
    }
    personnelUinRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (form != null) {
                let obj = {};
                if (form.get('new').get('particulars').get('isCompany').value == false && !form.get('new').get('particulars').get('uin').value) {
                    obj = { ...obj, uinRequired: true };
                }
                if (form.get('new').get('particulars').get('isCompany').value == false && !form.get('new').get('particulars').get('nationality').get('key').value) {
                    obj = { ...obj, nationalityRequired: true };
                }
                if (form.get('new').get('particulars').get('isCompany').value == false && !form.get('new').get('particulars').get('sex').get('key').value) {
                    obj = { ...obj, genderRequired: true };
                }
                return obj;
            } else {
                return null;
            }
        }
    }

    personnelUenRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (form != null) {
                let obj = {};
                if (form.get('new').get('particulars').get('isCompany').value == true && !form.get('new').get('particulars').get('companyUen').value) {
                    obj = { ...obj, uenRequired: true };
                }
                if (form.get('new').get('particulars').get('isCompany').value == true && !form.get('new').get('particulars').get('companyIncorporatedDate').value) {
                    obj = { ...obj, incorporatedDateRequired: true };
                }
                return obj;
            } else {
                return null;
            }
        }
    }

    sharesheldRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return (form.get('new').get('involvement').get('role').get('key').value == cnst.StakeholderRoles.STKHLD_SHAREHOLDER && (!form.get('new').get('involvement').get('sharesHeld').value && form.get('new').get('involvement').get('sharesHeld').value != 0) ? { sharesHeldRequired: true } : null);
        }
    }
    shAddRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (form) {
                let obj = {};
                if (form.get('new').get('particulars').get('address').get('type').get('key').value == cnst.AddressTypes.ADDR_LOCAL) {
                    if (!form.get('new').get('particulars').get('address').get('postal').value) {
                        obj = { ...obj, shAddPostalRequired: true };
                    }
                    if (!form.get('new').get('particulars').get('address').get('block').value) {
                        obj = { ...obj, shAddBlockRequired: true };
                    }
                    if (!form.get('new').get('particulars').get('address').get('street').value) {
                        obj = { ...obj, shAddStreetRequired: true };
                    }
                } else if (form.get('new').get('particulars').get('address').get('type').get('key').value == cnst.AddressTypes.ADDR_FOREIGN) {
                    if (!form.get('new').get('particulars').get('address').get('foreignLine1').value) {
                        obj = { ...obj, shAddForeignLine1Required: true };
                    }
                }
                return obj;
            } else {
                return null;
            }

        }
    }

    formControlValueChanged() {



    }


    get taStakeholders() {
        return this.formPersonnel.get('taStakeholders') as FormArray
    }

    loadEdh() {
        this.isEdhError = false;
        forkJoin([
            this.edhService.getEdhEntityShareholders(),
            this.edhService.getEdhEntityAppointments(),
        ]).subscribe(data => {
            //getEdhEntityShareholders
            if (data[0].errorMessage) {
                this.isEdhError = true;
            } else {
                data[0].records.forEach(record => {
                    let exist = false;
                    for (let stakeholder of this.taStakeholders.controls) {
                        if (((record.allotedPerson && stakeholder.get('current').get('particulars').get('uin').value == record.allotedPerson.idNumber) || (record.allotedEntity && stakeholder.get('current').get('particulars').get('companyUen').value == record.allotedEntity.registrationNumber)) && stakeholder.get('current').get('involvement').get('role').get('key').value == cnst.StakeholderRoles.STKHLD_SHAREHOLDER) {
                            exist = true;
                            if (record.allotedPerson) {
                                stakeholder.get('new').get('particulars').get('isCompany').setValue(false);
                                stakeholder.get('new').get('particulars').get('stakeholderName').setValue(record.allotedPerson.name);
                                stakeholder.get('new').get('particulars').get('uin').setValue(record.allotedPerson.idNumber);
                            } else {
                                stakeholder.get('new').get('particulars').get('isCompany').setValue(true);
                                stakeholder.get('new').get('particulars').get('stakeholderName').setValue(record.allotedEntity.name);
                                stakeholder.get('new').get('particulars').get('companyUen').setValue(record.allotedEntity.registrationNumber);
                            }
                            if (record.addressOfAlloted) {
                                stakeholder.get('new').get('particulars').get('address').get('type').get('key').setValue(record.addressOfAlloted.type);
                                if (record.addressOfAlloted.type == cnst.AddressTypes.ADDR_LOCAL) {
                                    stakeholder.get('new').get('particulars').get('address').get('postal').setValue(record.addressOfAlloted.postalCode);
                                    stakeholder.get('new').get('particulars').get('address').get('block').setValue(record.addressOfAlloted.houseBlockNumber);
                                    stakeholder.get('new').get('particulars').get('address').get('street').setValue(record.addressOfAlloted.streetName);
                                    stakeholder.get('new').get('particulars').get('address').get('building').setValue(record.addressOfAlloted.buildingName);
                                    stakeholder.get('new').get('particulars').get('address').get('floor').setValue(record.addressOfAlloted.levelNumber);
                                    stakeholder.get('new').get('particulars').get('address').get('unit').setValue(record.addressOfAlloted.unitNumber);
                                    stakeholder.get('new').get('particulars').get('address').get('foreignLine1').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('foreignLine2').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                                } else {
                                    stakeholder.get('new').get('particulars').get('address').get('foreignLine1').setValue(record.addressOfAlloted.unformattedAddressLines[0]);
                                    stakeholder.get('new').get('particulars').get('address').get('foreignLine2').setValue(record.addressOfAlloted.unformattedAddressLines[1]);
                                    stakeholder.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('postal').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('block').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('street').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('building').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('floor').setValue(null);
                                    stakeholder.get('new').get('particulars').get('address').get('unit').setValue(null);
                                }
                            } else {
                                stakeholder.get('new').get('particulars').get('address').get('type').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
                            }

                            stakeholder.get('new').get('involvement').get('role').get('key').setValue(cnst.StakeholderRoles.STKHLD_SHAREHOLDER);
                            stakeholder.get('new').get('involvement').get('sharesHeld').setValue(record.allotedNumber);
                            break;
                        }
                    }
                    if (!exist) {
                        let x = this.addPersonnelDtoFormControl();
                        if (record.allotedPerson) {
                            x.get('new').get('particulars').get('isCompany').setValue(false);
                            x.get('new').get('particulars').get('stakeholderName').setValue(record.allotedPerson.name);
                            x.get('new').get('particulars').get('uin').setValue(record.allotedPerson.idNumber);
                        } else {
                            x.get('new').get('particulars').get('isCompany').setValue(true);
                            x.get('new').get('particulars').get('stakeholderName').setValue(record.allotedEntity.name);
                            x.get('new').get('particulars').get('companyUen').setValue(record.allotedEntity.registrationNumber);
                        }
                        if (record.addressOfAlloted) {
                            x.get('new').get('particulars').get('address').get('type').get('key').setValue(record.addressOfAlloted.type);
                            if (record.addressOfAlloted.type == cnst.AddressTypes.ADDR_LOCAL) {
                                x.get('new').get('particulars').get('address').get('postal').setValue(record.addressOfAlloted.postalCode);
                                x.get('new').get('particulars').get('address').get('block').setValue(record.addressOfAlloted.houseBlockNumber);
                                x.get('new').get('particulars').get('address').get('street').setValue(record.addressOfAlloted.streetName);
                                x.get('new').get('particulars').get('address').get('building').setValue(record.addressOfAlloted.buildingName);
                                x.get('new').get('particulars').get('address').get('floor').setValue(record.addressOfAlloted.levelNumber);
                                x.get('new').get('particulars').get('address').get('unit').setValue(record.addressOfAlloted.unitNumber);
                                x.get('new').get('particulars').get('address').get('foreignLine1').setValue(null);
                                x.get('new').get('particulars').get('address').get('foreignLine2').setValue(null);
                                x.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                            } else {
                                x.get('new').get('particulars').get('address').get('foreignLine1').setValue(record.addressOfAlloted.unformattedAddressLines[0]);
                                x.get('new').get('particulars').get('address').get('foreignLine2').setValue(record.addressOfAlloted.unformattedAddressLines[1]);
                                x.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                                x.get('new').get('particulars').get('address').get('postal').setValue(null);
                                x.get('new').get('particulars').get('address').get('block').setValue(null);
                                x.get('new').get('particulars').get('address').get('street').setValue(null);
                                x.get('new').get('particulars').get('address').get('building').setValue(null);
                                x.get('new').get('particulars').get('address').get('floor').setValue(null);
                                x.get('new').get('particulars').get('address').get('unit').setValue(null);
                            }
                        } else {
                            x.get('new').get('particulars').get('address').get('type').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
                        }

                        x.get('new').get('involvement').get('role').get('key').setValue(cnst.StakeholderRoles.STKHLD_SHAREHOLDER);
                        x.get('new').get('involvement').get('sharesHeld').setValue(record.allotedNumber);
                        this.taStakeholders.push(x);
                    }

                });


                this.taStakeholders.controls.forEach(element => {
                    if (element.get('new').get('involvement').get('role').get('key').value == cnst.StakeholderRoles.STKHLD_SHAREHOLDER) {
                        let exist = false;
                        for (let edhRecord of data[0].records) {
                            if ((edhRecord.allotedPerson && element.get('new').get('particulars').get('uin').value == edhRecord.allotedPerson.idNumber) ||
                                (edhRecord.allotedEntity && element.get('new').get('particulars').get('companyUen').value == edhRecord.allotedEntity.registrationNumber)) {
                                exist = true;
                                break;
                            }

                        }
                        if (exist == false) {
                            element.get('new').get('involvement').get('resignedDate').setValue(DateUtil.getNow().format(DateUtil.DATE_FORMAT));
                        }
                    }

                });

            }
            //getEdhEntityAppointments
            if (!this.isEdhError) {
                if (data[1].errorMessage) {
                    this.isEdhError = true;
                } else {
                    data[1].records.forEach(record => {
                        if (record.positionHeld != 'STKHLD_AUD') {
                            let exist = false;
                            for (let stakeholder of this.taStakeholders.controls) {
                                if (((record.appointedPerson && stakeholder.get('current').get('particulars').get('uin').value == record.appointedPerson.idNumber) || (record.appointedEntity && stakeholder.get('current').get('particulars').get('companyUen').value == record.appointedEntity.registrationNumber)) && stakeholder.get('current').get('involvement').get('role').get('key').value == record.positionHeld) {
                                    exist = true;
                                    if (record.appointedPerson) {
                                        stakeholder.get('new').get('particulars').get('isCompany').setValue(false);
                                        stakeholder.get('new').get('particulars').get('stakeholderName').setValue(record.appointedPerson.name);
                                        stakeholder.get('new').get('particulars').get('uin').setValue(record.appointedPerson.idNumber);

                                    } else {
                                        stakeholder.get('new').get('particulars').get('isCompany').setValue(true);
                                        stakeholder.get('new').get('particulars').get('stakeholderName').setValue(record.appointedEntity.name);
                                        stakeholder.get('new').get('particulars').get('companyUen').setValue(record.appointedEntity.registrationNumber);
                                    }
                                    if (record.addressOfAppointed) {
                                        stakeholder.get('new').get('particulars').get('address').get('type').get('key').setValue(record.addressOfAppointed.type);
                                        if (record.addressOfAppointed.type == cnst.AddressTypes.ADDR_LOCAL) {
                                            stakeholder.get('new').get('particulars').get('address').get('postal').setValue(record.addressOfAppointed.postalCode);
                                            stakeholder.get('new').get('particulars').get('address').get('block').setValue(record.addressOfAppointed.houseBlockNumber);
                                            stakeholder.get('new').get('particulars').get('address').get('street').setValue(record.addressOfAppointed.streetName);
                                            stakeholder.get('new').get('particulars').get('address').get('building').setValue(record.addressOfAppointed.buildingName);
                                            stakeholder.get('new').get('particulars').get('address').get('floor').setValue(record.addressOfAppointed.levelNumber);
                                            stakeholder.get('new').get('particulars').get('address').get('unit').setValue(record.addressOfAppointed.unitNumber);
                                            stakeholder.get('new').get('particulars').get('address').get('foreignLine1').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('foreignLine2').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                                        } else {
                                            stakeholder.get('new').get('particulars').get('address').get('foreignLine1').setValue(record.addressOfAppointed.unformattedAddressLines[0]);
                                            stakeholder.get('new').get('particulars').get('address').get('foreignLine2').setValue(record.addressOfAppointed.unformattedAddressLines[1]);
                                            stakeholder.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('postal').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('block').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('street').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('building').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('floor').setValue(null);
                                            stakeholder.get('new').get('particulars').get('address').get('unit').setValue(null);
                                        }
                                    } else {
                                        stakeholder.get('new').get('particulars').get('address').get('type').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
                                    }

                                    stakeholder.get('new').get('involvement').get('appointedDate').setValue(record.entryDate);
                                    stakeholder.get('new').get('involvement').get('resignedDate').setValue(record.withdrawalDate);
                                    stakeholder.get('new').get('involvement').get('role').get('key').setValue(record.positionHeld);
                                }
                            }
                            if (!exist && !record.withdrawalDate) {
                                let x = this.addPersonnelDtoFormControl();
                                if (record.appointedPerson) {
                                    x.get('new').get('particulars').get('isCompany').setValue(false);
                                    x.get('new').get('particulars').get('stakeholderName').setValue(record.appointedPerson.name);
                                    x.get('new').get('particulars').get('uin').setValue(record.appointedPerson.idNumber);

                                } else {
                                    x.get('new').get('particulars').get('isCompany').setValue(true);
                                    x.get('new').get('particulars').get('stakeholderName').setValue(record.appointedEntity.name);
                                    x.get('new').get('particulars').get('companyUen').setValue(record.appointedEntity.registrationNumber);
                                }
                                if (record.addressOfAppointed) {
                                    x.get('new').get('particulars').get('address').get('type').get('key').setValue(record.addressOfAppointed.type);
                                    if (record.addressOfAppointed.type == cnst.AddressTypes.ADDR_LOCAL) {
                                        x.get('new').get('particulars').get('address').get('postal').setValue(record.addressOfAppointed.postalCode);
                                        x.get('new').get('particulars').get('address').get('block').setValue(record.addressOfAppointed.houseBlockNumber);
                                        x.get('new').get('particulars').get('address').get('street').setValue(record.addressOfAppointed.streetName);
                                        x.get('new').get('particulars').get('address').get('building').setValue(record.addressOfAppointed.buildingName);
                                        x.get('new').get('particulars').get('address').get('floor').setValue(record.addressOfAppointed.levelNumber);
                                        x.get('new').get('particulars').get('address').get('unit').setValue(record.addressOfAppointed.unitNumber);
                                        x.get('new').get('particulars').get('address').get('foreignLine1').setValue(null);
                                        x.get('new').get('particulars').get('address').get('foreignLine2').setValue(null);
                                        x.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                                    } else {
                                        x.get('new').get('particulars').get('address').get('foreignLine1').setValue(record.addressOfAppointed.unformattedAddressLines[0]);
                                        x.get('new').get('particulars').get('address').get('foreignLine2').setValue(record.addressOfAppointed.unformattedAddressLines[1]);
                                        x.get('new').get('particulars').get('address').get('foreignLine3').setValue(null);
                                        x.get('new').get('particulars').get('address').get('postal').setValue(null);
                                        x.get('new').get('particulars').get('address').get('block').setValue(null);
                                        x.get('new').get('particulars').get('address').get('street').setValue(null);
                                        x.get('new').get('particulars').get('address').get('building').setValue(null);
                                        x.get('new').get('particulars').get('address').get('floor').setValue(null);
                                        x.get('new').get('particulars').get('address').get('unit').setValue(null);
                                    }
                                } else {
                                    x.get('new').get('particulars').get('address').get('type').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
                                }

                                x.get('new').get('involvement').get('appointedDate').setValue(record.entryDate);
                                x.get('new').get('involvement').get('role').get('key').setValue(record.positionHeld);
                                this.taStakeholders.push(x);
                            }
                        }

                    });
                }
            }
            if (this.isEdhError) {
                this.clearEdh();
                this.alertService.error(cnst.TaAlertMessages.EDH_ERROR);
            } else {
                this.formPersonnel.get('isEdhPopulated').setValue(true);
            }
        });
    }

    retrieveEdh() {
        this.edit(true);
    };

    clearEdh() {
        this.edit(false);
    }

    loadCommonTypes() {
        this.commonService.getSexes().subscribe(data => this.sexes = data);
        this.commonService.getNationalities().subscribe(data => this.nationalities = data);
        this.commonService.getOccupations().subscribe(data => this.occupations = data);
        this.commonService.getQualifications().subscribe(data => this.qualifications = data);
        this.commonService.getStakeholderRoles().subscribe(data => this.roles = data);
        this.commonService.getAddressTypes().subscribe(data => this.address_types = data);
    }

    onPreview() {
        this.alertService.clear();
        if (this.formPersonnel.invalid) {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        } else {
            this.preview = true;
            window.scrollTo(0, 0);
        }
    }

    submit() {
        this.alertService.clear();
        if (this.formPersonnel.invalid) {
            this.alertService.error("Please ensure all fields are filled up correctly");
        } else {
            let stakeholders = [];
            this.taStakeholders.controls.forEach(element => {
                stakeholders.push(element.get('new').value);
            });
            this.service.savePersonnelList(stakeholders, this.formPersonnel.get('isEdhPopulated').value).subscribe(data => {
                this.service.getApplicationNo(data).subscribe(data => {
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { applicationNo: data[0], returnApp: this.returnAppCode } });
                });

            });
        }
    }
}

@Component({
    selector: 'app-ta-dialog-personnel-details',
    templateUrl: 'ta-dialog-personnel-details.component.html',
    styleUrls: ['ta-dialog-personnel-details.component.scss']
})
export class DialogPersonnelDetailsComponent {
    constructor(
        private formBuilder: FormBuilder,
        public formUtil: FormUtil,
        public dialogRef: MatDialogRef<DialogPersonnelDetailsComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private service: TaPersonnelService,
        private commonService: CommonService,

    ) { }
    formPersonnel: FormGroup = this.formBuilder.group({
        new: this.formBuilder.group({
            particulars: this.formBuilder.group({
                stakeholderId: [''],
                isCompany: [false],
                companyUen: [''],
                companyIncorporatedDate: [''],
                stakeholderName: ['', Validators.required],
                uin: [''],
                formerUin: [''],
                dob: [''],
                contactNo: ['', [Validators.required, Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
                email: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
                sex: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
                nationality: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
                address: this.formBuilder.group({
                    street: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)],
                    building: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
                    block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    unit: [''], // does not follow SGDRM as EDH returns "01/02" etc when there are multiple units
                    postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    foreignLine1: [''],
                    foreignLine2: [''],
                    foreignLine3: [''],
                    formatted: [''],
                    singleLined: [''],
                    type: this.formBuilder.group({
                        key: ['', Validators.required],
                        label: ['']
                    }),
                }),
            }),
            involvement: this.formBuilder.group({
                taStakeholderId: [''],
                sharesHeld: ['', Validators.pattern('^[0-9 ]*$')],
                appointedDate: ['', Validators.required],
                resignedDate: [''],
                role: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
            }),
        }),
        current: this.formBuilder.group({
            particulars: this.formBuilder.group({
                stakeholderId: [''],
                isCompany: [false],
                companyUen: [''],
                companyIncorporatedDate: [''],
                stakeholderName: [''],
                uin: [''],
                formerUin: [''],
                dob: [''],
                contactNo: [''],
                email: [''],
                sex: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
                nationality: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
                address: this.formBuilder.group({
                    street: [''],
                    building: [''],
                    block: [''],
                    floor: [''],
                    unit: [''],
                    postal: [''],
                    foreignLine1: [''],
                    foreignLine2: [''],
                    foreignLine3: [''],
                    formatted: [''],
                    singleLined: [''],
                    type: this.formBuilder.group({
                        key: [''],
                        label: ['']
                    }),
                }),
            }),
            involvement: this.formBuilder.group({
                taStakeholderId: [''],
                sharesHeld: [''],
                appointedDate: [''],
                resignedDate: [''],
                role: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
            }),
        })
    });
    cnst = cnst;
    personnel: any = { particulars: { sex: {}, nationality: {}, address: { type: {} }, designation: {} }, involvement: { role: {} } };
    editMode: boolean = false;
    edhPopulated: boolean = true;
    showErrorMsg: boolean = true;
    sexes: any = [];
    occupations: any = [];
    nationalities: any = [];
    qualifications: any = [];
    roles: any = [];
    address_types: any = [];

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.formPersonnel.pristine;
    }

    ngOnInit() {
        this.editMode = this.data.editMode;
        if (this.editMode) {
            this.formPersonnel = this.data.personnel;
            this.personnel = this.formPersonnel.get('new').value;
            if (this.formPersonnel.get('new').get('involvement').get('role').get('key').value == cnst.StakeholderRoles.STKHLD_KE) {
                this.editMode = false;
                this.personnel = this.formPersonnel.get('new').value;
            }
        } else {
            this.personnel = this.data.personnel;
        }

        this.sexes = this.data.sexes
        this.occupations = this.data.occupations;
        this.nationalities = this.data.nationalities;
        this.qualifications = this.data.qualifications;
        this.roles = this.data.roles;
        this.address_types = this.data.address_types;
        this.edhPopulated = this.data.isEdhPopulated;
        this.formControlValueChanged();
    }

    onCancelClick(decision) {
        this.dialogRef.close(decision);
    }

    formControlValueChanged() {

        this.formPersonnel.get('new').get('particulars').get('address').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (!this.edhPopulated) {
                    if (postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                        this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                            if (data) {
                                var addrResults = data['results'];

                                if (addrResults.length > 0) {
                                    var blkNo = addrResults[0]['BLK_NO'].trim();
                                    var roadName = addrResults[0]['ROAD_NAME'].trim();
                                    var building = addrResults[0]['BUILDING'].trim();

                                    this.formPersonnel.get('new').get('particulars').get('address').get('block').setValue(blkNo);
                                    this.formPersonnel.get('new').get('particulars').get('address').get('street').setValue(roadName);
                                    this.formPersonnel.get('new').get('particulars').get('address').get('building').setValue(building);


                                }
                            }
                        });
                    }
                }


            });

    }
}






