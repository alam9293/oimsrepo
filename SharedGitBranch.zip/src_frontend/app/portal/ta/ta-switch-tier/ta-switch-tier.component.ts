
import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { TaSwitchTierService } from './ta-switch-tier-service';
import { CommonService, AlertService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil } from '../../../common/helper';
import { FormBuilder, FormGroup, Validators, FormArray, ValidatorFn, ValidationErrors } from '@angular/forms';
import { Observable } from 'rxjs';
import { TaFormHelperUtil } from '../ta-helper';

@Component({
    selector: 'app-ta-switch-tier',
    templateUrl: './ta-switch-tier.component.html',
    styleUrls: ['./ta-switch-tier.component.scss']
})
export class TaSwitchTierComponent implements OnInit {

    constructor(public taFormHelperUtil: TaFormHelperUtil, private alertService: AlertService, private fb: FormBuilder, private commonService: CommonService, private service: TaSwitchTierService, private fileUtil: FileUtil, private formUtil: FormUtil, public dialog: MatDialog, private route: ActivatedRoute, private router: Router) { }
    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    application: any = { applicationStatus: {}, licenceStatus: {} };
    taTierLicences: any;
    cnst = cnst;
    checked: boolean = false;
    preview: boolean = false;
    selectedFile: File;
    form: FormGroup;
    files: any;
    fileForm: FormGroup;
    taServices: any;
    bizOpsForm: FormGroup;
    serviceNames: string[];
    unionMap = new Map<string, string>();
    ngOnInit() {

        this.form = this.fb.group({
            id: '',
            newLicenceTierCode: ['', Validators.required],
            oldLicenceTierCode: '',
            applicationId: '',
            licenceId: '',
            newTierStartDate: ['', Validators.required],
            files: this.fb.array([]),
            toDeleteFiles: this.fb.array([
                this.fb.control('')
            ]),
            taBusinessOperations: this.fb.array([], [this.taFormHelperUtil.minLengthArray(1), inboundTotalValidator, outboundTotalValidator, this.taFormHelperUtil.duplicatedSelectionValidator('service')]),
            newTaBusinessOperations: this.fb.array([], [this.taFormHelperUtil.minLengthArray(1), inboundTotalValidator, outboundTotalValidator, this.taFormHelperUtil.duplicatedSelectionValidator('service')]),
            toDeletebusinessRows: this.fb.array([
                this.fb.control('')
            ]),
        });
        this.commonService.getTaLicenceTiers().subscribe(data => this.taTierLicences = data);
        this.commonService.getTaServices().subscribe(data => this.taServices = data);
        if (this.route.snapshot.paramMap.get('appId')) {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        } else {
            this.createTaLicence();
        }
    }

    get bizOpsForms() {
        return this.form.get('taBusinessOperations') as FormArray
    }

    get newBizOpsForms() {
        return this.form.get('newTaBusinessOperations') as FormArray
    }

    get fileForms() {
        return this.form.get('files') as FormArray
    }

    createTaLicence(): void {
        this.service.createTaLicenceTierSwitchApplication().subscribe(data => {
            this.application = data;
            this.setupForm(this.application);
        });

    }

    remove(i: number, itemrow, name) {
        (this.form.get(name) as FormArray).removeAt(i);
        if (itemrow.value.id) {
            (this.form.get('toDeletebusinessRows') as FormArray).push(this.fb.control(itemrow.value.id));
        }
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.application = data;
            this.setupForm(this.application);
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

    initBusinessItemRow(fb: FormBuilder) {
        return fb.group({
            id: [],
            service: fb.group({
                key: ['', Validators.required],
                label: ['',]
            }),
            inboundPercent: ['0', Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
            outboundPercent: ['0', Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
        },
            { validator: Validators.compose([matchingMissingBothInboundOutboundValidator,]) }
        );
    }

    private setupForm(application: any) {
        this.form.patchValue(application);
        if (application.taBusinessOperations) {
            application.taBusinessOperations.forEach(item => {
                this.bizOpsForm = this.initBusinessItemRow(this.fb);
                this.bizOpsForm.patchValue(item);
                this.bizOpsForms.push(this.bizOpsForm);
            });
        }

        if (application.newTaBusinessOperations) {
            application.newTaBusinessOperations.forEach(item => {
                this.bizOpsForm = this.initBusinessItemRow(this.fb);
                this.bizOpsForm.patchValue(item);
                this.newBizOpsForms.push(this.bizOpsForm);
            });
        }

        this.application.files.forEach(item => {
            let req = true;
            if (item.docType === cnst.DocumentTypes.TA_DOC_OTHERS || (application.newLicenceTierCode === cnst.TaLicenceTier.TA_TIER_N && item.docType === cnst.DocumentTypes.TA_DOC_BANK)) {
                req = false;
            }
            this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, req);
            this.fileForm.patchValue(item);
            this.fileForms.push(this.fileForm);
        });
    }

    addBusinessOperation(form: FormArray) {
        form.push(this.initBusinessItemRow(this.fb));
    }

    openDialogLicenceTier() {
        const dialogRef = this.dialog.open(TaSwitchInfoDialog);
    }

    saveConfirmationDialog() {
        if (this.checked) {
            this.service.submit(this.form.value).subscribe(data => {
                this.form.markAsPristine();
                this.alertService.clear();
                this.service.createTaLicenceTierSwitchApplication().subscribe(data => {
                    this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { 'applicationNo': data.applicationNo } });
                });
                this.preview = false;
            });
        } else {
            alert(cnst.Messages.MSG_DECLARATION_CHECK);
        }
    }

    onPicked(input: HTMLInputElement, docType: string, index) {
        this.selectedFile = input.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(docType, this.selectedFile).subscribe(data => {
                if (docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
                    this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, false);
                    this.fileForm.patchValue(data);
                    this.fileForms.push(this.fileForm);
                } else {
                    var file: any = data;
                    if (file.originalName) {
                        this.fileForms.at(index).patchValue(file);
                    } else {
                        this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
                    }
                }
            });
        }
    }

    toDeleteFile(file, index) {
        if (file.controls.originalName.value) {
            (this.form.get('toDeleteFiles') as FormArray).push(this.fb.control(file.controls.id.value));
        }
        if (file.value.docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
            this.fileForms.removeAt(index);
        } else {
            this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
        }
    }

    showPreview() {
        console.log(this.form);
        this.alertService.clear();
        if (this.form.valid) {
            window.scrollTo(0, 0);
            this.preview = true
        } else {
            this.form.markAsTouched();
            this.formUtil.markFormGroupTouched(this.form);
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }

}

@Component({
    selector: 'ta-switch-tier-general-info',
    templateUrl: 'ta-switch-tier-general-info.html',
    styleUrls: ['./ta-switch-tier.component.scss']
})
export class TaSwitchInfoDialog {
    constructor(public dialogRef: MatDialogRef<TaSwitchInfoDialog>, ) { }
    closeDialog(): void {
        this.dialogRef.close();
    }
}


export const matchingMissingBothInboundOutboundValidator: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
    const inbound = control.get('inboundPercent');
    const outbound = control.get('outboundPercent');

    if (inbound && outbound) {
        if ((parseInt(inbound.value, 10) == 0) && ((parseInt(outbound.value, 10) == 0))) {
            return {
                'zeroValues': true
            };
        }
        else {
            return null;
        }
    }
};


export const inboundTotalValidator: ValidatorFn = (control: FormArray): ValidationErrors | null => {
    const array = control.value;
    let total = 0;
    if (array) {
        for (var i = 0; i < array.length; i++) {
            total = total + array[i].inboundPercent;
        }
        if (!(total == 100 || total == 0)) {
            return {
                'totalInboundError': true
            };
        } else {
            return null;
        }
    } else {
        return null;
    }
};

export const outboundTotalValidator: ValidatorFn = (control: FormArray): ValidationErrors | null => {
    const array = control.value;
    let total = 0;
    if (array) {
        for (var i = 0; i < array.length; i++) {
            total = total + array[i].outboundPercent;
        }
        if (!(total == 100 || total == 0)) {
            return {
                'totalOutboundError': true
            };
        } else {
            return null;
        }
    } else {
        return null;
    }
};