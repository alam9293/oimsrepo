import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgAssignmentCreateService {

    constructor(private http: HttpClient) { }

    public saveAssignment(application: any) {
        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/save', application);
    }

    public updateAssignment(application: any) {
        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/update', application);
    }


    public getSingleRecord(id: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/view/' + id);
    }

    public getlanguageTypes(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/view/language-types');
    }
}