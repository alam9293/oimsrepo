import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource, MatDialog, MatDialogRef } from '@angular/material';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { TgAssignmentListService } from './tg-assignment-list.service';
import { SideMenuTgService } from '../../../menu/side-menu-tg/side-menu-tg.service';
import { CommonService } from '../../../../common/services';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';
import { Router, ActivatedRoute } from '@angular/router';
import { DateUtil } from '../../../../common/helper/date.util'

@Component({
    selector: 'app-tg-assignment-list',
    templateUrl: './tg-assignment-list.component.html',
    styleUrls: ['./tg-assignment-list.component.scss']
})
export class TgAssignmentListComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    tgAssignmentDataSource = [];
    tgAssignmentDisplayedColumns = ['no', 'assignmentDate', 'assignmentEndDate', 'tourType', 'totalHours', 'empSrc', 'companyName', 'feeReceived', 'submissionDate', 'duplicate'];
    filter: any = {};
    cnst = cnst;
    record: any = { tourType: {} };
    isDeleted = false;
    selectionGroup: any;
    canAdd: boolean;
    showCurrent: boolean;
    years: any = [];
    todayDate = DateUtil.getNow();
    showDateRange: boolean = false;

    constructor(public dialog: MatDialog,
        private tgAssignmentListService: TgAssignmentListService,
        private sideMenuTgService: SideMenuTgService,
        private router: Router,
        private route: ActivatedRoute,
        private commonService: CommonService,
        public dateUtil: DateUtil) { }

    ngOnInit() {
        this.sort.sort(<MatSortable>{ id: 'startDate', start: 'desc' });
        let currentUrl = this.route.snapshot['_routerState'].url;
        if (currentUrl.indexOf('archive/view') > -1) {
            this.loadPastYears();
            this.selectionGroup = '';
            this.showCurrent = false;
            this.canAdd = false;
        } else {
            this.selectionGroup = 'current';
            this.showCurrent = true;
            this.sideMenuTgService.getSideMenu().subscribe(data => {
                var statusCode = data.licence.status.key;
                this.canAdd = statusCode == 'TG_A' || statusCode == 'TG_I';
            });
        }
        this.loadTgAssignment(this.selectionGroup);
    }

    loadPastYears() {
        this.tgAssignmentListService.getPastYears(3).subscribe(data => {
            this.years = data;
            this.filter.year = data[0].key;
            this.loadTgAssignment('');
        });
    }

    totalPages: number = 0;
    currentPage: number = 0;
    loadTgAssignment(selection: String) {
        this.selectionGroup = selection;
        this.filter.isDeleted = false;
        if (selection == 'deleted') {
            this.filter.isDeleted = true;
        }
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filter
        };

        if (selection == 'current') {
            this.tgAssignmentListService.getCurrentList(mergedDto).subscribe(data => {
                this.tgAssignmentDataSource = data.records;
                this.paginator.length = data.total;
                this.currentPage = this.paginator.pageIndex + 1;
                this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
            });
        }
        else {
            this.tgAssignmentListService.getList(mergedDto).subscribe(data => {
                this.tgAssignmentDataSource = data.records;
                this.paginator.length = data.total;
                this.currentPage = this.paginator.pageIndex + 1;
                this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
            });
        }
    }

    clearFilter() {
        this.filter.startDate = '';
        this.filter.endDate = '';
    }

    nextPage() {
        if (this.currentPage < this.totalPages) {
            this.paginator.pageIndex += 1;
            this.loadTgAssignment(this.selectionGroup);
        }
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.paginator.pageIndex -= 1;
            this.loadTgAssignment(this.selectionGroup);
        }
    }

    pageSizeChange() {
        this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        if (this.currentPage > this.totalPages) {
            this.paginator.pageIndex = this.totalPages - 1;
        }
        this.loadTgAssignment(this.selectionGroup);
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    deleteConfirmationDialog(recordId) {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: { message: 'This action will remove selected assignment' }
        });


        this.dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.record["tgAssignmentId"] = recordId;
                this.record["isDeleted"] = true;
                this.tgAssignmentListService.delete(this.record).subscribe(data => {
                    this.router.navigate(['/portal/tg/assignments/view']);
                }, error => {
                });
            }
        });
    }

    checkToDisplayDelete(deleted: boolean, licenceStartDate: Date, startDate: Date) {
        if (deleted) {
            return false;
        } else {
            if (new Date(licenceStartDate) > new Date(startDate)) {
                return false
            }
        }
        return true;
    }
}