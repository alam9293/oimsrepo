import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { TgCoursesAttendedPdcService } from './tg-courses-attended-pdc.service';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';

@Component({
    selector: 'app-tg-courses-attended-pdc',
    templateUrl: './tg-courses-attended-pdc.component.html',
    styleUrls: ['./tg-courses-attended-pdc.component.scss']
})
export class TgCoursesAttendedPdcComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    listOfCourseDataSource = [];
    listOfCoursedisplayedColumns: string[] = ['no', 'tpName', 'courseName', 'attendedDate', 'attendance'];
    filter: any = {};
    cnst = cnst;
    totalPages: number = 0;
    currentPage: number = 0;
    years: any = [];
    showDateRange: boolean = false;
    constructor(private tgCoursesAttendedPdcService: TgCoursesAttendedPdcService) { }

    ngOnInit() {
        this.sort.sort(<MatSortable>{ id: 'attendedDate', start: 'desc' });
        this.loadPastYears();
    }

    loadPastYears() {
        this.tgCoursesAttendedPdcService.getPastYears(3).subscribe(data => {
            this.years = data;
            this.filter.year = data[0].key;
            this.loadListOfCourseDetails('');
        });
    }

    loadListOfCourseDetails(selection: String) {
        this.filter.type = cnst.TpCourseTypes.pdc;
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filter
        };

        if (selection == 'current') {
            this.tgCoursesAttendedPdcService.getCurrentList(mergedDto).subscribe(data => {
                this.listOfCourseDataSource = data.records;
                this.paginator.length = data.total;
                this.currentPage = this.paginator.pageIndex + 1;
                this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
            });
        } else {
            this.tgCoursesAttendedPdcService.getListOfCourseDetails(mergedDto).subscribe(data => {
                this.listOfCourseDataSource = data.records;
                this.paginator.length = data.total;
                this.currentPage = this.paginator.pageIndex + 1;
                this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
            });
        }
    }

    clearFilter() {
        this.filter.startDate = '';
        this.filter.endDate = '';
    }

    nextPage(selection: String) {
        if (this.currentPage < this.totalPages) {
            this.paginator.pageIndex += 1;
            this.loadListOfCourseDetails(selection);
        }
    }

    previousPage(selection: String) {
        if (this.currentPage > 1) {
            this.paginator.pageIndex -= 1;
            this.loadListOfCourseDetails(selection);
        }
    }

    pageSizeChange(selection: String) {
        this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        if (this.currentPage > this.totalPages) {
            this.paginator.pageIndex = this.totalPages - 1;
        }
        this.loadListOfCourseDetails(selection);
    }
}
