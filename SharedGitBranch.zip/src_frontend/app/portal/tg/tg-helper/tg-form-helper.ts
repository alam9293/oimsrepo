import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil, } from '../../../common/helper';

@Injectable({
    providedIn: 'root'
})
export class TgFormHelperUtil {

    constructor(private fileUtil: FileUtil) { }

    removeEduLevels(data) {
        var list = [];
        for (let edu of data) {
            if (edu.key != 'EDU_0' && edu.key != 'EDU_1' && edu.key != 'EDU_2' && edu.key != 'EDU_N') {
                list.push(edu);
            }
        }
        return list;
    }

    removeResidentialStatus(data) {
        var list = [];
        for (let residential of data) {
            if (residential.key != 'RESD_N' && residential.key != 'RESD_U' && residential.key != 'RESD_A') {
                list.push(residential);
            }
        }
        return list;
    }

    checkIsProcessingOrRFA(status: any){
        return status != null && 
        (status.key == cnst.ApplicationStatuses.TG_APP_RFA || status.key == cnst.ApplicationStatuses.TG_APP_PENDING_APPROVAL ||
            status.key == cnst.ApplicationStatuses.TG_APP_PENDING_PO || status.key == cnst.ApplicationStatuses.TG_APP_PENDING_AO ||
            status.key == cnst.ApplicationStatuses.TG_APP_PENDING_HODIV);
    }

}