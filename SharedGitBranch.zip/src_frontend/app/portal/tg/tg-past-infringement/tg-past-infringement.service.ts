import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgPastInfringementService {

    constructor(private http: HttpClient) { }

    public getPastInfringements(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ce/directory/past-infringements/tg');
    }

}
