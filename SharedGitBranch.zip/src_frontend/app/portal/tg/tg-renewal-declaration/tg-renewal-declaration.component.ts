import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { CommonService } from '../../../common/services';
import { TgRenewalDeclarationService } from './tg-renewal-declaration.service';
import { TgRenewalFormService } from '../tg-renewal-form/tg-renewal-form.service';
import { Router } from '@angular/router';
import * as cnst from '../../../common/constants';
import { PaymentService } from '../../payment/payment.service';
import { PaymentDialogComponent } from 'src/app/common/modules/payment-dialog/payment-dialog.component';
import * as moment from 'moment';

@Component({
    selector: 'app-tg-renewal-declaration',
    templateUrl: './tg-renewal-declaration.component.html',
    styleUrls: ['./tg-renewal-declaration.component.scss']
})
export class TgRenewalDeclarationComponent implements OnInit {

    secondFormGroup: FormGroup;
    cnst = cnst;
    todayDate: any;
    allowBypassPayment: boolean = false;
    dropdowns: any = {};
    applicationId: any;
    applicationType: any;
    isWaived: boolean = false;
    isReinstate: boolean = false;
    amount: any;

    constructor(
        public dialog: MatDialog,
        private tgRenewalDeclarationService: TgRenewalDeclarationService,
        private tgRenewalFormService: TgRenewalFormService,
        private _formBuilder: FormBuilder,
        private commonService: CommonService,
        private router: Router,
        private paymentService: PaymentService
    ) { }

    ngOnInit() {
        this.todayDate = moment();
        this.amount = 72;

        this.secondFormGroup = this._formBuilder.group({
            convictChecked: ['', Validators.required],
            offenceDate: [''],
            offenceType: [''],
            enforcementOutcome: [''],
            hasConsentMobileNo: [''],
            hasConsentEmailAddress: [''],
            licenceCheck: ['', Validators.requiredTrue],
            infoCheck: ['', Validators.requiredTrue],
            personalCheck: ['', Validators.requiredTrue]
        });

        this.tgRenewalDeclarationService.getDeclaration().subscribe(data => {
            this.secondFormGroup.patchValue(data);
        });

        this.commonService.populateFormDropdowns().subscribe(data => {
            this.dropdowns = data;
        });

        this.tgRenewalFormService.getLicenceRenewal().subscribe(data => {
            this.applicationId = data.applicationId; // not appId. this is actually TgLicenceRenewalId
            this.applicationType = data.applicationType;
            this.isWaived = data.isWaived;
            this.isReinstate = data.isReinstate;
            if (data.paymentSuccess) {
                this.allowBypassPayment = true;
            }
        });
    }

    // convenience getter for easy access to form fields
    get f2() { return this.secondFormGroup.controls; }

    onConvictChecked() {

        if (this.secondFormGroup.value['offenceDate']) {
            this.secondFormGroup.controls['convictChecked'].setValue(true);
        }

        var fields = [];
        if (this.secondFormGroup.get('convictChecked').value) {
            fields['offenceDate'] = [Validators.required];
            fields['offenceType'] = [Validators.required];
            fields['enforcementOutcome'] = [Validators.required];
        } else {
            fields['offenceDate'] = null;
            fields['offenceType'] = null;
            fields['enforcementOutcome'] = null;
        }
        this.setValidators(fields);
    }

    setValidators(fields: any) {
        for (var item in fields) {
            this.secondFormGroup.get(item).setValidators(fields[item]);
            this.secondFormGroup.get(item).updateValueAndValidity();
        }
    }

    onSubmit() {
        if (this.isWaived) {
            this.saveAndInitPayment(null);
        } else {
            var paymentReqType = !this.isReinstate ? cnst.PaymentRequestTypes.PAYREQ_TG_RENEWAL : cnst.PaymentRequestTypes.PAYREQ_TG_REINSTATEMENT;
            // this dialog for user to select payment type
            let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.amount, paymentRequestType: paymentReqType } });
            dialog.afterClosed().subscribe(result => {
                if (result.decision) {
                    let paymentType = result.type;
                    this.saveAndInitPayment(paymentType);
                }
            });
        }
    }

    bypassPayment() {
        this.tgRenewalFormService.saveAfterPayment(this.applicationId).subscribe(data => {
            this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_RENEWAL + '/' + this.applicationId]);
        });
    }

    saveAndInitPayment(paymentType: any) {
        this.tgRenewalDeclarationService.save(this.secondFormGroup.getRawValue()).subscribe(data => {
            this.secondFormGroup.markAsPristine();
            let billRefNos = [];
            billRefNos.push(data.billRefNo);
            if (paymentType == cnst.PaymentTypes.PAYNOW) {
                this.generatePaynowQRCode(data.applicationId, billRefNos, paymentType);
            } else {
                this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNos, cnst.TgApplicationUrl.TG_APP_SUCCESS_RENEWAL + '/' + data.applicationId + '/' + billRefNos);
            }
        });
    }

    generatePaynowQRCode(id: any, billRefNo: any, paymentType: any) {
        var paymentReqType = !this.isReinstate ? cnst.PaymentRequestTypes.PAYREQ_TG_RENEWAL : cnst.PaymentRequestTypes.PAYREQ_TG_REINSTATEMENT;
        this.paymentService.createPayNowTxn(this.amount, billRefNo).subscribe(txn => {
            let payNowTxnId = txn;
            this.paymentService.generateQrCode(this.amount, txn).subscribe(qrCode => {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.amount, paymentRequestType: paymentReqType, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_RENEWAL + '/' + id + '/' + billRefNo, payNowTxnId);
                    }
                });
            });
        });
    }
}
