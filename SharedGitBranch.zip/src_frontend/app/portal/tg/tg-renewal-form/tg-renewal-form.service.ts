import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgRenewalFormService {

    constructor(private http: HttpClient) { }

    public getLicenceRenewal(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_RENEWAL + '/new');
    }

    public getCondition(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_RENEWAL + '/new/condition');
    }

    public getAssignmentList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/view/current', { params: searchDto });
    }

    public getMrcList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/current', { params: searchDto });
    }

    public getPdcList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/current', { params: searchDto });
    }

    public getAssessmentList(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_MLPT + '/view/reinstatement');
    }

    public update(newApp: any, docType: string, currentTgPhotoId: number): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(newApp)],
            { type: 'application/json' }
        ));
        if (!currentTgPhotoId) {
            currentTgPhotoId = 0;
        }

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_RENEWAL + '/update/' + docType + "/" + currentTgPhotoId, formData);
    }

    public save(): Observable<any> {
        return this.http.get(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_RENEWAL + '/save');
    }

    public saveAfterPayment(appId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_RENEWAL + "/save/" + appId);
    }

    public setCurrentTgPhoto(appId: number, currentTgPhotoId: number): Observable<any> {
        if (!currentTgPhotoId) {
            currentTgPhotoId = 0;
        }
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_RENEWAL + "/update/setCurrentTgPhoto/" + appId + "/" + currentTgPhotoId);
    }
}