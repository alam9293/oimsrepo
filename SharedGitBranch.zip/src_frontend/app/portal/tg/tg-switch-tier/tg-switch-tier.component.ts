import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import * as cnst from '../../../common/constants';
import { TgSwitchTierService } from './tg-switch-tier.service';
import { Router, ActivatedRoute } from '@angular/router';
import { PaymentService } from '../../payment/payment.service';
import { PaymentDialogComponent } from 'src/app/common/modules/payment-dialog/payment-dialog.component';

@Component({
    selector: 'app-tg-switch-tier',
    templateUrl: './tg-switch-tier.component.html',
    styleUrls: ['./tg-switch-tier.component.scss']
})
export class TgSwitchTierComponent implements OnInit {
    switchTierId: any;
    tierSwitchData: any;
    form: FormGroup;
    cnst = cnst;

    constructor(
        private dialog: MatDialog,
        private formBuilder: FormBuilder,
        private tgSwitchTierService: TgSwitchTierService,
        private route: ActivatedRoute,
        private router: Router,
        private paymentService: PaymentService) { }

    ngOnInit() {
        this.initiateForm()
        if (this.route.snapshot.paramMap.get('id') != null) {
            this.switchTierId = parseInt(this.route.snapshot.paramMap.get('id'), 10);
            this.loadPendingTierSwitchById();
        } else {
            this.loadPendingTierSwitch();
        }
    }

    initiateForm() {
        this.form = this.formBuilder.group({
            id: [],
            paymentFee: 0,
            pendingSwitch: [],
            paymentSuccess: []
        });
    }

    loadPendingTierSwitch() {
        this.tgSwitchTierService.getPendingTierSwitch().subscribe(data => {
            if (data) {
                this.tierSwitchData = data;
                this.switchTierId = data.id;
                this.form.patchValue(data);
            }
        });
    }

    loadPendingTierSwitchById() {
        this.tgSwitchTierService.getTierSwitchById(this.switchTierId).subscribe(data => {
            if (data) {
                this.tierSwitchData = data;
                this.form.patchValue(data);
            }
        });
    }

    save() {
        // this dialog for user to select payment type
        let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('paymentFee').value } });
        dialog.afterClosed().subscribe(result => {
            if (result.decision) {
                let paymentType = result.type;
                this.form.markAsPristine();
                if (this.tierSwitchData.appFeeBillRefNo == null) {
                    this.tgSwitchTierService.savePaymentRequest(this.form.getRawValue()).subscribe(result => {
                        let billRefNo = [];
                        billRefNo.push(result.billRefNo);
                        if (paymentType == cnst.PaymentTypes.PAYNOW) {
                            this.generatePaynowQRCode(result.id, billRefNo, paymentType);
                        } else {
                            this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_SWITCH_TIER + '/' + result.id + '/' + billRefNo);
                        }
                    });
                } else {
                    let billRefNo = [];
                    billRefNo.push(this.tierSwitchData.appFeeBillRefNo);
                    if (paymentType == cnst.PaymentTypes.PAYNOW) {
                        this.generatePaynowQRCode(this.switchTierId, billRefNo, paymentType);
                    } else {
                        this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_SWITCH_TIER + '/' + this.switchTierId + '/' + billRefNo);
                    }
                }
            }
        });
    }

    generatePaynowQRCode(id: any, billRefNo: any, paymentType: any) {
        this.paymentService.createPayNowTxn(this.form.get('paymentFee').value, billRefNo).subscribe(txn => {
            let payNowTxnId = txn;
            this.paymentService.generateQrCode(this.form.get('paymentFee').value, txn).subscribe(qrCode => {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('paymentFee').value, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_SWITCH_TIER + '/' + id + '/' + billRefNo, payNowTxnId);
                    }
                });
            });
        });
    }

    submit() {
        this.tgSwitchTierService.saveAfterPayment(this.switchTierId).subscribe(data => {
            this.form.markAsPristine();
            this.router.navigate([cnst.TgApplicationUrl.TG_APP_SWITCH_TIER + '/' + this.switchTierId]);
        });
    }
}

