import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { TgTrainingCalendarService } from '../tg-training-calendar.service';
import { CommonService } from '../../../../common/services';
import { DateUtil } from '../../../../common/helper';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
    selector: 'app-tg-training-calendar-tp-list',
    templateUrl: './tg-training-calendar-tp-list.component.html',
    styleUrls: ['./tg-training-calendar-tp-list.component.scss']
})
export class TgTrainingCalendarTpListComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    listOfTpDataSource = [];
    listOfCoursedisplayedColumns: string[] = ['no', 'name'];
    filter: any = {};
    cnst = cnst;
    totalPages: number = 0;
    currentPage: number = 0;

    constructor(
        private tgTrainingCalendarService: TgTrainingCalendarService,
        private commonService: CommonService,
    ) { }

    ngOnInit() {
        this.loadTps();
    }

    loadTps() {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filter
        };

        this.tgTrainingCalendarService.getListOfTps(mergedDto).subscribe(data => {
            this.listOfTpDataSource = data.records;
            this.paginator.length = data.total;
            this.currentPage = this.paginator.pageIndex + 1;
            this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        });

    }

    clearFilter() {
        this.filter = {};
    }

    nextPage() {
        if (this.currentPage < this.totalPages) {
            this.paginator.pageIndex += 1;
            this.loadTps();
        }
    }

    previousPage(selection: String) {
        if (this.currentPage > 1) {
            this.paginator.pageIndex -= 1;
            this.loadTps();
        }
    }

    pageSizeChange(selection: String) {
        this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        if (this.currentPage > this.totalPages) {
            this.paginator.pageIndex = this.totalPages - 1;
        }
        this.loadTps();
    }
}
