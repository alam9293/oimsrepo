import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { TgTrainingCalendarService } from '../tg-training-calendar.service';
import { CommonService } from '../../../../common/services';
import { DateUtil } from '../../../../common/helper';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
    selector: 'app-tg-training-calendar-view',
    templateUrl: './tg-training-calendar-view.component.html',
    styleUrls: ['./tg-training-calendar-view.component.scss']
})
export class TgTrainingCalendarViewComponent implements OnInit {
    subsidiesColumns = ['subsidy', 'fee'];
    course: any;
    cnst = cnst;
    isLoading: boolean = true;

    constructor(
        private tgTrainingCalendarService: TgTrainingCalendarService,
        private commonService: CommonService,
        private route: ActivatedRoute,
    ) { }

    ngOnInit() {
        let courseCode = this.route.snapshot.paramMap.get('code');
        this.tgTrainingCalendarService.getCourseDetails(courseCode).subscribe(data => {
            this.course = data;
            this.isLoading = false;
        });
    }

}