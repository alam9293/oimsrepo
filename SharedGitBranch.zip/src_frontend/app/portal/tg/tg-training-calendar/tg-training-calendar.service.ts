import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgTrainingCalendarService {

    constructor(private http: HttpClient) { }

    public getListOfCourseDetails(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/calendar', { params: searchDto });
    }

    public getCourseDetails(courseCode: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/calendar/' + courseCode);
    }

    public getListOfTps(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/calendar/tp/', { params: searchDto });
    }

    public getTpDetails(tpId: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/calendar/tp/' + tpId);
    }
}