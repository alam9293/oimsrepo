import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TgUpdateParticularsService } from '../tg-update-particulars/tg-update-particulars.service';
import { CommonService, MyInfoService } from '../../../common/services';
import { FormUtil, FileUtil, ValidateEmail } from '../../../common/helper';
import { TgFormHelperUtil } from '../tg-helper/tg-form-helper';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import * as cnst from '../../../common/constants';
import { PaymentDialogComponent } from 'src/app/common/modules/payment-dialog/payment-dialog.component';
import { PaymentService } from '../../payment/payment.service';

@Component({
    selector: 'app-tg-update-particulars',
    templateUrl: './tg-update-particulars.component.html',
    styleUrls: ['./tg-update-particulars.component.scss']
})
export class TgUpdateParticularsComponent implements OnInit {
    dropdowns: any = {};
    eduLevelExcluded: string[] = [];
    residentialStatusExcluded = [];
    residentialStatusExcludedAddMyInfoResult = [];
    form: FormGroup;
    submitLabel: String = cnst.previewBtnTxt;
    amtLabel: String = "";
    cnst = cnst;
    maxDate = moment().subtract(21, 'years');
    todayDate = moment();

    initialNric: String;
    initialName: String;
    initialResidentialStatus: String;
    initialEmployerName: String;
    initialWorkpassType: String;
    initialWorkpassExpiry: String;
    initialNationality: String;

    hasCharge: boolean = false;
    displayEditProfile: boolean = false;   //hide edit page by default
    displayMyInfoBtn: boolean = false;   //hide my info button by default
    displaySearchBtn: boolean = true;   //display search button by default
    toggleClearMyInfo: boolean = true; //display clear myinfo but will be toggle by toggleMyInfo during init
    displayEmploymentInfo: boolean = false;   //hide employment info by default
    displayWorkpassUpload: boolean = false;   //hide workpass holder section by default
    myInfoBtnText: String = "Clear MyInfo";
    myInfoNonEditableFields: string[] = [];

    selectedFile: File;
    selectedFiles: any = [];
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    unionMap = new Map<string, string>();


    constructor(
        public dialog: MatDialog,
        public formUtil: FormUtil,
        private fileUtil: FileUtil,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private myInfoService: MyInfoService,
        private tgUpdateParticularsService: TgUpdateParticularsService,
        private router: Router,
        private route: ActivatedRoute,
        private paymentService: PaymentService,
        private tgFormHelper: TgFormHelperUtil
    ) { }

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.initForm();
        this.commonService.populateFormDropdowns().subscribe(data => {
            this.dropdowns = data;
            this.eduLevelExcluded = this.tgFormHelper.removeEduLevels(this.dropdowns.education);
            this.residentialStatusExcluded = this.tgFormHelper.removeResidentialStatus(this.dropdowns.residential);
            this.retrieveFromDB();
        });
    }

    initForm() {
        this.form = this.formBuilder.group({
            salutation: ['', Validators.required],
            name: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            aliasName: [],
            nric: ['', Validators.required],
            dob: ['', Validators.required],
            birthCountry: ['', Validators.required],
            sex: ['', Validators.required],
            race: ['', Validators.required],
            maritalStatus: ['', Validators.required],
            mobileNo: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(8), Validators.pattern("^[0-9]*$")]],
            emailAddress: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
            highestEduLevel: ['', Validators.required],
            nationality: ['', Validators.required],
            paymentFee: [''],
            residentialStatus: ['', Validators.required],
            regPostal: ['', [Validators.minLength(6), Validators.pattern("^[0-9]*$"), Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL)]],
            regBlock: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            regStreet: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)]],
            regBuilding: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
            regFloor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            regUnit: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.UNIT), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            regForeignLine1: [''],
            regForeignLine2: [''],
            regForeignLine3: [''],
            regType: this.formBuilder.group({
                key: [cnst.AddressTypes.ADDR_LOCAL],
                label: ['']
            }),
            isAddrSame: [''],
            optPostal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            optBlock: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            optStreet: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)],
            optBuilding: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
            optFloor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            optUnit: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.UNIT), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            optForeignLine1: [''],
            optForeignLine2: [''],
            optForeignLine3: [''],
            optType: this.formBuilder.group({
                key: [cnst.AddressTypes.ADDR_LOCAL],
                label: ['']
            }),
            isWorkPassHolder: [false],
            employerName: [''],
            occupation: [''],
            occupationOther: [''],
            workPassType: [''],
            workpassExpiryDate: [''],
            convictChecked: ['', Validators.required],
            // offenceDeclaredDate: [],
            offenceDate: [],
            offenceType: [],
            enforcementOutcome: [],
            hasConsentMobileNo: [],
            hasConsentEmailAddress: [],
            licenceCheck: ['', Validators.requiredTrue],
            infoCheck: ['', Validators.requiredTrue],
            personalCheck: ['', Validators.requiredTrue],
            status: [null],
            statusRemark: [],
            id: [],
            applicationNo: [],
            totalDoc: [null],
            otherSupportDocs: [],
            isMyInfoPopulated: [false],
            paymentSuccess: [],
            isDraft: [],
            allowToEdit: [],
            isWaived: [],
        }, { validator: [this.nationalityAndResidentialStatusValidator(), this.regAddrRequiredValidator(), this.optAddrRequiredValidator()] });

    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    retrieveFromDB() {
        //to clear form before patching
        this.initForm();
        if (this.route.snapshot.paramMap.has('id')) {
            this.tgUpdateParticularsService.getTgPersonUpdate(this.route.snapshot.paramMap.get('id')).subscribe(data => {
                {
                    this.patchData(data);
                    //store initial value for comparison later
                    this.updateInitialValue(data.nric, data.name, data.employerName, data.residentialStatus, data.workPassType, data.workpassExpiryDate, data.nationality);
                    this.disableEditForm(data);
                }
            }, error => {
                this.router.navigate([cnst.TgApplicationUrl.TG_DASHBOARD]);
            });
        } else {
            this.tgUpdateParticularsService.getParticularInfo().subscribe(data => {
                {
                    this.patchData(data);
                    //store initial value for comparison later
                    this.updateInitialValue(data.nric, data.name, data.employerName, data.residentialStatus, data.workPassType, data.workpassExpiryDate, data.nationality);
                    this.disableEditForm(data);
                }
            });
        }
    }

    nationalityAndResidentialStatusValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.form != null) {
                return (this.form.get('nationality').value == 'NAT_SG' && this.form.get('residentialStatus').value != 'RESD_C' && !this.form.value.isMyInfoPopulated ? { nationalityAndResidentialStatusError: true } : null);

            } else {
                return null;
            }
        }
    }

    patchData(data: any) {
        this.form.markAsPristine();
        if (data.name) {
            data.name = this.camelCase(data.name);
        }
        if (data.aliasName) {
            data.aliasName = this.camelCase(data.aliasName);
        }
        this.form.patchValue(data);

        if (data.isWorkPassHolder) {
            this.displayEmploymentInfo = true;
        }
        if (data.otherSupportDocs) {
            this.displayWorkpassUpload = true;
            this.selectedFiles = data.otherSupportDocs;
            this.form.get('totalDoc').setValue(this.selectedFiles.length);
        }


        if (data.hasConsentMobileNo == true || data.hasConsentEmailAddress == true) {
            this.form.controls['personalCheck'].setValue(true);
        }
        else {
            this.form.controls['personalCheck'].setValue(false);
        }

        //set checkbox convictChecked to true if offenceDeclaredDate and etc are not null
        if ((data.offenceDeclaredDate != undefined && data.offenceDeclaredDate != "") || (data.offenceDate != undefined && data.offenceDate != "") || (data.offenceType != undefined && data.offenceType != "") || (data.enforcementOutcome != undefined && data.enforcementOutcome != "")) {
            this.form.controls['convictChecked'].setValue(true);
        } else {
            this.form.controls['convictChecked'].setValue(false);
        }

        this.onMailingAddressChange();
        this.checkIsWorkPassHolder();
        this.onConvictChecked();
        this.onOccupationChange();

        // verify if user is singpass logged in
        if (sessionStorage.loginTypeCode == "SP") {
            this.displayMyInfoBtn = true;
            //check if data is populated from my info
            if (this.form.get('isMyInfoPopulated').value) {
                //hide search button for registered address
                this.displaySearchBtn = false;
            }
            //allow singpass user to manual input
            else {
                this.toggleClearMyInfo = false;
                this.myInfoBtnText = "Retrieve MyInfo";
            }
        }
        if (data.regPostal == data.optPostal && data.regFloor == data.optFloor && data.regUnit == data.optUnit) {
            this.form.get('isAddrSame').setValue(true);
        }
        else {
            this.form.get('isAddrSame').setValue(false);
        }
    }

    camelCase(value: String) {
        var modifiedValue = [];
        modifiedValue = value.toLowerCase().split(' ');
        for (var i = 0; i < modifiedValue.length; i++) {
            modifiedValue[i] = modifiedValue[i].charAt(0).toUpperCase() + modifiedValue[i].slice(1);
        }
        return modifiedValue.join(' ');
    }

    toggleMyInfo() {
        this.toggleClearMyInfo = !this.toggleClearMyInfo;
        if (this.toggleClearMyInfo) {
            this.myInfoBtnText = "Clear MyInfo";
            this.retrieveMyInfo();
        }
        else {
            this.myInfoBtnText = "Retrieve MyInfo";
            this.clearMyInfo();
        }
    }

    retrieveMyInfo() {
        // hide the search registered postal code button
        this.displaySearchBtn = false;
        this.form.get('isMyInfoPopulated').setValue(true);

        this.myInfoService.getMyInfoPersonBasic().subscribe(data => {
            //store the list of fields that will not be editable
            this.myInfoNonEditableFields = data.nonEditableFields;
            this.form.get('name').setValue(this.camelCase(data.name));
            this.form.get('aliasName').setValue(this.camelCase(data.aliasName));
            this.form.get('nric').setValue(data.uinfin);
            this.form.get('dob').setValue(data.dob);
            this.form.get('birthCountry').setValue(data.birthCountry);
            this.form.get('sex').setValue(data.sex);
            this.form.get('race').setValue(data.race);
            this.form.get('maritalStatus').setValue(data.maritalStatus);
            this.form.get('mobileNo').setValue(data.mobileNo);
            this.form.get('emailAddress').setValue(data.email);
            this.form.get('nationality').setValue(data.nationality);
            this.form.get('residentialStatus').setValue(data.residentialStatus);
            // special handling for "Residential Status" drop down options
            this.residentialStatusExcludedAddMyInfoResult = JSON.parse(JSON.stringify(this.residentialStatusExcluded));
            if (data.residentialStatus == 'RESD_N' || data.residentialStatus == 'RESD_U' || data.residentialStatus == 'RESD_A') {
                this.residentialStatusExcludedAddMyInfoResult.push({ key: data.residentialStatus, label: this.formUtil.getLabelFromKey(this.dropdowns.residential, data.residentialStatus) });
            }

            if (this.formUtil.isMyinfoNonEditable(cnst.MyInfoFields.REG_ADD_POSTAL, this.myInfoNonEditableFields)) {
                this.form.get('regType').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
            }
            this.form.get('regPostal').setValue(data.regAddPostal);
            this.form.get('regBlock').setValue(data.regAddBlock);
            this.form.get('regBuilding').setValue(data.regAddBuilding);
            this.form.get('regStreet').setValue(data.regAddStreet);
            this.form.get('regFloor').setValue(data.regAddFloor);
            this.form.get('regUnit').setValue(data.regAddUnit);

            if (this.form.get('isWorkPassHolder').value) {
                // show exmployment info and allow upload supporting doc section if user is work pass holder
                this.displayWorkpassUpload = true;
                this.form.get('employerName').setValue(data.employment);
                this.form.get('occupation').setValue(data.occupation);
                this.form.get('workpassExpiryDate').setValue(data.workpassExpiryDate);
            }
            else {
                // hide exmployment info and allow upload supporting doc section if user is work pass holder
                this.displayWorkpassUpload = false;
                //set uploaded documents to be empty and remove validation
                var fields = [];
                fields['totalDoc'] = null;
                this.setValidators(fields);
                this.selectedFiles = [];
            }
            this.checkSupportDoc();
            this.chargeDisplay();
        }, error => {
            this.toggleMyInfo();
            this.displaySearchBtn = true;
            this.form.get('isMyInfoPopulated').setValue(false);
        });
    }

    clearMyInfo() {
        // show the search registered postal code button
        this.displaySearchBtn = true;
        this.myInfoNonEditableFields = [];
        this.form.get('isMyInfoPopulated').setValue(false);

        //remove information retrieved from myinfo
        this.form.get('name').setValue('');
        this.form.get('dob').setValue('');
        this.form.get('birthCountry').setValue('');
        this.form.get('sex').setValue('');
        this.form.get('race').setValue('');
        this.form.get('maritalStatus').setValue('');
        this.form.get('mobileNo').setValue('');
        this.form.get('emailAddress').setValue('');
        this.form.get('nationality').setValue('');
        this.form.get('residentialStatus').setValue('');
        this.form.get('regPostal').setValue('');
        this.form.get('regBlock').setValue('');
        this.form.get('regBuilding').setValue('');
        this.form.get('regStreet').setValue('');
        this.form.get('regFloor').setValue('');
        this.form.get('regUnit').setValue('');
        this.residentialStatusExcludedAddMyInfoResult = [];
    }

    onPostalCodeChange(isReg: boolean) {
        if (isReg) {
            var regPostal = this.form.get('regPostal').value.toString();
            if (regPostal.length == 6 && !isNaN(parseInt(regPostal, 10))) {
                this.commonService.getPostalCodeAddress(parseInt(regPostal, 10)).subscribe(data => {
                    if (data) {
                        var addrResults = data['results'];
                        if (addrResults.length > 0) {
                            this.form.patchValue({
                                regBlock: addrResults[0]['BLK_NO'].trim(),
                                regStreet: addrResults[0]['ROAD_NAME'].trim(),
                                regBuilding: addrResults[0]['BUILDING'].trim()
                            });
                        } else {
                            this.form.get('regPostal').setErrors({ 'invalid': true });
                        }
                    }
                });
            }
        } else {
            var optPostal = this.form.get('optPostal').value.toString();
            if (optPostal.length == 6 && !isNaN(parseInt(optPostal, 10))) {
                this.commonService.getPostalCodeAddress(parseInt(optPostal, 10)).subscribe(data => {
                    if (data) {
                        var addrResults = data['results'];
                        if (addrResults.length > 0) {
                            this.form.patchValue({
                                optBlock: addrResults[0]['BLK_NO'].trim(),
                                optStreet: addrResults[0]['ROAD_NAME'].trim(),
                                optBuilding: addrResults[0]['BUILDING'].trim()
                            });

                        } else {
                            this.form.get('optPostal').setErrors({ 'invalid': true });
                        }
                    }
                });
            }
        }
    }

    onWorkPassDocChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                this.selectedFiles.push(data);
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            });
        }
    }

    removeWorkPassDoc(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.form.get('totalDoc').setValue(this.selectedFiles.length);
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push(doc.publicFileId);
        }
    }

    downloadWorkPassDoc(doc) {
        var fileId, fileName;
        if (doc.publicFileId == null) {
            fileId = doc.id;
            fileName = doc.originalName;
        } else {
            fileId = doc.publicFileId;
            fileName = doc.processedName;
        }

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    onMailingAddressChange() {
        var fields = [];
        if (this.form.get('isAddrSame').value) {
            fields['optPostal'] = null;
            fields['optBlock'] = null;
            fields['optStreet'] = null;
        } else {
            fields['optPostal'] = [Validators.minLength(6), Validators.pattern("^[0-9]*$"), Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL)];
            fields['optBlock'] = [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')];
            fields['optStreet'] = [Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)];
        }
        this.setValidators(fields);
    }

    checkIsWorkPassHolder() {
        var fields = [];
        if (this.form.get('isWorkPassHolder').value) {
            fields['employerName'] = [Validators.required];
            fields['occupation'] = [Validators.required];
            fields['workPassType'] = [Validators.required];
            fields['workpassExpiryDate'] = [Validators.required];
        } else {
            fields['employerName'] = null;
            fields['occupation'] = null;
            fields['workPassType'] = null;
            fields['workpassExpiryDate'] = null;
        }
        this.setValidators(fields);
    }

    onConvictChecked() {
        var fields = [];
        if (this.form.get('convictChecked').value) {
            //default offenceDeclaredDate to today. no need user to input
            // this.form.get('offenceDeclaredDate').setValue(moment(this.todayDate).format(cnst.dateFormat));
            fields['offenceDate'] = [Validators.required];
            fields['offenceType'] = [Validators.required];
            fields['enforcementOutcome'] = [Validators.required];
        } else {
            // this.form.get('offenceDeclaredDate').setValue('');
            fields['offenceDate'] = null;
            fields['offenceType'] = null;
            fields['enforcementOutcome'] = null;
        }
        this.setValidators(fields);
    }

    onOccupationChange() {
        var fields = [];
        if (this.form.get('isWorkPassHolder').value && this.form.get('occupation').value == cnst.TgCommonTypes.TG_OCCUPATION) {
            fields['occupationOther'] = [Validators.required];
        } else {
            fields['occupationOther'] = null;
        }
        this.setValidators(fields);
    }

    setValidators(fields: any) {
        for (var item in fields) {
            this.form.get(item).setValidators(fields[item]);
            this.form.get(item).updateValueAndValidity();
        }
    }

    checkSupportDoc() {
        this.displayWorkpassUpload = false;
        var fields = [];
        fields['totalDoc'] = null;
        if (this.initialWorkpassType != this.form.get('workPassType').value) {
            this.displayWorkpassUpload = true;
            fields['totalDoc'] = [Validators.required, Validators.min(1)];
        }
        // if user has clicked on retrieve from myinfo
        // or user is not singpass log in
        if (!this.toggleClearMyInfo) {
            if (this.initialNric != this.form.get('nric').value || this.initialName != this.form.get('name').value || this.initialEmployerName != this.form.get('employerName').value || this.initialWorkpassExpiry != this.form.get('workpassExpiryDate').value || this.initialNationality != this.form.get('nationality').value) {
                this.displayWorkpassUpload = true;
                fields['totalDoc'] = [Validators.required, Validators.min(1)];
            }
        }
        this.setValidators(fields);
    }

    personalCheckChange() {
        if (this.form.get('personalCheck').value) {
            this.form.controls['hasConsentMobileNo'].setValue(true);
            this.form.controls['hasConsentEmailAddress'].setValue(true);
        } else {
            this.form.controls['hasConsentMobileNo'].setValue(false);
            this.form.controls['hasConsentEmailAddress'].setValue(false);
        }
    }

    chargeDisplay() {
        //charges only apply to change in name, company name and residential status
        this.hasCharge = false;
        var latestName = this.form.get('name').value,
            latestEmployerName = this.form.get('employerName').value,
            latestResidentialStatus = this.form.get('residentialStatus').value;

        if (!(this.form.get('status').value != null && this.form.get('status').value.key == cnst.ApplicationStatuses.TG_APP_RFA)) {
            if (latestName !== this.initialName) {
                this.hasCharge = true;
            } else {
                if (this.form.get('isWorkPassHolder').value) {
                    if (
                        latestEmployerName !== this.initialEmployerName ||
                        (this.initialResidentialStatus !== "RESD_C" && this.initialResidentialStatus !== "RESD_PR" && latestResidentialStatus === "RESD_PR")
                    ) {
                        this.hasCharge = true;
                    }
                }
            }

            if (this.hasCharge) {
                this.amtLabel = this.form.get('paymentFee').value;
                this.submitLabel = cnst.TgCommonMessage.CONFIRM_PAYMENT;
            } else {
                this.submitLabel = cnst.previewBtnTxt;
            }
        }

    }

    updateInitialValue(nric: String, name: String, employerName: String, residentialStatus: String, workPassType: String, workpassExpiry: String, nationality: String) {
        this.initialNric = nric;
        this.initialName = name;
        this.initialEmployerName = employerName == undefined ? "" : employerName;
        this.initialResidentialStatus = residentialStatus;
        this.initialWorkpassType = workPassType == undefined ? "" : workPassType;
        if (workpassExpiry == undefined) {
            workpassExpiry = "";
        }
        this.initialWorkpassExpiry = workpassExpiry;
        this.initialNationality = nationality;
    }

    resetBoolean() {
        this.hasCharge = false;
        this.displayEditProfile = false;   //hide edit page by default
        this.displayMyInfoBtn = false;   //hide my info button by default
        this.displaySearchBtn = true;   //display search button by default
        this.toggleClearMyInfo = true;       //display clear myinfo but will be toggle by toggleMyInfo during init
        this.displayEmploymentInfo = false;   //hide employment info by default
        this.displayWorkpassUpload = false;   //hide workpass holder section by default
        this.myInfoBtnText = "Clear MyInfo";
        this.myInfoNonEditableFields = [];
    }

    submitForm() {
        this.form.patchValue({
            otherSupportDocs: this.selectedFiles
        });

        if (this.form.get('isDraft').value != null && this.form.get('isDraft').value == true && this.form.get('paymentSuccess').value == true) {
            this.tgUpdateParticularsService.saveAfterPayment(this.form.get('id').value).subscribe(data => {
                this.form.markAsPristine();
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_PARTICULARS + '/' + data.id]);
            });
        } else if (this.form.get('status').value != null && (this.form.get('status').value.key == cnst.ApplicationStatuses.TG_APP_RFA || this.form.get('paymentSuccess').value == true)) {
            this.tgUpdateParticularsService.updateForm(this.form.getRawValue(), this.adminDeletedFiles).subscribe(data => {
                this.form.markAsPristine();
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_PARTICULARS + '/' + data.id]);
            });
        } else {
            console.log("this.hasCharge = " + this.hasCharge);
            if (this.hasCharge) {
                if (this.form.get('isWaived').value && this.form.get('isWaived').value == true) {
                    this.saveAndInitPayment(null);
                } else {
                    // this dialog for user to select payment type
                    let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('paymentFee').value, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE } });
                    dialog.afterClosed().subscribe(result => {
                        if (result.decision) {
                            let paymentType = result.type;
                            this.saveAndInitPayment(paymentType);
                        }
                    });
                }

            } else {
                this.tgUpdateParticularsService.submitForm(this.form.getRawValue(), this.adminDeletedFiles).subscribe(data => {
                    this.form.markAsPristine();
                    this.router.navigate([cnst.TgApplicationUrl.TG_THANK_YOU], {
                        queryParams: {
                            'title': 'Update Particulars'
                        }
                    });
                });
            }
        }
    }

    goBack() {
        window.history.back();
    }

    editProfile() {

        if (this.route.snapshot.paramMap.has('id')) {
            this.tgUpdateParticularsService.getTgPersonUpdate(this.route.snapshot.paramMap.get('id')).subscribe(data => {
                {
                    this.patchData(data);
                    this.displayEditProfile = true;
                    this.disableEditForm(data);
                    this.chargeDisplay();
                    this.checkSupportDoc();
                }
            }, error => {
                this.router.navigate([cnst.TgApplicationUrl.TG_DASHBOARD]);
            });
        } else {
            this.tgUpdateParticularsService.editParticularInfo().subscribe(data => {
                this.patchData(data);
                this.displayEditProfile = true;
                this.disableEditForm(data);
                this.chargeDisplay();
                this.checkSupportDoc();
            });
        }

    }

    disableEditForm(data) {
        //disable form if payment is made but havent submit the form
        if (this.isPaymentMade() && this.form.get('isDraft').value == true) {
            this.form.disable();
            this.form.get('licenceCheck').setValue(true);
            this.form.get('infoCheck').setValue(true);
        }
        //disable form if payment is made but fail
        if (data.paymentSuccess != null && data.paymentSuccess == false) {
            this.hasCharge = true;
            this.amtLabel = this.form.get('paymentFee').value;
            this.submitLabel = cnst.TgCommonMessage.CONFIRM_PAYMENT;
        }
        //disable form if application status is not RFA
        if (data.status != null && data.status.key != cnst.ApplicationStatuses.TG_APP_RFA) {
            this.form.disable();
        }
    }

    isPaymentMade() {
        if (this.form.get('status').value == null && this.form.get('paymentSuccess').value != null && this.form.get('paymentSuccess').value == true) {
            return true;
        }

        return false;
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    isAllowToEdit() {
        return this.form.get('allowToEdit').value;
    }

    regAddrRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.form) {
                let obj = {};
                if (this.form.get('regType').get('key').value == cnst.AddressTypes.ADDR_LOCAL) {

                    if (!this.form.get('regPostal').value) {
                        obj = { ...obj, regAddrPostalRequired: true };
                    }
                    if (!this.form.get('regBlock').value) {
                        obj = { ...obj, regAddrBlockRequired: true };
                    }
                    if (!this.form.get('regStreet').value) {
                        obj = { ...obj, regAddrStreetRequired: true };
                    }
                } else if (this.form.get('regType').get('key').value == cnst.AddressTypes.ADDR_FOREIGN) {

                    if (!this.form.get('regForeignLine1').value) {
                        obj = { ...obj, regAddrForeignLine1Required: true };
                    }
                    if (!this.form.get('regForeignLine2').value) {
                        obj = { ...obj, regAddrForeignLine2Required: true };
                    }
                    if (!this.form.get('regForeignLine3').value) {
                        obj = { ...obj, regAddrForeignLine3Required: true };
                    }
                }
                return obj;
            } else {
                return null;
            }

        }
    }

    optAddrRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.form && this.form.get('isAddrSame').value == false) {
                let obj = {};
                if (this.form.get('optType').get('key').value == cnst.AddressTypes.ADDR_LOCAL) {

                    if (!this.form.get('optPostal').value) {
                        obj = { ...obj, optAddrPostalRequired: true };
                    }
                    if (!this.form.get('optBlock').value) {
                        obj = { ...obj, optAddrBlockRequired: true };
                    }
                    if (!this.form.get('optStreet').value) {
                        obj = { ...obj, optAddrStreetRequired: true };
                    }
                } else if (this.form.get('optType').get('key').value == cnst.AddressTypes.ADDR_FOREIGN) {

                    if (!this.form.get('optForeignLine1').value) {
                        obj = { ...obj, optAddrForeignLine1Required: true };
                    }
                    if (!this.form.get('optForeignLine2').value) {
                        obj = { ...obj, optAddrForeignLine2Required: true };
                    }
                    if (!this.form.get('optForeignLine3').value) {
                        obj = { ...obj, optAddrForeignLine3Required: true };
                    }
                }
                return obj;
            } else {
                return null;
            }

        }
    }

    saveAndInitPayment(paymentType: any) {
        this.form.get('isDraft').setValue(true);
        this.tgUpdateParticularsService.submitForm(this.form.getRawValue(), this.adminDeletedFiles).subscribe(data => {
            let application = data;
            this.form.markAsPristine();
            if (application.billRefNo == null) {
                this.tgUpdateParticularsService.savePaymentRequest(this.form.getRawValue()).subscribe(result => {
                    let billRefNo = [];
                    billRefNo.push(result.billRefNo);
                    if (paymentType == cnst.PaymentTypes.PAYNOW) {
                        this.generatePaynowQRCode(result.id, billRefNo, paymentType);
                    } else {
                        this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_PARTICULARS + '/' + result.id + '/' + billRefNo);
                    }
                });
            } else {
                let billRefNo = [];
                billRefNo.push(application.billRefNo);
                if (paymentType == cnst.PaymentTypes.PAYNOW) {
                    this.generatePaynowQRCode(application.id, billRefNo, paymentType);
                } else {
                    this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_PARTICULARS + '/' + application.id + '/' + billRefNo);
                }
            }

        });
    }

    generatePaynowQRCode(id: any, billRefNo: any, paymentType: any) {
        this.paymentService.createPayNowTxn(this.form.get('paymentFee').value, billRefNo).subscribe(txn => {
            let payNowTxnId = txn;
            this.paymentService.generateQrCode(this.form.get('paymentFee').value, txn).subscribe(qrCode => {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('paymentFee').value, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_PARTICULARS + '/' + id + '/' + billRefNo, payNowTxnId);
                    }
                });
            });
        });
    }
}


