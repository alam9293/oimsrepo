import { Component, OnInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as cnst from '../../../common/constants';
import { TpCourseRenewalService } from './tp-course-renewal.service';
import { FileUtil } from 'src/app/common/helper';
import { TaFormHelperUtil } from '../../ta/ta-helper';
import { Observable } from 'rxjs';

@Component({
    selector: 'app-tp-course-renewal',
    templateUrl: './tp-course-renewal.component.html',
    styleUrls: ['./tp-course-renewal.component.scss']
})
export class TpCourseRenewalComponent implements OnInit {

    form: FormGroup;
    cnst = cnst;
    ratingColumns = ['criteria', 'rating'];
    preview: boolean = false;
    application: any = {};

    constructor(
        private tpCourseRenewalService: TpCourseRenewalService,
        private route: ActivatedRoute,
        private formBuilder: FormBuilder,
        private router: Router,
        public fileUtil: FileUtil,
        public taFormHelperUtil: TaFormHelperUtil
    ) { }

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.buildForm();
        let courseCode = this.route.snapshot.paramMap.get('code');
        if (courseCode) {
            this.loadCourse(courseCode);
        } else {
            let appId = this.route.snapshot.paramMap.get('appId');
            this.loadApplication(appId);
        }
    }

    goBack() {
        if (!this.preview) {
            window.history.back();
        } else {
            this.preview = false;
            this.form.enable();
        }
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    loadCourse(courseCode) {
        this.tpCourseRenewalService.getCourse(courseCode).subscribe(data => {
            this.buildForm(data);
        });
    }

    loadApplication(appId) {
        this.tpCourseRenewalService.getCourseRenewalApplication(appId).subscribe(data => {
            this.buildForm(data);
            this.application = data;
            this.preview = true;
            this.form.disable();
        });
    }

    buildForm(data?) {
        let tgCourseFormGroup = this.formBuilder.group({
            code: [''],
            name: [''],
            approvedStartDate: [''],
            approvedEndDate: [''],
            languageCode: [''],
            languageLabel: [''],
            typeCode: [''],
            typeLabel: [''],
            noOfHours: [''],
            categoryCode: [''],
            categoryLabel: [''],
            ssgCourseCode: ['', [Validators.maxLength(255)]],
            objective: [''],
            outline: [''],
            classroomHrs: [''],
            outOfClassroomHrs: [''],
            courseFee: [''],
            courseFeeNote: [''],
        });

        this.form = this.formBuilder.group({
            id: [''],
            tgCourse: tgCourseFormGroup,
            evaluations: this.formBuilder.array([]),
            remarks: ['', [Validators.maxLength(255)]],
            docs: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.minLengthArray(1)])),
        });

        if (data) {
            this.form.patchValue(data);
            // populate evaluations rows
            if (data.evaluations) {
                data.evaluations.forEach(element => {
                    this.addEvaluationRow(element);
                });
            }
            // populate docs rows
            if (data.docs) {
                data.docs.forEach(element => {
                    this.addDoc(element);
                });
            }
        }
    }

    addEvaluationRow(evaluationValue?) {
        let evaluationRow = this.formBuilder.group({
            id: [''],
            tgCourseCriteriaId: [''],
            criteria: [''],
            rating: ['', Validators.required],
            weightage: [''],
            ratings: this.formBuilder.array([]),
        });
        if (evaluationValue) {
            evaluationRow.patchValue(evaluationValue);
            evaluationValue.ratings.forEach(element => {
                this.addEvaluationRatingRow(<FormArray>evaluationRow.get('ratings'), element);
            });
        }
        this.evaluations.push(evaluationRow);
    }

    addEvaluationRatingRow(evaluationRatings: FormArray, value?) {
        let ratingRow = this.formBuilder.group({
            key: [''],
            label: [''],
            data: [''],
        });
        if (value) {
            ratingRow.patchValue(value);
        }
        evaluationRatings.push(ratingRow);
    }

    addDoc(value?) {
        let docRow = this.buildFileFormGroup();
        if (value) {
            docRow.patchValue(value);
        }
        this.docs.push(docRow);
    }

    removeDoc(index) {
        this.docs.removeAt(index);
    }

    downloadFile(doc) {
        this.fileUtil.download(doc.id, doc.hash).subscribe(data => {
            this.fileUtil.export(data, doc.originalName);
        });
    }

    onFileChanged(event, type) {
        let selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(selectedFile)) {
            this.fileUtil.upload(type, selectedFile).subscribe(data => {
                this.addDoc(data);
            });
        }
        event.target.value = '';
    }

    previewApp() {
        if (this.form.valid) {
            this.preview = true;
            this.form.disable();
            this.scrollToTop();
        }
    }

    submitCourseRenewal() {
        this.form.enable();
        if (this.form.valid) {
            this.tpCourseRenewalService.submitCourseRenewal(this.form.value).subscribe(data => {
                this.form.markAsPristine();
                this.tpCourseRenewalService.createAlert(data).subscribe(data => {
                    this.router.navigate([cnst.TpApplicationUrl.TP_APP_SUCCESS_COURSE_RENEWAL + '/' + data]);
                })
            })
        }
    }

    buildFileFormGroup(): FormGroup {
        return this.formBuilder.group({
            id: [],
            publicFileId: [],
            originalName: [''],
            processedName: [],
            docType: [],
            extension: [],
            path: [],
            size: [],
            hash: [],
            documentInstructions: [],
            documentTypeLabel: [],
            description: [],
            readableFileSize: [],
            hasTemplate: [],
        });
    }

    get evaluations() {
        return this.form.get('evaluations') as FormArray;
    }

    get tgCourse() {
        return this.form.get('tgCourse') as FormGroup;
    }

    get docs() {
        return this.form.get('docs') as FormArray;
    }
}
