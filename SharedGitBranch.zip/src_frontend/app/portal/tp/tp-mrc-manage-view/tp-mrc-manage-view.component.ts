import { Component, OnInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, AbstractControl } from '@angular/forms';
import { TpMrcManageViewService } from './tp-mrc-manage-view.service';
import { TpMrcManageService } from '../../tp/tp-mrc-manage/tp-mrc-manage.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService, AuthenticationService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormUtil, FileUtil } from '../../../common/helper';
import { Observable } from 'rxjs';
import { User } from '../../../common/models';
import * as moment from 'moment';

@Component({
    selector: 'app-tp-mrc-manage-view',
    templateUrl: './tp-mrc-manage-view.component.html',
    styleUrls: ['./tp-mrc-manage-view.component.scss']
})
export class TpMrcManageViewComponent implements OnInit {
    currentUser: User;
    attendanceTypes: any;
    attendanceId: any;
    form: FormGroup;
    selectedFile: File;
    selectedFiles: any = [];
    publicDeletedFiles: any = [];
    fieldArray: any;
    attendeeRows: FormArray;
    displayPreviewMrc: boolean = true; //hide preview mrc section by default
    cnst = cnst;
    todayDate = moment();

    constructor(public formUtil: FormUtil,
        private fileUtil: FileUtil,
        private formBuilder: FormBuilder,
        private tpMrcManageViewService: TpMrcManageViewService,
        private tpMrcManageService: TpMrcManageService,
        private authenticationService: AuthenticationService,
        private commonService: CommonService,
        private router: Router,
        private route: ActivatedRoute
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.scrollToTop();
        this.currentUser = this.authenticationService.currentUserValue;
        if (this.currentUser.tpMrc) {
            this.form = this.formBuilder.group({
                attendanceId: [],
                courseDate: ['', Validators.required],
                supportingDocs: [],
                totalDoc: [null, [Validators.required, Validators.min(1)]],
                attendeeRows: this.formBuilder.array([]),
                removeAttendeeRows: [[]]
            });

            this.loadAttendanceType();
            this.loadDetails();
        } else {
            this.router.navigate(['/portal/dashboard-tp']);
        }
    }

    loadAttendanceType() {
        this.commonService.getCourseAttendanceTypes().subscribe(data => this.attendanceTypes = data);
    }

    loadDetails() {
        this.attendanceId = this.route.snapshot.paramMap.get('id');
        this.tpMrcManageViewService.getCourseAttendanceDetails(this.attendanceId).subscribe(data => {
            this.form.patchValue(data);

            if (data.supportingDocs) {
                this.selectedFiles = data.supportingDocs;
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            }

            this.form.patchValue({
                attendanceId: this.attendanceId
            });
            this.attendeeRows = data.attendeeRows;

            const control = <FormArray>this.form.controls['attendeeRows'];
            for (var i in this.attendeeRows) {
                var attendee = this.attendeeRows[i];
                control.push(this.formBuilder.group({
                    attendanceDetailId: attendee.attendanceDetailId,
                    licenceNo: [attendee.licenceNo, [Validators.required, Validators.pattern("^[0-9]*$")]],
                    name: [attendee.name, [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
                    score: [attendee.score, [Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]],
                    maxScore: [attendee.maxScore, [Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]],
                    attendance: [attendee.attendance, Validators.required]
                }));
            }
        });
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {

                this.selectedFiles.push(data);
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            });
        }
        event.target.value = '';
    }

    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.form.get('totalDoc').setValue(this.selectedFiles.length);
        this.publicDeletedFiles.push(doc.id);
    }

    downloadFile(doc) {
        var fileId = doc.id,
            fileName = doc.originalName;

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    checkIfAbsent(index: number) {
        var tgCourseAttendanceDetailsArray = this.form.controls['attendeeRows'] as FormArray;
        var tgCourseAttendanceDetailsFormGroup = tgCourseAttendanceDetailsArray.at(index) as FormGroup;
        var attendance = tgCourseAttendanceDetailsFormGroup.controls['attendance'].value;
        if (attendance == cnst.TgCommonTypes.ATTENDANCE_ABSENT) {
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValue('0');
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].disable();
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValidators(null);
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].updateValueAndValidity;

            tgCourseAttendanceDetailsFormGroup.controls['score'].setValue('0');
            tgCourseAttendanceDetailsFormGroup.controls['score'].disable();
            tgCourseAttendanceDetailsFormGroup.controls['score'].setValidators(null);
            tgCourseAttendanceDetailsFormGroup.controls['score'].updateValueAndValidity;
        }
        else {
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].enable();
            tgCourseAttendanceDetailsFormGroup.controls['score'].enable();
            this.setMaxScoreValidation(index);
        }
        //check if attendance is absent
        //if so, clear score and max score, disable score and max score and remove validation
    }

    setMaxScoreValidation(index: any) {
        var tgCourseAttendanceDetailsArray = this.form.controls['attendeeRows'] as FormArray;
        var tgCourseAttendanceDetailsFormGroup = tgCourseAttendanceDetailsArray.at(index) as FormGroup;
        var score = tgCourseAttendanceDetailsFormGroup.controls['score'].value;
        var maxScore = tgCourseAttendanceDetailsFormGroup.controls['maxScore'].value;
        //to set min validtion to be score
        if (score != "" && !isNaN(parseInt(score, 10))) {
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValidators([Validators.required, Validators.min(score), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].updateValueAndValidity;
        } else {
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValidators([Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].updateValueAndValidity;
        }
        //to set max validtion to be maxScore
        if (maxScore != "" && !isNaN(parseInt(maxScore, 10))) {
            tgCourseAttendanceDetailsFormGroup.controls['score'].setValidators([Validators.required, Validators.min(0), Validators.max(maxScore), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['score'].updateValueAndValidity;
        } else {
            tgCourseAttendanceDetailsFormGroup.controls['score'].setValidators([Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['score'].updateValueAndValidity;
        }
    }

    addCourseAttendanceDetails() {
        const control = <FormArray>this.form.controls['attendeeRows'];
        control.push(this.initAttendeeRows());

    }

    deleteCourseAttendanceDetails(index: number) {
        const attendeeRowsArr = <FormArray>this.form.controls['attendeeRows'];
        const details = attendeeRowsArr.at(index);

        attendeeRowsArr.removeAt(index);
        //set minimum row to be 1, so that user cannot submit empty attendance details
        /*if (attendeeRowsArr.length == 0) {
            this.addCourseAttendanceDetails();
        }*/

        const removeAttendeeRowsArr = this.form.get('removeAttendeeRows').value;
        if (details.get('attendanceDetailId').value != '') {
            removeAttendeeRowsArr.push(details.get('attendanceDetailId').value);
        }
    }

    initAttendeeRows() {
        return this.formBuilder.group({
            attendanceDetailId: [],
            licenceNo: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
            name: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            score: ['', [Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]],
            maxScore: ['', [Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]],
            attendance: ['TP_ATN_ATN', Validators.required]
        });
    }

    goBack() {
        window.history.back();
    }

    updateRecord() {
        this.form.patchValue({
            supportingDocs: this.selectedFiles
        });
        this.tpMrcManageViewService.updateCourseAttendanceDetails(this.form.value).subscribe(data => {
            this.router.navigate(['portal/tp-MRC-manage']);
        });
    }

    loadName(row: AbstractControl) {
        this.tpMrcManageService.loadName(row.get("licenceNo").value).subscribe(data => {
            row.get("name").setValue(data);
        });
    }
}
