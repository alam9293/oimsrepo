import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, AbstractControl } from '@angular/forms';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { TpMrcManageService } from './tp-mrc-manage.service';
import { CommonService, AuthenticationService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormUtil, FileUtil } from '../../../common/helper';
import { Observable } from 'rxjs';
import { User } from '../../../common/models';
import * as moment from 'moment';

@Component({
    selector: 'app-tp-mrc-manage',
    templateUrl: './tp-mrc-manage.component.html',
    styleUrls: ['./tp-mrc-manage.component.scss']
})
export class TpMRCManageComponent implements OnInit {
    currentUser: User;
    form: FormGroup;
    uploadForm: FormGroup;

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    mrcListDataSource = new MatTableDataSource<any>();
    mrcListDisplayedColumns = ['serialNo', 'attendedDate', 'noOfParticipants', 'submissionDate'];

    courseList: any = [];
    uploadCourseList: any = [];
    attendanceTypes: any;
    filter: any = {};
    cnst = cnst;
    todayDate = moment();

    displayAddMrc: boolean = false; //hide add mrc section by default
    displayCourse: boolean = false;          // hide mrc selection until user select the attended date
    displayDataEntry: boolean = false;       //hide add TG records by default
    displayPreviewMrc: boolean = false; //hide preview mrc section by default

    selectedFile: File;
    selectedFiles: any = [];
    publicDeletedFiles: any = [];

    constructor(public formUtil: FormUtil,
        private fileUtil: FileUtil,
        private formBuilder: FormBuilder,
        private router: Router,
        private tpMrcManageService: TpMrcManageService,
        private authenticationService: AuthenticationService,
        private commonService: CommonService
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.uploadForm.pristine;
    }

    ngOnInit() {
        this.currentUser = this.authenticationService.currentUserValue;
        // check if logged in TP can view MRC
        if (this.currentUser.tpMrc) {
            this.form = this.formBuilder.group({
                courseDate: ['']
            });
            this.initUploadForm();
        }
        else {
            this.router.navigate(['/portal/dashboard-tp']);
        }
    }

    ngAfterViewInit() {
        this.loadMrcList();
    }

    loadAttendanceType() {
        this.commonService.getCourseAttendanceTypes().subscribe(data => this.attendanceTypes = data);
    }

    //course code is set at backend
    initUploadForm() {
        this.uploadForm = this.formBuilder.group({
            attendedDate: ['', Validators.required],
            supportingDocs: [],
            totalDoc: [null, [Validators.required, Validators.min(1)]],
            tgCourseAttendanceDetails: this.formBuilder.array([this.initCourseAttendanceDetailsItemRows()])
        });
    }

    initCourseAttendanceDetailsItemRows() {
        return this.formBuilder.group({
            licenceNo: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
            name: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            attendance: ['TP_ATN_ATN', Validators.required],
            score: ['', [Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]],
            maxScore: ['', [Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]]
        });
    }

    resetMrcSearch() {
        this.form.get('courseDate').setValue('');
        this.mrcListDataSource = new MatTableDataSource<any>();
        this.paginator.length = 0;
    }

    loadMrcList() {
        if (this.form.get('courseDate').value != '') {
            this.filter.courseDate = this.form.get('courseDate').value;
        }
        else {
            this.filter.courseDate = "";
        }
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filter
        };

        this.tpMrcManageService.getMRCList(mergedDto).subscribe(data => {
            this.mrcListDataSource = data.records;
            this.paginator.length = data.total;
        })
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    addCourseAttendanceDetails() {
        const control = <FormArray>this.uploadForm.controls['tgCourseAttendanceDetails'];
        control.push(this.initCourseAttendanceDetailsItemRows());
    }

    deleteCourseAttendanceDetails(index: number) {
        const control = <FormArray>this.uploadForm.controls['tgCourseAttendanceDetails'];
        control.removeAt(index);
        //set minimum row to be 1, so that user cannot submit empty attendance details
        /*if (control.length == 0) {
            this.addCourseAttendanceDetails();
        }*/
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                this.selectedFiles.push(data);
                this.uploadForm.get('totalDoc').setValue(this.selectedFiles.length);
            });
        }
        event.target.value = '';
    }

    setPhotoTouched() {
        this.uploadForm.controls['totalDoc'].markAsTouched({ onlySelf: true });
    }

    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.uploadForm.get('totalDoc').setValue(this.selectedFiles.length);
        this.publicDeletedFiles.push(doc.id);
    }

    downloadFile(doc) {
        var fileId = doc.id,
            fileName = doc.originalName;

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    checkIfAbsent(index: number) {
        var tgCourseAttendanceDetailsArray = this.uploadForm.controls['tgCourseAttendanceDetails'] as FormArray;
        var tgCourseAttendanceDetailsFormGroup = tgCourseAttendanceDetailsArray.at(index) as FormGroup;
        var attendance = tgCourseAttendanceDetailsFormGroup.controls['attendance'].value;
        if (attendance == cnst.TgCommonTypes.ATTENDANCE_ABSENT) {
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValue(0);
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValidators(null);
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].updateValueAndValidity;

            tgCourseAttendanceDetailsFormGroup.controls['score'].setValue(0);
            tgCourseAttendanceDetailsFormGroup.controls['score'].setValidators(null);
            tgCourseAttendanceDetailsFormGroup.controls['score'].updateValueAndValidity;
        }
        else {
            this.setMaxScoreValidation(index);
        }
    }

    setMaxScoreValidation(index: any) {
        var tgCourseAttendanceDetailsArray = this.uploadForm.controls['tgCourseAttendanceDetails'] as FormArray;
        var tgCourseAttendanceDetailsFormGroup = tgCourseAttendanceDetailsArray.at(index) as FormGroup;
        var score = tgCourseAttendanceDetailsFormGroup.controls['score'].value;
        var maxScore = tgCourseAttendanceDetailsFormGroup.controls['maxScore'].value;
        //to set min validtion to be score
        if (score != "" && !isNaN(parseInt(score, 10))) {
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValidators([Validators.required, Validators.min(score), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].updateValueAndValidity;
        } else {
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].setValidators([Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['maxScore'].updateValueAndValidity;
        }
        //to set max validtion to be maxScore
        if (maxScore != "" && !isNaN(parseInt(maxScore, 10))) {
            tgCourseAttendanceDetailsFormGroup.controls['score'].setValidators([Validators.required, Validators.min(0), Validators.max(maxScore), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['score'].updateValueAndValidity;
        } else {
            tgCourseAttendanceDetailsFormGroup.controls['score'].setValidators([Validators.required, Validators.min(0), Validators.pattern("^[0-9]*$")]);
            tgCourseAttendanceDetailsFormGroup.controls['score'].updateValueAndValidity;
        }
    }

    uploadAttendance() {
        this.uploadForm.patchValue({
            supportingDocs: this.selectedFiles
        });
        this.tpMrcManageService.saveAttendance(this.uploadForm.value).subscribe(data => {
            this.initUploadForm();
            location.reload();
        });
    }

    loadName(row: AbstractControl, index: any) {

        var licenceNo = row.get("licenceNo").value,
            validLicenceNo = true;;

        for (var i in this.uploadForm.get('tgCourseAttendanceDetails').value) {
            if (index != i && this.uploadForm.get('tgCourseAttendanceDetails').get(i).get('licenceNo').value == licenceNo) {
                validLicenceNo = false;
            }
        }

        if (validLicenceNo) {
            this.tpMrcManageService.loadName(licenceNo).subscribe(data => {
                row.get("name").setValue(data);
            });
        } else {
            row.get('licenceNo').setErrors({ 'sameRecord': true });
        }
    }
}
