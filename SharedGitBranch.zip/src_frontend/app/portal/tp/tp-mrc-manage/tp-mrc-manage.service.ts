import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TpMrcManageService {

    constructor(private http: HttpClient) { }

    public getMRCList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_MRC + '/view', { params: searchDto });
    }

    public saveAttendance(courseAttendanceDetail: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(courseAttendanceDetail)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_MRC + '/save', formData);
    }

    public loadName(licenceNo: string): Observable<any> {
        return this.http.get(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_MRC + '/view/name/' + licenceNo, { responseType: 'text' });
    }
}