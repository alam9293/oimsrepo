import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTable } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { DateValidator } from 'src/app/common/validators';
import * as cnst from '../../../../common/constants';
import { TpPdcCourseService } from '../tp-pdc-course.service';
import { AlertService } from 'src/app/common/services';
import { Observable } from 'rxjs';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
    selector: 'app-tp-pdc-course-view',
    templateUrl: './tp-pdc-course-view.component.html',
    styleUrls: ['./tp-pdc-course-view.component.scss']
})
export class TpPdcCourseViewComponent implements OnInit {
    public Editor = ClassicEditor;
    public config = { toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'inserttable', 'undo', 'redo'] };
    form: FormGroup;
    @ViewChild(MatTable) _matTables;
    subsidiesColumns = ['title', 'description', 'fee'];
    preview: boolean = false;
    cnst = cnst;
    course: any = {};

    constructor(
        private tpPdcCourseService: TpPdcCourseService,
        private route: ActivatedRoute,
        private formBuilder: FormBuilder,
        private router: Router,
        private alertService: AlertService,
    ) { }

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.buildForm();
        this.loadCourse();
    }

    goBack() {
        if (!this.preview) {
            window.history.back();
        } else {
            this.preview = false;
        }
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    loadCourse() {
        this.tpPdcCourseService.getCourse(this.form.get('code').value).subscribe(data => {
            this.buildForm(data);
            this.course = data;
        });
    }

    buildForm(data?) {
        this.form = this.formBuilder.group({
            code: [''],
            name: ['', Validators.required],
            approvedStartDate: ['', Validators.required],
            approvedEndDate: ['', Validators.required],
            languageCode: ['', Validators.required],
            languageLabel: [''],
            typeCode: ['', Validators.required],
            typeLabel: [''],
            noOfHours: ['', Validators.required],
            categoryCode: ['', Validators.required],
            categoryLabel: [''],
            ssgCourseCode: ['', [Validators.maxLength(255)]],
            objective: ['', Validators.required],
            outline: ['', Validators.required],
            classroomHrs: ['', Validators.required],
            outOfClassroomHrs: ['', Validators.required],
            courseFee: ['', Validators.required],
            courseFeeNote: [''],
            subsidies: this.formBuilder.array([]),
        });

        this.form.get('code').setValue(this.route.snapshot.paramMap.get('code'));
        if (data) {
            this.form.patchValue(data);
            // populate subsidies rows
            if (data.subsidies) {
                data.subsidies.forEach(element => {
                    this.addSubsidyRow(element);
                });
                this._matTables.renderRows();
            }
        }
    }

    addSubsidyRow(value?) {
        let subsidyRow = this.formBuilder.group({
            id: [''],
            typeCode: [''],
            title: [''],
            description: [''],
            fee: ['']
        });
        if (value) {
            subsidyRow.patchValue(value);
        }
        this.subsidies.push(subsidyRow);
    }

    previewCourse() {
        this.alertService.clear();
        this.preview = true;
        this.scrollToTop();
    }

    saveOrUpdateCourse() {
        this.alertService.clear();
        if (this.form.valid) {
            this.tpPdcCourseService.saveOrUpdateCourse(this.form.value).subscribe(data => {
                this.alertService.success(cnst.Messages.GENERIC_SUCCCESS);
                this.preview = false;
                this.loadCourse();
                this.scrollToTop();
            }, error => {
                this.alertService.error(cnst.Messages.ERR_MSG_GENERIC);
            });
        }
    }

    goToRenewCourse() {
        this.alertService.clear();
        if (this.form.valid) {
            this.router.navigate(['/portal/tp-pdc-courses/renew/' + this.form.get('code').value]);
        } else {
            this.alertService.error("Please update and submit course details before renew course.");
        }
    }

    get subsidies() {
        return this.form.get('subsidies') as FormArray;
    }
}
