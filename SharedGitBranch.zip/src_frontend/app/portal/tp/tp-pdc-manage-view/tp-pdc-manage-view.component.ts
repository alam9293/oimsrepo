import { Component, OnInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, AbstractControl } from '@angular/forms';
import { TpPDCManageService } from '../../tp/tp-pdc-manage/tp-pdc-manage.service';
import { TpPdcManageViewService } from './tp-pdc-manage-view.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService, AuthenticationService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormUtil, FileUtil } from '../../../common/helper';
import { Observable } from 'rxjs';
import { User } from '../../../common/models';
import * as moment from 'moment';

@Component({
    selector: 'app-tp-pdc-manage-view',
    templateUrl: './tp-pdc-manage-view.component.html',
    styleUrls: ['./tp-pdc-manage-view.component.scss']
})
export class TpPdcManageViewComponent implements OnInit {
    currentUser: User;
    attendanceTypes: any;
    attendanceId: any;
    form: FormGroup;
    courseList: any = [];
    selectedFile: File;
    selectedFiles: any = [];
    publicDeletedFiles: any = [];
    fieldArray: any;
    attendeeRows: FormArray;
    displayPreviewPdc: boolean = false; //hide preview pdc section by default
    cnst = cnst;
    todayDate = moment();

    constructor(public formUtil: FormUtil,
        private fileUtil: FileUtil,
        private formBuilder: FormBuilder,
        private tpPdcManageService: TpPDCManageService,
        private tpPdcManageViewService: TpPdcManageViewService,
        private authenticationService: AuthenticationService,
        private commonService: CommonService,
        private router: Router,
        private route: ActivatedRoute
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.scrollToTop();
        this.currentUser = this.authenticationService.currentUserValue;
        if (this.currentUser.tpPdc) {
            this.form = this.formBuilder.group({
                attendanceId: [],
                courseDate: ['', Validators.required],
                courseEndDate: ['', Validators.required],
                courseCode: ['', Validators.required],
                supportingDocs: [],
                attendeeRows: this.formBuilder.array([]),
                removeAttendeeRows: [[]],
                approvedStartDate: [],
                approvedEndDate: []
            });

            this.loadAttendanceType();
            this.loadDetails();
        } else {
            this.router.navigate(['/portal/dashboard-tp']);
        }

    }

    loadAttendanceType() {
        this.commonService.getCourseAttendanceTypes().subscribe(data => this.attendanceTypes = data);
    }

    loadDetails() {
        this.attendanceId = this.route.snapshot.paramMap.get('id');
        this.tpPdcManageService.getListOfCourse(null).subscribe(data => {
            this.courseList = data
            this.tpPdcManageViewService.getCourseAttendanceDetails(this.attendanceId).subscribe(data => {
                this.form.patchValue(data);

                if (data.supportingDocs) {
                    this.selectedFiles = data.supportingDocs;
                }

                this.form.patchValue({
                    attendanceId: this.attendanceId
                });
                this.attendeeRows = data.attendeeRows;

                const control = <FormArray>this.form.controls['attendeeRows'];
                for (var i in this.attendeeRows) {
                    var attendee = this.attendeeRows[i];
                    control.push(this.formBuilder.group({
                        attendanceDetailId: attendee.attendanceDetailId,
                        licenceNo: [attendee.licenceNo, [Validators.required, Validators.pattern("^[0-9]*$")]],
                        name: [attendee.name, [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
                        attendance: [attendee.attendance, Validators.required]
                    }));
                }
            });

        });

    }

    loadTpCourse() {
        if (this.form.get('courseDate').value != "") {
            this.tpPdcManageService.getListOfCourse(this.form.get('courseDate').value).subscribe(data => this.courseList = data);
        }
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {

                this.selectedFiles.push(data);
            });
        }
        event.target.value = '';
    }

    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.publicDeletedFiles.push(doc.id);
    }

    downloadFile(doc) {
        var fileId = doc.id,
            fileName = doc.originalName;

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    addCourseAttendanceDetails() {
        const control = <FormArray>this.form.controls['attendeeRows'];
        control.push(this.initAttendeeRows());

    }

    deleteCourseAttendanceDetails(index: number) {
        const attendeeRowsArr = <FormArray>this.form.controls['attendeeRows'];
        const details = attendeeRowsArr.at(index);

        attendeeRowsArr.removeAt(index);
        //set minimum row to be 1, so that user cannot submit empty attendance details
        /*if (attendeeRowsArr.length == 0) {
            this.addCourseAttendanceDetails();
        }*/

        const removeAttendeeRowsArr = this.form.get('removeAttendeeRows').value;
        if (details.get('attendanceDetailId').value != '') {
            removeAttendeeRowsArr.push(details.get('attendanceDetailId').value);
        }
    }

    getNameFromCode(list, code) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.courseCode == code) {
                    retVal = element.courseName;
                }
            });
        }
        return retVal;
    }

    getLanguageFromCode(list, code) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.courseCode == code) {
                    retVal = element.language;
                }
            });
        }
        return retVal;
    }

    initAttendeeRows() {
        return this.formBuilder.group({
            attendanceDetailId: [],
            licenceNo: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
            name: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            attendance: ['TP_ATN_ATN', Validators.required]
        });
    }

    goBack() {
        window.history.back();
    }

    updateRecord() {
        this.form.patchValue({
            supportingDocs: this.selectedFiles
        });
        this.tpPdcManageService.updateCourseAttendanceDetails(this.form.value).subscribe(data => {
            this.router.navigate(['portal/tp-PDC-manage']);
        });
    }


    loadName(row: AbstractControl, index: any) {
        var licenceNo = row.get("licenceNo").value,
            validLicenceNo = true;;
        if (licenceNo) {
            for (var i in this.form.get('attendeeRows').value) {
                if (index != i && this.form.get('attendeeRows').get(i).get('licenceNo').value == licenceNo) {
                    validLicenceNo = false;
                }
            }

            if (validLicenceNo) {
                this.tpPdcManageService.loadName(licenceNo).subscribe(data => {
                    row.get("name").setValue(data);
                });
            } else {
                row.get('licenceNo').setErrors({ 'sameRecord': true });
            }
        }

    }
}
