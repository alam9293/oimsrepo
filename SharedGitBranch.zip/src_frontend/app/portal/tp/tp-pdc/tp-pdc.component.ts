import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tp-pdc',
  templateUrl: './tp-pdc.component.html',
  styleUrls: ['./tp-pdc.component.scss']
})
export class TpPDCComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
