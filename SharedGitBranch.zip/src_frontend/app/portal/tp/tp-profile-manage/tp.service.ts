import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { Observable } from 'rxjs';

import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TrainingProviderService {

    constructor(private http: HttpClient) { }

    getProfile(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_TRAINING_PROVIDER + '/profile/load');
    }

    updateTrainingProvider(tp: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_TRAINING_PROVIDER + '/profile/update', tp, { responseType: 'text' });
    }
}
