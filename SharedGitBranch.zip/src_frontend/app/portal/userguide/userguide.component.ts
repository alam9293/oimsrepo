import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-userguide',
  templateUrl: './userguide.component.html',
  styleUrls: ['./userguide.component.scss']
})
export class UserguideComponent implements OnInit {
  dashboardTypeCode: string;
  constructor(
    private router: Router,
    private route: ActivatedRoute,

  ) { }

  ngOnInit() {
    this.dashboardTypeCode = 'AEM';
    
  }

}
