import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directory-ta',
  templateUrl: './directory-ta.component.html',
  styleUrls: ['./directory-ta.component.scss']
})
export class DirectoryTaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
