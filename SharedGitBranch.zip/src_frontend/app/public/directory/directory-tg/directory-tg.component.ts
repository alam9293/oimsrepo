import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directory-tg',
  templateUrl: './directory-tg.component.html',
  styleUrls: ['./directory-tg.component.scss']
})
export class DirectoryTgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
