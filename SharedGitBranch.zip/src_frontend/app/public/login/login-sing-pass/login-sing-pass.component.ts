import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-login-sing-pass',
    templateUrl: './login-sing-pass.component.html',
    styleUrls: ['./login-sing-pass.component.scss']
})
export class LoginSingPassComponent implements OnInit {
    successLink: String;

    constructor(private route: ActivatedRoute) { }

    ngOnInit() {
        this.successLink = this.route.snapshot.paramMap.get('successLink');
    }

    onLogin() {
        localStorage.setItem('isLoggedinPortal', 'true');
    }
}
