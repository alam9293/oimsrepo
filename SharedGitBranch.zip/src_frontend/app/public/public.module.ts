import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatAutocompleteModule,
    MatBadgeModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatPaginatorModule,
    MatRadioModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule
} from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { BackModule } from '../common/modules/back/back.module';
import { StatModule } from '../common/modules/stat/stat.module';
import { PublicRoutingModule } from './public-routing.module';
import { PublicComponent } from './public.component';
import { HomeComponent } from './home/home.component';
import { DirectoryTaComponent } from './directory/directory-ta/directory-ta.component';
import { DirectoryTgComponent } from './directory/directory-tg/directory-tg.component';
import { LoginCorpPassComponent } from './login/login-corp-pass/login-corp-pass.component';
import { LoginSingPassComponent } from './login/login-sing-pass/login-sing-pass.component';
import { LoginPortalIdComponent } from './login/login-portal-id/login-portal-id.component';
import { TaApplicationPreambleComponent } from './ta/ta-application-preamble/ta-application-preamble.component';
import { TgApplicationPreambleComponent } from './tg/tg-application-preamble/tg-application-preamble.component';
import { TgApplicationGuideComponent } from './tg/tg-application-guide/tg-application-guide.component';
import { FooterMenuModule } from '../common/modules/footer-menu/footer-menu.module';
import { TopMenuModule } from '../common/modules/top-menu/top-menu.module';
import { ScrollToTopModule } from '../common/modules/scroll-to-top/scroll-to-top.module';

@NgModule({
    imports: [
        CommonModule,
        FlexLayoutModule,
        FormsModule,
        ReactiveFormsModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatDatepickerModule,
        MatDialogModule,
        MatDividerModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        MatMenuModule,
        MatPaginatorModule,
        MatRadioModule,
        MatSelectModule,
        MatSidenavModule,
        MatSortModule,
        MatStepperModule,
        MatTableModule,
        MatTabsModule,
        MatToolbarModule,
        MatTooltipModule,
        MatMomentDateModule,
        BackModule,
        StatModule,
        PublicRoutingModule,
        FooterMenuModule,
        TopMenuModule,
        ScrollToTopModule
    ],
    declarations: [
        PublicComponent,
        HomeComponent,
        DirectoryTaComponent,
        DirectoryTgComponent,
        LoginCorpPassComponent,
        LoginSingPassComponent,
        LoginPortalIdComponent,
        TaApplicationPreambleComponent,
        TgApplicationPreambleComponent,
        TgApplicationGuideComponent
    ]
})
export class PublicModule { }
