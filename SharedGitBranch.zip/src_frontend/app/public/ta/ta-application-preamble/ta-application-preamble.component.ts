import { Component, OnInit } from '@angular/core';
import { AppUtil } from '../../../common/helper/app.util';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-ta-application-preamble',
    templateUrl: './ta-application-preamble.component.html',
    styleUrls: ['./ta-application-preamble.component.scss']
})
export class TaApplicationPreambleComponent implements OnInit {

    declared: boolean = false;
    cnst = cnst;
    constructor(public appUtil: AppUtil, ) { }

    ngOnInit() {
    }

}
