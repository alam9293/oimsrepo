import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tg-application-preamble',
  templateUrl: './tg-application-preamble.component.html',
  styleUrls: ['./tg-application-preamble.component.scss']
})
export class TgApplicationPreambleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
