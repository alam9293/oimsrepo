import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import 'hammerjs';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
    enableProdMode();
    if (window) {
        window.console.log = function () { };
    }

}

document.write('<script async src="https://www.googletagmanager.com/gtag/js?id=' + environment.googleAnalyticId + '"></script><script>window.dataLayer = window.dataLayer || [];function gtag() { dataLayer.push(arguments); }gtag("js", new Date());</script>');
document.write('<script>(function (w, d, s, l, i) {w[l] = w[l] || []; w[l].push({"gtm.start": new Date().getTime(), event: "gtm.js"}); var f = d.getElementsByTagName(s)[0],j = d.createElement(s), dl = l != "dataLayer" ? "&l=" + l : ""; j.async = true; j.src ="https://www.googletagmanager.com/gtm.js?id=" + i + dl; f.parentNode.insertBefore(j, f);})(window, document, "script", "dataLayer", "' + environment.googleAnalyticTagManagerId + '");</script>');
document.write('<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=' + environment.googleAnalyticTagManagerId + '" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>');

platformBrowserDynamic()
    .bootstrapModule(AppModule)
    .catch(err => console.log(err));
