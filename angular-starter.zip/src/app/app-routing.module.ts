import { NgModule } from '@angular/core';
import { RouterModule, Routes, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import {  PristineGuard, } from './common/guard/pristine.guard';
import * as env from '../environments/environment';
export class HomeComponent { }
export const routes: Routes = [
    { path: '', component: HomeComponent, resolve: { url: 'homeUrl' }, data: { externalUrl: env.environment.webPortalUrl }, pathMatch: 'full' },

{ 
    path: 'Supplier',
    loadChildren: () => import('./public/public.module').then(x => x.PublicModule)
 }

]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: [ PristineGuard, {
        provide: 'homeUrl',
        useValue: (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
            window.location.href = (route.data as any).externalUrl;
        }
    }]
})
export class AppRoutingModule { }
