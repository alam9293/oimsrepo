import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { RouterModule, Routes } from '@angular/router';
import { distinctUntilChanged } from 'rxjs/operators';
import { environment as env } from '../environments/environment';
import { LoaderComponent } from './common/modules/loader/loader.component';


declare var gtag: Function;

@Component({
    selector: 'app-root',
    standalone:false,
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    
})
export class AppComponent implements OnInit {
    title = 'angular-starter';
    constructor(
        private router: Router,
       
    ) {
      //   router.events.pipe(distinctUntilChanged((previous: any, current: any) => {
      //     // Subscribe to any `NavigationEnd` events where the url has changed
      //     if (current instanceof NavigationEnd) {
      //       return previous.url === current.url;
      //     }
      //   })
      // ).subscribe((x: any) => {
      //       gtag('config', env.googleAnalyticId, { 'page_path': x.url });
      //   });
      
        
    }

    ngOnInit() { }

    onActivate(_event: any) {
        window.scrollTo(0, 0);
    }
}
