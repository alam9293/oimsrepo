import { Component, OnInit, Input } from '@angular/core';
import * as cnst from '../../constants';

@Component({
    selector: 'app-footer-menu',
    templateUrl: './footer-menu.component.html',
    styleUrls: ['./footer-menu.component.scss']
})
export class FooterMenuComponent implements OnInit {
    cnst = cnst;

    constructor() { }

    ngOnInit() {

    }

}