import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule} from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FooterMenuComponent } from './footer-menu.component';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule
    ],
    declarations: [FooterMenuComponent],
    exports: [FooterMenuComponent]
})
export class FooterMenuModule { }
