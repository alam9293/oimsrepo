import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { RouterModule, Routes } from '@angular/router';
import { distinctUntilChanged } from 'rxjs/operators';
import { environment as env } from '../environments/environment';
import { LoaderComponent } from './common/modules/loader/loader.component';


declare var gtag: Function;

@Component({
    selector: 'app-root',
    standalone:true,
    templateUrl: './app.server.html',
    styleUrls: ['./app.server.scss'],
    
})
export class AppServer{
    title = 'server config bootstrapping';
 
}
