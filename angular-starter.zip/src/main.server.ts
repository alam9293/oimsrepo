import { bootstrapApplication } from '@angular/platform-browser';
import { AppServer } from './app/server.component';
import { config } from './app/app.config.server';

const bootstrap = () => bootstrapApplication(AppServer, config);

export default bootstrap;
