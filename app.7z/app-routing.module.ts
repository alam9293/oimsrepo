import { NgModule } from '@angular/core';
import { RouterModule, Routes, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthPortalGuard, PristineGuard, } from './common/guard';
import * as env from '../environments/environment';
export class HomeComponent { }
const routes: Routes = [
    { path: '', component: HomeComponent, resolve: { url: 'homeUrl' }, data: { externalUrl: env.environment.webPortalUrl }, pathMatch: 'full' },
    { path: 'portal', loadChildren: './portal/portal.module#PortalModule' },
    { path: 'public', loadChildren: './public/public.module#PublicModule' },]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: [AuthPortalGuard, PristineGuard, {
        provide: 'homeUrl',
        useValue: (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
            window.location.href = (route.data as any).externalUrl;
        }
    }]
})
export class AppRoutingModule { }


