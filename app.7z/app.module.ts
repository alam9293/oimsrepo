import { LayoutModule } from '@angular/cdk/layout';
import { OverlayModule } from '@angular/cdk/overlay';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JwtInterceptor, ErrorInterceptor, VersionCheckInterceptor, EncodeHttpParamsInterceptor } from './common/helper';
import { LoaderInterceptorService } from './common/helper/loader.interceptor';
import { LoaderComponent } from './common/modules/loader/loader.component';
import { ErrorDialogComponent } from './common/modules/error-dialog/errordialog.component'
import { MatDialogModule, MatSnackBarModule } from '@angular/material';
import { ErrorDialogService } from './common/services/errordialog.service';
import { AlertService } from './common/services/alert.service';
import { RedirectService } from './common/directives/redirect.service';

@NgModule({
    declarations: [AppComponent, LoaderComponent, ErrorDialogComponent],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        LayoutModule,
        OverlayModule,
        HttpClientModule,
        MatDialogModule,
        MatSnackBarModule
    ],
    providers: [
        ErrorDialogService,
        AlertService,
        RedirectService,
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: VersionCheckInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptorService, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: EncodeHttpParamsInterceptor, multi: true }
    ],
    entryComponents: [ErrorDialogComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }
