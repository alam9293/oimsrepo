import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';
import { NumeralUtil } from '../helper';
import { concat } from 'rxjs';

/**
 * This directive will round up to nearest integer and format the value to comma separated 
 * It is used in TA Audited Account Submission Form ,TA ABPR Form
 */
@Directive({
    selector: '[amountRoundSeparator]'
})
export class AmountRoundSeparatorDirective {

    ngOnInit() { }

    constructor(private control: NgControl) { }

    @HostListener('focusout', ['$event']) onLostFocus(event) {

        var value = this.control.value;
        if (value instanceof String) {
        } else {
            value = '' + value; // convert to string
        }
        value = value.replace(NumeralUtil.ALPHABET_CHAR, "");
        value = value.replace(NumeralUtil.SPECIAL_CHAR, "");
        value = value.replace(/,/g, '');

        var roundValue: any;
        roundValue = (Math.round(value)).toString();
        if (roundValue == 'NaN') {
            roundValue = 0;
        }
        var temp = NumeralUtil.addComma(roundValue);
        if (temp) {
            this.control.control.setValue(temp);
        } else {
            this.control.control.setValue(roundValue);
        }
    }

    @HostListener('keyup', ['$event']) inputChangedUp(event) {
        var value = this.control.value;
        value = value.replace(NumeralUtil.ALPHABET_CHAR, "");
        value = value.replace(NumeralUtil.SPECIAL_CHAR, "");
        value = value.replace(/,/g, '');
        var decVal: string;
        if (this.control.value.indexOf('.') >= 0) {
            value = value.split(".")[0];
            decVal = this.control.value.split(".")[1];
            decVal = decVal.replace(NumeralUtil.ALPHABET_CHAR, "");
            decVal = decVal.replace(NumeralUtil.SPECIAL_CHAR, "");
            decVal = decVal.replace(/,/g, '');

            var temp = NumeralUtil.addComma(value);
            this.control.control.setValue(temp.concat(decVal ? '.'.concat(decVal) : '.'));
        } else {
            this.control.control.setValue(NumeralUtil.addComma(value));
        }
    }

}
