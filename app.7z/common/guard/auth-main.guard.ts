import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Router } from '@angular/router';

@Injectable()
export class AuthMainGuard implements CanActivate {
    constructor(private router: Router) { }

    canActivate() {
        if (localStorage.getItem('isLoggedinMain')) {
            return true;
        } else {
            this.router.navigate(['/login']);
            return false;
        }
    }
}
