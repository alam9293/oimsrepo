import { Injectable } from '@angular/core';
import * as cnst from '../constants';
@Injectable({
    providedIn: 'root'
})
export class AppUtil {

    constructor() { }

    routeToHomePage() {
        window.location.href = cnst.WEB_PORTAL_URL;
    }

}
