import { Injectable } from '@angular/core';
import * as moment from 'moment';


@Injectable({
    providedIn: 'root'
})
export class DateUtil {

    constructor() { }

    public static DATETIME_FORMAT = "DD-MMM-YYYY HH:mm:ss";
    public static TIME_FORMAT = "HH:mm:ss";
    public static DATE_FORMAT = "DD-MMM-YYYY";
    public static REPORT_DATE_FORMAT = "YYYYMMDD";

    public static parseDate(value: string): moment.Moment {
        if (value) {
            return moment(value, DateUtil.DATE_FORMAT);
        } else {
            return null;
        }
    }

    public static parseDateTime(value: string): moment.Moment {
        if (value) {
            return moment(value, DateUtil.DATETIME_FORMAT);
        } else {
            return null;
        }
    }

    public static parseTime(value: string): moment.Moment {
        if (value) {
            return moment(value, DateUtil.TIME_FORMAT);
        } else {
            return null;
        }
    }

    public static getNow(): moment.Moment {
        return moment();
    }

    public static differenceInDays(date1: moment.Moment, date2: moment.Moment) {
        return date2.diff(date1, 'day');
    }

    isMoreThanXdaysLate(date: any, x: number) {
        if (DateUtil.differenceInDays(DateUtil.parseDate(date), DateUtil.getNow()) > x) {
            return true;
        } else {
            return false;
        }
    }
    plusDays(date: any, x: number) {
        if (DateUtil.parseDate(date)) {
            return DateUtil.parseDate(date).add(x, 'day');
        }
        return date;
    }
}
