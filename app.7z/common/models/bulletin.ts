import { Observable } from "rxjs";
import { BulletinItemDto } from "./common";

export class Bulletin {
    
    generalBulletins: Observable<BulletinItemDto>;
    taBulletins: Observable<BulletinItemDto>;
    tgBulletins: Observable<BulletinItemDto>;
    recentPosts: Observable<BulletinItemDto>;  
}