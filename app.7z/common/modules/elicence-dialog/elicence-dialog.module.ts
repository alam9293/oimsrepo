import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatButtonModule, MatIconModule, MatDividerModule } from '@angular/material';
import { ELicenceDialogComponent } from './elicence-dialog.component';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDividerModule,
        MatDialogModule
    ],
    declarations: [ELicenceDialogComponent],
    exports: [ELicenceDialogComponent]
})
export class ELicenceDialogModule { }

