import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-information-dialog',
    templateUrl: './information-dialog.component.html',
    styleUrls: ['./information-dialog.component.scss']
})
export class InformationDialogComponent implements OnInit {

    constructor(public dialogRef: MatDialogRef<InformationDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, ) { }

    url: string;
    ngOnInit() {
        this.url = this.data.url;
    }

    onCLose() {
        if (this.url != null) {
            this.router.navigate([this.url]);
        }
        this.dialogRef.close();
    }

}
