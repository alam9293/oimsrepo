import { Component, Inject, Input, OnInit, ViewChild, ElementRef, ViewChildren, QueryList } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DatePipe } from '@angular/common';
import { Observable, Subscription, interval } from 'rxjs';

import * as moment from 'moment';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../services/common.service';
import { TaElicenceRequestDialogComponent } from '../ta-elicence-request-dialog/ta-elicence-request-dialog.component';
import { TaElicenceDialogService } from '../ta-elicence-dialog/ta-elicence-dialog.service';
import { jsPDF } from "jspdf";
import JSZip from 'jszip/dist/jszip';
import * as FileSaver from 'file-saver';
import { DateUtil } from '../../helper';

declare var gtag: Function;

@Component({
    selector: 'app-ta-elicence-dialog',
    templateUrl: './ta-elicence-dialog.component.html',
    styleUrls: ['./ta-elicence-dialog.component.scss'],
    providers: [{ provide: DatePipe }]
})
export class TaElicenceDialogComponent implements OnInit {

    cnst = cnst;
    @ViewChild('canvas') canvas: ElementRef<HTMLCanvasElement>;
    private ctx: CanvasRenderingContext2D;
    private ctx1: CanvasRenderingContext2D;
    @Input() public heightRatio = 1.4142;
    @Input() public totalWidth = 0;
    @Input() public totalHeight = this.totalWidth * this.heightRatio;
    @Input() public totalA4Width = 0;
    @Input() public totalA4Height = 0;
    @Input() public width = 650;
    @Input() public height = 919;
    protected datePipe: DatePipe = new DatePipe('en-US');
    txtwidth = "";
    msg = "";

    constructor(private commonService: CommonService,
        private service: TaElicenceDialogService,
        public dialogRef: MatDialogRef<TaElicenceDialogComponent>,
        public dialog: MatDialog,
        @Inject(MAT_DIALOG_DATA) public data: any, private el: ElementRef) { }

    ngOnInit() {
    }

    ngAfterViewInit() {
        if (!this.data) {
            this.data = {};
        } else {
            this.data.licence.downloadFlag = this.getDefaultValue(this.data.licence.downloadFlag);
            this.drawLicenceImage();
            if (this.data.branchaddrlist.length > 0) {
                this.drawBranchLicenceImage();
            }

            //Special handling for mobile/ipad which font face fail to load at the first time
            if (/Android|webOS|iPhone|iPad|iPod|Macintosh|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                interval(500).subscribe(
                    (val) => {
                        if (val == 0) {
                            this.drawLicenceImage();
                            if (this.data.branchaddrlist.length > 0) {
                                this.drawBranchLicenceImage();
                            }
                        }
                    });
            }
        }
    }

    drawBranchLicenceImage() {
        if (this.data.branchaddrlist != null) {
            for (var i = 0; i < this.data.branchaddrlist.length; i++) {

                let branchAddress1 = this.getAddressLine1(this.data.branchaddrlist[i]);
                let branchAddress2 = this.getAddressLine2(this.data.branchaddrlist[i]);

                let canvas: any;
                canvas = <HTMLCanvasElement>this.el.nativeElement.querySelector('#canvas-' + i);
                let ctx = canvas.getContext('2d');
                if (ctx != null) {
                    ctx.canvas.style.width = ctx.canvas.clientWidth + 'px';
                    ctx.canvas.style.height = (ctx.canvas.clientWidth * this.heightRatio) + 'px';
                    ctx.canvas.width = this.width;
                    ctx.canvas.height = this.height;

                    this.totalWidth = ctx.canvas.width;
                    this.totalHeight = this.totalWidth * this.heightRatio;

                    ctx.clearRect(0, 0, this.totalWidth, this.totalHeight);
                    ctx.beginPath();

                    let backgroundImage = new Image();
                    let qrCode = new Image();
                    let offset = this.calculateSP(1.68, this.totalWidth);

                    qrCode.src = "data:image/png;base64," + this.data.qrCode;
                    backgroundImage.onload = () => {
                        ctx.drawImage(backgroundImage, 0, 0, this.totalWidth, this.totalHeight); //background template
                        ctx.lineWidth = 1;

                        ctx.drawImage(backgroundImage, 0, 0, this.totalWidth, this.totalHeight); //background template
                        ctx.lineWidth = 1;

                        //title
                        var textTitle_dx = this.calculateSP(32.1, this.totalWidth);
                        var textTitle_dy = this.calculateSP(12.47, this.totalHeight);
                        var textTitle = "";
                        if (this.data.licence.licenceTier.key == cnst.TaLicenceTier.TA_TIER_G) {
                            textTitle = "TRAVEL AGENT LICENCE (GENERAL)";
                        } else {
                            textTitle = "TRAVEL AGENT LICENCE (NICHE)";
                        }
                        var ctxTitle = canvas.getContext('2d');
                        ctxTitle.font = "16pt Calibri Bold Italic";
                        var textTitleWidth = ctxTitle.measureText(textTitle).width;
                        ctxTitle.fillText(textTitle, textTitle_dx, textTitle_dy);

                        //Licence Label
                        var licenceLabel_dx = this.calculateSP(32.1, this.totalWidth);
                        var licenceLabel_dy = this.calculateSP(14.96, this.totalHeight);
                        var licenceLabel = "Licence Number";
                        var ctxLicenceLabel = canvas.getContext('2d');
                        ctxLicenceLabel.font = "16pt Times New Roman Bold";
                        var ctxLicenceLabelWidth = ctxLicenceLabel.measureText(licenceLabel).width;
                        ctxLicenceLabel.fillText(licenceLabel, licenceLabel_dx, licenceLabel_dy);

                        //Licence
                        var licence_dx = this.calculateSP(32.1, this.totalWidth);
                        var licence_dy = this.calculateSP(18.29, this.totalHeight);
                        var licence = this.cnst.dashboardTypeCode.TA + this.data.licence.licenceNumber;
                        var ctxLicence = canvas.getContext('2d');
                        ctxLicence.font = "19pt Times New Roman Bold";
                        var ctxLicenceWidth = ctxLicence.measureText(licence).width;
                        ctxLicence.fillText(licence, licence_dx, licence_dy);

                        //Licensee Label
                        var licenseeLabel_dx = this.calculateSP(11, this.totalWidth);
                        var licenseeLabel_dy = this.calculateSP(26.36, this.totalHeight);
                        var licenseeLabel = "Name of Licensee:";
                        var ctxLicenseeLabel = canvas.getContext('2d');
                        ctxLicenseeLabel.font = "13pt Times New Roman Bold";
                        var ctxLicenceLabelWidth = ctxLicenseeLabel.measureText(licenseeLabel).width;
                        ctxLicenseeLabel.fillText(licenseeLabel, licenseeLabel_dx, licenseeLabel_dy);

                        //Licensee 
                        var licensee_dx = (licenseeLabel_dx + ctxLicenceLabelWidth + 5);
                        var licenseeMaxWidth = (this.totalWidth - (licensee_dx + offset)) - (this.calculateSP(8.74, this.totalWidth) + 5);
                        var fontSizeLN = 13;

                        var licensee_dy = this.calculateSP(26.36, this.totalHeight);
                        var ctxLicensee = canvas.getContext('2d');
                        var licensee = this.data.displayName.toLocaleUpperCase().trim();
                        var licenseeFontSize = this.countFontSizeByWidth(ctxLicensee, licensee, "Times New Roman Bold", licenseeMaxWidth, fontSizeLN);
                        ctxLicensee.font = licenseeFontSize + "pt Times New Roman Bold";
                        var licenseeTxtWidth = ctxLicensee.measureText(licensee).width;
                        ctxLicensee.fillText(licensee, (licensee_dx + offset), licensee_dy);

                        //line break
                        var licenseeLineWidth_dy = this.calculateSP(26.84, this.totalHeight);
                        ctx.moveTo(licensee_dx, licenseeLineWidth_dy);
                        ctx.lineTo((licensee_dx + licenseeMaxWidth + offset), licenseeLineWidth_dy);
                        ctx.stroke();

                        //Main Address Label
                        var mainAddrLabel_dx = this.calculateSP(11, this.totalWidth);
                        var mainAddrLabel_dy = this.calculateSP(29.80, this.totalHeight);
                        var mainAddrLabel = "Main Address:";
                        var ctxmainAddrLabel = canvas.getContext('2d');
                        ctxmainAddrLabel.font = "13pt Times New Roman Bold";
                        var ctxmainAddrLabelWidth = ctxmainAddrLabel.measureText(mainAddrLabel).width;
                        ctxmainAddrLabel.fillText(mainAddrLabel, mainAddrLabel_dx, mainAddrLabel_dy);

                        //Main Address
                        var mainAddr_dx = licensee_dx;
                        var mainAddrMaxWidth = (this.totalWidth - (mainAddr_dx + offset)) - (this.calculateSP(8.74, this.totalWidth) + 5);
                        var fontSizeLN = 12;

                        var mainAddr1_dy = this.calculateSP(29.80, this.totalHeight);
                        var mainAddr1 = this.getAddressLine1(this.data.address);
                        var ctxmainAddr1 = canvas.getContext('2d');
                        var mainAddr1FontSize = this.countFontSizeByWidth(ctxmainAddr1, mainAddr1, "Times New Roman Bold", mainAddrMaxWidth, fontSizeLN);
                        ctxmainAddr1.font = mainAddr1FontSize + "pt Times New Roman Bold";
                        var mainAddr1Width = ctxmainAddr1.measureText(mainAddr1).width;
                        ctxmainAddr1.fillText(mainAddr1, (mainAddr_dx + offset), mainAddr1_dy);

                        //line break
                        var mainAddrLineWidth_dy = this.calculateSP(30.28, this.totalHeight);
                        ctx.moveTo(mainAddr_dx, mainAddrLineWidth_dy);
                        ctx.lineTo((mainAddr_dx + mainAddrMaxWidth + offset), mainAddrLineWidth_dy);
                        ctx.stroke();

                        //Main Address2
                        var mainAddr2_dy = this.calculateSP(32.77, this.totalHeight);
                        var mainAddr2 = this.getAddressLine2(this.data.address);
                        var ctxmainAddr2 = canvas.getContext('2d');
                        var mainAddr2FontSize = this.countFontSizeByWidth(ctxmainAddr2, mainAddr2, "Times New Roman Bold", mainAddrMaxWidth, fontSizeLN);
                        ctxmainAddr2.font = mainAddr2FontSize + "pt Times New Roman Bold";
                        var mainAddr2Width = ctxmainAddr2.measureText(mainAddr2).width;
                        ctxmainAddr2.fillText(mainAddr2, (mainAddr_dx + offset), mainAddr2_dy);

                        //line break
                        var mainAddr2LineWidth_dy = this.calculateSP(33.25, this.totalHeight);
                        ctx.moveTo(mainAddr_dx, mainAddr2LineWidth_dy);
                        ctx.lineTo((mainAddr_dx + mainAddrMaxWidth + offset), mainAddr2LineWidth_dy);
                        ctx.stroke();

                        //Period of Validity
                        var periodLabel_dx = this.calculateSP(11, this.totalWidth);
                        var periodLabel_dy = this.calculateSP(36.57, this.totalHeight);
                        var periodLabel = "Period of Validity:";
                        var ctxperiodLabel = canvas.getContext('2d');
                        ctxperiodLabel.font = "13pt Times New Roman Bold";
                        var ctxperiodLabelWidth = ctxperiodLabel.measureText(periodLabel).width;
                        ctxperiodLabel.fillText(periodLabel, periodLabel_dx, periodLabel_dy);

                        var startPeriod_dx = (periodLabel_dx + ctxperiodLabelWidth + 5);
                        var startPeriod_dy = this.calculateSP(36.57, this.totalHeight);
                        var periodMaxWidth = (((this.totalWidth - startPeriod_dx) - (this.calculateSP(8.74, this.totalWidth) + 5)) / 2) - 8;

                        // "to" label
                        var toLabel_dx = (startPeriod_dx + periodMaxWidth);
                        var toLabel_dy = this.calculateSP(36.57, this.totalHeight);
                        var toLabel = "to";
                        var ctxtoLabel = canvas.getContext('2d');
                        ctxtoLabel.font = "13pt Times New Roman Bold";
                        var ctxtoLabelWidth = ctxtoLabel.measureText(toLabel).width;
                        ctxtoLabel.fillText(toLabel, toLabel_dx, toLabel_dy);

                        var endPeriod_dx = (startPeriod_dx + periodMaxWidth + ctxtoLabelWidth);
                        var endPeriod_dy = this.calculateSP(36.57, this.totalHeight);

                        //start period 
                        var textDateOfIssue = this.data.licence.startDate.toUpperCase();
                        var ctxDateOfIssue = canvas.getContext('2d');
                        var dateOfIssueFontSize = this.countFontSizeByWidth(ctxDateOfIssue, textDateOfIssue, "Times New Roman Bold", periodMaxWidth, fontSizeLN);
                        ctxDateOfIssue.font = dateOfIssueFontSize + "pt Times New Roman Bold";
                        var textDateOfIssueWidth = ctxDateOfIssue.measureText(textDateOfIssue).width;
                        ctxDateOfIssue.fillText(textDateOfIssue, (startPeriod_dx + ((periodMaxWidth / 2) - (textDateOfIssueWidth / 2))), startPeriod_dy);

                        //end period - Date of Expriy
                        var textDateOfExpriy = this.data.licence.expiryDate.toUpperCase();
                        var ctxDateOfExpriy = canvas.getContext('2d');
                        var dateOfExpriyFontSize = this.countFontSizeByWidth(ctxDateOfExpriy, textDateOfExpriy, "Times New Roman Bold", periodMaxWidth, fontSizeLN);
                        ctxDateOfExpriy.font = dateOfExpriyFontSize + "pt Times New Roman Bold";
                        var textDateOfExpriyWidth = ctxDateOfExpriy.measureText(textDateOfExpriy).width;
                        ctxDateOfExpriy.fillText(textDateOfExpriy, (endPeriod_dx + ((periodMaxWidth / 2) - (textDateOfExpriyWidth / 2))), endPeriod_dy);

                        //line break for start period
                        var startPeriodLineWidth_dy = this.calculateSP(37.05, this.totalHeight);
                        ctx.moveTo(startPeriod_dx, startPeriodLineWidth_dy);
                        ctx.lineTo((startPeriod_dx + periodMaxWidth), startPeriodLineWidth_dy);
                        ctx.stroke();

                        //line break for end period
                        var endPeriodLineWidth_dy = this.calculateSP(37.05, this.totalHeight);
                        ctx.moveTo(endPeriod_dx, endPeriodLineWidth_dy);
                        ctx.lineTo((endPeriod_dx + periodMaxWidth), endPeriodLineWidth_dy);
                        ctx.stroke();

                        //
                        var txtContent = "is  hereby  licensed  to  carry  on  the  business  of  a  travel agent  at";
                        var txtContent_dx = this.calculateSP(11, this.totalWidth);
                        var txtContent_dy = this.calculateSP(41.56, this.totalHeight);
                        var ctxTxtContent = canvas.getContext('2d');
                        ctxTxtContent.font = "12pt Times New Roman Bold";
                        var ctxTxtContentWidth = ctxTxtContent.measureText(txtContent).width;
                        ctxTxtContent.fillText(txtContent, txtContent_dx, txtContent_dy);

                        //Branch Address Label
                        var branchAddrLabel_dx = this.calculateSP(11, this.totalWidth);
                        var branchAddrLabel_dy = this.calculateSP(47.03, this.totalHeight);
                        var branchAddrLabel = "Branch Address:";
                        var ctxbranchAddrLabel = canvas.getContext('2d');
                        ctxbranchAddrLabel.font = "13pt Times New Roman Bold";
                        var ctxbranchAddrLabelWidth = ctxmainAddrLabel.measureText(branchAddrLabel).width;
                        ctxbranchAddrLabel.fillText(branchAddrLabel, branchAddrLabel_dx, branchAddrLabel_dy);

                        //Branch Address
                        var branchAddr_dx = licensee_dx;
                        var branchAddrMaxWidth = (this.totalWidth - (branchAddr_dx + offset)) - (this.calculateSP(8.74, this.totalWidth) + 5);
                        var fontSizeLN = 13;

                        var branchAddr1_dy = this.calculateSP(47.03, this.totalHeight);
                        var branchAddr1 = branchAddress1;
                        var ctxbranchAddr1 = canvas.getContext('2d');
                        var branchAddr1FontSize = this.countFontSizeByWidth(ctxbranchAddr1, branchAddr1, "Times New Roman Bold", branchAddrMaxWidth, fontSizeLN);
                        ctxbranchAddr1.font = branchAddr1FontSize + "pt Times New Roman Bold";
                        var branchAddr1Width = ctxbranchAddr1.measureText(branchAddr1).width;
                        ctxbranchAddr1.fillText(branchAddr1, (branchAddr_dx + offset), branchAddr1_dy);

                        //line break 
                        var branchAddr1LineWidth_dy = this.calculateSP(47.50, this.totalHeight);
                        ctx.moveTo(branchAddr_dx, branchAddr1LineWidth_dy);
                        ctx.lineTo((branchAddr_dx + branchAddrMaxWidth + offset), branchAddr1LineWidth_dy);
                        ctx.stroke();

                        var branchAddr2_dy = this.calculateSP(50.11, this.totalHeight);
                        var branchAddr2 = branchAddress2;
                        var ctxbranchAddr2 = canvas.getContext('2d');
                        var branchAddr2FontSize = this.countFontSizeByWidth(ctxbranchAddr2, branchAddr2, "Times New Roman Bold", branchAddrMaxWidth, fontSizeLN);
                        ctxbranchAddr2.font = branchAddr2FontSize + "pt Times New Roman Bold";
                        var branchAddr2Width = ctxbranchAddr2.measureText(branchAddr2).width;
                        ctxbranchAddr2.fillText(branchAddr2, (branchAddr_dx + offset), branchAddr2_dy);

                        //line break 
                        var branchAddr2LineWidth_dy = this.calculateSP(50.59, this.totalHeight);
                        ctx.moveTo(branchAddr_dx, branchAddr2LineWidth_dy);
                        ctx.lineTo((branchAddr_dx + branchAddrMaxWidth + offset), branchAddr2LineWidth_dy);
                        ctx.stroke();

                        //line break 
                        var lineWidth_dx = this.calculateSP(8.9, this.totalWidth);
                        var lineWidth_dy = this.calculateSP(53.91, this.totalHeight);
                        var lineWidthxOffset = this.calculateSP(90.76, this.totalWidth);
                        ctx.moveTo(lineWidth_dx, lineWidth_dy);
                        ctx.lineTo(lineWidthxOffset, lineWidth_dy);
                        ctx.stroke();

                        //content
                        var content_dx = this.calculateSP(11, this.totalWidth);
                        var content_dy = this.calculateSP(59.38, this.totalHeight);
                        let content: string[] = ['subject to the provisions of the Travel Agents Act, the Regulations made', 'thereunder and the conditions stipulated by the Singapore Tourism Board.'];
                        var ctxContent = canvas.getContext('2d');
                        ctxContent.font = "12pt Times New Roman Bold";
                        let lineheight = this.calculateSP(2.4, this.totalHeight);
                        var currentheight = 0;
                        for (var j = 0; j < content.length; j++) {
                            currentheight = content_dy + (j * lineheight);
                            ctxContent.fillText(content[j], content_dx, currentheight);
                        }

                        let content1: string[] = ['Unless revoked or surrendered prior to such date under the provisions of', 'the Travel Agents Act or any of the Regulations made thereunder.'];
                        var ctxContent1 = canvas.getContext('2d');
                        ctxContent1.font = "12pt Times New Roman Bold";
                        var content1_dy = this.calculateSP(67.22, this.totalHeight);
                        for (var j = 0; j < content1.length; j++) {
                            currentheight = content1_dy + (j * lineheight);
                            ctxContent1.fillText(content1[j], content_dx, currentheight);
                        }

                        var remark_dx = this.calculateSP(34, this.totalWidth);
                        var remark_dy = this.calculateSP(90.61, this.totalHeight);
                        var remark = "This is a computer-generated document, no signature is required.";
                        var ctxRemark = canvas.getContext('2d');
                        ctxRemark.font = "10pt Times New Roman";
                        ctxRemark.fillText(remark, remark_dx, remark_dy);

                        //
                        var qrInfo_dx = this.calculateSP(11, this.totalWidth);
                        var qrInfo_dy = this.calculateSP(74.5, this.totalHeight);
                        var qrInfo = "Scan QR code to check validity";
                        var ctxQRInfo = canvas.getContext('2d');
                        ctxQRInfo.font = "10pt Times New Roman";
                        ctxQRInfo.fillText(qrInfo, qrInfo_dx, qrInfo_dy);

                        var qrCode_dx = this.calculateSP(11, this.totalWidth);
                        var qrWidth = this.calculateSP(28.57, this.totalWidth);
                        var qrCode_dy = this.calculateSP(130, this.totalHeight);
                        ctx.drawImage(qrCode, qrCode_dx, remark_dy - 130, 130, 130);
                    }

                    if (this.data.licence.licenceTier.key == cnst.TaLicenceTier.TA_TIER_G) {
                        backgroundImage.src = "./assets/images/elicence/STB_Certificate_General.png";
                    } else {
                        backgroundImage.src = "./assets/images/elicence/STB_Certificate_Niche.png";
                    }
                }

            }
        }
    }

    drawLicenceImage() {
        this.ctx = this.canvas.nativeElement.getContext('2d');
        this.ctx.canvas.style.width = this.ctx.canvas.clientWidth + 'px';
        this.ctx.canvas.style.height = (this.ctx.canvas.clientWidth * this.heightRatio) + 'px';
        this.ctx.canvas.width = this.width;
        this.ctx.canvas.height = this.height;

        this.txtwidth = this.ctx.canvas.style.width;
        //show msg
        this.showMessage();

        this.totalWidth = this.ctx.canvas.width;
        this.totalHeight = this.totalWidth * this.heightRatio;

        this.ctx.clearRect(0, 0, this.totalWidth, this.totalHeight);
        this.ctx.beginPath();
        const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
        canvasEl.width = this.totalWidth;
        canvasEl.height = this.totalHeight;

        let backgroundImage = new Image();
        let qrCode = new Image();
        let offset = this.calculateSP(2, this.totalWidth);

        qrCode.src = "data:image/png;base64," + this.data.qrCode;
        backgroundImage.onload = () => {
            this.ctx.drawImage(backgroundImage, 0, 0, this.totalWidth, this.totalHeight); //background template
            this.ctx.lineWidth = 1;

            //title
            var textTitle_dx = this.calculateSP(32.1, this.totalWidth);
            var textTitle_dy = this.calculateSP(12.47, this.totalHeight);
            var textTitle = "";
            if (this.data.licence.licenceTier.key == cnst.TaLicenceTier.TA_TIER_G) {
                textTitle = "TRAVEL AGENT LICENCE (GENERAL)";
            } else {
                textTitle = "TRAVEL AGENT LICENCE (NICHE)";
            }
            var ctxTitle = this.canvas.nativeElement.getContext('2d');
            ctxTitle.font = "16pt Calibri Bold Italic";
            var textTitleWidth = ctxTitle.measureText(textTitle).width;
            ctxTitle.fillText(textTitle, textTitle_dx, textTitle_dy);

            //Licence Label
            var licenceLabel_dx = this.calculateSP(32.1, this.totalWidth);
            var licenceLabel_dy = this.calculateSP(14.96, this.totalHeight);
            var licenceLabel = "Licence Number";
            var ctxLicenceLabel = this.canvas.nativeElement.getContext('2d');
            ctxLicenceLabel.font = "16pt Times New Roman Bold";
            var ctxLicenceLabelWidth = ctxLicenceLabel.measureText(licenceLabel).width;
            ctxLicenceLabel.fillText(licenceLabel, licenceLabel_dx, licenceLabel_dy);

            //Licence
            var licence_dx = this.calculateSP(32.1, this.totalWidth);
            var licence_dy = this.calculateSP(18.29, this.totalHeight);
            var licence = this.cnst.dashboardTypeCode.TA + this.data.licence.licenceNumber;
            var ctxLicence = this.canvas.nativeElement.getContext('2d');
            ctxLicence.font = "19pt Times New Roman Bold";
            var ctxLicenceWidth = ctxLicence.measureText(licence).width;
            ctxLicence.fillText(licence, licence_dx, licence_dy);

            //Licensee Label
            var licenseeLabel_dx = this.calculateSP(11, this.totalWidth);
            var licenseeLabel_dy = this.calculateSP(26.12, this.totalHeight);
            var licenseeLabel = "Name of Licensee:";
            var ctxLicenseeLabel = this.canvas.nativeElement.getContext('2d');
            ctxLicenseeLabel.font = "13pt Times New Roman Bold";
            var ctxLicenceLabelWidth = ctxLicenseeLabel.measureText(licenseeLabel).width;
            ctxLicenseeLabel.fillText(licenseeLabel, licenseeLabel_dx, licenseeLabel_dy);

            //Licensee 
            var licensee_dx = (licenseeLabel_dx + ctxLicenceLabelWidth + 5);
            var licenseeMaxWidth = (this.totalWidth - (licensee_dx + offset)) - (this.calculateSP(8.74, this.totalWidth) + 5);
            var fontSizeLN = 13;

            var licensee_dy = this.calculateSP(26.12, this.totalHeight);
            var ctxLicensee = this.canvas.nativeElement.getContext('2d');
            var licensee = this.data.displayName.toLocaleUpperCase().trim();
            var licenseeFontSize = this.countFontSizeByWidth(ctxLicensee, licensee, "Times New Roman Bold", licenseeMaxWidth, fontSizeLN);
            ctxLicensee.font = licenseeFontSize + "pt Times New Roman Bold";
            var licenseeTxtWidth = ctxLicensee.measureText(licensee).width;
            ctxLicensee.fillText(licensee, (licensee_dx + offset), licensee_dy);

            //line break
            var licenseeLineWidth_dy = this.calculateSP(26.60, this.totalHeight);
            this.ctx.moveTo(licensee_dx, licenseeLineWidth_dy);
            this.ctx.lineTo((licensee_dx + licenseeMaxWidth + offset), licenseeLineWidth_dy);
            this.ctx.stroke();

            //Main Address Label
            var mainAddrLabel_dx = this.calculateSP(11, this.totalWidth);
            var mainAddrLabel_dy = this.calculateSP(31.59, this.totalHeight);
            var mainAddrLabel = "Main Address:";
            var ctxmainAddrLabel = this.canvas.nativeElement.getContext('2d');
            ctxmainAddrLabel.font = "13pt Times New Roman Bold";
            var ctxmainAddrLabelWidth = ctxmainAddrLabel.measureText(mainAddrLabel).width;
            ctxmainAddrLabel.fillText(mainAddrLabel, mainAddrLabel_dx, mainAddrLabel_dy);

            //Main Address1
            var mainAddr_dx = licensee_dx;
            var mainAddrMaxWidth = (this.totalWidth - (mainAddr_dx + offset)) - (this.calculateSP(8.74, this.totalWidth) + 5);
            var fontSizeLN = 12;

            var mainAddr1_dy = this.calculateSP(31.59, this.totalHeight);
            var mainAddr1 = this.getAddressLine1(this.data.address);
            var ctxmainAddr1 = this.canvas.nativeElement.getContext('2d');
            var mainAddr1FontSize = this.countFontSizeByWidth(ctxmainAddr1, mainAddr1, "Times New Roman Bold", mainAddrMaxWidth, fontSizeLN);
            ctxmainAddr1.font = mainAddr1FontSize + "pt Times New Roman Bold";
            var mainAddr1Width = ctxmainAddr1.measureText(mainAddr1).width;
            ctxmainAddr1.fillText(mainAddr1, (mainAddr_dx + offset), mainAddr1_dy);

            //line break
            var mainAddrLineWidth_dy = this.calculateSP(32.06, this.totalHeight);
            this.ctx.moveTo(mainAddr_dx, mainAddrLineWidth_dy);
            this.ctx.lineTo((mainAddr_dx + mainAddrMaxWidth + offset), mainAddrLineWidth_dy);
            this.ctx.stroke();

            //Main Address2
            var mainAddr2_dy = this.calculateSP(35.15, this.totalHeight);
            var mainAddr2 = this.getAddressLine2(this.data.address);
            var ctxmainAddr2 = this.canvas.nativeElement.getContext('2d');
            var mainAddr2FontSize = this.countFontSizeByWidth(ctxmainAddr2, mainAddr2, "Times New Roman Bold", mainAddrMaxWidth, fontSizeLN);
            ctxmainAddr2.font = mainAddr2FontSize + "pt Times New Roman Bold";
            var mainAddr2Width = ctxmainAddr2.measureText(mainAddr2).width;
            ctxmainAddr2.fillText(mainAddr2, (mainAddr_dx + offset), mainAddr2_dy);


            //line break
            var mainAddr2LineWidth_dy = this.calculateSP(35.62, this.totalHeight);
            this.ctx.moveTo(mainAddr_dx, mainAddr2LineWidth_dy);
            this.ctx.lineTo((mainAddr_dx + mainAddrMaxWidth + offset), mainAddr2LineWidth_dy);
            this.ctx.stroke();

            //Period of Validity
            var periodLabel_dx = this.calculateSP(11, this.totalWidth);
            var periodLabel_dy = this.calculateSP(40.85, this.totalHeight);
            var periodLabel = "Period of Validity:";
            var ctxperiodLabel = this.canvas.nativeElement.getContext('2d');
            ctxperiodLabel.font = "13pt Times New Roman Bold";
            var ctxperiodLabelWidth = ctxperiodLabel.measureText(periodLabel).width;
            ctxperiodLabel.fillText(periodLabel, periodLabel_dx, periodLabel_dy);

            var startPeriod_dx = (periodLabel_dx + ctxperiodLabelWidth + 5);
            var startPeriod_dy = this.calculateSP(40.85, this.totalHeight);
            var periodMaxWidth = (((this.totalWidth - startPeriod_dx) - (this.calculateSP(8.74, this.totalWidth) + 5)) / 2) - 8;

            // "to" label
            var toLabel_dx = (startPeriod_dx + periodMaxWidth);
            var toLabel_dy = this.calculateSP(40.85, this.totalHeight);
            var toLabel = "to";
            var ctxtoLabel = this.canvas.nativeElement.getContext('2d');
            ctxtoLabel.font = "13pt Times New Roman Bold";
            var ctxtoLabelWidth = ctxtoLabel.measureText(toLabel).width;
            ctxtoLabel.fillText(toLabel, toLabel_dx, toLabel_dy);

            var endPeriod_dx = (startPeriod_dx + periodMaxWidth + ctxtoLabelWidth);
            var endPeriod_dy = this.calculateSP(40.85, this.totalHeight);

            //start period 
            var textDateOfIssue = this.data.licence.startDate.toUpperCase();
            var ctxDateOfIssue = this.canvas.nativeElement.getContext('2d');
            var dateOfIssueFontSize = this.countFontSizeByWidth(ctxDateOfIssue, textDateOfIssue, "Times New Roman Bold", periodMaxWidth, fontSizeLN);
            ctxDateOfIssue.font = dateOfIssueFontSize + "pt Times New Roman Bold";
            var textDateOfIssueWidth = ctxDateOfIssue.measureText(textDateOfIssue).width;
            ctxDateOfIssue.fillText(textDateOfIssue, (startPeriod_dx + ((periodMaxWidth / 2) - (textDateOfIssueWidth / 2))), startPeriod_dy);

            //end period - Date of Expriy
            var textDateOfExpriy = this.data.licence.expiryDate.toUpperCase();
            var ctxDateOfExpriy = this.canvas.nativeElement.getContext('2d');
            var dateOfExpriyFontSize = this.countFontSizeByWidth(ctxDateOfExpriy, textDateOfExpriy, "Times New Roman Bold", periodMaxWidth, fontSizeLN);
            ctxDateOfExpriy.font = dateOfExpriyFontSize + "pt Times New Roman Bold";
            var textDateOfExpriyWidth = ctxDateOfExpriy.measureText(textDateOfExpriy).width;
            ctxDateOfExpriy.fillText(textDateOfExpriy, (endPeriod_dx + ((periodMaxWidth / 2) - (textDateOfExpriyWidth / 2))), endPeriod_dy);

            //line break for start period
            var startPeriodLineWidth_dy = this.calculateSP(41.33, this.totalHeight);
            this.ctx.moveTo(startPeriod_dx, startPeriodLineWidth_dy);
            this.ctx.lineTo((startPeriod_dx + periodMaxWidth), startPeriodLineWidth_dy);
            this.ctx.stroke();

            //line break for end period
            var endPeriodLineWidth_dy = this.calculateSP(41.33, this.totalHeight);
            this.ctx.moveTo(endPeriod_dx, endPeriodLineWidth_dy);
            this.ctx.lineTo((endPeriod_dx + periodMaxWidth), endPeriodLineWidth_dy);
            this.ctx.stroke();

            //line break 
            var lineWidth_dx = this.calculateSP(8.9, this.totalWidth);
            var lineWidth_dy = this.calculateSP(46.08, this.totalHeight);
            var lineWidthxOffset = this.calculateSP(90.76, this.totalWidth);
            this.ctx.moveTo(lineWidth_dx, lineWidth_dy);
            this.ctx.lineTo(lineWidthxOffset, lineWidth_dy);
            this.ctx.stroke();

            //content
            var content_dx = this.calculateSP(11, this.totalWidth);
            var content_dy = this.calculateSP(51.78, this.totalHeight);
            let content: string[] = ['is hereby licensed to carry on the business of a travel agent subject to the', 'provisions of the Travel Agents Act, the Regulations made thereunder and', 'the conditions stipulated by the Singapore Tourism Board.'];
            var ctxContent = this.canvas.nativeElement.getContext('2d');
            ctxContent.font = "12pt Times New Roman Bold";
            let lineheight = this.calculateSP(2.4, this.totalHeight);
            var currentheight = 0;
            for (var j = 0; j < content.length; j++) {
                currentheight = content_dy + (j * lineheight);
                ctxContent.fillText(content[j], content_dx, currentheight);
            }

            let content1: string[] = ['Unless revoked or surrendered prior to such date under the provisions of', 'the Travel Agents Act or any of the Regulations made thereunder.'];
            var ctxContent1 = this.canvas.nativeElement.getContext('2d');
            ctxContent1.font = "12pt Times New Roman Bold";
            var content1_dy = this.calculateSP(61.99, this.totalHeight);
            for (var j = 0; j < content1.length; j++) {
                currentheight = content1_dy + (j * lineheight);
                ctxContent1.fillText(content1[j], content_dx, currentheight);
            }

            var remark_dx = this.calculateSP(34, this.totalWidth);
            var remark_dy = this.calculateSP(90.61, this.totalHeight);
            var remark = "This is a computer-generated document, no signature is required.";
            var ctxRemark = this.canvas.nativeElement.getContext('2d');
            ctxRemark.font = "10pt Times New Roman";
            ctxRemark.fillText(remark, remark_dx, remark_dy);

            //
            var qrInfo_dx = this.calculateSP(11, this.totalWidth);
            var qrInfo_dy = this.calculateSP(75.05, this.totalHeight);
            var qrInfo = "Scan QR code to check validity";
            var ctxQRInfo = this.canvas.nativeElement.getContext('2d');
            ctxQRInfo.font = "10pt Times New Roman";
            ctxQRInfo.fillText(qrInfo, qrInfo_dx, qrInfo_dy);

            var qrCode_dx = this.calculateSP(11, this.totalWidth);
            var qrWidth = this.calculateSP(28.57, this.totalWidth);
            var qrCode_dy = this.calculateSP(130, this.totalHeight);
            this.ctx.drawImage(qrCode, qrCode_dx, remark_dy - 130, 130, 130);

        }

        if (this.data.licence.licenceTier.key == cnst.TaLicenceTier.TA_TIER_G) {
            backgroundImage.src = "./assets/images/elicence/STB_Certificate_General.png";
        } else {
            backgroundImage.src = "./assets/images/elicence/STB_Certificate_Niche.png";
        }
    }

    countFontSizeByWidth(context, text, fontface, maxWidth, fontSize) {
        // start with a large font size
        var fontsize = fontSize;

        // lower the font size until the text fits the canvas
        do {
            fontsize = fontsize - 0.01;
            context.font = fontsize + "pt " + fontface;
            //  context.textAlign = 'center';
        } while (parseInt(context.measureText(text).width) > maxWidth)
        return fontsize;
    }

    calculateSP(percent, x) {
        var res = 0;
        res = (percent) * (x / 100);
        return res;
    }

    save() {
        let dto = { "licence": { "downloadFlag": this.data.licence.downloadFlag, "licenceId": this.data.licence.licenceId }, "branchAddrList": this.data.branchaddrlist };
        var cnt = 0; // count of branches able to download e-licence
        for (var i = 0; i < this.data.branchaddrlist.length; i++) {
            if (this.data.branchaddrlist[i].downloadFlag == null
                || this.data.branchaddrlist[i].downloadFlag == this.cnst.ELicenceDownloadRequest.APPROVE
                || this.data.branchaddrlist[i].downloadFlag == this.cnst.ELicenceDownloadRequest.RESET) {
                cnt++;
            }
        }
        if (this.isDownloadableMainELicence()) {
            cnt++;
        }
        this.service.updateFlagAndDownloadFiles(this.data.licence.licenceId).subscribe(res => {
            if (this.data.branchaddrlist != null && this.data.branchaddrlist.length > 0) {
                if (cnt == 1) {
                    FileSaver.saveAs(res, 'TA-e-licence' + this.data.licence.licenceNumber + ".pdf");
                } else {
                    FileSaver.saveAs(res, 'TA-e-licence' + this.data.licence.licenceNumber + "_" + moment(new Date()).format(DateUtil.REPORT_DATE_FORMAT) + ".zip");
                }
            } else {
                FileSaver.saveAs(res, 'TA-e-licence' + this.data.licence.licenceNumber + ".pdf");
            }

            this.data.licence.downloadFlag = this.cnst.ELicenceDownloadRequest.NEED_TO_REQUEST;
            this.data.licence.isDownloadButtonOn = false;
            this.showMessage();
        });
    }

    showMessage() {
        if (this.data.licence.isDownloadButtonOn) {
            this.msg = "E-licence available to download once, please ensure the downloaded licence is kept properly.";
        } else if ((!this.data.licence.isDownloadButtonOn) && (this.data.licence.downloadFlag != this.cnst.ELicenceDownloadRequest.PENDING_REQUEST)) {
            this.msg = "Licence was previously downloaded, additional request is required for a re-download.";
        } else if (this.data.licence.downloadFlag == this.cnst.ELicenceDownloadRequest.PENDING_REQUEST) {
            this.msg = "Licence re-download has been requested, approval is in progress, please wait for an email notification on the approval to re-download.";
        } else {
            this.msg = "";
        }
    }

    isDownloadableMainELicence() {
        if (this.data.licence.downloadFlag != undefined &&
            (this.data.licence.downloadFlag == this.cnst.ELicenceDownloadRequest.PENDING_REQUEST
                || this.data.licence.downloadFlag == this.cnst.ELicenceDownloadRequest.NEED_TO_REQUEST
                || this.data.licence.downloadFlag == this.cnst.ELicenceDownloadRequest.REJECT)) {
            return false;
        }
        return true;
    }

    exportMultipleImagesToPDF(elementIdsOfCanvases: string[], pdffileName: string[], foldername) {
        var zip = new JSZip();
        var pdffolder = null;
        if (foldername != null) {
            pdffolder = zip.folder(foldername);
        }
        for (let i = 0; i < elementIdsOfCanvases.length; i++) {
            let canvas = document.getElementById(elementIdsOfCanvases[i]) as HTMLCanvasElement;
            let dataURL = canvas.toDataURL('image/jpg');
            const pdf = new jsPDF('p', 'pt', 'a4');
            var width = pdf.internal.pageSize.getWidth();
            var height = pdf.internal.pageSize.getHeight();
            pdf.addImage(dataURL, 'PNG', 0, 0, width, height); //sizings here

            if (foldername == null) {
                pdf.save(pdffileName[i]);
            } else {
                var out = pdf.output();
                var url = 'data:application/pdf;base64,' + btoa(out);
                let baseString = this.getBase64String(url);
                pdffolder.file(pdffileName[i], baseString, { base64: true });
            }
        }
        if (foldername != null) {
            zip.generateAsync({ type: "blob" }).then(function (content) {
                FileSaver.saveAs(content, foldername + ".zip");
            });
        }
    }

    getDefaultValue(val) {
        let default_val = 0;
        if (val == null || val == '' || val == undefined) {
            default_val = this.cnst.ELicenceDownloadRequest.RESET;
        } else {
            default_val = val;
        }
        return default_val;
    }

    openRequestReasonDialog() {
        let DialofRef = this.dialog.open(TaElicenceRequestDialogComponent, {
            width: '80%',
            data: ''
        });
    }

    close() {
        this.dialogRef.close();
    }

    getBase64String(dataURL) {
        var idx = dataURL.indexOf('base64,') + 'base64,'.length;
        return dataURL.substring(idx);
    }

    getAddressLine1(address) {
        let addressLine1 = '';
        if (address.type != undefined && address.type.key != undefined && address.type.key != null && address.type.key == this.cnst.AddressTypes.ADDR_LOCAL) {
            addressLine1 = this.getFormattedAddressLine1(address);
        } else {
            addressLine1 = address.singleLineAddress;
        }
        return addressLine1.toLocaleUpperCase().trim();;
    }

    getAddressLine2(address) {
        let addressLine2 = '';
        if (address.type != undefined && address.type.key != undefined && address.type.key != null && address.type.key == this.cnst.AddressTypes.ADDR_LOCAL) {
            addressLine2 = this.getFormattedAddressLine2(address);
        }
        return addressLine2.toLocaleUpperCase().trim();;
    }

    getFormattedAddressLine1(address) {
        var addr1 = address.street;
        if (!this.isNullOrEmpty(address.block)) {
            addr1 = address.block + " " + addr1;
        }

        // populating floor, unit and building
        if (!this.isNullOrEmpty(address.floor) || !this.isNullOrEmpty(address.unit) || !this.isNullOrEmpty(address.building)) {
            addr1 += " ";
        }
        if (!this.isNullOrEmpty(address.floor)) {
            if (!this.isNullOrEmpty(address.unit)) {
                addr1 += "#" + address.floor;
            } else {
                addr1 += address.floor;
            }
        }

        if (!this.isNullOrEmpty(address.unit)) {
            if (!this.isNullOrEmpty(address.floor) && !this.isNullOrEmpty(address.unit)) {
                addr1 += "-" + address.unit;
            } else {
                addr1 += address.unit;
            }
        }

        return addr1;
    }

    getFormattedAddressLine2(address) {
        var addr2 = '';
        if (!this.isNullOrEmpty(address.building)) {
            addr2 += address.building + " ";
        }
        // populating postal
        if (!this.isNullOrEmpty(address.postal)) {
            addr2 += "SINGAPORE " + address.postal;
        }

        return addr2;
    }

    isNullOrEmpty(val) {
        if (val != undefined && val != null && val.trim() != '') {
            return false;
        }
        return true;
    }
}
