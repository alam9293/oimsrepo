import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatButtonModule, MatIconModule, MatDividerModule, MatTooltipModule } from '@angular/material';
import { TaElicenceDialogComponent } from './ta-elicence-dialog.component';

@NgModule({
    declarations: [TaElicenceDialogComponent],
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDividerModule,
        MatDialogModule,
        MatTooltipModule
    ],
    exports: [TaElicenceDialogComponent]
})
export class TaElicenceDialogModule { }
