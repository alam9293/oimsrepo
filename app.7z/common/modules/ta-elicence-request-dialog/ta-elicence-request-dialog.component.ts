import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { TaElicenceRequestDialogService } from './ta-elicence-request-dialog.service';

@Component({
    selector: 'app-ta-elicence-request-dialog',
    templateUrl: './ta-elicence-request-dialog.component.html',
    styleUrls: ['./ta-elicence-request-dialog.component.scss']
})
export class TaElicenceRequestDialogComponent implements OnInit {
    cnst = cnst;
    reason: string = "";
    errMsg: string = "";
    form: FormGroup;
    constructor(private _dialog: MatDialog, public requestDialogRef: MatDialogRef<TaElicenceRequestDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any, private formBuilder: FormBuilder, private service: TaElicenceRequestDialogService, private router: Router) { }

    ngOnInit() {
        this.buildForm();
    }

    buildForm() {
        this.form = this.formBuilder.group({
            reason: '',
            isDownloadable: 0
        });
    }

    submitRequest() {
        let req_reason = this.form.get('reason').value;
        if (req_reason != '' && req_reason != null && req_reason != undefined) {
            if (this.validateInput(req_reason)) {
                this.form = this.formBuilder.group({
                    reason: req_reason,
                    isDownloadable: this.cnst.ELicenceDownloadRequest.PENDING_REQUEST
                });
                this.service.submit(this.form.value).subscribe(data => {
                    //this.form.markAsPristine();
                    //this.alertService.clear();
                    this.service.createTaELicenceRequestApplication().subscribe(data => {
                        this._dialog.closeAll();
                        this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { 'applicationNo': data.applicationNo } });
                    });

                });
            } else {
                this.errMsg = "NA, NIL or - values are not accepted."
            }

        } else {
            this.errMsg = 'Please fill reason';
        }
    }

    validateInput(val) {
        if (val) {
            if (val.trim().toUpperCase() != '-' && val.trim().toUpperCase() != 'NA' && val.trim().toUpperCase() != 'NIL') {
                return true;
            }
        }
        return false;
    }

    close() {
        this.requestDialogRef.close();
    }

}
