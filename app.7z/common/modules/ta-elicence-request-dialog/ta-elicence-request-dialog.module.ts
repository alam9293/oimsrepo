import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatButtonModule, MatIconModule, MatDividerModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TaElicenceRequestDialogComponent } from './ta-elicence-request-dialog.component';

@NgModule({
    declarations: [TaElicenceRequestDialogComponent],
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDividerModule,
        MatDialogModule,
        FormsModule,
        ReactiveFormsModule,
    ],
    exports: [TaElicenceRequestDialogComponent]
})
export class TaElicenceRequestDialogModule { }
