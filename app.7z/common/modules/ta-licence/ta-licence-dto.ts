export interface PeriodicElementDto {
    status: string;


    licenceTier: string;
    companyName: string;
    uen: string;
    formOfBusiness: string;
    taSegmentation: string;
    principleActivity: string;
    placeIncorporated: string;
    statusOfEstablishment: string;
    paidUpCapital: string;
    fye: string;
    website: string;
    businessEmail: string;

    registeredAddressPostalCode: string;
    registeredAddressBlk: string;
    registeredAddressStreet: string;
    registeredAddressBuilding: string;
    registeredAddressLevel: string;
    registeredAddressUnit: string;
    registeredAddressPremises: string;


    operatingAddressPostalCode: string;
    operatingAddressBlk: string;
    operatingAddressStreet: string;
    operatingAddressBuilding: string;
    operatingAddressLevel: string;
    operatingAddressUnit: string;
    operatingAddressPremises: string;

    ke: PersonnelDto;
    keDeclaration: declarationDto[];


}

export interface PersonnelDto {
    isCompany: boolean;
    isFromACRA: boolean;
    name: string;
    nric: string;
    dob: string;
    gender: string;
    nationality: string;
    contactNo: string;
    highestQualification: string;
    email: string;
    joinDate: string;
    roleInCompany: string;
    dateOfAppointment: string;
    designation: string;
    otherDesignation: string;
    noOfShares: string;
    effectiveShareholdingDate: string;
    blk: string;
    street: string;
    buildingName: string;
    level: string;
    unit: string;
    postalCode: string;
    uen: string;
    registeredDate: string;
}

export interface declarationDto {
    statement: string; remarks: string; index: number;
}

export const MOCK_PERIODIC_ELEMENT: PeriodicElementDto = {
    status: 'Pending Approval',

    licenceTier: 'General',
    companyName: 'Charlie and the Chocolate Factory',
    uen: '546454646',
    formOfBusiness: 'Private Limited',
    taSegmentation: '-',
    principleActivity: '-',
    placeIncorporated: '-',
    statusOfEstablishment: '-',
    paidUpCapital: '500, 000',
    fye: '31-Mar',
    website: 'elmo.com',
    businessEmail: 'elmo@wizvision.com',

    registeredAddressPostalCode: '000000',
    registeredAddressBlk: '10',
    registeredAddressStreet: 'Sesame Street',
    registeredAddressBuilding: '-',
    registeredAddressLevel: '-',
    registeredAddressUnit: '-',
    registeredAddressPremises: 'Office Building',


    operatingAddressPostalCode: '000000',
    operatingAddressBlk: '10',
    operatingAddressStreet: 'Sesame Street',
    operatingAddressBuilding: '-',
    operatingAddressLevel: '-',
    operatingAddressUnit: '-',
    operatingAddressPremises: 'Office Building',

    ke: {
        isCompany: null,
        isFromACRA: null,
        name: 'James Lee',
        nric: 'S1111111A',
        dob: '01/01/1980',
        gender: 'Male',
        nationality: 'Singaporean',
        contactNo: '8888 8888',
        highestQualification: 'Bachelor\'s Degree',
        email: 'elmo@wizvision.com',
        joinDate: '01/01/2000',
        roleInCompany: 'Director',
        dateOfAppointment: '01/01/2010',
        designation: 'Director',
        otherDesignation: '-',
        noOfShares: '-',
        effectiveShareholdingDate: '-',
        blk: '10',
        street: 'Sesame St',
        buildingName: '-',
        level: '-',
        unit: '-',
        postalCode: '000000',
        uen: null,
        registeredDate: null,
    },

    keDeclaration: [
        { index: 1, statement: 'I am not an undischarged bankrupt or financially insolvent.', remarks: null },
        { index: 2, statement: 'I have committed any offence involving dishonesty or moral turpitude within a period of 5 years preceding the date of this declaration.', remarks: 'Some remarks and examples about the offence...' },
        { index: 3, statement: 'I have not committed any offence under the Travel Agents Act (Cap.334) or regulations thereunder ,or contravened any condition of a TA licence, within a period of 5 years preceding the date of this declaration.', remarks: null },
        { index: 4, statement: 'I have not held a directorship or other managerial or executive position in any travel agency that has contravened any of the provisions of the Travel Agents Act (Cap.334) or regulations thereunder, or contravened any condition of a TA licence, within a period of 5 years preceding the date of this declaration.', remarks: null },
        { index: 5, statement: 'I have not held a directorship or other managerial or executive position in any travel agency licensed under the Travel Agents Act where the licence has been suspended or revoked by the Singapore Tourism Board within a period of 5 years preceding the date of this declaration.', remarks: null },
        { index: 6, statement: 'I have not been found unsuitable by STB for employment under a travel agency within a period of 5 years preceding the date of this declaration.', remarks: null },
        { index: 7, statement: 'I am not a Key Executive in any other travel agency licensed under the Travel Agents Act at this time.', remarks: null },
        { index: 8, statement: 'Do any of the directors in the business or you have immediate family who is holding or have previously held the Key Executive or directorship position in another travel agency in the last 5 years? No', remarks: null },
        { index: 9, statement: 'Do any of the directors in the business or you have immediate family who held a directorship position in a business entity that has been refused a travel agent licence in the last 5 years? No', remarks: null },
        { index: 10, statement: 'Do any of the directors in the business or you have immediate family who held the Key Executive or directorship in another travel agency which has been revoked or suspended in the last 5 years? No', remarks: null },],


};
export interface PersonnelDetails {
    id: number;
    nric: string;
    name: string;
    appt: string;
    sharesHold: number;
    keyExec: string;
}