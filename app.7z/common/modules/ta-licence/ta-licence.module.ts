import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatDividerModule, MatTabsModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { TaLicenceComponent } from './ta-licence.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatPaginatorModule, MatSortModule, MatTableModule, MatDialogModule } from '@angular/material';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule
    ],
    declarations: [TaLicenceComponent],
    exports: [TaLicenceComponent]
})
export class TaLicenceModule { }

