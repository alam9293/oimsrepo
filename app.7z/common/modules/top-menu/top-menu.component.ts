import { Component, OnInit, Input } from '@angular/core';
import * as cnst from '../../constants';
declare var jQuery: any;
import { ActivatedRoute, Router } from '@angular/router';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { FileUtil, FormUtil } from '../../../common/helper';
import { CommonService } from '../../../common/services'

@Component({
    selector: 'app-top-menu',
    templateUrl: './top-menu.component.html',
    styleUrls: ['./top-menu.component.scss']
})
export class TopMenuComponent implements OnInit {
    cnst = cnst;
    @Input() dashboardTypeCode: string;

    categoryMap = new Map();
    //category: String[] = [];
    filter: any = {};
    resourcesTypeCode: string;

    constructor(private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private fileUtil: FileUtil,
        private commonService: CommonService,
        public formUtil: FormUtil
    ) { }

    reload() {
        console.log('reloading');
        this.ngOnInit();
    }

    ngOnInit() {
        console.log('load bulletin');
        this.categoryMap.set(String(cnst.WEB_PORTAL_BULLETIN), String(cnst.WEB_PORTAL_BULLETIN));
        this.commonService.getAllResourcesList(this.filter, this.resourcesTypeCode).subscribe(data => {
            var JSONObject = JSON.parse(JSON.stringify(data));
            var categoryList = JSONObject["records"];
            categoryList.forEach(bindData => {
                this.categoryMap.set(bindData.title, bindData.id);
            });

        });


        (function ($) {
            var scrolling = false;
            var stickyHeight = $("header").height();
            $(window).scroll(function () {
                if ($(window).width() > 767) {
                    checkWindowScroll();
                }
            });

            function checkWindowScroll() {
                if (stickyHeight != $("header").height()) {
                    stickyHeight = $("header").height();
                }

                var sticky = $('header'),
                    scroll = $(window).scrollTop();

                if (!sticky.hasClass('not-scroll') && $(window).width() > 768) {
                    if (scroll >= (sticky.height())) {
                        sticky.addClass('scroll');

                        if (!scrolling) {
                            sticky.fadeIn().css({ top: -50 }).animate({ top: 0 });
                            scrolling = true;
                            $('body').css('padding-top', stickyHeight);
                        }
                    }
                    else {
                        sticky.removeClass('scroll');
                        scrolling = false;
                        $('body').css('padding-top', '0');
                    }
                }
                else if (sticky.hasClass("scroll-dashboard")) {
                    if (scroll >= (sticky.height())) {
                        sticky.addClass('scroll');

                        if (!scrolling) {
                            sticky.fadeIn().css({ top: -50 }).animate({ top: 0 });
                            scrolling = true;
                            $('body').css('padding-top', stickyHeight);
                        }
                    }
                    else {
                        sticky.removeClass('scroll');
                        scrolling = false;
                        $('body').css('padding-top', stickyHeight + 'px');
                    }
                }
            }

            window.onload = function () {
                checkWindowScroll();
            };
        })(jQuery);
    };
}
