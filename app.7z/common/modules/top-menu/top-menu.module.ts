import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MatButtonModule, MatIconModule } from '@angular/material';
import { TopMenuComponent } from './top-menu.component';

const routes: Routes = [
    { path: '', redirectTo: '/public/home', pathMatch: 'full' },
    { path: 'portal', loadChildren: '../../../portal/portal.module#PortalModule' },
    { path: 'public', loadChildren: '../../../public/public.module#PublicModule' }]

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        RouterModule.forChild(routes)
    ],
    declarations: [TopMenuComponent],
    exports: [TopMenuComponent, RouterModule]
})
export class TopMenuModule { }
