import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarVerticalPosition } from '@angular/material';
import { ErrorDialogComponent } from '../modules/error-dialog/errordialog.component';
import { Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import * as cnst from '../../common/constants';
import { AppUtil } from '../../common/helper/app.util';

@Injectable()
export class ErrorDialogService {
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    constructor(public dialog: MatDialog, public snackBar: MatSnackBar, private router: Router, public authService: AuthenticationService, private appUtil: AppUtil,) { }
    openDialog(data): void {
        const dialogRef = this.dialog.open(ErrorDialogComponent, {
            width: '50vw',
            data: data
        });

        console.log("ErrorDialogService openDialog " + data.status);

        dialogRef.afterClosed().subscribe(result => {
            if (data.status === cnst.HttpStatus.UNAUTHORIZED) {
                // auto logout if 401 response returned from api
                console.log("ErrorDialogService openDialog " + data.status);
                this.authService.logout();
                this.authService.clearSession(); //Clear Session
                this.appUtil.routeToHomePage();
            } else if (data.reason === cnst.Messages.MSG_INVALID_ACCESS) {
                this.router.navigateByUrl(data.routeBackUrl);
            }
        });
    }

    openErrorSnackBar(data) {
        this.snackBar.open(data.reason, 'X', {
            panelClass: ['error-snack'],
            verticalPosition: 'top',
        });
    }
}
