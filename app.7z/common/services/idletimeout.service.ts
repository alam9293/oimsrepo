import { Injectable } from '@angular/core';
import { Observable, Subject, Subscription, timer } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
import * as cnst from '../constants';

const jwtHelper = new JwtHelperService();

@Injectable({
    providedIn: 'root'
})
export class IdleTimeoutService {
    private _serviceId: string = 'idleTimeoutSvc-' + Math.floor(Math.random() * 10000);
    private sessionTimer: Observable<any>;
    private sessionTimerSubscription: Subscription;
    private sessionTimerInterval: number = 1000 * 60 * 1; // one minute
    public timeoutExpired: Subject<number> = new Subject<number>();

    constructor() {
        console.log("Constructed idleTimeoutService " + this._serviceId);

        this.startTimer();
    }

    private setSubscription() {
        //this.lastTime = (new Date()).getTime() ;        
        this.sessionTimer = timer(this.sessionTimerInterval); // compare every one minute
        this.sessionTimerSubscription = this.sessionTimer.subscribe(n => {
            let currentTime: number = (new Date()).getTime() / 1000; // convert to seconds
            let expiredTime = this.getJwtExpirationTime();
            let expiringTime = expiredTime - (cnst.COUNTDOWN_INIT * 60)
            if (currentTime > expiredTime) {
                this.timerComplete(cnst.SESSION_EXPIRED);
                this.stopTimer();
            } else if (currentTime > expiringTime) {
                this.timerComplete(cnst.SESSION_EXPIRING);
                this.stopTimer();
            } else {
                this.sessionTimerSubscription.unsubscribe();
                this.setSubscription();
            }
        });
    }

    private getJwtExpirationTime() {
        if (sessionStorage.getItem('jwt-token')) {
            const jwtToken = sessionStorage.getItem('jwt-token');
            const decodedToken = jwtHelper.decodeToken(jwtToken);
            return decodedToken.exp;
        }
    }

    public startTimer() {
        if (this.sessionTimerSubscription) {
            this.stopTimer();
        }

        this.setSubscription();
    }

    public stopTimer() {
        this.sessionTimerSubscription.unsubscribe();
    }

    public resetTimer() {
        this.startTimer();
    }

    private timerComplete(n: number) {
        this.timeoutExpired.next(n);
    }
}
