import { Injectable, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../constants';

@Injectable({
    providedIn: 'root'
})
export class NotificationService {

    constructor(private http: HttpClient) { }

    @Output() refreshUnread: EventEmitter<Number> = new EventEmitter();

    getAlerts(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/dashboard/alerts', { params: searchDto });
    }

    readAlert(id: number) {
        this.http.post(cnst.apexBaseUrl + '/dashboard/alerts/read/' + id, {}).subscribe(data => {
            this.refreshUnread.emit(data as Number);
        });
    }

    readAlerts(ids: Number[]) {
        return this.http.post(cnst.apexBaseUrl + '/dashboard/alerts/read', ids);
    }

    readAllAlerts() {
        return this.http.get<any>(cnst.apexBaseUrl + '/dashboard/alerts/read/all');
    }

    getTotalUnreadAlerts(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/dashboard/alerts/total-unread');
    }
}
