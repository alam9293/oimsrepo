import { Injectable } from '@angular/core';
import { FormGroup, ValidationErrors } from '@angular/forms';
import { DateUtil } from '../helper';

@Injectable({
    providedIn: 'root'
})
export class DateValidator {

    constructor() { }

    public static dateLessThan(from: string, to: string) {
        return this.dateLessThanWithCode(from, to, 'dateLessThan');
    }

    public static dateLessThanWithCode(from: string, to: string, code: string) {
        var obj = new Object();
        return (group: FormGroup) => {
            if (group.get(from).value != '' && group.get(to).value != '') {
                const invalidStartGreaterEndDate = DateUtil.parseDate(group.get(from).value).isAfter(DateUtil.parseDate(group.get(to).value));
                if (invalidStartGreaterEndDate) {
                    obj[code] = true;
                    group.get(from).setErrors(obj);
                    group.get(to).setErrors(obj);
                }
                else {
                    group.get(from).setErrors(null);
                    group.get(to).setErrors(null);
                }
            }
            return null;
        }
    }
}
