import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as cnst from '../../common/constants';

@Injectable({
  providedIn: 'root'
})

export class BulletinBoardNewsService {

  constructor(private http:HttpClient) { }

  getBulletinNewsData(id:string): Observable<any> {
    const params = new HttpParams()
    .set('id', id);
    return this.http.get(`${cnst.apexBaseUrl}/bulletin/public/bulletin-board-news`,{params});
    
  }

  

  downloadAttachment(id:number,hash:string){
    
    const params = new HttpParams()
    .set('fileId', ""+id)
    .set('hash', hash);
    return this.http.get(`${cnst.apexBaseUrl}/file/download/`,{params});

   }
 
}