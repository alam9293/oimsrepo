import { BulletinBoardNewsService } from './bulletin-board-news-services';
import * as cnst from '../../common/constants';
import { Component, OnInit} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { BulletinItemDto, FileDto} from '../../common/models/common';
import { ResultDto} from '../../common/models/common';
import { FileUtil } from '../../common/helper';
import { Observable,Subject } from "rxjs";


@Component({
    selector: 'app-site',
    templateUrl: './bulletin-board-news.component.html',
    styleUrls: ['./bulletin-board-news.component.scss']
})
export class bulletinBoardNewsComponent implements OnInit {
    dashboardTypeCode: string;
    bulletinId: string;
    //statuscode: string;
    touristGuideStatusCodeMap: Map<string,string>;
    touristGuideLanguageMap: Map<string,string>;
    touristGuideCategoryMap: Map<string,string>;
    touristGuideAreaMap: Map<string,string>;
    cnst = cnst;
    ResultDto: ResultDto<BulletinItemDto>;
    bulletinItems: BulletinItemDto;
       
    p: Number = 1;
    //count: Number = 15;
    count: Number ;
    startIndex:number =1;
    noOfItemsinaPage:number;
    //curentDisplayedPageNo1:number =1;
    //curentDisplayedPageNo2:number  =15;

    totalRecords:number[];
    searchType: string;

    bulletinType: string;
    activeButton = 'BULLETIN_GENERAL';

    // Filtered Crieteria Parameter
    Licenseno: string;
    Status: string;
    Language: string;
    Category: string;
    Name: string;

    inputlicenseno:string;
    statuskeymodel:string ="ALL";
    languagekeymodel:string ="ALL";
    catogerykeymodel:string ="ALL";
    http: any;

    

    
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private bulletinboardnewsService: BulletinBoardNewsService,
        private fileUtil: FileUtil
    ) {}

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        

        this.route.queryParams.subscribe(
            params => {
                this.bulletinId =  params['bulletinId'];
            });
            console.log("bulletinId :"+this.bulletinId);
        this.loadBulletinfromId();
  
    }
   
    loadBulletinfromId()
    {
        console.log("Going to Load Bulletin News Data from Id");
        this.bulletinboardnewsService.getBulletinNewsData(String(this.bulletinId)).subscribe(data =>{
        this.bulletinItems = data ;       
        }); 
    }
    downloadFile(file:FileDto)
    {    
        // this.bulletinboardnewsService.downloadAttachment(file.id,file.hash).subscribe((data:any) => {
        //     if(data === null)
        //     {
        //         console.log('No file Found.....');
        //     }
        //     else
        //     {
        //         try
        //         {
        //             console.log('file loading.....'+data);
        //             let blob:any = new Blob([data], {type: 'application/pdf'});
        //             var downloadURL = window.URL.createObjectURL(data);
        //             var link = document.createElement('a');
        //             link.href = downloadURL;
        //             link.download = file.originalName;
        //             link.click();
        //         }
        //         catch(e)
        //         {
        //             console.log(e);
        //         }
        //     }
            
    	// });
        
                
    }

    
} 
