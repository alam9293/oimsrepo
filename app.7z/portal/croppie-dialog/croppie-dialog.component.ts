import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
    selector: 'app-croppie-dialog',
    templateUrl: './croppie-dialog.component.html',
    styleUrls: ['./croppie-dialog.component.scss']
})
export class CroppieDialogComponent implements OnInit {
    form: FormGroup;

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.form = this.formBuilder.group({
            photo: []
        });
    }

}
