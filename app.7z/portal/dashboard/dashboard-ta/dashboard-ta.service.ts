import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants'

@Injectable({
    providedIn: 'root'
})
export class DashboardTaService {

    constructor(private http: HttpClient) { }

    getDashboardElements(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/dashboard/ta');
    }

    getPendingActions(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/dashboard/ta/pending-actions');
    }

    getMyOustandingPayments(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/dashboard/outstanding-payments');
    }

    // return non-json data (i.e. QR Code image in Base64 string)
    generateELicenceQrCode(licenceNo: String): Observable<any> {
        return this.http.get<string>(cnst.apexBaseUrl + '/qr-code/generate-ta-elicence-qr-code/' + licenceNo, { responseType: 'text' as 'json' });
    }

    getTaELicenceData(): Observable<any> {
        return this.http.get<string>(cnst.apexBaseUrl + '/ta/elicence-request/getData');
    }

}
