import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants'

@Injectable({
    providedIn: 'root'
})
export class DashboardTgService {

    constructor(private http: HttpClient) { }

    public getCountForTopNotification(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_DASHBOARD + '/top-notification');
    }

    getPendingActions(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/dashboard/tg/pending-actions');
    }

    public getLicenceExpiryDate(): Observable<any> {
        return this.http.get<string>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_DASHBOARD + '/licence-expiry-date');
    }

    public getMlptDetails(): Observable<any> {
        return this.http.get<string>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_DASHBOARD + '/mlpt');
    }

    public getStipendDetails(): Observable<any> {
        return this.http.get<string>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_DASHBOARD + '/stipend');
    }

}
