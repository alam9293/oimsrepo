import { Component, OnInit } from '@angular/core';
import { AuthenticationService, NotificationService } from '../../../common/services'
import { User } from '../../../common/models';
import * as _ from 'lodash';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-ta-notification',
    templateUrl: './ta-notification.component.html',
    styleUrls: ['./ta-notification.component.scss']
})
export class TaNotificationComponent implements OnInit {

    alerts: any = [];
    licence: any;
    applicationView = "all";
    currentUser: User;
    cnst = cnst;

    constructor(
        private notificationService: NotificationService,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
        this.loadAlerts();
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
            });
        }
    }

    startIndex = 0;
    totalRecords = 0;
    loadAlerts() {
        let mergedDto = {
            'pageSize': cnst.PAGINATION.DEFAULT_PAGE_SIZE,
            'startIndex': this.startIndex
        };
        this.notificationService.getAlerts(mergedDto).subscribe(data => {
            this.alerts = _.concat(this.alerts, data.records);
            this.totalRecords = data.total;
            var reads = [];
            var unreads = [];
            var idsToClear = [];
            _.forEach(data.records, function (value) {
                if (value.statusCode === cnst.AlertStatuses.READ) {
                    reads.push(value);
                } else if (value.statusCode === cnst.AlertStatuses.UNREAD) {
                    unreads.push(value);
                }
                if (!value.url) {
                    idsToClear.push(value.id);
                }
            });
            this.alerts.read = _.concat(this.alerts.read, reads);
            this.alerts.unread = _.concat(this.alerts.unread, unreads);
            this.startIndex += cnst.PAGINATION.DEFAULT_PAGE_SIZE;
            this.readAlertsWithoutUrl(idsToClear);
        });
    }

    readAlert(alert: any) {
        if (alert.statusCode === cnst.AlertStatuses.UNREAD) {
            this.notificationService.readAlert(alert.id);
        }
    }

    readAlertsWithoutUrl(ids: Number[]) {
        this.notificationService.readAlerts(ids).subscribe(data => { });
    }
}
