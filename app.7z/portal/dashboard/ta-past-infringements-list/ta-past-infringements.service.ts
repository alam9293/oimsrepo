import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants'

@Injectable({
    providedIn: 'root'
})
export class TaPastInfringementService {

    constructor(private http: HttpClient) { }

    getPastInfrignements(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/ce/directory/past-infringements');
    }
}
