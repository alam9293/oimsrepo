import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DashboardTaService } from '../dashboard-ta/dashboard-ta.service';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-ta-pending-actions',
    templateUrl: './ta-pending-actions.component.html',
    styleUrls: ['./ta-pending-actions.component.scss']
})
export class TaPendingActionsComponent implements OnInit {

    filter: any = {};
    applications = [];
    cnst = cnst;
    appsDisplayedColumns = ['date', 'typeRefId', 'status', 'remarks'];
    applicationStatuses: any = [];
    applicationTypes: any = [];

    constructor(
        private route: ActivatedRoute,
        private dialog: MatDialog,
        private service: DashboardTaService
    ) { }

    ngOnInit() {
        this.loadPendingActions();
    }

    loadPendingActions() {
        this.service.getPendingActions().subscribe(data => {
            this.applications = data;
        });
    }
}
