import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class SideMenuTgService {

    constructor(private http: HttpClient) { }

    getCurrentUser() {
        return this.http.get<any>(cnst.apexBaseUrl + '/users/current');
    }

    getSideMenu() {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_DASHBOARD + '/side-menu');
    }
}
