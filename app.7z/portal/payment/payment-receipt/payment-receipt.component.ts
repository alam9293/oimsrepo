import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PaymentService } from '../payment.service';
import { Router } from '@angular/router';
import * as cnst from '../../../common/constants';
import { DateUtil } from '../../../common/helper';

@Component({
    selector: 'app-payment-receipt',
    templateUrl: './payment-receipt.component.html',
    styleUrls: ['./payment-receipt.component.scss']
})
export class PaymentReceiptComponent implements OnInit {

    constructor(private route: ActivatedRoute, private paymentService: PaymentService) { }
    dashboardTypeCode: string;
    cnst = cnst;
    txn: any = { payReqs: [] };
    currentDate: Date;

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        this.paymentService.getPaymentTxn(this.route.snapshot.paramMap.get('txnId')).subscribe(data => {
            this.txn = data;
            this.currentDate = DateUtil.getNow().toDate();
        });
    }
    print() {
        window.print();
    }

}
