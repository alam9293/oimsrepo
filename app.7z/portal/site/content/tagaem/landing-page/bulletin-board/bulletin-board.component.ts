import { BulletinBoardService } from './bulletin-board.services';
import * as cnst from '../../../../../../common/constants';
import { Component, OnInit} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { BulletinItemDto} from '../../../../../../common/models/common';
import { ResultDto} from '../../../../../../common/models/common';
import { Observable,Subject } from "rxjs";


@Component({
    selector: 'app-site',
    templateUrl: './bulletin-board.component.html',
    styleUrls: ['./bulletin-board.component.scss']
})
export class bulletinBoardComponent implements OnInit {
    dashboardTypeCode: string;
    //statuscode: string;
    touristGuideStatusCodeMap: Map<string,string>;
    touristGuideLanguageMap: Map<string,string>;
    touristGuideCategoryMap: Map<string,string>;
    touristGuideAreaMap: Map<string,string>;
    cnst = cnst;
    ResultDto: ResultDto<BulletinItemDto>;
    bulletinItems: Observable<BulletinItemDto[]>;
       
    p: Number = 1;
    //count: Number = 15;
    count: Number ;
    startIndex:number =1;
    noOfItemsinaPage:number;
    //curentDisplayedPageNo1:number =1;
    //curentDisplayedPageNo2:number  =15;

    totalRecords:number[];
    searchType: string;

    bulletinType: string;
    activeButton = 'BULLETIN_GENERAL';

    // Filtered Crieteria Parameter
    Licenseno: string;
    Status: string;
    Language: string;
    Category: string;
    Name: string;

    inputlicenseno:string;
    statuskeymodel:string ="ALL";
    languagekeymodel:string ="ALL";
    catogerykeymodel:string ="ALL";

    

    
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private bulletinboardService: BulletinBoardService,
    ) {}

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        this.noOfItemsinaPage = cnst.PAGINATION.SIZE_OPTTIONS[0];
        console.log('noOfItemsinaPage:-'+this.noOfItemsinaPage);
        this.bulletinItemfromSelectedIndex(this.startIndex,'BULLETIN_GENERAL');
  
    }
    pageNumber:number=1;
    pageChanged(pageno?:number){
         
       pageno+=1;
       this.pageNumber=pageno;
        console.log("Selected pageno...."+pageno);
        if(pageno===1)
        {
            this.startIndex = pageno;
            //this.curentDisplayedPageNo2 = 15*pageno;
             console.log('pageno In If:-'+pageno);
        }
        else
        {
            this.startIndex = this.noOfItemsinaPage*(pageno-1)+1;
            //this.curentDisplayedPageNo2 = 15*pageno;
             console.log('pageno in Else:-'+pageno+ 'start Index:-'+this.startIndex);
        }
        this.bulletinItemfromSelectedIndex(this.startIndex,this.bulletinType);
        // return pageno;
    }
    
    getBulletin(bulletincode:string)
    {
        this.bulletinType=bulletincode;
        if(bulletincode=='BULLETIN_GENERAL')
        {
          this.activeButton = bulletincode;
          this.pageChanged(0);
        }else if(bulletincode=='BULLETIN_TA')
        {
           this.activeButton = bulletincode;
           this.pageChanged(0);

        }else{
            this.activeButton = bulletincode;
            this.pageChanged(0);

        }

        this.bulletinItemfromSelectedIndex(this.startIndex,bulletincode);

    }
   
    bulletinItemfromSelectedIndex(startindex:number,Bulletintype:string)
    {
            console.log("Going to Load Bulletin Items Based on startIndex");
            this.bulletinboardService.getBulletinItemsFromselectedIndex(String(this.startIndex),Bulletintype).subscribe(data =>{

                this.ResultDto    =  data;
                this.ResultDto.total = data.total;
                this.bulletinItems = this.ResultDto.records ; 
                this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
                this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                //console.log("this.totalRecords:"+this.totalRecords);
                console.log("this.ResultDto.total"+data.total);
                console.log("this.ResultDto.noOfPages"+data.noOfPages);    
            }); 
    }
      
}
