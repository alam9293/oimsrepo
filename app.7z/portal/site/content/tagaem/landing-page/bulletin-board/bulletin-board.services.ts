import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as cnst from '../../../../../../common/constants';

@Injectable({
  providedIn: 'root'
})

export class BulletinBoardService {

  constructor(private http:HttpClient) { }

  getBulletinItemsFromselectedIndex(startIndex:string,bulletintype:string): Observable<any> {
    const params = new HttpParams()
    .set('startIndex', startIndex)
    .set('bulletintype', bulletintype);
    return this.http.get(`${cnst.apexBaseUrl}/bulletin/public/bulletin-board`,{params});
    
  }
 
}