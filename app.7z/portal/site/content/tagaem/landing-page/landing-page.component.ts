import { LandingPageService } from './landing-page.services';
import * as cnst from '../../../../../common/constants';
import { Component, OnInit,ViewEncapsulation} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import * as _ from "lodash";
import { TouristGuideItemDto} from '../../../../../common/models/common';
import { ResultDto} from '../../../../../common/models/common';
import { Observable,Subject } from "rxjs";
import { DomSanitizer } from '@angular/platform-browser';
import { Bulletin } from 'src/app/common/models/bulletin';


@Component({
    selector: 'app-site',
    templateUrl: './landing-page.component.html',
    styleUrls: ['./landing-page.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class LandingPageComponent implements OnInit {
    dashboardTypeCode: string;
    //statuscode: string;
    touristGuideStatusCodeMap: Map<string,string>;
    touristGuideLanguageMap: Map<string,string>;
    touristGuideCategoryMap: Map<string,string>;
    touristGuideAreaMap: Map<string,string>;
    travelAgentStatusMap: Map<string,string>;
    travelAgentLicensetypeMap: Map<string,string>;

    cnst = cnst;
    bulletin: Bulletin;
    ResultDto: ResultDto<TouristGuideItemDto>;
    touristGuides: Observable<TouristGuideItemDto[]>;
       
    p: Number = 1;
    //count: Number = 15;
    count: Number ;
    
    startIndex:number =1;
    noOfItemsinaPage:number;
    //curentDisplayedPageNo1:number =1;
    //curentDisplayedPageNo2:number  =15;

    // totalRecords:number[];
    searchType: string;

    // Filtered Crieteria Parameter
    // Licenseno: string;
    // Status: string;
    // Language: string;
    // Category: string;
    // Name: string;

    inputlicenseno:string ="";
    tastatuskeymodel:string ="TA_A";
    tgstatuskeymodel:string ="ALL";
    languagekeymodel:string ="ALL";
    catogerykeymodel:string ="ALL";
    areakeymodel:string ="ALL";

    isCompleted: boolean = false;
    isMobileResolution: boolean = false;
    
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private landingPageService: LandingPageService,
        private _sanitizer: DomSanitizer,
    ) {
        
    }

    ngOnInit() {

        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;

        this.touristGuideStatusCodeMap = cnst.TouristGuideStatusCodeMap.tgStatusCodeMap;
        this.touristGuideLanguageMap = cnst.TouristGuideLanguages.tgLanguagesMap;    
        this.touristGuideCategoryMap = cnst.TouristGuideCategories.tgCategoryMap;
        this.touristGuideAreaMap = cnst.TouristGuideAreas.tgAreaMap;
        this.travelAgentStatusMap = cnst.TravelAgentLicenceStatuses.taLicenceStatusesMap;
        this.travelAgentLicensetypeMap = cnst.TravelAgentLicenceTypes.taLicenceTypesMap;
        
        this.noOfItemsinaPage = cnst.PAGINATION.SIZE_OPTTIONS[2];

        console.log("window.innerWidth :"+window.innerWidth);
        this.getAllpublicBulletins();
  
    }
    scroll() {
        if (window.innerWidth < 769) {

            console.log("Scroll Function called");
            var el  = document.getElementById("page-title-id");
            var el1  = document.getElementById("section-banner");
            var el2  = document.getElementById("top-left-id1");
            console.log("window.pageYOffset :"+window.pageYOffset);
            console.log("el.offsetHeight :"+el.offsetHeight);
            console.log("el1.offsetHeight :"+el1.offsetHeight);
            console.log("el2.offsetHeight :"+el2.offsetHeight);

            if(window.pageYOffset >= el1.offsetHeight+el2.offsetHeight-el.offsetHeight)
            {
                document.getElementById("mobiledivid").style.display ="block"; 
                document.getElementById("top-left-id1").style.display ="none";
            }
            else
            {
                document.getElementById("mobiledivid").style.display ="none";
                document.getElementById("top-left-id1").style.display ="block";
            }
        }  
        else
        {
            document.getElementById("mobiledivid").style.display ="none";
        }         
    }
    getImagePath(extension:string, base64string:string)
    {
        //console.log("extension:"+extension+"base64string:"+base64string);
        let imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/'+extension+';base64,' 
                 +base64string);
        return imagePath;
    }

    // getcurentDisplayedPageNo1(){
    //    return this.curentDisplayedPageNo1;
    // }
    // getcurentDisplayedPageNo2(){
    //     if(this.totalRecords.length<15)
    //     {
    //         return this.totalRecords.length;
    //     }
    //     else
    //     {
    //         return this.curentDisplayedPageNo2;
    //     }
        
    //  }  
    
    pageChanged(pageno:number){
         
        pageno+=1;
        console.log("Selected pageno...."+pageno);
        if(pageno===1)
        {
            this.startIndex = pageno;
            //this.curentDisplayedPageNo2 = 15*pageno;
        }
        else
        {
            this.startIndex = this.noOfItemsinaPage*(pageno-1)+1;
            //this.curentDisplayedPageNo2 = 15*pageno;
        }
    }

    getAllpublicBulletins()
    {
        console.log("Going to Load All Public bulletins");
            this.landingPageService.getAllpublicBulletins().subscribe(data =>{
                
                this.bulletin    =  data;
                this.isCompleted  = true;
                // this.ResultDto    =  data;
                // this.ResultDto.total = data.total;
                // this.touristGuides = this.ResultDto.records ; 
                // this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
               // this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                //console.log("this.totalRecords:"+this.totalRecords);
                // console.log("this.ResultDto.total"+data.total);
                // console.log("this.ResultDto.noOfPages"+data.noOfPages);    
            }); 
    }
    

    tgfilterdformbysearchcrieteria =new FormGroup({
        tglicenceNo:new FormControl(),
        tgstatuskey:new FormControl(),
        languagekey:new FormControl(),
        categorykey:new FormControl(),
        areakey:new FormControl(),
        tgName:new FormControl()
    });

    tafilterdformbysearchcrieteria =new FormGroup({
        taName:new FormControl(),
        talicenceNo:new FormControl(),
        tastatuskey:new FormControl()
    });

    getFilteredtgBySearchCrieteria(getFilteredtgBySearchCrieteria){

        
        console.log("getFilteredtgBySearchCrieteria(getFilteredtgBySearchCrieteria)");

        let tgName:string = this.tgfilterdformbysearchcrieteria.get('tgName').value; 
        let licenseno:string  = this.tgfilterdformbysearchcrieteria.get('tglicenceNo').value;
        let tgstatuskey:string  = this.tgfilterdformbysearchcrieteria.get('tgstatuskey').value;
        let languagekey:string = this.tgfilterdformbysearchcrieteria.get('languagekey').value;
        let categorykey:string = this.tgfilterdformbysearchcrieteria.get('categorykey').value;  
        let areakey:string = this.tgfilterdformbysearchcrieteria.get('areakey').value; 
        
        console.log("tgName**********"+tgName);
        console.log("licenseno**********"+licenseno);
        console.log("tgstatus**********"+tgstatuskey);
        console.log("language**********"+languagekey);
        console.log("category**********"+categorykey);
        console.log("area**********"+areakey);
        
        let param1: string = licenseno==null?"":licenseno;
        let param2: string = this.touristGuideStatusCodeMap.has(tgstatuskey)?tgstatuskey:"";
        let param3: string = this.touristGuideLanguageMap.has(languagekey)?languagekey:"";
        let param4: string = this.touristGuideCategoryMap.has(categorykey)?categorykey:"";
        let param5: string = this.touristGuideAreaMap.has(areakey)?areakey:"";
        let param6: string = tgName;


        let navigationExtras: NavigationExtras = {queryParams: { 
        'param1': param1,
        'param2': param2,
        'param3': param3,
        'param4': param4,
        'param5': param5,
        'param6': param6,
        'param7': true,
        } };  
        // Navigate to the login page with extras
        
        this.router.navigate(['/portal/touristGuide'], navigationExtras);
    };

    getFilteredtaBySearchCrieteria(getFilteredtaBySearchCrieteria){

        
        console.log("getFilteredtaBySearchCrieteria(getFilteredtaBySearchCrieteria)");
        let taName: string=this.tafilterdformbysearchcrieteria.get('taName').value;
        let talicensetypekey: string='';
        let talicenceNo: string=this.tafilterdformbysearchcrieteria.get('talicenceNo').value;
        let tastatuskey: string=this.tafilterdformbysearchcrieteria.get('tastatuskey').value;

        

        this.travelAgentLicensetypeMap.forEach((value: string, key: string) => {
           // console.log(key, value);
            const radio = document.getElementById(
                key,
              ) as HTMLInputElement | null;
              
              if (radio.checked) {
                console.log('Radio is checked');
                talicensetypekey+=key+',';
              } else {
                console.log('Radio is NOT checked');
              }
        });

       
       
        if(talicensetypekey.endsWith(','))
        {
            talicensetypekey = talicensetypekey.substring(0,talicensetypekey.length-1);
        }

        console.log("taName**********"+taName);
        console.log("talicensetypekey**********"+talicensetypekey);
        console.log("talicenceNo**********"+talicenceNo);
        console.log("tastatuskey**********"+tastatuskey);

        let param1: string = taName==null?"":taName;
        let param2: string = talicenceNo==null?"":talicenceNo;
       

        let navigationExtras: NavigationExtras = {queryParams: { 
        'param1': taName,
        'param2': talicensetypekey,
        'param3': talicenceNo,
        'param4': tastatuskey,
        'param5': true,
        } };  
        this.router.navigate(['/portal/travelAgent'], navigationExtras);
    };

    identify(index, item)
    {
        // console.log("index......."+index);
         
        //  return item.label;
    }

    resetDropdown()
    {  
        this.tgfilterdformbysearchcrieteria.controls['tglicenceNo'].setValue("");
        this.tgfilterdformbysearchcrieteria.controls['tgstatuskey'].setValue("ALL");
        this.tgfilterdformbysearchcrieteria.controls['languagekey'].setValue("ALL");
        this.tgfilterdformbysearchcrieteria.controls['categorykey'].setValue("ALL");
    }

    changeDisplayView(viewtype:string)
    {
        if (viewtype==="cardview") 
        {
            for(let i=0;i<this.ResultDto.paginationBean.lastItem;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                console.log("parentDiv.classList:"+parentDiv.classList+" gridorlineviewdividi :"+"gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-12");
                gridviewdiv.classList.remove("list");   //remove the class 
                parentDiv.classList.add("col-sm-4");
                gridviewdiv.classList.add("grid");   //add the class
            }
            document.getElementById("header_textid").style.display ="none";
        }
        if (viewtype==="lineview") 
        {
            for(let i=0;i<this.ResultDto.paginationBean.lastItem;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                console.log("parentDiv.classList:"+parentDiv.classList+" gridorlineviewdividi :"+"gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-4");
                gridviewdiv.classList.remove("grid");   //remove the class
                parentDiv.classList.add("col-sm-12");
                gridviewdiv.classList.add("list");   //add the class
            }
            
            document.getElementById("header_textid").style.display ="block";
        }    
    }

    showhidefiltermobileDiv()
    {
       if(document.getElementById("filtermobiledivid").style.display =="block")
       {
           document.getElementById("filtermobiledivid").style.display ="none";
           document.getElementById("filterclosebtn").textContent="Filter";
       }
       else
       {
          document.getElementById("filtermobiledivid").style.display ="block";
          document.getElementById("filterclosebtn").textContent= "Close";
       }
    }

    getLengthofTgName(tgname:string)
    {
        var str = new String(tgname);
        //console.log("str.length :"+str.length);
        return str.length>38;
    }

    returnZero() {
        return 0
    }

    displayareadiv(categorycode:string)
    {
        let categorykey:string = this.tgfilterdformbysearchcrieteria.get('categorykey').value;
        if(categorykey==='TG_TIER_A'||categorykey==='TG_TIER_GA')
        {
            console.log("categorycode :"+categorykey);
            document.getElementById("asdivid").style.display ="block";
        }
        else
        {
            console.log("categorycode :"+categorykey);
            document.getElementById("asdivid").style.display ="none";
        }
    }

    showhideAdvancedDiv(id:string)
    {
        
        if(document.getElementById(id).style.display==="block")
        {
            document.getElementById(id).style.display ="none";
        }
        else
        {
            document.getElementById(id).style.display ="block";
        }
    }
}
