import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as cnst from '../../../../../common/constants';

@Injectable({
  providedIn: 'root'
})

export class LandingPageService {

  

  constructor(private http:HttpClient) { }

  getAllpublicBulletins(): Observable<any> {
   
    return this.http.get(`${cnst.apexBaseUrl}/bulletin/public/Allbulletins`);
    
  }

  getLicensedTouristGuideList(curentDisplayedPageNo1:string): Observable<any> {
    const params = new HttpParams()
    .set('startIndex', curentDisplayedPageNo1);
    return this.http.get(`${cnst.apexBaseUrl}/directory/tg/licensed`,{params});
    
  }

  getTouristGuidebyFilteredCrieteria(
  licenseno:string,status:string,language:string,category:string,startindex:string): Observable<any> {
    const params = new HttpParams()
    .set('licenseno', licenseno)
    .set('licensestatus', status)
    .set('tglanguage', language)
    .set('tgcategory', category)
    .set('startIndex', startindex);
    return this.http.get(`${cnst.apexBaseUrl}/directory/tg/tgfilteredbysearchparam`,{params}); 
  }

  getTouristGuidebyNameCrieteria(
    name:string,startindex:string): Observable<any> {
      const params = new HttpParams()
    .set('tgName', name)
    .set('startIndex', startindex);
      return this.http.get(`${cnst.apexBaseUrl}/directory/tg/filteredbyName`,{params});
      
    }

  
  
}                                           