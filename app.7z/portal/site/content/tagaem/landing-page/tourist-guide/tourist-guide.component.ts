import { TouristGuideService } from './tourist-guide.services';
import * as cnst from '../../../../../../common/constants';
import { Component, OnInit,ViewEncapsulation} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { TouristGuideItemDto} from '../../../../../../common/models/common';
import { ResultDto} from '../../../../../../common/models/common';
import { Observable,Subject } from "rxjs";
import { DomSanitizer } from '@angular/platform-browser';


@Component({
    selector: 'app-site',
    templateUrl: './tourist-guide.component.html',
    styleUrls: ['./tourist-guide.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class TouristGuideComponent implements OnInit {
    dashboardTypeCode: string;
    //statuscode: string;
    touristGuideStatusCodeMap: Map<string,string>;
    touristGuideLanguageMap: Map<string,string>;
    touristGuideCategoryMap: Map<string,string>;
    touristGuideAreaMap: Map<string,string>;

    cnst = cnst;
    ResultDto: ResultDto<TouristGuideItemDto>;
    touristGuides: Observable<TouristGuideItemDto[]>;
       
    p: Number = 1;
    //count: Number = 15;
    count: Number ;
    
    startIndex:number =1;
    noOfItemsinaPage:number;
    //curentDisplayedPageNo1:number =1;
    //curentDisplayedPageNo2:number  =15;

    totalRecords:number[];
    searchType: string;

    // Filtered Crieteria Parameter routed from Landing Page
    Licenseno: string;
    Status: string;
    Language: string;
    Category: string;
    Area: string;
    Name: string;
    routedFromLandingPage:boolean;

    inputlicenseno:string ="";
    statuskeymodel:string ="ALL";
    languagekeymodel:string ="ALL";
    catogerykeymodel:string ="ALL";
    areakeymodel:string ="ALL";

    isCompleted: boolean = false;
    isMobileResolution: boolean = false;
    
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private touristGuideService: TouristGuideService,
        private _sanitizer: DomSanitizer
    ) {

        
    }

    ngOnInit() {

        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;

        this.touristGuideStatusCodeMap = cnst.TouristGuideStatusCodeMap.tgStatusCodeMap;
        this.touristGuideLanguageMap = cnst.TouristGuideLanguages.tgLanguagesMap;    
        this.touristGuideCategoryMap = cnst.TouristGuideCategories.tgCategoryMap;
        this.touristGuideAreaMap = cnst.TouristGuideAreas.tgAreaMap;
        this.noOfItemsinaPage = cnst.PAGINATION.SIZE_OPTTIONS[2];

        console.log("window.innerWidth :"+window.innerWidth);
        // if (window.innerWidth < 768) {
        //     this.isMobileResolution = true;
        //     document.getElementById("mobiledivid").style.display ="block";
        //   } else {
        //     this.isMobileResolution = false;
        //     document.getElementById("mobiledivid").style.display ="none";
        //   }
        window.addEventListener('scroll', this.scroll, true);

        this.route.queryParams.subscribe(
        params => {
            this.Licenseno =  params['param1'];
            this.Status =  params['param2'];
            this.Language =  params['param3'];
            this.Category =  params['param4'];
            this.Area =  params['param5'];
            this.Name =  params['param6'];
            this.routedFromLandingPage = params['param7'];
        });
        console.log("this.Licenseno :"+this.Licenseno);
        console.log("this.Status :"+this.Status);
        console.log("this.Language :"+this.Language);
        console.log("this.Category :"+this.Category);
        console.log("this.Area :"+this.Area);
        console.log("this.Name :"+this.Name);
        console.log("this.routedFromLandingPage :"+this.routedFromLandingPage);

        if(this.routedFromLandingPage===true)
        {
           // licenseno:string,status:string,language:string,category:string,startindex:string
            this.searchType="FilterBySearchparam";
            this.filterdBySearchparamfromSelectedIndex(this.Licenseno,this.Status,this.Language,this.Category,this.Area,this.Name,1); 
        }
        else
        {
           this.licensedtgfromSelectedIndex(this.startIndex);
        }
        this.statuskeymodel ="TG_A";
    }
    scroll() {
        if (window.innerWidth < 769) {

            console.log("Scroll Function called");
            var el  = document.getElementById("page-title-id");
            var el1  = document.getElementById("section-banner");
            var el2  = document.getElementById("top-left-id1");
            console.log("window.pageYOffset :"+window.pageYOffset);
            console.log("el.offsetHeight :"+el.offsetHeight);
            console.log("el1.offsetHeight :"+el1.offsetHeight);
            console.log("el2.offsetHeight :"+el2.offsetHeight);

            if(window.pageYOffset >= el1.offsetHeight+el2.offsetHeight-el.offsetHeight)
            {
                document.getElementById("mobiledivid").style.display ="block"; 
                document.getElementById("top-left-id1").style.display ="none";
            }
            else
            {
                document.getElementById("mobiledivid").style.display ="none";
                document.getElementById("top-left-id1").style.display ="block";
            }
        }  
        else
        {
            document.getElementById("mobiledivid").style.display ="none";
        }         
    }
    getImagePath(extension:string, base64string:string)
    {
        //console.log("extension:"+extension+"base64string:"+base64string);
        let imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/'+extension+';base64,' 
                 +base64string);
        return imagePath;
    }

    // getcurentDisplayedPageNo1(){
    //    return this.curentDisplayedPageNo1;
    // }
    // getcurentDisplayedPageNo2(){
    //     if(this.totalRecords.length<15)
    //     {
    //         return this.totalRecords.length;
    //     }
    //     else
    //     {
    //         return this.curentDisplayedPageNo2;
    //     }
        
    //  }  
    
    pageChanged(pageno:number){
         
        pageno+=1;
        console.log("Selected pageno...."+pageno);
        if(pageno===1)
        {
            this.startIndex = pageno;
            //this.curentDisplayedPageNo2 = 15*pageno;
        }
        else
        {
            this.startIndex = this.noOfItemsinaPage*(pageno-1)+1;
            //this.curentDisplayedPageNo2 = 15*pageno;
        }
        this.loaddatafromselectedIndex(this.startIndex);
        this.changeDisplayView("cardview");
        // return pageno;
    }

    loaddatafromselectedIndex(startindex:number)
    {
        
        if(this.searchType==="FilterBySearchparam")
        {
            let licenseno:string  = this.tgfilterdformbysearchcrieteria.get('licenceNo').value;
            let statuskey:string  = this.tgfilterdformbysearchcrieteria.get('statuskey').value;
            let languagekey:string = this.tgfilterdformbysearchcrieteria.get('languagekey').value;
            let categorykey:string = this.tgfilterdformbysearchcrieteria.get('categorykey').value; 
            let areakey:string = this.tgfilterdformbysearchcrieteria.get('areakey').value;  
            
            console.log("licenseno**********"+licenseno);
            console.log("status**********"+statuskey);
            console.log("language**********"+languagekey);
            console.log("category**********"+categorykey);
            
            let param1: string = licenseno==null?"":licenseno;
            let param2: string = this.touristGuideStatusCodeMap.has(statuskey)?statuskey:"";
            let param3: string = this.touristGuideLanguageMap.has(languagekey)?languagekey:"";
            let param4: string = this.touristGuideCategoryMap.has(categorykey)?categorykey:"";
            let param5: string = this.touristGuideCategoryMap.has(areakey)?areakey:"";
            let param6: string = "";
            this.filterdBySearchparamfromSelectedIndex(param1,param2,param3,param4,param5,param6,this.startIndex);
        }
        if(this.searchType==="FilterByName")
        {
            let tgName:string = this.tgfilterdformbytgName.get('tgName').value; 
            console.log("tgName**********"+tgName);
            this.filterdByNamefromSelectedIndex(tgName,this.startIndex);
        }
        else
        {
            this.licensedtgfromSelectedIndex(this.startIndex);         
        }
    }

    filterdBySearchparamfromSelectedIndex(param1:string,param2:string,param3:string,param4:string,param5:string,param6:string,startindex:number)
    {
        console.log("Going to Load Tourist Guide Based on Filtered Param and startIndex");
        this.searchType ="FilterBySearchparam";
                this.touristGuideService.getTouristGuidebyFilteredCrieteria(
                param1,param2,param3,param4,param5,param6,String(startindex)).subscribe(data =>{
                    this.isCompleted = true;
                    this.ResultDto    =  data;
                    this.ResultDto.total = data.total;
                    this.touristGuides = this.ResultDto.records ; 
                    this.count = data.total;
                    //this.totalRecords = data.total;
                    // let i:number;
                    this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                    console.log("this.ResultDto.total"+data.total);
                    console.log("this.ResultDto.noOfPages"+data.noOfPages);
                
        });
    }

    filterdByNamefromSelectedIndex(name:string,startindex:number)
    {
        this.searchType ="FilterByName";
        console.log("Going to Load Tourist Guide Based on Name and startIndex");
        this.touristGuideService.getTouristGuidebyNameCrieteria(name,String(startindex)).subscribe(data =>{
            
                this.ResultDto    =  data;
                this.ResultDto.total = data.total;
                this.touristGuides = this.ResultDto.records ; 
                this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
                this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                console.log("this.ResultDto.total"+data.total);
                console.log("this.ResultDto.noOfPages"+data.noOfPages);      
        });
    }

    licensedtgfromSelectedIndex(startindex:number)
    {
        console.log("Going to Load Licensed Tourist Guide Based on startIndex");
            this.touristGuideService.getLicensedTouristGuideList(String(this.startIndex)).subscribe(data =>{
                this.isCompleted = true;
                this.ResultDto    =  data;
                this.ResultDto.total = data.total;
                this.touristGuides = this.ResultDto.records ; 
                this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
                this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                //console.log("this.totalRecords:"+this.totalRecords);
                console.log("this.ResultDto.total"+data.total);
                console.log("this.ResultDto.noOfPages"+data.noOfPages);    
            }); 
    }
    

    tgfilterdformbysearchcrieteria =new FormGroup({
        licenceNo:new FormControl(),
        statuskey:new FormControl(),
        languagekey:new FormControl(),
        categorykey:new FormControl(),
        areakey:new FormControl()
    });

      tgfilterdformbytgName =new FormGroup({
        tgName:new FormControl()
    });

    getFilteredtgByName(getFilteredtgByName){

        console.log("getFilteredtgByName(getFilteredtgByName)");
        let tgName:string = this.tgfilterdformbytgName.get('tgName').value; 
        console.log("tgName**********"+tgName);
        this.filterdByNamefromSelectedIndex(tgName,1);
        this.changeDisplayView("cardview");
    }

    getFilteredtgBySearchCrieteria(getFilteredtgBySearchCrieteria){

        
        console.log("getFilteredtgBySearchCrieteria(getFilteredtgBySearchCrieteria)");

        let licenseno:string  = this.tgfilterdformbysearchcrieteria.get('licenceNo').value;
        let statuskey:string  = this.tgfilterdformbysearchcrieteria.get('statuskey').value;
        let languagekey:string = this.tgfilterdformbysearchcrieteria.get('languagekey').value;
        let categorykey:string = this.tgfilterdformbysearchcrieteria.get('categorykey').value;  
        let areakey:string = this.tgfilterdformbysearchcrieteria.get('areakey').value; 
        
        console.log("licenseno**********"+licenseno);
        console.log("status**********"+statuskey);
        console.log("language**********"+languagekey);
        console.log("category**********"+categorykey);
        
        let param1: string = licenseno==null?"":licenseno;
        let param2: string = this.touristGuideStatusCodeMap.has(statuskey)?statuskey:"";
        let param3: string = this.touristGuideLanguageMap.has(languagekey)?languagekey:"";
        let param4: string = this.touristGuideCategoryMap.has(categorykey)?categorykey:"";
        let param5: string = this.touristGuideCategoryMap.has(areakey)?areakey:"";
        let param6: string = "";

        this.filterdBySearchparamfromSelectedIndex(param1,param2,param3,param4,param5,param6,1);
        this.changeDisplayView("cardview");   
    }
    identify(index, item)
    {
        // console.log("index......."+index);
         
        //  return item.label;
    }

    resetDropdown()
    {  
        this.tgfilterdformbysearchcrieteria.controls['licenceNo'].setValue("");
        this.tgfilterdformbysearchcrieteria.controls['statuskey'].setValue("ALL");
        this.tgfilterdformbysearchcrieteria.controls['languagekey'].setValue("ALL");
        this.tgfilterdformbysearchcrieteria.controls['categorykey'].setValue("ALL");
    }

    changeDisplayView(viewtype:string)
    {
        if (viewtype==="cardview") 
        {
            for(let i=0;i<this.ResultDto.paginationBean.lastItem;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                console.log("parentDiv.classList:"+parentDiv.classList+" gridorlineviewdividi :"+"gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-12");
                gridviewdiv.classList.remove("list");   //remove the class 
                parentDiv.classList.add("col-sm-4");
                gridviewdiv.classList.add("grid");   //add the class
            }
            document.getElementById("header_textid").style.display ="none";
        }
        if (viewtype==="lineview") 
        {
            for(let i=0;i<this.ResultDto.paginationBean.lastItem;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                console.log("parentDiv.classList:"+parentDiv.classList+" gridorlineviewdividi :"+"gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-4");
                gridviewdiv.classList.remove("grid");   //remove the class
                parentDiv.classList.add("col-sm-12");
                gridviewdiv.classList.add("list");   //add the class
            }
            
            document.getElementById("header_textid").style.display ="block";
        }    
    }

    showhidefiltermobileDiv()
    {
       if(document.getElementById("filtermobiledivid").style.display =="block")
       {
           document.getElementById("filtermobiledivid").style.display ="none";
           document.getElementById("filterclosebtn").textContent="Filter";
       }
       else
       {
          document.getElementById("filtermobiledivid").style.display ="block";
          document.getElementById("filterclosebtn").textContent= "Close";
       }
    }

    getLengthofTgName(tgname:string)
    {
        var str = new String(tgname);
        //console.log("str.length :"+str.length);
        return str.length>38;
    }

    returnZero() {
        return 0
    }

    displayareadiv(categorycode:string)
    {
        let categorykey:string = this.tgfilterdformbysearchcrieteria.get('categorykey').value;
        if(categorykey==='TG_TIER_A'||categorykey==='TG_TIER_GA')
        {
            console.log("categorycode :"+categorykey);
            document.getElementById("asdivid").style.display ="block";
        }
        else
        {
            console.log("categorycode :"+categorykey);
            document.getElementById("asdivid").style.display ="none";
        }
    }
}
