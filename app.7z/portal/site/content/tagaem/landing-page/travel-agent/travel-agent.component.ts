import { TravelAgentService } from './travel-agent.services';
import * as cnst from '../../../../../../common/constants';
import { Component, OnInit,ViewEncapsulation} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { TravelAgentItemDto} from '../../../../../../common/models/common';
import { ResultDto} from '../../../../../../common/models/common';
import { Observable,Subject } from "rxjs";
import { DomSanitizer } from '@angular/platform-browser';
import { FileUtil } from '../../../../../../common/helper';


@Component({
    selector: 'app-site',
    templateUrl: './travel-agent.component.html',
    styleUrls: ['./travel-agent.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class TravelAgentComponent implements OnInit {
    dashboardTypeCode: string;
    
    travelAgentServicesMap: Map<string,string>;
    travelAgentStatusMap: Map<string,string>;
    travelAgentLicensetypeMap: Map<string,string>;
    ResultDto: ResultDto<TravelAgentItemDto>;
    travelAgents: Observable<TravelAgentItemDto[]>;
       
    p: Number = 1;
    //count: Number = 15;
    count: Number ;
    
    startIndex:number =1;
    noOfItemsinaPage:number;
    //curentDisplayedPageNo1:number =1;
    //curentDisplayedPageNo2:number  =15;

    totalRecords:number[];
    searchType: string;

    //Filtered Crieteria Parameter
    taName: string;
    talicensetypekey: string;
    talicenceNo: string;
    tastatuskey: string;
    routedFromLandingPage:boolean;

    inputlicenseno:string ="";
    statuskeymodel:string ="ALL";
    languagekeymodel:string ="ALL";
    catogerykeymodel:string ="ALL";
    areakeymodel:string ="ALL";

    isCompleted: boolean = false;
    isMobileResolution: boolean = false;
    
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private travelAgentService: TravelAgentService,
        private _sanitizer: DomSanitizer,
        private fileUtil: FileUtil,
    ) {

        
    }

    ngOnInit() {

        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;

        this.travelAgentServicesMap = cnst.TravelAgentServices.taServicesMap;
        this.travelAgentStatusMap = cnst.TravelAgentLicenceStatuses.taLicenceStatusesMap;  
        this.travelAgentLicensetypeMap =cnst.TravelAgentLicenceTypes.taLicenceTypesMap;
        this.noOfItemsinaPage = cnst.PAGINATION.SIZE_OPTTIONS[2];

        console.log("window.innerWidth :"+window.innerWidth);
        // if (window.innerWidth < 768) {
        //     this.isMobileResolution = true;
        //     document.getElementById("mobiledivid").style.display ="block";
        //   } else {
        //     this.isMobileResolution = false;
        //     document.getElementById("mobiledivid").style.display ="none";
        //   }
        window.addEventListener('scroll', this.scroll, true);

        this.route.queryParams.subscribe(
            params => {
            this.taName= params['param1'];
            this.talicensetypekey= params['param2'];
            this.talicenceNo= params['param3'];
            this.tastatuskey= params['param4'];
            this.routedFromLandingPage = params['param5'];
            });
            console.log("this.taName :"+this.taName);
            console.log("this.Status :"+this.talicensetypekey);
            console.log("this.Language :"+this.talicenceNo);
            console.log("this.Area :"+this.tastatuskey);
            console.log("this.routedFromLandingPage :"+this.routedFromLandingPage);

            if(this.routedFromLandingPage===true)
            {
                this.filterdByLandingPageSearchparamfromSelectedIndex(this.taName,this.talicensetypekey,this.talicenceNo,this.tastatuskey,1);
            }
            else
            {
                this.licensedtgfromSelectedIndex(this.startIndex);
            }
    }
    scroll() {
        if (window.innerWidth < 769) {

            console.log("Scroll Function called");
            var el  = document.getElementById("page-title-id");
            var el1  = document.getElementById("section-banner");
            var el2  = document.getElementById("top-left-id1");
            console.log("window.pageYOffset :"+window.pageYOffset);
            console.log("el.offsetHeight :"+el.offsetHeight);
            console.log("el1.offsetHeight :"+el1.offsetHeight);
            console.log("el2.offsetHeight :"+el2.offsetHeight);

            if(window.pageYOffset >= el1.offsetHeight+el2.offsetHeight-el.offsetHeight)
            {
                document.getElementById("mobiledivid").style.display ="block"; 
                document.getElementById("top-left-id1").style.display ="none";
            }
            else
            {
                document.getElementById("mobiledivid").style.display ="none";
                document.getElementById("top-left-id1").style.display ="block";
            }
        }  
        else
        {
            document.getElementById("mobiledivid").style.display ="none";
        }         
    }
    getImagePath(extension:string, base64string:string)
    {
        //console.log("extension:"+extension+"base64string:"+base64string);
        let imagePath = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/'+extension+';base64,' 
                 +base64string);
        return imagePath;
    }

    // getcurentDisplayedPageNo1(){
    //    return this.curentDisplayedPageNo1;
    // }
    // getcurentDisplayedPageNo2(){
    //     if(this.totalRecords.length<15)
    //     {
    //         return this.totalRecords.length;
    //     }
    //     else
    //     {
    //         return this.curentDisplayedPageNo2;
    //     }
        
    //  }  
    
    pageChanged(pageno:number){
         
        pageno+=1;
        console.log("Selected pageno...."+pageno);
        if(pageno===1)
        {
            this.startIndex = pageno;
            //this.curentDisplayedPageNo2 = 15*pageno;
        }
        else
        {
            this.startIndex = this.noOfItemsinaPage*(pageno-1)+1;
            //this.curentDisplayedPageNo2 = 15*pageno;
        }
        this.loaddatafromselectedIndex(this.startIndex);
        this.changeDisplayView("cardview");
        // return pageno;
    }

    loaddatafromselectedIndex(startindex:number)
    {
        
        if(this.searchType==="FilterBySearchparam")
        {
            let serviceskeys: string='';
            let licensetypekey: string='';
            let statuskeys: string='';
           
            this.travelAgentServicesMap.forEach((value: string, key: string) => {
                // console.log(key, value);
                 const checkbox = document.getElementById(
                     key,
                   ) as HTMLInputElement | null;
                   
                   if (checkbox.checked) {
                     console.log('Checkbox is checked');
                     serviceskeys+=key+',';
                   } else {
                     console.log('Checkbox is NOT checked');
                   }
             });
     
             this.travelAgentLicensetypeMap.forEach((value: string, key: string) => {
                // console.log(key, value);
                 const radio = document.getElementById(
                     key,
                   ) as HTMLInputElement | null;
                   
                   if (radio.checked) {
                     console.log('Radio is checked');
                     licensetypekey+=key+',';
                   } else {
                     console.log('Radio is NOT checked');
                   }
             });
     
             this.travelAgentStatusMap.forEach((value: string, key: string) => {
                 //console.log(key, value);
                 const checkbox = document.getElementById(
                     key,
                   ) as HTMLInputElement | null;
                   
                   if (checkbox.checked) {
                     console.log('Checkbox is checked');
                     statuskeys+=key+',';
                   } else {
                     console.log('Checkbox is NOT checked');
                   }
             });
             if(serviceskeys.endsWith(','))
             {
                 serviceskeys = serviceskeys.substring(0,serviceskeys.length-1);
             }
             if(licensetypekey.endsWith(','))
             {
                 licensetypekey = licensetypekey.substring(0,licensetypekey.length-1);
             }
             if(statuskeys.endsWith(','))
             {
                 statuskeys = statuskeys.substring(0,statuskeys.length-1);
             }
     
             console.log("serviceskeys**********"+serviceskeys);
             console.log("licensetypekey**********"+licensetypekey);
             console.log("statuskeys**********"+statuskeys);
            this.filterdBySearchparamfromSelectedIndex(serviceskeys,licensetypekey,statuskeys,this.startIndex); 
        }
        else
        {
            if(this.searchType==="FilterByName")
            {
                let taName:string = this.tafilterdformbytaName.get('tgName').value; 
                console.log("taName**********"+taName);
                this.filterdByNameorLicenseNofromSelectedIndex(taName,this.startIndex);
            }
            else
            {
                this.licensedtgfromSelectedIndex(this.startIndex);         
            }
       }
    }

    filterdByLandingPageSearchparamfromSelectedIndex(param1:string,param2:string,param3:string,param4:string,startindex:number)
    {
        console.log("Going to Load Travel Agent Based on Landing Page Filtered Param and startIndex");
        
                this.travelAgentService.getTravelAgentbyFilteredCrieteriaofLandingPage(
                param1,param2,param3,param4,String(startindex)).subscribe(data =>{

                    this.ResultDto    =  data;
                    this.ResultDto.total = data.total;
                    this.travelAgents = this.ResultDto.records ; 
                    this.count = data.total;
                    //this.totalRecords = data.total;
                    // let i:number;
                    this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                    console.log("this.ResultDto.total"+data.total);
                    console.log("this.ResultDto.noOfPages"+data.noOfPages);
                
        });
    }

    filterdBySearchparamfromSelectedIndex(param1:string,param2:string,param3:string,startindex:number)
    {
        console.log("Going to Load Travel Agent Based on Filtered Param and startIndex");
        this.searchType ="FilterBySearchparam";
                this.travelAgentService.getTravelAgentbyFilteredCrieteria(
                param1,param2,param3,String(startindex)).subscribe(data =>{

                    this.ResultDto    =  data;
                    this.ResultDto.total = data.total;
                    this.travelAgents = this.ResultDto.records ; 
                    this.count = data.total;
                    //this.totalRecords = data.total;
                    // let i:number;
                    this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                    console.log("this.ResultDto.total"+data.total);
                    console.log("this.ResultDto.noOfPages"+data.noOfPages);
                
        });
    }

    filterdByNameorLicenseNofromSelectedIndex(name:string,startindex:number)
    {
        this.searchType ="FilterByName";
        console.log("Going to Load Travel Agent Based on Name or License No and startIndex");
        this.travelAgentService.getTravelAgentbyNameorLicenseNoCrieteria(name,String(startindex)).subscribe(data =>{
            
                this.ResultDto    =  data;
                this.ResultDto.total = data.total;
                this.travelAgents = this.ResultDto.records ; 
                this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
                this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                console.log("this.ResultDto.total"+data.total);
                console.log("this.ResultDto.noOfPages"+data.noOfPages);      
        });
    }

    licensedtgfromSelectedIndex(startindex:number)
    {
        console.log("Going to Load Licensed Travel Agent Based on startIndex");
            this.travelAgentService.getActiveTravelAgentList(String(this.startIndex)).subscribe(data =>{
                this.isCompleted = true;
                this.ResultDto    =  data;
                this.ResultDto.total = data.total;
                this.travelAgents = this.ResultDto.records ; 
                this.count = data.total;
                //this.totalRecords = data.total;
               // let i:number;
                this.totalRecords = Array(data.total).fill(data.total).map((x,i)=>i);
                //console.log("this.totalRecords:"+this.totalRecords);
                console.log("this.ResultDto.total"+data.total);
                console.log("this.ResultDto.noOfPages"+data.noOfPages);    
            }); 
    }
    

    tafilterdformbysearchcrieteria =new FormGroup({
        licenceNo:new FormControl(),
        statuskey:new FormControl(),
        languagekey:new FormControl(),
        categorykey:new FormControl(),
        areakey:new FormControl()
    });

      tafilterdformbytaName =new FormGroup({
        taName:new FormControl()
    });

    getFilteredtaByName(getFilteredtgByName){

        console.log("getFilteredtaByName(getFilteredtaByName)");
        let taName:string = this.tafilterdformbytaName.get('taName').value; 
        console.log("taName**********"+taName);
        this.filterdByNameorLicenseNofromSelectedIndex(taName,1);
        //this.changeDisplayView("cardview");
    }

    getFilteredtaBySearchCrieteria(getFilteredtaBySearchCrieteria){

        
        console.log("getFilteredtaBySearchCrieteria(getFilteredtaBySearchCrieteria)");
        let serviceskeys: string='';
        let licensetypekey: string='';
        let statuskeys: string='';


         this.travelAgentServicesMap.forEach((value: string, key: string) => {
           // console.log(key, value);
            const checkbox = document.getElementById(
                key,
              ) as HTMLInputElement | null;
              
              if (checkbox.checked) {
                console.log('Checkbox is checked');
                serviceskeys+=key+',';
              } else {
                console.log('Checkbox is NOT checked');
              }
        });

        this.travelAgentLicensetypeMap.forEach((value: string, key: string) => {
           // console.log(key, value);
            const radio = document.getElementById(
                key,
              ) as HTMLInputElement | null;
              
              if (radio.checked) {
                console.log('Radio is checked');
                licensetypekey+=key+',';
              } else {
                console.log('Radio is NOT checked');
              }
        });

        this.travelAgentStatusMap.forEach((value: string, key: string) => {
            //console.log(key, value);
            const checkbox = document.getElementById(
                key,
              ) as HTMLInputElement | null;
              
              if (checkbox.checked) {
                console.log('Checkbox is checked');
                statuskeys+=key+',';
              } else {
                console.log('Checkbox is NOT checked');
              }
        });
        if(serviceskeys.endsWith(','))
        {
            serviceskeys = serviceskeys.substring(0,serviceskeys.length-1);
        }
        if(licensetypekey.endsWith(','))
        {
            licensetypekey = licensetypekey.substring(0,licensetypekey.length-1);
        }
        if(statuskeys.endsWith(','))
        {
            statuskeys = statuskeys.substring(0,statuskeys.length-1);
        }

        console.log("serviceskeys**********"+serviceskeys);
        console.log("licensetypekey**********"+licensetypekey);
        console.log("statuskeys**********"+statuskeys);

        this.filterdBySearchparamfromSelectedIndex(serviceskeys,licensetypekey,statuskeys,this.startIndex); 
        //this.changeDisplayView("cardview");   
    }
    identify(index, item)
    {
        // console.log("index......."+index);
         
        //  return item.label;
    }

    resetDropdown()
    {  
        this.tafilterdformbysearchcrieteria.controls['licenceNo'].setValue("");
        this.tafilterdformbysearchcrieteria.controls['statuskey'].setValue("ALL");
        this.tafilterdformbysearchcrieteria.controls['languagekey'].setValue("ALL");
        this.tafilterdformbysearchcrieteria.controls['categorykey'].setValue("ALL");
    }

    changeDisplayView(viewtype:string)
    {
        if (viewtype==="cardview") 
        {
            for(let i=0;i<this.ResultDto.paginationBean.lastItem;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                console.log("parentDiv.classList:"+parentDiv.classList+" gridorlineviewdividi :"+"gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-12");
                gridviewdiv.classList.remove("list");   //remove the class 
                parentDiv.classList.add("col-sm-4");
                gridviewdiv.classList.add("grid");   //add the class
            }
            document.getElementById("header_textid").style.display ="none";
        }
        if (viewtype==="lineview") 
        {
            for(let i=0;i<this.ResultDto.paginationBean.lastItem;i++)
            {
                let gridviewdiv = document.getElementById("box-listid"+i);
                let  parentDiv = document.getElementById("gridorlineviewdivid"+i);
                console.log("parentDiv.classList:"+parentDiv.classList+" gridorlineviewdividi :"+"gridorlineviewdivid"+i);
                parentDiv.classList.remove("col-sm-4");
                gridviewdiv.classList.remove("grid");   //remove the class
                parentDiv.classList.add("col-sm-12");
                gridviewdiv.classList.add("list");   //add the class
            }
            
            document.getElementById("header_textid").style.display ="block";
        }    
    }

    showhidefiltermobileDiv()
    {
       if(document.getElementById("filtermobiledivid").style.display =="block")
       {
           document.getElementById("filtermobiledivid").style.display ="none";
           document.getElementById("filterclosebtn").textContent="Filter";
       }
       else
       {
          document.getElementById("filtermobiledivid").style.display ="block";
          document.getElementById("filterclosebtn").textContent= "Close";
       }
    }

    getLengthofTaName(taname:string)
    {
        var str = new String(taname);
        //console.log("str.length :"+str.length);
        return str.length>38;
    }

    returnZero() {
        return 0
    }

    exportExcel(){
        console.log("Going to export excel");
        this.travelAgentService.downloadExportedExcel().subscribe(data => {
            this.fileUtil.export(data, "ta_directory");
        });;
    }

}
