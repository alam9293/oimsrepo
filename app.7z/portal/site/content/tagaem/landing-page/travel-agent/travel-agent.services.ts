import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as cnst from '../../../../../../common/constants';

@Injectable({
  providedIn: 'root'
})

export class TravelAgentService {

  

  constructor(private http:HttpClient) { }

  getActiveTravelAgentList(curentDisplayedPageNo1:string): Observable<any> {
    const params = new HttpParams()
    .set('startIndex', curentDisplayedPageNo1);
    return this.http.get(`${cnst.apexBaseUrl}/directory/ta/getActivelicensedTravelAgent`,{params});
    
  }

  getTravelAgentbyFilteredCrieteria(
    services:string,licensetype:string,statuses:string,startindex:string): Observable<any> {
    const params = new HttpParams()
    .set('services', services)
    .set('licensetype', licensetype)
    .set('statuses', statuses)
    .set('startIndex', startindex);
    return this.http.get(`${cnst.apexBaseUrl}/directory/ta/tafilteredbylandingpagesearchparam`,{params}); 
  }

  getTravelAgentbyFilteredCrieteriaofLandingPage(
    taName:string,talicensetype:string,talicenceNo:string,tastatus:string,startindex:string): Observable<any> {
    const params = new HttpParams()
    .set('taName', taName)
    .set('talicensetype', talicensetype)
    .set('talicenceNo', talicenceNo)
    .set('tastatus', tastatus)
    .set('startIndex', startindex);
    return this.http.get(`${cnst.apexBaseUrl}/directory/ta/tafilteredbysearchparam`,{params}); 
  }

  getTravelAgentbyNameorLicenseNoCrieteria(
    paramstring:string,startindex:string): Observable<any> {
      const params = new HttpParams()
    .set('paramstring', paramstring)
    .set('startIndex', startindex);
      return this.http.get(`${cnst.apexBaseUrl}/directory/ta/filteredbyNameorlicenseno`,{params});
      
    }

    downloadExportedExcel(
      ): Observable<any> {
      //   const params = new HttpParams()
      // .set('paramstring', paramstring)
      // .set('startIndex', startindex);
        //return this.http.get(`${cnst.apexBaseUrl}/directory/ta/generate-excel`);
        return this.http.get<any>(cnst.apexBaseUrl + '/directory/ta/generate-excel/' , { responseType: 'blob' as 'json' });
        
      }

  
  
}                                           