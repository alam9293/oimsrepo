import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class TaAaService {

    constructor(private http: HttpClient) { }

    createTaLicenceAaApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_AA + '/new');
    }

    submit(application: any): Observable<any> {
        if (application.applicationId) {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_AA + '/update', application);
        } else {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_AA + '/save', application);
        }
    }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_AA + '/load/' + applicationId);
    }

}
