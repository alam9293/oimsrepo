import { Component, HostListener, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil, NumeralUtil } from '../../../common/helper';
import { AlertService, AuthenticationService, CommonService, ErrorDialogService } from '../../../common/services';
import { TaFormHelperUtil, ValidateDigitMaxLength } from '../ta-helper';
import { TaAaService } from './ta-aa-submission-service';

@Component({
    selector: 'app-ta-aa-submission',
    templateUrl: './ta-aa-submission.component.html',
    styleUrls: ['./ta-aa-submission.component.scss']
})
export class TaAaSubmissionComponent implements OnInit {

    constructor(
        private taFormHelperUtil: TaFormHelperUtil,
        private alertService: AlertService,
        private service: TaAaService,
        private fb: FormBuilder,
        private fileUtil: FileUtil,
        private formUtil: FormUtil,
        private route: ActivatedRoute,
        private router: Router,
        private commonService: CommonService,
        private authService: AuthenticationService,
        private errorDialogService: ErrorDialogService
    ) { }
    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    application: any = { applicationStatus: {}, licenceStatus: {} };
    cnst = cnst;
    checked: boolean = false;
    preview: boolean = false;
    prologue: boolean = false;
    selectedFile: File;
    form: FormGroup;
    fileForm: FormGroup;
    annualFilingDto: FormGroup;
    files: any;
    appId: number;
    isTaActive: boolean = true;
    errorMsg = {
        reason: cnst.Messages.MSG_INVALID_ACCESS,
        routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
    };

    ngOnInit() {
        this.initiateForm();
        this.isTaActive = this.authService.isTaActive();
        if (this.route.snapshot.paramMap.get('appId')) {
            this.appId = +this.route.snapshot.paramMap.get('appId');
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        } else {
            this.createTaLicence();
            if (!this.isTaActive) {
                setTimeout(() => this.errorDialogService.openDialog({
                    reason: cnst.Messages.MSG_INVALID_ACCESS,
                    routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
                }))
            }
        }
    }

    saveConfirmationDialog(isDraft: boolean) {
        this.form.patchValue({
            draft: isDraft
        });
        if (this.checked || this.form.get('draft').value) {
            this.service.submit(this.form.value).subscribe(data => {
                this.form.markAsPristine();
                this.alertService.clear();
                this.service.createTaLicenceAaApplication().subscribe(data => {
                    if (isDraft) {
                        this.preview = false;
                        this.application = data;
                        this.setupForm(this.application);
                        this.alertService.success(cnst.TaAlertMessages.APP_DRAFT_SAVED);
                    } else {
                        this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                    }
                });
            });
        } else {
            alert(cnst.Messages.MSG_DECLARATION_CHECK);
        }
    }

    // convenience getter for easy access to form fields
    get f() {
        return this.form.controls;
    }
    get fileForms() {
        return this.form.get('files') as FormArray
    }
    get annualFilingForm() {
        return this.form.get('annualFilingDto') as FormGroup
    }

    initiateForm() {
        this.annualFilingDto = this.fb.group({
            fyStartDate: ['',],
            fyEndDate: '',
            dueDate: ['',],
            annualFilingId: ['',],
            hasAaToSubmit: ['',],
            annualFilingFy: ['',],
        })

        this.form = this.fb.group({
            totalAssets: ['', [Validators.required, ValidateDigitMaxLength]],
            capital: ['', [Validators.required, ValidateDigitMaxLength]],
            totalLiabilities: ['', [Validators.required, ValidateDigitMaxLength]],
            aaSubmissionId: '',
            applicationId: '',
            draft: false,
            isEdit: false,
            annualFilingDto: this.annualFilingDto,
            files: this.fb.array([]),
            toDeleteFiles: this.fb.array([
                this.fb.control('')
            ]),
        });
    }


    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.application = data;
            this.setupForm(this.application);
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

    createTaLicence(): void {
        this.service.createTaLicenceAaApplication().subscribe(data => {
            this.application = data;
            if (data.hasAaToSubmit) {
                if (cnst.ApplicationStatuses.TA_APP_NEW === this.application.applicationStatus.key) {
                    this.prologue = true;
                } else {
                    this.setupForm(this.application);

                }
            }
        });

    }

    private setupForm(application: any) {
        this.initiateForm();
        this.form.patchValue(application);
        if (application.files) {
            application.files.forEach(item => {
                this.fileForm = this.fb.group({
                    id: [''],
                    publicFileId: [''],
                    originalName: ['', Validators.required],
                    processedName: [''],
                    docType: [''],
                    extension: [''],
                    path: [''],
                    size: [''],
                    hash: [''],
                    documentInstructions: [''],
                    documentTypeLabel: [''],
                    description: [''],
                    readableFileSize: [''],
                    hasTemplate: [],
                });
                this.fileForm.patchValue(item);
                this.fileForms.push(this.fileForm);
            });
        }

        if (application.draft) {
            this.form.markAsTouched();
            this.formUtil.markFormGroupTouched(this.form);
        }

    }

    onPicked(input: HTMLInputElement, docType: string, index) {
        this.selectedFile = input.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(docType, this.selectedFile).subscribe(data => {
                if (docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
                    this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, false);
                    this.fileForm.patchValue(data);
                    this.fileForms.push(this.fileForm);
                } else {
                    var file: any = data;
                    if (file.originalName) {
                        this.fileForms.at(index).patchValue(file);
                    } else {
                        this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
                    }
                }
            });
        }
    }

    toDeleteFile(file, index) {
        if (file.controls.originalName.value) {
            (this.form.get('toDeleteFiles') as FormArray).push(this.fb.control(file.controls.id.value));
        }
        if (file.value.docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
            this.fileForms.removeAt(index);
        } else {
            this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
        }
    }

    showPreview() {
        console.log(this.form);
        this.alertService.clear();
        if (this.form.valid) {
            this.preview = true
            window.scrollTo(0, 0);
            // this.summationValidator();
        } else {
            this.form.markAsTouched();
            this.formUtil.markFormGroupTouched(this.form);
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }

    loadForm() {
        this.prologue = false;
        this.setupForm(this.application);
    }

    summationValidator() {
        this.alertService.clear();
        let totalAssets = this.f.totalAssets.value;
        let totalEquity = this.f.totalEquity.value;
        let totalLiab = this.f.totalLiabilities.value;

        let currentAssets = this.f.currentAssets.value;
        let nonCurrentAssets = this.f.nonCurrentAssets.value;

        let nonCurrentLiab = this.f.nonCurrentLiabilities.value;
        let currentLiab = this.f.currentLiabilities.value;

        var message = "";

        if (NumeralUtil.parseNumeric(totalAssets) != NumeralUtil.addStrings([totalEquity, totalLiab])) {
            message += " Total Assets should be equal to Total Equity + Total Liabilities. <br> ";
            // this.alertService.warn(" Total Assets should be equals to Total equity + Total Liabilities. ");
        }
        if (NumeralUtil.parseNumeric(totalAssets) != NumeralUtil.addStrings([currentAssets, nonCurrentAssets])) {
            message += " Total Assets should be equal to Non-current Assets + Current Assets.  <br> ";
            //  this.alertService.warn(" Total Assets should be equals to Non-current Assets + Current Assets. ");
        }

        if (NumeralUtil.parseNumeric(totalLiab) != NumeralUtil.addStrings([nonCurrentLiab, currentLiab])) {
            message += " Total Liabilities should be equal to Non-current Liabilities + Current Liabilities.  <br> ";
            // this.alertService.warn(" Total Liabilities should be equals to Non-current Liabilities + Current Liabilities. ");
        }

        if (message.length > 0) {
            message = "Guidelines: <br> " + message;
            this.alertService.warn(message);
        }
    }

}




