import { Component, HostListener, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import * as numeral from 'numeral';
import { forkJoin, Observable } from 'rxjs';
import * as cnst from '../../../common/constants';
import { FormUtil } from '../../../common/helper';
import { InformationDialogComponent } from '../../../common/modules/information-dialog/information-dialog.component';
import { AlertService, AuthenticationService, CommonService, ErrorDialogService } from '../../../common/services';
import { TaAbprSubmissionService } from '../ta-abpr-submission/ta-abpr-submission.service';
import { TaFormHelperUtil, ValidateDigitMaxLength, ValidateIntegerMaxLength } from '../ta-helper';
import * as dto from './ta-abpr-submission-dto';


@Component({
    selector: 'app-ta-abpr-submission',
    templateUrl: './ta-abpr-submission.component.html',
    styleUrls: ['./ta-abpr-submission.component.scss']
})
export class TaAbprSubmissionComponent implements OnInit {

    constructor(
        private alertService: AlertService,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private formBuilder: FormBuilder,
        public formUtil: FormUtil,
        private router: Router,
        private route: ActivatedRoute,
        private service: TaAbprSubmissionService,
        private commonService: CommonService,
        private authService: AuthenticationService,
        private errorDialogService: ErrorDialogService,
        private taFormHelperUtil: TaFormHelperUtil,
    ) { }

    cnst = cnst;
    business_services: dto.ListableDto[];
    area_of_focus: dto.ListableDto[];
    nationalities: dto.ListableDto[];
    application: any = { applicationStatus: {}, licenceStatus: {}, taLicenceAnnualFilingDto: {} };
    defaultOptions: any[] = [{ key: '', label: '' }, { key: true, label: 'Yes' }, { key: false, label: 'No' }];
    form: FormGroup;
    nilSubmissionForm: FormGroup;
    inboundRows: FormArray;
    outboundRows: FormArray;
    businessRows: FormArray;
    annualBusinessProfileReturnRows: FormArray;
    focusRows: FormArray;
    functionRow: FormGroup;
    otherFocusRow: FormGroup;
    focusRow: FormGroup;
    businessRow: FormGroup;
    marketItem: FormGroup;

    prologue: boolean = false;
    isOnload: boolean = false;
    newApplication: boolean = true;
    viewApplication: boolean = true;
    preview: boolean = false;
    isTaActive: boolean = true;
    isNilSubmission: boolean = false;
    unionMap = new Map<string, string>();

    listableDto = new FormGroup({
        key: new FormControl(['', Validators.required]),
        label: new FormControl(),
        otherLabel: new FormControl()
    });

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        if (this.form && this.nilSubmissionForm) {
            return this.form.pristine && this.nilSubmissionForm.pristine;
        } else if (this.form) {
            return this.form.pristine
        } else if (this.nilSubmissionForm) {
            return this.nilSubmissionForm.pristine
        } else {
            return true;
        }


    }
    ngOnInit() {

        this.getCommonData();
        this.isTaActive = this.authService.isTaActive();
        if (this.route.snapshot.paramMap.get('appId') != null) {
            this.getApplication(this.route.snapshot.paramMap.get('appId'));
        } else {
            this.checkForAbprSubmission();
            if (!this.isTaActive) {
                setTimeout(() => this.errorDialogService.openDialog({
                    reason: cnst.Messages.MSG_INVALID_ACCESS,
                    routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
                }))
            }
        }
    }

    buildForm() {
        const taLicenceAnnualFilingDto = this.formBuilder.group({
            fyStartDate: [''],
            fyEndDate: [''],
            dueDate: [''],
            annualFilingId: [''],
            annualFilingFy: [''],
        });

        this.form = this.formBuilder.group({
            draft: false,
            applicationId: [''],
            abprSubmissionId: [''],
            applicationNo: [''],
            applicationStatus: this.listableDto,
            licenceStatus: this.listableDto,
            externalRemarks: [''],
            taLicenceAnnualFilingDto: taLicenceAnnualFilingDto,
            hasAbprToSubmit: [''],
            declared: [''],

            //ANNUAL BUSINESS PROFILE RETURNS
            businessRows: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.minLengthArray(1), this.taFormHelperUtil.duplicatedSelectionValidator('service')])),

            //TOTAL BUSINESS OPERATION (NON-EDITABLE)
            inboundBusinessTotalAmount: [0],
            outboundBusinessTotalAmount: [0],
            inboundBusinessPercentage: [0],
            outboundBusinessPercentage: [0],
            inboundOutboundBusinessTotalPercentage: [0],
            inboundOutboundBusinessTotalAmount: [0],

            //PASSENGER HANDLED
            inboundGrpPax: [0, [ValidateIntegerMaxLength]],
            inboundGrpPaxPercent: [0],
            outboundGrpPax: [0, [ValidateIntegerMaxLength]],
            outboundGrpPaxPercent: [0],
            inboundFitPax: [0, [ValidateIntegerMaxLength]],
            inboundFitPaxPercent: [0],
            outboundFitPax: [0, [ValidateIntegerMaxLength]],
            outboundFitPaxPercent: [0],

            //MARKET SPECIALISATION
            inboundRows: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.duplicatedSelectionValidator('country'),])),
            outboundRows: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.duplicatedSelectionValidator('country'),])),

            //AREA OF FOCUS   
            inboundOp: [''],
            inboundOpPercent: [''],//?
            outboundOp: [''],
            outboundOpPercent: [''],//?
            focusRows: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.minLengthArray(1), this.taFormHelperUtil.duplicatedSelectionValidator('focusArea')])),

            //OTHER AREA OF FOCUS
            otherFocusRows: this.formBuilder.array([]),

            //FUNCTIONS AND ACTIVITIES
            functionRows: this.formBuilder.array([]),

            // OTHER INFORMATION
            noOfEmployee: [0, [Validators.required, ValidateIntegerMaxLength]],
            operatingCost: [0, [Validators.required, ValidateDigitMaxLength]],
            depreciation: [0, [Validators.required, ValidateDigitMaxLength]],
            remuneration: [0, [Validators.required, ValidateDigitMaxLength]],
            indirectTax: [0, [Validators.required, ValidateDigitMaxLength]],
            hasOverseasBranch: ['', Validators.required],
        }, {
            validator: Validators.compose(
                [
                    this.taFormHelperUtil.zeroValuePercentageValidator("inboundBusinessPercentage", "inboundRows", "percentage", "inboundRowsNotZeroError"),
                    this.taFormHelperUtil.zeroValuePercentageValidator("outboundBusinessPercentage", "outboundRows", "percentage", "outboundRowsNotZeroError"),
                    this.taFormHelperUtil.hundredValuePercentageValidator("inboundBusinessPercentage", "inboundRows", "percentage", "inboundRowsNotHundredError"),
                    this.taFormHelperUtil.hundredValuePercentageValidator("outboundBusinessPercentage", "outboundRows", "percentage", "outboundRowsNotHundredError"),
                    this.inboundFitGrpRequiredValidator(),
                    this.outboundFitGrpRequiredValidator(),
                    this.taFormHelperUtil.matchingInboundOutboundCheckValidator("inboundBusinessTotalAmount", "focusRows", "hasInboundOp", "mismatchedInboundFocusPercentage", "mismatchedInboundFocusZero"),
                    this.taFormHelperUtil.matchingInboundOutboundCheckValidator("outboundBusinessTotalAmount", "focusRows", "hasOutboundOp", "mismatchedOutboundFocusPercentage", "mismatchedOutboundFocusZero"),
                    this.taFormHelperUtil.matchingInboundOutboundCheckValidator("inboundBusinessTotalAmount", "otherFocusRows", "hasInboundOp", "otherMismatchedInboundFocusPercentage", "otherMismatchedInboundFocusZero"),
                    this.taFormHelperUtil.matchingInboundOutboundCheckValidator("outboundBusinessTotalAmount", "otherFocusRows", "hasOutboundOp", "otherMismatchedOutboundFocusPercentage", "otherMismatchedOutboundFocusZero"),
                ]
            )
        }
        );
    }

    buildNilSubmissionForm() {
        const taLicenceAnnualFilingDto = this.formBuilder.group({
            fyStartDate: [''],
            fyEndDate: [''],
            dueDate: [''],
            annualFilingId: [''],
            annualFilingFy: [''],
        });

        this.nilSubmissionForm = this.formBuilder.group({
            draft: false,
            applicationId: [''],
            abprSubmissionId: [''],
            applicationNo: [''],
            applicationStatus: this.listableDto,
            licenceStatus: this.listableDto,
            externalRemarks: [''],
            taLicenceAnnualFilingDto: taLicenceAnnualFilingDto,
            hasAbprToSubmit: [''],
            declared: [''],

            // OTHER INFORMATION
            noOfEmployee: [0, [Validators.required, ValidateIntegerMaxLength]],
            operatingCost: [0, [Validators.required, ValidateDigitMaxLength]],
            depreciation: [0, [Validators.required, ValidateDigitMaxLength]],
            remuneration: [0, [Validators.required, ValidateDigitMaxLength]],
            indirectTax: [0, [Validators.required, ValidateDigitMaxLength]],
            hasOverseasBranch: ['', Validators.required],
        });
    }
    inboundFitGrpRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.form) {
                let obj = {};
                if (this.form.get('inboundBusinessTotalAmount').value && this.form.get('inboundBusinessTotalAmount').value != 0 && (!this.form.get('inboundGrpPax').value || this.form.get('inboundGrpPax').value == 0) && (!this.form.get('inboundFitPax').value || this.form.get('inboundFitPax').value == 0)) {
                    obj = { ...obj, inboundFitGrpRequired: true };
                }
                if ((!this.form.get('inboundBusinessTotalAmount').value || this.form.get('inboundBusinessTotalAmount').value == 0) && this.form.get('inboundFitPax').value && this.form.get('inboundFitPax').value != 0) {
                    obj = { ...obj, inboundFitNotRequired: true };
                }
                if ((!this.form.get('inboundBusinessTotalAmount').value || this.form.get('inboundBusinessTotalAmount').value == 0) && this.form.get('inboundGrpPax').value && this.form.get('inboundGrpPax').value != 0) {
                    obj = { ...obj, inboundGrpNotRequired: true };
                }
                return obj;
            } else {
                return null;
            }

        }
    }


    outboundFitGrpRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.form) {
                let obj = {};
                if (this.form.get('outboundBusinessTotalAmount').value && this.form.get('outboundBusinessTotalAmount').value != 0 && (!this.form.get('outboundGrpPax').value || this.form.get('outboundGrpPax').value == 0) && (!this.form.get('outboundFitPax').value || this.form.get('outboundFitPax').value == 0)) {
                    obj = { ...obj, outboundFitGrpRequired: true };
                }
                if ((!this.form.get('outboundBusinessTotalAmount').value || this.form.get('outboundBusinessTotalAmount').value == 0) && this.form.get('outboundFitPax').value && this.form.get('outboundFitPax').value != 0) {
                    obj = { ...obj, outboundFitNotRequired: true };
                }
                if ((!this.form.get('outboundBusinessTotalAmount').value || this.form.get('outboundBusinessTotalAmount').value == 0) && this.form.get('outboundGrpPax').value && this.form.get('outboundGrpPax').value != 0) {
                    obj = { ...obj, outboundGrpNotRequired: true };
                }
                return obj;
            } else {
                return null;
            }

        }
    }


    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.setupAbprSubmissionApplication(data);
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }
    checkForAbprSubmission() {
        this.service.checkForAbprSubmission().subscribe(data => {
            this.setupAbprSubmissionApplication(data);
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        });
    }
    setupAbprSubmissionApplication(data: any) {
        this.application = data;
        if (this.application.isNilSubmission) {
            this.isNilSubmission = true;
            this.buildNilSubmissionForm();
            this.nilSubmissionForm.patchValue(this.application);
        } else {
            this.buildForm();
            this.setupForm(this.application);
            if (this.application.inboundOpPercent > 0) {
                this.form.get('inboundBusinessPercentage').patchValue(this.form.get('inboundOpPercent').value);
            }
            if (this.application.outboundOpPercent > 0) {
                this.form.get('outboundBusinessPercentage').patchValue(this.form.get('outboundOpPercent').value);
            }
            this.form.get('inboundOutboundBusinessTotalPercentage').setValue(this.form.get('inboundBusinessPercentage').value + this.form.get('outboundBusinessPercentage').value);
            this.formControlValueChanged();
        }

        if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_NEW) {
            this.prologue = true;
        }
        if (this.application.applicationStatus != null && (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA || this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_DRAFT)) {
            this.preview = false;
            this.newApplication = false;
            this.viewApplication = false;

        } else if (this.application.applicationStatus == null || this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_NEW) {
            this.newApplication = true;
            this.viewApplication = false;
            this.preview = false;
        }
        else if (this.application.applicationStatus != null && (this.application.applicationStatus.key != cnst.ApplicationStatuses.TA_APP_NEW && this.application.applicationStatus.key != cnst.ApplicationStatuses.TA_APP_RFA && this.application.applicationStatus.key != cnst.ApplicationStatuses.TA_APP_DRAFT)) {
            this.viewApplication = true;
            this.newApplication = false;
            this.preview = true;
        }
        else {
            this.preview = false;
            this.newApplication = false;
            this.viewApplication = false;
        }

        this.isOnload = true;
    }
    setupForm(application: any) {
        this.form.patchValue(application);
        if (this.application.inboundRows)
            this.application.inboundRows.forEach(item => {
                this.marketItem = this.initMarketItemRows();
                this.marketItem.patchValue(item);
                this.inboundForms.push(this.marketItem);
            });
        if (this.application.outboundRows)
            this.application.outboundRows.forEach(item => {
                this.marketItem = this.initMarketItemRows();
                this.marketItem.patchValue(item);
                this.outboundForms.push(this.marketItem);
            });
        if (this.application.businessRows)
            this.application.businessRows.forEach(item => {
                this.businessRow = this.initBusinessItemRows();
                this.businessRow.patchValue(item);
                this.businessForms.push(this.businessRow);
            });

        if (this.application.focusRows)
            this.application.focusRows.forEach(item => {
                this.focusRow = this.initFocusItemRows();
                this.focusRow.patchValue(item);
                this.focusForms.push(this.focusRow);
            });
        if (this.application.otherFocusRows)
            this.application.otherFocusRows.forEach(item => {
                this.otherFocusRow = this.initOtherFocusItemRows();
                this.otherFocusRow.patchValue(item);
                this.otherFocusForms.push(this.otherFocusRow);
            });
        if (this.application.functionRows) {
            this.application.functionRows.forEach(item => {
                this.functionRow = this.initFunctionItemRows();
                this.functionRow.patchValue(item);
                this.functionForms.push(this.functionRow);
            });
        }
    }

    passengerHandled(groupPax: string, groupPercent: string, fitPax: string, fitPercent: string) {
        let boundGrpPax: number = 0;
        let boundFitPax: number = 0;
        boundGrpPax = numeral(this.form.get(groupPax).value).value() ? numeral(this.form.get(groupPax).value).value() : 0;
        boundFitPax = numeral(this.form.get(fitPax).value).value() ? numeral(this.form.get(fitPax).value).value() : 0;

        let boundGrpPaxPercent = parseFloat((boundGrpPax / (boundGrpPax + boundFitPax)).toFixed(3)) * 100;
        let boundFitPaxPercent = parseFloat((boundFitPax / (boundGrpPax + boundFitPax)).toFixed(3)) * 100;

        this.form.get(groupPercent).patchValue(boundGrpPaxPercent ? boundGrpPaxPercent.toFixed(2) : 0);
        this.form.get(fitPercent).patchValue(boundFitPaxPercent ? boundFitPaxPercent.toFixed(2) : 0);
    }
    formControlValueChanged() {
        this.form.get('inboundBusinessTotalAmount').valueChanges.subscribe(
            (data: any) => {
                this.functionForms.controls.forEach(element => {
                    this.formUtil.validateAllFormControl(element as FormGroup);
                });
            });
        this.form.get('outboundBusinessTotalAmount').valueChanges.subscribe(
            (data: any) => {
                this.functionForms.controls.forEach(element => {
                    this.formUtil.validateAllFormControl(element as FormGroup);
                });
            });
        this.form.get('outboundFitPax').valueChanges.subscribe(
            (data: any) => {
                this.passengerHandled('outboundGrpPax', 'outboundGrpPaxPercent', 'outboundFitPax', 'outboundFitPaxPercent');
            });
        this.form.get('outboundGrpPax').valueChanges.subscribe(
            (data: any) => {
                this.passengerHandled('outboundGrpPax', 'outboundGrpPaxPercent', 'outboundFitPax', 'outboundFitPaxPercent');
            });
        this.form.get('inboundFitPax').valueChanges.subscribe(
            (data: any) => {
                this.passengerHandled('inboundGrpPax', 'inboundGrpPaxPercent', 'inboundFitPax', 'inboundFitPaxPercent');
            });
        this.form.get('inboundGrpPax').valueChanges.subscribe(
            (data: any) => {
                this.passengerHandled('inboundGrpPax', 'inboundGrpPaxPercent', 'inboundFitPax', 'inboundFitPaxPercent');
            });
        this.form.get('businessRows').valueChanges.subscribe(
            (data: any) => {
                if (data.length > 0) {
                    let inbound: number = 0;
                    let outbound: number = 0;
                    let total: number = 0;
                    data.forEach(element => {
                        inbound = inbound + Number((element.inbound.toString()).replace(/,/g, ''));
                        outbound = outbound + Number((element.outbound.toString()).replace(/,/g, ''));

                    });

                    total = inbound + outbound;

                    this.form.get('inboundBusinessTotalAmount').patchValue(inbound);
                    this.form.get('outboundBusinessTotalAmount').patchValue(outbound);
                    this.form.get('inboundOutboundBusinessTotalAmount').patchValue(total);

                    let inboundBusinessPercentage = 0;
                    let outboundBusinessPercentage = 0;
                    if (inbound > 0 || outbound > 0) {
                        inboundBusinessPercentage = inbound / (inbound + outbound) * 100;
                        outboundBusinessPercentage = outbound / (inbound + outbound) * 100;
                    }
                    this.form.get('inboundBusinessPercentage').patchValue(inboundBusinessPercentage.toFixed(2));
                    this.form.get('outboundBusinessPercentage').patchValue(outboundBusinessPercentage.toFixed(2));
                    this.form.get('inboundOutboundBusinessTotalPercentage').patchValue((inboundBusinessPercentage + outboundBusinessPercentage).toFixed(2));
                }
            });
    }

    get inboundForms() {
        return this.form.get('inboundRows') as FormArray
    }
    get outboundForms() {
        return this.form.get('outboundRows') as FormArray
    }
    get businessForms() {
        return this.form.get('businessRows') as FormArray
    }
    get focusForms() {
        return this.form.get('focusRows') as FormArray
    }
    get otherFocusForms() {
        return this.form.get('otherFocusRows') as FormArray
    }
    get functionForms() {
        return this.form.get('functionRows') as FormArray
    }
    get formControl() {
        return this.form.controls
    }

    getCommonData() {
        forkJoin([
            this.commonService.getTaFocusAreas(),
            this.commonService.getTaServices(),
            this.commonService.getCountries(),
        ]).subscribe(data => {
            this.area_of_focus = data[0].filter(function (type) {
                return type.key != "TA_AREA_O";
            });
            this.business_services = data[1];
            this.nationalities = data[2];
        });
    }

    initMarketItemRows() {
        return this.formBuilder.group({
            country: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['',]
            }),
            percentage: [0, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
        });
    }

    initBusinessItemRows() {
        return this.formBuilder.group({
            service: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['',]
            }),
            inbound: [0, Validators.compose([Validators.required, ValidateDigitMaxLength])],
            outbound: [0, Validators.compose([Validators.required, ValidateDigitMaxLength])],
            isInboundOwned: ['',],
            isOutboundOwned: [''],
        },
            {
                validator: Validators.compose([
                    this.taFormHelperUtil.bothZeroValuesValidator('inbound', 'outbound', 'zeroValues'),
                    this.taFormHelperUtil.missingSelectionValidator("inbound", "isInboundOwned"),
                    this.taFormHelperUtil.missingSelectionValidator("outbound", "isOutboundOwned"),
                ]
                )
            }
        )
    };

    initFunctionItemRows() {
        return this.formBuilder.group({
            id: '',
            question: this.formBuilder.group({
                key: ['',],
                label: ['',]
            }),
            isInbound: ['', Validators.compose([this.taFormHelperUtil.selectionCrossValueValidator(this.form.controls.inboundBusinessTotalAmount),])],
            isOutbound: ['', Validators.compose([this.taFormHelperUtil.selectionCrossValueValidator(this.form.controls.outboundBusinessTotalAmount),])],
        },
            {
                validator: Validators.compose(
                    [
                    ]
                )
            }
        );
    }
    initOtherFocusItemRows() {
        return this.formBuilder.group({
            otherFocusArea: ['', Validators.required],
            hasInboundOp: [false,],
            hasOutboundOp: [false,],
            bothInOutNull: [],
            hasOp: [],
            remarks: [''],
        }, {
            validator: this.taFormHelperUtil.matchingMissingBothCheckBoxValidator(this.form.controls.inboundBusinessTotalAmount, this.form.controls.inboundBusinessTotalAmount, "hasInboundOp", "hasOutboundOp", "mismatchedMissingBothCheckbox"),

        }
        );
    }

    initFocusItemRows() {
        return this.formBuilder.group({
            focusArea: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['',]
            }),
            hasInboundOp: [false,],
            hasOutboundOp: [false,],
            bothInOutNull: [],
            hasOp: [],
            remarks: [''],
        }, {
            validator: this.taFormHelperUtil.matchingMissingBothCheckBoxValidator(this.form.controls.inboundBusinessTotalAmount, this.form.controls.outboundBusinessTotalAmount, "hasInboundOp", "hasOutboundOp", "mismatchedMissingBothCheckbox"),

        }
        );
    }


    deleteRow(i: number, form: FormArray) {
        form.removeAt(i);
    }

    addBusinessOperation() {
        this.businessForms.push(this.initBusinessItemRows());
    }

    addAreaOfFocus() {
        this.focusForms.push(this.initFocusItemRows());
    }

    addOtherAreaOfFocus() {
        this.otherFocusForms.push(this.initOtherFocusItemRows());
    }

    addRow(form: FormArray) {
        form.push(this.initMarketItemRows());
    }

    openInformationDialog(msg) {
        this.dialog.open(InformationDialogComponent, { data: { content: msg } })

    }
    openInformationDialogForFunctionsAndActivity(code) {
        var msg;
        if (code == 'TA_FUNC_ACT_1') {
            msg = cnst.TaAbprTooltip.TA_FUNC_ACT_1;
        } else if (code == 'TA_FUNC_ACT_2') {
            msg = cnst.TaAbprTooltip.TA_FUNC_ACT_2;
        } else if (code == 'TA_FUNC_ACT_3') {
            msg = cnst.TaAbprTooltip.TA_FUNC_ACT_3;
        }
        this.dialog.open(InformationDialogComponent, { data: { content: msg } })

    }

    onSubmit() {
        this.formUtil.validateAllFormControl(this.form);
        this.formUtil.markFormGroupTouched(this.form);
        console.log(this.form);
        this.alertService.clear();
        window.scrollTo(0, 0);
        if (this.form.valid) {
            this.form.get('inboundOp').patchValue(this.form.get('inboundBusinessTotalAmount').value);
            this.form.get('outboundOp').patchValue(this.form.get('outboundBusinessTotalAmount').value);
            this.form.get('inboundOpPercent').patchValue(this.form.get('inboundBusinessPercentage').value);
            this.form.get('outboundOpPercent').patchValue(this.form.get('outboundBusinessPercentage').value);
            this.preview = true;
            this.application = this.form.value;
        }
        else {
            this.form.markAsTouched();
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }
    onPreviewNilSubmission() {
        this.formUtil.validateAllFormControl(this.nilSubmissionForm);
        this.formUtil.markFormGroupTouched(this.nilSubmissionForm);
        this.alertService.clear();
        window.scrollTo(0, 0);
        if (this.nilSubmissionForm.valid) {
            this.preview = true;
        }
        else {
            this.nilSubmissionForm.markAsTouched();
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }

    getFormValidationErrors() {
        Object.keys(this.form.controls).forEach(key => {
            const controlErrors: ValidationErrors = this.form.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }

    loadForm() {
        this.prologue = false;
    }
    toggleNilSubmission(isNilSubmission) {
        this.isNilSubmission = isNilSubmission;
        if (this.isNilSubmission) {
            if (!this.nilSubmissionForm) {
                this.buildNilSubmissionForm();
                this.nilSubmissionForm.patchValue(this.application);
            }
            this.nilSubmissionForm.get('noOfEmployee').setValue(this.form.get('noOfEmployee').value);
            this.nilSubmissionForm.get('operatingCost').setValue(this.form.get('operatingCost').value);
            this.nilSubmissionForm.get('depreciation').setValue(this.form.get('depreciation').value);
            this.nilSubmissionForm.get('remuneration').setValue(this.form.get('remuneration').value);
            this.nilSubmissionForm.get('indirectTax').setValue(this.form.get('indirectTax').value);
            this.nilSubmissionForm.get('hasOverseasBranch').setValue(this.form.get('hasOverseasBranch').value);
        } else {
            if (!this.form) {
                this.buildForm();
                this.setupForm(this.application);
                if (this.application.inboundOpPercent > 0) {
                    this.form.get('inboundBusinessPercentage').patchValue(this.form.get('inboundOpPercent').value);
                }
                if (this.application.outboundOpPercent > 0) {
                    this.form.get('outboundBusinessPercentage').patchValue(this.form.get('outboundOpPercent').value);
                }
                this.form.get('inboundOutboundBusinessTotalPercentage').setValue(this.form.get('inboundBusinessPercentage').value + this.form.get('outboundBusinessPercentage').value);
                this.formControlValueChanged();
            }
            this.form.get('noOfEmployee').setValue(this.nilSubmissionForm.get('noOfEmployee').value);
            this.form.get('operatingCost').setValue(this.nilSubmissionForm.get('operatingCost').value);
            this.form.get('depreciation').setValue(this.nilSubmissionForm.get('depreciation').value);
            this.form.get('remuneration').setValue(this.nilSubmissionForm.get('remuneration').value);
            this.form.get('indirectTax').setValue(this.nilSubmissionForm.get('indirectTax').value);
            this.form.get('hasOverseasBranch').setValue(this.nilSubmissionForm.get('hasOverseasBranch').value);
        }
    }
    cancelDialog() {
        this.preview = false;
    }

    saveConfirmationDialog(status: string) {
        if (cnst.ApplicationStatuses.TA_APP_DRAFT === status) {
            this.form.patchValue({
                draft: true
            });
        } else {
            this.form.patchValue({
                draft: false
            });
        }
        this.form.get('inboundOp').patchValue(this.form.get('inboundBusinessTotalAmount').value);
        this.form.get('outboundOp').patchValue(this.form.get('outboundBusinessTotalAmount').value);
        this.form.get('inboundOpPercent').patchValue(this.form.get('inboundBusinessPercentage').value);
        this.form.get('outboundOpPercent').patchValue(this.form.get('outboundBusinessPercentage').value);
        if (this.form.value.draft || this.form.value.declared) {
            this.service.save(this.form.value).subscribe(data => {
                this.form.markAsPristine();
                this.alertService.clear();
                this.service.checkForAbprSubmission().subscribe(data => {
                    if (cnst.ApplicationStatuses.TA_APP_DRAFT === status) {
                        this.setupAbprSubmissionApplication(data);
                        this.alertService.success(cnst.TaAlertMessages.APP_DRAFT_SAVED);
                    }
                    else {
                        this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { 'applicationNo': data.applicationNo } });
                    }

                }, error => {
                    this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
                });

            }, error => {
                // this.snackBar.openFromComponent(SuccessSnackbarComponent, {
                //     duration: 5000,
                //     data: { message: 'Error' }
                // });
            });
        } else {
            alert(cnst.Messages.MSG_DECLARATION_CHECK)
        }
    }
    saveNilSubmission() {
        if (this.nilSubmissionForm.value.declared) {
            this.service.saveNilSubmission(
                this.nilSubmissionForm.value).subscribe(data => {
                    this.nilSubmissionForm.markAsPristine();
                    this.alertService.clear();
                    this.service.checkForAbprSubmission().subscribe(data => {
                        this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { 'applicationNo': data.applicationNo } });
                    }, error => {
                        this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
                    });

                });
        } else {
            alert(cnst.Messages.MSG_DECLARATION_CHECK)
        }
    }
}


