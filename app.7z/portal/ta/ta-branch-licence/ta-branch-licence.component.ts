import { Component, OnInit, ViewChild, Inject, HostListener } from '@angular/core';
import { MatSort, MatTableDataSource, MatDialogRef, MatDialog, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import * as dto from './ta-branch-licence.component-dto';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { SuccessSnackbarComponent } from '../../../common/modules/success-snackbar/success-snackbar.component';
import * as _ from "lodash";
import { TaBranchService } from '../ta-branch-licence/ta-branch-licence.service';
import { CommonService, AuthenticationService } from '../../../common/services';
import { ActivatedRoute, Router } from '@angular/router';
import * as cnst from '../../../common/constants';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PaymentDialogComponent } from '../../../common/modules/payment-dialog/payment-dialog.component';
import { PaymentService } from '../../payment/payment.service';
import { DialogTaCeasedBranches, DialogTaManageBranch } from './ta-manage-branch.component';

@Component({
    selector: 'app-ta-branch-licence',
    templateUrl: './ta-branch-licence.component.html',
    styleUrls: ['./ta-branch-licence.component.scss']
})
export class TaBranchLicenceComponent implements OnInit {
    _ = _;
    checked: boolean = false;
    newApplication: boolean = true;
    application: any = { applicationStatus: {}, licenceStatus: {}, taLicenceAnnualFilingDto: {} };
    preview = false;
    @ViewChild(MatSort) sort: MatSort;
    active = [];
    //  activeDataSource = new MatTableDataSource(this.active);
    //  activeDisplayedColumns = ['no', 'address', 'status'];
    ceased = []
    applications = [];
    fileName: string;
    licenceNo: number;
    applicationsbyId = [];
    // applicationDataSource = new MatTableDataSource(this.applications);
    applicationByIdDataSource = new MatTableDataSource(this.applicationsbyId);
    submittedRecords = [];
    //submittedDataSource = new MatTableDataSource(this.submittedRecords);
    //submittedDisplayedColumns = ['no', 'address', 'status'];
    amountPayable: number = 0;
    submitted: boolean = false;
    //selectedFile: File;
    cnst = cnst;
    lcnst = dto;
    //past = [];
    isAppId: boolean = false;
    premises_types: any = [];
    form: FormGroup;
    isTaActive: boolean = true;
    chosenItemList = [];
    isPreviewPayment: boolean = false;
    isEdited: boolean = false;
    editApplication = [];
    returnAppCode: string;

    buildForm() {
        this.form = this.formBuilder.group({
            application: ['', Validators.required],
            declared: [''],
        }, {
        }

        );
    }
    constructor(
        private formBuilder: FormBuilder,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private router: Router,
        private route: ActivatedRoute,
        private service: TaBranchService,
        private commonService: CommonService,
        private authService: AuthenticationService,
        private paymentService: PaymentService,

    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    ngOnInit() {
        this.buildForm();
        this.returnAppCode = this.route.snapshot.queryParams.returnApp;
        this.isTaActive = this.authService.isTaActive();
        if (this.route.snapshot.paramMap.get('appId') != null) {
            this.getApplication(this.route.snapshot.paramMap.get('appId'));
        }
        else {
            this.checkForBranchApplication();
        }
        //     this.activeDataSource.sort = this.sort;
        this.getPremiseTypes();
    }

    formControlValueChanged() {
        this.form.get('application').valueChanges.subscribe(
            (modal: any) => {
                if (this.applications.length == 0) {
                    Object.keys(this.form.controls).forEach(key => {
                        this.form.get(key).markAsPristine();
                    });
                }
                else {
                    Object.keys(this.form.controls).forEach(key => {
                        this.form.get(key).markAsDirty();
                    });
                }
            });
    }

    getPremiseTypes() {
        this.commonService.getPremiseTypes().subscribe(data => {
            this.premises_types = data;
        });
    }
    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            console.log("Start - data");
            console.log(data);
            console.log("End - data");
            if (
                (data.applicationStatus != null && data.paymentStatus != null && data.isConcluded == null) ||
                (data.applicationStatus != null && (data.applicationStatus.key != cnst.ApplicationStatuses.TA_APP_APPROVED && data.applicationStatus.key != cnst.ApplicationStatuses.TA_APP_REJECTED))
            ) {
                this.checkForBranchApplication();
            }
            else {
                console.log(data);
                this.amountPayable = 0;
                if (data.taBranchApplicationDtoList.length > 0) {
                    this.applicationsbyId = data;
                    data.taBranchApplicationDtoList.forEach(element => {
                        if (element.type == this.lcnst.LocalConstants.BRANCH_NEW) {
                            element.fee = this.lcnst.LocalConstants.taBranchApplicationFeeLabel;
                            this.amountPayable = this.amountPayable + this.lcnst.LocalConstants.taBranchApplicationFeeNumber;
                        }
                    });
                }
                console.log(data.taBranchApplicationDtoList);
                this.isAppId = true;
                this.applicationByIdDataSource = new MatTableDataSource(data.taBranchApplicationDtoList);
                this.newApplication = false;
            }
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }
    checkForBranchApplication() {
        this.service.checkForBranchApplication().subscribe(data => {
            console.log(data);
            this.application = data;
            if (this.application.applicationStatus != null && this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                this.amountPayable = 0;
                data.taBranchApplicationDtoList.forEach(element => {
                    if (element.status == 'TA_BRANCH_A' || element.status == 'TA_BRANCH_M_PENDING_RENEWAL') {
                        element.status = element.statusLabel;
                        this.active.push(element);
                    } else if (element.status == 'TA_BRANCH_PA' || element.status == 'TA_BRANCH_PU' || element.status == 'TA_BRANCH_PC' || element.status == cnst.ApplicationStatuses.TA_APP_RFA) {
                        element.status = element.statusLabel;
                        if (element.type == this.lcnst.LocalConstants.BRANCH_NEW) {
                            element.fee = this.lcnst.LocalConstants.taBranchApplicationFeeLabel;
                        }
                        this.applications.push(element);
                        this.calculateAmountPayable();
                        this.submitted = false;
                        this.newApplication = false;
                    } else if (element.status == 'TA_BRANCH_C' || element.status == 'TA_BRANCH_M_C' || element.status == 'TA_BRANCH_M_R' || element.status == 'TA_BRANCH_M_S' || element.status == 'TA_BRANCH_M_L') {
                        this.ceased.push({ 'address': element.formatAddress, 'ceasedDate': element.ceasedDate });
                    }
                });
            } else {
                this.amountPayable = 0;
                data.taBranchApplicationDtoList.forEach(element => {
                    if (element.status == 'TA_BRANCH_A' || element.status == 'TA_BRANCH_M_PENDING_RENEWAL') {
                        element.status = element.statusLabel;
                        this.active.push(element);
                    } else if (element.status == 'TA_BRANCH_PA' || element.status == 'TA_BRANCH_PU' || element.status == 'TA_BRANCH_PC' || element.status == cnst.ApplicationStatuses.TA_APP_RFA) {
                        element.status = 'Processing (' + element.type + ')';
                        if (element.type == this.lcnst.LocalConstants.BRANCH_NEW) {
                            element.fee = this.lcnst.LocalConstants.taBranchApplicationFeeLabel;
                            this.amountPayable = this.amountPayable + this.lcnst.LocalConstants.taBranchApplicationFeeNumber;
                        }
                        this.submittedRecords.push(element);
                        this.submitted = true;
                        this.newApplication = false;
                    } else if (element.status == 'TA_BRANCH_C' || element.status == 'TA_BRANCH_M_C' || element.status == 'TA_BRANCH_M_R' || element.status == 'TA_BRANCH_M_S' || element.status == 'TA_BRANCH_M_L') {
                        this.ceased.push({ 'address': element.formatAddress, 'ceasedDate': element.ceasedDate });
                    } else {
                        this.applications.push(element);
                        this.submitted == true
                    }
                    if (this.application.applicationId != null) {
                        this.submitted = true;
                    }
                });
            }
        });
    }

    previewPayment() {
        this.chosenItemList = [];
        this.isPreviewPayment = true;
        this.chosenItemList.push(this.application.paymentRequestDto);
    }
    cancelPreviewPayment() {
        this.isPreviewPayment = false;
    }
    makePayment() {
        let billRefNos = [];
        billRefNos.push(this.application.billRefNo);
        let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.amountPayable } });
        dialog.afterClosed().subscribe(result => {
            if (result.decision) {
                let paymentType = result.type;
                if (paymentType == cnst.PaymentTypes.PAYNOW) {
                    this.paymentService.createPayNowTxn(this.amountPayable, billRefNos).subscribe(txn => {
                        let payNowTxnId = txn;
                        this.paymentService.generateQrCode(this.amountPayable, txn).subscribe(qrCode => {
                            let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.amountPayable, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNos } });
                            dialog.afterClosed().subscribe(result => {
                                /*
                                if (result.decision) {
                                    this.paymentService.routeToPaymentSuccessPage(true, cnst.eNets.URL_TA_RETURN, paymentType, billRefNos, cnst.TaApplicationUrl.TA_APP_BRANCH, payNowTxnId);
                                }
                                */
                                this.paymentService.routeToPaymentSuccessPage(true, cnst.eNets.URL_TA_RETURN, paymentType, billRefNos, cnst.TaApplicationUrl.TA_APP_BRANCH, payNowTxnId);
                            });
                        });
                    });
                } else {
                    this.paymentService.initPaymentProcess(true, cnst.eNets.URL_TA_RETURN, paymentType, billRefNos, cnst.TaApplicationUrl.TA_APP_BRANCH);
                }
            }
        });
    }
    delete(object): void {
        var index = this.applications.indexOf(object);
        this.applications.splice(index, 1);
        this.calculateAmountPayable();

        //    this.applicationDataSource = new MatTableDataSource(this.applications);
        this.form.controls['application'].setValue(this.applications);
    }
    undo(object): void {
        var index = this.applications.indexOf(object);
        this.applications.splice(index, 1);
        //  this.applicationDataSource = new MatTableDataSource(this.applications);
        this.form.controls['application'].setValue(this.applications);
        if (object.type == this.lcnst.LocalConstants.BRANCH_UPDATE) {
            object.toReplace.status = "Active";
        }

        if (object.type == this.lcnst.LocalConstants.BRANCH_CESSATION) {
            object.status = "Active";
            this.active.push(object);
        } else {
            this.active.push(object.toReplace);
        }
        //   this.activeDataSource = new MatTableDataSource(this.active);
    }
    calculateAmountPayable(): void {
        this.amountPayable = 0;
        this.applications.forEach(element => {
            if (element.type == this.lcnst.LocalConstants.BRANCH_NEW) {
                this.amountPayable = this.amountPayable + this.lcnst.LocalConstants.taBranchApplicationFeeNumber;
            }
        });
    }

    changeToUpdate() {
        var groupedApplication = _.groupBy(this.applications, 'type');
        var newCount = groupedApplication.New.length;
        var ceaseCount = groupedApplication.Cessation.length;
        var countToChange = 0;
        if (newCount == 0 || ceaseCount == 0) {
            return;
        }
        if (newCount > ceaseCount) {
            countToChange = ceaseCount;
        } else {
            countToChange = newCount;
        }

        for (var i = 0; i < countToChange; i++) {
            var index = this.applications.indexOf(groupedApplication.New[i]);
            this.applications[index].type = this.lcnst.LocalConstants.BRANCH_UPDATE;
            this.applications[index].fee = null;
            this.applications[index].toReplace = groupedApplication.Cessation[i];
            this.applications.splice(this.applications.indexOf(groupedApplication.Cessation[i]), 1);
        }
        this.calculateAmountPayable();
        //    this.applicationDataSource = new MatTableDataSource(this.applications);
        this.form.controls['application'].setValue(this.applications);
    }
    openCeasedDialog() {
        this.dialog.open(DialogTaCeasedBranches, {
            data: this.ceased,
            width: '80vw',
            disableClose: true
        });
    }


    openManageEditDialog(object): void {
        this.isEdited = true;
        this.editApplication = object;
        this.openManageDialog();
    }
    openManageNewDialog() {
        this.isEdited = false;
        this.editApplication = null;
        this.openManageDialog();

    }
    openManageDialog() {
        let ref = this.dialog.open(DialogTaManageBranch, {
            data: { applications: this.applications, active: this.active, edit: this.editApplication, premises_types: this.premises_types, isEdited: this.isEdited },
            width: '80vw',
            disableClose: true
        });
        ref.afterClosed().subscribe(data => {
            if (data) {
                this.applications = data.applications;
                this.active = data.active;

            }
            //       this.applicationDataSource = new MatTableDataSource(this.applications);
            this.form.controls['application'].setValue(this.applications);
            //  this.activeDataSource = new MatTableDataSource(this.active);
            this.calculateAmountPayable();

        });
    }
    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog() {

        if (this.form.value.declared) {
            this.applications.forEach(element => {
                if (element.type == this.lcnst.LocalConstants.BRANCH_NEW) {
                    element.status = this.lcnst.LocalConstants.BRANCH_PROCESSING_NEW
                } else if (element.type == this.lcnst.LocalConstants.BRANCH_UPDATE) {
                    element.status = this.lcnst.LocalConstants.BRANCH_PROCESSING_UPDATE
                } else if (element.type == this.lcnst.LocalConstants.BRANCH_CESSATION) {
                    element.status = this.lcnst.LocalConstants.BRANCH_PROCESSING_CESSATION
                }
                this.submittedRecords.push(element);
            });
            this.active.forEach(element => {
                this.submittedRecords.push(element);
            });
            this.applications.forEach(element => {
                element.licenceNo = this.licenceNo;
            });
            console.log(this.applications);
            this.service.save(
                this.applications).subscribe(data => {
                    this.service.checkForBranchApplication().subscribe(ldata => {
                        Object.keys(this.form.controls).forEach(key => {
                            this.form.get(key).markAsPristine();
                        });
                        this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { applicationNo: ldata.applicationNo, returnApp: this.returnAppCode } });
                    });
                    this.submitted = true;
                    this.checkForBranchApplication();
                    this.preview = false;
                }, error => {
                    this.snackBar.openFromComponent(SuccessSnackbarComponent, {
                        duration: 5000,
                        data: { message: 'Error' }
                    });
                });
        }

    }

    previewForm() {
        this.preview = true;
        window.scrollTo(0, 0);
    }
}
