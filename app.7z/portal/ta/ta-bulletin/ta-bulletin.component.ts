import { Component, OnInit } from '@angular/core';
import { CommonService, ErrorDialogService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FileUtil } from '../../../common/helper';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
    selector: 'app-ta-bulletin',
    templateUrl: './ta-bulletin.component.html',
    styleUrls: ['./ta-bulletin.component.scss']
})
export class TaBulletinComponent implements OnInit {

    bulletin: any;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private commonService: CommonService,
        private errorDialogService: ErrorDialogService,
        private fileUtil: FileUtil,
    ) { }



    ngOnInit() {

        if (this.route.snapshot.paramMap.get('bulletinId')) {
            this.getBulletin(+this.route.snapshot.paramMap.get('bulletinId'));
        } else {

        }

    }

    getBulletin(id) {
        this.commonService.getBulletinDetails(id).subscribe(data => {
            this.bulletin = data;
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

    downloadAttachment(file) {
        if (file.fileId) {
            this.fileUtil.download(file.fileId, file.hash).subscribe(data => {
                this.fileUtil.export(data, file.originalName);
            });
        } else {
            this.errorDialogService.openDialog({ reason: "File unavailable at this  moment. Please check back again later." });
        }

    }

}




