import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaInboundOutboundServicesService {

    constructor(private http: HttpClient) { }

    checkForCompanyUpdateInboundOutBound(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_COMPANY_UPDATES + '/new/InboundOutboundServices');
    }

    save(applications: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_COMPANY_UPDATES + '/save/InboundOutboundServices', applications);
    }

    getLicenceeDetails(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_COMPANY_UPDATES + '/new/licence-details');
    }

}
