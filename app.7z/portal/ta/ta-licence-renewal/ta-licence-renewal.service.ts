import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class TaLicenceRenewalService {

    constructor(private http: HttpClient) { }

    createApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_RNW + '/new');
    }

    submit(application: any): Observable<any> {
        if (application.applicationId) {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_RNW + '/update', application);
        } else {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_RNW + '/save', application);
        }
    }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_RNW + '/load/' + applicationId);
    }

}
