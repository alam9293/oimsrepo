import { Component, OnInit, HostListener } from '@angular/core';
import { CommonService, AlertService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { FileUtil, FormUtil, NumeralUtil, DateUtil } from '../../../common/helper';
import { ActivatedRoute, Router } from '@angular/router';
import { TaKeResignService } from './ta-manage-ke-resign.service';
import { Observable } from 'rxjs';
import { ManageKeAppHelperUtil, TaFormHelperUtil } from '../ta-helper'

@Component({
    selector: 'app-ta-manage-ke-resign',
    templateUrl: './ta-manage-ke-resign.component.html',
    styleUrls: ['./ta-manage-ke-resign.component.scss']
})
export class TaManageKeResignComponent implements OnInit {
    application: any = { applicationStatus: {}, licenceStatus: {} };
    cnst = cnst;
    checked: boolean = false;
    preview: boolean = false;
    kePendingResignation: boolean = false;  // Is current KE already resigned at a future date
    stakeholderDetails: any = { sex: {}, nationality: {}, highestEduLevel: {}, designation: {} };
    addressDetails: any = { premisesType: {} };
    selectedFile: File;
    form: FormGroup;
    fileForm: FormGroup;
    files: any;


    constructor(
        private taFormHelperUtil: TaFormHelperUtil,
        private alertService: AlertService,
        private fileUtil: FileUtil,
        private formUtil: FormUtil,
        private fb: FormBuilder,
        private router: Router,
        private service: TaKeResignService,
        private route: ActivatedRoute,
        private commonService: CommonService,
        private dateUtil: DateUtil,
    ) { }
    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    ngOnInit() {
        this.initiateForm();
        if (this.route.snapshot.paramMap.get('appId')) {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        } else {
            this.createTaLicence();
        }
    }

    // convenience getter for easy access to form fields
    get stakeholderControl() {
        return (this.form.get('stakeholderDto') as FormGroup).controls;
    }
    get fileForms() {
        return this.form.get('files') as FormArray
    }
    get stakeholderForm() {
        return this.form.get('stakeholderDto') as FormGroup
    }

    get taKeStakeholderForm() {
        return this.form.get('taKeStakeholder') as FormGroup
    }
    get taKeStakeholderControl() {
        return (this.form.get('taKeStakeholder') as FormGroup).controls;
    }
    get addressForm() {
        return this.stakeholderForm.get('address') as FormGroup
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.application = data;
            this.stakeholderDetails = data.stakeholderDto;
            this.addressDetails = data.stakeholderDto.address;
            this.setupForm(this.application);
            this.kePendingResignation = data.taKeStakeholder.keResignedAtFutureDate;
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

    createTaLicence(): void {
        this.service.createTaLicenceAaApplication().subscribe(data => {
            this.application = data;
            if (data.haveKe) {
                this.stakeholderDetails = data.stakeholderDto;
                this.addressDetails = data.stakeholderDto.address;
                this.setupForm(this.application);
                this.kePendingResignation = data.taKeStakeholder.keResignedAtFutureDate;
            }
        });
    }

    private setupForm(application: any) {
        this.initiateForm();
        this.addressForm.patchValue(application.stakeholderDto.address);
        this.form.patchValue(application);
        if (application.files) {
            application.files.forEach(item => {
                var req = true;
                if (cnst.DocumentTypes.TA_DOC_OTHERS === item.docType) {
                    req = false;
                }
                this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, req);
                this.fileForm.patchValue(item);
                this.fileForms.push(this.fileForm);
            });
        }
    }

    initiateForm() {
        this.form = this.fb.group({
            stakeholderDto: this.fb.group({
                stakeholderId: [],
                stakeholderName: [''],
                uin: [''],
                sex: this.fb.group({
                    key: ['',],
                    label: ['']
                }),
                nationality: this.fb.group({
                    key: ['',],
                    label: ['']
                }),
                address: this.fb.group({
                    postal: [''],
                    block: [''],
                    street: [''],
                    building: [''],
                    floor: [''],
                    unit: [''],
                    addressId: ['']
                }),
                dob: [''],
                contactNo: ['',],
                email: ['',],
                highestEduLevel: this.fb.group({
                    key: ['',],
                    label: ['']
                }),
                designation: this.fb.group({
                    key: ['',],
                    label: ['']
                }),
                otherDesignation: [''],
            }),

            taKeStakeholder: this.fb.group({
                taStakeholderId: [],
                resignedDate: ['', Validators.required],
            }),

            keAppType: ['',],
            keAppTypeLabel: ['',],
            taKeAppId: '',
            applicationId: '',
            draft: '',
            files: this.fb.array([]),
            toDeleteFiles: this.fb.array([
                this.fb.control('')
            ]),
        });
    }

    onPicked(input: HTMLInputElement, docType: string, index) {
        this.selectedFile = input.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(docType, this.selectedFile).subscribe(data => {
                if (docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
                    this.fileForm = this.taFormHelperUtil.initiateFileForm(this.fb, false);
                    this.fileForm.patchValue(data);
                    this.fileForms.push(this.fileForm);
                } else {
                    var file: any = data;
                    if (file.originalName) {
                        this.fileForms.at(index).patchValue(file);
                    } else {
                        this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
                    }
                }
            });
        }
    }

    toDeleteFile(file, index) {
        if (file.controls.originalName.value) {
            (this.form.get('toDeleteFiles') as FormArray).push(this.fb.control(file.controls.id.value));
        }
        if (file.value.docType === cnst.DocumentTypes.TA_DOC_OTHERS) {
            this.fileForms.removeAt(index);
        } else {
            this.taFormHelperUtil.clearFileDetails(this.fileForms.at(index));
        }
    }

    showPreview() {
        this.alertService.clear();
        if (this.form.valid) {
            this.preview = true
            window.scrollTo(0, 0);
        } else {
            this.form.markAsTouched();
            this.formUtil.markFormGroupTouched(this.form);
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
        }
    }

    saveConfirmationDialog() {
        this.service.submit(this.form.value).subscribe(data => {
            this.alertService.clear();
            this.form.markAsPristine();
            this.service.createTaLicenceAaApplication().subscribe(data => {
                this.router.navigate([cnst.TaApiUrl.TA_THANK_YOU], { queryParams: { 'applicationNo': data.applicationNo } });
            });
            this.preview = false;
        });
    }

    isPendingTaSubmission(): boolean {
        return (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_NEW || this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA || this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_DRAFT)
    }

}
