import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class TaPersonnelService {

    constructor(private http: HttpClient) { }

    getPersonnelList(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_PERSONNEL + '/load');
    }

    getPersonnelParticulars(id: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_PERSONNEL + '/load/' + id);
    }

    getFullPersonnelList(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_PERSONNEL + '/load/full');
    }
    savePersonnelList(application: any, isEdhPopulated): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_PERSONNEL + '/save/' + isEdhPopulated, application);
    }


    getApplicationNo(appId): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_PERSONNEL + '/load/get-application-no/' + appId);
    }

}
