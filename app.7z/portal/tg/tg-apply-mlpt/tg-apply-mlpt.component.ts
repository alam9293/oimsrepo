import { Component, HostListener, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { Observable, forkJoin } from 'rxjs';
import { PaymentDialogComponent } from 'src/app/common/modules/payment-dialog/payment-dialog.component';
import * as cnst from '../../../common/constants';
import { FormUtil } from '../../../common/helper';
import { CommonService } from '../../../common/services';
import { SideMenuTgService } from '../../menu/side-menu-tg/side-menu-tg.service';
import { PaymentService } from '../../payment/payment.service';
import { TgApplyMLPTService } from './tg-apply-mlpt.service';

@Component({
    selector: 'app-tg-apply-mlpt',
    templateUrl: './tg-apply-mlpt.component.html',
    styleUrls: ['./tg-apply-mlpt.component.scss']
})
export class TgApplyMLPTComponent implements OnInit {
    languageList: any = [];
    tgGuidingLanguages: any = [];
    mlptDataSource: any = {};
    submittedMlptDataSource: any = {};
    mlptId: number;
    selectedLanguage: any = [];
    mlptDetails = new MatTableDataSource<any>();
    form: FormGroup;
    cnst = cnst;
    isReinstate: boolean = false;
    resultDisplayedColumns = ['no', 'language', 'examDate', 'examTime', 'result'];

    constructor(
        private dialog: MatDialog,
        private formBuilder: FormBuilder,
        public formUtil: FormUtil,
        private commonService: CommonService,
        private tgMlptService: TgApplyMLPTService,
        private route: ActivatedRoute,
        private router: Router,
        private paymentService: PaymentService,
        private sideMenuTgService: SideMenuTgService,
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.initiateForm();
        this.formControlValueChanged();
        this.loadTgGuidingLanguages();

        if (this.route.snapshot.paramMap.get('mlptId') != null) {
            this.mlptId = +this.route.snapshot.paramMap.get('mlptId');
            this.loadMlptRegistrationById();
        } else {
            this.loadMlptRegistration();
        }
    }

    initiateForm() {
        this.form = this.formBuilder.group({
            declareCheck: [false, Validators.requiredTrue],
            testLanguages: this.formBuilder.array([], Validators.required),
            paymentFee: 0,
            cardPaymentFee: 5,
            draft: [],
            paymentSuccess: [],
            registrationId: [],
            selectedLanguages: [],
            isWaived: [],
        });
    }

    get testLanguages() {
        return this.form.get('testLanguages') as FormArray;
    }

    loadMlptRegistration() {
        this.tgMlptService.getMlptRegistration().subscribe(data => {
            this.mlptDataSource = data;
            this.mlptId = data.mlptId;
            if (data.mlptDraftApplication) {
                data.mlptDraftApplication.testLanguages = [];
                for (let language of data.mlptDraftApplication.tgMlptSlots) {
                    data.mlptDraftApplication.testLanguages.push(language.testLanguages);
                    this.selectedLanguage = data.mlptDraftApplication.testLanguages;
                }

                this.form.patchValue(data.mlptDraftApplication);

                if (this.selectedLanguage) {
                    this.selectedLanguage.forEach(item => {
                        this.testLanguages.push(this.formBuilder.group(item));
                    });
                }
            }

            if (data.mlptId) {
                this.loadSubmittedRegistration();
            }

            if (data.isRegistrationClosed) {
                this.loadMlptDetails();
            }
        });

    }

    loadMlptRegistrationById() {
        this.tgMlptService.getMlptRegistrationById(this.mlptId).subscribe(data => {
            this.mlptDataSource = data;
            if (data.mlptDraftApplication) {
                data.mlptDraftApplication.testLanguages = [];
                for (let language of data.mlptDraftApplication.tgMlptSlots) {
                    data.mlptDraftApplication.testLanguages.push(language.testLanguages);
                    this.selectedLanguage = data.mlptDraftApplication.testLanguages;
                }
                this.form.patchValue(data.mlptDraftApplication);
            }

            if (data.mlptId) {
                this.loadSubmittedRegistration();
            }

            if (data.isRegistrationClosed) {
                this.loadMlptDetails();
            }
        });

    }

    loadSubmittedRegistration() {
        this.tgMlptService.getSubmittedMlptRegistrations(this.mlptId).subscribe(data => {
            this.submittedMlptDataSource = data;

            if (data.cardPaymentFee) {
                this.form.get('cardPaymentFee').setValue(data.cardPaymentFee);
            }

            if (data.isWaived) {
                this.form.get('isWaived').setValue(data.isWaived);
            }

            if (data.nextMlptName) {
                this.mlptDataSource.mlptStartDate = data.nextMlptStartDate;
                this.mlptDataSource.mlptEndDate = data.nextMlptEndDate;
                this.mlptDataSource.regStartDate = data.nextRegStartDate;
                this.mlptDataSource.regEndDate = data.nextRegEndDate;
            }
        });
    }

    loadMlptDetails() {
        this.tgMlptService.getMlptRegistrationDetails(this.mlptId).subscribe(data => {
            this.mlptDetails = data;
        });
    }

    loadTgGuidingLanguages() {

        forkJoin([
            this.commonService.getTgGuidingLanguages(),
            this.sideMenuTgService.getSideMenu(),
            this.tgMlptService.getTgGuidingLanguages(),
        ]).subscribe(([allGuidingLanguages, tgSideMenu, tgGuidingLanguages]) => {
            this.isReinstate = tgSideMenu.licenceRenewalStatus === cnst.LicenceRenewalStatus.REINREINSTATE_AF_3YRSTATE;
            if (this.isReinstate) {
                this.languageList = tgGuidingLanguages;
            } else {
                this.languageList = allGuidingLanguages;
                this.tgGuidingLanguages = tgGuidingLanguages;
            }
        });
    }

    save() {
        // this dialog for user to select payment type
        this.tgMlptService.saveMlptRegistration(this.form.value, this.mlptId).subscribe(data => {
            let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('paymentFee').value, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION, waiveForInactiveLic: data.waiveForInactiveLic } });
            dialog.afterClosed().subscribe(result => {
                if (result.decision) {
                    let paymentType = result.type;
                    this.form.get('draft').setValue(true);
                    let application = data;
                    this.form.markAsPristine();
                    if (application.appFeeBillRefNo == null) {
                        this.tgMlptService.savePaymentRequest(this.form.value, data.registrationId).subscribe(result => {
                            let appFeeBillRefNo = [];
                            appFeeBillRefNo.push(result.appFeeBillRefNo);
                            if (paymentType == cnst.PaymentTypes.PAYNOW) {
                                this.generatePaynowQRCode(result.registrationId, appFeeBillRefNo, paymentType, false, this.form.get('paymentFee').value);
                            } else {
                                this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, appFeeBillRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/' + result.registrationId + '/' + appFeeBillRefNo);
                            }
                        });
                    } else {
                        let appFeeBillRefNo = [];
                        appFeeBillRefNo.push(application.appFeeBillRefNo);
                        if (paymentType == cnst.PaymentTypes.PAYNOW) {
                            this.generatePaynowQRCode(data.registrationId, appFeeBillRefNo, paymentType, false, this.form.get('paymentFee').value);
                        } else {
                            this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, appFeeBillRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/' + data.registrationId + '/' + appFeeBillRefNo);
                        }
                    }

                }
            });

        });
    }

    submit() {
        this.tgMlptService.saveAfterPayment(this.form.get('registrationId').value).subscribe(data => {
            this.form.markAsPristine();
            this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/' + this.form.get('registrationId').value]);
        });
    }

    submitForLicencePrint() {
        this.tgMlptService.saveAfterCardPayment(this.mlptId).subscribe(data => {
            this.form.markAsPristine();
            this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/' + this.mlptId]);
        });
    }

    formControlValueChanged() {
        this.form.get('selectedLanguages').valueChanges.subscribe(
            (data: any) => {
                this.selectedLanguage = data;
                var length = data.length;
                var fee = this.mlptDataSource.mlptFee ? this.mlptDataSource.mlptFee : cnst.TgFees.mlptFee;
                this.form.get('paymentFee').setValue(length * fee);
                if (this.selectedLanguage) {
                    // clear form array
                    while (this.testLanguages.length) {
                        this.testLanguages.removeAt(this.testLanguages.length - 1);
                    }
                    this.selectedLanguage.forEach(item => {
                        this.testLanguages.push(this.formBuilder.group(item));
                    });
                }
            });
    }

    compareLanguages(o1: any, o2: any): boolean {
        if (o1 && o2) {
            return o1.key === o2.key;
        } else {
            return false;
        }
    }

    applied(language) {
        let submitted = false;

        if (this.submittedMlptDataSource != null && this.submittedMlptDataSource.mlptSubmittedApplications != null) {
            this.submittedMlptDataSource.mlptSubmittedApplications.forEach(element => {
                element.tgMlptSlots.forEach(slot => {
                    if (language === slot.testLanguages.key) {
                        submitted = true;
                    }
                })
            })
        }

        if (submitted == false) {
            this.tgGuidingLanguages.forEach(TgLanguage => {
                if (language === TgLanguage.key) {
                    submitted = true;
                }
            })
        }

        return submitted;
    }

    getTime(time: any) {
        var time, startTime, endTime;

        if (time) {
            startTime = moment(time, 'DD-MMM-YYYY HH:mm:ss').format('HH:mm');
            endTime = moment(time, 'DD-MMM-YYYY HH:mm:ss').add(30, 'm').format('HH:mm');
            return startTime + " - " + endTime;
        } else {
            return '';
        }
    }

    cardPayment() {

        if (this.form.get('isWaived').value == true) {
            this.saveAndInitPayment(null, null);
        } else {
            // this dialog for user to select payment type
            let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('cardPaymentFee').value, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_MLPT } });
            dialog.afterClosed().subscribe(result => {
                if (result.decision) {
                    let paymentType = result.type;
                    this.saveAndInitPayment(paymentType, this.form.get('cardPaymentFee').value);
                }
            });
        }

    }

    saveAndInitPayment(paymentType: any, paymentFee: any) {
        if (!this.submittedMlptDataSource.printFeeBillRefNo) {
            this.tgMlptService.saveCardPaymentRequest(this.form.value, this.mlptId).subscribe(result => {
                let printFeeBillRefNo = [];
                printFeeBillRefNo.push(result.printFeeBillRefNo);
                if (paymentType == cnst.PaymentTypes.PAYNOW) {
                    this.generatePaynowQRCode(this.mlptId, printFeeBillRefNo, paymentType, true, paymentFee);
                } else {
                    this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, printFeeBillRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/licence-print/' + printFeeBillRefNo + '/' + this.mlptId);
                }
            });
        } else if (this.submittedMlptDataSource.printFeeBillRefNo != null && this.submittedMlptDataSource.isCardPaymentSuccess == false) {
            let printFeeBillRefNo = [];
            printFeeBillRefNo.push(this.submittedMlptDataSource.printFeeBillRefNo);
            if (paymentType == cnst.PaymentTypes.PAYNOW) {
                this.generatePaynowQRCode(this.mlptId, printFeeBillRefNo, paymentType, true, paymentFee);
            } else {
                this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, printFeeBillRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/licence-print/' + printFeeBillRefNo + '/' + this.mlptId);
            }
        }
    }

    generatePaynowQRCode(id: any, billRefNo: any, paymentType: any, isRouteToLicPrint: boolean, paymentFee: any) {
        this.paymentService.createPayNowTxn(paymentFee, billRefNo).subscribe(txn => {
            let payNowTxnId = txn;
            this.paymentService.generateQrCode(paymentFee, txn).subscribe(qrCode => {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: paymentFee, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        if (isRouteToLicPrint) {
                            this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/licence-print/' + billRefNo + '/' + id, payNowTxnId);
                        } else {
                            this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_MLPT + '/' + id + '/' + billRefNo, payNowTxnId);
                        }
                    }
                });
            });
        });
    }
}
