import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgApplyMLPTService {

    baseUrl: String = cnst.apexBaseUrl + '/tg/mlpt/registration';

    constructor(private http: HttpClient) { }

    getMlptRegistration(): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view');
    }

    getMlptRegistrationById(mlptId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view/' + mlptId);
    }

    getSubmittedMlptRegistrations(mlptId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view/submitted/' + mlptId);
    }

    getMlptRegistrationDetails(mlptId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view/details/' + mlptId);
    }

    getTgGuidingLanguages(): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view/tg-guiding-languages');
    }

    saveMlptRegistration(registration: any, mlptId: number): Observable<any> {
        return this.http.post(this.baseUrl + '/save/mlpt/' + mlptId, registration);
    }

    public savePaymentRequest(app: any, regId: number): Observable<any> {
        return this.http.post(this.baseUrl + '/save/payment/' + regId, app);
    }

    public saveCardPaymentRequest(app: any, mlptId: number): Observable<any> {
        return this.http.post(this.baseUrl + '/save/card-payment/' + mlptId, app);
    }

    public saveAfterPayment(regId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/save/' + regId);
    }

    public saveAfterCardPayment(mlptId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + "/save/licence-print/" + mlptId);
    }
}
