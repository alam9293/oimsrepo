import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl } from '@angular/forms';
import { TgAssignmentCreateService } from '../tg-assignment-create/tg-assignment-create.service';
import { CommonService } from '../../../../common/services';
import { SideMenuTgService } from '../../../menu/side-menu-tg/side-menu-tg.service';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import * as cnst from '../../../../common/constants';
import { FormUtil } from '../../../../common/helper'

@Component({
    selector: 'app-tg-assignment-create',
    templateUrl: './tg-assignment-create.component.html',
    styleUrls: ['./tg-assignment-create.component.scss']
})
export class TgAssignmentCreateComponent implements OnInit {
    tourTypes: any = [];
    employmentSourceTypes: any = [];
    languageTypes: any = [];
    totalHours: number = 0;
    startDt: any;
    endDt: any;
    displayDay: boolean = false;
    cnst = cnst;
    form: FormGroup;
    displayPreview: boolean = false;
    todayDate: any;
    licenceStartDate: any;
    isNew: boolean;
    unionMap = new Map<string, string>();

    constructor(public formUtil: FormUtil,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private taService: TgAssignmentCreateService,
        private sideMenuTgService: SideMenuTgService,
        private router: Router,
        private activatedRoute: ActivatedRoute) { }

    ngOnInit() {
        this.todayDate = moment();

        this.isNew = this.activatedRoute.snapshot.url[2].toString() === 'create';

        this.sideMenuTgService.getSideMenu().subscribe(data => {
            this.licenceStartDate = data.licence.startDate;
        });
        this.commonService.getTgTourType().subscribe(data => this.tourTypes = data);
        this.commonService.getTgEmpSrcType().subscribe(data => this.employmentSourceTypes = data);
        this.taService.getlanguageTypes().subscribe(data => this.languageTypes = data);

        this.form = this.formBuilder.group({
            tgAssignmentId: [''],
            tourType: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            tourTypeOther: [''],
            startDate: ['', Validators.required],
            endDate: ['', Validators.required],
            tgAssignmentDates: this.formBuilder.array([this.initAssignmentDates('', '')]),
            employmentSourceType: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            employmentSourceTypeOther: [''],
            companyName: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            language: ['', Validators.required],
            feeReceived: ['', [Validators.required, Validators.min(0)]]
        });

        if (this.activatedRoute.snapshot.paramMap.get('id') != null) {
            this.taService.getSingleRecord(this.activatedRoute.snapshot.paramMap.get('id')).subscribe(data => {
                this.form.patchValue(data);
                this.totalHours = data.totalHours
                this.startDt = data.startDate
                this.endDt = data.endDate
                this.loadAssignmentDateAndHour(data.tgAssignmentDates);
                this.onTourTypeChange();
                this.onEmploymentSourceTypeChange();
            });
        }
    }

    initAssignmentDates(dateParam: any, noOfHoursParam: any) {
        var group = this.formBuilder.group({
            date: [dateParam],
            noOfHours: [noOfHoursParam, Validators.compose([Validators.required, this.invalidHourValidator])]
        });
        if (noOfHoursParam != '') {
            group.get('noOfHours').markAsDirty();
        }

        group.valueChanges
            .subscribe(val => {
                group.get('noOfHours').patchValue(Math.round(val.noOfHours * 100) / 100, { emitEvent: false })
            });

        return group;
    }

    invalidHourValidator(control: AbstractControl): { [key: string]: any } | null {
        return (control.value > 24) ? { invalidHour: true } : null;
    }


    loadAssignmentDateAndHour(tgAssignmentDates: TgAssignmentDates[]) {
        const control = <FormArray>this.form.controls['tgAssignmentDates'];
        control.controls = [];
        for (let tad of tgAssignmentDates) {
            this.displayDay = true;
            control.push(this.initAssignmentDates(tad.date, tad.noOfHours));
        }
    }

    onDateChanged() {
        this.totalHours = 0;
        var currDate = moment(this.form.get('startDate').value, cnst.dateFormat);
        var lastDate = moment(this.form.get('endDate').value, cnst.dateFormat);

        if (currDate.isValid() && lastDate.isValid()) {
            if (currDate.isSameOrBefore(lastDate)) {
                this.displayDay = true;
                const control = <FormArray>this.form.controls['tgAssignmentDates'];
                var tempControl = control.controls;
                control.controls = [];

                this.addAssignmentDates(control, tempControl, currDate);
                while (currDate.add(1, 'days').diff(lastDate) <= 0) {
                    this.addAssignmentDates(control, tempControl, currDate);
                }
            } else {
                this.displayDay = false;
                this.form.get('startDate').setErrors({ 'invalidStartGreaterEndDate': true });
            }
        }
    }

    addAssignmentDates(control: any, tempControl: any, currDate: any) {
        var isExist = false;
        for (var i = 0; i < tempControl.length; i++) {
            if (currDate.isSame(tempControl[i].get('date').value)) {
                control.push(tempControl[i]);
                isExist = true;
            }
        }
        if (!isExist) {
            control.push(this.initAssignmentDates(currDate.format(cnst.dateFormat), ''));
        }
    }

    onHourChanged() {
        const control = <FormArray>this.form.controls['tgAssignmentDates'];
        var newTotalHours = 0;
        for (var i = 0; i < control.length; i++) {
            var data = control.controls[i];
            if (data.value.noOfHours && data.value.noOfHours < 25) {
                newTotalHours += data.value.noOfHours;
            }
            this.totalHours = newTotalHours;
        }
    }

    onEmploymentSourceTypeChange() {
        if (this.form.get('employmentSourceType').get('key').value == cnst.TgAssignmentTypes.empSrcTypeOther) {
            this.form.get('employmentSourceTypeOther').setValidators([Validators.required, Validators.maxLength(cnst.maxLengthStr)]);
            this.form.get('employmentSourceTypeOther').updateValueAndValidity();
        } else {
            this.form.get('employmentSourceTypeOther').setValidators(null);
            this.form.get('employmentSourceTypeOther').updateValueAndValidity();
        }
    }

    onTourTypeChange() {
        if (this.form.get('tourType').get('key').value == cnst.TgAssignmentTypes.tourTypeOther) {
            this.form.get('tourTypeOther').setValidators([Validators.required, Validators.maxLength(cnst.maxLengthStr)]);
            this.form.get('tourTypeOther').updateValueAndValidity();
        } else {
            this.form.get('tourTypeOther').setValidators(null);
            this.form.get('tourTypeOther').updateValueAndValidity();
        }
    }

    uploadRecord() {
        if (this.isNew) {
            this.taService.saveAssignment(this.form.value).subscribe(data => {
                this.goBack();
                //this.router.navigate(['/portal/tg/assignments/view']);
            }, error => {
            });
        }
        else {
            this.form.controls['tgAssignmentId'].setValue(this.activatedRoute.snapshot.paramMap.get('id'));
            this.taService.updateAssignment(this.form.value).subscribe(data => {
                this.goBack();
                //this.router.navigate(['/portal/tg/assignments/view']);
            }, error => {
            });
        }
    }

    goBack() {
        window.history.back();
    }

    toPreviewPage(displayPreview: boolean) {
        this.displayPreview = displayPreview;
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }
}

export interface TgAssignmentDates {
    date: Date;
    noOfHours: number;
}