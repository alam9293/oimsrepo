import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgAssignmentListService {

    constructor(private http: HttpClient) { }

    public getList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/view', { params: searchDto });
    }

    public getCurrentList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/view/current', { params: searchDto });
    }

    public delete(application: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/update/delete', application);
    }

    public getPastYears(number: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/view/past-years/' + number);
    }

}