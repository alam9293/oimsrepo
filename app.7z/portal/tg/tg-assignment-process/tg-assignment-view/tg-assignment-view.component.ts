import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { TgAssignmentViewService } from '../tg-assignment-view/tg-assignment-view.service';
import { TgAssignmentCreateService } from '../tg-assignment-create/tg-assignment-create.service';
import { CommonService } from '../../../../common/services';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import * as cnst from '../../../../common/constants';
import { FormUtil } from '../../../../common/helper'

@Component({
    selector: 'app-tg-assignment-view',
    templateUrl: './tg-assignment-view.component.html',
    styleUrls: ['./tg-assignment-view.component.scss']
})
export class TgAssignmentViewComponent implements OnInit {
    tourTypes: any = [];
    employmentSourceTypes: any = [];
    languageTypes: any = [];
    record: any = { tourType: {}, employmentSourceType: {} };
    totalHours: number = 0;
    startDt: any;
    endDt: any;
    displayDay: boolean = false;
    isArchive: boolean = false;
    cnst = cnst;
    form: FormGroup;
    id: any;
    unionMap = new Map<string, string>();

    constructor(public formUtil: FormUtil,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private tavService: TgAssignmentViewService,
        private taService: TgAssignmentCreateService,
        private router: Router,
        private activatedRoute: ActivatedRoute) { }

    ngOnInit() {
        let currentUrl = this.activatedRoute.snapshot['_routerState'].url;
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        if (currentUrl.indexOf('archive/view') > -1) {
           this.isArchive = true;
        } 
       
        this.commonService.getTgTourType().subscribe(data => this.tourTypes = data);
        this.commonService.getTgEmpSrcType().subscribe(data => this.employmentSourceTypes = data);
        this.taService.getlanguageTypes().subscribe(data => this.languageTypes = data);

        this.form = this.formBuilder.group({
            tourType: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            tourTypeOther: [],
            startDate: [],
            endDate: [],
            tgAssignmentDates: this.formBuilder.array([this.initAssignmentDates('', '')]),
            employmentSourceType: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            employmentSourceTypeOther: [],
            companyName: [],
            language: [],
            feeReceived: []
        });

        this.tavService.getSingleRecord(this.id).subscribe(data => {
            this.form.patchValue(data);
            this.totalHours = data.totalHours
            this.startDt = data.startDate
            this.endDt = data.endDate
            this.loadAssignmentDateAndHour(data.tgAssignmentDates);
        }, error => {
            this.router.navigate(['/portal/tg/assignments/view']);
        });
    }

    initAssignmentDates(dateParam: any, noOfHoursParam: any) {
        return this.formBuilder.group({
            date: [dateParam],
            noOfHours: [noOfHoursParam]
        });
    }

    loadAssignmentDateAndHour(tgAssignmentDates: TgAssignmentDates[]) {
        const control = <FormArray>this.form.controls['tgAssignmentDates'];
        control.controls = [];
        for (let tad of tgAssignmentDates) {
            this.displayDay = true;
            control.push(this.initAssignmentDates(tad.date, tad.noOfHours));
        }
    }
}

export interface TgAssignmentDates {
    date: Date;
    noOfHours: number;
}
