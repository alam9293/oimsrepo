import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService, ErrorDialogService } from 'src/app/common/services';
import { FileUtil } from '../../../common/helper';

@Component({
    selector: 'app-tg-bulletin',
    templateUrl: './tg-bulletin.component.html',
    styleUrls: ['./tg-bulletin.component.scss']
})
export class TgBulletinComponent implements OnInit {
    bulletinDetail: any;

    constructor(
        private route: ActivatedRoute,
        private commonService: CommonService,
        private errorDialogService: ErrorDialogService,
        private fileUtil: FileUtil,
    ) { }

    ngOnInit() {
        var bulletinId = this.route.snapshot.paramMap.get('bulletinId');
        this.commonService.getBulletinDetails(parseInt(bulletinId)).subscribe(data => {
            this.bulletinDetail = data;
        })
    }

    downloadAttachment(file) {
        if (file.fileId) {
            this.fileUtil.download(file.fileId, file.hash).subscribe(data => {
                this.fileUtil.export(data, file.originalName);
            });
        } else {
            this.errorDialogService.openDialog({ reason: "File unavailable at this  moment. Please check back again later." });
        }

    }

}
