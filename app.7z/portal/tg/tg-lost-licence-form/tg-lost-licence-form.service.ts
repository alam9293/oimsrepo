import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgLostLicenceFormService {

    constructor(private http: HttpClient) { }

    public newApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_REPLACE + "/new");
    }

    public edit(id: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_REPLACE + "/edit/" + id);
    }

    public save(newApp: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(newApp)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_REPLACE + '/save', formData);
    }

    public update(app: any, deletedList: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(app)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_REPLACE + '/update', formData);
    }

    public savePaymentRequest(app: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(app)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_REPLACE + '/save/payment', formData);
    }

    public saveAfterPayment(appId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_REPLACE + "/save/" + appId); 
    }

    getApp(id): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_REPLACE  + '/load/' + id);
    }
}
