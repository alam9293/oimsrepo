import { Component, OnInit } from '@angular/core';
import * as cnst from '../../../common/constants';
import { TgPastInfringementService } from './tg-past-infringement.service';

@Component({
    selector: 'app-tg-past-infringement',
    templateUrl: './tg-past-infringement.component.html',
    styleUrls: ['./tg-past-infringement.component.scss']
})
export class TgPastInfringementComponent implements OnInit {

    relevantOffenceColumns = ['infringedDate', 'provisionSection', 'outcomeLabel'];
    relevantOffenceDataSource = [];
    cnst = cnst;

    constructor(
        private tgPastInfringementService: TgPastInfringementService,
    ) { }

    ngOnInit() {
        this.tgPastInfringementService.getPastInfringements().subscribe(data => {
            this.relevantOffenceDataSource = data;
        })
    }
}
