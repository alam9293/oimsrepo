import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-tg-reinstate-form',
    templateUrl: './tg-reinstate-form.component.html',
    styleUrls: ['./tg-reinstate-form.component.scss']
})
export class TgReinstateFormComponent implements OnInit {
    PDCdisplayedColumns: string[] = ['PRCposition', 'PRCdate', 'PRCcode', 'PRCname', 'PRCtime', 'PRCresult'];
    PDCdataSource = PDCArray_DATA;
    MRCdisplayedColumns: string[] = ['MRCposition', 'MRCdate', 'MRCattendance', 'MRCresult'];
    MRCdataSource = MRCArray_DATA;
    AssignmentDisplayedColumns: string[] = ['AssignmentPosition', 'AssignmentUploadedDate', 'AssignmentTourType', 'AssignmentTotalHours'];
    AssignmentDataSource = AssignmentArray_DATA;
    PhotoDisplayedColumns: string[] = ['PhotoUpload', 'PhotoCheck'];
    MedicalDisplayedColumns: string[] = ['MedicalButton', 'MedicalUploadedDate'];
    MedicalDataSource = MedicalArray_DATA;

    panelOpenStatePdc = PanelStateInit.panelOpenStatePdc;
    panelOpenStateMrc = PanelStateInit.panelOpenStateMrc;
    panelOpenStateAssignment = PanelStateInit.panelOpenStateAssignment;
    panelOpenStateMedical = PanelStateInit.panelOpenStateMedical;

    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    thirdFormGroup: FormGroup;
    forthFormGroup: FormGroup;

    cnst = cnst;

    constructor(private _formBuilder: FormBuilder) { }

    ngOnInit() {
        this.firstFormGroup = this._formBuilder.group({
            name: ['', Validators.required],
            nric: ['', Validators.required],
            dob: ['', Validators.required],
            gender: ['', Validators.required],
            nationality: ['', Validators.required],
            designation: ['', Validators.required],
            officeNo: ['', Validators.required],
        });
        this.secondFormGroup = this._formBuilder.group({
            guidingLanguages: ['', Validators.required],
            areaOfInterest: ['', Validators.required],
        });
        this.thirdFormGroup = this._formBuilder.group({
        });
        this.forthFormGroup = this._formBuilder.group({
        });
    }

}

export interface PanelState {
    panelOpenStatePdc: boolean;
    panelOpenStateMrc: boolean;
    panelOpenStateAssignment: boolean;
    panelOpenStateMedical: boolean;
}

const PanelStateInit: PanelState = {
    panelOpenStatePdc: false,
    panelOpenStateMrc: false,
    panelOpenStateAssignment: false,
    panelOpenStateMedical: false
};

export interface PDCArray {
    PRCposition: number;
    PRCdate: string;
    PRCcode: string;
    PRCname: string;
    PRCtime: number;
    PRCresult: string;
}
const PDCArray_DATA: PDCArray[] = [
    { PRCposition: 0, PRCdate: '29-Oct-2018', PRCcode: 'CRS-N-0045002', PRCname: 'Apply Feng Shui Knowledge on a Tour through Singapore', PRCtime: 7, PRCresult: '80/100' },
    { PRCposition: 0, PRCdate: '31-Oct-2018', PRCcode: 'CRS-N-0040341', PRCname: 'Art in Public Places', PRCtime: 7, PRCresult: '85/100' },
    { PRCposition: 0, PRCdate: '02-Nov-2018', PRCcode: 'CRS-N-0035439', PRCname: 'Exploring Peranakan Culture', PRCtime: 7, PRCresult: '80/100' },
];

export interface MRCArray {
    MRCposition: number;
    MRCdate: string;
    MRCattendance: string;
    MRCresult: string;
}
const MRCArray_DATA: MRCArray[] = [
    { MRCposition: 0, MRCdate: '29-Sep-2018', MRCattendance: 'Attended', MRCresult: 'Failed' },
    { MRCposition: 0, MRCdate: '29-Oct-2018', MRCattendance: 'Attended', MRCresult: 'Passed' },
];

export interface AssignmentArray {
    AssignmentPosition: number;
    AssignmentUploadedDate: string;
    AssignmentTourType: string;
    AssignmentTotalHours: number;
}
const AssignmentArray_DATA: AssignmentArray[] = [
    { AssignmentPosition: 0, AssignmentUploadedDate: '19-Jan-2017', AssignmentTourType: 'City Tour', AssignmentTotalHours: 8 },
    { AssignmentPosition: 0, AssignmentUploadedDate: '28-Dec-2017', AssignmentTourType: 'City Tour', AssignmentTotalHours: 4 },
    { AssignmentPosition: 0, AssignmentUploadedDate: '7-Jan-2018', AssignmentTourType: 'City Tour', AssignmentTotalHours: 6 },
    { AssignmentPosition: 0, AssignmentUploadedDate: '10-Feb-2018', AssignmentTourType: 'City Tour', AssignmentTotalHours: 4 },
    { AssignmentPosition: 0, AssignmentUploadedDate: '19-Mar-2018', AssignmentTourType: 'City Tour', AssignmentTotalHours: 8 }
];

export interface MedicalArray {
    MedicalUploadedDate: string;
    MedicalName: string;
    MedicalButton: string;
}
const MedicalArray_DATA: MedicalArray[] = [
    { MedicalUploadedDate: '-', MedicalName: '-', MedicalButton: '' },
];
