import { Component, OnInit, AfterViewInit, ViewChildren, QueryList, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatSortable } from '@angular/material';
import { FormBuilder, FormGroup, FormArray, AbstractControl } from '@angular/forms';
import { TgRenewalFormService } from './tg-renewal-form.service';
import { TgRenewalHelperUtil } from '../tg-helper';
import { CommonService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { DomSanitizer } from '@angular/platform-browser';
import * as _ from 'lodash';
import { FileUtil } from '../../../common/helper';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { CroppieDialogComponent } from '../../croppie-dialog/croppie-dialog.component';

@Component({
    selector: 'app-tg-renewal-form',
    templateUrl: './tg-renewal-form.component.html',
    styleUrls: ['./tg-renewal-form.component.scss']
})
export class TgRenewalFormComponent implements OnInit, AfterViewInit {
    @ViewChildren(MatSort) sorts = new QueryList<MatSort>();
    @ViewChild(MatSort) assignmentSort: MatSort;

    @ViewChild('pdcPaginator', { read: MatPaginator }) pdcPaginator: MatPaginator;
    @ViewChild('mrcPaginator', { read: MatPaginator }) mrcPaginator: MatPaginator;
    @ViewChild('assignmentPaginator', { read: MatPaginator }) assignmentPaginator: MatPaginator;

    filter: any = {};

    selectedFile: File;
    selectedFiles: any = [];
    cnst = cnst;
    PDCdisplayedColumns: string[] = ['serialNo', 'tpName', 'courseName', 'attendedDate', 'attendance'];
    MRCdisplayedColumns: string[] = ['serialNo', 'courseName', 'attendedDate', 'score', 'scoreInPercent', 'result'];
    tgAssignmentDisplayedColumns = ['serialNo', 'assignmentDate', 'assignmentEndDate', 'tourType', 'totalHours', 'empSrc', 'companyName', 'feeReceived'];
    tgAssessmentDisplayedColumns = ['serialNo', 'date', 'language', 'mlptResult'];
    tgAssignmentDataSource = [];
    listOfMrcDataSource = [];
    listOfPdcDataSource = [];
    tgAssessmentDataSource = [];
    photo: File;
    imageSrc: any = "./assets/images/tg_photo.png";
    todayDate: any;
    renewalConditions: string;
    medicalTouched: boolean = false;
    assignmentStartIndex: number = 0;
    isLoading = true;
    showPhotoGuideline = false;

    firstFormGroup: FormGroup;

    dropdowns: any = {};

    constructor(
        public dialog: MatDialog,
        private tgRenewalFormService: TgRenewalFormService,
        private tgRenewalHelperUtil: TgRenewalHelperUtil,
        private _formBuilder: FormBuilder,
        private fileUtil: FileUtil,
        private _sanitizer: DomSanitizer,
        private commonService: CommonService,
        private router: Router,
        private route: ActivatedRoute,
    ) { }

    ngOnInit() {
        this.todayDate = moment();
        this.renewalConditions = this.route.snapshot.paramMap.get('renewalConditions');

        this.firstFormGroup = this._formBuilder.group({
            applicationNo: [''],
            statusRemark: [''],
            status: this._formBuilder.group({
                key: ['', this.tgRenewalHelperUtil.isEditable],
                label: [''],
            }),
            photo: [],
            medDate: [''],
            medFiles: this._formBuilder.array([]),
            workPassFiles: this._formBuilder.array([]),
            hasNoAssignment: [false],
            cpfDeclared: [false],
            mrc: this.tgRenewalHelperUtil.getConditionGroup(),
            pdc: this.tgRenewalHelperUtil.getConditionGroup(),
            assignments: this.tgRenewalHelperUtil.getConditionGroup(),
            cpf: this.tgRenewalHelperUtil.getConditionGroup(),
            assessment: this.tgRenewalHelperUtil.getConditionGroup(),
            newPhoto: this.tgRenewalHelperUtil.getConditionGroup(),
            medicalReport: this.tgRenewalHelperUtil.getConditionGroup(),
            workPass: this.tgRenewalHelperUtil.getConditionGroup(),
            isOpenForRenewal: [false],
            medRequiredStartDate: [''],
            renewalStatus: this._formBuilder.group({
                key: [''],
                label: ['renewal'],
                otherLabel: ['renewal']
            }),
            paymentFee: [],
            paymentSuccess: [],
            id: [],
            applicationId: [],
            cpfStatus: [],
            isNewPhotoRequire: [false],
            isCurrentTgPhoto: [false],
            currentTgPhotoId: [],
            isRfaApp: [false]
        });

        this.tgRenewalFormService.getLicenceRenewal().subscribe(data => {
            this.firstFormGroup.patchValue(data);

            if (data.photo) {
                if (data.photo.publicFileId && data.photo.hash) {
                    this.fileUtil.download(data.photo.publicFileId, data.photo.hash).subscribe(data => {
                        const reader = new FileReader();
                        reader.onload = (e: any) => {
                            this.imageSrc = this._sanitizer.bypassSecurityTrustUrl(e.target.result);
                        };
                        reader.readAsDataURL(data);
                    });
                }
            }
            if (data.medFiles.length > 0) {
                data.medFiles.forEach(item => {
                    this.medFiles.push(this._formBuilder.group(item));
                });
            }

            if (data.workPassFiles.length > 0) {
                data.workPassFiles.forEach(item => {
                    this.workPassFiles.push(this._formBuilder.group(item));
                });
            }

            this.tgRenewalHelperUtil.loadConditions(this.firstFormGroup);
            this.isLoading = false;
        });

        this.commonService.populateFormDropdowns().subscribe(data => {
            this.dropdowns = data;
        });
    }

    ngAfterViewInit() {
        this.loadTgAssignment();
        this.loadListOfMrc();
        this.loadListOfPdc();
        this.loadListOfAssessment();
    }

    // convenience getter for easy access to form fields
    get f1() { return this.firstFormGroup.controls; }

    get medFiles() {
        return this.firstFormGroup.get('medFiles') as FormArray;
    }

    get workPassFiles() {
        return this.firstFormGroup.get('workPassFiles') as FormArray;
    }

    isConditionGrey(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionGrey(condition);
    }

    isConditionGreyOnly(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionGreyOnly(condition);
    }

    isConditionGreyTemp(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionGreyTemp(condition);
    }

    isConditionHide(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionHide(condition);
    }

    isConditionTickOnly(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionTickOnly(condition);
    }

    isConditionBlankOnly(condition: AbstractControl) {
        return this.tgRenewalHelperUtil.isConditionBlankOnly(condition);
    }

    loadListOfMrc() {
        var paginator = this.mrcPaginator;
        var sort = this.sorts.toArray()[0];

        this.filter.type = cnst.TpCourseTypes.mrc;
        let mergedDto = {
            'pageSize': paginator.pageSize,
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sort.active,
            'order': sort.direction,
            ...this.filter
        };

        this.tgRenewalFormService.getMrcList(mergedDto).subscribe(data => {
            if (data.attendance == "Absent") {
                data.result = "Absent";
                data.score = "";
                data.scoreInPercent = "";
            }
            this.listOfMrcDataSource = data.records;
            paginator.length = data.total;
        });

    }

    loadListOfPdc() {
        var paginator = this.pdcPaginator;
        var sort = this.sorts.toArray()[1];

        this.filter.type = cnst.TpCourseTypes.pdc;
        let mergedDto = {
            'pageSize': paginator.pageSize,
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sort.active,
            'order': sort.direction,
            ...this.filter
        };

        this.tgRenewalFormService.getPdcList(mergedDto).subscribe(data => {
            this.listOfPdcDataSource = data.records;
            paginator.length = data.total;
        });

    }

    loadTgAssignment() {
        var paginator = this.assignmentPaginator;
        var sort = this.sorts.toArray()[2];
        var sortProperty;
        var sortOrder;
        if (!sort.active) {
            sortProperty = 'startDate';
            sortOrder = 'desc';
        } else {
            sortProperty = sort.active;
            sortOrder = sort.direction;
        }

        let mergedDto = {
            'pageSize': paginator.pageSize,
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sortProperty,
            'order': sortOrder
        };

        this.tgRenewalFormService.getAssignmentList(mergedDto).subscribe(data => {
            this.tgAssignmentDataSource = data.records;
            paginator.length = data.total;
            this.assignmentStartIndex = paginator.pageIndex * paginator.pageSize;
        });

    }

    loadListOfAssessment() {
        this.tgRenewalFormService.getAssessmentList().subscribe(data => {
            this.tgAssessmentDataSource = data;
        });

    }

    onPhotoChanged(event: any) {
        var fileValid = true;
        this.imageSrc = "./assets/images/tg_photo.png";
        this.photo = event.target.files[0];

        var photoExtension = this.photo.name.split('.').pop().toLowerCase();
        if (this.fileUtil.checkPhotoFileExt(photoExtension)) {
            fileValid = false;
            this.firstFormGroup.get('photo').setErrors({ 'invalidPhotoExtension': true });
        }

        if (this.fileUtil.exceedMaxSize(this.photo)) {
            fileValid = false;
            this.firstFormGroup.get('photo').setErrors({ 'maxFileSize': true });
        }
        else if (this.fileUtil.exceedMinSize(this.photo)) {
            fileValid = false;
            this.firstFormGroup.get('photo').setErrors({ 'minFileSize': true });
        }
        if (fileValid && event.target.files && event.target.files[0]) {
            var form = this.firstFormGroup;
            var photo = this.photo;
            var fileUtil = this.fileUtil;
            var tgRenewalFormService = this.tgRenewalFormService;
            const reader = new FileReader();
            reader.readAsDataURL(event.target.files[0]);
            reader.onload = (e: any) => {
                let self = this;
                var image = new Image();
                image.src = e.target.result;
                image.onload = function () {
                    if (image.width != 400 || image.height != 514) {
                        form.get('photo').setErrors({ 'invalidWidthHeight': true });
                    }
                    else {
                        form.get('photo').setErrors(null);
                        self.imageSrc = e.target.result;
                        fileUtil.upload(cnst.DocumentTypes.TG_DOC_PASSPORT_PHOTO, photo).subscribe(data => {
                            
                            form.controls['currentTgPhotoId'].setValue(data.id);
                            form.patchValue({
                                photo: data
                                
                            });
                            tgRenewalFormService.update(form.getRawValue(), cnst.renewalConditions.RENEWAL_NEW_PHOTO, form.get('currentTgPhotoId').value).subscribe(data => {
                                form.get('newPhoto').setValue({
                                    'key': cnst.renewalStatusCode.renewalTick,
                                    'value': cnst.renewalStatusUrl.renewalTick
                                });
                            });
                        });
                    }
                };

            };
        }
        this.firstFormGroup.get('isCurrentTgPhoto').setValue(false);
        this.displayPhotoGuideline(true);
    }

    setPhotoTouched() {
        this.firstFormGroup.controls['photo'].markAsTouched({ onlySelf: true });
    }

    setMedicalReportTouched() {
        this.firstFormGroup.controls['photo'].markAsTouched({ onlySelf: true });
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                const fileDto = this._formBuilder.group({
                    id: [],
                    publicFileId: [],
                    originalName: [],
                    processedName: [],
                    docType: [],
                    extension: [],
                    path: [],
                    size: [],
                    hash: [],
                    documentInstructions: [],
                    documentTypeLabel: [],
                    description: [],
                    readableFileSize: []
                });
                fileDto.patchValue(data);

                switch (type) {
                    case cnst.DocumentTypes.TG_DOC_MEDICAL_65:
                        this.medFiles.push(fileDto);
                        this.onUpdate(cnst.renewalConditions.RENEWAL_MEDICAL_REPORT);
                        break;
                    case cnst.DocumentTypes.TG_DOC_WORK_PASS:
                        this.workPassFiles.push(fileDto);
                        this.onUpdate(cnst.renewalConditions.RENEWAL_WORK_PASS);
                        break;
                    default:
                }
            });
        }
        event.target.value = '';
    }

    updateNilAssignment() {
        this.firstFormGroup.patchValue({
            hasNoAssignment: true
        });
        this.onUpdate(cnst.renewalConditions.RENEWAL_ASSIGNMENTS);
    }

    onUpdate(type: string) {
        this.tgRenewalFormService.update(this.firstFormGroup.getRawValue(), type, null).subscribe(data => {
            this.ngOnInit();
            this.ngAfterViewInit();
        });
    }

    removeFile(doc, index, type) {
        this.fileUtil.delete({ publicFileId: doc.id, hash: doc.hash });

        switch (type) {
            case cnst.DocumentTypes.TG_DOC_MEDICAL_65:
                this.medFiles.removeAt(index);
                this.onUpdate(cnst.renewalConditions.RENEWAL_MEDICAL_REPORT);
                break;
            case cnst.DocumentTypes.TG_DOC_WORK_PASS:
                this.workPassFiles.removeAt(index);
                this.onUpdate(cnst.renewalConditions.RENEWAL_WORK_PASS);
                break;
            default:
        }
    }

    downloadFile(doc) {
        var fileId, fileName;
        if (doc.publicFileId == null) {
            fileId = doc.id;
            fileName = doc.originalName;
        } else {
            fileId = doc.publicFileId;
            fileName = doc.processedName;
        }

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    isDisabled(status: any) {
        return status.value.key == cnst.ApplicationStatuses.TG_APP_PENDING_APPROVAL ||
            status.value.key == cnst.ApplicationStatuses.TG_APP_PENDING_PO ||
            status.value.key == cnst.ApplicationStatuses.TG_APP_PENDING_AO ||
            status.value.key == cnst.ApplicationStatuses.TG_APP_PENDING_HODIV ||
            status.value.key == cnst.ApplicationStatuses.TG_APP_APPROVED ||
            status.value.key == cnst.ApplicationStatuses.TG_APP_REJECTED;
    }

    openCropDialog() {
        let dialog = this.dialog.open(CroppieDialogComponent);
    }

    onSubmit() {

        this.tgRenewalFormService.save().subscribe(data => {
            this.router.navigate([cnst.TgApplicationUrl.TG_THANK_YOU], {
                queryParams: {
                    'title': 'Return For Action',
                    'applicationNo': data.applicationNo
                }
            });
        });
    }

    saveAfterPayment() {
        this.tgRenewalFormService.saveAfterPayment(this.firstFormGroup.get('id').value).subscribe(data => {
            this.firstFormGroup.markAsPristine();
            this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_RENEWAL + '/' + this.firstFormGroup.get('id').value]);
        });
    }

    setCurrentTGPhoto() {
        this.tgRenewalFormService.setCurrentTgPhoto(this.firstFormGroup.get('id').value, this.firstFormGroup.get('currentTgPhotoId').value).subscribe(data => {
            this.ngOnInit();
            this.ngAfterViewInit();
            this.displayPhotoGuideline(false);
        });
    }

    displayPhotoGuideline(isDisplay) {
        this.showPhotoGuideline = isDisplay;
    }
}
