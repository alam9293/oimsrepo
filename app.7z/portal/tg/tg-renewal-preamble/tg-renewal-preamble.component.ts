import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tg-renewal-preamble',
  templateUrl: './tg-renewal-preamble.component.html',
  styleUrls: ['./tg-renewal-preamble.component.scss']
})
export class TgRenewalPreambleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
