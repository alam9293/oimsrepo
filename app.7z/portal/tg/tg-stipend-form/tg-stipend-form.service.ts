import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgStipendFormService {

    baseUrl: String = cnst.apexBaseUrl + cnst.TgAPiUrl.TG_STIPEND;

    constructor(private http: HttpClient) { }

    newApplication(configId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + "/new/" + configId);
    }

    load(id: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + "/load/" + id);
    }

    loadByApplication(appId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + "/load/app/" + appId);
    }

    save(newApp: any, deletedList: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(newApp)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(this.baseUrl + '/save', formData);
    }

    update(app: any, deletedList: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(app)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(this.baseUrl + '/update', formData);
    }

    updateAfterFollowUp(app: any): Observable<any> {
        return this.http.post(this.baseUrl + '/update/follow-up', app);
    }

}
