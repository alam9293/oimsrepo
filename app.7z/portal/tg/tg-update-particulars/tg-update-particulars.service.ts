import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgUpdateParticularsService {

    constructor(private http: HttpClient) { }

    public getTgPersonUpdate(id: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_PARTICULARS + '/edit/' + id);
    }

    public updateForm(particular: any, deletedList: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(particular)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_PARTICULARS + '/update', formData);
    }

    public submitForm(particular: any, deletedList: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(particular)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_PARTICULARS + '/save', formData);
    }

    public getParticularInfo(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_PARTICULARS + '/new');
    }

    public editParticularInfo(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_PARTICULARS + '/edit');
    }

    public savePaymentRequest(particular: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(particular)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_PARTICULARS + '/save/payment', formData);
    }

    public saveAfterPayment(appId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_PARTICULARS + "/save/" + appId);
    }
}