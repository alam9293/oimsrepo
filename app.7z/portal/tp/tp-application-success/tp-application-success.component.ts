import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import * as cnst from '../../../common/constants';
import { TpApplicationSuccessService } from './tp-application-success.service';

@Component({
    selector: 'app-tp-application-success',
    templateUrl: './tp-application-success.component.html',
    styleUrls: ['./tp-application-success.component.scss']
})
export class TpApplicationSuccessComponent implements OnInit {

    application: any = { applicationStatus: {}, tgCourse: {} };
    cnst = cnst;
    module: any;

    constructor(
        private route: ActivatedRoute,
        private tpApplicationSuccessService: TpApplicationSuccessService
    ) { }

    ngOnInit() {

        this.module = this.route.snapshot.paramMap.get('module');
        let appId = this.route.snapshot.paramMap.get('appId');

        if (appId) {
            this.tpApplicationSuccessService.getApplication(this.module, appId).subscribe(data => {
                this.application = data;
            })
        }
    }

    displayByStatus(statuses: any) {
        return statuses.includes(this.application.applicationStatus.key);
    }
}
