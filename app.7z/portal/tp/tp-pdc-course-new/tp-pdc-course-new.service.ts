import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TpPdcCourseNewService {

    public baseUrl = cnst.apexBaseUrl + cnst.TgAPiUrl.TG_COURSE_CREATION;

    constructor(private http: HttpClient) { }

    submitNewCourse(form: any, deletedList: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(form)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(this.baseUrl + '/save', formData, { responseType: 'text' });
    }

    getApplication(id): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view/' + id);
    }

    createAlert(id): Observable<any> {
        return this.http.post(this.baseUrl + '/save/create-alert/' + id, { responseType: 'text' });
    }
}