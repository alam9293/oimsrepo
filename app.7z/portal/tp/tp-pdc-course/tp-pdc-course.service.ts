import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TpPdcCourseService {

    constructor(private http: HttpClient) { }

    getApprovedCourses(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/courses/view', { params: searchDto });
    }

    getCourse(courseCode: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/courses/view/' + courseCode);
    }

    saveOrUpdateCourse(formData: any): Observable<any> {
        if (formData.code) {
            return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/courses/update', formData, { responseType: 'text' });
        } else {
            return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/courses/save', formData, { responseType: 'text' });
        }
    }
}