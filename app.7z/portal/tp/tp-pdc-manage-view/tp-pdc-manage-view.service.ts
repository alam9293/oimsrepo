import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TpPdcManageViewService {

    constructor(private http: HttpClient) { }

    public getCourseAttendanceDetails(attendanceId: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/view/' + attendanceId);
    }
}