import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { ValidateEmail } from 'src/app/common/helper/form.util';
import { TrainingProviderService } from './tp.service';
import { AlertService, CommonService } from 'src/app/common/services';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
    selector: 'app-tp-profile-manage',
    templateUrl: './tp-profile-manage.component.html',
    styleUrls: ['./tp-profile-manage.component.scss']
})
export class TpProfileManageComponent implements OnInit {
    public Editor = ClassicEditor;
    public config = { toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'inserttable', 'undo', 'redo'] };
    form: FormGroup;
    cnst = cnst;
    commonData: any = {};

    constructor(
        private formBuilder: FormBuilder,
        private tpService: TrainingProviderService,
        private alertService: AlertService,
        private commonService: CommonService
    ) { }

    ngOnInit() {
        this.initForm();
        this.loadCommonTypes();
        this.loadTpProfile();
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    loadTpProfile() {
        this.tpService.getProfile().subscribe(data => {
            this.form.patchValue(data);
        })
    }

    loadCommonTypes() {
        this.commonService.getAddressTypes().subscribe(data => {
            this.commonData.addressTypes = data;
        })
    }

    initForm() {
        this.form = this.formBuilder.group({
            id: [''],
            name: ['', Validators.required],
            uen: [''],
            isMrc: [''],
            isPdc: [''],
            isAto: [''],
            status: [''],
            contactPerson: ['', [
                Validators.required,
                Validators.maxLength(255)]],
            contactNo: ['', [
                Validators.required,
                Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
            email: ['', [
                Validators.required,
                Validators.maxLength(320), ValidateEmail]],
            contactPerson1: ['', [
                Validators.maxLength(255)]],
            contactNo1: ['', [
                Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
            email1: ['', [
                Validators.maxLength(320), ValidateEmail]],
            profileSummary: ['', Validators.required],
            webLink: [''],
            signUpLink: [''],
            address: this.formBuilder.group({
                street: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)]],
                building: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
                block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                unit: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.UNIT), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern("^[0-9]*$")]],
                formatted: [''],
                singleLined: [''],
                premisesType: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
                type: this.formBuilder.group({
                    key: [cnst.AddressTypes.ADDR_LOCAL, Validators.required],
                    label: ['']
                }),
                foreignLine1: ['', Validators.maxLength(255)],
                foreignLine2: ['', Validators.maxLength(255)],
                foreignLine3: ['', Validators.maxLength(255)],
                singleLineAddress: [''],
                addressId: ['']
            })
        });
    }

    saveTpDetails() {
        this.alertService.clear();
        this.tpService.updateTrainingProvider(this.form.value).subscribe(data => {
            this.alertService.success(cnst.Messages.GENERIC_SUCCCESS);
            this.scrollToTop();
            this.loadTpProfile();
        }, error => {
            this.alertService.error(cnst.Messages.ERR_MSG_GENERIC);
        });
    }

    onPostalCodeChange() {
        var postal = this.form.get('address').get('postal').value.toString();
        if (postal.length == 6 && !isNaN(parseInt(postal, 10))) {
            this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                if (data) {
                    var addrResults = data['results'];
                    if (addrResults.length > 0) {
                        this.form.get('address').patchValue({
                            block: addrResults[0]['BLK_NO'].trim(),
                            street: addrResults[0]['ROAD_NAME'].trim(),
                            building: addrResults[0]['BUILDING'].trim()
                        });
                    } else {
                        this.form.get('address').get('postal').setErrors({ 'invalid': true });
                    }
                }
            });
        }
    }

    goBack() {
        window.history.back();
    }

}
