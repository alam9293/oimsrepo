import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-login-portal-id',
    templateUrl: './login-portal-id.component.html',
    styleUrls: ['./login-portal-id.component.scss']
})
export class LoginPortalIdComponent implements OnInit {
    successLink: String;

    constructor(private route: ActivatedRoute) { }

    ngOnInit() {
        this.successLink = this.route.snapshot.paramMap.get('successLink');
    }

    onLogin() {
        localStorage.setItem('isLoggedinPortal', 'true');
    }
}
