import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PublicComponent } from './public.component';
import { HomeComponent } from './home/home.component';
import { DirectoryTaComponent } from './directory/directory-ta/directory-ta.component';
import { DirectoryTgComponent } from './directory/directory-tg/directory-tg.component';
import { LoginSingPassComponent } from './login/login-sing-pass/login-sing-pass.component';
import { LoginCorpPassComponent } from './login/login-corp-pass/login-corp-pass.component';
import { LoginPortalIdComponent } from './login/login-portal-id/login-portal-id.component';
import { TaApplicationPreambleComponent } from './ta/ta-application-preamble/ta-application-preamble.component';
import { TgApplicationGuideComponent } from './tg/tg-application-guide/tg-application-guide.component';
import { TgApplicationPreambleComponent } from './tg/tg-application-preamble/tg-application-preamble.component';

const routes: Routes = [{
    path: '',
    component: PublicComponent,
    children: [
        { path: 'home', component: HomeComponent },
        { path: 'directory-ta', component: DirectoryTaComponent },
        { path: 'directory-tg', component: DirectoryTgComponent },
        { path: 'login-sing-pass/:successLink', component: LoginSingPassComponent },
        { path: 'login-corp-pass/:successLink', component: LoginCorpPassComponent },
        { path: 'login-portal-id/:successLink', component: LoginPortalIdComponent },
        { path: 'ta-application-preamble', component: TaApplicationPreambleComponent },
        { path: 'tg-application-preamble', component: TgApplicationPreambleComponent },
        { path: 'tg-application-guide', component: TgApplicationGuideComponent }
    ]
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PublicRoutingModule { }
