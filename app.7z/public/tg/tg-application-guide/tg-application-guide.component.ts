import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tg-application-guide',
  templateUrl: './tg-application-guide.component.html',
  styleUrls: ['./tg-application-guide.component.scss']
})
export class TgApplicationGuideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
