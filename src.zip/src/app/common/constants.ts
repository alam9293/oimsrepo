import { environment } from '../../environments/environment';

export const apiBaseUrl = environment.apiAppUrl;
export const apexBaseUrl = environment.apexAppUrl;
export const apexPublicBaseUrls = [apexBaseUrl + '/payment/public'] // skip jwt-interceptor
export const apexPublicBaseUrlsResources = [apexBaseUrl + '/category/public-get-all-categorys'] // skip jwt-interceptor
export const apexPublicBaseUrlsResourcesCategoryId = [apexBaseUrl + '/category/public-get-categorys-by-id'] // skip jwt-interceptor

export const showDebugError = true;
export const maxLengthStr = 255;
export const dateFormat = "DD-MMM-YYYY";
export const dateFormat1 = "dd MMMM yyyy";
export const passwordPattern = "(^(?=.*[a-zA-Z])(?=.*[0-9]).{12,}$)";
export const nextBtnTxt = "Next";
export const previewBtnTxt = "Confirm";
export const submitBtnTxt = "Submit";
export const cancelBtnTxt = "Cancel";
export const backBtnTxt = "Back";

export class PAGINATION {
    public static SIZE_OPTTIONS = [5, 10, 20, 50];
    public static DEFAULT_PAGE_SIZE = 10;
}

export const PUBLIC_HOME_URL = '/public/home';
export const STB_TA_EMAIL_ADDRESS = 'STB_TA@STB.GOV.SG';


//export const WEB_PORTAL_URL = environment.webPortalUrl;
export const WEB_PORTAL_URL = environment.webPortalUrl;

export const WEB_PORTAL_CONTACT_US = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/contact-us.html'];
export const WEB_PORTAL_SITE_MAP = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/site-map.html'];
export const WEB_PORTAL_HOME = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page.html'];
export const WEB_PORTAL_TRAVEL_AGENT = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/travel-agent.html'];
export const WEB_PORTAL_TOURIST_GUIDE = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/tourist-guide.html'];
export const WEB_PORTAL_BULLETIN = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/bulletin-board.html'];
export const WEB_PORTAL_USER_GUIDE = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/user-guide.html'];
export const WEB_PORTAL_USER_GUIDE_TG = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/user-guide.html?target=2'];
export const WEB_PORTAL_LEGISLATION = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/legislation.html'];
export const WEB_PORTAL_TERMS_USE = [WEB_PORTAL_URL + '/site/content/tagaem/landing-page/terms-of-use.html'];

export const WEB_PORTAL_FAQS = "http://www.ifaq.gov.sg/STB/apps/Fcd_faqmain.aspx";
export const WEB_PORTAL_APPLY_TG = "https://www.stb.gov.sg/content/stb/en/assistance-and-licensing/licensing-overview/tourist-guide-licence.html#TouristGuideLicence";
export const WEB_PORTAL_ABOUT_STB = "https://www.stb.gov.sg/content/stb/en.html";
export const WEB_PORTAL_NEWSROOM_PUBLICATIONS = "https://www.stb.gov.sg/content/stb/en/media-centre/corporate-publications.html";
export const WEB_PORTAL_CAREERS = "https://www.stb.gov.sg/content/stb/en/careers/overview.html";
export const WEB_PORTAL_INVEST_IN_TOURISM = "https://www.stb.gov.sg/content/stb/en/about-stb/invest-in-tourism.html";
export const WEB_PORTAL_STATISTICS_MARKET_INSIGHTS = "https://www.stb.gov.sg/content/stb/en/statistics-and-market-insights/statistics-and-market-insights-overview.html";
export const WEB_PORTAL_INDUSTRIES = "https://www.stb.gov.sg/content/stb/en/industries/industries-overview.html";
export const WEB_PORTAL_ASSISTANCE_LICENSING = "https://www.stb.gov.sg/content/stb/en/assistance-and-licensing/assistance-and-licensing.html";
export const WEB_PORTAL_TRADE_EVENTS = "https://www.stb.gov.sg/content/stb/en/trade-events-and-resources/trade-events-overview.html";
export const WEB_PORTAL_VISIT_INFO = "https://www.visitsingapore.com/en_my/";
export const WEB_PORTAL_SECB = "https://www.visitsingapore.com/mice/en/";
export const WEB_PORTAL_SG_TOURISM_AWARDS = "https://www.singaporetourismawards.com/#EBlKAeMvsIKapv3b.97";
export const WEB_PORTAL_PRIVACY_STATEMENT = "https://www.stb.gov.sg/content/stb/en/footer/privacy-statement.html";
export const WEB_PORTAL_REPORT_VULNERABILITY = "https://go.gov.sg/trust-disclose";
export const WEB_PORTAL_STB_IG = "https://instagram.com/visit_singapore";
export const WEB_PORTAL_STB_FB = "https://www.facebook.com/VisitSingaporeOfficial";
export const WEB_PORTAL_STB_TWITTER = "https://www.twitter.com/visitsingapore";
export const WEB_PORTAL_FEEDBACK = "https://www.stb.gov.sg/content/stb/en/footer/feedback.html";
export const WEB_PORTAL_STB = "https://www.stb.gov.sg/";
export const WEB_PORTAL_SG_GOV = "https://www.gov.sg";
export const WEB_PORTAL_VISIT_SG = "https://www.visitsingapore.com/en/";
export const WEB_COMMON_BANK_CODE = "https://www.uob.com.sg/assets/pdfs/global/achcode.pdf";
export const WEB_PORTAL_SG_TOURISM_ANALYTIC = "https://stan.stb.gov.sg";

export class HttpStatus {
    public static BAD_REQUEST = 400;
    public static UNAUTHORIZED = 401;
    public static FORBIDDEN = 403;
    public static UNAVAILABLE = 503;
    public static CONFLICT = 409;
    public static INTERNAL_SERVER_ERROR = 505;
}

export class SgdrmAddressFieldsSize {
    public static BLOCK = 10;
    public static STREET = 32;
    public static FLOOR = 3;
    public static UNIT = 5;
    public static BUILDING = 66;
    public static POSTAL = 6;
}

export class SgdrmEmailFieldsSize {
    public static LOCAL = 64;
    public static ATSIGN = 1;
    public static DOMAIN = 255;
    public static FULL = 320;
}
export class SgdrmPhoneFieldsSize {
    public static FULL = 16;
}

/* session time out countdown */
export const COUNTDOWN_INIT = 5; // 5 mins before session expired,
export const SESSION_EXPIRING: number = 0;
export const SESSION_EXPIRED: number = 1;
export const MAX_FILE_SIZE = 20971520;
export const MIN_FILE_SIZE = 92165;

/*            payment            */
export class eNets {
    public static URL = environment.eNetsUrl;
    public static URL_AEM_RETURN = environment.eNetsReturnUrl + '1';//payment-result
    public static URL_TA_RETURN = environment.eNetsReturnUrl + '2';//ta-payment-result
    public static URL_TACDD_RETURN = environment.eNetsReturnUrl + '3';//ta-application-payment-result
    public static URL_TG_RETURN = environment.eNetsReturnUrl + '4';//tg-payment-result
    public static URL_TG_CAND_RETURN = environment.eNetsReturnUrl + '5';//tg-cand-payment-result
}

export class PaymentRequestTypes {
    public static PAYREQ_TA_CREATION_A = "PAYREQ_TA_CREATION_A";
    public static PAYREQ_TA_CREATION_L = "PAYREQ_TA_CREATION_L";
    public static PAYREQ_TA_REPLACEMENT = "PAYREQ_TA_REPLACEMENT";
    public static PAYREQ_TA_RENEWAL = "PAYREQ_TA_RENEWAL";


    public static PAYREQ_TG_RENEWAL = "PAYREQ_TG_RENEWAL";
    public static PAYREQ_TG_REINSTATEMENT = "PAYREQ_TG_REINSTATEMENT";
    public static PAYREQ_TG_APP_REPLACEMENT = "PAYREQ_TG_APP_REPLACEMENT";
    public static PAYREQ_TG_CREATION = "PAYREQ_TG_CREATION";
    public static PAYREQ_TG_PARTICULAR_UPDATE = "PAYREQ_TG_PARTICULAR_UPDATE";
    public static PAYREQ_TG_SWITCH_TIER = "PAYREQ_TG_SWITCH_TIER";
    public static PAYREQ_TG_MLPT = "PAYREQ_TG_MLPT";
    public static PAYREQ_TG_MLPT_REGISTRATION = "PAYREQ_TG_MLPT_REGISTRATION";
    public static PAYREQ_TG_SWITCH_RESIDENTIAL_STATUS = "PAYREQ_TG_CHANGE_RESD";
    public static PAYREQ_TG_ATG_EXAM = "PAYREQ_TG_ATG_EXAM";
}

/*            API URL            */
/* TA */
export class TaApiUrl {
    public static TA_APPLICATION = "/ta/applications";
    public static TA_COMPANY_UPDATES = "/ta/company-updates";
    public static TA_TIER_SWITCH = "/ta/tier-switches";
    public static TA_AA = "/ta/audited-accounts";
    public static TA_KE_UPDATE_DETAILS = "/ta/ke/update-details"
    public static TA_KE_RESIGN = "/ta/ke/resign"
    public static TA_KE_ASSIGN = "/ta/ke/assign"
    public static TA_BRANCH_APPLICATIONS = "/ta/branch-applications";
    public static TA_ABPR_APPLICATIONS = "/ta/abprs";
    public static TA_MAKE_PAYMENT = "/ta/make-payment";
    public static TA_PERSONNEL = "/ta/personnel"
    public static TA_NET_VALUE_RECTIFICATION = '/ta/ta-shortfall-fulfillment';
    public static TA_RNW = "/ta/renewals";
    public static TA_THANK_YOU = "/portal/ta-thankyou";
    public static TA_DASHBOARD = "/portal/dashboard-ta";
    public static TA_ELICENCE_REQUEST = "/ta/elicence-request";
}

export class TaApplicationUrl {
    public static TA_APP_NEW = "/portal/ta-application-form";
    public static TA_APP_CREATION = TaApplicationUrl.TA_APP_NEW;
    public static TA_APP_MAKE_PAYMENT = "/portal/ta-make-payment";
    public static TA_APP_COMPANY_UPDATE = "/portal/ta-change-company-details";
    public static TA_APP_INBOUND_OUTBOUND_SERVICES = "/portal/ta-inbound-outbound-services";
    public static TA_APP_ABPR_SUBMISSION = '/portal/ta-abpr-submission';
    public static TA_APP_AA_SUBMISSION = '/portal/ta-aa-submission';
    public static TA_APP_BRANCH = '/portal/ta-application-branch-licence';
    public static TA_APP_TIER_SWITCH = '/portal/ta-switch-tier';
    public static TA_APP_REPLACEMENT = '/portal/ta-replace-licence';
    public static TA_APP_CESSATION = '/portal/ta-cease-licence';
    public static TA_APP_FY_UPDATE = '/portal/ta-change-fye';
    public static TA_APP_KE_UPD_DETAILS = '/portal/ta-manage-ke-update';
    public static TA_APP_KE_REASSIGN = '/portal/ta-manage-ke-assign';
    public static TA_APP_KE_ASSIGN = '/portal/ta-manage-ke-assign';
    public static TA_APP_KE_RESIGN = '/portal/ta-manage-ke-resign';
    public static TA_APP_RENEWAL = '/portal/ta-renew-licence';
    public static TA_APP_MA_SUBMISSION = '/portal/ta-ma-submission';
    public static TA_APP_ADHOC_MA_SUBMISSION = '/portal/ta-ma-submission';
    public static TA_APP_NET_VALUE_RECTIFICATION = '/portal/ta-shortfall-fulfilment';
    public static TA_APP_ADHOC_DOC_SUBMISSION = '/portal/ta-doc-submission';
    public static TA_APP_ELICENCE_REQUEST = '/portal/ta-e-licence-request';
}

export class TaApplicationUrlMap {
    public static ['TA_APP_RENEWAL'] = '/portal/ta-renew-licence';
}

/* TG */
export class TgModule {
    public static TG_MODULE_CREATIONS = "creations";
    public static TG_MODULE_PARTICULARS = "particulars";
    public static TG_MODULE_REPLACE = "replace";
    public static TG_MODULE_RENEWAL = "licence-renewals";
    public static TG_MODULE_CANCEL = "cancel";
    public static TG_MODULE_MLPT = "mlpt";
    public static TG_MODULE_SWITCH_TIER = "switch-tier";
    public static TG_MODULE_STIPEND = "stipend";
}

export class TgAPiUrl {
    public static TG = "/tg";
    public static TG_CREATION = "/tg/creations";
    public static TG_RENEWAL = "/tg/licence-renewals";
    public static TG_ASSIGNMENT = "/tg/assignments";
    public static TG_PARTICULARS = "/tg/particulars";
    public static TG_CANCEL = "/tg/cancel";
    public static TG_REPLACE = "/tg/replace";
    public static TP_PDC = "/tp/pdc";
    public static TP_MRC = "/tp/mrc";
    public static TG_CSE = "/tg/course";
    public static TG_CSES = "/tg/courses";
    public static TG_MLPT = "/tg/mlpt/registration";
    public static TG_DASHBOARD = "/dashboard/tg";
    public static TG_SWITCH_TIER = "/tg/candidates/switch-tier"
    public static TG_TRAINING_PROVIDER = "/tg/training-provider";
    public static TG_COURSE_RENEWAL = "/tg/course-renewal";
    public static TG_COURSE_CREATION = "/tg/course-creation";
    public static TG_STIPEND = "/tg/stipend";
}

export class TgApplicationUrl {
    public static TG_APP_SUCCESS = "/portal/tg/application-success";
    public static TG_APP_SUCCESS_CREATIONS = TgApplicationUrl.TG_APP_SUCCESS + "/" + TgModule.TG_MODULE_CREATIONS;
    public static TG_APP_SUCCESS_PARTICULARS = TgApplicationUrl.TG_APP_SUCCESS + "/" + TgModule.TG_MODULE_PARTICULARS;
    public static TG_APP_SUCCESS_REPLACE = TgApplicationUrl.TG_APP_SUCCESS + "/" + TgModule.TG_MODULE_REPLACE;
    public static TG_APP_SUCCESS_RENEWAL = TgApplicationUrl.TG_APP_SUCCESS + "/" + TgModule.TG_MODULE_RENEWAL;
    public static TG_APP_SUCCESS_MLPT = TgApplicationUrl.TG_APP_SUCCESS + "/" + TgModule.TG_MODULE_MLPT;
    public static TG_APP_SUCCESS_SWITCH_TIER = TgApplicationUrl.TG_APP_SUCCESS + "/" + TgModule.TG_MODULE_SWITCH_TIER;
    public static TG_APP_SUCCESS_STIPEND = TgApplicationUrl.TG_APP_SUCCESS + "/" + TgModule.TG_MODULE_STIPEND;

    public static TG_APP_CREATION = "/portal/tg/application-form/";
    public static TG_APP_RENEWAL = "/portal/tg/renewal-form";
    public static TG_APP_REINSTATEMENT = "/portal/tg/renewal-form";
    public static TG_APP_PERSON_UPDATE = "/portal/tg/particulars/view/";
    public static TG_APP_CANCELLATION = "/portal/tg/cancel-form/";
    public static TG_APP_REPLACEMENT = "/portal/tg/lost-licence-form/";
    public static TG_APP_MLPT = "/portal/tg/apply-mlpt/";
    public static TG_APP_SWITCH_TIER = "/portal/tg/switch-tier/";
    public static TG_APP_STIPEND = "/portal/tg/stipend-form/";

    public static TG_THANK_YOU = "/portal/tg-thankyou";
    public static TG_DASHBOARD = "/portal/dashboard-tg";
}

export class TpModule {
    public static TP_MODULE_CREATION = "course-creation";
    public static TP_MODULE_RENEWAL = "course-renewal";
}

export class TpApplicationUrl {
    public static TP_APP_SUCCESS = "portal/tp-application-success/";
    public static TP_APP_SUCCESS_COURSE_CREATION = TpApplicationUrl.TP_APP_SUCCESS + "/" + TpModule.TP_MODULE_CREATION;
    public static TP_APP_SUCCESS_COURSE_RENEWAL = TpApplicationUrl.TP_APP_SUCCESS + "/" + TpModule.TP_MODULE_RENEWAL;

    public static TP_APP_CREATION = "/portal/tp-pdc-courses/new/";
}

/* common */
export class commonApiUrl {
    public static COMMON_APPLICATION = "/common";
}

export class TaAppType {
    public static TA_KE_ASSIGN = "TA_KE_ASSIGN"
    public static TA_APP_KE_REASSIGN = "TA_APP_KE_REASSIGN"
    public static TA_APP_NET_VALUE_RECTIFICATION = "TA_APP_NET_VALUE_RECTIFICATION"
}

export class TgAppType {
    public static TG_APP_CREATION = "TG_APP_CREATION";
    public static TG_APP_RENEWAL = "TG_APP_RENEWAL";
}

export class TaAnnualFilingStatus {
    public static TA_FILING_PS = "TA_FILING_PS";
    public static TA_FILING_PA = 'TA_FILING_PA';
    public static TA_FILING_RFA = 'TA_FILING_RFA';
    public static TA_FILING_LATE = 'TA_FILING_LATE';
    public static TA_FILING_APPR = 'TA_FILING_APPR';
}

/*            message            */
/* TA */
export const TA_DECLARE_TEXT = '<span class="note"> I, hereby declare that the information provided in this submission is, to the best of my knowledge true and complete. ' +
    'I understand that I and/or the Business may be liable to criminal prosecution in respect of any statement made or information furnished by me that is known or ought reasonable known to be false, or misleading by omission, in respect of any material particular.<br><br>' +
    'I acknowledge the requirement specified in Section 13 of the Travel Agents Act (Cap. 334), wherein is stated that any person who, in connection with any application for the grant or renewal of a licence, or for any other purpose under the Travel Agents Act or the Travel Agents Regulations 2017, makes any statement or furnishes any information to the Board or an officer of the Board that the person knows, or ought reasonably to know, is false or misleading (including by reason of any omission) in any material particular, shall be guilty of an offence.</span>';

export const TA_DECLARE_SUBMIT = '<span class="thick">I,</span> on behalf of the licensee, declare that I am authorised to act for the Business for the purposes of this submission.<br><br>' + TA_DECLARE_TEXT;

export const TA_DECLARE_CHECK = 'I have read and understood the declaration.';

export const TA_DECLARE_ACK_INFRINGEMENT_CHECK = 'I have acknowledged the contraventions listed.';

export class TaAlertMessages {
    public static APP_DRAFT_SAVED = "Draft Saved";
    public static MY_INFO_ERROR = "MyInfo is unavailable now, please key in particulars manually or try again later";
    public static EDH_ERROR = "ACRA is unavailable now.<br>We are currently experiencing unusually high traffic. Please try again later. We are sorry for the inconvenience caused.";
    public static ONEMAP_ERROR = "OneMap services is unavailable to provide with address, please enter block/house no. and street name manually";
    public static COMING_SOON = "Coming Soon";
}

export class TaInfoMessages {
    public static MY_INFO = "Click to auto populate personal particulars from MyInfo (Coming Soon)";
    public static MY_INFO_CLEAR = "Click to clear personal particulars from MyInfo and input personal particulars manually";
}

export class TaValidationMessages {
    public static MIN_PERCENT = "Minimum value is 0";
    public static MAX_PERCENT = "Maximum value is 100";
    public static SUM_INBOUND_OPERATIONS = "Sum of all inbound operations should be 0% or 100%";
    public static SUM_OUTBOUND_OPERATIONS = "Sum of all outbound operations should be 0% or 100%";
    public static DUPLICATED_VALUES = "Duplicate values are not allowed";
    public static DIGIT_LENGTH = 'Max numerical amount is 16 digits'
    public static REQUIRED = "Mandatory field";
    public static EDH_REQUIRED = "Mandatory field, please update with ACRA";
    public static DATE_BEFORE_MIN = "Date input is before the minimum date allowed";
    public static DATE_AFTER_MAX = "Date input is after the maximum date allowed";
}

export class TaTierSwitchValidationMessages {
    public static IN_OR_OUT_REQ = "Either inbound or outbound operation percentage should be greater than 0%";

}

export class TaBranchApplicationErrorMessage {
    public static TA_INVALID_MAX_LENGTH_255 = "Input cannot be more than 255 characters (Max. 255)";

    public static TA_INVALID_START_GREATER_END_DATE = "Start date should be less than end date";
    public static TA_INVALID_START_EQUAL_END_DATE = "Start date and end date should not be on the same day";

    public static TA_INVALID_POSTAL_CODE_NUMBER = "Postal code is invalid";
    public static TA_INVALID_POSTAL_CODE_NOT_FOUND = "Postal code not found in Singapore";
    public static TA_INVALID_POSTAL_CODE_LENGTH = "Postal code is 6-digit code";
    public static TA_INVALID_POSTAL_CODE_2_HOUSE_NO = "Postal code and block/house no. does not match";
    public static TA_INVALID_POSTAL_CODE_2_STREET = "Postal code and street does not match";
}

export class TaABPRErrorMessage {
    public static TA_MAX_AMOUNT_LENGTH = 'Max numerical amount is 16 digits'
    public static TA_MAX_INTEGER_LENGTH = 'Max numerical amount is 9 digits'

    public static TA_INVALID_NICHE_BUSINESS_TYPE = "Niche licence cannot do accommodation and air ticketing business type";
    public static TA_INVALID_NICHE_OUTBOUND = "Niche licence cannot do outbound business";
    public static TA_MISSING_ROWS = "Rows should not be empty";
    public static TA_MISSING_TOTAL_INBOUND = "Total inbound % cannot be empty";
    public static TA_MISSING_TOTAL_OUTBOUND = "Total outbound % cannot be empty";
    public static TA_MISSING_BUSINESS = "Mandatory field";
    public static TA_MISSING_FOCUS = "Mandatory field";
    public static TA_MISSING_ANSWER = "Mandatory field";
    public static TA_INVALID_ANSWER = "Yes is not allowed if amount is 0";
    public static TA_INVALID_INBOUND_ANSWER = "As your inbound operations was indicated as 0% in the previous section, selection should be empty or 'No'";
    public static TA_INVALID_OUTBOUND_ANSWER = "As your outbound operations was indicated as 0% in the previous section, selection should be empty or 'No'";
    public static TA_MISSING_BOTH_CHECKBOXES = "Select a checkbox";
    public static TA_MISSING_COUNTRY = "Mandatory field";
    public static TA_MISSING_PERCENTAGE = "Mandatory field";
    public static TA_REPEATED_BUSINESS = "Duplicate values is not allowed";
    public static TA_NOT_MATCHED_PERCENTAGE_INBOUND_OUTBOUND = "Inbound and outbound operations should add up to be 100%";

    public static TA_NOT_MATCHED_PERCENTAGE_INBOUND_OPERATIONS = "Sum of all source countries' inbound operations should be 100%";
    public static TA_NOT_MATCHED_PERCENTAGE_OUTBOUND_OPERATIONS = "Sum of all destination countries' outbound operations should be 100%";
    public static TA_NOT_MATCHED_ZERO_INBOUND = "Inbound percentage should be 0 when outbound is 100%";
    public static TA_NOT_MATCHED_ZERO_OUTBOUND = "Outbound percentage should be 0 when inbound is 100%";
    public static TA_NOT_MATCHED_ZERO_INBOUND_OPERATIONS = "Values in this section should be 0 when inbound operations is 0%";
    public static TA_NOT_MATCHED_ZERO_OUTBOUND_OPERATIONS = "Values in this section should be 0 when outbound operations is 0%";
    public static TA_REQUIRE_INBOUND_OPERATIONS = "Inbound value is mandatory when inbound operations > 0%";
    public static TA_REQUIRE_OUTBOUND_OPERATIONS = "Outbound value is mandatory when outbound operations > 0%";
    public static TA_NOT_MATCHED_ZERO_INBOUND_OPERATIONS_CHECKBOX = "Inbound checkbox should be unchecked when inbound operations is 0%";
    public static TA_NOT_MATCHED_ZERO_OUTBOUND_OPERATIONS_CHECKBOX = "Outbound checkbox should be unchecked when outbound operations is 0%";
    public static TA_NOT_MATCHED_TRUE_INBOUND_OPERATIONS_CHECKBOX = "Inbound checkbox mandatory as your inbound operation > 0%";
    public static TA_NOT_MATCHED_TRUE_OUTBOUND_OPERATIONS_CHECKBOX = "Outbound checkbox mandatory as your outbound operation > 0%";
}

/* TG */
export class TgCommonErrorMessage {
    public static INPUT_REQUIRED = "Input required";
    public static INVALID_POSTAL_CODE = "Invalid postal code";
    public static INPUT_LENGTH_MIN_6 = "Input too short (Min. 6)";
    public static INPUT_LENGTH_8 = "Input only allowed 8 characters";
    public static INVALID_MOBILE_NO = "Invalid mobile no.";
    public static INVALID_EMAIL = "Email is not in the correct format";
    public static INPUT_LENGTH_MAX = "Input too long (Max. " + maxLengthStr + ")";
    public static INVALID_NAME = "Invalid name";
    public static INVALID_SCORE = "Invalid score";
    public static INVALID_MAX_SCORE = "Max score is not allowed to be smaller than score"
    public static INVALID_LICENCE_NO = "Invalid licence no.";
    public static INVALID_PHOTO_DIMENSION = "Photo width and height has to be 400px and 514px respectively";
    public static INVALID_PHOTO_RESOLUTION = "Minimum photo resolution has to be 96dpi";
    public static MIN_PHOTO_SIZE = "Minimum file size has to be 90KB";
    public static MAX_PHOTO_SIZE = "Uploaded file size cannot exceed 1MB";
    public static INPUT_NUMBER_ONLY = "Input only allowed numbers";
}

export class TgCommonMessage {
    public static AMOUNT_PAID = "Amount to be paid: S$";
    public static CONFIRM_PAYMENT = "Confirm and make payment";
}


export class TgLicenceReplacementErrorMessage {
    public static POLICE_REPORT_REQUIRED = "Please upload police report";
}

export class TgLicenceRenewalErrorMessage {
    public static MED_65_REQUIRED = "Please upload medical report";
    public static WORK_PASS_REQUIRED = "Please upload work pass";
    public static SUPPORTING_DOC_REQUIRED = "Please upload supporting document(s)";
    public static PHOTO_REQUIRED = "Please upload photo";
    public static PHOTO_EXTENSION = "Allowable photo extensions: jpg,jpeg,gif,png";
}

export class TpErrorMessage {
    public static DUP_LICENCE_NO = "Duplicate licence no";
}

/* common */
export class Messages {
    public static ERR_MSG_GENERIC = "System error occurred. Please provide a screen shot and contact administrator at 6736 6622 or email at STB_TA@STB.GOV.SG (TA) or STB_TOURIST_GUIDE@STB.GOV.SG (TG). Operating hours are 8.00am to 8.00pm, Monday to Friday excluding Public holidays and weekends.";
    public static GENERIC_CONFIRM = "Are you sure you wish to continue?";
    public static GENERIC_PREVIEW = "Preview";
    public static GENERIC_SUCCCESS = "Changes saved successfully. ";
    public static MSG_INCOMPLETE_FORM = "Please check the values for all mandatory fields.";
    public static MSG_ERROR_DRAFT = "Please check max length and email format";
    public static MSG_DECLARATION_CHECK = "Please read and check declaration for submission";
    public static MSG_INVALID_ACCESS = "You are not allowed to access this function. Please verify your licence status is Active.";
    public static MSG_NO_RECORDS = "No records found.";
    public static MSG_NO_FILE = "No File found.";
    public static MSG_NO_SELECTED_RECORDS = "Please select at least one record.";
    public static MSG_PREVIEW_EDIT = "You may amend any incorrect data by clicking on the 'back' button below";
    public static MSG_STEPPER_EDIT = "Click on the step number to navigate between different steps.";
    public static MSG_OTHER_DOC = "Please name your documents clearly before uploading";
    public static MSG_MIN_SELECTION = "Please select at least one option";
    public static MSG_MIN_DOC = "Either Latest Bank Statement or Directors' Resolution needs to be uploaded";
    public static MSG_UPLOAD_DOC = "Please upload at least one document.";
    public static PAYNOW_TIMEOUT_MESSAGE = "if you have made a successfully payment, please do not retry and provide a screen shot and contact administrator at 6736 6622 or email at STB_TA@STB.GOV.SG (TA) or STB_TOURIST_GUIDE@STB.GOV.SG (TG). Operating hours are 8.00am to 8.00pm, Monday to Friday excluding Public holidays and weekends.";

}

export class commonErrorMessages {
    public static require = "Input required";
    public static maxLength = "Input too long (Max. " + maxLengthStr + ")";
    public static maxDigitLength = 'Max numerical amount is 16 digits'
    public static minValue = "Input too small (Min. 0)";
    public static startGreaterEndDate = "Start date must not be after end date";
    public static invalidHour = "Input must be smaller or equal to 24 hours";
    public static noAddress = "Enter the address here";
    public static maxBlockLength = "Input too long (Max. " + SgdrmAddressFieldsSize.BLOCK + ")";
    public static maxStreetLength = "Input too long (Max. " + SgdrmAddressFieldsSize.STREET + ")";
    public static maxFloorLength = "Input too long (Max. " + SgdrmAddressFieldsSize.FLOOR + ")";
    public static maxUnitLength = "Input too long (Max. " + SgdrmAddressFieldsSize.UNIT + ")";
    public static maxPostalLength = "Input too long (Max. " + SgdrmAddressFieldsSize.POSTAL + ")";
    public static maxBuildingLength = "Input too long (Max. " + SgdrmAddressFieldsSize.BUILDING + ")";
    public static invalidEmailFormat = "Email is not in the correct format";
    public static invalidEmailLength = "Email length is wrong (Max. Local: " + SgdrmEmailFieldsSize.LOCAL + ", At Sign: " + SgdrmEmailFieldsSize.ATSIGN + ", Domain: " + SgdrmEmailFieldsSize.DOMAIN + ")";
    public static maxEmailLength = "Input too long (Max. " + SgdrmEmailFieldsSize.FULL + ")";
    public static onlyAlphaNumericPattern = "Input cannot contain special characters";
    public static onlyNumericPattern = "Input only allow numeric";
    public static maxPhoneLength = "Input too long (Max. " + SgdrmPhoneFieldsSize.FULL + ")";
    public static invalidAddressInput = "NA, NIL or - values are not accepted. Please leave blank if there is no value";
    public static invalidAddressInputRequired = "NA, NIL or - values are not accepted.";
}

/*            status            */
export class ApplicationStatuses {
    // @Deprecated
    //public static TA_APP_PENDING_APPROVAL = "TA_APP_PA"; 
    public static TA_APP_PENDING_PO = "TA_APP_PEND_PO";
    public static TA_APP_PENDING_VO = "TA_APP_PEND_VO";
    public static TA_APP_PENDING_AO = "TA_APP_PEND_AO";
    public static TA_APP_PENDING_HOD = "TA_APP_PEND_HOD";
    public static TA_APP_PENDING_HODIV = "TA_APP_PEND_HODIV";
    public static TA_APP_PENDING_OA = "TA_APP_P_OA";
    public static TA_APP_APPROVED = "TA_APP_APPR";
    public static TA_APP_RFA = "TA_APP_RFA";
    public static TA_APP_REJECTED = "TA_APP_REJ";
    public static TA_APP_NEW = "TA_APP_NEW";
    public static TA_APP_DRAFT = "TA_APP_DRAFT";
    public static TA_APP_PENDING_KE = "TA_APP_P_KE";

    public static TG_APP_PENDING_APPROVAL = "TG_APP_PA";
    public static TG_APP_PENDING_PO = "TG_APP_PEND_PO";
    public static TG_APP_PENDING_AO = "TG_APP_PEND_AO";
    public static TG_APP_PENDING_HODIV = "TG_APP_PEND_HODIV";
    public static TG_APP_APPROVED = "TG_APP_APPR";
    public static TG_APP_RFA = "TG_APP_RFA";
    public static TG_APP_REJECTED = "TG_APP_REJ";

}

/*            types            */
export class DocumentTypes {
    public static TA_DOC_BANK = "TA_DOC_BANK";
    public static TA_DOC_KE_RESUME = "TA_DOC_KE_RESUME";
    public static TA_DOC_CEASE_DIRECTOR_RESOLUTION = "TA_DOC_CEASE_DIRECTOR_RESOLUTION";
    public static TA_DOC_CFYE_DIRECTOR_RESOLUTION = "TA_DOC_CFYE_DIRECTOR_RESOLUTION";
    public static TA_DOC_POLICE_REPORT = "TA_DOC_POLICE_REPORT";
    public static TA_DOC_MGMT_ACC = "TA_DOC_MGMT_ACC";
    public static TA_DOC_AUDIT_REPORT = "TA_DOC_AUDIT_REPORT";
    public static TA_DOC_OTHERS = "TA_DOC_O";
    public static TA_DOC_BRANCH = "TA_DOC_BRANCH";
    public static TA_DOC_KE_RESIGN_LETTER = "TA_DOC_KE_RESIGN_LETTER";
    public static TA_DOC_KE_DIR_RESOLUTION = "TA_DOC_KE_DIR_RESOLUTION";
    public static TA_DOC_KE_NRIC = "TA_DOC_KE_NRIC";
    public static TA_DOC_BEOC = "TA_DOC_BEOC";
    public static TA_DOC_TENANCY = "TA_DOC_TENANCY";
    public static TA_DOC_HOS_APPROVAL = "TA_DOC_HOS_APPROVAL";
    public static TA_DOC_CBS = "TA_DOC_CBS";
    public static TA_DOC_MANAGEMENT_ACCOUNTS = "TA_DOC_MANAGEMENT_ACCOUNTS";
    public static TA_DOC_REC_DIRECTOR_RESOLUTION = "TA_DOC_REC_DIRECTOR_RESOLUTION";
    public static TA_DOC_REC_BANK_STATEMENT = "TA_DOC_REC_BANK_STATEMENT";
    public static TA_DOC_ACRA_BIZ = "TA_DOC_ACRA_BIZ";
    public static TA_DOC_ADHOC_DOC = "TA_DOC_ADHOC_DOC";

    public static TG_DOC_MEDICAL_65 = "TG_DOC_MED";
    public static TG_DOC_PASSPORT_PHOTO = "TG_DOC_PHOTO";
    public static TG_DOC_POLICE_REPORT = "TG_DOC_POLICE";
    public static TG_DOC_WORK_PASS = "TG_DOC_WP";
    public static TG_DOC_OTHERS = "TG_DOC_O";
    public static TG_DOC_STIPEND = "TG_DOC_STIPEND";

}

/* TA */
export const TaCessationOtherReason = 'TA_RESN_CEASE_O';
export const TaReplacementOtherReason = 'TA_RESN_REPLACE_O';
export const TaReplacementLostReason = 'TA_RESN_REPLACE_L';

export class BusinessConstitution {
    public static BC_SOLE = "BC_S";
    public static BC_PARTNERS = "BC_P";
}

export class StakeholderRoles {
    public static STKHLD_SHAREHOLDER = "STKHLD_SH";
    public static STKHLD_KE = "STKHLD_KE";
}

export class TaStatuses {
    public static ACTIVE = ['TA_A', 'TA_PS', 'TA_I', 'TA_PR', 'TA_S', 'TA_PRN'];
    public static INACTIVE = ['TA_C', 'TA_L'];
    public static SUSPEND = ['TA_S'];
    public static REVOKED = ['TA_R'];
    public static PENDING_RENEWAL = "TA_PRN";
}

export class TaAbprTooltip {
    public static EMPLOYMENT = '<b>Employment</b> number includes only <br><br>  1. paid employee - full time <br>  2. working directors <br>  3. working proprietor/partners';
    public static OPERATING_COST = '<b>Operating Cost Incurred</b> includes :<br><br>\
     1.	work given out (for work performed on behalf of the establishment with or without basic materials supplied),<br>\
     2.	commission & agency fees on services rendered,<br>\
      3.	repairs & maintenance of premises,<br>\
     4.	servicing & repairing of machinery & equipment,<br>\
     5.	upkeep of vehicles in terms of road tax, petrol, servicing & others,<br>\
     6.	royalties and franchise fees paid,<br>\
      7.	printing, stationery, newspapers & office supplies,<br>\
      8.	utilities charges,<br>\
     9.	charter of vehicles,<br>\
     10.	rental of machinery & equipment,<br>\
     11.	group tour expenditure: inbound, outbound,<br>\
     12.	cost of air tickets sold by travel agents,<br>\
     13.	postage, telephone, telegram, telex, pager & telefax,<br>\
     14.	transport & travelling expenses,<br>\
     15.	banking & other financial charges,<br>\
     16.	insurance premium excluding workmen compensation,<br>\
     17.	accounting, auditing, legal & professional services,<br>\
     18.	computer information consultancy, software development & other information technology professional services (exclude the purchase of computer software),<br>\
     19.	advertisement, publicity & promotional expenses,<br>\
     20.	administration & management fees<br>\
     21.	entertainment expenses';
    public static REMUNERATION = '<b>Remuneration</b> includes :<br><br>\
    1.	wages & salaries including bonuses & allowances paid to employees (full time and part time) and working directors,<br>\
    2.	employers contribution to Central Provident Fund/pension fund paid to employees (full time and part time) and working directors,<br>\
    3.	other benefits including food, medical & housing benefits paid to employees (full time and part time), working directors and unpaid family workers,<br>\
    4.	insurance premium for persons engaged in Singapore.<br><br>\
    and excludes :<br>\
    1.	gratuity paid to retired employees,<br>\
    2.	benefits paid to sleeping directors/partners,<br>\
    3.	contribution to Skills Development Fund<br>\
    4.	wages & salaries and other benefits paid to employees posted overseas for one year and over.';
    public static INDIRECT_TAX = '<b>Indirect Taxes</b> include property tax & stamp duties but exclude Additional Registration Fee (ARF).';
    public static MARKET_SPECIALISATION = 'Inbound Market Specialisation denotes the countries that passengers come from into Singapore and Outbound Market Specialisation specifies the countries that passengers depart for from Singapore.';
    public static PASSENGERS_HANDLED = 'This form is divided into 2 categories; passengers handled either in Groups or for Free and Independent Travellers (FITs). Please fill in the total number of passengers handled for Group tours and FITs for both the Inbound and Outbound traffic. For example, you have arranged for 2000 passengers coming to Singapore for a 3D/2N tour and have arranged accommodation for 500 FIT passengers in Singapore, then you have 2000 and 500 for Group and FITs respectively under the Inbound category.';
    public static BUSINESS_OPERATIONS = 'Your total business operation is made up of your Inbound and Outbound business calculated from the previous section. For example, if your Inbound business constitutes 50% of your total business operation, then your Outbound business will constitute the other 50%. If your company focuses only in the Inbound segment, then your Inbound business constitutes 100% of your total business operation.';
    public static ABPR = 'Please indicate your annual business profile returns for each of the travel service that your company offers. For example, if your company offers 2 travel services, accommodation and air ticketing to the Inbound segment and they make up S$40,000 and S$60,000 in turnover respectively, please select ‘accommodation’ and ‘air ticketing’ and fill in the amount under the Inbound Operations section. ';

    public static TA_FUNC_ACT_1 = 'Please indicate a Yes if you promote or sell travel services such as air tickets, travel insurance or tour packages that were provided by other suppliers such as the airlines, hotels or other tour operators.';
    public static TA_FUNC_ACT_2 = 'Please indicate a Yes if you arrange and put together 2 or more travel services such as air ticket, accommodation and transfers into a single package and sell it to a consumer (regardless whether the consumer is billed separately for each service).';
    public static TA_FUNC_ACT_3 = 'Please indicate a Yes if you arrange and put together a tour such as a sightseeing tour to Chinatown or a shopping tour in Orchard Road in Singapore and sell it to a consumer.';
}

export class TaKeApplicationTooltip {
    public static APPOINTED_DATE = 'Travel agents are required to have another person appointed or act as key executive officer within 3 months after the vacancy arises.';
}
/* TG */
export class TgAssignmentTypes {
    public static tourTypeOther = "TG_TOUR_O";
    public static empSrcTypeOther = "TG_EMP_O";
}

export class TgCommonTypes {
    public static ATTENDANCE_ABSENT = "TP_ATN_ABS";
    public static ATTENDANCE_ATTENDED = "TP_ATN_ATN";
    public static TG_OCCUPATION = "OCCP_O";
    public static TG_AREA = "TG_TIER_A";
    public static TG_GENERAL_AREA = "TG_TIER_GA";
    public static TG_TAXI = "TG_TIER_T";
}

export class WorkflowActionTypes {
    public static WKFLW_ACT_FOLLOW_UP = "WKFLW_ACT_FOLLOW_UP";
}

export class renewalStatusCode {
    public static renewalBlank = "RENEWAL_BLANK";
    public static renewalTick = "RENEWAL_TICK";
    public static renewalGrey = "RENEWAL_GREY";
    public static renewalGreyTemp = "RENEWAL_GREY_TEMP"; //not yet due for renewal
    public static renewalHide = "RENEWAL_HIDE";
}

export class renewalConditions {
    public static RENEWAL_MRC = "RENEWAL_MRC";
    public static RENEWAL_PDC = "RENEWAL_PDC";
    public static RENEWAL_ASSIGNMENTS = "RENEWAL_ASSIGNMENTS";
    public static RENEWAL_CPF = "RENEWAL_CPF";
    public static RENEWAL_NEW_PHOTO = "RENEWAL_NEW_PHOTO";
    public static RENEWAL_MEDICAL_REPORT = "RENEWAL_MEDICAL_REPORT";
    public static RENEWAL_WORK_PASS = "RENEWAL_WORK_PASS";
    public static RENEWAL_LICENCE_FEE = "RENEWAL_LICENCE_FEE";
    public static RENEWAL_ASSESSMENT = "RENEWAL_ASSESSMENT";
}

export class LicenceRenewalStatus {
    public static RENEWAL = "TG_RENEWAL";
    public static REINSTATE = "TG_REINSTATE";
    public static OVERDUE = "TG_OVERDUE";
    public static REINSTATE_B4_3YR = "TG_REINSTATE_B4_3YR";
    public static REINREINSTATE_AF_3YRSTATE = "TG_REINSTATE_AF_3YR";
}
export class renewalStatusUrl {
    public static renewalBlank = "assets/images/icon-renewal.png";
    public static renewalTick = "assets/images/icon-renewal-tick-green.png";
    public static renewalGrey = "assets/images/icon-renewal-gray.png";
}

export class printStatusCode {
    public static PRINT_PENDING_COLLECTION = "PRINT_PC";
}

export class TgFees {
    public static mlptFee = 50;
}

export class TgCommonStatuses {
    public static TG_CANDIDATE_RESULT_COMPETENT = "TG_CANDIDATE_RESULT_COMPETENT";
    public static TG_MLPT_COMPETENT = "TG_MLPT_COMP";
    public static TG_MLPT_ALLOCATION_DRAFT = "TG_MLPT_ALLOC_DRAFT";
    public static TG_MLPT_ALLOCATION_PUBLISHED = "TG_MLPT_ALLOC_PUB";
}

/* TP */
export class TpCourseTypes {
    public static pdc = "TP_CSE_P";
    public static mrc = "TP_CSE_M";
}

/* common */
export class PremisesTypes {
    public static PREM_HO = "PREM_HO";
}

export class AddressTypes {
    public static ADDR_FOREIGN = "ADDR_F";
    public static ADDR_LOCAL = "ADDR_L";
}

export class CommonRoles {
    public static TG_PUBLIC = "TG_PUB";
    public static TP_PUBLIC = "TP_PUB";
    public static TG_CANDIDATE = "TG_CDD";
    public static TA_PUBLIC = "TA_PUB";
    public static TA_CANDIDATE = "TA_CDD";
}

export class PaymentStatuses {
    public static PAYREQ_NOT_PAID = "PAYREQ_N";
    public static PAYREQ_PAID = "PAYREQ_P";
    public static PAYREQ_SETTLED = "PAYREQ_S";
    public static PAYREQ_VOID = "PAYREQ_V";
    public static PAYREQ_WAIVED = "PAYREQ_W";
    public static PAYREQ_PENDING_PAYMENT = "PAYREQ_PD";
    public static PAYREQ_DISBURSED = "PAYREQ_DISBURSED";
    public static PAYREQ_PENDING_TG = "PAYREQ_PEND_TG";
}

export class PaymentTxnStatuses {
    public static PAYTXN_P = "PAYTXN_P";
    public static PAYTXN_S = "PAYTXN_S";
    public static PAYTXN_F = "PAYTXN_F";
    public static PAYTXN_T = "PAYTXN_T";
    public static PAYTXN_V = "PAYTXN_V";
}


export class MyInfoFields {
    public static UINFIN = "uinfin";
    public static NAME = "name";
    public static ALIAS_NAME = "aliasName";
    public static DOB = "dob";
    public static CTY_BIRTH = "birthCountry";
    public static SEX = "sex";
    public static RACE = "race";
    public static NATIONALITY = "nationality";
    public static BIRTHCOUNTRY = "birthCountry";
    public static RESIDENTIAL_STATUS = "residentialSt";
    public static TG_RESIDENTIAL_STATUS = "residentialStatus";
    public static REG_ADD_POSTAL = "regAddPostal";
    public static REG_ADD_BLOCK = "regAddBlock";
    public static REG_ADD_STREET = "regAddStreet";
    public static REG_ADD_BUILDING = "regAddBuilding";
    public static REG_ADD_FLOOR = "regAddFloor";
    public static REG_ADD_UNIT = "regAddUnit";
    public static EDU_LEVEL = "eduLevel";
    public static MOBILE_NO = "mobileNo";
    public static EMAIL = "email";
    public static MAIL_ADD_POSTAL = "mailAddPostal";
    public static MAIL_ADD_BLOCK = "mailAddBlock";
    public static MAIL_ADD_STREET = "mailAddStreet";
    public static MAIL_ADD_BUILDING = "mailAddBuildi";
    public static MAIL_ADD_FLOOR = "mailAddFloor";
    public static MAIL_ADD_UNIT = "mailAddUnit";
    public static MARITAL_STATUS = "maritalStatus";
    // workpass
    public static OCCUPATION = "occupation";
    public static EMPLOYMENT = "employment"; // company name
    public static WORKPASS_STATUS = "workpassStatus";
    public static WORKPASS_EXPIRY_DATE = "workpassExpiryDate";
}

export class AlertStatuses {
    public static READ = "ALERT_R";
    public static UNREAD = "ALERT_U";
    public static DELETED = "ALERT_D";
}

export class TaLicenceTier {
    public static TA_TIER_G = "TA_TIER_G";
    public static TA_TIER_N = "TA_TIER_N";

}

export class dashboardTypeCode {
    public static TA = "TA";
    public static TG = "TG";
    public static TACDD = "TACDD";
    public static TP = "TP";
    public static AEM = "AEM";
}

//Added by Mohd. Alam
export class TouristGuideStatusCode {
    public static TG_A = "Licensed";
    public static TG_I2TG_C = "De-Licensed";
    public static TG_S = "Suspended";
    public static TG_R = "Revoked";
    
}

//Added by Mohd. Alam
export class TouristGuideLanguages
{
   
		public static tgLanguagesMap = new Map<string, string>([
            ["TG_LANG_ARB", "Arabic"],
            ["TG_LANG_BI", "Bahasa Indonesia"],
            ["TG_LANG_BM", "Bahasa Melayu"],
            ["TG_LANG_CZH", "Czech"],
            ["TG_LANG_DAN", "Danish"],
            ["TG_LANG_DTC", "Dutch"],
            ["TG_LANG_ENG", "English"],
            ["TG_LANG_FIN", "Finnish"],
            ["TG_LANG_FRN", "French"],
            ["TG_LANG_GRK", "Greek"],
            ["TG_LANG_GRM", "German"],
            ["TG_LANG_HB", "Hebrew"],
            ["TG_LANG_HND", "Hindi"],
            ["TG_LANG_IND", "Indonesian"],
            ["TG_LANG_ITL", "Italian"],
            ["TG_LANG_JAP", "Japanese"],
            ["TG_LANG_KOR", "Korean"],
            ["TG_LANG_MAL", "Malay"],
            ["TG_LANG_MAN", "Mandarin"],
            ["TG_LANG_MYN", "Myanmar"],
            ["TG_LANG_NOR", "Norwegian"],
            ["TG_LANG_PER", "Persian"],
            ["TG_LANG_POR", "Portuguese"],
            ["TG_LANG_RUS", "Russian"],
            ["TG_LANG_SIN", "Singhalese"],
            ["TG_LANG_SLO", "Slovak"],
            ["TG_LANG_SPN", "Spanish"],
            ["TG_LANG_SWD", "Swedish"],
            ["TG_LANG_THI", "Thai"],
            ["TG_LANG_TML", "Tamil"],
            ["TG_LANG_TUR", "Turkish"],
            ["TG_LANG_UKR", "Ukrainian"],
            ["TG_LANG_VIET", "Vietnamese"],
            ["TG_LANG_YUG", "Yugoslavian"],
    
        ]);      
}

//Added by Mohd. Alam
export class TouristGuideCategories
{
	public static tgCategoryMap = new Map<string, string>([
		["TG_TIER_A", "Area Tourist Guide"],
		["TG_TIER_G", "General Tourist Guide"],
		["TG_TIER_GA", "General & Area Tourist Guide"],
		["TG_TIER_T", "Taxi Tourist Guide"],

	]);
}

//Added by Mohd. Alam
export class TouristGuideAreas
{
	public static tgAreaMap = new Map<string, string>([
		["TG_AREA_ART", "Arts"],
		["TG_AREA_FD", "Food"],
		["TG_AREA_HRT", "Heritage"],
		["TG_AREA_NT", "Nature"],
		["TG_AREA_PA", "Paranormal Activity"]

	]);
}

export class BulletinTypes {
    public static GENERAL = "BULLETIN_GENERAL";
    public static TA = "BULLETIN_TA";
    public static TG = "BULLETIN_TG";
}

export class Codes {
    public static SEX_U = "SEX_U";
    public static NAT_SG = "NAT_SG";
    public static CTRY_SG = "CTRY_SG";
}

export class cpfMedisave {
    public static CPF_MEDISAVE_YES = "CPF_MEDI_Y";
    public static CPF_MEDISAVE_NO = "CPF_MEDI_N";
    public static CPF_MEDISAVE_INVALID = "CPF_MEDI_I";
    public static CPF_MEDISAVE_ERROR = "CPF_MEDI_E";
}

export class SystemParameters {
    public static TG_STIPEND_PREAMBLE_TEXT = 'TG_STIPEND_PREAMBLE_TEXT';
    public static TG_STIPEND_DECLARATION = 'TG_STIPEND_DECLARATION';
}

export class PaymentTypes {
    public static PAYNOW = "PAY_P";
    public static MASTERCARD = "PAY_M";
    public static VISA = "PAY_V";
}

export const amountCurrencyMaskConfig = {
    align: "left",
    allowNegative: true,
    allowZero: true,
    decimal: ".",
    precision: 2,
    prefix: "S$ ",
    suffix: "",
    thousands: ",",
    nullable: true
};

export let defaultOptionsRadio = [{ key: true, label: 'Yes' }, { key: false, label: 'No' }];

export class TaLicenceAppBizWriteUpQns {
    public static Q1 = "Business Idea";
    public static Q2 = "Consumer facing brand (where applicable)";
    public static Q3 = "Marketing and communications plan";
    public static Q4 = "Sales channels";
    public static Q5 = "Financial strategy";
    public static Q6 = "Financial projections for next 2 years";
    public static Q7 = "Competitive edge (if applicable)";
    public static Q8 = "Partners and service providers";
    public static Q9 = "Other business activities";
    public static Q10 = "Focus on Travel Agent business (only if answer to question 9 is 'Yes')";
    public static Q11 = "Has the company applied for / been granted a Travel Agent licence in the past?";
    public static Q12 = "Please provide details of the company's travel agent business when the company was previously licensed (e.g. type of business services provided, target customers etc.) (only if answer to question 11 is 'Yes')";
    public static Q13 = "Relationship with other Travel Agents (if any)";
    public static Q14 = "Others";
}

export class ELicenceDownloadRequest {
    public static RESET = 0;
    public static PENDING_REQUEST = 1;
    public static APPROVE = 2;
    public static REJECT = 3;
    public static NEED_TO_REQUEST = 4;
}

export class ELicenceView {
    public static HIDE = 0;
    public static VIEW = 1;
}