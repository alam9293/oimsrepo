import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';
import { NumeralUtil } from '../helper';
import * as numeral from 'numeral';

/**
 * This directive will format the input value to thousand separator and round up to nearest dollar
 * It is used in TA Audited Account Submission Form
 */
@Directive({
    selector: '[appWizAuditAmount]'
})
export class WizAuditAmountDirective {

    ngOnInit() { }

    constructor(private control: NgControl) { }

    @HostListener('keyup', ['$event']) inputChangedUp(event) {
        var type = this.control.value.charAt(0);
        if ((type === '-' && this.control.value.length < 23)
            || (type != '-' && this.control.value.length < 22)) {
            if (this.control.value && this.control.value != '-') {
                var value = this.control.value;
                value = value.replace(NumeralUtil.SPECIAL_CHAR, "");

                if (value.indexOf('.') >= 0) {
                    var numVal: string = value.split('.')[0];
                    var decVal: string = value.split('.')[1];
                    this.control.control.setValue(numeral(numVal).format(NumeralUtil.THOUSAND_SEPARATOR_FORMAT).concat('.').concat(decVal ? numeral(decVal).format('0') : decVal));
                } else {
                    this.control.control.setValue(numeral(value).format(NumeralUtil.THOUSAND_SEPARATOR_FORMAT));
                }
            }
        }


    }

    @HostListener('keydown', ['$event']) inputChangedDown(event) {
        var type = this.control.value.charAt(0);
        if ((type === '-' && this.control.value.length < 23)
            || (type != '-' && this.control.value.length < 22)) {
            if (this.control.value && this.control.value != '-') {
                var value = this.control.value;
                value = value.replace(NumeralUtil.SPECIAL_CHAR, "");

                if (value.indexOf('.') >= 0) {
                    var numVal: string = value.split('.')[0];
                    var decVal: string = value.split('.')[1];
                    this.control.control.setValue(numeral(numVal).format(NumeralUtil.THOUSAND_SEPARATOR_FORMAT).concat('.').concat(decVal ? numeral(decVal).format('0') : decVal));
                } else {
                    this.control.control.setValue(numeral(value).format(NumeralUtil.THOUSAND_SEPARATOR_FORMAT));
                }
            }
        }
    }

    @HostListener('focusout', ['$event']) onLostFocus(event) {
        var type = this.control.value.charAt(0);
        if ((type === '-' && this.control.value.length < 23)
            || (type != '-' && this.control.value.length < 22)) {
            var value = this.control.value;
            value = value.replace(NumeralUtil.SPECIAL_CHAR, "");

            if (value) {
                this.control.control.setValue(numeral(value).format(NumeralUtil.THOUSAND_SEPARATOR_FORMAT));
            }
        }
    }
}
