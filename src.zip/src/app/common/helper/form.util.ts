import { Injectable } from '@angular/core';
import { FormGroup, Validators, FormBuilder, AbstractControl, ValidationErrors, FormArray, ValidatorFn } from '@angular/forms';
import { CommonService } from '../../common/services';
import * as _ from 'lodash';
import * as cnst from '../constants';

@Injectable({
    providedIn: 'root'
})
export class FormUtil {

    constructor(private commonService: CommonService) { }

    /**
  * Marks all controls in a form group as touched
  * @param formGroup - The form group to touch
  */
    markFormGroupTouched(formGroup: FormGroup) {
        Object.keys(formGroup.controls).map(x => formGroup.controls[x]).forEach(control => {
            control.markAsTouched();

            if ((control as FormGroup).controls) {
                this.markFormGroupTouched((control as FormGroup));
            }
        });
    }

    /**
* Marks all controls in a form group as touched
* @param formGroup - The form group to touch
*/
    validateAllFormControl(formGroup: FormGroup) {
        Object.keys(formGroup.controls).map(x => formGroup.controls[x]).forEach(control => {
            control.updateValueAndValidity();
            if ((control as FormGroup).controls) {
                this.validateAllFormControl((control as FormGroup));
            }
        });
    }

    unionList(list, key, unionMap: Map<String, String>) {
        var retVal = "";
        if (list) {
            var listSize = JSON.stringify(list).replace("[]", "").length;
            if (listSize && key) {
                list.forEach(element => {
                    if (element.key == key) {
                        retVal = element.label;
                    }
                });

                //for inactive type
                if (retVal === "") {
                    if (unionMap.get(key) == null) {
                        unionMap.set(key, key);
                        this.commonService.getFormList(key).subscribe(data => {
                            if (data[0]) {
                                list.push(data[0]);
                            }
                        });
                    }
                }
            }
        }
        return list;
    }
    /**
    * Return the label of the code
    * @param list - The code list
    *  @param key - The code 
    */
    getLabelFromMasterKey(list, key, unionMap: Map<String, String>) {
        var retVal = "";
        if (list) {
            var listSize = JSON.stringify(list).replace("[]", "").length;
            if (listSize && key) {
                list.forEach(element => {
                    if (element.key == key) {
                        retVal = element.label;
                    }
                });

                //for inactive type
                if (retVal === "") {
                    if (unionMap.get(key) == null) {
                        unionMap.set(key, key);
                        this.commonService.getFormList(key).subscribe(data => {
                            if (data[0]) {
                                list.push(data[0]);
                            }
                        });
                    }
                }
            }
        }
        return retVal;
    }

    getLabelFromKey(list, key) {
        var retVal = "";
        if (list) {
            var listSize = JSON.stringify(list).replace("[]", "").length;
            if (listSize && key) {
                list.forEach(element => {
                    if (element.key == key) {
                        retVal = element.label;
                    }
                });
            }
        }
        return retVal;
    }

    getOtherLabelFromKey(list, key) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.key == key) {
                    if (element.otherLabel) {
                        retVal = element.otherLabel;
                    } else {
                        retVal = element.label;
                    }
                }
            });
        }
        return retVal;
    }

    getDataFromKey(list, key) {
        var retVal: any;
        if (list) {
            list.forEach(element => {
                if (element.key == key) {

                    retVal = element.data;

                }
            });
        }
        return retVal;
    }

    getObjectFromKey(list, key) {
        var retVal: any;
        if (list) {
            list.forEach(element => {
                if (element.key == key) {

                    retVal = element;

                }
            });
        }
        return retVal;
    }

    isMyinfoNonEditable(fieldName: string, nonEditableFields: string[]) {
        return nonEditableFields.includes(fieldName);
    }

    getAddressFrmPostal(address: FormGroup) {
        address.get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (postal && postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                    this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                        this.setAddress(data, address);
                    }, error => {
                        // alert(cnst.TaAlertMessages.ONEMAP_ERROR);
                    });
                }
            });
    }

    setAddress(data, address: FormGroup) {
        if (data) {
            var addrResults = data['results'];

            if (addrResults.length > 0) {
                var blkNo = addrResults[0]['BLK_NO'].trim();
                var roadName = addrResults[0]['ROAD_NAME'].trim();
                var building = addrResults[0]['BUILDING'].trim();
                address.get('block').setValue(blkNo);
                address.get('street').setValue(roadName);
                address.get('building').setValue(building);
            }
        }
        return address;
    }

    isValueSame(value1, value2) {
        if (value1 == value2) {
            return true;
        } else {
            return false;
        }
    }

    placeFieldAsFirst(list, obj) {
        var newList: any = [];
        list.forEach(element => {
            if (element != obj) {
                newList.push(element);
            }
        });
        newList.splice(0, 0, obj);
        return newList;
    }

    listableForm(fb: FormBuilder) {
        return (
            fb.group({
                key: ['', Validators.required],
                label: [''],
                otherLabel: ['']
            })
        )
    }

    addressForm(fb: FormBuilder) {
        return (
            fb.group({
                street: ['', Validators.required],
                building: [''],
                block: [''],
                floor: [''],
                unit: [''],
                postal: [''],
                premisesType: this.listableForm,
                type: this.listableForm,
                singleLineAddress: [''],
                formatted: [''],
                singleLined: [''],
                foreignLine1: [''],
                foreignLine2: [''],
                foreignLine3: [''],
            })
        )
    }

    getFormValidationErrors(form: FormGroup) {
        Object.keys(form.controls).forEach(key => {
            const controlErrors: ValidationErrors = form.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }

    /**
  * Return if control has required validator
  * @param form - FormGroup
  * @param formControlName - FormControl name
  */
    isControlRequired = (form: FormGroup, formControlName): boolean => {
        const control = form.get(formControlName);
        if (!control) {
            return false;
        }
        if (control.validator) {
            const validator = control.validator({} as AbstractControl);
            if (validator && validator.required) {
                return true;
            }
        }

        return false;
    };


}

export function ValidateEmail(control: AbstractControl) {
    var value = control.value;
    if (value) {
        var local = value.split("@")[0];
        var atSign = value.split("@");
        var domain = value.split("@")[1];
        if (atSign.length != 2) {
            return { invalidEmailFormat: true };
        } else if (local.length > cnst.SgdrmEmailFieldsSize.LOCAL || domain.length > cnst.SgdrmEmailFieldsSize.DOMAIN) {
            return { invalidEmailLength: true };
        } else {
            return null
        }
    }
    return null;
}

export function MinSelectedCheckboxes(minLength) {
    const validator: ValidatorFn = (formArray: FormArray) => {
        const totalSelected = formArray.controls
            .map(control => control.value)
            .reduce((prev, next) => next ? prev + next : prev, 0);
        return totalSelected >= minLength ? null : { 'required': true };
    };

    return validator;
}

export function ValidateAddressInput(control: AbstractControl) {
    var value = control.value;
    if (value) {
        if (value.trim().toUpperCase() != 'NA' && value.trim().toUpperCase() != 'NIL') {
            return null;
        } else {
            return { invalidAddressInput: true };
        }
    }
    return null;
}

export function ValidateAddressInputIncDash(control: AbstractControl) {
    var value = control.value;
    if (value) {
        if (value.trim().toUpperCase() != 'NA' && value.trim().toUpperCase() != 'NIL' && value.trim().toUpperCase() != '-') {
            return null;
        } else {
            return { invalidAddressInput: true };
        }
    }
    return null;
}

