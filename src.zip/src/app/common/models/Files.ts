export class Files {
    id: number;
    publicFileId: number;
    filename: string;
    originalFilename: string;
    path: string;
    size: number;
    extension: string;
    description: string;
    transferError: string;
    hash: string;
    isDeleted: boolean;
}