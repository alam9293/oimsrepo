import { Statuses } from './Statuses';
    
    export class Licences {
        id: number;
        isViewable: number;
        isDownloadable: number;
        licenceNo: string;
        taTgType: string;
        issueDate: Date;
        ceasedDate: Date;
        startDate: Date;
        expiryDate: Date;
        isPendingCessation: boolean;
        status: Statuses; 
    }