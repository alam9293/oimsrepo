
    
    export class Statuses {
        code: string;
        isActive: boolean;
        isEditable: boolean;
        label: string;
        mappingCode: string;
        ordinal: number;
        otherLabel: string;
        runningCode: number;
        categoryCode: string;
        createdBy: string;
        createdDate: Date;
        updatedBy: string;
        updatedDate: Date;
        version: number;
        footNote: string;
    }