
import { Files } from './Files';
import { Licences } from './Licences';

export class TouristGuide {
    photo: string;
    status: Licences;
    licenceId: number;
    displayName: string;
    aliasName: string;
    specializedAreaswithComma: string;
    guidingLanguageswithComma: string;
    mobileNo: string;
    emailAddress: string;
    photoExtension: Files;
    specializedAreas: string;
    guidingLanguages: string;
}