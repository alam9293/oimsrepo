import { Observable } from "rxjs";

export class FileDto {
    id: number;
    publicFileId: number;
    originalName: string;
    processedName: string;
    docType: string;
    extension: string;
    path: string;
    size: number;
    hash: string;
    documentInstructions: string;
    documentTypeLabel: string;
    description: string;
    readableFileSize: string;
    hasTemplate: boolean;
}

export class ListableDto {
    key: string;
    label: string;
    otherLabel: string;
}

export class AddressDto {
    street: string;
    building: string;
    block: string;
    floor: string;
    unit: string;
    postal: string;
    premisesType: ListableDto;
    type: ListableDto;
    singleLineAddress: string;
    formatted: string;
    singleLined: string;
    addressId: number;
    foreignLine1: string;
    foreignLine2: string;
    foreignLine3: string;
}

export class ResultDto<TouristGuideItemDto> {
    total: number;
	noOfPages: number ;
	models: Observable<TouristGuideItemDto>;
	records: any;
	result: any ;
	successFlag: string ;
}

export class TouristGuideItemDto {

    licenceNo: string;
	name: string ;
	aliasName: string ;
	status: string ;
	emailAddress: string ;
	phoneNo: string ;
	touristType: string ;
	guidingLanguages: Observable<string> ;
	areaSpecialisations: Observable<string>;
	languagesWithComma: string ;
	areaSpecialisationsWithComma: string ;
	photo: string ;
	photoExtension: string ;
	publicFileId: number ;
	displayPhoto: boolean ;
	hash: string ;
}

