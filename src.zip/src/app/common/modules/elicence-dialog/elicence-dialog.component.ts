import { Component, Inject, Input, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DatePipe } from '@angular/common';
import { Observable, Subscription, interval } from 'rxjs';

import * as cnst from '../../../common/constants';
import { CommonService } from '../../services/common.service';
declare var gtag: Function;

@Component({
    selector: 'app-elicence-dialog',
    templateUrl: './elicence-dialog.component.html',
    styleUrls: ['./elicence-dialog.component.scss'],
    providers: [{ provide: DatePipe }]
})
export class ELicenceDialogComponent implements OnInit {

    cnst = cnst;
    @ViewChild('canvas') canvas: ElementRef<HTMLCanvasElement>;
    private ctx: CanvasRenderingContext2D;
    @Input() public totalWidth = 414;
    @Input() public totalHeight = 508;
    @Input() public width = 414;
    @Input() public height = 487;
    protected datePipe: DatePipe = new DatePipe('en-US');

    constructor(private commonService: CommonService,
        public dialogRef: MatDialogRef<ELicenceDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any) {
    }

    ngOnInit() {
        if (!this.data) {
            this.data = {};
        } else {
            this.drawLicenceImage();
            //Special handling for mobile/ipad which font face fail to load at the first time
            if (/Android|webOS|iPhone|iPad|iPod|Macintosh|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                interval(500).subscribe(
                    (val) => {
                        if (val == 0) {
                            this.drawLicenceImage();
                        }
                    });
            }
        }
    }

    drawLicenceImage() {
        this.ctx = this.canvas.nativeElement.getContext('2d');
        this.ctx.clearRect(0, 0, this.totalWidth, this.totalHeight);
        this.ctx.beginPath();
        const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
        canvasEl.width = this.totalWidth;
        canvasEl.height = this.totalHeight;

        let backgroundImage = new Image();
        let tgPhoto = new Image();

        if (this.data.licence.licenceTier.key == cnst.TgCommonTypes.TG_AREA) {
            backgroundImage.src = "./assets/images/elicence/elicence_background_pink.jpg";
        } else {
            backgroundImage.src = "./assets/images/elicence/elicence_background_white.jpg";
        }
        tgPhoto.src = this.data.tgPhotoSrc;
        backgroundImage.onload = () => {
            this.ctx.drawImage(backgroundImage, 0, 0, this.width, this.height); //background template
            this.ctx.lineWidth = 1;
            this.ctx.strokeStyle = "#ECE6E5";
            this.ctx.strokeRect(0, 0, this.width, this.height);

            this.ctx.drawImage(tgPhoto, 25, 46, 160, 222); //TG photo

            //Accurate as of date text
            var dateTimeNow = "Accurate as of " + this.datePipe.transform(new Date(), 'dd MMM yyyy, hh:mm a');
            var currentDateText = this.canvas.nativeElement.getContext('2d');
            currentDateText.font = "12pt Calibri";
            currentDateText.fillText(dateTimeNow, 3, 505);

            // Badge Number text
            var ctxBadgeNumText = this.canvas.nativeElement.getContext('2d');
            ctxBadgeNumText.font = "10pt Calibri Bold";
            ctxBadgeNumText.fillText("BADGE NUMBER", 25, 290);

            // licence No
            var ctxLicenceNo = this.canvas.nativeElement.getContext('2d');
            ctxLicenceNo.font = "32pt Calibri";
            ctxLicenceNo.fillText(this.data.licence.licenceNumber, 25, 330);

            //Expiry date 
            var ctxExpiryDateText = this.canvas.nativeElement.getContext('2d');
            ctxExpiryDateText.font = "10.5pt Calibri Bold";
            ctxExpiryDateText.fillText("EXPIRY DATE", 318, 382);

            var ctxExpiryDate = this.canvas.nativeElement.getContext('2d');
            var expiryDate = this.data.licence.expiryDate.replace('-', ' ').replace('-', ' ').toLocaleUpperCase();
            ctxExpiryDate.font = "31pt Calibri";
            ctxExpiryDate.fillText(expiryDate, this.totalWidth - (ctxExpiryDate.measureText(expiryDate).width + 23), 422);

            //Licensee Name
            var ctxLicenceeName = this.canvas.nativeElement.getContext('2d');
            var licenceeName = this.data.touristGuide.displayName.toLocaleUpperCase().trim();
            var licenceeSecondName;

            var fontSizeLN = 18;
            var xLN = 300;
            var yLN = 90;
            var maxWidthLN = 200;
            var maxHeightLN = 55;
            var lastFontName;
            var firstFontName = this.countFontSizeByWidth(ctxLicenceeName, licenceeName, "Calibri", maxWidthLN, fontSizeLN);

            var ctxLicenceeSecondName = this.canvas.nativeElement.getContext('2d');
            if (this.data.touristGuide.displaySecondName) {
                licenceeSecondName = this.data.touristGuide.displaySecondName.toLocaleUpperCase().trim();
            } else {
                licenceeSecondName = "";
            }

            var secondFontName = this.countFontSizeByWidth(ctxLicenceeSecondName, licenceeSecondName, "Calibri", maxWidthLN, fontSizeLN);
            if (firstFontName > secondFontName) {
                lastFontName = secondFontName;
            } else {
                lastFontName = firstFontName;
            }
            ctxLicenceeName.font = lastFontName + "pt Calibri";
            ctxLicenceeName.textAlign = 'center';
            ctxLicenceeName.fillText(licenceeName, xLN, yLN);

            ctxLicenceeSecondName.font = lastFontName + "pt Calibri";
            ctxLicenceeSecondName.textAlign = 'center';
            ctxLicenceeSecondName.fillText(licenceeSecondName, xLN, yLN + 27.5);

            //is licensed to guide tourist in text
            var middleText = this.canvas.nativeElement.getContext('2d');
            middleText.font = "9pt Calibri Bold";
            middleText.fillText("IS LICENSED TO GUIDE TOURIST IN", 300, 150);

            //Guiding Languague
            var ctxGuidingLanguague = this.canvas.nativeElement.getContext('2d');
            var fontSizeGL = 18;
            ctxLicenceeName.font = fontSizeGL + "pt Calibri";
            ctxLicenceeName.textAlign = 'center';
            var lineHeightGL = 22.5;
            var xGL = 300;
            var yGL = 183;
            var maxHeightGL = 190;
            this.wrapGudingLanguague(ctxGuidingLanguague, xGL, yGL, lineHeightGL, maxHeightGL, fontSizeGL);

            //Employer Name for workpass holder
            if (this.data.touristGuide.isWorkPassHolder) {
                var ctxEmployerName = this.canvas.nativeElement.getContext('2d');
                var ctxEmployerSecondName = this.canvas.nativeElement.getContext('2d');
                var employerName;
                var employerSecondName;

                if (this.data.touristGuide.displayEmployerName) {
                    employerName = this.data.touristGuide.displayEmployerName.toLocaleUpperCase().trim();
                    var fontSizeEN = 17;
                    ctxEmployerName.font = fontSizeEN + "pt Calibri";
                    ctxEmployerName.textAlign = 'center';
                    var xEN = 300;
                    var yEN = 330;
                    var maxWidthEN = 200;
                    var maxHeightEN = 46;
                    var lastFontEmployer;
                    var firstFontEmployer = this.countFontSizeByWidth(ctxEmployerName, employerName, "Calibri", maxWidthEN, fontSizeEN);
                    if (this.data.touristGuide.displaySecondEmployerName) {
                        employerSecondName = this.data.touristGuide.displaySecondEmployerName.toLocaleUpperCase().trim();
                    } else {
                        employerSecondName = "";
                    }

                    var secondFontEmployer = this.countFontSizeByWidth(ctxEmployerSecondName, employerSecondName, "Calibri", maxWidthEN, fontSizeEN);
                    if (firstFontEmployer > secondFontEmployer) {
                        lastFontEmployer = secondFontEmployer;
                    } else {
                        lastFontEmployer = firstFontEmployer;
                    }

                    ctxEmployerName.font = lastFontEmployer + "pt Calibri";
                    ctxEmployerName.textAlign = 'center';
                    ctxEmployerName.fillText(employerName, xEN, yEN);

                    ctxEmployerSecondName.font = lastFontEmployer + "pt Calibri";
                    ctxEmployerSecondName.textAlign = 'center';
                    ctxEmployerSecondName.fillText(employerSecondName, xEN, yEN + 23);
                }
            }
        }
    }

    countFontSizeByWidth(context, text, fontface, maxWidth, fontSize) {
        // start with a large font size
        var fontsize = fontSize;

        // lower the font size until the text fits the canvas
        do {
            fontsize = fontsize - 0.01;
            context.font = fontsize + "pt " + fontface;
            context.textAlign = 'center';
        } while (parseInt(context.measureText(text).width) > maxWidth)
        return fontsize;
    }

    wrapGudingLanguague(context, x, y, lineHeight, maxHeight, fontSize) {
        var guidingLanguage = this.data.touristGuide.guidingLanguages;
        var specializedArea = this.data.touristGuide.specializedAreas;
        if (this.data.licence.licenceTier.key == cnst.TgCommonTypes.TG_AREA || this.data.licence.licenceTier.key == cnst.TgCommonTypes.TG_GENERAL_AREA) {
            guidingLanguage = specializedArea.replace("Paranormal Activity", "Paranormal,Activity") + ',' + guidingLanguage;
        } else if (this.data.licence.licenceTier.key == cnst.TgCommonTypes.TG_TAXI) {
            guidingLanguage = "TAXI" + ',' + guidingLanguage;
        }
        var words = guidingLanguage.toLocaleUpperCase().split(',');
        var count = words.length;

        if (count < 4) {
            y = y + 10;
            lineHeight = lineHeight + 5;
        }
        if (this.data.touristGuide.isWorkPassHolder && (this.data.touristGuide.employerName || this.data.touristGuide.displayEmployerName)) {
            if (count < 7) {
                for (var n = 0; n < count; n++) {
                    context.fillText(words[n], x, y);
                    y += lineHeight;
                }
            } else {
                var maxHeightTemp = maxHeight - 50;
                y = y - 8;
                for (var n = 0; n < count; n++) {
                    this.fitTextOnCanvas(context, words[n], "Calibri", x, y, maxHeightTemp / count, fontSize);
                    y += maxHeightTemp / count;
                }
            }
        } else {
            if (count < 9) {
                for (var n = 0; n < count; n++) {
                    context.fillText(words[n], x, y);
                    y += lineHeight;
                }
            } else {
                y = y - 8;
                for (var n = 0; n < count; n++) {
                    this.fitTextOnCanvas(context, words[n], "Calibri", x, y, maxHeight / count, fontSize);
                    y += maxHeight / count;
                }
            }
        }
    }

    countLineHeight(context, text, maxWidth, maxHeight) {
        var words = text.split(' ');
        var line = '';
        var count = 1;
        for (var n = 0; n < words.length; n++) {
            var testLine = line + words[n] + ' ';
            var testWidth = context.measureText(testLine).width;
            if (testWidth > maxWidth && n > 0) {
                line = words[n] + ' ';
                count = count + 1;
            }
            else {
                line = testLine;
            }
        }
        return count;
    }

    wrapText(context, text, x, y, maxWidth, lineHeight, fontSize) {
        var words = text.split(' ');
        var line = '';
        for (var n = 0; n < words.length; n++) {
            var testLine = line + words[n] + ' ';
            var testWidth = context.measureText(testLine).width;
            if (testWidth > maxWidth && n > 0) {
                this.fitTextOnCanvas(context, line, "Calibri", x, y, lineHeight, fontSize);
                line = words[n] + ' ';
                y += lineHeight;
            }
            else {
                line = testLine;
            }
        }
        this.fitTextOnCanvas(context, line, "Calibri", x, y, lineHeight, fontSize);
    }

    fitTextOnCanvas(context, text, fontface, xPosition, yPosition, lineHeight, fontSize) {
        // start with a large font size
        var fontsize = fontSize;

        // lower the font size until the text fits the canvas
        do {
            fontsize = fontsize - 0.01;
            context.font = fontsize + "pt " + fontface;
            context.textAlign = 'center';
        } while (parseInt(context.font.match(/\d+/), 10) > lineHeight)

        // draw the text
        context.fillText(text, xPosition, yPosition);
    }

    save() {
        // Save the canvas context to file
        const timestamped = this.ctx.canvas.toDataURL('image/png');
        const fileName = 'e-licence' + this.data.licence.licenceNumber + '.png';
        if (window.navigator.msSaveOrOpenBlob) {
            //IE & Edge
            var binary = atob(timestamped.split(',')[1]);
            var array = [];
            for (var i = 0; i < binary.length; i++) {
                array.push(binary.charCodeAt(i));
            }
            var blob = new Blob([new Uint8Array(array)], { type: 'image/png' });
            window.navigator.msSaveOrOpenBlob(blob, fileName);
        } else {
            const a = window.document.createElement('a');
            window.document.body.appendChild(a);
            const url = timestamped;
            a.href = url;
            a.download = fileName;
            a.click();
        }
        this.drawLicenceImage();

        //Google Analytics : To track no of e-licence download 
        gtag('send', {
            hitType: 'event',
            eventCategory: 'TG ELicence Download',
            eventAction: 'TG ELicence Download',
            eventLabel: 'TG ELicence Download',
        });
    }

    close() {
        this.dialogRef.close();
    }
}