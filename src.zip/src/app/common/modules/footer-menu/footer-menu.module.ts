import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatIconModule } from '@angular/material';
import { FooterMenuComponent } from './footer-menu.component';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule
    ],
    declarations: [FooterMenuComponent],
    exports: [FooterMenuComponent]
})
export class FooterMenuModule { }
