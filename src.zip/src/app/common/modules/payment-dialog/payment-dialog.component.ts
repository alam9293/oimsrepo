import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PaymentService } from '../../../portal/payment/payment.service';
import { environment } from '../../../../environments/environment';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../services/common.service';

@Component({
    selector: 'app-payment-dialog',
    templateUrl: './payment-dialog.component.html',
    styleUrls: ['./payment-dialog.component.scss']
})
export class PaymentDialogComponent implements OnInit {

    isSingleBill: boolean = false;
    qrCode: string;
    cnst = cnst;
    isLoading = true;
    waiveForInactiveLic = true;
    message: string;

    constructor(private commonService: CommonService, private paymentService: PaymentService, public dialogRef: MatDialogRef<PaymentDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
        // disable PayNow for production
        if (this.data.billRefNos && !environment.production) {
            this.isSingleBill = this.data.billRefNos.length === 1;
        }
        dialogRef.disableClose = true;
    }

    ngOnInit() {
        if (this.data.waiveForInactiveLic !== undefined) {
            this.waiveForInactiveLic = this.data.waiveForInactiveLic;
        }

        if (this.data.paymentRequestType) {
            this.commonService.checkPaymentIsWaived(this.data.paymentRequestType).subscribe(result => {
                this.isLoading = false;
                if (result == true && this.waiveForInactiveLic) {
                    let obj = {
                        decision: true,
                    };
                    this.dialogRef.close(obj);
                }
            });
        }
        else {
            this.isLoading = false;
        }

        if (this.data.payNowTxnId == 0) {//waive payment
            this.close(true, cnst.PaymentTypes.PAYNOW, true);
        } else {
            if (this.data.payNowTxnId) {
                console.log("PayNowId :" + this.data.payNowTxnId)
                this.qrCode = this.data.qrCode;
                this.getPaymentTxnForICNResult();
            }
        }
    }

    close(decision: boolean, type: any, isPayNowCompleted: boolean) {
        if (!isPayNowCompleted && this.data.payNowTxnId && !this.message) {//PayNow
            let close = confirm('Retrieving payment result in progress. Please DO NOT close the browser if you have made a successfully payment.\
                                Are you sure you want to close the browser? ');
            if (!close) {
                return true;
            }
        }
        let obj = {
            decision: decision,
            type: type, // Visa or Masters or PayNow
        };
        this.dialogRef.close(obj);
    }

    // Retry the polling result every 10 seconds until PayNow ICN has callback to server, or the txn has timeout after 5 min
    getPaymentTxnForICNResult() {
        this.paymentService.getPaymentTxnForICNResult(this.data.payNowTxnId).subscribe(data => {
            if (data === 1) {//Successful
                this.close(true, cnst.PaymentTypes.PAYNOW, true);
            } else if (data === 2) {//Pending
                setTimeout(() => { this.getPaymentTxnForICNResult(); }, 10000);
            } else {//Timeout
                this.message = "PayNow Transaction ID " + this.data.payNowTxnId + " has been timeout. " + cnst.Messages.PAYNOW_TIMEOUT_MESSAGE;
            }
        });
    }
}