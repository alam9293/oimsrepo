import { Component, ChangeDetectorRef, ChangeDetectionStrategy, OnInit, OnDestroy, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Observable, Subscription, timer } from 'rxjs';
import { IdleTimeoutService, AuthenticationService } from '../../services';
import * as cnst from '../../constants';
import { AppUtil } from '../../../common/helper/app.util';

@Component({
    selector: 'app-session-timeout',
    template: '<div></div>',
    //styleUrls: ['./session-timeout.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SessionTimeoutComponent implements OnInit {
    public _status: string = "Initialized.";
    private _idleTimerSubscription: Subscription;

    constructor(
        private changeRef: ChangeDetectorRef,
        private idleTimeoutSvc: IdleTimeoutService,
        public dialog: MatDialog,
        private authService: AuthenticationService,
        private router: Router,
        private appUtil: AppUtil,
    ) { }

    ngOnInit() {
        this.setSubscription();
    }

    private setSubscription() {
        this._idleTimerSubscription = this.idleTimeoutSvc.timeoutExpired.subscribe(res => {
            if (res === cnst.SESSION_EXPIRED) {
                this.openSessionExpiringDialog(cnst.SESSION_EXPIRED);
            } else {
                this.openSessionExpiringDialog(cnst.SESSION_EXPIRING);
            }
        });
    }

    openSessionExpiringDialog(status: number) {
        this.changeRef.markForCheck();
        let ref = this.dialog.open(DialogSessionExpiringComponent, {
            data: { status: status },
            disableClose: true
        });
        ref.afterClosed().subscribe(res => {
            if (res) {
                this.authService.extendCurrentSession().subscribe(data => {
                    this._status = "Session was extended.";
                    this.idleTimeoutSvc.resetTimer();
                    this.changeRef.markForCheck();
                }, error => {
                    this.authService.logout();
                });
            } else {
                this._status = "Session timeout.";
                this.changeRef.markForCheck();
                this.authService.logout();
                this.appUtil.routeToHomePage();
            }
        });
    }

    ngOnDestroy() {
        if (this._idleTimerSubscription) {
            this._idleTimerSubscription.unsubscribe();
        }
    }
}

@Component({
    selector: 'session-timeout-expiring-dialog',
    templateUrl: './session-timeout.component.html',
    styleUrls: ['./session-timeout.component.scss'],
})
export class DialogSessionExpiringComponent {

    private _timerSubscription: Subscription;
    private _timer: Observable<number>;
    public _counter: number = cnst.COUNTDOWN_INIT * 60;

    constructor(
        public dialogRef: MatDialogRef<DialogSessionExpiringComponent>,
        private authService: AuthenticationService,
        @Inject(MAT_DIALOG_DATA) public data: any

    ) { }

    ngOnInit() {
        if (this.data.status === cnst.SESSION_EXPIRING) {
            this.startCounter();
        } else {
            this._counter = 0;
        }
    }

    ngOnDestroy() {
        if (this._timerSubscription) {
            this._timerSubscription.unsubscribe();
        }
    }

    public startCounter() {
        if (this._timerSubscription) {
            this._timerSubscription.unsubscribe();
        }

        this._timer = timer(1000, 1000); // delay one sec, and repeat every one sec
        this._timerSubscription = this._timer.subscribe(n => {
            this._counter--;
            if (this._counter <= 0) {
                this._timerSubscription.unsubscribe();
                this.authService.logout();
            }
        });
    }
}