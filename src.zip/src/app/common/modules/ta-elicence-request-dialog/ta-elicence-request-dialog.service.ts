import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaElicenceRequestDialogService {

    constructor(private http: HttpClient) { }

    createTaELicenceRequestApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_ELICENCE_REQUEST + '/new');
    }

    submit(application: any): Observable<any> {
        if (application.applicationId) {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_ELICENCE_REQUEST + '/update', application);
        } else {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_ELICENCE_REQUEST + '/save', application);
        }
    }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_ELICENCE_REQUEST + '/load/' + applicationId);
    }
}