import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CroppieFormControlComponent } from './croppie-form-control.component';

describe('CroppieFormControlComponent', () => {
  let component: CroppieFormControlComponent;
  let fixture: ComponentFixture<CroppieFormControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CroppieFormControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CroppieFormControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
