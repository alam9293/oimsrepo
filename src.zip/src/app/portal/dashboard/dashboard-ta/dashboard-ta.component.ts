import { Component, OnInit } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { CommonService, AlertService } from '../../../common/services';
import { DashboardTaService } from './dashboard-ta.service';
import { FormUtil, NumeralUtil } from '../../../common/helper';
import { AuthenticationService } from '../../../common/services'
import { User, LicenseeDto, AddressDto, LicenceDto } from '../../../common/models';
import { TaElicenceDialogComponent } from '../../../common/modules/ta-elicence-dialog/ta-elicence-dialog.component';
import * as numeral from 'numeral';
import * as cnst from '../../../common/constants';
import * as _ from 'lodash';
import * as $ from 'jquery';

@Component({
    selector: 'app-dashboard-ta',
    templateUrl: './dashboard-ta.component.html',
    styleUrls: ['./dashboard-ta.component.scss']
})
export class DashboardTaComponent implements OnInit {

    currentUser: User;
    licensee: LicenseeDto;
    licence: LicenceDto;
    address: AddressDto;
    dashboard: any = { licence: { status: {}, downloadFlag: 0 }, address: {} };
    appTypeList: any;
    cnst = cnst;
    numeral = numeral;
    bulletins: any;
    taBulletins: any;
    taBulletin: boolean = false;
    minItem: any = 4;
    statusColor: string;
    THOUSAND_SEPARATOR_FORMAT: any;

    constructor(
        private dashboardService: DashboardTaService,
        public formUtil: FormUtil,
        public numeralUtil: NumeralUtil,
        private commonService: CommonService,
        private authenticationService: AuthenticationService,
        public dialog: MatDialog,
    ) { }

    ngAfterViewChecked() {
        this.checkWindowWidth();

    }

    ngOnInit() {

        this.THOUSAND_SEPARATOR_FORMAT = NumeralUtil.THOUSAND_SEPARATOR_FORMAT;
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
            this.licensee = this.currentUser.licensee;
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
                this.licensee = this.currentUser.licensee;
            });
        }
        this.dashboardService.getDashboardElements().subscribe(data => {
            this.dashboard = data;
            this.licence = data.licence;

            if (cnst.TaStatuses.ACTIVE.indexOf(this.dashboard.licence.status.key) > -1 && this.dashboard.licence.status.key != cnst.TaStatuses.SUSPEND) {
                this.statusColor = 'status-active';
            } else if (cnst.TaStatuses.INACTIVE.indexOf(this.dashboard.licence.status.key) > -1) {
                this.statusColor = 'status-inactive';
            } else if (cnst.TaStatuses.SUSPEND.indexOf(this.dashboard.licence.status.key) > -1 || cnst.TaStatuses.REVOKED.indexOf(this.dashboard.licence.status.key) > -1) {
                this.statusColor = '';
            }
        });
        this.commonService.getTaApplicationTypes().subscribe(data => this.appTypeList = data);
        this.commonService.getBulletinsAll(cnst.BulletinTypes.TA).subscribe(data => {
            this.taBulletins = data;
            setTimeout(() => {
                $('.carousel2 .item').each(function () {
                    var next = $(this).next();
                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }
                    next.children(':first-child').clone().appendTo($(this));

                    for (var i = 0; i < 2; i++) {
                        next = next.next();
                        if (!next.length) {
                            next = $(this).siblings(':first');
                        }

                        next.children(':first-child').clone().appendTo($(this));
                    }
                });
            })
        });
        this.commonService.getBulletinsAll(cnst.BulletinTypes.GENERAL).subscribe(data => {
            this.bulletins = data;
            setTimeout(() => {
                $('.carousel1 .item').each(function () {
                    var next = $(this).next();
                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }
                    next.children(':first-child').clone().appendTo($(this));

                    for (var i = 0; i < 2; i++) {
                        next = next.next();
                        if (!next.length) {
                            next = $(this).siblings(':first');
                        }

                        next.children(':first-child').clone().appendTo($(this));
                    }
                })
            })
        });
        this.checkWindowWidth();
    }

    isTaActive(status: string): Boolean {
        if (status) {
            var active_statuses = this.cnst.TaStatuses.ACTIVE;
            var isActive: boolean;
            _.forEach(active_statuses, function (value) {
                if (status === value) {
                    isActive = true;
                    return;
                }
            });
            return isActive;
        } else {
            return false;
        }
    }

    isELicenceBtnView(status: string, viewflag: number): Boolean {
        if (status && viewflag && viewflag == this.cnst.ELicenceView.VIEW) {
            var active_statuses = this.cnst.TaStatuses.ACTIVE;
            var isActive: boolean;
            _.forEach(active_statuses, function (value) {
                if (status === value) {
                    isActive = true;
                    return;
                }
            });
            return isActive;
        } else {
            return false;
        }
    }

    checkWindowWidth() {
        if ($(window).width() < 992) {
            this.minItem = 2;
        }
        if ($(window).width() < 768) {
            this.minItem = 1;
        }
    }

    switchTaBulletin() {

        if (this.taBulletins.length < 1) {

        }

    }

    openELicenceDialog() {
        this.dashboardService.getTaELicenceData().subscribe(res => {
            let elicenceDialogRef = this.dialog.open(TaElicenceDialogComponent, {
                data: {
                    licence: res.licence,
                    address: res.displayAddr,
                    displayName: res.displayName,
                    qrCode: res.qrCode,
                    branchaddrlist: res.branchAddrList
                }
            });
        });

    }



}


