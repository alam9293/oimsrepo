
import { downloadFileService } from './downfile.service';
import * as cnst from '../../common/constants';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';



@Component({
    selector: 'app-site',
    templateUrl: './download-file.component.html',
    styleUrls: ['./download-file.component.scss']
})
export class downloadFileComponent implements OnInit {
    fileName: string;
    cnst = cnst;
    
   
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private downloadFileService: downloadFileService,
        
       ) { }
        

    ngOnInit() {

        console.log("************* inside downloadFile");
        //this.fileName = this.route.snapshot.data.fileName;
        this.fileName = this.route.snapshot.paramMap.get('fileName');
        console.log("*************"+this.fileName);
        this.downloadFileService.downloadFile(this.fileName).subscribe((data:any) => {
            if(data === null)
            {
                console.log('No file Found.....');
            }
            else
            {
                try
                {
                    console.log('file loading.....'+data);
                    let blob:any = new Blob([data], {type: 'application/pdf'});
                    var downloadURL = window.URL.createObjectURL(data);
                    var link = document.createElement('a');
                    link.href = downloadURL;
                    link.download = this.fileName;
                    link.click();
                }
                catch(e)
                {
                    console.log(e);
                }
            }
            close();
    	});

      
    }
    
}