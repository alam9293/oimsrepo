import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../common/services';
import { User } from '../../common/models';
import { first } from 'rxjs/operators';
import { environment as env } from '../../../environments/environment';
import * as cnst from '../../common/constants';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    returnUrl: string;
    error = '';
    loginForm: any = {};
    loginTypeCode: string;
    selectedLoginTypeCode: string; //to be removed
    dashboardTypeCode: string;
    cnst = cnst;
    env = env;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
        console.log("LoginComponent ngOnInit start");
        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        let returnUrl = sessionStorage.getItem('returnUrl');
        if (returnUrl) {
            var delimiter = returnUrl.indexOf("/");
            this.dashboardTypeCode = returnUrl.substring(0, delimiter);
            this.returnUrl = returnUrl.substring(delimiter + 1);
        }
        this.loginTypeCode = this.route.snapshot.data.loginTypeCode;
        this.selectedLoginTypeCode = this.loginTypeCode;    //to be removed

        // in non-production environment, auto-select login type based on dashboard Type Code
        if (!env.production) {
            let dashboardTypeCode = this.route.snapshot.queryParams['dashboardTypeCode']
            if (dashboardTypeCode === 'TA' || dashboardTypeCode === 'TACDD' || dashboardTypeCode === 'TP') {
                this.selectedLoginTypeCode = 'CP';
            }
        }

        if (this.loginTypeCode !== 'TAG') {
            console.log("LoginComponent ngOnInit IAMS start");
            let iamsAccessCode = this.route.snapshot.queryParams['code'];
            this.authenticationService.loginByIams(iamsAccessCode, this.dashboardTypeCode, this.loginTypeCode).subscribe(
                data => {
                    if (data.auth) {
                        var user: User = data.user;
                        if (user.selectedRole.key == cnst.CommonRoles.TG_CANDIDATE) {
                            this.returnUrl = '/portal/tg/application-form';
                        } else if (user.selectedRole.key == cnst.CommonRoles.TP_PUBLIC) {
                            if (user.tpPdc) {
                                this.returnUrl = '/portal/tp-PDC-manage';
                            }
                            else if (user.tpMrc) {
                                this.returnUrl = '/portal/tp-MRC-manage';
                            }
                        }
                        this.router.navigate([this.returnUrl]);
                    } else {
                        this.error = data.reason;
                    }
                }, error => {
                    this.error = error;
                }
            );

        }
    }

    onLogin() {

        this.authenticationService.login(this.loginForm.username, this.loginForm.password, this.loginForm.uen, this.selectedLoginTypeCode)
            .pipe(first())
            .subscribe(
                data => {
                    if (data.auth) {
                        var user: User = data.user;
                        var dashboardUrl: string;
                        if (user.selectedRole.key == cnst.CommonRoles.TA_PUBLIC) {
                            dashboardUrl = '/portal/dashboard-ta';
                        } else if (user.selectedRole.key == cnst.CommonRoles.TG_PUBLIC) {
                            dashboardUrl = '/portal/dashboard-tg';
                        } else if (user.selectedRole.key == cnst.CommonRoles.TP_PUBLIC) {
                            if (user.tpPdc) {
                                dashboardUrl = '/portal/tp-PDC-manage';
                            } else if (user.tpMrc) {
                                dashboardUrl = '/portal/tp-MRC-manage';
                            }
                        } else if (user.selectedRole.key == cnst.CommonRoles.TA_CANDIDATE) {
                            this.returnUrl = '/portal/ta-application-form';
                        }
                        else if (user.selectedRole.key == cnst.CommonRoles.TG_CANDIDATE) {
                            this.returnUrl = '/portal/tg/application-form';
                        }
                        this.returnUrl = this.returnUrl || dashboardUrl;
                        this.router.navigate([this.returnUrl]);
                    } else {
                        this.error = data.reason;
                    }
                },
                error => {
                    this.error = error;
                });


    }


}
