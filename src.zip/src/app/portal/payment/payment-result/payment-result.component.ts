import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PaymentService } from '../payment.service';
import { Router } from '@angular/router';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-payment-result',
    templateUrl: './payment-result.component.html',
    styleUrls: ['./payment-result.component.scss']
})
export class PaymentResultComponent implements OnInit {
    dashboardTypeCode: string;
    paymentRequests: Array<any>;
    showDefault: boolean;
    continueUrl: string;
    message: string = 'Retrieving payment result in progress. Please DO NOT leave or refresh the browser. Thank you.';
    initCompleted: boolean = false;
    cnst = cnst;
    isTgCandidate: boolean = false;

    constructor(private router: Router, private route: ActivatedRoute, private paymentService: PaymentService) { }

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        this.isTgCandidate = this.route.snapshot.data.isCandidate;
        let billRefNo = this.route.snapshot.paramMap.get('anyBillRefNo');
        let txnId = this.route.snapshot.paramMap.get('txnId');
        this.showDefault = JSON.parse(this.route.snapshot.paramMap.get('showDefault'));
        this.route.queryParams.subscribe(params => {
            this.continueUrl = params['continueUrl'];
        });

        if (!this.showDefault && !this.continueUrl) {//to cater eNets payment return 
            this.paymentService.getContinueUrlByTxnId(txnId).subscribe(data => {
                this.continueUrl = data.continueUrl;
            });
        }

        this.paymentService.getPaymentRequestsForResult(billRefNo, txnId).subscribe(data => {
            this.paymentRequests = data;
            this.initCompleted = true;
            if (!this.showDefault) {
                this.router.navigate([this.continueUrl]);
            }

        }, error => {
            if (error.status !== cnst.HttpStatus.UNAVAILABLE) {
                this.message = error.error.message;
                this.initCompleted = true;
                if (!this.showDefault) {
                    this.router.navigate([this.continueUrl]);
                }
            }
        });
    }
    print() {
        window.print();
    }

}
