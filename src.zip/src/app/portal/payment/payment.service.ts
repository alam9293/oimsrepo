import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { retryWhen, delay, tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { LoaderService } from '../../common/services/loader.service';
import * as cnst from '../../common/constants';
import * as _ from 'lodash';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { RedirectService } from './../../common/directives/redirect.service';

@Injectable({
    providedIn: 'root'
})
export class PaymentService {

    constructor(private http: HttpClient, private loaderService: LoaderService, private router: Router, private redirect: RedirectService) { }

    savePaymentRequest(dto: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + '/payment/requests/save', dto, { responseType: 'text' });
    }

    getPaymentRequestsForPayment(params: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/public/requests-for-payment', { params: params });
    }

    getPaymentRequests(billRefNo: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/portal/get-payment-request', { params: { billRefNo: billRefNo } });
    }
    getPaymentTxns(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/portal/get-payment-txn', { params: searchDto });
    }
    getPaymentTxn(id): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/portal/get-payment-txn/' + id);
    }

    appendHiddenField(form: HTMLFormElement, name: string, value: any) {
        var input = document.createElement("input");
        input.setAttribute("type", "hidden");
        input.setAttribute("name", name);
        input.setAttribute("value", value);
        form.appendChild(input);
    }

    initPaymentProcess(showDefault: boolean, returnTypeUrl: string, paymentType: string, billRefNos: Array<string>, continueUrl: string) {
        if (billRefNos.length > 0) {
            let statusUrl = cnst.apexBaseUrl + '/payment/public/cpp';
            let returnUrl = returnTypeUrl + "/" + billRefNos[0] + '/txnId/' + showDefault;
            let formData: FormData = new FormData();
            formData.append('billRefNos', new Blob(
                [JSON.stringify(billRefNos)],
                { type: 'application/json' }
            ));

            //maxLength of statusUrl & returnUrl is 80
            formData.append('statusUrl', new Blob(
                [JSON.stringify(statusUrl)],
                { type: 'application/json' }
            ));
            formData.append('returnUrl', new Blob(
                [JSON.stringify(returnUrl)],
                { type: 'application/json' }
            ));
            formData.append('continueUrl', new Blob(
                [JSON.stringify(continueUrl)],
                { type: 'application/json' }
            ));

            this.http.post(cnst.apexBaseUrl + '/payment/public/init-payment-process/' + paymentType, formData).subscribe((eNets: any) => {
                if (eNets.isAllWaived) {
                    this.router.navigate([continueUrl]);
                } else {
                    if (cnst.eNets.URL) {
                        let param = { payload: eNets.payload, apiKey: eNets.keyId, hmac: eNets.hmac };
                        this.redirect.post(cnst.eNets.URL, param);
                    } else {
                        //Only for local testing to bypass eNets (cannot redirect post http)
                        window.location.href = returnTypeUrl + "/" + billRefNos[0] + '/' + eNets.txnId + '/' + showDefault + '?continueUrl=' + continueUrl;
                    }
                }
            });
        }
    }
    routeToPaymentSuccessPage(showDefault: boolean, returnTypeUrl: string, paymentType: string, billRefNos: Array<string>, continueUrl: string, payNowTxnId: number) {
        if (billRefNos.length > 0) {
            if (payNowTxnId == 0) {//waive payment
                this.router.navigate([continueUrl]);
            } else {
                window.location.href = returnTypeUrl + "/" + billRefNos[0] + '/' + payNowTxnId + '/' + showDefault + '?continueUrl=' + continueUrl;
            }
        }
    }

    getPaymentRequestsForResult(anyBillRefNo: string, txnId: string): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/public/requests-for-result/' + anyBillRefNo + '/' + txnId).pipe(retryWhen(errors =>
            errors.pipe(tap(error => {
                // Retry the service every 20 seconds until eNets has callback to server, or the txn has timeout
                if (error.status !== cnst.HttpStatus.UNAVAILABLE) {
                    throw error;
                }
                this.loaderService.show();
            }), delay(20000))));
    }

    // return non-json data (i.e. QR Code image in Base64 string)
    generateQrCode(amount: number, txnId: String): Observable<any> {
        return this.http.get<string>(cnst.apiBaseUrl + '/pay-now/generate-qr-code/' + amount + '/' + txnId, { responseType: 'text' as 'json' });
    }

    createPayNowTxn(amount: number, anyBillRefNo: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/public/create-txn-paynow/' + amount + '/' + anyBillRefNo);
    }

    getPaymentTxnForICNResult(txnId: string): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/public/requests-for-icn-result/' + txnId);
    }

    getContinueUrlByTxnId(txnId: string): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + '/payment/public/get-txn-continueUrl/' + txnId);
    }
}
