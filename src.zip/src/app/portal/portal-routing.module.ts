// Others
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PortalComponent } from './portal.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentListComponent } from './payment/payment-list/payment-list.component';
import { PaymentResultComponent } from './payment/payment-result/payment-result.component';
import { PaymentPastComponent } from './payment/payment-past/payment-past.component';
import { PaymentReceiptComponent } from './payment/payment-receipt/payment-receipt.component';
import { TouristGuideComponent } from './site/content/tagaem/landing-page/tg/tourist-guide.component';
import { UserGuideComponent } from './site/content/tagaem/landing-page/user-guide/user-guide.component';
import * as cnst from '../common/constants';
// TA
import { DashboardTaComponent } from './dashboard/dashboard-ta/dashboard-ta.component';
import { TaPendingActionsComponent } from './dashboard/ta-pending-actions/ta-pending-actions.component';
import { TaApplicationsHistoryComponent } from './dashboard/ta-applications-history/ta-applications-history.component';
import { TaNotificationComponent } from './dashboard/ta-notification/ta-notification.component';
import { TaPersonnelListComponent } from './ta/ta-personnel-list/ta-personnel-list.component';
import { TaKeDeclarationComponent } from './ta/ta-ke-declaration/ta-ke-declaration.component';
import { TaBranchLicenceComponent } from './ta/ta-branch-licence/ta-branch-licence.component';
import { TaApplicationFormComponent } from './ta/ta-application-form/ta-application-form.component';
import { TaApplicationPaymentComponent } from './ta/ta-application-form/ta-application-payment/ta-application-payment.component';
import { TaApplicationSuccessComponent } from './ta/ta-application-form/ta-application-success/ta-application-success.component';
import { TaReplaceLicenceComponent } from './ta/ta-replace-licence/ta-replace-licence.component';
import { TaCeaseLicenceComponent } from './ta/ta-cease-licence/ta-cease-licence.component';
import { TaSwitchTierComponent } from './ta/ta-switch-tier/ta-switch-tier.component';
import { TaManageKeUpdateComponent } from './ta/ta-manage-ke-update/ta-manage-ke-update.component';
import { TaManageKeResignComponent } from './ta/ta-manage-ke-resign/ta-manage-ke-resign.component';
import { TaManageKeAssignComponent } from './ta/ta-manage-ke-assign/ta-manage-ke-assign.component';
import { TaAaSubmissionComponent } from './ta/ta-aa-submission/ta-aa-submission.component';
import { TaChangeFyeComponent } from './ta/ta-change-fye/ta-change-fye.component';
import { TaChangeCompayDetailsComponent } from './ta/ta-change-compay-details/ta-change-compay-details.component';
import { TaAbprSubmissionComponent } from './ta/ta-abpr-submission/ta-abpr-submission.component';
import { TaShortfallFulfilmentComponent } from './ta/ta-shortfall-fulfilment/ta-shortfall-fulfilment.component';
import { TaInboundOutboundServicesComponent } from './ta/ta-inbound-outbound-services/ta-inbound-outbound-services.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { TaBulletinComponent } from './ta/ta-bulletin/ta-bulletin.component';
import { TaLicenceRenewalComponent } from './ta/ta-licence-renewal/ta-licence-renewal.component'
import { TaMaSubmissionComponent } from './ta/ta-ma-submission/ta-ma-submission.component';
import { TaPastInfringementsComponent } from './dashboard/ta-past-infringements/ta-past-infringements.component';
import { TaDocSubmissionComponent } from './ta/ta-doc-submission/ta-doc-submission.component';

// TG
import { DashboardTgComponent } from './dashboard/dashboard-tg/dashboard-tg.component';
import { TgPendingActionsComponent } from './dashboard/tg-pending-actions/tg-pending-actions.component';
import { TgApplicationFormComponent } from './tg/tg-application-form/tg-application-form.component';
import { TgApplicationSuccessComponent } from './tg/tg-application-success/tg-application-success.component';
import { TgApplyMLPTComponent } from './tg/tg-apply-mlpt/tg-apply-mlpt.component';
import { TgRenewalPreambleComponent } from './tg/tg-renewal-preamble/tg-renewal-preamble.component';
import { TgRenewalFormComponent } from './tg/tg-renewal-form/tg-renewal-form.component';
import { TgRenewalDeclarationComponent } from './tg/tg-renewal-declaration/tg-renewal-declaration.component';
import { TgLostLicenceFormComponent } from './tg/tg-lost-licence-form/tg-lost-licence-form.component';
import { TgPastInfringementComponent } from './tg/tg-past-infringement/tg-past-infringement.component';
import { TgCancelFormComponent } from './tg/tg-cancel-form/tg-cancel-form.component';
import { TgAssignmentListComponent } from './tg/tg-assignment-process/tg-assignment-list/tg-assignment-list.component';
import { TgAssignmentViewComponent } from './tg/tg-assignment-process/tg-assignment-view/tg-assignment-view.component';
import { TgAssignmentCreateComponent } from './tg/tg-assignment-process/tg-assignment-create/tg-assignment-create.component';
import { TgUpdateParticularsComponent } from './tg/tg-update-particulars/tg-update-particulars.component';
import { TgCoursesAttendedPdcComponent } from './tg/tg-courses-attended/tg-courses-attended-pdc/tg-courses-attended-pdc.component';
import { TgCoursesAttendedMrcComponent } from './tg/tg-courses-attended/tg-courses-attended-mrc/tg-courses-attended-mrc.component';
import { TgThankyouComponent } from './tg/tg-thankyou/tg-thankyou.component';
import { TgBulletinComponent } from './tg/tg-bulletin/tg-bulletin.component';
import { TgTrainingCalendarListComponent } from './tg/tg-training-calendar/tg-training-calendar-list/tg-training-calendar-list.component';
import { TgTrainingCalendarViewComponent } from './tg/tg-training-calendar/tg-training-calendar-view/tg-training-calendar-view.component';
import { TgTrainingCalendarTpListComponent } from './tg/tg-training-calendar/tg-training-calendar-tp-list/tg-training-calendar-tp-list.component';
import { TgTrainingCalendarTpViewComponent } from './tg/tg-training-calendar/tg-training-calendar-tp-view/tg-training-calendar-tp-view.component';
import { TgStipendFormComponent } from './tg/tg-stipend-form/tg-stipend-form.component';
//TP
import { TpPDCComponent } from './tp/tp-pdc/tp-pdc.component';
import { TpPDCManageComponent } from './tp/tp-pdc-manage/tp-pdc-manage.component';
import { TpPdcManageViewComponent } from './tp/tp-pdc-manage-view/tp-pdc-manage-view.component';
import { TpPdcCourseNewComponent } from './tp/tp-pdc-course-new/tp-pdc-course-new.component';
import { TpMRCComponent } from './tp/tp-mrc/tp-mrc.component';
import { TpMRCManageComponent } from './tp/tp-mrc-manage/tp-mrc-manage.component';
import { TpMrcManageViewComponent } from './tp/tp-mrc-manage-view/tp-mrc-manage-view.component';
import { TpPdcCourseListComponent } from './tp/tp-pdc-course/tp-pdc-course-list/tp-pdc-course-list.component';
import { TpPdcCourseViewComponent } from './tp/tp-pdc-course/tp-pdc-course-view/tp-pdc-course-view.component';
import { TpProfileManageComponent } from './tp/tp-profile-manage/tp-profile-manage.component';
import { TpCourseRenewalComponent } from './tp/tp-course-renewal/tp-course-renewal.component';
import { TpApplicationSuccessComponent } from './tp/tp-application-success/tp-application-success.component';

import { LoginComponent } from './login/login.component';
import { AuthPortalGuard, PristineGuard } from './../common/guard';
import { TgSwitchTierComponent } from './tg/tg-switch-tier/tg-switch-tier.component';
import { BulletinComponent } from './bulletin/bulletin.component';

const routes: Routes = [
    { path: 'login', component: LoginComponent, data: { loginTypeCode: 'TAG' } },
    { path: 'login-sp', component: LoginComponent, data: { loginTypeCode: 'SP' } },
    { path: 'login-cp', component: LoginComponent, data: { loginTypeCode: 'CP' } },
    { path: 'login-portal', component: LoginComponent, data: { loginTypeCode: 'PORTAL' } },
    { path: 'infohub', component: BulletinComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.AEM } },
    { path: 'payment-list', component: PaymentListComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.AEM } },
    { path: 'touristGuide', component: TouristGuideComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.AEM,touristGuideStatusCode: cnst.TouristGuideStatusCode.TG_A} },
    { path: 'userGuide', component: UserGuideComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.AEM,touristGuideStatusCode: cnst.TouristGuideStatusCode.TG_A} },
    { path: '1/:anyBillRefNo/:txnId/:showDefault', component: PaymentResultComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.AEM } },
    {
        path: '',
        component: PortalComponent,
        canActivate: [AuthPortalGuard],
        children: [
            // For testing iams in uat/stg env
            { path: 'dashboard-ta-testing-iams', component: DashboardTaComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'dashboard-tg-portal-testing-iams', component: DashboardTgComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: 'dashboard-tg-testing-iams', component: DashboardTgComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: 'dashboard-tp-testing-iams', component: DashboardComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TP } },
            { path: 'ta-application-form-testing-iams', component: TaApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'tg/application-form-testing-iams', component: TgApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, canDeactivate: [PristineGuard] },
            { path: 'tg-portal/application-form-testing-iams', component: TgApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, canDeactivate: [PristineGuard] },
            // Others
            { path: 'dashboard-ta', component: DashboardTaComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'dashboard-tg-portal', component: DashboardTgComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: 'dashboard-tg', component: DashboardTgComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: 'dashboard-tp', component: DashboardComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TP } },
            { path: 'payment/:successLink', component: PaymentComponent },
            { path: 'payment/:tgType/application/:module', component: PaymentComponent },
            { path: 'ta/payment-past', component: PaymentPastComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-cdd/payment-past', component: PaymentPastComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'tg/payment-past', component: PaymentPastComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: 'ta/payment-receipt/:txnId', component: PaymentReceiptComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'tg/payment-receipt/:txnId', component: PaymentReceiptComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: 'ta-thankyou', component: ThankyouComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-thankyou/:billRefNo', component: ThankyouComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-thankyou/:billRefNo/:continueUrl', component: ThankyouComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'tg-thankyou', component: TgThankyouComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            // TA
            { path: 'ta-applications-history', component: TaApplicationsHistoryComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-past-infringements', component: TaPastInfringementsComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-pending-actions', component: TaPendingActionsComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-notifications', component: TaNotificationComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-personnel-list', component: TaPersonnelListComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-manage-ke-update', component: TaManageKeUpdateComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-manage-ke-update/:appId', component: TaManageKeUpdateComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-manage-ke-resign', component: TaManageKeResignComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-manage-ke-resign/:appId', component: TaManageKeResignComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-manage-ke-assign', component: TaManageKeAssignComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-manage-ke-assign/:appId', component: TaManageKeAssignComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-aa-submission/:appId', component: TaAaSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-aa-submission', component: TaAaSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-change-fye', component: TaChangeFyeComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-change-fye/:appId', component: TaChangeFyeComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-ke-declaration', component: TaKeDeclarationComponent },
            { path: 'ta-change-company-details', component: TaChangeCompayDetailsComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-inbound-outbound-services', component: TaInboundOutboundServicesComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-change-company-details/:appId', component: TaChangeCompayDetailsComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-make-payment', component: PaymentListComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-make-payment/:appId', component: PaymentListComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: '2/:anyBillRefNo/:txnId/:showDefault', component: PaymentResultComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-bulletin/:bulletinId', component: TaBulletinComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA } },
            { path: 'ta-application-form', component: TaApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'ta-application-form/:id', component: TaApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'ta-application-form/:id/:stepNo', component: TaApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'ta-application-payment', component: TaApplicationPaymentComponent },
            { path: '3/:anyBillRefNo/:txnId/:showDefault', component: PaymentResultComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'ta-application-success/:appId/:anyBillRefNo/:paymentType', component: TaApplicationSuccessComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'ta-application-success/:appId', component: TaApplicationSuccessComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TACDD } },
            { path: 'ta-replace-licence/:appId', component: TaReplaceLicenceComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-replace-licence/:appId/:billRefNo/:paymentFailed/:appFailed', component: TaReplaceLicenceComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-cease-licence/:appId', component: TaCeaseLicenceComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-application-branch-licence', component: TaBranchLicenceComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-application-branch-licence/:appId', component: TaBranchLicenceComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-switch-tier/:appId', component: TaSwitchTierComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-switch-tier', component: TaSwitchTierComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-abpr-submission', component: TaAbprSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-abpr-submission/:appId', component: TaAbprSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-shortfall-fulfilment', component: TaShortfallFulfilmentComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-shortfall-fulfilment/:appId', component: TaShortfallFulfilmentComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-renew-licence/:appId', component: TaLicenceRenewalComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-renew-licence', component: TaLicenceRenewalComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-ma-submission', component: TaMaSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-ma-submission/:appId', component: TaMaSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-doc-submission', component: TaDocSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },
            { path: 'ta-doc-submission/:appId', component: TaDocSubmissionComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TA }, canDeactivate: [PristineGuard] },

            // TG
            { path: 'tg-pending-actions', component: TgPendingActionsComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: 'tg/application-form', component: TgApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, canDeactivate: [PristineGuard] },
            { path: 'tg/application-form/:id', component: TgApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, canDeactivate: [PristineGuard] },
            { path: 'tg-portal/application-form', component: TgApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, canDeactivate: [PristineGuard] },
            { path: 'tg-portal/application-form/:id', component: TgApplicationFormComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, canDeactivate: [PristineGuard] },
            { path: 'tg/application-success/:module', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgApplicationSuccessComponent },
            { path: 'tg/application-success/:module/:appId', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgApplicationSuccessComponent },
            { path: 'tg/application-success/:module/:appId/:anyBillRefNo', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgApplicationSuccessComponent },
            { path: 'tg/application-success/:module/licence-print/:anyBillRefNo/:mlptId', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgApplicationSuccessComponent },
            { path: 'tg/renewal-preamble', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgRenewalPreambleComponent },
            { path: 'tg/renewal-form', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgRenewalFormComponent },
            { path: 'tg/renewal-form/:renewalConditions', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgRenewalFormComponent },
            { path: 'tg/renewal-declaration', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgRenewalDeclarationComponent },
            { path: 'tg/lost-licence-form', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgLostLicenceFormComponent, canDeactivate: [PristineGuard] },
            { path: 'tg/lost-licence-form/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgLostLicenceFormComponent, canDeactivate: [PristineGuard] },
            { path: 'tg/past-infringement', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgPastInfringementComponent },
            { path: 'tg/cancel-form', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgCancelFormComponent },
            { path: 'tg/cancel-form/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgCancelFormComponent },
            { path: 'tg/assignments/archive/view', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgAssignmentListComponent },
            { path: 'tg/assignments/view', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgAssignmentListComponent },
            { path: 'tg/assignments/archive/view/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgAssignmentViewComponent },
            { path: 'tg/assignments/view/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgAssignmentViewComponent },
            { path: 'tg/assignments/create', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgAssignmentCreateComponent },
            { path: 'tg/assignments/create/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgAssignmentCreateComponent },
            { path: 'tg/assignments/update/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgAssignmentCreateComponent },
            { path: 'tg/particulars/view', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgUpdateParticularsComponent, canDeactivate: [PristineGuard] },
            { path: 'tg/particulars/view/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgUpdateParticularsComponent, canDeactivate: [PristineGuard] },
            { path: 'tg/tg-courses-attended-pdc', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgCoursesAttendedPdcComponent },
            { path: 'tg/tg-courses-attended-mrc', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgCoursesAttendedMrcComponent },
            { path: 'tg/tg-thankyou', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgThankyouComponent },
            { path: 'tg/tg-bulletin/:bulletinId', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgBulletinComponent },
            { path: '4/:anyBillRefNo/:txnId/:showDefault', component: PaymentResultComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG } },
            { path: '5/:anyBillRefNo/:txnId/:showDefault', component: PaymentResultComponent, data: { dashboardTypeCode: cnst.dashboardTypeCode.TG, isCandidate: true } },
            { path: 'tg/apply-mlpt', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgApplyMLPTComponent },
            { path: 'tg/apply-mlpt/:mlptId', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgApplyMLPTComponent },
            { path: 'tg/switch-tier', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgSwitchTierComponent },
            { path: 'tg/switch-tier/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgSwitchTierComponent },
            { path: 'tg/training-calendar/cse/list', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgTrainingCalendarListComponent },
            { path: 'tg/training-calendar/cse/view/:code', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgTrainingCalendarViewComponent },
            { path: 'tg/training-calendar/tp/list', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgTrainingCalendarTpListComponent },
            { path: 'tg/training-calendar/tp/view/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgTrainingCalendarTpViewComponent },
            { path: 'tg/stipend-form', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgStipendFormComponent },
            { path: 'tg/stipend-form/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgStipendFormComponent },
            { path: 'tg/stipend-form/app/:appId', data: { dashboardTypeCode: cnst.dashboardTypeCode.TG }, component: TgStipendFormComponent },
            //TP
            { path: 'tp-PDC', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpPDCComponent },
            { path: 'tp-PDC-manage', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpPDCManageComponent },
            { path: 'tp-PDC-manage/view/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpPdcManageViewComponent },
            { path: 'tp-MRC', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpMRCComponent },
            { path: 'tp-MRC-manage', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpMRCManageComponent },
            { path: 'tp-MRC-manage/view/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpMrcManageViewComponent },
            { path: 'tp-profile-manage', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpProfileManageComponent },
            { path: 'tp-pdc-courses', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpPdcCourseListComponent },
            { path: 'tp-pdc-courses/view/:code', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpPdcCourseViewComponent, canDeactivate: [PristineGuard] },
            { path: 'tp-pdc-courses/renew/:code', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpCourseRenewalComponent, canDeactivate: [PristineGuard] },
            { path: 'tp-pdc-courses/renew/app/:appId', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpCourseRenewalComponent },
            { path: 'tp-application-success/:module/:appId', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpApplicationSuccessComponent },
            { path: 'tp-pdc-courses/new', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpPdcCourseNewComponent, canDeactivate: [PristineGuard] },
            { path: 'tp-pdc-courses/new/:id', data: { dashboardTypeCode: cnst.dashboardTypeCode.TP }, component: TpPdcCourseNewComponent },


        ]
    }];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PortalRoutingModule { }
