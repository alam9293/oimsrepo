import { Component, OnInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { AuthenticationService } from '../common/services';
import { AppUtil } from '../common/helper';
import { User } from '../common/models';
import * as cnst from '../common/constants';

@Component({
    selector: 'app-portal',
    templateUrl: './portal.component.html',
    styleUrls: ['./portal.component.scss']
})

export class PortalComponent implements OnInit {
    dashboardTypeCode: string;
    currentUser: User;
    cnst = cnst;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private appUtil: AppUtil
    ) { }

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.firstChild.data.dashboardTypeCode;
        this.currentUser = this.authenticationService.currentUserValue;

        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };

        this.router.events.subscribe((evt) => {
            if (evt instanceof NavigationEnd) {
                this.router.navigated = false;
                window.scrollTo(0, 0);
            }
        });
    }

    onLoggedout() {
        this.authenticationService.logout();
        // this.appUtil.routeToHomePage();
    }
}
