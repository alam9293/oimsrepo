import { SelectionModel } from '@angular/cdk/collections';
import { SuccessSnackbarComponent } from '../../../../../../common/modules/success-snackbar/success-snackbar.component';
import { MatTableDataSource, MatSnackBar, MatDialog } from '@angular/material';
import { TouristGuideService } from './tourist-guide.services';
import { LoaderService } from '../../../../../../common/services/loader.service';
import { PaymentDialogComponent } from '../../../../../../common/modules/payment-dialog/payment-dialog.component';
import * as cnst from '../../../../../../common/constants';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService, AlertService, MyInfoService, EdhService } from '../../../../../../common/services';
import { FormUtil } from '../../../../../../common/helper';

import { DashboardTaService } from '../../../../../dashboard/dashboard-ta/dashboard-ta.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { TouristGuide } from '../../../../../../common/models/TouristGuide';
import { Observable,Subject } from "rxjs";

@Component({
    selector: 'app-site',
    templateUrl: './tourist-guide.component.html',
    styleUrls: ['./tourist-guide.component.scss']
})
export class TouristGuideComponent implements OnInit {
    dashboardTypeCode: string;
    touristGuideStatusCode: string;
    touristGuideLanguageMap: Map<string,string>;
    touristGuideCategoryMap: Map<string,string>;
    touristGuideAreaMap: Map<string,string>;
    cnst = cnst;
    touristGuides: Observable<TouristGuide[]>;
    dtTrigger: Subject<any>= new Subject();
    
    
   
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private dashboardService: DashboardTaService,
        private formBuilder: FormBuilder,
        private touristGuideService: TouristGuideService,
        private loaderService: LoaderService,
        private snackBar: MatSnackBar,
        public dialog: MatDialog,
        public alertService: AlertService,
        public formUtil: FormUtil) { }

    ngOnInit() {

        console.log("*************");
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        this.touristGuideStatusCode = this.route.snapshot.data.touristGuideStatusCode;
        this.touristGuideLanguageMap = cnst.TouristGuideLanguages.tgLanguagesMap;
        this.touristGuideCategoryMap = cnst.TouristGuideCategories.tgCategoryMap;
        this.touristGuideAreaMap = cnst.TouristGuideAreas.tgAreaMap;
 
        this.touristGuideService.getTouristGuideList().subscribe(data =>{
            this.touristGuides =data;
            this.dtTrigger.next();
        })
    }

}
