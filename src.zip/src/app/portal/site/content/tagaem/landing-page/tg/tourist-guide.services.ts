import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as cnst from '../../../../../../common/constants';

@Injectable({
  providedIn: 'root'
})

export class TouristGuideService {

  

  constructor(private http:HttpClient) { }

  getTouristGuideList(status: string): Observable<any> {
    return this.http.get(`${cnst.apiBaseUrl}/directory/tg/licensed`);
    
  }

  
  
}                                           