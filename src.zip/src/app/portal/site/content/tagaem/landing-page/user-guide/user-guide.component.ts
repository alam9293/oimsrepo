import * as cnst from '../../../../../../common/constants';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterModule, Routes } from '@angular/router';


@Component({
    selector: 'app-site',
    templateUrl: './user-guide.component.html',
    styleUrls: ['./user-guide.component.scss']
})

export class UserGuideComponent implements OnInit {
    dashboardTypeCode: string;
    cnst = cnst;
    
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        
       ) { }
        
    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
       
    }
  
}