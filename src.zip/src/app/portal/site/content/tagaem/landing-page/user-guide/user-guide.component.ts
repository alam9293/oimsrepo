import { SelectionModel } from '@angular/cdk/collections';
import { SuccessSnackbarComponent } from '../../../../../../common/modules/success-snackbar/success-snackbar.component';
import { MatTableDataSource, MatSnackBar, MatDialog } from '@angular/material';
import { UserGuideService } from './user-guide.services';
import { LoaderService } from '../../../../../../common/services/loader.service';
import { PaymentDialogComponent } from '../../../../../../common/modules/payment-dialog/payment-dialog.component';
import * as cnst from '../../../../../../common/constants';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService, AlertService, MyInfoService, EdhService } from '../../../../../../common/services';
import { FormUtil } from '../../../../../../common/helper';

import { DashboardTaService } from '../../../../../dashboard/dashboard-ta/dashboard-ta.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from "lodash";
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { Observable,Subject } from "rxjs";
import { saveAs } from 'file-saver';

@Component({
    selector: 'app-site',
    templateUrl: './user-guide.component.html',
    styleUrls: ['./user-guide.component.scss']
})
export class UserGuideComponent implements OnInit {
    dashboardTypeCode: string;
    cnst = cnst;
    
   
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private dashboardService: DashboardTaService,
        private formBuilder: FormBuilder,
        private userGuideService: UserGuideService,
        private loaderService: LoaderService,
        private snackBar: MatSnackBar,
        public dialog: MatDialog,
        public alertService: AlertService,
        public formUtil: FormUtil) { }
        

    ngOnInit() {

        console.log("*************");
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
      
    }

    

    //   download(fileName: string): void {
    //     this.userGuideService
    //       .downloadFile(fileName)
    //       .subscribe(blob => {
            
    //         if (blob == null) {
    //             console.log(cnst.Messages.MSG_NO_FILE);
    //             this.alertService.error(cnst.Messages.MSG_NO_FILE);
    //         }
    //         else
    //         {
    //             this.alertService.error("Saving File.....");
    //             saveAs(blob, fileName);
    //         }
    //     });
    //   }

    //   download(fileName: string) {
	// 	this.userGuideService.downloadFile(fileName).subscribe((ResponseEntity: any) => {
    //         console.log('file loading.....');
	// 		let blob:any = new Blob([ResponseEntity.blob], { type: 'text/json; charset=utf-8' });
	// 		const url = window.URL.createObjectURL(blob);
	// 		//window.open(url);
	// 		saveAs(blob, 'employees.json');
	// 		}), (error: any) => console.log('Error downloading the file'),
	// 		() => console.info('File downloaded successfully');
	// }

    download(fileName: string) {
		this.userGuideService.downloadFile(fileName).subscribe((data:any) => {
            if(data === null)
            {
                console.log('No file Found.....');
            }
            else
            {
                console.log('file loading.....');
                let blob:any = new Blob([data], {type: 'application/pdf'});
                var downloadURL = window.URL.createObjectURL(data);
                var link = document.createElement('a');
                link.href = downloadURL;
                link.download = fileName;
                link.click();
            }
			
	});

}
}