
import { UserGuideService } from './user-guide.services';
import * as cnst from '../../../../../../common/constants';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterModule, Routes } from '@angular/router';



@Component({
    selector: 'app-site',
    templateUrl: './user-guide.component.html',
    styleUrls: ['./user-guide.component.scss']
})
export class UserGuideComponent implements OnInit {
    dashboardTypeCode: string;
    cnst = cnst;
    
   
    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private userGuideService: UserGuideService,
       ) { }
        

    ngOnInit() {

        console.log("*************");
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
      
    }

    download(fileName: string) {
		this.userGuideService.downloadFile(fileName).subscribe((data:any) => {
            if(data === null)
            {
                console.log('No file Found.....');
            }
            else
            {
                try
                {
                    console.log('file loading.....'+data);
                    let blob:any = new Blob([data], {type: 'application/pdf'});
                    var downloadURL = window.URL.createObjectURL(data);
                    var link = document.createElement('a');
                    link.href = downloadURL;
                    link.download = fileName;
                    link.click();
                }
                catch(e)
                {
                    console.log(e);
                }
            }
    	});

    }
}