import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as cnst from '../../../../../../common/constants';

@Injectable({
  providedIn: 'root'
})

export class UserGuideService {

  constructor(private http:HttpClient) { }

  downloadFile(docName: string){
    console.log("downloading file......");
    const httpOptions = {
      responseType: 'blob' as 'json'
    };
    try
    {
		  // return this.http.get(`${cnst.apiBaseUrl}/file/downloadFile/${docName}`, {responseType: 'blob'});
      return this.http.get(`${cnst.apiBaseUrl}/file/downloadFile/${docName}`, httpOptions);
    }
    catch(e){
      console.log(e,'error')
    }
  }
  
}                                           