import { Component, Inject, HostListener } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import * as dto from './ta-branch-licence.component-dto';
import * as _ from "lodash";
import { TaBranchService } from './ta-branch-licence.service';
import { CommonService } from '../../../common/services';
import { ActivatedRoute, Router } from '@angular/router'
import * as cnst from '../../../common/constants';
import { FileUtil, DateUtil, ValidateAddressInput, ValidateAddressInputIncDash } from '../../../common/helper';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { AbstractControl, FormBuilder, FormArray, FormControl, FormGroup, Validators, ValidatorFn } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'ta-ceased-branches-dialog',
    templateUrl: 'ta-ceased-branches-dialog.html',
    styleUrls: ['./ta-branch-licence.component.scss']
})
export class DialogTaCeasedBranches {
    constructor(
        public dialogRef: MatDialogRef<DialogTaCeasedBranches>, @Inject(MAT_DIALOG_DATA) public data: any) {

    }
    ceased = this.data;
    onNoClick(): void {
        this.dialogRef.close();
    }
}

@Component({
    selector: 'ta-manage-branch-dialog',
    templateUrl: 'ta-manage-branch-dialog.html',
    styleUrls: ['./ta-branch-licence.component.scss']
})
export class DialogTaManageBranch {
    constructor(private formBuilder: FormBuilder,
        public dialogRef: MatDialogRef<DialogTaManageBranch>, private http: HttpClient, @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, private route: ActivatedRoute, private service: TaBranchService, private commonService: CommonService, private fileUtil: FileUtil) { }
    lcnst = dto;
    action: string = null;
    new: dto.BranchDto;
    cease: dto.BranchDto;
    premisesOnLoad: boolean = false;
    postalCode2Blk: string;
    postalCode2Street: string;
    selectedFile: File;
    cnst = cnst;
    form: FormGroup;
    ceaseForm: FormGroup;
    postalCodeCount: boolean = false;
    postalCodeOptions = [];
    blkOptions = [];
    streetOptions = [];
    buidlingNameOptions = [];
    blkLoad: boolean = true;
    streetLoad: boolean = true;
    editedBranch: any;
    isEdited: boolean = false;
    isLoaded: boolean = false;
    ngOnInit() {
        this.isLoaded = false;
        this.isEdited = this.data.isEdited;
        this.buildForm();
        if (this.data.edit && this.data.isEdited) {
            setTimeout(() => {
                this.addNewUpdateBranch(this.data.edit.type);
                if (this.action == this.lcnst.LocalConstants.BRANCH_UPDATE || this.action == this.lcnst.LocalConstants.BRANCH_NEW) {
                    if (this.action == this.lcnst.LocalConstants.BRANCH_UPDATE) {
                        this.data.active.push(this.data.edit.toReplace);
                        this.form.controls['formerBranches'].setValue(this.data.edit.toReplace);
                    }
                    this.form.controls['postalCode'].setValue(this.data.edit.postalCode);
                    this.form.controls['level'].setValue(this.data.edit.level);
                    this.form.controls['unit'].setValue(this.data.edit.unit);
                    this.form.controls['buildingName'].setValue(this.data.edit.buildingName, { onlySelf: true });
                    this.form.controls['blk'].setValue(this.data.edit.blk);
                    this.form.controls['street'].setValue(this.data.edit.street);
                    this.form.controls['applicationBranchId'].setValue(this.data.edit.applicationBranchId);

                    console.log(this.data.edit);
                    if (this.data.edit.tenancyStartDate) {
                        //    this.new.tenancyStartDate = moment(this.form.value.tenancyStartDate, DateUtil.DATE_FORMAT).format(DateUtil.DATE_FORMAT);
                        this.form.controls['tenancyStartDate'].setValue(moment(this.data.edit.tenancyStartDate, 'DD-MMM-YYYY'));
                    }
                    if (this.data.edit.tenancyEndDate) {
                        // this.new.tenancyEndDate = moment(this.form.value.tenancyEndDate, DateUtil.DATE_FORMAT).format(DateUtil.DATE_FORMAT);
                        this.form.controls['tenancyEndDate'].setValue(moment(this.data.edit.tenancyEndDate, 'DD-MMM-YYYY'));
                    }


                    //  this.form.controls['tenancyEndDate'].setValue(moment(this.data.edit.tenancyEndDate, 'DD-MMM-YYYY'));
                    this.form.controls['fileDoc'].setValue(this.data.edit.selectedFile.originalName);
                    //  console.log(this.data.edit);
                    //   (<HTMLInputElement>document.getElementById("fileSupportingDocument")).files[0] = this.data.edit.selectedFile.originalName;
                    this.form.controls['premisesTypes'].get('key').setValue(this.data.edit.premisesType, { onlySelf: true });
                    if (this.data.edit.selectedFile) {
                        this.selectedFile = this.data.edit.selectedFile;
                        this.form.patchValue({ branchDoc: this.selectedFile });
                        this.new.selectedFile = this.selectedFile;
                        this.new.originalFileName = this.selectedFile['originalName'];
                        this.new.docFileType = this.selectedFile['docType'];
                        this.new.supportingDocument = this.selectedFile['originalName'];
                        this.form.controls['fileDoc'].setValue(this.selectedFile['originalName']);
                        //     (<HTMLInputElement>document.getElementById("fileSupportingDocument")).name = this.selectedFile['originalName'];
                    }
                }
                else if (this.action == this.lcnst.LocalConstants.BRANCH_CEASE || this.action == this.lcnst.LocalConstants.BRANCH_CESSATION) {
                    this.data.active.push(this.data.edit);
                    this.ceaseForm.controls['formerBranches'].setValue(this.data.edit);
                }
            }
            )
        }

        this.formControlValueChanged();
        this.isLoaded = true;
    }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        this.ceaseForm.pristine;
        return this.form.pristine;
    }
    formControlValueChanged() {

        this.dialogRef.afterClosed().subscribe(() => {
            this.ceaseForm.pristine;
            this.form.pristine;
        });
        const formerBranches = this.form.get('formerBranches');
        if (this.action == this.lcnst.LocalConstants.BRANCH_NEW) {
            formerBranches.get('key').clearValidators();
        }
        else if (this.action == this.lcnst.LocalConstants.BRANCH_UPDATE) {

        }

        this.form.get('formerBranches').valueChanges.subscribe(
            (formerBranches: any) => {
                this.new.toReplace = formerBranches;
            });
        // console.log(this.ceaseForm.valid);
        this.ceaseForm.get('formerBranches').valueChanges.subscribe(
            (formerBranches: any) => {
                this.cease = formerBranches;
            });
        this.form.get('postalCode').valueChanges.subscribe(
            (postalCode: any) => {
                const isNumber = /^\d+$/.test(postalCode.toString());
                if (isNumber && postalCode.length == 6 && !isNaN(parseInt(postalCode.toString(), 10))) {
                    this.postalCodeCount = true;
                    this.new.postalCode = postalCode;
                    this.commonService.getPostalCodeAddress(parseInt(this.new.postalCode.toString(), 10)).subscribe(data => {
                        this.blkOptions = [];
                        this.streetOptions = [];
                        this.buidlingNameOptions = [];
                        this.postalCodeOptions = [];
                        if (data['results'].length) {
                            this.new.blk = data['results'][0]['BLK_NO'];
                            this.new.street = data['results'][0]['ROAD_NAME'];
                            this.new.buildingName = data['results'][0]['BUILDING'];
                            if (this.data.isEdited && postalCode === this.data.edit.postalCode) {
                                this.form.controls['blk'].setValue(this.data.edit.blk);
                                this.form.controls['street'].setValue(this.data.edit.street);
                                this.form.controls['buildingName'].setValue(this.data.edit.buildingName);
                            } else {
                                this.form.controls['blk'].setValue(data['results'][0]['BLK_NO']);
                                this.form.controls['street'].setValue(data['results'][0]['ROAD_NAME']);
                                this.form.controls['buildingName'].setValue(data['results'][0]['BUILDING']);

                            }
                            data['results'].forEach(element => {
                                this.blkOptions.push(element['BLK_NO']);
                                this.streetOptions.push(element['ROAD_NAME']);
                                this.buidlingNameOptions.push(element['BUILDING']);
                            });
                            this.blkOptions = Array.from(new Set(this.blkOptions));
                            this.streetOptions = Array.from(new Set(this.streetOptions));
                            this.buidlingNameOptions = Array.from(new Set(this.buidlingNameOptions));
                        }
                        this.form.controls['blk'].setValidators(Validators.compose([Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK)]));
                        this.form.controls['street'].setValidators(Validators.compose([Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)]));
                        this.form.controls['buildingName'].setValidators(Validators.compose([Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)]));
                        this.form.controls['blk'].updateValueAndValidity();
                        this.form.controls['street'].updateValueAndValidity();
                        this.form.controls['buildingName'].updateValueAndValidity();
                    });
                }
                else if (this.postalCodeCount) {
                    this.new.blk = '';
                    this.new.street = '';
                    this.new.buildingName = '';
                    this.form.controls['blk'].setValue('');
                    this.form.controls['street'].setValue('');
                    this.form.controls['buildingName'].setValue('');
                    this.postalCodeCount = false;
                }
            });

    }
    buildForm() {
        const listableDto = this.formBuilder.group({
            key: ['', Validators.required],
            label: ['']
        });

        const fileDto = this.formBuilder.group({
            id: [],
            publicFileId: [],
            originalName: ['', Validators.required],
            processedName: [],
            docType: [],
            extension: [],
            path: [],
            size: [],
            hash: [],
            documentInstructions: [],
            documentTypeLabel: [],
            description: [],
            readableFileSize: [],
            hasTemplate: [],
        });
        this.form = this.formBuilder.group({
            applicationBranchId: [],
            formerBranches: ['', Validators.required],
            premisesTypes: listableDto,
            level: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
            unit: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.UNIT), ValidateAddressInput]],
            buildingName: ['', Validators.compose([Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING), ValidateAddressInputIncDash])],
            blk: ['', Validators.compose([Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput])],
            street: ['', Validators.compose([Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET), ValidateAddressInputIncDash])],
            postalCode: ['', Validators.compose([Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput])],
            tenancyStartDate: [''],
            tenancyEndDate: [''],
            branchDoc: fileDto,
            fileDoc: [null, Validators.required],
            statusLabel: [],
        }, {
            validator: this.validateDate
        }

        );
        this.ceaseForm = this.formBuilder.group({
            formerBranches: ['', Validators.required]
        }, {
        }

        );
    }

    validateDate(group: FormGroup) {
        if (group.get('tenancyStartDate').value != '' && group.get('tenancyEndDate').value != '') {
            const invalidStartEqualEndDate = moment(group.get('tenancyStartDate').value, DateUtil.DATE_FORMAT).isSame(moment(group.get('tenancyEndDate').value, DateUtil.DATE_FORMAT));
            if (invalidStartEqualEndDate) {
                group.get('tenancyStartDate').setErrors({ 'invalidStartEqualEndDate': true });
                group.get('tenancyEndDate').setErrors({ 'invalidStartEqualEndDate': true });
            }
            const invalidStartGreaterEndDate = moment(group.get('tenancyStartDate').value, DateUtil.DATE_FORMAT).isAfter(moment(group.get('tenancyEndDate').value, DateUtil.DATE_FORMAT));
            //group.get('tenancyStartDate').value > group.get('tenancyEndDate').value;
            if (invalidStartGreaterEndDate) {
                group.get('tenancyStartDate').setErrors({ 'invalidStartGreaterEndDate': true });
                group.get('tenancyEndDate').setErrors({ 'invalidStartGreaterEndDate': true });
            }
            if (!invalidStartEqualEndDate && !invalidStartGreaterEndDate) {
                group.get('tenancyStartDate').setErrors(null);
                group.get('tenancyEndDate').setErrors(null);
            }
        }
        return null;
    }

    // postalCodeValidator(options: any): ValidatorFn {
    //     return (control: AbstractControl): { [key: string]: any } | null => {
    //         const valid = options.some(function (data) { return data.toLowerCase() === control.value.toLowerCase() });
    //         return valid ? null : { invalidOptions: { valid: false, value: control.value } };
    //     };
    // }
    // postalCodeNumberValidator(control: AbstractControl): { [key: string]: any } | null {
    //     const valid = /^\d+$/.test(control.value);
    //     return valid ? null : { invalidNumber: { valid: false, value: control.value } };
    // }
    // postalCodeLengthValidator(control: AbstractControl): { [key: string]: any } | null {
    //     const valid = /\d{6}/.test(control.value) && /^\d+$/.test(control.value);
    //     return valid ? null : { invalidCount: { valid: false, value: control.value } };
    // }
    onFileChangedForm(event, type) {
        this.selectedFile = event.target.files[0];
        // console.log(this.selectedFile);
        this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                if (type == cnst.DocumentTypes.TA_DOC_BRANCH) {
                    //    console.log(data);
                    this.form.patchValue({ branchDoc: data });
                    this.new.selectedFile = data;
                    this.new.originalFileName = data['originalName'];
                    this.new.docFileType = data['docType'];
                    this.new.supportingDocument = data['originalName'];
                    this.form.controls['fileDoc'].setValue(data['originalName']);
                }
            }
        });

    }
    validateAllFormFields(formGroup: FormGroup | FormArray) {         //{1}
        Object.keys(formGroup.controls).forEach(field => {  //{2}
            const control = formGroup.get(field);             //{3}
            if (control instanceof FormControl) {             //{4}
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup || control instanceof FormArray) {        //{5}
                this.validateAllFormFields(control);            //{6}
            }
        });
    }
    onSubmit() {
        if (this.form.valid) {
            this.new.level = this.form.value.level;
            this.new.unit = this.form.value.unit;
            this.new.blk = this.form.value.blk;
            this.new.street = this.form.value.street;
            this.new.postalCode = this.form.value.postalCode;
            this.new.buildingName = this.form.value.buildingName;
            this.new.premisesType = this.form.get('premisesTypes.key').value;
            if (this.form.value.tenancyStartDate) {
                this.new.tenancyStartDate = moment(this.form.value.tenancyStartDate, DateUtil.DATE_FORMAT).format(DateUtil.DATE_FORMAT);
            }
            if (this.form.value.tenancyEndDate) {
                this.new.tenancyEndDate = moment(this.form.value.tenancyEndDate, DateUtil.DATE_FORMAT).format(DateUtil.DATE_FORMAT);
            }
            this.new.applicationBranchId = this.form.value.applicationBranchId;
            console.log(this.form);

            this.addressDisplay();
            if (this.action == this.lcnst.LocalConstants.BRANCH_NEW) {
                this.new.fee = this.lcnst.LocalConstants.taBranchApplicationFeeLabel;
            }
            if (this.data.edit) {
                var index = this.data.applications.indexOf(this.data.edit);
                this.data.applications.splice(index, 1);
            }

            this.data.applications.push(this.new);
            if (this.action == this.lcnst.LocalConstants.BRANCH_UPDATE) {
                var index = this.data.active.indexOf(this.new.toReplace);
                this.data.active.splice(index, 1);
            }
            this.data.isEdited = false;
            this.dialogRef.close(this.data);
        }
        else {
            this.validateAllFormFields(this.form);
        }
    }
    reset() {
        this.form.reset();
    }

    addressDisplay() {
        this.new.level = (this.new.level) ? this.new.level.trim().toLocaleUpperCase() : '';
        this.new.unit = (this.new.unit) ? this.new.unit.trim().toLocaleUpperCase() : '';
        this.new.blk = (this.new.blk) ? this.new.blk.trim().toLocaleUpperCase() : '';
        this.new.street = (this.new.street) ? this.new.street.trim().toLocaleUpperCase() : '';
        this.new.postalCode = (this.new.postalCode) ? this.new.postalCode.trim().toLocaleUpperCase() : '';
        this.new.buildingName = (this.new.buildingName) ? this.new.buildingName.trim().toLocaleUpperCase() : '';
        var floorUnit = "";
        if (this.new.level != "" && this.new.unit != "") {
            floorUnit = "#" + this.new.level.trim().toLocaleUpperCase() + "-" + this.new.unit.trim().toLocaleUpperCase();
        }
        if (this.new.level != "" && this.new.unit == "") {
            floorUnit = this.new.level.trim().toLocaleUpperCase();
        }
        this.new.formatAddress = this.new.blk.trim().toLocaleUpperCase() + " " + this.new.street.trim().toLocaleUpperCase() + "<br/>" + floorUnit.toLocaleUpperCase() + " " + this.new.buildingName.toLocaleUpperCase() +
            "<br/>" + "Singapore".toLocaleUpperCase() + " " + this.new.postalCode.trim().toLocaleUpperCase();
    }
    ceaseConfirm() {
        if (this.ceaseForm.valid) {
            if (this.data.edit) {
                var index = this.data.applications.indexOf(this.data.edit);
                this.data.applications.splice(index, 1);
            }
            this.cease.type = this.lcnst.LocalConstants.BRANCH_CESSATION;
            var index = this.data.active.indexOf(this.cease);
            this.data.active.splice(index, 1);
            this.cease.supportingDocument = '';
            this.data.applications.push(this.cease);
            this.dialogRef.close(this.data);
        }
        else {
            this.validateAllFormFields(this.form);
        }
    }

    addNewUpdateBranch(type) {
        this.action = type;
        const formerBranches = this.form.get('formerBranches');
        if (this.action == this.lcnst.LocalConstants.BRANCH_NEW) {
            formerBranches.clearValidators();
        }
        this.new = { applicationBranchId: null, branchId: null, selectedFile: null, formatAddress: null, originalFileName: null, docFileType: null, licenceNo: null, address: null, blk: null, street: null, buildingName: null, level: null, unit: null, postalCode: null, premisesType: null, tenancyStartDate: null, tenancyEndDate: null, supportingDocument: '', status: '-', statusLabel: null, type: type, fee: null, toReplace: null, previousBranches: null, previousBranchesId: null };
        console.log(this.new);
    }

    onNoClick(): void {
        if (this.data.edit && (this.action == this.lcnst.LocalConstants.BRANCH_UPDATE || this.action == this.lcnst.LocalConstants.BRANCH_CEASE || this.action == this.lcnst.LocalConstants.BRANCH_CESSATION)) {
            var index = this.data.active.indexOf(this.data.edit);
            this.data.active.splice(index, 1);
        }

        this.form.pristine;
        this.dialogRef.close();
    }
    onDateChange(item, form) {
        form.controls[item].setValue(form.get(item).value);
    }
    removeFileForm(id, obj, type) {
        var deleteList = [];
        deleteList.push(this.new.selectedFile['id']);
        if (type == cnst.DocumentTypes.TA_DOC_BRANCH) {
            this.form.patchValue({
                branchDoc: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    documentInstructions: '',
                    documentTypeLabel: '',
                    description: '',
                    readableFileSize: '',
                }
            }
            )
            obj = null;
            this.form.controls['fileDoc'].setValue('');
            // this.fileUtil.delete(deleteList).subscribe(data => {
            this.new.selectedFile = null;
            this.new.originalFileName = null;
            this.new.docFileType = null;
            this.new.supportingDocument = null;
            (<HTMLInputElement>document.getElementById(id)).value = '';
            // });
        }
    }
}











