
import { Component, OnInit, HostListener } from '@angular/core';
import { ErrorStateMatcher, MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router'
import { TaCessationService } from '../ta-cease-licence/ta-cease-licence.service';
import { CommonService, AlertService, AuthenticationService, ErrorDialogService } from '../../../common/services';
import { FileUtil, DateUtil, FormUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';
import { Observable } from 'rxjs';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import { ErrorDialogComponent } from '../../../common/modules/error-dialog/errordialog.component';
@Component({
    selector: 'app-ta-cease-licence',
    templateUrl: './ta-cease-licence.component.html',
    styleUrls: ['./ta-cease-licence.component.scss']
})
export class TaCeaseLicenceComponent implements OnInit {

    constructor(
        public dialog: MatDialog,
        private route: ActivatedRoute,
        private service: TaCessationService,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        private router: Router,
        private formBuilder: FormBuilder,
        private formUtil: FormUtil,
        private alertService: AlertService,
        private authService: AuthenticationService,
        private errorDialogService: ErrorDialogService
    ) { }

    selectedFile: File;
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    newApplication: boolean = true;
    rfa: boolean = false;
    preview = false;
    reasonForCessation: any = [];
    application: any = { applicationStatus: {}, directorResolution: {}, otherDocuments: [], reason: {} };
    cnst = cnst;
    minCeaseDate: Date;
    maxCeaseDate: Date;
    form: FormGroup;
    drUploadTouched = false;
    showErrorMsg = false;
    isTaActive: boolean = true;
    isPendingCessation: boolean = false;
    unionMap = new Map<string, string>();

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.buildForm();
        this.isTaActive = this.authService.isTaActive();
        if (this.route.snapshot.paramMap.get('appId') == 'new') {
            this.checkForPendingApplication();
            if (!this.isTaActive) {
                setTimeout(() => this.errorDialogService.openDialog({
                    reason: cnst.Messages.MSG_INVALID_ACCESS,
                    routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
                }))
            }
        } else {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        }
        this.commonService.getTaCessationReasons().subscribe(data => {
            this.reasonForCessation = data;
        });
    }

    buildForm() {
        this.form = this.formBuilder.group({
            applicationId: [''],
            reason: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            otherReason: ['', Validators.maxLength(255)],
            cessationDate: ['', Validators.required],
            directorResolution: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: ['', Validators.required],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            otherDocuments: this.formBuilder.array([]),
            declared: ['']

        }, { validator: this.otherReasonRequiredValidator() });
    }

    get otherDocuments() {
        return this.form.get('otherDocuments') as FormArray;
    }

    otherReasonRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return (form.get('reason').get('key').value == cnst.TaCessationOtherReason && !form.get('otherReason').value) ? { otherReasonRequired: true } : null;
        }
    }

    checkForPendingApplication() {
        this.service.checkForPendingApplication().subscribe(data => {
            if (data.isPendingCessation) {
                this.isPendingCessation = true;
            }
            else if (data.applicationId) {
                this.application = data;
                this.form.patchValue(data);
                this.newApplication = false;
                if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                    this.rfa = true;
                }
                if (data.otherDocuments.length > 0) {
                    data.otherDocuments.forEach(item => {
                        this.otherDocuments.push(this.formBuilder.group(item));
                    });
                }

            } else {
                this.application.licenceStartDate = data.startDate;
                this.application.licenceExpiryDate = data.expiryDate;
                this.application.licenceIssueDate = data.issueDate;
                this.form.patchValue(data);
                this.form.markAsPristine();
            }

        });
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.rfa = false;
            this.application = data;
            this.form.patchValue(data);
            this.newApplication = false;
            if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                this.rfa = true;
            }
            if (data.otherDocuments.length > 0) {
                data.otherDocuments.forEach(item => {
                    this.otherDocuments.push(this.formBuilder.group(item));
                });
            }

        }, error => {
            this.router.navigate(['/portal/dashboard-ta']);
        })
    }

    isMoreThan7daysLate() {
        if (DateUtil.getNow().diff(DateUtil.parseDate(this.form.get('cessationDate').value), 'days') > 7) {
            return true;
        } else {
            return false;
        }
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (this.selectedFile) {
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                    if (type == cnst.DocumentTypes.TA_DOC_CEASE_DIRECTOR_RESOLUTION) {
                        this.form.patchValue({ directorResolution: data });

                    } else {
                        const fileDto = this.formBuilder.group({
                            id: [],
                            publicFileId: [],
                            originalName: [],
                            processedName: [],
                            docType: [],
                            extension: [],
                            path: [],
                            size: [],
                            hash: [],
                            documentInstructions: [],
                            documentTypeLabel: [],
                            description: [],
                            readableFileSize: [],
                        });
                        fileDto.patchValue(data);
                        this.otherDocuments.push(fileDto);
                    }


                });
            }
        }

        event.target.value = '';

    }



    removeFile(obj, type, doc) {
        if (type == cnst.DocumentTypes.TA_DOC_CEASE_DIRECTOR_RESOLUTION) {
            this.form.patchValue({
                directorResolution: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else {
            this.otherDocuments.removeAt(obj);
        }
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push({ publicFileId: doc.publicFileId, hash: doc.hash });
        }

    }

    showPreview() {
        this.alertService.clear();
        if (this.form.valid) {
            this.preview = true
            window.scrollTo(0, 0);

        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    saveConfirmationDialog() {
        if (this.form.value.declared) {
            this.service.save(this.form.value).subscribe(data => {
                this.service.checkForPendingApplication().subscribe(data => {
                    this.form.markAsPristine();
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                });
            });
        } else {
            alert(cnst.Messages.MSG_DECLARATION_CHECK)
        }
    }
    updateConfirmationDialog() {
        this.service.update(this.form.value, this.adminDeletedFiles).subscribe(data => {
            this.fileUtil.delete(this.publicDeletedFiles).subscribe();
            this.service.checkForPendingApplication().subscribe(data => {
                this.form.markAsPristine();
                this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
            });
        });

    }


}

export class otherReasonRequiredMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
        return control.invalid || (control.touched && (control.parent.hasError('otherReasonRequired')));
    }
}

