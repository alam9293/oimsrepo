import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaChangeCompayDetailsService {

    constructor(private http: HttpClient) { }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_COMPANY_UPDATES + '/new/business-entity/' + applicationId);
    }

    checkForCompanyUpdateBusinessEntity(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_COMPANY_UPDATES + '/new/business-entity');
    }

    saveBusinessEntity(application: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_COMPANY_UPDATES + '/save/business-entity', application);
    }

}
