
import { Component, HostListener, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';
import { DateUtil, FileUtil, FormUtil } from '../../../common/helper';
import { AlertService, AuthenticationService, CommonService, ErrorDialogService } from '../../../common/services';
import { TaChangeFyeService } from './ta-change-fye.service';

@Component({
    selector: 'app-ta-change-fye',
    templateUrl: './ta-change-fye.component.html',
    styleUrls: ['./ta-change-fye.component.scss']
})
export class TaChangeFyeComponent implements OnInit {

    constructor(
        private route: ActivatedRoute,
        private service: TaChangeFyeService,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        private router: Router,
        private formBuilder: FormBuilder,
        private formUtil: FormUtil,
        private alertService: AlertService,
        private authService: AuthenticationService,
        private errorDialogService: ErrorDialogService,
        private dateUtil: DateUtil,
    ) { }
    selectedFile: File;
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    newApplication: boolean = true;
    rfa: boolean = false;
    preview = false;
    fys: any = [];
    application: any = { applicationStatus: {}, directorResolution: {}, otherDocuments: [], reason: {} };
    cnst = cnst;
    minCeaseDate: Date;
    maxCeaseDate: Date;
    form: FormGroup;
    drUploadTouched = false;
    showErrorMsg = false;
    fyeParam: any;
    isTaActive: boolean = true;
    minFyEndDate = '';
    maxFyEndDate = '';
    isLateSubmission: boolean = false;

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.buildForm();
        this.fyeParam = this.route.snapshot.queryParams['fye'] || null;
        this.isTaActive = this.authService.isTaActive();
        this.service.getFys().subscribe(data => {
            this.fys = data;
            if (this.route.snapshot.paramMap.get('appId')) {
                this.getApplication(this.route.snapshot.paramMap.get('appId'));
            } else {
                this.checkForPendingApplication();
                if (!this.isTaActive) {
                    setTimeout(() => this.errorDialogService.openDialog({
                        reason: cnst.Messages.MSG_INVALID_ACCESS,
                        routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
                    }))
                }
            }
        });
        this.commonService.getSystemParameter('CE_TA_MONTHS_TO_INFORM_DUE_FYE_CHANGE').subscribe(sysParam => {
            this.form.get('fyEndDateToBeChanged').valueChanges.subscribe(selectedFyEndDate => {
                var selectedFyObj = this.getFyObjFromFyEndDate(selectedFyEndDate);
                if (selectedFyObj) {
                    this.form.patchValue({ selectedFyObj: selectedFyObj });
                    this.minFyEndDate = selectedFyObj.minFyEndDate;
                    this.maxFyEndDate = selectedFyObj.maxFyEndDate;
                }

                if (this.form.get('selectedFyObj').value.fyStartDate) {
                    let baseDate = DateUtil.parseDate(this.form.get('selectedFyObj').value.fyStartDate);
                    baseDate.add(sysParam.label, 'month').startOf('day').subtract(1, 'millisecond');

                    this.isLateSubmission = DateUtil.getNow().isAfter(baseDate);
                }

            });
        });
    }

    buildForm() {
        this.form = this.formBuilder.group({
            applicationId: [''],
            //selectedFyObj: ['', Validators.required],
            selectedFyObj: this.formBuilder.group({
                fyStartDate: [],
                fyEndDate: ['', Validators.required],
                minFyEndDate: [],
                maxFyEndDate: [],
            }),
            fyEndDateToBeChanged: ['', Validators.required],
            newFyEndDate: ['', Validators.required],
            reason: ['', [Validators.required, Validators.maxLength(255)]],
            directorResolution: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: ['', Validators.required],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            otherDocuments: this.formBuilder.array([]),
            declared: [{ disabled: true, value: false }, Validators.requiredTrue]
        }, {
            validator: this.validateFyEndDate
        });
    }

    get otherDocuments() {
        return this.form.get('otherDocuments') as FormArray;
    }

    checkForPendingApplication() {
        this.service.checkForPendingApplication().subscribe(data => {
            if (data.applicationId) {
                this.application = data;
                this.form.patchValue(data);
                this.newApplication = false;
                if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                    this.rfa = true;
                }
                if (data.otherDocuments.length > 0) {
                    data.otherDocuments.forEach(item => {
                        this.otherDocuments.push(this.formBuilder.group(item));
                    });
                }
                if (data.selectedFyObj) {
                    this.form.patchValue({ fyEndDateToBeChanged: data.selectedFyObj.fyEndDate });
                }
            } else {
                this.application.licenceStartDate = data.startDate;
                this.application.licenceExpiryDate = data.expiryDate;
                if (this.fyeParam && this.getFyObjFromFyEndDate(this.fyeParam)) {
                    this.form.patchValue({ fyEndDateToBeChanged: this.fyeParam });
                }
                this.form.get('directorResolution').patchValue(data.directorResolution);
                this.form.markAsPristine();
            }
        });
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.rfa = false;
            this.application = data;
            this.form.patchValue(data);
            this.newApplication = false;
            if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                this.rfa = true;
            }
            if (data.otherDocuments.length > 0) {
                data.otherDocuments.forEach(item => {
                    this.otherDocuments.push(this.formBuilder.group(item));
                });
            }
            if (data.selectedFyObj) {
                this.form.patchValue({ fyEndDateToBeChanged: data.selectedFyObj.fyEndDate });
            }
        }, error => {
            this.router.navigate(['/portal/dashboard-ta']);
        })
    }

    getFyObjFromFyEndDate(val) {
        var retVal: any;
        if (this.fys) {
            this.fys.forEach(element => {
                if (element.fyEndDate == val) {
                    retVal = element;
                }
            });
        }
        return retVal;
    }


    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                if (type == cnst.DocumentTypes.TA_DOC_CFYE_DIRECTOR_RESOLUTION) {
                    this.form.patchValue({ directorResolution: data });
                } else {
                    const fileDto = this.formBuilder.group({
                        id: [],
                        publicFileId: [],
                        originalName: [],
                        processedName: [],
                        docType: [],
                        extension: [],
                        path: [],
                        size: [],
                        hash: [],
                        documentInstructions: [],
                        documentTypeLabel: [],
                        description: [],
                        readableFileSize: [],
                        hasTemplate: [],
                    });
                    fileDto.patchValue(data);
                    this.otherDocuments.push(fileDto);
                }
            });
        }
    }

    removeFile(obj, type, doc) {
        if (type == cnst.DocumentTypes.TA_DOC_CFYE_DIRECTOR_RESOLUTION) {
            this.form.patchValue({
                directorResolution: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else {
            this.otherDocuments.removeAt(obj);
        }
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push({ publicFileId: doc.publicFileId, hash: doc.hash });
        }

    }

    showPreview() {
        this.alertService.clear();
        if (this.form.valid) {
            this.preview = true;
            window.scrollTo(0, 0);
            this.form.controls['declared'].enable();
        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    backToApplicationForm() {
        this.preview = false;
        this.form.controls['declared'].disable();
    }

    saveConfirmationDialog() {
        if (this.form.valid) {
            if (this.form.value.declared) {
                this.service.save(this.form.value).subscribe(data => {
                    this.service.checkForPendingApplication().subscribe(data => {
                        this.form.markAsPristine();
                        this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                    });
                });
            } else {
                alert(cnst.Messages.MSG_DECLARATION_CHECK)
            }
        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    updateConfirmationDialog() {
        if (this.form.valid) {
            this.service.update(this.form.value, this.adminDeletedFiles).subscribe(data => {
                this.fileUtil.delete(this.publicDeletedFiles).subscribe();
                this.service.checkForPendingApplication().subscribe(data => {
                    this.form.markAsPristine();
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                });
            });
        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    validateFyEndDate(fg: FormGroup) {
        if (fg.get('newFyEndDate').value && fg.get('selectedFyObj').value) {
            if (DateUtil.parseDate(fg.get('newFyEndDate').value).isBefore(DateUtil.parseDate(fg.get('selectedFyObj').value.minFyEndDate))) {
                fg.get('newFyEndDate').setErrors({ 'isBeforeMinDate': true });
            }
            if (DateUtil.parseDate(fg.get('newFyEndDate').value).isAfter(DateUtil.parseDate(fg.get('selectedFyObj').value.maxFyEndDate))) {
                fg.get('newFyEndDate').setErrors({ 'isAfterMaxDate': true });
            }
            if (DateUtil.parseDate(fg.get('newFyEndDate').value).isBetween(DateUtil.parseDate(fg.get('selectedFyObj').value.minFyEndDate), DateUtil.parseDate(fg.get('selectedFyObj').value.maxFyEndDate), null, '[]')) {
                fg.get('newFyEndDate').setErrors(null);
            }
        }
        return null;
    }
}


