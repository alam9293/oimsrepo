import { Component, OnInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';
import { TaElicenceRequestService } from './ta-elicence-request.service';

@Component({
    selector: 'app-ta-elicence-request',
    templateUrl: './ta-elicence-request.component.html',
    styleUrls: ['./ta-elicence-request.component.scss']
})
export class TaElicenceRequestComponent implements OnInit {

    constructor(private service: TaElicenceRequestService, private route: ActivatedRoute, private router: Router) { }
    application: any = { applicationStatus: {}, licenceStatus: {} };
    cnst = cnst;

    ngOnInit() {
        if (this.route.snapshot.paramMap.get('appId')) {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        }
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.application = data;
        }, error => {
            this.router.navigate([cnst.TaApiUrl.TA_DASHBOARD]);
        })
    }

}
