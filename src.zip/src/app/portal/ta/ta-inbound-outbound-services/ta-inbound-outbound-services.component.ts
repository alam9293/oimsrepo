import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, FormArray } from '@angular/forms';
import { CommonService, AuthenticationService, AlertService, ErrorDialogService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormUtil } from '../../../common/helper';
import { forkJoin, Observable } from 'rxjs';
import { TaInboundOutboundServicesService } from './ta-inbound-outbound-services.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TaFormHelperUtil } from '../ta-helper';

@Component({
    selector: 'app-inbound-outbound-services',
    templateUrl: './ta-inbound-outbound-services.component.html',
    styleUrls: ['./ta-inbound-outbound-services.component.scss'],
})

export class TaInboundOutboundServicesComponent implements OnInit {
    displayedColumns: string[] = ['name', 'new', 'old'];
    days: number[];
    months: string[];
    constructor(
        private alertService: AlertService,
        private formUtil: FormUtil,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private formBuilder: FormBuilder,
        private taFormHelperUtil: TaFormHelperUtil,
        private commonService: CommonService,
        private service: TaInboundOutboundServicesService,
        private authService: AuthenticationService,
        private errorDialogService: ErrorDialogService
    ) { }
    companyUpdate: FormGroup;

    application: any = {};
    licenceTier: any = { key: '', label: '' };
    isInboundOutboundServiceSelected: boolean = false;
    isTaActive: boolean = true;
    licenceDetails: any = {};

    openBusinessEnitityFlag: Boolean = true;
    openInboundOutboundServicesFlag: Boolean = false;
    submittedFlag: boolean = false;
    preview: boolean = false;
    cnst = cnst;
    focusRows: FormGroup;
    formInboundOutBoundServices: FormGroup;
    business_services: any = [];
    unionMap = new Map<string, string>();

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.formInboundOutBoundServices.pristine;
    }

    ngOnInit() {
        this.isTaActive = this.authService.isTaActive();
        if (!this.isTaActive) {
            setTimeout(() => this.errorDialogService.openDialog({
                reason: cnst.Messages.MSG_INVALID_ACCESS,
                routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
            }))
        }

        this.service.getLicenceeDetails().subscribe(licencee => {
            this.licenceDetails = licencee;
            this.licenceTier = licencee.licenceTier;
            if (licencee.licenceTier.code == cnst.TaLicenceTier.TA_TIER_N) {
                this.business_services = this.business_services.filter(function (type) {
                    return type.key != "TA_SERV_ACCOMMODATION" && type.key != "TA_SERV_AIR_TICKETING";
                });
            }
        });

        this.loadCommonTypes();
        this.buildForm();
    }
    buildForm() {
        this.initiateInboundOutBoundServicesForm();
        this.openInboundOutboundServicesDialog();
    }
    checkForCompanyUpdateInboundOutBound() {
        this.service.checkForCompanyUpdateInboundOutBound().subscribe(data => {
            data.forEach(item => {
                this.focusRows = this.initFocusItemRows();
                this.focusRows.patchValue(item);
                this.focusForms.push(this.focusRows);
            });
        });
    }

    get focusForms() {
        return this.formInboundOutBoundServices.get('focusRows') as FormArray
    }

    initiateInboundOutBoundServicesForm() {

        const listableDto = this.formBuilder.group({
            key: [''],
            label: ['']
        });
        this.formInboundOutBoundServices = this.formBuilder.group({
            draft: false,
            applicationId: [''],
            abprSubmissionId: [''],
            applicationNo: [''],
            applicationStatus: listableDto,
            licenceStatus: listableDto,
            externalRemarks: [''],
            hasAbprToSubmit: [''],
            declared: [''],
            focusRows: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.duplicatedSelectionValidator('service'),])),
        }, {
            validator: Validators.compose(
                [
                ]
            )
        }
        );
    }

    onSubmitBusinessServices() {
        this.alertService.clear();
        console.log(this.formInboundOutBoundServices);
        if (this.formInboundOutBoundServices.valid) {
            this.openConfirmationBusinessServicesDialog();
        }
        else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.formUtil.validateAllFormControl(this.formInboundOutBoundServices);
            this.formUtil.markFormGroupTouched(this.formInboundOutBoundServices);
        }
        window.scrollTo(0, 0);
    }
    openConfirmationBusinessServicesDialog() {
        this.preview = true;
        this.submittedFlag = true;
    }
    getFormValidationErrors(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(key => {
            const controlErrors: ValidationErrors = formGroup.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    validateAllFormFields(formGroup: FormGroup | FormArray) {         //{1}
        Object.keys(formGroup.controls).forEach(field => {  //{2}
            const control = formGroup.get(field);             //{3}
            if (control instanceof FormControl) {             //{4}
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup || control instanceof FormArray) {        //{5}
                this.validateAllFormFields(control);            //{6}
            }
        });
    }
    openBusinessEnitityDialog() {
        this.openBusinessEnitityFlag = true;
        this.openInboundOutboundServicesFlag = false;
        this.preview = false;
    }
    openInboundOutboundServicesDialog() {
        this.openBusinessEnitityFlag = false;
        this.openInboundOutboundServicesFlag = true;
        this.preview = false;
        if (!this.isInboundOutboundServiceSelected) {
            this.checkForCompanyUpdateInboundOutBound();
            this.isInboundOutboundServiceSelected = true;
        }
    }

    addBusinessOperation() {
        this.focusForms.push(this.initFocusItemRows());
    }
    deleteBusinessOperation(index: number) {
        this.focusForms.removeAt(index);
    }
    changeValue(form: FormGroup) {
        Object.keys(form.controls).forEach(key => {
            form.get(key).markAsDirty();
        });
    }
    initFocusItemRows() {
        return this.formBuilder.group({
            service: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            inbound: [false, Validators.required],
            outbound: [false, Validators.required],
        }, {
            validator: Validators.compose(
                [
                    this.matchingMissingBothCheckBoxValidator("inbound", "outbound", "mismatchedMissingBothCheckbox"),
                ]
            )
        }
        );
    }
    saveConfirmationDialog() {
        this.alertService.clear();
        this.service.save(this.focusForms.value).subscribe(data => {
            this.preview = false;
            this.formInboundOutBoundServices.markAsPristine();
            this.alertService.success("Travel agent services updated");
            this.formInboundOutBoundServices.controls['declared'].setValue(null);
        }, error => {
            this.alertService.error(cnst.Messages.ERR_MSG_GENERIC);
        });
    }

    matchingMissingBothCheckBoxValidator(inboundKey: string, outboundKey: string, errorGroup: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let inbound = group.controls[inboundKey];
            let outbound = group.controls[outboundKey];
            if (!inbound.value && !outbound.value) {
                return {
                    [errorGroup]: true
                };
            }
            else {
                return null;
            }
        }
    }

    loadCommonTypes() {
        forkJoin([
            this.commonService.getTaServices(),
        ]).subscribe(data => {
            this.business_services = data[0];
        });
    }
}
