export interface ApplicationDto {

    keDeclarations: ListableDto[];
    keAdditionalInfo: ListableDto[];

}



export interface ListableDto {
    key: string;
    label: string;
    data: string;
}

export const NEW_APPLICATION: ApplicationDto =
{
    keDeclarations: [{ key: '1', label: null, data: null },
    { key: '2', label: null, data: null },
    { key: '3', label: null, data: null },
    { key: '4', label: null, data: null },
    { key: '5', label: null, data: null },
    { key: '6', label: null, data: null },
    { key: '7', label: null, data: null },
    { key: '8', label: null, data: null },
    { key: '9', label: null, data: null },],
    keAdditionalInfo: [{ key: '1', label: null, data: null },
    { key: '2', label: null, data: null },
    { key: '3', label: null, data: null },],
};

