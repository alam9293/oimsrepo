import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';
import { DateUtil } from '../../../common/helper';

@Injectable({
    providedIn: 'root'
})
export class TaKeResignService {

    constructor(private http: HttpClient) { }

    createTaLicenceAaApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_RESIGN + '/new');
    }

    submit(application: any): Observable<any> {
        if (application.applicationId) {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_RESIGN + '/update', application);
        } else {
            return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_RESIGN + '/save', application);
        }
    }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_KE_RESIGN + '/load/' + applicationId);
    }
}
