
import { Component, OnInit, HostListener } from '@angular/core';
import { ErrorStateMatcher, MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router'
import { TaReplacementService } from '../ta-replace-licence/ta-replace-licence.service';
import { CommonService, AlertService } from '../../../common/services';
import { FileUtil, FormUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';
import { Observable } from 'rxjs';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import { PaymentService } from '../../payment/payment.service';
import { PaymentDialogComponent } from '../../../common/modules/payment-dialog/payment-dialog.component';

@Component({
    selector: 'app-ta-replace-licence',
    templateUrl: './ta-replace-licence.component.html',
    styleUrls: ['./ta-replace-licence.component.scss']
})
export class TaReplaceLicenceComponent implements OnInit {

    constructor(
        private alertService: AlertService,
        private route: ActivatedRoute,
        private formUtil: FormUtil,
        private formBuilder: FormBuilder,
        private router: Router,
        private service: TaReplacementService,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        private paymentService: PaymentService,
        public dialog: MatDialog,) { }


    selectedFile: File;
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    newApplication: boolean = true;
    rfa: boolean = false;
    preview = false;
    reasonForReplacement: any = [];
    replaceFeeAmount: any;
    application: any = { applicationStatus: {}, policeReport: {}, otherDocuments: [], reason: {}, payment: {} };
    cnst = cnst;
    form: FormGroup;
    prUploadTouched: boolean = false;
    showErrorMsg: boolean = false;
    paymentFailed: boolean = false;
    unionMap = new Map<string, string>();

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.buildForm();
        if (this.route.snapshot.paramMap.get('billRefNo') == null) {
            if (this.route.snapshot.paramMap.get('appId') == 'new') {
                this.checkForPendingApplication();
            } else {
                this.getApplication(+this.route.snapshot.paramMap.get('appId'));
            }
        } else if (this.route.snapshot.paramMap.get('paymentFailed') == 'true') {
            this.service.getApplication(+this.route.snapshot.paramMap.get('appId')).subscribe(data => {
                this.application = data;
                this.form.patchValue(data);
                if (data.otherDocuments.length > 0) {
                    data.otherDocuments.forEach(item => {
                        this.otherDocuments.push(this.formBuilder.group(item));
                    });
                }
                this.newApplication = true;
                this.alertService.error("There was an error while making payment. Please try again.");
            })

        } else if (this.route.snapshot.paramMap.get('appFailed') == 'true') {
            this.service.getApplication(+this.route.snapshot.paramMap.get('appId')).subscribe(data => {
                this.application = data;
                this.form.patchValue(data);
                if (data.otherDocuments.length > 0) {
                    data.otherDocuments.forEach(item => {
                        this.otherDocuments.push(this.formBuilder.group(item));
                    });
                }
                this.newApplication = false;
                this.alertService.error("There was an error submitting your application. Please try again.");
            })

        } else {
            this.service.getApplication(+this.route.snapshot.paramMap.get('appId')).subscribe(data => {
                this.application = data;
                if (this.application.payment.statusCode == cnst.PaymentStatuses.PAYREQ_PAID) {
                    this.application.draft = false;
                    this.service.save(this.application).subscribe(data => {
                        this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo, 'billRefNo': this.route.snapshot.paramMap.get('billRefNo') } });
                    }, error => {
                        this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo, 'billRefNo': this.route.snapshot.paramMap.get('billRefNo'), 'continueUrl': '/portal/ta-replace-licence/' + data.applicationId + '/null/true/false' } });
                    })
                } else {
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo, 'billRefNo': this.route.snapshot.paramMap.get('billRefNo'), 'continueUrl': '/portal/ta-replace-licence/' + data.applicationId + '/null/false/true' } });
                }
            })
        }


        this.commonService.getTaReplacementReasons().subscribe(data => this.reasonForReplacement = data);
        this.commonService.getSystemParameter("TA_LIC_REPLACE_FEE").subscribe(data => {
            this.replaceFeeAmount = data.label
        });
    }

    buildForm() {
        this.form = this.formBuilder.group({
            applicationId: [''],
            reason: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            otherReasons: ['', Validators.maxLength(255)],
            policeReport: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: [],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            otherDocuments: this.formBuilder.array([]),
            declared: [{ disabled: true, value: false }, Validators.requiredTrue],
            draft: [false]

        }, { validator: [this.otherReasonRequiredValidator(), this.policeReportRequiredValidator()] });
    }

    otherReasonRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return (form.get('reason').get('key').value == cnst.TaReplacementOtherReason && !form.get('otherReasons').value) ? { otherReasonRequired: true } : null;
        }
    }

    policeReportRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return (form.get('reason').get('key').value == cnst.TaReplacementLostReason && !form.get('policeReport').get('originalName').value) ? { policeReportRequired: true } : null;
        }
    }
    get otherDocuments() {
        return this.form.get('otherDocuments') as FormArray;
    }

    checkForPendingApplication() {
        this.service.checkForPendingApplication().subscribe(data => {
            if (data.applicationId) {
                this.newApplication = false;
                this.form.patchValue(data);
                this.application = data;
                if (data.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                    this.rfa = true;
                }
                if (data.otherDocuments && data.otherDocuments.length > 0) {
                    data.otherDocuments.forEach(item => {
                        this.otherDocuments.push(this.formBuilder.group(item));
                    });
                }
            } else {
                this.form.patchValue(data);
            }
        });
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.form.patchValue(data);
            this.application = data;
            this.newApplication = false;
            if (data.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                this.rfa = true;
            }
            if (data.otherDocuments.length > 0) {
                data.otherDocuments.forEach(item => {
                    this.otherDocuments.push(this.formBuilder.group(item));
                });
            }

        }, error => {
            this.router.navigate(['/portal/dashboard-ta']);
        })
    }


    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (this.selectedFile) {
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                    if (type == cnst.DocumentTypes.TA_DOC_POLICE_REPORT) {
                        this.form.patchValue({ policeReport: data });
                    } else {
                        const fileDto = this.formBuilder.group({
                            id: [],
                            publicFileId: [],
                            originalName: [],
                            processedName: [],
                            docType: [],
                            extension: [],
                            path: [],
                            size: [],
                            hash: [],
                            documentInstructions: [],
                            documentTypeLabel: [],
                            description: [],
                            readableFileSize: [],
                        });
                        fileDto.patchValue(data);
                        this.otherDocuments.push(fileDto);
                    }
                });
            }
        }
        event.target.value = '';
    }

    removeFile(obj, type, doc) {
        if (type == cnst.DocumentTypes.TA_DOC_POLICE_REPORT) {
            this.form.patchValue({
                policeReport: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else {
            this.otherDocuments.removeAt(obj);
        }
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push({ publicFileId: doc.publicFileId, hash: doc.hash });
        }
    }



    backToApplicationForm() {
        this.preview = false;
        this.form.controls['declared'].disable();
    }

    showPreview() {
        this.alertService.clear();
        if (this.form.valid) {
            this.preview = true;
            window.scrollTo(0, 0);
            this.form.controls['declared'].enable();
        }
    }

    pay() {
        if (this.form.valid) {
            if (this.form.value.declared) {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.replaceFeeAmount } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        let paymentType = result.type;
                        this.form.get('draft').setValue(true);
                        this.service.save(this.form.value).subscribe(data => {
                            let application = data;
                            this.form.markAsPristine();
                            if (application.payment.billRefNo == null) {
                                let paymentReqDto = { refNo: application.applicationId, payerUinUen: data.uen, description: 'TA Licence Replacement Fee', payableAmount: this.replaceFeeAmount, typeCode: cnst.PaymentRequestTypes.PAYREQ_TA_REPLACEMENT };
                                this.service.savePaymentRequest(paymentReqDto).subscribe(result => {
                                    let billRefNo = [];
                                    billRefNo.push(result);
                                    this.service.linkAppFee(application.applicationId, billRefNo[0]).subscribe(data => {
                                        if (paymentType == cnst.PaymentTypes.PAYNOW) {
                                            this.generatePaynowQRCode(application.applicationId, billRefNo, paymentType);
                                        } else {
                                            this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TA_RETURN, paymentType, billRefNo, '/portal/ta-replace-licence/' + application.applicationId + '/' + billRefNo + '/false/false');
                                        }
                                    });

                                });
                            } else {
                                let billRefNo = [];
                                billRefNo.push(application.payment.billRefNo);
                                if (paymentType == cnst.PaymentTypes.PAYNOW) {
                                    this.generatePaynowQRCode(application.applicationId, application.payment.billRefNo, paymentType);
                                } else {
                                    this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TA_RETURN, paymentType, application.payment.billRefNo, '/portal/ta-replace-licence/' + application.applicationId + '/' + application.payment.billRefNo + '/false/false');
                                }
                            }

                        });
                    }
                });

            } else {
                alert(cnst.Messages.MSG_DECLARATION_CHECK)
            }
        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    generatePaynowQRCode(id: any, billRefNo: any, paymentType: any) {
        this.paymentService.createPayNowTxn(this.replaceFeeAmount, billRefNo).subscribe(txn => {
            let payNowTxnId = txn;
            this.paymentService.generateQrCode(this.replaceFeeAmount, txn).subscribe(qrCode => {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.replaceFeeAmount, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TA_RETURN, paymentType, billRefNo, '/portal/ta-replace-licence/' + id + '/' + billRefNo + '/false/false', payNowTxnId);
                    }
                });
            });
        });
    }

    updateConfirmationDialog() {
        if (this.form.valid) {
            this.service.save(this.form.value).subscribe(data => {
                this.fileUtil.delete(this.publicDeletedFiles).subscribe();
                this.service.checkForPendingApplication().subscribe(data => {
                    this.form.markAsPristine();
                    this.router.navigate(['/portal/ta-thankyou'], { queryParams: { 'applicationNo': data.applicationNo } });
                });
            })
        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }



}

export class otherReasonRequiredMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
        return control.invalid || (control.touched && (control.parent.hasError('otherReasonRequired')));
    }
}

export class policeReportRequiredMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
        return control.invalid || (control.touched && (control.parent.hasError('policeReportRequired')));
    }
}

