
import { Component, OnInit, HostListener } from '@angular/core';
import { TaShortfallFulfilmentService } from './ta-shortfall-fulfilment.service';
import { AlertService, AuthenticationService, ErrorDialogService, EdhService } from '../../../common/services';
import { FileUtil } from '../../../common/helper';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-ta-shortfall-fulfilment',
    templateUrl: './ta-shortfall-fulfilment.component.html',
    styleUrls: ['./ta-shortfall-fulfilment.component.scss']
})
export class TaShortfallFulfilmentComponent implements OnInit {

    constructor(
        private route: ActivatedRoute,
        private service: TaShortfallFulfilmentService,
        private fileUtil: FileUtil,
        private router: Router,
        private formBuilder: FormBuilder,
        private alertService: AlertService,
        private authService: AuthenticationService,
        private errorDialogService: ErrorDialogService,
        private edhService: EdhService,
    ) { }
    appId: number;
    selectedFile: File;
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    newApplication: boolean = true;
    rfa: boolean = false;
    preview = false;
    application: any = { applicationStatus: {}, directorResolution: {}, bankStatement: {}, otherDocuments: [], netvalueShortfalls: [], hasShortfallToRectify: true, capital: [] };
    cnst = cnst;
    form: FormGroup;
    directorResolutionUploadTouched = false;
    bankStatementUploadTouched = false;
    showErrorMsg = false;
    isTaActive: boolean = true;
    hasShortfallLetter: boolean = false;
    edhData: any = { entity: { basic: {} }, appointments: {}, shareholders: {}, financials: {} };

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.buildForm();
        this.isTaActive = this.authService.isTaActive();
        if (this.route.snapshot.paramMap.get('appId')) {
            this.appId = +this.route.snapshot.paramMap.get('appId');
            this.getApplication(this.route.snapshot.paramMap.get('appId'));
        } else {
            this.checkForPendingApplication();
            if (!this.isTaActive) {
                setTimeout(() => this.errorDialogService.openDialog({
                    reason: cnst.Messages.MSG_INVALID_ACCESS,
                    routeBackUrl: cnst.TaApiUrl.TA_DASHBOARD
                }))
            }
        }
    }

    buildForm() {
        this.form = this.formBuilder.group({
            applicationId: [''],
            hasShortfallToRectify: [''],
            netvalueShortfalls: this.formBuilder.array([]),
            capital: [''],
            isEdhPopulated: ['', Validators.required],
            directorResolution: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: [],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            bankStatement: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: [],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            acra: this.formBuilder.group({
                id: [],
                publicFileId: [],
                originalName: [],
                processedName: [],
                docType: [],
                extension: [],
                path: [],
                size: [],
                hash: [],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [],
                readableFileSize: [],
                hasTemplate: [],
            }),
            otherDocuments: this.formBuilder.array([]),
            declared: [{ disabled: true, value: false }, Validators.requiredTrue]
        });
        this.listenAcraDocRequiredValidator();
    }

    get otherDocuments() {
        return this.form.get('otherDocuments') as FormArray;
    }

    get netvalueShortfalls() {
        return this.form.get('netvalueShortfalls') as FormArray;
    }

    // convenience getter for easy access to form fields
    get f() {
        return this.form.controls;
    }

    listenAcraDocRequiredValidator() {
        this.form.get('isEdhPopulated').valueChanges.subscribe(
            (isEdhPopulated: any) => {
                if (!isEdhPopulated) {
                    this.form.get('acra').get('originalName').setValidators([Validators.required]);
                } else {
                    this.form.get('acra').get('originalName').clearValidators();
                }
                this.form.get('acra').get('originalName').updateValueAndValidity();
            });

    }

    checkForPendingApplication() {
        this.service.checkForPendingApplication().subscribe(data => {
            this.application = data;
            if (data.applicationId) {
                this.form.patchValue(data);
                this.newApplication = false;
                if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                    this.rfa = true;
                    if (this.application.isEdhPopulated == true) {
                        this.loadAppEdh();
                    }
                }
                if (data.otherDocuments.length > 0) {
                    data.otherDocuments.forEach(item => {
                        this.otherDocuments.push(this.formBuilder.group(item));
                    });
                }
            } else if (data.hasShortfallToRectify) {
                this.loadAppEdh();
                this.form.get('directorResolution').patchValue(data.directorResolution);
                this.form.get('bankStatement').patchValue(data.bankStatement);
                this.form.get('acra').patchValue(data.acra);
                this.form.markAsPristine();
            }
            if (data.netvalueShortfalls && data.netvalueShortfalls.length > 0) {
                data.netvalueShortfalls.forEach(item => {
                    this.netvalueShortfalls.push(this.formBuilder.group(item));
                    if (item.hasSystemGeneratedShortfallLetter) {
                        this.hasShortfallLetter = true;
                    }
                })
            }
        });
    }

    getApplication(appId) {
        this.service.getApplication(appId).subscribe(data => {
            this.rfa = false;
            this.application = data;
            this.form.patchValue(data);
            this.newApplication = false;
            if (this.application.applicationStatus.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                this.rfa = true;
            }
            if (data.otherDocuments.length > 0) {
                data.otherDocuments.forEach(item => {
                    this.otherDocuments.push(this.formBuilder.group(item));
                });
            }
            if (data.netvalueShortfalls && data.netvalueShortfalls.length > 0) {
                data.netvalueShortfalls.forEach(item => {
                    this.netvalueShortfalls.push(this.formBuilder.group(item));
                    if (item.hasSystemGeneratedShortfallLetter) {
                        this.hasShortfallLetter = true;
                    }
                })
            }
        }, error => {
            this.router.navigate(['/portal/dashboard-ta']);
        })
    }

    removeFile(obj, type, doc) {
        if (type == cnst.DocumentTypes.TA_DOC_REC_DIRECTOR_RESOLUTION) {
            this.form.patchValue({
                directorResolution: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else if (type == cnst.DocumentTypes.TA_DOC_REC_BANK_STATEMENT) {
            this.form.patchValue({
                bankStatement: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else if (type == cnst.DocumentTypes.TA_DOC_ACRA_BIZ) {
            this.form.patchValue({
                acra: {
                    id: '',
                    publicFileId: '',
                    originalName: '',
                    processedName: '',
                    docType: '',
                    extension: '',
                    path: '',
                    size: '',
                    hash: '',
                    description: '',
                    readableFileSize: '',
                }
            });
        } else {
            this.otherDocuments.removeAt(obj);
        }
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push({ publicFileId: doc.publicFileId, hash: doc.hash });
        }
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (this.selectedFile) {
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                    if (type == cnst.DocumentTypes.TA_DOC_REC_DIRECTOR_RESOLUTION) {
                        this.form.patchValue({ directorResolution: data });

                    } else if (type == cnst.DocumentTypes.TA_DOC_REC_BANK_STATEMENT) {
                        this.form.patchValue({ bankStatement: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_ACRA_BIZ) {
                        this.form.patchValue({ acra: data });
                    } else {
                        const fileDto = this.formBuilder.group({
                            id: [],
                            publicFileId: [],
                            originalName: [],
                            processedName: [],
                            docType: [],
                            extension: [],
                            path: [],
                            size: [],
                            hash: [],
                            documentInstructions: [],
                            documentTypeLabel: [],
                            description: [],
                            readableFileSize: [],
                        });
                        fileDto.patchValue(data);
                        this.otherDocuments.push(fileDto);
                    }
                });
            }
        }
        event.target.value = '';
    }

    loadAppEdh() {

        this.edhService.getEdhEntityFinancials().subscribe(data => {
            if (data.errorMessage) {
                this.alertService.error(cnst.TaAlertMessages.EDH_ERROR);
                this.form.patchValue({ isEdhPopulated: false });
            }
            else {
                this.edhData.financials = data;
                if (data.capitals[0]) {
                    this.application.capital = this.edhData.financials.capitals[0].paidUpCapitalAmount ? this.edhData.financials.capitals[0].paidUpCapitalAmount : 0;
                    this.form.patchValue({ capital: this.application.capital });
                }
                else {
                    this.application.capital = 0;
                    this.form.patchValue({ capital: this.application.capital });
                }
                this.form.patchValue({ isEdhPopulated: true });
            }

        });
    }

    clearAppEdh() {
        this.form.patchValue({ capital: 0 });
        this.form.patchValue({ isEdhPopulated: false });
    }

    showPreview() {
        this.alertService.clear();
        if (!this.form.get('directorResolution').get('originalName').value && !this.form.get('bankStatement').get('originalName').value) {
            this.alertService.error(cnst.Messages.MSG_MIN_DOC);
            this.showErrorMsg = true;
        } else {
            this.alertService.clear();
            if (this.form.valid) {
                this.preview = true;
                window.scrollTo(0, 0);
                this.form.controls['declared'].enable();
            } else {
                this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
                this.showErrorMsg = true;
            }
        }
    }

    backToApplicationForm() {
        this.preview = false;
        this.form.controls['declared'].disable();
    }

    saveConfirmationDialog() {
        if (this.form.valid) {
            if (this.form.value.declared) {
                this.service.save(this.form.value).subscribe(savedDate => {
                    this.service.checkForPendingApplication().subscribe(data => {
                        this.form.markAsPristine();
                        this.service.email(data.applicationId).subscribe(emailData => {
                            this.router.navigate(['/portal/ta-thankyou'], { queryParams: { applicationNo: data.applicationNo, id: data.applicationId } });
                        });
                    });
                });
            } else {
                alert(cnst.Messages.MSG_DECLARATION_CHECK)
            }
        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    updateConfirmationDialog() {
        if (this.form.valid) {
            this.service.update(this.form.value, this.adminDeletedFiles).subscribe(data => {
                this.fileUtil.delete(this.publicDeletedFiles).subscribe();
                this.service.checkForPendingApplication().subscribe(data => {
                    this.form.markAsPristine();
                    this.service.email(data.applicationId).subscribe(emailData => {
                        this.router.navigate(['/portal/ta-thankyou'], { queryParams: { applicationNo: data.applicationNo, id: data.applicationId } });
                    });
                });
            });
        } else {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
        }
    }

    downloadShortfallLetter(file) {
        if (file.publicFileId) {
            this.fileUtil.download(file.publicFileId, file.hash).subscribe(data => {
                this.fileUtil.export(data, file.processedName);
            });
        } else {
            this.errorDialogService.openDialog({ reason: "File is unavailable at this moment. Please check back again later." });
        }
    }
}
