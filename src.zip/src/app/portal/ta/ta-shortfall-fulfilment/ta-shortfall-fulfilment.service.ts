import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class TaShortfallFulfilmentService {

    constructor(private http: HttpClient) { }

    checkForPendingApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_NET_VALUE_RECTIFICATION + '/load');
    }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TaApiUrl.TA_NET_VALUE_RECTIFICATION + '/load/' + applicationId);
    }

    save(application: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_NET_VALUE_RECTIFICATION + '/save', application);
    }

    update(application: any, deletedList: any): Observable<any> {
        var formData = this.buildFormData(application, deletedList);
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_NET_VALUE_RECTIFICATION + '/update', formData);
    }

    email(applicationId: number): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_NET_VALUE_RECTIFICATION + '/save/email-acknowledgement/' + applicationId, {});
    }

    buildFormData(application, deletedList) {

        var formDataObj = new FormData();
        var applicationBlob = new Blob(
            [JSON.stringify(application)],
            { type: 'application/json' }
        );
        formDataObj.append('application', applicationBlob);

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formDataObj.append('deletedFiles', deletedBlob);
        return formDataObj;
    }
}
