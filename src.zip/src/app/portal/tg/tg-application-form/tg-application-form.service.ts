import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgApplicationFormService {

    constructor(private http: HttpClient) { }

    public newApplication(): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CREATION + "/new");
    }

    public save(newApp: any, deletedList: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(newApp)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CREATION + '/save', formData);
    }

    public draft(newApp: any, deletedList: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(newApp)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CREATION + '/draft', formData);
    }

    public edit(id: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CREATION + "/edit/" + id);
    }

    public update(newApp: any, deletedList: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(newApp)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CREATION + '/update', formData);
    }

    public getApplicationNo(module: String): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + "/tg/" + module + "/new/application-no");
    }

    public savePaymentRequest(newApp: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(newApp)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CREATION + '/save/payment', formData);
    }

    public saveAfterPayment(module: String, appId: number): Observable<any> {
        if (module == 'mlpt') module = 'mlpt/registration';
        if (module == 'switch-tier') module = 'candidates/switch-tier';
        return this.http.get<any>(cnst.apexBaseUrl + "/tg/" + module + "/save/" + appId);
    }

    public saveAfterMlptCardPayment(module: String, mlptId: number): Observable<any> {
        if (module == 'mlpt') module = 'mlpt/registration';
        return this.http.get<any>(cnst.apexBaseUrl + "/tg/" + module + "/save/licence-print/" + mlptId);
    }

    getApplication(module: String, appId: number): Observable<any> {
        if (module == 'mlpt') module = 'mlpt/registration';
        if (module == 'switch-tier') module = 'candidates/switch-tier';
        return this.http.get<any>(cnst.apexBaseUrl + "/tg/" + module + "/load/" + appId);
    }

    getMlpt(module: String, mlptId: number): Observable<any> {
        if (module == 'mlpt') module = 'mlpt/registration';
        return this.http.get<any>(cnst.apexBaseUrl + "/tg/" + module + "/load/mlpt/" + mlptId);
    }
}
