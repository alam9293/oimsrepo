import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TgApplicationFormService } from '../tg-application-form/tg-application-form.service';
import { AuthenticationService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { AppUtil } from '../../../common/helper';

@Component({
    selector: 'app-tg-application-success',
    templateUrl: './tg-application-success.component.html',
    styleUrls: ['./tg-application-success.component.scss']
})
export class TgApplicationSuccessComponent implements OnInit {

    showAppSubmissionSuccessMessage: boolean = false;
    showAppFeeFailureMessage: boolean = false;
    showAppSubmissionFailureMessage: boolean = false;
    showLicenceFeeFailedMessage: boolean = false;
    showLicenceFeeSuccessMessage: boolean = false;
    showDraftSubmissionMessage: boolean = false;
    application: any;
    appId: any;
    mlptId: any;
    appNo: String;
    module: String;
    isDraft: boolean;
    cnst = cnst;
    payRefNo: any;
    paymentResult: any = { lastTxn: {} };
    showPaymentResult: boolean = false;

    constructor(
        private route: ActivatedRoute,
        private service: TgApplicationFormService,
        private authenticationService: AuthenticationService,
        private router: Router,
        public appUtil: AppUtil,
    ) { }

    ngOnInit() {
        this.module = this.route.snapshot.paramMap.get('module');
        this.appId = this.route.snapshot.paramMap.get('appId');
        this.mlptId = this.route.snapshot.paramMap.get('mlptId');
        var paymentSuccessStatuses = [cnst.PaymentStatuses.PAYREQ_SETTLED, cnst.PaymentStatuses.PAYREQ_PAID, cnst.PaymentStatuses.PAYREQ_WAIVED];

        if (this.appId != null && this.mlptId == null) {
            if (this.route.snapshot.paramMap.get('anyBillRefNo') != null) {
                this.service.getApplication(this.module, this.appId).subscribe(data => {
                    this.application = data;
                    this.paymentResult = data.appFee;
                    this.showPaymentResult = true;
                    if (this.module == cnst.TgModule.TG_MODULE_MLPT) {
                        this.mlptId = data.mlptId;
                    }

                    if (paymentSuccessStatuses.includes(this.application.appFee.statusCode)) {
                        this.service.saveAfterPayment(this.module, this.appId).subscribe(data => {
                            this.payRefNo = this.application.appFee.billRefNo;
                            this.showAppSubmissionSuccessMessage = true;
                            this.isDraft = data.isDraft;
                        }, error => {
                            this.showAppSubmissionFailureMessage = true;
                        });
                    } else {
                        this.showAppSubmissionFailureMessage = true;
                    }
                })
            } else {
                this.service.getApplication(this.module, this.appId).subscribe(data => {
                    this.application = data;
                    this.isDraft = this.application.isDraft;
                    if (this.isDraft == false) {
                        this.showAppSubmissionSuccessMessage = true;
                    } else {
                        this.showAppSubmissionFailureMessage = true;
                    }
                })
            }
        } else if (this.mlptId != null) {
            if (this.route.snapshot.paramMap.get('anyBillRefNo') != null) {
                this.service.getMlpt(this.module, this.mlptId).subscribe(data => {
                    this.application = data;
                    this.paymentResult = data.cardFee;
                    this.showPaymentResult = true;

                    if (paymentSuccessStatuses.includes(this.application.cardFee.statusCode)) {
                        this.service.saveAfterMlptCardPayment(this.module, this.mlptId).subscribe(data => {
                            this.payRefNo = this.application.cardFee.billRefNo;
                            this.showAppSubmissionSuccessMessage = true;
                            this.isDraft = data.isDraft;
                        }, error => {
                            this.showAppSubmissionFailureMessage = true;
                        });
                    } else {
                        this.showAppSubmissionFailureMessage = true;
                    }
                })
            } else {
                this.service.getMlpt(this.module, this.mlptId).subscribe(data => {
                    this.application = data;
                    if (data.licencePrintStatus != "") {
                        this.showAppSubmissionSuccessMessage = true;
                    } else {
                        this.showAppSubmissionFailureMessage = true;
                    }
                })
            }
        } else {
            this.service.getApplicationNo(this.module).subscribe(data => {
                this.appId = data.id;
                this.isDraft = data.isDraft;
                this.application = data;
                if (this.isDraft == true) {
                    this.showDraftSubmissionMessage = true;
                } else {
                    this.showAppSubmissionSuccessMessage = true;
                }
            });
        }
    }

    routeToAppPreview() {
        switch (this.module) {
            case cnst.TgModule.TG_MODULE_CREATIONS:
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_CREATION + this.appId]);
                break;
            case cnst.TgModule.TG_MODULE_PARTICULARS:
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_PERSON_UPDATE + this.appId]);
                break;
            case cnst.TgModule.TG_MODULE_REPLACE:
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_REPLACEMENT + this.appId]);
                break;
            case cnst.TgModule.TG_MODULE_RENEWAL:
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_RENEWAL]);
                break;
            case cnst.TgModule.TG_MODULE_MLPT:
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_MLPT + this.mlptId]);
                break;
            case cnst.TgModule.TG_MODULE_SWITCH_TIER:
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_SWITCH_TIER + this.appId]);
                break;
        }
    }

    resume() {
        this.router.navigate(['/portal/tg/application-form/' + this.appId]);
    }

    backToPortal() {
        this.appUtil.routeToHomePage();
    }

    onLoggedout() {
        this.authenticationService.logout();
        //  this.appUtil.routeToHomePage();
    }

    print() {
        window.print();
    }

}
