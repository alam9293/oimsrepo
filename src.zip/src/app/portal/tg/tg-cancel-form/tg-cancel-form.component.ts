import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { TgCancelFormService } from './tg-cancel-form.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';

@Component({
    selector: 'app-tg-cancel-form',
    templateUrl: './tg-cancel-form.component.html',
    styleUrls: ['./tg-cancel-form.component.scss']
})
export class TgCancelFormComponent implements OnInit {
    licenceCancellationId: any;
    form: FormGroup;
    cnst = cnst;

    constructor(
        private _formBuilder: FormBuilder,
        private dialog: MatDialog,
        private tgCancelFormService: TgCancelFormService,
        private route: ActivatedRoute,
        private router: Router) { }

    ngOnInit() {
        this.form = this._formBuilder.group({
            reason: ['', Validators.required],
            agreeCheck: ['', Validators.requiredTrue],
            status: [],
            statusRemark: [],
            applicationNo: [],
            id: [], // licence cancellation id
            allowCancel: []
        });

        if (this.route.snapshot.paramMap.get('id') != null) {
            this.licenceCancellationId = parseInt(this.route.snapshot.paramMap.get('id'), 10);
        }

        if (this.licenceCancellationId != null) {
            this.tgCancelFormService.edit(this.licenceCancellationId).subscribe(data => {
                this.patchData(data);
            });
        } else {
            this.tgCancelFormService.newApplication().subscribe(data => {
                this.patchData(data);
            });
        }

    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog() {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: { message: 'This action will cancel your current licence' }
        });


        this.dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.tgCancelFormService.save(this.form.getRawValue()).subscribe(data => {
                    this.form.markAsPristine();
                    this.router.navigate(['/portal/tg/application-success/cancel']);
                });
            }
        });
    }

    patchData(data: any) {
        this.form.patchValue(data);

        if (!data.allowCancel) {
            this.form.disable();

            if (data.reason) {
                this.form.patchValue({
                    agreeCheck: true
                });
            }
        }
    }
}

