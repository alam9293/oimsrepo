import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgCoursesAttendedMrcService {

    constructor(private http: HttpClient) { }

    public getListOfCourseDetails(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view', { params: searchDto });
    }

    public getCurrentList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/current', { params: searchDto });
    }

    public getPastYears(number: number): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/past-years/' + number);
    }
}