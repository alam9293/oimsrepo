import { Injectable } from '@angular/core';
import { FormGroup, FormControl, AbstractControl } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { TgRenewalFormService } from '../tg-renewal-form/tg-renewal-form.service';

@Injectable({
    providedIn: 'root'
})
export class TgRenewalHelperUtil {

    constructor(
        private tgRenewalFormService: TgRenewalFormService,
    ) { }

    getConditionGroup() {
        const conditionGroup = new FormGroup({
            key: new FormControl('', this.isRenewableCondition),
            value: new FormControl('')
        });

        return conditionGroup;
    }

    loadConditions(form: FormGroup) {
        this.tgRenewalFormService.getCondition().subscribe(data => {
            form.get('mrc').setValue(this.assignConditionSrc(data.mrc));
            form.get('pdc').setValue(this.assignConditionSrc(data.pdc));
            form.get('assignments').setValue(this.assignConditionSrc(data.assignments));
            form.get('cpf').setValue(this.assignConditionSrc(data.cpf));
            if (form.get('isCurrentTgPhoto').value) {
                form.get('newPhoto').setValue(this.assignConditionSrc(cnst.renewalStatusCode.renewalTick));
            } else {
                form.get('newPhoto').setValue(this.assignConditionSrc(data.newPhoto));
            }
            form.get('medicalReport').setValue(this.assignConditionSrc(data.medicalReport));
            form.get('workPass').setValue(this.assignConditionSrc(data.workPass));
            form.get('assessment').setValue(this.assignConditionSrc(data.assessment));
            if (form.get('isOpenForRenewal')) {
                form.get('isOpenForRenewal').setValue(data.isOpenForRenewal);
            }
            if (form.get('isRfaApp').value) {
                form.get('mrc').setValue(this.assignConditionSrc(cnst.renewalStatusCode.renewalTick));
                form.get('pdc').setValue(this.assignConditionSrc(cnst.renewalStatusCode.renewalTick));
                form.get('assignments').setValue(this.assignConditionSrc(cnst.renewalStatusCode.renewalTick));
            }

        });
    }

    assignConditionSrc(status: String) {
        var value = '';

        switch (status) {
            case cnst.renewalStatusCode.renewalBlank:
                value = cnst.renewalStatusUrl.renewalBlank;
                break;
            case cnst.renewalStatusCode.renewalTick:
                value = cnst.renewalStatusUrl.renewalTick;
                break;
            case cnst.renewalStatusCode.renewalGrey:
                value = cnst.renewalStatusUrl.renewalGrey;
                break;
            case cnst.renewalStatusCode.renewalGreyTemp:
                value = cnst.renewalStatusUrl.renewalGrey;
                break;
            case cnst.renewalStatusCode.renewalHide:
                value = '';
                break;
            default:
        }

        return { 'key': status, 'value': value };
    }

    isEditable(control: AbstractControl): { [key: string]: any } | null {
        let criteria: boolean = control.value == cnst.ApplicationStatuses.TG_APP_PENDING_APPROVAL ||
            control.value == cnst.ApplicationStatuses.TG_APP_APPROVED ||
            control.value == cnst.ApplicationStatuses.TG_APP_REJECTED;
        return criteria ? { isEditable: true } : null;
    }

    isRenewableCondition(control: AbstractControl): { [key: string]: any } | null {
        return (control.value == cnst.renewalStatusCode.renewalBlank || control.value == cnst.renewalStatusCode.renewalGreyTemp) ? { invalidCondition: true } : null;
    }

    isConditionGrey(condition: AbstractControl) {
        return condition.value.key == cnst.renewalStatusCode.renewalGrey || condition.value.key == cnst.renewalStatusCode.renewalGreyTemp;
    }

    isConditionGreyOnly(condition: AbstractControl) {
        return condition.value.key == cnst.renewalStatusCode.renewalGrey;
    }

    isConditionGreyTemp(condition: AbstractControl) {
        return condition.value.key == cnst.renewalStatusCode.renewalGreyTemp;
    }

    isConditionHide(condition: AbstractControl) {
        return condition.value.key == cnst.renewalStatusCode.renewalHide;
    }

    isConditionTickOnly(condition: AbstractControl) {
        return condition.value.key == cnst.renewalStatusCode.renewalTick;
    }

    isConditionBlankOnly(condition: AbstractControl) {
        return condition.value.key == cnst.renewalStatusCode.renewalBlank;
    }
}