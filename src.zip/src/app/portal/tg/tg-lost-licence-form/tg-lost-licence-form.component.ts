import { Component, OnInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { FileUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';
import { TgLostLicenceFormService } from './tg-lost-licence-form.service';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { PaymentDialogComponent } from 'src/app/common/modules/payment-dialog/payment-dialog.component';
import { PaymentService } from '../../payment/payment.service';
import { TgFormHelperUtil } from '../tg-helper';

@Component({
    selector: 'app-tg-lost-licence-form',
    templateUrl: './tg-lost-licence-form.component.html',
    styleUrls: ['./tg-lost-licence-form.component.scss']
})
export class TgLostLicenceFormComponent implements OnInit {
    licenceReplacementId: any;
    selectedFile: File;
    selectedFiles: any = [];
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];
    form: FormGroup;
    cnst = cnst;

    constructor(
        private dialog: MatDialog,
        private formBuilder: FormBuilder,
        private fileUtil: FileUtil,
        private tgLostLicenceFormService: TgLostLicenceFormService,
        private route: ActivatedRoute,
        private router: Router,
        private paymentService: PaymentService,
        private tgFormHelper: TgFormHelperUtil
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.form = this.formBuilder.group({
            totalDoc: [null, [Validators.required, Validators.min(1)]],
            otherSupportDocs: [],
            declareCheck: [false],
            status: [],
            statusRemark: [],
            applicationNo: [],
            id: [],
            paymentSuccess: [],
            paymentFee: [],
            selectedFiles: [],
            isDraft: []
        });

        if (this.route.snapshot.paramMap.get('id') != null) {
            this.licenceReplacementId = parseInt(this.route.snapshot.paramMap.get('id'), 10);
        }

        if (this.licenceReplacementId != null) {
            this.tgLostLicenceFormService.edit(this.licenceReplacementId).subscribe(data => {
                this.patchData(data);
            });
        } else {
            this.tgLostLicenceFormService.newApplication().subscribe(data => {
                this.form.patchValue(data);
                if (data.id != null || this.tgFormHelper.checkIsProcessingOrRFA(data.status)) {
                    this.router.navigate(['/portal/tg/lost-licence-form/' + data.id]);
                }
            });
        }
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {

                this.selectedFiles.push(data);
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            });
        }
    }

    setPhotoTouched() {
        this.form.controls['totalDoc'].markAsTouched({ onlySelf: true });
    }

    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.form.get('totalDoc').setValue(this.selectedFiles.length);
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push({ publicFileId: doc.publicFileId, hash: doc.hash });
        }
    }

    downloadFile(doc) {
        var fileId, fileName;
        if (doc.publicFileId == null) {
            fileId = doc.id;
            fileName = doc.originalName;
        } else {
            fileId = doc.publicFileId;
            fileName = doc.processedName;
        }

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    save() {
        // this dialog for user to select payment type
        let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('paymentFee').value, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_APP_REPLACEMENT } });
        dialog.afterClosed().subscribe(result => {
            if (result.decision) {
                let paymentType = result.type;
                this.form.get('isDraft').setValue(true);
                this.form.patchValue({
                    otherSupportDocs: this.selectedFiles
                });
                this.tgLostLicenceFormService.save(this.form.getRawValue()).subscribe(data => {
                    let application = data;
                    this.form.markAsPristine();
                    this.fileUtil.delete(this.publicDeletedFiles).subscribe();
                    if (application.billRefNo == null) {
                        this.tgLostLicenceFormService.savePaymentRequest(this.form.getRawValue()).subscribe(result => {
                            let billRefNo = [];
                            billRefNo.push(result.billRefNo);
                            if (paymentType == cnst.PaymentTypes.PAYNOW) {
                                this.generatePaynowQRCode(result.id, billRefNo, paymentType);
                            } else {
                                this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_REPLACE + '/' + result.id + '/' + billRefNo);
                            }
                        });
                    } else {
                        let billRefNo = [];
                        billRefNo.push(application.billRefNo);
                        if (paymentType == cnst.PaymentTypes.PAYNOW) {
                            this.generatePaynowQRCode(application.id, billRefNo, paymentType);
                        } else {
                            this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_REPLACE + '/' + application.id + '/' + billRefNo);
                        }
                    }

                });
            }
        });
    }

    generatePaynowQRCode(id: any, billRefNo: any, paymentType: any) {
        this.paymentService.createPayNowTxn(this.form.get('paymentFee').value, billRefNo).subscribe(txn => {
            let payNowTxnId = txn;
            this.paymentService.generateQrCode(this.form.get('paymentFee').value, txn).subscribe(qrCode => {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.form.get('paymentFee').value, paymentRequestType: cnst.PaymentRequestTypes.PAYREQ_TG_APP_REPLACEMENT, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TG_RETURN, paymentType, billRefNo, cnst.TgApplicationUrl.TG_APP_SUCCESS_REPLACE + '/' + id + '/' + billRefNo, payNowTxnId);
                    } else {
                        this.form.get('isDraft').setValue(null);
                    }
                });
            });
        });
    }

    update() {
        this.form.patchValue({
            otherSupportDocs: this.selectedFiles
        });
        this.tgLostLicenceFormService.update(this.form.getRawValue(), this.adminDeletedFiles).subscribe(data => {
            this.form.markAsPristine();
            this.fileUtil.delete(this.publicDeletedFiles).subscribe();
            this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_REPLACE + '/' + this.form.get('id').value]);
        });
    }

    submit() {
        this.tgLostLicenceFormService.saveAfterPayment(this.form.get('id').value).subscribe(data => {
            this.form.markAsPristine();
            this.fileUtil.delete(this.publicDeletedFiles).subscribe();
            this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_REPLACE + '/' + this.form.get('id').value]);
        });
    }

    patchData(data: any) {
        this.form.patchValue(data);
        if (data.otherSupportDocs) {
            this.selectedFiles = data.otherSupportDocs;
        } else {
            this.selectedFiles = [];
        }
        this.form.get('totalDoc').setValue(this.selectedFiles.length);

        if (!data.allowReplace || (data.status != null && data.status.key != cnst.ApplicationStatuses.TG_APP_RFA)) {
            this.form.disable();

            this.form.patchValue({
                declareCheck: true
            });
        }
    }
}
