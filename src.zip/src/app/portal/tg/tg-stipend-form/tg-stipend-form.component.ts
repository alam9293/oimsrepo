import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertService, CommonService } from '../../../common/services';
import { FileUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';
import { TgStipendFormService } from './tg-stipend-form.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-tg-stipend-form',
    templateUrl: './tg-stipend-form.component.html',
    styleUrls: ['./tg-stipend-form.component.scss']
})
export class TgStipendFormComponent implements OnInit {
    stipendSubmissionId: any;
    applicationId: any;
    configId: any;
    isRfaOrFollowUp: boolean = false;
    form: FormGroup;
    cnst = cnst;

    selectedFile: File;
    selectedFiles: any = [];
    adminDeletedFiles: any = [];
    publicDeletedFiles: any = [];

    constructor(
        private formBuilder: FormBuilder,
        private alertService: AlertService,
        private fileUtil: FileUtil,
        private tgStipendFormService: TgStipendFormService,
        private commonService: CommonService,
        private route: ActivatedRoute,
        private router: Router) { }

    ngOnInit() {
        this.initForm();

        if (this.route.snapshot.paramMap.get('id') != null) {
            this.stipendSubmissionId = parseInt(this.route.snapshot.paramMap.get('id'), 10);
        }
        if (this.route.snapshot.queryParamMap.get('configId')) {
            this.configId = parseInt(this.route.snapshot.queryParamMap.get('configId'), 10);
        }
        if (this.route.snapshot.paramMap.get('appId') != null) {
            this.applicationId = parseInt(this.route.snapshot.paramMap.get('appId'), 10);
        }

        if (this.stipendSubmissionId != null) {
            this.tgStipendFormService.load(this.stipendSubmissionId).subscribe(data => {
                this.patchData(data);
            });
        } else if (this.applicationId != null) {
            this.tgStipendFormService.loadByApplication(this.applicationId).subscribe(data => {
                this.patchData(data);
            });
        } else {
            this.tgStipendFormService.newApplication(this.configId).subscribe(data => {
                this.patchData(data);
            });
        }
    }

    initForm() {
        this.form = this.formBuilder.group({
            id: [], // stipend submission id
            applicationNo: [],
            applicationStatus: [],
            externalRemarks: [],
            appPayout: [],
            name: [],
            licenceNo: [],
            guidingLanguage: [],
            residentialStatus: [],
            nameAsPerBank: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            bankName: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            bankCode: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr), Validators.pattern('^[0-9]*$')]],
            bankBranchCode: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr), Validators.pattern('^[0-9]*$')]],
            bankAccountNo: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr), Validators.pattern('^[0-9]*$')]],
            amount: [],
            declarationCheck: ['', Validators.requiredTrue],
            configDto: [],
            supportingDocs: [],
            totalDoc: [null, [Validators.required, Validators.min(1)]],
            isEligible: [],
            lastActionType: []
        });
    }

    patchData(data: any) {
        this.form.patchValue(data);
        if (data.supportingDocs) {
            this.selectedFiles = data.supportingDocs;
        } else {
            this.selectedFiles = [];
        }
        this.form.get('totalDoc').setValue(this.selectedFiles.length);

        this.isRfaOrFollowUp = this.stipendSubmissionId != null 
        && ((data.applicationStatus && data.applicationStatus.key == cnst.ApplicationStatuses.TG_APP_RFA)
        || (data.lastActionType && data.lastActionType.key == cnst.WorkflowActionTypes.WKFLW_ACT_FOLLOW_UP));

        if (this.stipendSubmissionId != null && !this.isRfaOrFollowUp) {
            this.form.disable();

            this.form.patchValue({
                declarationCheck: true
            });
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    submit() {
        this.alertService.clear();
        if (this.form.invalid) {
            this.alertService.error("Please ensure all fields are filled up correctly");
        } else {
            this.form.patchValue({
                supportingDocs: this.selectedFiles
            });
            this.tgStipendFormService.save(this.form.getRawValue(), this.adminDeletedFiles).subscribe(data => {
                this.form.markAsPristine();
                this.fileUtil.delete(this.publicDeletedFiles).subscribe();
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_STIPEND + '/' + data]);
            });
        }
    }

    update() {
        this.alertService.clear();
        if (this.form.invalid) {
            this.alertService.error("Please ensure all fields are filled up correctly");
        } else {
            this.form.patchValue({
                supportingDocs: this.selectedFiles
            });
            this.tgStipendFormService.update(this.form.getRawValue(), this.adminDeletedFiles).subscribe(data => {
                this.form.markAsPristine();
                this.fileUtil.delete(this.publicDeletedFiles).subscribe();
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_STIPEND + '/' + data]);
            });
        }
    }

    updateAfterFollowUp() {
        this.alertService.clear();
        if (this.form.invalid) {
            this.alertService.error("Please ensure all fields are filled up correctly");
        } else {
            this.tgStipendFormService.updateAfterFollowUp(this.form.value).subscribe(data => {
                this.form.markAsPristine();
                this.router.navigate([cnst.TgApplicationUrl.TG_APP_SUCCESS_STIPEND + '/' + data]);
            });
        }
    }

    onSupportingDocChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                this.selectedFiles.push(data);
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            });
        }
    }

    removeSupportingDoc(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.form.get('totalDoc').setValue(this.selectedFiles.length);
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
            this.publicDeletedFiles.push({ publicFileId: doc.publicFileId, hash: doc.hash });
        }
    }

    downloadSupportingDoc(doc) {
        var fileId, fileName;
        if (doc.publicFileId == null) {
            fileId = doc.id;
            fileName = doc.originalName;
        } else {
            fileId = doc.publicFileId;
            fileName = doc.processedName;
        }

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

}

