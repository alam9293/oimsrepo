import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthenticationService } from 'src/app/common/services';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-tg-thankyou',
    templateUrl: './tg-thankyou.component.html',
    styleUrls: ['./tg-thankyou.component.scss']
})
export class TgThankyouComponent implements OnInit {
    title: string;
    applicationNo: string;
    currentUser: any = {};
    cnst = cnst;

    constructor(
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
        this.title = this.route.snapshot.queryParams.title;
        this.applicationNo = this.route.snapshot.queryParams.applicationNo;
        this.currentUser = this.authenticationService.currentUserValue;
        
    }

}
