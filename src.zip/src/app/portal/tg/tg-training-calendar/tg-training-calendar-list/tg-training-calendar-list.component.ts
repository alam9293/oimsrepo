import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { TgTrainingCalendarService } from '../tg-training-calendar.service';
import { CommonService } from '../../../../common/services';
import { DateUtil } from '../../../../common/helper';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
    selector: 'app-tg-training-calendar-list',
    templateUrl: './tg-training-calendar-list.component.html',
    styleUrls: ['./tg-training-calendar-list.component.scss']
})
export class TgTrainingCalendarListComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    listOfCourseDataSource = [];
    listOfCoursedisplayedColumns: string[] = ['no', 'attendedDate', 'courseName', 'tpName', 'noOfHours', 'language', 'category'];
    filter: any = {};
    cnst = cnst;
    totalPages: number = 0;
    currentPage: number = 0;
    tps: any;
    categoryTypes: any;
    languageTypes: any;
    showMore: Boolean = false;

    constructor(
        private tgTrainingCalendarService: TgTrainingCalendarService,
        private commonService: CommonService,
    ) { }

    ngOnInit() {
        this.commonService.getTpsForPDC().subscribe(data => {
            this.tps = data;
        });
        this.commonService.getTgCourseCategoryTypes().subscribe(data => {
            this.categoryTypes = data;
        });
        this.commonService.getTgGuidingLanguages().subscribe(data => {
            this.languageTypes = data;
        });
        this.loadListOfCourseDetails();
    }

    loadListOfCourseDetails() {
        this.filter.type = cnst.TpCourseTypes.pdc;
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filter
        };

        this.tgTrainingCalendarService.getListOfCourseDetails(mergedDto).subscribe(data => {
            this.listOfCourseDataSource = data.records;
            this.paginator.length = data.total;
            this.currentPage = this.paginator.pageIndex + 1;
            this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        });

    }

    clearFilter() {
        this.filter = {};
    }

    nextPage() {
        if (this.currentPage < this.totalPages) {
            this.paginator.pageIndex += 1;
            this.loadListOfCourseDetails();
        }
    }

    previousPage(selection: String) {
        if (this.currentPage > 1) {
            this.paginator.pageIndex -= 1;
            this.loadListOfCourseDetails();
        }
    }

    pageSizeChange(selection: String) {
        this.totalPages = Math.ceil(this.paginator.length / this.paginator.pageSize);
        if (this.currentPage > this.totalPages) {
            this.paginator.pageIndex = this.totalPages - 1;
        }
        this.loadListOfCourseDetails();
    }
}
