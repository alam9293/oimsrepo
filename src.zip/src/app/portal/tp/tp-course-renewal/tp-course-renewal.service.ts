import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TpCourseRenewalService {

    public baseUrl = cnst.apexBaseUrl + cnst.TgAPiUrl.TG_COURSE_RENEWAL;

    constructor(private http: HttpClient) { }

    getCourse(courseCode: any): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/load/' + courseCode);
    }

    submitCourseRenewal(formData: any): Observable<any> {
        return this.http.post(this.baseUrl + '/save', formData, { responseType: 'text' });
    }

    getCourseRenewalApplication(id): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view/' + id);
    }

    createAlert(id): Observable<any> {
        return this.http.post(this.baseUrl + '/save/create-alert/' + id, { responseType: 'text' });
    }
}