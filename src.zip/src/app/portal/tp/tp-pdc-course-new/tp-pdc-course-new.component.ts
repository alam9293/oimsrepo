import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTable, DateAdapter } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { FileUtil, FormUtil } from 'src/app/common/helper';
import { CommonService } from 'src/app/common/services';

import * as cnst from '../../../common/constants';
import { TaFormHelperUtil } from '../../ta/ta-helper';
import { TpPdcCourseService } from '../tp-pdc-course/tp-pdc-course.service';
import { TpPdcCourseNewService } from './tp-pdc-course-new.service';
import { Observable } from 'rxjs';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
    selector: 'app-tp-pdc-course-new',
    templateUrl: './tp-pdc-course-new.component.html',
    styleUrls: ['./tp-pdc-course-new.component.scss']
})
export class TpPdcCourseNewComponent implements OnInit {
    public Editor = ClassicEditor;
    public config = { toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'inserttable', 'undo', 'redo'] };
    form: FormGroup;
    @ViewChild(MatTable) _matTables;
    subsidiesColumns = ['title', 'description', 'fee'];
    subsidiesRows: any = [];
    commonData: any = {};
    cnst = cnst;
    isPreview: boolean = false;
    isEditable: boolean = true;
    adminDeletedFiles: any = [];

    constructor(
        private commonService: CommonService,
        private tpPdcCourseNewService: TpPdcCourseNewService,
        private router: Router,
        private route: ActivatedRoute,
        private formBuilder: FormBuilder,
        public formUtil: FormUtil,
        public fileUtil: FileUtil,
        public taFormHelperUtil: TaFormHelperUtil
    ) { }

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.buildForm();
        this.loadCommonTypes();

        if (this.route.snapshot.paramMap.has('id')) {
            this.tpPdcCourseNewService.getApplication(this.route.snapshot.paramMap.get('id')).subscribe(data => {
                {
                    this.patchData(data);

                    if (data.applicationStatus.key !== cnst.ApplicationStatuses.TG_APP_RFA) {
                        this.isPreview = true;
                        this.isEditable = false;
                    }
                }
            }, error => {

            });
        } else {
            this.commonService.getTgCourseSubsidies().subscribe(data => {
                this.setSubsidies(data);
                this._matTables.renderRows();
            });
        }
    }

    goBack() {
        window.history.back();
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    buildForm() {

        let tgCourseFormGroup = this.formBuilder.group({
            code: [''],
            name: ['', Validators.required],
            approvedStartDate: [''],
            approvedEndDate: [''],
            languageCode: ['', Validators.required],
            languageLabel: [''],
            typeCode: [''],
            typeLabel: [''],
            noOfHours: [''],
            categoryCode: ['', Validators.required],
            categoryLabel: [''],
            ssgCourseCode: [''],
            objective: ['', Validators.required],
            outline: ['', Validators.required],
            classroomHrs: ['', Validators.required],
            outOfClassroomHrs: ['', Validators.required],
            courseFee: ['', Validators.required],
            courseFeeNote: [''],
            subsidies: this.formBuilder.array([]),
        });

        this.form = this.formBuilder.group({
            applicationStatus: [],
            externalRemarks: [],
            applicationNo: [],
            id: [''],
            tgCourse: tgCourseFormGroup,
            trainers: ['', Validators.required],
            assessment: ['', Validators.required],
            // appropriateLevel: ['', Validators.required],
            synopsis: ['', Validators.required],
            docs: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.minLengthArray(1)])),
        });

    }

    addSubsidyRow(value?) {
        let subsidyRow = this.formBuilder.group({
            id: [''],
            typeCode: [''],
            title: [''],
            description: [''],
            fee: ['']
        });
        if (value) {
            subsidyRow.patchValue(value);
        }
        this.subsidies.push(subsidyRow);
    }

    get subsidies() {
        return this.form.get('tgCourse').get('subsidies') as FormArray;
    }

    setSubsidies(data) {
        let control = <FormArray>this.form.get('tgCourse').get('subsidies');
        data.forEach(x => {
            control.push(this.formBuilder.group({
                id: [x.id],
                typeCode: [x.typeCode],
                title: [x.title],
                description: [x.description],
                fee: [x.fee]
            }));
        });
    }

    loadCommonTypes() {
        this.commonService.getTgGuidingLanguages().subscribe(data => this.commonData.tgGuidingLanguages = data);
        this.commonService.getTgCourseCategoryTypes().subscribe(data => this.commonData.tgCourseCategoryTypes = data);
    }

    submit() {
        if (this.form.valid) {
            this.tpPdcCourseNewService.submitNewCourse(this.form.value, this.adminDeletedFiles).subscribe(data => {
                this.form.markAsPristine();
                this.tpPdcCourseNewService.createAlert(data).subscribe(data => {
                    this.router.navigate([cnst.TpApplicationUrl.TP_APP_SUCCESS_COURSE_CREATION + '/' + data]);
                })
            })
        }
    }

    get courseForm() {
        return this.form.get('tgCourse');
    }

    get docs() {
        return this.form.get('docs') as FormArray;
    }

    onFileChanged(event, type) {
        let selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(selectedFile)) {
            this.fileUtil.upload(type, selectedFile).subscribe(data => {
                this.addDoc(data);
            });
        }
        event.target.value = '';
    }

    removeDoc(index, doc) {
        this.docs.removeAt(index);
        if (doc.publicFileId) {
            this.adminDeletedFiles.push(doc.id);
        }
    }

    addDoc(value?) {
        let docRow = this.buildFileFormGroup();
        if (value) {
            docRow.patchValue(value);
        }
        this.docs.push(docRow);
    }

    downloadFile(doc) {
        this.fileUtil.download(doc.id, doc.hash).subscribe(data => {
            this.fileUtil.export(data, doc.originalName);
        });
    }

    buildFileFormGroup(): FormGroup {
        return this.formBuilder.group({
            id: [],
            publicFileId: [],
            originalName: [''],
            processedName: [],
            docType: [],
            extension: [],
            path: [],
            size: [],
            hash: [],
            documentInstructions: [],
            documentTypeLabel: [],
            description: [],
            readableFileSize: [],
            hasTemplate: [],
        });
    }

    patchData(data: any) {
        this.form.patchValue(data);

        if (data.docs) {
            data.docs.forEach(element => {
                this.addDoc(element);
            });
        }

        if (data.tgCourse && data.tgCourse.subsidies) {
            this.setSubsidies(data.tgCourse.subsidies);
            this._matTables.renderRows();
        }
    }
}
