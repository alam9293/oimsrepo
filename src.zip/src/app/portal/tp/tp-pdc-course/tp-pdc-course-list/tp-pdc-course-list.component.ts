import { Component, OnInit, ViewChild } from '@angular/core';
import { TpPdcCourseService } from '../tp-pdc-course.service';
import { CommonService } from 'src/app/common/services';
import * as cnst from '../../../../common/constants';
import { MatPaginator, MatSort } from '@angular/material';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
    selector: 'app-tp-pdc-course-list',
    templateUrl: './tp-pdc-course-list.component.html',
    styleUrls: ['./tp-pdc-course-list.component.scss']
})
export class TpPdcCourseListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    rows: any = [];
    displayedColumns = ['no', 'name', 'approvedStartDate', 'approvedEndDate', 'language'];
    filterForm: FormGroup;
    cnst = cnst;
    commonData: any = {};

    constructor(
        private tpPdcCourseService: TpPdcCourseService,
        private commonService: CommonService,
        private formBuilder: FormBuilder,
    ) { }

    ngOnInit() {
        this.buildFilterForm();
        this.loadCourses();
        this.loadCommonTypes();
    }

    loadCourses() {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filterForm.value
        };

        this.tpPdcCourseService.getApprovedCourses(mergedDto).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
        });
    }

    buildFilterForm() {
        this.filterForm = this.formBuilder.group({
            name: [''],
            approvedStartDate: [''],
            approvedEndDate: [''],
            categoryCode: [''],
            languageCode: [''],
            noOfHours: [''],
        })
    }

    loadCommonTypes() {
        this.commonService.getTgGuidingLanguages().subscribe(data => this.commonData.tgGuidingLanguages = data);
    }
}
