import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators, AbstractControl } from '@angular/forms';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { TpPDCManageService } from './tp-pdc-manage.service';
import { CommonService, AuthenticationService } from '../../../common/services';
import * as cnst from '../../../common/constants';
import { FormUtil, FileUtil } from '../../../common/helper';
import { Observable } from 'rxjs';
import { User } from '../../../common/models';
import * as moment from 'moment';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
    selector: 'app-tp-pdc-manage',
    templateUrl: './tp-pdc-manage.component.html',
    styleUrls: ['./tp-pdc-manage.component.scss']
})
export class TpPDCManageComponent implements OnInit {
    currentUser: User;
    form: FormGroup;
    uploadForm: FormGroup;

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    pdcListDataSource = new MatTableDataSource<any>();
    pdcListDisplayedColumns = ['no', 'name', 'attendedDate', 'noOfParticipants', 'submissionDate'];

    courseList: any = [];
    uploadCourseList: any = [];
    tpCourseAdded: any = [];
    attendanceTypes: any;
    filter: any = {};
    cnst = cnst;

    displayAddPdc: boolean = false; //hide add pdc section by default
    displayCourse: boolean = false;          // hide pdc selection until user select the attended date
    displayDataEntry: boolean = false;       //hide add TG records by default
    displayPreviewPdc: boolean = false; //hide preview pdc section by default

    selectedFile: File;
    selectedFiles: any = [];
    publicDeletedFiles: any = [];

    constructor(public formUtil: FormUtil,
        private fileUtil: FileUtil,
        private formBuilder: FormBuilder,
        private router: Router,
        private tpPdcManageService: TpPDCManageService,
        private authenticationService: AuthenticationService,
        private commonService: CommonService
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.uploadForm.pristine;
    }

    ngOnInit() {
        this.currentUser = this.authenticationService.currentUserValue;
        // check if logged in TP can view PDC
        if (this.currentUser.tpPdc) {
            this.form = this.formBuilder.group({
                courseDate: [''],
                courseCode: ['']
            });

            this.initUploadForm();
            this.loadTpCourse();
        }
        // else route user away 
        else {
            this.router.navigate(['/portal/dashboard-tp']);
        }

    }

    ngAfterViewInit() {
        this.loadPdcList();
    }

    loadAttendanceType() {
        this.commonService.getCourseAttendanceTypes().subscribe(data => this.attendanceTypes = data);
    }

    initUploadForm() {
        this.uploadForm = this.formBuilder.group({
            attendedDate: ['', Validators.required],
            attendedEndDate: ['', Validators.required],
            courseCode: ['', Validators.required],
            supportingDocs: [],
            tgCourseAttendanceDetails: this.formBuilder.array([])
        });
    }

    initCourseAttendanceDetailsItemRows() {
        return this.formBuilder.group({
            licenceNo: ['', Validators.pattern("^[0-9]*$")],
            name: ['', Validators.maxLength(cnst.maxLengthStr)],
            attendance: ['TP_ATN_ATN']
        });
    }

    loadTpCourse() {
        if (this.uploadForm.get('attendedDate').value != "") {
            this.tpPdcManageService.getListOfCourse(this.uploadForm.get('attendedDate').value).subscribe(data => {
                this.uploadCourseList = data;
                for (let course of this.tpCourseAdded) {
                    for (let dropDownCourse of this.uploadCourseList) {
                        if (dropDownCourse.courseCode == course.courseCode && this.uploadForm.get('attendedDate').value == course.startDate) {
                            var index = this.uploadCourseList.indexOf(dropDownCourse);
                            this.uploadCourseList.splice(index, 1);
                        }
                    }

                }

            });
        } else {
            this.tpPdcManageService.getListOfCourse(null).subscribe(data => this.courseList = data);
        }
    }

    resetPdcSearch() {
        this.form.get('courseCode').setValue('');
        this.filter.courseCode = "";
        this.form.get('courseDate').setValue('');
        this.pdcListDataSource = new MatTableDataSource<any>();
        this.paginator.length = 0;
    }

    loadPdcList() {
        if (this.form.get('courseCode').value != undefined && this.form.get('courseCode').value != '') {
            this.filter.courseCode = this.form.get('courseCode').value;
        }
        else {
            this.filter.courseCode = "";
        }
        if (this.form.get('courseDate').value != '') {
            this.filter.courseDate = this.form.get('courseDate').value;
        }
        else {
            this.filter.courseDate = "";
        }
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active,
            'order': this.sort.direction,
            ...this.filter
        };
        this.tpPdcManageService.getListOfCourseDetails(mergedDto).subscribe(data => {
            this.pdcListDataSource = data.records;
            for (let course of data.records) {
                this.tpCourseAdded.push({ courseCode: course.courseCode, startDate: course.attendedDate });
            }

            this.paginator.length = data.total;
        })
    }

    scrollToTop() {
        window.scrollTo(0, 0);
    }

    addCourseAttendanceDetails() {
        const control = <FormArray>this.uploadForm.controls['tgCourseAttendanceDetails'];
        control.push(this.initCourseAttendanceDetailsItemRows());
    }

    deleteCourseAttendanceDetails(index: number) {
        const control = <FormArray>this.uploadForm.controls['tgCourseAttendanceDetails'];
        control.removeAt(index);
        /*set minimum row to be 1, so that user cannot submit empty attendance details
        if (control.length == 0) {
            this.addCourseAttendanceDetails();
        }*/
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {

                this.selectedFiles.push(data);
            });
        }
        event.target.value = '';
    }

    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.publicDeletedFiles.push(doc.id);
    }

    downloadFile(doc) {
        var fileId = doc.id,
            fileName = doc.originalName;

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    getNameFromCode(list, code) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.courseCode == code) {
                    retVal = element.courseName;
                }
            });
        }
        return retVal;
    }

    getLanguageFromCode(list, code) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.courseCode == code) {
                    retVal = element.language;
                }
            });
        }
        return retVal;
    }

    uploadAttendance() {
        this.uploadForm.patchValue({
            supportingDocs: this.selectedFiles
        });
        this.tpPdcManageService.saveAttendance(this.uploadForm.value).subscribe(data => {
            this.displayAddPdc = false;
            this.displayCourse = false;
            this.displayDataEntry = false;
            this.displayPreviewPdc = false;
            this.initUploadForm();
            this.loadTpCourse();
            this.loadPdcList();
        });
    }

    loadName(row: AbstractControl, index: any) {
        var licenceNo = row.get("licenceNo").value,
            validLicenceNo = true;;
        if (licenceNo) {
            for (var i in this.uploadForm.get('tgCourseAttendanceDetails').value) {
                if (index != i && this.uploadForm.get('tgCourseAttendanceDetails').get(i).get('licenceNo').value == licenceNo) {
                    validLicenceNo = false;
                }
            }

            if (validLicenceNo) {
                this.tpPdcManageService.loadName(licenceNo).subscribe(data => {
                    row.get("name").setValue(data);
                });
            } else {
                row.get('licenceNo').setErrors({ 'sameRecord': true });
            }
        }

    }
}