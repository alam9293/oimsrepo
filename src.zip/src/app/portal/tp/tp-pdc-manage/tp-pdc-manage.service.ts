import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TpPDCManageService {

    constructor(private http: HttpClient) { }

    public getListOfCourse(attendedDate: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/view/listOfCourse/' + attendedDate);
    }

    public getListOfCourseDetails(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/view', { params: searchDto });
    }

    public saveAttendance(courseAttendanceDetail: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(courseAttendanceDetail)],
            { type: 'application/json' }
        ));

        return this.http.post<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/save', formData);
    }

    public updateCourseAttendanceDetails(courseAttendanceDetail: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(courseAttendanceDetail)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_PDC + '/update', formData);
    }

    public loadName(licenceNo: string): Observable<any> {
        return this.http.get(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_MRC + '/view/name/' + licenceNo, { responseType: 'text' });
    }
}