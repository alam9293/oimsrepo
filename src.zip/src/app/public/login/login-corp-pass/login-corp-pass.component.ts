import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-login-corp-pass',
    templateUrl: './login-corp-pass.component.html',
    styleUrls: ['./login-corp-pass.component.scss']
})
export class LoginCorpPassComponent implements OnInit {
    successLink: String;

    constructor(private route: ActivatedRoute) { }

    ngOnInit() {
        this.successLink = this.route.snapshot.paramMap.get('successLink');


    }

    onLogin() {
        localStorage.setItem('isLoggedinPortal', 'true');
    }
}
