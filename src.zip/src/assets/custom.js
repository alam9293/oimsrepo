
function change(element) {
    var style = element.style;
    style.color = colorGreen;
    style.backgroundColor = colorWhiteBut;
}