export const environment = {
    production: true,
    apiAppUrl: 'https://trust.stb.gov.sg/webservice-public/api/v1',
    apexAppUrl: 'https://trust.stb.gov.sg/webservice-public/apex/v1', // use APEX
    //apexAppUrl: 'https://trust.stb.gov.sg/webservice-admin/api/v1', // skip APEX
    eNetsUrl: 'https://www2.enets.sg/GW2/TxnReqListenerToHost',
    eNetsReturnUrl: 'https://trust.stb.gov.sg/public/portal/',
    webPortalUrl: 'https://trust.stb.gov.sg',
    googleAnalyticId: 'UA-146763563-4',
    googleAnalyticTagManagerId: 'GTM-N5SX9KJ',
    iamsUrl: 'https://sso.stb.gov.sg/oxauth/restv1/authorize?scope=openid%20profile%20email%20user_name${UEN_SCOPE}' + '&response_type=code' + '&client_id=${CLIENT_ID}' + '&acr_values=${ACR_VALUE}' + '&redirect_uri=https%3A%2F%2Ftrust.stb.gov.sg%2Fpublic%2Fportal%2F${LOGIN_TYPE}',
    iamsClientId: '0ca4efd3-3e0b-4588-a6c3-0efce044f76a',
    testingIamsUrl: 'https://sso.stb.gov.sg/oxauth/restv1/authorize?scope=openid%20profile%20email%20user_name${UEN_SCOPE}' + '&response_type=code' + '&client_id=${CLIENT_ID}' + '&acr_values=${ACR_VALUE}' + '&redirect_uri=http%3A%2F%2Ftrust.stb.gov.sg%2Fpublic%2Fportal%2F${LOGIN_TYPE}',
    iamsLogoutUrl: 'https://sso.stb.gov.sg/oxauth/restv1/end_session?id_token_hint=${IAMS_ID_TOKEN}&post_logout_redirect_uri=https%3A%2F%2Ftrust.stb.gov.sg'
};
