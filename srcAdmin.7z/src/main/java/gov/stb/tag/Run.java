package gov.stb.tag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication(scanBasePackages = { "com.wiz", "gov.stb.tag" })
@EnableCaching
public class Run extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(Run.class, args);
	}
}
