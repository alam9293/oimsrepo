package gov.stb.tag.controllers;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.wiz.model.api.AuditableEntity;
import com.wiz.model.api.Listable;
import com.wiz.security.CustomAuthenticationToken;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.AssignDto;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ErrorDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.TypeDto;
import gov.stb.tag.exception.UnavailableException;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.VersionCheckRepository;
import gov.stb.tag.util.EncryptionUtil;

public class BaseController {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	protected static final String ACTION_RFA = "rfa";
	protected static final String ACTION_APPROVE = "approve";
	protected static final String ACTION_REJECT = "reject";
	protected static final String ACTION_ROUTE = "route";
	protected static final String ACTION_SUBMIT = "submit";
	protected static final String ACTION_SAVE = "save";
	protected static final String ACTION_EDIT = "edit";
	protected static final String ACTION_EMAIL = "email";
	protected static final String ACTION_FOLLOW_UP = "follow-up";

	protected static final String DASHBOARD_MY = "my";
	protected static final String DASHBOARD_DEPT = "dept";

	@Autowired
	protected CacheHelper cache;
	@Autowired
	protected Properties properties;
	@Autowired
	protected VersionCheckRepository versionCheckRepository;
	@Autowired
	protected CommonRepository commonRepository;
	@Autowired
	protected UserRepository userRepository;
	@Autowired
	protected ApplicationHelper appHelper;
	@Autowired
	protected WorkflowHelper workflowHelper;

	/**
	 * Gets the cached user record of the user making the request, along with the granted Roles
	 * 
	 * @return AuthenticatedUserDTO
	 */
	protected User getUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = (User) authentication.getPrincipal();

		return user;
	}

	/**
	 * Get the current selected role code for the user making the request
	 * 
	 * @return
	 */
	protected String getSelectedRoleCode() {
		CustomAuthenticationToken authentication = (CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
		return authentication.getRoleCode();
	}

	/**
	 * Get iams id token for /end_session (only for public login)
	 * 
	 * @return
	 */
	protected String getIamsIdToken() {
		CustomAuthenticationToken authentication = (CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
		return authentication.getIamsIdToken();
	}

	/**
	 * Get sp id token for /myinfo api retrieval (only for SP login)
	 * 
	 * @return
	 */
	protected String getSpIdToken() {
		CustomAuthenticationToken authentication = (CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
		return authentication.getSpIdToken();
	}

	/**
	 * Inauthenticate user upon logout so that the previous token will become invalid
	 * 
	 * 
	 */
	protected void setInAuthenticated() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		authentication.setAuthenticated(false);
	}

	/**
	 * Handles {@link UnavailableException}s thrown by the application business logic to prompt for retry
	 */
	@ExceptionHandler(UnavailableException.class)
	@ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
	public ErrorDto handleAppException(UnavailableException e) {
		logger.error("service unavailable", e);
		return new ErrorDto(HttpStatus.SERVICE_UNAVAILABLE.value(), e.getMessage());
	}

	/**
	 * Handles {@link ValidationException}s thrown by the application business logic to prompt for error display
	 */
	@ExceptionHandler(ValidationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDto handleAppException(ValidationException e) {
		logger.error("bad request", e);
		return new ErrorDto(HttpStatus.BAD_REQUEST.value(), e.getMessage());
	}

	/**
	 * Handles {@link MethodArgumentNotValidException}s thrown by DTO validation in POST method's RequestBody
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDto handleAppException(MethodArgumentNotValidException e) {
		logger.error(e.getMessage(), e);
		return handleSpringValidationException(e.getBindingResult());
	}

	/**
	 * Handles {@link BindException}s thrown by DTO validation in GET method
	 */
	@ExceptionHandler(BindException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDto handleAppException(BindException e) {
		logger.error(e.getMessage(), e);
		return handleSpringValidationException(e.getBindingResult());
	}

	/**
	 * Handles {@link OptimisticLockingFailureException}s thrown when more than one transaction is updating a particular record
	 */
	@ExceptionHandler({ OptimisticLockingFailureException.class })
	@ResponseStatus(HttpStatus.CONFLICT)
	public ErrorDto handleAppException(OptimisticLockingFailureException e) {
		logger.error("conflict", e);
		return new ErrorDto(HttpStatus.CONFLICT.value(), Messages.Errors.VERSION_CHECK_MISMATCH);
	}

	/**
	 * Handles {@link InsufficientAuthenticationException}s thrown by the UserController, if any (usually handled by Spring Security instead of controller)
	 */
	@ExceptionHandler(InsufficientAuthenticationException.class)
	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	public ErrorDto handleAppException(InsufficientAuthenticationException e) {
		logger.error("unauthorized", e);
		return new ErrorDto(HttpStatus.UNAUTHORIZED.value(), e.getMessage());
	}

	/**
	 * Handle all generic exceptions
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ErrorDto handleAppException(Exception e) {
		long errTs = new Date().getTime();
		logger.error(e.getMessage() + ". ref: " + errTs, e);
		StringBuilder stringBuilder = new StringBuilder();
		if (properties.showDebugMessage) {
			stringBuilder.append("<b>");
			stringBuilder.append("boo");
			stringBuilder.append("</b><br>");
			stringBuilder.append(e.getClass().getName() + ": " + e.getLocalizedMessage());
			for (int i = 0; i < e.getStackTrace().length; i++) {
				stringBuilder.append("<br>");
				stringBuilder.append(e.getStackTrace()[i]);
			}
		} else {
			stringBuilder.append("System Error Occurred. Please quote reference number " + errTs
					+ " with a screen shot and contact administrator at 6736 6622 or email at STB_TA@STB.GOV.SG (TA) or STB_TOURIST_GUIDE@STB.GOV.SG (TG). Operating hours are 8.00am to 8.00pm, Monday to Friday excluding Public holidays and weekends.");
		}
		return new ErrorDto(HttpStatus.INTERNAL_SERVER_ERROR.value(), stringBuilder.toString());
	}

	private ErrorDto handleSpringValidationException(BindingResult bindingResult) {
		StringBuilder errorMessage = new StringBuilder();
		for (ObjectError error : bindingResult.getAllErrors()) {
			errorMessage.append("&bull; ");
			errorMessage.append(error.getDefaultMessage());
			errorMessage.append("<br>");
		}
		if (errorMessage.length() > 0) {
			return new ErrorDto(HttpStatus.BAD_REQUEST.value(), errorMessage.substring(0, errorMessage.length() - 4));
		} else {
			return new ErrorDto(HttpStatus.BAD_REQUEST.value(), "");
		}
	}

	protected void validateFileDeleteStatus(File file, String messageFailed) {
		if (!file.delete()) {
			throw new ValidationException(messageFailed);
		}
	}

	protected <T extends Listable> List<ListableDto> toListableDtos(List<T> listables) {
		List<ListableDto> listableDtos = Lists.newArrayList();
		listables.forEach(o -> listableDtos.add(new ListableDto(o.getKey(), o.getLabel())));
		return listableDtos;
	}

	protected List<ListableDto> allFieldsToListableDtos(List<Type> types) {
		List<ListableDto> listableDtos = Lists.newArrayList();
		types.forEach(o -> listableDtos.add(new ListableDto(o)));
		return listableDtos;
	}

	protected <T extends Listable> List<ListableDto> toListableDtos(Set<T> listables) {
		List<ListableDto> listableDtos = Lists.newArrayList();
		listables.forEach(o -> listableDtos.add(new ListableDto(o.getKey(), o.getLabel())));
		return listableDtos;
	}

	protected <T extends Listable> List<ListableDto> toListableDtos(List<T> listables, Boolean includeOtherLabel) {
		List<ListableDto> listableDtos = Lists.newArrayList();
		listables.forEach(o -> listableDtos.add(new ListableDto(o.getKey(), o.getLabel(), o.getOtherLabel())));
		return listableDtos;
	}

	protected <T extends Listable> List<ListableDto> toListableDtos(Map<?, String> map) {
		List<ListableDto> listableDtos = Lists.newArrayList();
		map.entrySet().forEach(o -> listableDtos.add(new ListableDto((Serializable) o.getKey(), o.getValue())));
		return listableDtos;
	}

	protected List<TypeDto> toTypeDtos(List<Type> types) {
		List<TypeDto> typeDtos = Lists.newArrayList();
		types.forEach(o -> typeDtos.add(new TypeDto(o.getCategory().getCode(), o.getCode(), o.getLabel(), o.getOrdinal(), o.isActive())));
		return typeDtos;
	}

	protected TypeDto toTypeDto(SystemParameter sysParam) {
		return new TypeDto(null, sysParam.getCode(), sysParam.getValue(), sysParam.getOrdinal(), null);
	}

	/**
	 * Adds the "Version-Check" header for frontend to encrypt and cache the entityIds & versions of entities which are affected by possible updates later. Use this method if your entityDto is built
	 * using the AuditableEntity itself.
	 */
	protected <T> ResponseEntity<T> addVersionCheck(T respBody, AuditableEntity... entities) {
		if (entities.length > 0) {
			StringBuilder values = new StringBuilder();
			for (AuditableEntity entity : entities) {
				values.append(",");
				values.append(entity.getClass().getSimpleName());
				values.append(",");
				try {
					values.append(EncryptionUtil.encrypt(versionCheckRepository.getEntityId(entity).toString() + "," + entity.getVersion().toString())); // Base64 will not have ","
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
			values.deleteCharAt(0);
			return ResponseEntity.status(HttpStatus.OK).header(Codes.Headers.VERSION_CHECK, values.toString()).body(respBody);
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(respBody);
		}
	}

	/**
	 * Adds the "Version-Check" header for frontend to encrypt and cache the entityIds & versions of entities which are affected by possible updates later. Use this method if your entityDto is built
	 * using @MapProjection (i.e. AuditableEntity object not returned). Note that the getVersion(), getEntityName() and getEntityId() functions in the EntityDto must not return null.
	 */
	protected <T, E extends EntityDto> ResponseEntity<T> addVersionCheck(T respBody, E... entities) {
		if (entities.length > 0) {
			StringBuilder values = new StringBuilder();
			for (E entity : entities) {
				values.append(",");
				values.append(entity.getEntityName());
				values.append(",");
				try {
					values.append(EncryptionUtil.encrypt(versionCheckRepository.getEntityId(entity).toString() + "," + entity.getVersion().toString())); // Base64 will not have ","
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
			values.deleteCharAt(0);
			return ResponseEntity.status(HttpStatus.OK).header(Codes.Headers.VERSION_CHECK, values.toString()).body(respBody);
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(respBody);
		}
	}

	/**
	 * Adds the "Version-Check" header for frontend to encrypt and cache the entityIds & versions of entities which are affected by possible updates later. Use this method for batch update in a
	 * listing page. Note that the getVersion(), getEntityName() and getEntityId() functions in the EntityDto must not return null.
	 */
	protected <T, E extends EntityDto> ResponseEntity<T> addVersionCheckForListing(T respBody, List<E> entityDtos) {
		if (!entityDtos.isEmpty()) {
			E dto = entityDtos.get(0);
			if (Strings.isNullOrEmpty(dto.getEntityName())) {
				throw new RuntimeException(Messages.Errors.VERSION_CHECK_MISSING_VALUES);
			}
			StringBuilder entityIds = new StringBuilder();
			StringBuilder versions = new StringBuilder();
			for (E entityDto : entityDtos) {
				if (Strings.isNullOrEmpty(entityDto.getEntityId()) || entityDto.getVersion() == null) {
					throw new RuntimeException(Messages.Errors.VERSION_CHECK_MISSING_VALUES);
				}
				entityIds.append("|").append(entityDto.getEntityId());
				versions.append("|").append(entityDto.getVersion());
			}
			entityIds.deleteCharAt(0);
			versions.deleteCharAt(0);
			String values;
			try {
				values = dto.getEntityName() + "," + EncryptionUtil.encrypt(entityIds + "," + versions);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
			return ResponseEntity.status(HttpStatus.OK).header(Codes.Headers.VERSION_CHECK_LISTING, values.toString()).body(respBody);
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(respBody);
		}
	}

	/**
	 * Decrypt and parse the specified "Version-Check" header value back to the entityNames, entityIds, and versions. Retrieve from the DB the current versions of these entities to check if they have
	 * been modified before. If yes, throws a OptimisticLockingFailureException for BaseController to return as HTTP 409 Conflict.
	 */
	protected void runVersionCheck(String headerValue) {
		if (!Strings.isNullOrEmpty(headerValue)) {
			logger.debug("Version-Check header found. Validating versions received with current versions...");
			String[] values = headerValue.split(",");
			if (values.length % 2 != 0) {
				throw new ValidationException(Messages.Errors.VERSION_CHECK_INCORRECT_NO_OF_VALUES);
			} else {
				for (int i = 0; i < values.length; i++) {
					// split & decrypt header values
					String entityName = values[i].trim();
					String[] entityIdVersion;
					try {
						entityIdVersion = EncryptionUtil.decrypt(values[++i].trim()).split(",");
					} catch (Exception e) {
						logger.error(e.getMessage());
						throw new ValidationException(Messages.Errors.VERSION_CHECK_DECRYPTION_FAIL);
					}
					String entityId = entityIdVersion[0];
					String version = entityIdVersion[1];

					// validate mandatory header values
					if (Strings.isNullOrEmpty(entityName) || Strings.isNullOrEmpty(entityId) || Strings.isNullOrEmpty(version)) {
						throw new ValidationException(Messages.Errors.VERSION_CHECK_MISSING_VALUES);
					}

					// get current version and check with received version
					doVersionCheck(entityName, version, versionCheckRepository.getCurrentVersion(entityName, entityId));
				}
			}
			logger.debug("Version Check successful.");
		}
	}

	/**
	 * Decrypt and parse the specified "Version-Check-Listing" header value back to the entityName, entityIds, and versions. Retrieve from the DB the current versions of these entities to check if
	 * they have been modified before. If yes, throws a OptimisticLockingFailureException for BaseController to return as HTTP 409 Conflict.
	 */
	protected void runVersionCheckForListing(String headerValue, List<String> selectedEntityIds) {
		if (!Strings.isNullOrEmpty(headerValue)) {
			logger.debug("Version-Check-Listing header found. Validating versions received with current versions...");
			String[] values = headerValue.split(",");
			if (values.length % 2 != 0) {
				throw new ValidationException(Messages.Errors.VERSION_CHECK_INCORRECT_NO_OF_VALUES);
			} else {
				// split & decrypt header values
				String entityName = values[0].trim();
				String[] entityIdsVersions;
				try {
					entityIdsVersions = EncryptionUtil.decrypt(values[1].trim()).split(",");
				} catch (Exception e) {
					logger.error(e.getMessage());
					throw new ValidationException(Messages.Errors.VERSION_CHECK_DECRYPTION_FAIL);
				}

				// remove away the unselected entityIds
				List<String> entityIds = new ArrayList<>(Arrays.asList(entityIdsVersions[0].split("\\|")));
				List<String> versions = new ArrayList<>(Arrays.asList(entityIdsVersions[1].split("\\|")));
				if (entityIds.size() != versions.size()) {
					throw new ValidationException(Messages.Errors.VERSION_CHECK_INCORRECT_NO_OF_VALUES);
				}
				if (selectedEntityIds != null) {
					for (int i = entityIds.size() - 1; i >= 0; i--) {
						if (!selectedEntityIds.contains(entityIds.get(i))) {
							entityIds.remove(i);
							versions.remove(i);
						}
					}
				}

				// validate mandatory header values
				if (Strings.isNullOrEmpty(entityName)) {
					throw new ValidationException(Messages.Errors.VERSION_CHECK_MISSING_VALUES);
				}
				for (int i = 0; i < entityIds.size(); i++) {
					if (Strings.isNullOrEmpty(entityIds.get(i)) || Strings.isNullOrEmpty(versions.get(i))) {
						throw new ValidationException(Messages.Errors.VERSION_CHECK_MISSING_VALUES);
					}
				}

				// get current versions and check with received versions
				Map<String, String> currentVersions = versionCheckRepository.getCurrentVersions(entityName, entityIds);
				for (int i = 0; i < entityIds.size(); i++) {
					String currentVersion = currentVersions.get(entityIds.get(i));
					doVersionCheck(entityName, versions.get(i), currentVersion);
					logger.debug(entityIds.get(i) + " " + versions.get(i) + " " + currentVersion);
				}
			}
			logger.debug("Version Check successful.");
		}
	}

	private void doVersionCheck(String entityName, String version, String currentVersion) {
		if (Strings.isNullOrEmpty(currentVersion)) {
			throw new ValidationException(String.format(Messages.Errors.VERSION_CHECK_NOT_FOUND, entityName));
		} else if (!version.equals(currentVersion)) {
			throw new OptimisticLockingFailureException(Messages.Errors.VERSION_CHECK_MISMATCH);
		}
	}

	/**
	 * Convenient method to convert a list of integer to a list of strings
	 */
	protected List<String> toStrings(List<Integer> ids) {
		return ids.stream().map(id -> id.toString()).collect(Collectors.toList());
	}

	/*
	 * Reassign Application(s) to other Officer
	 */
	protected void reAssignApplication(AssignDto dto) {
		List<Application> applications = commonRepository.getApplicationsByIds(dto.getApplicationIds());
		for (Application app : applications) {
			appHelper.reAssign(app, userRepository.getUserWithRolesById(dto.getReAssignedOfficerId()), dto.getInternalRemarks());
		}
		// applications.forEach(u -> appHelper.reAssign(u, userRepository.getUserWithRolesById(dto.getReAssignedOfficerId()), dto.getInternalRemarks()));
		// commonRepository.saveOrUpdate(applications);

	}

	/*
	 * Reassign Workflow(s) to other Officer
	 */
	protected void reAssignWorkflow(AssignDto dto) {
		List<Workflow> workflows = commonRepository.getWorkflowsByIds(dto.getWorkflowIds());
		for (Workflow workflow : workflows) {
			workflowHelper.reAssign(workflow, userRepository.getUserWithRolesById(dto.getReAssignedOfficerId()), dto.getInternalRemarks());
		}
	}
}
