package gov.stb.tag.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;

@ControllerAdvice

@Order(10000)

public class BinderControllerAdvice {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@InitBinder
	public void setAllowedFields(WebDataBinder dataBinder) {

		String[] denylist = new String[] { "class.*", "Class.*", "*.class.*", "*.Class.*" };
		logger.info("BinderControllerAdvice class.*, *.Class.*");

		dataBinder.setDisallowedFields(denylist);

	}

}