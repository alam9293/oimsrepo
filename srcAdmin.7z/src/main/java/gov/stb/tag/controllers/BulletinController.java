package gov.stb.tag.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.bulletin.AllBulletinListDto;
import gov.stb.tag.dto.bulletin.BulletinCatgoryListingDto;
import gov.stb.tag.dto.bulletin.BulletinItemDto;
import gov.stb.tag.dto.bulletin.BulletinSearchDto;
import gov.stb.tag.dto.bulletin.FileDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Bulletin;
import gov.stb.tag.model.CategoryListing;
import gov.stb.tag.model.File;
import gov.stb.tag.repository.BulletinRepository;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.util.FileUtil;

@RestController
@RequestMapping(path = "/api/v1/bulletin")
@Transactional
public class BulletinController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private BulletinRepository bulletinRepository;

	@Autowired
	private FileRepository fileRepository;

	@Autowired
	FileHelper fileHelper;

	@RequestMapping(value = "/public/bulletin", method = RequestMethod.GET)
	public List<BulletinCatgoryListingDto> getAllBulletins() {

		List<BulletinCatgoryListingDto> allList = new ArrayList<BulletinCatgoryListingDto>();

		List<Bulletin> allBulletins = bulletinRepository.getAllPublicBulletins();
		if (allBulletins.size() > 0) {
			for (Bulletin bulletin : allBulletins) {
				BulletinCatgoryListingDto dto = BulletinCatgoryListingDto.buildFromBulletin(cache, bulletin);
				allList.add(dto);
			}
		}
		// Add InfoHub
		List<CategoryListing> allCategoryListing = bulletinRepository.getAllInfoHubListings();
		if (allCategoryListing.size() > 0) {
			for (CategoryListing listings : allCategoryListing) {
				BulletinCatgoryListingDto dto = BulletinCatgoryListingDto.buildFromBulletin(cache, listings);
				allList.add(dto);
			}
		}

		Collections.sort(allList, new Comparator<BulletinCatgoryListingDto>() {
			@Override
			public int compare(BulletinCatgoryListingDto m2, BulletinCatgoryListingDto m1) {
				return m1.getUpdatedDate().compareTo(m2.getUpdatedDate());
			}
		});

		return allList;
	}

	@RequestMapping(value = "/public/bulletin-board", method = RequestMethod.GET)
	public ResultDto<BulletinItemDto> getAllBulletinsByType(BulletinSearchDto searchDto) throws IOException {
		return bulletinRepository.getBulletinsByType(searchDto);
	}

	@RequestMapping(value = "/public/bulletin-board-news", method = RequestMethod.GET)
	public BulletinItemDto getBulletinDetails(@RequestParam(value = "id", required = false) Integer id) throws IOException {
		return populateDetail(id, true);
	}

	@RequestMapping(path = { "/list/{type}", "/list/{type}/{isPrivate}" }, method = RequestMethod.GET)
	public List<BulletinItemDto> getBulletins(@PathVariable String type, @PathVariable Optional<Boolean> isPrivate) {
		Boolean isPrivate2 = null;
		if (isPrivate.isPresent()) {
			isPrivate2 = isPrivate.get();
		}

		List<BulletinItemDto> allList = new ArrayList<BulletinItemDto>();
		List<Bulletin> allBulletins = bulletinRepository.getAllBulletins(type, isPrivate2);
		if (allBulletins.size() > 0) {
			for (Bulletin bulletin : allBulletins) {
				allList.add(BulletinItemDto.buildFromBulletin(cache, bulletin));
			}
		}

		return allList;
	}

	@RequestMapping(path = { "/view/{bulletinId}", "/load/{bulletinId}" }, method = RequestMethod.GET)
	public BulletinItemDto getBulletinDetail(@PathVariable Integer bulletinId) {
		return populateDetail(bulletinId, false);
	}

	private BulletinItemDto populateDetail(Integer id, boolean fromAEM) {
		Bulletin bulletin = bulletinRepository.getDetailsById(id, fromAEM);

		BulletinItemDto dto = BulletinItemDto.buildFromBulletin(cache, bulletin);
		List<FileDto> files = new ArrayList<>();

		if (!bulletin.getFiles().isEmpty()) {
			for (File file : bulletin.getFiles()) {
				FileDto fileDto = new FileDto();

				try {
					fileDto.setOriginalName(file.getOriginalFilename());
					fileDto.setExtension(file.getExtension());
					fileDto.setHash(file.getHash());
					fileDto.setSize(file.getSize());
					fileDto.setReadableFileSize(FileUtil.readableFileSize(file.getSize()));
					fileDto.setFileId(file.getPublicFileId());
					fileDto.setId(file.getId());

					files.add(fileDto);
				} catch (Exception e) {
					logger.error("Invalid bulletin attachment, bulletinId : {}; fileId: {}", bulletin.getId(), file.getId());
				}
			}
			dto.setFiles(files);
		}

		return dto;
	}

	@RequestMapping(path = { "/list-all/{type}" }, method = RequestMethod.GET)
	public ResultDto<BulletinItemDto> getAllBulletinsList(@PathVariable String type, BulletinSearchDto searchDto) {

		return bulletinRepository.getAllBulletinsList(type, searchDto);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveBulletin(@RequestPart(name = "dto") BulletinItemDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {
		Bulletin bulletin = new Bulletin();
		if (!Strings.isNullOrEmpty(dto.getContent())) {
			String content = dto.getContent().replace("<table>", "<table style=\"border: 1px solid black\">");
			content = content.replace("<table", "<table style=\"overflow-wrap: break-word\"");
			content = content.replace("<tr>", "<tr style=\"border: 1px solid black\">");
			content = content.replace("<td>", "<td style=\"border: 1px solid black\">");
			content = content.replace("“", "\"");
			content = content.replace("”", "\"");
			content = content.replace("–", "-");
			dto.setContent(content);
		}

		if (dto.getId() != null) {
			bulletin = bulletinRepository.getDetailsById(dto.getId(), false);
			bulletin = buildBulletin(dto, bulletin);
		} else {
			bulletin = buildBulletin(dto, bulletin);
			bulletinRepository.save(bulletin);
		}

		Set<File> files = new HashSet<>();
		// save file
		for (FileDto doc : dto.getFiles()) {
			File file = new File();
			if (doc.getId() != null) {
				file = fileHelper.getFile(doc.getId());
				file.setTransferStatus(cache.getStatus(Codes.Statuses.TXF_TO_PUB_PENDING));
				fileRepository.update(file);
			}
			files.add(file);
			bulletin.setFiles(files);
			bulletinRepository.update(bulletin);
		}

		// delete file
		if (deletedFiles != null) {
			for (Integer fileId : deletedFiles) {
				File file = fileHelper.getFile(fileId);
				if (file != null) {
					fileHelper.deleteFile(file);
					logger.info("[{}] saveBulletin(), file.id={} deleted for bulletin.id={}", getUser().getLoginId(), fileId, bulletin.getId());
				}
			}
		}
		return bulletin.getId();
	}

	public Bulletin buildBulletin(BulletinItemDto dto, Bulletin bulletin) {
		bulletin.setType(cache.getType(dto.getTypeCode()));
		bulletin.setPrivate(dto.getIsPrivate());
		bulletin.setTitle(dto.getTitle());
		bulletin.setContent(dto.getContent());
		bulletin.setEffectiveDate(dto.getEffectiveDate());
		bulletin.setExpiryDate(dto.getExpiryDate());
		return bulletin;
	}

	@RequestMapping(value = "/public/Allbulletins", method = RequestMethod.GET)
	public AllBulletinListDto getBulletinsAll() {

		List<BulletinCatgoryListingDto> bulletinBeanList = new ArrayList<>();
		List<BulletinCatgoryListingDto> recentPosts = new ArrayList<>();
		List<BulletinCatgoryListingDto> generalBulletins = new ArrayList<>();
		List<BulletinCatgoryListingDto> taBulletins = new ArrayList<>();
		List<BulletinCatgoryListingDto> tgBulletins = new ArrayList<>();

		AllBulletinListDto allBulletinListDto = new AllBulletinListDto();

		List<Bulletin> allBulletins = bulletinRepository.getAllPublicBulletins();
		if (allBulletins.size() > 0) {
			for (Bulletin bulletin : allBulletins) {
				BulletinCatgoryListingDto dto = BulletinCatgoryListingDto.buildFromBulletin(cache, bulletin);
				bulletinBeanList.add(dto);
			}
		}
		// Add InfoHub
		List<CategoryListing> allCategoryListing = bulletinRepository.getAllInfoHubListings();
		if (allCategoryListing.size() > 0) {
			for (CategoryListing listings : allCategoryListing) {
				BulletinCatgoryListingDto dto = BulletinCatgoryListingDto.buildFromBulletin(cache, listings);
				bulletinBeanList.add(dto);
			}
		}

		Collections.sort(bulletinBeanList, new Comparator<BulletinCatgoryListingDto>() {
			@Override
			public int compare(BulletinCatgoryListingDto m2, BulletinCatgoryListingDto m1) {
				return m1.getUpdatedDate().compareTo(m2.getUpdatedDate());
			}
		});

		recentPosts = bulletinBeanList.stream().limit(4).collect(Collectors.toList());
		logger.info("bulletin list size  : {}" + bulletinBeanList.size());
		for (BulletinCatgoryListingDto bb : bulletinBeanList) {

			// for General Bulletin
			if (bb.getTypeCode().indexOf(Codes.Constants.BULLETIN_GENERAL) > 0) {
				generalBulletins.add(bb);
			}

			// for TA Bulletin
			if (bb.getTypeCode().indexOf(Codes.Constants.BULLETIN_TA) > 0) {
				taBulletins.add(bb);
			}

			// for TG Bulletin
			if (bb.getTypeCode().indexOf(Codes.Constants.BULLETIN_TG) > 0) {
				tgBulletins.add(bb);
			}

		}
		logger.info("general bulletin list size : {}", generalBulletins.size());
		logger.info("ta bulletin list size : {}", taBulletins.size());
		logger.info("tg bulletin list size : {}", tgBulletins.size());

		allBulletinListDto.setGeneralBulletins(generalBulletins);
		allBulletinListDto.setRecentPosts(recentPosts);
		allBulletinListDto.setTaBulletins(taBulletins);
		allBulletinListDto.setTgBulletins(tgBulletins);

		return allBulletinListDto;
	}

}
