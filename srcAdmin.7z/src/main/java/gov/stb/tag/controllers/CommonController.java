package gov.stb.tag.controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.constant.Codes.CE_TA_FIELD_REPORT_CLASS;
import gov.stb.tag.constant.Codes.SystemParameters;
import gov.stb.tag.dto.CeProvisionReadWithDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.TgCourseSubsidyDto;
import gov.stb.tag.dto.TypeDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.dto.tg.trainingprovider.TrainingProviderDto;
import gov.stb.tag.helper.CpfHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.TgCourseHelper;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.WorkflowStepAssignment;
import gov.stb.tag.repository.CeProvisionRepository;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.WorkflowRepository;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.tg.TgTrainingProviderRepository;

@RestController
@RequestMapping(path = "/api/v1/common")
@Transactional
public class CommonController extends BaseController {

	@Autowired
	CommonRepository commonRepository;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	TgTrainingProviderRepository tpRepository;
	@Autowired
	CpfHelper cpfHelper;
	@Autowired
	CeProvisionRepository ceProvisionRepository;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	TgCourseHelper tgCourseHelper;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	WorkflowRepository workflowRepository;

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@RequestMapping(path = "/address-types", method = RequestMethod.GET)
	public List<ListableDto> getAddressTypes() {
		return toListableDtos(cache.getAddressTypes());
	}

	@RequestMapping(path = "/countries", method = RequestMethod.GET)
	public List<ListableDto> getCountries() {
		return toListableDtos(cache.getCountries());
	}

	@RequestMapping(path = "/marital-statuses", method = RequestMethod.GET)
	public List<ListableDto> getMaritalStatuses() {
		return toListableDtos(cache.getMaritalStatuses());
	}

	@RequestMapping(path = "/nationalities", method = RequestMethod.GET)
	public List<ListableDto> getNationalities() {
		return toListableDtos(cache.getNationalities());
	}

	@RequestMapping(path = "/payment-types", method = RequestMethod.GET)
	public List<ListableDto> getPaymentTypes() {
		return toListableDtos(cache.getPaymentTypes());
	}

	@RequestMapping(path = "/payment-request-types", method = RequestMethod.GET)
	public List<ListableDto> getPaymentRequestTypes() {
		return toListableDtos(cache.getPaymentRequestTypes());
	}

	@RequestMapping(path = "/premise-types", method = RequestMethod.GET)
	public List<ListableDto> getPremiseTypes() {
		return toListableDtos(cache.getPremiseTypes());
	}

	@RequestMapping(path = "/races", method = RequestMethod.GET)
	public List<ListableDto> getRaces() {
		return toListableDtos(cache.getRaces());
	}

	@RequestMapping(path = "/qualifications", method = RequestMethod.GET)
	public List<ListableDto> getQualifications() {
		return toListableDtos(cache.getQualifications());
	}

	@RequestMapping(path = "/occupations", method = RequestMethod.GET)
	public List<ListableDto> getOccupations() {
		return toListableDtos(cache.getOccupations());
	}

	@RequestMapping(path = "/form-of-business", method = RequestMethod.GET)
	public List<ListableDto> getFormOfBusiness() {
		List<ListableDto> listableDtos = Lists.newArrayList();
		cache.getFormOfBusiness().forEach(o -> listableDtos.add(new ListableDto(o.getKey(), o.getLabel(), null, o.getMappingCode(), null)));
		return listableDtos;
	}

	@RequestMapping(path = "/principle-activities", method = RequestMethod.GET)
	public List<ListableDto> getPrincipleActivities() {
		return toListableDtos(cache.getPrincipleActivities());
	}

	@RequestMapping(path = "/business-constitution", method = RequestMethod.GET)
	public List<ListableDto> getBusinessConstitution() {
		return toListableDtos(cache.getBusinessConstitution());
	}

	@RequestMapping(path = "/stakeholder-roles", method = RequestMethod.GET)
	public List<ListableDto> getStakeholderRoles() {
		return toListableDtos(cache.getStakeholderRoles());
	}

	@RequestMapping(path = "/residential-statuses", method = RequestMethod.GET)
	public List<ListableDto> getResidentialStatuses() {
		return toListableDtos(cache.getResidentialStatuses());
	}

	@RequestMapping(path = "/establishment-statuses", method = RequestMethod.GET)
	public List<ListableDto> getEstablishmentStatus() {
		List<ListableDto> listableDtos = toListableDtos(cache.getEstablishmentStatuses());
		listableDtos.forEach(o -> o.setData(toListableDtos(cache.getSubEstablishmentStatuses(o.getKey().toString()))));
		return listableDtos;
	}

	@RequestMapping(path = "/sexes", method = RequestMethod.GET)
	public List<ListableDto> getSexes() {
		return toListableDtos(cache.getSexes());
	}

	@RequestMapping(path = "/tg-tour-type", method = RequestMethod.GET)
	public List<ListableDto> getTgTourTypes() {
		return toListableDtos(cache.getTgTourTypes());
	}

	@RequestMapping(path = "/tg-emp-src-type", method = RequestMethod.GET)
	public List<ListableDto> getTgEmpSrcTypes() {
		return toListableDtos(cache.getTgEmpSrcTypes());
	}

	@RequestMapping(path = "/ta-application-types", method = RequestMethod.GET)
	public List<ListableDto> getTaApplicationTypes() {
		List<ListableDto> results = toListableDtos(cache.getTaApplicationTypes(), true);
		results.addAll(toListableDtos(cache.getTaKeApplicationTypes(), true));
		results.remove(results.stream().filter(r -> r.getKey().equals(Codes.ApplicationTypes.TA_APP_KE)).findAny().get());
		return results;
	}

	@RequestMapping(path = "/ta-approval-types", method = RequestMethod.GET)
	public List<ListableDto> getTaApprovalModes() {
		return toListableDtos(cache.getTaApprovalModes());
	}

	@RequestMapping(path = "/ta-focus-areas", method = RequestMethod.GET)
	public List<ListableDto> getTaFocusAreas() {
		return toListableDtos(cache.getTaFocusAreas());
	}

	@RequestMapping(path = "/ta-function-activities", method = RequestMethod.GET)
	public List<ListableDto> getTaFunctionActivity() {
		return toListableDtos(cache.getTaFunctionActivity());
	}

	@RequestMapping(path = "/ta-segmentations", method = RequestMethod.GET)
	public List<ListableDto> getTaSegmentations() {
		return toListableDtos(cache.getTaSegmentations());
	}

	@RequestMapping(path = "/ta-services", method = RequestMethod.GET)
	public List<ListableDto> getTaServices() {
		return toListableDtos(cache.getTaServices());
	}

	@RequestMapping(path = "/ta-licence-tiers", method = RequestMethod.GET)
	public List<ListableDto> getTaLicenceTiers() {
		return toListableDtos(cache.getTaLicenceTiers());
	}

	@RequestMapping(path = "/ta-auditor-opinions", method = RequestMethod.GET)
	public List<ListableDto> getAuditorOpinions() {
		return toListableDtos(cache.getTaAuditorOpinions());
	}

	@RequestMapping(path = "/flags", method = RequestMethod.GET)
	public List<ListableDto> getFlags() {
		return toListableDtos(cache.getFlags());
	}

	@RequestMapping(path = "/ta-reasons-for-cessation", method = RequestMethod.GET)
	public List<ListableDto> getTaReasonsForCessation() {
		return toListableDtos(cache.getTaReasonsForCessation());
	}

	@RequestMapping(path = "/ta-reasons-for-replacement", method = RequestMethod.GET)
	public List<ListableDto> getTaReasonsForReplacement() {
		return toListableDtos(cache.getTaReasonsForReplacement());
	}

	@RequestMapping(path = "/tg-application-types", method = RequestMethod.GET)
	public List<ListableDto> getTgApplicationTypes() {
		return toListableDtos(cache.getTgApplicationTypes());
	}

	@RequestMapping(path = "/tg-specialised-areas", method = RequestMethod.GET)
	public List<ListableDto> getTgSpecialisedAreas() {
		return toListableDtos(cache.getTgSpecialisedAreas());
	}

	@RequestMapping(path = "/tg-course-types", method = RequestMethod.GET)
	public List<ListableDto> getTgCourseTypes() {
		return toListableDtos(cache.getTgCourseTypes());
	}

	@RequestMapping(path = "/tg-document-types", method = RequestMethod.GET)
	public List<ListableDto> getTgDocumentTypes() {
		return toListableDtos(cache.getTgDocumentTypes());
	}

	@RequestMapping(path = "/tg-guiding-languages", method = RequestMethod.GET)
	public List<ListableDto> getTgGuidingLanguages() {
		return toListableDtos(cache.getTgGuidingLanguages());
	}

	@RequestMapping(path = "/tg-declared-offence-types", method = RequestMethod.GET)
	public List<ListableDto> getTgDeclaredOffenceTypes() {
		return toListableDtos(cache.getTgDeclaredOffenceTypes());
	}

	@RequestMapping(path = "/tg-licence-tiers", method = RequestMethod.GET)
	public List<ListableDto> getTgLicenceTiers() {
		return toListableDtos(cache.getTgLicenceTiers());
	}

	@RequestMapping(path = "/tg-course-category-types", method = RequestMethod.GET)
	public List<ListableDto> getTgCourseCategoryTypes() {
		return toListableDtos(cache.getTgCourseCategoryTypes());
	}

	@RequestMapping(path = "/tg-candidate-itineraries", method = RequestMethod.GET)
	public List<ListableDto> getTgCandidateItineraries() {
		return toListableDtos(cache.getTgCandidateItineraries());
	}

	@RequestMapping(path = "/tg-candidate-results", method = RequestMethod.GET)
	public List<ListableDto> getTgCandidateResults() {
		return toListableDtos(cache.getTgCandidateResults());
	}

	@RequestMapping(path = "/tg-mlpt-results", method = RequestMethod.GET)
	public List<ListableDto> getTgMlptResults() {
		return toListableDtos(cache.getTgMlptResults());
	}

	@RequestMapping(value = "/training-providers", method = RequestMethod.GET)
	public List<ListableDto> getTps() {
		return toListableDtos(tpRepository.getActiveTrainingProvider());
	}

	@RequestMapping(value = "/training-providers-pdc", method = RequestMethod.GET)
	public List<ListableDto> getTpsForPDC() {
		return toListableDtos(tpRepository.getActiveTrainingProviderForPDC());
	}

	@RequestMapping(path = "/tg-training-providers", method = RequestMethod.GET)
	public List<TrainingProviderDto> getTrainingProviders() {
		List<TgTrainingProvider> trainingProviders = tpRepository.getActiveTrainingProvider();
		List<TrainingProviderDto> trainingProviderDtos = new ArrayList<TrainingProviderDto>();
		for (TgTrainingProvider tp : trainingProviders) {
			trainingProviderDtos.add(new TrainingProviderDto(cache, tp));
		}
		return trainingProviderDtos;
	}

	@RequestMapping(path = "/tg-training-providers/ato", method = RequestMethod.GET)
	public List<TrainingProviderDto> getAtoTrainingProviders() {
		List<TgTrainingProvider> trainingProviders = tpRepository.getAtoTrainingProviders();
		List<TrainingProviderDto> trainingProviderDtos = new ArrayList<TrainingProviderDto>();
		for (TgTrainingProvider tp : trainingProviders) {
			trainingProviderDtos.add(new TrainingProviderDto(cache, tp));
		}
		return trainingProviderDtos;
	}

	@RequestMapping(path = "/payment-request-statuses", method = RequestMethod.GET)
	public List<ListableDto> getPaymentRequestStatuses() {
		return toListableDtos(cache.getPaymentRequestStatuses());
	}

	@RequestMapping(path = "/payment-txn-statuses", method = RequestMethod.GET)
	public List<ListableDto> getPaymentTxnStatuses() {
		return toListableDtos(cache.getPaymentTxnStatuses());
	}

	@RequestMapping(path = "/ta-application-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTaApplicationStatuses() {
		return toListableDtos(
				cache.getTaApplicationStatuses().stream().filter(o -> !o.getCode().equals(Codes.Statuses.TA_APP_DRAFT) && !o.getCode().equals(Codes.Statuses.TA_APP_NEW)).collect(Collectors.toList()),
				true);
	}

	@RequestMapping(path = "/postal-code/{postalCode}", method = RequestMethod.GET)
	public Object getPostalAddress(@PathVariable String postalCode) {
		final String uri = "https://developers.onemap.sg/commonapi/search?searchVal=" + postalCode + "&returnGeom=N&getAddrDetails=Y&pageNum=1%2024";
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.getForObject(uri, Object.class);
	}

	@RequestMapping(path = "/ta-licence-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTaLicenceStatuses() {
		return toListableDtos(cache.getTaLicenceStatuses());
	}

	@RequestMapping(path = "/ta-ke-app-type", method = RequestMethod.GET)
	public List<ListableDto> getTaKeAppType() {
		return toListableDtos(cache.getTaKeAppType());
	}

	@RequestMapping(path = "/tg-application-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTgApplicationStatuses() {
		return toListableDtos(cache.getTgApplicationStatuses());
	}

	@RequestMapping(path = "/tg-licence-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTgLicenceStatuses() {
		return toListableDtos(cache.getTgLicenceStatuses());
	}

	@RequestMapping(path = "/tg-course-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTgCourseStatuses() {
		return toListableDtos(cache.getTgCourseStatuses());
	}

	@RequestMapping(path = "/system-parameter/{code}", method = RequestMethod.GET)
	public ListableDto getSystemParameter(@PathVariable String code) {
		return new ListableDto(code, cache.getSystemParameter(code).getValue());
	}

	@RequestMapping(path = "/user-statuses", method = RequestMethod.GET)
	public List<ListableDto> getUserStatuses() {
		return toListableDtos(cache.getUserStatuses());
	}

	@RequestMapping(path = "/return-statuses", method = RequestMethod.GET)
	public List<ListableDto> getReturnStatuses() {
		return toListableDtos(cache.getReturnStatuses());
	}

	@RequestMapping(path = "/print-statuses", method = RequestMethod.GET)
	public List<ListableDto> getPrintStatuses() {
		return toListableDtos(cache.getPrintStatuses(), true);
	}

	@RequestMapping(path = "/ta-print-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTaPrintStatuses() {
		return toListableDtos(cache.getTaPrintStatuses(), true);
	}

	@RequestMapping(path = "/type-code-list", method = RequestMethod.GET)
	public List<ListableDto> getTypeCodeList() {
		return toListableDtos(cache.getTypeCodeList());
	}

	@RequestMapping(path = "/type-code-tatg-list", method = RequestMethod.GET)
	public List<ListableDto> getTypeCodeTaTgList() {
		List<Type> types = new ArrayList<Type>();

		types.add(commonRepository.getTypeCodeTaTgList(Codes.Types.BULLETIN_TA));
		types.add(commonRepository.getTypeCodeTaTgList(Codes.Types.BULLETIN_TG));
		types.add(commonRepository.getTypeCodeTaTgList(Codes.Types.BULLETIN_TA_TG));

		return toListableDtos(types);
	}

	// to populate all dropdown values
	@RequestMapping(path = "/form-dropdowns", method = RequestMethod.GET)
	public HashMap<String, List<ListableDto>> populateFormDropdowns() {
		HashMap<String, List<ListableDto>> dropdowns = new HashMap<>();
		dropdowns.put("country", toListableDtos(cache.getCountries()));
		dropdowns.put("marital", toListableDtos(cache.getMaritalStatuses()));
		dropdowns.put("nationality", toListableDtos(cache.getNationalities()));
		dropdowns.put("race", toListableDtos(cache.getRaces()));
		dropdowns.put("residential", toListableDtos(cache.getResidentialStatuses()));
		dropdowns.put("sex", toListableDtos(cache.getSexes()));
		dropdowns.put("education", toListableDtos(cache.getEducationLevels()));
		dropdowns.put("salutation", toListableDtos(cache.getSalutations()));
		dropdowns.put("offence", toListableDtos(cache.getTgDeclaredOffenceTypes()));
		dropdowns.put("passType", toListableDtos(cache.getWorkPassTypes()));
		dropdowns.put("occupation", toListableDtos(cache.getOccupations()));
		dropdowns.put("addressType", toListableDtos(cache.getAddressTypes()));
		return dropdowns;
	}

	@RequestMapping(path = "/course-attendance-types", method = RequestMethod.GET)
	public List<ListableDto> getCourseAttendanceTypes() {
		return toListableDtos(cache.getCourseAttendanceTypes());
	}

	@RequestMapping(path = "/ta-workflow-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTaWorkflowStatuses() {
		return toListableDtos(cache.getTaWorkflowStatuses());
	}

	@RequestMapping(path = "/tg-workflow-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTgWorkflowStatuses() {
		return toListableDtos(cache.getTgWorkflowStatuses());
	}

	@RequestMapping(path = "/ta-shortfall-types", method = RequestMethod.GET)
	public List<ListableDto> getTaShortfallTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TA_SHORTFALL));
	}

	@RequestMapping(path = "/recommend-types", method = RequestMethod.GET)
	public List<ListableDto> getRecommendationTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.RECOMMEND));
	}

	@RequestMapping(path = "/ta-app-pending-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTaApplicationPendingStatuses() {
		return toListableDtos(cache.getTaApplicationStatuses().stream().filter(o -> Codes.PendingApprovalStatuses.TA.contains(o.getCode())).collect(Collectors.toList()), true);
	}

	@RequestMapping(path = "/types/{categoryCode}", method = RequestMethod.GET)
	public List<ListableDto> getTypesByCategoryCode(@PathVariable String categoryCode) {
		return toListableDtos(cache.getTypesByCategory(categoryCode));
	}

	@RequestMapping(path = "/statuses/{categoryCode}", method = RequestMethod.GET)
	public List<ListableDto> getStatusesByCategoryCode(@PathVariable String categoryCode) {
		return toListableDtos(cache.getStatusesByCategory(categoryCode));
	}

	@RequestMapping(path = "/status/{code}", method = RequestMethod.GET)
	public ListableDto getStatusByCode(@PathVariable String code) {
		return new ListableDto(cache.getStatus(code));
	}

	@RequestMapping(path = "/ce-pending-statuses", method = RequestMethod.GET)
	public List<ListableDto> getCEPendingStatuses() {
		return toListableDtos(cache.getTaApplicationStatuses().stream().filter(o -> Codes.PendingApprovalStatuses.TA_CE.contains(o.getCode())).collect(Collectors.toList()), true);
	}

	@RequestMapping(path = "/filing-statuses", method = RequestMethod.GET)
	public List<ListableDto> getFilingStatuses() {
		return toListableDtos(cache.getStatusesByCategory(Codes.StatusCategories.TA_FILING).stream().filter(stat -> !Entities.equals(stat, Codes.Statuses.TA_FILING_VOID)).collect(Collectors.toList()),
				true);
	}

	@RequestMapping(path = "/user-roles", method = RequestMethod.GET)
	public List<ListableDto> getUserRoles() {
		return toListableDtos(cache.getUserRoles());
	}

	@RequestMapping(path = "/department", method = RequestMethod.GET)
	public List<ListableDto> getDepartment() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.DEPT));
	}

	@RequestMapping(path = "/module", method = RequestMethod.GET)
	public List<ListableDto> getModule() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.MOD));
	}

	@RequestMapping(path = "/function/{module}", method = RequestMethod.GET)
	public List<ListableDto> getFunction(@PathVariable String module) {
		return toListableDtos(cache.getModFunction(module));
	}

	@RequestMapping(path = "/ta-branch-statuses", method = RequestMethod.GET)
	public List<ListableDto> getTaBranchStatuses() {
		return toListableDtos(cache.getStatusesByCategory(Codes.StatusCategories.TA_BRANCH_LICENCE), true);
	}

	@RequestMapping(path = "/ta-address-types", method = RequestMethod.GET)
	public List<ListableDto> getTaAddressTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TA_ADDR), true);
	}

	@RequestMapping(path = "/ta-service-types", method = RequestMethod.GET)
	public List<ListableDto> getTaServiceTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TA_SERVICE_TYPE), true);
	}

	@RequestMapping(path = "/ta-check-types", method = RequestMethod.GET)
	public List<ListableDto> getTaCheckTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TA_CHECK), true);
	}

	@RequestMapping(path = "/ce-tg-schedule-meridiem-types", method = RequestMethod.GET)
	public List<ListableDto> getCeTgScheduleMeridiemTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_TG_SCHEDULE_MERIDIEM), true);
	}

	@RequestMapping(path = "/ce-tg-schedule-location-types", method = RequestMethod.GET)
	public List<ListableDto> getCeTgScheduleLocationTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_TG_SCHEDULE_LOCATION), true);
	}

	@RequestMapping(path = "/ce-oeo-types", method = RequestMethod.GET)
	public List<ListableDto> getCeOeoTypes() {
		return toListableDtos(cache.getTypesByCategoryOrderLabel(Codes.TypeCategories.CE_OEO), true);
	}

	@RequestMapping(path = "/all-ce-oeo-types", method = RequestMethod.GET)
	public List<ListableDto> getAllCeOeoTypes() {
		return toListableDtos(cache.getAllTypesByCategoryOrderLabel(Codes.TypeCategories.CE_OEO), true);
	}

	@RequestMapping(path = "/ce-ta-eo-users", method = RequestMethod.GET)
	public List<ListableDto> getCeTaEoUsers() {
		List<ListableDto> results = userRepository
				.getListableActiveUsersByRoles(Lists.newArrayList(Codes.Roles.TA_CNE_ENFORCEMENT_OFFICER, Codes.Roles.CNE_COMPLIANCE_OFFICER, Codes.Roles.CNE_INVESTIGATION_OFFICER));
		return results;
	}

	@RequestMapping(path = "/ce-ta-aux-eo-users", method = RequestMethod.GET)
	public List<ListableDto> getCeTaAuxEoUsers() {
		List<ListableDto> results = toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_SUB_OEO), true);
		results.addAll(toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_OEO), true));
		return results;
	}

	@RequestMapping(path = "/ce-case-oic-users", method = RequestMethod.GET)
	public List<ListableDto> getCeCaseOicUsers() {
		List<ListableDto> results = userRepository.getListableActiveUsersByRoles(Lists.newArrayList(Codes.Roles.CNE_INVESTIGATION_OFFICER, Codes.Roles.CNE_COMPLIANCE_OFFICER));
		return results;
	}

	@RequestMapping(path = "/clear-system-cache", method = RequestMethod.GET)
	public void clearSystemCache() {
		cache.clearCache();
	}

	@RequestMapping(path = "/docType-by-key/{key}", method = RequestMethod.GET)
	public List<ListableDto> getDocTypeByKey(@PathVariable String key) {
		return toListableDtos(commonRepository.getDocTypeListByKey(key), true);
	}

	@RequestMapping(path = "/formList/{key}", method = RequestMethod.GET)
	public List<ListableDto> getFormList(@PathVariable String key) {
		return toListableDtos(cache.getFormListByKey(key));
	}

	@RequestMapping(path = "/formStatusList/{key}", method = RequestMethod.GET)
	public List<ListableDto> getFormStatusList(@PathVariable String key) {
		return toListableDtos(cache.getFormStatusListByKey(key));
	}

	// to populate all dropdown values in mobile
	// http://localhost:9191/webservice-admin/api/v1/common/mobile-types
	@RequestMapping(path = "/mobile-types", method = RequestMethod.GET)
	public List<TypeDto> getTypesForMobile() {
		List<TypeDto> dropdowns = new ArrayList<>();
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.COUNTRY)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.NATIONALITY)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.ADDRESS_TYPE)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.PREMISE_TYPE)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.CE_TG_SCHEDULE_LOCATION)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.CE_TG_FIELD_REPORT_ASSESSMENT)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.CE_CHAPTER)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.FLAG)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.PREMISE_TYPE)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.TA_ADDR)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.CE_OEO)));
		dropdowns.addAll(toTypeDtos(cache.getAllTypesByCategory(Codes.TypeCategories.CE_SUB_OEO)));
		dropdowns.add(toTypeDto(cache.getSystemParameter(SystemParameters.CE_TATI_CHECK_INFO)));
		dropdowns.add(toTypeDto(cache.getSystemParameter(SystemParameters.CE_TA_CHECKS_DECLARATION)));
		return dropdowns;
	}

	// to save provisions and offences in mobile
	// http://localhost:9191/webservice-admin/api/v1/common/ce-provisions-mobile
	@RequestMapping(path = "/ce-provisions-mobile", method = RequestMethod.GET)
	public List<CeProvisionDto> getCeProvisionsForMobile() {
		List<CeProvisionDto> ceProvisionDtos = new ArrayList<CeProvisionDto>();
		List<CeProvision> ceOffenceProvisions = ceProvisionRepository.getAllCeOffenceProvisions();
		ceOffenceProvisions.forEach(u -> ceProvisionDtos.add(CeProvisionDto.buildFromProvisions(cache, u)));
		return ceProvisionDtos;
	}

	// to save list of provision readwiths mapping in mobile
	// http://localhost:9191/webservice-admin/api/v1/common/ce-provisions-readwiths
	@RequestMapping(path = "/ce-provisions-readwiths", method = RequestMethod.GET)
	public List<CeProvisionReadWithDto> getCeProvisionsReadWithForMobile() {
		return ceProvisionRepository.getAllProvisionReadWiths();
	}

	@RequestMapping(path = "/ce-offence-provisions", method = RequestMethod.GET)
	public List<CeProvisionDto> getCeProvisions() {
		List<CeProvisionDto> ceProvisionDtos = new ArrayList<CeProvisionDto>();
		List<CeProvision> ceOffenceProvisions = ceProvisionRepository.getAllCeOffenceProvisions();
		ceOffenceProvisions.forEach(u -> ceProvisionDtos.add(new CeProvisionDto(cache, u)));
		return ceProvisionDtos;
	}

	@RequestMapping(path = "/ce-outcomes", method = RequestMethod.GET)
	public List<ListableDto> getCeOutcomes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_OUTCOME), true);
	}

	@RequestMapping(path = "/ce-outcomes-ip", method = RequestMethod.GET)
	public List<ListableDto> getCeOutcomesIp() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_OUTCOME, Codes.TypeCategories.CE_OUTCOME_IP), true);
	}

	@RequestMapping(path = "/ce-task-types", method = RequestMethod.GET)
	public List<ListableDto> getCeTaskTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_TASK), true);
	}

	@RequestMapping(path = "/ce-task-statuses", method = RequestMethod.GET)
	public List<ListableDto> getCeTaskStatuses() {
		return toListableDtos(
				cache.getStatusesByCategory(Codes.StatusCategories.CE_TASK).stream().filter(stat -> !Entities.equals(stat, Codes.CeTaskStatus.CE_TASK_COMPLETED)).collect(Collectors.toList()), true);
	}

	@RequestMapping(path = "/ce-ta-check-statuses", method = RequestMethod.GET)
	public List<ListableDto> getCeTaCheckStatuses() {
		return toListableDtos(cache.getStatusesByCategory(Codes.StatusCategories.CE_TA_CHECK), true);
	}

	@RequestMapping(path = "/ce-ta-field-report-classifications", method = RequestMethod.GET)
	public List<ListableDto> getCeTaFieldReportClassifications() {
		List<ListableDto> list = toListableDtos(cache.getTypesByCategoryOrderLabel(Codes.TypeCategories.CE_TA_FIELD_REPORT_CLASS).stream()
				.filter(o -> !o.getCode().equals(CE_TA_FIELD_REPORT_CLASS.OTHERS)).collect(Collectors.toList()), true);
		list.add(new ListableDto(cache.getType(CE_TA_FIELD_REPORT_CLASS.OTHERS)));
		return list;
	}

	@RequestMapping(path = "/ce-appeal-results", method = RequestMethod.GET)
	public List<ListableDto> getCeAppealResults() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_APPEAL_RESULT), true);
	}

	@RequestMapping(path = "/ce-decisions", method = RequestMethod.GET)
	public List<ListableDto> getCeDecisions() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_DECISION), true);
	}

	@RequestMapping(path = "/ce-provision-chapters", method = RequestMethod.GET)
	public List<ListableDto> getCeProvisionChapters() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.CE_CHAPTER), true);
	}

	@RequestMapping(path = "/tg-age-groups", method = RequestMethod.GET)
	public List<ListableDto> getTgAgeGroups() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TG_AGE_GROUP), true);
	}

	@RequestMapping(path = "/email-broadcast-frequency", method = RequestMethod.GET)
	public List<ListableDto> getEmailBroadcastFreq() {
		return toListableDtos(cache.getTypesByCategoryOrderLabel(Codes.TypeCategories.EMAIL_BROADCAST_FREQUENCY), false);
	}

	@RequestMapping(path = "/check-payment-waive/{paymentReqType}", method = RequestMethod.GET)
	public Boolean checkPaymentIsWaived(@PathVariable String paymentReqType) {
		return paymentHelper.checkPaymentIsWaived(paymentReqType);
	}

	@RequestMapping(path = { "/tg-course-subsidies" }, method = RequestMethod.GET)
	public List<TgCourseSubsidyDto> getTgCourseSubsidies() {
		List<TgCourseSubsidyDto> subsidies = new ArrayList<TgCourseSubsidyDto>();
		if (subsidies.size() == 0) {
			List<Type> types = cache.getTypesByCategory(Codes.TypeCategories.TG_COURSE_SUBSIDY);
			types.stream().forEach(type -> subsidies.add(new TgCourseSubsidyDto(type)));
		}
		return subsidies;
	}

	@RequestMapping(path = "/ta-filing-request-types", method = RequestMethod.GET)
	public List<ListableDto> getTaFilingRequestTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TA_REQ_ADHOC));
	}

	@RequestMapping(path = "/ta-filing-condition-types", method = RequestMethod.GET)
	public List<ListableDto> getTaFilingConditionTypes() {
		List<ListableDto> listableDtos = toListableDtos(cache.getTypes(ApplicationTypes.TA_FILING_TYPES));
		Collections.sort(listableDtos, Comparator.comparing(ListableDto::getLabel));
		return listableDtos;
	}

	@RequestMapping(path = "/ta-ma-filing-condition-types", method = RequestMethod.GET)
	public List<ListableDto> getTaMaFilingConditionTypes() {
		List<ListableDto> listableDtos = toListableDtos(cache.getTypes(ApplicationTypes.TA_MA_FILING_TYPES));
		return listableDtos;
	}

	@RequestMapping(path = "/ta-filing-amend-types", method = RequestMethod.GET)
	public List<ListableDto> getTaFilingAmendTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TA_FILING_AMENDMENT));
	}

	@RequestMapping(path = "/ta-sales-channels", method = RequestMethod.GET)
	public List<ListableDto> getTaSalesChannels() {
		return allFieldsToListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TA_SALES_CHANNEL));
	}

	@RequestMapping(method = RequestMethod.GET, value = "/first-level-workflow-types/{workflowTypes}/{selectedRoleCode}")
	public List<ListableDto> getFirstLevelWorkflowsForCurrentUser(@PathVariable Object[] workflowTypes, @PathVariable String selectedRoleCode) {
		List<WorkflowStepAssignment> workflowFirstLevels = workflowRepository.getFirstLevelWorkflowSteps(workflowTypes);
		List<ListableDto> requestList = new ArrayList<ListableDto>();
		for (WorkflowStepAssignment row : workflowFirstLevels) {
			if (selectedRoleCode.equalsIgnoreCase(row.getWorkflowStep().getRole().getCode().toString())) {
				requestList.add(new ListableDto(Codes.TA_WKFLW_TYPE_MAP.get(row.getWorkflowConfig().getAppOrWkflwType().getCode()).get(0),
						cache.getType(Codes.TA_WKFLW_TYPE_MAP.get(row.getWorkflowConfig().getAppOrWkflwType().getCode()).get(0)).getLabel()));
			}
		}

		return requestList;
	}

	// get iams sso enabled flag
	@RequestMapping(method = RequestMethod.GET, value = "/iams-sso")
	public Boolean getIamsSsoMode() {
		return properties.iamsSsoEnabled;
	}

	@RequestMapping(path = "/tg-info-types", method = RequestMethod.GET)
	public List<ListableDto> getTgInfoTypes() {
		return toListableDtos(cache.getTypesByCategory(Codes.TypeCategories.TG_INFO));
	}
}
