package gov.stb.tag.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.FileTxfDto;
import gov.stb.tag.dto.FileTxfListDto;
import gov.stb.tag.dto.WorkflowAttachmentDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.LicenceReturnBatch;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowFile;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.util.FileUtil;

@RestController
@RequestMapping(path = "/api/v1/file")
@Transactional
public class FileController extends BaseController {

	private static final String SECRET = "ThisIsASecret123";

	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	Properties properties;

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@RequestMapping(path = "/download/{fileId}/{hash}", method = RequestMethod.GET)
	public void downloadFiles(HttpServletResponse response, @PathVariable Integer fileId, @PathVariable String hash) throws IOException {
		File file = fileHelper.getFile(fileId);
		if (file != null) {
			fileHelper.isHashBelongToFile(file, hash);
			FileUtil.downloadSingleFile(response, fileHelper.getPhyiscalFile(file), file.getExtension());
			logger.info("file content type : " + response.getContentType());
		} else {
			throw new ValidationException("File not found");
		}
	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public void deleteFiles(@RequestBody List<Integer> deleted) {
		for (Integer fileId : deleted) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			} else {
				logger.error("File not found: " + fileId);
			}

		}

	}

	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public FileDto uploadFile(@RequestPart(name = "docType") String docType, @RequestPart(name = "file") MultipartFile file) {

		// 1. Save documents
		File fileObj = fileHelper.saveFile(docType, file, false);

		// 2. Pass DTO containing new fileID to frontend (to pass to admin webservice for reference)
		FileDto dto = FileDto.buildFromFile(fileObj, cache.getType(docType), fileHelper);
		return dto;

	}

	@RequestMapping(value = "/upload/updateFiles", method = RequestMethod.POST)
	public List<FileDto> updateAttachments(@RequestBody List<FileDto> fileDtos) {

		List<FileDto> updatedFiletDtos = new ArrayList<FileDto>();

		for (FileDto fileDto : fileDtos) {
			File fileObj = fileHelper.updateFileFromFileDto(fileRepository.get(File.class, fileDto.getId()), fileDto, Boolean.FALSE);
			updatedFiletDtos.add(FileDto.buildFromFile(fileObj));
		}

		return updatedFiletDtos;
	}

	@RequestMapping(value = "/upload/asAttachment", method = RequestMethod.POST)
	public AttachmentDto uploadAsAttachment(@RequestPart(name = "docType") String docType, @RequestPart(name = "file") MultipartFile file) {

		// 1. Save documents
		File fileObj = fileHelper.saveFile(docType, file, false);

		// 2. Get docment type model
		Type docTypeModel = new Type();
		docTypeModel = fileRepository.get(Type.class, docType);

		// 2. Pass DTO containing new fileID to frontend (to pass to admin webservice for reference)
		AttachmentDto dto = AttachmentDto.buildFromFile(fileObj);
		return dto;

	}

	@RequestMapping(value = "/upload/updateAttachment", method = RequestMethod.POST)
	public AttachmentDto updateAttachment(@RequestBody AttachmentDto attachmentDto) {

		File fileObj = fileHelper.updateFileFromAttachmentDto(fileRepository.get(File.class, attachmentDto.getId()), attachmentDto, Boolean.FALSE);

		AttachmentDto dto = AttachmentDto.buildFromFile(fileObj);
		return dto;
	}

	@RequestMapping(value = "/upload/transfer-to-internet", method = RequestMethod.POST)
	public FileDto uploadFileToTransferToInternet(@RequestPart(name = "docType") String docType, @RequestPart(name = "file") MultipartFile file) {

		// 1. Save documents
		File fileObj = fileHelper.saveFile(docType, file, false, true, null);

		// 2. Pass DTO containing new fileID to frontend (to pass to admin webservice for reference)
		FileDto dto = FileDto.buildFromFile(fileObj, cache.getType(docType), fileHelper);
		return dto;

	}

	@RequestMapping(value = "/upload/bulletin-file", method = RequestMethod.POST)
	public FileDto uploadBulletinFile(@RequestPart(name = "docType") String docType, @RequestPart(name = "file") MultipartFile file) {

		// 1. Save documents
		File fileObj = fileHelper.saveBulletinFile(docType, file, false);

		// 2. Get docment type model
		Type docTypeModel = new Type();
		docTypeModel = fileRepository.get(Type.class, docType);

		// 2. Pass DTO containing new fileID to frontend (to pass to admin webservice for reference)
		FileDto dto = FileDto.buildFromFile(fileObj, docTypeModel, fileHelper);
		return dto;

	}

	@RequestMapping(value = "/upload/workflow-file/{workflowId}", method = RequestMethod.POST)
	public AttachmentDto uploadSingleWorkflowFile(AttachmentDto attachmentDto, @PathVariable Integer workflowId) {

		WorkflowFile fileObj = fileHelper.saveOrUpdateWorkflowFile(attachmentDto, fileRepository.get(Workflow.class, workflowId));

		AttachmentDto dto = AttachmentDto.buildFromWorkflowFile(fileObj, fileHelper);
		return dto;
	}

	@RequestMapping(value = "/upload/licence-return-batch-file/{licenceReturnBatchId}", method = RequestMethod.POST)
	public FileDto uploadLicenceReturnBatchFile(@RequestPart(name = "file") MultipartFile file, @PathVariable Integer licenceReturnBatchId) {

		// 1. Save documents
		File fileObj = fileHelper.saveFile(Codes.TaDocumentTypes.TA_DOC_OTHERS, file, false, false, properties.licenceReturnUploadDir);

		// 2. Link file to Licence Return Batch
		LicenceReturnBatch lrb = fileRepository.get(LicenceReturnBatch.class, licenceReturnBatchId);
		lrb.getSupportingDocs().add(fileObj);

		// 3. Pass DTO containing new fileID to frontend (to pass to admin webservice for reference)
		FileDto dto = FileDto.buildFromFile(fileObj, cache.getType(Codes.TaDocumentTypes.TA_DOC_OTHERS), fileHelper);
		return dto;
	}

	@RequestMapping(value = "/delete/workflow-file", method = RequestMethod.POST)
	public void deleteWorkflowFiles(@RequestBody List<Integer> deleted) {
		for (Integer workflowFileId : deleted) {
			fileHelper.deleteWorkflowFileByWorkflowFileId(workflowFileId);
		}
	}

	@RequestMapping(value = "/upload/workflow-files/{workflowId}", method = RequestMethod.POST)
	public void updateWorkflowFiles(@PathVariable Integer workflowId, @RequestBody WorkflowAttachmentDto workflowAttachmentDto) {

		// save files
		if (CollectionUtils.isNotEmpty(workflowAttachmentDto.getWorkflowFiles())) {
			for (AttachmentDto attachmentDto : workflowAttachmentDto.getWorkflowFiles()) {
				fileHelper.saveOrUpdateWorkflowFile(attachmentDto, fileRepository.get(Workflow.class, workflowId));
			}
		}

		// delete files
		if (CollectionUtils.isNotEmpty(workflowAttachmentDto.getDeletedWorkflowFileIds())) {
			for (Integer workflowFileId : workflowAttachmentDto.getDeletedWorkflowFileIds()) {
				fileHelper.deleteWorkflowFileByWorkflowFileId(workflowFileId);
			}
		}
	}

	// only to be called by server-to-server logic via APEX
	@RequestMapping(method = RequestMethod.POST, value = "/update-file-txf")
	public FileTxfListDto updateFileTxf(@Validated @RequestBody FileTxfListDto fileTxfListDto) {
		if (!SECRET.equals(fileTxfListDto.getSecret())) {
			throw new ValidationException(Messages.Errors.LOGIN_SECRET_MISMATCH);
		} else {
			for (FileTxfDto dto : fileTxfListDto.getFileTxfDtos()) {
				File file = fileRepository.getFile(dto.getAdminFileId());
				if (file == null) {
					dto.setTransferStatusCode(Codes.Statuses.TXF_TO_PUB_FAIL);
					dto.setTransferError(Messages.Errors.FILE_NOT_FOUND);
				} else {
					if (!file.getHash().equals(dto.getHash())) {
						dto.setTransferStatusCode(Codes.Statuses.TXF_TO_PUB_FAIL);
						dto.setTransferError(Messages.Errors.FILE_HASH_MISMATCH);
					} else {
						dto.setDescription(file.getDescription());
						dto.setExtension(file.getExtension());
						dto.setFilename(file.getFilename());
						dto.setOriginalFilename(file.getOriginalFilename());
						dto.setPath(file.getPath());
						dto.setSize(file.getSize());
						dto.setDeleted(file.getIsDeleted());
						dto.setTransferStatusCode(Codes.Statuses.TXF_TO_PUB_SUCCESSFUL);
						file.setPublicFileId(dto.getPublicFileId());
					}
					file.setTransferStatus(cache.getStatus(dto.getTransferStatusCode()));
					file.setTransferError(dto.getTransferError());
				}
				logger.info(dto.getPublicFileId() + ", " + dto.getAdminFileId() + ", " + dto.getHash() + "," + dto.getTransferStatusCode() + ", " + dto.getTransferError() + ", " + dto.getFilename()
						+ ", " + dto.getOriginalFilename() + ", " + dto.getExtension() + ", " + dto.isDeleted());
			}
		}
		return fileTxfListDto;
	}
}
