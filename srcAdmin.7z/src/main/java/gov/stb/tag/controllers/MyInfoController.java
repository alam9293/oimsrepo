package gov.stb.tag.controllers;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import gov.stb.tag.dto.myinfo.MyInfoPersonBasicDto;
import gov.stb.tag.helper.MyInfoHelper;
import gov.stb.tag.model.User;

@RestController
@RequestMapping(path = "/api/v1/my-info")
@Transactional
public class MyInfoController extends BaseController {
    protected transient Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    MyInfoHelper myInfoHelper;

    /**
     * A copy of MyInfo query result is stored, and subsequently retrieved for Gov data
     * This is to eliminate the risk of user tampers the Gov data via form editing
     * @param body
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/snapshot", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public MyInfoPersonBasicDto saveMyInfoSnapshot(@RequestParam Map<String, String> body)throws UnsupportedEncodingException  { //@RequestBody String jsonText
        MyInfoPersonBasicDto dto = new MyInfoPersonBasicDto();
        User user = getUser();
        String jsonText = body.get("jsonText");
        if (jsonText == null || jsonText.isEmpty()) {
            dto.setUinfin(user.getLoginId());
            dto.setError(true);
            dto.setErrorMessage("");
            logger.error("saveMyInfoSnapshot(): myinfo response is blank, uinfin: " + user.getLoginId());
        } else {
            jsonText = URLDecoder.decode(jsonText, "UTF-8");
            dto = myInfoHelper.saveRawResponse(user.getLoginId(), jsonText);
        }
        return dto;
    }
}
