package gov.stb.tag.controllers;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Objects;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.eNets.ENetsTxnDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.payment.PaymentRequestItemDto;
import gov.stb.tag.dto.payment.PaymentRequestSearchDto;
import gov.stb.tag.dto.payment.PaymentStatusSpanDto;
import gov.stb.tag.dto.payment.PaymentTxnDto;
import gov.stb.tag.dto.payment.PaymentTxnSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentStatusSpan;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.PaymentRefundRepository;
import gov.stb.tag.repository.PaymentRepository;

@RestController
@RequestMapping(path = "/api/v1/payment/")
@Transactional
public class PaymentController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private PaymentRepository paymentRepository;
	@Autowired
	private CommonRepository commonRepository;
	@Autowired
	private PaymentHelper helper;
	@Autowired
	private PaymentRefundRepository paymentRefundRepository;

	@RequestMapping(value = "/requests/view/payment-request-types", method = RequestMethod.GET)
	public List<ListableDto> getPaymentRequestTypes() {
		List<ListableDto> results = new ArrayList<>();
		for (Type type : cache.getPaymentRequestTypes()) {
			if (Codes.PAYREQ_ACCESS_RIGHTS.get(getSelectedRoleCode()).contains(type.getCode())) {
				results.add(new ListableDto(type.getKey(), type.getLabel()));
			}
		}
		return results;
	}

	@RequestMapping(value = "/requests/view", method = RequestMethod.GET)
	public ResponseEntity<ResultDto<PaymentRequestItemDto>> getPaymentRequests(PaymentRequestSearchDto searchDto) {
		ResultDto<PaymentRequestItemDto> resultDto = paymentRepository.getPaymentRequests(searchDto, Codes.PAYREQ_ACCESS_RIGHTS.get(getSelectedRoleCode()));
		return addVersionCheckForListing(resultDto, resultDto.getModels());
	}

	@RequestMapping(value = "/requests/view/{billRefNo}", method = RequestMethod.GET)
	public ResponseEntity<PaymentRequestDto> getPaymentRequest(@PathVariable String billRefNo) {
		PaymentRequestDto dto = new PaymentRequestDto(cache, paymentRepository.getPaymentRequest(billRefNo), true);
		if (!Codes.PAYREQ_ACCESS_RIGHTS.get(getSelectedRoleCode()).contains(dto.getTypeCode())) {
			throw new ValidationException("You are not allowed to view this payment request. Role: " + getSelectedRoleCode() + ", PayReqType: " + dto.getTypeCode());
		}
		if (paymentRefundRepository.getPaymentRefundNotRejected(billRefNo) != null) {
			dto.setHasRefund(true);
		}
		return addVersionCheckForListing(dto, Arrays.asList(dto)); // use Version-Check-Listing here because update is shared with batch update in listing
	}

	@RequestMapping(value = "/portal/get-payment-request", method = RequestMethod.GET)
	public PaymentRequestDto getPaymentRequestForPortal(@RequestParam String billRefNo) {
		User currentUser = commonRepository.getLicenseeUserByUserId(getUser().getId());
		PaymentRequest payReq = paymentRepository.getPaymentRequest(billRefNo);
		if (payReq != null && !(payReq.getPayerUinUen().equals(currentUser.getUen()) || payReq.getPayerUinUen().equals(currentUser.getLoginId()))) {
			throw new ValidationException("Payment Request does not belong to the logged in user.");
		}
		PaymentRequestDto dto = new PaymentRequestDto(cache, payReq, true);
		return dto;
	}

	@RequestMapping(value = "/portal/get-payment-txn", method = RequestMethod.GET)
	public ResultDto<PaymentTxn> getPaymentTxnForPortal(PaymentTxnSearchDto searchDto) {
		User currentUser = commonRepository.getLicenseeUserByUserId(getUser().getId());
		ResultDto<PaymentTxn> results = paymentRepository.getPaymentTxns(searchDto, currentUser.getUen() != null ? currentUser.getUen() : currentUser.getLoginId());

		Object[] finalRecords = new Object[results.getRecords().length];
		var i = 0;
		for (PaymentTxn txn : results.getModels()) {
			var dto = new PaymentTxnDto(cache, txn);

			// 1. handling to concat multiple payreq bill ref no into 1 field separated by comma.
			// 2. done in controller rather than dto due to need to call repository as filter (bill ref no) will return only 1 payreq for 1 txn when there could be multiple thus the need to call repo
			// one
			// more time
			String billRefNos = "";
			String payReqTypes = "";
			for (PaymentRequest pr : paymentRepository.getPaymentRequestByTxn(txn.getId())) {
				billRefNos = billRefNos + ", " + pr.getBillRefNo();
				if (!payReqTypes.contains(cache.getLabel(pr.getType(), false))) {
					payReqTypes = payReqTypes + ", " + cache.getLabel(pr.getType(), false);
				}
			}
			billRefNos = billRefNos.substring(2, billRefNos.length());
			payReqTypes = payReqTypes.substring(2, payReqTypes.length());
			dto.setBillRefNos(billRefNos);
			dto.setPayReqTypes(payReqTypes);

			finalRecords[i] = dto;
			i++;
		}
		results.setRecords(finalRecords);
		return results;
	}

	@RequestMapping(value = "/portal/get-payment-txn/{id}", method = RequestMethod.GET)
	public PaymentTxnDto getPaymentTxnForPortal(@PathVariable Integer id) {
		User currentUser = commonRepository.getLicenseeUserByUserId(getUser().getId());
		String uinUen = currentUser.getUen() != null ? currentUser.getUen() : currentUser.getLoginId();

		PaymentTxn txn = paymentRepository.get(PaymentTxn.class, id);
		List<ListableDto> payReq = new ArrayList<>();
		for (PaymentRequest pr : txn.getPaymentRequests()) {
			if (!pr.getPayerUinUen().equals(uinUen)) {
				throw new ValidationException("Payment Request does not belong to user: {}", pr.getBillRefNo());
			}
			payReq.add(new ListableDto(pr.getBillRefNo(), cache.getLabel(pr.getType(), false), pr.getPayableAmount().toString()));
		}
		PaymentTxnDto dto = new PaymentTxnDto(cache, txn);
		dto.setPayReqs(payReq);

		return dto;
	}

	@RequestMapping(value = "/requests/save", method = RequestMethod.POST)
	public String savePaymentRequest(@RequestBody PaymentRequestDto dto) {
		PaymentRequest req = helper.savePaymentRequest(dto.getRefNo(), dto.getTypeCode(), dto.getPayerUinUen(), dto.getPayerName(), dto.getPayableAmount(), dto.getDescription(), dto.getRemarks(),
				false, dto.getIsPayerCompany(), dto.getUserField2());
		return req.getBillRefNo();
	}

	@RequestMapping(value = "/requests/update-status/{statusCode}", method = RequestMethod.POST)
	public Boolean updatePaymentRequestStatuses(@RequestHeader(Codes.Headers.VERSION_CHECK_LISTING) String vcl, PaymentStatusSpanDto dto, @PathVariable String statusCode) {
		runVersionCheckForListing(vcl, toStrings(dto.getIds()));
		String status = "";
		if (statusCode.equals("not-paid")) {
			status = Codes.Statuses.PAYREQ_NOT_PAID;
		} else if (statusCode.equals("paid")) {
			status = Codes.Statuses.PAYREQ_PAID;
		} else if (statusCode.equals("settled")) {
			status = Codes.Statuses.PAYREQ_SETTLED;
		} else if (statusCode.equals("void")) {
			status = Codes.Statuses.PAYREQ_VOID;
		} else if (statusCode.equals("refund")) {
			status = Codes.Statuses.PAYREQ_REFUNDED;
		} else if (statusCode.equals("disbursed")) {
			status = Codes.Statuses.PAYREQ_DISBURSED;
		}
		helper.updatePaymentRequestStatuses(dto.getIds(), status, dto, null);
		return true;
	}

	@RequestMapping(value = "/requests/notes/save", method = RequestMethod.POST)
	public void addNote(CaseNoteDto dto) {
		PaymentRequest pr = paymentRepository.get(PaymentRequest.class, dto.getPayReqId());
		PaymentStatusSpan span = helper.createPaymentStatusSpan(pr, pr.getStatus(), dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	@RequestMapping(method = RequestMethod.GET, value = "/requests/view/status-spans//{payReqId}")
	public ResultDto<PaymentStatusSpan> getPaymentStatusSpanList(@PathVariable Integer payReqId, WorkflowActionSearchDto searchDto) {
		ResultDto<PaymentStatusSpan> results = paymentRepository.getPaymentStatusSpans(payReqId, searchDto);
		var models = results.getModels();
		models.stream().forEach(u -> {
			var dto = PaymentStatusSpanDto.buildFromPaymentStatusSpan(u, cache);
			results.getRecords()[models.indexOf(u)] = dto;
		});
		return results;
	}

	@RequestMapping(value = "/txns/save/{billRefNo}", method = RequestMethod.POST)
	public Integer savePaymentTxn(@PathVariable String billRefNo, @RequestBody PaymentTxnDto dto) {
		PaymentTxn txn = helper.savePaymentTxn(dto.getPaymentTypeCode(), Arrays.asList(billRefNo), dto.getAmount(), dto.getRemarks(), true);
		txn.getPaymentRequests().forEach(req -> {
			req.setStatus(cache.getStatus(dto.getResultantStatusCode()));
			helper.createPaymentStatusSpan(req, cache.getStatus(dto.getResultantStatusCode()));
			helper.updatePaymentCeTask(req);
		});
		return txn.getId();
	}

	@RequestMapping(value = "/txns/save/multiple", method = RequestMethod.POST)
	public void savePaymentTxn(@RequestBody PaymentTxnDto dto) {
		if (dto.getPayReqItems() != null) {
			for (PaymentRequestItemDto item : dto.getPayReqItems()) {
				PaymentTxn txn = helper.savePaymentTxn(dto.getPaymentTypeCode(), Arrays.asList(item.getBillRefNo()), item.getPayableAmount(), dto.getRemarks(), true);
				txn.getPaymentRequests().forEach(req -> {
					req.setStatus(cache.getStatus(dto.getResultantStatusCode()));
					helper.createPaymentStatusSpan(req, cache.getStatus(dto.getResultantStatusCode()));
					helper.updatePaymentCeTask(req);
				});
			}

		}
	}

	@RequestMapping(value = "/txns/delete/{paymentTxnId}", method = RequestMethod.POST)
	public Integer deletePaymentTxn(@PathVariable Integer paymentTxnId) {
		PaymentTxn txn = paymentRepository.get(PaymentTxn.class, paymentTxnId);
		if (Entities.anyEquals(txn.getPaymentType(), Codes.PaymentTypes.VISA, Codes.PaymentTypes.MASTERCARD)) {
			throw new ValidationException("Deletion of credit card transaction is not allowed!");
		}
		for (PaymentRequest req : txn.getPaymentRequests()) {
			if (req.getLastTxn().getId() == txn.getId()) {
				PaymentTxn prevTxn = paymentRepository.getPrevPaymentTxn(txn.getId(), req.getId());
				req.setLastTxn(prevTxn);
				if (prevTxn == null) {
					req.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_NOT_PAID));
					helper.createPaymentStatusSpan(req, cache.getStatus(Codes.Statuses.PAYREQ_NOT_PAID));
					helper.updatePaymentCeTask(req);
				}
			}
			req.getPaymentTxns().remove(txn);
		}
		paymentRepository.delete(txn);
		return paymentTxnId;
	}

	@RequestMapping(value = "/public/requests-for-payment", method = RequestMethod.GET)
	public List<PaymentRequestDto> getPaymentRequestsForPayment(@RequestParam String billRefNo, @RequestParam String payerUinUen) {

		if (Strings.isNullOrEmpty(billRefNo) && Strings.isNullOrEmpty(payerUinUen)) {
			throw new ValidationException("Both bill ref. no. and payer's UIN/UEN must be provided");
		}

		List<PaymentRequestDto> dtos = new ArrayList<>();
		PaymentRequest payReq = paymentRepository.getPaymentRequest(billRefNo, payerUinUen);
		if (payReq != null) {
			if (Objects.equal(Codes.Statuses.PAYREQ_NOT_PAID, payReq.getStatus().getCode())) {
				dtos.add(new PaymentRequestDto(cache, payReq, false)); // put as first payment to display
			}

			// payment details are entered correctly, start to find all outstanding payments
			List<PaymentRequest> otherPaymentRequests = paymentRepository.getPaymentRequestsForPaymentByPayerId(payerUinUen);
			if (CollectionUtils.isNotEmpty(otherPaymentRequests)) {
				otherPaymentRequests.forEach(o -> {
					if (!Objects.equal(billRefNo, o.getBillRefNo())) {
						dtos.add(new PaymentRequestDto(cache, o, false));
					}
				});
			}

			return dtos;

		} else {

			return null;
		}
	}

	@RequestMapping(value = "/public/init-payment-process/{paymentTypeCode}", method = RequestMethod.POST)
	public ENetsTxnDto initPaymentProcess(@PathVariable String paymentTypeCode, @RequestPart(name = "billRefNos") List<String> billRefNos, @RequestPart(name = "statusUrl") String statusUrl,
			@RequestPart(name = "returnUrl") String returnUrl, @RequestPart(name = "continueUrl") String continueUrl) throws NoSuchAlgorithmException {

		// to waive the bill if any
		List<String> payBills = helper.waivePayments(billRefNos);

		if (CollectionUtils.isEmpty(payBills)) {
			ENetsTxnDto dto = new ENetsTxnDto();
			dto.setIsAllWaived(Boolean.TRUE);
			return dto;
		} else {
			statusUrl = statusUrl.replace("\"", "");
			returnUrl = returnUrl.replace("\"", "");
			continueUrl = continueUrl.replace("\"", "");
			return helper.initPaymentProcess(paymentTypeCode, payBills, null, statusUrl, returnUrl, continueUrl);
		}
	}

	// Sample for manual callback:
	// "http://localhost:9191/webservice-admin/api/v1/payment/public/complete-payment-process
	/*
	 * {"ss":"1","msg":{"netsMid":"UMID_887770001","merchantTxnRef":"20170821 17:07:51.69","merchantTxnDtm":"20170821 17:07:51.690","paymentType":"SALE","currencyCode":"SGD","netsTxnRef":
	 * "20170821170826664","netsTxnDtm":"20170821 17:08:27.000","paymentMode":"CC","merchantTimeZone":"+8:00","netsTxnStatus":"0","netsTxnMsg":"Approval","netsAmountDeducted":"1000","maskPan":
	 * "4111XXXXXXXX1111","bankAuthId":"014089","stageRespCode":"0005-00000","txnRand":"20170821170803492","actionCode":"0","netsMidIndicator":"U"}}
	 */
	@RequestMapping(value = "/public/cpp", method = { RequestMethod.GET, RequestMethod.POST })
	public void completePaymentProcess(@RequestBody String json, HttpServletRequest request) throws NoSuchAlgorithmException {
		helper.completePaymentProcess(json, request);
	}

	@RequestMapping(value = "/public/requests-for-result/{anyBillRefNo}/{txnId}", method = RequestMethod.GET)
	public List<PaymentRequestDto> getPaymentRequestsForResult(@PathVariable String anyBillRefNo, @PathVariable Integer txnId) throws InterruptedException {
		List<PaymentRequest> reqs = helper.getPaymentProcessResult(anyBillRefNo, txnId);
		List<PaymentRequestDto> dtos = new ArrayList<>();
		reqs.forEach(req -> dtos.add(new PaymentRequestDto(cache, req, false)));
		return dtos;
	}

	@RequestMapping(value = "/public/create-txn-paynow/{amount}/{billRefNo}", method = RequestMethod.GET)
	public Integer createPayNowTxn(@PathVariable String amount, @PathVariable String billRefNo) throws NoSuchAlgorithmException {
		BigDecimal bamount = new BigDecimal("0.0");
		List<String> billRefNos = new ArrayList<>();
		billRefNos.addAll(Arrays.asList(billRefNo.split(",")));

		logger.info("createPayNowTxn 111111 amount: {}, billRefNo: {}", amount, billRefNo);
		// to waive the bill if any
		List<String> payBills = helper.waivePayments(billRefNos);
		if (CollectionUtils.isEmpty(payBills)) {
			return 0;
		} else {
			if (amount.equalsIgnoreCase("undefined")) {
				PaymentRequest pr = paymentRepository.getPaymentRequest(billRefNo);
				bamount = pr.getPayableAmount();
				logger.info("createPayNowTxn 22222 amount: {}, billRefNo: {}", amount, billRefNo);
			} else {
				bamount = new BigDecimal(amount);
				logger.info("createPayNowTxn 33333 amount: {}, billRefNo: {}", amount, billRefNo);
			}
			PaymentTxn txn = helper.savePaymentTxn(Codes.PaymentTypes.PAYNOW, billRefNos, bamount, null, false);
			logger.info("createPayNowTxn 4444 PaymentTxn ID: {}, PaymentTypes: {}", txn.getId(), Codes.PaymentTypes.PAYNOW);
			return txn.getId();
		}
	}

	// PayNow :API end point for DBS to call to return the status
	// "http://localhost:9191/webservice-admin/api/v1/payment/public/complete-payment-process-paynow";
	/**
	 * {"header": {"msgId": "IRGPPHK290419124937A0006051","orgId": "DBSTDS01","timeStamp": "2018-01-22T15:29:53.202","ctry": "HK"},"txnInfo": {"txnType": "FPS","customerReference": "24975",
	 * "txnRefId": "1904291337531RBCO012","txnDate": "2018-01-22","valueDt": "2018-01-22","receivingParty": {"name": "rpName","accountNo": "920171277999001"},"amtDtls": {"txnCcy": "HKD","txnAmt":
	 * 35.30},"senderParty": {"name": " Company Name1","senderBankId": "185"},"rmtInf": {"paymentDetails": "TEST 123456","purposeCode": "CXBSNS"}}}
	 **/
	@RequestMapping(value = "/public/complete-payment-process-paynow", method = { RequestMethod.POST })
	public void completePaymentProcessPayNow(@RequestBody String json) throws NoSuchAlgorithmException {
		helper.completePaymentProcessPayNow(json);
	}

	@RequestMapping(value = "/public/requests-for-icn-result/{txnId}", method = RequestMethod.GET)
	public Integer getPaymentTxnForICNResult(@PathVariable Integer txnId) throws InterruptedException {
		return helper.getPaymentTxnForICNResult(txnId);
	}

	@RequestMapping(value = "/public/get-txn-continueUrl/{txnId}", method = RequestMethod.GET)
	public PaymentTxnDto getPaymentTxnContinueUrl(@PathVariable Integer txnId) throws InterruptedException {
		PaymentTxnDto dto = new PaymentTxnDto();
		dto.setContinueUrl(paymentRepository.getPaymentTxnContinueUrl(txnId));
		return dto;
	}
}
