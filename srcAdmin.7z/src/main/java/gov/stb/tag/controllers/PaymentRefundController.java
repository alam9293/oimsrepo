package gov.stb.tag.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.payment.PaymentRefundDto;
import gov.stb.tag.dto.payment.PaymentRefundSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.PaymentRefund;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.PaymentRefundRepository;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.UserRepository;

@RestController
@RequestMapping(path = "/api/v1/payment-refund")
@Transactional
public class PaymentRefundController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private PaymentRepository paymentRepository;
	@Autowired
	private PaymentRefundRepository paymentRefundRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private WorkflowHelper workflowHelper;
	@Autowired
	private EmailHelper emailHelper;
	@Autowired
	private PaymentHelper paymentHelper;

	@RequestMapping(value = "/view/{billRefNo}", method = RequestMethod.GET)
	public PaymentRefundDto getPaymentRefund(@PathVariable String billRefNo) {
		PaymentRequest payReq = paymentRepository.getPaymentRequest(billRefNo);
		if (payReq != null) {
			PaymentRefundDto dto = new PaymentRefundDto();
			PaymentRefund refund = paymentRefundRepository.getPaymentRefundNotRejected(billRefNo);
			if (refund != null) {
				dto = PaymentRefundDto.buildFromPaymentRefund(cache, refund, payReq);
			} else {
				dto = PaymentRefundDto.buildFromPaymentRequest(cache, payReq);
			}
			return dto;
		} else {
			throw new ValidationException("Unable to find Payment Request for: {}", billRefNo);
		}

	}

	@RequestMapping(value = "/view/id/{id}", method = RequestMethod.GET)
	public PaymentRefundDto getPaymentRefundById(@PathVariable Integer id) {
		PaymentRefund refund = paymentRefundRepository.get(PaymentRefund.class, id);
		if (refund != null) {
			PaymentRefundDto dto = new PaymentRefundDto();
			PaymentRequest payReq = paymentRepository.getPaymentRequest(refund.getBillRefNo());
			dto = PaymentRefundDto.buildFromPaymentRefund(cache, refund, payReq);
			return dto;
		} else {
			throw new ValidationException("Unable to find Payment Refund for ID: {}", id.toString());
		}

	}

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<PaymentRefund> getPaymentRequests(PaymentRefundSearchDto searchDto) {
		ResultDto<PaymentRefund> resultDto = paymentRefundRepository.getPaymentRequests(searchDto, Codes.PAYREQ_ACCESS_RIGHTS.get(getSelectedRoleCode()));

		Object[] finalRecords = new Object[resultDto.getRecords().length];
		var i = 0;
		for (PaymentRefund l : resultDto.getModels()) {
			var dto = PaymentRefundDto.buildFromPaymentRefund(cache, l, paymentRepository.getPaymentRequest(l.getBillRefNo()));
			finalRecords[i] = dto;
			i++;
		}
		resultDto.setRecords(finalRecords);
		return resultDto;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public PaymentRefundDto savePaymentRefund(PaymentRefundDto dto) {

		// 1. check if payment request exists for given bill ref no
		PaymentRequest payReq = paymentRepository.getPaymentRequest(dto.getBillRefNo());
		if (payReq != null) {

			// 2. create payment refund object
			PaymentRefund refund = new PaymentRefund();
			refund.setBankAccountNo(dto.getBankAccountNo());
			refund.setBillRefNo(dto.getBillRefNo());
			refund.setPayerName(dto.getPayerName());
			refund.setRefundAmount(dto.getRefundAmount());

			// 3. create workflow
			Workflow workflow;
			if (Codes.PAYREQ_VIEWABLE_TYPES.TA.contains(payReq.getType().getCode())) {
				workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.PAY_WKFLW_REFUND_TA, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription(), true, null, null,
						dto.getApproverId());
			} else if (Codes.PAYREQ_VIEWABLE_TYPES.TG.contains(payReq.getType().getCode())) {
				workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.PAY_WKFLW_REFUND_TG, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription(), true, null, null,
						dto.getApproverId());
			} else {
				throw new ValidationException("Unable to determine workflow type for payment req type: {}", payReq.getType().getCode());
			}
			refund.setWorkflow(workflow);

			// 4. final commit
			paymentRefundRepository.save(refund);
			return PaymentRefundDto.buildFromPaymentRefund(cache, refund, payReq);
		} else {
			throw new ValidationException("Unable to find Payment Request for: {}", dto.getBillRefNo());
		}
	}

	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(PaymentRefundDto dto, @PathVariable String action, @PathVariable Integer id) {

		// 1. checks if refund obj exists
		PaymentRefund refund = paymentRefundRepository.get(PaymentRefund.class, id);
		if (refund != null) {

			// 2. process action on refund obj
			switch (action) {

			case ACTION_APPROVE:
				// 3. update refund workflow
				workflowHelper.forward(refund.getWorkflow(), false, dto.getInternalRemarks(), null, null, false, dto.getFiles(), dto.getFileDescription());

				// 4. update payment request
				PaymentRequest payReq = paymentRepository.getPaymentRequest(refund.getBillRefNo());
				payReq.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_PENDING_REFUND));
				paymentHelper.createPaymentStatusSpan(payReq, cache.getStatus(Codes.Statuses.PAYREQ_PENDING_REFUND));
				paymentHelper.updatePaymentCeTask(payReq);

				// 5. email
				List<String> recipients = new ArrayList<>();
				for (User user : userRepository.getFinanceUsers()) {
					recipients.add(user.getEmailAddress());
				}
				String[] recipient = recipients.toArray(new String[recipients.size()]);
				emailHelper.emailUponPaymentRefundApproval(Codes.EmailType.PAYMENT_REFUND_APPROVAL, refund, recipients.toArray(recipient));
				break;

			case ACTION_REJECT:
				// 3. update refund workflow
				workflowHelper.reject(refund.getWorkflow(), dto.getInternalRemarks(), null, dto.getFiles(), dto.getFileDescription());
				break;

			default:
				throw new ValidationException("Action received is invalid: " + action);
			}

		} else {
			throw new ValidationException("Unable to find Payment Refund for ID: {}", id.toString());
		}
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = paymentRefundRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

}
