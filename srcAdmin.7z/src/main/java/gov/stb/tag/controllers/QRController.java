package gov.stb.tag.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.zxing.WriterException;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceDto;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.QRCodeGenerator;

@RestController
@RequestMapping(path = "/api/v1/qr-code/")
@Transactional
public class QRController extends BaseController {
	@Autowired
	TravelAgentRepository travelAgentRepository;

	@RequestMapping(method = RequestMethod.GET, value = "/generate-ta-elicence-qr-code/{id}/{licNo}/{type}")
	public TaELicenceDto generateTAELicenceQrCode(@PathVariable Integer id, @PathVariable String licNo, @PathVariable String type) {
		TaELicenceDto res = new TaELicenceDto();
		List<TaBranch> branches = new ArrayList<TaBranch>();
		List<AddressDto> branchAddrDtoList = new ArrayList<AddressDto>();

		try {
			// get Branches
			branches = travelAgentRepository.getActiveBranchesByLicenceId(id);
			for (TaBranch branch : branches) {
				AddressDto branchAddrDto = new AddressDto();
				branchAddrDto = AddressDto.buildFromAddress(cache, branch.getAddress(), branch.getIsDownloadable());
				branchAddrDtoList.add(branchAddrDto);
			}
			res.setBranchAddrList(branchAddrDtoList);

			if ("0".equals(licNo)) {
				res.setQrCode("");
				return res;
			}
			byte[] image = new byte[0];
			String content = "";
			String qrcode = "";

			content = properties.taELicenceQrUrl;
			logger.info("QR Code URL" + content);

			content = content + id;
			// Generate and Return Qr Code in Byte Array
			if (type != null && type.equalsIgnoreCase(Codes.Types.TA_TIER_GENERAL)) { // 8dc7c0
				image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0xFFc1dfdb); // general bg color
			} else if (type != null && type.equalsIgnoreCase(Codes.Types.TA_TIER_NICHE)) {
				image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0xFFEAE5AD); // niche bg color
			} else {
				image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0);
			}
			// Convert Byte Array into Base64 Encode String
			qrcode = Base64.getEncoder().encodeToString(image);
			res.setQrCode(qrcode);

			return res;
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("WriterException : " + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("IOException : " + e.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Exception : " + e.getMessage());
		}

		return res; // return blank if QR Code generation fails for whatever reason
	}
}
