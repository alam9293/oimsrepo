package gov.stb.tag.controllers;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.report.ReportDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.ExcelFileHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Job;
import gov.stb.tag.repository.ReportRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.FileUtil;
import gov.stb.tag.util.ReportUtil;
import gov.stb.tag.util.ReportUtil.Reports;

@RestController
@RequestMapping(path = "/api/v1/reports")
@Transactional
public class ReportController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ReportRepository reportRepository;

	@Autowired
	private FileHelper fileHelper;

	@Autowired
	private ExcelFileHelper excelFileHelper;

	@RequestMapping(value = "/ta/view", method = RequestMethod.GET)
	public List<ReportDto> listReports() {
		List<ReportDto> results = new ArrayList<>();
		Job job = reportRepository.getByClassName(Codes.JobName.TaReportGenerationJob);
		if (job != null && job.getLastEndDate() != null) {
			for (Reports report : ReportUtil.getReports(Codes.TaTgType.TA)) {
				results.add(new ReportDto(report.getReportName(), getReportFileName(report.getReportName(), job.getLastEndDate())));
			}
		}
		return results;
	}

	@RequestMapping(value = "/ta/view/last-run", method = RequestMethod.GET)
	public LocalDateTime getReportLastGenerationDate() {
		Job job = reportRepository.getByClassName(Codes.JobName.TaReportGenerationJob);
		if (job != null) {
			return job.getLastEndDate();
		}
		return null;
	}

	@RequestMapping(value = "/ta/download/{reportName}", method = RequestMethod.GET)
	public void downloadReport(HttpServletResponse response, @PathVariable String reportName) throws IOException {
		Job job = reportRepository.getByClassName(Codes.JobName.TaReportGenerationJob);
		if (job != null) {
			File file = new File();
			file.setPath(properties.reportTaPlaceholderPath);
			file.setFilename(getReportFileName(reportName, job.getLastEndDate()));
			file.setExtension("csv");
			FileUtil.downloadSingleFile(response, fileHelper.getPhyiscalFile(file), file.getExtension());
		}
	}

	private String getReportFileName(String reportName, LocalDateTime lastRunDate) {
		if (lastRunDate == null) {
			throw new ValidationException("Report has not been generated.");
		}
		String prefix = DateUtil.format(lastRunDate, DateUtil.REPORT_DATE_FORMAT_PATTERN).concat("_");
		return prefix.concat(reportName).concat(".csv");
	}

	@RequestMapping(value = "/tg/download/active-tg", method = RequestMethod.GET)
	public void downloadActiveTgList(HttpServletResponse response) {
		Reports report = ReportUtil.Reports.valueOf("TG_REPORT_ACTIVE");

		List<Object[]> dataList = reportRepository.getResultSetFromNamedQuery(report.getNamedQuery(), null);
		Workbook workbook = excelFileHelper.createExcelSheet("Active TG", report.getHeaderNames());
		excelFileHelper.createCell(workbook.getSheetAt(0), dataList);
		excelFileHelper.createExcelFile("active tourist guide.xlsx", workbook, response);
	}

}
