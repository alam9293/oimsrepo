package gov.stb.tag.controllers.ce;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Objects;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.cases.CeCaseTaskLogDto;
import gov.stb.tag.dto.ce.cases.CeCaseTaskSummaryDto;
import gov.stb.tag.dto.ce.cases.CeCaseTaskWorkflowDto;
import gov.stb.tag.dto.ce.cases.CeCasesDto;
import gov.stb.tag.dto.ce.cases.CeComplainantDto;
import gov.stb.tag.dto.ce.cases.CeComplianceCheckDto;
import gov.stb.tag.dto.ce.cases.CeComplianceCheckSearchDto;
import gov.stb.tag.dto.ce.cases.CeDecisionDto;
import gov.stb.tag.dto.ce.cases.CeInfringementDto;
import gov.stb.tag.dto.ce.cases.CeInfringerDto;
import gov.stb.tag.dto.ce.cases.CeRecommendationDto;
import gov.stb.tag.dto.ce.cases.CeRescindDto;
import gov.stb.tag.dto.ce.cases.CeResultDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.CeCaseComplainant;
import gov.stb.tag.model.CeCaseDecision;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.CeCaseRescind;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaFieldReport;
import gov.stb.tag.model.CeTgFieldReport;
import gov.stb.tag.model.EmailLog;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowFile;
import gov.stb.tag.model.WorkflowStep;
import gov.stb.tag.model.WorkflowStepAssignment;
import gov.stb.tag.repository.CeCaseRepository;
import gov.stb.tag.repository.CeProvisionRepository;
import gov.stb.tag.repository.CeTaskRepository;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.LicenceStatusRepository;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.WorkflowRepository;
import gov.stb.tag.repository.ce.CeCaseAppealRepository;
import gov.stb.tag.repository.ce.CeCaseComplainantRepository;
import gov.stb.tag.repository.ce.CeCaseDecisionRepository;
import gov.stb.tag.repository.ce.CeCaseInfringementRepository;
import gov.stb.tag.repository.ce.CeCaseInfringerRepository;
import gov.stb.tag.repository.ce.CeCaseRecommendationRepository;
import gov.stb.tag.repository.ce.CeCaseRescindRepository;
import gov.stb.tag.repository.ce.CeTaCheckRepository;
import gov.stb.tag.repository.ce.CeTaFieldReportRepository;
import gov.stb.tag.repository.ce.CeTgFieldReportRepository;
import gov.stb.tag.repository.ta.TaKeyExecutiveRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/ce/case")
@Transactional
public class CeCaseController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaKeyExecutiveRepository taKeyExecutiveRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TouristGuideRepository touristGuideRepository;
	@Autowired
	CeCaseRepository ceCaseRepository;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	CeProvisionRepository ceProvisionRepository;
	@Autowired
	CeCaseComplainantRepository ceCaseComplainantRepository;
	@Autowired
	CeCaseInfringerRepository ceCaseInfringerRepository;
	@Autowired
	CeCaseInfringementRepository ceCaseInfringementRepository;
	@Autowired
	CeCaseRecommendationRepository ceCaseRecommendationRepository;
	@Autowired
	CeCaseDecisionRepository ceCaseDecisionRepository;
	@Autowired
	CeTaCheckRepository CeTatiCheckRepository;
	@Autowired
	CeTaFieldReportRepository CeTaFieldReportRepository;
	@Autowired
	CeTgFieldReportRepository CeTgFieldReportRepository;
	@Autowired
	WorkflowRepository workflowRepository;
	@Autowired
	CeCaseAppealRepository ceCaseAppealRepository;
	@Autowired
	CeCaseRescindRepository ceCaseRescindRepository;
	@Autowired
	PaymentRepository paymentRepository;
	@Autowired
	LicenceStatusRepository licenceStatusRepository;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	CeTaskRepository ceTaskRepository;

	@RequestMapping(value = "/view/{taTgType}/load-offender-details/{uenUin}", method = RequestMethod.GET)
	public CeInfringerDto loadOffenderDetails(@PathVariable String taTgType, @PathVariable String uenUin) {

		CeInfringerDto ceInfringerDto = null;

		if (Entities.equals(getUser().getDepartment(), Codes.DepartmentType.TA)) {
			TravelAgent ta = travelAgentRepository.getTaByUen(uenUin);
			if (ta != null) {
				ceInfringerDto = new CeInfringerDto(ta);
			}

			Stakeholder stakeholder = taKeyExecutiveRepository.getKeyExecutiveByUin(uenUin);
			if (stakeholder != null) {
				ceInfringerDto = new CeInfringerDto(stakeholder);
			}

		} else {
			TouristGuide tg = touristGuideRepository.getTouristGuideByUin(uenUin);
			if (tg != null) {
				ceInfringerDto = new CeInfringerDto(tg);
			}
		}

		if (ceInfringerDto == null) {
			CeCaseInfringer ceCaseInfringer = ceCaseInfringerRepository.getCeCaseInfringerByUenUin(uenUin);

			if (ceCaseInfringer != null) {
				ceInfringerDto = new CeInfringerDto(ceCaseInfringer);
			}
		}

		return ceInfringerDto;
	}

	@RequestMapping(value = "/view/ta/search-compliance-checks", method = RequestMethod.GET)
	public ResultDto<CeComplianceCheckDto> getComplianceChecks(CeComplianceCheckSearchDto searchDto) {

		// if (Entities.equals(getUser().getDepartment(), Codes.DepartmentType.TG)) {
		// return CeTgFieldReportRepository.getTgFieldReports(searchDto);
		// }

		return CeTaFieldReportRepository.getTaFieldReports(searchDto);
	}

	@RequestMapping(value = "/view/{taTgType}/{caseId}", method = RequestMethod.GET)
	public CeCasesDto viewCase(@PathVariable String taTgType, @PathVariable Integer caseId) {
		CeCase ceCase = ceCaseRepository.getCeCaseById(caseId);

		if (ceCase == null) {
			throw new ValidationException("Case not found.");
		}

		return populateCeCasesDto(ceCase);
	}

	// save, submit
	@RequestMapping(value = "/{action}", method = RequestMethod.POST)
	public CeCasesDto saveCase(@RequestBody CeCasesDto dto, @PathVariable String action) {
		return saveCaseFromDto(dto, action);
	}

	// save, submit
	@RequestMapping(value = "/{action}/create-ce-task", method = RequestMethod.POST)
	public void createCeTask(@RequestBody CeCasesDto dto, @PathVariable String action) {
		if (!dto.getIsTaskCreated()) {

			// if isFromCreateCaseTask = false, create ce task only if the case is still new
			boolean isTaskRequired = true;
			if (!dto.getCurrentWorkflow().getIsFromCreateCaseTask() && !dto.getIsNew()) {
				isTaskRequired = false;
			}

			if (isTaskRequired) {
				CeCase ceCase = ceCaseRepository.getCeCaseById(dto.getId());

				Workflow workflow = null;
				Integer workflowId = dto.getCurrentWorkflow().getWorkflowId();
				if (workflowId != null) {
					workflow = workflowRepository.getWorkflowById(workflowId);
				}

				CeCaseTaskWorkflowDto currWorkflow = dto.getCurrentWorkflow();
				if (ACTION_SUBMIT.equals(action)
						&& StringUtils.containsAny(currWorkflow.getAppOrWkflwTypeCode(), Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL, Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL)) {
					ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, getTaskTypeByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()),
							getTaskStatusByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()), null, LocalDate.now());
				} else {
					ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, getTaskTypeByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()),
							getTaskStatusByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()), getSlaParameterByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()), null);
				}
			}

		}
	}

	// tag case
	@RequestMapping(value = "/save/tag", method = RequestMethod.POST)
	public CeCasesDto tagCase(@RequestBody CeCasesDto dto) {
		dto = saveCaseFromDto(dto, ACTION_SAVE);

		logger.info("[{}] tag case - case ID: {} Start <", getUser().getLoginId(), dto.getId());
		CeCase taggedCase = ceCaseRepository.getCaseFromCaseNo(dto.getTaggedCaseNo());

		CeCase ceCase = ceCaseRepository.getCeCaseById(dto.getId());
		ceCase.setTaggedCase(taggedCase);
		ceCaseRepository.update(ceCase);

		Set<CeCaseInfringement> infringements = ceCaseHelper.getInfringementsFromCase(ceCase);
		infringements.forEach(inf -> {
			CeCaseRecommendation recomm = inf.getLastRecommendation();
			if (recomm != null && recomm.getWorkflow() != null) {
				recomm.setWorkflow(null);
				ceCaseRecommendationRepository.update(recomm);
			}

			inf.setCeCase(taggedCase);
		});
		ceCaseInfringementRepository.update(infringements);

		// complete current case
		ceTaskHelper.completeCeTaskByCeCase(ceCase, false);

		dto.setTaggedCaseId(taggedCase.getId());
		logger.info("[{}] tag case - case ID: {} End >", getUser().getLoginId(), dto.getId());
		return dto;
	}

	// untag case
	@RequestMapping(value = "/save/untag", method = RequestMethod.POST)
	public CeCasesDto untagCase(@RequestBody CeCasesDto dto) {

		// dto = saveCaseFromDto(dto, ACTION_SAVE);

		logger.info("[{}] untag case - case ID: {} Start <", getUser().getLoginId(), dto.getId());
		CeCase ceCase = ceCaseRepository.getCeCaseById(dto.getId());
		ceCase.setTaggedCase(null);
		ceCaseRepository.update(ceCase);

		Set<CeCaseInfringement> infringements = ceCaseHelper.getInfringementsFromCase(ceCase);
		infringements.forEach(inf -> {
			if (inf.getCeCase() != inf.getCeOriginatingCase()) {
				inf.setCeCase(inf.getCeOriginatingCase());
			}
		});
		ceCaseInfringementRepository.update(infringements);

		// create to recommend ce task once case is untagged
		String workflowType = Codes.TaTgType.TA.equals(ceCase.getTaTgType()) ? Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND : Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND;
		ceTaskHelper.createCeTaskForCeCase(ceCase, null, getTaskTypeByWkflwTypeCode(workflowType), getTaskStatusByWkflwTypeCode(workflowType), getSlaParameterByWkflwTypeCode(workflowType), null);
		logger.info("[{}] untag case - case ID: {} End >", getUser().getLoginId(), dto.getId());
		return dto;
	}

	@RequestMapping(value = "/view/{taTgType}/load-case-task", method = RequestMethod.POST)
	public CeCasesDto loadCaseTask(@PathVariable String taTgType, @RequestBody CeCasesDto dto) {

		Integer currWorkflowId = dto.getCurrentWorkflow().getWorkflowId();

		Workflow workflow = null;
		switch (dto.getCurrentWorkflow().getAppOrWkflwTypeCode()) {
		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
			CeCaseRecommendation recommendation = null;
			if (currWorkflowId != null) {
				List<CeCaseRecommendation> recommendations = ceCaseRecommendationRepository.getRecommendationsByWorkflowId(currWorkflowId);
				if (CollectionUtils.isNotEmpty(recommendations)) {
					recommendation = recommendations.get(0);
				}
			} else if (dto.getId() != null) {
				recommendation = ceCaseRecommendationRepository.getDraftRecommendationByCaseId(dto.getId());
			}

			if (recommendation != null) {
				workflow = recommendation.getWorkflow();
			}
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
			CeCaseDecision decision = null;
			if (currWorkflowId != null) {
				List<CeCaseDecision> decisions = ceCaseDecisionRepository.getDecisionsByWorkflowId(currWorkflowId);
				if (CollectionUtils.isNotEmpty(decisions)) {
					decision = decisions.get(0);
				}
			} else if (dto.getId() != null) {
				decision = ceCaseDecisionRepository.getDraftDecisionByCaseId(dto.getId());
			}

			if (decision != null) {
				workflow = decision.getWorkflow();
			}
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
			CeCaseAppeal appeal = null;
			if (currWorkflowId != null) {
				List<CeCaseAppeal> appeals = ceCaseAppealRepository.getAppealsByWorkflowId(currWorkflowId);
				if (CollectionUtils.isNotEmpty(appeals)) {
					appeal = appeals.get(0);
				}
			} else if (dto.getId() != null) {
				appeal = ceCaseAppealRepository.getDraftAppealByCaseId(dto.getId());
			}

			if (appeal != null) {
				workflow = appeal.getWorkflow();
			}
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
			CeCaseRescind rescind = null;
			if (currWorkflowId != null) {
				List<CeCaseRescind> rescinds = ceCaseRescindRepository.getRescindsByWorkflowId(currWorkflowId);
				if (CollectionUtils.isNotEmpty(rescinds)) {
					rescind = rescinds.get(0);
				}
			} else if (dto.getId() != null) {
				rescind = ceCaseRescindRepository.getDraftRescindByCaseId(dto.getId());
			}

			if (rescind != null) {
				workflow = rescind.getWorkflow();
			}
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_LIFT:

			break;

		}

		if (workflow != null) {
			dto.setCurrentWorkflow(new CeCaseTaskWorkflowDto(workflow, fileHelper, cache, workflowHelper, getUser()));
		}

		return dto;
	}

	// approve, reject, rfa
	@RequestMapping(value = "/{action}/{workflowId}", method = RequestMethod.POST)
	public void process(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer workflowId) {
		logger.info("[{}] {} case task - workflow ID : {}", getUser().getLoginId(), action, workflowId);
		Workflow workflow = workflowRepository.getWorkflowById(workflowId);
		switch (workflow.getType().getCode()) {
		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
			processForRecommendation(action, workflow, dto);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
			processForImposeDecision(action, workflow, dto);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
			processForAppeal(action, workflow, dto);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
			processForRescind(action, workflow, dto);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_LIFT:

			break;

		}
	}

	@RequestMapping(value = "/view/{taTgType}/load-case-task-log/{caseId}", method = RequestMethod.GET)
	public List<CeCaseTaskLogDto> loadCaseTaskLog(@PathVariable String taTgType, @PathVariable Integer caseId) {

		CeCase ceCase = ceCaseRepository.getCeCaseById(caseId);
		Set<CeCaseInfringement> infringements = ceCaseHelper.getInfringementsFromCase(ceCase);
		List<CeCaseInfringer> infringers = ceCaseHelper.getInfringersFromInfringements(infringements);

		List<Integer> infringementIds = infringements.stream().map(CeCaseInfringement::getId).collect(Collectors.toList());

		if (CollectionUtils.isNotEmpty(infringementIds)) {
			// recommendation
			List<CeCaseRecommendation> allRecommendations = ceCaseRecommendationRepository.getAllProcessRecommendationsByInfringementIds(infringementIds);

			// impose decision
			List<CeCaseDecision> allDecisions = ceCaseDecisionRepository.getAllProcessDecisionsByInfringementIds(infringementIds);

			// appeal result
			List<CeCaseAppeal> allAppeals = ceCaseAppealRepository.getAllProcessAppealsByInfringementIds(infringementIds);

			// rescind
			List<CeCaseRescind> allRescinds = ceCaseRescindRepository.getAllProcessRescindsByInfringementIds(infringementIds);

			List<CeCaseTaskLogDto> caseTaskLogs = new ArrayList<>();
			if (ceCase != null && !CollectionUtils.isEmpty(infringers)) {
				for (CeCaseInfringer infringer : infringers) {
					CeCaseTaskLogDto dto = new CeCaseTaskLogDto();
					dto.setOffenderUenUin(infringer.getUenUin());
					dto.setOffenderName(infringer.getName());

					List<CeCaseInfringement> relInfringements = infringements.stream().filter(inf -> Objects.equal(inf.getCeCaseInfringer().getUenUin(), infringer.getUenUin()))
							.collect(Collectors.toList());

					List<Integer> relInfringementIds = relInfringements.stream().map(CeCaseInfringement::getId).collect(Collectors.toList());

					Set<Workflow> workflows = new HashSet<>();
					// recommendation
					List<CeCaseRecommendation> relRecomms = allRecommendations.stream().filter(recomm -> relInfringementIds.contains(recomm.getCeCaseInfringement().getId()))
							.collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(relRecomms)) {
						workflows.addAll(relRecomms.stream().map(CeCaseRecommendation::getWorkflow).collect(Collectors.toSet()));
					}

					// impose decision
					List<CeCaseDecision> relDecis = allDecisions.stream().filter(deci -> relInfringementIds.contains(deci.getCeCaseInfringement().getId())).collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(relDecis)) {
						workflows.addAll(relDecis.stream().map(CeCaseDecision::getWorkflow).collect(Collectors.toSet()));
					}

					// appeal result
					List<CeCaseAppeal> relAppeals = allAppeals.stream().filter(appeal -> relInfringementIds.contains(appeal.getCeCaseInfringement().getId())).collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(relAppeals)) {
						workflows.addAll(relAppeals.stream().map(CeCaseAppeal::getWorkflow).collect(Collectors.toSet()));
					}

					// rescind
					List<CeCaseRescind> relRescinds = allRescinds.stream().filter(rescind -> relInfringementIds.contains(rescind.getCeCaseInfringement().getId())).collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(relRescinds)) {
						workflows.addAll(relRescinds.stream().map(CeCaseRescind::getWorkflow).collect(Collectors.toSet()));
					}

					if (!workflows.isEmpty()) {
						List<CeCaseTaskSummaryDto> caseTaskSummaries = new ArrayList<>();
						for (Workflow workflow : workflows) {
							CeCaseTaskSummaryDto summaryDto = new CeCaseTaskSummaryDto();

							String workflowTypeCode = workflow.getType().getCode();
							summaryDto.setCaseTaskType(new ListableDto(workflowTypeCode, cache.getLabel(workflow.getType(), false)));

							WorkflowAction lastAction = workflow.getLastAction();
							summaryDto.setApprovedDate(lastAction.getCreatedDate());
							summaryDto.setWorkflowId(workflow.getId());
							summaryDto.setCaseTaskStatus(new ListableDto(lastAction.getStatus().getCode(), cache.getLabel(lastAction.getStatus(), false)));

							List<CeProvisionDto> offenceProvisions = new ArrayList<>();
							List<String> taskDetails = new ArrayList<>();
							Set<FileDto> letterIssuances = new HashSet<>();

							switch (workflowTypeCode) {
							case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
							case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
								List<CeCaseRecommendation> recomms = relRecomms.stream().filter(rec -> rec.getWorkflow().getId().equals(workflow.getId())).collect(Collectors.toList());
								for (CeCaseRecommendation recomm : recomms) {
									CeProvision ceProvision = recomm.getCeCaseInfringement().getCeProvision();
									offenceProvisions.add(new CeProvisionDto(cache, ceProvision));

									String taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), recomm.getOutcome(),
											recomm.getPenaltyAmount(), recomm.getPenaltyStatusStartDate(), recomm.getPenaltyStatusEndDate(), null, null, null);
									taskDetails.add(taskDetail);

									File letter = recomm.getLetter();
									if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
										letterIssuances.add(FileDto.buildFromFile(letter, null, fileHelper));
									}
								}
								break;

							case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
							case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
								List<CeCaseDecision> decis = relDecis.stream().filter(rec -> rec.getWorkflow().getId().equals(workflow.getId())).collect(Collectors.toList());
								for (CeCaseDecision deci : decis) {
									CeProvision ceProvision = deci.getCeCaseInfringement().getCeProvision();
									offenceProvisions.add(new CeProvisionDto(cache, ceProvision));

									LocalDate paymentDueDate = deci.getBillExpiryDate() != null ? deci.getBillExpiryDate().toLocalDate() : null;
									String paymentStatus = deci.getPaymentStatus() != null ? deci.getPaymentStatus().getLabel() : null;

									String taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), deci.getOutcome(),
											deci.getPenaltyAmount(), deci.getPenaltyStatusStartDate(), deci.getPenaltyStatusEndDate(), paymentDueDate, paymentStatus, deci.getBillRefNo());
									taskDetails.add(taskDetail);

									File letter = deci.getLetter();
									if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
										letterIssuances.add(FileDto.buildFromFile(letter, null, fileHelper));
									}
								}
								break;

							case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
							case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
								List<CeCaseAppeal> appeals = relAppeals.stream().filter(rec -> rec.getWorkflow().getId().equals(workflow.getId())).collect(Collectors.toList());
								for (CeCaseAppeal appeal : appeals) {
									CeProvision ceProvision = appeal.getCeCaseInfringement().getCeProvision();
									offenceProvisions.add(new CeProvisionDto(cache, ceProvision));

									String billRefNo = appeal.getBillRefNo();
									LocalDate paymentDueDate = appeal.getBillExpiryDate() != null ? appeal.getBillExpiryDate().toLocalDate() : null;
									String paymentStatus = appeal.getPaymentStatus() != null ? appeal.getPaymentStatus().getLabel() : null;
									BigDecimal amount = appeal.getPenaltyAmount();

									if (amount == null && billRefNo != null) {
										PaymentRequest payReq = paymentRepository.getPaymentRequest(billRefNo);
										amount = payReq.getPayableAmount();
									}

									String taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), appeal.getOutcome(), amount,
											appeal.getPenaltyStatusStartDate(), appeal.getPenaltyStatusEndDate(), paymentDueDate, paymentStatus, appeal.getBillRefNo());
									taskDetails.add(taskDetail);

									File letter = appeal.getLetter();
									if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
										letterIssuances.add(FileDto.buildFromFile(letter, null, fileHelper));
									}
								}
								break;

							case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
							case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
								List<CeCaseRescind> rescinds = relRescinds.stream().filter(rec -> rec.getWorkflow().getId().equals(workflow.getId())).collect(Collectors.toList());
								for (CeCaseRescind rescind : rescinds) {
									CeProvision ceProvision = rescind.getCeCaseInfringement().getCeProvision();
									offenceProvisions.add(new CeProvisionDto(cache, ceProvision));

									String taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), null, null, null, null, null, null,
											null);
									taskDetails.add(taskDetail);

									File letter = rescind.getLetter();
									if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
										letterIssuances.add(FileDto.buildFromFile(letter, null, fileHelper));
									}
								}
								break;

							case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:
							case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_LIFT:
								break;
							}

							summaryDto.setOffenceProvisions(offenceProvisions);
							summaryDto.setTaskDetails(taskDetails);
							summaryDto.setLetterIssuances(letterIssuances);
							caseTaskSummaries.add(summaryDto);
						}

						caseTaskSummaries = caseTaskSummaries.stream().sorted(Comparator.comparing(CeCaseTaskSummaryDto::getApprovedDate).reversed()).collect(Collectors.toList());
						dto.setCaseTaskSummary(caseTaskSummaries);
					}

					caseTaskLogs.add(dto);
				}
			}

			return caseTaskLogs;
		}
		return null;
	}

	@RequestMapping(value = "/view/{taTgType}/load-log-details/{workflowTypeCode}/{workflowId}/{caseId}", method = RequestMethod.GET)
	public CeCasesDto loadCaseTaskLogDetail(@PathVariable String taTgType, @PathVariable String workflowTypeCode, @PathVariable Integer workflowId, @PathVariable Integer caseId) {
		logger.info("[{}] view case task log details - case ID: {}; workflow ID: {}; workflow type: {}", getUser().getLoginId(), caseId, workflowId, workflowTypeCode);

		CeCase ceCase = ceCaseRepository.getCeCaseById(caseId);

		if (ceCase == null) {
			throw new ValidationException("Case not found.");
		}

		CeCasesDto dto = new CeCasesDto(ceCase, cache);

		List<CeCaseInfringement> infringements = new ArrayList<>();
		List<CeInfringementDto> infringementDtos = new ArrayList<>();
		Workflow workflow = null;
		switch (workflowTypeCode) {
		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:

			List<CeCaseRecommendation> recommendations = ceCaseRecommendationRepository.getRecommendationsByWorkflowId(workflowId);
			infringements = recommendations.stream().map(CeCaseRecommendation::getCeCaseInfringement).collect(Collectors.toList());

			for (CeCaseInfringement infringement : infringements) {
				CeCaseInfringer ceCaseInfringer = infringement.getCeCaseInfringer();
				CeInfringementDto ceInfringementDto = new CeInfringementDto(ceCaseInfringer, infringement, cache, false, ceCaseHelper);

				CeCaseRecommendation recomm = recommendations.stream().filter(u -> u.getCeCaseInfringement().getId().equals(infringement.getId())).findAny().get();
				CeRecommendationDto recommDto = new CeRecommendationDto(recomm, cache, fileHelper, workflowHelper, infringement.getCeCase().getOic(), true);
				ceInfringementDto.setRecommendation(recommDto);
				workflow = recomm.getWorkflow();

				infringementDtos.add(ceInfringementDto);
			}
			dto.setInfringements(infringementDtos);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
			List<CeCaseDecision> decisions = ceCaseDecisionRepository.getDecisionsByWorkflowId(workflowId);
			infringements = decisions.stream().map(CeCaseDecision::getCeCaseInfringement).collect(Collectors.toList());

			for (CeCaseInfringement infringement : infringements) {
				CeCaseInfringer ceCaseInfringer = infringement.getCeCaseInfringer();
				CeInfringementDto ceInfringementDto = new CeInfringementDto(ceCaseInfringer, infringement, cache, false, ceCaseHelper);

				CeCaseDecision deci = decisions.stream().filter(u -> u.getCeCaseInfringement().getId().equals(infringement.getId())).findAny().get();
				CeDecisionDto deciDto = new CeDecisionDto(deci, cache, fileHelper, workflowHelper, infringement.getCeCase().getOic(), true);

				if (deci.getCeCaseRecommendation() != null) {
					CeCaseRecommendation recomm = ceCaseRecommendationRepository.getRecommendationById(deci.getCeCaseRecommendation().getId());
					CeRecommendationDto recommDto = new CeRecommendationDto(recomm, cache, fileHelper, workflowHelper, infringement.getCeCase().getOic(), true);
					ceInfringementDto.setRecommendation(recommDto);
				}

				ceInfringementDto.setDecision(deciDto);
				workflow = deci.getWorkflow();

				infringementDtos.add(ceInfringementDto);
			}
			dto.setInfringements(infringementDtos);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
			List<CeCaseAppeal> appeals = ceCaseAppealRepository.getAppealsByWorkflowId(workflowId);
			infringements = appeals.stream().map(CeCaseAppeal::getCeCaseInfringement).collect(Collectors.toList());

			for (CeCaseInfringement infringement : infringements) {
				CeCaseInfringer ceCaseInfringer = infringement.getCeCaseInfringer();
				CeInfringementDto ceInfringementDto = new CeInfringementDto(ceCaseInfringer, infringement, cache, false, ceCaseHelper);

				CeCaseAppeal appeal = appeals.stream().filter(u -> u.getCeCaseInfringement().getId().equals(infringement.getId())).findAny().get();
				CeResultDto resultDto = new CeResultDto(appeal, cache, fileHelper, workflowHelper, infringement.getCeCase().getOic());

				if (appeal.getCeCaseDecision() != null) {
					CeCaseDecision deci = ceCaseDecisionRepository.getDecisionById(appeal.getCeCaseDecision().getId());
					CeDecisionDto deciDto = new CeDecisionDto(deci, cache, fileHelper, workflowHelper, infringement.getCeCase().getOic(), true);
					ceInfringementDto.setDecision(deciDto);

					if (deci.getCeCaseRecommendation() != null) {
						CeCaseRecommendation recomm = ceCaseRecommendationRepository.getRecommendationById(deci.getCeCaseRecommendation().getId());
						CeRecommendationDto recommDto = new CeRecommendationDto(recomm, cache, fileHelper, workflowHelper, infringement.getCeCase().getOic(), true);
						ceInfringementDto.setRecommendation(recommDto);
					}
				}

				ceInfringementDto.setResult(resultDto);
				workflow = appeal.getWorkflow();

				infringementDtos.add(ceInfringementDto);
			}
			dto.setInfringements(infringementDtos);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
			List<CeCaseRescind> rescinds = ceCaseRescindRepository.getRescindsByWorkflowId(workflowId);
			infringements = rescinds.stream().map(CeCaseRescind::getCeCaseInfringement).collect(Collectors.toList());

			for (CeCaseInfringement infringement : infringements) {
				CeCaseInfringer ceCaseInfringer = infringement.getCeCaseInfringer();
				CeInfringementDto ceInfringementDto = new CeInfringementDto(ceCaseInfringer, infringement, cache, false, ceCaseHelper);

				CeCaseRescind rescind = rescinds.stream().filter(u -> u.getCeCaseInfringement().getId().equals(infringement.getId())).findAny().get();
				CeRescindDto rescindDto = new CeRescindDto(rescind, cache, fileHelper, workflowHelper, infringement.getCeCase().getOic(), true);

				ceInfringementDto.setRescind(rescindDto);
				workflow = rescind.getWorkflow();

				infringementDtos.add(ceInfringementDto);
			}
			dto.setInfringements(infringementDtos);
			break;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_LIFT:

			break;

		}

		if (workflow != null) {
			dto.setCurrentWorkflow(new CeCaseTaskWorkflowDto(workflow, fileHelper, cache, workflowHelper, getUser()));
		}

		return dto;
	}

	@RequestMapping(value = "/view/{taTgType}/relevant-infringements", method = RequestMethod.POST)
	public CeCasesDto reloadRelevantInfringements(@PathVariable String taTgType, @RequestBody CeCasesDto dto) {

		if (CollectionUtils.isNotEmpty(dto.getInfringements())) {
			List<CeInfringementDto> infringementDtos = dto.getInfringements();

			List<String> uenUins = infringementDtos.stream().map(CeInfringementDto::getOffenderUenUin).collect(Collectors.toList());

			List<CeCaseInfringer> othInfringers = ceCaseInfringerRepository.getOtherInfringersByUenUinsAndCaseId(uenUins, dto.getId());
			setOtherInfringements(othInfringers, dto);
		}

		return dto;
	}

	private CeCasesDto saveCaseFromDto(CeCasesDto dto, String action) {
		logger.info("[{}] save Case - case ID:[{}] Start <", getUser().getLoginId(), dto.getId());
		validateInfringements(dto, action);
		CeCase ceCase = saveOrUpdateCeCase(dto);
		saveOrUpdateComplainants(dto, ceCase);
		saveOrUpdateComplianceChecks(dto, ceCase);
		saveOrUpdateOtherAttachments(dto, ceCase);
		Workflow workflow = saveOrUpdateWorkflow(dto, action);
		saveOrUpdateInfringements(dto, ceCase, workflow, action);

		CeCaseTaskWorkflowDto currWorkflow = dto.getCurrentWorkflow();
		if (ACTION_SUBMIT.equals(action)) {
			if (Entities.equals(ceCase.getStatus(), Codes.CeCaseStatus.CE_CASE_CLOSED)) {
				logger.info("[{}] Re-open Case - case ID:[{}]", getUser().getLoginId(), ceCase.getId());
				ceCase.setStatus(cache.getStatus(Codes.CeCaseStatus.CE_CASE_LIVE));
			}
			workflowHelper.forward(workflow, true, currWorkflow.getWorkflowAssessment(), currWorkflow.getSupporterId(), currWorkflow.getApproverId(), true, true);
		}

		if (ACTION_EDIT.equals(action) && workflow != null) {
			workflow.setDescription(currWorkflow.getWorkflowAssessment());
			workflowHelper.edit(workflow, currWorkflow.getWorkflowAssessment());
		}

		if (workflow != null) {
			currWorkflow.setWorkflowId(workflow.getId());
		}

		dto.setId(ceCase.getId());
		ceCaseHelper.processCeCase(ceCase);
		ceCaseRepository.saveOrUpdate(ceCase);

		logger.info("[{}] save Case - case ID:[{}] End >", getUser().getLoginId(), dto.getId());
		return dto;
	}

	private void validateInfringements(CeCasesDto dto, String action) {
		logger.info("[{}] validate infringement", getUser().getLoginId());

		boolean hasInvolvedInfringements = false;
		if (CollectionUtils.isNotEmpty(dto.getInfringements())) {

			switch (dto.getCurrentWorkflow().getAppOrWkflwTypeCode()) {
			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
				for (CeInfringementDto infDto : dto.getInfringements()) {
					if (infDto.getRecommendation() != null) {
						CeRecommendationDto recommDto = infDto.getRecommendation();
						if (recommDto.getRecommendation() != null) {
							CeCaseRecommendation recomm = new CeCaseRecommendation();

							if (recommDto.getRecommendationId() == null) {
								recomm.setNewOrEdited(true);
								hasInvolvedInfringements = true;
							} else {
								recomm = ceCaseRecommendationRepository.getRecommendationById(recommDto.getRecommendationId());

								Workflow currRecommWorkflow = recomm.getWorkflow();
								if (currRecommWorkflow == null || currRecommWorkflow.getLastAction() == null) {
									recomm.setNewOrEdited(true);
									hasInvolvedInfringements = true;
								} else {

									Status lastActionStatus = currRecommWorkflow.getLastAction().getStatus();
									if (lastActionStatus != null
											&& Entities.anyEquals(lastActionStatus, Codes.Statuses.CE_WKFLW_ROUTED, Codes.Statuses.CE_WKFLW_PEND_APPR, Codes.Statuses.CE_WKFLW_PEND_SUPP)) {
										recomm.setNewOrEdited(true);
										hasInvolvedInfringements = true;
									}

									// to create new recommendation if
									// 1. current recommendation is approved / rejected
									else if (validateNewRecommIsRequired(recomm, infDto) || ACTION_SUBMIT.equals(action)) {
										recomm = new CeCaseRecommendation();
										recomm.setNewOrEdited(true);
										hasInvolvedInfringements = true;
									}

								}

							}

							recommDto.setCeCaseRecommendation(recomm);
						}

					}
				}
				break;

			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
				for (CeInfringementDto infDto : dto.getInfringements()) {
					if (infDto.getDecision() != null) {
						CeDecisionDto decisionDto = infDto.getDecision();

						// do not create ce_case_decisions if the recommendation is NOD/NFA/Caution/Circular/Counsel/Open IP/Tag IP
						CeRecommendationDto recommDto = infDto.getRecommendation();
						if (recommDto.getRecommendation() != null && isCompleteOutcome(recommDto.getRecommendation().getKeyString())) {
							continue;
						}

						CeCaseDecision decision = new CeCaseDecision();

						if (decisionDto.getDecisionId() == null) {
							decision.setNewOrEdited(true);
							hasInvolvedInfringements = true;
						} else {
							decision = ceCaseDecisionRepository.getDecisionById(decisionDto.getDecisionId());

							Workflow currDecWorkflow = decision.getWorkflow();
							if (currDecWorkflow == null || currDecWorkflow.getLastAction() == null) {
								decision.setNewOrEdited(true);
								hasInvolvedInfringements = true;
							} else {

								Status lastActionStatus = currDecWorkflow.getLastAction().getStatus();
								if (lastActionStatus != null
										&& Entities.anyEquals(lastActionStatus, Codes.Statuses.CE_WKFLW_ROUTED, Codes.Statuses.CE_WKFLW_PEND_APPR, Codes.Statuses.CE_WKFLW_PEND_SUPP)) {
									decision.setNewOrEdited(true);
									hasInvolvedInfringements = true;
								}

								// to create new decision if
								// 1. current decision is approved / rejected
								else if (validateNewDecisionIsRequired(decision, infDto) || ACTION_SUBMIT.equals(action)) {
									CeCaseDecision newDeci = new CeCaseDecision();
									newDeci.setNewOrEdited(true);

									if (StringUtils.containsAny(decisionDto.getDecision().getKeyString(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {
										newDeci.setBillRefNo(decision.getBillRefNo());
										newDeci.setBillExpiryDate(decision.getBillExpiryDate());
									}

									decision = newDeci;
									hasInvolvedInfringements = true;
								}
							}

						}
						decisionDto.setCeCaseDecision(decision);
					}
				}
				break;

			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
				for (CeInfringementDto infDto : dto.getInfringements()) {
					if (infDto.getResult() != null) {
						CeResultDto resultDto = infDto.getResult();

						// do not create ce_case_appeals if the recommendation/decision is NOD/NFA/Caution/Circular/Counsel/Open IP/Tag IP
						CeRecommendationDto recommDto = infDto.getRecommendation();
						CeDecisionDto deciDto = infDto.getDecision();
						if ((recommDto.getRecommendation() != null && isCompleteOutcome(recommDto.getRecommendation().getKeyString()))
								|| (deciDto.getDecision() != null && isCompleteOutcome(deciDto.getDecision().getKeyString()))) {
							continue;
						}

						CeCaseAppeal appeal = new CeCaseAppeal();

						if (resultDto.getResultId() == null) {
							appeal.setNewOrEdited(true);
							hasInvolvedInfringements = true;
						} else {
							appeal = ceCaseAppealRepository.getAppealById(resultDto.getResultId());

							Workflow currAppealWorkflow = appeal.getWorkflow();
							if (currAppealWorkflow == null || currAppealWorkflow.getLastAction() == null) {
								appeal.setNewOrEdited(true);
								hasInvolvedInfringements = true;
							} else {

								Status lastActionStatus = currAppealWorkflow.getLastAction().getStatus();
								if (lastActionStatus != null
										&& Entities.anyEquals(lastActionStatus, Codes.Statuses.CE_WKFLW_ROUTED, Codes.Statuses.CE_WKFLW_PEND_APPR, Codes.Statuses.CE_WKFLW_PEND_SUPP)) {
									appeal.setNewOrEdited(true);
									hasInvolvedInfringements = true;
								}

								// to create new appeal if
								// 1. current appeal is approved / rejected
								else if (validateNewAppealIsRequired(appeal, infDto) || ACTION_SUBMIT.equals(action)) {
									CeCaseAppeal newAppeal = new CeCaseAppeal();
									newAppeal.setNewOrEdited(true);

									if (StringUtils.containsAny(resultDto.getNewDecision().getKeyString(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {
										newAppeal.setBillRefNo(appeal.getBillRefNo());
										newAppeal.setBillExpiryDate(appeal.getBillExpiryDate());
									}

									appeal = newAppeal;
									hasInvolvedInfringements = true;
								}
							}
						}

						resultDto.setCeCaseAppeal(appeal);

					}
				}
				break;

			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
				for (CeInfringementDto infDto : dto.getInfringements()) {
					CeRescindDto rescindDto = infDto.getRescind();
					if (rescindDto != null) {
						CeCaseRescind rescind = new CeCaseRescind();

						if (rescindDto.getRescindId() == null) {
							rescind.setNewOrEdited(true);
							hasInvolvedInfringements = true;
						} else {
							rescind = ceCaseRescindRepository.getRescindById(rescindDto.getRescindId());

							Workflow currRescWorkflow = rescind.getWorkflow();
							if (currRescWorkflow == null || currRescWorkflow.getLastAction() == null) {
								rescind.setNewOrEdited(true);
								hasInvolvedInfringements = true;
							} else {

								if (Entities.anyEquals(currRescWorkflow.getLastAction().getStatus(), Codes.Statuses.CE_WKFLW_ROUTED, Codes.Statuses.CE_WKFLW_PEND_APPR,
										Codes.Statuses.CE_WKFLW_PEND_SUPP)) {
									rescind.setNewOrEdited(true);
									hasInvolvedInfringements = true;
								}

								// to create new rescind if forward for approval
								else if (ACTION_SUBMIT.equals(action)) {
									rescind = new CeCaseRescind();
									rescind.setNewOrEdited(true);
									hasInvolvedInfringements = true;
								}
							}

						}

						rescindDto.setCeCaseRescind(rescind);
					}
				}
				break;

			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_LIFT:

				break;

			}

		}

		dto.setWorkflowRequired(hasInvolvedInfringements);

	}

	private CeCase saveOrUpdateCeCase(CeCasesDto dto) {
		logger.info("[{}] save or update ce case", getUser().getLoginId());
		CeCase ceCase = new CeCase();
		if (dto.getId() != null) {
			ceCase = ceCaseRepository.get(CeCase.class, dto.getId());
		} else {
			ceCase.setTaTgType(dto.getTaTgType());
			ceCase.setStatus(cache.getStatus(Codes.CeCaseStatus.CE_CASE_LIVE));
			ceCase.setIsIp(false);
		}
		if (dto.getIsPendingApproval() == null || !dto.getIsPendingApproval()) {
			ceCase.setOic(getUser());
		}
		ceCase.setCrmRefNo(dto.getCrmNo());
		ceCase.setAssessment(dto.getAssessment());
		ceCase.setMitigatingFactors(dto.getMitigatingFactors());
		ceCase.setAggravatingFactors(dto.getAggravatingFactors());
		ceCaseRepository.saveOrUpdate(ceCase);
		return ceCase;
	}

	private void saveOrUpdateComplainants(CeCasesDto dto, CeCase ceCase) {
		logger.info("[{}] save or update complainants", getUser().getLoginId());
		if (CollectionUtils.isNotEmpty(dto.getComplainants())) {
			List<FileDto> deletedFiles = new ArrayList<>();
			List<CeCaseComplainant> complainants = new ArrayList<CeCaseComplainant>();
			dto.getComplainants().forEach(u -> {
				CeCaseComplainant complainant = new CeCaseComplainant();
				if (u.getId() != null) {
					complainant = ceCaseRepository.get(CeCaseComplainant.class, u.getId());
				}
				complainant.setName(u.getName());
				complainant.setContactNo(u.getContactNo());
				complainant.setEmailAddress(u.getEmailAddress());
				// complainant.setAddress(u.getAddress());
				Address complainantAddress = complainant.getAddress();
				if (u.getResidentialType() != null && (u.getPostalCode() != null || u.getForeignLine1() != null)) {
					Address addr = null;
					if (Codes.Types.ADDR_LOCAL.equals(u.getResidentialType())) {
						addr = AddressDto.buildAddressFromDto(complainantAddress != null ? complainantAddress : new Address(), cache.getType(u.getResidentialType()), u.getStreet(), u.getBuilding(),
								u.getBlock(), u.getLevel(), u.getUnit(), u.getPostalCode(), null, null, null);
					} else {
						addr = AddressDto.buildAddressFromDto(complainantAddress != null ? complainantAddress : new Address(), cache.getType(u.getResidentialType()), null, null, null, null, null,
								null, u.getForeignLine1(), u.getForeignLine2(), u.getForeignLine3());
					}
					ceCaseComplainantRepository.saveOrUpdate(addr);
					complainant.setAddress(addr);
				} else {
					if (complainantAddress != null) {
						complainant.setAddress(null);
					}
				}

				complainant.setIsDeleted(false);
				complainant.setType(cache.getType(Codes.ComplainantType.CE_COMPLAINANT_PUBLIC));
				if (CollectionUtils.isNotEmpty(u.getAttachment())) {
					List<File> files = fileRepository.getFiles(u.getAttachment().stream().map(FileDto::getId).collect(Collectors.toList()));
					complainant.setFiles(new HashSet<File>(files));
				} else {
					complainant.setFiles(null);
				}

				if (u.getDeletedAttachment() != null) {
					deletedFiles.addAll(u.getDeletedAttachment());
				}

				complainant.setCeCase(ceCase);

				complainants.add(complainant);

			});
			fileHelper.deleteAllFiles(deletedFiles);
			ceCaseComplainantRepository.saveOrUpdate(complainants);
		}

		if (CollectionUtils.isNotEmpty(dto.getDeletedComplainants())) {
			List<CeCaseComplainant> complainants = ceCaseComplainantRepository
					.getCeCaseComplainantsByIds(dto.getDeletedComplainants().stream().map(CeComplainantDto::getId).collect(Collectors.toList()));

			List<File> complainantFiles = new ArrayList<>();
			complainants.stream().filter(u -> CollectionUtils.isNotEmpty(u.getFiles())).forEach(u -> {
				complainantFiles.addAll(u.getFiles());
			});
			List<File> files = fileRepository.getFiles(complainantFiles.stream().map(File::getId).collect(Collectors.toList()));

			complainants.forEach(u -> u.setIsDeleted(true));
			files.forEach(u -> u.setIsDeleted(true));
		}
	}

	private void saveOrUpdateInfringements(CeCasesDto dto, CeCase ceCase, Workflow workflow, String action) {
		logger.info("[{}] save or update infringements", getUser().getLoginId());
		if (CollectionUtils.isNotEmpty(dto.getInfringements())) {

			LocalDate letterIssuanceDate = null;
			LocalDate appealRespondByDate = null;
			LocalDate respondedDate = null;
			LocalDate showCauseDate = null;
			Type appealResult = null;
			Workflow latestWorkflow = workflow;

			Map<String, CeCaseInfringer> infringerMap = new HashMap<>();
			for (CeInfringementDto u : dto.getInfringements()) {

				// process infringer
				CeCaseInfringer infringer = new CeCaseInfringer();
				String uenUin = u.getOffenderUenUin();
				if (infringerMap.containsKey(uenUin)) {
					infringer = infringerMap.get(uenUin);
				} else {

					if (u.getOffenderId() != null) {
						infringer = ceCaseInfringerRepository.getCeCaseInfringerById(u.getOffenderId());
					}

					if (u.getLicenceId() != null) {
						Licence licence = ceCaseInfringerRepository.get(Licence.class, u.getLicenceId());
						infringer.setLicence(licence);
					}

					infringer.setName(u.getOffenderName());
					infringer.setUenUin(uenUin);
					infringer.setCeCase(ceCase);
					infringer.setIsDeleted(false);
					infringer.setIdType(cache.getType(Codes.TaTgType.TA.equals(dto.getTaTgType()) ? Codes.defendantIdType.ENTITY : Codes.defendantIdType.INDIVIDUAL));
					ceCaseInfringerRepository.saveOrUpdate(infringer);

					infringerMap.put(uenUin, infringer);
				}

				// process infringements
				CeCaseInfringement ceCaseInfringement = new CeCaseInfringement();
				if (u.getInfringementId() != null) {
					ceCaseInfringement = ceCaseInfringementRepository.getCeCaseInfringementById(u.getInfringementId());
				} else {
					ceCaseInfringement.setCeCase(ceCase);
					ceCaseInfringement.setCeOriginatingCase(ceCase);
					ceCaseInfringement.setCeCaseInfringer(infringer);
					ceCaseInfringement.setIsDeleted(false);
					ceCaseInfringement.setIsConcluded(false);
				}

				ceCaseInfringement.setInfringedDate(u.getOffenceDate());
				if (u.getOffenceProvision() != null) {
					ceCaseInfringement.setCeProvision(ceProvisionRepository.get(CeProvision.class, u.getOffenceProvision().getId()));
				}
				ceCaseInfringementRepository.saveOrUpdate(ceCaseInfringement);

				switch (dto.getCurrentWorkflow().getAppOrWkflwTypeCode()) {
				case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
				case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
					CeCaseRecommendation recomm = saveOrUpdateRecommendation(ceCase, u, ceCaseInfringement, dto.getInfringements(), workflow, action);

					if (recomm != null) {
						if (StringUtils.equalsAny(action, ACTION_SUBMIT, ACTION_EDIT)) {
							ceCaseInfringement.setLastRecommendation(recomm);
							ceCaseInfringementRepository.saveOrUpdate(ceCaseInfringement);
						}

						if (recomm.isLetterIssueDateChanged() && recomm.getLetterIssuanceDate() != null) {
							letterIssuanceDate = getLatestDate(letterIssuanceDate, recomm.getLetterIssuanceDate());
						}

						if (latestWorkflow == null) {
							latestWorkflow = recomm.getWorkflow();
						}

					}
					break;

				case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
				case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
					CeCaseDecision decision = saveOrUpdateDecision(u, ceCaseInfringement, dto.getInfringements(), workflow, action);

					if (decision != null) {
						if (StringUtils.equalsAny(action, ACTION_SUBMIT, ACTION_EDIT)) {
							ceCaseInfringement.setLastDecision(decision);
							ceCaseInfringementRepository.saveOrUpdate(ceCaseInfringement);
						}

						if (decision.isShowCauseDateChanged() && decision.getShowCauseDate() != null) {
							showCauseDate = getLatestDate(showCauseDate, decision.getShowCauseDate());
						}

						if (decision.getLetterIssuanceDate() != null) {
							letterIssuanceDate = getLatestDate(letterIssuanceDate, decision.getLetterIssuanceDate());
						}

						if (latestWorkflow == null) {
							latestWorkflow = decision.getWorkflow();
						}

					}
					break;

				case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
				case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
					CeCaseAppeal appeal = saveOrUpdateAppealResult(u, ceCaseInfringement, dto.getInfringements(), workflow, action);

					if (appeal != null) {
						if (appeal.getAppealRespondByDate() != null) {
							appealRespondByDate = getLatestDate(appealRespondByDate, appeal.getAppealRespondByDate());
						}

						if (appeal.getRespondedDate() != null) {
							respondedDate = getLatestDate(respondedDate, appeal.getRespondedDate());
						}

						if (appeal.getResult() != null) {
							appealResult = appeal.getResult();
						}

					}

					break;

				case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
				case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
					CeCaseRescind rescind = saveOrUpdateRescind(u, ceCaseInfringement, dto.getInfringements(), workflow, action);

					if (rescind != null) {

						if (!rescind.isNewOrEdited()) {
							dto.setIsTaskCreated(true);
						}

						if (rescind.getLetterIssuanceDate() != null) {
							letterIssuanceDate = rescind.getLetterIssuanceDate();
						}

						if (latestWorkflow == null) {
							latestWorkflow = rescind.getWorkflow();
						}
					}
					break;

				case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:
				case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_LIFT:

					break;

				}

			}

			// if appeal result is no appeal / rejected / acceded
			// sla expiry date will be 0 days
			//
			// if appeal result is in progress
			// there is STB responded date, sla expiry date will be responded Date + MTI respond SLA
			// there is no responded date but respond by date, sla expiry date will be respond by date
			// user submit for approval, sla expiry date will follow Appeal sla
			if (appealResult != null && !ACTION_SUBMIT.equals(action)) {
				if (Entities.equals(appealResult, Codes.CeAppealResult.CE_APPEAL_RESULT_PEND)) {
					if (!Entities.anyEquals(ceCase.getStatus(), Codes.CeCaseStatus.CE_CASE_CLOSED)) {
						if (respondedDate != null) {
							dto.setIsTaskCreated(true);
							ceTaskHelper.createCeTaskForCeCase(ceCase, null, Codes.CeTaskTypes.CE_TASK_PEND_MTI, Codes.CeTaskStatus.CE_TASK_MTI_PENDING, Codes.SystemParameters.CE_SLA_MTI_RESPOND,
									respondedDate);
						} else if (appealRespondByDate != null) {
							dto.setIsTaskCreated(true);
							ceTaskHelper.createCeTaskForCeCase(ceCase, null, Codes.CeTaskTypes.CE_TASK_REPLY_MTI, Codes.CeTaskStatus.CE_TASK_TO_REPLY_MTI, null, appealRespondByDate);
						}
					}
				} else {
					dto.setIsTaskCreated(true);
					CeCaseTaskWorkflowDto currWorkflow = dto.getCurrentWorkflow();
					ceTaskHelper.createCeTaskForCeCase(ceCase, null, getTaskTypeByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()),
							getTaskStatusByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()), null, LocalDate.now());
				}
			}

			// for impose decision
			// if there is show cause date, sla expiry date will be show cause date + impose decision sla
			// if there is no show cause date, sla expiry date will be impose decision sla
			if (showCauseDate != null) {
				CeCaseTaskWorkflowDto currWorkflow = dto.getCurrentWorkflow();
				ceTaskHelper.createCeTaskForCeCase(ceCase, null, getTaskTypeByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()), getTaskStatusByWkflwTypeCode(currWorkflow.getAppOrWkflwTypeCode()),
						Codes.TaTgType.TA.equals(dto.getTaTgType()) ? Codes.SystemParameters.CE_TA_SLA_IMPOSE_DECISION_WITH_SHOW_CAUSE
								: Codes.SystemParameters.CE_TG_SLA_IMPOSE_DECISION_WITH_SHOW_CAUSE,
						showCauseDate);
			}

			// if letter issuance date is updated
			// only applicable for recommendation, impose decision
			if (letterIssuanceDate != null) {
				createCeTaskAfterLetterIssued(latestWorkflow, ceCase, dto, letterIssuanceDate);
			}
		}

		if (CollectionUtils.isNotEmpty(dto.getDeletedInfringements())) {
			List<CeCaseInfringement> deletedInfringements = ceCaseInfringementRepository
					.getCeCaseInfringementsByIds(dto.getDeletedInfringements().stream().map(CeInfringementDto::getInfringementId).collect(Collectors.toList()));

			List<Integer> checkedOffenderIds = new ArrayList<>();
			List<CeCaseInfringer> deletedInfringers = new ArrayList<>();
			dto.getDeletedInfringements().forEach(u -> {
				if (!checkedOffenderIds.contains(u.getOffenderId())) {
					CeCaseInfringer infringer = ceCaseInfringerRepository.getCeCaseInfringerById(u.getOffenderId());

					if (infringer != null) {
						if (CollectionUtils.isNotEmpty(infringer.getCeCaseInfringements())) {
							List<CeCaseInfringement> infringements = infringer.getCeCaseInfringements().stream().filter(infringement -> !infringement.getIsDeleted()).collect(Collectors.toList());

							List<CeCaseInfringement> particularDeletedInfringements = deletedInfringements.stream().filter(del -> del.getCeCaseInfringer().getId().equals(infringer.getId()))
									.collect(Collectors.toList());

							if (infringements.size() == particularDeletedInfringements.size()) {
								deletedInfringers.add(infringer);
							}
						}

						checkedOffenderIds.add(u.getOffenderId());
					}
				}
			});

			deletedInfringements.forEach(u -> u.setIsDeleted(true));
			deletedInfringers.forEach(u -> u.setIsDeleted(true));
			ceCaseInfringementRepository.saveOrUpdate(deletedInfringements);
			ceCaseInfringerRepository.saveOrUpdate(deletedInfringers);
		}

		// return involvedInfringements;
	}

	private void saveOrUpdateComplianceChecks(CeCasesDto dto, CeCase ceCase) {

		List<CeComplianceCheckDto> complianceChecks = dto.getComplianceChecks();
		if (CollectionUtils.isNotEmpty(complianceChecks)) {
			logger.info("[{}] save or update compliance checks - size {}", getUser().getLoginId(), complianceChecks.size());
			Optional<CeComplianceCheckDto> tgFieldReportOptional = complianceChecks.stream().filter(u -> Codes.ComplianceCheckFieldReportType.TG_FIELD_REPORT.equals(u.getType())).findFirst();
			if (tgFieldReportOptional.isPresent()) {
				CeTgFieldReport ceTgFieldReport = CeTgFieldReportRepository.get(CeTgFieldReport.class, tgFieldReportOptional.get().getId());
				ceCase.setCeTgFieldReport(ceTgFieldReport);
			} else {
				ceCase.setCeTgFieldReport(null);
			}

			List<CeComplianceCheckDto> taFieldReports = complianceChecks.stream().filter(u -> Codes.ComplianceCheckFieldReportType.TA_FIELD_REPORT.equals(u.getType())).collect(Collectors.toList());

			if (CollectionUtils.isNotEmpty(taFieldReports)) {
				List<CeTaFieldReport> ceTaFieldReports = CeTaFieldReportRepository.getAllCeTaFieldReportsByIds(taFieldReports.stream().map(CeComplianceCheckDto::getId).collect(Collectors.toList()));
				ceTaFieldReports.forEach(u -> u.setCeCase(ceCase));
				CeTaFieldReportRepository.save(ceTaFieldReports);
			}
		}

		// deleted compliance checks only applicable for TA
		List<CeComplianceCheckDto> deletedComplianceChecks = dto.getDeletedComplianceChecks();
		if (CollectionUtils.isNotEmpty(deletedComplianceChecks)) {
			logger.info("[{}] delete compliance checks - size {}", getUser().getLoginId(), deletedComplianceChecks.size());
			List<CeComplianceCheckDto> taDeletedFieldReports = deletedComplianceChecks.stream().filter(u -> Codes.ComplianceCheckFieldReportType.TA_FIELD_REPORT.equals(u.getType()))
					.collect(Collectors.toList());

			if (CollectionUtils.isNotEmpty(taDeletedFieldReports)) {
				List<CeTaFieldReport> ceTaFieldReports = CeTaFieldReportRepository
						.getAllCeTaFieldReportsByIds(taDeletedFieldReports.stream().map(CeComplianceCheckDto::getId).collect(Collectors.toList()));
				ceTaFieldReports.forEach(u -> u.setCeCase(null));
				CeTaFieldReportRepository.save(ceTaFieldReports);
			}
		}
	}

	private Workflow saveOrUpdateWorkflow(CeCasesDto dto, String action) {

		if (dto.getWorkflowRequired()) {
			logger.info("[{}] save or update workflow", getUser().getLoginId());
			CeCaseTaskWorkflowDto currWorkflow = dto.getCurrentWorkflow();
			if (currWorkflow != null) {

				// supporter ID and approver ID must be null if data is not passed from case task dialog
				if (currWorkflow.getSupporterId() != null || currWorkflow.getApproverId() != null) {
					Workflow workflow = new Workflow();
					if (currWorkflow.getWorkflowId() != null) {
						workflow = workflowRepository.getWorkflowById(currWorkflow.getWorkflowId());
					} else {
						workflow = workflowHelper.saveNewWorkflow(currWorkflow.getAppOrWkflwTypeCode(), currWorkflow.getWorkflowAssessment(), null, null, false, null);
					}
					workflow.setIsDraft(ACTION_SAVE.equals(action) ? true : false);

					// temporary save in workflow description.
					// Once submit for approval, workflow assessment will become internal remarks of workflow action
					workflow.setDescription(currWorkflow.getWorkflowAssessment());
					workflowRepository.saveOrUpdate(workflow);

					if (CollectionUtils.isNotEmpty(currWorkflow.getWorkflowFiles())) {
						List<Integer> fileIds = currWorkflow.getWorkflowFiles().stream().map(FileDto::getId).collect(Collectors.toList());
						List<File> files = fileRepository.getFiles(fileIds);
						List<WorkflowFile> workflowFiles = fileRepository.getWorkflowFilesByFileIds(fileIds);
						for (File file : files) {
							FileDto fileDto = currWorkflow.getWorkflowFiles().stream().filter(u -> u.getId().equals(file.getId())).findAny().get();
							String docType = fileDto.getDocType();
							Optional<WorkflowFile> workflowFileOptional = workflowFiles.stream().filter(wk -> wk.getFile().getId().equals(file.getId())).findAny();

							file.setDescription(fileDto.getDescription());
							fileHelper.saveWorkflowFileFromFile(workflow, file, docType, workflowFileOptional.isPresent() ? workflowFileOptional.get() : null);
						}
					}

					if (CollectionUtils.isNotEmpty(currWorkflow.getDeletedWorkflowFiles())) {
						List<WorkflowFile> wkFiles = fileRepository.getWorkflowFilesByFileIds(currWorkflow.getDeletedWorkflowFiles().stream().map(FileDto::getId).collect(Collectors.toList()));
						if (CollectionUtils.isNotEmpty(wkFiles)) {
							wkFiles.forEach(wf -> fileHelper.deleteWorkflowFileByWorkflowFileId(wf.getId()));
						}
					}

					return workflowHelper.saveOrUpdateStepAssignment(workflow, currWorkflow.getSupporterId(), currWorkflow.getApproverId());
				} else if (currWorkflow.getWorkflowId() != null) {
					return workflowRepository.getWorkflowById(currWorkflow.getWorkflowId());
				}
			}
		}

		return null;
	}

	private void saveOrUpdateOtherAttachments(CeCasesDto dto, CeCase ceCase) {
		if (CollectionUtils.isNotEmpty(dto.getOthAttachments())) {
			List<File> files = fileRepository.getFiles(dto.getOthAttachments().stream().map(FileDto::getId).collect(Collectors.toList()));
			for (File file : files) {
				FileDto fDto = dto.getOthAttachments().stream().filter(u -> u.getId().equals(file.getId())).findFirst().get();
				file.setDescription(fDto.getDescription());
			}
			ceCase.setFiles(new HashSet<File>(files));
		}

		if (CollectionUtils.isNotEmpty(dto.getOthDeletedAttachments())) {
			fileHelper.deleteAllFiles(dto.getOthDeletedAttachments());
		}
	}

	private CeCaseRecommendation saveOrUpdateRecommendation(CeCase ceCase, CeInfringementDto dto, CeCaseInfringement ceCaseInfringement, List<CeInfringementDto> infringements, Workflow workflow,
			String action) {
		logger.info("[{}] infringement ID : {}", getUser().getLoginId(), ceCaseInfringement.getId());
		if (!ceCaseInfringement.getIsConcluded()) {
			CeRecommendationDto recommDto = dto.getRecommendation();
			if (recommDto != null && recommDto.getRecommendation() != null) {
				CeCaseRecommendation recomm = recommDto.getCeCaseRecommendation();
				if (recomm != null) {
					logger.info("[{}] save or update recommendation - recommendation ID : {}", getUser().getLoginId(), recomm.getId());

					if (recomm.isNewOrEdited() && recomm.getWorkflow() == null) {
						recomm.setWorkflow(workflow);
					}
					recomm.setCeCaseInfringement(ceCaseInfringement);
					recomm.setToEmailLetter(recommDto.getToEmailLetter() == null ? false : recommDto.getToEmailLetter());
					recomm.setOutcome(cache.getType(recommDto.getRecommendation().getKey().toString()));
					if (Entities.anyEquals(recomm.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {
						setRecommendationPenaltyDetails(recomm, recommDto.getPenaltyAmount(), null, null, null);
					} else if (Entities.anyEquals(recomm.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_SUSPEND)) {
						setRecommendationPenaltyDetails(recomm, null, recommDto.getPenaltyStartDate(), recommDto.getPenaltyEndDate(), null);
					} else if (Entities.anyEquals(recomm.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
						setRecommendationPenaltyDetails(recomm, null, recommDto.getPenaltyStartDate(), null, null);
					} else if (Entities.anyEquals(recomm.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_TAG_IP)) {
						setRecommendationPenaltyDetails(recomm, null, null, null, recommDto.getTaggedIpCaseNo());
					} else {
						setRecommendationPenaltyDetails(recomm, null, null, null, null);
					}

					if (recommDto.getLetterIssuance() != null) {
						recomm.setLetter(fileRepository.getFile(recommDto.getLetterIssuance().getId()));
						if (recommDto.getLetterIssuanceDate() != null) {
							if (!Objects.equal(recomm.getLetterIssuanceDate(), recommDto.getLetterIssuanceDate())) {
								recomm.setLetterIssueDateChanged(true);
								recomm.setLetterIssuanceDate(recommDto.getLetterIssuanceDate());
							}
						}
					} else {
						recomm.setLetter(null);
						recomm.setLetterIssuanceDate(null);
					}

					if (CollectionUtils.isNotEmpty(recommDto.getDeletedLetterIssuance())) {
						recommDto.getDeletedLetterIssuance().forEach(letter -> {
							Optional<CeInfringementDto> infringementOptional = infringements.stream()
									.filter(inf -> inf.getRecommendation().getLetterIssuance() != null && inf.getRecommendation().getLetterIssuance().getId().equals(letter.getId())).findAny();
							if (infringementOptional.isEmpty()) {
								fileHelper.deleteFile(letter);
							}
						});
					}

					ceCaseRecommendationRepository.saveOrUpdate(recomm);
					return recomm;
				}
			}
		}
		return null;
	}

	private CeCaseDecision saveOrUpdateDecision(CeInfringementDto dto, CeCaseInfringement ceCaseInfringement, List<CeInfringementDto> infringements, Workflow workflow, String action) {
		logger.info("[{}] infringement ID : {}", getUser().getLoginId(), ceCaseInfringement.getId());
		if (!ceCaseInfringement.getIsConcluded()) {
			CeDecisionDto decisionDto = dto.getDecision();
			if (decisionDto != null) {
				CeCaseDecision decision = decisionDto.getCeCaseDecision();
				if (decision != null) {
					logger.info("[{}] save or update decision - decision ID : {}", getUser().getLoginId(), decision.getId());
					if (decision.isNewOrEdited() && decision.getWorkflow() == null) {
						decision.setWorkflow(workflow);
					}
					decision.setCeCaseInfringement(ceCaseInfringement);
					decision.setCeCaseRecommendation(ceCaseInfringement.getLastRecommendation());
					decision.setToEmailLetter(decisionDto.getToEmailLetter() == null ? false : decisionDto.getToEmailLetter());
					decision.setHasShowCause(decisionDto.getShowCause());
					if (!Objects.equal(decision.getShowCauseDate(), decisionDto.getShowCauseDate())) {
						decision.setShowCauseDateChanged(true);
						decision.setShowCauseDate(decisionDto.getShowCauseDate());
					}

					if (decisionDto.getDecision() != null) {
						decision.setOutcome(cache.getType(decisionDto.getDecision().getKey().toString()));

						if (Entities.anyEquals(decision.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {
							setDecisionPenaltyDetails(decision, decisionDto.getPenaltyAmount(), null, null, null);
						} else if (Entities.anyEquals(decision.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_SUSPEND)) {
							setDecisionPenaltyDetails(decision, null, decisionDto.getPenaltyStartDate(), decisionDto.getPenaltyEndDate(), null);
						} else if (Entities.anyEquals(decision.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
							setDecisionPenaltyDetails(decision, null, decisionDto.getPenaltyStartDate(), null, null);
						} else if (Entities.anyEquals(decision.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_TAG_IP)) {
							setDecisionPenaltyDetails(decision, null, null, null, decisionDto.getTaggedIpCaseNo());
						} else {
							setDecisionPenaltyDetails(decision, null, null, null, null);
						}
					}

					if (decisionDto.getLetterIssuance() != null) {
						decision.setLetter(fileRepository.getFile(decisionDto.getLetterIssuance().getId()));
						if (decisionDto.getLetterIssuanceDate() != null) {
							decision.setLetterIssuanceDate(decisionDto.getLetterIssuanceDate());
						}
					} else {
						decision.setLetter(null);
						decision.setLetterIssuanceDate(null);
					}

					if (CollectionUtils.isNotEmpty(decisionDto.getDeletedLetterIssuance())) {
						decisionDto.getDeletedLetterIssuance().forEach(letter -> {
							Optional<CeInfringementDto> infringementOptional = infringements.stream()
									.filter(inf -> inf.getDecision().getLetterIssuance() != null && inf.getDecision().getLetterIssuance().getId().equals(letter.getId())).findAny();
							if (infringementOptional.isEmpty()) {
								fileHelper.deleteFile(letter);
							}
						});
					}

					ceCaseDecisionRepository.saveOrUpdate(decision);
					return decision;
				}

			}
		}
		return null;
	}

	private CeCaseAppeal saveOrUpdateAppealResult(CeInfringementDto dto, CeCaseInfringement ceCaseInfringement, List<CeInfringementDto> infringements, Workflow workflow, String action) {
		logger.info("[{}] infringement ID : {}", getUser().getLoginId(), ceCaseInfringement.getId());
		if (!ceCaseInfringement.getIsConcluded()) {
			CeResultDto resultDto = dto.getResult();
			if (resultDto != null) {
				CeCaseAppeal appeal = resultDto.getCeCaseAppeal();
				if (appeal != null) {
					logger.info("[{}] save or update appeal - appeal ID : {}", getUser().getLoginId(), appeal.getId());
					if (appeal.isNewOrEdited() && appeal.getWorkflow() == null) {
						appeal.setWorkflow(workflow);
					}

					CeCaseDecision lastDecision = ceCaseDecisionRepository.getDecisionById(ceCaseInfringement.getLastDecision().getId());
					// CeCaseDecision lastDecision = ceCaseInfringement.getLastDecision();
					lastDecision.setHasInProgressAppeal(false);
					appeal.setCeCaseDecision(lastDecision);
					appeal.setToEmailLetter(resultDto.getToEmailLetter());
					appeal.setPendingBatchJob(false);
					if (resultDto.getResult() != null) {
						appeal.setResult(cache.getType(resultDto.getResult().getKeyString()));
					}

					appeal.setAppealDate(resultDto.getAppealDate());
					appeal.setAppealRespondByDate(resultDto.getAppealRespondByDate());
					appeal.setRespondedDate(resultDto.getRespondedDate());

					if (lastDecision.getBillRefNo() != null) {
						appeal.setBillRefNo(lastDecision.getBillRefNo());
						appeal.setBillExpiryDate(lastDecision.getBillExpiryDate());

						PaymentRequest payReq = paymentRepository.getPaymentRequest(lastDecision.getBillRefNo());
						appeal.setPaymentStatus(payReq.getStatus());
					}

					if (appeal.getResult() != null) {
						if (Entities.anyEquals(appeal.getResult(), Codes.CeAppealResult.CE_APPEAL_RESULT_ACD, Codes.CeAppealResult.CE_APPEAL_RESULT_NO_APPEAL)) {

							if (Entities.equals(appeal.getResult(), Codes.CeAppealResult.CE_APPEAL_RESULT_NO_APPEAL)) {
								appeal.setAppealDate(null);
								appeal.setAppealRespondByDate(null);
								appeal.setRespondedDate(null);
							}

							if (resultDto.getNewDecision() != null) {
								appeal.setOutcome(cache.getType(resultDto.getNewDecision().getKey().toString()));
								if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {
									setAppealPenaltyDetails(appeal, resultDto.getPenaltyAmount(), null, null);
								} else if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_SUSPEND)) {
									setAppealPenaltyDetails(appeal, null, resultDto.getPenaltyStartDate(), resultDto.getPenaltyEndDate());
								} else if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
									setAppealPenaltyDetails(appeal, null, resultDto.getPenaltyStartDate(), null);
								} else {
									setAppealPenaltyDetails(appeal, null, null, null);
								}
							}

						} else if (Entities.anyEquals(appeal.getResult(), Codes.CeAppealResult.CE_APPEAL_RESULT_PEND)) {
							lastDecision.setHasInProgressAppeal(true);
							appeal.setNewOrEdited(false); // set to false as infringement with "In Progress" appeal result dont need approval
							appeal.setOutcome(null);
							appeal.setBillRefNo(null);
							appeal.setBillExpiryDate(null);
							appeal.setPaymentStatus(null);
							setAppealPenaltyDetails(appeal, null, null, null);
							if (Entities.anyEquals(lastDecision.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {

								// if appeal result is "In Progress", system have to remove payment due date
								appeal.setBillExpiryDate(null);

								if (StringUtils.isNotEmpty(appeal.getBillRefNo())) {
									PaymentRequest payReq = paymentRepository.getPaymentRequest(appeal.getBillRefNo());
									if (payReq != null) {
										payReq.setDueDate(null);
										paymentRepository.update(payReq);
									}
									ceTaskHelper.completeCeTaskByBill(appeal.getBillRefNo());
								}
							}

						} else if (Entities.anyEquals(appeal.getResult(), Codes.CeAppealResult.CE_APPEAL_RESULT_REJ)) {
							if (resultDto.getNewDecision() != null) {
								appeal.setOutcome(cache.getType(resultDto.getNewDecision().getKey().toString()));
								if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {
									setAppealPenaltyDetails(appeal, resultDto.getPenaltyAmount(), null, null);
								} else if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_SUSPEND)) {
									setAppealPenaltyDetails(appeal, null, resultDto.getPenaltyStartDate(), resultDto.getPenaltyEndDate());
								} else if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
									setAppealPenaltyDetails(appeal, null, resultDto.getPenaltyStartDate(), null);
								} else {
									setAppealPenaltyDetails(appeal, null, null, null);
								}
							}
						}
					}

					if (resultDto.getLetterIssuance() != null) {
						appeal.setLetter(fileRepository.getFile(resultDto.getLetterIssuance().getId()));
						if (resultDto.getLetterIssuanceDate() != null) {
							appeal.setLetterIssuanceDate(resultDto.getLetterIssuanceDate());
						}
					} else {
						appeal.setLetter(null);
						appeal.setLetterIssuanceDate(null);
					}

					if (CollectionUtils.isNotEmpty(resultDto.getDeletedLetterIssuance())) {
						resultDto.getDeletedLetterIssuance().forEach(letter -> {
							Optional<CeInfringementDto> infringementOptional = infringements.stream()
									.filter(inf -> inf.getDecision().getLetterIssuance() != null && inf.getDecision().getLetterIssuance().getId().equals(letter.getId())).findAny();
							if (infringementOptional.isEmpty()) {
								fileHelper.deleteFile(letter);
							}
						});
					}

					ceCaseDecisionRepository.update(lastDecision);
					appeal.setCeCaseInfringement(ceCaseInfringement);
					ceCaseAppealRepository.saveOrUpdate(appeal);
					return appeal;
				}
			}
		}
		return null;
	}

	private CeCaseRescind saveOrUpdateRescind(CeInfringementDto dto, CeCaseInfringement ceCaseInfringement, List<CeInfringementDto> infringements, Workflow workflow, String action) {
		logger.info("[{}] infringement ID : {}", getUser().getLoginId(), ceCaseInfringement.getId());
		if (!ceCaseInfringement.getIsConcluded()) {
			CeRescindDto rescindDto = dto.getRescind();
			if (rescindDto != null) {
				CeCaseRescind rescind = rescindDto.getCeCaseRescind();
				if (rescind != null) {
					logger.info("[{}] save or update rescind - rescind ID : {}", getUser().getLoginId(), rescind.getId());
					if (rescind.isNewOrEdited() && rescind.getWorkflow() == null) {
						rescind.setWorkflow(workflow);
					}
					rescind.setCeCaseInfringement(ceCaseInfringement);
					rescind.setToEmailLetter(rescindDto.getToEmailLetter());

					if (rescindDto.getLetterIssuance() != null) {
						rescind.setLetter(fileRepository.getFile(rescindDto.getLetterIssuance().getId()));
						if (rescindDto.getLetterIssuanceDate() != null) {
							rescind.setLetterIssuanceDate(rescindDto.getLetterIssuanceDate());
						}
					} else {
						rescind.setLetter(null);
						rescind.setLetterIssuanceDate(null);
					}

					if (CollectionUtils.isNotEmpty(rescindDto.getDeletedLetterIssuance())) {
						rescindDto.getDeletedLetterIssuance().forEach(letter -> {
							Optional<CeInfringementDto> infringementOptional = infringements.stream()
									.filter(inf -> inf.getDecision().getLetterIssuance() != null && inf.getDecision().getLetterIssuance().getId().equals(letter.getId())).findAny();
							if (infringementOptional.isEmpty()) {
								fileHelper.deleteFile(letter);
							}
						});
					}

					ceCaseRescindRepository.saveOrUpdate(rescind);
					return rescind;
				}
			}
		}
		return null;
	}

	// method to check whether new recommendation is required
	private boolean validateNewRecommIsRequired(CeCaseRecommendation recomm, CeInfringementDto dto) {
		Workflow currRecommWorkflow = recomm.getWorkflow();
		WorkflowAction lastAction = currRecommWorkflow.getLastAction();

		CeRecommendationDto recommDto = dto.getRecommendation();

		if (lastAction != null && Entities.anyEquals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_APPR, Codes.Statuses.CE_WKFLW_REJ)) {
			return isOutcomeDifferent(recomm.getOutcome(), recommDto.getRecommendation()) || isPenaltyAmountDifferent(recomm.getPenaltyAmount(), recommDto.getPenaltyAmount())
					|| isPenaltyDateDifferent(recomm.getPenaltyStatusStartDate(), recommDto.getPenaltyStartDate())
					|| isPenaltyDateDifferent(recomm.getPenaltyStatusEndDate(), recommDto.getPenaltyEndDate());
		}

		return false;
	}

	// method to check whether new decision is required
	private boolean validateNewDecisionIsRequired(CeCaseDecision decision, CeInfringementDto dto) {
		Workflow currDecWorkflow = decision.getWorkflow();
		WorkflowAction lastAction = currDecWorkflow.getLastAction();

		CeDecisionDto decisionDto = dto.getDecision();

		if (lastAction != null && Entities.anyEquals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_APPR, Codes.Statuses.CE_WKFLW_REJ)) {
			return isOutcomeDifferent(decision.getOutcome(), decisionDto.getDecision()) || isPenaltyAmountDifferent(decision.getPenaltyAmount(), decisionDto.getPenaltyAmount())
					|| isPenaltyDateDifferent(decision.getPenaltyStatusStartDate(), decisionDto.getPenaltyStartDate())
					|| isPenaltyDateDifferent(decision.getPenaltyStatusEndDate(), decisionDto.getPenaltyEndDate());
		}

		return false;
	}

	// method to check whether new appeal is required
	private boolean validateNewAppealIsRequired(CeCaseAppeal appeal, CeInfringementDto dto) {
		Workflow currAppealWorkflow = appeal.getWorkflow();
		WorkflowAction lastAction = currAppealWorkflow.getLastAction();

		CeResultDto resultDto = dto.getResult();

		if (lastAction != null && Entities.anyEquals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_APPR, Codes.Statuses.CE_WKFLW_REJ)) {
			return isOutcomeDifferent(appeal.getResult(), resultDto.getResult()) || isOutcomeDifferent(appeal.getOutcome(), resultDto.getNewDecision())
					|| isPenaltyAmountDifferent(appeal.getPenaltyAmount(), resultDto.getPenaltyAmount()) || isPenaltyDateDifferent(appeal.getPenaltyStatusStartDate(), resultDto.getPenaltyStartDate())
					|| isPenaltyDateDifferent(appeal.getPenaltyStatusEndDate(), resultDto.getPenaltyEndDate());
		}

		return false;
	}

	// method to check whether new rescind is required
	private boolean validateNewRescindIsRequired(CeCaseRescind rescind, CeInfringementDto dto) {
		Workflow currRescindWorkflow = rescind.getWorkflow();
		WorkflowAction lastAction = currRescindWorkflow.getLastAction();

		CeRescindDto rescindDto = dto.getRescind();

		if (lastAction != null && Entities.anyEquals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_APPR, Codes.Statuses.CE_WKFLW_REJ)) {
			return Objects.equal(rescindDto.getLetterIssuance(), rescind.getLetter());
		}

		return false;
	}

	private boolean isPenaltyAmountDifferent(BigDecimal currPenaltyAmount, BigDecimal newPenaltyAmount) {
		return (currPenaltyAmount != null && newPenaltyAmount == null) || (currPenaltyAmount == null && newPenaltyAmount != null)
				|| (currPenaltyAmount != null && newPenaltyAmount != null && currPenaltyAmount.compareTo(newPenaltyAmount) != 0);
	}

	private boolean isPenaltyDateDifferent(LocalDate currPenaltyDate, LocalDate newPenaltyDate) {
		return (currPenaltyDate != null && newPenaltyDate == null) || (currPenaltyDate == null && newPenaltyDate != null)
				|| (currPenaltyDate != null && newPenaltyDate != null && !currPenaltyDate.equals(newPenaltyDate));
	}

	private boolean isOutcomeDifferent(Type outcome, ListableDto newOutcome) {
		return (outcome != null && newOutcome == null) || (outcome == null && newOutcome != null) || (outcome != null && newOutcome != null && !outcome.getCode().equals(newOutcome.getKeyString()));
	}

	private void setRecommendationPenaltyDetails(CeCaseRecommendation recomm, BigDecimal amount, LocalDate startDate, LocalDate endDate, String ipCaseNo) {
		recomm.setTaggedIpCaseNo(ipCaseNo);
		recomm.setPenaltyAmount(amount);
		recomm.setPenaltyStatusStartDate(startDate);
		recomm.setPenaltyStatusEndDate(endDate);
	}

	private void setDecisionPenaltyDetails(CeCaseDecision decision, BigDecimal amount, LocalDate startDate, LocalDate endDate, String ipCaseNo) {
		decision.setTaggedIpCaseNo(ipCaseNo);
		decision.setPenaltyAmount(amount);
		decision.setPenaltyStatusStartDate(startDate);
		decision.setPenaltyStatusEndDate(endDate);
	}

	private void setAppealPenaltyDetails(CeCaseAppeal appeal, BigDecimal amount, LocalDate startDate, LocalDate endDate) {
		appeal.setPenaltyAmount(amount);
		appeal.setPenaltyStatusStartDate(startDate);
		appeal.setPenaltyStatusEndDate(endDate);
	}

	private CeCasesDto populateCeCasesDto(CeCase ceCase) {
		User user = getUser();
		User oic = ceCase.getOic();

		CeCasesDto dto = new CeCasesDto(ceCase, cache);
		dto.setCurrentWorkflow(new CeCaseTaskWorkflowDto());

		List<CeCase> taggedCases = ceCaseRepository.getChildCaseByCaseId(ceCase.getId());
		if (CollectionUtils.isNotEmpty(taggedCases)) {
			dto.setHasChildCase(true);
		}

		// complainants
		if (CollectionUtils.isNotEmpty(ceCase.getCeCaseComplainants())) {
			List<CeComplainantDto> complainants = new ArrayList<>();
			ceCase.getCeCaseComplainants().forEach(u -> {
				if (!u.getIsDeleted()) {
					complainants.add(new CeComplainantDto(u, fileHelper, cache));
				}
			});
			dto.setComplainants(complainants);
		}

		// infringements
		Set<Workflow> workflows = new HashSet<>();

		Set<CeCaseInfringement> infringements = ceCaseHelper.getInfringementsFromCase(ceCase);

		if (CollectionUtils.isNotEmpty(infringements)) {
			List<Integer> infringementIds = infringements.stream().map(CeCaseInfringement::getId).collect(Collectors.toList());

			List<CeCaseRecommendation> ceCaseApprovedRecommendations = ceCaseRecommendationRepository.getApprovedRecommendationsByInfringementIds(infringementIds);
			List<CeCaseRecommendation> ceCaseDraftRecommendations = ceCaseRecommendationRepository.getDraftRecommendationsByInfringementIds(infringementIds);
			List<CeCaseDecision> ceCaseDraftDecisions = ceCaseDecisionRepository.getDraftDecisionsByInfringementIds(infringementIds);
			List<CeCaseAppeal> ceCaseDraftAppeals = ceCaseAppealRepository.getDraftAppealsByInfringementIds(infringementIds);
			List<CeCaseRescind> ceCasePendingOrApprovedRescinds = ceCaseRescindRepository.getPendingOrApprovedRescindsByInfringementIds(infringementIds);
			List<CeCaseRescind> ceCaseDraftRescinds = ceCaseRescindRepository.getDraftRescindsByInfringementIds(infringementIds);

			List<CeInfringementDto> infringementList = new ArrayList<>();
			for (CeCaseInfringement infringement : infringements) {
				CeCaseInfringer ceCaseInfringer = infringement.getCeCaseInfringer();
				CeInfringementDto ceInfringementDto = new CeInfringementDto(ceCaseInfringer, infringement, cache, false, ceCaseHelper);

				Optional<CeCaseRecommendation> approvedRecommOptional = ceCaseApprovedRecommendations.stream().filter(u -> u.getCeCaseInfringement().getId().equals(infringement.getId())).findAny();
				if (approvedRecommOptional.isPresent()) {
					ceInfringementDto.setHasApprovedPastRecommendation(true);
				}

				// recommendation
				CeCaseRecommendation recomm = getRecommendation(infringement, ceCaseDraftRecommendations, user, oic);
				if (recomm != null) {
					CeRecommendationDto recommDto = new CeRecommendationDto(recomm, cache, fileHelper, workflowHelper, oic, false);
					ceInfringementDto.setRecommendation(recommDto);
					if (recomm.getWorkflow() != null) {
						workflows.add(recomm.getWorkflow());
					}
					if (recommDto.getWorkflowStatus() != null) {
						ceInfringementDto.setIsPendingApproval(true);
					}

				}

				// decision
				CeCaseDecision decision = getDecision(infringement, ceCaseDraftDecisions, user, oic);
				if (decision != null) {
					CeDecisionDto decisionDto = new CeDecisionDto(decision, cache, fileHelper, workflowHelper, oic, false);
					ceInfringementDto.setDecision(decisionDto);
					if (decision.getWorkflow() != null) {
						workflows.add(decision.getWorkflow());
					}
					if (decisionDto.getWorkflowStatus() != null) {
						ceInfringementDto.setIsPendingApproval(true);
					}
				}

				// appeal
				CeCaseAppeal appeal = getAppeal(infringement, ceCaseDraftAppeals, user, oic);
				if (appeal != null) {
					CeResultDto resultDto = new CeResultDto(appeal, cache, fileHelper, workflowHelper, oic);
					ceInfringementDto.setResult(resultDto);
					if (appeal.getWorkflow() != null) {
						workflows.add(appeal.getWorkflow());
					}
					if (resultDto.getWorkflowStatus() != null) {
						ceInfringementDto.setIsPendingApproval(true);
					}
				}

				// rescind
				Optional<CeCaseRescind> pendingRescindOptional = ceCasePendingOrApprovedRescinds.stream().filter(pr -> pr.getCeCaseInfringement().getId().equals(infringement.getId())).findFirst();
				CeCaseRescind rescind = getRescind(infringement, pendingRescindOptional, ceCaseDraftRescinds, user, oic);
				if (rescind != null) {
					CeRescindDto rescindDto = new CeRescindDto(rescind, cache, fileHelper, workflowHelper, oic, false);
					ceInfringementDto.setRescind(rescindDto);
					if (rescind.getWorkflow() != null) {
						workflows.add(rescind.getWorkflow());
					}
					if (rescindDto.getWorkflowStatus() != null) {
						ceInfringementDto.setIsPendingApproval(true);
					}
				}

				infringementList.add(ceInfringementDto);
			}

			infringementList.sort(Comparator.comparingInt(CeInfringementDto::getOffenderId));
			dto.setInfringements(infringementList);
		}

		// Compliance Checks and Field Reports
		List<CeComplianceCheckDto> complianceChecks = new ArrayList<>();
		Set<CeTaFieldReport> taFieldReports = ceCase.getCeTaFieldReports();
		if (!taFieldReports.isEmpty()) {
			taFieldReports.forEach(u -> {
				complianceChecks.add(new CeComplianceCheckDto(u, ceCase.getId()));
			});
		}

		CeTgFieldReport ceTgFieldReport = ceCase.getCeTgFieldReport();
		if (ceTgFieldReport != null) {
			complianceChecks.add(new CeComplianceCheckDto(ceTgFieldReport, ceCase.getId()));
		}

		Set<CeTaCheck> ceTaChecks = ceCase.getCeTaChecks();
		if (!ceTaChecks.isEmpty()) {
			ceTaChecks.forEach(u -> {
				complianceChecks.add(new CeComplianceCheckDto(u, ceCase.getId()));
			});
		}
		dto.setComplianceChecks(complianceChecks);

		// other attachments
		Set<File> files = ceCase.getFiles();
		if (!files.isEmpty()) {
			List<FileDto> othAttachments = new ArrayList<>();
			files.forEach(u -> {
				if (!u.getIsDeleted()) {
					othAttachments.add(FileDto.buildFromFile(u, null, fileHelper));
				}
			});
			dto.setOthAttachments(othAttachments);
		}

		// relevant offences and infringements
		List<CeCaseInfringer> othInfringers = retrieveRelevantInfringements(infringements);
		setOtherInfringements(othInfringers, dto);

		// to populate workflow info
		dto.setIsNew(checkCaseIsNew(ceCase.getId()));
		dto.setIsOic(oic != null && oic.getId().equals(user.getId()) ? true : false);

		if (CollectionUtils.isNotEmpty(workflows)) {
			Set<Workflow> workflowSet = workflows.stream()
					.filter(wk -> wk.getLastAction() != null && (workflowHelper.isPendingApproval(wk.getLastAction().getStatus()) || workflowHelper.isRoutedBack(wk.getLastAction().getStatus())))
					.collect(Collectors.toSet());

			// if there is pending approval or routed back workflow exists
			if (workflowSet != null && !workflowSet.isEmpty()) {
				dto.setIsPendingApproval(true);
				List<CeCaseTaskWorkflowDto> ceTaskWorkflows = new ArrayList<>();
				for (Workflow workflow : workflowSet) {

					if (workflowHelper.isRoutedBack(workflow.getLastAction().getStatus())) {
						dto.setIsRoutedBack(true);
					}

					CeCaseTaskWorkflowDto workflowDto = new CeCaseTaskWorkflowDto(workflow, fileHelper, cache, workflowHelper, user);
					List<WorkflowStepAssignment> workflowStepAssignments = workflowRepository.getWorkflowStepAssignmentsByWkflwType(workflow.getType().getCode());
					workflowStepAssignments.forEach(u -> {
						WorkflowStep ws = u.getWorkflowStep();
						if (ws != null) {
							Set<Role> roles = ws.getRoles();
							if (roles.contains(user.getDefaultRole())) {
								workflowDto.setIsInGroup(true);
							}
						}

					});

					switch (workflow.getType().getCode()) {
					case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
					case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
						List<CeCaseRecommendation> recommendationList = ceCaseRecommendationRepository.getRecommendationsByWorkflowId(workflow.getId());
						workflowDto.setCaseTaskSummary(CeCaseTaskSummaryDto.populateRecommendationCaseTaskSummaryDetails(recommendationList, dto, ceCaseHelper));
						break;

					case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
					case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
						List<CeCaseDecision> decisionList = ceCaseDecisionRepository.getDecisionsByWorkflowId(workflow.getId());
						workflowDto.setCaseTaskSummary(CeCaseTaskSummaryDto.populateDecisionCaseTaskSummaryDetails(decisionList, dto, ceCaseHelper));
						break;

					case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
					case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
						List<CeCaseAppeal> appealList = ceCaseAppealRepository.getAppealsByWorkflowId(workflow.getId());
						workflowDto.setCaseTaskSummary(CeCaseTaskSummaryDto.populateAppealCaseTaskSummaryDetails(appealList, dto, ceCaseHelper));
						break;

					case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
					case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
						List<CeCaseRescind> rescindList = ceCaseRescindRepository.getRescindsByWorkflowId(workflow.getId());
						workflowDto.setCaseTaskSummary(CeCaseTaskSummaryDto.populateRescindCaseTaskSummaryDetails(rescindList, dto, ceCaseHelper));
						break;

					case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:

						break;

					}
					ceTaskWorkflows.add(workflowDto);
				}
				dto.setWorkflows(ceTaskWorkflows);
			}

		}

		return dto;
	}

	private void setOtherInfringements(List<CeCaseInfringer> othInfringers, CeCasesDto dto) {
		if (CollectionUtils.isNotEmpty(othInfringers)) {
			List<CeInfringementDto> othInfringements = new ArrayList<>();
			for (CeCaseInfringer ceCaseInfringer : othInfringers) {
				if (!ceCaseInfringer.getIsDeleted()) {
					if (CollectionUtils.isEmpty(ceCaseInfringer.getCeCaseInfringements())) {
						othInfringements.add(new CeInfringementDto(ceCaseInfringer, null, cache, true, ceCaseHelper));
					} else {

						for (CeCaseInfringement infringement : ceCaseInfringer.getCeCaseInfringements()) {
							if (!infringement.getIsDeleted()
									&& othInfringements.stream().filter(u -> u.getInfringementId() != null && u.getInfringementId().equals(infringement.getId())).findAny().isEmpty()) {
								CeInfringementDto infringementDto = new CeInfringementDto(ceCaseInfringer, infringement, cache, true, ceCaseHelper);

								if (infringement.getLastRecommendation() != null) {
									CeCaseRecommendation lastRecommendation = ceCaseRecommendationRepository.getRecommendationById(infringement.getLastRecommendation().getId());
									infringementDto.setRecommendation(new CeRecommendationDto(lastRecommendation, cache, fileHelper, workflowHelper, null, false));
								}
								othInfringements.add(infringementDto);
							}
						}
					}
				}
			}
			dto.setOthInfringements(othInfringements);
		}
	}

	private CeCaseRecommendation getRecommendation(CeCaseInfringement ceCaseInfringement, List<CeCaseRecommendation> ceCaseDraftRecommendations, User user, User oic) {
		CeCaseRecommendation ceCaseRecommendation = ceCaseInfringement.getLastRecommendation();
		if (user != null && user.getId().equals(oic.getId())) {
			Optional<CeCaseRecommendation> lastDraftRecommOptional = ceCaseDraftRecommendations.stream().filter(dr -> dr.getCeCaseInfringement().getId().equals(ceCaseInfringement.getId()))
					.findFirst();
			if (lastDraftRecommOptional.isPresent()) {
				ceCaseRecommendation = lastDraftRecommOptional.get();
			}
		}

		return ceCaseRecommendation;
	}

	private CeCaseDecision getDecision(CeCaseInfringement ceCaseInfringement, List<CeCaseDecision> ceCaseDraftDecisions, User user, User oic) {
		CeCaseDecision ceCaseDecision = ceCaseInfringement.getLastDecision();
		if (user != null && user.getId().equals(oic.getId())) {
			Optional<CeCaseDecision> lastDraftDecisionOptional = ceCaseDraftDecisions.stream().filter(dr -> dr.getCeCaseInfringement().getId().equals(ceCaseInfringement.getId())).findFirst();
			if (lastDraftDecisionOptional.isPresent()) {
				ceCaseDecision = lastDraftDecisionOptional.get();
			}
		}

		return ceCaseDecision;
	}

	private CeCaseAppeal getAppeal(CeCaseInfringement ceCaseInfringement, List<CeCaseAppeal> ceCaseDraftAppeals, User user, User oic) {
		CeCaseDecision ceCaseDecision = ceCaseInfringement.getLastDecision();
		if (ceCaseDecision != null) {
			CeCaseAppeal ceCaseAppeal = ceCaseDecision.getCeCaseAppeal();
			if (user != null && user.getId().equals(oic.getId())) {
				Optional<CeCaseAppeal> lastDraftAppealOptional = ceCaseDraftAppeals.stream().filter(dr -> dr.getCeCaseInfringement().getId().equals(ceCaseInfringement.getId())).findFirst();
				if (lastDraftAppealOptional.isPresent()) {
					ceCaseAppeal = lastDraftAppealOptional.get();
				}
			}
			return ceCaseAppeal;
		}

		return null;
	}

	private CeCaseRescind getRescind(CeCaseInfringement ceCaseInfringement, Optional<CeCaseRescind> pendingRescindOptional, List<CeCaseRescind> ceCaseDraftRescinds, User user, User oic) {

		CeCaseRescind ceCaseRescind = pendingRescindOptional.isPresent() ? pendingRescindOptional.get() : null;
		if (user != null && user.getId().equals(oic.getId())) {
			Optional<CeCaseRescind> lastDraftRescindOptional = ceCaseDraftRescinds.stream().filter(dr -> dr.getCeCaseInfringement().getId().equals(ceCaseInfringement.getId())).findFirst();
			if (lastDraftRescindOptional.isPresent()) {
				ceCaseRescind = lastDraftRescindOptional.get();
			}
		}

		return ceCaseRescind;
	}

	private List<CeCaseInfringer> retrieveRelevantInfringements(Set<CeCaseInfringement> infringements) {
		Set<CeCaseInfringer> infringers = new HashSet<>();
		infringements.forEach(infringement -> {
			infringers.add(infringement.getCeCaseInfringer());
		});

		if (!infringers.isEmpty()) {
			return ceCaseInfringerRepository.getOtherInfringersByUenUins(infringers.stream().map(CeCaseInfringer::getUenUin).collect(Collectors.toList()),
					infringers.stream().map(CeCaseInfringer::getId).collect(Collectors.toList()));
		}

		return null;
	}

	// approve, reject, route back for recommendation workflow
	private void processForRecommendation(String action, Workflow workflow, ApprovalDto dto) {
		logger.info("[{}] {} recommendation case task - workflow ID : {}", getUser().getLoginId(), action, workflow.getId());
		List<CeCaseRecommendation> recommendationList = ceCaseRecommendationRepository.getRecommendationsByWorkflowId(workflow.getId());
		CeCaseRecommendation ceCaseRecommendation = recommendationList.get(0);
		CeCase ceCase = ceCaseRecommendation.getCeCaseInfringement().getCeCase();

		LocalDate letterIssuanceDate = null;
		Set<CeCaseInfringement> infringements = new HashSet<>();
		for (CeCaseRecommendation recomm : recommendationList) {
			infringements.add(recomm.getCeCaseInfringement());

			if (recomm.getLetterIssuanceDate() != null) {
				letterIssuanceDate = recomm.getLetterIssuanceDate();
			}
		}

		String taskType = getTaskTypeByWkflwTypeCode(workflow.getType().getCode());
		String taskStatus = getTaskStatusByWkflwTypeCode(workflow.getType().getCode());
		String slaParameter = getSlaParameterByWkflwTypeCode(workflow.getType().getCode());

		switch (action) {
		case ACTION_APPROVE:
			workflowHelper.forward(workflow, false, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), true, null);

			boolean isCaseClosed = ceCaseHelper.processRecommendationDirectOutcome(recommendationList, ceCase);
			if (isCaseClosed) {
				sendLetterIssuanceForRecomm(recommendationList);
				ceTaskHelper.completeOpenCeTaskByCeCase(ceCase);
			} else {

				// to check whether current workflow is final approval stage
				// if final approval stage, system have to process the recommendation outcome
				if (workflowHelper.hasFinalApproved(workflow)) {
					sendLetterIssuanceForRecomm(recommendationList);
					isCaseClosed = ceCaseHelper.processRecommendationOutcome(recommendationList, ceCase);

					// if case is closed, system have to complete all the open ce task related to case
					if (isCaseClosed) {
						ceTaskHelper.completeCeTaskByCeCase(ceCase, false);
					} else {

						// if case is not closed and letter issuance date is provided, system will generate new ce task for next level.
						if (letterIssuanceDate != null) {
							createCeTaskAfterLetterIssued(workflow, ceCase, null, letterIssuanceDate);
						} else {
							ceTaskHelper.createCeTaskForCeCase(ceCase, null, taskType, Codes.CeTaskStatus.CE_TASK_TO_UPDATE_LETTER_DATE, slaParameter, null);
						}

					}

					ceCaseHelper.processEmailNotification(recommendationList, ceCase);

				} else {
					ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
				}
			}

			break;

		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);

			recommendationList.forEach(recommendation -> {
				CeCaseInfringement ceCaseInfringement = recommendation.getCeCaseInfringement();
				List<CeCaseRecommendation> approvedRecommList = ceCaseRecommendationRepository.getApprovedRecommendationsByInfringementId(ceCaseInfringement.getId());
				if (CollectionUtils.isEmpty(approvedRecommList)) {
					ceCaseInfringement.setLastRecommendation(null);
				} else {
					ceCaseInfringement.setLastRecommendation(approvedRecommList.get(0));
				}
			});
			ceCaseRecommendationRepository.update(recommendationList);
			// completeCaseWorkflowTask(infringements, ceCase, workflow);
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		case ACTION_ROUTE:
			User oic = ceCase.getOic();
			workflowHelper.rfa(workflow, Codes.Statuses.CE_WKFLW_ROUTED, dto.getInternalRemarks(), null, null, null, null, oic.getId());
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		ceCaseHelper.acknowledgeTaCheck(recommendationList, ceCase, getUser());
	}

	// approve, reject, route back for decision workflow
	private void processForImposeDecision(String action, Workflow workflow, ApprovalDto dto) {
		logger.info("[{}] {} impose decision case task - workflow ID : {}", getUser().getLoginId(), action, workflow.getId());
		List<CeCaseDecision> decisionList = ceCaseDecisionRepository.getDecisionsByWorkflowId(workflow.getId());
		CeCaseDecision ceCaseDecision = decisionList.get(0);
		CeCase ceCase = ceCaseDecision.getCeCaseInfringement().getCeCase();

		LocalDate letterIssuanceDate = null;
		Set<CeCaseInfringement> infringements = new HashSet<>();
		for (CeCaseDecision decision : decisionList) {
			infringements.add(decision.getCeCaseInfringement());

			if (decision.getLetterIssuanceDate() != null) {
				letterIssuanceDate = decision.getLetterIssuanceDate();
			}
		}

		String taskType = getTaskTypeByWkflwTypeCode(workflow.getType().getCode());
		String taskStatus = getTaskStatusByWkflwTypeCode(workflow.getType().getCode());
		String slaParameter = getSlaParameterByWkflwTypeCode(workflow.getType().getCode());

		switch (action) {
		case ACTION_APPROVE:
			workflowHelper.forward(workflow, false, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), true, dto.getFiles());

			// to check whether current workflow is final approval stage
			// if final approval stage, system have to process the impose decision outcome
			if (workflowHelper.hasFinalApproved(workflow)) {
				sendLetterIssuanceForDecision(decisionList);
				boolean isCaseClosed = processImposeOutcome(decisionList, ceCase);

				// if case is closed, system have to complete all the open ce task related to case
				if (isCaseClosed) {
					ceTaskHelper.completeCeTaskByCeCase(ceCase, false);
				} else {

					// if case is not closed and letter issuance date is provided, system will generate new ce task for next level.
					if (letterIssuanceDate != null) {
						createCeTaskAfterLetterIssued(workflow, ceCase, null, letterIssuanceDate);
					} else {
						ceTaskHelper.createCeTaskForCeCase(ceCase, null, taskType, Codes.CeTaskStatus.CE_TASK_TO_UPDATE_LETTER_DATE, slaParameter, null);
					}

				}
			} else {
				ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			}

			break;

		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);

			decisionList.forEach(decision -> {
				CeCaseInfringement ceCaseInfringement = decision.getCeCaseInfringement();
				List<CeCaseDecision> approvedDecisionList = ceCaseDecisionRepository.getApprovedDecisionsByInfringementId(ceCaseInfringement.getId());
				if (CollectionUtils.isEmpty(approvedDecisionList)) {
					ceCaseInfringement.setLastDecision(null);
				} else {
					ceCaseInfringement.setLastDecision(approvedDecisionList.get(0));
				}
			});
			ceCaseDecisionRepository.update(decisionList);
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		case ACTION_ROUTE:
			User oic = ceCase.getOic();
			workflowHelper.rfa(workflow, Codes.Statuses.CE_WKFLW_ROUTED, dto.getInternalRemarks(), null, null, null, null, oic.getId());
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}
	}

	// approve, reject, route back for appeal workflow
	private void processForAppeal(String action, Workflow workflow, ApprovalDto dto) {
		logger.info("[{}] {} appeal case task - workflow ID : {}", getUser().getLoginId(), action, workflow.getId());
		List<CeCaseAppeal> appealList = ceCaseAppealRepository.getAppealsByWorkflowId(workflow.getId());
		CeCaseAppeal ceCaseAppeal = appealList.get(0);
		CeCase ceCase = ceCaseAppeal.getCeCaseInfringement().getCeCase();

		String taskType = getTaskTypeByWkflwTypeCode(workflow.getType().getCode());
		String taskStatus = getTaskStatusByWkflwTypeCode(workflow.getType().getCode());
		String slaParameter = getSlaParameterByWkflwTypeCode(workflow.getType().getCode());

		switch (action) {
		case ACTION_APPROVE:
			workflowHelper.forward(workflow, false, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), true, dto.getFiles());

			// to check whether current workflow is final approval stage
			// if final approval stage, system have to process appeal outcome
			if (workflowHelper.hasFinalApproved(workflow)) {
				sendLetterIssuanceForAppeal(appealList);
				processAppealOutcome(appealList, ceCase);

				ceTaskHelper.completeCeTaskByCeCase(ceCase, false);
			} else {
				ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			}

			break;

		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);

			appealList.forEach(appeal -> {
				CeCaseInfringement ceCaseInfringement = appeal.getCeCaseInfringement();
				List<CeCaseAppeal> approvedAppealList = ceCaseAppealRepository.getApprovedAppealsByInfringementId(ceCaseInfringement.getId());

				CeCaseDecision lastDecision = ceCaseDecisionRepository.getDecisionById(ceCaseInfringement.getLastDecision().getId());
				if (CollectionUtils.isEmpty(approvedAppealList)) {
					lastDecision.setCeCaseAppeal(null);
				} else {
					lastDecision.setCeCaseAppeal(approvedAppealList.get(0));
				}
			});
			ceCaseAppealRepository.update(appealList);
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		case ACTION_ROUTE:
			User oic = ceCase.getOic();
			workflowHelper.rfa(workflow, Codes.Statuses.CE_WKFLW_ROUTED, dto.getInternalRemarks(), null, null, null, null, oic.getId());
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}
	}

	// approve, reject, route back for rescind workflow
	private void processForRescind(String action, Workflow workflow, ApprovalDto dto) {
		logger.info("[{}] {} rescind case task - workflow ID : {}", getUser().getLoginId(), action, workflow.getId());
		List<CeCaseRescind> rescindList = ceCaseRescindRepository.getRescindsByWorkflowId(workflow.getId());
		CeCaseRescind ceCaseRescind = rescindList.get(0);
		CeCase ceCase = ceCaseRescind.getCeCaseInfringement().getCeCase();

		LocalDate letterIssuanceDate = null;
		for (CeCaseRescind rescind : rescindList) {
			if (rescind.getLetterIssuanceDate() != null) {
				letterIssuanceDate = rescind.getLetterIssuanceDate();
			}
		}
		String taskType = getTaskTypeByWkflwTypeCode(workflow.getType().getCode());
		String taskStatus = getTaskStatusByWkflwTypeCode(workflow.getType().getCode());
		String slaParameter = getSlaParameterByWkflwTypeCode(workflow.getType().getCode());

		switch (action) {
		case ACTION_APPROVE:
			workflowHelper.forward(workflow, false, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), true, dto.getFiles());
			if (workflowHelper.hasFinalApproved(workflow)) {
				sendLetterIssuanceForRescind(rescindList);

				if (letterIssuanceDate == null) {
					ceTaskHelper.createCeTaskForCeCase(ceCase, null, taskType, Codes.CeTaskStatus.CE_TASK_TO_UPDATE_LETTER_DATE, slaParameter, null);
				} else {
					ceTaskHelper.completeCeTaskByCeCase(ceCase, true);
				}
			} else {
				ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			}

			break;

		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		case ACTION_ROUTE:
			User oic = ceCase.getOic();
			workflowHelper.rfa(workflow, Codes.Statuses.CE_WKFLW_ROUTED, dto.getInternalRemarks(), null, null, null, null, oic.getId());
			ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}
	}

	private boolean processImposeOutcome(List<CeCaseDecision> decisionList, CeCase ceCase) {

		Set<CeCaseInfringer> infringers = new HashSet<>();
		HashMap<Integer, List<CeCaseDecision>> infringerDecisionMap = new LinkedHashMap<>();

		Set<Licence> licSet = new HashSet<>();
		HashMap<Integer, String> licenceHighestStatusMap = new HashMap<>(); // to store the highest status that going to be updated for that licence

		decisionList.forEach(decision -> {
			CeCaseInfringement ceCaseInfringement = decision.getCeCaseInfringement();
			CeCaseInfringer ceCaseInfringer = ceCaseInfringement.getCeCaseInfringer();
			Licence lic = ceCaseInfringer.getLicence();

			if (decision.getOutcome() != null) {
				String decisionCode = decision.getOutcome().getCode();
				switch (decisionCode) {
				case Codes.CeRecommendation.CE_OUTCOME_NOD:
				case Codes.CeRecommendation.CE_OUTCOME_NFA:
				case Codes.CeRecommendation.CE_OUTCOME_CAUTION:
				case Codes.CeRecommendation.CE_OUTCOME_CIRCULAR:
				case Codes.CeRecommendation.CE_OUTCOME_COUNSEL:

					ceCaseInfringement.setOutcome(decision.getOutcome());
					ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
					ceCaseInfringementRepository.update(ceCaseInfringement);
					break;

				case Codes.CeRecommendation.CE_OUTCOME_AFP:
					infringers.add(ceCaseInfringer);

					List<CeCaseDecision> decisions = new ArrayList<>();
					if (infringerDecisionMap.isEmpty() || !infringerDecisionMap.containsKey(ceCaseInfringer.getId())) {
						decisions.add(decision);
					} else {
						decisions = infringerDecisionMap.get(ceCaseInfringer.getId());
						decisions.add(decision);
					}
					infringerDecisionMap.put(ceCaseInfringer.getId(), decisions);
					break;

				case Codes.CeRecommendation.CE_OUTCOME_SUSPEND:
				case Codes.CeRecommendation.CE_OUTCOME_REVOKE:

					// only TA will change status to "Pending Suspension/Pending Revocation"
					// TG status will be changed to "Suspended/Revoked" directly after MTI appeal result
					if (lic != null && Codes.TaTgType.TA.equals(ceCase.getTaTgType())) {
						String updatedStatus = null;
						if (licenceHighestStatusMap.isEmpty() || !licenceHighestStatusMap.containsKey(lic.getId())) {
							updatedStatus = decisionCode.equals(Codes.CeRecommendation.CE_OUTCOME_SUSPEND) ? Codes.Statuses.TA_PEND_SUSPENSION : Codes.Statuses.TA_PEND_REVOCATION;
						} else {
							updatedStatus = licenceHighestStatusMap.get(lic.getId());
							if (decisionCode.equals(Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
								updatedStatus = Codes.Statuses.TA_PEND_REVOCATION;
							}
						}
						licenceHighestStatusMap.put(lic.getId(), updatedStatus);
						licSet.add(lic);
					}

					break;

				}

				ceCaseInfringement.setOutcome(decision.getOutcome());
				ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
				ceCaseInfringementRepository.update(ceCaseInfringement);
			}
		});

		if (!infringerDecisionMap.isEmpty()) {
			infringerDecisionMap.forEach((infringerId, decisions) -> {
				CeCaseInfringer ceCaseInfringer = infringers.stream().filter(u -> u.getId().equals(infringerId)).findAny().get();

				String billRefNo = null;
				List<String> billDescriptions = new ArrayList<>();
				BigDecimal penaltyAmt = new BigDecimal(0);
				for (CeCaseDecision deci : decisions) {
					CeProvision provision = deci.getCeCaseInfringement().getCeProvision();
					billDescriptions.add(provision.getChapter().getCode() + " " + provision.getSection());
					penaltyAmt = penaltyAmt.add(deci.getPenaltyAmount());

					billRefNo = deci.getBillRefNo();
				}

				LocalDate paymentDueDate = ceTaskHelper.deriveSlaExpiryDate(LocalDate.now(), Codes.SystemParameters.CE_SLA_AFP_PAYMENT);

				// create new payment request if there is no exist bill
				if (billRefNo == null) {
					createAFPPaymentReq(ceCase, ceCaseInfringer, billDescriptions, penaltyAmt, paymentDueDate, decisions, null);
				} else {
					updateAFPPaymentReq(ceCase, ceCaseInfringer, billRefNo, billDescriptions, penaltyAmt, paymentDueDate, decisions, null);
				}

			});
		}

		if (!licenceHighestStatusMap.isEmpty()) {
			licenceHighestStatusMap.forEach((licenceId, status) -> {
				Licence licence = licSet.stream().filter(u -> u.getId().equals(licenceId)).findAny().get();
				licenceHelper.updateLicenceStatus(licence, status);
			});
		}

		ceCaseDecisionRepository.update(decisionList);

		return ceCaseHelper.processCeCase(ceCase);
	}

	private boolean processAppealOutcome(List<CeCaseAppeal> appealList, CeCase ceCase) {

		Set<CeCaseInfringer> infringers = new HashSet<>();
		HashMap<Integer, List<CeCaseAppeal>> infringerAppealMap = new LinkedHashMap<>();
		HashMap<Integer, Type> appealOutcomeMap = new LinkedHashMap<>();

		Set<Licence> licSet = new HashSet<>();
		HashMap<Integer, String> licenceHighestStatusMap = new HashMap<>(); // to store the highest status that going to be updated for that licence
		HashMap<Integer, LocalDate> licenceSuspendStartDateMap = new HashMap<>();
		HashMap<Integer, LocalDate> licenceSuspendEndDateMap = new HashMap<>();

		appealList.forEach(appeal -> {
			CeCaseInfringement ceCaseInfringement = appeal.getCeCaseInfringement();
			CeCaseInfringer ceCaseInfringer = ceCaseInfringement.getCeCaseInfringer();
			Licence lic = ceCaseInfringer.getLicence();

			// if there is no approved appeal then get last decision
			List<CeCaseAppeal> approvedAppealList = ceCaseAppealRepository.getApprovedAppealsByInfringementId(ceCaseInfringement.getId());
			Type prevDecisionOutcome = null;
			if (CollectionUtils.isEmpty(approvedAppealList)) {
				CeCaseDecision prevDecision = ceCaseDecisionRepository.getDecisionById(appeal.getCeCaseDecision().getId());
				prevDecisionOutcome = prevDecision.getOutcome();
			} else {
				CeCaseAppeal prevAppeal = approvedAppealList.get(0);
				CeCaseDecision prevDecision = ceCaseDecisionRepository.getDecisionById(prevAppeal.getCeCaseDecision().getId());
				prevDecisionOutcome = prevDecision.getOutcome();
			}

			if (appeal.getOutcome() != null) {
				String decisionCode = appeal.getOutcome().getCode();
				switch (decisionCode) {

				case Codes.CeRecommendation.CE_OUTCOME_NOD:
				case Codes.CeRecommendation.CE_OUTCOME_NFA:
				case Codes.CeRecommendation.CE_OUTCOME_CAUTION:
				case Codes.CeRecommendation.CE_OUTCOME_CIRCULAR:
				case Codes.CeRecommendation.CE_OUTCOME_COUNSEL:

					if (Entities.equals(prevDecisionOutcome, Codes.CeRecommendation.CE_OUTCOME_AFP)) {
						waiveOrRefundAFPPayment(appeal, ceCase.getTaTgType());
					} else if (Entities.equals(prevDecisionOutcome, Codes.CeRecommendation.CE_OUTCOME_SUSPEND)) {
						if (lic != null) {
							licenceHelper.liftSuspensionRevocation(lic);
						}
					} else if (Entities.equals(prevDecisionOutcome, Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
						if (lic != null) {
							licenceHelper.liftSuspensionRevocation(lic);
						}
					}

					ceCaseInfringement.setOutcome(appeal.getOutcome());
					ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
					ceCaseInfringementRepository.update(ceCaseInfringement);
					break;

				case Codes.CeRecommendation.CE_OUTCOME_AFP:

					appealOutcomeMap.put(appeal.getId(), prevDecisionOutcome);
					infringers.add(ceCaseInfringer);

					List<CeCaseAppeal> appeals = new ArrayList<>();
					if (infringerAppealMap.isEmpty() || !infringerAppealMap.containsKey(ceCaseInfringer.getId())) {
						appeals.add(appeal);
					} else {
						appeals = infringerAppealMap.get(ceCaseInfringer.getId());
						appeals.add(appeal);
					}
					infringerAppealMap.put(ceCaseInfringer.getId(), appeals);

					ceCaseInfringement.setOutcome(appeal.getOutcome());
					ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
					ceCaseInfringementRepository.update(ceCaseInfringement);
					break;

				case Codes.CeRecommendation.CE_OUTCOME_SUSPEND:
					if (lic != null) {
						if (checkBeforeOrSameDay(appeal.getPenaltyStatusStartDate())) {
							if (licenceHighestStatusMap.isEmpty() || !licenceHighestStatusMap.containsKey(lic.getId())) {
								licenceSuspendStartDateMap.put(lic.getId(), appeal.getPenaltyStatusStartDate());
								licenceSuspendEndDateMap.put(lic.getId(), appeal.getPenaltyStatusEndDate());
								licenceHighestStatusMap.put(lic.getId(), Codes.TaTgType.TA.equals(ceCase.getTaTgType()) ? Codes.Statuses.TA_SUSPENDED : Codes.Statuses.TG_SUSPENDED);
							}
							licSet.add(lic);
						} else {
							lic.setSuspendStartDate(appeal.getPenaltyStatusStartDate());
							lic.setSuspendEndDate(appeal.getPenaltyStatusEndDate());
							ceCaseInfringementRepository.update(lic);

							appeal.setPendingBatchJob(true);
						}
					}

					ceCaseInfringement.setOutcome(appeal.getOutcome());
					ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
					ceCaseInfringementRepository.update(ceCaseInfringement);

					break;
				case Codes.CeRecommendation.CE_OUTCOME_REVOKE:
					if (lic != null) {
						if (checkBeforeOrSameDay(appeal.getPenaltyStatusStartDate())) {
							licenceHighestStatusMap.put(lic.getId(), Codes.TaTgType.TA.equals(ceCase.getTaTgType()) ? Codes.Statuses.TA_REVOKED : Codes.Statuses.TG_REVOKED);
							licSet.add(lic);
						} else {
							lic.setSuspendStartDate(null);
							lic.setSuspendEndDate(null);
							ceCaseInfringementRepository.update(lic);

							appeal.setPendingBatchJob(true);
						}
					}

					ceCaseInfringement.setOutcome(appeal.getOutcome());
					ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
					ceCaseInfringementRepository.update(ceCaseInfringement);

					break;

				}
			}
			ceCaseAppealRepository.update(appeal);
		});

		if (!infringerAppealMap.isEmpty()) {
			LocalDate paymentDueDate = ceTaskHelper.deriveSlaExpiryDate(LocalDate.now(), Codes.SystemParameters.CE_SLA_AFP_PAYMENT);

			infringerAppealMap.forEach((infringerId, appeals) -> {
				CeCaseInfringer ceCaseInfringer = infringers.stream().filter(u -> u.getId().equals(infringerId)).findAny().get();
				Licence lic = ceCaseInfringer.getLicence();

				String billRefNo = null;
				List<String> billDescriptions = new ArrayList<>();
				BigDecimal penaltyAmt = new BigDecimal(0);
				for (CeCaseAppeal appeal : appeals) {

					CeProvision provision = appeal.getCeCaseInfringement().getCeProvision();
					billDescriptions.add(provision.getChapter().getCode() + " " + provision.getSection());
					penaltyAmt = penaltyAmt.add(appeal.getPenaltyAmount());

					Type prevDecisionOutcome = appealOutcomeMap.get(appeal.getId());
					if (Entities.equals(prevDecisionOutcome, Codes.CeRecommendation.CE_OUTCOME_AFP)) {
						billRefNo = appeal.getBillRefNo();
						appeal.setBillExpiryDate(paymentDueDate.atTime(LocalTime.MAX));
						ceCaseAppealRepository.update(appeal);

					} else if (Entities.equals(prevDecisionOutcome, Codes.CeRecommendation.CE_OUTCOME_SUSPEND)) {
						if (lic != null) {
							licenceHelper.liftSuspensionRevocation(lic);
						}
					} else if (Entities.equals(prevDecisionOutcome, Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
						if (lic != null) {
							licenceHelper.liftSuspensionRevocation(lic);
						}
					}

				}

				if (billRefNo == null) {
					// create new payment request if there is no exist bill
					createAFPPaymentReq(ceCase, ceCaseInfringer, billDescriptions, penaltyAmt, paymentDueDate, null, appeals);
				} else {
					updateAFPPaymentReq(ceCase, ceCaseInfringer, billRefNo, billDescriptions, penaltyAmt, paymentDueDate, null, appeals);
				}

			});
		}

		if (!licenceHighestStatusMap.isEmpty()) {
			licenceHighestStatusMap.forEach((licenceId, status) -> {
				Licence licence = licSet.stream().filter(u -> u.getId().equals(licenceId)).findAny().get();
				if (StringUtils.containsAny(status, Codes.Statuses.TA_SUSPENDED, Codes.Statuses.TG_SUSPENDED)) {
					licence.setSuspendStartDate(licenceSuspendStartDateMap.get(licenceId));
					licence.setSuspendEndDate(licenceSuspendEndDateMap.get(licenceId));
					licenceHelper.suspendLicence(licence);
				} else if (StringUtils.containsAny(status, Codes.Statuses.TA_REVOKED, Codes.Statuses.TG_REVOKED)) {
					licenceHelper.revokeLicence(licence);
				}
			});
		}

		ceCaseAppealRepository.update(appealList);

		return ceCaseHelper.processCeCase(ceCase);
	}

	private void createAFPPaymentReq(CeCase ceCase, CeCaseInfringer ceCaseInfringer, List<String> billDescriptions, BigDecimal penaltyAmt, LocalDate paymentDueDate, List<CeCaseDecision> decisions,
			List<CeCaseAppeal> appeals) {
		PaymentRequest payReq = paymentHelper.savePaymentRequest(ceCase.getCaseNo(), Codes.CePaymentRequestTypes.PAYREQ_CE_AFP, ceCaseInfringer.getUenUin(), ceCaseInfringer.getName(), penaltyAmt,
				billDescriptions.stream().collect(Collectors.joining(", ")), null, false, true, paymentDueDate);

		if (decisions != null) {
			decisions.forEach(deci -> {
				deci.setBillRefNo(payReq.getBillRefNo());
				deci.setBillExpiryDate(payReq.getDueDate().atTime(LocalTime.MAX));
				deci.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_NOT_PAID));
			});
			ceCaseDecisionRepository.update(decisions);
		} else {
			appeals.forEach(appeal -> {
				appeal.setBillRefNo(payReq.getBillRefNo());
				appeal.setBillExpiryDate(payReq.getDueDate().atTime(LocalTime.MAX));
				appeal.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_NOT_PAID));
			});
			ceCaseAppealRepository.update(appeals);
		}

		// create case task for AFP Payment
		ceTaskHelper.createCeTaskForAFPPayment(payReq.getBillRefNo(), payReq.getStatus(), ceCase.getOic(), ceCase.getOic(), penaltyAmt, ceCaseInfringer.getLicence(), ceCaseInfringer, paymentDueDate,
				ceCase);
	}

	private void updateAFPPaymentReq(CeCase ceCase, CeCaseInfringer ceCaseInfringer, String billRefNo, List<String> billDescriptions, BigDecimal penaltyAmt, LocalDate paymentDueDate,
			List<CeCaseDecision> decisions, List<CeCaseAppeal> appeals) {

		PaymentRequest existPayReq = paymentRepository.getPaymentRequest(billRefNo);
		boolean paymentSuccess = existPayReq.getStatus() != null && Entities.equals(existPayReq.getStatus(), Codes.Statuses.PAYREQ_SETTLED);

		if (paymentSuccess) {
			BigDecimal existAmount = existPayReq.getPayableAmount();

			if (existAmount.compareTo(penaltyAmt) > 0) {
				// if paid amount is exceed the new payment amount, system need to update payment request and insert refund amount
				BigDecimal refundAmount = existAmount.subtract(penaltyAmt);
				paymentHelper.autoApproveForPaymentRefund(refundAmount, existPayReq, ceCase.getTaTgType());
				if (decisions != null) {
					decisions.forEach(deci -> {
						deci.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_PENDING_REFUND));
					});
					ceCaseDecisionRepository.update(decisions);
				} else {
					appeals.forEach(appeal -> {
						appeal.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_PENDING_REFUND));
					});
					ceCaseAppealRepository.update(appeals);
				}
				paymentHelper.updatePaymentRequestStatuses(Arrays.asList(existPayReq.getId()), Codes.Statuses.PAYREQ_PENDING_REFUND);
				ceTaskHelper.completeCeTaskByBill(existPayReq.getBillRefNo());

				// create pending refund task
				ceTaskHelper.createCeTaskForAFPPayment(billRefNo, existPayReq.getStatus(), ceCase.getOic(), ceCase.getOic(), existAmount, ceCaseInfringer.getLicence(), ceCaseInfringer,
						existPayReq.getDueDate(), ceCase);

			} else if (existAmount.compareTo(penaltyAmt) < 0) {

				// have to complete previous AFP payment task
				ceTaskHelper.completeCeTaskByBill(existPayReq.getBillRefNo());

				// if paid amount is less than new payment amount, system need to create a new payment request with subtracted amount
				BigDecimal payableAmount = penaltyAmt.subtract(existAmount);

				PaymentRequest newPayReq = paymentHelper.savePaymentRequest(ceCase.getCaseNo(), Codes.CePaymentRequestTypes.PAYREQ_CE_AFP, ceCaseInfringer.getUenUin(), ceCaseInfringer.getName(),
						payableAmount, billDescriptions.stream().collect(Collectors.joining(", ")), null, false, true, paymentDueDate);

				if (decisions != null) {
					decisions.forEach(deci -> {
						deci.setBillRefNo(newPayReq.getBillRefNo());
						deci.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_NOT_PAID));
						deci.setBillExpiryDate(newPayReq.getDueDate().atTime(LocalTime.MAX));
					});
					ceCaseDecisionRepository.update(decisions);
				} else {
					appeals.forEach(appeal -> {
						appeal.setBillRefNo(newPayReq.getBillRefNo());
						appeal.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_NOT_PAID));
						appeal.setBillExpiryDate(newPayReq.getDueDate().atTime(LocalTime.MAX));
					});
					ceCaseAppealRepository.update(appeals);
				}

				ceTaskHelper.createCeTaskForAFPPayment(newPayReq.getBillRefNo(), newPayReq.getStatus(), ceCase.getOic(), ceCase.getOic(), payableAmount, ceCaseInfringer.getLicence(), ceCaseInfringer,
						paymentDueDate, ceCase);
			}
		} else if (Entities.equals(existPayReq.getStatus(), Codes.Statuses.PAYREQ_NOT_PAID)) {
			existPayReq.setPayableAmount(Entities.equals(existPayReq.getStatus(), Codes.Statuses.PAYREQ_NOT_PAID) ? penaltyAmt : existPayReq.getPayableAmount());
			existPayReq.setDueDate(paymentDueDate);
			paymentRepository.update(existPayReq);

			ceTaskHelper.createCeTaskForAFPPayment(existPayReq.getBillRefNo(), existPayReq.getStatus(), ceCase.getOic(), ceCase.getOic(), penaltyAmt, ceCaseInfringer.getLicence(), ceCaseInfringer,
					existPayReq.getDueDate(), ceCase);
		}
	}

	private void waiveOrRefundAFPPayment(CeCaseAppeal appeal, String taTgType) {
		String billRefNo = appeal.getBillRefNo();
		if (StringUtils.isBlank(billRefNo)) {
			throw new ValidationException("No Bill Reference No found.");
		}

		paymentHelper.waiveOrRefundPayment(billRefNo, taTgType, appeal);
	}

	private void createCeTaskAfterLetterIssued(Workflow workflow, CeCase ceCase, CeCasesDto dto, LocalDate letterIssuanceDate) {
		if (workflow != null && workflow.getLastAction() != null && Entities.equals(workflow.getLastAction().getStatus(), Codes.Statuses.CE_WKFLW_APPR)) {

			String currentWorkflowType = workflow.getType().getCode();
			boolean nextCaseTaskRequired = true;
			boolean isRescind = false;
			String nexTaskType = null;
			String nextTaskStatus = null;
			String nextWorkflowType = null;
			switch (currentWorkflowType) {
			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
				nexTaskType = Codes.CeTaskTypes.CE_TASK_DECISION;
				nextTaskStatus = Codes.CeTaskStatus.CE_TASK_TO_IMPOSE_DECISION;
				nextWorkflowType = (Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND.equals(currentWorkflowType)) ? Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION
						: Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION;
				break;

			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
				nexTaskType = Codes.CeTaskTypes.CE_TASK_APPEAL;
				nextTaskStatus = Codes.CeTaskStatus.CE_TASK_TO_APPEAL;
				nextWorkflowType = (Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION.equals(currentWorkflowType)) ? Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL
						: Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL;
				break;

			case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
			case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
				isRescind = true;
				nextCaseTaskRequired = false;
				break;

			default:
				nextCaseTaskRequired = false;
				break;

			}

			if (nextCaseTaskRequired) {
				if (dto != null) {
					dto.setIsTaskCreated(true);
				}
				ceTaskHelper.createCeTaskForCeCase(ceCase, null, nexTaskType, nextTaskStatus, getSlaParameterByWkflwTypeCode(nextWorkflowType), letterIssuanceDate);
			} else {
				if (dto != null) {
					dto.setIsTaskCreated(true);
				}
				ceTaskHelper.completeCeTaskByCeCase(ceCase, isRescind);
			}

		}
	}

	/*
	 * Send Letter Issuance
	 * 
	 */
	private void sendLetterIssuanceForRecomm(List<CeCaseRecommendation> recommendationList) {
		Set<File> fileSet = new HashSet<>();
		Map<Integer, List<CeCaseInfringement>> infringementsLetter = new HashMap<>();
		for (CeCaseRecommendation recommendation : recommendationList) {
			File letter = recommendation.getLetter();
			fileSet.add(letter);
			if (recommendation.getToEmailLetter() && letter != null) {
				if (infringementsLetter.containsKey(letter.getId())) {
					List<CeCaseInfringement> infringements = infringementsLetter.get(letter.getId());
					infringements.add(recommendation.getCeCaseInfringement());

					infringementsLetter.put(letter.getId(), infringements);
				} else {
					infringementsLetter.put(letter.getId(), new ArrayList<>(Arrays.asList(recommendation.getCeCaseInfringement())));
				}

			}
		}

		sendLetterIssuance(infringementsLetter, fileSet, true, false, false, false, null);
	}

	private void sendLetterIssuanceForDecision(List<CeCaseDecision> decisionList) {
		Set<File> fileSet = new HashSet<>();
		Map<Integer, List<CeCaseInfringement>> infringementsLetter = new HashMap<>();
		decisionList.forEach(decision -> {
			File letter = decision.getLetter();
			fileSet.add(letter);
			if (decision.getToEmailLetter() && letter != null) {
				if (infringementsLetter.containsKey(letter.getId())) {
					List<CeCaseInfringement> infringements = infringementsLetter.get(letter.getId());
					infringements.add(decision.getCeCaseInfringement());

					infringementsLetter.put(letter.getId(), infringements);
				} else {
					infringementsLetter.put(letter.getId(), new ArrayList<>(Arrays.asList(decision.getCeCaseInfringement())));
				}

			}

		});

		sendLetterIssuance(infringementsLetter, fileSet, false, true, false, false, null);
	}

	private void sendLetterIssuanceForAppeal(List<CeCaseAppeal> appealList) {
		Set<File> fileSet = new HashSet<>();
		Map<Integer, List<CeCaseInfringement>> infringementsLetter = new HashMap<>();
		appealList.forEach(appl -> {
			File letter = appl.getLetter();
			fileSet.add(letter);
			if (appl.getToEmailLetter() && letter != null) {
				if (infringementsLetter.containsKey(letter.getId())) {
					List<CeCaseInfringement> infringements = infringementsLetter.get(letter.getId());
					infringements.add(appl.getCeCaseInfringement());

					infringementsLetter.put(letter.getId(), infringements);
				} else {
					infringementsLetter.put(letter.getId(), new ArrayList<>(Arrays.asList(appl.getCeCaseInfringement())));
				}

			}

		});

		sendLetterIssuance(infringementsLetter, fileSet, false, false, true, false, null);
	}

	private void sendLetterIssuanceForRescind(List<CeCaseRescind> rescindList) {
		Set<File> fileSet = new HashSet<>();
		Map<Integer, List<CeCaseInfringement>> infringementsLetter = new HashMap<>();
		rescindList.forEach(rescind -> {
			File letter = rescind.getLetter();
			fileSet.add(letter);
			if (rescind.getToEmailLetter() && letter != null) {
				if (infringementsLetter.containsKey(letter.getId())) {
					List<CeCaseInfringement> infringements = infringementsLetter.get(letter.getId());
					infringements.add(rescind.getCeCaseInfringement());

					infringementsLetter.put(letter.getId(), infringements);
				} else {
					infringementsLetter.put(letter.getId(), new ArrayList<>(Arrays.asList(rescind.getCeCaseInfringement())));
				}

			}

		});

		sendLetterIssuance(infringementsLetter, fileSet, false, false, false, true, rescindList);
	}

	private void sendLetterIssuance(Map<Integer, List<CeCaseInfringement>> infringementsLetter, Set<File> fileSet, boolean isRecommendation, boolean isDecision, boolean isAppeal, boolean isRescind,
			List<CeCaseRescind> rescindList) {
		infringementsLetter.forEach((letterId, infringements) -> {
			File letter = fileSet.stream().filter(u -> u.getId().equals(letterId)).findFirst().get();

			CeCaseInfringer infringer = infringements.get(0).getCeCaseInfringer();
			Licence lic = infringer.getLicence();
			if (lic != null) {
				EmailLog log = null;
				TravelAgent ta = lic.getTravelAgent();
				if (ta != null && ta.getEmailAddress() != null) {
					log = emailHelper.emailLetterIssuance(infringements, Codes.EmailType.CNE_CASE_LETTER_ISSUANCE, fileHelper.getPhyiscalFile(letter), ta.getName(), ta.getEmailAddress());
				}

				TouristGuide tg = lic.getTouristGuide();
				if (tg != null && tg.getEmailAddress() != null) {
					log = emailHelper.emailLetterIssuance(infringements, Codes.EmailType.CNE_CASE_LETTER_ISSUANCE, fileHelper.getPhyiscalFile(letter), tg.getName(), tg.getEmailAddress());
				}

				if (log != null) {
					for (CeCaseInfringement inf : infringements) {
						if (isRecommendation) {
							CeCaseRecommendation lastRecomm = inf.getLastRecommendation();
							lastRecomm.setLetterEmailLog(log);
							ceCaseRecommendationRepository.update(lastRecomm);
						} else if (isDecision) {
							CeCaseDecision lastDecision = inf.getLastDecision();
							lastDecision.setLetterEmailLog(log);
							ceCaseDecisionRepository.update(lastDecision);
						} else if (isAppeal) {
							CeCaseDecision deci = inf.getLastDecision();
							CeCaseAppeal appeal = deci.getCeCaseAppeal();
							appeal.setLetterEmailLog(log);
							ceCaseAppealRepository.update(appeal);
						} else if (isRescind) {
							List<CeCaseRescind> rescinds = rescindList.stream()
									.filter(u -> infringements.stream().filter(infr -> infr.getId().equals(u.getCeCaseInfringement().getId())).findAny().isPresent()).collect(Collectors.toList());
							for (CeCaseRescind rescind : rescinds) {
								rescind.setLetterEmailLog(log);
							}
							ceCaseRescindRepository.update(rescinds);
						}
					}
					ceCaseInfringementRepository.update(infringements);
				}
			}

		});
	}

	private String getTaskTypeByWkflwTypeCode(String wkflwTypeCode) {
		switch (wkflwTypeCode) {
		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
			return Codes.CeTaskTypes.CE_TASK_RECOMMEND;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
			return Codes.CeTaskTypes.CE_TASK_DECISION;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
			return Codes.CeTaskTypes.CE_TASK_APPEAL;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
			return Codes.CeTaskTypes.CE_TASK_RESCIND;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_LIFT:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_LIFT:

			break;

		}

		return null;
	}

	private String getTaskStatusByWkflwTypeCode(String wkflwTypeCode) {
		switch (wkflwTypeCode) {
		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
			return Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
			return Codes.CeTaskStatus.CE_TASK_TO_IMPOSE_DECISION;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
			return Codes.CeTaskStatus.CE_TASK_TO_APPEAL;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
			return Codes.CeTaskStatus.CE_TASK_TO_RESCIND;
		}

		return null;
	}

	private String getSlaParameterByWkflwTypeCode(String wkflwTypeCode) {
		switch (wkflwTypeCode) {
		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
			return Codes.SystemParameters.CE_TA_SLA_SUBMIT_RECOMMENDATION;

		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
			return Codes.SystemParameters.CE_TG_SLA_SUBMIT_RECOMMENDATION;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_DECISION:
			return Codes.SystemParameters.CE_TA_SLA_IMPOSE_DECISION_WITHOUT_SHOW_CAUSE;

		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_DECISION:
			return Codes.SystemParameters.CE_TG_SLA_IMPOSE_DECISION_WITHOUT_SHOW_CAUSE;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL:
			return Codes.SystemParameters.CE_TA_SLA_APPEAL;

		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL:
			return Codes.SystemParameters.CE_TG_SLA_APPEAL;

		case Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND:
			return Codes.SystemParameters.CE_SLA_TA_RESCIND;

		case Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND:
			return Codes.SystemParameters.CE_SLA_TA_RESCIND;
		}

		return null;
	}

	private Boolean checkCaseIsNew(Integer ceCaseId) {
		List<CeCaseRecommendation> ceCaseRecommendations = ceCaseRecommendationRepository.getApprovedRecommendationsByCaseId(ceCaseId);
		return CollectionUtils.isEmpty(ceCaseRecommendations);
	}

	private boolean checkBeforeOrSameDay(LocalDate startDate) {
		return startDate.isBefore(LocalDate.now()) || startDate.isEqual(LocalDate.now());
	}

	private boolean isCompleteOutcome(String outcome) {
		return StringUtils.containsAny(outcome, Codes.CeRecommendation.COMPLETED_OUTCOME);
	}

	private LocalDate getLatestDate(LocalDate existDate, LocalDate newDate) {
		LocalDate latestDate = existDate;
		if (latestDate == null) {
			latestDate = newDate;
		} else {
			if (newDate.isAfter(latestDate)) {
				latestDate = newDate;
			}
		}

		return latestDate;
	}
}
