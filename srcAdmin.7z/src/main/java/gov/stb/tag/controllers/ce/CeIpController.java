package gov.stb.tag.controllers.ce;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ce.ip.CeIpComplainantDto;
import gov.stb.tag.dto.ce.ip.CeIpCompositionDto;
import gov.stb.tag.dto.ce.ip.CeIpCompositionWorkflowDto;
import gov.stb.tag.dto.ce.ip.CeIpDto;
import gov.stb.tag.dto.ce.ip.CeIpInfringementDto;
import gov.stb.tag.dto.ce.ip.CeIpInfringerDto;
import gov.stb.tag.dto.ce.ip.CeIpRevIpDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseComplainant;
import gov.stb.tag.model.CeCaseComposition;
import gov.stb.tag.model.CeCaseExternalIp;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.EmailLog;
import gov.stb.tag.model.File;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.ce.CeCaseInfringerRepository;
import gov.stb.tag.repository.ce.CeIpRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/ce/ip")
@Transactional
public class CeIpController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeIpRepository ceIpRepository;
	@Autowired
	TouristGuideRepository touristGuideRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	CeCaseInfringerRepository ceCaseInfringerRepository;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	TgHelper tgHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;

	@RequestMapping(value = "/view/{ipId}", method = RequestMethod.GET)
	public CeIpDto viewIp(@PathVariable Integer ipId) {
		CeCase ceIp = ceIpRepository.getCeCase(ipId);
		if (ceIp != null) {
			List<CeCaseInfringement> infringements = ceIpRepository.getCeCaseInfringements(ipId);
			return new CeIpDto(ceIp, infringements, fileHelper, cache);
		} else {
			return new CeIpDto();
		}
	}

	@RequestMapping(value = "/view/relevant", method = RequestMethod.GET)
	public CeIpRevIpDto viewRevIp(@RequestParam String caseNo) {
		CeCase ceIp = ceIpRepository.getRevIp(caseNo);
		if (ceIp != null) {
			return new CeIpRevIpDto(ceIp);
		} else {
			return new CeIpRevIpDto(caseNo);
		}
	}

	// to search person details by uin
	@RequestMapping(path = { "/view/licence/{idTypeCode}/{uenUin}" }, method = RequestMethod.GET)
	public CeIpInfringerDto getInfringerDetailsFromuenUin(@PathVariable String idTypeCode, @PathVariable String uenUin) {
		CeIpInfringerDto ceIpInfringerDto = new CeIpInfringerDto();

		if (Codes.Types.CE_ID_TYPE_INDIVIDUAL.equals(idTypeCode)) {
			TouristGuide tg = touristGuideRepository.getTouristGuideByUin(uenUin);
			if (tg != null) {
				ceIpInfringerDto = new CeIpInfringerDto(tg, tgHelper);
			} else {
				ceIpInfringerDto = getCeCaseInfringerByUenUin(uenUin, "Tourist Guide not found in TRUST");
			}
		} else if (Codes.Types.CE_ID_TYPE_ENTITY.equals(idTypeCode)) {
			TravelAgent ta = travelAgentRepository.getTaByUen(uenUin);
			if (ta != null) {
				ceIpInfringerDto = new CeIpInfringerDto(ta);
			} else {
				ceIpInfringerDto = getCeCaseInfringerByUenUin(uenUin, "Tourist Guide not found in TRUST");
			}
		}

		return ceIpInfringerDto;
	}

	// to save
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveIp(@RequestBody CeIpDto dto) {

		CeCase ceIp = ceIpRepository.get(CeCase.class, dto.getId());
		String previousStatusCode = ceIp.getStatus() != null ? ceIp.getStatus().getCode() : "";
		ceIp.setStatus(cache.getStatus(dto.getStatus().getKeyString()));

		// if(ceIp.isComplex() == null || ceIp.isComplex() != dto.getIsComplex()) {
		ceIp.setIsComplex(dto.getIsComplex());

		// get ceTask
		List<CeTask> ipTasks = ceTaskHelper.getCeTasksByIpId(ceIp.getId(), false);
		ipTasks.forEach(ipTask -> {
			ipTask.setSlaExpiryDate(ceIp.getCreatedDate().toLocalDate()
					.plusDays(ceIp.isComplex() ? cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_IP_COMPLEX_SLA) : cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_IP_SLA)));
			ceIpRepository.save(ipTask);
		});
		// }

		for (CeIpComplainantDto complainantDto : dto.getComplainants()) {
			CeCaseComplainant complainant;
			if (complainantDto.getId() != null) {
				complainant = ceIpRepository.load(CeCaseComplainant.class, complainantDto.getId());
			} else {
				complainant = new CeCaseComplainant();
				complainant.setCeCase(ceIp);
			}

			complainant.setName(complainantDto.getName());
			complainant.setIdType(cache.getType(complainantDto.getIdType().getKeyString()));
			complainant.setUenUin(complainantDto.getUenUin());
			complainant.setType(cache.getType(complainantDto.getType().getKeyString()));

			ceIpRepository.saveOrUpdate(complainant);
		}

		for (Integer tobeDeletedId : dto.getDeletedComplainants()) {
			CeCaseComplainant tobeDeleted = ceIpRepository.load(CeCaseComplainant.class, tobeDeletedId);
			tobeDeleted.setIsDeleted(true);// soft delete
			ceIpRepository.update(tobeDeleted);
		}

		for (CeIpInfringementDto infringementDto : dto.getInfringements()) {
			CeCaseInfringement infringement;
			CeCaseInfringer infringer;

			if (infringementDto.getId() != null) {
				infringement = ceIpRepository.load(CeCaseInfringement.class, infringementDto.getId());
			} else {
				infringement = new CeCaseInfringement();
				infringement.setCeCase(ceIp);
				infringement.setCeOriginatingCase(ceIp);
			}

			if (infringementDto.getInfringerId() != null) {
				infringer = ceIpRepository.load(CeCaseInfringer.class, infringementDto.getInfringerId());
			} else {
				infringer = new CeCaseInfringer();
				infringer.setCeCase(ceIp);
			}
			infringement.setCeCaseInfringer(infringer);
			infringer.setIdType(cache.getType(infringementDto.getIdType().getKeyString()));
			infringer.setName(infringementDto.getName());
			infringer.setUenUin(infringementDto.getUenUin());
			infringer.setLicence(ceIpRepository.getLicenceByLicenceNo(infringementDto.getLicenceNo()));
			infringer.setCategory(infringementDto.getCategory());
			infringer.setNationality(cache.getType(infringementDto.getNationality().getKeyString()));
			infringer.setAgeGroup(cache.getType(infringementDto.getAgeGroup().getKeyString()));
			infringer.setGuidingLanguageProvided(cache.getType(infringementDto.getGuidingLanguageProvided().getKeyString()));

			infringement.setIpOffenceCount(infringementDto.getIpOffenceCount());
			infringement.setInfringedDate(infringementDto.getOffenceDate() != null ? infringementDto.getOffenceDate().atStartOfDay() : null);
			if (infringementDto.getProvision().getId() != null) {
				infringement.setCeProvision(ceIpRepository.load(CeProvision.class, infringementDto.getProvision().getId()));
			}
			Set<CeProvision> readWiths = new HashSet<CeProvision>();
			if (infringementDto.getProvisionsReadWith() != null) {
				for (CeProvisionDto provisionDto : infringementDto.getProvisionsReadWith()) {
					readWiths.add(ceIpRepository.load(CeProvision.class, provisionDto.getId()));
				}
			}
			infringement.setReadWiths(readWiths);
			infringement.setOutcome(cache.getType(infringementDto.getOutcome().getKeyString()));
			infringement.setIpSentencingDetails(infringementDto.getIpSentencingDetails());
			infringement.setIpCourtCaseNo(infringementDto.getIpCourtCaseNo());
			infringement.setOutcomeDate(infringementDto.getOutcomeDate() != null ? infringementDto.getOutcomeDate().atStartOfDay() : null);
			infringement.setLocation(infringementDto.getLocation());

			ceIpRepository.saveOrUpdate(infringement);
			ceIpRepository.saveOrUpdate(infringer);
		}

		for (Integer tobeDeletedId : dto.getDeletedInfringements()) {
			CeCaseInfringement tobeDeleted = ceIpRepository.load(CeCaseInfringement.class, tobeDeletedId);
			tobeDeleted.setIsDeleted(true);// soft delete
			ceIpRepository.update(tobeDeleted);
		}

		Set<CeCase> revInternalIps = new HashSet<CeCase>();
		for (CeIpRevIpDto revIpDto : dto.getRevIps()) {
			if (revIpDto.getTypeCode().equals(Codes.revelantIpType.INTERNAL)) {
				revInternalIps.add(ceIpRepository.load(CeCase.class, revIpDto.getId()));
			} else {
				CeCaseExternalIp externalIp;
				if (revIpDto.getId() == null) {
					externalIp = new CeCaseExternalIp();
				} else {
					externalIp = ceIpRepository.load(CeCaseExternalIp.class, revIpDto.getId());
				}
				externalIp.setCeCase(ceIp);
				externalIp.setCaseNo(revIpDto.getCaseNo());
				externalIp.setStatus(cache.getStatus(revIpDto.getStatus().getKeyString()));
				externalIp.setOic(revIpDto.getOic());
				externalIp.setOicContactNo(revIpDto.getOicContactNumber());
				ceIpRepository.saveOrUpdate(externalIp);
			}

		}
		ceIp.setCeCaseInternalIps(revInternalIps);

		for (Integer tobeDeletedId : dto.getDeletedRevIps()) {
			CeCaseExternalIp tobeDeleted = ceIpRepository.load(CeCaseExternalIp.class, tobeDeletedId);
			tobeDeleted.setIsDeleted(true);// soft delete
			ceIpRepository.update(tobeDeleted);
		}

		if (CollectionUtils.isNotEmpty(dto.getOthAttachments())) {
			List<File> files = fileRepository.getFiles(dto.getOthAttachments().stream().map(FileDto::getId).collect(Collectors.toList()));
			for (File file : files) {
				FileDto fDto = dto.getOthAttachments().stream().filter(u -> u.getId().equals(file.getId())).findFirst().get();
				file.setDescription(fDto.getDescription());
			}
			ceIp.setFiles(new HashSet<File>(files));
		}
		fileHelper.deleteAllFiles(dto.getOthDeletedAttachments());

		for (CeIpCompositionDto compoDto : dto.getCompositions()) {
			saveOrUpdateCompo(compoDto);
		}

		if (Codes.CeCaseStatus.CE_CASE_CLOSED.equals(dto.getStatus().getKeyString()) && !Codes.CeCaseStatus.CE_CASE_CLOSED.equals(previousStatusCode)) {
			Set<CeCaseInfringement> infringements = ceIp.getCeCaseInfringements();
			infringements.forEach(inf -> inf.setIsConcluded(true));
			ceIpRepository.update(infringements);

			ceTaskHelper.completeCeTaskByCeIp(ceIp, true);
			if (ceIp.getTaggedCase() != null) {
				ceCaseHelper.processCeCase(ceIp.getTaggedCase());
			}
		}

		ceIpRepository.update(ceIp);
	}

	@RequestMapping(value = "/view/composition/{ipId}", method = RequestMethod.GET)
	public CeIpCompositionWorkflowDto viewIpCompo(@PathVariable Integer ipId) {
		CeCase ceIp = ceIpRepository.getCeCase(ipId);
		List<CeCaseComposition> compositions = ceIpRepository.getCompositions(ipId);

		if (ceIp != null) {
			List<CeCaseInfringement> infringements = ceIpRepository.getCeCaseInfringements(ipId);
			return new CeIpCompositionWorkflowDto(ceIp, infringements, compositions, fileHelper, cache, workflowHelper, getUser(), paymentHelper);
		} else {
			return new CeIpCompositionWorkflowDto();
		}
	}

	@RequestMapping(value = "/view/composition-workflow/{ipId}", method = RequestMethod.GET)
	public CeIpCompositionWorkflowDto viewIpCompoWorkflow(@PathVariable Integer ipId) {
		CeCase ceIp = ceIpRepository.getCeCase(ipId);

		List<CeCaseComposition> compositions = ceIpRepository.getPendingCompositions(ipId);

		if (compositions.size() != 0) {
			return new CeIpCompositionWorkflowDto(ceIp, compositions, fileHelper, cache, workflowHelper, getUser(), paymentHelper);
		} else {
			return new CeIpCompositionWorkflowDto();
		}
	}

	// to submit, approve, route-back
	@RequestMapping(value = "/composition/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody CeIpCompositionWorkflowDto dto, @PathVariable String action, @PathVariable Integer id) {

		CeCase ip = ceIpRepository.getCeCase(id);

		switch (action) {
		case ACTION_SUBMIT: // submit for approval

			for (CeIpCompositionDto compoDto : dto.getCompositions()) {
				CeCaseComposition compo = saveOrUpdateCompo(compoDto);
				compo.setPayReqStatus(cache.getStatus(compoDto.getStatus().getKeyString()));

				if (compo.getWorkflow() == null) {
					// first submission, save new workflow
					String workflowType = ip.getTaTgType().equalsIgnoreCase(Codes.TaTgType.TA) ? Codes.Workflow.CE_WKFLW_TA_IP_COMPO_IMPOSE : Codes.Workflow.CE_WKFLW_TG_IP_COMPO_IMPOSE;
					Workflow workflow = workflowHelper.saveNewWorkflow(workflowType, dto.getInternalRemarks(), null, null, true, null, dto.getSupporterId(), dto.getApproverId());
					compo.setWorkflow(workflow);
				} else {
					/*
					 * if (Codes.Statuses.CE_WKFLW_APPR.equals(compo.getWorkflow().getLastAction().getStatus().getCode())) { if (compo.getWaiveWorkflow() == null) { String workflowType =
					 * ip.getTaTgType().equalsIgnoreCase(Codes.TaTgType.TA) ? Codes.Workflow.CE_WKFLW_TA_IP_COMPO_WAIVE : Codes.Workflow.CE_WKFLW_TG_IP_COMPO_WAIVE; Workflow workflow =
					 * workflowHelper.saveNewWorkflow(workflowType, dto.getInternalRemarks(), null, null, true, null, dto.getSupporterId(), dto.getApproverId()); compo.setWaiveWorkflow(workflow); }
					 * else { // re-submission workflowHelper.forward(compo.getWaiveWorkflow(), true, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), false, dto.getFiles()); } }
					 * else {
					 */
					// re-submission
					workflowHelper.forward(compo.getWorkflow(), true, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), false, dto.getFiles());
					// }
				}

				ceIpRepository.saveOrUpdate(compo);
				ceTaskHelper.createCeTaskForComposition(ip, compo, Codes.CeTaskStatus.CE_TASK_TO_APPROVE);
			}

			break;
		case ACTION_APPROVE:
			for (CeIpCompositionDto compoDto : dto.getCompositions()) {
				CeCaseComposition compo = ceIpRepository.get(CeCaseComposition.class, compoDto.getId());
				CeCaseInfringer ceCaseInfringer = compo.getCeCaseInfringer();
				workflowHelper.forward(compo.getWorkflow(), false, dto.getInternalRemarks(), null, getUser().getId(), false, null);

				if (!StringUtils.isEmpty(compo.getBillRefNo())) {
					ceTaskHelper.completeCeTaskByBill(compo.getBillRefNo());
					PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(compo.getBillRefNo());
					paymentRequest.setPayableAmount(compo.getAmount());
					paymentRequest.setDescription(compo.getDescription());
					paymentRequest.setDueDate(compo.getDueDate());
					if (Codes.Statuses.PAYREQ_WAIVED.equals(compoDto.getStatus().getKeyString())) {
						paymentRequest.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_WAIVED));
						paymentHelper.createPaymentStatusSpan(paymentRequest, cache.getStatus(Codes.Statuses.PAYREQ_WAIVED));
						paymentHelper.updatePaymentCeTask(paymentRequest);
					} else {
						ceTaskHelper.createCeTaskForCompoPayment(compo, ip);
					}
					ceIpRepository.update(paymentRequest);
				} else {
					PaymentRequest newPayReq = paymentHelper.savePaymentRequest(ip.getCaseNo(), Codes.CePaymentRequestTypes.PAYREQ_CE_COMPOSITION, ceCaseInfringer.getUenUin(),
							ceCaseInfringer.getName(), compo.getAmount(), compo.getDescription(), null, false, true, compo.getDueDate());
					compo.setBillRefNo(newPayReq.getBillRefNo());
					ceTaskHelper.createCeTaskForCompoPayment(compo, ip);
				}
				compo.setPayReqStatus(null);
				ceIpRepository.update(compo);
			}
			ceTaskHelper.completeCeTaskByCeIp(ip, false);

			break;
		case ACTION_ROUTE:
			ceTaskHelper.completeCeTaskByCeIp(ip, false);
			for (CeIpCompositionDto compoDto : dto.getCompositions()) {
				CeCaseComposition compo = ceIpRepository.get(CeCaseComposition.class, compoDto.getId());
				workflowHelper.rfa(compo.getWorkflow(), Codes.Statuses.CE_WKFLW_ROUTED, dto.getInternalRemarks(), dto.getExternalRemarks(), dto.getRecommendationCode(), dto.getFiles(),
						dto.getFileDescription(), ip.getOic().getId());
				ceTaskHelper.createCeTaskForComposition(ip, compo, Codes.CeTaskStatus.CE_TASK_TO_SUBMIT);
			}

			break;
		case ACTION_EMAIL:
			for (CeIpCompositionDto compoDto : dto.getCompositions()) {
				CeCaseComposition compo = saveOrUpdateCompo(compoDto);
				EmailLog log = emailHelper.emailLetterIssuance(Lists.newArrayList(), Codes.EmailType.CNE_COMPO_LETTER, fileHelper.getPhyiscalFile(fileHelper.getFile(compoDto.getLetter().getId())),
						compoDto.getName(), compoDto.getEmail());
				compo.setLetterEmailLog(log);
				ceIpRepository.update(compo);
			}
			break;
		default:
			throw new ValidationException("Action received is invalid: " + action);
		}
	}

	/*
	 * private Workflow getWorkflow(CeCaseComposition compo) { if (compo.getWorkflow() == null) { return null; } else { if (compo.getWaiveWorkflow() == null) { return compo.getWorkflow(); } else {
	 * return compo.getWaiveWorkflow(); } } }
	 */

	private CeCaseComposition saveOrUpdateCompo(CeIpCompositionDto compoDto) {
		CeCaseComposition compo;
		if (compoDto.getId() != null) {
			compo = ceIpRepository.get(CeCaseComposition.class, compoDto.getId());
		} else {
			compo = new CeCaseComposition();
		}

		compo.setCeCaseInfringer(ceIpRepository.load(CeCaseInfringer.class, compoDto.getInfringerId()));
		compo.setDescription(compoDto.getDescription());
		compo.setEmail(compoDto.getEmail());
		compo.setAmount(compoDto.getAmount());
		compo.setRemarks(compoDto.getRemarks());
		compo.setDueDate(compoDto.getDueDate());
		compo.setLetter(fileHelper.getFile(compoDto.getLetter().getId()));

		ceIpRepository.saveOrUpdate(compo);
		return compo;
	}

	private CeIpInfringerDto getCeCaseInfringerByUenUin(String uenUin, String errorMessage) {
		CeCaseInfringer ceCaseInfringer = ceCaseInfringerRepository.getCeCaseInfringerByUenUin(uenUin);

		if (ceCaseInfringer != null) {
			return new CeIpInfringerDto(ceCaseInfringer);
		} else {
			throw new ValidationException(errorMessage);
		}

	}
}
