package gov.stb.tag.controllers.ce;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.tg.schedule.CeTgCheckScheduleDto;
import gov.stb.tag.dto.ce.tg.schedule.CeTgCheckScheduleItemDto;
import gov.stb.tag.dto.ce.tg.schedule.CeTgCheckScheduleItemLocationDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeTgCheckSchedule;
import gov.stb.tag.model.CeTgCheckScheduleItem;
import gov.stb.tag.model.CeTgCheckScheduleItemLocation;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ce.CeTgCheckScheduleRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ce/tg-check-schedules")
@Transactional
public class CeTgCheckScheduleController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTgCheckScheduleRepository ceTgCheckScheduleRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;

	@RequestMapping(value = "/view/{year}/{fromDateString}", method = RequestMethod.GET)
	public CeTgCheckScheduleDto viewSchedule(@PathVariable Integer year, @PathVariable String fromDateString) {

		LocalDate fromDate = DateUtil.parseDate(fromDateString);

		CeTgCheckSchedule ceTgCheckSchedule = ceTgCheckScheduleRepository.getSchedule(year, fromDate);
		if (ceTgCheckSchedule != null) {
			if (ceTgCheckSchedule.getFromDate().isAfter(ceTgCheckSchedule.getToDate())) {
				logger.error("ceTgCheckSchedule id {}: from date {} is after to date {}", ceTgCheckSchedule.getId(), ceTgCheckSchedule.getFromDate(), ceTgCheckSchedule.getToDate());
				throw new ValidationException("Schedule From Date is greater than Schedule To Date");
			}
			return new CeTgCheckScheduleDto(cache, workflowHelper, ceTgCheckSchedule, userRepository.getUserByLoginId(ceTgCheckSchedule.getCreatedBy()));
		} else {
			return new CeTgCheckScheduleDto(year, fromDate);
		}

	}

	@RequestMapping(value = "/view/years", method = RequestMethod.GET)
	public Integer[] viewYears() {

		Integer[] years;
		LocalDate currentDate = LocalDate.now().plusWeeks(Codes.Constants.CE_SCHEDULE_ADDITIONAL_WEEKS);

		years = new Integer[currentDate.getYear() - Codes.Constants.CE_SCHEDULE_START_YEAR + 1];
		for (int i = 0; i < years.length; i++) {
			years[i] = Codes.Constants.CE_SCHEDULE_START_YEAR + i;
		}

		return years;
	}

	@RequestMapping(value = "/view/fromDates/{year}", method = RequestMethod.GET)
	public List<ListableDto> viewfromDates(@PathVariable Integer year) {

		List<ListableDto> fromDates = new ArrayList<ListableDto>();

		LocalDate firstDayOfFirstWeek = LocalDate.of(year, 1, 1).with(DayOfWeek.MONDAY);
		LocalDate firstDayOfLastWeek = LocalDate.of(year, 12, 31).with(DayOfWeek.MONDAY);

		LocalDate firstDayOfLastWeekOfCurrentYear = LocalDate.now().with(DayOfWeek.MONDAY).plusWeeks(Codes.Constants.CE_SCHEDULE_ADDITIONAL_WEEKS);
		if (year.equals(firstDayOfLastWeekOfCurrentYear.getYear())) {
			firstDayOfLastWeek = firstDayOfLastWeekOfCurrentYear;
		}

		LocalDate currWeek = firstDayOfFirstWeek;
		while (currWeek.isBefore(firstDayOfLastWeek.plusWeeks(1))) {
			fromDates.add(new ListableDto(currWeek, DateUtil.format(currWeek) + " to " + DateUtil.format(currWeek.plusDays(6))));
			currWeek = currWeek.plusDays(7);
		}

		return fromDates;

	}

	@RequestMapping(value = "/view/eo", method = RequestMethod.GET)
	public List<ListableDto> viewSchedule() {

		return toListableDtos(userRepository.getActiveUsersByRole(Codes.Roles.TG_CNE_ENFORCEMENT_OFFICER));

	}

	// to save schedule
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveTgSchedule(@RequestBody CeTgCheckScheduleDto dto) {

		CeTgCheckSchedule schedule = saveSchedule(dto);

		if (schedule.getWorkflow() != null) {
			Workflow workflow = schedule.getWorkflow();
			workflowHelper.edit(workflow, dto.getInternalRemarks());
		}

		ceTaskHelper.createOrUpdateCeTaskForCeCheckScheduleWorkflow(null, schedule);

	}

	// to submit, approve, route-back
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody CeTgCheckScheduleDto dto, @PathVariable String action, @PathVariable Integer id) {

		CeTgCheckSchedule schedule = saveSchedule(dto);

		switch (action) {
		case ACTION_SUBMIT: // submit for approval

			if (schedule.getWorkflow() == null) {
				// first submission, save new workflow
				Workflow workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.CE_WKFLW_TG_SCHEDULE, dto.getInternalRemarks(), null, null, true, null, dto.getSupporterId(), dto.getApproverId());
				schedule.setWorkflow(workflow);
			} else {
				// re-submission
				workflowHelper.forward(schedule.getWorkflow(), true, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), false, dto.getFiles());
			}

			ceTaskHelper.createOrUpdateCeTaskForCeCheckScheduleWorkflow(null, schedule);

			break;
		case ACTION_APPROVE:
			workflowHelper.forward(schedule.getWorkflow(), false, dto.getInternalRemarks(), null, null, false, dto.getFiles());

			// delete last approved, and snapshot a new set of approved schedule items
			List<CeTgCheckScheduleItem> lastApprovedItems = schedule.getCeTgCheckScheduleItems().stream().filter(item -> item.isApproved() && !item.getIsDeleted()).collect(Collectors.toList());
			for (CeTgCheckScheduleItem lastApprovedItem : lastApprovedItems) {
				if (lastApprovedItem.isEditable()) {
					lastApprovedItem.setIsDeleted(true);
				}
			}
			if (CollectionUtils.isEmpty(lastApprovedItems)) {
				ceTgCheckScheduleRepository.save(lastApprovedItems);
			}

			List<CeTgCheckScheduleItem> confirmedItems = schedule.getCeTgCheckScheduleItems().stream().filter(item -> !item.isApproved() && !item.getIsDeleted()).collect(Collectors.toList());
			for (CeTgCheckScheduleItem confirmedItem : confirmedItems) {
				if (confirmedItem.isEditable()) {
					logger.info("Creating new CeTaCheckScheduleItem for approved, snaphot from confirmed scheduleItemId: {}", confirmedItem.getId());
					snapshotApprovedCeTgCheckScheduleItem(confirmedItem);
				}
			}

			ceTaskHelper.completeCeTaskByScheduleWeek(schedule.getYear(), schedule.getFromDate(), schedule.getToDate());

			break;
		case ACTION_ROUTE:
			User oic = userRepository.getUserByLoginId(schedule.getCreatedBy());
			workflowHelper.rfa(schedule.getWorkflow(), Codes.Statuses.CE_WKFLW_ROUTED, dto.getInternalRemarks(), dto.getExternalRemarks(), dto.getRecommendationCode(), dto.getFiles(),
					dto.getFileDescription(), oic.getId());

			ceTaskHelper.createOrUpdateCeTaskForCeCheckScheduleWorkflow(null, schedule);

			break;
		default:
			throw new ValidationException("Action received is invalid: " + action);
		}
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = ceTgCheckScheduleRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void setCeTgCheckScheduleItem(CeTgCheckScheduleItem scheduleItem, CeTgCheckScheduleItemDto dto) {
		setCeTgCheckScheduleItem(scheduleItem, dto, false);
	}

	private void setCeTgCheckScheduleItem(CeTgCheckScheduleItem scheduleItem, CeTgCheckScheduleItemDto dto, Boolean isSnapshot) {
		scheduleItem.setScheduleDate(dto.getScheduleDate());
		scheduleItem.setRemarks(dto.getRemarks());
		scheduleItem.setEoUsers(dto.getEoUsers().stream().map(x -> {
			return ceTgCheckScheduleRepository.load(User.class, x);
		}).collect(Collectors.toSet()));
		scheduleItem.setOeoUsers(cache.getTypes(dto.getOeoUsers()));

		CeTgCheckScheduleItemLocation ceTgCheckSduleItemLocation;
		for (CeTgCheckScheduleItemLocationDto ceTgCheckScheduleItemLocationDto : dto.getCeTgCheckScheduleItemLocations()) {
			if (ceTgCheckScheduleItemLocationDto.getId() != null && !isSnapshot) {
				ceTgCheckSduleItemLocation = ceTgCheckScheduleRepository.get(CeTgCheckScheduleItemLocation.class, ceTgCheckScheduleItemLocationDto.getId());
			} else {
				ceTgCheckSduleItemLocation = new CeTgCheckScheduleItemLocation();
				ceTgCheckSduleItemLocation.setCeTgCheckScheduleItem(scheduleItem);
			}
			ceTgCheckSduleItemLocation.setMeridiem(cache.getType(getListableKey(ceTgCheckScheduleItemLocationDto.getMeridiem())));
			ceTgCheckSduleItemLocation.setLocation(cache.getType(getListableKey(ceTgCheckScheduleItemLocationDto.getLocation())));
			ceTgCheckScheduleRepository.saveOrUpdate(ceTgCheckSduleItemLocation);
		}

		for (Integer tobeDeletedId : dto.getCeTgCheckScheduleItemLocationsToBeDeleted()) {
			CeTgCheckScheduleItemLocation tobeDeleted = ceTgCheckScheduleRepository.load(CeTgCheckScheduleItemLocation.class, tobeDeletedId);
			tobeDeleted.setIsDeleted(true);// soft delete
			ceTgCheckScheduleRepository.save(tobeDeleted);
		}
	}

	private String getListableKey(ListableDto listableDto) {
		return listableDto != null ? listableDto.getKey() != null ? listableDto.getKey().toString() : null : null;
	}

	private CeTgCheckSchedule saveSchedule(CeTgCheckScheduleDto dto) {
		CeTgCheckSchedule schedule = ceTgCheckScheduleRepository.getSchedule(dto.getYear(), dto.getFromDate());

		if (schedule == null) {
			schedule = new CeTgCheckSchedule();
			schedule.setFromDate(dto.getFromDate());
			schedule.setToDate(dto.getFromDate().plusDays(6));
			schedule.setYear(dto.getYear());
			for (CeTgCheckScheduleItemDto scheduleItemDto : dto.getCeTgCheckScheduleItems()) {
				logger.info("Creating new CeTgCheckScheduleItem");
				CeTgCheckScheduleItem scheduleItem = new CeTgCheckScheduleItem();
				scheduleItem.setCeTgCheckSchedule(schedule);
				setCeTgCheckScheduleItem(scheduleItem, scheduleItemDto);
				ceTgCheckScheduleRepository.save(scheduleItem);
			}
		} else {
			Map<LocalDate, CeTgCheckScheduleItem> scheduleItems = schedule.getCeTgCheckScheduleItems().stream()
					// remove approved
					.filter(x -> !x.getIsApproved())
					// map to map array
					.collect(Collectors.toMap(CeTgCheckScheduleItem::getScheduleDate, item -> item));
			for (CeTgCheckScheduleItemDto scheduleItemDto : dto.getCeTgCheckScheduleItems()) {
				logger.info("Updating existing CeTgCheckScheduleItem id={}", scheduleItemDto.getId());
				CeTgCheckScheduleItem scheduleItem = scheduleItems.get(scheduleItemDto.getScheduleDate());
				setCeTgCheckScheduleItem(scheduleItem, scheduleItemDto);
				ceTgCheckScheduleRepository.saveOrUpdate(scheduleItem);
			}
		}

		ceTgCheckScheduleRepository.save(schedule);
		return schedule;
	}

	private void snapshotApprovedCeTgCheckScheduleItem(CeTgCheckScheduleItem scheduleItem) {
		CeTgCheckScheduleItemDto scheduleItemDto = new CeTgCheckScheduleItemDto(scheduleItem);
		CeTgCheckScheduleItem approvedScheduleItem = new CeTgCheckScheduleItem();
		approvedScheduleItem.setCeTgCheckSchedule(scheduleItem.getCeTgCheckSchedule());
		approvedScheduleItem.setIsApproved(true);
		setCeTgCheckScheduleItem(approvedScheduleItem, scheduleItemDto, true);
		ceTgCheckScheduleRepository.save(approvedScheduleItem);

		scheduleItem.setLastApprovedCeTgCheckScheduleItem(approvedScheduleItem);
		ceTgCheckScheduleRepository.save(scheduleItem);
	}

}
