package gov.stb.tag.controllers.ce;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.CeSubmissionStatus;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.ce.tg.groundcheck.CeTgGroundCheckDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.*;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ce.CeTgGroundCheckRepository;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(path = "/api/v1/ce/tg-ground-check")
@Transactional
public class CeTgGroundCheckController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTgGroundCheckRepository ceTgGroundCheckRepository;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	UserRepository userRepository;

	@RequestMapping(path = { "/view/{checkScheduleItemLocationId}" }, method = RequestMethod.GET)
	public CeTgGroundCheckDto viewTgGroundObservation(@PathVariable Integer checkScheduleItemLocationId) {
		CeTgGroundCheckDto resultDto = new CeTgGroundCheckDto();
		Role selectedRole = userRepository.getRoleWithFunctions(getSelectedRoleCode());

		if (checkScheduleItemLocationId != null) {
			// check for existing report
			CeTgCheck ceTgCheck = ceTgGroundCheckRepository.getTgCheckFromScheduleLocation(checkScheduleItemLocationId);
			if (ceTgCheck == null) {
				CeTgCheckScheduleItemLocation scheduleItemLocation = ceTgGroundCheckRepository.get(CeTgCheckScheduleItemLocation.class, checkScheduleItemLocationId);
				if (!isEditable(scheduleItemLocation)) {
					logger.error("Unable to submit TG Ground Checks Observation for ceTgCheckScheduleLocation.id={}. Schedule is pending approval.", checkScheduleItemLocationId);
					throw new ValidationException("Schedule is pending approval.");
				}
				if (scheduleItemLocation.getCeTgCheckScheduleItem().getScheduleDate().isAfter(LocalDate.now())) {
					logger.error("Unable to submit TG Ground Checks Observation for ceTgCheckScheduleLocation.id={}. Schedule is in future date.", checkScheduleItemLocationId);
					throw new ValidationException("Schedule is in future date.");
				}
				resultDto = CeTgGroundCheckDto.buildNewObservationDto(scheduleItemLocation);
			} else {
				resultDto = CeTgGroundCheckDto.buildSubmittedObservationDto(cache, ceTgCheck, userRepository);
			}

			resultDto.setDisableEdit(!selectedRole.getFunctions().stream().filter(func -> func.getCode().equals(Codes.Permission.CE_TG_GROUND_CHECK_SAVE)).findFirst().isPresent());

		}
		return resultDto;
	}

	// to create/update tg ground check observation
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveTgGroundCheck(@RequestBody CeTgGroundCheckDto dto) {
		CeTgCheck ceTgCheck = new CeTgCheck();
		CeTgCheckScheduleItemLocation scheduleItemLocation = new CeTgCheckScheduleItemLocation();

		if (dto.getCeTgCheckId() != null) {
			ceTgCheck = ceTgGroundCheckRepository.get(CeTgCheck.class, dto.getCeTgCheckId());
		}

		if (dto.getScheduleItemLocationId() != null) {
			scheduleItemLocation = ceTgGroundCheckRepository.get(CeTgCheckScheduleItemLocation.class, dto.getScheduleItemLocationId());
		} else {
			// means the report is synced from offline, need to prompt user to key in the schedule item location ID
			throw new ValidationException("Schedule ID is required. Please access TG Checks Schedule module in the web application to retrieve schedule ID.");

		}

		updateCeCheckValues(ceTgCheck, dto, scheduleItemLocation);
		updateAttachments(dto.getFiles());

		return dto.getScheduleItemLocationId();
	}

	private CeTgCheck updateCeCheckValues(CeTgCheck ceTgCheck, CeTgGroundCheckDto dto, CeTgCheckScheduleItemLocation scheduleItemLocation) {
		ceTgCheck.setCeTgCheckScheduleItemLocation(scheduleItemLocation);

		ceTgCheck.setNoOfGrpWithTg(dto.getNoOfGrpWithTg());
		ceTgCheck.setNoOfGrpWithoutTg(dto.getNoOfGrpWithoutTg());
		ceTgCheck.setNoOfGrpWithExpert(dto.getNoOfGrpWithExpert());
		ceTgCheck.setNoOfStudGrpWithTg(dto.getNoOfStudGrpWithTg());
		ceTgCheck.setNoOfStudGrpWithTchr(dto.getNoOfStudGrpWithTchr());
		ceTgCheck.setNoOfStudGrpWithStud(dto.getNoOfStudGrpWithStud());
		ceTgCheck.setNoOfCruiseWithTg(dto.getNoOfCruiseWithTg());
		ceTgCheck.setNoOfCruiseWithoutTg(dto.getNoOfCruiseWithoutTg());
		ceTgCheck.setNoOfMiceGrpWithTg(dto.getNoOfMiceGrpWithTg());
		ceTgCheck.setNoOfMiceGrpWithExpat(dto.getNoOfMiceGrpWithExpat());

		if (dto.getFiles().size() > 0) {
			List<Integer> fileIds = dto.getFiles().parallelStream().map(AttachmentDto::getId).collect(Collectors.toList());
			if (fileIds.size() > 0) {
				List<File> files = fileRepository.getFiles(fileIds);
				ceTgCheck.setFiles(new HashSet<>(files));
			}
		}
		if (dto.getToSubmit()) {
			ceTgCheck.setIsDraft(Boolean.FALSE);
		} else {
			ceTgCheck.setIsDraft(Boolean.TRUE);
		}

		ceTgGroundCheckRepository.saveOrUpdate(ceTgCheck);

		scheduleItemLocation.setCeTgCheck(ceTgCheck);
		ceTgGroundCheckRepository.saveOrUpdate(scheduleItemLocation);

		fileHelper.softDeleteFileList(dto.getFilesToDelete());

		return ceTgCheck;
	}

	private void updateAttachments(List<AttachmentDto> filesDto) {
		if (CollectionUtils.isNotEmpty(filesDto)) {
			List<File> files = fileRepository.getFiles(filesDto.stream().map(AttachmentDto::getId).collect(Collectors.toList()));
			for (File file : files) {
				AttachmentDto fDto = filesDto.stream().filter(u -> u.getId().equals(file.getId())).findFirst().get();
				file.setDescription(fDto.getDescription());
			}
		}
	}

	private Boolean isEditable(CeTgCheckScheduleItemLocation ceTgCheckScheduleItemLocation) {
		WorkflowAction lastAction = null;
		CeTgCheckScheduleItem ceTgCheckScheduleItem = ceTgCheckScheduleItemLocation.getCeTgCheckScheduleItem();

		if (!ceTgCheckScheduleItemLocation.getCreatedBy().equalsIgnoreCase("Data Migration")) {
			lastAction = ceTgCheckScheduleItem.getCeTgCheckSchedule().getWorkflow().getLastAction();
		}

		Boolean isPendingApproval = lastAction != null && Codes.Statuses.CE_WKFLW_APPR.equals(lastAction.getStatus().getCode()) ? false : true;

		if (isPendingApproval && ceTgCheckScheduleItem.isEditable()) {
			return false;
		}
		return true;
	}

}
