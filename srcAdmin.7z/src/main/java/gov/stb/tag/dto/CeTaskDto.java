package gov.stb.tag.dto;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Map;

import com.google.common.collect.Maps;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.Role;
import gov.stb.tag.util.DateUtil;

public class CeTaskDto {

	private Integer id;
	private String name;
	private String uenUin;
	private String licenceNo;
	private String type;
	private String details;
	private String assignee;
	private String oic;
	private Long sla;
	private String status;
	private String uri;
	private Map<String, Object> params;
	private Boolean hasPermission = false;
	private String colorCode;
	private String caseNo;

	public CeTaskDto() {
		this.params = Maps.newHashMap();
	}

	public static CeTaskDto buildFromCeTask(Cache cache, CeTask ceTask, Role selectedRole) {
		CeTaskDto ceTaskDto = new CeTaskDto();
		ceTaskDto.setId(ceTask.getId());
		ceTaskDto.setName(ceTask.getName());
		ceTaskDto.setUenUin(ceTask.getUenUin());
		ceTaskDto.setLicenceNo(ceTask.getLicence() != null ? ceTask.getLicence().getLicenceNo() : null);
		ceTaskDto.setType(cache.getLabel(ceTask.getType(), false));
		ceTaskDto.setStatus(cache.getLabel(ceTask.getStatus(), false));
		ceTaskDto.setDetails(ceTask.getDetails());
		ceTaskDto.setAssignee(ceTask.getAssignee() != null ? ceTask.getAssignee().getName() : null);
		ceTaskDto.setOic(ceTask.getOic() != null ? ceTask.getOic().getName() : null);
		ceTaskDto.setSla(ceTask.getSlaExpiryDate() != null ? ChronoUnit.DAYS.between(LocalDate.now(), ceTask.getSlaExpiryDate()) : null);
		if (ceTaskDto.getSla() != null) {
			ceTaskDto.setColorCode(ceTaskDto.getSla().compareTo(0L) <= 0 ? "danger" : ceTaskDto.getSla().compareTo(3L) <= 0 ? "warning" : "success");
		}
		if (ceTask.getForCase() != null) {
			CeCase ceCase = ceTask.getForCase();
			ceTaskDto.setCaseNo(ceCase.getCaseNo());
			if (ceCase.isIp()) {
				ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_IP);
				ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_IP.concat("/").concat(ceCase.getId().toString()));
			} else {
				if (Codes.TaTgType.TA.equals(ceCase.getTaTgType())) {
					ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_TA_CASE);
					ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_CASE.concat("/ta/").concat(ceCase.getId().toString()));
				} else {
					ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_TG_CASE);
					ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_CASE.concat("/tg/").concat(ceCase.getId().toString()));
				}
			}

		} else if (Entities.equals(ceTask.getType(), Codes.CeTaskTypes.CE_TASK_TA_CHECK_SCHEDULE)) {
			ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_TA_CHECKS_SCHEDULE);
			ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_TA_CHECKS_SCHEDULE);
			ceTaskDto.getParams().put("year", ceTask.getForScheduleYear());
			ceTaskDto.getParams().put("month", ceTask.getForScheduleMonth());
		} else if (Entities.equals(ceTask.getType(), Codes.CeTaskTypes.CE_TASK_TG_CHECK_SCHEDULE)) {
			ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_TG_CHECKS_SCHEDULE);
			ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_TG_CHECKS_SCHEDULE);
			ceTaskDto.getParams().put("year", ceTask.getForScheduleYear());
			ceTaskDto.getParams().put("fromDate", DateUtil.format(ceTask.getForScheduleFromDate()));
		} else if (Entities.equals(ceTask.getType(), Codes.CeTaskTypes.CE_TASK_TA_CHECK)) {
			ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_TA_CHECKS_REPORT);
			ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_TA_CHECKS_REPORT);
		} else if (Entities.equals(ceTask.getType(), Codes.CeTaskTypes.CE_TASK_TG_CHECK)) {
			ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_TG_CHECKS_REPORT);
			ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_TG_CHECKS_REPORT);
		} else if (Entities.equals(ceTask.getType(), Codes.CeTaskTypes.CE_TASK_TA_CHECK_COMPLIANT)) {
			ceTaskDto.setHasPermission(selectedRole, Codes.Permission.VIEW_CE_TATI_COMPLIANT_CASES);
			ceTaskDto.setUri(Codes.FrontEndUrl.VIEW_CE_TATI_COMPLIANT_CASES);
		}
		return ceTaskDto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getOic() {
		return oic;
	}

	public void setOic(String oic) {
		this.oic = oic;
	}

	public Long getSla() {
		return sla;
	}

	public void setSla(Long sla) {
		this.sla = sla;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public Boolean getHasPermission() {
		return hasPermission;
	}

	public void setHasPermission(Boolean hasPermission) {
		this.hasPermission = hasPermission;
	}

	public void setHasPermission(Role selectedRole, String permissionCode) {
		this.hasPermission = selectedRole.getFunctions().stream().filter(func -> func.getCode().equals(permissionCode)).findFirst().isPresent();
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

}
