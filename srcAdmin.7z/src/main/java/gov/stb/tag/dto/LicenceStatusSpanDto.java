package gov.stb.tag.dto;

import java.time.LocalDateTime;

import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.StatusSpan;

public class LicenceStatusSpanDto extends EntityDto {

	private Integer id;
	private Integer licenceId;
	private LocalDateTime startDate;
	private LocalDateTime endDate;
	private String statusLabel;
	private String internalRemarks;
	private String externalRemarks;
	private LocalDateTime updatedDate;
	private String updatedBy;
	private String tierLabel;

	public static LicenceStatusSpanDto buildFromStatusSpan(Cache cache, StatusSpan ss) {
		LicenceStatusSpanDto dto = new LicenceStatusSpanDto();
		dto.setId(ss.getId());
		dto.setLicenceId(ss.getLicence().getId());
		dto.setStartDate(ss.getStartDate());
		dto.setEndDate(ss.getEndDate());
		dto.setStatusLabel(cache.getLabel(ss.getStatus(), false));
		dto.setInternalRemarks(ss.getInternalRemarks());
		dto.setExternalRemarks(ss.getExternalRemarks());
		dto.setUpdatedBy(ss.getUpdatedBy());
		dto.setUpdatedDate(ss.getUpdatedDate());
		dto.setTierLabel(cache.getLabel(ss.getTier(), false));
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public String getStatusLabel() {
		return statusLabel;
	}

	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getTierLabel() {
		return tierLabel;
	}

	public void setTierLabel(String tierLabel) {
		this.tierLabel = tierLabel;
	}

}
