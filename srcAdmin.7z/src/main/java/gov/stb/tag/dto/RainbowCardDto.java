package gov.stb.tag.dto;

import java.util.Map;

public class RainbowCardDto {

	private String typeCode;

	private String typeLabel;

	private String status;

	private Long count;

	private Map<String, Object> params;

	public RainbowCardDto() {

	}

	public RainbowCardDto(String typeCode, String typeLabel, String status, Long count) {
		super();
		this.typeCode = typeCode;
		this.typeLabel = typeLabel;
		this.status = status;
		this.count = count;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

}
