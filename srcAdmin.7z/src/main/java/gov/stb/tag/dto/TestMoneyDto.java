package gov.stb.tag.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.stb.tag.jackson.BigDecimalToMoneyThousandSeparatorConverter;
import gov.stb.tag.jackson.MoneyThousandSeparatorToBigDecimalConverter;

public class TestMoneyDto {

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal money;

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

}
