package gov.stb.tag.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.WorkflowAction;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowActionDto {

	@MapProjection(path = "status.label")
	private String action;

	@MapProjection(path = "internalRemarks")
	private String internalRemarks;

	@MapProjection(path = "externalRemarks")
	private String externalRemarks;

	@MapProjection(path = "createdDate")
	private LocalDateTime actionDate;

	@MapProjection(path = "createdBy")
	private String actionBy;

	@MapProjection(path = "type.label")
	private String actionType;

	@MapProjection(path = "type.code")
	private String actionTypeCode;

	@MapProjection(path = "recommendation.code")
	private String recommendationCode;

	@MapProjection(path = "recommendation.label")
	private String recommendationType;

	private List<FileDto> supportDocs;

	private String assignee;

	public WorkflowActionDto() {

	}

	public WorkflowActionDto(Cache cache, WorkflowAction wa) {
		this.action = cache.getLabel(wa.getStatus(), false);
		this.internalRemarks = wa.getInternalRemarks();
		this.externalRemarks = wa.getExternalRemarks();
		this.actionDate = wa.getCreatedDate();
		this.actionBy = wa.getCreatedBy();
		if (wa.getApplication() != null) {
			this.actionType = cache.getLabel(wa.getType(), false);
		} else {
			this.actionType = cache.getLabel(wa.getType(), true);
		}
		if (wa.getType() != null) {
			this.actionTypeCode = wa.getType().getCode();
		}
		if (wa.getRecommendation() != null) {
			this.recommendationType = cache.getLabel(wa.getRecommendation(), false);
			this.recommendationCode = wa.getRecommendation().getCode();
		}
		List<FileDto> suppDocs = new ArrayList<FileDto>();
		for (File file : wa.getFiles()) {
			suppDocs.add(FileDto.buildFromFile(file, null, null));
		}
		this.assignee = wa.getAssignee() != null ? wa.getAssignee().getName() : null;
		this.supportDocs = suppDocs;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getActionTypeCode() {
		return actionTypeCode;
	}

	public void setActionTypeCode(String actionTypeCode) {
		this.actionTypeCode = actionTypeCode;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public LocalDateTime getActionDate() {
		return actionDate;
	}

	public void setActionDate(LocalDateTime actionDate) {
		this.actionDate = actionDate;
	}

	public String getActionBy() {
		return actionBy;
	}

	public void setActionBy(String actionBy) {
		this.actionBy = actionBy;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getRecommendationType() {
		return recommendationType;
	}

	public void setRecommendationType(String recommendationType) {
		this.recommendationType = recommendationType;
	}

	public String getRecommendationCode() {
		return recommendationCode;
	}

	public void setRecommendationCode(String recommendationCode) {
		this.recommendationCode = recommendationCode;
	}

	public List<FileDto> getSupportDocs() {
		return supportDocs;
	}

	public void setSupportDocs(List<FileDto> supportDocs) {
		this.supportDocs = supportDocs;
	}

	public static List<WorkflowActionDto> toList(Cache cache, Application tlcApp) {
		List<WorkflowActionDto> workflowActionList = new LinkedList<WorkflowActionDto>();
		Set<WorkflowAction> waList = tlcApp.getWorkflowActions();
		if (waList != null) {
			List<WorkflowAction> sortedWorkflowList = waList.stream().sorted(Comparator.comparing(WorkflowAction::getId).reversed()).collect(Collectors.toList());
			for (WorkflowAction wa : sortedWorkflowList) {
				workflowActionList.add(new WorkflowActionDto(cache, wa));
			}
		}

		return workflowActionList.size() > 0 ? workflowActionList : null;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

}
