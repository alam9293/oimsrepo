package gov.stb.tag.dto;

import java.util.List;

public class WorkflowAttachmentDto {

	private List<AttachmentDto> workflowFiles;
	private List<Integer> deletedWorkflowFileIds;

	public List<AttachmentDto> getWorkflowFiles() {
		return workflowFiles;
	}

	public void setWorkflowFiles(List<AttachmentDto> workflowFiles) {
		this.workflowFiles = workflowFiles;
	}

	public List<Integer> getDeletedWorkflowFileIds() {
		return deletedWorkflowFileIds;
	}

	public void setDeletedWorkflowFileIds(List<Integer> deletedWorkflowFileIds) {
		this.deletedWorkflowFileIds = deletedWorkflowFileIds;
	}

}
