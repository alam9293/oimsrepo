package gov.stb.tag.dto.bulletin;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AllBulletinListDto {

	private List<BulletinCatgoryListingDto> recentPosts = new ArrayList<>();
	private List<BulletinCatgoryListingDto> generalBulletins = new ArrayList<>();
	private List<BulletinCatgoryListingDto> taBulletins = new ArrayList<>();
	private List<BulletinCatgoryListingDto> tgBulletins = new ArrayList<>();

	public List<BulletinCatgoryListingDto> getRecentPosts() {
		return recentPosts;
	}

	public void setRecentPosts(List<BulletinCatgoryListingDto> recentPosts) {
		this.recentPosts = recentPosts;
	}

	public List<BulletinCatgoryListingDto> getGeneralBulletins() {
		return generalBulletins;
	}

	public void setGeneralBulletins(List<BulletinCatgoryListingDto> generalBulletins) {
		this.generalBulletins = generalBulletins;
	}

	public List<BulletinCatgoryListingDto> getTaBulletins() {
		return taBulletins;
	}

	public void setTaBulletins(List<BulletinCatgoryListingDto> taBulletins) {
		this.taBulletins = taBulletins;
	}

	public List<BulletinCatgoryListingDto> getTgBulletins() {
		return tgBulletins;
	}

	public void setTgBulletins(List<BulletinCatgoryListingDto> tgBulletins) {
		this.tgBulletins = tgBulletins;
	}
}
