package gov.stb.tag.dto.bulletin;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.model.CategoryListing;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CategoryListDto {

	private Integer id;

	private String type;

	private Integer categoryId;

	private Integer fileId;

	private Integer ordinal;

	private String title;

	private String originalFilename;

	private String hash;

	private LocalDate effectiveDate;

	private LocalDate expiryDate;
	private List<FileDto> files = new ArrayList<>();

	@MapProjection(path = "updatedBy")
	private String updatedBy;

	@MapProjection(path = "updatedDate")
	private LocalDateTime updatedDate;

	private Integer fileIconId;

	private String originalIconFilename;

	private String hashIcon;

	// @MapProjection(path = "isDelisted")
	// private Boolean isDelisted;

	// private Boolean isCurrentlyDisplay;

	public static CategoryListDto buildFromCategoryListing(CategoryListing category) {

		if (category != null) {
			CategoryListDto dto = new CategoryListDto();

			dto.setId(category.getId());
			dto.setType(category.getType().getCode());
			dto.setCategoryId(category.getCategories().getId());
			dto.setFileId(category.getFileId());
			dto.setEffectiveDate(category.getEffectiveDate());
			dto.setTitle(category.getTitle());
			dto.setHash(category.getHash());
			dto.setOriginalFilename(category.getOriginalFilename());
			dto.setUpdatedBy(category.getUpdatedBy());
			dto.setUpdatedDate(category.getUpdatedDate());
			dto.setExpiryDate(category.getExpiryDate());

			dto.setFileIconId(category.getFileIconId());
			dto.setHashIcon(category.getHashIcon());
			dto.setOriginalIconFilename(category.getOriginalIconFilename());
			return dto;
		}

		return null;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/*
	 * public String getContent() { return content; }
	 * 
	 * public void setContent(String content) { this.content = content; }
	 */

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public String getOriginalFilename() {
		return originalFilename;
	}

	public void setOriginalFilename(String originalFilename) {
		this.originalFilename = originalFilename;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getFileIconId() {
		return fileIconId;
	}

	public void setFileIconId(Integer fileIconId) {
		this.fileIconId = fileIconId;
	}

	public String getOriginalIconFilename() {
		return originalIconFilename;
	}

	public void setOriginalIconFilename(String originalIconFilename) {
		this.originalIconFilename = originalIconFilename;
	}

	public String getHashIcon() {
		return hashIcon;
	}

	public void setHashIcon(String hashIcon) {
		this.hashIcon = hashIcon;
	}
}
