package gov.stb.tag.dto.ce;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.Optional;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.workflow.WorkflowDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;

public class CeCheckScheduleDto extends ApprovalDto {

	private ListableDto status;
	private ListableDto oic;
	private LocalDateTime updatedDate;
	private WorkflowDto workflow;
	private WorkflowActionDto lastAction;
	private WorkflowActionDto lastApprovedAction;
	private WorkflowActionDto lastEditAction;
	private Boolean hasEditedAfterApproved = false;

	public CeCheckScheduleDto() {
		// initialize all objects, prevent undefined object at front-end
		this.status = new ListableDto();
		this.oic = new ListableDto();
		this.workflow = new WorkflowDto();
		this.lastAction = new WorkflowActionDto();
		this.lastApprovedAction = new WorkflowActionDto();
		this.lastEditAction = new WorkflowActionDto();
	}

	public static void buildWorkflowAction(Cache cache, WorkflowHelper workflowHelper, CeCheckScheduleDto dto, Workflow workflow) {
		dto.getWorkflow().buildFromWorkflow(cache, workflow, dto.getWorkflow(), workflowHelper);
		dto.setStatus(new ListableDto(workflow.getLastAction().getStatus()));
		dto.setLastAction(new WorkflowActionDto(cache, workflow.getLastAction()));

		Optional<WorkflowAction> lastApprovedAction = workflow.getWorkflowActions().stream().filter(action -> Entities.equals(action.getType(), Codes.WorkflowActionTypes.APPROVE))
				.sorted(Comparator.comparing(WorkflowAction::getCreatedDate).reversed()).findFirst();
		if (lastApprovedAction.isPresent()) {
			dto.setLastApprovedAction(new WorkflowActionDto(cache, lastApprovedAction.get()));
		}

		Optional<WorkflowAction> lastEditAction = workflow.getWorkflowActions().stream().filter(action -> Entities.equals(action.getType(), Codes.WorkflowActionTypes.EDIT))
				.sorted(Comparator.comparing(WorkflowAction::getCreatedDate).reversed()).findFirst();
		if (lastEditAction.isPresent()) {
			dto.setLastEditAction(new WorkflowActionDto(cache, lastEditAction.get()));
			dto.setHasEditedAfterApproved(lastApprovedAction.isPresent() && lastEditAction.get().getCreatedDate().isAfter(lastApprovedAction.get().getCreatedDate()));
		}
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public ListableDto getOic() {
		return oic;
	}

	public void setOic(ListableDto oic) {
		this.oic = oic;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public WorkflowDto getWorkflow() {
		return workflow;
	}

	public void setWorkflow(WorkflowDto workflow) {
		this.workflow = workflow;
	}

	public WorkflowActionDto getLastAction() {
		return lastAction;
	}

	public void setLastAction(WorkflowActionDto lastAction) {
		this.lastAction = lastAction;
	}

	public WorkflowActionDto getLastApprovedAction() {
		return lastApprovedAction;
	}

	public void setLastApprovedAction(WorkflowActionDto lastApprovedAction) {
		this.lastApprovedAction = lastApprovedAction;
	}

	public WorkflowActionDto getLastEditAction() {
		return lastEditAction;
	}

	public void setLastEditAction(WorkflowActionDto lastEditAction) {
		this.lastEditAction = lastEditAction;
	}

	public Boolean getHasEditedAfterApproved() {
		return hasEditedAfterApproved;
	}

	public void setHasEditedAfterApproved(Boolean hasEditedAfterApproved) {
		this.hasEditedAfterApproved = hasEditedAfterApproved;
	}

}
