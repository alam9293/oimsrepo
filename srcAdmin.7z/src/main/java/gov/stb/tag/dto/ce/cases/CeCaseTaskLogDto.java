package gov.stb.tag.dto.ce.cases;

import java.util.List;

public class CeCaseTaskLogDto {

	private String offenderName;
	private String offenderUenUin;

	private List<CeCaseTaskSummaryDto> caseTaskSummary;

	public CeCaseTaskLogDto() {

	}

	public String getOffenderName() {
		return offenderName;
	}

	public void setOffenderName(String offenderName) {
		this.offenderName = offenderName;
	}

	public String getOffenderUenUin() {
		return offenderUenUin;
	}

	public void setOffenderUenUin(String offenderUenUin) {
		this.offenderUenUin = offenderUenUin;
	}

	public List<CeCaseTaskSummaryDto> getCaseTaskSummary() {
		return caseTaskSummary;
	}

	public void setCaseTaskSummary(List<CeCaseTaskSummaryDto> caseTaskSummary) {
		this.caseTaskSummary = caseTaskSummary;
	}

}
