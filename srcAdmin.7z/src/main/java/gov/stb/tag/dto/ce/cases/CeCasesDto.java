package gov.stb.tag.dto.ce.cases;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.Transient;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.CeCase;

public class CeCasesDto {

	// ce case info
	private Integer id;
	private String caseNo;
	private LocalDateTime createdDate;
	private String crmNo;
	private String oic;
	private ListableDto status;
	private String taTgType;

	// case overview
	private String assessment;
	private String aggravatingFactors;
	private String mitigatingFactors;

	// complainants
	private List<CeComplainantDto> complainants;
	private List<CeComplainantDto> deletedComplainants;

	// compliance checks and field reports
	private List<CeComplianceCheckDto> complianceChecks;
	private List<CeComplianceCheckDto> deletedComplianceChecks;

	// offences and infringements
	private List<CeInfringementDto> infringements;
	private List<CeInfringementDto> deletedInfringements;

	// other attachments
	private List<FileDto> othAttachments;
	private List<FileDto> othDeletedAttachments;

	// other offences and infringements
	private List<CeInfringementDto> othInfringements;

	private List<CeCaseTaskWorkflowDto> workflows;
	private CeCaseTaskWorkflowDto currentWorkflow;

	private Boolean isNew = false; // to indicate whether this case is totally new (no any approved recommendation)
	private Boolean isOic = false; // to indicate whether current user is OIC
	private Boolean isPendingApproval = false; // to show the case task details
	private Boolean hasChildCase = false;
	private Boolean isRoutedBack = false;
	private Boolean isTaskCreated = false;

	private String taggedCaseNo;
	private Integer taggedCaseId;

	@Transient
	private Boolean workflowRequired = false;

	public CeCasesDto() {

	}

	public CeCasesDto(CeCase ceCase, CacheHelper cache) {
		this.id = ceCase.getId();
		this.caseNo = ceCase.getCaseNo();
		this.createdDate = ceCase.getCreatedDate();
		this.crmNo = ceCase.getCrmRefNo();
		this.oic = ceCase.getOic().getName();
		this.status = new ListableDto(ceCase.getStatus().getCode(), cache.getLabel(ceCase.getStatus(), false));
		this.taTgType = ceCase.getTaTgType();

		this.assessment = ceCase.getAssessment();
		this.aggravatingFactors = ceCase.getAggravatingFactors();
		this.mitigatingFactors = ceCase.getMitigatingFactors();

		if (ceCase.getTaggedCase() != null) {
			CeCase taggedCase = ceCase.getTaggedCase();
			this.taggedCaseNo = taggedCase.getCaseNo();
			this.taggedCaseId = taggedCase.getId();
		}
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCrmNo() {
		return crmNo;
	}

	public void setCrmNo(String crmNo) {
		this.crmNo = crmNo;
	}

	public String getOic() {
		return oic;
	}

	public void setOic(String oic) {
		this.oic = oic;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getAssessment() {
		return assessment;
	}

	public void setAssessment(String assessment) {
		this.assessment = assessment;
	}

	public String getAggravatingFactors() {
		return aggravatingFactors;
	}

	public void setAggravatingFactors(String aggravatingFactors) {
		this.aggravatingFactors = aggravatingFactors;
	}

	public String getMitigatingFactors() {
		return mitigatingFactors;
	}

	public void setMitigatingFactors(String mitigatingFactors) {
		this.mitigatingFactors = mitigatingFactors;
	}

	public List<CeComplainantDto> getComplainants() {
		return complainants;
	}

	public void setComplainants(List<CeComplainantDto> complainants) {
		this.complainants = complainants;
	}

	public List<CeComplainantDto> getDeletedComplainants() {
		return deletedComplainants;
	}

	public void setDeletedComplainants(List<CeComplainantDto> deletedComplainants) {
		this.deletedComplainants = deletedComplainants;
	}

	public List<CeInfringementDto> getInfringements() {
		return infringements;
	}

	public void setInfringements(List<CeInfringementDto> infringements) {
		this.infringements = infringements;
	}

	public List<CeInfringementDto> getDeletedInfringements() {
		return deletedInfringements;
	}

	public void setDeletedInfringements(List<CeInfringementDto> deletedInfringements) {
		this.deletedInfringements = deletedInfringements;
	}

	public List<FileDto> getOthAttachments() {
		return othAttachments;
	}

	public void setOthAttachments(List<FileDto> othAttachments) {
		this.othAttachments = othAttachments;
	}

	public List<FileDto> getOthDeletedAttachments() {
		return othDeletedAttachments;
	}

	public void setOthDeletedAttachments(List<FileDto> othDeletedAttachments) {
		this.othDeletedAttachments = othDeletedAttachments;
	}

	public List<CeInfringementDto> getOthInfringements() {
		return othInfringements;
	}

	public void setOthInfringements(List<CeInfringementDto> othInfringements) {
		this.othInfringements = othInfringements;
	}

	public List<CeComplianceCheckDto> getComplianceChecks() {
		return complianceChecks;
	}

	public void setComplianceChecks(List<CeComplianceCheckDto> complianceChecks) {
		this.complianceChecks = complianceChecks;
	}

	public List<CeComplianceCheckDto> getDeletedComplianceChecks() {
		return deletedComplianceChecks;
	}

	public void setDeletedComplianceChecks(List<CeComplianceCheckDto> deletedComplianceChecks) {
		this.deletedComplianceChecks = deletedComplianceChecks;
	}

	public Boolean getIsNew() {
		return isNew;
	}

	public void setIsNew(Boolean isNew) {
		this.isNew = isNew;
	}

	public Boolean getIsPendingApproval() {
		return isPendingApproval;
	}

	public void setIsPendingApproval(Boolean isPendingApproval) {
		this.isPendingApproval = isPendingApproval;
	}

	public Boolean getIsOic() {
		return isOic;
	}

	public void setIsOic(Boolean isOic) {
		this.isOic = isOic;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public List<CeCaseTaskWorkflowDto> getWorkflows() {
		return workflows;
	}

	public void setWorkflows(List<CeCaseTaskWorkflowDto> workflows) {
		this.workflows = workflows;
	}

	public CeCaseTaskWorkflowDto getCurrentWorkflow() {
		return currentWorkflow;
	}

	public void setCurrentWorkflow(CeCaseTaskWorkflowDto currentWorkflow) {
		this.currentWorkflow = currentWorkflow;
	}

	public String getTaggedCaseNo() {
		return taggedCaseNo;
	}

	public void setTaggedCaseNo(String taggedCaseNo) {
		this.taggedCaseNo = taggedCaseNo;
	}

	public Integer getTaggedCaseId() {
		return taggedCaseId;
	}

	public void setTaggedCaseId(Integer taggedCaseId) {
		this.taggedCaseId = taggedCaseId;
	}

	public Boolean getHasChildCase() {
		return hasChildCase;
	}

	public void setHasChildCase(Boolean hasChildCase) {
		this.hasChildCase = hasChildCase;
	}

	public Boolean getIsRoutedBack() {
		return isRoutedBack;
	}

	public void setIsRoutedBack(Boolean isRoutedBack) {
		this.isRoutedBack = isRoutedBack;
	}

	public Boolean getWorkflowRequired() {
		return workflowRequired;
	}

	public void setWorkflowRequired(Boolean workflowRequired) {
		this.workflowRequired = workflowRequired;
	}

	public Boolean getIsTaskCreated() {
		return isTaskCreated;
	}

	public void setIsTaskCreated(Boolean isTaskCreated) {
		this.isTaskCreated = isTaskCreated;
	}

}
