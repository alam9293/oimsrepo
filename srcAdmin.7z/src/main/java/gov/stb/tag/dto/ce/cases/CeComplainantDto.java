package gov.stb.tag.dto.ce.cases;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.CeCaseComplainant;

public class CeComplainantDto {

	private Integer id;
	private String name;
	private String contactNo;
	private String emailAddress;
	private String residentialType;
	private String postalCode;
	private String block;
	private String street;
	private String building;
	private String level;
	private String unit;
	private String foreignLine1;
	private String foreignLine2;
	private String foreignLine3;
	private String address;
	private List<FileDto> attachment;
	private List<FileDto> deletedAttachment;

	public CeComplainantDto() {

	}

	public CeComplainantDto(CeCaseComplainant ceCaseComplainant, FileHelper fileHelper, Cache cache) {
		this.id = ceCaseComplainant.getId();
		this.name = ceCaseComplainant.getName();
		this.contactNo = ceCaseComplainant.getContactNo();
		this.emailAddress = ceCaseComplainant.getEmailAddress();
		Address address = ceCaseComplainant.getAddress();
		if (address != null) {
			if (address.getAddressType() != null) {
				this.residentialType = address.getAddressType().getCode();
			}
			this.postalCode = address.getPostal();
			this.block = address.getBlock();
			this.street = address.getStreet();
			this.building = address.getBuilding();
			this.level = address.getFloor();
			this.unit = address.getUnit();
			this.foreignLine1 = address.getForeignLine1();
			this.foreignLine2 = address.getForeignLine2();
			this.foreignLine3 = address.getForeignLine3();
		}

		if (CollectionUtils.isNotEmpty(ceCaseComplainant.getFiles())) {
			this.attachment = new ArrayList<>();
			ceCaseComplainant.getFiles().forEach(u -> {
				if (!u.getIsDeleted()) {
					this.attachment.add(FileDto.buildFromFile(u, null, fileHelper));
				}
			});
		}
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<FileDto> getAttachment() {
		return attachment;
	}

	public void setAttachment(List<FileDto> attachment) {
		this.attachment = attachment;
	}

	public List<FileDto> getDeletedAttachment() {
		return deletedAttachment;
	}

	public void setDeletedAttachment(List<FileDto> deletedAttachment) {
		this.deletedAttachment = deletedAttachment;
	}

	public String getResidentialType() {
		return residentialType;
	}

	public void setResidentialType(String residentialType) {
		this.residentialType = residentialType;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getForeignLine1() {
		return foreignLine1;
	}

	public void setForeignLine1(String foreignLine1) {
		this.foreignLine1 = foreignLine1;
	}

	public String getForeignLine2() {
		return foreignLine2;
	}

	public void setForeignLine2(String foreignLine2) {
		this.foreignLine2 = foreignLine2;
	}

	public String getForeignLine3() {
		return foreignLine3;
	}

	public void setForeignLine3(String foreignLine3) {
		this.foreignLine3 = foreignLine3;
	}

}
