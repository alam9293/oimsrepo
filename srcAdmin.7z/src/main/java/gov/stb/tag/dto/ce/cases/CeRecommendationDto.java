package gov.stb.tag.dto.ce.cases;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;

public class CeRecommendationDto {

	private Integer recommendationId;
	private String taggedIpCaseNo;
	private ListableDto recommendation;
	private BigDecimal penaltyAmount;
	private LocalDate penaltyStartDate;
	private LocalDate penaltyEndDate;

	private Boolean toEmailLetter;
	private LocalDate letterIssuanceDate;
	private FileDto letterIssuance;
	private List<FileDto> deletedLetterIssuance;

	private Integer workflowId;
	private ListableDto workflowStatus;
	private LocalDateTime approvedDate;

	@JsonIgnore
	private CeCaseRecommendation ceCaseRecommendation;

	public CeRecommendationDto() {

	}

	public CeRecommendationDto(CeCaseRecommendation ceCaseRecommendation, CacheHelper cache, FileHelper fileHelper, WorkflowHelper workflowHelper, User oic, boolean isForCaseTaskLogDetails) {
		if (ceCaseRecommendation != null) {
			this.recommendationId = ceCaseRecommendation.getId();
			if (ceCaseRecommendation.getOutcome() != null) {
				this.recommendation = new ListableDto(ceCaseRecommendation.getOutcome().getCode(), cache.getLabel(ceCaseRecommendation.getOutcome(), false));
			}

			this.toEmailLetter = ceCaseRecommendation.getToEmailLetter();
			this.taggedIpCaseNo = ceCaseRecommendation.getTaggedIpCaseNo();
			this.penaltyAmount = ceCaseRecommendation.getPenaltyAmount();
			this.penaltyStartDate = ceCaseRecommendation.getPenaltyStatusStartDate();
			this.penaltyEndDate = ceCaseRecommendation.getPenaltyStatusEndDate();
			this.letterIssuanceDate = ceCaseRecommendation.getLetterIssuanceDate();

			Workflow workflow = ceCaseRecommendation.getWorkflow();
			if (workflow != null) {
				WorkflowAction lastAction = workflow.getLastAction();

				if (lastAction != null) {
					boolean isPendingApproval = workflowHelper.isPendingApproval(lastAction.getStatus());
					if (isPendingApproval) {
						this.workflowId = workflow.getId();
						this.workflowStatus = new ListableDto(lastAction.getStatus().getCode(), cache.getLabel(lastAction.getStatus(), false));
					}

					if (Entities.equals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_APPR)) {
						this.approvedDate = lastAction.getCreatedDate();
					}
				}
			}

			if (ceCaseRecommendation.getLetter() != null) {
				this.letterIssuance = FileDto.buildFromFile(ceCaseRecommendation.getLetter(), null, fileHelper);
			}

		}
	}

	public Integer getRecommendationId() {
		return recommendationId;
	}

	public void setRecommendationId(Integer recommendationId) {
		this.recommendationId = recommendationId;
	}

	public ListableDto getRecommendation() {
		return recommendation;
	}

	public void setRecommendation(ListableDto recommendation) {
		this.recommendation = recommendation;
	}

	public BigDecimal getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(BigDecimal penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public LocalDate getPenaltyStartDate() {
		return penaltyStartDate;
	}

	public void setPenaltyStartDate(LocalDate penaltyStartDate) {
		this.penaltyStartDate = penaltyStartDate;
	}

	public LocalDate getPenaltyEndDate() {
		return penaltyEndDate;
	}

	public void setPenaltyEndDate(LocalDate penaltyEndDate) {
		this.penaltyEndDate = penaltyEndDate;
	}

	public Boolean getToEmailLetter() {
		return toEmailLetter;
	}

	public void setToEmailLetter(Boolean toEmailLetter) {
		this.toEmailLetter = toEmailLetter;
	}

	public FileDto getLetterIssuance() {
		return letterIssuance;
	}

	public void setLetterIssuance(FileDto letterIssuance) {
		this.letterIssuance = letterIssuance;
	}

	public List<FileDto> getDeletedLetterIssuance() {
		return deletedLetterIssuance;
	}

	public void setDeletedLetterIssuance(List<FileDto> deletedLetterIssuance) {
		this.deletedLetterIssuance = deletedLetterIssuance;
	}

	public ListableDto getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(ListableDto workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public String getTaggedIpCaseNo() {
		return taggedIpCaseNo;
	}

	public void setTaggedIpCaseNo(String taggedIpCaseNo) {
		this.taggedIpCaseNo = taggedIpCaseNo;
	}

	public CeCaseRecommendation getCeCaseRecommendation() {
		return ceCaseRecommendation;
	}

	public void setCeCaseRecommendation(CeCaseRecommendation ceCaseRecommendation) {
		this.ceCaseRecommendation = ceCaseRecommendation;
	}

	public LocalDate getLetterIssuanceDate() {
		return letterIssuanceDate;
	}

	public void setLetterIssuanceDate(LocalDate letterIssuanceDate) {
		this.letterIssuanceDate = letterIssuanceDate;
	}

	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

}
