package gov.stb.tag.dto.ce.cases;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeCaseRescind;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;

public class CeRescindDto {

	private Integer rescindId;

	private Boolean toEmailLetter;
	private LocalDate letterIssuanceDate;
	private FileDto letterIssuance;
	private List<FileDto> deletedLetterIssuance;

	private Integer workflowId;
	private ListableDto workflowStatus;

	@JsonIgnore
	private CeCaseRescind ceCaseRescind;

	public CeRescindDto() {

	}

	public CeRescindDto(CeCaseRescind ceCaseRescind, CacheHelper cache, FileHelper fileHelper, WorkflowHelper workflowHelper, User oic, boolean isForCaseTaskLogDetails) {
		if (ceCaseRescind != null) {
			this.rescindId = ceCaseRescind.getId();
			this.toEmailLetter = ceCaseRescind.getToEmailLetter();
			this.letterIssuanceDate = ceCaseRescind.getLetterIssuanceDate();

			Workflow workflow = ceCaseRescind.getWorkflow();
			if (workflow != null) {
				WorkflowAction lastAction = workflow.getLastAction();

				if (lastAction != null) {
					if (workflowHelper.isPendingApproval(lastAction.getStatus())) {
						this.workflowId = workflow.getId();
						this.workflowStatus = new ListableDto(lastAction.getStatus().getCode(), cache.getLabel(lastAction.getStatus(), false));
					}
				}
			}

			if (ceCaseRescind.getLetter() != null) {
				this.letterIssuance = FileDto.buildFromFile(ceCaseRescind.getLetter(), null, fileHelper);
			}

		}
	}

	public Integer getRescindId() {
		return rescindId;
	}

	public void setRescindId(Integer rescindId) {
		this.rescindId = rescindId;
	}

	public Boolean getToEmailLetter() {
		return toEmailLetter;
	}

	public void setToEmailLetter(Boolean toEmailLetter) {
		this.toEmailLetter = toEmailLetter;
	}

	public FileDto getLetterIssuance() {
		return letterIssuance;
	}

	public void setLetterIssuance(FileDto letterIssuance) {
		this.letterIssuance = letterIssuance;
	}

	public List<FileDto> getDeletedLetterIssuance() {
		return deletedLetterIssuance;
	}

	public void setDeletedLetterIssuance(List<FileDto> deletedLetterIssuance) {
		this.deletedLetterIssuance = deletedLetterIssuance;
	}

	public ListableDto getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(ListableDto workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public CeCaseRescind getCeCaseRescind() {
		return ceCaseRescind;
	}

	public void setCeCaseRescind(CeCaseRescind ceCaseRescind) {
		this.ceCaseRescind = ceCaseRescind;
	}

	public LocalDate getLetterIssuanceDate() {
		return letterIssuanceDate;
	}

	public void setLetterIssuanceDate(LocalDate letterIssuanceDate) {
		this.letterIssuanceDate = letterIssuanceDate;
	}

}
