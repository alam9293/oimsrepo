package gov.stb.tag.dto.ce.directory;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeDirectoryItemDto {

	@MapProjection(path = "ceCaseInfringer.licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "ceCaseInfringer.name")
	private String name;

	@MapProjection(path = "ceCaseInfringer.idType.label")
	private String idTypeLabel;

	@MapProjection(path = "ceProvision.chapter.code")
	private String provisionChapterCode;

	@MapProjection(path = "ceProvision.section")
	private String provisionSection;

	@MapProjection(path = "ceProvision.description")
	private String provisionDescription;

	@MapProjection(path = "infringedDate")
	private LocalDateTime infringedDate;

	@MapProjection(path = "outcome.label")
	private String outcomeLabel;

	@MapProjection(path = "outcomeDate")
	private LocalDateTime outcomeDate;

	@MapProjection(path = "ceCase.oic.name")
	private String oicName;

	@MapProjection(path = "ceCase.status.label")
	private String caseStatusLabel;

	@MapProjection(path = "ceCase.caseNo")
	private String caseNo;

	@MapProjection(path = "ceCase.id")
	private Integer caseId;

	@MapProjection(path = "ceCase.isIp")
	private Boolean caseIsIp;

	@MapProjection(path = "ceCase.taTgType")
	private String taTgType;

	@MapProjection(path = "ceOriginatingCase.caseNo")
	private String ceOriginatingCaseNo;

	@MapProjection(path = "ceOriginatingCase.id")
	private Integer ceOriginatingCaseId;

	public CeDirectoryItemDto() {

	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdTypeLabel() {
		return idTypeLabel;
	}

	public void setIdTypeLabel(String idTypeLabel) {
		this.idTypeLabel = idTypeLabel;
	}

	public String getProvisionSection() {
		return provisionSection;
	}

	public void setProvisionSection(String provisionSection) {
		this.provisionSection = provisionSection;
	}

	public String getProvisionChapterCode() {
		return provisionChapterCode;
	}

	public void setProvisionChapterCode(String provisionChapterCode) {
		this.provisionChapterCode = provisionChapterCode;
	}

	public String getProvisionDescription() {
		return provisionDescription;
	}

	public void setProvisionDescription(String provisionDescription) {
		this.provisionDescription = provisionDescription;
	}

	public LocalDateTime getInfringedDate() {
		return infringedDate;
	}

	public void setInfringedDate(LocalDateTime infringedDate) {
		this.infringedDate = infringedDate;
	}

	public String getOutcomeLabel() {
		return outcomeLabel;
	}

	public void setOutcomeLabel(String outcomeLabel) {
		this.outcomeLabel = outcomeLabel;
	}

	public LocalDateTime getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(LocalDateTime outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getOicName() {
		return oicName;
	}

	public void setOicName(String oicName) {
		this.oicName = oicName;
	}

	public String getCaseStatusLabel() {
		return caseStatusLabel;
	}

	public void setCaseStatusLabel(String caseStatusLabel) {
		this.caseStatusLabel = caseStatusLabel;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public Integer getCaseId() {
		return caseId;
	}

	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}

	public Boolean getCaseIsIp() {
		return caseIsIp;
	}

	public void setCaseIsIp(Boolean caseIsIp) {
		this.caseIsIp = caseIsIp;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public String getCeOriginatingCaseNo() {
		return ceOriginatingCaseNo;
	}

	public void setCeOriginatingCaseNo(String ceOriginatingCaseNo) {
		this.ceOriginatingCaseNo = ceOriginatingCaseNo;
	}

	public Integer getCeOriginatingCaseId() {
		return ceOriginatingCaseId;
	}

	public void setCeOriginatingCaseId(Integer ceOriginatingCaseId) {
		this.ceOriginatingCaseId = ceOriginatingCaseId;
	}

}
