package gov.stb.tag.dto.ce.directory;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeDirectorySearchDto extends SearchDto {

	private String idTypeCode;

	private String name;

	private String uenUin;

	private String licenceNo;

	private String section;

	private String caseNo;

	private String caseStatusCode;

	private String oicName;

	private String[] outcomeCodes;

	private LocalDate outcomeDateFrom;

	private LocalDate outcomeDateTo;

	private LocalDate infringedDateFrom;

	private LocalDate infringedDateTo;

	private Boolean isIp;

	private Boolean myTask;

	public String getIdTypeCode() {
		return idTypeCode;
	}

	public void setIdTypeCode(String idTypeCode) {
		this.idTypeCode = idTypeCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getCaseStatusCode() {
		return caseStatusCode;
	}

	public void setCaseStatusCode(String caseStatusCode) {
		this.caseStatusCode = caseStatusCode;
	}

	public String getOicName() {
		return oicName;
	}

	public void setOicName(String oicName) {
		this.oicName = oicName;
	}

	public String[] getOutcomeCodes() {
		return outcomeCodes;
	}

	public void setOutcomeCodes(String[] outcomeCodes) {
		this.outcomeCodes = outcomeCodes;
	}

	public LocalDate getOutcomeDateFrom() {
		return outcomeDateFrom;
	}

	public void setOutcomeDateFrom(LocalDate outcomeDateFrom) {
		this.outcomeDateFrom = outcomeDateFrom;
	}

	public LocalDate getOutcomeDateTo() {
		return outcomeDateTo;
	}

	public void setOutcomeDateTo(LocalDate outcomeDateTo) {
		this.outcomeDateTo = outcomeDateTo;
	}

	public LocalDate getInfringedDateFrom() {
		return infringedDateFrom;
	}

	public void setInfringedDateFrom(LocalDate infringedDateFrom) {
		this.infringedDateFrom = infringedDateFrom;
	}

	public LocalDate getInfringedDateTo() {
		return infringedDateTo;
	}

	public void setInfringedDateTo(LocalDate infringedDateTo) {
		this.infringedDateTo = infringedDateTo;
	}

	public Boolean getIsIp() {
		return isIp;
	}

	public void setIsIp(Boolean isIp) {
		this.isIp = isIp;
	}

	public Boolean getMyTask() {
		return myTask;
	}

	public void setMyTask(Boolean myTask) {
		this.myTask = myTask;
	}

}
