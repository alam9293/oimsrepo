package gov.stb.tag.dto.ce.directory;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.ListableDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeInfringementForPublicDto {

	@MapProjection(path = "ceCaseInfringer.licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "ceCaseInfringer.name")
	private String name;

	@MapProjection(path = "ceCaseInfringer.uenUin")
	private String uenUin;

	@MapProjection(path = "ceCaseInfringer.idType.label")
	private String idTypeLabel;

	@MapProjection(path = "ceProvision.chapter.code")
	private String provisionChapterCode;

	@MapProjection(path = "ceProvision.section")
	private String provisionSection;

	@MapProjection(path = "ceProvision.description")
	private String provisionDescription;

	@MapProjection(path = "infringedDate")
	private LocalDateTime infringedDate;

	@MapProjection(path = "outcome.otherLabel")
	private String outcomeLabel;

	@MapProjection(path = "outcomeDate")
	private LocalDateTime outcomeDate;

	@MapProjection(path = "ceCase.isIp")
	private Boolean caseIsIp;

	@MapProjection(path = "lastDecision.billRefNo")
	private String billRefNo;

	@MapProjection(path = "lastDecision.billExpiryDate")
	private LocalDateTime billExpiryDate;

	@MapProjection(path = "lastDecision.penaltyAmount")
	private BigDecimal penaltyAmount;

	@MapProjection(path = "lastDecision.paymentStatus.code")
	private String paymentStatusCode;

	@MapProjection(path = "lastDecision.paymentStatus.label")
	private String paymentStatusLabel;

	@MapProjection(path = "lastDecision.penaltyStatusEndDate")
	private LocalDate penaltyStatusEndDate;

	private ListableDto paymentRequestStatus = new ListableDto(); // to manual derive from payment request

	public CeInfringementForPublicDto() {

	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public String getIdTypeLabel() {
		return idTypeLabel;
	}

	public void setIdTypeLabel(String idTypeLabel) {
		this.idTypeLabel = idTypeLabel;
	}

	public String getProvisionSection() {
		return provisionSection;
	}

	public void setProvisionSection(String provisionSection) {
		this.provisionSection = provisionSection;
	}

	public String getProvisionChapterCode() {
		return provisionChapterCode;
	}

	public void setProvisionChapterCode(String provisionChapterCode) {
		this.provisionChapterCode = provisionChapterCode;
	}

	public String getProvisionDescription() {
		return provisionDescription;
	}

	public void setProvisionDescription(String provisionDescription) {
		this.provisionDescription = provisionDescription;
	}

	public LocalDateTime getInfringedDate() {
		return infringedDate;
	}

	public void setInfringedDate(LocalDateTime infringedDate) {
		this.infringedDate = infringedDate;
	}

	public String getOutcomeLabel() {
		return outcomeLabel;
	}

	public void setOutcomeLabel(String outcomeLabel) {
		this.outcomeLabel = outcomeLabel;
	}

	public LocalDateTime getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(LocalDateTime outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public Boolean getCaseIsIp() {
		return caseIsIp;
	}

	public void setCaseIsIp(Boolean caseIsIp) {
		this.caseIsIp = caseIsIp;
	}

	public BigDecimal getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(BigDecimal penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public String getPaymentStatusCode() {
		return paymentStatusCode;
	}

	public void setPaymentStatusCode(String paymentStatusCode) {
		this.paymentStatusCode = paymentStatusCode;
	}

	public String getPaymentStatusLabel() {
		return paymentStatusLabel;
	}

	public void setPaymentStatusLabel(String paymentStatusLabel) {
		this.paymentStatusLabel = paymentStatusLabel;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public LocalDateTime getBillExpiryDate() {
		return billExpiryDate;
	}

	public void setBillExpiryDate(LocalDateTime billExpiryDate) {
		this.billExpiryDate = billExpiryDate;
	}

	public ListableDto getPaymentRequestStatus() {
		return paymentRequestStatus;
	}

	public void setPaymentRequestStatus(ListableDto paymentRequestStatus) {
		this.paymentRequestStatus = paymentRequestStatus;
	}

	public LocalDate getPenaltyStatusEndDate() {
		return penaltyStatusEndDate;
	}

	public void setPenaltyStatusEndDate(LocalDate penaltyStatusEndDate) {
		this.penaltyStatusEndDate = penaltyStatusEndDate;
	}

}
