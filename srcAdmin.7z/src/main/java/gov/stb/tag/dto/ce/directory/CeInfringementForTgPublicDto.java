package gov.stb.tag.dto.ce.directory;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.util.DateUtil;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeInfringementForTgPublicDto {

	@MapProjection(path = "infringedDate")
	private LocalDateTime infringedDate;

	@MapProjection(path = "ceProvision.description")
	private String provisionDescription;

	@MapProjection(path = "readWiths.description")
	private String readWithDescription;

	@MapProjection(path = "outcome.otherLabel")
	private String outcomeLabel;

	@MapProjection(path = "lastDecision.ceCaseAppeal.penaltyStatusStartDate")
	private LocalDate penaltyStatusStartDate;

	@MapProjection(path = "lastDecision.ceCaseAppeal.penaltyStatusEndDate")
	private LocalDate penaltyStatusEndDate;

	public CeInfringementForTgPublicDto() {
	}

	public LocalDateTime getInfringedDate() {
		return infringedDate;
	}

	public void setInfringedDate(LocalDateTime infringedDate) {
		this.infringedDate = infringedDate;
	}

	public String getProvisionDescription() {
		return readWithDescription != null ? readWithDescription : provisionDescription;
	}

	public void setProvisionDescription(String provisionDescription) {
		this.provisionDescription = provisionDescription;
	}

	public void setReadWithDescription(String readWithDescription) {
		this.readWithDescription = readWithDescription;
	}

	public String getOutcome() {
		String outcome = outcomeLabel;

		if (this.penaltyStatusEndDate != null) {
			if (this.penaltyStatusStartDate != null) {
				outcome += " (" + DateUtil.format(penaltyStatusStartDate) + " to " + DateUtil.format(penaltyStatusEndDate) + ")";
			} else {
				outcome += " (with effect from " + DateUtil.format(penaltyStatusEndDate) + ")";
			}
		}

		return outcome;
	}

	public void setOutcomeLabel(String outcomeLabel) {
		this.outcomeLabel = outcomeLabel;
	}

	public void setPenaltyStatusStartDate(LocalDate penaltyStatusStartDate) {
		this.penaltyStatusStartDate = penaltyStatusStartDate;
	}

	public void setPenaltyStatusEndDate(LocalDate penaltyStatusEndDate) {
		this.penaltyStatusEndDate = penaltyStatusEndDate;
	}

}
