package gov.stb.tag.dto.ce.ip;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.CeCaseComplainant;

public class CeIpComplainantDto {

	private Integer id;

	private String name;

	private ListableDto idType;

	private String uenUin;

	private ListableDto type;

	public CeIpComplainantDto() {
	}

	public CeIpComplainantDto(CeCaseComplainant ceCaseComplainant) {
		this.id = ceCaseComplainant.getId();
		this.name = ceCaseComplainant.getName();
		this.idType = new ListableDto(ceCaseComplainant.getIdType());
		this.uenUin = ceCaseComplainant.getUenUin();
		this.type = new ListableDto(ceCaseComplainant.getType());
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ListableDto getIdType() {
		return idType;
	}

	public void setIdType(ListableDto idType) {
		this.idType = idType;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public ListableDto getType() {
		return type;
	}

	public void setType(ListableDto type) {
		this.type = type;
	}

}
