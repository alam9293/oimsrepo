package gov.stb.tag.dto.ce.ip;

import java.math.BigDecimal;
import java.time.LocalDate;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.cases.CeCaseTaskWorkflowDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.CeCaseComposition;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.Workflow;

public class CeIpCompositionDto {

	private Integer id;

	private Integer infringerId;

	private String name;

	private String uenUin;

	private String email;

	private String description;

	private BigDecimal amount;

	private LocalDate dueDate;

	private String billRefNo;

	private ListableDto status;

	private String remarks;

	private FileDto letter;

	private Boolean isEditable;

	private Boolean isApproved = false;

	private Boolean checked = false;

	public CeIpCompositionDto() {
	}

	private CeIpCompositionDto(CeCaseInfringer infringer) {
		this.infringerId = infringer.getId();
		this.name = infringer.getName();
		this.uenUin = infringer.getUenUin();
	}

	public CeIpCompositionDto(CeCaseInfringer infringer, CeCaseTaskWorkflowDto overallWorkflow) {
		this(infringer);
		this.isEditable = isEditable(overallWorkflow, null, null);
	}

	public CeIpCompositionDto(CeCaseComposition compo, PaymentHelper paymentHelper, CeCaseTaskWorkflowDto overallWorkflow, FileHelper fileHelper) {
		this(compo.getCeCaseInfringer());
		this.id = compo.getId();
		this.email = compo.getEmail();
		this.description = compo.getDescription();
		this.amount = compo.getAmount();
		this.dueDate = compo.getDueDate();
		this.billRefNo = compo.getBillRefNo();
		PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(compo.getBillRefNo());
		if (compo.getPayReqStatus() != null) {
			this.status = new ListableDto(compo.getPayReqStatus());
		} else {
			this.status = paymentRequest != null ? new ListableDto(paymentRequest.getStatus()) : null;
		}
		this.remarks = compo.getRemarks();
		this.isEditable = isEditable(overallWorkflow, compo.getWorkflow(), paymentRequest != null ? paymentRequest.getStatus() : null);
		this.isApproved = isWorkflowStatus(compo, Codes.Statuses.CE_WKFLW_APPR);
		this.checked = isWorkflowStatus(compo, Codes.Statuses.CE_WKFLW_ROUTED);
		this.letter = FileDto.buildFromFile(compo.getLetter(), null, fileHelper);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getInfringerId() {
		return infringerId;
	}

	public void setInfringerId(Integer infringerId) {
		this.infringerId = infringerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public FileDto getLetter() {
		return letter;
	}

	public void setLetter(FileDto letter) {
		this.letter = letter;
	}

	public Boolean getIsEditable() {
		return isEditable;
	}

	public void setIsEditable(Boolean isEditable) {
		this.isEditable = isEditable;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public Boolean getChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}

	private Boolean isEditable(CeCaseTaskWorkflowDto overallWorkflow, Workflow itemWorkflow, Status payReqStatus) {
		Boolean isAssignee = overallWorkflow.getIsAssignee();

		String overallWorkflowStatus = overallWorkflow.getCaseTaskStatus() != null ? overallWorkflow.getCaseTaskStatus().getKeyString() : "";
		String itemWorkflowStatus = itemWorkflow != null ? itemWorkflow.getLastAction().getStatus().getCode() : "";

		if (Codes.Statuses.CE_WKFLW_PEND_APPR.equals(overallWorkflowStatus)) {
			return false;
		} else if (Codes.Statuses.CE_WKFLW_ROUTED.equals(overallWorkflowStatus)) {
			if (isAssignee && Codes.Statuses.CE_WKFLW_ROUTED.equals(itemWorkflowStatus)) {
				return isEditablePayment(payReqStatus);
			} else {
				return false;
			}
		} else {
			return isEditablePayment(payReqStatus);
		}
	}

	private Boolean isEditablePayment(Status payReqStatus) {
		return payReqStatus == null || Codes.Statuses.PAYREQ_NOT_PAID.equals(payReqStatus.getCode());
	}

	private Boolean isWorkflowStatus(CeCaseComposition compo, String status) {
		return compo.getWorkflow() != null ? status.equals(compo.getWorkflow().getLastAction().getStatus().getCode()) : false;
	}

}
