package gov.stb.tag.dto.ce.ip;

import java.time.LocalDateTime;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseExternalIp;

public class CeIpRevIpDto {

	private Integer id;

	private LocalDateTime createdOn;

	private String typeCode;

	private String caseNo;

	private ListableDto status;

	private String oic;

	private String oicContactNumber;

	public CeIpRevIpDto() {
	}

	public CeIpRevIpDto(String caseNo) {
		this.typeCode = Codes.revelantIpType.INTERNAL;
		this.caseNo = caseNo;
		this.status = new ListableDto("", "");
		this.oicContactNumber = "NA";
	}

	public CeIpRevIpDto(CeCase ceCase) {
		this.id = ceCase.getId();
		this.typeCode = Codes.revelantIpType.INTERNAL;
		this.createdOn = ceCase.getCreatedDate();
		this.caseNo = ceCase.getCaseNo();
		this.status = new ListableDto(ceCase.getStatus());
		this.oic = ceCase.getOic().getName();
		this.oicContactNumber = "NA";
	}

	public CeIpRevIpDto(CeCaseExternalIp ceCaseExternalIp) {
		this.id = ceCaseExternalIp.getId();
		this.typeCode = Codes.revelantIpType.EXTERNAL;
		this.caseNo = ceCaseExternalIp.getCaseNo();
		this.status = new ListableDto(ceCaseExternalIp.getStatus());
		this.oic = ceCaseExternalIp.getOic();
		this.oicContactNumber = ceCaseExternalIp.getOicContactNo();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getOic() {
		return oic;
	}

	public void setOic(String oic) {
		this.oic = oic;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getOicContactNumber() {
		return oicContactNumber;
	}

	public void setOicContactNumber(String oicContactNumber) {
		this.oicContactNumber = oicContactNumber;
	}

}
