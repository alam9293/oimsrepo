package gov.stb.tag.dto.ce.rectificationshortfall;

import java.time.LocalDateTime;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TravelAgent;

public class CeRectificationShortfallItemDto extends SearchDto {

	@MapProjection(path = "id")
	private Integer id;
	@MapProjection(path = "createdBy")
	private String createdBy;
	@MapProjection(path = "createdDate")
	private LocalDateTime createdDate;
	@MapProjection(path = "updatedBy")
	private String updatedBy;
	@MapProjection(path = "updatedDate")
	private LocalDateTime updatedDate;
	@MapProjection(path = "application")
	private Application application;
	@MapProjection(path = "travelAgent")
	private TravelAgent travelAgent;
	@MapProjection(path = "amount")
	private double amount;

	public CeRectificationShortfallItemDto() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public TravelAgent getTravelAgent() {
		return travelAgent;
	}

	public void setTravelAgent(TravelAgent travelAgent) {
		this.travelAgent = travelAgent;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
