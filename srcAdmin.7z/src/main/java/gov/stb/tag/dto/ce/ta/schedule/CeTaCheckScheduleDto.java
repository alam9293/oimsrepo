package gov.stb.tag.dto.ce.ta.schedule;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.CeCheckScheduleDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeTaCheckSchedule;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;

public class CeTaCheckScheduleDto extends CeCheckScheduleDto {

	private Integer[] years;
	private LocalDate minDate;
	private LocalDate maxDate;

	private Integer id;
	private Integer month;
	private Integer year;

	private List<CeTaCheckScheduleItemDto> scheduleItems = Lists.newArrayList();
	private List<Integer> scheduleItemsTobeDeleted = Lists.newArrayList();

	public CeTaCheckScheduleDto() {
		super();
		LocalDate currentDate = LocalDate.now();
		this.setYears(new Integer[currentDate.getYear() - Codes.Constants.CE_SCHEDULE_START_YEAR + 2]);
		for (int i = 0; i < this.years.length; i++) {
			this.years[i] = Codes.Constants.CE_SCHEDULE_START_YEAR + i;
		}
	}

	public static void setMinMaxDate(CeTaCheckScheduleDto dto) {
		dto.setMinDate(LocalDate.of(dto.getYear(), dto.getMonth(), 1));
		dto.setMaxDate(dto.getMinDate().plusMonths(1).minusDays(1));
	}

	public static CeTaCheckScheduleDto buildNewCeTaCheckSchedule(Integer year, Integer month) {
		CeTaCheckScheduleDto dto = new CeTaCheckScheduleDto();
		dto.setMonth(month);
		dto.setYear(year);
		dto.setStatus(new ListableDto(Codes.Statuses.CE_WKFLW_NEW, "New"));
		setMinMaxDate(dto);
		return dto;
	}

	public static CeTaCheckScheduleDto buildFromCeTaCheckSchedule(Cache cache, WorkflowHelper workflowHelper, CeTaCheckSchedule schedule, User oic) {
		CeTaCheckScheduleDto dto = new CeTaCheckScheduleDto();
		dto.setId(schedule.getId());
		dto.setMonth(schedule.getMonth());
		dto.setYear(schedule.getYear());
		dto.setOic(new ListableDto(oic));
		dto.setUpdatedDate(schedule.getUpdatedDate());
		setMinMaxDate(dto);

		List<CeTaCheckScheduleItem> scheduleItems = schedule.getCeTaCheckScheduleItems().stream().filter(item -> !item.isDeleted()).collect(Collectors.toList());
		if (CollectionUtils.isNotEmpty(scheduleItems)) {
			List<CeTaCheckScheduleItem> sortedScheduleItems = scheduleItems.stream()
					.sorted(Comparator.comparing(CeTaCheckScheduleItem::getScheduledDate, Comparator.nullsFirst(Comparator.naturalOrder()))).collect(Collectors.toList());
			sortedScheduleItems.forEach(item -> dto.getScheduleItems().add(CeTaCheckScheduleItemDto.buildFromScheduleItem(cache, item)));
		}

		Workflow workflow = schedule.getWorkflow();
		if (workflow != null) {
			CeTaCheckScheduleDto.buildWorkflowAction(cache, workflowHelper, dto, workflow);
		} else {
			dto.setStatus(new ListableDto(Codes.Statuses.CE_WKFLW_NEW, "Draft"));
		}

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer[] getYears() {
		return years;
	}

	public void setYears(Integer[] years) {
		this.years = years;
	}

	public LocalDate getMinDate() {
		return minDate;
	}

	public void setMinDate(LocalDate minDate) {
		this.minDate = minDate;
	}

	public LocalDate getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(LocalDate maxDate) {
		this.maxDate = maxDate;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public List<CeTaCheckScheduleItemDto> getScheduleItems() {
		return scheduleItems;
	}

	public void setScheduleItems(List<CeTaCheckScheduleItemDto> scheduleItems) {
		this.scheduleItems = scheduleItems;
	}

	public List<Integer> getScheduleItemsTobeDeleted() {
		return scheduleItemsTobeDeleted;
	}

	public void setScheduleItemsTobeDeleted(List<Integer> scheduleItemsTobeDeleted) {
		this.scheduleItemsTobeDeleted = scheduleItemsTobeDeleted;
	}

}
