package gov.stb.tag.dto.ce.ta.tacheck;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import com.google.common.base.Strings;

import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckDocument;
import gov.stb.tag.model.File;
import gov.stb.tag.repository.FileRepository;

public class CeTaCheckDocumentDto extends EntityDto {

	private Integer id;

	private String invoiceBookingNo;

	private BigDecimal totalPrice;

	private Integer noOfPax;

	private BigDecimal paymentDepositMade;

	private ListableDto isConsumerInformed = new ListableDto();

	private String remarks;

	private List<AttachmentDto> files = new ArrayList<AttachmentDto>();

	public static CeTaCheckDocumentDto buildCheckDoc(Cache cache, CeTaCheckDocument model, CeTaCheckDocumentDto dto) {
		dto.setId(model.getId());
		dto.setInvoiceBookingNo(model.getInvoiceBookingNo());
		dto.setTotalPrice(model.getTotalPrice());
		dto.setNoOfPax(model.getNoOfPax());
		dto.setPaymentDepositMade(model.getPaymentDepositMade());
		dto.setIsConsumerInformed(new ListableDto(model.getIsConsumerInformed()));
		dto.setRemarks(model.getRemarks());
		if (model.getFiles() != null && model.getFiles().size() > 0) {
			for (File row : model.getFiles()) {
				dto.getFiles().add(AttachmentDto.buildFromFile(row));
			}
		}
		return dto;
	}

	public static CeTaCheckDocument buildDocumentDtoToModel(FileHelper fileHelper, FileRepository fileRepository, CacheHelper cache, CeTaCheckDocumentDto dto, CeTaCheckDocument docModel,
			CeTaCheck ceTaCheck) {
		docModel.setCeTaCheck(ceTaCheck);
		docModel.setInvoiceBookingNo(dto.getInvoiceBookingNo());
		docModel.setTotalPrice(dto.getTotalPrice());
		docModel.setNoOfPax(dto.getNoOfPax());
		docModel.setPaymentDepositMade(dto.getPaymentDepositMade());
		docModel.setIsConsumerInformed(cache.getType(dto.getIsConsumerInformed().getKey().toString()));
		docModel.setRemarks(dto.getRemarks());
		if (dto.getFiles() != null && dto.getFiles().size() > 0) {
			List<Integer> fileIds = dto.getFiles().parallelStream().map(AttachmentDto::getId).collect(Collectors.toList());
			if (fileIds.size() > 0) {
				List<File> files = fileRepository.getFiles(fileIds);
				docModel.setFiles(new HashSet<>(files));
			}
		}
		return docModel;
	}

	public boolean isValid(CeTaCheckDocumentDto dto) {
		return !Strings.isNullOrEmpty(dto.getInvoiceBookingNo()) || dto.getTotalPrice() != null || dto.getNoOfPax() != null || dto.getPaymentDepositMade() != null
				|| !Strings.isNullOrEmpty(dto.getIsConsumerInformed().getKey().toString()) || (dto.getFiles() != null && dto.getFiles().size() > 0);
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getInvoiceBookingNo() {
		return invoiceBookingNo;
	}

	public void setInvoiceBookingNo(String invoiceBookingNo) {
		this.invoiceBookingNo = invoiceBookingNo;
	}

	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Integer getNoOfPax() {
		return noOfPax;
	}

	public void setNoOfPax(Integer noOfPax) {
		this.noOfPax = noOfPax;
	}

	public BigDecimal getPaymentDepositMade() {
		return paymentDepositMade;
	}

	public void setPaymentDepositMade(BigDecimal paymentDepositMade) {
		this.paymentDepositMade = paymentDepositMade;
	}

	public ListableDto getIsConsumerInformed() {
		return isConsumerInformed;
	}

	public void setIsConsumerInformed(ListableDto isConsumerInformed) {
		this.isConsumerInformed = isConsumerInformed;
	}

	public String getIsConsumerInformedCode() {
		return isConsumerInformed.getKey() != null ? isConsumerInformed.getKey().toString() : null;
	}

	public List<AttachmentDto> getFiles() {
		return files;
	}

	public void setFiles(List<AttachmentDto> files) {
		this.files = files;
	}

}
