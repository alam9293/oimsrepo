package gov.stb.tag.dto.ce.ta.tacheck;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.CeSubmissionStatus;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.AuditableEntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.SignDocDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportTaDetailsDto;
import gov.stb.tag.dto.dashboard.UserProfileDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckDocument;
import gov.stb.tag.model.CeTaCheckQn;
import gov.stb.tag.model.CeTaCheckQnResponse;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.UserRepository;

public class CeTaCheckDto extends AuditableEntityDto {
	private Boolean toSubmit = false;
	private Boolean isDraft = true;

	// Ce schedule details
	private Integer ceTaCheckScheduleItemId;
	private Integer scheduleMonth;
	private Integer scheduleYear;
	private ListableDto ceTaCheckType = new ListableDto();
	private LocalDate scheduledDate;

	// Ce check details
	private Integer ceTaCheckId;
	private Boolean isAcknowledged;
	private LocalDate lastAcknowledgedDate;
	private UserProfileDto lastAcknowledgedBy;
	private ListableDto isCompliant = new ListableDto();;
	private ListableDto submissionStatus = new ListableDto();
	private String toRevisit;
	private String crmRefNo;

	// TA details
	private CeTaCheckReportTaDetailsDto taDetailsDto = new CeTaCheckReportTaDetailsDto();

	private String taStaffName; // Travel agent staff who assisted in the check (include designation)
	private String taStaffDesignation;
	private LocalDateTime checkedDate; // system stamp the date and time after TA staff signs

	private UserProfileDto eoUserDto; // [Assigned EO], not editable
	private ListableDto auxEo = new ListableDto();
	private String remarks;

	private List<CeTaCheckQnReponseDto> ceTaCheckQnResponseDto = new ArrayList<CeTaCheckQnReponseDto>();
	private List<CeTaCheckQnReponseDto> ceTaCheckQnResponseGeneralDto = new ArrayList<CeTaCheckQnReponseDto>();
	private List<CeTaCheckDocumentDto> ceTaCheckDocumentDto = new ArrayList<CeTaCheckDocumentDto>();
	private List<Integer> checkDocumentsToDelete = new ArrayList<Integer>();
	private List<AttachmentDto> files = new ArrayList<AttachmentDto>();
	private List<Integer> filesToDelete = new ArrayList<Integer>();

	private Boolean disableEdit = Boolean.FALSE;

	// Case details
	private Integer caseId;
	private String caseNo;

	// For acknowledgement
	private Long daysLeftToAcknowledge;

	// For Sign Doc
	private SignDocDto signDocDto;

	public static CeTaCheckDto buildCheckDtoFromCheckModel(Cache cache, CeTaCheck model, CeTaCheckDto dto, UserRepository userRepo) {
		dto.setCeTaCheckId(model.getId());
		dto.setCeTaCheckScheduleItemId(model.getCeTaCheckScheduleItem().getId());
		dto.setCeTaCheckType(new ListableDto(model.getCeTaCheckScheduleItem().getCheckType()));
		dto.setSubmissionStatus(new ListableDto(cache.getStatus(model.isDraft() ? CeSubmissionStatus.STAT_CE_SUBMISSION_DRAFT : CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED)));
		dto.setToRevisit(model.getCeTaCheckScheduleItem().toRevisit());
		dto.setIsDraft(model.isDraft());

		CeTaCheckReportTaDetailsDto taDetailsDto = new CeTaCheckReportTaDetailsDto();
		taDetailsDto.setAddressDto(AddressDto.buildFromAddress(cache, model.getAddress()));
		if (model.getAddressType() != null) {
			taDetailsDto.setAddressType(new ListableDto(model.getAddressType()));
		}
		taDetailsDto.setLicenceNo(model.getLicenceNo());
		taDetailsDto.setUen(model.getUen());
		taDetailsDto.setTaName(model.getTaName());
		taDetailsDto.setTaKeUin(model.getTaKeUin());
		taDetailsDto.setTaKeName(model.getTaKeName());
		dto.setTaDetailsDto(taDetailsDto);

		dto.setTaStaffName(model.getTaStaffName());
		dto.setTaStaffDesignation(model.getTaStaffDesignation());
		dto.setCheckedDate(model.getCheckedDate());
		dto.setIsAcknowledged(model.isAcknowledged());
		dto.setLastAcknowledgedDate(model.getLastAcknowledgedDate());
		if (model.getLastAcknowledgedBy() != null) {
			dto.setLastAcknowledgedBy(UserProfileDto.buildFromUser(cache, model.getLastAcknowledgedBy(), null));
		}
		dto.setEoUserDto(UserProfileDto.buildFromUser(cache, model.getEoUser(), null));
		if (model.getIsCompliant() != null) {
			dto.setIsCompliant(new ListableDto(model.getIsCompliant()));
		}
		if (model.getAuxEoUser() != null) {
			dto.setAuxEo(new ListableDto(model.getAuxEoUser()));
		}
		dto.setRemarks(model.getRemarks());
		if (model.getCeTaCheckQnResponses() != null && model.getCeTaCheckQnResponses().size() > 0) {
			for (CeTaCheckQnResponse row : model.getCeTaCheckQnResponses()) {
				if (!row.getCeTaCheckQn().isGeneral()) {
					dto.getCeTaCheckQnResponseDto().add(CeTaCheckQnReponseDto.buildQnAndReponse(cache, row, new CeTaCheckQnReponseDto()));
				} else {
					dto.getCeTaCheckQnResponseGeneralDto().add(CeTaCheckQnReponseDto.buildQnAndReponse(cache, row, new CeTaCheckQnReponseDto()));
				}
			}
			Collections.sort(dto.getCeTaCheckQnResponseGeneralDto(), Comparator.comparing(CeTaCheckQnReponseDto::getOrdinal));
			Collections.sort(dto.getCeTaCheckQnResponseDto(), Comparator.comparing(CeTaCheckQnReponseDto::getOrdinal));
		}

		if (model.getCeTaCheckDocuments() != null && model.getCeTaCheckDocuments().size() > 0) {
			for (CeTaCheckDocument row : model.getCeTaCheckDocuments()) {
				dto.getCeTaCheckDocumentDto().add(CeTaCheckDocumentDto.buildCheckDoc(cache, row, new CeTaCheckDocumentDto()));
			}
		}

		if (model.getFiles() != null && model.getFiles().size() > 0) {
			for (File row : model.getFiles()) {
				dto.getFiles().add(AttachmentDto.buildFromFile(row));
			}
		}

		if (model.getCeCase() != null) {
			dto.setCaseId(model.getCeCase().getId());
			dto.setCaseNo(model.getCeCase().getCaseNo());
			dto.setCrmRefNo(model.getCeCase().getCrmRefNo());
			dto.setDaysLeftToAcknowledge(
					ChronoUnit.DAYS.between(LocalDate.now(), model.getCeCase().getCreatedDate().toLocalDate().plusDays(cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_SLA_FOR_APPROVAL))));
		}

		dto.buildEditorDetailsFromModel(model, dto, userRepo);

		if (!Strings.isNullOrEmpty(model.getSigndocId())) {
			dto.setSignDocDto(new SignDocDto());
			dto.getSignDocDto().setSdweb_docid(model.getSigndocId());
		}

		return dto;
	}

	public static CeTaCheckDto buildNewCheckDto(Cache cache, CeTaCheckScheduleItem model, Stakeholder stakeholderModel, CeTaCheckDto dto, List<CeTaCheckQn> checkQns, User currentUser) {
		dto.setCeTaCheckScheduleItemId(model.getId());
		dto.setSubmissionStatus(new ListableDto(CeSubmissionStatus.STAT_CE_NEW, "New"));
		dto.setCeTaCheckType(new ListableDto(model.getCheckType()));

		CeTaCheckReportTaDetailsDto taDetails = new CeTaCheckReportTaDetailsDto();
		taDetails.setAddressDto(AddressDto.buildFromAddress(cache, model.getAddress()));
		taDetails.setAddressType(new ListableDto(model.getAddressType()));
		taDetails.setLicenceNo(model.getLicence().getLicenceNo());
		taDetails.setUen(model.getLicence().getTravelAgent().getUen());
		taDetails.setTaName(model.getTaName());
		if (stakeholderModel != null) {
			taDetails.setTaKeUin(stakeholderModel.getUin());
			taDetails.setTaKeName(stakeholderModel.getName());
		}
		dto.setTaDetailsDto(taDetails);
		dto.setEoUserDto(UserProfileDto.buildFromUser(cache, model.getEoUser(), null));

		if (model.getAuxEoUser() != null) {
			dto.setAuxEo(new ListableDto(model.getAuxEoUser()));
		}

		if (checkQns != null) {
			for (CeTaCheckQn row : checkQns) {
				if (!row.isGeneral()) {
					dto.getCeTaCheckQnResponseDto().add(CeTaCheckQnReponseDto.buildQnOnly(cache, row, new CeTaCheckQnReponseDto()));
				} else {
					dto.getCeTaCheckQnResponseGeneralDto().add(CeTaCheckQnReponseDto.buildQnOnly(cache, row, new CeTaCheckQnReponseDto()));
				}

			}
		}

		dto.buildEditorDetails(currentUser.getName(), LocalDateTime.now(), null, null, dto);

		return dto;
	}

	public Integer getCeTaCheckId() {
		return ceTaCheckId;
	}

	public void setCeTaCheckId(Integer ceTaCheckId) {
		this.ceTaCheckId = ceTaCheckId;
	}

	public Integer getCeTaCheckScheduleItemId() {
		return ceTaCheckScheduleItemId;
	}

	public void setCeTaCheckScheduleItemId(Integer ceTaCheckScheduleItemId) {
		this.ceTaCheckScheduleItemId = ceTaCheckScheduleItemId;
	}

	public ListableDto getSubmissionStatus() {
		return submissionStatus;
	}

	public void setSubmissionStatus(ListableDto submissionStatus) {
		this.submissionStatus = submissionStatus;
	}

	public ListableDto getCeTaCheckType() {
		return ceTaCheckType;
	}

	public void setCeTaCheckType(ListableDto ceTaCheckType) {
		this.ceTaCheckType = ceTaCheckType;
	}

	public String getTaStaffName() {
		return taStaffName;
	}

	public void setTaStaffName(String taStaffName) {
		this.taStaffName = taStaffName;
	}

	public String getTaStaffDesignation() {
		return taStaffDesignation;
	}

	public void setTaStaffDesignation(String taStaffDesignation) {
		this.taStaffDesignation = taStaffDesignation;
	}

	public LocalDateTime getCheckedDate() {
		return checkedDate;
	}

	public void setCheckedDate(LocalDateTime checkedDate) {
		this.checkedDate = checkedDate;
	}

	public UserProfileDto getEoUserDto() {
		return eoUserDto;
	}

	public void setEoUserDto(UserProfileDto eoUserDto) {
		this.eoUserDto = eoUserDto;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getScheduleMonth() {
		return scheduleMonth;
	}

	public void setScheduleMonth(Integer scheduleMonth) {
		this.scheduleMonth = scheduleMonth;
	}

	public List<CeTaCheckQnReponseDto> getCeTaCheckQnResponseDto() {
		return ceTaCheckQnResponseDto;
	}

	public void setCeTaCheckQnResponseDto(List<CeTaCheckQnReponseDto> ceTaCheckQnResponseDto) {
		this.ceTaCheckQnResponseDto = ceTaCheckQnResponseDto;
	}

	public List<CeTaCheckDocumentDto> getCeTaCheckDocumentDto() {
		return ceTaCheckDocumentDto;
	}

	public void setCeTaCheckDocumentDto(List<CeTaCheckDocumentDto> ceTaCheckDocumentDto) {
		this.ceTaCheckDocumentDto = ceTaCheckDocumentDto;
	}

	public Integer getScheduleYear() {
		return scheduleYear;
	}

	public void setScheduleYear(Integer scheduleYear) {
		this.scheduleYear = scheduleYear;
	}

	public List<CeTaCheckQnReponseDto> getCeTaCheckQnResponseGeneralDto() {
		return ceTaCheckQnResponseGeneralDto;
	}

	public void setCeTaCheckQnResponseGeneralDto(List<CeTaCheckQnReponseDto> ceTaCheckQnResponseGeneralDto) {
		this.ceTaCheckQnResponseGeneralDto = ceTaCheckQnResponseGeneralDto;
	}

	public ListableDto getAuxEo() {
		return auxEo;
	}

	public void setAuxEo(ListableDto auxEo) {
		this.auxEo = auxEo;
	}

	public Boolean getIsAcknowledged() {
		return isAcknowledged;
	}

	public void setIsAcknowledged(Boolean isAcknowledged) {
		this.isAcknowledged = isAcknowledged;
	}

	public LocalDate getLastAcknowledgedDate() {
		return lastAcknowledgedDate;
	}

	public void setLastAcknowledgedDate(LocalDate lastAcknowledgedDate) {
		this.lastAcknowledgedDate = lastAcknowledgedDate;
	}

	public List<Integer> getCheckDocumentsToDelete() {
		return checkDocumentsToDelete;
	}

	public void setCheckDocumentsToDelete(List<Integer> checkDocumentsToDelete) {
		this.checkDocumentsToDelete = checkDocumentsToDelete;
	}

	public List<AttachmentDto> getFiles() {
		return files;
	}

	public void setFiles(List<AttachmentDto> files) {
		this.files = files;
	}

	public List<Integer> getFilesToDelete() {
		return filesToDelete;
	}

	public void setFilesToDelete(List<Integer> filesToDelete) {
		this.filesToDelete = filesToDelete;
	}

	public LocalDate getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(LocalDate scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public Boolean getToSubmit() {
		return toSubmit;
	}

	public void setToSubmit(Boolean toSubmit) {
		this.toSubmit = toSubmit;
	}

	public ListableDto getIsCompliant() {
		return isCompliant;
	}

	public void setIsCompliant(ListableDto isCompliant) {
		this.isCompliant = isCompliant;
	}

	public UserProfileDto getLastAcknowledgedBy() {
		return lastAcknowledgedBy;
	}

	public void setLastAcknowledgedBy(UserProfileDto lastAcknowledgedBy) {
		this.lastAcknowledgedBy = lastAcknowledgedBy;
	}

	public Boolean getDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(Boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public Integer getCaseId() {
		return caseId;
	}

	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public CeTaCheckReportTaDetailsDto getTaDetailsDto() {
		return taDetailsDto;
	}

	public void setTaDetailsDto(CeTaCheckReportTaDetailsDto taDetailsDto) {
		this.taDetailsDto = taDetailsDto;
	}

	public String getCrmRefNo() {
		return crmRefNo;
	}

	public void setCrmRefNo(String crmRefNo) {
		this.crmRefNo = crmRefNo;
	}

	public Boolean getToRevisit() {
		return Boolean.valueOf(toRevisit);
	}

	public void setToRevisit(Boolean toRevisit) {
		this.toRevisit = toRevisit == null ? null : String.valueOf(toRevisit);
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public Long getDaysLeftToAcknowledge() {
		return daysLeftToAcknowledge;
	}

	public void setDaysLeftToAcknowledge(Long daysLeftToAcknowledge) {
		this.daysLeftToAcknowledge = daysLeftToAcknowledge;
	}

	public SignDocDto getSignDocDto() {
		return signDocDto;
	}

	public void setSignDocDto(SignDocDto signDocDto) {
		this.signDocDto = signDocDto;
	}

}
