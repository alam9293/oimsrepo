package gov.stb.tag.dto.ce.ta.tacheck;

import gov.stb.tag.dto.SignDocDto;

public class CeTaCheckSearchDto extends SignDocDto {
	private Integer ceTaCheckScheduleItemId;
	private Integer ceTaCheckId;

	public Integer getCeTaCheckScheduleItemId() {
		return ceTaCheckScheduleItemId;
	}

	public void setCeTaCheckScheduleItemId(Integer ceTaCheckScheduleItemId) {
		this.ceTaCheckScheduleItemId = ceTaCheckScheduleItemId;
	}

	public Integer getCeTaCheckId() {
		return ceTaCheckId;
	}

	public void setCeTaCheckId(Integer ceTaCheckId) {
		this.ceTaCheckId = ceTaCheckId;
	}

}
