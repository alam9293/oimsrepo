package gov.stb.tag.dto.ce.ta.tacheckreport;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import gov.stb.tag.constant.Codes.CeSubmissionStatus;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTaFieldReport;

public class CeTaCheckReportItemDto extends ApprovalDto {

	private Integer tatiCheckId;
	private Integer ceScheduleItemId;
	private LocalDate scheduledDate;
	private String taName;
	private ListableDto checkType;
	private List<ListableDto> fieldReportIds;
	private ListableDto checkStatus;
	private ListableDto scheduleStatus;
	private Boolean disableSubmit;
	private ListableDto eoUser;
	private ListableDto addressType;
	private Integer caseId;
	private String caseNo;

	public static CeTaCheckReportItemDto buildItemDto(Cache cache, CeTaCheckScheduleItem model, String loginId) {
		CeTaCheckReportItemDto dto = new CeTaCheckReportItemDto();
		dto.setCeScheduleItemId(model.getId());
		dto.setScheduledDate(model.getScheduledDate());
		dto.setTaName(model.getTaName());
		dto.setCheckType(new ListableDto(model.getCheckType()));
		dto.setAddressType(new ListableDto(model.getAddressType()));
		if (model.getCeTaCheck() != null) {
			dto.setTatiCheckId(model.getCeTaCheck().getId());
			dto.setCheckStatus(new ListableDto(cache.getStatus(model.getCeTaCheck().isDraft() ? CeSubmissionStatus.STAT_CE_SUBMISSION_DRAFT : CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED)));
			if (model.getCeTaCheck().getCeCase() != null) {
				dto.setCaseId(model.getCeTaCheck().getCeCase().getId());
				dto.setCaseNo(model.getCeTaCheck().getCeCase().getCaseNo());
			}
		} else {
			dto.setCheckStatus(new ListableDto(CeSubmissionStatus.STAT_CE_NEW, "Create New"));
		}
		if (model.getScheduledDate().isAfter(LocalDate.now().plusMonths(1)) || (!model.getEoUser().getLoginId().equalsIgnoreCase(loginId) && model.getCeTaCheck() == null)) {
			dto.setDisableSubmit(Boolean.TRUE);
		}

		if (model.getCeTaFieldReports() != null && model.getCeTaFieldReports().size() > 0) {
			dto.fieldReportIds = new ArrayList<ListableDto>();
			for (CeTaFieldReport row : model.getCeTaFieldReports()) {
				dto.getFieldReportIds().add(new ListableDto(row.getId(), row.getReportNo()));
				if (row.getCeCase() != null) {
					dto.setCaseId(row.getCeCase().getId());
					dto.setCaseNo(row.getCeCase().getCaseNo());
				}
			}
		}
		if (model.getEoUser() != null) {
			dto.setEoUser(new ListableDto(model.getEoUser().getKey(), model.getEoUser().getName()));
		}

		return dto;
	}

	public Integer getTatiCheckId() {
		return tatiCheckId;
	}

	public void setTatiCheckId(Integer tatiCheckId) {
		this.tatiCheckId = tatiCheckId;
	}

	public Integer getCeScheduleItemId() {
		return ceScheduleItemId;
	}

	public void setCeScheduleItemId(Integer ceScheduleItemId) {
		this.ceScheduleItemId = ceScheduleItemId;
	}

	public LocalDate getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(LocalDate scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public ListableDto getCheckType() {
		return checkType;
	}

	public void setCheckType(ListableDto checkType) {
		this.checkType = checkType;
	}

	public ListableDto getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(ListableDto checkStatus) {
		this.checkStatus = checkStatus;
	}

	public ListableDto getScheduleStatus() {
		return scheduleStatus;
	}

	public void setScheduleStatus(ListableDto scheduleStatus) {
		this.scheduleStatus = scheduleStatus;
	}

	public Boolean getDisableSubmit() {
		return disableSubmit;
	}

	public void setDisableSubmit(Boolean disableSubmit) {
		this.disableSubmit = disableSubmit;
	}

	public List<ListableDto> getFieldReportIds() {
		return fieldReportIds;
	}

	public void setFieldReportIds(List<ListableDto> fieldReportIds) {
		this.fieldReportIds = fieldReportIds;
	}

	public ListableDto getEoUser() {
		return eoUser;
	}

	public void setEoUser(ListableDto eoUser) {
		this.eoUser = eoUser;
	}

	public ListableDto getAddressType() {
		return addressType;
	}

	public void setAddressType(ListableDto addressType) {
		this.addressType = addressType;
	}

	public Integer getCaseId() {
		return caseId;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

}
