package gov.stb.tag.dto.ce.ta.tacheckreport;

public class CeTaCheckReportPersonDetailsDto {

	// Person Details
	private String uinPassportNo;
	private String name;
	private String role;
	private String personContactNo;
	// private ListableDto nationality = new ListableDto();

	public String getUinPassportNo() {
		return uinPassportNo;
	}

	public void setUinPassportNo(String uinPassportNo) {
		this.uinPassportNo = uinPassportNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPersonContactNo() {
		return personContactNo;
	}

	public void setPersonContactNo(String personContactNo) {
		this.personContactNo = personContactNo;
	}

}
