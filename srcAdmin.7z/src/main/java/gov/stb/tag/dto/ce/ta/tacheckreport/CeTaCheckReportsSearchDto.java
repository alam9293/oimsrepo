package gov.stb.tag.dto.ce.ta.tacheckreport;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeTaCheckReportsSearchDto extends SearchDto {

	private String taName;

	private String status;

	private String type;

	private Object[] types;
	private Object[] reportStatus;

	private LocalDate scheduledDateFrom;
	private LocalDate scheduledDateTo;

	private String assignedOfficer;

	private String resultOfTatiCheck;
	private String isDraft;

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Object[] getReportStatus() {
		return reportStatus;
	}

	public void setReportStatus(Object[] reportStatus) {
		this.reportStatus = reportStatus;
	}

	public Object[] getTypes() {
		return types;
	}

	public void setTypes(Object[] types) {
		this.types = types;
	}

	public LocalDate getScheduledDateFrom() {
		return scheduledDateFrom;
	}

	public LocalDate getScheduledDateTo() {
		return scheduledDateTo;
	}

	public void setScheduledDateFrom(LocalDate scheduledDateFrom) {
		this.scheduledDateFrom = scheduledDateFrom;
	}

	public void setScheduledDateTo(LocalDate scheduledDateTo) {
		this.scheduledDateTo = scheduledDateTo;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getResultOfTatiCheck() {
		return resultOfTatiCheck;
	}

	public void setResultOfTatiCheck(String resultOfTatiCheck) {
		this.resultOfTatiCheck = resultOfTatiCheck;
	}

	public String getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(String isDraft) {
		this.isDraft = isDraft;
	}

}
