package gov.stb.tag.dto.ce.tg.checkreports;

import com.google.common.collect.Lists;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.tg.tgfieldreport.CeTgFieldReportDto;
import gov.stb.tag.dto.ce.tg.tgfieldreport.CeTgFieldReportTgDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CeTgCheckReportItemDto extends ApprovalDto {

	// private Integer tgFieldReportId;
	private Integer ceScheduleItemLocationId;
	private LocalDate scheduleDate;
	private ListableDto shift;
	private ListableDto location;
	private List<ListableDto> eoUsers;

	private Integer tgCheckId;
	private List<CeTgFieldReportDto> tgFieldReports = Lists.newArrayList();
	private ListableDto checkStatus;
	private Boolean disableSubmit;
	private Boolean isPendingApproval;

	public static CeTgCheckReportItemDto buildTgCheckReportItemDto(Cache cache, CeTgCheckScheduleItemLocation scheduleItemLocation) {
		CeTgCheckReportItemDto dto = new CeTgCheckReportItemDto();
		dto.setCeScheduleItemLocationId(scheduleItemLocation.getId());
		dto.setScheduleDate(scheduleItemLocation.getCeTgCheckScheduleItem().getScheduleDate());
		dto.setShift(new ListableDto(scheduleItemLocation.getMeridiem().getCode(), scheduleItemLocation.getMeridiem().getLabel()));
		dto.setLocation(new ListableDto(scheduleItemLocation.getLocation().getCode(), scheduleItemLocation.getLocation().getLabel()));

		dto.setEoUsers(new ArrayList<ListableDto>());
		CeTgCheckScheduleItem ceTgCheckScheduleItem = scheduleItemLocation.getCeTgCheckScheduleItem();
		if (ceTgCheckScheduleItem != null && !ceTgCheckScheduleItem.getEoUsers().isEmpty()) {
			for (User user : ceTgCheckScheduleItem.getEoUsers()) {
				dto.getEoUsers().add(new ListableDto(user.getId(), user.getName()));
			}
		}

		if (scheduleItemLocation.getCeTgCheck() != null) {
			CeTgCheck ceTgCheck = scheduleItemLocation.getCeTgCheck();
			dto.setTgCheckId(ceTgCheck.getId());
			dto.setCheckStatus(new ListableDto(cache.getStatus(ceTgCheck.isDraft() ? Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_DRAFT: Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED )) );
		}

		dto.setTgFieldReports(new ArrayList<CeTgFieldReportDto>());
		if (scheduleItemLocation.getCeTgFieldReport() != null && !scheduleItemLocation.getCeTgFieldReport().isEmpty()) {
			for (CeTgFieldReport ceTgFieldReport : scheduleItemLocation.getCeTgFieldReport()) {
				dto.getTgFieldReports().add(CeTgFieldReportDto.buildFromScheduleItemLocationId(cache, ceTgFieldReport));
			}
		}

		WorkflowAction lastAction = null;
		if (!ceTgCheckScheduleItem.getCreatedBy().equalsIgnoreCase("Data Migration")) {
			lastAction = ceTgCheckScheduleItem.getCeTgCheckSchedule().getWorkflow().getLastAction();
		}

		dto.setIsPendingApproval(lastAction != null && Codes.Statuses.CE_WKFLW_APPR.equals(lastAction.getStatus().getCode()) ? false : true);

		if (ceTgCheckScheduleItem.getScheduleDate().isAfter(LocalDate.now()) || (dto.getIsPendingApproval() && ceTgCheckScheduleItem.isEditable())) {
			dto.setDisableSubmit(Boolean.TRUE);
		}

		return dto;
	}

	public Integer getCeScheduleItemLocationId() { return ceScheduleItemLocationId; }

	public void setCeScheduleItemLocationId(Integer ceScheduleItemLocationId) { this.ceScheduleItemLocationId = ceScheduleItemLocationId; }

	public LocalDate getScheduleDate() { return scheduleDate; }

	public void setScheduleDate(LocalDate scheduledDate) { this.scheduleDate = scheduledDate; }

	public ListableDto getShift() { return shift; }

	public void setShift(ListableDto shift) { this.shift = shift; }

	public ListableDto getLocation() { return location; }

	public void setLocation(ListableDto location) { this.location = location; }

	public List<ListableDto> getEoUsers() { return eoUsers; }

	public void setEoUsers(List<ListableDto> eoUsers) { this.eoUsers = eoUsers; }

	public Integer getTgCheckId() { return tgCheckId; }

	public void setTgCheckId(Integer ceTgCheckId) { this.tgCheckId = ceTgCheckId; }

	public List<CeTgFieldReportDto> getTgFieldReports() { return tgFieldReports; }

	public void setTgFieldReports(List<CeTgFieldReportDto> tgFieldReports) { this.tgFieldReports = tgFieldReports; }

	public ListableDto getCheckStatus() { return checkStatus; }

	public void setCheckStatus(ListableDto checkStatus) { this.checkStatus = checkStatus; }

	public Boolean getDisableSubmit() { return disableSubmit; }

	public void setDisableSubmit(Boolean disableSubmit) { this.disableSubmit = disableSubmit; }

	public Boolean getIsPendingApproval() { return isPendingApproval; }

	public void setIsPendingApproval(Boolean isPendingApproval) { this.isPendingApproval = isPendingApproval; }
}
