package gov.stb.tag.dto.ce.tg.groundcheck;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.AuditableEntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportTaDetailsDto;
import gov.stb.tag.dto.dashboard.UserProfileDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.*;
import gov.stb.tag.repository.UserRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CeTgGroundCheckDto extends AuditableEntityDto {
	private Boolean toSubmit = false;

	// Ce schedule details
	private Integer scheduleItemLocationId;
	private LocalDate scheduledDate;
	private ListableDto shift = new ListableDto();
	private ListableDto location = new ListableDto();

	// Ce check details
	private Integer ceTgCheckId;
	private ListableDto ceTgCheckstatus = new ListableDto();
	private Integer noOfGrpWithTg;
	private Integer noOfGrpWithoutTg;
	private Integer noOfGrpWithExpert;
	private Integer noOfStudGrpWithTg;
	private Integer noOfStudGrpWithTchr;
	private Integer noOfStudGrpWithStud;
	private Integer noOfMiceGrpWithTg;
	private Integer noOfMiceGrpWithExpat;
	private Integer noOfCruiseWithTg;
	private Integer noOfCruiseWithoutTg;

	private List<AttachmentDto> files = new ArrayList<AttachmentDto>();
	private List<Integer> filesToDelete = new ArrayList<Integer>();

	private Boolean disableEdit = Boolean.FALSE;

	public static CeTgGroundCheckDto buildSubmittedObservationDto(Cache cache, CeTgCheck tgCheck, UserRepository userRepo) {
		CeTgGroundCheckDto dto = new CeTgGroundCheckDto();

		CeTgCheckScheduleItemLocation ceTgCheckScheduleItemLocation = tgCheck.getCeTgCheckScheduleItemLocation();
		CeTgCheckScheduleItem ceTgCheckScheduleItem = new CeTgCheckScheduleItem();

		if (ceTgCheckScheduleItemLocation != null) {
			ceTgCheckScheduleItem = ceTgCheckScheduleItemLocation.getCeTgCheckScheduleItem();
			dto.setScheduleItemLocationId(ceTgCheckScheduleItemLocation.getId());
			dto.setScheduledDate(ceTgCheckScheduleItem.getScheduleDate());
			dto.setShift(new ListableDto(ceTgCheckScheduleItemLocation.getMeridiem().getCode(), ceTgCheckScheduleItemLocation.getMeridiem().getLabel()));
			dto.setLocation(new ListableDto(ceTgCheckScheduleItemLocation.getLocation().getCode(), ceTgCheckScheduleItemLocation.getLocation().getLabel()));
		}

		dto.setCeTgCheckId(tgCheck.getId());
		dto.setCeTgCheckstatus(new ListableDto(cache.getStatus(tgCheck.isDraft() ? Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_DRAFT : Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED )) );
		dto.setNoOfGrpWithTg(tgCheck.getNoOfGrpWithTg());
		dto.setNoOfGrpWithoutTg(tgCheck.getNoOfGrpWithoutTg());
		dto.setNoOfGrpWithExpert(tgCheck.getNoOfGrpWithExpert());
		dto.setNoOfStudGrpWithTg(tgCheck.getNoOfStudGrpWithTg());
		dto.setNoOfStudGrpWithTchr(tgCheck.getNoOfStudGrpWithTchr());
		dto.setNoOfStudGrpWithStud(tgCheck.getNoOfStudGrpWithStud());
		dto.setNoOfMiceGrpWithTg(tgCheck.getNoOfMiceGrpWithTg());
		dto.setNoOfMiceGrpWithExpat(tgCheck.getNoOfMiceGrpWithExpat());
		dto.setNoOfCruiseWithTg(tgCheck.getNoOfCruiseWithTg());
		dto.setNoOfCruiseWithoutTg(tgCheck.getNoOfCruiseWithoutTg());

		if (tgCheck.getFiles().size() > 0) {
			for (File row : tgCheck.getFiles()) {
				dto.getFiles().add(AttachmentDto.buildFromFile(row));
			}
		}

		dto.buildEditorDetailsFromModel(tgCheck, dto, userRepo);

		return dto;
	}

	public static CeTgGroundCheckDto buildNewObservationDto(CeTgCheckScheduleItemLocation scheduleItemLocation) {
		CeTgGroundCheckDto dto = new CeTgGroundCheckDto();

		CeTgCheckScheduleItem ceTgCheckScheduleItem = new CeTgCheckScheduleItem();

		dto.setScheduleItemLocationId(scheduleItemLocation.getId());

		if (scheduleItemLocation != null) {
			ceTgCheckScheduleItem = scheduleItemLocation.getCeTgCheckScheduleItem();
			dto.setScheduledDate(ceTgCheckScheduleItem.getScheduleDate());
			dto.setShift(new ListableDto(scheduleItemLocation.getMeridiem().getCode(), scheduleItemLocation.getMeridiem().getLabel()));
			dto.setLocation(new ListableDto(scheduleItemLocation.getLocation().getCode(), scheduleItemLocation.getLocation().getLabel()));
		}

		return dto;
	}

	public Boolean getToSubmit() {
		return toSubmit;
	}

	public void setToSubmit(Boolean toSubmit) {
		this.toSubmit = toSubmit;
	}

	public Integer getScheduleItemLocationId() {
		return scheduleItemLocationId;
	}

	public void setScheduleItemLocationId(Integer scheduleItemLocationId) {
		this.scheduleItemLocationId = scheduleItemLocationId;
	}

	public LocalDate getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(LocalDate scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public ListableDto getShift() {
		return shift;
	}

	public void setShift(ListableDto shift) {
		this.shift = shift;
	}

	public ListableDto getLocation() {
		return location;
	}

	public void setLocation(ListableDto location) {
		this.location = location;
	}

	public Integer getCeTgCheckId() {
		return ceTgCheckId;
	}

	public void setCeTgCheckId(Integer ceTgCheckId) {
		this.ceTgCheckId = ceTgCheckId;
	}

	public ListableDto getCeTgCheckstatus() {
		return ceTgCheckstatus;
	}

	public void setCeTgCheckstatus(ListableDto ceTgCheckstatus) {
		this.ceTgCheckstatus = ceTgCheckstatus;
	}

	public Integer getNoOfGrpWithTg() {
		return noOfGrpWithTg;
	}

	public void setNoOfGrpWithTg(Integer noOfGrpWithTg) {
		this.noOfGrpWithTg = noOfGrpWithTg;
	}

	public Integer getNoOfGrpWithoutTg() {
		return noOfGrpWithoutTg;
	}

	public void setNoOfGrpWithoutTg(Integer noOfGrpWithoutTg) {
		this.noOfGrpWithoutTg = noOfGrpWithoutTg;
	}

	public Integer getNoOfGrpWithExpert() {
		return noOfGrpWithExpert;
	}

	public void setNoOfGrpWithExpert(Integer noOfGrpWithExpert) {
		this.noOfGrpWithExpert = noOfGrpWithExpert;
	}

	public Integer getNoOfStudGrpWithTg() {
		return noOfStudGrpWithTg;
	}

	public void setNoOfStudGrpWithTg(Integer noOfStudGrpWithTg) {
		this.noOfStudGrpWithTg = noOfStudGrpWithTg;
	}

	public Integer getNoOfStudGrpWithTchr() {
		return noOfStudGrpWithTchr;
	}

	public void setNoOfStudGrpWithTchr(Integer noOfStudGrpWithTgTchr) {
		this.noOfStudGrpWithTchr = noOfStudGrpWithTgTchr;
	}

	public Integer getNoOfStudGrpWithStud() {
		return noOfStudGrpWithStud;
	}

	public void setNoOfStudGrpWithStud(Integer noOfStudGrpWithStud) {
		this.noOfStudGrpWithStud = noOfStudGrpWithStud;
	}

	public Integer getNoOfMiceGrpWithTg() {
		return noOfMiceGrpWithTg;
	}

	public void setNoOfMiceGrpWithTg(Integer noOfMiceGrpWithTg) {
		this.noOfMiceGrpWithTg = noOfMiceGrpWithTg;
	}

	public Integer getNoOfMiceGrpWithExpat() {
		return noOfMiceGrpWithExpat;
	}

	public void setNoOfMiceGrpWithExpat(Integer noOfMiceGrpWithExpat) {
		this.noOfMiceGrpWithExpat = noOfMiceGrpWithExpat;
	}

	public Integer getNoOfCruiseWithTg() {
		return noOfCruiseWithTg;
	}

	public void setNoOfCruiseWithTg(Integer noOfCruiseWithTg) {
		this.noOfCruiseWithTg = noOfCruiseWithTg;
	}

	public Integer getNoOfCruiseWithoutTg() {
		return noOfCruiseWithoutTg;
	}

	public void setNoOfCruiseWithoutTg(Integer noOfCruiseWithoutTg) {
		this.noOfCruiseWithoutTg = noOfCruiseWithoutTg;
	}

	public List<AttachmentDto> getFiles() {
		return files;
	}

	public void setFiles(List<AttachmentDto> files) {
		this.files = files;
	}

	public List<Integer> getFilesToDelete() {
		return filesToDelete;
	}

	public void setFilesToDelete(List<Integer> filesToDelete) {
		this.filesToDelete = filesToDelete;
	}

	public Boolean getDisableEdit() { return disableEdit; }

	public void setDisableEdit(Boolean disableEdit) { this.disableEdit = disableEdit; }

}
