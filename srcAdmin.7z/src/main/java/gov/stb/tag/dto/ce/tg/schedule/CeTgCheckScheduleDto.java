package gov.stb.tag.dto.ce.tg.schedule;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import gov.stb.tag.dto.ce.CeCheckScheduleDto;
import org.apache.commons.collections.CollectionUtils;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeTgCheckSchedule;
import gov.stb.tag.model.CeTgCheckScheduleItem;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;

public class CeTgCheckScheduleDto extends CeCheckScheduleDto {

	private static final Integer DAYS_IN_WEEK = 7;

	private Integer id;

	private Integer year;

	private LocalDate fromDate;

	private List<CeTgCheckScheduleItemDto> ceTgCheckScheduleItems = Lists.newArrayList();

	public CeTgCheckScheduleDto() {
		super();
	}

	public CeTgCheckScheduleDto(Integer year, LocalDate fromDate) {
		super();
		setStatus(new ListableDto(Codes.Statuses.CE_WKFLW_NEW, "New"));
		this.year = year;
		this.fromDate = fromDate;

		for (int i = 0; i < DAYS_IN_WEEK; i++) {
			ceTgCheckScheduleItems.add(new CeTgCheckScheduleItemDto(fromDate));
			fromDate = fromDate.plusDays(1);
		}
	}

	public CeTgCheckScheduleDto(Cache cache, WorkflowHelper workflowHelper, CeTgCheckSchedule ceTgCheckSchedule, User oic) {
		super();
		if (ceTgCheckSchedule != null) {
			this.id = ceTgCheckSchedule.getId();
			LocalDate tempFromDate = ceTgCheckSchedule.getFromDate();
			this.year = ceTgCheckSchedule.getYear();
			this.fromDate = tempFromDate;
			setOic(new ListableDto(oic));
			setUpdatedDate(ceTgCheckSchedule.getUpdatedDate());

			Set<CeTgCheckScheduleItem> scheduleItems = ceTgCheckSchedule.getCeTgCheckScheduleItems();
			if (CollectionUtils.isNotEmpty(scheduleItems)) {
				this.ceTgCheckScheduleItems = scheduleItems.stream()
						// sort by date
						.sorted(Comparator.comparing(CeTgCheckScheduleItem::getScheduleDate, Comparator.nullsFirst(Comparator.naturalOrder())))
						// map to CeTgCheckScheduleItemDto
						.map(x -> {
							return new CeTgCheckScheduleItemDto(x);
						}).collect(Collectors.toList());
			}

			Workflow workflow = ceTgCheckSchedule.getWorkflow();
			if (workflow != null) {
				buildWorkflowAction(cache, workflowHelper, this, workflow);
			} else {
				setStatus(new ListableDto(Codes.Statuses.CE_WKFLW_NEW, "Draft"));
			}
		}
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<CeTgCheckScheduleItemDto> getCeTgCheckScheduleItems() {
		return ceTgCheckScheduleItems;
	}

	public void setCeTgCheckScheduleItems(List<CeTgCheckScheduleItemDto> ceTgCheckScheduleItems) {
		this.ceTgCheckScheduleItems = ceTgCheckScheduleItems;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

}
