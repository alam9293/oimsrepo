package gov.stb.tag.dto.ce.tg.schedule;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;

import gov.stb.tag.model.CeTgCheckScheduleItem;
import gov.stb.tag.model.CeTgCheckScheduleItemLocation;

public class CeTgCheckScheduleItemDto {

	private static final Integer DEFAULT_LOCATION = 4;

	private Integer id;

	private LocalDate scheduleDate;

	private String remarks;

	private List<Integer> eoUsers = Lists.newArrayList();;

	private List<String> oeoUsers = Lists.newArrayList();;

	private List<CeTgCheckScheduleItemLocationDto> ceTgCheckScheduleItemLocations = Lists.newArrayList();

	private List<Integer> ceTgCheckScheduleItemLocationsToBeDeleted = Lists.newArrayList();

	private Boolean isApproved = false;

	private Boolean isEditable = true;

	public CeTgCheckScheduleItemDto() {
	}

	public CeTgCheckScheduleItemDto(LocalDate scheduleDate) {
		super();
		this.scheduleDate = scheduleDate;

		for (int i = 0; i < DEFAULT_LOCATION; i++) {
			ceTgCheckScheduleItemLocations.add(new CeTgCheckScheduleItemLocationDto());
		}

		this.isApproved = false;
		// this.isEditable = !scheduleDate.isBefore(LocalDate.now());
	}

	public CeTgCheckScheduleItemDto(CeTgCheckScheduleItem ceTgCheckScheduleItem) {
		super();
		this.id = ceTgCheckScheduleItem.getId();
		this.scheduleDate = ceTgCheckScheduleItem.getScheduleDate();
		this.remarks = ceTgCheckScheduleItem.getRemarks();
		this.eoUsers = ceTgCheckScheduleItem.getEoUsers().stream().map(x -> Integer.parseInt(x.getKey().toString())).collect(Collectors.toList());
		this.oeoUsers = ceTgCheckScheduleItem.getOeoUsers().stream().map(x -> x.getKey().toString()).collect(Collectors.toList());

		for (CeTgCheckScheduleItemLocation ceTgCheckScheduleItemLocation : ceTgCheckScheduleItem.getCeTgCheckScheduleItemLocations()) {
			this.ceTgCheckScheduleItemLocations.add(new CeTgCheckScheduleItemLocationDto(ceTgCheckScheduleItemLocation));
		}
		this.isApproved = ceTgCheckScheduleItem.isApproved();
		this.isEditable = ceTgCheckScheduleItem.isEditable();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getScheduleDate() {
		return scheduleDate;
	}

	public void setScheduleDate(LocalDate scheduleDate) {
		this.scheduleDate = scheduleDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public List<Integer> getEoUsers() {
		return eoUsers;
	}

	public void setEoUsers(List<Integer> eoUsers) {
		this.eoUsers = eoUsers;
	}

	public List<String> getOeoUsers() {
		return oeoUsers;
	}

	public void setOeoUsers(List<String> oeoUsers) {
		this.oeoUsers = oeoUsers;
	}

	public List<CeTgCheckScheduleItemLocationDto> getCeTgCheckScheduleItemLocations() {
		return ceTgCheckScheduleItemLocations;
	}

	public void setCeTgCheckScheduleItemLocations(List<CeTgCheckScheduleItemLocationDto> ceTgCheckScheduleItemLocations) {
		this.ceTgCheckScheduleItemLocations = ceTgCheckScheduleItemLocations;
	}

	public List<Integer> getCeTgCheckScheduleItemLocationsToBeDeleted() {
		return ceTgCheckScheduleItemLocationsToBeDeleted;
	}

	public void setCeTgCheckScheduleItemLocationsToBeDeleted(List<Integer> ceTgCheckScheduleItemLocationsToBeDeleted) {
		this.ceTgCheckScheduleItemLocationsToBeDeleted = ceTgCheckScheduleItemLocationsToBeDeleted;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public Boolean getIsEditable() {
		return isEditable;
	}

	public void setIsEditable(Boolean isEditable) {
		this.isEditable = isEditable;
	}

}
