package gov.stb.tag.dto.ce.tg.schedule;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.CeTgCheckScheduleItemLocation;

public class CeTgCheckScheduleItemLocationDto {

	private Integer id;

	private ListableDto meridiem;

	private ListableDto location;

	public CeTgCheckScheduleItemLocationDto() {
	}

	public CeTgCheckScheduleItemLocationDto(CeTgCheckScheduleItemLocation ceTgCheckScheduleItemLocation) {
		this.id = ceTgCheckScheduleItemLocation.getId();
		this.meridiem = new ListableDto(ceTgCheckScheduleItemLocation.getMeridiem());
		this.location = new ListableDto(ceTgCheckScheduleItemLocation.getLocation());
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ListableDto getMeridiem() {
		return meridiem;
	}

	public void setMeridiem(ListableDto meridiem) {
		this.meridiem = meridiem;
	}

	public ListableDto getLocation() {
		return location;
	}

	public void setLocation(ListableDto location) {
		this.location = location;
	}

}
