package gov.stb.tag.dto.ce.tg.tgfieldreport;

import com.google.common.collect.Lists;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.AuditableEntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.dashboard.UserProfileDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.*;
import gov.stb.tag.repository.UserRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CeTgFieldReportDto extends AuditableEntityDto {
	private Boolean toSubmit = false;

	// Field Report details
	private Integer ceTgFieldReportId;
	private String ceTgFieldReportNo;
	private ListableDto status = new ListableDto();
	private String details;
	private String remarks;
	private UserProfileDto eoUser;
	private Integer approverId;
	private String infringedTime;

	// Ce schedule details
	private Integer ceTgCheckScheduleItemLocationId; // ceTgCheckScheduleItemLocationId
	private LocalDate scheduledDate;
	private ListableDto shift = new ListableDto();
	private ListableDto location = new ListableDto();

	// TG details
	private List<CeTgFieldReportTgDto> tgDetailsDtos;
	private List<Integer> deletedTgDetailsDtos = Lists.newArrayList();

	private List<AttachmentDto> files = Lists.newArrayList();
	private List<Integer> filesToDelete = Lists.newArrayList();
	private Boolean disableEdit = Boolean.FALSE;

	private Integer caseId;
	private String caseNo;

	public static CeTgFieldReportDto buildDtoFromTgFieldReport(Cache cache, CeTgFieldReport tgFieldReport, CeTgFieldReportDto dto, UserRepository userRepo) {

		CeTgCheckScheduleItemLocation scheduleItemLocation = tgFieldReport.getCeTgCheckScheduleItemLocation();
		CeTgCheckScheduleItem ceTgCheckScheduleItem = tgFieldReport.getCeTgCheckScheduleItemLocation().getCeTgCheckScheduleItem();

		// field report details
		dto.setCeTgFieldReportId(tgFieldReport.getId());
		dto.setCeTgFieldReportNo(tgFieldReport.getReportNo());
		dto.setStatus(new ListableDto(cache.getStatus(tgFieldReport.isDraft() ? Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_DRAFT : Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED )) );
		dto.setDetails(tgFieldReport.getDetails());
		dto.setRemarks(tgFieldReport.getRemarks());
		dto.setEoUser(UserProfileDto.buildFromUser(cache, tgFieldReport.getEoUser(), null));
		dto.setApproverId(tgFieldReport.getAoUser() != null ? tgFieldReport.getAoUser().getId() : null);
		dto.setInfringedTime(tgFieldReport.getInfringedDate() != null ? tgFieldReport.getInfringedDate().toLocalTime().toString() : null);

		// schedule details
		dto.setCeTgCheckScheduleItemLocationId(tgFieldReport.getCeTgCheckScheduleItemLocation().getId());
		dto.setScheduledDate(ceTgCheckScheduleItem.getScheduleDate());
		dto.setShift(new ListableDto(scheduleItemLocation.getMeridiem().getCode(), scheduleItemLocation.getMeridiem().getLabel()));
		dto.setLocation(new ListableDto(scheduleItemLocation.getLocation().getCode(), scheduleItemLocation.getLocation().getLabel()));

		// TG details
		List<CeTgFieldReportTgDto> tgDetailsDtos = new ArrayList<>();
		Set<CeTgFieldReportTg> ceTgFieldReportTgs = tgFieldReport.getCeTgFieldReportTgs();
		for (CeTgFieldReportTg tg : ceTgFieldReportTgs) {
			tgDetailsDtos.add(CeTgFieldReportTgDto.buildFromCeTgFieldReportTg(cache, tg));
		}
		dto.setTgDetailsDtos(tgDetailsDtos);

		if (tgFieldReport.getFiles() != null && tgFieldReport.getFiles().size() > 0) {
			for (File row : tgFieldReport.getFiles()) {
				dto.getFiles().add(AttachmentDto.buildFromFile(row));
			}
		}

		dto.buildEditorDetailsFromModel(tgFieldReport, dto, userRepo);

		return dto;
	}

	public static CeTgFieldReportDto buildNewTgFieldReport(CeTgCheckScheduleItemLocation scheduleItemLocation) {
		CeTgFieldReportDto dto = new CeTgFieldReportDto();

		CeTgCheckScheduleItem ceTgCheckScheduleItem = scheduleItemLocation.getCeTgCheckScheduleItem();

		dto.setCeTgCheckScheduleItemLocationId(scheduleItemLocation.getId());

		if (scheduleItemLocation != null) {
			dto.setScheduledDate(ceTgCheckScheduleItem.getScheduleDate());
			dto.setShift(new ListableDto(scheduleItemLocation.getMeridiem().getCode(), scheduleItemLocation.getMeridiem().getLabel()));
			dto.setLocation(new ListableDto(scheduleItemLocation.getLocation().getCode(), scheduleItemLocation.getLocation().getLabel()));
		}

		return dto;
	}

	public static CeTgFieldReportDto buildFromScheduleItemLocationId(Cache cache, CeTgFieldReport ceTgFieldReport) {
		CeTgFieldReportDto dto = new CeTgFieldReportDto();
		dto.setCeTgFieldReportId(ceTgFieldReport.getId());
		dto.setCeTgFieldReportNo(ceTgFieldReport.getReportNo());
		dto.setStatus(new ListableDto(cache.getStatus(ceTgFieldReport.isDraft() ? Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_DRAFT : Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED )) );
		return dto;
	}


	public Integer getCeTgFieldReportId() {
		return ceTgFieldReportId;
	}

	public void setCeTgFieldReportId(Integer ceTgFieldReportId) {
		this.ceTgFieldReportId = ceTgFieldReportId;
	}

	public String getCeTgFieldReportNo() { return ceTgFieldReportNo; }

	public void setCeTgFieldReportNo(String ceTgFieldReportNo) { this.ceTgFieldReportNo = ceTgFieldReportNo; }

	public ListableDto getStatus() { return status; }

	public void setStatus(ListableDto status) { this.status = status; }

	public String getDetails() { return details; }

	public void setDetails(String details) { this.details = details; }

	public String getRemarks() { return remarks; }

	public void setRemarks(String remarks) { this.remarks = remarks; }

	public UserProfileDto getEoUser() { return eoUser; }

	public void setEoUser(UserProfileDto eoUser) { this.eoUser = eoUser; }

	public Integer getApproverId() { return approverId; }

	public void setApproverId(Integer approverId) { this.approverId = approverId; }

	public String getInfringedTime() { return infringedTime; }

	public void setInfringedTime(String infringedTime) { this.infringedTime = infringedTime; }

	public Integer getCeTgCheckScheduleItemLocationId() { return ceTgCheckScheduleItemLocationId; }

	public void setCeTgCheckScheduleItemLocationId(Integer ceTgCheckScheduleItemLocationId) { this.ceTgCheckScheduleItemLocationId = ceTgCheckScheduleItemLocationId; }

	public LocalDate getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(LocalDate scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public ListableDto getShift() {
		return shift;
	}

	public void setShift(ListableDto shift) {
		this.shift = shift;
	}

	public ListableDto getLocation() {
		return location;
	}

	public void setLocation(ListableDto location) {
		this.location = location;
	}

	public List<CeTgFieldReportTgDto> getTgDetailsDtos() { return tgDetailsDtos; }

	public void setTgDetailsDtos(List<CeTgFieldReportTgDto> tgDetailsDtos) { this.tgDetailsDtos = tgDetailsDtos; }

	public List<Integer> getDeletedTgDetailsDtos() { return deletedTgDetailsDtos; }

	public void setDeletedTgDetailsDtos(List<Integer> deletedTgDetailsDtos) { this.deletedTgDetailsDtos = deletedTgDetailsDtos; }

	public Boolean getToSubmit() {
		return toSubmit;
	}

	public void setToSubmit(Boolean toSubmit) {
		this.toSubmit = toSubmit;
	}

	public List<AttachmentDto> getFiles() {
		return files;
	}

	public void setFiles(List<AttachmentDto> files) {
		this.files = files;
	}

	public List<Integer> getFilesToDelete() {
		return filesToDelete;
	}

	public void setFilesToDelete(List<Integer> filesToDelete) {
		this.filesToDelete = filesToDelete;
	}

	public Boolean getDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(Boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public Integer getCaseId() { return caseId; }

	public void setCaseId(Integer caseId) { this.caseId = caseId; }

	public String getCaseNo() { return caseNo; }

	public void setCaseNo(String caseNo) { this.caseNo = caseNo; }
}
