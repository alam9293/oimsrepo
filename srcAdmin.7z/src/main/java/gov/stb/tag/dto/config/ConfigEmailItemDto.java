package gov.stb.tag.dto.config;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.model.EmailTemplate;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConfigEmailItemDto extends EntityDto {

	@MapProjection(path = "code")
	private String code;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "description")
	private String description;

	@MapProjection(path = "subject")
	private String subject;

	@MapProjection(path = "body")
	private String body;

	@MapProjection(path = "isActive")
	private Boolean isActive;

	public ConfigEmailItemDto buildConfigEmailItem(ConfigEmailItemDto dto, EmailTemplate emailTemplate) {

		if (emailTemplate != null) {
			dto.setCode(emailTemplate.getCode());
			dto.setName(emailTemplate.getName());
			dto.setSubject(emailTemplate.getSubject());
			dto.setBody(emailTemplate.getBody());
			dto.setIsActive(emailTemplate.getIsActive());
		}
		return dto;
	}

	public EmailTemplate buildEmailTemplate(ConfigEmailItemDto dto, EmailTemplate email) {
		email.setCode(dto.getCode());
		email.setSubject(dto.getSubject());
		email.setBody(dto.getBody());
		email.setIsActive(dto.getIsActive());
		return email;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
}
