package gov.stb.tag.dto.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.Type;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConfigItemDto extends EntityDto {

	@MapProjection(path = "code")
	private String code;

	@MapProjection(path = "label")
	private String label;

	@MapProjection(path = "otherLabel")
	private String otherLabel;

	@MapProjection(path = "isActive")
	private Boolean isActive = Boolean.FALSE;

	@MapProjection(path = "isEditable")
	private Boolean isEditable;

	@MapProjection(path = "ordinal")
	protected Integer ordinal;

	@MapProjection(path = "categoryCode")
	private String categoryCode;

	@MapProjection(path = "value")
	private String value;

	@MapProjection(path = "description")
	private String description;

	@MapProjection(path = "footNote")
	private String footNote;

	// Types
	public ConfigItemDto buildConfigTypeItem(Type type) {
		ConfigItemDto dto = new ConfigItemDto();
		dto.setCode(type.getCode());
		dto.setLabel(type.getLabel());
		dto.setOtherLabel(type.getOtherLabel());
		dto.setIsActive(type.isActive());
		dto.setIsEditable(type.isEditable());
		dto.setOrdinal(type.getOrdinal());
		dto.setFootNote(type.getFootNote());

		return dto;
	}

	public Type buildConfigTypeItem(ConfigItemDto dto, Type type, int ordinalCount, Type category) {
		if (dto.getCode() != null) {
			type.setCode(dto.getCode());
		}
		type.setLabel(dto.getLabel());
		type.setOtherLabel(dto.getOtherLabel());
		type.setOrdinal(ordinalCount);
		if (dto.getIsActive() != null && dto.getIsActive()) {
			type.setIsActive(true);
		} else {
			type.setIsActive(false);
		}

		if (category != null) {
			type.setCategory(category);
		}

		type.setFootNote(dto.getFootNote());
		return type;
	}

	// Status
	public ConfigItemDto buildConfigStatusItem(Status status) {
		ConfigItemDto dto = new ConfigItemDto();
		dto.setCode(status.getCode());
		dto.setLabel(status.getLabel());
		dto.setOtherLabel(status.getOtherLabel());
		dto.setIsActive(status.isActive());
		dto.setIsEditable(status.isEditable());
		dto.setOrdinal(status.getOrdinal());
		dto.setFootNote(status.getFootNote());

		return dto;
	}

	public Status buildConfigStatusItem(ConfigItemDto dto, Status status, int ordinalCount) {
		status.setLabel(dto.getLabel());
		status.setOtherLabel(dto.getOtherLabel());
		status.setOrdinal(ordinalCount);
		status.setIsActive(dto.getIsActive());
		status.setFootNote(dto.getFootNote());

		return status;
	}

	// System Parameter
	public ConfigItemDto buildConfigSysParameterItem(SystemParameter sysParameter) {
		ConfigItemDto dto = new ConfigItemDto();
		dto.setCode(sysParameter.getCode());
		dto.setDescription(sysParameter.getDescription());
		dto.setValue(sysParameter.getValue());
		dto.setIsEditable(sysParameter.isEditable());
		dto.setOrdinal(sysParameter.getOrdinal());
		dto.setCategoryCode(sysParameter.getDataType().getCode());

		return dto;
	}

	public SystemParameter buildConfigStatusItem(ConfigItemDto dto, SystemParameter sys, int ordinalCount) {
		if (!Strings.isNullOrEmpty(dto.getDescription())) {
			sys.setDescription(dto.getDescription());
		}
		if (!Strings.isNullOrEmpty(dto.getValue())) {
			sys.setValue(dto.getValue());
		}
		sys.setOrdinal(ordinalCount);

		return sys;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getOtherLabel() {
		return otherLabel;
	}

	public void setOtherLabel(String otherLabel) {
		this.otherLabel = otherLabel;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsEditable() {
		return isEditable;
	}

	public void setIsEditable(Boolean isEditable) {
		this.isEditable = isEditable;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFootNote() {
		return footNote;
	}

	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}
}
