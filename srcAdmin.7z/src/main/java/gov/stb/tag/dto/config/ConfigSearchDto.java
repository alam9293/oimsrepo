package gov.stb.tag.dto.config;

import gov.stb.tag.dto.SearchDto;

public class ConfigSearchDto extends SearchDto {

	private String selectedCategory;

	private String selectedTypeLabel;

	private String selectedEmail;

	public String getSelectedCategory() {
		return selectedCategory;
	}

	public void setSelectedCategory(String selectedCategory) {
		this.selectedCategory = selectedCategory;
	}

	public String getSelectedTypeLabel() {
		return selectedTypeLabel;
	}

	public void setSelectedTypeLabel(String selectedTypeLabel) {
		this.selectedTypeLabel = selectedTypeLabel;
	}

	public String getSelectedEmail() {
		return selectedEmail;
	}

	public void setSelectedEmail(String selectedEmail) {
		this.selectedEmail = selectedEmail;
	}
}
