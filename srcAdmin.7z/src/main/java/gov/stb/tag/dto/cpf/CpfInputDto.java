package gov.stb.tag.dto.cpf;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CpfInputDto {

	private String sempswi_eeacn_c;

	private String sempswi_con_id;

	private String sempswi_guid;

	public String getSempswi_eeacn_c() {
		return sempswi_eeacn_c;
	}

	public void setSempswi_eeacn_c(String sempswi_eeacn_c) {
		this.sempswi_eeacn_c = sempswi_eeacn_c;
	}

	public String getSempswi_con_id() {
		return sempswi_con_id;
	}

	public void setSempswi_con_id(String sempswi_con_id) {
		this.sempswi_con_id = sempswi_con_id;
	}

	public String getSempswi_guid() {
		return sempswi_guid;
	}

	public void setSempswi_guid(String sempswi_guid) {
		this.sempswi_guid = sempswi_guid;
	}

}
