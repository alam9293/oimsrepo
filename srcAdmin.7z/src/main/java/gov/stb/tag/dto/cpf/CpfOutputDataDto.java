package gov.stb.tag.dto.cpf;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CpfOutputDataDto {

	private String sempswo_eeacn_c;

	private String sempswo_con_id;

	private String sempswo_guid;

	private String sempswo_pmt_sts;

	private String sempswo_return_code;

	public String getSempswo_eeacn_c() {
		return sempswo_eeacn_c;
	}

	public void setSempswo_eeacn_c(String sempswo_eeacn_c) {
		this.sempswo_eeacn_c = sempswo_eeacn_c;
	}

	public String getSempswo_con_id() {
		return sempswo_con_id;
	}

	public void setSempswo_con_id(String sempswo_con_id) {
		this.sempswo_con_id = sempswo_con_id;
	}

	public String getSempswo_guid() {
		return sempswo_guid;
	}

	public void setSempswo_guid(String sempswo_guid) {
		this.sempswo_guid = sempswo_guid;
	}

	public String getSempswo_pmt_sts() {
		return sempswo_pmt_sts;
	}

	public void setSempswo_pmt_sts(String sempswo_pmt_sts) {
		this.sempswo_pmt_sts = sempswo_pmt_sts;
	}

	public String getSempswo_return_code() {
		return sempswo_return_code;
	}

	public void setSempswo_return_code(String sempswo_return_code) {
		this.sempswo_return_code = sempswo_return_code;
	}

}
