package gov.stb.tag.dto.cpf;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CpfRDXSEMPSOperationDto {

	private CpfInputDto input_data;

	public CpfInputDto getInput_data() {
		return input_data;
	}

	public void setInput_data(CpfInputDto input_data) {
		this.input_data = input_data;
	}

}
