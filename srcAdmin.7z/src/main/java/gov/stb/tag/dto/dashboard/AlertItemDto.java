package gov.stb.tag.dto.dashboard;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Alert;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AlertItemDto extends EntityDto {

	@MapProjection(path = "id")
	private Integer id;
	@MapProjection(path = "createdDate")
	private LocalDateTime createdDate;
	@MapProjection(path = "module.label")
	private String module;
	@MapProjection(path = "type.code")
	private String typeCode;
	@MapProjection(path = "type.label")
	private String type;
	@MapProjection(path = "type.otherLabel")
	private String typeOtherLabel;
	@MapProjection(path = "message")
	private String message;
	@MapProjection(path = "url")
	private String url;
	@MapProjection(path = "status.label")
	private String status;
	@MapProjection(path = "status.code")
	private String statusCode;

	public AlertItemDto() {

	}

	public AlertItemDto(Cache cache, Alert alert) {
		id = alert.getId();
		createdDate = alert.getCreatedDate();
		module = cache.getLabel(alert.getModule(), true);
		type = cache.getLabel(alert.getType(), true);
		typeCode = alert.getType().getCode();
		message = alert.getMessage();
		url = alert.getUrl();
		status = cache.getLabel(alert.getStatus(), true);
		statusCode = alert.getStatus().getCode();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getTypeOtherLabel() {
		return typeOtherLabel;
	}

	public void setTypeOtherLabel(String typeOtherLabel) {
		this.typeOtherLabel = typeOtherLabel;
	}

}
