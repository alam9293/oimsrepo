package gov.stb.tag.dto.dashboard;

import java.util.List;
import java.util.Map;

import gov.stb.tag.dto.ListableDto;

public class OfficerDashboardDto {

	private Map<String, List<ListableDto>> pendingActions;

	public Map<String, List<ListableDto>> getPendingActions() {
		return pendingActions;
	}

	public void setPendingActions(Map<String, List<ListableDto>> pendingActions) {
		this.pendingActions = pendingActions;
	}

}
