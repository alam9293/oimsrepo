package gov.stb.tag.dto.dashboard;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Function;
import gov.stb.tag.model.Role;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleFunctionItemDto extends EntityDto {

	private String functionCode;

	private String functionLabel;

	private String moduleCode;

	private String moduleLabel;

	private List<String> roles = new ArrayList<String>();

	private Function functionItem = new Function();

	private Role roleItem = new Role();

	public static RoleFunctionItemDto setListOfRoleFunction(Cache cache, Function fn) {
		RoleFunctionItemDto rfDto = new RoleFunctionItemDto();
		rfDto.setModuleCode(fn.getModule().getCode());
		rfDto.setModuleLabel(fn.getModule().getLabel());
		rfDto.setFunctionCode(fn.getCode());
		rfDto.setFunctionLabel(fn.getLabel());
		return rfDto;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public String getModuleLabel() {
		return moduleLabel;
	}

	public void setModuleLabel(String moduleLabel) {
		this.moduleLabel = moduleLabel;
	}

	public String getFunctionCode() {
		return functionCode;
	}

	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	public String getFunctionLabel() {
		return functionLabel;
	}

	public void setFunctionLabel(String functionLabel) {
		this.functionLabel = functionLabel;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public Function getFunctionItem() {
		return functionItem;
	}

	public void setFunctionItem(Function functionItem) {
		this.functionItem = functionItem;
	}

	public Role getRoleItem() {
		return roleItem;
	}

	public void setRoleItem(Role roleItem) {
		this.roleItem = roleItem;
	}
}
