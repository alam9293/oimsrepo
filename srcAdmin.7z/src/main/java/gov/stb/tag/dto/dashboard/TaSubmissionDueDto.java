package gov.stb.tag.dto.dashboard;

import java.math.BigDecimal;
import java.time.LocalDate;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaNetValueShortfall;

public class TaSubmissionDueDto {

	private Integer taFilingId;

	private ListableDto type;

	private Integer fy;

	private LocalDate dueDate;
	private LocalDate extendedDueDate;

	private ListableDto status;

	private boolean requireRectification = false;

	private boolean rectificationApproved = false;

	private Integer appId;

	private BigDecimal shortfallAmt;

	private Integer rectAppId;

	public TaSubmissionDueDto() {

	}

	public static TaSubmissionDueDto buildFromAnnualFiling(Cache cache, TaFilingCondition filing) {
		if (filing != null) {
			TaSubmissionDueDto dto = new TaSubmissionDueDto();
			dto.setTaFilingId(filing.getId());
			dto.setType(new ListableDto(filing.getApplicationType().getCode(), cache.getLabel(filing.getApplicationType(), true)));
			dto.setDueDate(filing.getDueDate());
			dto.setFy(filing.getFy());
			dto.setStatus(new ListableDto(filing.getStatus().getCode(), cache.getLabel(filing.getStatus(), true)));
			if (filing.getLastExtension() != null && filing.getLastExtension().getToProceed()) {
				dto.setExtendedDueDate(filing.getLastExtension().getExtendedDueDate());
			}
			return dto;
		}
		return null;
	}

	public static TaSubmissionDueDto buildFromAnnualFilingWithRectification(Cache cache, TaFilingCondition filing, boolean requireRectification, boolean rectificationApproved) {
		TaSubmissionDueDto dto = buildFromAnnualFiling(cache, filing);
		dto.setShortfallAmt(dto.getShortfallAmt());
		dto.setRequireRectification(requireRectification);
		dto.setRectificationApproved(rectificationApproved);
		return dto;
	}

	public static TaSubmissionDueDto buildFromShortfall(Cache cache, TaNetValueShortfall shortfall) {
		if (shortfall != null) {
			TaSubmissionDueDto dto = new TaSubmissionDueDto();
			dto.setTaFilingId(shortfall.getId());
			dto.setType(new ListableDto(Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION, cache.getLabel(cache.getType(Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION), true)));
			dto.setDueDate(shortfall.getExtendedDueDate() == null ? shortfall.getRectificationDueDate() : shortfall.getExtendedDueDate());
			dto.setShortfallAmt(shortfall.getAmount());
			if (shortfall.getTaAaSubmission() != null && shortfall.getTaAaSubmission().getId() != null) {
				dto.setFy(shortfall.getTaAaSubmission().getTaAnnualFiling().getFy());
			}
			if (shortfall.getTaMaSubmission() != null && shortfall.getTaMaSubmission().getId() != null) {
				dto.setFy(shortfall.getTaMaSubmission().getTaFilingCondition().getFy());
			}
			if (shortfall.getTaNetValueRectification() == null) {
				TaSubmissionDueDto.setSubmissionStatus(cache, dto);
			} else {
				dto.setStatus(new ListableDto(shortfall.getTaNetValueRectification().getApplication().getLastAction().getStatus().getCode(),
						shortfall.getTaNetValueRectification().getApplication().getLastAction().getStatus().getOtherLabel()));
			}
			return dto;
		}
		return null;
	}

	public static void setSubmissionStatus(Cache cache, TaSubmissionDueDto dto) {
		if (dto.getDueDate() == null) {
			// default
			dto.setStatus(new ListableDto(cache.getStatus(Codes.Statuses.TA_FILING_PEND_SUBMISSION), true));
		} else {
			if (LocalDate.now().isAfter(dto.getDueDate())) {
				dto.setStatus(new ListableDto(cache.getStatus(Codes.Statuses.TA_FILING_LATE), true));
			} else {
				dto.setStatus(new ListableDto(cache.getStatus(Codes.Statuses.TA_FILING_PEND_SUBMISSION), true));
			}
		}
	}

	public ListableDto getType() {
		return type;
	}

	public void setType(ListableDto type) {
		this.type = type;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public Integer getTaFilingId() {
		return taFilingId;
	}

	public void setTaFilingId(Integer taFilingId) {
		this.taFilingId = taFilingId;
	}

	public void setRequireRectification(boolean requireRectification) {
		this.requireRectification = requireRectification;
	}

	public void setRectificationApproved(boolean rectificationApproved) {
		this.rectificationApproved = rectificationApproved;
	}

	public boolean isRequireRectification() {
		return requireRectification;
	}

	public boolean isRectificationApproved() {
		return rectificationApproved;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public BigDecimal getShortfallAmt() {
		return shortfallAmt;
	}

	public void setShortfallAmt(BigDecimal shortfallAmt) {
		this.shortfallAmt = shortfallAmt;
	}

	public Integer getRectAppId() {
		return rectAppId;
	}

	public void setRectAppId(Integer rectAppId) {
		this.rectAppId = rectAppId;
	}

	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

}
