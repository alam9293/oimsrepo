package gov.stb.tag.dto.dashboard;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.tg.touristguide.TouristGuideDto;
import gov.stb.tag.dto.tg.trainingprovider.TrainingProviderDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.User;

public class TgSideMenuDto {

	private LicenceDto licence;

	private TouristGuideDto touristGuide;

	private TrainingProviderDto trainingProvider;

	private boolean viewRenew;

	private boolean viewReinstate;

	private boolean viewReplace;

	private boolean viewCancel;

	private boolean viewMlpt;

	private String licenceRenewalStatus;

	public TgSideMenuDto(Cache cache, User user, FileHelper fileHelper, LicenceHelper licenceHelper) {
		if (!user.getRoles().isEmpty()) {
			if (Codes.Roles.TP_PUBLIC.equals(user.getRoles().iterator().next().getCode())) {
				this.trainingProvider = new TrainingProviderDto(cache, user.getTgTrainingProvider());
			} else {
				TouristGuide tg = user.getTouristGuide();
				Licence tgLicence = tg.getLicence();

				this.licence = LicenceDto.buildFromLicence(cache, tgLicence);
				this.touristGuide = new TouristGuideDto(cache, tg, fileHelper);
				String renewalStatus = licenceHelper.getLicenceRenewalStatus(user);
				this.licenceRenewalStatus = renewalStatus;

				switch (tgLicence.getStatus().getCode()) {
				case Codes.Statuses.TG_ACTIVE:
					viewRenew = renewalStatus != null ? renewalStatus.equals(Codes.LicenceRenewalStatus.RENEWAL) : false;
					viewReinstate = false;
					viewReplace = true;
					viewCancel = true;
					viewMlpt = true;
					break;
				case Codes.Statuses.TG_INACTIVE:
					viewRenew = false;
					viewReinstate = true;
					viewReplace = false;
					viewCancel = false;
					viewMlpt = false;
					break;
				case Codes.Statuses.TG_CANCELLED:
					viewRenew = false;
					viewReinstate = false;
					viewReplace = false;
					viewCancel = true;
					viewMlpt = false;
					break;
				case Codes.Statuses.TG_REVOKED:
					viewRenew = false;
					viewReinstate = false;
					viewReplace = false;
					viewCancel = false;
					viewMlpt = false;
					break;
				case Codes.Statuses.TG_SUSPENDED:
					viewRenew = false;
					viewReinstate = false;
					viewReplace = false;
					viewCancel = false;
					viewMlpt = false;
					break;
				}
			}
		} else {
			throw new ValidationException("No role has been assigned for you.");
		}
	}

	public LicenceDto getLicence() {
		return licence;
	}

	public void setLicence(LicenceDto licence) {
		this.licence = licence;
	}

	public TouristGuideDto getTouristGuide() {
		return touristGuide;
	}

	public void setTouristGuide(TouristGuideDto touristGuide) {
		this.touristGuide = touristGuide;
	}

	public TrainingProviderDto getTrainingProvider() {
		return trainingProvider;
	}

	public void setTrainingProvider(TrainingProviderDto trainingProvider) {
		this.trainingProvider = trainingProvider;
	}

	public boolean isViewRenew() {
		return viewRenew;
	}

	public void setViewRenew(boolean viewRenew) {
		this.viewRenew = viewRenew;
	}

	public boolean isViewReinstate() {
		return viewReinstate;
	}

	public void setViewReinstate(boolean viewReinstate) {
		this.viewReinstate = viewReinstate;
	}

	public boolean isViewReplace() {
		return viewReplace;
	}

	public void setViewReplace(boolean viewReplace) {
		this.viewReplace = viewReplace;
	}

	public boolean isViewCancel() {
		return viewCancel;
	}

	public void setViewCancel(boolean viewCancel) {
		this.viewCancel = viewCancel;
	}

	public boolean isViewMlpt() {
		return viewMlpt;
	}

	public void setViewMlpt(boolean viewMlpt) {
		this.viewMlpt = viewMlpt;
	}

	public String getLicenceRenewalStatus() {
		return licenceRenewalStatus;
	}

	public void setLicenceRenewalStatus(String licenceRenewalStatus) {
		this.licenceRenewalStatus = licenceRenewalStatus;
	}
}
