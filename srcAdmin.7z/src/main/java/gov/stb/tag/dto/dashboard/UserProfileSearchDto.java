package gov.stb.tag.dto.dashboard;

import java.util.List;

import gov.stb.tag.dto.SearchDto;

public class UserProfileSearchDto extends SearchDto {

	private String loginId;

	private String name;

	private String emailAddress;

	private String taAssigneeChars;

	private Object[] roles;

	private String department;

	private String status;

	List<String> assigneeChars;

	private String module;

	private String function;

	private List<String> moduleList;

	public UserProfileSearchDto() {

	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getTaAssigneeChars() {
		return taAssigneeChars;
	}

	public void setTaAssigneeChars(String taAssigneeChars) {
		this.taAssigneeChars = taAssigneeChars;
	}

	public Object[] getRoles() {
		return roles;
	}

	public void setRoles(Object[] roles) {
		this.roles = roles;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getAssigneeChars() {
		return assigneeChars;
	}

	public void setAssigneeChars(List<String> assigneeChars) {
		this.assigneeChars = assigneeChars;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public List<String> getModuleList() {
		return moduleList;
	}

	public void setModuleList(List<String> moduleList) {
		this.moduleList = moduleList;
	}
}
