package gov.stb.tag.dto.eNets;

public class ENetsReponseMessageDto {

	private String netsMid;

	private String merchantTxnRef;

	private String merchantTxnDtm;

	private String paymentType;

	private String currencyCode;

	private String netsTxnRef;

	private String netsTxnDtm;

	private String paymentMode;

	private String merchantTimeZone;

	private String netsTxnStatus;

	private String netsTxnMsg;

	private String netsAmountDeducted;

	private String maskPan;

	private String bankAuthId;

	private String stageRespCode;

	private String txnRand;

	private String actionCode;

	private String netsMidIndicator;

	public ENetsReponseMessageDto() {
	}

	public String getNetsMid() {
		return netsMid;
	}

	public String getMerchantTxnRef() {
		return merchantTxnRef;
	}

	public String getMerchantTxnDtm() {
		return merchantTxnDtm;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public String getNetsTxnRef() {
		return netsTxnRef;
	}

	public String getNetsTxnDtm() {
		return netsTxnDtm;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public String getMerchantTimeZone() {
		return merchantTimeZone;
	}

	public String getNetsTxnStatus() {
		return netsTxnStatus;
	}

	public String getNetsTxnMsg() {
		return netsTxnMsg;
	}

	public String getNetsAmountDeducted() {
		return netsAmountDeducted;
	}

	public String getMaskPan() {
		return maskPan;
	}

	public String getBankAuthId() {
		return bankAuthId;
	}

	public String getStageRespCode() {
		return stageRespCode;
	}

	public String getTxnRand() {
		return txnRand;
	}

	public String getActionCode() {
		return actionCode;
	}

	public String getNetsMidIndicator() {
		return netsMidIndicator;
	}

	public void setNetsMid(String netsMid) {
		this.netsMid = netsMid;
	}

	public void setMerchantTxnRef(String merchantTxnRef) {
		this.merchantTxnRef = merchantTxnRef;
	}

	public void setMerchantTxnDtm(String merchantTxnDtm) {
		this.merchantTxnDtm = merchantTxnDtm;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public void setNetsTxnRef(String netsTxnRef) {
		this.netsTxnRef = netsTxnRef;
	}

	public void setNetsTxnDtm(String netsTxnDtm) {
		this.netsTxnDtm = netsTxnDtm;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public void setMerchantTimeZone(String merchantTimeZone) {
		this.merchantTimeZone = merchantTimeZone;
	}

	public void setNetsTxnStatus(String netsTxnStatus) {
		this.netsTxnStatus = netsTxnStatus;
	}

	public void setNetsTxnMsg(String netsTxnMsg) {
		this.netsTxnMsg = netsTxnMsg;
	}

	public void setNetsAmountDeducted(String netsAmountDeducted) {
		this.netsAmountDeducted = netsAmountDeducted;
	}

	public void setMaskPan(String maskPan) {
		this.maskPan = maskPan;
	}

	public void setBankAuthId(String bankAuthId) {
		this.bankAuthId = bankAuthId;
	}

	public void setStageRespCode(String stageRespCode) {
		this.stageRespCode = stageRespCode;
	}

	public void setTxnRand(String txnRand) {
		this.txnRand = txnRand;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public void setNetsMidIndicator(String netsMidIndicator) {
		this.netsMidIndicator = netsMidIndicator;
	}
}
