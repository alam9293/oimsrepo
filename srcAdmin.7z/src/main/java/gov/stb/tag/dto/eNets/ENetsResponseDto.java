package gov.stb.tag.dto.eNets;

public class ENetsResponseDto {

	private String ss;

	private ENetsReponseMessageDto msg;

	public ENetsResponseDto() {
	}

	public String getSs() {
		return ss;
	}

	public void setSs(String ss) {
		this.ss = ss;
	}

	public ENetsReponseMessageDto getMsg() {
		return msg;
	}

	public void setMsg(ENetsReponseMessageDto msg) {
		this.msg = msg;
	}
}
