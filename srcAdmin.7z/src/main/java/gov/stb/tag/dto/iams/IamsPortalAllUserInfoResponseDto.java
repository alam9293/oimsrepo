package gov.stb.tag.dto.iams;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IamsPortalAllUserInfoResponseDto {

	private String uri;

	private String display;

	private String longDisplay;

	private IamsPortalValueResponseDto values;

	private IamsPortalDisplayValueResponseDto displayValues;

	public IamsPortalAllUserInfoResponseDto() {
	}

	public String getUri() {
		return uri;
	}

	public String getDisplay() {
		return display;
	}

	public String getLongDisplay() {
		return longDisplay;
	}

	@JsonProperty("values")
	public IamsPortalValueResponseDto getValues() {
		return values;
	}

	@JsonProperty("displayValues")
	public IamsPortalDisplayValueResponseDto getDisplayValues() {
		return displayValues;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	public void setLongDisplay(String longDisplay) {
		this.longDisplay = longDisplay;
	}

	@JsonProperty("values")
	public void setValues(IamsPortalValueResponseDto values) {
		this.values = values;
	}

	@JsonProperty("displayValues")
	public void setDisplayValues(IamsPortalDisplayValueResponseDto displayValues) {
		this.displayValues = displayValues;
	}

}
