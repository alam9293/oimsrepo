package gov.stb.tag.dto.iams;

public class IamsPortalLoginRequestDto {

	private String authString;

	public IamsPortalLoginRequestDto() {
	}

	public String getAuthString() {
		return authString;
	}

	public void setAuthString(String authString) {
		this.authString = authString;
	}

}
