package gov.stb.tag.dto.iams;

public class IamsPortalUserRequestDto {

	private String firstName;

	private String lastName;

	private String centralAccount;

	private String defaultEmailAddress;

	private String contactEmail;

	private String phone;

	private Boolean isExternal;

	private Boolean isInActive;

	public IamsPortalUserRequestDto() {
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getCentralAccount() {
		return centralAccount;
	}

	public String getDefaultEmailAddress() {
		return defaultEmailAddress;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public String getPhone() {
		return phone;
	}

	public Boolean getIsExternal() {
		return isExternal;
	}

	public Boolean getIsInActive() {
		return isInActive;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setCentralAccount(String centralAccount) {
		this.centralAccount = centralAccount;
	}

	public void setDefaultEmailAddress(String defaultEmailAddress) {
		this.defaultEmailAddress = defaultEmailAddress;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setIsExternal(Boolean isExternal) {
		this.isExternal = isExternal;
	}

	public void setIsInActive(Boolean isInActive) {
		this.isInActive = isInActive;
	}

}
