package gov.stb.tag.dto.iams;

public class IamsPortalUserValueRequestDto {

	private IamsPortalUserRequestDto values;

	public IamsPortalUserValueRequestDto() {
	}

	public IamsPortalUserRequestDto getValues() {
		return values;
	}

	public void setValues(IamsPortalUserRequestDto values) {
		this.values = values;
	}

}
