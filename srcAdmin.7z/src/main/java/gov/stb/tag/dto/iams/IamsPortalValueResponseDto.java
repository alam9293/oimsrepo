package gov.stb.tag.dto.iams;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IamsPortalValueResponseDto {

	private String centralAccount;

	private String internalName;

	private String uidPerson;

	private String xMarkedForDeletion;

	public IamsPortalValueResponseDto() {
	}

	@JsonProperty("CentralAccount")
	public String getCentralAccount() {
		return centralAccount;
	}

	@JsonProperty("InternalName")
	public String getInternalName() {
		return internalName;
	}

	@JsonProperty("UID_Person")
	public String getUidPerson() {
		return uidPerson;
	}

	@JsonProperty("XMarkedForDeletion")
	public String getxMarkedForDeletion() {
		return xMarkedForDeletion;
	}

	@JsonProperty("CentralAccount")
	public void setCentralAccount(String centralAccount) {
		this.centralAccount = centralAccount;
	}

	@JsonProperty("InternalName")
	public void setInternalName(String internalName) {
		this.internalName = internalName;
	}

	@JsonProperty("UID_Person")
	public void setUidPerson(String uidPerson) {
		this.uidPerson = uidPerson;
	}

	@JsonProperty("XMarkedForDeletion")
	public void setxMarkedForDeletion(String xMarkedForDeletion) {
		this.xMarkedForDeletion = xMarkedForDeletion;
	}

}
