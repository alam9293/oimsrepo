package gov.stb.tag.dto.iams;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.model.Role;

public class IamsRoleDto {

	@MapProjection(path = "code")
	private String code;

	@MapProjection(path = "label")
	private String name;

	public IamsRoleDto() {

	}

	public IamsRoleDto(Role role) {
		this.code = role.getCode();
		this.name = role.getLabel();
	}

	public String getCode() { return code; }

	public void setCode(String code) { this.code = code; }

	public String getName() { return name; }

	public void setName(String name) { this.name = name; }
}
