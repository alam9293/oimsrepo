package gov.stb.tag.dto.iams;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.model.User;

import java.time.LocalDateTime;

public class IamsUserDto {

	@MapProjection(path = "loginId")
	private String loginId;

	@MapProjection(path = "emailAddress")
	private String emailAddress;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "department.code")
	private String departmentCode;

	@MapProjection(path = "lastLoginDate")
	private LocalDateTime lastLoginDate;

	@MapProjection(path = "status.code")
	private String statusCode;

	@MapProjection(path = "type.code")
	private String typeCode;

	public IamsUserDto() {

	}

	public IamsUserDto(User user) {
		this.loginId = user.getLoginId();
		this.emailAddress = user.getEmailAddress();
		this.name = user.getName();
		this.departmentCode = user.getDepartment().getCode();
		this.lastLoginDate = user.getLastLoginDate();
		this.statusCode = user.getStatus().getCode();
		this.typeCode = user.getType().getCode();
	}

	public String getLoginId() { return loginId; }

	public void setLoginId(String loginId) { this.loginId = loginId; }

	public String getEmailAddress() { return emailAddress; }

	public void setEmailAddress(String emailAddress) { this.emailAddress = emailAddress; }

	public String getName() { return name; }

	public void setName(String name) { this.name = name; }

	public LocalDateTime getLastLoginDate() { return lastLoginDate; }

	public void setLastLoginDate(LocalDateTime lastLoginDate) { this.lastLoginDate = lastLoginDate; }

	public String getDepartmentCode() { return departmentCode; }

	public void setDepartmentCode(String departmentCode) { this.departmentCode = departmentCode; }

	public String getStatusCode() { return statusCode; }

	public void setStatusCode(String statusCode) { this.statusCode = statusCode; }

	public String getTypeCode() { return typeCode; }

	public void setTypeCode(String typeCode) { this.typeCode = typeCode; }
}
