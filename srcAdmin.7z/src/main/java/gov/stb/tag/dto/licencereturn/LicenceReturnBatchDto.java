package gov.stb.tag.dto.licencereturn;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.licence.TaLicenceDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.LicenceReturn;
import gov.stb.tag.model.LicenceReturnBatch;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LicenceReturnBatchDto extends TaLicenceDto {

	private Integer id;

	private LocalDate dueDate;

	private ListableDto status;

	private ListableDto type;

	private Integer appId;

	private List<LicenceReturnDto> licences = new ArrayList<>();

	private List<FileDto> supportingDocs;

	public static LicenceReturnBatchDto build(Cache cache, LicenceReturnBatch lrb, FileHelper fileHelper) {
		LicenceReturnBatchDto dto = new LicenceReturnBatchDto();
		dto = dto.buildFromLicence(cache, lrb.getLicence(), dto);
		dto.setId(lrb.getId());
		dto.setDueDate(lrb.getDueDate());
		dto.setStatus(new ListableDto(lrb.getStatus().getKey(), cache.getLabel(lrb.getStatus(), false)));
		for (LicenceReturn lr : lrb.getLicences()) {
			dto.getLicences().add(LicenceReturnDto.build(cache, lr));
		}
		dto.setType(new ListableDto(lrb.getType().getKey(), cache.getLabel(lrb.getType(), false)));
		dto.setAppId(lrb.getApplication() != null ? lrb.getApplication().getId() : null);

		if (lrb.getSupportingDocs() != null) {
			List<File> files = new ArrayList<>(lrb.getSupportingDocs());
			List<FileDto> supportingDocs = new ArrayList<FileDto>();
			if (files.size() > 0) {
				for (File file : files) {
					if (!file.getIsDeleted()) {
						supportingDocs.add(FileDto.buildFromFile(file, cache.getType(Codes.TaDocumentTypes.TA_DOC_OTHERS), fileHelper));

					}
				}
				dto.setSupportingDocs(supportingDocs);
			}

		}

		return dto;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public List<LicenceReturnDto> getLicences() {
		return licences;
	}

	public void setLicences(List<LicenceReturnDto> licences) {
		this.licences = licences;
	}

	public ListableDto getType() {
		return type;
	}

	public void setType(ListableDto type) {
		this.type = type;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public List<FileDto> getSupportingDocs() {
		return supportingDocs;
	}

	public void setSupportingDocs(List<FileDto> supportingDocs) {
		this.supportingDocs = supportingDocs;
	}

}
