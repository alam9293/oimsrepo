package gov.stb.tag.dto.licencereturn;

import java.time.LocalDate;

import gov.stb.tag.dto.SearchDto;

public class LicenceReturnBatchSearchDto extends SearchDto {

	private String name;
	private String licenceNo;
	private LocalDate deadlineFrom;
	private LocalDate deadlineTo;
	private String uen;
	private String status;

	private Boolean allRecords;

	public Boolean getAllRecords() {
		return allRecords;
	}

	public void setAllRecords(Boolean allRecords) {
		this.allRecords = allRecords;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public LocalDate getDeadlineFrom() {
		return deadlineFrom;
	}

	public void setDeadlineFrom(LocalDate deadlineFrom) {
		this.deadlineFrom = deadlineFrom;
	}

	public LocalDate getDeadlineTo() {
		return deadlineTo;
	}

	public void setDeadlineTo(LocalDate deadlineTo) {
		this.deadlineTo = deadlineTo;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
