package gov.stb.tag.dto.licencereturn;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.LicenceReturn;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LicenceReturnDto extends EntityDto {

	private Integer id;
	private String address;
	private String status;
	private String type;
	private LocalDate returnedDate;

	public static LicenceReturnDto build(Cache cache, LicenceReturn lr) {
		LicenceReturnDto dto = new LicenceReturnDto();
		dto.setAddress(lr.getBranch() != null ? lr.getBranch().getAddress().getAddressDisplay() : lr.getLicence().getTravelAgent().getOperatingAddress().getAddressDisplay());
		dto.setId(lr.getId());
		dto.setStatus(lr.getReturnedDate() == null ? "Not Returned" : "Returned");
		dto.setReturnedDate(lr.getReturnedDate());
		dto.setType(lr.getBranch() != null ? "Branch" : "Main");
		return dto;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public LocalDate getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(LocalDate returnedDate) {
		this.returnedDate = returnedDate;
	}

}
