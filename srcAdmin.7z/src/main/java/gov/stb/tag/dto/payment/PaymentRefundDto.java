package gov.stb.tag.dto.payment;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.PaymentRefund;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.WorkflowStepAssignment;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentRefundDto extends ApprovalDto {

	private Integer id;
	private String payerName;
	private String billRefNo;
	private BigDecimal refundAmount;
	private String bankAccountNo;

	private String payReqRefNo;
	private String payReqType;
	private String payReqTypeCode;

	private ListableDto status;
	private LocalDate createdDate;
	private Integer workflowId;
	private String assignedOfficer;

	public PaymentRefundDto() {

	}

	public static PaymentRefundDto buildFromPaymentRefund(CacheHelper cache, PaymentRefund refund, PaymentRequest payReq) {
		PaymentRefundDto dto = new PaymentRefundDto();
		dto.setId(refund.getId());
		dto.setPayerName(refund.getPayerName());
		dto.setBillRefNo(refund.getBillRefNo());
		dto.setRefundAmount(refund.getRefundAmount());
		dto.setBankAccountNo(refund.getBankAccountNo());
		dto.setStatus(new ListableDto(refund.getWorkflow().getLastAction().getStatus()));
		dto.setCreatedDate(refund.getCreatedDate().toLocalDate());
		dto.setWorkflowId(refund.getWorkflow().getId());
		for (WorkflowStepAssignment wsa : refund.getWorkflow().getWorkflowStepAssignments()) {
			if (wsa.getWorkflowStep().getStartStatus().getCode().equals(Codes.Statuses.PAY_WKFLW_PEND_APPR)) {
				dto.setAssignedOfficer(wsa.getUser().getName());
			}
		}
		dto.setPayReqRefNo(payReq.getRefNo());
		dto.setPayReqType(cache.getLabel(payReq.getType(), false));
		return dto;
	}

	public static PaymentRefundDto buildFromPaymentRequest(CacheHelper cache, PaymentRequest payReq) {
		PaymentRefundDto dto = new PaymentRefundDto();
		dto.setPayerName(payReq.getPayerName());
		dto.setBillRefNo(payReq.getBillRefNo());
		dto.setRefundAmount(payReq.getPayableAmount());
		dto.setPayReqRefNo(payReq.getRefNo());
		dto.setPayReqType(cache.getLabel(payReq.getType(), false));
		dto.setPayReqTypeCode(payReq.getType().getCode());
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public String getPayReqRefNo() {
		return payReqRefNo;
	}

	public void setPayReqRefNo(String payReqRefNo) {
		this.payReqRefNo = payReqRefNo;
	}

	public String getPayReqType() {
		return payReqType;
	}

	public void setPayReqType(String payReqType) {
		this.payReqType = payReqType;
	}

	public String getPayReqTypeCode() {
		return payReqTypeCode;
	}

	public void setPayReqTypeCode(String payReqTypeCode) {
		this.payReqTypeCode = payReqTypeCode;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

}
