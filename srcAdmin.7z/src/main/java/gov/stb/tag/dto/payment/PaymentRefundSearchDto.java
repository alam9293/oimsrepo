package gov.stb.tag.dto.payment;

import java.math.BigDecimal;

import gov.stb.tag.dto.SearchDto;

public class PaymentRefundSearchDto extends SearchDto {

	private String billRefNo;
	private String payerName;
	private BigDecimal refundAmount;
	private String statusCode;
	private Boolean allRecords;

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public Boolean getAllRecords() {
		return allRecords;
	}

	public void setAllRecords(Boolean allRecords) {
		this.allRecords = allRecords;
	}

}
