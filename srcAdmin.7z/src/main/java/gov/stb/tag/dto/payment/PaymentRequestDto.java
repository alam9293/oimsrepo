package gov.stb.tag.dto.payment;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentStatusSpan;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentRequestDto extends EntityDto {

	private Integer id;
	private Integer version;
	private String billRefNo;
	private String refNo;
	private String payerUinUen;
	private String payerName;
	private Boolean isPayerCompany;
	private String description;
	private BigDecimal payableAmount;
	private String type;
	private String typeCode;
	private String status;
	private String statusCode;
	private String remarks;
	private String userField2;
	private PaymentTxnDto lastTxn;
	private List<PaymentTxnDto> paymentTxns = new ArrayList<>();
	private List<PaymentStatusSpanDto> paymentStatusSpan = new ArrayList<>();
	private Boolean hasRefund;

	public PaymentRequestDto() {

	}

	public PaymentRequestDto(CacheHelper cache, PaymentRequest paymentRequest, boolean toLoadAllTxns) {
		if (paymentRequest != null) {
			this.id = paymentRequest.getId();
			this.version = paymentRequest.getVersion();
			this.billRefNo = paymentRequest.getBillRefNo();
			this.refNo = paymentRequest.getRefNo();
			this.payerUinUen = paymentRequest.getPayerUinUen();
			this.payerName = paymentRequest.getPayerName();
			this.description = paymentRequest.getDescription();
			this.payableAmount = paymentRequest.getPayableAmount();
			this.type = cache.getLabel(paymentRequest.getType(), true);
			this.typeCode = paymentRequest.getType().getCode();
			this.status = cache.getLabel(paymentRequest.getStatus(), true);
			this.statusCode = paymentRequest.getStatus().getCode();
			this.remarks = paymentRequest.getRemarks();
			this.userField2 = paymentRequest.getUserField2();
			this.isPayerCompany = paymentRequest.isPayerCompany();
			if (toLoadAllTxns) {
				paymentRequest.getPaymentTxns().forEach(o -> {
					this.paymentTxns.add(new PaymentTxnDto(cache, o));
				});
				paymentTxns.sort(Comparator.comparing(PaymentTxnDto::getTxnDate).reversed());
				lastTxn = new PaymentTxnDto(cache, paymentRequest.getLastTxn());
			} else {
				lastTxn = new PaymentTxnDto(cache, paymentRequest.getLastTxn());
			}
		}
	}

	public PaymentRequestDto buildPaymentStatusSpan(CacheHelper cache, PaymentRequestDto dto, List<PaymentStatusSpan> results) {
		if (results != null && dto != null) {
			results.stream().forEach(u -> {
				PaymentStatusSpanDto statusSpanDto = new PaymentStatusSpanDto();
				statusSpanDto = PaymentStatusSpanDto.buildFromPaymentStatusSpan(u, cache);
				dto.getPaymentStatusSpan().add(statusSpanDto);
			});
		}
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getPayerUinUen() {
		return payerUinUen;
	}

	public void setPayerUinUen(String payerUinUen) {
		this.payerUinUen = payerUinUen;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public Boolean getIsPayerCompany() {
		return isPayerCompany;
	}

	public void setIsPayerCompany(Boolean isPayerCompany) {
		this.isPayerCompany = isPayerCompany;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(BigDecimal payableAmount) {
		this.payableAmount = payableAmount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getUserField2() {
		return userField2;
	}

	public void setUserField2(String userField2) {
		this.userField2 = userField2;
	}

	public PaymentTxnDto getLastTxn() {
		return lastTxn;
	}

	public void setLastTxn(PaymentTxnDto lastTxn) {
		this.lastTxn = lastTxn;
	}

	public List<PaymentTxnDto> getPaymentTxns() {
		return paymentTxns;
	}

	public void setPaymentTxns(List<PaymentTxnDto> paymentTxns) {
		this.paymentTxns = paymentTxns;
	}

	public Boolean getHasRefund() {
		return hasRefund;
	}

	public void setHasRefund(Boolean hasRefund) {
		this.hasRefund = hasRefund;
	}

	@Override
	public String getEntityName() {
		return PaymentRequest.class.getSimpleName();
	}

	@Override
	public String getEntityId() {
		return id != null ? id.toString() : null;
	}

	public List<PaymentStatusSpanDto> getPaymentStatusSpan() {
		return paymentStatusSpan;
	}

	public void setPaymentStatusSpan(List<PaymentStatusSpanDto> paymentStatusSpan) {
		this.paymentStatusSpan = paymentStatusSpan;
	}

}
