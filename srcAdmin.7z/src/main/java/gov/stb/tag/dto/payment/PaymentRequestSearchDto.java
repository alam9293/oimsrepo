package gov.stb.tag.dto.payment;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import gov.stb.tag.dto.SearchDto;

public class PaymentRequestSearchDto extends SearchDto {

	private String billRefNo;
	private String refNo;
	private String payerUinUen;
	private String payerName;
	private BigDecimal payableAmount;
	private String typeCode;
	private String statusCode;
	private String lastTxnStatusCode;
	private Integer paymentTxnId;
	private LocalDateTime txnDateFrom;
	private LocalDateTime txnDateTo;
	private String paymentType;

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getPayerUinUen() {
		return payerUinUen;
	}

	public void setPayerUinUen(String payerUinUen) {
		this.payerUinUen = payerUinUen;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public BigDecimal getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(BigDecimal payableAmount) {
		this.payableAmount = payableAmount;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getLastTxnStatusCode() {
		return lastTxnStatusCode;
	}

	public void setLastTxnStatusCode(String lastTxnStatusCode) {
		this.lastTxnStatusCode = lastTxnStatusCode;
	}

	public Integer getPaymentTxnId() {
		return paymentTxnId;
	}

	public void setPaymentTxnId(Integer paymentTxnId) {
		this.paymentTxnId = paymentTxnId;
	}

	public LocalDateTime getTxnDateFrom() {
		return txnDateFrom;
	}

	public void setTxnDateFrom(LocalDateTime txnDateFrom) {
		this.txnDateFrom = txnDateFrom;
	}

	public LocalDateTime getTxnDateTo() {
		return txnDateTo;
	}

	public void setTxnDateTo(LocalDateTime txnDateTo) {
		this.txnDateTo = txnDateTo;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
}
