package gov.stb.tag.dto.payment;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.File;
import gov.stb.tag.model.PaymentStatusSpan;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentStatusSpanDto extends ApprovalDto {

	private Integer id;
	private List<Integer> ids;
	private ListableDto status;
	private LocalDateTime createdDate;
	private String createdBy;
	private List<FileDto> supportDocs;

	public PaymentStatusSpanDto() {

	}

	public static PaymentStatusSpanDto buildFromPaymentStatusSpan(PaymentStatusSpan pss, Cache cahce) {
		PaymentStatusSpanDto dto = new PaymentStatusSpanDto();
		dto.setInternalRemarks(pss.getInternalRemarks());
		dto.setStatus(new ListableDto(pss.getStatus()));
		dto.setId(pss.getId());
		dto.setCreatedBy(pss.getCreatedBy());
		dto.setCreatedDate(pss.getCreatedDate());
		List<FileDto> suppDocs = new ArrayList<FileDto>();
		for (File file : pss.getFiles()) {
			suppDocs.add(FileDto.buildFromFile(file, null, null));
		}
		dto.setSupportDocs(suppDocs);
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<FileDto> getSupportDocs() {
		return supportDocs;
	}

	public void setSupportDocs(List<FileDto> supportDocs) {
		this.supportDocs = supportDocs;
	}

}
