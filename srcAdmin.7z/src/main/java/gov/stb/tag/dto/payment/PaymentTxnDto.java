package gov.stb.tag.dto.payment;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.PaymentTxn;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentTxnDto extends EntityDto {

	private Integer id;
	private BigDecimal amount;
	private String status;
	private String statusCode;
	private String paymentType;
	private String paymentTypeCode;
	private LocalDateTime validityDate;
	private LocalDateTime txnDate;
	private String remarks;
	private String errorMsg;
	private String resultantStatusCode;

	private String billRefNos = "";
	private String payReqTypes = "";
	private List<ListableDto> payReqs;
	private List<PaymentRequestItemDto> payReqItems;

	private String continueUrl;

	public PaymentTxnDto() {

	}

	public PaymentTxnDto(CacheHelper cache, PaymentTxn paymentTxn) {
		if (paymentTxn != null) {
			this.id = paymentTxn.getId();
			this.amount = paymentTxn.getAmount();
			this.status = cache.getLabel(paymentTxn.getStatus(), true);
			this.statusCode = paymentTxn.getStatus().getCode();
			this.paymentType = cache.getLabel(paymentTxn.getPaymentType(), true);
			this.paymentTypeCode = paymentTxn.getPaymentType().getCode();
			this.validityDate = paymentTxn.getValidityDate();
			this.txnDate = paymentTxn.getTxnDate();
			this.remarks = paymentTxn.getRemarks();
			this.errorMsg = paymentTxn.getErrorMsg();

		}
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentTypeCode() {
		return paymentTypeCode;
	}

	public void setPaymentTypeCode(String paymentTypeCode) {
		this.paymentTypeCode = paymentTypeCode;
	}

	public LocalDateTime getValidityDate() {
		return validityDate;
	}

	public void setValidityDate(LocalDateTime validityDate) {
		this.validityDate = validityDate;
	}

	public LocalDateTime getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(LocalDateTime txnDate) {
		this.txnDate = txnDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getResultantStatusCode() {
		return resultantStatusCode;
	}

	public void setResultantStatusCode(String resultantStatusCode) {
		this.resultantStatusCode = resultantStatusCode;
	}

	public String getBillRefNos() {
		return billRefNos;
	}

	public void setBillRefNos(String billRefNos) {
		this.billRefNos = billRefNos;
	}

	public String getPayReqTypes() {
		return payReqTypes;
	}

	public void setPayReqTypes(String payReqTypes) {
		this.payReqTypes = payReqTypes;
	}

	public List<ListableDto> getPayReqs() {
		return payReqs;
	}

	public void setPayReqs(List<ListableDto> payReqs) {
		this.payReqs = payReqs;
	}

	public List<PaymentRequestItemDto> getPayReqItems() {
		return payReqItems;
	}

	public void setPayReqItems(List<PaymentRequestItemDto> payReqItems) {
		this.payReqItems = payReqItems;
	}

	public String getContinueUrl() {
		return continueUrl;
	}

	public void setContinueUrl(String continueUrl) {
		this.continueUrl = continueUrl;
	}
}
