package gov.stb.tag.dto.paynow;

public class TxnInfoDto {

	private String txnType;

	private String customerReference;

	private String txnRefId;

	private String txnDate;

	private String valueDt;

	private ReceivingPartyDto receivingParty;

	private AmtDtlsDto amtDtls;

	private SenderPartyDto senderParty;

	private RmtInfDto rmtInf;

	public TxnInfoDto() {
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getCustomerReference() {
		return customerReference;
	}

	public void setCustomerReference(String customerReference) {
		this.customerReference = customerReference;
	}

	public String getTxnRefId() {
		return txnRefId;
	}

	public void setTxnRefId(String txnRefId) {
		this.txnRefId = txnRefId;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	public String getValueDt() {
		return valueDt;
	}

	public void setValueDt(String valueDt) {
		this.valueDt = valueDt;
	}

	public ReceivingPartyDto getReceivingParty() {
		return receivingParty;
	}

	public void setReceivingParty(ReceivingPartyDto receivingParty) {
		this.receivingParty = receivingParty;
	}

	public AmtDtlsDto getAmtDtls() {
		return amtDtls;
	}

	public void setAmtDtls(AmtDtlsDto amtDtls) {
		this.amtDtls = amtDtls;
	}

	public SenderPartyDto getSenderParty() {
		return senderParty;
	}

	public void setSenderParty(SenderPartyDto senderParty) {
		this.senderParty = senderParty;
	}

	public RmtInfDto getRmtInf() {
		return rmtInf;
	}

	public void setRmtInf(RmtInfDto rmtInf) {
		this.rmtInf = rmtInf;
	}

}
