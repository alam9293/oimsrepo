package gov.stb.tag.dto.report;

public class ReportDto {

	private String reportName;

	private String fileName;

	public ReportDto() {

	}

	public ReportDto(String reportName, String fileName) {
		super();
		this.reportName = reportName;
		this.fileName = fileName;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
