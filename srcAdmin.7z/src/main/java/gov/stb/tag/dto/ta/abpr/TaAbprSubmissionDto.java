package gov.stb.tag.dto.ta.abpr;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.jackson.BigDecimalToMoneyThousandSeparatorConverter;
import gov.stb.tag.jackson.IntegerToValueThousandSeparatorConverter;
import gov.stb.tag.jackson.MoneyThousandSeparatorToBigDecimalConverter;
import gov.stb.tag.jackson.ValueThousandSeparatorToIntegerConverter;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaBusinessOperation;
import gov.stb.tag.model.TaFocusArea;
import gov.stb.tag.model.TaFunctionActivity;
import gov.stb.tag.model.TaSpecializedMarket;
import gov.stb.tag.model.Type;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaAbprSubmissionDto extends TaApplicationDto {

	private Integer abprSubmissionId;

	private Boolean isNilSubmission;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal inboundOp;
	private BigDecimal inboundOpPercent;
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal outboundOp;
	private BigDecimal outboundOpPercent;
	@JsonDeserialize(converter = ValueThousandSeparatorToIntegerConverter.class)
	@JsonSerialize(converter = IntegerToValueThousandSeparatorConverter.class)
	private Integer inboundGrpPax;
	private BigDecimal inboundGrpPaxPercent;
	@JsonDeserialize(converter = ValueThousandSeparatorToIntegerConverter.class)
	@JsonSerialize(converter = IntegerToValueThousandSeparatorConverter.class)
	private Integer outboundGrpPax;
	private BigDecimal outboundGrpPaxPercent;
	@JsonDeserialize(converter = ValueThousandSeparatorToIntegerConverter.class)
	@JsonSerialize(converter = IntegerToValueThousandSeparatorConverter.class)
	private Integer inboundFitPax;
	private BigDecimal inboundFitPaxPercent;
	@JsonDeserialize(converter = ValueThousandSeparatorToIntegerConverter.class)
	@JsonSerialize(converter = IntegerToValueThousandSeparatorConverter.class)
	private Integer outboundFitPax;
	private BigDecimal outboundFitPaxPercent;
	@JsonDeserialize(converter = ValueThousandSeparatorToIntegerConverter.class)
	@JsonSerialize(converter = IntegerToValueThousandSeparatorConverter.class)
	private Integer noOfEmployee;
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal operatingCost;
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal depreciation;
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal remuneration;
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal indirectTax;
	private Boolean hasOverseasBranch;

	private BigDecimal inboundBusinessTotalAmount;
	private BigDecimal outboundBusinessTotalAmount;
	private BigDecimal inboundOutboundBusinessTotalAmount;

	@JsonDeserialize(converter = ValueThousandSeparatorToIntegerConverter.class)
	@JsonSerialize(converter = IntegerToValueThousandSeparatorConverter.class)
	private Integer totalInboundFitGrpPax;
	@JsonDeserialize(converter = ValueThousandSeparatorToIntegerConverter.class)
	@JsonSerialize(converter = IntegerToValueThousandSeparatorConverter.class)
	private Integer totalOutboundFitGrpPax;

	private List<TaMarketSpecializationDto> inboundRows = new ArrayList<>();
	private List<TaMarketSpecializationDto> outboundRows = new ArrayList<>();
	private List<TaBusinessOperationDto> businessRows = new ArrayList<>();
	private List<TaAreaOfFocusDto> focusRows = new ArrayList<>();
	private List<TaAreaOfFocusDto> otherFocusRows = new ArrayList<>();

	private List<TaFunctionActivityDto> functionRows = new ArrayList<>();
	private TaAnnualFilingDto taLicenceAnnualFilingDto = new TaAnnualFilingDto();
	private boolean hasAbprToSubmit = true;

	public static TaAbprSubmissionDto buildFromApplication(CacheHelper cache, ApplicationHelper appHelper, TaAbprSubmission taAbprSubmission, Boolean loadNewFunctionalActivities) {
		TaAbprSubmissionDto taAbprSubmissionDto = new TaAbprSubmissionDto();
		taAbprSubmissionDto = taAbprSubmissionDto.buildFromApplication(cache, appHelper, taAbprSubmission.getApplication(), taAbprSubmissionDto);
		taAbprSubmissionDto.setAbprSubmissionId(taAbprSubmission.getId());
		taAbprSubmissionDto.setIsNilSubmission(taAbprSubmission.getIsNilSubmission());

		taAbprSubmissionDto.setInboundOp(taAbprSubmission.getInboundOp());
		taAbprSubmissionDto.setOutboundOp(taAbprSubmission.getOutboundOp());
		taAbprSubmissionDto.setInboundOpPercent(taAbprSubmission.getInboundOpPercent());
		taAbprSubmissionDto.setOutboundOpPercent(taAbprSubmission.getOutboundOpPercent());

		taAbprSubmissionDto.setInboundFitPax(taAbprSubmission.getInboundFitPax());
		taAbprSubmissionDto.setInboundGrpPax(taAbprSubmission.getInboundGrpPax());
		taAbprSubmissionDto.setOutboundFitPax(taAbprSubmission.getOutboundFitPax());
		taAbprSubmissionDto.setOutboundGrpPax(taAbprSubmission.getOutboundGrpPax());
		taAbprSubmissionDto.setInboundFitPaxPercent(taAbprSubmission.getInboundFitPaxPercent());
		taAbprSubmissionDto.setOutboundFitPaxPercent(taAbprSubmission.getOutboundFitPaxPercent());
		taAbprSubmissionDto.setInboundGrpPaxPercent(taAbprSubmission.getInboundGrpPaxPercent());
		taAbprSubmissionDto.setOutboundGrpPaxPercent(taAbprSubmission.getOutboundGrpPaxPercent());

		taAbprSubmissionDto.setNoOfEmployee(taAbprSubmission.getNoOfEmployee());
		taAbprSubmissionDto.setOperatingCost(taAbprSubmission.getOperatingCost());
		taAbprSubmissionDto.setDepreciation(taAbprSubmission.getDepreciation());
		taAbprSubmissionDto.setRemuneration(taAbprSubmission.getRemuneration());
		taAbprSubmissionDto.setIndirectTax(taAbprSubmission.getIndirectTax());
		taAbprSubmissionDto.setHasOverseasBranch(taAbprSubmission.hasOverseasBranch());

		for (TaSpecializedMarket ms : taAbprSubmission.getTaSpecializedMarkets()) {
			if (ms.getIsInbound()) {
				taAbprSubmissionDto.getInboundRows().add(TaMarketSpecializationDto.buildFromMS(cache, ms));
			} else {
				taAbprSubmissionDto.getOutboundRows().add(TaMarketSpecializationDto.buildFromMS(cache, ms));
			}
		}
		for (TaBusinessOperation bo : taAbprSubmission.getTaBusinessOperations()) {
			taAbprSubmissionDto.getBusinessRows().add(TaBusinessOperationDto.buildFromBO(cache, bo));

		}
		for (TaFocusArea aof : taAbprSubmission.getTaFocusAreas()) {
			if (aof.getFocusArea() != null && aof.getOtherFocusArea() == null) {
				taAbprSubmissionDto.getFocusRows().add(TaAreaOfFocusDto.buildFromFA(cache, aof));
			}

		}
		for (TaFocusArea aof : taAbprSubmission.getTaFocusAreas()) {
			if (aof.getFocusArea() == null && aof.getOtherFocusArea() != null) {
				taAbprSubmissionDto.getOtherFocusRows().add(TaAreaOfFocusDto.buildFromFA(cache, aof));
			}

		}
		for (TaFunctionActivity fa : taAbprSubmission.getTaFunctionActivities()) {
			// if (aof.get == null && aof.getOtherFocusArea() != null) {
			taAbprSubmissionDto.getFunctionRows().add(TaFunctionActivityDto.buildFromFA(cache, fa));
			// }

		}
		if (loadNewFunctionalActivities && taAbprSubmission.getIsNilSubmission() && taAbprSubmission.getApplication().getLastAction().getStatus().getCode().equals(Codes.Statuses.TA_APP_RFA)) {
			List<TaFunctionActivityDto> functionActivities = new ArrayList<TaFunctionActivityDto>();
			for (Type type : cache.getTaFunctionActivity()) {
				TaFunctionActivityDto a = new TaFunctionActivityDto();
				a.setQuestion(new ListableDto(type.getKey(), type.getLabel()));
				functionActivities.add(a);
			}
			taAbprSubmissionDto.setFunctionRows(functionActivities);
		}

		taAbprSubmissionDto.setInboundBusinessTotalAmount(taAbprSubmissionDto.getInboundOp());
		taAbprSubmissionDto.setOutboundBusinessTotalAmount(taAbprSubmissionDto.getOutboundOp());
		taAbprSubmissionDto.setInboundOutboundBusinessTotalAmount(taAbprSubmissionDto.getInboundOp().add(taAbprSubmissionDto.getOutboundOp()));

		taAbprSubmissionDto.setTotalInboundFitGrpPax(taAbprSubmissionDto.getInboundFitPax() + taAbprSubmissionDto.getInboundGrpPax());
		taAbprSubmissionDto.setTotalOutboundFitGrpPax(taAbprSubmissionDto.getOutboundFitPax() + taAbprSubmissionDto.getOutboundGrpPax());

		taAbprSubmissionDto.setTaLicenceAnnualFilingDto(TaAnnualFilingDto.build(taAbprSubmission.getTaAnnualFiling()));
		return taAbprSubmissionDto;
	}

	public Integer getAbprSubmissionId() {
		return abprSubmissionId;
	}

	public void setAbprSubmissionId(Integer abprSubmissionId) {
		this.abprSubmissionId = abprSubmissionId;
	}

	public boolean isHasAbprToSubmit() {
		return hasAbprToSubmit;
	}

	public void setHasAbprToSubmit(boolean hasAbprToSubmit) {
		this.hasAbprToSubmit = hasAbprToSubmit;
	}

	public List<TaMarketSpecializationDto> getInboundRows() {
		return inboundRows;
	}

	public void setInboundRows(List<TaMarketSpecializationDto> inboundRows) {
		this.inboundRows = inboundRows;
	}

	public List<TaMarketSpecializationDto> getOutboundRows() {
		return outboundRows;
	}

	public void setOutboundRows(List<TaMarketSpecializationDto> outboundRows) {
		this.outboundRows = outboundRows;
	}

	public List<TaBusinessOperationDto> getBusinessRows() {
		return businessRows;
	}

	public void setBusinessRows(List<TaBusinessOperationDto> businessRows) {
		this.businessRows = businessRows;
	}

	public List<TaAreaOfFocusDto> getFocusRows() {
		return focusRows;
	}

	public void setFocusRows(List<TaAreaOfFocusDto> focusRows) {
		this.focusRows = focusRows;
	}

	public TaAnnualFilingDto getTaLicenceAnnualFilingDto() {
		return taLicenceAnnualFilingDto;
	}

	public void setTaLicenceAnnualFilingDto(TaAnnualFilingDto taLicenceAnnualFilingDto) {
		this.taLicenceAnnualFilingDto = taLicenceAnnualFilingDto;
	}

	public List<TaFunctionActivityDto> getFunctionRows() {
		return functionRows;
	}

	public void setFunctionRows(List<TaFunctionActivityDto> functionRows) {
		this.functionRows = functionRows;
	}

	public Integer getInboundGrpPax() {
		return inboundGrpPax;
	}

	public void setInboundGrpPax(Integer inboundGrpPax) {
		this.inboundGrpPax = inboundGrpPax;
	}

	public BigDecimal getInboundGrpPaxPercent() {
		return inboundGrpPaxPercent;
	}

	public void setInboundGrpPaxPercent(BigDecimal inboundGrpPaxPercent) {
		this.inboundGrpPaxPercent = inboundGrpPaxPercent;
	}

	public Integer getOutboundGrpPax() {
		return outboundGrpPax;
	}

	public void setOutboundGrpPax(Integer outboundGrpPax) {
		this.outboundGrpPax = outboundGrpPax;
	}

	public BigDecimal getOutboundGrpPaxPercent() {
		return outboundGrpPaxPercent;
	}

	public void setOutboundGrpPaxPercent(BigDecimal outboundGrpPaxPercent) {
		this.outboundGrpPaxPercent = outboundGrpPaxPercent;
	}

	public Integer getInboundFitPax() {
		return inboundFitPax;
	}

	public void setInboundFitPax(Integer inboundFitPax) {
		this.inboundFitPax = inboundFitPax;
	}

	public BigDecimal getInboundFitPaxPercent() {
		return inboundFitPaxPercent;
	}

	public void setInboundFitPaxPercent(BigDecimal inboundFitPaxPercent) {
		this.inboundFitPaxPercent = inboundFitPaxPercent;
	}

	public Integer getOutboundFitPax() {
		return outboundFitPax;
	}

	public void setOutboundFitPax(Integer outboundFitPax) {
		this.outboundFitPax = outboundFitPax;
	}

	public BigDecimal getOutboundFitPaxPercent() {
		return outboundFitPaxPercent;
	}

	public void setOutboundFitPaxPercent(BigDecimal outboundFitPaxPercent) {
		this.outboundFitPaxPercent = outboundFitPaxPercent;
	}

	public Integer getNoOfEmployee() {
		return noOfEmployee;
	}

	public void setNoOfEmployee(Integer noOfEmployee) {
		this.noOfEmployee = noOfEmployee;
	}

	public BigDecimal getOperatingCost() {
		return operatingCost;
	}

	public void setOperatingCost(BigDecimal operatingCost) {
		this.operatingCost = operatingCost;
	}

	public BigDecimal getDepreciation() {
		return depreciation;
	}

	public void setDepreciation(BigDecimal depreciation) {
		this.depreciation = depreciation;
	}

	public BigDecimal getRemuneration() {
		return remuneration;
	}

	public void setRemuneration(BigDecimal remuneration) {
		this.remuneration = remuneration;
	}

	public BigDecimal getIndirectTax() {
		return indirectTax;
	}

	public void setIndirectTax(BigDecimal indirectTax) {
		this.indirectTax = indirectTax;
	}

	public Boolean getHasOverseasBranch() {
		return hasOverseasBranch;
	}

	public void setHasOverseasBranch(Boolean hasOverseasBranch) {
		this.hasOverseasBranch = hasOverseasBranch;
	}

	public BigDecimal getInboundOp() {
		return inboundOp;
	}

	public void setInboundOp(BigDecimal inboundOp) {
		this.inboundOp = inboundOp;
	}

	public BigDecimal getInboundOpPercent() {
		return inboundOpPercent;
	}

	public void setInboundOpPercent(BigDecimal inboundOpPercent) {
		this.inboundOpPercent = inboundOpPercent;
	}

	public BigDecimal getOutboundOp() {
		return outboundOp;
	}

	public void setOutboundOp(BigDecimal outboundOp) {
		this.outboundOp = outboundOp;
	}

	public BigDecimal getOutboundOpPercent() {
		return outboundOpPercent;
	}

	public void setOutboundOpPercent(BigDecimal outboundOpPercent) {
		this.outboundOpPercent = outboundOpPercent;
	}

	public List<TaAreaOfFocusDto> getOtherFocusRows() {
		return otherFocusRows;
	}

	public void setOtherFocusRows(List<TaAreaOfFocusDto> otherFocusRows) {
		this.otherFocusRows = otherFocusRows;
	}

	public BigDecimal getInboundBusinessTotalAmount() {
		return inboundBusinessTotalAmount;
	}

	public void setInboundBusinessTotalAmount(BigDecimal inboundBusinessTotalAmount) {
		this.inboundBusinessTotalAmount = inboundBusinessTotalAmount;
	}

	public BigDecimal getOutboundBusinessTotalAmount() {
		return outboundBusinessTotalAmount;
	}

	public void setOutboundBusinessTotalAmount(BigDecimal outboundBusinessTotalAmount) {
		this.outboundBusinessTotalAmount = outboundBusinessTotalAmount;
	}

	public BigDecimal getInboundOutboundBusinessTotalAmount() {
		return inboundOutboundBusinessTotalAmount;
	}

	public void setInboundOutboundBusinessTotalAmount(BigDecimal inboundOutboundBusinessTotalAmount) {
		this.inboundOutboundBusinessTotalAmount = inboundOutboundBusinessTotalAmount;
	}

	public Integer getTotalInboundFitGrpPax() {
		return totalInboundFitGrpPax;
	}

	public void setTotalInboundFitGrpPax(Integer totalInboundFitGrpPax) {
		this.totalInboundFitGrpPax = totalInboundFitGrpPax;
	}

	public Integer getTotalOutboundFitGrpPax() {
		return totalOutboundFitGrpPax;
	}

	public void setTotalOutboundFitGrpPax(Integer totalOutboundFitGrpPax) {
		this.totalOutboundFitGrpPax = totalOutboundFitGrpPax;
	}

	public Boolean getIsNilSubmission() {
		return isNilSubmission;
	}

	public void setIsNilSubmission(Boolean isNilSubmission) {
		this.isNilSubmission = isNilSubmission;
	}

}
