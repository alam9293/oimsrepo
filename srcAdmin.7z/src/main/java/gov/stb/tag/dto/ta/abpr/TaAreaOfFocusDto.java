package gov.stb.tag.dto.ta.abpr;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaFocusArea;

public class TaAreaOfFocusDto extends EntityDto {

	private Integer id;

	private ListableDto focusArea;

	private String otherFocusArea;

	private Boolean hasInboundOp = null;

	private Boolean hasOutboundOp = null;

	private Boolean hasOp;

	private String remarks;

	private Boolean bothInOutNull = false;

	public static TaAreaOfFocusDto buildFromFA(Cache cache, TaFocusArea aof) {
		TaAreaOfFocusDto dto = new TaAreaOfFocusDto();
		dto.setId(aof.getId());
		dto.setFocusArea((aof.getFocusArea() != null) ? new ListableDto(aof.getFocusArea().getKey(), cache.getLabel(aof.getFocusArea(), false)) : new ListableDto());
		dto.setOtherFocusArea(aof.getOtherFocusArea());
		dto.setHasInboundOp(aof.getHasInboundOp());
		dto.setHasOutboundOp(aof.getHasOutboundOp());
		if (aof.getHasInboundOp() == null && aof.getHasOutboundOp() == null) {
			dto.setBothInOutNull(true);
		}
		dto.setHasOp(aof.getHasOp());
		dto.setRemarks(aof.getRemarks());
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ListableDto getFocusArea() {
		return focusArea;
	}

	public void setFocusArea(ListableDto focusArea) {
		this.focusArea = focusArea;
	}

	public String getOtherFocusArea() {
		return otherFocusArea;
	}

	public void setOtherFocusArea(String otherFocusArea) {
		this.otherFocusArea = otherFocusArea;
	}

	public Boolean getHasInboundOp() {
		return hasInboundOp;
	}

	public void setHasInboundOp(Boolean hasInboundOp) {
		this.hasInboundOp = hasInboundOp;
	}

	public Boolean getHasOutboundOp() {
		return hasOutboundOp;
	}

	public void setHasOutboundOp(Boolean hasOutboundOp) {
		this.hasOutboundOp = hasOutboundOp;
	}

	public Boolean getHasOp() {
		return hasOp;
	}

	public void setHasOp(Boolean hasOp) {
		this.hasOp = hasOp;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Boolean getBothInOutNull() {
		return bothInOutNull;
	}

	public void setBothInOutNull(Boolean bothInOutNull) {
		this.bothInOutNull = bothInOutNull;
	}

}
