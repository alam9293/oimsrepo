package gov.stb.tag.dto.ta.abpr;

import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.jackson.BigDecimalToMoneyThousandSeparatorConverter;
import gov.stb.tag.jackson.MoneyThousandSeparatorToBigDecimalConverter;
import gov.stb.tag.model.TaBusinessOperation;

public class TaBusinessOperationDto extends EntityDto {

	private Integer id;
	private ListableDto service;
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal inbound;
	private BigDecimal inboundPercent;
	private Boolean isInboundOwned;
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal outbound;
	private BigDecimal outboundPercent;
	private Boolean isOutboundOwned;

	public static TaBusinessOperationDto buildFromBO(Cache cache, TaBusinessOperation bo) {
		TaBusinessOperationDto dto = new TaBusinessOperationDto();
		dto.setId(bo.getId());
		dto.setService((bo.getService() != null) ? new ListableDto(bo.getService().getKey(), cache.getLabel(bo.getService(), false)) : new ListableDto());
		dto.setInbound(bo.getInbound());
		dto.setInboundPercent(bo.getInboundPercent());
		dto.setIsInboundOwned(bo.isInboundOwned());
		dto.setOutbound(bo.getOutbound());
		dto.setIsOutboundOwned(bo.isOutboundOwned());
		dto.setOutboundPercent(bo.getOutboundPercent());
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ListableDto getService() {
		return service;
	}

	public void setService(ListableDto service) {
		this.service = service;
	}

	public BigDecimal getInboundPercent() {
		return inboundPercent;
	}

	public void setInboundPercent(BigDecimal inboundPercent) {
		this.inboundPercent = inboundPercent;
	}

	public BigDecimal getOutboundPercent() {
		return outboundPercent;
	}

	public void setOutboundPercent(BigDecimal outboundPercent) {
		this.outboundPercent = outboundPercent;
	}

	public BigDecimal getInbound() {
		return inbound;
	}

	public void setInbound(BigDecimal inbound) {
		this.inbound = inbound;
	}

	public Boolean getIsInboundOwned() {
		return isInboundOwned;
	}

	public void setIsInboundOwned(Boolean isInboundOwned) {
		this.isInboundOwned = isInboundOwned;
	}

	public BigDecimal getOutbound() {
		return outbound;
	}

	public void setOutbound(BigDecimal outbound) {
		this.outbound = outbound;
	}

	public Boolean getIsOutboundOwned() {
		return isOutboundOwned;
	}

	public void setIsOutboundOwned(Boolean isOutboundOwned) {
		this.isOutboundOwned = isOutboundOwned;
	}

}
