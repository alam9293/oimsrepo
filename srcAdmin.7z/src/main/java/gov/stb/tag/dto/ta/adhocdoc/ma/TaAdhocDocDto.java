package gov.stb.tag.dto.ta.adhocdoc.ma;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TaAdhocDocDto extends TaApplicationDto {

	private TaAnnualFilingDto filingDto;
	private Boolean hasDocToSubmit;
	private List<FileDto> documents;

	public TaAdhocDocDto() {
		super();
		this.hasDocToSubmit = true;
	}

	public static TaAdhocDocDto buildFromNew(Cache cache, TaFilingCondition filing, FileHelper fileHelper) {
		TaAdhocDocDto dto = new TaAdhocDocDto();
		if (filing == null) {
			dto.setHasDocToSubmit(Boolean.FALSE);
		} else {
			dto.setHasDocToSubmit(Boolean.TRUE);
			dto.setFilingDto(TaAnnualFilingDto.build(filing));
			dto.setApplicationStatus(new ListableDto(cache.getStatus(Codes.Statuses.TA_APP_NEW)));
		}
		return dto;
	}

	public static TaAdhocDocDto buildFromApplication(Cache cache, ApplicationHelper appHelper, WorkflowHelper workflowHelper, TaAdhocDocSubmission ma, FileHelper fileHelper) {
		TaAdhocDocDto dto = new TaAdhocDocDto();
		dto = dto.buildFromApplication(cache, appHelper, ma.getApplication(), dto);
		// setting director's resolution, bank statement, and other documents
		List<ApplicationFile> appFiles = new ArrayList<>(ma.getApplication().getApplicationFiles());
		List<FileDto> documents = new ArrayList<FileDto>();
		for (ApplicationFile appFile : appFiles) {
			if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_ADHOC_DOC)) {
				documents.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			}
		}
		dto.setDocuments(documents);
		if (ma.getTaFilingCondition() != null) {
			dto.setFilingDto(TaAnnualFilingDto.build(ma.getTaFilingCondition()));
		}
		return dto;
	}

	public TaAnnualFilingDto getFilingDto() {
		return filingDto;
	}

	public void setFilingDto(TaAnnualFilingDto filingDto) {
		this.filingDto = filingDto;
	}

	public Boolean getHasDocToSubmit() { return hasDocToSubmit; }

	public void setHasDocToSubmit(Boolean hasDocToSubmit) { this.hasDocToSubmit = hasDocToSubmit; }

	public List<FileDto> getDocuments() { return documents; }

	public void setDocuments(List<FileDto> documents) { this.documents = documents; }
}
