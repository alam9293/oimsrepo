package gov.stb.tag.dto.ta.annualfiling;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFilingConditionExtension;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceFilingExtensionDateDto extends TaAnnualFilingDto {

	private Integer extensionDateId;
	private LocalDate extendedDueDate;
	private String remarks;
	private Boolean toExtend;
	private ListableDto ammendType; // FILING_EXTEND, FILING_CANCEL

	// private ListableDto filingCondition;

	public static TaLicenceFilingExtensionDateDto buildFilingExtensionDto(TaFilingConditionExtension model, TaLicenceFilingExtensionDateDto dto) {
		if (model != null) {
			dto = dto.buildFromModel(model.getTaFilingCondition(), dto);
			dto.setExtendedDueDate(model.getExtendedDueDate());
			dto.setToExtend(model.getToProceed());
			dto.setExtensionDateId(model.getId());
			dto.setRemarks(model.getRemarks());
			if (model.getAmmendmentType() != null) {
				dto.setAmmendType(new ListableDto(model.getAmmendmentType()));
			}
		}

		return dto;
	}

	public static TaLicenceFilingExtensionDateDto buildFilingExtensionDto(TaFilingCondition model, TaLicenceFilingExtensionDateDto dto) {
		if (model != null) {
			dto = dto.buildFromModel(model, dto);
		}

		return dto;
	}

	@Override
	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	@Override
	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

	@Override
	public Boolean getToExtend() {
		return toExtend;
	}

	@Override
	public void setToExtend(Boolean toExtend) {
		this.toExtend = toExtend;
	}

	public Integer getExtensionDateId() {
		return extensionDateId;
	}

	public void setExtensionDateId(Integer extensionDateId) {
		this.extensionDateId = extensionDateId;
	}

	@Override
	public String getRemarks() {
		return remarks;
	}

	@Override
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public ListableDto getAmmendType() {
		return ammendType;
	}

	public void setAmmendType(ListableDto ammendType) {
		this.ammendType = ammendType;
	}

}
