package gov.stb.tag.dto.ta.annualfiling;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.workflow.WorkflowDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaFilingConditionExtension;
import gov.stb.tag.model.TaFilingConditionExtensionAssessment;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceFilingExtensionDto extends WorkflowDto {

	private Integer filingExtensionId;
	private LocalDateTime createdDate;
	private ListableDto type; // preliminary, detailed
	private String reason;
	private String riskAssessment;
	private ListableDto hasConsecutiveLosses;
	private String consecutiveLossesRemarks;
	private ListableDto hasShortfallExceeded;
	private String shortfallExceededLossesRemarks;
	private ListableDto isCurrentRatioLessThanOne;
	private String isCurrentRatioLessRemarks;
	private String inboundOutboundRisk;
	private String salesTurnoverRisk;
	private String amtOwedByDirRisk;
	private String litigationSuitRisk;
	private String cpfArrearsRisk;
	private String nonDeliveryRisk;
	private String managerAssessment;
	private String externalRemarks;
	private String internalRemarks;

	private Integer assessedAaId;
	private Integer assessedAa2Id;
	private Integer assessedAbprId;

	private List<TaLicenceFilingExtensionDateDto> extensionDates;

	private List<TaLicenceFilingExtensionDateDto> pastExtensionDates;

	private List<AttachmentDto> files;
	private List<Integer> toDeleteFiles = new ArrayList<Integer>();

	public static TaLicenceFilingExtensionDto buildFromExtension(Cache cache, TaFilingConditionExtensionAssessment extension, TaLicenceFilingExtensionDto dto, Licence licence,
			WorkflowHelper workflowHelper) {

		if (extension != null) {
			dto.setFilingExtensionId(extension.getId());
			dto.setCreatedDate(extension.getCreatedDate());
			dto.setReason(extension.getReason());
			dto.setRiskAssessment(extension.getRiskAssessment());
			dto.setHasConsecutiveLosses(new ListableDto(extension.getHasConsecutiveLosses().getCode(), extension.getHasConsecutiveLosses().getLabel()));
			dto.setConsecutiveLossesRemarks(extension.getConsecutiveLossesRemarks());
			dto.setHasShortfallExceeded(new ListableDto(extension.getHasShortfallExceeded().getCode(), extension.getHasShortfallExceeded().getLabel()));
			dto.setShortfallExceededLossesRemarks(extension.getShortfallExceededLossesRemarks());
			dto.setIsCurrentRatioLessThanOne(new ListableDto(extension.getIsCurrentRatioLessThanOne().getCode(), extension.getIsCurrentRatioLessThanOne().getLabel()));
			dto.setIsCurrentRatioLessRemarks(extension.getIsCurrentRatioLessRemarks());
			dto.setInboundOutboundRisk(extension.getInboundOutboundRisk());
			dto.setSalesTurnoverRisk(extension.getSalesTurnoverRisk());
			dto.setAmtOwedByDirRisk(extension.getAmtOwedByDirRisk());
			dto.setLitigationSuitRisk(extension.getLitigationSuitRisk());
			dto.setCpfArrearsRisk(extension.getCpfArrearsRisk());
			dto.setNonDeliveryRisk(extension.getNonDeliveryRisk());
			dto.setManagerAssessment(extension.getManagerAssessment());
			if (extension.getAssessedAa() != null) {
				dto.setAssessedAaId(extension.getAssessedAa().getId());
			}
			if (extension.getAssessedAa2() != null) {
				dto.setAssessedAa2Id(extension.getAssessedAa2().getId());
			}
			if (extension.getAssessedAbpr() != null) {
				dto.setAssessedAbprId(extension.getAssessedAbpr().getId());
			}
			dto.setType(new ListableDto(extension.getWorkflow().getType().getCode(), extension.getWorkflow().getType().getLabel()));
			dto = dto.buildFromWorkflow(cache, extension.getWorkflow(), dto, workflowHelper);

			if (extension.getTaFilingConditionExtensions() != null) {
				dto.setExtensionDates(new ArrayList<TaLicenceFilingExtensionDateDto>());
				for (TaFilingConditionExtension row : extension.getTaFilingConditionExtensions()) {
					dto.getExtensionDates().add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(row, new TaLicenceFilingExtensionDateDto()));
				}
			}
		} else {
			dto = dto.buildFromWorkflow(cache, null, dto, workflowHelper);
		}
		dto = dto.buildFromLicence(cache, licence, dto);
		return dto;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public ListableDto getType() {
		return type;
	}

	public void setType(ListableDto type) {
		this.type = type;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRiskAssessment() {
		return riskAssessment;
	}

	public void setRiskAssessment(String riskAssessment) {
		this.riskAssessment = riskAssessment;
	}

	public String getInboundOutboundRisk() {
		return inboundOutboundRisk;
	}

	public void setInboundOutboundRisk(String inboundOutboundRisk) {
		this.inboundOutboundRisk = inboundOutboundRisk;
	}

	public String getSalesTurnoverRisk() {
		return salesTurnoverRisk;
	}

	public void setSalesTurnoverRisk(String salesTurnoverRisk) {
		this.salesTurnoverRisk = salesTurnoverRisk;
	}

	public String getAmtOwedByDirRisk() {
		return amtOwedByDirRisk;
	}

	public void setAmtOwedByDirRisk(String amtOwedByDirRisk) {
		this.amtOwedByDirRisk = amtOwedByDirRisk;
	}

	public String getLitigationSuitRisk() {
		return litigationSuitRisk;
	}

	public void setLitigationSuitRisk(String litigationSuitRisk) {
		this.litigationSuitRisk = litigationSuitRisk;
	}

	public String getCpfArrearsRisk() {
		return cpfArrearsRisk;
	}

	public void setCpfArrearsRisk(String cpfArrearsRisk) {
		this.cpfArrearsRisk = cpfArrearsRisk;
	}

	public String getNonDeliveryRisk() {
		return nonDeliveryRisk;
	}

	public void setNonDeliveryRisk(String nonDeliveryRisk) {
		this.nonDeliveryRisk = nonDeliveryRisk;
	}

	public String getManagerAssessment() {
		return managerAssessment;
	}

	public void setManagerAssessment(String managerAssessment) {
		this.managerAssessment = managerAssessment;
	}

	public List<TaLicenceFilingExtensionDateDto> getExtensionDates() {
		return extensionDates;
	}

	public void setExtensionDates(List<TaLicenceFilingExtensionDateDto> extensionDates) {
		this.extensionDates = extensionDates;
	}

	public ListableDto getHasConsecutiveLosses() {
		return hasConsecutiveLosses;
	}

	public void setHasConsecutiveLosses(ListableDto hasConsecutiveLosses) {
		this.hasConsecutiveLosses = hasConsecutiveLosses;
	}

	public ListableDto getHasShortfallExceeded() {
		return hasShortfallExceeded;
	}

	public void setHasShortfallExceeded(ListableDto hasShortfallExceeded) {
		this.hasShortfallExceeded = hasShortfallExceeded;
	}

	public ListableDto getIsCurrentRatioLessThanOne() {
		return isCurrentRatioLessThanOne;
	}

	public void setIsCurrentRatioLessThanOne(ListableDto isCurrentRatioLessThanOne) {
		this.isCurrentRatioLessThanOne = isCurrentRatioLessThanOne;
	}

	public String getConsecutiveLossesRemarks() {
		return consecutiveLossesRemarks;
	}

	public void setConsecutiveLossesRemarks(String consecutiveLossesRemarks) {
		this.consecutiveLossesRemarks = consecutiveLossesRemarks;
	}

	public String getShortfallExceededLossesRemarks() {
		return shortfallExceededLossesRemarks;
	}

	public void setShortfallExceededLossesRemarks(String shortfallExceededLossesRemarks) {
		this.shortfallExceededLossesRemarks = shortfallExceededLossesRemarks;
	}

	public String getIsCurrentRatioLessRemarks() {
		return isCurrentRatioLessRemarks;
	}

	public void setIsCurrentRatioLessRemarks(String isCurrentRatioLessRemarks) {
		this.isCurrentRatioLessRemarks = isCurrentRatioLessRemarks;
	}

	public List<AttachmentDto> getFiles() {
		return files;
	}

	public void setFiles(List<AttachmentDto> files) {
		this.files = files;
	}

	public Integer getFilingExtensionId() {
		return filingExtensionId;
	}

	public void setFilingExtensionId(Integer filingExtensionId) {
		this.filingExtensionId = filingExtensionId;
	}

	public Integer getAssessedAaId() {
		return assessedAaId;
	}

	public void setAssessedAaId(Integer assessedAaId) {
		this.assessedAaId = assessedAaId;
	}

	public Integer getAssessedAbprId() {
		return assessedAbprId;
	}

	public void setAssessedAbprId(Integer assessedAbprId) {
		this.assessedAbprId = assessedAbprId;
	}

	public List<Integer> getToDeleteFiles() {
		return toDeleteFiles;
	}

	public void setToDeleteFiles(List<Integer> toDeleteFiles) {
		this.toDeleteFiles = toDeleteFiles;
	}

	public Integer getAssessedAa2Id() {
		return assessedAa2Id;
	}

	public void setAssessedAa2Id(Integer assessedAa2Id) {
		this.assessedAa2Id = assessedAa2Id;
	}

	public List<TaLicenceFilingExtensionDateDto> getPastExtensionDates() {
		return pastExtensionDates;
	}

	public void setPastExtensionDates(List<TaLicenceFilingExtensionDateDto> pastExtensionDates) {
		this.pastExtensionDates = pastExtensionDates;
	}

}
