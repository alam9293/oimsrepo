package gov.stb.tag.dto.ta.application;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaApplicationBasicDto {

	@MapProjection(path = "id")
	private Integer applicationId;

	@MapProjection(path = "applicationNo")
	private String applicationNo;

	@MapProjection(path = "updatedDate")
	private LocalDateTime updatedDate;

	@MapProjection(path = "type.code")
	private String type;

	@MapProjection(path = "type.label")
	private String typeLabel;

	public TaApplicationBasicDto() {

	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

}
