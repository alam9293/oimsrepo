package gov.stb.tag.dto.ta.application;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaApplicationSearchDto extends SearchDto {
	private String name;
	private Integer licenceId;
	private Integer applicationId;
	private String licenceNo;
	private String applicationNo;
	private LocalDateTime submissionDateFrom;
	private LocalDateTime submissionDateTo;
	private String uen;
	private String applicationStatus;
	private Object[] applicationStatuses;
	private String applicationType;
	private String assignedOfficer;
	private Boolean isOfflineSubmission;
	private String excludeSubmissionType;

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public Object[] getApplicationStatuses() {
		return applicationStatuses;
	}

	public void setApplicationStatuses(Object[] applicationStatuses) {
		this.applicationStatuses = applicationStatuses;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public LocalDateTime getSubmissionDateFrom() {
		return submissionDateFrom;
	}

	public void setSubmissionDateFrom(LocalDateTime submissionDateFrom) {
		this.submissionDateFrom = submissionDateFrom;
	}

	public LocalDateTime getSubmissionDateTo() {
		return submissionDateTo;
	}

	public void setSubmissionDateTo(LocalDateTime submissionDateTo) {
		this.submissionDateTo = submissionDateTo;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public Boolean getIsOfflineSubmission() {
		return isOfflineSubmission;
	}

	public void setIsOfflineSubmission(Boolean isOfflineSubmission) {
		this.isOfflineSubmission = isOfflineSubmission;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getExcludeSubmissionType() {
		return excludeSubmissionType;
	}

	public void setExcludeSubmissionType(String excludeSubmissionType) {
		this.excludeSubmissionType = excludeSubmissionType;
	}

}
