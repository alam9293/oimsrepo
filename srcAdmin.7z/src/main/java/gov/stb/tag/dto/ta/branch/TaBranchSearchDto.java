package gov.stb.tag.dto.ta.branch;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaBranchSearchDto extends SearchDto {
	// private String name;
	//
	//
	//
	//
	// private String name;
	// private Integer licenceNo;
	// private Integer applicationId;
	// private LocalDateTime submissionDateFrom;
	// private LocalDateTime submissionDateTo;
	// private String uen;
	// private String applicationStatus;
	//
	// public String getApplicationStatus() {
	// return applicationStatus;
	// }
	//
	// public void setApplicationStatus(String applicationStatus) {
	// this.applicationStatus = applicationStatus;
	// }
	//
	// public String getName() {
	// return name;
	// }
	//
	// public void setName(String name) {
	// this.name = name;
	// }
	//
	// public String getUen() {
	// return uen;
	// }
	//
	// public void setUen(String uen) {
	// this.uen = uen;
	// }
	//
	// public Integer getLicenceNo() {
	// return licenceNo;
	// }
	//
	// public void setLicenceNo(Integer licenceNo) {
	// this.licenceNo = licenceNo;
	// }
	//
	// public Integer getApplicationId() {
	// return applicationId;
	// }
	//
	// public void setApplicationId(Integer applicationId) {
	// this.applicationId = applicationId;
	// }
	//
	// public LocalDateTime getSubmissionDateFrom() {
	// return submissionDateFrom;
	// }
	//
	// public void setSubmissionDateFrom(LocalDateTime submissionDateFrom) {
	// this.submissionDateFrom = submissionDateFrom;
	// }
	//
	// public LocalDateTime getSubmissionDateTo() {
	// return submissionDateTo;
	// }
	//
	// public void setSubmissionDateTo(LocalDateTime submissionDateTo) {
	// this.submissionDateTo = submissionDateTo;
	// }

}
