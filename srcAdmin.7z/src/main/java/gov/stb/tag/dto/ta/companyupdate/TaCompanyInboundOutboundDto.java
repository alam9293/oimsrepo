package gov.stb.tag.dto.ta.companyupdate;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;

public class TaCompanyInboundOutboundDto extends EntityDto {

	private ListableDto service;
	private boolean inbound;
	private boolean outbound;

	public ListableDto getService() {
		return service;
	}

	public void setService(ListableDto service) {
		this.service = service;
	}

	public boolean isInbound() {
		return inbound;
	}

	public void setInbound(boolean inbound) {
		this.inbound = inbound;
	}

	public boolean isOutbound() {
		return outbound;
	}

	public void setOutbound(boolean outbound) {
		this.outbound = outbound;
	}

}
