package gov.stb.tag.dto.ta.companyupdate;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TaCompanyUpdate;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaCompanyUpdateSubmissionDto extends TaApplicationDto {
	// Application Details
	private Integer id;

	private String applicationNo;

	private Boolean isDraft;

	private ListableDto status;

	private String externalRemarks;

	// Current Business Entity Details
	private TaCompanyDetailsDto currentDetails;

	// New Business Entity Details
	private TaCompanyDetailsDto newDetails;

	private FileDto companyDetailsDocument;
	private FileDto acra;

	private Boolean isEdhPopulated;

	private List<FileDto> otherDocuments = new ArrayList<FileDto>();

	// private List<Integer> toDeleteFiles = new ArrayList<Integer>();

	public static TaCompanyUpdateSubmissionDto buildFromApplication(Cache cache, ApplicationHelper appHelper, TaCompanyUpdate taCompanyUpdate, FileHelper fileHelper) {
		TaCompanyUpdateSubmissionDto taCompanyUpdateSubmissionDto = new TaCompanyUpdateSubmissionDto();

		// 1. Application
		taCompanyUpdateSubmissionDto = taCompanyUpdateSubmissionDto.buildFromApplication(cache, appHelper, taCompanyUpdate.getApplication(), taCompanyUpdateSubmissionDto);

		// 2. Business Entity - New
		taCompanyUpdateSubmissionDto.setNewDetails(TaCompanyDetailsDto.buildFromApplication(cache, taCompanyUpdate));
		taCompanyUpdateSubmissionDto.getNewDetails().setFye(taCompanyUpdate.getApplication().getLicence().getTravelAgent().getFyeDate());

		// 3. Business Entity - Current
		taCompanyUpdateSubmissionDto.setCurrentDetails(TaCompanyDetailsDto.buildFromApplication(cache, taCompanyUpdate.getPreviousValue()));
		taCompanyUpdateSubmissionDto.getCurrentDetails().setFye(taCompanyUpdateSubmissionDto.getNewDetails().getFye());

		List<ApplicationFile> applicationFileList = new ArrayList<>(taCompanyUpdate.getApplication().getApplicationFiles());
		if (applicationFileList.size() > 0) {
			for (ApplicationFile applicationFile : applicationFileList) {
				if (applicationFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_TENANCY)) {
					taCompanyUpdateSubmissionDto.setCompanyDetailsDocument(FileDto.buildFromFile(applicationFile.getFile(), applicationFile.getDocumentType(), fileHelper));
				} else if (applicationFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ)) {
					taCompanyUpdateSubmissionDto.setAcra(FileDto.buildFromFile(applicationFile.getFile(), applicationFile.getDocumentType(), fileHelper));
				} else {
					taCompanyUpdateSubmissionDto.getOtherDocuments().add(FileDto.buildFromFile(applicationFile.getFile(), applicationFile.getDocumentType(), fileHelper));
				}

			}

		}
		if (taCompanyUpdateSubmissionDto.getCompanyDetailsDocument() == null) {
			taCompanyUpdateSubmissionDto.setCompanyDetailsDocument(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_TENANCY), fileHelper));
		}
		if (taCompanyUpdateSubmissionDto.getAcra() == null) {
			taCompanyUpdateSubmissionDto.setAcra(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ), fileHelper));
		}
		taCompanyUpdateSubmissionDto.setIsEdhPopulated(taCompanyUpdate.getIsEdhPopulated());
		taCompanyUpdateSubmissionDto.setId(taCompanyUpdate.getId());
		return taCompanyUpdateSubmissionDto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String getApplicationNo() {
		return applicationNo;
	}

	@Override
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	@Override
	public String getExternalRemarks() {
		return externalRemarks;
	}

	@Override
	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public TaCompanyDetailsDto getCurrentDetails() {
		return currentDetails;
	}

	public void setCurrentDetails(TaCompanyDetailsDto currentDetails) {
		this.currentDetails = currentDetails;
	}

	public TaCompanyDetailsDto getNewDetails() {
		return newDetails;
	}

	public void setNewDetails(TaCompanyDetailsDto newDetails) {
		this.newDetails = newDetails;
	}

	public FileDto getCompanyDetailsDocument() {
		return companyDetailsDocument;
	}

	public void setCompanyDetailsDocument(FileDto companyDetailsDocument) {
		this.companyDetailsDocument = companyDetailsDocument;
	}

	public FileDto getAcra() {
		return acra;
	}

	public void setAcra(FileDto acra) {
		this.acra = acra;
	}

	public Boolean getIsEdhPopulated() {
		return isEdhPopulated;
	}

	public void setIsEdhPopulated(Boolean isEdhPopulated) {
		this.isEdhPopulated = isEdhPopulated;
	}

	public List<FileDto> getOtherDocuments() {
		return otherDocuments;
	}

	public void setOtherDocuments(List<FileDto> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

}
