package gov.stb.tag.dto.ta.elicencerequest;

import java.util.List;

import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.dashboard.LicenceDto;

public class TaELicenceDto {

	private String displayName;
	private AddressDto displayAddr;
	private LicenceDto licence;
	private String qrCode;
	private List<AddressDto> branchAddrList;

	public TaELicenceDto() {

	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public AddressDto getDisplayAddr() {
		return displayAddr;
	}

	public void setDisplayAddr(AddressDto displayAddr) {
		this.displayAddr = displayAddr;
	}

	public LicenceDto getLicence() {
		return licence;
	}

	public void setLicence(LicenceDto licence) {
		this.licence = licence;
	}

	public String getQrCode() {
		return qrCode;
	}

	public void setQrCode(String qrCode) {
		this.qrCode = qrCode;
	}

	public List<AddressDto> getBranchAddrList() {
		return branchAddrList;
	}

	public void setBranchAddrList(List<AddressDto> branchAddrList) {
		this.branchAddrList = branchAddrList;
	}

}
