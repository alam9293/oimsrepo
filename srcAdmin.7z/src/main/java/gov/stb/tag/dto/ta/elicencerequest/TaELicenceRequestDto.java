package gov.stb.tag.dto.ta.elicencerequest;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaELicenceRequestDto extends TaApplicationDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "application.licence.isDownloadable")
	private Integer isDownloadable;

	@MapProjection(path = "reason")
	private String reason;

	public TaELicenceRequestDto() {

	}

	public static TaELicenceRequestDto buildApplication(Cache cache, ApplicationHelper appHelper, Application app, TaELicenceRequestDto dto) {
		dto = dto.buildFromApplication(cache, appHelper, app, dto);
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIsDownloadable() {
		return isDownloadable;
	}

	public void setIsDownloadable(Integer isDownloadable) {
		this.isDownloadable = isDownloadable;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
}
