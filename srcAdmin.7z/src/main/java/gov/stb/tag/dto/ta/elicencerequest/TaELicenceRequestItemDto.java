package gov.stb.tag.dto.ta.elicencerequest;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaELicenceRequestItemDto extends TaApplicationItemDto {

	public TaELicenceRequestItemDto() {

	}
}
