package gov.stb.tag.dto.ta.filingamend;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.workflow.TaWorkflowSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceFilingAmendSearchDto extends TaWorkflowSearchDto {
	private Integer licenceId;
	private String ammendTypeCode;
	private Integer excludeAmendId;

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public Integer getExcludeAmendId() {
		return excludeAmendId;
	}

	public void setExcludeAmendId(Integer excludeAmendId) {
		this.excludeAmendId = excludeAmendId;
	}

	public String getAmmendTypeCode() {
		return ammendTypeCode;
	}

	public void setAmmendTypeCode(String ammendTypeCode) {
		this.ammendTypeCode = ammendTypeCode;
	}

}
