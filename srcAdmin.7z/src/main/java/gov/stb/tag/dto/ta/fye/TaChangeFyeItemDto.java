package gov.stb.tag.dto.ta.fye;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaChangeFyeItemDto extends TaApplicationItemDto {

	public TaChangeFyeItemDto() {

	}

}
