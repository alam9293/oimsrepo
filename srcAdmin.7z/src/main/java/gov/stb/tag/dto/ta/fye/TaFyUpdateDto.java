package gov.stb.tag.dto.ta.fye;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaFyUpdate;

public class TaFyUpdateDto extends TaApplicationDto {

	private TaFyDto selectedFyObj;

	private LocalDate newFyEndDate;

	private String reason;

	private FileDto directorResolution;
	private List<FileDto> otherDocuments;
	private List<TaAnnualFilingSubmissionDto> affectedFilings;

	public static TaFyUpdateDto buildFromApplication(Cache cache, ApplicationHelper appHelper, TaFyUpdate tlc, FileHelper fileHelper) {

		if (tlc != null) {
			TaFyUpdateDto dto = new TaFyUpdateDto();
			dto = dto.buildFromApplication(cache, appHelper, tlc.getApplication(), dto);
			dto.setSelectedFyObj(new TaFyDto(tlc.getFyStartDate(), tlc.getOldFyeDate()));
			dto.setNewFyEndDate(tlc.getNewFyeDate());
			dto.setReason(tlc.getReason());

			// setting director's resolution and other documents
			List<ApplicationFile> appFiles = new ArrayList<>(tlc.getApplication().getApplicationFiles());
			List<FileDto> otherDocuments = new ArrayList<FileDto>();
			for (ApplicationFile appFile : appFiles) {
				if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_CFYE_DIRECTOR_RESOLUTION)) {
					dto.setDirectorResolution(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
				} else {
					otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
				}
			}
			dto.setOtherDocuments(otherDocuments);
			return dto;
		}
		return null;
	}

	public static TaFyUpdateDto buildFromNew(Cache cache, Licence licence, FileHelper fileHelper) {

		TaFyUpdateDto dto = new TaFyUpdateDto();
		dto.setExpiryDate(licence.getExpiryDate());
		dto.setStartDate(licence.getStartDate());
		dto.setDirectorResolution(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_CFYE_DIRECTOR_RESOLUTION), fileHelper));
		return dto;
	}

	public TaFyDto getSelectedFyObj() {
		return selectedFyObj;
	}

	public void setSelectedFyObj(TaFyDto selectedFyObj) {
		this.selectedFyObj = selectedFyObj;
	}

	public LocalDate getNewFyEndDate() {
		return newFyEndDate;
	}

	public void setNewFyEndDate(LocalDate newFyEndDate) {
		this.newFyEndDate = newFyEndDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public FileDto getDirectorResolution() {
		return directorResolution;
	}

	public void setDirectorResolution(FileDto directorResolution) {
		this.directorResolution = directorResolution;
	}

	public List<FileDto> getOtherDocuments() {
		return otherDocuments;
	}

	public void setOtherDocuments(List<FileDto> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

	public List<TaAnnualFilingSubmissionDto> getAffectedFilings() {
		return affectedFilings;
	}

	public void setAffectedFilings(List<TaAnnualFilingSubmissionDto> affectedFilings) {
		this.affectedFilings = affectedFilings;
	}

}
