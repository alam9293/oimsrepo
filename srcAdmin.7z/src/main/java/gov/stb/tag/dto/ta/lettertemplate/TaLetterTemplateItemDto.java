package gov.stb.tag.dto.ta.lettertemplate;

import com.fasterxml.jackson.annotation.JsonInclude;
import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.model.EmailTemplate;
import gov.stb.tag.model.LetterTemplate;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLetterTemplateItemDto extends EntityDto {

	private String code;
	private String name;
	private String description;
	private String content;
	private Boolean isActive;

	public static TaLetterTemplateItemDto build(LetterTemplate template) {
		TaLetterTemplateItemDto dto = new TaLetterTemplateItemDto();
		if (template != null) {
			dto.setCode(template.getCode());
			dto.setName(template.getName());
			dto.setContent(template.getContent());
			dto.setIsActive(template.getIsActive());
		}
		return dto;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getContent() { return content; }

	public void setContent(String content) { this.content = content; }

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
}
