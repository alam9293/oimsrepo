package gov.stb.tag.dto.ta.licence;

import java.time.LocalDate;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;

public class TaCpfArrearDto extends EntityDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "responseDate")
	private LocalDate responseDate;

	@MapProjection(path = "hasCpfArrear")
	private Boolean hasCpfArrear;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getHasCpfArrear() {
		return hasCpfArrear;
	}

	public void setHasCpfArrear(Boolean hasCpfArrear) {
		this.hasCpfArrear = hasCpfArrear;
	}

	public LocalDate getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(LocalDate responseDate) {
		this.responseDate = responseDate;
	}

}
