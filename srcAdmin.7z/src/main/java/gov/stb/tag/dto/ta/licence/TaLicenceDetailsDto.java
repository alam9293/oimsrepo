package gov.stb.tag.dto.ta.licence;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.branch.TaBranchDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaBranch;

public class TaLicenceDetailsDto extends EntityDto {

	private ListableDto tier;
	private String name;
	private String formerName;
	private String displayName;
	private String uen;
	private ListableDto formOfBusiness;
	private ListableDto businessConstitution;
	private ListableDto principleActivity;
	private ListableDto secondaryPrincipleActivity;
	private ListableDto placeIncorporated;
	private LocalDate incorporatedDate;
	private ListableDto statusOfEstablishment;
	private ListableDto taSegmentation;
	private BigDecimal paidUpCapital;
	private LocalDate fye;
	private String contactNo;
	private String faxNo;
	private String email;
	private String url;
	private AddressDto registeredAddress;
	private AddressDto operatingAddress;
	private AddressDto displayAddress;
	private List<TaBranchDto> activeBranches;
	private List<TaBranchDto> formerBranches;

	public static TaLicenceDetailsDto build(Cache cache, Licence licence, List<TaBranch> branches) {
		TaLicenceDetailsDto dto = new TaLicenceDetailsDto();
		dto.setTier(licence.getTier() != null ? new ListableDto(licence.getTier().getKey(), cache.getLabel(licence.getTier(), false)) : new ListableDto());
		dto.setName(licence.getTravelAgent().getName());
		dto.setFormerName(licence.getTravelAgent().getFormerName());
		if (licence.getTravelAgent().getDisplayName() != null && !licence.getTravelAgent().getDisplayName().isEmpty()) {
			dto.setDisplayName(licence.getTravelAgent().getDisplayName());
		} else {
			dto.setDisplayName(licence.getTravelAgent().getName());
		}
		dto.setUen(licence.getTravelAgent().getUen());
		dto.setFormOfBusiness(licence.getTravelAgent().getFormOfBusiness() != null
				? new ListableDto(licence.getTravelAgent().getFormOfBusiness().getKey(), cache.getLabel(licence.getTravelAgent().getFormOfBusiness(), false))
				: new ListableDto());
		dto.setPrincipleActivity(licence.getTravelAgent().getPrincipleActivities() != null
				? new ListableDto(licence.getTravelAgent().getPrincipleActivities().getKey(), cache.getLabel(licence.getTravelAgent().getPrincipleActivities(), false))
				: new ListableDto());
		dto.setSecondaryPrincipleActivity(licence.getTravelAgent().getSecondaryPrincipleActivities() != null
				? new ListableDto(licence.getTravelAgent().getSecondaryPrincipleActivities().getKey(), cache.getLabel(licence.getTravelAgent().getSecondaryPrincipleActivities(), false))
				: new ListableDto());
		dto.setPlaceIncorporated(licence.getTravelAgent().getIncorporatedPlace() != null
				? new ListableDto(licence.getTravelAgent().getIncorporatedPlace().getKey(), cache.getLabel(licence.getTravelAgent().getIncorporatedPlace(), false))
				: new ListableDto());
		dto.setStatusOfEstablishment(licence.getTravelAgent().getEstablishmentStatus() != null
				? new ListableDto(licence.getTravelAgent().getEstablishmentStatus().getKey(), cache.getLabel(licence.getTravelAgent().getEstablishmentStatus(), false))
				: new ListableDto());
		dto.setTaSegmentation(licence.getTravelAgent().getTaSegmentation() != null
				? new ListableDto(licence.getTravelAgent().getTaSegmentation().getKey(), cache.getLabel(licence.getTravelAgent().getTaSegmentation(), false))
				: new ListableDto());
		dto.setBusinessConstitution(licence.getTravelAgent().getBusinessConstitution() != null
				? new ListableDto(licence.getTravelAgent().getBusinessConstitution().getKey(), cache.getLabel(licence.getTravelAgent().getBusinessConstitution(), false))
				: new ListableDto());
		dto.setIncorporatedDate(licence.getTravelAgent().getIncorporatedDate());
		dto.setPaidUpCapital(licence.getTravelAgent().getPaidUpCapital());
		dto.setFye(licence.getTravelAgent().getFyeDate());
		dto.setContactNo(licence.getTravelAgent().getContactNo());
		dto.setFaxNo(licence.getTravelAgent().getFaxNo());
		dto.setEmail(licence.getTravelAgent().getEmailAddress());
		dto.setUrl(licence.getTravelAgent().getWebsiteUrl());

		dto.setRegisteredAddress(AddressDto.buildFromAddress(cache, licence.getTravelAgent().getRegisteredAddress()));

		dto.setOperatingAddress(AddressDto.buildFromAddress(cache, licence.getTravelAgent().getOperatingAddress()));

		if (licence.getTravelAgent().getDisplayAddress() == null) {
			dto.setDisplayAddress(AddressDto.buildFromAddress(cache, licence.getTravelAgent().getOperatingAddress()));
		} else {
			dto.setDisplayAddress(AddressDto.buildFromAddress(cache, licence.getTravelAgent().getDisplayAddress()));
		}

		List<TaBranchDto> activeList = new ArrayList<>();
		List<TaBranchDto> formerList = new ArrayList<>();

		for (TaBranch aBranch : branches) {
			TaBranchDto branchDto = TaBranchDto.buildFromTaBranch(cache, aBranch);
			if (aBranch.getStatus().getCode().equals(Codes.Statuses.TA_BRANCH_ACTIVE) || aBranch.getStatus().getCode().equals(Codes.Statuses.TA_BRANCH_M_PENDING_RENEWAL)) {
				activeList.add(branchDto);
			} else {
				formerList.add(branchDto);
			}

		}

		dto.setActiveBranches(activeList);
		dto.setFormerBranches(formerList);

		return dto;
	}

	public ListableDto getTier() {
		return tier;
	}

	public void setTier(ListableDto tier) {
		this.tier = tier;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFormerName() {
		return formerName;
	}

	public void setFormerName(String formerName) {
		this.formerName = formerName;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public ListableDto getFormOfBusiness() {
		return formOfBusiness;
	}

	public void setFormOfBusiness(ListableDto formOfBusiness) {
		this.formOfBusiness = formOfBusiness;
	}

	public ListableDto getPrincipleActivity() {
		return principleActivity;
	}

	public void setPrincipleActivity(ListableDto princinpleActivity) {
		this.principleActivity = princinpleActivity;
	}

	public ListableDto getSecondaryPrincipleActivity() {
		return secondaryPrincipleActivity;
	}

	public void setSecondaryPrincipleActivity(ListableDto secondaryPrincipleActivity) {
		this.secondaryPrincipleActivity = secondaryPrincipleActivity;
	}

	public ListableDto getPlaceIncorporated() {
		return placeIncorporated;
	}

	public void setPlaceIncorporated(ListableDto placeIncorporated) {
		this.placeIncorporated = placeIncorporated;
	}

	public LocalDate getIncorporatedDate() {
		return incorporatedDate;
	}

	public void setIncorporatedDate(LocalDate incorporatedDate) {
		this.incorporatedDate = incorporatedDate;
	}

	public ListableDto getBusinessConstitution() {
		return businessConstitution;
	}

	public void setBusinessConstitution(ListableDto businessConstitution) {
		this.businessConstitution = businessConstitution;
	}

	public ListableDto getStatusOfEstablishment() {
		return statusOfEstablishment;
	}

	public void setStatusOfEstablishment(ListableDto statusOfEstablishment) {
		this.statusOfEstablishment = statusOfEstablishment;
	}

	public ListableDto getTaSegmentation() {
		return taSegmentation;
	}

	public void setTaSegmentation(ListableDto taSegmentation) {
		this.taSegmentation = taSegmentation;
	}

	public BigDecimal getPaidUpCapital() {
		return paidUpCapital;
	}

	public void setPaidUpCapital(BigDecimal paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}

	public LocalDate getFye() {
		return fye;
	}

	public void setFye(LocalDate fye) {
		this.fye = fye;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public AddressDto getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(AddressDto registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public AddressDto getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(AddressDto operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public List<TaBranchDto> getActiveBranches() {
		return activeBranches;
	}

	public void setActiveBranches(List<TaBranchDto> activeBranches) {
		this.activeBranches = activeBranches;
	}

	public List<TaBranchDto> getFormerBranches() {
		return formerBranches;
	}

	public void setFormerBranches(List<TaBranchDto> formerBranches) {
		this.formerBranches = formerBranches;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public AddressDto getDisplayAddress() {
		return displayAddress;
	}

	public void setDisplayAddress(AddressDto displayAddress) {
		this.displayAddress = displayAddress;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

}
