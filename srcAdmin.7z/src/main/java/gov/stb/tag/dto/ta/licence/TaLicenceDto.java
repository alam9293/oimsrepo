package gov.stb.tag.dto.ta.licence;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaStakeholder;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceDto extends EntityDto {

	public Integer getIsViewable() {
		return isViewable;
	}

	public void setIsViewable(Integer isViewable) {
		this.isViewable = isViewable;
	}

	private String name;
	private String uen;
	private String licenceNo;
	private Integer licenceId;
	private Integer taId;
	private Integer isViewable;
	private LocalDate issueDate;
	private LocalDate startDate;
	private LocalDate expiryDate;
	private LocalDate ceasedDate;
	private ListableDto licenceStatus;
	private ListableDto licenceTier;

	private Integer keId;
	private String keName;
	private String keContact;

	public <T extends TaLicenceDto> T buildFromLicence(Cache cache, Licence licence, T dto) {
		dto.setName(licence.getTravelAgent().getName());
		dto.setUen(licence.getTravelAgent().getUen());
		dto.setLicenceNo(licence.getLicenceNo());
		dto.setLicenceId(licence.getId());
		dto.setTaId(licence.getTravelAgent().getId());
		dto.setIsViewable(licence.getIsViewable());
		dto.setIssueDate(licence.getIssueDate());
		dto.setStartDate(licence.getStartDate());
		dto.setExpiryDate(licence.getExpiryDate());
		dto.setCeasedDate(licence.getCeasedDate());
		dto.setLicenceStatus(new ListableDto(licence.getStatus().getCode(), cache.getLabel(licence.getStatus(), false), cache.getLabel(licence.getStatus(), true), licence.isPendingCessation(), null));
		dto.setLicenceTier(new ListableDto(licence.getTier().getCode(), cache.getLabel(licence.getTier(), false)));
		return dto;
	}

	public <T extends TaLicenceDto> T setKeDetails(Cache cache, TaStakeholder ke, T dto) {
		if (ke != null) {
			dto.setKeId(ke.getId());
			dto.setKeName(ke.getStakeholder().getName());
			dto.setKeContact(ke.getStakeholder().getContactNo());
		}
		return dto;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public Integer getTaId() {
		return taId;
	}

	public void setTaId(Integer taId) {
		this.taId = taId;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	public ListableDto getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(ListableDto licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public ListableDto getLicenceTier() {
		return licenceTier;
	}

	public void setLicenceTier(ListableDto licenceTier) {
		this.licenceTier = licenceTier;
	}

	public Integer getKeId() {
		return keId;
	}

	public void setKeId(Integer keId) {
		this.keId = keId;
	}

	public String getKeName() {
		return keName;
	}

	public void setKeName(String keName) {
		this.keName = keName;
	}

	public String getKeContact() {
		return keContact;
	}

	public void setKeContact(String keContact) {
		this.keContact = keContact;
	}

}
