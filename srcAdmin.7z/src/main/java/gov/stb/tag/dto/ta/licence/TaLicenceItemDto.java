package gov.stb.tag.dto.ta.licence;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceItemDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "licenceNo")
	private String licenceNo;

	@MapProjection(path = "travelAgent.name")
	private String name;

	@MapProjection(path = "travelAgent.uen")
	private String uen;

	@MapProjection(path = "tier.label")
	private String tier;

	@MapProjection(path = "issueDate")
	private LocalDate issueDate;

	@MapProjection(path = "ceasedDate")
	private LocalDate ceasedDate;

	@MapProjection(path = "expiryDate")
	private LocalDate expiryDate;

	@MapProjection(path = "status.label")
	private String status;

	@MapProjection(path = "status.code")
	private String statusCode;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

}
