package gov.stb.tag.dto.ta.licence;

import java.util.ArrayList;
import java.util.List;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Licence;

public class TaLicencePastDto extends EntityDto {

	private List<TaLicenceDto> otherLicences = new ArrayList<>();

	public static TaLicencePastDto build(Cache cache, Licence licence) {
		TaLicencePastDto dto = new TaLicencePastDto();
		for (Licence otherLicence : licence.getTravelAgent().getLicences()) {
			if (otherLicence.getId() != licence.getId()) {
				TaLicenceDto licenceDto = new TaLicenceDto();
				dto.getOtherLicences().add(licenceDto.buildFromLicence(cache, otherLicence, licenceDto));
			}

		}
		return dto;

	}

	public List<TaLicenceDto> getOtherLicences() {
		return otherLicences;
	}

	public void setOtherLicences(List<TaLicenceDto> otherLicences) {
		this.otherLicences = otherLicences;
	}

}
