package gov.stb.tag.dto.ta.licence;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicencePersonnelSearchDto extends SearchDto {

}
