package gov.stb.tag.dto.ta.licence;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceSearchDto extends SearchDto {

	private String name;
	private String uen;
	private String licenceNo;
	private String tier;
	private LocalDate issueDateFrom;
	private LocalDate issueDateTo;
	private LocalDate cessationDateFrom;
	private LocalDate cessationDateTo;
	private String statusCode;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public LocalDate getIssueDateFrom() {
		return issueDateFrom;
	}

	public void setIssueDateFrom(LocalDate issueDateFrom) {
		this.issueDateFrom = issueDateFrom;
	}

	public LocalDate getIssueDateTo() {
		return issueDateTo;
	}

	public void setIssueDateTo(LocalDate issueDateTo) {
		this.issueDateTo = issueDateTo;
	}

	public LocalDate getCessationDateFrom() {
		return cessationDateFrom;
	}

	public void setCessationDateFrom(LocalDate cessationDateFrom) {
		this.cessationDateFrom = cessationDateFrom;
	}

	public LocalDate getCessationDateTo() {
		return cessationDateTo;
	}

	public void setCessationDateTo(LocalDate cessationDateTo) {
		this.cessationDateTo = cessationDateTo;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
