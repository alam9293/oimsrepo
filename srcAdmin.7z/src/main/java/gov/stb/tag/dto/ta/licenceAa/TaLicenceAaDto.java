package gov.stb.tag.dto.ta.licenceAa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.jackson.BigDecimalToMoneyThousandSeparatorConverter;
import gov.stb.tag.jackson.MoneyThousandSeparatorToBigDecimalConverter;
import gov.stb.tag.model.Application;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceAaDto extends TaApplicationDto {

	@MapProjection(path = "id")
	private Integer aaSubmissionId;

	private TaAnnualFilingDto annualFilingDto = new TaAnnualFilingDto();

	private boolean hasAaToSubmit = true;

	private Boolean isEdit;

	// Profit loss statment fields
	@MapProjection(path = "revenue")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal revenue;

	@MapProjection(path = "otherIncome")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal otherIncome;

	@MapProjection(path = "grossProfitLoss")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal grossProfitLoss;

	@MapProjection(path = "netProfitLoss")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal netProfitLoss;

	@MapProjection(path = "dividendsPaid")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal dividendsPaid;

	// Balacnce sheet: Assets
	@MapProjection(path = "bankBalance")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal bankBalance;

	@MapProjection(path = "cashCashEquiv")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal cashCashEquiv;

	@MapProjection(path = "tradeReceivables")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal tradeReceivables;

	@MapProjection(path = "tradeSecurities")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal tradeSecurities;

	@MapProjection(path = "amtOwnByDir")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal amtOwnByDir;

	@MapProjection(path = "nonCurrentAssets")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal nonCurrentAssets;

	@MapProjection(path = "currentAssets")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal currentAssets;

	@MapProjection(path = "totalAssets")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal totalAssets;

	// Balacnce sheet: Equity
	@MapProjection(path = "capital")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal capital;

	@MapProjection(path = "accProfitLoss")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal accProfitLoss;

	@MapProjection(path = "totalEquity")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal totalEquity;

	// Balacnce sheet: Liabilities
	@MapProjection(path = "nonCurrentLiabilities")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal nonCurrentLiabilities;

	@MapProjection(path = "currentLiabilities")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal currentLiabilities;

	@MapProjection(path = "totalLiabilities")
	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal totalLiabilities;

	@MapProjection(path = "netProfitMargin")
	private BigDecimal netProfitMargin;

	@MapProjection(path = "quickRatio")
	private BigDecimal quickRatio;

	@MapProjection(path = "debtEquityRatio")
	private BigDecimal debtEquityRatio;

	@MapProjection(path = "profitScRatio")
	private BigDecimal profitScRatio;

	@MapProjection(path = "netValue")
	private BigDecimal netValue;

	@MapProjection(path = "shortfall")
	private BigDecimal shortfall;

	// Auditor’s Opinion Code
	@MapProjection(path = "auditorOpinion.code")
	private String auditorOpinionCode;

	// Auditor’s Opinion Label
	@MapProjection(path = "auditorOpinion.label")
	private String auditorOpinionLabel;

	private TaNetValueShortfallDto shortfallDto;

	private List<FileDto> files = new ArrayList<FileDto>(); // require audited report. optional: other doc

	private List<Integer> toDeleteFiles = new ArrayList<Integer>();

	public static TaLicenceAaDto buildApplication(Cache cache, ApplicationHelper appHelper, Application app, TaLicenceAaDto dto) {
		dto = dto.buildFromApplication(cache, appHelper, app, dto);
		return dto;
	}

	public List<Integer> getToDeleteFiles() {
		return toDeleteFiles;
	}

	public void setToDeleteFiles(List<Integer> toDeleteFiles) {
		this.toDeleteFiles = toDeleteFiles;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public Integer getAaSubmissionId() {
		return aaSubmissionId;
	}

	public void setAaSubmissionId(Integer aaSubmissionId) {
		this.aaSubmissionId = aaSubmissionId;
	}

	public BigDecimal getRevenue() {
		return revenue;
	}

	public void setRevenue(BigDecimal revenue) {
		this.revenue = revenue;
	}

	public BigDecimal getOtherIncome() {
		return otherIncome;
	}

	public void setOtherIncome(BigDecimal otherIncome) {
		this.otherIncome = otherIncome;
	}

	public BigDecimal getGrossProfitLoss() {
		return grossProfitLoss;
	}

	public void setGrossProfitLoss(BigDecimal grossProfitLoss) {
		this.grossProfitLoss = grossProfitLoss;
	}

	public BigDecimal getNetProfitLoss() {
		return netProfitLoss;
	}

	public void setNetProfitLoss(BigDecimal netProfitLoss) {
		this.netProfitLoss = netProfitLoss;
	}

	public BigDecimal getDividendsPaid() {
		return dividendsPaid;
	}

	public void setDividendsPaid(BigDecimal dividendsPaid) {
		this.dividendsPaid = dividendsPaid;
	}

	public BigDecimal getBankBalance() {
		return bankBalance;
	}

	public void setBankBalance(BigDecimal bankBalance) {
		this.bankBalance = bankBalance;
	}

	public BigDecimal getCashCashEquiv() {
		return cashCashEquiv;
	}

	public void setCashCashEquiv(BigDecimal cashCashEquiv) {
		this.cashCashEquiv = cashCashEquiv;
	}

	public BigDecimal getTradeReceivables() {
		return tradeReceivables;
	}

	public void setTradeReceivables(BigDecimal tradeReceivables) {
		this.tradeReceivables = tradeReceivables;
	}

	public BigDecimal getTradeSecurities() {
		return tradeSecurities;
	}

	public void setTradeSecurities(BigDecimal tradeSecurities) {
		this.tradeSecurities = tradeSecurities;
	}

	public BigDecimal getAmtOwnByDir() {
		return amtOwnByDir;
	}

	public void setAmtOwnByDir(BigDecimal amtOwnByDir) {
		this.amtOwnByDir = amtOwnByDir;
	}

	public BigDecimal getNonCurrentAssets() {
		return nonCurrentAssets;
	}

	public void setNonCurrentAssets(BigDecimal nonCurrentAssets) {
		this.nonCurrentAssets = nonCurrentAssets;
	}

	public BigDecimal getCurrentAssets() {
		return currentAssets;
	}

	public void setCurrentAssets(BigDecimal currentAssets) {
		this.currentAssets = currentAssets;
	}

	public BigDecimal getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(BigDecimal totalAssets) {
		this.totalAssets = totalAssets;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getAccProfitLoss() {
		return accProfitLoss;
	}

	public void setAccProfitLoss(BigDecimal accProfitLoss) {
		this.accProfitLoss = accProfitLoss;
	}

	public BigDecimal getTotalEquity() {
		return totalEquity;
	}

	public void setTotalEquity(BigDecimal totalEquity) {
		this.totalEquity = totalEquity;
	}

	public BigDecimal getNonCurrentLiabilities() {
		return nonCurrentLiabilities;
	}

	public void setNonCurrentLiabilities(BigDecimal nonCurrentLiabilities) {
		this.nonCurrentLiabilities = nonCurrentLiabilities;
	}

	public BigDecimal getCurrentLiabilities() {
		return currentLiabilities;
	}

	public void setCurrentLiabilities(BigDecimal currentLiabilities) {
		this.currentLiabilities = currentLiabilities;
	}

	public BigDecimal getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(BigDecimal totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public String getAuditorOpinionCode() {
		return auditorOpinionCode;
	}

	public void setAuditorOpinionCode(String auditorOpinionCode) {
		this.auditorOpinionCode = auditorOpinionCode;
	}

	public boolean isHasAaToSubmit() {
		return hasAaToSubmit;
	}

	public void setHasAaToSubmit(boolean hasAaToSubmit) {
		this.hasAaToSubmit = hasAaToSubmit;
	}

	public TaAnnualFilingDto getAnnualFilingDto() {
		return annualFilingDto;
	}

	public void setAnnualFilingDto(TaAnnualFilingDto annualFilingDto) {
		this.annualFilingDto = annualFilingDto;
	}

	public String getAuditorOpinionLabel() {
		return auditorOpinionLabel;
	}

	public void setAuditorOpinionLabel(String auditorOpinionLabel) {
		this.auditorOpinionLabel = auditorOpinionLabel;
	}

	public BigDecimal getNetProfitMargin() {
		return netProfitMargin;
	}

	public void setNetProfitMargin(BigDecimal netProfitMargin) {
		this.netProfitMargin = netProfitMargin;
	}

	public BigDecimal getQuickRatio() {
		return quickRatio;
	}

	public void setQuickRatio(BigDecimal quickRatio) {
		this.quickRatio = quickRatio;
	}

	public BigDecimal getDebtEquityRatio() {
		return debtEquityRatio;
	}

	public void setDebtEquityRatio(BigDecimal debtEquityRatio) {
		this.debtEquityRatio = debtEquityRatio;
	}

	public BigDecimal getProfitScRatio() {
		return profitScRatio;
	}

	public void setProfitScRatio(BigDecimal profitScRatio) {
		this.profitScRatio = profitScRatio;
	}

	public BigDecimal getNetValue() {
		return netValue;
	}

	public void setNetValue(BigDecimal netValue) {
		this.netValue = netValue;
	}

	public Boolean getIsEdit() {
		return isEdit;
	}

	public void setIsEdit(Boolean isEdit) {
		this.isEdit = isEdit;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public TaNetValueShortfallDto getShortfallDto() {
		return shortfallDto;
	}

	public void setShortfallDto(TaNetValueShortfallDto shortfallDto) {
		this.shortfallDto = shortfallDto;
	}

}
