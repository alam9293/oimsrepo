package gov.stb.tag.dto.ta.licenceAdhocDoc;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceAdhocDocDto extends TaApplicationDto {

	@MapProjection(path = "id")
	private Integer docSubmissionId;

	private TaAnnualFilingDto annualFilingDto = new TaAnnualFilingDto();

	private boolean hasDocToSubmit = true;

	private Boolean isEdit;

	private List<FileDto> files = new ArrayList<FileDto>();

	private List<Integer> toDeleteFiles = new ArrayList<Integer>();

	public static TaLicenceAdhocDocDto buildApplication(Cache cache, ApplicationHelper appHelper, Application app, TaLicenceAdhocDocDto dto) {
		dto = dto.buildFromApplication(cache, appHelper, app, dto);
		return dto;
	}

	public Integer getDocSubmissionId() {
		return docSubmissionId;
	}

	public void setDocSubmissionId(Integer docSubmissionId) {
		this.docSubmissionId = docSubmissionId;
	}

	public TaAnnualFilingDto getAnnualFilingDto() {
		return annualFilingDto;
	}

	public void setAnnualFilingDto(TaAnnualFilingDto annualFilingDto) {
		this.annualFilingDto = annualFilingDto;
	}

	public boolean isHasDocToSubmit() {
		return hasDocToSubmit;
	}

	public void setHasDocToSubmit(boolean hasDocToSubmit) {
		this.hasDocToSubmit = hasDocToSubmit;
	}

	public Boolean getIsEdit() {
		return isEdit;
	}

	public void setIsEdit(Boolean isEdit) {
		this.isEdit = isEdit;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public List<Integer> getToDeleteFiles() {
		return toDeleteFiles;
	}

	public void setToDeleteFiles(List<Integer> toDeleteFiles) {
		this.toDeleteFiles = toDeleteFiles;
	}

}
