package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.math.BigDecimal;

import gov.stb.tag.annotation.MapProjection;

public class AaSubmissionForRenewalDto {

	@MapProjection(path = "id")
	private Integer taAaSubmissionId;

	@MapProjection(path = "taAnnualFiling.licence.id")
	private Integer licenceId;

	@MapProjection(path = "taAnnualFiling.licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "currentAssets")
	private BigDecimal currentAssets;

	@MapProjection(path = "currentLiabilities")
	private BigDecimal currentLiabilities;

	@MapProjection(path = "shortfall")
	private BigDecimal shortfall;

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public BigDecimal getCurrentAssets() {
		return currentAssets;
	}

	public void setCurrentAssets(BigDecimal currentAssets) {
		this.currentAssets = currentAssets;
	}

	public BigDecimal getCurrentLiabilities() {
		return currentLiabilities;
	}

	public void setCurrentLiabilities(BigDecimal currentLiabilities) {
		this.currentLiabilities = currentLiabilities;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public Integer getTaAaSubmissionId() {
		return taAaSubmissionId;
	}

	public void setTaAaSubmissionId(Integer taAaSubmissionId) {
		this.taAaSubmissionId = taAaSubmissionId;
	}

}
