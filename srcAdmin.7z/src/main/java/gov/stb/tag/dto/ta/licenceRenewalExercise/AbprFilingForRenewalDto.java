package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.time.LocalDate;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;

public class AbprFilingForRenewalDto extends TaFilingForRenewalDto {

	@MapProjection(path = "taAbprSubmission.id")
	private Integer taAbprSubmissionId;

	@MapProjection(path = "fyEndDate")
	private LocalDate fyEndDate;

	public static AbprFilingForRenewalDto buildAbprFillingForRenewalDto(TaFilingCondition filingModel, AbprFilingForRenewalDto dto, TaAbprSubmission abpr) {
		if (filingModel != null) {
			dto = dto.buildFromFiling(filingModel, dto,
					abpr != null && abpr.getApplication() != null && !abpr.getApplication().isDraft() && !abpr.getApplication().isDeleted() ? abpr.getApplication().getId() : null,
					abpr != null && abpr.getApplication() != null && !abpr.getApplication().isDraft() && !abpr.getApplication().isDeleted() ? abpr.getApplication().getApplicationNo() : null);
			dto.setFyEndDate(filingModel.getFyEndDate());

		} else {
			dto.setFilingSubmissionStatus("Not required");
		}
		if (abpr != null && !abpr.getApplication().isDraft() && !abpr.getApplication().isDeleted()) {
			dto.setTaAbprSubmissionId(abpr.getId());
		}
		return dto;
	}

	public Integer getTaAbprSubmissionId() {
		return taAbprSubmissionId;
	}

	public void setTaAbprSubmissionId(Integer taAbprSubmissionId) {
		this.taAbprSubmissionId = taAbprSubmissionId;
	}

	public LocalDate getFyEndDate() {
		return fyEndDate;
	}

	public void setFyEndDate(LocalDate fyEndDate) {
		this.fyEndDate = fyEndDate;
	}

}
