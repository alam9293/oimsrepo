package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.time.LocalDate;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.model.TaFilingCondition;

public class TaFilingForRenewalDto {

	@MapProjection(path = "id")
	private Integer filingId;

	@MapProjection(path = "licence.id")
	private Integer licenceId;

	@MapProjection(path = "licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "status.code")
	private String taAnnualFilingStatusCode;

	@MapProjection(path = "fy")
	private Integer fy;

	@MapProjection(path = "taAaSubmission.application.id")
	private Integer applicationId;

	@MapProjection(path = "taAaSubmission.application.applicationNo")
	private String applicationNo;

	private String filingSubmissionStatus;

	private LocalDate requestedAsAtDate;
	private LocalDate dueDate;

	public <T extends TaFilingForRenewalDto> T buildFromFiling(TaFilingCondition filingModel, T dto, Integer appId, String applicationNo) {
		if (filingModel != null) {
			dto.setFilingId(filingModel.getId());
			dto.setLicenceId(filingModel.getLicence().getId());
			dto.setLicenceNo(filingModel.getLicence().getLicenceNo());
			dto.setTaAnnualFilingStatusCode(filingModel.getStatus().getCode());
			dto.setFy(filingModel.getFy());
			dto.setRequestedAsAtDate(filingModel.getRequestedAsAtDate());
			dto.setDueDate(filingModel.getDueDate());
			if (filingModel.getApplicationType().getCode().equalsIgnoreCase(ApplicationTypes.TA_APP_ABPR_SUBMISSION)) {
				if (!dto.getTaAnnualFilingStatusCode().equalsIgnoreCase(Statuses.TA_FILING_PEND_SUBMISSION)) {
					dto.setFilingSubmissionStatus("Submitted");
				} else {
					dto.setFilingSubmissionStatus("Not Submitted");
				}
			} else {
				if (dto.getTaAnnualFilingStatusCode().equalsIgnoreCase(Statuses.TA_FILING_APPROVED)) {
					dto.setFilingSubmissionStatus("Submitted");
				} else {
					dto.setFilingSubmissionStatus("Not Submitted");
				}
			}
		} else {
			dto.setFilingSubmissionStatus("Not required");
		}
		dto.setApplicationId(appId);
		dto.setApplicationNo(applicationNo);

		return dto;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getTaAnnualFilingStatusCode() {
		return taAnnualFilingStatusCode;
	}

	public void setTaAnnualFilingStatusCode(String taAnnualFilingStatusCode) {
		this.taAnnualFilingStatusCode = taAnnualFilingStatusCode;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public Integer getFilingId() {
		return filingId;
	}

	public void setFilingId(Integer filingId) {
		this.filingId = filingId;
	}

	public String getFilingSubmissionStatus() {
		return filingSubmissionStatus;
	}

	public void setFilingSubmissionStatus(String filingSubmissionStatus) {
		this.filingSubmissionStatus = filingSubmissionStatus;
	}

	public LocalDate getRequestedAsAtDate() {
		return requestedAsAtDate;
	}

	public void setRequestedAsAtDate(LocalDate requestedAsAtDate) {
		this.requestedAsAtDate = requestedAsAtDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

}
