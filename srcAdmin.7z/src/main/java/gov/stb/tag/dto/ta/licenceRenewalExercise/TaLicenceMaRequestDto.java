package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.time.LocalDate;

import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaLicenceRenewalExerciseParam;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;

public class TaLicenceMaRequestDto {

	private LocalDate requestedMaAsAtDate;
	private LocalDate maSubmissionDueDate;
	private Integer renewalExerciseTaId;
	private Integer renewalExerciseId;
	private Integer licenceId;
	private String isRequireMa;

	public LocalDate getRequestedMaAsAtDate() {
		return requestedMaAsAtDate;
	}

	public void setRequestedMaAsAtDate(LocalDate requestedMaAsAtDate) {
		this.requestedMaAsAtDate = requestedMaAsAtDate;
	}

	public LocalDate getMaSubmissionDueDate() {
		return maSubmissionDueDate;
	}

	public void setMaSubmissionDueDate(LocalDate maSubmissionDueDate) {
		this.maSubmissionDueDate = maSubmissionDueDate;
	}

	public static TaLicenceMaRequestDto buildRequestMaDto(TaLicenceRenewalExerciseParam exerciseParam, TaLicenceMaRequestDto dto, Integer licenceId, Integer renewalExerciseId,
			Integer renewalExerciseTaId, TaLicenceRenewalExercise taLicenceRenewalExercise, TaLicenceRenewalExerciseTa taLicenceRenewalExerciseTa) {
		if (exerciseParam == null) {
			dto.setRequestedMaAsAtDate(taLicenceRenewalExercise.getDefaultRequestedMaAsAtDate());
			dto.setIsRequireMa(taLicenceRenewalExerciseTa.isMaRequired().toString());
		} else {
			dto.setRequestedMaAsAtDate(exerciseParam.getRequestedMaAsAtDate());
			dto.setMaSubmissionDueDate(exerciseParam.getMaSubmissionDueDate());
			dto.setIsRequireMa(exerciseParam.isMaRequiredByUser().toString());
		}
		dto.setLicenceId(licenceId);
		dto.setRenewalExerciseId(renewalExerciseId);
		dto.setRenewalExerciseTaId(renewalExerciseTaId);
		return dto;
	}

	public static TaLicenceMaRequestDto buildRequestMaDto(TaFilingCondition filing, TaLicenceMaRequestDto dto) {
		dto.setRequestedMaAsAtDate(filing.getRequestedAsAtDate());
		dto.setMaSubmissionDueDate(filing.getDueDate());
		dto.setLicenceId(filing.getLicence().getId());

		return dto;
	}

	public String getIsRequireMa() {
		return isRequireMa;
	}

	public void setIsRequireMa(String isRequireMa) {
		this.isRequireMa = isRequireMa;
	}

	public Integer getRenewalExerciseTaId() {
		return renewalExerciseTaId;
	}

	public void setRenewalExerciseTaId(Integer renewalExerciseTaId) {
		this.renewalExerciseTaId = renewalExerciseTaId;
	}

	public Integer getRenewalExerciseId() {
		return renewalExerciseId;
	}

	public void setRenewalExerciseId(Integer renewalExerciseId) {
		this.renewalExerciseId = renewalExerciseId;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

}
