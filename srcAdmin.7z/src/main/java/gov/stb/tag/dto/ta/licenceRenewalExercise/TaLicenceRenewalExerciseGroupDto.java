package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.workflow.WorkflowDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.TaLicenceRenewalExercise;

public class TaLicenceRenewalExerciseGroupDto extends WorkflowDto {

	private Integer renewalExerciseId;
	private Integer renewalYear;
	private LocalDateTime snapshotAsatDate;
	private LocalDate renewalStartDate;
	private LocalDate renewalEndDate;
	private LocalDate fyeCutOffDate;
	private LocalDate requestedMaAsAtDate;

	private Integer totalLicence;
	private Integer totalExpress;
	private Integer totalCustomised;
	private List<ListableDto> totalLicenceByStatus;

	private Integer totalRenewed;
	private Integer totalNotRenewed;

	private List<TaLicenceRenewalExerciseParticipantDto> express;
	private List<TaLicenceRenewalExerciseParticipantDto> customised;

	public TaLicenceRenewalExerciseGroupDto() {
		this.setExpress(Lists.newArrayList());
		this.setCustomised(Lists.newArrayList());
		// this.setTotalLicenceByStatus(Maps.newHashMap());
	}

	public static TaLicenceRenewalExerciseGroupDto mapModeltoRenewalExerciseGroupDto(Cache cache, TaLicenceRenewalExercise renewalExerciseModel, TaLicenceRenewalExerciseGroupDto dto,
			WorkflowHelper workflowHelper) {
		dto.setRenewalExerciseId(renewalExerciseModel.getId());
		dto.setRenewalYear(renewalExerciseModel.getYear());
		dto.setRenewalStartDate(renewalExerciseModel.getStartDate());
		dto.setRenewalEndDate(renewalExerciseModel.getEndDate());
		dto.setFyeCutOffDate(renewalExerciseModel.getFyeCutOffDate());
		dto.setRequestedMaAsAtDate(renewalExerciseModel.getDefaultRequestedMaAsAtDate());
		dto.setSnapshotAsatDate(renewalExerciseModel.getRefreshedDate());
		dto = dto.buildNewWorkflowDto(cache, renewalExerciseModel.getWorkflow(), dto, workflowHelper, Codes.Workflow.TA_WKFLW_RENEW_EX);

		return dto;
	}

	public Integer getRenewalYear() {
		return renewalYear;
	}

	public void setRenewalYear(Integer renewalYear) {
		this.renewalYear = renewalYear;
	}

	public LocalDateTime getSnapshotAsatDate() {
		return snapshotAsatDate;
	}

	public void setSnapshotAsatDate(LocalDateTime snapshotAsatDate) {
		this.snapshotAsatDate = snapshotAsatDate;
	}

	public LocalDate getRenewalStartDate() {
		return renewalStartDate;
	}

	public void setRenewalStartDate(LocalDate renewalStartDate) {
		this.renewalStartDate = renewalStartDate;
	}

	public LocalDate getRenewalEndDate() {
		return renewalEndDate;
	}

	public void setRenewalEndDate(LocalDate renewalEndDate) {
		this.renewalEndDate = renewalEndDate;
	}

	public LocalDate getFyeCutOffDate() {
		return fyeCutOffDate;
	}

	public void setFyeCutOffDate(LocalDate fyeCutOffDate) {
		this.fyeCutOffDate = fyeCutOffDate;
	}

	public Integer getTotalLicence() {
		return totalLicence;
	}

	public void setTotalLicence(Integer totalLicence) {
		this.totalLicence = totalLicence;
	}

	public Integer getTotalExpress() {
		return totalExpress;
	}

	public void setTotalExpress(Integer totalExpress) {
		this.totalExpress = totalExpress;
	}

	public Integer getTotalCustomised() {
		return totalCustomised;
	}

	public void setTotalCustomised(Integer totalCustomised) {
		this.totalCustomised = totalCustomised;
	}

	public Integer getTotalRenewed() {
		return totalRenewed;
	}

	public void setTotalRenewed(Integer totalRenewed) {
		this.totalRenewed = totalRenewed;
	}

	public Integer getTotalNotRenewed() {
		return totalNotRenewed;
	}

	public void setTotalNotRenewed(Integer totalNotRenewed) {
		this.totalNotRenewed = totalNotRenewed;
	}

	public List<TaLicenceRenewalExerciseParticipantDto> getExpress() {
		return express;
	}

	public void setExpress(List<TaLicenceRenewalExerciseParticipantDto> express) {
		this.express = express;
	}

	public List<TaLicenceRenewalExerciseParticipantDto> getCustomised() {
		return customised;
	}

	public void setCustomised(List<TaLicenceRenewalExerciseParticipantDto> customised) {
		this.customised = customised;
	}

	public LocalDate getRequestedMaAsAtDate() {
		return requestedMaAsAtDate;
	}

	public void setRequestedMaAsAtDate(LocalDate requestedMaAsAtDate) {
		this.requestedMaAsAtDate = requestedMaAsAtDate;
	}

	public Integer getRenewalExerciseId() {
		return renewalExerciseId;
	}

	public void setRenewalExerciseId(Integer renewalExerciseId) {
		this.renewalExerciseId = renewalExerciseId;
	}

	public List<ListableDto> getTotalLicenceByStatus() {
		return totalLicenceByStatus;
	}

	public void setTotalLicenceByStatus(List<ListableDto> totalLicenceByStatus) {
		this.totalLicenceByStatus = totalLicenceByStatus;
	}

}
