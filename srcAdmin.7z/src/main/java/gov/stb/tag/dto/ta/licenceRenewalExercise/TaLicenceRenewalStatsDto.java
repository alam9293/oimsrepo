package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.time.LocalDateTime;
import java.util.Map;

public class TaLicenceRenewalStatsDto {

	private LocalDateTime snapshotAsatDate;

	private Integer totalLicence;
	private Integer totalExpress;
	private Integer totalCustomised;
	private Map<String, Integer> totalLicenceByStatus;

	private Integer totalRenewed;
	private Integer totalNotRenewed;

	public Integer getTotalLicence() {
		return totalLicence;
	}

	public void setTotalLicence(Integer totalLicence) {
		this.totalLicence = totalLicence;
	}

	public Integer getTotalExpress() {
		return totalExpress;
	}

	public void setTotalExpress(Integer totalExpress) {
		this.totalExpress = totalExpress;
	}

	public Integer getTotalCustomised() {
		return totalCustomised;
	}

	public void setTotalCustomised(Integer totalCustomised) {
		this.totalCustomised = totalCustomised;
	}

	public Map<String, Integer> getTotalLicenceByStatus() {
		return totalLicenceByStatus;
	}

	public void setTotalLicenceByStatus(Map<String, Integer> totalLicenceByStatus) {
		this.totalLicenceByStatus = totalLicenceByStatus;
	}

	public Integer getTotalRenewed() {
		return totalRenewed;
	}

	public void setTotalRenewed(Integer totalRenewed) {
		this.totalRenewed = totalRenewed;
	}

	public Integer getTotalNotRenewed() {
		return totalNotRenewed;
	}

	public void setTotalNotRenewed(Integer totalNotRenewed) {
		this.totalNotRenewed = totalNotRenewed;
	}

	public LocalDateTime getSnapshotAsatDate() {
		return snapshotAsatDate;
	}

	public void setSnapshotAsatDate(LocalDateTime snapshotAsatDate) {
		this.snapshotAsatDate = snapshotAsatDate;
	}
}
