package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.time.LocalDate;

import gov.stb.tag.annotation.MapProjection;

public class TravelAgentForRenewalDto {

	@MapProjection(path = "id")
	private Integer licenceId;

	@MapProjection(path = "travelAgent.id")
	private Integer travelAgentId;

	@MapProjection(path = "travelAgent.name")
	private String name;

	@MapProjection(path = "travelAgent.uen")
	private String uen;

	@MapProjection(path = "licenceNo")
	private String licenceNo;

	@MapProjection(path = "status.code")
	private String licenceStatusCode;

	@MapProjection(path = "status.label")
	private String licenceStatusLabel;

	@MapProjection(path = "travelAgent.fyeDate")
	private LocalDate fye;

	public Integer getTravelAgentId() {
		return travelAgentId;
	}

	public void setTravelAgentId(Integer travelAgentId) {
		this.travelAgentId = travelAgentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getLicenceStatusCode() {
		return licenceStatusCode;
	}

	public void setLicenceStatusCode(String licenceStatusCode) {
		this.licenceStatusCode = licenceStatusCode;
	}

	public String getLicenceStatusLabel() {
		return licenceStatusLabel;
	}

	public void setLicenceStatusLabel(String licenceStatusLabel) {
		this.licenceStatusLabel = licenceStatusLabel;
	}

	public LocalDate getFye() {
		return fye;
	}

	public void setFye(LocalDate fye) {
		this.fye = fye;
	}

}
