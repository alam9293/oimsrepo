package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.time.LocalDate;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.model.TaNetValueShortfall;

public class shortfallRectificationForRenewalDto {

	@MapProjection(path = "taNetValueShortfall.id")
	private Integer taNetValueShortfallId;

	@MapProjection(path = "taNetValueShortfall.application.id")
	private Integer applicationId;

	@MapProjection(path = "taNetValueShortfall.application.applicationNo")
	private String applicationNo;

	private LocalDate rectificationDueDate;

	private String rectificationStatus;

	public static shortfallRectificationForRenewalDto buildShortFallForRenewalDto(TaNetValueShortfall shortfallModel, shortfallRectificationForRenewalDto dto) {
		if (shortfallModel != null && shortfallModel.getWorkflow().getLastAction().getStatus().getKey().toString().equalsIgnoreCase(Statuses.TA_WKFLW_APPROVED)
				&& shortfallModel.getWorkflow().getLastAction().getRecommendation().getCode().equalsIgnoreCase(Types.RECOMMEND_IMPOSE)) {
			dto.setTaNetValueShortfallId(shortfallModel.getId());
		} else {
			dto.setRectificationStatus("Not required");
		}
		if (shortfallModel.getTaNetValueRectification() != null && shortfallModel.getTaNetValueRectification().getApplication() != null
				&& shortfallModel.getTaNetValueRectification().getApplication().getLastAction() != null) {
			if (shortfallModel.getTaNetValueRectification().getApplication().getLastAction().getStatus().getCode().equalsIgnoreCase(Statuses.TA_APP_APPROVED)) {
				dto.setApplicationId(shortfallModel.getTaNetValueRectification().getApplication().getId());
				dto.setApplicationNo(shortfallModel.getTaNetValueRectification().getApplication().getApplicationNo());
				dto.setRectificationStatus("Submitted");
			} else {
				dto.setRectificationStatus("Not Submitted");
			}
		}

		return dto;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public Integer getTaNetValueShortfallId() {
		return taNetValueShortfallId;
	}

	public void setTaNetValueShortfallId(Integer taNetValueShortfallId) {
		this.taNetValueShortfallId = taNetValueShortfallId;
	}

	public LocalDate getRectificationDueDate() {
		return rectificationDueDate;
	}

	public void setRectificationDueDate(LocalDate rectificationDueDate) {
		this.rectificationDueDate = rectificationDueDate;
	}

	public String getRectificationStatus() {
		return rectificationStatus;
	}

	public void setRectificationStatus(String rectificationStatus) {
		this.rectificationStatus = rectificationStatus;
	}

}
