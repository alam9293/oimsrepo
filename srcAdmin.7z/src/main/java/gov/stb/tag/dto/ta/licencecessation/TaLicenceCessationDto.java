package gov.stb.tag.dto.ta.licencecessation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.LicenceReturnBatch;
import gov.stb.tag.model.TaLicenceCessation;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceCessationDto extends TaApplicationDto {

	private ListableDto reason;
	private String otherReason;
	private LocalDate cessationDate;
	private FileDto directorResolution = new FileDto();
	private List<FileDto> otherDocuments;
	private Integer licenceReturnBatchId;
	private ListableDto licenceReturnedStatus;
	private Boolean isPendingCessation;
	private Boolean hasSubmittedCessation;

	public static TaLicenceCessationDto buildFromApplication(Cache cache, ApplicationHelper appHelper, TaLicenceCessation tlc, LicenceReturnBatch lrb, FileHelper fileHelper) {
		TaLicenceCessationDto dto = new TaLicenceCessationDto();
		dto = dto.buildFromApplication(cache, appHelper, tlc.getApplication(), dto);
		dto.setReason(new ListableDto(tlc.getReason().getKey(), tlc.getReason().getLabel()));
		dto.setOtherReason(tlc.getOtherReason());
		dto.setCessationDate(tlc.getEffectiveDate());

		// setting director's resolution and other documents
		List<ApplicationFile> appFiles = new ArrayList<>(tlc.getApplication().getApplicationFiles());
		List<FileDto> otherDocuments = new ArrayList<FileDto>();
		for (ApplicationFile appFile : appFiles) {
			if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_CEASE_DIRECTOR_RESOLUTION)) {
				dto.setDirectorResolution(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			} else {
				otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			}

		}
		if (dto.getDirectorResolution() == null) {
			dto.setDirectorResolution(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_CEASE_DIRECTOR_RESOLUTION), fileHelper));
		}
		dto.setOtherDocuments(otherDocuments);
		if (lrb != null) {
			dto.setLicenceReturnBatchId(lrb.getId());
			dto.setLicenceReturnedStatus(new ListableDto(lrb.getStatus().getKey(), cache.getLabel(lrb.getStatus(), false)));
		}

		return dto;
	}

	public static TaLicenceCessationDto buildFromNew(Cache cache, Licence licence, FileHelper fileHelper) {
		TaLicenceCessationDto dto = new TaLicenceCessationDto();
		dto.setExpiryDate(licence.getExpiryDate());
		dto.setStartDate(licence.getStartDate());
		dto.setIssueDate(licence.getIssueDate());
		dto.setDirectorResolution(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_CEASE_DIRECTOR_RESOLUTION), fileHelper));
		dto.setHasSubmittedCessation(Boolean.FALSE);
		return dto;
	}

	public ListableDto getReason() {
		return reason;
	}

	public void setReason(ListableDto reason) {
		this.reason = reason;
	}

	public String getOtherReason() {
		return otherReason;
	}

	public void setOtherReason(String otherReason) {
		this.otherReason = otherReason;
	}

	public LocalDate getCessationDate() {
		return cessationDate;
	}

	public void setCessationDate(LocalDate cessationDate) {
		this.cessationDate = cessationDate;
	}

	public FileDto getDirectorResolution() {
		return directorResolution;
	}

	public void setDirectorResolution(FileDto directorResolution) {
		this.directorResolution = directorResolution;
	}

	public List<FileDto> getOtherDocuments() {
		return otherDocuments;
	}

	public void setOtherDocuments(List<FileDto> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

	public Integer getLicenceReturnBatchId() {
		return licenceReturnBatchId;
	}

	public void setLicenceReturnBatchId(Integer licenceReturnBatchId) {
		this.licenceReturnBatchId = licenceReturnBatchId;
	}

	public ListableDto getLicenceReturnedStatus() {
		return licenceReturnedStatus;
	}

	public void setLicenceReturnedStatus(ListableDto licenceReturnedStatus) {
		this.licenceReturnedStatus = licenceReturnedStatus;
	}

	public Boolean getIsPendingCessation() {
		return isPendingCessation;
	}

	public void setIsPendingCessation(Boolean isPendingCessation) {
		this.isPendingCessation = isPendingCessation;
	}

	public Boolean getHasSubmittedCessation() { return hasSubmittedCessation; }

	public void setHasSubmittedCessation(Boolean hasSubmittedCessation) { this.hasSubmittedCessation = hasSubmittedCessation; }
}
