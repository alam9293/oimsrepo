package gov.stb.tag.dto.ta.licencecessation;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceCessationSearchDto extends TaApplicationSearchDto {

}
