package gov.stb.tag.dto.ta.licencemanageke;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceKeItemDto extends TaApplicationItemDto {

	@MapProjection(path = "type.label")
	private String appTypeLabel;

	@MapProjection(path = "type.code")
	private String appType;

	public TaLicenceKeItemDto() {

	}

	public String getAppTypeLabel() {
		return appTypeLabel;
	}

	public void setAppTypeLabel(String appTypeLabel) {
		this.appTypeLabel = appTypeLabel;
	}

	public String getAppType() {
		return appType;
	}

	public void setAppType(String appType) {
		this.appType = appType;
	}

}
