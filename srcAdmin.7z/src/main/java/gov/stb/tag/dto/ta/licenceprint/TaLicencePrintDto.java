package gov.stb.tag.dto.ta.licenceprint;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicencePrintDto extends EntityDto {

	private List<Integer> applicationIds;
	private ListableDto status;

	public List<Integer> getApplicationIds() {
		return applicationIds;
	}

	public void setApplicationIds(List<Integer> applicationIds) {
		this.applicationIds = applicationIds;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

}
