package gov.stb.tag.dto.ta.licenceprint;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicencePrintItemDto extends TaApplicationItemDto {

	@MapProjection(path = "licenceCollectedDate")
	private LocalDate licenceCollectedDate;

	@MapProjection(path = "licencePrintStatus.code")
	private String licencePrintStatusCode;

	@MapProjection(path = "licencePrintStatus.label")
	private String licencePrintStatus;

	@MapProjection(path = "lastAction.updatedDate")
	private LocalDateTime appApprovedDate;

	public TaLicencePrintItemDto() {

	}

	public LocalDate getLicenceCollectedDate() {
		return licenceCollectedDate;
	}

	public void setLicenceCollectedDate(LocalDate licenceCollectedDate) {
		this.licenceCollectedDate = licenceCollectedDate;
	}

	public String getLicencePrintStatusCode() {
		return licencePrintStatusCode;
	}

	public void setLicencePrintStatusCode(String licencePrintStatusCode) {
		this.licencePrintStatusCode = licencePrintStatusCode;
	}

	public String getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(String licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}

	public LocalDateTime getAppApprovedDate() {
		return appApprovedDate;
	}

	public void setAppApprovedDate(LocalDateTime appApprovedDate) {
		this.appApprovedDate = appApprovedDate;
	}

}
