package gov.stb.tag.dto.ta.licenceprint;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicencePrintSearchDto extends TaApplicationSearchDto {

	private String licencePrintStatus;
	private LocalDate licenceExpiryDate;

	public String getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(String licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

}
