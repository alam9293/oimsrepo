package gov.stb.tag.dto.ta.licencereplacement;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TaLicenceReplacement;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceReplacementDto extends TaApplicationDto {

	private String otherReasons;
	private ListableDto reason;
	private PaymentRequestDto payment;
	private FileDto policeReport;
	private List<FileDto> otherDocuments;

	public TaLicenceReplacementDto() {

	}

	public static TaLicenceReplacementDto buildFromApplication(CacheHelper cache, ApplicationHelper appHelper, PaymentHelper paymentHelper, TaLicenceReplacement tlr, FileHelper fileHelper) {
		TaLicenceReplacementDto dto = new TaLicenceReplacementDto();
		dto = dto.buildFromApplication(cache, appHelper, tlr.getApplication(), dto);
		dto.setOtherReasons(tlr.getReason().getCode().equals(Codes.Types.TA_REASON_REPLACE_OTHERS) ? tlr.getOtherReason() : null);
		dto.setReason(new ListableDto(tlr.getReason().getCode(), tlr.getReason().getLabel()));
		dto.setPayment(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tlr.getBillRefNo()), false));

		// setting police report and other documents
		List<ApplicationFile> appFiles = new ArrayList<>(tlr.getApplication().getApplicationFiles());
		List<FileDto> otherDocuments = new ArrayList<FileDto>();
		if (appFiles.size() > 0) {
			for (ApplicationFile appFile : appFiles) {
				if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_POLICE_REPORT)) {
					dto.setPoliceReport(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
				} else {
					otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
				}

			}
			dto.setOtherDocuments(otherDocuments);
		}
		if (dto.getPoliceReport() == null) {
			dto.setPoliceReport(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_POLICE_REPORT), fileHelper));
		}

		return dto;
	}

	public static TaLicenceReplacementDto buildFromNew(CacheHelper cache, FileHelper fileHelper) {
		TaLicenceReplacementDto dto = new TaLicenceReplacementDto();
		dto.setPoliceReport(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_POLICE_REPORT), fileHelper));

		return dto;
	}

	public FileDto getPoliceReport() {
		return policeReport;
	}

	public void setPoliceReport(FileDto policeReport) {
		this.policeReport = policeReport;
	}

	public List<FileDto> getOtherDocuments() {
		return otherDocuments;
	}

	public void setOtherDocuments(List<FileDto> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

	public String getOtherReasons() {
		return otherReasons;
	}

	public void setOtherReasons(String otherReasons) {
		this.otherReasons = otherReasons;
	}

	public ListableDto getReason() {
		return reason;
	}

	public void setReason(ListableDto reason) {
		this.reason = reason;
	}

	public PaymentRequestDto getPayment() {
		return payment;
	}

	public void setPayment(PaymentRequestDto payment) {
		this.payment = payment;
	}

}
