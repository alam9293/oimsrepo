package gov.stb.tag.dto.ta.licencetierswitch;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ta.abpr.TaBusinessOperationDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceTierSwitchDto extends TaApplicationDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "oldLicenceTier.label")
	private String oldLicenceTier;

	@MapProjection(path = "newLicenceTier.label")
	private String newLicenceTier;

	@MapProjection(path = "oldLicenceTier.code")
	private String oldLicenceTierCode;

	@MapProjection(path = "newLicenceTier.code")
	private String newLicenceTierCode;

	@MapProjection(path = "startDate")
	private LocalDate newTierStartDate;

	@MapProjection(path = "pendingSwitch")
	private Boolean pendingSwitch;

	private LocalDate minDate = LocalDate.now();

	private List<TaBusinessOperationDto> taBusinessOperations = new ArrayList<>();

	private List<TaBusinessOperationDto> newTaBusinessOperations = new ArrayList<>();

	private List<Integer> toDeletebusinessRows = new ArrayList<Integer>();

	private List<FileDto> files = new ArrayList<FileDto>();

	private List<Integer> toDeleteFiles = new ArrayList<Integer>();

	public TaLicenceTierSwitchDto() {

	}

	public static TaLicenceTierSwitchDto buildApplication(Cache cache, ApplicationHelper appHelper, Application app, TaLicenceTierSwitchDto dto) {
		dto = dto.buildFromApplication(cache, appHelper, app, dto);
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOldLicenceTier() {
		return oldLicenceTier;
	}

	public void setOldLicenceTier(String oldLicenceTier) {
		this.oldLicenceTier = oldLicenceTier;
	}

	public String getNewLicenceTier() {
		return newLicenceTier;
	}

	public void setNewLicenceTier(String newLicenceTier) {
		this.newLicenceTier = newLicenceTier;
	}

	public String getOldLicenceTierCode() {
		return oldLicenceTierCode;
	}

	public void setOldLicenceTierCode(String oldLicenceTierCode) {
		this.oldLicenceTierCode = oldLicenceTierCode;
	}

	public String getNewLicenceTierCode() {
		return newLicenceTierCode;
	}

	public void setNewLicenceTierCode(String newLicenceTierCode) {
		this.newLicenceTierCode = newLicenceTierCode;
	}

	public List<Integer> getToDeleteFiles() {
		return toDeleteFiles;
	}

	public void setToDeleteFiles(List<Integer> toDeleteFiles) {
		this.toDeleteFiles = toDeleteFiles;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public List<TaBusinessOperationDto> getTaBusinessOperations() {
		return taBusinessOperations;
	}

	public void setTaBusinessOperations(List<TaBusinessOperationDto> taBusinessOperations) {
		this.taBusinessOperations = taBusinessOperations;
	}

	public List<TaBusinessOperationDto> getNewTaBusinessOperations() {
		return newTaBusinessOperations;
	}

	public void setNewTaBusinessOperations(List<TaBusinessOperationDto> newTaBusinessOperations) {
		this.newTaBusinessOperations = newTaBusinessOperations;
	}

	public List<Integer> getToDeletebusinessRows() {
		return toDeletebusinessRows;
	}

	public void setToDeletebusinessRows(List<Integer> toDeletebusinessRows) {
		this.toDeletebusinessRows = toDeletebusinessRows;
	}

	public LocalDate getNewTierStartDate() {
		return newTierStartDate;
	}

	public void setNewTierStartDate(LocalDate newTierStartDate) {
		this.newTierStartDate = newTierStartDate;
	}

	public LocalDate getMinDate() {
		return minDate;
	}

	public void setMinDate(LocalDate minDate) {
		this.minDate = minDate;
	}

	public Boolean getPendingSwitch() {
		return pendingSwitch;
	}

	public void setPendingSwitch(Boolean pendingSwitch) {
		this.pendingSwitch = pendingSwitch;
	}

}
