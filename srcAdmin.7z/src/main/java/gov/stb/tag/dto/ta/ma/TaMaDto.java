package gov.stb.tag.dto.ta.ma;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;

public class TaMaDto extends TaApplicationDto {

	private TaAnnualFilingDto filingDto;
	private Boolean hasMaToSubmit;
	private LocalDate asatDate;
	private BigDecimal capital;
	private BigDecimal totalAssets;
	private BigDecimal totalLiabilities;
	private BigDecimal netValue;
	private BigDecimal shortfall;
	private FileDto managementAccounts;
	private List<FileDto> otherDocuments;
	private TaNetValueShortfallDto shortfallDto;
	private LocalDate maxAsatDate;
	private Boolean isEdit;

	public TaMaDto() {
		super();
		this.hasMaToSubmit = true;
		this.maxAsatDate = LocalDate.now();
	}

	public static TaMaDto buildFromNew(Cache cache, TaFilingCondition filing, FileHelper fileHelper) {
		TaMaDto dto = new TaMaDto();
		if (filing == null) {
			dto.setHasMaToSubmit(Boolean.FALSE);
		} else {
			dto.setHasMaToSubmit(Boolean.TRUE);
			dto.setFilingDto(TaAnnualFilingDto.build(filing));
			dto.setManagementAccounts(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_MANAGEMENT_ACCOUNTS), fileHelper));
			dto.setApplicationStatus(new ListableDto(cache.getStatus(Codes.Statuses.TA_APP_NEW)));
		}
		return dto;
	}

	public static TaMaDto buildFromApplication(Cache cache, ApplicationHelper appHelper, WorkflowHelper workflowHelper, TaMaSubmission ma, TaNetValueShortfall shortfall,
			TaNetValueRectification rectification, FileHelper fileHelper) {
		TaMaDto dto = new TaMaDto();
		dto = dto.buildFromApplication(cache, appHelper, ma.getApplication(), dto);
		dto.setTotalAssets(ma.getTotalAssets());
		dto.setTotalLiabilities(ma.getTotalLiabilities());
		dto.setAsatDate(ma.getAsAtDate());
		dto.setCapital(ma.getPaidUpCapital());
		dto.setNetValue(ma.getNetValue());
		dto.setShortfall(ma.getShortfall());
		// setting director's resolution, bank statement, and other documents
		List<ApplicationFile> appFiles = new ArrayList<>(ma.getApplication().getApplicationFiles());
		List<FileDto> otherDocuments = new ArrayList<FileDto>();
		for (ApplicationFile appFile : appFiles) {
			if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_MANAGEMENT_ACCOUNTS)) {
				dto.setManagementAccounts(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			} else {
				otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			}
		}
		dto.setOtherDocuments(otherDocuments);
		if (ma.getTaFilingCondition() != null) {
			dto.setFilingDto(TaAnnualFilingDto.build(ma.getTaFilingCondition()));
		}
		if (shortfall != null) {
			dto.setShortfallDto(TaNetValueShortfallDto.buildFromNetValueShortfall(cache, workflowHelper, fileHelper, appHelper, shortfall, rectification, Boolean.TRUE));
		}
		return dto;
	}

	public TaAnnualFilingDto getFilingDto() {
		return filingDto;
	}

	public void setFilingDto(TaAnnualFilingDto filingDto) {
		this.filingDto = filingDto;
	}

	public Boolean getHasMaToSubmit() {
		return hasMaToSubmit;
	}

	public void setHasMaToSubmit(Boolean hasMaToSubmit) {
		this.hasMaToSubmit = hasMaToSubmit;
	}

	public LocalDate getAsatDate() {
		return asatDate;
	}

	public void setAsatDate(LocalDate asatDate) {
		this.asatDate = asatDate;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(BigDecimal totalAssets) {
		this.totalAssets = totalAssets;
	}

	public BigDecimal getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(BigDecimal totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public BigDecimal getNetValue() {
		return netValue;
	}

	public void setNetValue(BigDecimal netValue) {
		this.netValue = netValue;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public FileDto getManagementAccounts() {
		return managementAccounts;
	}

	public void setManagementAccounts(FileDto managementAccounts) {
		this.managementAccounts = managementAccounts;
	}

	public List<FileDto> getOtherDocuments() {
		return otherDocuments;
	}

	public void setOtherDocuments(List<FileDto> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

	public TaNetValueShortfallDto getShortfallDto() {
		return shortfallDto;
	}

	public void setShortfallDto(TaNetValueShortfallDto shortfallDto) {
		this.shortfallDto = shortfallDto;
	}

	public LocalDate getMaxAsatDate() {
		return maxAsatDate;
	}

	public void setMaxAsatDate(LocalDate maxAsatDate) {
		this.maxAsatDate = maxAsatDate;
	}

	public Boolean getIsEdit() { return isEdit; }

	public void setIsEdit(Boolean edit) { isEdit = edit; }
}
