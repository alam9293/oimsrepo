package gov.stb.tag.dto.ta.ma;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaMaSearchDto extends TaApplicationSearchDto {

    private Object[] filingTypes;

    public Object[] getFilingTypes() { return filingTypes; }

    public void setFilingTypes(Object[] filingTypes) { this.filingTypes = filingTypes; }
}
