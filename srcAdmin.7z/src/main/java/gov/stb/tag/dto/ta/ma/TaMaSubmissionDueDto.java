package gov.stb.tag.dto.ta.ma;

import java.time.LocalDate;

public class TaMaSubmissionDueDto {

	private LocalDate asatDate;
	private LocalDate dueDate;

	public LocalDate getAsatDate() {
		return asatDate;
	}

	public void setAsatDate(LocalDate asatDate) {
		this.asatDate = asatDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

}
