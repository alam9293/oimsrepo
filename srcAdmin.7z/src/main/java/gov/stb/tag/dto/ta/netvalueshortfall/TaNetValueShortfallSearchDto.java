package gov.stb.tag.dto.ta.netvalueshortfall;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.workflow.TaWorkflowSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaNetValueShortfallSearchDto extends TaWorkflowSearchDto {

	private String shortfallFor;
	private String shortfallStatus;
	private Object[] shortfallStatuses;
	private String rectificationStatus;
	private LocalDate rectificationDueDateFrom;
	private LocalDate rectificationDueDateTo;
	private String letterPendingIssuanceStatus;

	public String getShortfallFor() {
		return shortfallFor;
	}

	public void setShortfallFor(String shortfallFor) {
		this.shortfallFor = shortfallFor;
	}

	public String getShortfallStatus() {
		return shortfallStatus;
	}

	public void setShortfallStatus(String shortfallStatus) {
		this.shortfallStatus = shortfallStatus;
	}

	public Object[] getShortfallStatuses() {
		return shortfallStatuses;
	}

	public void setShortfallStatuses(Object[] shortfallStatuses) {
		this.shortfallStatuses = shortfallStatuses;
	}

	public String getRectificationStatus() {
		return rectificationStatus;
	}

	public void setRectificationStatus(String rectificationStatus) {
		this.rectificationStatus = rectificationStatus;
	}

	public LocalDate getRectificationDueDateFrom() {
		return rectificationDueDateFrom;
	}

	public void setRectificationDueDateFrom(LocalDate rectificationDueDateFrom) {
		this.rectificationDueDateFrom = rectificationDueDateFrom;
	}

	public LocalDate getRectificationDueDateTo() {
		return rectificationDueDateTo;
	}

	public void setRectificationDueDateTo(LocalDate rectificationDueDateTo) {
		this.rectificationDueDateTo = rectificationDueDateTo;
	}

	public String getLetterPendingIssuanceStatus() {
		return letterPendingIssuanceStatus;
	}

	public void setLetterPendingIssuanceStatus(String letterPendingIssuanceStatus) {
		this.letterPendingIssuanceStatus = letterPendingIssuanceStatus;
	}

}
