package gov.stb.tag.dto.ta.netvalueshortfall;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.workflow.WorkflowDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.repository.ta.TaRenewalRepository;

public class TaNetValueShortfallUpdateDto extends WorkflowDto {

	private Integer id;
	private LocalDate dueDate;
	private LocalDate extendedDueDate;
	private BigDecimal amount;
	private String shortfallTypeCode;
	private LocalDateTime createdDate;
	private String remarks;
	private String recommendationCode;
	private LocalDate letterIssuedDate;
	private TaNetValueShortfallUpdateDto linkedNetValueShortfall;
	private Boolean isParent;

	// tag to AA/MA details
	private List<TaNetValueShortfallAaOrMaDto> shortfallAaOrMa;

	// rectification details
	private Integer rectificationAppId;
	private String rectificationStatus;
	private LocalDate rectifiedDate;

	private Boolean isDueDateDerived;
	private Boolean disabledEdit;
	private Boolean enableRescind;
	private Boolean enableExtension;
	private String letterContent;
	private Boolean hasSystemGeneratedLetter;

	public static TaNetValueShortfallUpdateDto buildFromNetValueShortfall(Cache cache, WorkflowHelper workflowHelper, ApplicationHelper appHelper, TaNetValueShortfall shortfall,
			TaNetValueRectification rectification, TaRenewalRepository taRenewalRepository) {
		TaNetValueShortfallUpdateDto dto = new TaNetValueShortfallUpdateDto();
		dto = dto.buildFromWorkflow(cache, shortfall.getWorkflow(), dto, workflowHelper);
		dto.setId(shortfall.getId());
		dto.setAmount(shortfall.getAmount());
		dto.setDueDate(TaNetValueShortfallItemDto.calculateShortfallProjectedDuedate(cache, shortfall.getRectificationDueDate(), dto.getLicenceId(), taRenewalRepository));
		dto.setIsDueDateDerived(shortfall.getRectificationDueDate() == null);
		dto.setExtendedDueDate(shortfall.getExtendedDueDate());
		dto.setCreatedDate(shortfall.getCreatedDate());
		dto.setShortfallTypeCode(shortfall.getType().getCode());
		dto.setLetterIssuedDate(shortfall.getLetterIssuedDate());
		dto.setRemarks(shortfall.getRemarks());
		if (shortfall.getWorkflow().getLastAction().getRecommendation() != null) {
			dto.setRecommendationCode(shortfall.getWorkflow().getLastAction().getRecommendation().getCode());
		}

		dto.setShortfallAaOrMa(Lists.newArrayList());
		if (shortfall.getTaAaSubmission() != null) {
			dto.getShortfallAaOrMa().add(TaNetValueShortfallAaOrMaDto.buildFromAaOrMa(cache, shortfall.getTaAaSubmission(), null));
		} else if (shortfall.getTaMaSubmission() != null) {
			dto.getShortfallAaOrMa().add(TaNetValueShortfallAaOrMaDto.buildFromAaOrMa(cache, null, shortfall.getTaMaSubmission()));
		}

		dto.setRectificationStatus(shortfall.deriveRectificationStatus());
		if (rectification != null) {
			dto.setRectificationAppId(rectification.getApplication().getId());
			if (appHelper.hasFinalApproved(rectification.getApplication())) {
				dto.setRectifiedDate(rectification.getRectifiedDate());
			}
		}

		if (workflowHelper.hasFinalApprovedOrRejected(shortfall.getWorkflow())) {
			dto.setDisabledEdit(Boolean.TRUE);
			dto.setEnableExtension(Boolean.TRUE);
		} else {
			dto.setDisabledEdit(Boolean.FALSE);
			dto.setEnableExtension(Boolean.FALSE);
		}
		dto.setEnableRescind(workflowHelper.hasFinalApproved(shortfall.getWorkflow()));
		// disable extension if shortfall is fulfiled
		if (dto.getRectificationStatus().equalsIgnoreCase(Codes.Constants.YES)) {
			dto.setEnableExtension(Boolean.FALSE);
		}

		dto.setLetterContent(shortfall.getLetterContent());
		dto.setHasSystemGeneratedLetter(shortfall.getLetterContent() != null);

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getRecommendationCode() {
		return recommendationCode;
	}

	public void setRecommendationCode(String recommendationCode) {
		this.recommendationCode = recommendationCode;
	}

	public LocalDate getLetterIssuedDate() {
		return letterIssuedDate;
	}

	public void setLetterIssuedDate(LocalDate letterIssuedDate) {
		this.letterIssuedDate = letterIssuedDate;
	}

	public String getShortfallTypeCode() {
		return shortfallTypeCode;
	}

	public void setShortfallTypeCode(String shortfallTypeCode) {
		this.shortfallTypeCode = shortfallTypeCode;
	}

	public List<TaNetValueShortfallAaOrMaDto> getShortfallAaOrMa() {
		return shortfallAaOrMa;
	}

	public void setShortfallAaOrMa(List<TaNetValueShortfallAaOrMaDto> shortfallAaOrMa) {
		this.shortfallAaOrMa = shortfallAaOrMa;
	}

	public Integer getRectificationAppId() {
		return rectificationAppId;
	}

	public void setRectificationAppId(Integer rectificationAppId) {
		this.rectificationAppId = rectificationAppId;
	}

	public String getRectificationStatus() {
		return rectificationStatus;
	}

	public void setRectificationStatus(String rectificationStatus) {
		this.rectificationStatus = rectificationStatus;
	}

	public LocalDate getRectifiedDate() {
		return rectifiedDate;
	}

	public void setRectifiedDate(LocalDate rectifiedDate) {
		this.rectifiedDate = rectifiedDate;
	}

	public Boolean getDisabledEdit() {
		return disabledEdit;
	}

	public void setDisabledEdit(Boolean disabledEdit) {
		this.disabledEdit = disabledEdit;
	}

	public Boolean getEnableRescind() {
		return enableRescind;
	}

	public void setEnableRescind(Boolean enableRescind) {
		this.enableRescind = enableRescind;
	}

	public Boolean getIsDueDateDerived() {
		return isDueDateDerived;
	}

	public void setIsDueDateDerived(Boolean isDueDateDerived) {
		this.isDueDateDerived = isDueDateDerived;
	}

	public TaNetValueShortfallUpdateDto getLinkedNetValueShortfall() {
		return linkedNetValueShortfall;
	}

	public void setLinkedNetValueShortfall(TaNetValueShortfallUpdateDto linkedNetValueShortfall) {
		this.linkedNetValueShortfall = linkedNetValueShortfall;
	}

	public Boolean getIsParent() {
		return isParent;
	}

	public void setIsParent(Boolean isParent) {
		this.isParent = isParent;
	}

	public Boolean getEnableExtension() {
		return enableExtension;
	}

	public void setEnableExtension(Boolean enableExtension) {
		this.enableExtension = enableExtension;
	}

	public String getLetterContent() { return letterContent; }

	public void setLetterContent(String letterContent) { this.letterContent = letterContent; }

	public Boolean getHasSystemGeneratedLetter() { return hasSystemGeneratedLetter; }

	public void setHasSystemGeneratedLetter(Boolean hasSystemGeneratedLetter) { this.hasSystemGeneratedLetter = hasSystemGeneratedLetter; }
}
