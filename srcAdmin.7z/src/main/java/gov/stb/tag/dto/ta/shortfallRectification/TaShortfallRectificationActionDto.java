package gov.stb.tag.dto.ta.shortfallRectification;

import java.time.LocalDate;

import gov.stb.tag.dto.ApprovalDto;

public class TaShortfallRectificationActionDto extends ApprovalDto {

	private LocalDate rectifiedDate;

	public LocalDate getRectifiedDate() {
		return rectifiedDate;
	}

	public void setRectifiedDate(LocalDate rectifiedDate) {
		this.rectifiedDate = rectifiedDate;
	}

}
