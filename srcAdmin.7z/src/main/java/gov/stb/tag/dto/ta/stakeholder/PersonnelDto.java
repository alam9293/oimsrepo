package gov.stb.tag.dto.ta.stakeholder;

import gov.stb.tag.annotation.MapProjection;

public class PersonnelDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "stakeholder.isCompany")
	private Boolean isCompany;

	@MapProjection(path = "stakeholder.name")
	private String name;

	@MapProjection(path = "stakeholder.uin")
	private String uin;

	@MapProjection(path = "stakeholder.companyUen")
	private String uen;

	@MapProjection(path = "role.label")
	private String role;

	@MapProjection(path = "sharesHeld")
	private Integer sharesHeld;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getSharesHeld() {
		return sharesHeld;
	}

	public void setSharesHeld(Integer sharesHeld) {
		this.sharesHeld = sharesHeld;
	}

	public Boolean getIsCompany() {
		return isCompany;
	}

	public void setIsCompany(Boolean isCompany) {
		this.isCompany = isCompany;
	}

}
