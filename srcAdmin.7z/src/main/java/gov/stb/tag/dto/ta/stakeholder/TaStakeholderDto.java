package gov.stb.tag.dto.ta.stakeholder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.licence.TaLicenceDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;

public class TaStakeholderDto extends TaLicenceDto {

	private Integer taStakeholderId;

	private Integer sharesHeld;

	private LocalDate appointedDate;

	private LocalDate resignedDate;

	private Boolean keResignedAtFutureDate = Boolean.FALSE;

	private Boolean keAppointedAtFutureDate = Boolean.FALSE;

	private ListableDto role;

	private Boolean isKe;

	private LocalDate companyIncorporatedDate;

	// KE only
	private List<TaKeDeclarationsDto> taKeDeclarations;

	public static TaStakeholderDto buildTaStakeholderDtoFromTaStakeholderModel(Cache cache, TaStakeholder stakeholder, Boolean loadDeclarations, Boolean loadLicence) {
		TaStakeholderDto dto = new TaStakeholderDto();

		if (stakeholder != null) {
			dto.setTaStakeholderId(stakeholder.getId());
			dto.setSharesHeld(stakeholder.getSharesHeld());
			dto.setRole(stakeholder.getRole() != null ? new ListableDto(stakeholder.getRole().getKey(), cache.getLabel(stakeholder.getRole(), false)) : new ListableDto());
			dto.setAppointedDate(stakeholder.getAppointedDate());
			dto.setResignedDate(stakeholder.getResignedDate());
			dto.setIsKe(Codes.TaStakeholderRoles.STKHLD_KE.equals(stakeholder.getRole().getCode()));
			dto.setKeResignedAtFutureDate(checkIfKeResignedAtFutureDate(stakeholder.getResignedDate()));
			dto.setKeAppointedAtFutureDate(stakeholder.getAppointedDate() != null && stakeholder.getAppointedDate().isAfter(LocalDate.now()));
		}

		if (loadDeclarations) {
			List<TaKeDeclarationsDto> declarations = new ArrayList<>();
			for (TaKeDeclaration x : stakeholder.getTaKeDeclarations()) {
				declarations.add(TaKeDeclarationsDto.build(cache, x));
			}
			declarations.sort(Comparator.comparingInt(TaKeDeclarationsDto::getOrdinal));
			dto.setTaKeDeclarations(declarations);
		}
		if (loadLicence) {
			dto = dto.buildFromLicence(cache, stakeholder.getLicence(), dto);
		}

		return dto;
	}

	public static TaStakeholderDto buildFromTaStakeholder(Cache cache, TaStakeholderApplication stakeholder, Boolean loadDeclarations) {
		TaStakeholderDto dto = new TaStakeholderDto();

		if (stakeholder != null) {
			dto.setTaStakeholderId(stakeholder.getId());
			dto.setSharesHeld(stakeholder.getSharesHeld());
			dto.setRole(stakeholder.getRole() != null ? new ListableDto(stakeholder.getRole().getKey(), cache.getLabel(stakeholder.getRole(), false)) : new ListableDto());
			dto.setAppointedDate(stakeholder.getAppointedDate());
			dto.setResignedDate(stakeholder.getResignedDate());
			dto.setCompanyIncorporatedDate(stakeholder.getCompanyIncorporatedDate());
		}

		if (loadDeclarations) {
			List<TaKeDeclarationsDto> declarations = new ArrayList<>();
			for (TaKeDeclaration x : stakeholder.getTaKeDeclarations()) {
				declarations.add(TaKeDeclarationsDto.build(cache, x));
			}
			declarations.sort(Comparator.comparingInt(TaKeDeclarationsDto::getOrdinal));
			dto.setTaKeDeclarations(declarations);
		}

		return dto;
	}

	public Integer getTaStakeholderId() {
		return taStakeholderId;
	}

	public void setTaStakeholderId(Integer taStakeholderId) {
		this.taStakeholderId = taStakeholderId;
	}

	public Integer getSharesHeld() {
		return sharesHeld;
	}

	public void setSharesHeld(Integer sharesHeld) {
		this.sharesHeld = sharesHeld;
	}

	public LocalDate getAppointedDate() {
		return appointedDate;
	}

	public void setAppointedDate(LocalDate appointedDate) {
		this.appointedDate = appointedDate;
	}

	public LocalDate getResignedDate() {
		return resignedDate;
	}

	public void setResignedDate(LocalDate resignedDate) {
		this.resignedDate = resignedDate;
	}

	public ListableDto getRole() {
		return role;
	}

	public void setRole(ListableDto role) {
		this.role = role;
	}

	public List<TaKeDeclarationsDto> getTaKeDeclarations() {
		return taKeDeclarations;
	}

	public void setTaKeDeclarations(List<TaKeDeclarationsDto> taKeDeclarations) {
		this.taKeDeclarations = taKeDeclarations;
	}

	public Boolean getIsKe() {
		return isKe;
	}

	public void setIsKe(Boolean isKe) {
		this.isKe = isKe;
	}

	public Boolean getKeResignedAtFutureDate() {
		return keResignedAtFutureDate;
	}

	public void setKeResignedAtFutureDate(Boolean keResignedAtFutureDate) {
		this.keResignedAtFutureDate = keResignedAtFutureDate;
	}

	public Boolean getKeAppointedAtFutureDate() {
		return keAppointedAtFutureDate;
	}

	public void setKeAppointedAtFutureDate(Boolean keAppointedAtFutureDate) {
		this.keAppointedAtFutureDate = keAppointedAtFutureDate;
	}

	public static boolean checkIfKeResignedAtFutureDate(LocalDate resignedDate) {
		return resignedDate != null && !resignedDate.isBefore(LocalDate.now());
	}
	public LocalDate getCompanyIncorporatedDate() {
		return companyIncorporatedDate;
	}

	public void setCompanyIncorporatedDate(LocalDate companyIncorporatedDate) {
		this.companyIncorporatedDate = companyIncorporatedDate;
	}
}
