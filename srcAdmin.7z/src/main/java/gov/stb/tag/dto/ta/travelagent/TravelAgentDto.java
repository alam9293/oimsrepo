package gov.stb.tag.dto.ta.travelagent;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.util.DateUtil;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TravelAgentDto extends EntityDto {

	private String licenceNo;
	private String name;
	private String uen;
	private String status;
	private List<String> inboundServices;
	private List<String> outboundServices;
	private String emailAddress;
	private String contactNo;
	private String faxNo;
	private String licenceIssuedDate;
	private String operatingAddress;
	private String keName;
	private String keDesignation;
	private Integer operationYear;
	private String websiteUrl;
	private List<String> branches;
	private AddressDto operatingAddressDto;

	public TravelAgentDto() {

	}

	public static TravelAgentDto buildTravelAgentDto(Cache cache, TravelAgent travelAgent) {
		TravelAgentDto dto = new TravelAgentDto();
		dto.setLicenceNo(travelAgent.getLicence().getLicenceNo());
		dto.setName(travelAgent.getName());
		dto.setUen(travelAgent.getUen());
		dto.setStatus(travelAgent.getLicence().getStatus().getCode());
		dto.setEmailAddress(travelAgent.getEmailAddress());
		dto.setContactNo(travelAgent.getContactNo());
		dto.setLicenceIssuedDate(travelAgent.getLicence().getIssueDate().format(DateUtil.DATE_FORMAT));
		dto.setOperatingAddress(travelAgent.getOperatingAddress().getSingleLineAddressDisplay());
		dto.setWebsiteUrl(travelAgent.getWebsiteUrl());
		dto.setOperatingAddressDto(AddressDto.buildFromAddress(cache, travelAgent.getOperatingAddress()));

		return dto;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getInboundServices() {
		return inboundServices;
	}

	public void setInboundServices(List<String> inboundServices) {
		this.inboundServices = inboundServices;
	}

	public List<String> getOutboundServices() {
		return outboundServices;
	}

	public void setOutboundServices(List<String> outboundServices) {
		this.outboundServices = outboundServices;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getLicenceIssuedDate() {
		return licenceIssuedDate;
	}

	public void setLicenceIssuedDate(String licenceIssuedDate) {
		this.licenceIssuedDate = licenceIssuedDate;
	}

	public String getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(String operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public String getKeName() {
		return keName;
	}

	public void setKeName(String keName) {
		this.keName = keName;
	}

	public String getKeDesignation() {
		return keDesignation;
	}

	public void setKeDesignation(String keDesignation) {
		this.keDesignation = keDesignation;
	}

	public Integer getOperationYear() {
		return operationYear;
	}

	public void setOperationYear(Integer operationYear) {
		this.operationYear = operationYear;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public List<String> getBranches() {
		return branches;
	}

	public void setBranches(List<String> branches) {
		this.branches = branches;
	}

	public AddressDto getOperatingAddressDto() {
		return operatingAddressDto;
	}

	public void setOperatingAddressDto(AddressDto operatingAddressDto) {
		this.operatingAddressDto = operatingAddressDto;
	}

}
