package gov.stb.tag.dto.ta.travelagent;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TravelAgent;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TravelAgentItemDto {

	private String licenceNo;

	private String name;

	private String uen;

	private String address;

	private String type;

	private String phoneNo;

	private String emailAddress;

	private String websiteUrl;

	private String status;

	public TravelAgentItemDto() {

	}

	public static TravelAgentItemDto buildFromTravelAgent(Cache cache, TravelAgent ta) {

		TravelAgentItemDto dto = new TravelAgentItemDto();
		dto.setLicenceNo(ta.getLicence().getLicenceNo());
		dto.setName(ta.getName());
		dto.setUen(ta.getUen());
		dto.setWebsiteUrl(ta.getWebsiteUrl());
		dto.setPhoneNo(ta.getContactNo());
		dto.setEmailAddress(ta.getEmailAddress());
		dto.setAddress(ta.getOperatingAddress().toFormattedSingleLineAddress());
		dto.setWebsiteUrl(ta.getWebsiteUrl());

		var licence = ta.getLicence();
		dto.setType(cache.getLabel(licence.getTier(), false));
		dto.setStatus(licence.getStatus().getCode());

		return dto;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
