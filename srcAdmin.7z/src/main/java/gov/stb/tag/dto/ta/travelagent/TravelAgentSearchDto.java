package gov.stb.tag.dto.ta.travelagent;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TravelAgentSearchDto extends SearchDto {

	private String licenceNo;
	private String name;
	private String type;
	private List<String> service;
	private List<String> status;
	private String licenceName;
	private String mobileName;

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getService() {
		return service;
	}

	public void setService(List<String> service) {
		this.service = service;
	}

	public List<String> getStatus() {
		return status;
	}

	public void setStatus(List<String> status) {
		this.status = status;
	}

	public String getLicenceName() {
		return licenceName;
	}

	public void setLicenceName(String licenceName) {
		this.licenceName = licenceName;
	}

	public String getMobileName() {
		return mobileName;
	}

	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}

}
