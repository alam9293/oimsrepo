package gov.stb.tag.dto.test;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class TestDateDto {

	private LocalDateTime datetime;

	private LocalDate date;

	public LocalDateTime getDatetime() {
		return datetime;
	}

	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

}
