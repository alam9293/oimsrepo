package gov.stb.tag.dto.tg.application;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.tg.licence.TgLicenceDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgApplicationDto extends TgLicenceDto {

	private Integer applicationId;
	private String applicationNo;
	private String applicationType;
	private ListableDto applicationStatus;
	private LocalDateTime submissionDate;
	private String externalRemarks;
	private String billRefNo;
	private Boolean isPaymentSuccess;
	private boolean draft;
	private boolean isFinalApproval;
	private boolean isInLowestStep;
	private ListableDto licencePrintStatus;
	private Boolean isOfflineSubmission;

	private String approver;
	private LocalDateTime approvedDate;
	private ListableDto lastActionType;

	public TgApplicationDto() {

	}

	public TgApplicationDto(Cache cache, Application application, String billRefNo, Integer renewalId) {
		this.applicationId = renewalId;
		this.applicationNo = application.getApplicationNo();
		this.billRefNo = billRefNo;
	}

	public <T extends TgApplicationDto> T buildFromApplication(Cache cache, ApplicationHelper appHelper, Application app, T dto) {
		dto = dto.buildFromLicence(cache, app.getLicence(), dto);
		if (app.getId() != null) {
			dto.setIsOfflineSubmission(app.isOfflineSubmission());
			dto.setApplicationId(app.getId());
			dto.setApplicationNo(app.getApplicationNo());
			dto.setApplicationType(app.getType().getCode());
			dto.setIsFinalApproval(appHelper.isFinalApproval(app));
			dto.setIsInLowestStep(appHelper.isInLowestStep(null, app));
			if (app.getLastAction() != null) {
				dto.setApplicationStatus(new ListableDto(app.getLastAction().getStatus().getCode(), cache.getLabel(app.getLastAction().getStatus(), false),
						cache.getLabel(app.getLastAction().getStatus(), true), null, null));
				dto.setSubmissionDate(app.getSubmissionDate());
				dto.setExternalRemarks(app.getLastAction().getExternalRemarks());
				if (app.getLastAction().getStatus().getCode().equalsIgnoreCase(Statuses.TG_APP_APPROVED)) {
					dto.setApprover(app.getLastAction().getActionBy().getName());
					dto.setApprovedDate(app.getLastAction().getCreatedDate());
				}
				dto.setLastActionType(new ListableDto(app.getLastAction().getType()));
			}
			if (app.getIsDraft() != null) {
				dto.setDraft(app.getIsDraft());
			}
			if (app.getLicencePrintStatus() != null) {
				dto.setLicencePrintStatus(new ListableDto(app.getLicencePrintStatus().getCode(), cache.getLabel(app.getLicencePrintStatus(), true)));
			}

		}
		return dto;

	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public Boolean isPaymentSuccess() {
		return isPaymentSuccess;
	}

	public void setPaymentSuccess(Boolean isPaymentSuccess) {
		this.isPaymentSuccess = isPaymentSuccess;
	}

	public ListableDto getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(ListableDto applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public Boolean getPaymentSuccess() {
		return isPaymentSuccess;
	}

	public boolean isDraft() {
		return draft;
	}

	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	public boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	public void setIsFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public boolean getIsInLowestStep() {
		return isInLowestStep;
	}

	public void setIsInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public ListableDto getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(ListableDto licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}

	public Boolean getIsOfflineSubmission() {
		return isOfflineSubmission;
	}

	public void setIsOfflineSubmission(Boolean isOfflineSubmission) {
		this.isOfflineSubmission = isOfflineSubmission;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

	public ListableDto getLastActionType() { return lastActionType; }

	public void setLastActionType(ListableDto lastActionType) { this.lastActionType = lastActionType; }
}
