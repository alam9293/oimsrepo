package gov.stb.tag.dto.tg.application;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgApplicationItemDto {

	private boolean isWorkPassHolder;

	@MapProjection(path = "application.id")
	private Integer applicationId;

	@MapProjection(path = "application.applicationNo")
	private String applicationNo;

	private String applicationType;

	@MapProjection(path = "application.submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "application.licence.touristGuide.name")
	private String name;

	private String aliasName;
	private LocalDate dob;

	@MapProjection(path = "application.licence.touristGuide.uin")
	private String nric;

	private String nationality;
	private String salutation;
	private String sex;
	private String maritalStatus;
	private String race;
	private String birthCountry;
	private String residentialStatus;
	private String highestEduLevel;
	private String mobileNo;
	private String emailAddress;
	private String employerName;
	private String occupation;
	private String occupationOther;
	private String workPassType;
	private LocalDate workpassExpiryDate;

	private String regStreet;
	private String regBuilding;
	private String regBlock;
	private String regFloor;
	private String regUnit;
	private String regPostal;
	private String registeredAddress;

	private String optStreet;
	private String optBuilding;
	private String optBlock;
	private String optFloor;
	private String optUnit;
	private String optPostal;
	private String operatingAddress;

	private String regForeignLine1;
	private String regForeignLine2;
	private String regForeignLine3;

	private String optForeignLine1;
	private String optForeignLine2;
	private String optForeignLine3;

	private ListableDto status;
	private String statusRemark;
	private String guidingLanguage;
	private String areaSpecification;

	@MapProjection(path = "application.licence.id")
	private Integer licenceId;

	private String licenceType;

	@MapProjection(path = "application.licence.licenceNo")
	private String licenceNo;

	private String licenceStatus;
	private LocalDate licenceIssueDate;
	private LocalDate licenceStartDate;

	@MapProjection(path = "application.licence.expiryDate")
	private LocalDate licenceExpiryDate;

	private FileDto photo;
	private List<FileDto> otherSupportDocs;
	private List<WorkflowActionDto> workflowActions;

	private boolean isAddrSame;

	private boolean isFinalApproval;
	private boolean isInLowestStep;

	public <T extends TgApplicationItemDto> T buildFromApplication(Cache cache, Application application, T dto, ApplicationHelper appHelper, FileHelper fileHelper) {

		var licence = application.getLicence();
		var tg = licence.getTouristGuide();

		// licence
		dto.setLicenceId(licence.getId());
		dto.setLicenceType(application.getLicence().getTier().getLabel());
		dto.setLicenceIssueDate(licence.getIssueDate());
		dto.setLicenceNo(licence.getLicenceNo());
		dto.setLicenceStatus(cache.getLabel(licence.getStatus(), false));
		dto.setLicenceStartDate(licence.getStartDate());
		dto.setLicenceExpiryDate(licence.getExpiryDate());

		// tourist guide
		dto.setName(tg.getName());
		dto.setDob(tg.getDob());
		dto.setNric(tg.getUin());
		dto.setNationality(cache.getLabel(tg.getNationality(), true));
		dto.setSalutation(cache.getLabel(tg.getSalutation(), true));
		dto.setSex(cache.getLabel(tg.getSex(), true));
		dto.setMaritalStatus(tg.getMaritalStatus() != null ? cache.getLabel(tg.getMaritalStatus(), true) : null);
		dto.setRace(tg.getRace() != null ? cache.getLabel(tg.getRace(), true) : null);
		dto.setBirthCountry(cache.getLabel(tg.getBirthCountry(), true));
		dto.setResidentialStatus(cache.getLabel(tg.getResidentialStatus(), true));
		dto.setHighestEduLevel(cache.getLabel(tg.getHighestEduLevel(), true));
		dto.setMobileNo(tg.getMobileNo());
		dto.setEmailAddress(tg.getEmailAddress());
		dto.setEmployerName(tg.getEmployerName());
		dto.setOccupation(cache.getLabel(tg.getOccupation(), true));
		dto.setOccupationOther(tg.getOccupationOther());
		dto.setWorkPassType(tg.getWorkPassType() != null ? cache.getLabel(tg.getWorkPassType(), true) : null);
		dto.setWorkpassExpiryDate(tg.getWorkPassExpiryDate());
		dto.setAliasName(tg.getAliasName());
		dto.setRegisteredAddress(tg.getRegisteredAddress() != null ? tg.getRegisteredAddress().getAddressDisplay() : null);
		dto.setOperatingAddress(tg.getMailingAddress() != null ? tg.getMailingAddress().getAddressDisplay() : null);
		dto.setGuidingLanguage(tg.getGuidingLanguagesWithComma(cache));

		if (Codes.Types.TG_TIER_AREA.equals(tg.getLicence().getTier().getCode()) || Codes.Types.TG_TIER_GENERAL_AREA.equals(tg.getLicence().getTier().getCode())) {
			dto.setAreaSpecification(tg.getSpecializedAreasWithComma(cache));
		}

		var lastAction = application.getLastAction();
		if (lastAction != null) {
			var lastStatus = lastAction.getStatus();
			dto.setStatus(new ListableDto(lastStatus.getCode(), cache.getLabel(lastStatus, false)));
		}

		dto.setApplicationId(application.getId());
		dto.setApplicationNo(application.getApplicationNo());
		dto.setApplicationType(application.getType().getCode());
		dto.setSubmissionDate(application.getSubmissionDate());
		dto.setIsFinalApproval(appHelper.isFinalApproval(application));
		dto.setIsInLowestStep(appHelper.isInLowestStep(null, application));

		List<FileDto> othSuppDocs = new ArrayList<FileDto>();
		if (application.getApplicationFiles() != null) {
			for (ApplicationFile appFile : application.getApplicationFiles()) {
				if (Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(appFile.getDocumentType().getCode())) {
					dto.setPhoto(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
				} else {
					othSuppDocs.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
				}
			}
			dto.setOtherSupportDocs(othSuppDocs);
		}

		if (dto.getPhoto() == null && tg.getPhoto() != null) {
			dto.setPhoto(FileDto.buildFromFile(tg.getPhoto(), null, null));
		}

		return dto;
	}

	public <T extends TgApplicationItemDto> T populateAppStatus(Cache cache, Application application, T dto) {

		if (application != null) {
			var lastAction = application.getLastAction();
			dto.setApplicationNo(application.getApplicationNo());
			if (lastAction != null) {
				var lastStatus = lastAction.getStatus();
				dto.setStatus(new ListableDto(lastStatus.getCode(), cache.getLabel(lastStatus, true)));
				dto.setStatusRemark(lastAction.getExternalRemarks());
			}

		}
		return dto;
	}

	public boolean getIsWorkPassHolder() {
		return isWorkPassHolder;
	}

	public void setIsWorkPassHolder(boolean isWorkPassHolder) {
		this.isWorkPassHolder = isWorkPassHolder;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(String birthCountry) {
		this.birthCountry = birthCountry;
	}

	public String getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public String getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(String highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOccupationOther() {
		return occupationOther;
	}

	public void setOccupationOther(String occupationOther) {
		this.occupationOther = occupationOther;
	}

	public String getWorkPassType() {
		return workPassType;
	}

	public void setWorkPassType(String workPassType) {
		this.workPassType = workPassType;
	}

	public LocalDate getWorkpassExpiryDate() {
		return workpassExpiryDate;
	}

	public void setWorkpassExpiryDate(LocalDate workpassExpiryDate) {
		this.workpassExpiryDate = workpassExpiryDate;
	}

	public String getRegStreet() {
		return regStreet;
	}

	public void setRegStreet(String regStreet) {
		this.regStreet = regStreet;
	}

	public String getRegBuilding() {
		return regBuilding;
	}

	public void setRegBuilding(String regBuilding) {
		this.regBuilding = regBuilding;
	}

	public String getRegBlock() {
		return regBlock;
	}

	public void setRegBlock(String regBlock) {
		this.regBlock = regBlock;
	}

	public String getRegFloor() {
		return regFloor;
	}

	public void setRegFloor(String regFloor) {
		this.regFloor = regFloor;
	}

	public String getRegUnit() {
		return regUnit;
	}

	public void setRegUnit(String regUnit) {
		this.regUnit = regUnit;
	}

	public String getRegPostal() {
		return regPostal;
	}

	public void setRegPostal(String regPostal) {
		this.regPostal = regPostal;
	}

	public String getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(String registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public String getOptStreet() {
		return optStreet;
	}

	public void setOptStreet(String optStreet) {
		this.optStreet = optStreet;
	}

	public String getOptBuilding() {
		return optBuilding;
	}

	public void setOptBuilding(String optBuilding) {
		this.optBuilding = optBuilding;
	}

	public String getOptBlock() {
		return optBlock;
	}

	public void setOptBlock(String optBlock) {
		this.optBlock = optBlock;
	}

	public String getOptFloor() {
		return optFloor;
	}

	public void setOptFloor(String optFloor) {
		this.optFloor = optFloor;
	}

	public String getOptUnit() {
		return optUnit;
	}

	public void setOptUnit(String optUnit) {
		this.optUnit = optUnit;
	}

	public String getOptPostal() {
		return optPostal;
	}

	public void setOptPostal(String optPostal) {
		this.optPostal = optPostal;
	}

	public String getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(String operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public String getRegForeignLine1() {
		return regForeignLine1;
	}

	public void setRegForeignLine1(String regForeignLine1) {
		this.regForeignLine1 = regForeignLine1;
	}

	public String getRegForeignLine2() {
		return regForeignLine2;
	}

	public void setRegForeignLine2(String regForeignLine2) {
		this.regForeignLine2 = regForeignLine2;
	}

	public String getRegForeignLine3() {
		return regForeignLine3;
	}

	public void setRegForeignLine3(String regForeignLine3) {
		this.regForeignLine3 = regForeignLine3;
	}

	public String getOptForeignLine1() {
		return optForeignLine1;
	}

	public void setOptForeignLine1(String optForeignLine1) {
		this.optForeignLine1 = optForeignLine1;
	}

	public String getOptForeignLine2() {
		return optForeignLine2;
	}

	public void setOptForeignLine2(String optForeignLine2) {
		this.optForeignLine2 = optForeignLine2;
	}

	public String getOptForeignLine3() {
		return optForeignLine3;
	}

	public void setOptForeignLine3(String optForeignLine3) {
		this.optForeignLine3 = optForeignLine3;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getStatusRemark() {
		return statusRemark;
	}

	public void setStatusRemark(String statusRemark) {
		this.statusRemark = statusRemark;
	}

	public String getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(String guidingLanguage) {
		this.guidingLanguage = guidingLanguage;
	}

	public String getAreaSpecification() {
		return areaSpecification;
	}

	public void setAreaSpecification(String areaSpecification) {
		this.areaSpecification = areaSpecification;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public FileDto getPhoto() {
		return photo;
	}

	public void setPhoto(FileDto photo) {
		this.photo = photo;
	}

	public List<FileDto> getOtherSupportDocs() {
		return otherSupportDocs;
	}

	public void setOtherSupportDocs(List<FileDto> otherSupportDocs) {
		this.otherSupportDocs = otherSupportDocs;
	}

	public List<WorkflowActionDto> getWorkflowActions() {
		return workflowActions;
	}

	public void setWorkflowActions(List<WorkflowActionDto> workflowActions) {
		this.workflowActions = workflowActions;
	}

	public boolean isAddrSame() {
		return isAddrSame;
	}

	public void setAddrSame(boolean isAddrSame) {
		this.isAddrSame = isAddrSame;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(String licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public LocalDate getLicenceIssueDate() {
		return licenceIssueDate;
	}

	public void setLicenceIssueDate(LocalDate licenceIssueDate) {
		this.licenceIssueDate = licenceIssueDate;
	}

	public LocalDate getLicenceStartDate() {
		return licenceStartDate;
	}

	public void setLicenceStartDate(LocalDate licenceStartDate) {
		this.licenceStartDate = licenceStartDate;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	public void setIsFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public boolean getIsInLowestStep() {
		return isInLowestStep;
	}

	public void setIsInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

}
