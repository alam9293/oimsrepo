package gov.stb.tag.dto.tg.assignment;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgAssignmentDto extends EntityDto {

	private Integer tgAssignmentId;
	private LocalDate startDate;
	private LocalDate endDate;
	private ListableDto tourType;
	private String tourTypeOther;
	private ListableDto employmentSourceType;
	private String employmentSourceTypeOther;
	private String companyName;
	private String language;
	private BigDecimal feeReceived;
	private Set<TgAssignmentDateDto> tgAssignmentDates;
	private boolean isDeleted;

	public TgAssignmentDto() {

	}

	public Integer getTgAssignmentId() {
		return tgAssignmentId;
	}

	public void setTgAssignmentId(Integer tgAssignmentId) {
		this.tgAssignmentId = tgAssignmentId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public ListableDto getTourType() {
		return tourType;
	}

	public void setTourType(ListableDto tourType) {
		this.tourType = tourType;
	}

	public String getTourTypeOther() {
		return tourTypeOther;
	}

	public void setTourTypeOther(String tourTypeOther) {
		this.tourTypeOther = tourTypeOther;
	}

	public ListableDto getEmploymentSourceType() {
		return employmentSourceType;
	}

	public void setEmploymentSourceType(ListableDto employmentSourceType) {
		this.employmentSourceType = employmentSourceType;
	}

	public String getEmploymentSourceTypeOther() {
		return employmentSourceTypeOther;
	}

	public void setEmploymentSourceTypeOther(String employmentSourceTypeOther) {
		this.employmentSourceTypeOther = employmentSourceTypeOther;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public BigDecimal getFeeReceived() {
		return feeReceived;
	}

	public void setFeeReceived(BigDecimal feeReceived) {
		this.feeReceived = feeReceived;
	}

	public Set<TgAssignmentDateDto> getTgAssignmentDates() {
		return tgAssignmentDates;
	}

	public void setTgAssignmentDates(Set<TgAssignmentDateDto> tgAssignmentDates) {
		this.tgAssignmentDates = tgAssignmentDates;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
}
