package gov.stb.tag.dto.tg.assignment;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgAssignmentSearchDto extends SearchDto {

	private LocalDate startDate;
	private LocalDate endDate;
	private String tourType;
	private String companyName;
	private BigDecimal feeReceived;
	private LocalDateTime submissionDate;
	private boolean isDeleted;
	private boolean isCurrentCycle = false;
	private Integer year;

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getTourType() {
		return tourType;
	}

	public void setTourType(String tourType) {
		this.tourType = tourType;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public BigDecimal getFeeReceived() {
		return feeReceived;
	}

	public void setFeeReceived(BigDecimal feeReceived) {
		this.feeReceived = feeReceived;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public boolean isCurrentCycle() {
		return isCurrentCycle;
	}

	public void setIsCurrentCycle(boolean isCurrentCycle) {
		this.isCurrentCycle = isCurrentCycle;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

}
