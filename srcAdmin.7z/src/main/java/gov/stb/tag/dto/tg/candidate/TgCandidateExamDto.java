package gov.stb.tag.dto.tg.candidate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TgLicenceTierSwitch;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.tg.TgCandidateRepository;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCandidateExamDto extends EntityDto {

	private Integer resultId;

	// candidate last exam result
	private String name;
	private String email;
	private String specializedArea;
	private String guidingLanguage;
	private List<String> diGuidingLanguages;
	private String selectedItinerary; // A to N
	private String tier;

	private String isDirectIssuance;
	private LocalDate directIssuanceDate; // only for directIssuance

	private LocalDate examDate;
	private Integer tgTrainingProvider; // id
	private String remarks;
	private String chiefAssessor;
	private String deputyChiefAssessor;
	private String languageAssessor;
	private String result; // competent, non yet competent, absence

	private String specializedAreaLabel;
	private String selectedItineraryLabel;
	private String guidingLanguageLabel;
	private String diGuidingLanguagesLabel;
	private String resultLabel;
	private String tierLabel;
	private String tgTrainingProviderName;

	private String updatedBy;

	private List<FileDto> supportingDocs = new ArrayList<FileDto>();

	private Boolean isForSwitchTier;

	private String billRefNo;
	private String paymentStatus;

	private String switchTierBillRefNo;
	private String switchTierPaymentStatus;

	public TgCandidateExamDto() {

	}

	public TgCandidateExamDto(CacheHelper cache, TgCandidateResult result, PaymentHelper paymentHelper, Boolean buildResult, TgCandidateRepository repository) {
		if (result != null && buildResult) {
			this.resultId = result.getId();
			this.email = result.getEmail();
			this.name = result.getName();

			if (result.getSpecializedArea() != null) {
				this.specializedArea = result.getSpecializedArea().getCode();
				this.specializedAreaLabel = result.getSpecializedArea().getLabel();
			}

			if (result.getGuidingLanguage() != null) {
				this.guidingLanguage = result.getGuidingLanguage().getCode();
				this.guidingLanguageLabel = result.getGuidingLanguage().getLabel();
			}

			if (result.getTier() != null) {
				this.tier = result.getTier().getCode();
				this.tierLabel = result.getTier().getLabel();
			}

			if (result.getBillRefNo() != null) {
				PaymentRequest payReq = paymentHelper.getPaymentRequest(result.getBillRefNo());
				this.billRefNo = result.getBillRefNo();
				this.paymentStatus = payReq != null ? cache.getLabel(payReq.getStatus(), true) : null;
			}

			TgLicenceTierSwitch licenceTierSwitch = repository.getTgLicenceTierSwitchById(result.getId());
			if (licenceTierSwitch != null) {
				PaymentRequest payReq = paymentHelper.getPaymentRequest(licenceTierSwitch.getAppFeeBillRefNo());
				this.switchTierBillRefNo = licenceTierSwitch.getAppFeeBillRefNo();
				this.switchTierPaymentStatus = payReq != null ? cache.getLabel(payReq.getStatus(), true) : null;
			}

			if (result.getResult() != null) {
				this.result = result.getResult().getCode();
				this.resultLabel = result.getResult().getLabel();
			}

			if (result.getSelectedItinerary() != null) {
				this.selectedItinerary = result.getSelectedItinerary().getCode();
				this.selectedItineraryLabel = result.getSelectedItinerary().getLabel();
			}

			if (result.getDiGuidingLanguages() != null) {
				List<String> languageList = new ArrayList<>();
				for (Type language : result.getDiGuidingLanguages()) {
					languageList.add(language.getCode());
				}
				this.diGuidingLanguages = languageList;
				this.diGuidingLanguagesLabel = result.getDiGuidingLanguagesWithComma(cache);
			}

			this.isDirectIssuance = result.isDirectIssuance() != null ? result.isDirectIssuance().toString() : Boolean.FALSE.toString();
			this.directIssuanceDate = result.getDirectIssuanceDate();
			this.examDate = result.getExamDate();
			this.chiefAssessor = result.getChiefAssessor();
			this.deputyChiefAssessor = result.getDeputyChiefAssessor();
			this.languageAssessor = result.getAssessor();
			this.remarks = result.getRemarks();

			if (result.getTgTrainingProvider() != null) {
				this.tgTrainingProvider = result.getTgTrainingProvider().getId();
				this.tgTrainingProviderName = result.getTgTrainingProvider().getName();
			}

			this.updatedBy = result.getUpdatedBy();

			Set<File> resultFiles = result.getFiles();
			if (CollectionUtils.isNotEmpty(resultFiles)) {
				List<FileDto> otherDocuments = new ArrayList<FileDto>();
				for (File file : resultFiles) {
					otherDocuments.add(FileDto.buildFromFile(file, null, null));
				}

				if (otherDocuments != null && otherDocuments.size() > 0) {
					this.supportingDocs = otherDocuments;
				}
			}

			this.isForSwitchTier = result.isForSwitchTier();
		} else {
			this.name = result != null ? result.getName() : "";
		}
	}

	public Integer getResultId() { return resultId; }

	public void setResultId(Integer examId) {
		this.resultId = examId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String emailAddress) {
		this.email = emailAddress;
	}

	public LocalDate getExamDate() {
		return examDate;
	}

	public void setExamDate(LocalDate examDate) {
		this.examDate = examDate;
	}

	public String getSpecializedArea() {
		return specializedArea;
	}

	public void setSpecializedArea(String specializedAreas) {
		this.specializedArea = specializedAreas;
	}

	public String getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(String guidingLanguages) {
		this.guidingLanguage = guidingLanguages;
	}

	public List<String> getDiGuidingLanguages() {
		return diGuidingLanguages;
	}

	public void setDiGuidingLanguages(List<String> diGuidingLanguages) {
		this.diGuidingLanguages = diGuidingLanguages;
	}

	public String getDiGuidingLanguagesLabel() {
		return diGuidingLanguagesLabel;
	}

	public void setDiGuidingLanguagesLabel(String diGuidingLanguagesLabel) {
		this.diGuidingLanguagesLabel = diGuidingLanguagesLabel;
	}

	public Integer getTgTrainingProvider() {
		return tgTrainingProvider;
	}

	public void setTgTrainingProvider(Integer tgTrainingProvider) {
		this.tgTrainingProvider = tgTrainingProvider;
	}

	public String getTgTrainingProviderName() {
		return tgTrainingProviderName;
	}

	public void setTgTrainingProviderName(String tgTrainingProviderName) {
		this.tgTrainingProviderName = tgTrainingProviderName;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getSelectedItinerary() {
		return selectedItinerary;
	}

	public void setSelectedItinerary(String selectedItinerary) {
		this.selectedItinerary = selectedItinerary;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getChiefAssessor() {
		return chiefAssessor;
	}

	public void setChiefAssessor(String chiefAssessor) {
		this.chiefAssessor = chiefAssessor;
	}

	public String getDeputyChiefAssessor() {
		return deputyChiefAssessor;
	}

	public void setDeputyChiefAssessor(String deputyChiefAssessor) {
		this.deputyChiefAssessor = deputyChiefAssessor;
	}

	public String getLanguageAssessor() {
		return languageAssessor;
	}

	public void setLanguageAssessor(String languageAssessor) {
		this.languageAssessor = languageAssessor;
	}

	public String getIsDirectIssuance() {
		return isDirectIssuance;
	}

	public void setIsDirectIssuance(String directIssuance) {
		isDirectIssuance = directIssuance;
	}

	public LocalDate getDirectIssuanceDate() {
		return directIssuanceDate;
	}

	public void setDirectIssuanceDate(LocalDate directIssuanceDate) {
		this.directIssuanceDate = directIssuanceDate;
	}

	public String getSelectedItineraryLabel() {
		return selectedItineraryLabel;
	}

	public void setSelectedItineraryLabel(String selectedItineraryLabel) {
		this.selectedItineraryLabel = selectedItineraryLabel;
	}

	public String getSpecializedAreaLabel() {
		return specializedAreaLabel;
	}

	public void setSpecializedAreaLabel(String specializedAreaLabel) {
		this.specializedAreaLabel = specializedAreaLabel;
	}

	public String getGuidingLanguageLabel() {
		return guidingLanguageLabel;
	}

	public void setGuidingLanguageLabel(String guidingLanguageLabel) {
		this.guidingLanguageLabel = guidingLanguageLabel;
	}

	public String getResultLabel() {
		return resultLabel;
	}

	public void setResultLabel(String resultLabel) {
		this.resultLabel = resultLabel;
	}

	public String getTierLabel() {
		return tierLabel;
	}

	public void setTierLabel(String tierLabel) {
		this.tierLabel = tierLabel;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public List<FileDto> getSupportingDocs() {
		return supportingDocs;
	}

	public void setSupportingDocs(List<FileDto> supportingDocs) {
		this.supportingDocs = supportingDocs;
	}

	public Boolean getForSwitchTier() {
		return isForSwitchTier;
	}

	public void setForSwitchTier(Boolean forSwitchTier) {
		isForSwitchTier = forSwitchTier;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getSwitchTierBillRefNo() {
		return switchTierBillRefNo;
	}

	public String getSwitchTierPaymentStatus() {
		return switchTierPaymentStatus;
	}

	public void setSwitchTierBillRefNo(String switchTierBillRefNo) {
		this.switchTierBillRefNo = switchTierBillRefNo;
	}

	public void setSwitchTierPaymentStatus(String switchTierPaymentStatus) {
		this.switchTierPaymentStatus = switchTierPaymentStatus;
	}
}
