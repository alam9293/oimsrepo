package gov.stb.tag.dto.tg.candidate;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCandidateSearchDto extends SearchDto {

	private String uin;
	private String name;
	private String licenceNo;
	private Boolean isDirectIssuance;
	private String testLanguage;
	private String tier;
	private String specializedArea;
	private LocalDate examDateFrom;
	private LocalDate examDateTo;
	private String result;
	private Integer trainingProvider;
	private String trainingProviderName;

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public Boolean isDirectIssuance() {
		return isDirectIssuance;
	}

	public void setIsDirectIssuance(Boolean directIssuance) {
		isDirectIssuance = directIssuance;
	}

	public String getTestLanguage() {
		return testLanguage;
	}

	public void setTestLanguage(String testLanguage) {
		this.testLanguage = testLanguage;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getSpecializedArea() {
		return specializedArea;
	}

	public void setSpecializedArea(String specializedArea) {
		this.specializedArea = specializedArea;
	}

	public LocalDate getExamDateFrom() {
		return examDateFrom;
	}

	public void setExamDateFrom(LocalDate examDateFrom) {
		this.examDateFrom = examDateFrom;
	}

	public LocalDate getExamDateTo() {
		return examDateTo;
	}

	public void setExamDateTo(LocalDate examDateTo) {
		this.examDateTo = examDateTo;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Integer getTrainingProvider() {
		return trainingProvider;
	}

	public void setTrainingProvider(Integer trainingProvider) {
		this.trainingProvider = trainingProvider;
	}

	public String getTrainingProviderName() {
		return trainingProviderName;
	}

	public void setTrainingProviderName(String trainingProviderName) {
		this.trainingProviderName = trainingProviderName;
	}
}
