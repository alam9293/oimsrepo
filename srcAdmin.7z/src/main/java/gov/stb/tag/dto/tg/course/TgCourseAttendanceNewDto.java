package gov.stb.tag.dto.tg.course;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.FileDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseAttendanceNewDto extends EntityDto {

	private Integer tgCourseAssignmentId;
	private String courseCode;
	private LocalDate attendedDate;
	private LocalDate attendedEndDate;
	private Set<TgCourseAttendanceDetailDto> tgCourseAttendanceDetails;
	private List<FileDto> supportingDocs;

	public TgCourseAttendanceNewDto() {

	}

	public Integer getTgCourseAssignmentId() {
		return tgCourseAssignmentId;
	}

	public void setTgCourseAssignmentId(Integer tgCourseAssignmentId) {
		this.tgCourseAssignmentId = tgCourseAssignmentId;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public LocalDate getAttendedDate() {
		return attendedDate;
	}

	public void setAttendedDate(LocalDate attendedDate) {
		this.attendedDate = attendedDate;
	}

	public void setCourseDate(LocalDate courseDate) {
		this.attendedDate = courseDate;
	}

	public LocalDate getAttendedEndDate() {
		return attendedEndDate;
	}

	public void setAttendedEndDate(LocalDate attendedEndDate) {
		this.attendedEndDate = attendedEndDate;
	}

	public void setCourseEndDate(LocalDate courseEndDate) {
		this.attendedEndDate = courseEndDate;
	}

	public Set<TgCourseAttendanceDetailDto> getTgCourseAttendanceDetails() {
		return tgCourseAttendanceDetails;
	}

	public void setTgCourseAttendanceDetails(Set<TgCourseAttendanceDetailDto> tgCourseAttendanceDetails) {
		this.tgCourseAttendanceDetails = tgCourseAttendanceDetails;
	}

	public void setAttendeeRows(Set<TgCourseAttendanceDetailDto> attendeeRows) {
		this.tgCourseAttendanceDetails = attendeeRows;
	}

	public List<FileDto> getSupportingDocs() {
		return supportingDocs;
	}

	public void setSupportingDocs(List<FileDto> supportingDocs) {
		this.supportingDocs = supportingDocs;
	}

}
