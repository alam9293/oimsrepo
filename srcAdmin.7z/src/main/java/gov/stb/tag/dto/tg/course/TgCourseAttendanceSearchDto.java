package gov.stb.tag.dto.tg.course;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.Type;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseAttendanceSearchDto extends SearchDto {

	private String courseCode;
	private String courseName;
	private LocalDate courseDate;
	private Type language;
	private String type;
	// private boolean adhoc; //use to verify if course is created for specific TG
	// private LocalDate approvedStartDate;
	// private LocalDate approvedEndDate;
	private BigDecimal noOfHours;
	private List<Integer> tgTrainingProviderIds;
	private List<String> categoryTypeCodes;
	private List<String> languageTypeCodes;
	private TgTrainingProvider tgTrainingProvider;
	private Set<TgCourseAttendance> tgCourseAttendances;
	private Integer year;
	private LocalDate startDate;
	private LocalDate endDate;

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public LocalDate getCourseDate() {
		return courseDate;
	}

	public void setCourseDate(LocalDate courseDate) {
		this.courseDate = courseDate;
	}

	public Type getLanguage() {
		return language;
	}

	public void setLanguage(Type language) {
		this.language = language;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

	public TgTrainingProvider getTgTrainingProvider() {
		return tgTrainingProvider;
	}

	public void setTgTrainingProvider(TgTrainingProvider tgTrainingProvider) {
		this.tgTrainingProvider = tgTrainingProvider;
	}

	public Set<TgCourseAttendance> getTgCourseAttendances() {
		return tgCourseAttendances;
	}

	public void setTgCourseAttendances(Set<TgCourseAttendance> tgCourseAttendances) {
		this.tgCourseAttendances = tgCourseAttendances;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public List<Integer> getTgTrainingProviderIds() {
		return tgTrainingProviderIds;
	}

	public void setTgTrainingProviderIds(List<Integer> tgTrainingProviderIds) {
		this.tgTrainingProviderIds = tgTrainingProviderIds;
	}

	public List<String> getCategoryTypeCodes() {
		return categoryTypeCodes;
	}

	public void setCategoryTypeCodes(List<String> categoryTypeCodes) {
		this.categoryTypeCodes = categoryTypeCodes;
	}

	public List<String> getLanguageTypeCodes() {
		return languageTypeCodes;
	}

	public void setLanguageTypeCodes(List<String> languageTypeCodes) {
		this.languageTypeCodes = languageTypeCodes;
	}

}
