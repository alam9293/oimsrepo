package gov.stb.tag.dto.tg.course;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgCourseAttendanceDetail;
import gov.stb.tag.model.TgTrainingProvider;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseResultDto {

	private Integer attendanceId;
	private Integer tpId;
	private String tpName;
	private String courseCode;
	private String courseName;
	private Integer tgCourseAttendanceId;
	private String language;
	private LocalDate attendedDate;
	private LocalDate attendedEndDate;
	private LocalDate completionDate;
	private Integer score;
	private Integer maxScore;
	private String result;
	private Integer noOfParticipants;
	private LocalDate submissionDate;
	private String attendance;
	private BigDecimal noOfHours;
	private BigDecimal scoreInPercent;
	private String categoryLabel;

	public TgCourseResultDto() {

	}

	public static TgCourseResultDto buildFromAssignment(Cache cache, TgCourse tc) {
		TgCourseResultDto tcDto = new TgCourseResultDto();
		tcDto.setCourseCode(tc.getCode());
		tcDto.setCourseName(tc.getName());
		tcDto.setLanguage(cache.getLabel(tc.getLanguage(), false));
		return tcDto;
	}

	public static TgCourseResultDto setListOfCourseDetails(Cache cache, TgCourseAttendance tca) {
		TgCourseResultDto tcDto = new TgCourseResultDto();
		tcDto.setTgCourseAttendanceId(tca.getId());
		tcDto.setCourseName(tca.getTgCourse().getName());
		tcDto.setCourseCode(tca.getTgCourse().getCode());
		tcDto.setAttendedDate(tca.getAttendedDate());
		tcDto.setAttendedEndDate(tca.getAttendedEndDate());
		tcDto.setNoOfParticipants((int) tca.getTgCourseAttendanceDetails().stream().filter(u -> !u.isDeleted()).count());
		tcDto.setSubmissionDate(tca.getCreatedDate().toLocalDate());
		return tcDto;
	}

	public static TgCourseResultDto setListOfTgCourse(Cache cache, TgCourseAttendance tca) {
		TgCourse course = tca.getTgCourse();

		TgCourseResultDto tcDto = new TgCourseResultDto();
		tcDto.setCourseCode(course.getCode());
		tcDto.setTgCourseAttendanceId(tca.getId());
		TgTrainingProvider tp = course.getTgTrainingProvider();
		tcDto.setTpId(tp.getId());
		tcDto.setTpName(tp.getName());
		tcDto.setCourseName(course.getName());
		tcDto.setLanguage(cache.getLabel(course.getLanguage(), false));
		tcDto.setAttendedDate(tca.getAttendedDate());
		tcDto.setAttendedEndDate(tca.getAttendedEndDate());

		tcDto.setNoOfHours(course.getNoOfHours());
		int score = 0, maxScore = 0;
		LocalDate completionDate = tca.getAttendedDate();
		BigDecimal scoreInPercent = new BigDecimal(0);
		String result = "", attendance = "";
		for (TgCourseAttendanceDetail tcad : tca.getTgCourseAttendanceDetails()) {
			if (tcad.getScore() != null) {
				score = tcad.getScore();
				scoreInPercent = tcad.getScoreInPercent();
			}
			if (tcad.getMaxScore() != null) {
				maxScore = tcad.getMaxScore();
			}
			if (tcad.getResult() != null) {
				result = cache.getLabel(tcad.getResult(), false);
			}
			if (tcad.getAttendance() != null) {
				attendance = cache.getLabel(tcad.getAttendance(), false);
			}
			if (tcad.getCompletionDate() != null) {
				completionDate = tcad.getCompletionDate();
			}
			break;
		}
		// = tca.getTgCourseAttendanceDetails().toArray(TgCourseAttendanceDetails).getScore();
		tcDto.setCompletionDate(completionDate);
		tcDto.setScore(score);
		tcDto.setMaxScore(maxScore);
		tcDto.setScoreInPercent(scoreInPercent);
		tcDto.setResult(result);
		tcDto.setAttendance(attendance);
		tcDto.setCategoryLabel(course.getCategory() != null ? course.getCategory().getLabel() : null);
		return tcDto;
	}

	public Integer getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(Integer attendanceId) {
		this.attendanceId = attendanceId;
	}

	public Integer getTpId() {
		return tpId;
	}

	public void setTpId(Integer tpId) {
		this.tpId = tpId;
	}

	public String getTpName() {
		return tpName;
	}

	public void setTpName(String tpName) {
		this.tpName = tpName;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Integer getTgCourseAttendanceId() {
		return tgCourseAttendanceId;
	}

	public void setTgCourseAttendanceId(Integer tgCourseAttendanceId) {
		this.tgCourseAttendanceId = tgCourseAttendanceId;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public LocalDate getAttendedDate() {
		return attendedDate;
	}

	public void setAttendedDate(LocalDate attendedDate) {
		this.attendedDate = attendedDate;
	}

	public LocalDate getAttendedEndDate() {
		return attendedEndDate;
	}

	public void setAttendedEndDate(LocalDate attendedEndDate) {
		this.attendedEndDate = attendedEndDate;
	}

	public LocalDate getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(LocalDate completionDate) {
		this.completionDate = completionDate;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(Integer maxScore) {
		this.maxScore = maxScore;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Integer getNoOfParticipants() {
		return noOfParticipants;
	}

	public void setNoOfParticipants(Integer noOfParticipants) {
		this.noOfParticipants = noOfParticipants;
	}

	public LocalDate getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDate submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getAttendance() {
		return attendance;
	}

	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

	public BigDecimal getScoreInPercent() {
		return scoreInPercent;
	}

	public void setScoreInPercent(BigDecimal scoreInPercent) {
		this.scoreInPercent = scoreInPercent;
	}

	public String getCategoryLabel() {
		return categoryLabel;
	}

	public void setCategoryLabel(String categoryLabel) {
		this.categoryLabel = categoryLabel;
	}

}
