package gov.stb.tag.dto.tg.course;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseSearchDto extends SearchDto {

	private String name;

	private LocalDate approvedStartDate;

	private LocalDate approvedEndDate;

	private String categoryCode;

	private String languageCode;

	private BigDecimal noOfHours;

	private String typeCode;

	private Integer trainingProviderId;

	private String trainingProviderName;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getApprovedStartDate() {
		return approvedStartDate;
	}

	public void setApprovedStartDate(LocalDate approvedStartDate) {
		this.approvedStartDate = approvedStartDate;
	}

	public LocalDate getApprovedEndDate() {
		return approvedEndDate;
	}

	public void setApprovedEndDate(LocalDate approvedEndDate) {
		this.approvedEndDate = approvedEndDate;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public Integer getTrainingProviderId() {
		return trainingProviderId;
	}

	public void setTrainingProviderId(Integer trainingProviderId) {
		this.trainingProviderId = trainingProviderId;
	}

	public String getTrainingProviderName() {
		return trainingProviderName;
	}

	public void setTrainingProviderName(String trainingProviderName) {
		this.trainingProviderName = trainingProviderName;
	}

}
