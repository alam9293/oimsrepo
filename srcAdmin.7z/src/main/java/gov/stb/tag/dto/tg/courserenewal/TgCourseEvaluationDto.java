package gov.stb.tag.dto.tg.courserenewal;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.TgCourseCriteria;
import gov.stb.tag.model.TgCourseEvaluation;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseEvaluationDto extends EntityDto {

	private Integer id;
	private Integer tgCourseCriteriaId;
	private String criteria;
	private Integer rating;
	private BigDecimal weightage;
	private List<ListableDto> ratings;

	public static TgCourseEvaluationDto buildFromTgCourseCriteria(TgCourseCriteria tgCourseCriteria) {
		TgCourseEvaluationDto dto = new TgCourseEvaluationDto();
		dto.setTgCourseCriteriaId(tgCourseCriteria.getId());
		dto.setCriteria(tgCourseCriteria.getCriteria());
		setRatings(dto, tgCourseCriteria);

		return dto;
	}

	public static TgCourseEvaluationDto buildFromTgCourseEvaluation(TgCourseEvaluation tgCourseEvaluation) {
		TgCourseEvaluationDto dto = new TgCourseEvaluationDto();
		dto.setTgCourseCriteriaId(tgCourseEvaluation.getTgCourseCriteria().getId());
		dto.setCriteria(tgCourseEvaluation.getTgCourseCriteria().getCriteria());
		setRatings(dto, tgCourseEvaluation.getTgCourseCriteria());
		dto.setRating(tgCourseEvaluation.getRating());
		dto.setWeightage(tgCourseEvaluation.getWeightage());
		return dto;
	}

	private static void setRatings(TgCourseEvaluationDto dto, TgCourseCriteria tgCourseCriteria) {
		dto.setRatings(Lists.newArrayList());
		dto.getRatings().add(new ListableDto(5, "Rating 5", null, tgCourseCriteria.getWeightage5(), null));
		dto.getRatings().add(new ListableDto(4, "Rating 4", null, tgCourseCriteria.getWeightage4(), null));
		dto.getRatings().add(new ListableDto(3, "Rating 3", null, tgCourseCriteria.getWeightage3(), null));
		dto.getRatings().add(new ListableDto(2, "Rating 2", null, tgCourseCriteria.getWeightage2(), null));
		dto.getRatings().add(new ListableDto(1, "Rating 1", null, tgCourseCriteria.getWeightage1(), null));
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTgCourseCriteriaId() {
		return tgCourseCriteriaId;
	}

	public void setTgCourseCriteriaId(Integer tgCourseCriteriaId) {
		this.tgCourseCriteriaId = tgCourseCriteriaId;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public BigDecimal getWeightage() {
		return weightage;
	}

	public void setWeightage(BigDecimal weightage) {
		this.weightage = weightage;
	}

	public List<ListableDto> getRatings() {
		return ratings;
	}

	public void setRatings(List<ListableDto> ratings) {
		this.ratings = ratings;
	}

}
