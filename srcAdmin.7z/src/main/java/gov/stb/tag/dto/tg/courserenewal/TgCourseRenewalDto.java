package gov.stb.tag.dto.tg.courserenewal;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.tg.application.TgApplicationDto;
import gov.stb.tag.dto.tg.course.TgCourseDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.TgCourseHelper;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseRenewal;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseRenewalDto extends TgApplicationDto {

	private Integer id;
	private TgCourseDto tgCourse;
	private TgCourseDto renewedTgCourse;
	private List<TgCourseEvaluationDto> evaluations;
	private String remarks;
	private List<FileDto> docs;

	public TgCourseRenewalDto() {

	}

	public static void buildFromTgCourseRenewal(TgCourseRenewal tgCourseRenewal, TgCourseRenewalDto dto, Cache cache, ApplicationHelper appHelper, TgCourseHelper tgCourseHelper,
			FileHelper fileHelper) {
		dto.buildFromApplication(cache, appHelper, tgCourseRenewal.getApplication(), dto);
		dto.setId(tgCourseRenewal.getId());
		dto.setRemarks(tgCourseRenewal.getRemarks());
		TgCourse renewalCourse = tgCourseRenewal.getTgCourse();
		dto.setTgCourse(tgCourseHelper.getTgCourseByCode(renewalCourse.getCode()));
		TgCourse nextCycleTgCourse = tgCourseHelper.getNextCycleTgCourse(renewalCourse);
		if (nextCycleTgCourse != null) {
			dto.setRenewedTgCourse(tgCourseHelper.getTgCourseByCode(nextCycleTgCourse.getCode()));
		}
		dto.setEvaluations(Lists.newArrayList());
		tgCourseRenewal.getTgCourseEvaluation().forEach(eval -> {
			dto.getEvaluations().add(TgCourseEvaluationDto.buildFromTgCourseEvaluation(eval));
		});

		dto.setDocs(Lists.newArrayList());
		tgCourseRenewal.getApplication().getApplicationFiles().forEach(appFile -> {
			dto.getDocs().add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
		});
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TgCourseDto getTgCourse() {
		return tgCourse;
	}

	public void setTgCourse(TgCourseDto tgCourse) {
		this.tgCourse = tgCourse;
	}

	public List<TgCourseEvaluationDto> getEvaluations() {
		return evaluations;
	}

	public void setEvaluations(List<TgCourseEvaluationDto> evaluations) {
		this.evaluations = evaluations;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public List<FileDto> getDocs() {
		return docs;
	}

	public void setDocs(List<FileDto> docs) {
		this.docs = docs;
	}

	public TgCourseDto getRenewedTgCourse() {
		return renewedTgCourse;
	}

	public void setRenewedTgCourse(TgCourseDto renewedTgCourse) {
		this.renewedTgCourse = renewedTgCourse;
	}

}
