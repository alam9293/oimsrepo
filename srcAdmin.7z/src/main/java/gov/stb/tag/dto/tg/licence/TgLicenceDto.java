package gov.stb.tag.dto.tg.licence;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TouristGuide;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceDto extends EntityDto {

	private String name;
	private String uin;
	private Integer licenceId;
	private String licenceNo;
	private Integer tgId;
	private LocalDate issueDate;
	private LocalDate effectiveStartDate;
	private LocalDate effectiveEndDate;
	private LocalDate ceasedDate;
	private String licenceStatusCode;
	private ListableDto licenceStatus;
	private ListableDto licenceTier;
	private Boolean isStatusUpdate;
	private Boolean hasPersonUpdateAccess;
	private String internalRemarks;
	private String tgIdString;
	private Object data; // to facilitate mapping of additional data
	private String areaSpecification;
	private Boolean hasPassedOn;
	private String displayName;
	private String displayEmployerName;
	private String displaySecondEmployerName;
	private String displaySecondName;

	public static <T extends TgLicenceDto> T buildFromLicence(Cache cache, Licence licence, T dto) {
		if (licence != null) {
			TouristGuide tg = licence.getTouristGuide();
			dto.setName(tg.getName());
			dto.setUin(tg.getUin());
			dto.setLicenceId(licence.getId());
			dto.setLicenceNo(licence.getLicenceNo());
			dto.setTgId(tg.getId());
			dto.setIssueDate(licence.getIssueDate());
			dto.setEffectiveStartDate(licence.getStartDate());
			dto.setEffectiveEndDate(licence.getExpiryDate());
			dto.setCeasedDate(licence.getCeasedDate());
			dto.setLicenceStatus(
					new ListableDto(licence.getStatus().getCode(), cache.getLabel(licence.getStatus(), false), cache.getLabel(licence.getStatus(), true), licence.isPendingCessation(), null));
			dto.setLicenceTier(new ListableDto(licence.getTier().getCode(), cache.getLabel(licence.getTier(), false)));
			dto.setTgIdString(licence.getTouristGuide().getId().toString());
			if (Codes.Types.TG_TIER_AREA.equals(licence.getTier().getCode()) || Codes.Types.TG_TIER_GENERAL_AREA.equals(licence.getTier().getCode())) {
				Set<String> specializedAreaSet = new HashSet<>();
				if (tg.getSpecializedAreas() != null) {
					specializedAreaSet.addAll(tg.getSpecializedAreas().stream().map(u -> cache.getLabel(u, true)).collect(Collectors.toSet()));
				}
				dto.setAreaSpecification(StringUtils.join(specializedAreaSet, " / "));
			}
			dto.setData(false);
		}
		return dto;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public Integer getTgId() {
		return tgId;
	}

	public void setTgId(Integer tgId) {
		this.tgId = tgId;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(LocalDate effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public LocalDate getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(LocalDate effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	public String getLicenceStatusCode() {
		return licenceStatusCode;
	}

	public void setLicenceStatusCode(String licenceStatusCode) {
		this.licenceStatusCode = licenceStatusCode;
	}

	public ListableDto getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(ListableDto licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public ListableDto getLicenceTier() {
		return licenceTier;
	}

	public void setLicenceTier(ListableDto licenceTier) {
		this.licenceTier = licenceTier;
	}

	public Boolean getIsStatusUpdate() {
		return isStatusUpdate;
	}

	public void setIsStatusUpdate(Boolean isStatusUpdate) {
		this.isStatusUpdate = isStatusUpdate;
	}

	public Boolean getHasPersonUpdateAccess() {
		return hasPersonUpdateAccess;
	}

	public void setHasPersonUpdateAccess(Boolean hasPersonUpdateAccess) {
		this.hasPersonUpdateAccess = hasPersonUpdateAccess;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public String getTgIdString() {
		return tgIdString;
	}

	public void setTgIdString(String tgIdString) {
		this.tgIdString = tgIdString;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getAreaSpecification() {
		return areaSpecification;
	}

	public void setAreaSpecification(String areaSpecification) {
		this.areaSpecification = areaSpecification;
	}

	public Boolean getHasPassedOn() {
		return hasPassedOn;
	}

	public void setHasPassedOn(Boolean hasPassedOn) {
		this.hasPassedOn = hasPassedOn;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayEmployerName() {
		return displayEmployerName;
	}

	public void setDisplayEmployerName(String displayEmployerName) {
		this.displayEmployerName = displayEmployerName;
	}

	public String getDisplaySecondEmployerName() {
		return displaySecondEmployerName;
	}

	public void setDisplaySecondEmployerName(String displaySecondEmployerName) {
		this.displaySecondEmployerName = displaySecondEmployerName;
	}

	public String getDisplaySecondName() {
		return displaySecondName;
	}

	public void setDisplaySecondName(String displaySecondName) {
		this.displaySecondName = displaySecondName;
	}
}
