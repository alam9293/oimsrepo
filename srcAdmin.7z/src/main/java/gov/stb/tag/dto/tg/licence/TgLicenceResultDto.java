package gov.stb.tag.dto.tg.licence;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Objects;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.User;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceResultDto {

	private Integer licenceId;
	private Boolean isPortalId;
	private String licenceNo = "";
	private String licenceType = "";
	private LocalDate issueDate;
	private LocalDate startDate;
	private LocalDate expiryDate;
	private String licenceStatus = "";
	private String licenceStatusCode = "";
	private String salutation = "";
	private String name = "";
	private String nric = "";
	private String aliasName = "";
	private String sex = "";
	private LocalDate dob;
	private String birthCountry = "";
	private String nationality = "";
	private String race = "";
	private String maritalStatus = "";
	private String language = "";
	private String highestEduLevel = "";
	private String mobileNo = "";
	private String emailAddress = "";
	private String residentialStatus = "";
	private String residentialStatusCode = "";
	private String employerName = "";
	private String occupation = "";
	private String occupationCode = "";
	private String occupationOther = "";
	private String workPassType = "";
	private String workPassTypeCode = "";
	private LocalDate workPassExpiryDate;
	private boolean isWorkPassHolder = false;
	private String registeredAddress = "";
	private String mailingAddress = "";
	private boolean isSameAddress;
	private LocalDate ceasedDate; // the date the licence was ceased
	private FileDto photo;
	private List<ListableDto> licenceStatuses;
	private Boolean hasPersonUpdateAccess;
	private String areaSpecification = "";
	private Boolean isMyInfoPopulated;
	private Boolean hasPassedOn;
	private String displayEmployerName;
	private String displayName;
	private String displaySecondEmployerName;
	private String displaySecondName;
	private String licenceTypeCode = "";

	public TgLicenceResultDto() {

	}

	public static TgLicenceResultDto buildListAllPage(Cache cache, Licence l) {
		TgLicenceResultDto tlDto = new TgLicenceResultDto();
		tlDto.setLicenceId(l.getId());
		tlDto.setLicenceNo(l.getLicenceNo());
		tlDto.setName(l.getTouristGuide().getName());
		tlDto.setLicenceType(cache.getLabel(l.getTier(), false));
		tlDto.setIssueDate(l.getIssueDate());
		tlDto.setStartDate(l.getStartDate());
		tlDto.setExpiryDate(l.getExpiryDate());
		tlDto.setLicenceStatus(cache.getLabel(l.getStatus(), false));
		tlDto.setLanguage(l.getTouristGuide().getGuidingLanguagesWithComma(cache));
		tlDto.setWorkPassExpiryDate(l.getTouristGuide().getWorkPassExpiryDate());
		return tlDto;
	}

	public static TgLicenceResultDto buildSinglePage(Cache cache, Licence licence, UserHelper userHelper, LicenceHelper licenceHelper) {
		TouristGuide tg = licence.getTouristGuide();
		User user = tg.getUser();

		TgLicenceResultDto tlDto = new TgLicenceResultDto();
		tlDto.setLicenceId(licence.getId());
		tlDto.setIsPortalId(user != null ? Codes.UserTypes.USER_PUBLIC_PORTAL.equals(user.getType().getKey()) : false);
		tlDto.setLicenceNo(licence.getLicenceNo());
		tlDto.setLicenceType((licence.getTier() != null) ? cache.getLabel(licence.getTier(), false) : "");
		tlDto.setIssueDate(licence.getIssueDate());
		tlDto.setStartDate(licence.getStartDate());
		tlDto.setExpiryDate(licence.getExpiryDate());
		tlDto.setLicenceStatus(licence.getStatus() != null ? cache.getLabel(licence.getStatus(), false) : "");
		tlDto.setLicenceStatusCode(licence.getStatus() != null ? licence.getStatus().getCode() : "");
		tlDto.setSalutation((tg.getSalutation() != null) ? cache.getLabel(tg.getSalutation(), false) : "");
		tlDto.setName(tg.getName());
		tlDto.setNric(tg.getUin());
		tlDto.setAliasName(tg.getAliasName());
		tlDto.setSex((tg.getSex() != null) ? cache.getLabel(tg.getSex(), false) : "");
		tlDto.setDob(tg.getDob());
		tlDto.setBirthCountry((tg.getBirthCountry() != null) ? cache.getLabel(tg.getBirthCountry(), false) : "");
		tlDto.setNationality((tg.getNationality() != null) ? cache.getLabel(tg.getNationality(), false) : "");
		tlDto.setRace((tg.getRace() != null) ? cache.getLabel(tg.getRace(), false) : "");
		tlDto.setMaritalStatus(tg.getMaritalStatus() != null ? cache.getLabel(tg.getMaritalStatus(), false) : "");
		tlDto.setLanguage(tg.getGuidingLanguagesWithComma(cache));
		tlDto.setHighestEduLevel((tg.getHighestEduLevel() != null) ? cache.getLabel(tg.getHighestEduLevel(), false) : "");
		tlDto.setMobileNo(tg.getMobileNo());
		tlDto.setEmailAddress(tg.getEmailAddress());
		tlDto.setResidentialStatus((tg.getResidentialStatus() != null) ? cache.getLabel(tg.getResidentialStatus(), false) : "");
		tlDto.setResidentialStatusCode((tg.getResidentialStatus() != null) ? tg.getResidentialStatus().getCode() : "");
		tlDto.setEmployerName(tg.getEmployerName());
		tlDto.setOccupation((tg.getOccupation() != null) ? cache.getLabel(tg.getOccupation(), false) : "");
		tlDto.setOccupationCode((tg.getOccupation() != null) ? tg.getOccupation().getCode() : "");
		tlDto.setOccupationOther(tg.getOccupationOther());
		tlDto.setWorkPassType(tg.getWorkPassType() != null ? cache.getLabel(tg.getWorkPassType(), false) : "");
		tlDto.setWorkPassTypeCode((tg.getWorkPassType() != null) ? tg.getWorkPassType().getCode() : "");
		tlDto.setWorkPassExpiryDate(tg.getWorkPassExpiryDate());
		tlDto.setWorkPassHolder(userHelper.checkWorkPassHolder(tg.getUin()));
		if (tg.getRegisteredAddress() != null) {
			tlDto.setRegisteredAddress(tg.getRegisteredAddress().getAddressDisplay() != null ? tg.getRegisteredAddress().getAddressDisplay() : "");
		}
		if (tg.getMailingAddress() != null) {
			tlDto.setMailingAddress(tg.getMailingAddress().getAddressDisplay() != null ? tg.getMailingAddress().getAddressDisplay() : "");
		}
		tlDto.setSameAddress(Objects.equal(tg.getRegisteredAddress(), tg.getMailingAddress()));
		tlDto.setCeasedDate(licence.getCeasedDate());
		tlDto.setPhoto(FileDto.buildFromFile(tg.getPhoto(), null, null));
		tlDto.setLicenceStatuses(generateLicenceStatus(cache, licence, licenceHelper));
		tlDto.setHasPersonUpdateAccess(tg.getHasPersonUpdateAccess());

		if (Codes.Types.TG_TIER_AREA.equals(licence.getTier().getCode()) || Codes.Types.TG_TIER_GENERAL_AREA.equals(licence.getTier().getCode())) {
			if (tg.getSpecializedAreas() != null) {
				tlDto.setAreaSpecification(tg.getSpecializedAreasWithComma(cache));
			}
		}

		tlDto.setIsMyInfoPopulated(tg.isMyInfoPopulated());
		tlDto.setHasPassedOn(tg.getHasPassedOn());

		tlDto.setSplitName(tg, tlDto, true);// For TG Name
		tlDto.setSplitName(tg, tlDto, false);// For TG Employer Name
		tlDto.setLicenceTypeCode((licence.getTier() != null) ? licence.getTier().getCode() : "");

		return tlDto;
	}

	public void setSplitName(TouristGuide tg, TgLicenceResultDto tlDto, Boolean isName) {
		int nameCharLimit = Codes.ELicenceCharacterLimit.CHARACTER_LIMIT;
		String tgName = "";
		if (isName) {
			tgName = tg.getName();
		} else {
			tgName = tg.getEmployerName();
		}

		String tgName1 = "", tgName2 = "";
		// if tg name is more than character limit
				if (!Strings.isNullOrEmpty(tgName)) {
					if (tgName.length() > Codes.ELicenceCharacterLimit.CHARACTER_LIMIT) {
						nameCharLimit = tgName.length() / 2;
					}
					if (tgName.length() > nameCharLimit) {
						String[] splitedTgName = tgName.split(" ");
						// if first word is bigger than character limit
						// if (splitedTgName[0].length() > nameCharLimit) {
						// set tgName1 to be the maximum character limit of tg name and the rest to tgName2
						// tgName1 = splitedTgName[0].substring(0, nameCharLimit);
						// if (splitedTgName[0].length() > tgName1.length()) {
						// tgName2 = "-";
						// }
						// tgName2 = tgName2 + splitedTgName[0].substring(nameCharLimit);
						// for (int i = 1; i < splitedTgName.length; i++) {
						// tgName2 += " " + splitedTgName[i];
						// }
						// } else { // more than 1 word in the name
						tgName1 = splitedTgName[0];
						for (int i = 1; i < splitedTgName.length; i++) {
							if ((tgName1.length() + splitedTgName[i].length() + 1) > nameCharLimit) {
								tgName2 = splitedTgName[i];
								for (int j = i; j < splitedTgName.length - 1; j++) {
									tgName2 += " " + splitedTgName[j + 1];
								}
								break;
							} else {
								tgName1 += " " + splitedTgName[i];
							}
						}
						// }
					} else { // tg name is less than character limit
						tgName1 = tgName;
					}
				}

		if (isName) {
			if (!Strings.isNullOrEmpty(tg.getDisplayName())) {
				tlDto.setDisplayName(tg.getDisplayName());
			} else {
				tlDto.setDisplayName(tgName1);
			}

			if ((!Strings.isNullOrEmpty(tg.getDisplayName()) && !Strings.isNullOrEmpty(tg.getDisplaySecondName()))
					|| (!Strings.isNullOrEmpty(tg.getDisplayName()) && Strings.isNullOrEmpty(tg.getDisplaySecondName()))) {
				tlDto.setDisplaySecondName(tg.getDisplaySecondName());
			} else {
				tlDto.setDisplaySecondName(tgName2);
			}

		} else {
			if (!Strings.isNullOrEmpty(tg.getDisplayEmployerName())) {
				tlDto.setDisplayEmployerName(tg.getDisplayEmployerName());
			} else {
				tlDto.setDisplayEmployerName(tgName1);
			}

			if ((!Strings.isNullOrEmpty(tg.getDisplayEmployerName()) && !Strings.isNullOrEmpty(tg.getDisplaySecondEmployerName()))
					|| (!Strings.isNullOrEmpty(tg.getDisplayEmployerName()) && Strings.isNullOrEmpty(tg.getDisplaySecondEmployerName()))) {
				tlDto.setDisplaySecondEmployerName(tg.getDisplaySecondEmployerName());
			} else {
				tlDto.setDisplaySecondEmployerName(tgName2);
			}
		}
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public Boolean getIsPortalId() {
		return isPortalId;
	}

	public void setIsPortalId(Boolean isPortalId) {
		this.isPortalId = isPortalId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(String licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public String getLicenceStatusCode() {
		return licenceStatusCode;
	}

	public void setLicenceStatusCode(String licenceStatusCode) {
		this.licenceStatusCode = licenceStatusCode;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(String birthCountry) {
		this.birthCountry = birthCountry;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public String getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(String highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOccupationCode() {
		return occupationCode;
	}

	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}

	public String getOccupationOther() {
		return occupationOther;
	}

	public void setOccupationOther(String occupationOther) {
		this.occupationOther = occupationOther;
	}

	public String getWorkPassType() {
		return workPassType;
	}

	public void setWorkPassType(String workPassType) {
		this.workPassType = workPassType;
	}

	public String getWorkPassTypeCode() {
		return workPassTypeCode;
	}

	public void setWorkPassTypeCode(String workPassTypeCode) {
		this.workPassTypeCode = workPassTypeCode;
	}

	public LocalDate getWorkPassExpiryDate() {
		return workPassExpiryDate;
	}

	public LocalDate getWorkpassExpiryDate() {
		return workPassExpiryDate;
	}

	public void setWorkPassExpiryDate(LocalDate workPassExpiryDate) {
		this.workPassExpiryDate = workPassExpiryDate;
	}

	public boolean isWorkPassHolder() {
		return isWorkPassHolder;
	}

	public void setWorkPassHolder(boolean isWorkPassHolder) {
		this.isWorkPassHolder = isWorkPassHolder;
	}

	public String getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(String address) {
		this.registeredAddress = address;
	}

	public String getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	public FileDto getPhoto() {
		return photo;
	}

	public void setPhoto(FileDto photo) {
		this.photo = photo;
	}

	public List<ListableDto> getLicenceStatuses() {
		return licenceStatuses;
	}

	public void setLicenceStatuses(List<ListableDto> licenceStatuses) {
		this.licenceStatuses = licenceStatuses;
	}

	public Boolean getHasPersonUpdateAccess() {
		return hasPersonUpdateAccess;
	}

	public void setHasPersonUpdateAccess(Boolean hasPersonUpdateAccess) {
		this.hasPersonUpdateAccess = hasPersonUpdateAccess;
	}

	public String getAreaSpecification() {
		return areaSpecification;
	}

	public void setAreaSpecification(String areaSpecification) {
		this.areaSpecification = areaSpecification;
	}

	public String getResidentialStatusCode() {
		return residentialStatusCode;
	}

	public void setResidentialStatusCode(String residentialStatusCode) {
		this.residentialStatusCode = residentialStatusCode;
	}

	private static List<ListableDto> generateLicenceStatus(Cache cache, Licence l, LicenceHelper licenceHelper) {
		List<ListableDto> list = new ArrayList<ListableDto>();

		switch (l.getStatus().getCode()) {
		case Codes.Statuses.TG_ACTIVE:
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_CANCELLED)));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_REVOKED)));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_SUSPENDED)));
			break;
		case Codes.Statuses.TG_INACTIVE:
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_CANCELLED)));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_REVOKED)));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_SUSPENDED)));
			break;
		case Codes.Statuses.TG_CANCELLED:
			list.add(new ListableDto(cache.getStatus(licenceHelper.calculateLicenceStatus(l))));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_REVOKED)));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_SUSPENDED)));
			break;
		case Codes.Statuses.TG_SUSPENDED:
			list.add(new ListableDto(cache.getStatus(licenceHelper.calculateLicenceStatus(l))));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_CANCELLED)));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_REVOKED)));
			break;
		case Codes.Statuses.TG_REVOKED:
			list.add(new ListableDto(cache.getStatus(licenceHelper.calculateLicenceStatus(l))));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_CANCELLED)));
			list.add(new ListableDto(cache.getStatus(Codes.Statuses.TG_SUSPENDED)));
			break;
		}

		return list;
	}

	public Boolean getMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	public boolean isSameAddress() {
		return isSameAddress;
	}

	public void setSameAddress(boolean isSameAddress) {
		this.isSameAddress = isSameAddress;
	}

	public Boolean getHasPassedOn() {
		return hasPassedOn;
	}

	public void setHasPassedOn(Boolean hasPassedOn) {
		this.hasPassedOn = hasPassedOn;
	}

	public String getDisplayEmployerName() {
		return displayEmployerName;
	}

	public void setDisplayEmployerName(String displayEmployerName) {
		this.displayEmployerName = displayEmployerName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplaySecondEmployerName() {
		return displaySecondEmployerName;
	}

	public void setDisplaySecondEmployerName(String displaySecondEmployerName) {
		this.displaySecondEmployerName = displaySecondEmployerName;
	}

	public String getDisplaySecondName() {
		return displaySecondName;
	}

	public void setDisplaySecondName(String displaySecondName) {
		this.displaySecondName = displaySecondName;
	}

	public String getLicenceTypeCode() {
		return licenceTypeCode;
	}

	public void setLicenceTypeCode(String licenceTypeCode) {
		this.licenceTypeCode = licenceTypeCode;
	}
}
