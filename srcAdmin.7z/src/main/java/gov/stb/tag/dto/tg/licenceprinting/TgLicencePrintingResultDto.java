package gov.stb.tag.dto.tg.licenceprinting;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Type;

public class TgLicencePrintingResultDto {

	private String licenceType;
	private String LicenceNo;
	private String name1;
	private Integer column;
	private String name2;
	private Integer cal2;
	private String language1;
	private String language2;
	private String language3;
	private String language4;
	private String language5;
	private String language6;
	private String language7;
	private String language8;
	private String language9;
	private LocalDate expiryDate;

	public TgLicencePrintingResultDto() {

	}

	public static TgLicencePrintingResultDto buildFromAssignment(Cache cache, Licence l, LocalDate expiryDate, boolean isWorkPassHolder) {
		TgLicencePrintingResultDto tlpDto = new TgLicencePrintingResultDto();
		int nameCharLimit = Codes.ELicenceCharacterLimit.CHARACTER_LIMIT;
		;
		String tgName = l.getTouristGuide().getName();
		String tgName1 = "", tgName2 = "";
		String employerName1 = "", employerName2 = "";
		if (tgName.length() > Codes.ELicenceCharacterLimit.CHARACTER_LIMIT) {
			nameCharLimit = tgName.length() / 2;
		}
		// if tg name is more than character limit
		if (!Strings.isNullOrEmpty(tgName)) {
			if (tgName.length() > Codes.ELicenceCharacterLimit.CHARACTER_LIMIT) {
				nameCharLimit = tgName.length() / 2;
			}
			if (tgName.length() > nameCharLimit) {
				String[] splitedTgName = tgName.split(" ");
				// if first word is bigger than character limit
				// if (splitedTgName[0].length() > nameCharLimit) {
				// set tgName1 to be the maximum character limit of tg name and the rest to tgName2
				// tgName1 = splitedTgName[0].substring(0, nameCharLimit);
				// if (splitedTgName[0].length() > tgName1.length()) {
				// tgName2 = "-";
				// }
				// tgName2 = tgName2 + splitedTgName[0].substring(nameCharLimit);
				// for (int i = 1; i < splitedTgName.length; i++) {
				// tgName2 += " " + splitedTgName[i];
				// }
				// } else { // more than 1 word in the name
				tgName1 = splitedTgName[0];
				for (int i = 1; i < splitedTgName.length; i++) {
					if ((tgName1.length() + splitedTgName[i].length() + 1) > nameCharLimit) {
						tgName2 = splitedTgName[i];
						for (int j = i; j < splitedTgName.length - 1; j++) {
							tgName2 += " " + splitedTgName[j + 1];
						}
						break;
					} else {
						tgName1 += " " + splitedTgName[i];
					}
				}
				// }
			} else { // tg name is less than character limit
				tgName1 = tgName;
			}
		}

		// if employer name is more than character limit
		if (isWorkPassHolder) {
			String employerName = l.getTouristGuide().getEmployerName().toUpperCase();
			if (employerName.length() > Codes.ELicenceCharacterLimit.CHARACTER_LIMIT) {
				nameCharLimit = employerName.length() / 2;
			} else {
				nameCharLimit = Codes.ELicenceCharacterLimit.CHARACTER_LIMIT;
				;
			}
			if (employerName.length() > nameCharLimit) {
				String[] splitedEmployerName = employerName.split(" ");
				// if first word is bigger than character limit
				if (splitedEmployerName[0].length() > nameCharLimit) {
					// set employerName1 to be the maximum character limit of employer name and the rest to employerName2
					employerName1 = splitedEmployerName[0].substring(0, nameCharLimit);
					employerName2 = splitedEmployerName[0].substring(nameCharLimit);
					for (int i = 1; i < splitedEmployerName.length; i++) {
						employerName2 += " " + splitedEmployerName[i];
					}
				} else { // more than 1 word in the name
					employerName1 = splitedEmployerName[0];
					for (int i = 1; i < splitedEmployerName.length; i++) {
						if ((employerName1.length() + splitedEmployerName[i].length() + 1) > nameCharLimit) {
							employerName2 = splitedEmployerName[i];
							for (int j = i; j < splitedEmployerName.length - 1; j++) {
								employerName2 += " " + splitedEmployerName[j + 1];
							}
							break;
						} else {
							employerName1 += " " + splitedEmployerName[i];
						}
					}
				}
			} else { // employer name is less than character limit
				employerName1 = employerName;
			}
		}

		tlpDto.setLicenceType(cache.getLabel(l.getTier(), false));
		tlpDto.setLicenceNo(l.getLicenceNo());
		tlpDto.setName1(tgName1.toUpperCase());
		tlpDto.setColumn(tgName1.length());
		tlpDto.setName2(tgName2.toUpperCase());
		tlpDto.setCal2(tgName2.length());
		tlpDto.setExpiryDate(expiryDate);

		// add language
		List<String> languageList = new ArrayList<String>();
		Set<Type> guidingLanguages = l.getTouristGuide().getGuidingLanguages();
		for (Type language : guidingLanguages) {
			languageList.add(cache.getLabel(language, false));
		}
		List<String> languageSorted = new ArrayList<String>();

		// add area of specialisation if ATG
		if (l.getTier().getCode().equals(Codes.Types.TG_TIER_AREA) || l.getTier().getCode().equals(Codes.Types.TG_TIER_GENERAL_AREA)) {
			List<String> specializationList = new ArrayList<String>();
			Set<Type> specializations = l.getTouristGuide().getSpecializedAreas();
			for (Type specialization : specializations) {
				specializationList.add(cache.getLabel(specialization, false));
			}
			languageSorted = specializationList.stream().sorted().collect(Collectors.toList());
		} else if (l.getTier().getCode().equals(Codes.Types.TG_TIER_TAXI)) {
			languageSorted.add("TAXI");
		}

		languageSorted.addAll(languageList.stream().sorted().collect(Collectors.toList()));
		// set language1 as empty space unless all columns needs to be utilized, add empty space to make up all 8 language
		if (languageSorted.size() < 9) {
			if (languageSorted.size() != 7) {
				languageSorted.add(0, "");
			}
			for (int i = languageSorted.size(); i < 9; i++) {
				languageSorted.add("");
			}
			// add employer name if workpass holder
			if (isWorkPassHolder) {
				languageSorted.add(7, employerName1);
				languageSorted.add(8, employerName2);
			}
		}

		tlpDto.setLanguage1(languageSorted.get(0));
		tlpDto.setLanguage2(languageSorted.get(1));
		tlpDto.setLanguage3(languageSorted.get(2));
		tlpDto.setLanguage4(languageSorted.get(3));
		tlpDto.setLanguage5(languageSorted.get(4));
		tlpDto.setLanguage6(languageSorted.get(5));
		tlpDto.setLanguage7(languageSorted.get(6));
		tlpDto.setLanguage8(languageSorted.get(7));
		tlpDto.setLanguage9(languageSorted.get(8));
		return tlpDto;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public String getLicenceNo() {
		return LicenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		LicenceNo = licenceNo;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public Integer getColumn() {
		return column;
	}

	public void setColumn(Integer column) {
		this.column = column;
	}

	public String getName2() {
		return name2;
	}

	public void setName2(String name2) {
		this.name2 = name2;
	}

	public Integer getCal2() {
		return cal2;
	}

	public void setCal2(Integer cal2) {
		this.cal2 = cal2;
	}

	public String getLanguage1() {
		return language1;
	}

	public void setLanguage1(String language1) {
		this.language1 = language1;
	}

	public String getLanguage2() {
		return language2;
	}

	public void setLanguage2(String language2) {
		this.language2 = language2;
	}

	public String getLanguage3() {
		return language3;
	}

	public void setLanguage3(String language3) {
		this.language3 = language3;
	}

	public String getLanguage4() {
		return language4;
	}

	public void setLanguage4(String language4) {
		this.language4 = language4;
	}

	public String getLanguage5() {
		return language5;
	}

	public void setLanguage5(String language5) {
		this.language5 = language5;
	}

	public String getLanguage6() {
		return language6;
	}

	public void setLanguage6(String language6) {
		this.language6 = language6;
	}

	public String getLanguage7() {
		return language7;
	}

	public void setLanguage7(String language7) {
		this.language7 = language7;
	}

	public String getLanguage8() {
		return language8;
	}

	public void setLanguage8(String language8) {
		this.language8 = language8;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getLanguage9() {
		return language9;
	}

	public void setLanguage9(String language9) {
		this.language9 = language9;
	}
}
