package gov.stb.tag.dto.tg.licencerenewal;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.CpfHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TouristGuide;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceRenewalDto extends EntityDto {

	// Licence Renewal
	private Integer id;
	private LocalDate renewalCycleStartDate;
	private LocalDate renewalCycleExpiryDate;
	private LocalDate newCycleLicenceStartDate;
	private LocalDate newCycleLicenceExpiryDate;

	// licence
	private String name;
	private String licenceNo;
	private ListableDto licenceStatus;
	private LocalDate licenceIssueDate;
	private LocalDate licenceStartDate;
	private LocalDate licenceExpiryDate;
	private ListableDto licenceType;
	private Integer licenceId;
	private String guidingLanguage;
	private String areaSpecification;

	// app
	private Integer applicationId;
	private String applicationNo;
	private String applicationType;
	private ListableDto status;
	private String statusRemark;
	private LocalDateTime submissionDate;
	private boolean isFinalApproval;
	private boolean isInLowestStep;
	private ListableDto licencePrintStatus;

	// upload
	private FileDto photo;
	private LocalDate medDate;
	private List<FileDto> medFiles;
	private List<FileDto> workPassFiles;

	// indication
	private Boolean cpfDeclared;
	private Boolean hasNoAssignment;

	// rfa
	private Boolean hasRfaNewPhoto;
	private Boolean hasRfaMedicalReport;
	private Boolean hasRfaWorkPass;

	// validation
	private LocalDate medRequiredStartDate;
	private ListableDto renewalStatus;

	private Boolean isDraft;

	// payment
	private Boolean paymentSuccess;
	private PaymentRequestDto appFee;
	private String billRefNo;
	private Boolean isWaived = false;
	private Boolean isReinstate = false;

	// cpf
	private ListableDto cpfStatus;

	// Photo Submission
	private Boolean isNewPhotoRequire = false;
	private Boolean isCurrentTgPhoto = false;
	private Integer currentTgPhotoId;

	private Boolean isRfaApp = false;

	public TgLicenceRenewalDto() {
	}

	public TgLicenceRenewalDto(CacheHelper cache, TgLicenceRenewal licenceRenewal, TouristGuide tg, FileHelper fileHelper, ApplicationHelper appHelper, PaymentHelper paymentHelper,
			UserHelper userHelper, CpfHelper cpfHelper, boolean fromFrontEnd) {
		if (licenceRenewal != null) {
			Application application = licenceRenewal.getApplication();
			Licence licence = application.getLicence();
			tg = licence.getTouristGuide();
			List<FileDto> tempMedFiles = new ArrayList<FileDto>();
			List<FileDto> tempWorkPassFiles = new ArrayList<FileDto>();

			// licence
			this.licenceNo = licence.getLicenceNo();
			this.name = licence.getTouristGuide().getName();
			this.licenceStatus = new ListableDto(licence.getStatus());
			this.licenceIssueDate = licence.getIssueDate();
			this.licenceStartDate = licence.getStartDate();
			this.licenceExpiryDate = licence.getExpiryDate();
			this.licenceId = licence.getId();
			this.licenceType = new ListableDto(licence.getTier());
			this.guidingLanguage = tg.getGuidingLanguagesWithComma(cache);

			if (Codes.Types.TG_TIER_AREA.equals(licence.getTier().getCode()) || Codes.Types.TG_TIER_GENERAL_AREA.equals(licence.getTier().getCode())) {
				Set<String> specializedAreaSet = new HashSet<>();
				if (tg.getSpecializedAreas() != null) {
					specializedAreaSet.addAll(tg.getSpecializedAreas().stream().map(u -> cache.getLabel(u, true)).collect(Collectors.toSet()));
				}
				this.areaSpecification = StringUtils.join(specializedAreaSet, " / ");
			}

			// app
			this.applicationNo = application.getApplicationNo();
			this.applicationId = application.getId();
			this.applicationType = application.getType().getCode();
			this.licencePrintStatus = application.getLicencePrintStatus() != null
					? new ListableDto(application.getLicencePrintStatus().getCode(), cache.getLabel(application.getLicencePrintStatus(), fromFrontEnd ? true : false))
					: null;
			this.id = licenceRenewal.getId();
			var lastAction = application.getLastAction();
			if (lastAction != null) {
				var lastStatus = lastAction.getStatus();
				this.status = new ListableDto(lastStatus.getCode(), cache.getLabel(lastStatus, fromFrontEnd ? true : false));
				this.statusRemark = lastAction.getExternalRemarks();
			}
			this.submissionDate = application.getSubmissionDate();
			this.isFinalApproval = appHelper.isFinalApproval(application);
			this.isInLowestStep = appHelper.isInLowestStep(null, application);
			this.renewalCycleStartDate = licenceRenewal.getPreviousLicenceStartDate();
			this.renewalCycleExpiryDate = licenceRenewal.getPreviousLicenceExpiryDate();
			this.newCycleLicenceStartDate = licenceRenewal.getLicenceStartDate();
			this.newCycleLicenceExpiryDate = licenceRenewal.getLicenceExpiryDate();

			// upload
			medDate = licenceRenewal.getMedicalDate();

			if (application.getApplicationFiles() != null) {
				for (ApplicationFile appFile : application.getApplicationFiles()) {
					if (Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(appFile.getDocumentType().getCode())) {
						this.photo = FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper);
						if (fromFrontEnd && (tg.getPhoto() != null && tg.getPhoto().getId() == appFile.getFile().getId()) && (application.getLastAction() == null
								|| (application.getLastAction() != null && !Entities.equals(application.getLastAction().getStatus(), Codes.Statuses.TG_APP_APPROVED)))) {
							this.isCurrentTgPhoto = true;
						}
					} else if (Codes.TgDocumentTypes.TG_DOC_MEDICAL_65.equals(appFile.getDocumentType().getCode())) {
						tempMedFiles.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (Codes.TgDocumentTypes.TG_DOC_WORK_PASS.equals(appFile.getDocumentType().getCode())) {
						tempWorkPassFiles.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					}
				}
			}

			if (fromFrontEnd) {
				if (tg.getPhoto() != null) {
					this.currentTgPhotoId = tg.getPhoto().getId();
				}

				if ((application.getLastAction() != null && Entities.equals(application.getLastAction().getStatus(), Codes.Statuses.TG_APP_RFA))) {
					this.isRfaApp = true;
				}

				if ((application.getLastAction() == null || (application.getLastAction() != null && !Entities.equals(application.getLastAction().getStatus(), Codes.Statuses.TG_APP_APPROVED)))) {
					// If TG is 30 and 55 years old, need to upload new photo
					Period period = Period.between(tg.getDob(), LocalDate.now());
					Integer currentYear = period.getYears();
					if (currentYear == 30 || currentYear == 55) {
						this.isNewPhotoRequire = true;
					}

					// check TG's age on last renewal cycle based on photo submission date
					// E.g. this person renewed his licence at age 29 and the next renewal is at age 32. The system will ask him to submit photo at age 32
					if (!this.isNewPhotoRequire) {
						TgLicenceRenewal lastRenewal = appHelper.getRenewalAppByLicId(this.licenceId);
						if (lastRenewal != null) {
							if (lastRenewal.getApplication().getApplicationFiles() != null) {
								for (ApplicationFile appFiles : lastRenewal.getApplication().getApplicationFiles()) {
									if (!appFiles.getIsDeleted() && (Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(appFiles.getDocumentType().getCode()))) {
										Period prevPeriod = Period.between(tg.getDob(), appFiles.getCreatedDate().toLocalDate());
										Integer prevYear = prevPeriod.getYears();
										if (currentYear > 30) {
											if (prevYear >= 20 && prevYear < 30) {
												this.isNewPhotoRequire = true;
											}
										}
										if (currentYear > 55) {
											if (prevYear < 55) {
												this.isNewPhotoRequire = true;
											}
										}
									}
								}
							}
						}
					}

					// If TG is not 30 and 55 years old, auto populate back the current photo
					if (!this.isNewPhotoRequire && this.photo == null && tg.getPhoto() != null) {
						File file = fileHelper.getFile(tg.getPhoto().getId());
						this.photo = FileDto.buildFromFile(file, cache.getType(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO), fileHelper);
						this.isCurrentTgPhoto = true;
					}
				}
			}

			medFiles = tempMedFiles;
			workPassFiles = tempWorkPassFiles;

			// indication
			// cpfDeclared = licenceRenewal.isCpfDeclared();
			hasNoAssignment = licenceRenewal.isHasNoAssignment();

			// rfa
			hasRfaNewPhoto = licenceRenewal.getHasRfaNewPhoto();
			hasRfaMedicalReport = licenceRenewal.getHasRfaMedicalReport();
			hasRfaWorkPass = licenceRenewal.getHasRfaWorkPass();

			// validation
			application.getLicence().getExpiryDate();

			// payment
			if (paymentHelper != null) {
				appFee = new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(licenceRenewal.getAppFeeBillRefNo()), false);
				this.isWaived = paymentHelper
						.checkPaymentIsWaived(LocalDate.now().isBefore(licence.getExpiryDate()) ? Codes.TgPaymentRequestTypes.PAYREQ_TG_RENEWAL : Codes.TgPaymentRequestTypes.PAYREQ_TG_REINSTATEMENT);
			}

			this.isReinstate = LocalDate.now().isBefore(licence.getExpiryDate()) ? false : true;

		}

		if (tg != null && !userHelper.checkWorkPassHolder(tg.getUin())) {
			Status cpfStatus = cpfHelper.checkMedisavePaymentStatus(tg.getUin());
			this.cpfStatus = new ListableDto(cpfStatus.getCode(), cache.getLabel(cpfStatus, false));
		}
	}

	public static TgLicenceRenewalDto buildSubmissionDetails(CacheHelper cache, PaymentHelper paymentHelper, TgLicenceRenewal tlr) {
		TgLicenceRenewalDto dto = new TgLicenceRenewalDto();
		var application = tlr.getApplication();
		dto.setApplicationId(application.getId());
		dto.setApplicationNo(application.getApplicationNo());
		dto.setIsDraft(application.getIsDraft());

		// Payment
		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tlr.getAppFeeBillRefNo()), false));

		return dto;
	}

	public TgLicenceRenewalDto(CacheHelper cache, TgLicenceRenewal licenceRenewal, LocalDate medRequiredStartDate, boolean paymentSuccess, ApplicationHelper appHelper, FileHelper fileHelper,
			LicenceHelper licenceHelper, UserHelper userHelper, CpfHelper cpfHelper, PaymentHelper paymentHelper) {

		this(cache, licenceRenewal, null, fileHelper, appHelper, paymentHelper, userHelper, cpfHelper, true);
		this.applicationId = licenceRenewal.getId();
		this.medRequiredStartDate = medRequiredStartDate;
		String licenceTypeCode = licenceHelper.getLicenceRenewalType(licenceRenewal.getApplication().getLicence());
		this.renewalStatus = new ListableDto(cache.getType(licenceTypeCode));
		this.paymentSuccess = paymentSuccess;

	}

	public FileDto getPhoto() {
		return photo;
	}

	public void setPhoto(FileDto photo) {
		this.photo = photo;
	}

	public List<FileDto> getMedFiles() {
		return medFiles;
	}

	public void setMedFiles(List<FileDto> medFiles) {
		this.medFiles = medFiles;
	}

	public List<FileDto> getWorkPassFiles() {
		return workPassFiles;
	}

	public void setWorkPassFiles(List<FileDto> workPassFiles) {
		this.workPassFiles = workPassFiles;
	}

	public LocalDate getMedDate() {
		return medDate;
	}

	public void setMedDate(LocalDate medDate) {
		this.medDate = medDate;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getStatusRemark() {
		return statusRemark;
	}

	public void setStatusRemark(String statusRemark) {
		this.statusRemark = statusRemark;
	}

	public Boolean getHasRfaNewPhoto() {
		return hasRfaNewPhoto;
	}

	public void setHasRfaNewPhoto(Boolean hasRfaNewPhoto) {
		this.hasRfaNewPhoto = hasRfaNewPhoto;
	}

	public Boolean getHasRfaMedicalReport() {
		return hasRfaMedicalReport;
	}

	public void setHasRfaMedicalReport(Boolean hasRfaMedicalReport) {
		this.hasRfaMedicalReport = hasRfaMedicalReport;
	}

	public Boolean getHasRfaWorkPass() {
		return hasRfaWorkPass;
	}

	public void setHasRfaWorkPass(Boolean hasRfaWorkPass) {
		this.hasRfaWorkPass = hasRfaWorkPass;
	}

	public Boolean getCpfDeclared() {
		return cpfDeclared;
	}

	public void setCpfDeclared(Boolean cpfDeclared) {
		this.cpfDeclared = cpfDeclared;
	}

	public Boolean getHasNoAssignment() {
		return hasNoAssignment;
	}

	public void setHasNoAssignment(Boolean hasNoAssignment) {
		this.hasNoAssignment = hasNoAssignment;
	}

	public LocalDate getLicenceIssueDate() {
		return licenceIssueDate;
	}

	public void setLicenceIssueDate(LocalDate licenceIssueDate) {
		this.licenceIssueDate = licenceIssueDate;
	}

	public LocalDate getLicenceStartDate() {
		return licenceStartDate;
	}

	public void setLicenceStartDate(LocalDate licenceStartDate) {
		this.licenceStartDate = licenceStartDate;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(String guidingLanguage) {
		this.guidingLanguage = guidingLanguage;
	}

	public String getAreaSpecification() {
		return areaSpecification;
	}

	public void setAreaSpecification(String areaSpecification) {
		this.areaSpecification = areaSpecification;
	}

	public LocalDate getMedRequiredStartDate() {
		return medRequiredStartDate;
	}

	public void setMedRequiredStartDate(LocalDate medRequiredStartDate) {
		this.medRequiredStartDate = medRequiredStartDate;
	}

	public Boolean getPaymentSuccess() {
		return paymentSuccess;
	}

	public void setPaymentSuccess(Boolean paymentSuccess) {
		this.paymentSuccess = paymentSuccess;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public ListableDto getRenewalStatus() {
		return renewalStatus;
	}

	public void setRenewalStatus(ListableDto renewalStatus) {
		this.renewalStatus = renewalStatus;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean draft) {
		isDraft = draft;
	}

	public PaymentRequestDto getAppFee() {
		return appFee;
	}

	public void setAppFee(PaymentRequestDto appFee) {
		this.appFee = appFee;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public ListableDto getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(ListableDto licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public ListableDto getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(ListableDto licenceType) {
		this.licenceType = licenceType;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	public void setIsFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public boolean getIsInLowestStep() {
		return isInLowestStep;
	}

	public void setIsInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public ListableDto getCpfStatus() {
		return cpfStatus;
	}

	public void setCpfStatus(ListableDto cpfStatus) {
		this.cpfStatus = cpfStatus;
	}

	public LocalDate getRenewalCycleStartDate() {
		return renewalCycleStartDate;
	}

	public void setRenewalCycleStartDate(LocalDate renewalCycleStartDate) {
		this.renewalCycleStartDate = renewalCycleStartDate;
	}

	public LocalDate getRenewalCycleExpiryDate() {
		return renewalCycleExpiryDate;
	}

	public void setRenewalCycleExpiryDate(LocalDate renewalCycleExpiryDate) {
		this.renewalCycleExpiryDate = renewalCycleExpiryDate;
	}

	public LocalDate getNewCycleLicenceStartDate() {
		return newCycleLicenceStartDate;
	}

	public void setNewCycleLicenceStartDate(LocalDate newCycleLicenceStartDate) {
		this.newCycleLicenceStartDate = newCycleLicenceStartDate;
	}

	public LocalDate getNewCycleLicenceExpiryDate() {
		return newCycleLicenceExpiryDate;
	}

	public void setNewCycleLicenceExpiryDate(LocalDate newCycleLicenceExpiryDate) {
		this.newCycleLicenceExpiryDate = newCycleLicenceExpiryDate;
	}

	public Boolean getIsWaived() {
		return isWaived;
	}

	public void setIsWaived(Boolean isWaived) {
		this.isWaived = isWaived;
	}

	public ListableDto getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(ListableDto licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}
	public Boolean getIsReinstate() {
		return isReinstate;
	}

	public void setIsReinstate(Boolean isReinstate) {
		this.isReinstate = isReinstate;
	}

	public Boolean getIsNewPhotoRequire() {
		return isNewPhotoRequire;
	}

	public void setIsNewPhotoRequire(Boolean isNewPhotoRequire) {
		this.isNewPhotoRequire = isNewPhotoRequire;
	}

	public Boolean getIsCurrentTgPhoto() {
		return isCurrentTgPhoto;
	}

	public void setIsCurrentTgPhoto(Boolean isCurrentTgPhoto) {
		this.isCurrentTgPhoto = isCurrentTgPhoto;
	}

	public Integer getCurrentTgPhotoId() {
		return currentTgPhotoId;
	}

	public void setCurrentTgPhotoId(Integer currentTgPhotoId) {
		this.currentTgPhotoId = currentTgPhotoId;
	}

	public Boolean getIsRfaApp() {
		return isRfaApp;
	}

	public void setIsRfaApp(Boolean isRfaApp) {
		this.isRfaApp = isRfaApp;
	}
}
