package gov.stb.tag.dto.tg.licencereplacement;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.tg.application.TgApplicationItemDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.TgLicenceReplacement;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceReplacementDto extends TgApplicationItemDto {

	private Integer id;
	private boolean allowReplace = true;
	private Integer paymentFee;
	private String billRefNo;
	private Boolean isPaymentSuccess;
	private Boolean isDraft;

	// Payment
	private PaymentRequestDto appFee;

	public TgLicenceReplacementDto() {

	}

	public TgLicenceReplacementDto buildFromTgLicenceReplacement(CacheHelper cache, TgLicenceReplacement tlr, ApplicationHelper appHelper, FileHelper fileHelper, PaymentHelper paymentHelper) {
		TgLicenceReplacementDto dto = new TgLicenceReplacementDto();
		var application = tlr.getApplication();
		dto = dto.buildFromApplication(cache, application, dto, appHelper, fileHelper);
		dto.setId(tlr.getId());
		dto.setBillRefNo(tlr.getAppFeeBillRefNo());
		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tlr.getAppFeeBillRefNo()), false));

		return dto;
	}

	public static TgLicenceReplacementDto buildSubmissionDetails(CacheHelper cache, PaymentHelper paymentHelper, TgLicenceReplacement tlr) {
		TgLicenceReplacementDto dto = new TgLicenceReplacementDto();
		var application = tlr.getApplication();
		dto.setId(application.getId());
		dto.setApplicationNo(application.getApplicationNo());
		dto.setIsDraft(application.getIsDraft());

		// Payment
		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tlr.getAppFeeBillRefNo()), false));

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public boolean isAllowReplace() {
		return allowReplace;
	}

	public void setAllowReplace(boolean allowReplace) {
		this.allowReplace = allowReplace;
	}

	public Integer getPaymentFee() {
		return paymentFee;
	}

	public void setPaymentFee(Integer paymentFee) {
		this.paymentFee = paymentFee;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public Boolean isPaymentSuccess() {
		return isPaymentSuccess;
	}

	public void setPaymentSuccess(Boolean isPaymentSuccess) {
		this.isPaymentSuccess = isPaymentSuccess;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public PaymentRequestDto getAppFee() {
		return appFee;
	}

	public void setAppFee(PaymentRequestDto appFee) {
		this.appFee = appFee;
	}

}
