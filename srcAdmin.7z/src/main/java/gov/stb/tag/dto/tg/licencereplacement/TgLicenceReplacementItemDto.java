package gov.stb.tag.dto.tg.licencereplacement;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgLicenceReplacement;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceReplacementItemDto extends SearchDto {

	@MapProjection(path = "id")
	private Integer licenceReplacementId;

	@MapProjection(path = "application.licence.touristGuide.name")
	private String name;

	@MapProjection(path = "application.licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "application.submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "application.applicationNo")
	private String applicationNo;

	@MapProjection(path = "application.id")
	private Integer applicationId;

	@MapProjection(path = "application.lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "application.lastAction.status.label")
	private String status;

	@MapProjection(path = "application.assignee.name")
	private String assignedOfficer;

	@MapProjection(path = "application.licence.touristGuide.uin")
	private String nricFin;

	@MapProjection(path = "application.licence.expiryDate")
	private LocalDate licenceExpiryDate;

	public TgLicenceReplacementItemDto() {

	}

	public static TgLicenceReplacementItemDto buildFromLicenceReplacement(Cache cache, TgLicenceReplacement tlr) {
		var dto = new TgLicenceReplacementItemDto();
		dto.setLicenceReplacementId(tlr.getId());

		var application = tlr.getApplication();
		var licence = application.getLicence();
		var tg = licence.getTouristGuide();
		dto.setNricFin(tg.getUin());
		dto.setName(tg.getName());
		dto.setLicenceNo(licence.getLicenceNo());
		dto.setLicenceExpiryDate(licence.getExpiryDate());
		dto.setSubmissionDate(application.getSubmissionDate());

		return dto;
	}

	public Integer getLicenceReplacementId() {
		return licenceReplacementId;
	}

	public void setLicenceReplacementId(Integer licenceReplacementId) {
		this.licenceReplacementId = licenceReplacementId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getNricFin() {
		return nricFin;
	}

	public void setNricFin(String nricFin) {
		this.nricFin = nricFin;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
