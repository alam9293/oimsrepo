package gov.stb.tag.dto.tg.mlpt;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "regStartDate")
	private LocalDate regStartDate;

	@MapProjection(path = "regEndDate")
	private LocalDate regEndDate;

	@MapProjection(path = "mlptStartDate")
	private LocalDate mlptStartDate;

	@MapProjection(path = "mlptEndDate")
	private LocalDate mlptEndDate;

	@MapProjection(path = "remarks")
	private String remarks;

	@MapProjection(path = "allocationStatus.code")
	private String allocationStatusCode;

	public TgMlptDto() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getRegStartDate() {
		return regStartDate;
	}

	public void setRegStartDate(LocalDate regStartDate) {
		this.regStartDate = regStartDate;
	}

	public LocalDate getRegEndDate() {
		return regEndDate;
	}

	public void setRegEndDate(LocalDate regEndDate) {
		this.regEndDate = regEndDate;
	}

	public LocalDate getMlptStartDate() {
		return mlptStartDate;
	}

	public void setMlptStartDate(LocalDate mlptStartDate) {
		this.mlptStartDate = mlptStartDate;
	}

	public LocalDate getMlptEndDate() {
		return mlptEndDate;
	}

	public void setMlptEndDate(LocalDate mlptEndDate) {
		this.mlptEndDate = mlptEndDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAllocationStatusCode() {
		return allocationStatusCode;
	}

	public void setAllocationStatusCode(String allocationStatusCode) {
		this.allocationStatusCode = allocationStatusCode;
	}

}
