package gov.stb.tag.dto.tg.mlpt;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptSearchDto extends SearchDto {

	private String name;

	private LocalDate regStartDate;

	private LocalDate regEndDate;

	private LocalDate mlptStartDate;

	private LocalDate mlptEndDate;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getRegStartDate() {
		return regStartDate;
	}

	public void setRegStartDate(LocalDate regStartDate) {
		this.regStartDate = regStartDate;
	}

	public LocalDate getRegEndDate() {
		return regEndDate;
	}

	public void setRegEndDate(LocalDate regEndDate) {
		this.regEndDate = regEndDate;
	}

	public LocalDate getMlptStartDate() {
		return mlptStartDate;
	}

	public void setMlptStartDate(LocalDate mlptStartDate) {
		this.mlptStartDate = mlptStartDate;
	}

	public LocalDate getMlptEndDate() {
		return mlptEndDate;
	}

	public void setMlptEndDate(LocalDate mlptEndDate) {
		this.mlptEndDate = mlptEndDate;
	}

}
