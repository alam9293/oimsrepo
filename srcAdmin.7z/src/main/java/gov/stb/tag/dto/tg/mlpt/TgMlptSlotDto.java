package gov.stb.tag.dto.tg.mlpt;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgMlptSlot;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptSlotDto extends TgMlptSlotItemDto {

	@MapProjection(path = "touristGuide.aliasName", doNotCreateAlias = true)
	private String aliasName;

	@MapProjection(path = "touristGuide.mobileNo", doNotCreateAlias = true)
	private String mobileNo;

	@MapProjection(path = "touristGuide.emailAddress", doNotCreateAlias = true)
	private String emailAddress;

	public TgMlptSlotDto() {

	}

	public String getAliasName() {
		return aliasName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
}
