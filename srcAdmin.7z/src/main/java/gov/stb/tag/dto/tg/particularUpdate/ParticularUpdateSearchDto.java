package gov.stb.tag.dto.tg.particularUpdate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.tg.application.TgApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParticularUpdateSearchDto extends TgApplicationSearchDto {

}
