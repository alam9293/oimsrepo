package gov.stb.tag.dto.tg.stipend;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgStipendConfigSearchDto extends TgStipendSearchDto {

	private Integer id;

	private Boolean forAppeal;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getForAppeal() {
		return forAppeal;
	}

	public void setForAppeal(Boolean forAppeal) {
		this.forAppeal = forAppeal;
	}

}
