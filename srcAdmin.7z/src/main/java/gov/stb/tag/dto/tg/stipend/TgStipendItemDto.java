package gov.stb.tag.dto.tg.stipend;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.tg.application.TgApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgStipendItemDto extends TgApplicationItemDto {

	@MapProjection(path = "id")
	private Integer stipendId;

	@MapProjection(path = "application.lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "application.lastAction.status.label")
	private String statusLabel;

	@MapProjection(path = "application.assignee.name")
	private String assignedOfficer;

	public TgStipendItemDto() {

	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getStatusLabel() {
		return statusLabel;
	}

	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	public Integer getStipendId() {
		return stipendId;
	}

	public void setStipendId(Integer stipendId) {
		this.stipendId = stipendId;
	}
}
