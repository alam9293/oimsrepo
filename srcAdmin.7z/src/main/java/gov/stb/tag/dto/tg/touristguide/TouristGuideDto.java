package gov.stb.tag.dto.tg.touristguide;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.TouristGuide;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TouristGuideDto extends EntityDto {

	private String name;

	private String aliasName;

	private FileDto photo;

	private String guidingLanguages;

	private String specializedAreas;

	private String employerName;

	private String displayEmployerName;

	private String displayName;

	private String displaySecondEmployerName;

	private String displaySecondName;

	private Boolean isWorkPassHolder;

	public TouristGuideDto(Cache cache, TouristGuide tg, FileHelper fileHelper) {
		this.name = tg.getName();
		this.aliasName = tg.getAliasName();
		this.photo = FileDto.buildFromFile(tg.getPhoto(), cache.getType(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO), fileHelper);
		this.guidingLanguages = tg.getGuidingLanguagesWithComma(cache);
		this.specializedAreas = tg.getSpecializedAreasWithComma(cache);
		this.employerName = tg.getEmployerName();

		// for e-licence
		setSplitName(tg, true); // For TG Name
		setSplitName(tg, false); // For TG Employer Name
		this.isWorkPassHolder = !tg.getUin().toLowerCase().startsWith("s") && !tg.getUin().toLowerCase().startsWith("t");
	}

	public void setSplitName(TouristGuide tg, Boolean isName) {
		int nameCharLimit = Codes.ELicenceCharacterLimit.CHARACTER_LIMIT;
		String tgName = "";
		if (isName) {
			tgName = tg.getName();
		} else {
			tgName = tg.getEmployerName();
		}
		String tgName1 = "", tgName2 = "";
		// if tg name is more than character limit
		if (!Strings.isNullOrEmpty(tgName)) {
			if (tgName.length() > Codes.ELicenceCharacterLimit.CHARACTER_LIMIT) {
				nameCharLimit = tgName.length() / 2;
			}
			if (tgName.length() > nameCharLimit) {
				String[] splitedTgName = tgName.split(" ");
				// if first word is bigger than character limit
				// if (splitedTgName[0].length() > nameCharLimit) {
				// set tgName1 to be the maximum character limit of tg name and the rest to tgName2
				// tgName1 = splitedTgName[0].substring(0, nameCharLimit);
				// if (splitedTgName[0].length() > tgName1.length()) {
				// tgName2 = "-";
				// }
				// tgName2 = tgName2 + splitedTgName[0].substring(nameCharLimit);
				// for (int i = 1; i < splitedTgName.length; i++) {
				// tgName2 += " " + splitedTgName[i];
				// }
				// } else { // more than 1 word in the name
				tgName1 = splitedTgName[0];
				for (int i = 1; i < splitedTgName.length; i++) {
					if ((tgName1.length() + splitedTgName[i].length() + 1) > nameCharLimit) {
						tgName2 = splitedTgName[i];
						for (int j = i; j < splitedTgName.length - 1; j++) {
							tgName2 += " " + splitedTgName[j + 1];
						}
						break;
					} else {
						tgName1 += " " + splitedTgName[i];
					}
				}
				// }
			} else { // tg name is less than character limit
				tgName1 = tgName;
			}
		}

		if (isName) {
			if (!Strings.isNullOrEmpty(tg.getDisplayName())) {
				this.setDisplayName(tg.getDisplayName());
			} else {
				this.setDisplayName(tgName1);
			}

			if ((!Strings.isNullOrEmpty(tg.getDisplayName()) && !Strings.isNullOrEmpty(tg.getDisplaySecondName()))
					|| (!Strings.isNullOrEmpty(tg.getDisplayName()) && Strings.isNullOrEmpty(tg.getDisplaySecondName()))) {
				this.setDisplaySecondName(tg.getDisplaySecondName());
			} else {
				this.setDisplaySecondName(tgName2);
			}

		} else {
			if (!Strings.isNullOrEmpty(tg.getDisplayEmployerName())) {
				this.setDisplayEmployerName(tg.getDisplayEmployerName());
			} else {
				this.setDisplayEmployerName(tgName1);
			}

			if ((!Strings.isNullOrEmpty(tg.getDisplayEmployerName()) && !Strings.isNullOrEmpty(tg.getDisplaySecondEmployerName()))
					|| (!Strings.isNullOrEmpty(tg.getDisplayEmployerName()) && Strings.isNullOrEmpty(tg.getDisplaySecondEmployerName()))) {
				this.setDisplaySecondEmployerName(tg.getDisplaySecondEmployerName());
			} else {
				this.setDisplaySecondEmployerName(tgName2);
			}
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public FileDto getPhoto() {
		return photo;
	}

	public void setPhoto(FileDto photo) {
		this.photo = photo;
	}

	public String getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(String guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public String getSpecializedAreas() {
		return specializedAreas;
	}

	public void setSpecializedAreas(String specializedAreas) {
		this.specializedAreas = specializedAreas;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getDisplayEmployerName() {
		return displayEmployerName;
	}

	public void setDisplayEmployerName(String displayEmployerName) {
		this.displayEmployerName = displayEmployerName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getIsWorkPassHolder() {
		return isWorkPassHolder;
	}

	public void setIsWorkPassHolder(Boolean isWorkPassHolder) {
		this.isWorkPassHolder = isWorkPassHolder;
	}

	public String getDisplaySecondEmployerName() {
		return displaySecondEmployerName;
	}

	public void setDisplaySecondEmployerName(String displaySecondEmployerName) {
		this.displaySecondEmployerName = displaySecondEmployerName;
	}

	public String getDisplaySecondName() {
		return displaySecondName;
	}

	public void setDisplaySecondName(String displaySecondName) {
		this.displaySecondName = displaySecondName;
	}
}
