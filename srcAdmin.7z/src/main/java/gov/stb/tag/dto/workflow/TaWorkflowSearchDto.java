package gov.stb.tag.dto.workflow;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaWorkflowSearchDto extends SearchDto {

	private String name;
	private String uen;
	private String licenceNo;
	private Object[] applicationStatuses;
	private String assignedOfficer;

	private LocalDateTime createdDateFrom;
	private LocalDateTime createdDateTo;

	private LocalDateTime approveDateFrom;
	private LocalDateTime approveDateTo;

	private String[] applicationType; // TA_APP, TG_APP, WKFLW_CASE_TA, WKFLW_CASE_TG

	private String workflowStepType; // WKFLW_STEP_TA, WKFLW_STEP_TG, WKFLW_STEP_CE

	public String[] getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String[] applicationType) {
		this.applicationType = applicationType;
	}

	public String getWorkflowStepType() {
		return workflowStepType;
	}

	public void setWorkflowStepType(String workflowStepType) {
		this.workflowStepType = workflowStepType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public Object[] getApplicationStatuses() {
		return applicationStatuses;
	}

	public void setApplicationStatuses(Object[] applicationStatuses) {
		this.applicationStatuses = applicationStatuses;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public LocalDateTime getCreatedDateFrom() {
		return createdDateFrom;
	}

	public void setCreatedDateFrom(LocalDateTime createdDateFrom) {
		this.createdDateFrom = createdDateFrom;
	}

	public LocalDateTime getCreatedDateTo() {
		return createdDateTo;
	}

	public void setCreatedDateTo(LocalDateTime createdDateTo) {
		this.createdDateTo = createdDateTo;
	}

	public LocalDateTime getApproveDateFrom() {
		return approveDateFrom;
	}

	public void setApproveDateFrom(LocalDateTime approveDateFrom) {
		this.approveDateFrom = approveDateFrom;
	}

	public LocalDateTime getApproveDateTo() {
		return approveDateTo;
	}

	public void setApproveDateTo(LocalDateTime approveDateTo) {
		this.approveDateTo = approveDateTo;
	}

}
