package gov.stb.tag.dto.workflow;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowSearchDto extends EntityDto {

	private String[] applicationType; // TA_APP, TG_APP, WKFLW_CASE_TA, WKFLW_CASE_TG

	private String workflowStepType; // WKFLW_STEP_TA, WKFLW_STEP_TG, WKFLW_STEP_CE

	public String[] getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String[] applicationType) {
		this.applicationType = applicationType;
	}

	public String getWorkflowStepType() {
		return workflowStepType;
	}

	public void setWorkflowStepType(String workflowStepType) {
		this.workflowStepType = workflowStepType;
	}

}
