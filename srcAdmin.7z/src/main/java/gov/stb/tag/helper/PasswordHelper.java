package gov.stb.tag.helper;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static com.google.common.base.Strings.isNullOrEmpty;

import java.security.SecureRandom;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.model.PasswordHistory;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.util.EncryptionUtil;

@Component
public class PasswordHelper {

	@Autowired
	UserRepository repository;

	public static String encode(String password, String salt) {
		checkState(!isNullOrEmpty(password));
		checkNotNull(salt);

		return EncryptionUtil.encode(password, salt);
	}

	public static boolean doPasswordsMatch(String hashedPassword, String plainPassword, String salt) {
		checkNotNull(hashedPassword);
		checkNotNull(plainPassword);
		checkNotNull(salt);

		return EncryptionUtil.matches(salt, hashedPassword, plainPassword);
	}

	public static String GenerateRandomPassword(int minLength, int maxLength, int minLCaseCount, int minUCaseCount, int minNumCount, int minSpecialCount) {
		// From http://stackoverflow.com/questions/4090021/need-a-secure-password-generator-recommendation
		char[] randomString;

		String LCaseChars = "abcdefgijkmnopqrstwxyz";
		String UCaseChars = "ABCDEFGHJKLMNPQRSTWXYZ";
		String NumericChars = "1234567890";
		String SpecialChars = "$+?_&!%";

		Map<String, Integer> charGroupsUsed = new HashMap<String, Integer>();
		charGroupsUsed.put("lcase", minLCaseCount);
		charGroupsUsed.put("ucase", minUCaseCount);
		charGroupsUsed.put("num", minNumCount);
		charGroupsUsed.put("special", minSpecialCount);

		// Because we cannot use the default randomizer, which is based on the
		// current time (it will produce the same "random" number within a
		// second), we will use a random number generator to seed the
		// randomizer.

		// Use a 4-byte array to fill it with random bytes and convert it then
		// to an integer value.
		byte[] randomBytes = new byte[4];

		// Generate 4 random bytes.
		new SecureRandom().nextBytes(randomBytes);

		// Convert 4 bytes into a 32-bit integer value.
		int seed = (randomBytes[0] & 0x7f) << 24 | randomBytes[1] << 16 | randomBytes[2] << 8 | randomBytes[3];

		// Create a randomizer from the seed.
		SecureRandom random = new SecureRandom();
		random.setSeed(seed);

		// Allocate appropriate memory for the password.
		int randomIndex = -1;
		if (minLength < maxLength) {
			randomIndex = random.nextInt((maxLength - minLength) + 1) + minLength;
			randomString = new char[randomIndex];
		} else {
			randomString = new char[minLength];
		}

		int requiredCharactersLeft = minLCaseCount + minUCaseCount + minNumCount + minSpecialCount;

		// Build the password.
		for (int i = 0; i < randomString.length; i++) {
			String selectableChars = "";

			// if we still have plenty of characters left to acheive our minimum requirements.
			if (requiredCharactersLeft < randomString.length - i) {
				// choose from any group at random
				selectableChars = LCaseChars + UCaseChars + NumericChars + SpecialChars;
			} else // we are out of wiggle room, choose from a random group that still needs to have a minimum required.
			{
				// choose only from a group that we need to satisfy a minimum for.
				for (Map.Entry<String, Integer> charGroup : charGroupsUsed.entrySet()) {
					if (charGroup.getValue() > 0) {
						if ("lcase".equals(charGroup.getKey())) {
							selectableChars += LCaseChars;
						} else if ("ucase".equals(charGroup.getKey())) {
							selectableChars += UCaseChars;
						} else if ("num".equals(charGroup.getKey())) {
							selectableChars += NumericChars;
						} else if ("special".equals(charGroup.getKey())) {
							selectableChars += SpecialChars;
						}
					}
				}
			}

			// Now that the string is built, get the next random character.
			randomIndex = random.nextInt((selectableChars.length()) - 1);
			char nextChar = selectableChars.charAt(randomIndex);

			// Tac it onto our password.
			randomString[i] = nextChar;

			// Now figure out where it came from, and decrement the appropriate minimum value.
			if (LCaseChars.indexOf(nextChar) > -1) {
				charGroupsUsed.put("lcase", charGroupsUsed.get("lcase") - 1);
				if (charGroupsUsed.get("lcase") >= 0) {
					requiredCharactersLeft--;
				}
			} else if (UCaseChars.indexOf(nextChar) > -1) {
				charGroupsUsed.put("ucase", charGroupsUsed.get("ucase") - 1);
				if (charGroupsUsed.get("ucase") >= 0) {
					requiredCharactersLeft--;
				}
			} else if (NumericChars.indexOf(nextChar) > -1) {
				charGroupsUsed.put("num", charGroupsUsed.get("num") - 1);
				if (charGroupsUsed.get("num") >= 0) {
					requiredCharactersLeft--;
				}
			} else if (SpecialChars.indexOf(nextChar) > -1) {
				charGroupsUsed.put("special", charGroupsUsed.get("special") - 1);
				if (charGroupsUsed.get("special") >= 0) {
					requiredCharactersLeft--;
				}
			}
		}
		return new String(randomString);
	}

	/**
	 * Returns if the password is strong enough
	 * 
	 * @param password
	 * @return
	 */
	public static boolean isPasswordStrong(String password) {
		boolean strong = password.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,255})");

		return strong;
	}

	/**
	 * Returns if the password meets requirement which is must be at least 12 characters long, contains at least one upper case character, one lower case character and a number
	 * 
	 * @param password
	 * @return
	 */
	public static boolean isPasswordMeetsRequirement(String password) {
		boolean valid = password.matches("(^(?=.*[a-zA-Z])(?=.*[0-9]).{12,}$)");

		return valid;
	}

	/**
	 * Returns false if the password not in histories
	 * 
	 * @param password
	 * @return
	 */
	public static boolean isPasswordReused(List<PasswordHistory> passwordHistories, String password) {

		for (PasswordHistory oldPassword : passwordHistories) {
			if (doPasswordsMatch(oldPassword.getPassword(), password, oldPassword.getSalt())) {
				return true;
			}
		}

		return false;
	}

	public void moveCurrentPasswordToHistory(User user) {

		List<PasswordHistory> passwordHistories = user.getPasswordHistories();
		Collections.sort(passwordHistories, new Comparator<PasswordHistory>() {
			@Override
			public int compare(PasswordHistory pwd1, PasswordHistory pwd2) {
				return pwd1.getOrdinal().compareTo(pwd2.getOrdinal());
			}
		});

		// kick out the first password
		if (passwordHistories.size() >= 3) {
			repository.delete(passwordHistories.get(0));
		}

		// save user current password as history
		PasswordHistory newPasswordHistory = new PasswordHistory();
		newPasswordHistory.setPassword(user.getPassword());
		newPasswordHistory.setSalt(user.getSalt());
		newPasswordHistory.setUser(user);
		newPasswordHistory.setOrdinal(passwordHistories.size() == 0 ? 1 : passwordHistories.get(passwordHistories.size() - 1).getOrdinal().intValue() + 1);
		repository.save(newPasswordHistory);
	}
}
