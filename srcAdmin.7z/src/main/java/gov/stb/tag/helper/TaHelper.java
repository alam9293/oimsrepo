package gov.stb.tag.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.dashboard.TaSubmissionDueDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalChecklist;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaApplicationRepository;
import gov.stb.tag.repository.ta.TaKeApplicationRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@Component
public class TaHelper {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaRenewalRepository taRenewalRepo;
	@Autowired
	CacheHelper cacheHelper;
	@Autowired
	TaNetValueShortfallRepository taNetValueRepo;
	@Autowired
	TaAnnualFilingRepository repository;
	@Autowired
	TaKeApplicationRepository taKeApplicationRepository;
	@Autowired
	TaApplicationRepository taApplicationRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;

	private static final Object[] keAssignType = { Codes.ApplicationTypes.TA_APP_KE_ASSIGN, Codes.ApplicationTypes.TA_APP_KE_REASSIGN, Codes.ApplicationTypes.TA_APP_KE_RESIGN };

	public TaLicenceRenewalChecklist getTaRenewalChecklist(Integer year, Licence licence, TaLicenceRenewalChecklist renewalChecklist, BigDecimal outstandingPayment) {
		Object[] fys = { year, year - 1, year - 2 };
		List<TaFilingCondition> pastFilings = new ArrayList<TaFilingCondition>();

		// get the renewal exercise params
		TaLicenceRenewalExercise renewalExercise = taRenewalRepo.getApprovedRenewalExerciseFromYear(year);
		if (renewalExercise == null) {
			logger.error("TA renewal Exercise for year " + year + " has not started.");
		} else {

			for (String filingType : Codes.ApplicationTypes.TA_RENEWAL_FILING_TYPES) {
				Integer filingCount = 0;
				List<TaFilingCondition> filings = repository.getTaFilingConditionsByType(licence.getId(), filingType, fys);
				for (TaFilingCondition filing : filings) {
					if (filing.getApplicationType().getCode().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION)
							|| filing.getApplicationType().getCode().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION)) {
						if (filing.getFyEndDate() != null && filing.getFyEndDate().isAfter(renewalExercise.getFyeCutOffDate())
								&& Objects.equals(filing.getStatus().getCode(), Codes.Statuses.TA_FILING_APPROVED)) {
							pastFilings.add(filing);
							filingCount++;
							logger.info("1 Licence no: {}, added filing for type {}, FY {}", licence.getLicenceNo(), filingType, filing.getFy());
						} else if (filing.getFyEndDate() != null && !filing.getFyEndDate().isAfter(renewalExercise.getFyeCutOffDate()) && filingCount < 2) {
							pastFilings.add(filing);
							filingCount++;
							logger.info("2 Licence no: {}, added filing for type {}, FY {}", licence.getLicenceNo(), filingType, filing.getFy());
						} else {
							logger.info("3 Licence no: {} - Skip {} Filing for FYE {}", licence.getLicenceNo(), filingType, filing.getFyEndDate());
						}
					}
				}
			}

			TaLicenceRenewalExerciseTa renewalTa = taRenewalRepo.getTaLicenceRenewalExerciseTa(renewalExercise.getId(), licence.getId(), Boolean.TRUE);
			if (renewalTa != null && renewalTa.getMaFilingCondition() != null) {
				pastFilings.add(renewalTa.getMaFilingCondition());
			}

			if (pastFilings != null && !pastFilings.isEmpty()) {
				// Reorder pastFilings by Type, follow by fyEndDate in ASC
				Collections.sort(pastFilings, new Comparator<TaFilingCondition>() {
					@Override
					public int compare(TaFilingCondition f1, TaFilingCondition f2) {
						if (f1.getApplicationType().getCode().compareTo(f2.getApplicationType().getCode()) == 0) {
							if (f1.getFyEndDate() != null && f2.getFyEndDate() != null) {
								return f1.getFyEndDate().compareTo(f2.getFyEndDate());
							} else {
								return f1.getFy().compareTo(f2.getFy());
							}
						} else {
							return f1.getApplicationType().getCode().compareTo(f2.getApplicationType().getCode());
						}
					}
				});

				for (TaFilingCondition filing : pastFilings) {
					boolean requireRectification = Boolean.FALSE;
					boolean rectificationApproved = Boolean.FALSE;
					Integer appId = null;
					TaNetValueShortfall shortFallmodel = null;
					if (!filing.getStatus().getCode().equalsIgnoreCase(Statuses.TA_FILING_APPROVED) && renewalChecklist.isMetRenewalCriteria()) {
						renewalChecklist.setMetRenewalCriteria(Boolean.FALSE);
					}
					if (filing.getStatus().getCode().equalsIgnoreCase(Statuses.TA_FILING_APPROVED)) {

						if (filing.getApplicationType().getCode().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION)) {
							shortFallmodel = taNetValueRepo.getImposedShortfallByLicenceIdAndFiling(licence.getId(), filing.getId(), null);
							for (TaAaSubmission submission : filing.getTaAaSubmission()) {
								// filter out the rejected one
								if (submission.getApplication() != null && !submission.getApplication().isDraft() && !submission.getApplication().isDeleted()
										&& submission.getApplication().getLastAction() != null
										&& !submission.getApplication().getLastAction().getStatus().getCode().equalsIgnoreCase(Codes.Statuses.TA_APP_REJECTED)) {
									appId = submission.getApplication().getId();
									break;
								}
							}
						}
						if (filing.getApplicationType().getCode().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_MA_SUBMISSION)
								|| filing.getApplicationType().getCode().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION)) {
							shortFallmodel = taNetValueRepo.getImposedShortfallByLicenceIdAndFiling(licence.getId(), null, filing.getId());
							for (TaMaSubmission submission : filing.getTaMaSubmission()) {
								if (submission.getApplication() != null && !submission.getApplication().isDraft() && !submission.getApplication().isDeleted()
										&& submission.getApplication().getLastAction() != null
										&& !submission.getApplication().getLastAction().getStatus().getCode().equalsIgnoreCase(Codes.Statuses.TA_APP_REJECTED)) {
									appId = submission.getApplication().getId();
									break;
								}
							}
						}
						if (filing.getApplicationType().getCode().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION)) {
							for (TaAbprSubmission submission : filing.getTaAbprSubmission()) {
								// filter out the rejected one
								if (submission.getApplication() != null && !submission.getApplication().isDraft() && !submission.getApplication().isDeleted()
										&& submission.getApplication().getLastAction() != null
										&& !submission.getApplication().getLastAction().getStatus().getCode().equalsIgnoreCase(Codes.Statuses.TA_APP_REJECTED)) {
									appId = submission.getApplication().getId();
									break;
								}
							}
						}
						if (shortFallmodel != null) {
							requireRectification = Boolean.TRUE;
							// not yet rectify or rectification pending approval
							if (shortFallmodel.getTaNetValueRectification() == null
									|| !shortFallmodel.getTaNetValueRectification().getApplication().getLastAction().getStatus().getCode().equalsIgnoreCase(Statuses.TA_APP_APPROVED)) {
								rectificationApproved = Boolean.FALSE;
								renewalChecklist.setMetRenewalCriteria(Boolean.FALSE);
							} else {
								rectificationApproved = Boolean.TRUE;
							}
						}
					}
					TaSubmissionDueDto dto = TaSubmissionDueDto.buildFromAnnualFilingWithRectification(cacheHelper, filing, requireRectification, rectificationApproved);
					dto.setAppId(appId);
					if (shortFallmodel != null && shortFallmodel.getTaNetValueRectification() != null) {
						dto.setRectAppId(shortFallmodel.getTaNetValueRectification().getApplication().getId());
					}
					renewalChecklist.getAnnualFilings().add(dto);

				}
			}
			if (outstandingPayment != null && renewalChecklist.isMetRenewalCriteria()) {
				renewalChecklist.setMetRenewalCriteria(Boolean.FALSE);
			}
			// Check if TA has KE or Have resignation , reassignment submission pending approval
			Application appModel = taApplicationRepository.getPendingApplicationsFromLicenceId(licence.getId(), keAssignType, Boolean.FALSE);
			if (travelAgentRepository.getExistingKe(licence.getId()) == null || appModel != null) {
				renewalChecklist.setHasKe(Boolean.FALSE);
				renewalChecklist.setMetRenewalCriteria(Boolean.FALSE);
			}
		}
		return renewalChecklist;
	}
}
