package gov.stb.tag.helper;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Objects;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.TgCourseSubsidyDto;
import gov.stb.tag.dto.tg.course.TgCourseDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseCreation;
import gov.stb.tag.model.TgCourseRenewal;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.tg.TgCourseRenewalRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.util.DateUtil;

@Component
public class TgCourseHelper {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgCourseRenewalRepository tgCourseRenewalRepository;
	@Autowired
	CacheHelper cache;

	public void isTgCourseBelongToTp(TgTrainingProvider tp, TgCourse course, TgCourseCreation tgCourseCreation) {
		if (tp == null) {
			throw new ValidationException("Training provider is null");
		}
		if (course == null && tgCourseCreation == null) {
			throw new ValidationException("Course is null");
		}
		if (course != null && !Objects.equal(course.getTgTrainingProvider().getUen(), tp.getUen())) {
			throw new ValidationException("The course does not belong to the training provider");
		}
		if (tgCourseCreation != null && !Objects.equal(tgCourseCreation.getTgTrainingProvider().getUen(), tp.getUen())) {
			throw new ValidationException("The course creation does not belong to the training provider");
		}
	}

	public List<TgCourseSubsidyDto> getCourseSubsidyFromTypes() {
		List<TgCourseSubsidyDto> subsidies = new ArrayList<TgCourseSubsidyDto>();
		if (subsidies.size() == 0) {
			List<Type> types = cache.getTypesByCategory(Codes.TypeCategories.TG_COURSE_SUBSIDY);
			types.stream().forEach(type -> subsidies.add(new TgCourseSubsidyDto(type)));
		}
		return subsidies;
	}

	public TgCourseDto getTgCourseByCode(String code) {
		TgCourseDto course = tgCourseRepository.getTgCourseByCode(code);
		List<TgCourseSubsidyDto> subsidies = tgCourseRepository.getTgCourseSubsidyByCode(code);
		if (subsidies.size() == 0) {
			subsidies = getCourseSubsidyFromTypes();
		}
		course.setSubsidies(subsidies);
		course.setCourseDates(tgCourseRepository.getTgCourseDates(code));
		return course;
	}

	public Boolean checkIsCourseEligibleToRenew(TgCourse tgCourse) {

		if (tgCourse != null) {
			// criteria 1: course end date before 01-Jan-2020 cannot renew: hard-code
			LocalDate firstJan2020 = LocalDate.of(2020, 1, 1);
			if (tgCourse.getApprovedEndDate().isBefore(firstJan2020)) {
				return false;
			}

			// criteria 2: 3 months before course end date
			LocalDate renewalStartDate = tgCourse.getApprovedEndDate().plusDays(1).minusMonths(cache.getSystemParameterAsInteger(Codes.SystemParameters.TG_COURSE_MTHS_TO_RENEW_BEF_END_DATE));
			if (LocalDate.now().isBefore(renewalStartDate)) {
				return false;
			}

			// criteria 3: one year after expiry date cannot renew
			LocalDate renewalEndDate = tgCourse.getApprovedEndDate().plusYears(cache.getSystemParameterAsInteger(Codes.SystemParameters.TG_COURSE_YRS_TO_EXPIRED_WHEN_NOT_RENEWED));
			if (LocalDate.now().isAfter(renewalEndDate)) {
				return false;
			}

			// criteria 4: last renewal application is pending processing, approved or rfa cannot renew (rejected before can re-submit)
			TgCourseRenewal lastTgCourseRenewal = tgCourseRenewalRepository.getValidTgCourseRenewalApplication(tgCourse.getCode());
			if (lastTgCourseRenewal != null) {
				return false;
			}

			return true;

		} else {
			return false;
		}
	}

	public TgCourse getNextCycleTgCourse(TgCourse tgCourse) {
		return tgCourseRepository.getNextCycleTgCourse(tgCourse.getCode(), tgCourse.getApprovedStartDate());
	}

	public String generateCourseCode(TgTrainingProvider tp) {

		String tpCode = getFirstLetters(tp.getName());
		String timeCode = DateUtil.format(LocalDateTime.now(), "yyyyMMdd-HHmmss");
		return tpCode + "-" + timeCode;
	}

	private String getFirstLetters(String text) {
		String firstLetters = "";
		text = text.replaceAll("[^a-zA-Z\\s]", ""); // only characters
		for (String s : text.split(" ")) {
			if (!s.isBlank()) {
				firstLetters += s.charAt(0);
			}
		}
		return firstLetters;
	}
}
