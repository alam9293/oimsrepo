package gov.stb.tag.helper;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalConditionDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotItemDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgAssignment;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgCourseAttendanceDetail;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TgStipendConfig;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.tg.TgAssignmentRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgLicenceRenewalRepository;
import gov.stb.tag.repository.tg.TgMlptRepository;

@Component
public class TgHelper {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicenceRenewalRepository tgLicenceRenewalRepository;
	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgAssignmentRepository tgAssignmentRepository;
	@Autowired
	TgMlptRepository tgMlptRepository;
	@Autowired
	CacheHelper cache;
	@Autowired
	CpfHelper cpfHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	UserHelper userHelper;

	public TgLicenceRenewalConditionDto setLicenceRenewalCondition(TouristGuide tg) {
		Licence licence = tg.getLicence();
		TgLicenceRenewal rfaLicenceRenewal = tgLicenceRenewalRepository.getRfaRenewal(tg.getUser().getId(), licence.getExpiryDate());
		TgLicenceRenewal renewal = rfaLicenceRenewal != null ? rfaLicenceRenewal : tgLicenceRenewalRepository.getRenewalByLicenceId(tg.getLicence().getId());
		String appType = renewal != null && renewal.getApplication().getType() != null ? renewal.getApplication().getType().getCode() : null;

		// initialize
		TgLicenceRenewalConditionDto conditions = new TgLicenceRenewalConditionDto();
		List<TgCourseAttendance> mrcAttendances = rfaLicenceRenewal != null && Codes.ApplicationTypes.TG_APP_RENEWAL.equals(appType) ?
				tgCourseRepository.getPrevCycleListOfCourseAttendanceByTgId(Codes.Types.TP_COURSE_MRC, tg.getId(), rfaLicenceRenewal.getPreviousLicenceStartDate(), rfaLicenceRenewal.getPreviousLicenceExpiryDate())
				: tgCourseRepository.getListOfCourseAttendanceByTgId(Codes.Types.TP_COURSE_MRC, tg.getId());
		List<TgCourse> pdcCourses = rfaLicenceRenewal != null && Codes.ApplicationTypes.TG_APP_RENEWAL.equals(appType) ?
				tgCourseRepository.getPrevCycleListOfCourseByTgId(Codes.Types.TP_COURSE_PDC, tg.getId(), rfaLicenceRenewal.getPreviousLicenceStartDate(), rfaLicenceRenewal.getPreviousLicenceExpiryDate())
				: tgCourseRepository.getListOfCourseByTgId(Codes.Types.TP_COURSE_PDC, tg.getId());
		List<TgAssignment> assignments = rfaLicenceRenewal != null && Codes.ApplicationTypes.TG_APP_RENEWAL.equals(appType)  ?
				tgAssignmentRepository.getAllPrevCycleAssignments(tg.getId(), rfaLicenceRenewal.getPreviousLicenceStartDate(), rfaLicenceRenewal.getPreviousLicenceExpiryDate())
				: tgAssignmentRepository.getAllCurrentAssignments(tg.getId());

		LocalDate expiryDate = rfaLicenceRenewal != null ? rfaLicenceRenewal.getPreviousLicenceExpiryDate() : licence.getExpiryDate();
		List<TgMlptSlotItemDto> assessments = tgMlptRepository.getCurrentMlptSlotForReinstatement(licence.getId(), expiryDate.plusYears(3).atStartOfDay(),
				expiryDate.plusYears(6).atStartOfDay());
		conditions.setMrc(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setPdc(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setAssignments(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setCpf(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setNewPhoto(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setWorkPass(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setAssessment(Codes.RenewalStatus.RENEWAL_BLANK);
		conditions.setIsOpenForRenewal(true);

		// MRC
		for (TgCourseAttendance attendance : mrcAttendances) {
			for (TgCourseAttendanceDetail detail : attendance.getTgCourseAttendanceDetails()) {
				if (detail.getResult().getCode().equals(Codes.Types.TG_RESULT_PASS)) {
					conditions.setMrc(Codes.RenewalStatus.RENEWAL_TICK);
				}
			}
		}

		// PDC
		BigDecimal total = new BigDecimal(0.0);
		for (TgCourse course : pdcCourses) {
			total = total.add(course.getNoOfHours());
		}
		if (total.compareTo(new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TG_PDC_MIN).getValue())) >= 0) {
			conditions.setPdc(Codes.RenewalStatus.RENEWAL_TICK);
		}

		// Assignments
		if (CollectionUtils.isNotEmpty(assignments) || (renewal != null && renewal.isHasNoAssignment())) {
			conditions.setAssignments(Codes.RenewalStatus.RENEWAL_TICK);
		}

		// Assessment
		for (TgMlptSlotItemDto assessment : assessments) {
			if (Codes.Statuses.TG_MLPT_COMPETENT.equals(assessment.getResultStatusCode())) {
				conditions.setAssessment(Codes.RenewalStatus.RENEWAL_TICK);
			}
		}

		// CPF
		if (!Entities.anyEquals(cpfHelper.checkMedisavePaymentStatus(tg.getUin()), Codes.Statuses.CPF_MEDISAVE_N)) {
			conditions.setCpf(Codes.RenewalStatus.RENEWAL_TICK);
		}

		// Documents
		if (renewal != null) {
			for (ApplicationFile appFile : renewal.getApplication().getApplicationFiles()) {
				setAppFilesCondition(conditions, appFile);
			}
		}
		if (renewal != null && renewal.getMedicalDate() == null) {
			conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_BLANK);
		}

		// Set RFA conditions
		if (renewal != null) {
			Application application = renewal.getApplication();
			WorkflowAction lastAction = application.getLastAction();
			if (lastAction != null && lastAction.getStatus().getCode().equals(Codes.Statuses.TG_APP_RFA)) {
				if (renewal.getHasRfaNewPhoto()) {
					conditions.setNewPhoto(Codes.RenewalStatus.RENEWAL_BLANK);
				}
				if (renewal.getHasRfaMedicalReport()) {
					conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_BLANK);
					if (renewal.getUpdatedDate().isAfter(lastAction.getUpdatedDate())) {
						conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_TICK);
					}
				}
				if (renewal.getHasRfaWorkPass()) {
					conditions.setWorkPass(Codes.RenewalStatus.RENEWAL_BLANK);
				}

				// if (renewal.getHasRfaCpf()) {
				// conditions.setCpf(Codes.RenewalStatus.RENEWAL_BLANK);
				// if (renewal.getUpdatedDate().isAfter(lastAction.getUpdatedDate()) && renewal.isCpfDeclared()) {
				// conditions.setCpf(Codes.RenewalStatus.RENEWAL_TICK);
				// }
				// }

				for (ApplicationFile appFile : application.getApplicationFiles()) {
					if (appFile.getUpdatedDate().isAfter(lastAction.getUpdatedDate())) {
						setAppFilesCondition(conditions, appFile);
					}
				}
			}
		}

		/* Grey-Temp must be before Grey */

		// Disable if licenced but not eligible for renewal OR no RFA renewal
		String licenceRenewalStatus = licenceHelper.getLicenceRenewalStatus(licence);
		if (rfaLicenceRenewal == null && licenceRenewalStatus == null) {
			conditions.setNewPhoto(Codes.RenewalStatus.RENEWAL_GREY_TEMP);
			conditions.setCpf(Codes.RenewalStatus.RENEWAL_GREY_TEMP);
			conditions.setWorkPass(Codes.RenewalStatus.RENEWAL_GREY_TEMP);
			conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_GREY_TEMP);
			conditions.setIsOpenForRenewal(false);
		}

		/* Grey must be after Grey-Temp */

		// Disable if not allowed
		// TODO: Use a new status code to handle a different message
		String licenceStatusCode = licence.getStatus().getCode();
		if (Codes.LicenceRenewalStatus.OVERDUE.equals(licenceRenewalStatus) || Codes.Statuses.TG_CANCELLED.equals(licenceStatusCode) || Codes.Statuses.TG_REVOKED.equals(licenceStatusCode)
				|| Codes.Statuses.TG_SUSPENDED.equals(licenceStatusCode)) {
			conditions.setNewPhoto(Codes.RenewalStatus.RENEWAL_GREY);
			conditions.setCpf(Codes.RenewalStatus.RENEWAL_GREY);
			conditions.setWorkPass(Codes.RenewalStatus.RENEWAL_GREY);
			conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_GREY);
			conditions.setAssignments(Codes.RenewalStatus.RENEWAL_GREY);
			conditions.setIsOpenForRenewal(false);
		}

		// Disable if CPF not required
		if (userHelper.checkWorkPassHolder(tg.getUin())) {
			conditions.setCpf(Codes.RenewalStatus.RENEWAL_GREY);
		}

		// Disable if not yet Medical Report age
		if (licence.getTouristGuide().getDob() != null) {
			int age = Period.between(licence.getTouristGuide().getDob(), LocalDate.now()).getYears();
			if (age < Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_MEDICAL_REPORT_AGE).getValue())) {
				conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_GREY);
			}
		}

		/* Hide must be after disable */

		// Hide if not Work Pass Holder
		if (!userHelper.checkWorkPassHolder(tg.getUin())) {
			conditions.setWorkPass(Codes.RenewalStatus.RENEWAL_HIDE);
		}

		// Hide if Area(only)
		if (Codes.Types.TG_TIER_AREA.equals(licence.getTier().getCode())) {
			conditions.setMrc(Codes.RenewalStatus.RENEWAL_HIDE);
			conditions.setPdc(Codes.RenewalStatus.RENEWAL_HIDE);
		}

		// Hide if Assessment not required
		if (!Codes.LicenceRenewalStatus.REINSTATE_AF_3YR.equals(licenceRenewalStatus)) {
			conditions.setAssessment(Codes.RenewalStatus.RENEWAL_HIDE);
		}
		// Hide if Assessment is required
		else {
			conditions.setMrc(Codes.RenewalStatus.RENEWAL_HIDE);
			conditions.setPdc(Codes.RenewalStatus.RENEWAL_HIDE);
			conditions.setAssignments(Codes.RenewalStatus.RENEWAL_HIDE);
		}

		//

		return conditions;
	}

	public Type calculateAgeGroup(TouristGuide touristGuide) {
		if (touristGuide == null) {
			throw new ValidationException("Tourist Guide is null.");
		}

		LocalDate dateOfBirth = touristGuide.getDob();
		Type ageGroup = null;

		if (dateOfBirth != null) {
			int age = Period.between(dateOfBirth, LocalDate.now()).getYears();

			if (age < 21) {
				ageGroup = cache.getType(Codes.Types.TG_AGE_GROUP_LESS_21);
			} else if (age >= 21 && age <= 30) {
				ageGroup = cache.getType(Codes.Types.TG_AGE_GROUP_21_TO_30);
			} else if (age >= 31 && age <= 40) {
				ageGroup = cache.getType(Codes.Types.TG_AGE_GROUP_31_TO_40);
			} else if (age >= 41 && age <= 50) {
				ageGroup = cache.getType(Codes.Types.TG_AGE_GROUP_41_TO_50);
			} else if (age >= 51 && age <= 60) {
				ageGroup = cache.getType(Codes.Types.TG_AGE_GROUP_51_TO_60);
			} else if (age > 60) {
				ageGroup = cache.getType(Codes.Types.TG_AGE_GROUP_ABOVE_60);
			}
		}

		return ageGroup;

	}

	public Boolean getStipendEligibility(TouristGuide tg, TgStipendConfig config) {
		if (tg == null) {
			throw new ValidationException("Tourist Guide is null.");
		}

		Boolean isEligible = false;
		Boolean hasGuidingLanguage = false;
		Boolean isSingaporeanOrPR;
		Boolean isBeforeRequiredLicenceStartDate;

		Licence licence = tg.getLicence();

		LocalDate todayDate = LocalDate.now();
		LocalDate periodStartDate = config.getPeriodStartDate();
		LocalDate periodEndDate = config.getPeriodEndDate();
		LocalDate licenceStartDateBefore = config.getLicenceStartBefore();

		String configGuidingLanguages = config.getGuidingLanguages();

		// check whether today's date within periodStartDate and periodEndDate
		if (!(todayDate.isBefore(periodStartDate) || todayDate.isAfter(periodEndDate))) {

			if (!config.getForAppeal()) {
				// check whether TG has the required guiding languages to apply stipend. If languages in config is empty, means all languages are applicable.
				if (Strings.isNullOrEmpty(configGuidingLanguages)) {
					hasGuidingLanguage = true;
				} else {
					Set<Type> guidingLanguages = tg.getGuidingLanguages();
					List<String> eligibleLanguages = new ArrayList<>();
					eligibleLanguages.addAll(Arrays.asList(configGuidingLanguages.split(",")));
					for (Type language : guidingLanguages) {
						hasGuidingLanguage = eligibleLanguages.stream().anyMatch(g -> g.equals(language.getCode()));
						if (hasGuidingLanguage) {
							break;
						}
					}
				}

				// check whether TG licence start date is before TG_STIPEND_LICENCE_START_DATE_BEFORE
				isBeforeRequiredLicenceStartDate = Codes.Statuses.TG_ACTIVE.equals(licence.getStatus().getCode()) && licence.getStartDate().isBefore(licenceStartDateBefore);

				// check whether TG is Singaporean / PR
				isSingaporeanOrPR = Entities.anyEquals(tg.getResidentialStatus(), Codes.Types.RESIDENTIAL_CITIZEN, Codes.Types.RESIDENTIAL_PR);

				// check eligibility
				if (hasGuidingLanguage && isBeforeRequiredLicenceStartDate && isSingaporeanOrPR) {
					isEligible = true;
				}

				logger.info("getStipendEligibility(): tg.id={}, hasGuidingLanguage={}, isBeforeRequiredLicenceStartDate={}, isSingaporeanOrPR={}, isEligible={}", tg.getId(), hasGuidingLanguage,
						isBeforeRequiredLicenceStartDate, isSingaporeanOrPR, isEligible);
			} else {
				isEligible = true;
			}

		}

		return isEligible;
	}

	private void setAppFilesCondition(TgLicenceRenewalConditionDto conditions, ApplicationFile appFile) {
		if (Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(appFile.getDocumentType().getCode())) {
			conditions.setNewPhoto(Codes.RenewalStatus.RENEWAL_TICK);
		} else if (Codes.TgDocumentTypes.TG_DOC_MEDICAL_65.equals(appFile.getDocumentType().getCode())) {
			conditions.setMedicalReport(Codes.RenewalStatus.RENEWAL_TICK);
		} else if (Codes.TgDocumentTypes.TG_DOC_WORK_PASS.equals(appFile.getDocumentType().getCode())) {
			conditions.setWorkPass(Codes.RenewalStatus.RENEWAL_TICK);
		}
	}
}
