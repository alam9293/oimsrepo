package gov.stb.tag.helper;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.payment.PaymentStatusSpanDto;
import gov.stb.tag.dto.payment.PaymentTxnDto;
import gov.stb.tag.dto.tg.stipend.TgStipendDto;
import gov.stb.tag.helper.signdoc.PdfHelper;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.HeaderFooterPageEvent;
import gov.stb.tag.util.NumeralUtil;

@Component
public class TgStipendPdfHelper extends PdfHelper {
	@Autowired
	protected CacheHelper cacheHelper;

	@Autowired
	protected FileHelper fileHelper;

	@Autowired
	Properties properties;

	public byte[] generatePdf(List<TgStipendDto> dtos, String outputFilePath) {
		Document document = createDefaultDocument();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = null;
		try {
			logger.info("Start TgStipend create PDF ");
			writer = PdfWriter.getInstance(document, new FileOutputStream(outputFilePath));
			HeaderFooterPageEvent event = new HeaderFooterPageEvent(null);
			writer.setPageEvent(event);
			document.open();

			Font headerFont = new Font(Font.HELVETICA, 16, Font.BOLD, Color.BLACK);
			Font cellHeaderFont = new Font(Font.HELVETICA, 12, Font.BOLD, Color.BLACK);

			for (TgStipendDto resultDto : dtos) {
				document.add(createParaWithSpacing("Details", headerFont, 7f));
				PdfPTable table = createNewTable(2, 100, new float[] { 1f, 1f });

				table.addCell(createCellWithBorder("Bill Ref. No"));
				table.addCell(createCellWithBorder(resultDto.getAppPayout().getBillRefNo()));

				table.addCell(createCellWithBorder("Status"));
				table.addCell(createCellWithBorder(resultDto.getAppPayout().getStatus()));

				table.addCell(createCellWithBorder("Reference No. (e.g. Case No. / Submission ID.)"));
				table.addCell(createCellWithBorder(resultDto.getApplicationNo()));

				table.addCell(createCellWithBorder("Type"));
				table.addCell(createCellWithBorder(resultDto.getAppPayout().getType()));

				table.addCell(createCellWithBorder("Payer NRIC / FIN / Passport No."));
				table.addCell(createCellWithBorder(resultDto.getAppPayout().getPayerUinUen()));

				table.addCell(createCellWithBorder("Payer Name"));
				table.addCell(createCellWithBorder(resultDto.getAppPayout().getPayerName()));

				table.addCell(createCellWithBorder("Total Payable Amount"));
				table.addCell(createCellWithBorder(NumeralUtil.formatToLocalCurrency(resultDto.getAppPayout().getPayableAmount())));

				table.addCell(createCellWithBorder("Internal Remarks"));
				table.addCell(createCellWithBorder(resultDto.getAppPayout().getRemarks()));

				document.add(table);
				document.add(Chunk.NEWLINE);

				document.add(createParaWithSpacing("Transactions", headerFont, 7f));
				List<String> txnList = new ArrayList<>();
				txnList.add("id");
				txnList.add("Date");
				txnList.add("Status");
				txnList.add("Amount");
				txnList.add("Payment Type");
				txnList.add("Remarks");

				table = createNewTable(6, 100, new float[] { 0.5f, 1f, 1f, 1f, 1f, 2f });

				for (String row : txnList) {
					table.addCell(createStyledCellWithBorder(row, cellHeaderFont));
				}
				table.setHeaderRows(1);

				if (resultDto.getAppPayout().getPaymentTxns() != null && resultDto.getAppPayout().getPaymentTxns().size() > 0) {
					for (PaymentTxnDto txn : resultDto.getAppPayout().getPaymentTxns()) {
						table.addCell(createCellWithBorder(txn.getId().toString()));
						table.addCell(createCellWithBorder(DateUtil.format(txn.getTxnDate(), DateUtil.DATETIME_FORMAT_PATTERN)));
						table.addCell(createCellWithBorder(txn.getStatus()));
						table.addCell(createCellWithBorder(txn.getAmount().toString()));
						table.addCell(createCellWithBorder(txn.getPaymentType()));
						table.addCell(createCellWithBorder(txn.getRemarks()));
					}
				}
				document.add(table);
				document.add(Chunk.NEWLINE);

				document.add(createParaWithSpacing("Status History", headerFont, 7f));
				List<String> statusList = new ArrayList<>();
				statusList.add("No");
				statusList.add("Timestamp");
				statusList.add("Action By");
				statusList.add("Status");
				statusList.add("Remarks");

				table = createNewTable(5, 100, new float[] { 0.5f, 1f, 1f, 1f, 2f });

				for (String row : statusList) {
					table.addCell(createStyledCellWithBorder(row, cellHeaderFont));
				}
				table.setHeaderRows(1);

				if (resultDto.getAppPayout().getPaymentStatusSpan() != null && resultDto.getAppPayout().getPaymentStatusSpan().size() > 0) {
					for (PaymentStatusSpanDto status : resultDto.getAppPayout().getPaymentStatusSpan()) {
						table.addCell(createCellWithBorder(status.getId().toString()));
						table.addCell(createCellWithBorder(DateUtil.format(status.getCreatedDate(), DateUtil.DATETIME_FORMAT_PATTERN)));
						table.addCell(createCellWithBorder(status.getCreatedBy()));
						table.addCell(createCellWithBorder(status.getStatus().getLabel()));
						table.addCell(createCellWithBorder(status.getInternalRemarks()));
					}
				}
				document.add(table);
				document.add(Chunk.NEWLINE);

				document.add(createParaWithSpacing("Stipend Details", headerFont, 7f));
				table = createNewTable(2, 100, new float[] { 1f, 2f });

				table.addCell(createCellWithBorder("TG Name"));
				table.addCell(createCellWithBorder(resultDto.getName()));

				table.addCell(createCellWithBorder("Guiding Language(s)"));
				table.addCell(createCellWithBorder(resultDto.getGuidingLanguage()));

				table.addCell(createCellWithBorder("Residential Status"));
				table.addCell(createCellWithBorder(resultDto.getResidentialStatus().getLabel()));

				table.addCell(createCellWithBorder("Amount"));
				table.addCell(createCellWithBorder(NumeralUtil.formatToLocalCurrency(resultDto.getAmount())));

				table.addCell(createCellWithBorder("TG name as per bank account"));
				table.addCell(createCellWithBorder(resultDto.getNameAsPerBank()));

				table.addCell(createCellWithBorder("Bank Name"));
				table.addCell(createCellWithBorder(resultDto.getBankName()));

				table.addCell(createCellWithBorder("Bank Code"));
				table.addCell(createCellWithBorder(resultDto.getBankCode()));

				table.addCell(createCellWithBorder("Bank Branch Code"));
				table.addCell(createCellWithBorder(resultDto.getBankBranchCode()));

				table.addCell(createCellWithBorder("Bank Account No"));
				table.addCell(createCellWithBorder(resultDto.getBankAccountNo()));
				document.add(table);

				if (dtos.indexOf(resultDto) + 1 < dtos.size()) {
					document.add(Chunk.NEXTPAGE);
				}

			}

			logger.info("End TgStipend PDF ");

		} catch (

		Exception e) {
			e.printStackTrace();
		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}
		return out.toByteArray();

	}

}