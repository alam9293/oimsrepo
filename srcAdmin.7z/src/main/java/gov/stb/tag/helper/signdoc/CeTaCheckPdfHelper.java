package gov.stb.tag.helper.signdoc;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.google.common.base.Strings;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import gov.stb.tag.constant.Codes.SystemParameters;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckDocumentDto;
import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckDto;
import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckQnReponseDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.HeaderFooterPageEvent;
import gov.stb.tag.util.NumeralUtil;

@Component
public class CeTaCheckPdfHelper extends SigndocPdfHelper {
	@Autowired
	protected CacheHelper cacheHelper;

	@Autowired
	protected FileHelper fileHelper;

	private static final String SIGNATURE_PLACEHOLDER = "<Signature>";

	@Override
	protected String getResultUrl() {
		return properties.signdocCeTaCheckResultUrl;
	}

	@Override
	protected void addCommands(MultiValueMap<String, Object> body) {
		// add a search-&-replace non-mandatory, lock_after_signed signature field command
		body.add("cmd_1", "name=Signature|searchtext=" + SIGNATURE_PLACEHOLDER + "|width=140|height=50|offsetx=0|offsety=0|type=formfield|subtype=signature|lock_after_sign=self|required=false");
	}

	public byte[] generatePdf(CeTaCheckDto resultDto) {
		Document document = createDefaultDocument();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = null;
		try {
			logger.info("Start CeTaCheck create PDF ");
			writer = PdfWriter.getInstance(document, out);
			HeaderFooterPageEvent event = new HeaderFooterPageEvent(properties.baseDir + "/stb_logo.jpg");
			writer.setPageEvent(event);
			document.open();

			Font headerFont = new Font(Font.HELVETICA, 16, Font.BOLD, Color.BLACK);
			Font cellHeaderFont = new Font(Font.HELVETICA, 12, Font.BOLD, Color.BLACK);

			document.add(createParaWithSpacing("TRAVEL INSURANCE COMPLIANCE CHECK", headerFont, 7f));
			PdfPTable table = createNewTable(2, 100, new float[] { 1f, 2f });
			// table.addCell(createCellNoBorder("Submission Status "));
			// table.addCell(createCellNoBorder(resultDto.getSubmissionStatus().getLabel()));

			table.addCell(createCellNoBorder("Created By"));
			table.addCell(createCellNoBorder(resultDto.getCreatedBy() + " on " + DateUtil.format(resultDto.getCreatedDate())));

			if (!Strings.isNullOrEmpty(resultDto.getUpdatedBy())) {
				table.addCell(createCellNoBorder("Updated By"));
				table.addCell(createCellNoBorder(resultDto.getUpdatedBy() + " on " + DateUtil.format(resultDto.getUpdatedDate())));
			}

			table.addCell(createCellNoBorder("Check Type"));
			table.addCell(createCellNoBorder(resultDto.getCeTaCheckType().getLabel()));

			// table.addCell(createCellNoBorder("Is TA Compliant"));
			// table.addCell(createCellNoBorder(resultDto.getIsCompliant().getLabel()));

			// table.addCell(createCellNoBorder("To Revisit?"));
			// table.addCell(createCellNoBorder(resultDto.getToRevisit() ? "Yes" : "No"));

			// table.addCell(createCellNoBorder("Case No"));
			// table.addCell(createCellNoBorder(resultDto.getCaseNo()));

			document.add(table);
			document.add(Chunk.NEWLINE);
			document.add(createParaWithSpacing("Travel Agent Licensing and Regulatory Review Department", headerFont, 7f));

			// table = createNewTable(2, 100, new float[] { 1f, 2f });
			table.flushContent();
			table.addCell(createCellWithBorder("Licence No"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getLicenceNo()));

			table.addCell(createCellWithBorder("UEN"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getUen()));

			table.addCell(createCellWithBorder("Name of Travel Agent"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getTaName()));

			table.addCell(createCellWithBorder("NRIC/FIN/Passport No. of Key Executive"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getTaKeUin()));

			table.addCell(createCellWithBorder("Name of Key Executive"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getTaKeName()));

			table.addCell(createCellWithBorder("Postal Code"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressDto().getPostal()));

			table.addCell(createCellWithBorder("Address Type"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressType().getLabel()));

			table.addCell(createCellWithBorder("Block/House No"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressDto().getBlock()));

			table.addCell(createCellWithBorder("Street Name"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressDto().getStreet()));

			table.addCell(createCellWithBorder("Building Name"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressDto().getBuilding()));

			table.addCell(createCellWithBorder("Premises Type"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressDto().getPremisesType().getLabel()));

			table.addCell(createCellWithBorder("Level No"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressDto().getFloor()));

			table.addCell(createCellWithBorder("Unit No"));
			table.addCell(createCellWithBorder(resultDto.getTaDetailsDto().getAddressDto().getUnit()));

			document.add(table);

			document.add(Chunk.NEWLINE);
			document.add(createParaWithSpacing("General", headerFont, 7f));

			List<String> checklistHeaderList = new ArrayList<>();
			checklistHeaderList.add("Activity");
			checklistHeaderList.add("Yes/No");
			checklistHeaderList.add("Remarks");

			List<String> invoiceHeaderList = new ArrayList<>();
			invoiceHeaderList.add("Invoice no. / Booking no.");
			invoiceHeaderList.add("Total Package Price");
			invoiceHeaderList.add("Total Pax");
			invoiceHeaderList.add("Payment/ Deposit made");
			invoiceHeaderList.add("Deposit Price per Pax");
			invoiceHeaderList.add("Was consumer informed?");
			invoiceHeaderList.add("Remarks");

			table = createNewTable(3, 100, new float[] { 3f, 0.65f, 3f });

			for (String row : checklistHeaderList) {
				table.addCell(createStyledCellWithBorder(row, cellHeaderFont));
			}
			table.setHeaderRows(1);

			Collections.sort(resultDto.getCeTaCheckQnResponseGeneralDto(), Comparator.comparing(CeTaCheckQnReponseDto::getOrdinal));
			Collections.sort(resultDto.getCeTaCheckQnResponseDto(), Comparator.comparing(CeTaCheckQnReponseDto::getOrdinal));

			for (CeTaCheckQnReponseDto row : resultDto.getCeTaCheckQnResponseGeneralDto()) {
				table.addCell(createCellWithBorder(row.getQuestion()));
				table.addCell(createCellWithBorderAlignCenter(row.getIsYes() ? "Yes" : "No"));
				table.addCell(createCellWithBorder(row.getRemarks()));
			}
			document.add(table);

			document.add(Chunk.NEWLINE);
			document.add(createParaWithSpacing("Checklist", headerFont, 7f));

			// table = createNewTable(3, 100, new float[] { 3f, 0.75f, 3f });
			table.flushContent();

			for (String row : checklistHeaderList) {
				table.addCell(createStyledCellWithBorder(row, cellHeaderFont));
			}

			for (CeTaCheckQnReponseDto row : resultDto.getCeTaCheckQnResponseDto()) {
				if (!Strings.isNullOrEmpty(row.getTitle())) {
					table.addCell(createCellWithBorderColSpan(row.getTitle(), 3, cellHeaderFont));
				}
				// String textOnly = Jsoup.parse(row.getQuestion()).text();
				table.addCell(createCellWithBorder(row.getQuestion()));
				table.addCell(createCellWithBorderAlignCenter(row.getIsYes() ? "Yes" : "No"));
				table.addCell(createCellWithBorder(row.getRemarks()));
			}
			document.add(table);

			document.add(Chunk.NEWLINE);
			document.add(createParaWithSpacing("Documents Furnished by Travel Agent", headerFont, 7f));

			table = createNewTable(7, 100, new float[] { 1f, 1f, 0.5f, 1f, 1f, 1f, 1f });

			for (String row : invoiceHeaderList) {
				table.addCell(createStyledCellWithBorder(row, cellHeaderFont));
			}
			table.setHeaderRows(1);

			for (CeTaCheckDocumentDto row : resultDto.getCeTaCheckDocumentDto()) {
				table.addCell(createCellWithBorder(row.getInvoiceBookingNo()));
				table.addCell(createCellWithBorder(NumeralUtil.formatToLocalCurrency(row.getTotalPrice())));
				table.addCell(createCellWithBorder(NumeralUtil.formatIntegerToString(row.getNoOfPax())));
				table.addCell(createCellWithBorder(NumeralUtil.formatToLocalCurrency(row.getPaymentDepositMade())));
				if (row.getNoOfPax() != null) {
					table.addCell(createCellWithBorder(NumeralUtil.formatToLocalCurrency(row.getPaymentDepositMade().divide(new BigDecimal(row.getNoOfPax()), 2, RoundingMode.HALF_UP))));
				} else {
					table.addCell(createCellWithBorder(null));
				}

				table.addCell(createCellWithBorder(row.getIsConsumerInformed().getLabel()));
				table.addCell(createCellWithBorder(row.getRemarks()));
			}
			document.add(table);

			document.add(Chunk.NEWLINE);

			table = createNewTable(2, 100, new float[] { 1f, 2f });
			table.addCell(createCellWithBorder("Remarks (if any)"));
			table.addCell(createCellWithBorder(resultDto.getRemarks()));

			table.addCell(createCellWithBorder("Date/Time"));
			table.addCell(createCellWithBorder(DateUtil.format(resultDto.getCheckedDate())));

			table.addCell(createCellWithBorder("Assigned EO"));
			table.addCell(createCellWithBorder(resultDto.getEoUserDto().getName()));

			// table.addCell(createCellWithBorder("Witness Officer's Name"));
			// table.addCell(createCellWithBorder(resultDto.getAuxEo().getLabel()));

			document.add(table);

			table = createNewTable(3, 100, new float[] { 1f, 1f, 1f });

			table.addCell(createCellWithBorderRowSpan("STB Officer", 2));
			table.addCell(createCellWithBorderRowSpan(resultDto.getAuxEo().getLabel(), 2));
			table.addCell(createCellWithBorder("Signature: "));
			table.addCell(createCellForSignature("<Signature>"));

			table.addCell(createCellWithBorderRowSpan("Travel Agent Representative", 2));
			String content = resultDto.getTaStaffName();
			if (!Strings.isNullOrEmpty(resultDto.getTaStaffDesignation())) {
				content = content + "(" + resultDto.getTaStaffDesignation() + ")";
			}
			table.addCell(createCellWithBorderRowSpan(content, 2));

			table.addCell(createCellWithBorder("Signature: "));
			table.addCell(createCellForSignature("<Signature>"));

			document.add(table);
			document.add(Chunk.NEWLINE);

			document.add(createParaWithSpacing(cacheHelper.getSystemParameter(SystemParameters.CE_TA_CHECKS_DECLARATION).getValue(), cellHeaderFont, 7f));

			document.add(Chunk.NEWLINE);

			// document.add(createParaWithSpacing("Invoice Attachments", headerFont, 7f));
			for (CeTaCheckDocumentDto obj : resultDto.getCeTaCheckDocumentDto()) {
				for (AttachmentDto row : obj.getFiles()) {
					if (fileHelper.isImage(row.getExtension())) {
						attachImage(document, writer, fileHelper.getFullFilePath(properties.baseDir, row.getFilePath(), row.getFileName()));
					}
					if (row.getExtension().equalsIgnoreCase("pdf")) {
						attachPdf(document, writer, fileHelper.getFullFilePath(properties.baseDir, row.getFilePath(), row.getFileName()));
					}
				}
			}

			// document.add(createParaWithSpacing("Other Attachments", headerFont, 7f));
			for (AttachmentDto row : resultDto.getFiles()) {
				if (fileHelper.isImage(row.getExtension())) {
					attachImage(document, writer, fileHelper.getFullFilePath(properties.baseDir, row.getFilePath(), row.getFileName()));
				}
				if (row.getExtension().equalsIgnoreCase("pdf")) {
					attachPdf(document, writer, fileHelper.getFullFilePath(properties.baseDir, row.getFilePath(), row.getFileName()));
				}
			}

			logger.info("End CeTaCheck PDF ");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}
		return out.toByteArray();

	}
}