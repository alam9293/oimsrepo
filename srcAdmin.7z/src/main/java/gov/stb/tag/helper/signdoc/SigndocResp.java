package gov.stb.tag.helper.signdoc;

public class SigndocResp {

	private RestLoadId restLoadId;

	public RestLoadId getRestLoadId() {
		return restLoadId;
	}

	public void setRestLoadId(RestLoadId restLoadId) {
		this.restLoadId = restLoadId;
	}

}
