package gov.stb.tag.jackson;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.util.StdConverter;

public class BigDecimalToMoneyThousandSeparatorConverter extends StdConverter<BigDecimal, String> {

	protected transient static Logger logger = LoggerFactory.getLogger(MoneyThousandSeparatorToBigDecimalConverter.class);

	@Override
	public String convert(BigDecimal value) {
		if (value != null) {
			return new DecimalFormat("#,###").format(value);
		} else {
			return null;
		}

	}
}
