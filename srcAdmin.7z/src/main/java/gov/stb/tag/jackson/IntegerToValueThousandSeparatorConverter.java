package gov.stb.tag.jackson;

import java.text.NumberFormat;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.util.StdConverter;

public class IntegerToValueThousandSeparatorConverter extends StdConverter<Integer, String> {

	protected transient static Logger logger = LoggerFactory.getLogger(IntegerToValueThousandSeparatorConverter.class);

	@Override
	public String convert(Integer value) {
		if (value != null) {
			return NumberFormat.getNumberInstance(Locale.US).format(value);
			// new DecimalFormat("#,###").format(value);
		} else {
			return null;
		}

	}
}
