package gov.stb.tag.jackson;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.util.StdConverter;
import com.google.common.base.Strings;

public class MoneyThousandSeparatorToBigDecimalConverter extends StdConverter<String, BigDecimal> {

	protected transient static Logger logger = LoggerFactory.getLogger(MoneyThousandSeparatorToBigDecimalConverter.class);

	@Override
	public BigDecimal convert(String value) {
		DecimalFormat nf = new DecimalFormat("#,###", new DecimalFormatSymbols(Locale.ENGLISH));
		nf.setParseBigDecimal(true);
		try {
			if (Strings.isNullOrEmpty(value)) {
				return null;
			} else {
				return (BigDecimal) nf.parse(value);
			}
		} catch (ParseException e) {
			logger.error(e.getMessage());
			throw new IllegalArgumentException(String.format("Failed to convert [%s] to [%s] for value '%s'", String.class.toString(), BigDecimal.class.toString(), value));
		}
	}
}
