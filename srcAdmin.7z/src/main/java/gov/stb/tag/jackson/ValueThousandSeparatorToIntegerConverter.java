package gov.stb.tag.jackson;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.util.StdConverter;
import com.google.common.base.Strings;

public class ValueThousandSeparatorToIntegerConverter extends StdConverter<String, Integer> {

	protected transient static Logger logger = LoggerFactory.getLogger(ValueThousandSeparatorToIntegerConverter.class);

	@Override
	public Integer convert(String value) {
		// DecimalFormat nf = new DecimalFormat("#,###", new DecimalFormatSymbols(Locale.ENGLISH));
		// nf.setParseBigDecimal(true);
		try {
			if (Strings.isNullOrEmpty(value)) {
				return null;
			} else {
				return Integer.valueOf(value.replace(",", ""));
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new IllegalArgumentException(String.format("Failed to convert [%s] to [%s] for value '%s'", String.class.toString(), Integer.class.toString(), value));
		}
	}
}
