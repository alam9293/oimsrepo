package gov.stb.tag.mapper;

@FunctionalInterface
public interface SearchRecordMapper<M, T> {

	public T apply(M model);

}