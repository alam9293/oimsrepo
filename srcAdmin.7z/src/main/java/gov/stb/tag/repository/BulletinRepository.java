package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.bulletin.BulletinItemDto;
import gov.stb.tag.dto.bulletin.BulletinSearchDto;
import gov.stb.tag.model.Bulletin;
import gov.stb.tag.model.CategoryListing;

@Repository
public class BulletinRepository extends BaseRepository {

	public List<Bulletin> getAllPublicBulletins() {
		DetachedCriteria dc = DetachedCriteria.forClass(Bulletin.class);
		dc.add(Restrictions.and(Restrictions.eq("isPrivate", false)));
		// dc.add(Restrictions.and(Restrictions.le("effectiveDate", LocalDate.now())));
		// dc.add(Restrictions.and(Restrictions.ge("expiryDate", LocalDate.now())));
		// dc.addOrder(Order.desc("effectiveDate"));
		// dc.addOrder(Order.desc("updatedDate"));
		return getList(dc);
	}

	// CategoryListings
	public List<CategoryListing> getAllInfoHubListings() {
		DetachedCriteria dc = DetachedCriteria.forClass(CategoryListing.class);
		// dc.add(Restrictions.and(Restrictions.eq("isPrivate", false)));
		dc.add(Restrictions.and(Restrictions.le("effectiveDate", LocalDate.now())));
		dc.add(Restrictions.and(Restrictions.ge("expiryDate", LocalDate.now())));
		// dc.addOrder(Order.desc("effectiveDate"));
		// dc.addOrder(Order.desc("updatedDate"));
		return getList(dc);
	}

	public ResultDto<BulletinItemDto> getBulletinsByType(BulletinSearchDto dto) {
		var dc = DetachedCriteria.forClass(Bulletin.class);
		dc.add(Restrictions.and(Restrictions.eq("isPrivate", false)));

		String typeCode = dto.getType().substring(dto.getType().lastIndexOf("_") + 1);
		dc.add(Restrictions.disjunction().add(Restrictions.ilike("type.code", typeCode, MatchMode.ANYWHERE)).add(Restrictions.ilike("type.code", typeCode, MatchMode.ANYWHERE)));

		dc.add(Restrictions.and(Restrictions.le("effectiveDate", LocalDate.now())));
		dc.add(Restrictions.and(Restrictions.ge("expiryDate", LocalDate.now())));
		dc.addOrder(Order.desc("effectiveDate"));
		dc.addOrder(Order.desc("updatedDate"));
		addDtoProjections(dc, BulletinItemDto.class);
		return search(dc, dto, true);
	}

	public Bulletin getDetailsById(Integer id, boolean fromAEM) {
		var dc = DetachedCriteria.forClass(Bulletin.class);
		if (fromAEM) {
			dc.add(Restrictions.and(Restrictions.eq("isPrivate", Boolean.FALSE)));
		}
		dc.add(Restrictions.and(Restrictions.eq("id", id)));

		return getFirst(dc);
	}

	public List<Bulletin> getAllBulletins(String type, Boolean isPrivate) {
		DetachedCriteria dc = DetachedCriteria.forClass(Bulletin.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		if (isPrivate != null) {
			dc.add(Restrictions.and(Restrictions.eq("isPrivate", isPrivate)));
		}
		String typeCode = type.substring(type.lastIndexOf("_") + 1);
		dc.add(Restrictions.disjunction().add(Restrictions.ilike("type.code", typeCode, MatchMode.ANYWHERE)).add(Restrictions.ilike("type.code", typeCode, MatchMode.ANYWHERE)));

		dc.add(Restrictions.and(Restrictions.le("effectiveDate", LocalDate.now())));
		dc.add(Restrictions.and(Restrictions.ge("expiryDate", LocalDate.now())));
		dc.addOrder(Order.desc("effectiveDate"));
		dc.addOrder(Order.desc("updatedDate"));
		dc.addOrder(Order.desc("expiryDate"));
		return getList(dc);
	}

	public ResultDto<BulletinItemDto> getAllBulletinsList(String type, BulletinSearchDto dto) {
		ResultDto<BulletinItemDto> allList = new ResultDto<BulletinItemDto>();

		var dc = DetachedCriteria.forClass(Bulletin.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);

		String typeCode = type.substring(type.lastIndexOf("_") + 1);
		dc.add(Restrictions.disjunction().add(Restrictions.ilike("type.code", typeCode, MatchMode.ANYWHERE)).add(Restrictions.ilike("type.code", typeCode, MatchMode.ANYWHERE)));
		filter(dto, dc);

		dc.addOrder(Order.desc("effectiveDate"));
		dc.addOrder(Order.desc("updatedDate"));

		addDtoProjections(dc, BulletinItemDto.class);

		allList = search(dc, dto, true);
		buildFromAllList(allList);
		return allList;
	}

	private void buildFromAllList(ResultDto<BulletinItemDto> allList) {
		if (allList.getModels().size() > 0) {
			for (BulletinItemDto dto : allList.getModels()) {

				if (dto.getEffectiveDate() != null && dto.getExpiryDate() != null) {
					if ((dto.getEffectiveDate().isBefore(LocalDate.now()) || dto.getEffectiveDate().isEqual(LocalDate.now()))
							&& (dto.getExpiryDate().isAfter(LocalDate.now()) || dto.getExpiryDate().isEqual(LocalDate.now()))) {
						dto.setIsCurrentlyDisplay(Boolean.TRUE);
					} else {
						dto.setIsCurrentlyDisplay(Boolean.FALSE);
					}
				}
			}
		}
	}

	private DetachedCriteria filter(BulletinSearchDto searchDto, DetachedCriteria dc) {

		if (!Strings.isNullOrEmpty(searchDto.getTitle())) {
			dc.add(Restrictions.disjunction().add(Restrictions.ilike("title", searchDto.getTitle(), MatchMode.ANYWHERE)).add(Restrictions.ilike("title", searchDto.getTitle(), MatchMode.ANYWHERE)));
		}

		if (!Strings.isNullOrEmpty(searchDto.getIsPrivate())) {
			if ("Yes".equals(searchDto.getIsPrivate())) {
				addEq(dc, "isPrivate", Boolean.TRUE);
			} else {
				addEq(dc, "isPrivate", Boolean.FALSE);
			}
		}

		if (!Strings.isNullOrEmpty(searchDto.getIsDelisted())) {
			if ("Yes".equals(searchDto.getIsDelisted())) {
				addEq(dc, "isDelisted", Boolean.TRUE);
			} else {
				addEq(dc, "isDelisted", Boolean.FALSE);
			}
		}

		if (!Strings.isNullOrEmpty(searchDto.getIsCurrentlyDisplay())) {
			if ("Yes".equals(searchDto.getIsCurrentlyDisplay())) {
				addLe(dc, "effectiveDate", LocalDate.now());
				addGe(dc, "expiryDate", LocalDate.now());

			} else {
				addLt(dc, "effectiveDate", LocalDate.now());
				addLt(dc, "expiryDate", LocalDate.now());
			}
		}

		if (searchDto.getEffectiveDateFrom() != null) {
			addGe(dc, "effectiveDate", searchDto.getEffectiveDateFrom());

		}
		if (searchDto.getEffectiveDateTo() != null) {
			addLe(dc, "effectiveDate", searchDto.getEffectiveDateTo());
		}

		if (searchDto.getExpiryDateFrom() != null) {
			addGe(dc, "expiryDate", searchDto.getExpiryDateFrom());
		}

		if (searchDto.getExpiryDateTo() != null) {
			addLe(dc, "expiryDate", searchDto.getExpiryDateTo());
		}

		return dc;
	}

}
