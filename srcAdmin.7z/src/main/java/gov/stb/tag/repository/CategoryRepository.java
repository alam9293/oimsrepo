package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.bulletin.BulletinSearchDto;
import gov.stb.tag.dto.bulletin.CategoryItemDto;
import gov.stb.tag.model.Category;
import gov.stb.tag.model.CategoryListing;

@Repository
public class CategoryRepository extends BaseRepository {

	public ResultDto<CategoryItemDto> getAllCategorys(BulletinSearchDto dto) {
		ResultDto<CategoryItemDto> allList = new ResultDto<CategoryItemDto>();
		dto.setPageSize(Integer.MAX_VALUE);
		var dc = DetachedCriteria.forClass(Category.class);

		// dc.add(Restrictions.and(Restrictions.gt("effectiveDate", type)).add(Restrictions.lt("type.code", "BULLETIN_GENERAL")));

		LocalDate todayDate = LocalDate.now();
		// Date todayDate = getDateWithoutTime(fromTimestamp);
		dc.add(Restrictions.and(

				Restrictions.le("effectiveDate", todayDate))

				.add(Restrictions.ge("expiryDate", todayDate)));

		dc.addOrder(Order.asc("effectiveDate"));
		dc.addOrder(Order.asc("id"));
		addDtoProjections(dc, CategoryItemDto.class);
		allList = search(dc, dto, true);
		buildFromAllList(allList);
		return allList;
	}

	public ResultDto<CategoryItemDto> getAllCategorys(String type, BulletinSearchDto dto) {
		ResultDto<CategoryItemDto> allList = new ResultDto<CategoryItemDto>();

		var dc = DetachedCriteria.forClass(Category.class);
		filter(dto, dc);
		dc.addOrder(Order.desc("effectiveDate"));
		dc.addOrder(Order.desc("id"));
		addDtoProjections(dc, CategoryItemDto.class);
		allList = search(dc, dto, true);
		buildFromAllList(allList);
		return allList;
	}

	private void buildFromAllList(ResultDto<CategoryItemDto> allList) {
		if (allList.getModels().size() > 0) {
			for (CategoryItemDto dto : allList.getModels()) {

				if (dto.getEffectiveDate() != null && dto.getExpiryDate() != null) {
					if ((dto.getEffectiveDate().isBefore(LocalDate.now()) || dto.getEffectiveDate().isEqual(LocalDate.now()))
							&& (dto.getExpiryDate().isAfter(LocalDate.now()) || dto.getExpiryDate().isEqual(LocalDate.now()))) {
						dto.setIsCurrentlyDisplay(Boolean.TRUE);
					} else {
						dto.setIsCurrentlyDisplay(Boolean.FALSE);
					}
				}
			}
		}
	}

	private DetachedCriteria filter(BulletinSearchDto searchDto, DetachedCriteria dc) {

		if (!Strings.isNullOrEmpty(searchDto.getTitle())) {
			dc.add(Restrictions.disjunction().add(Restrictions.ilike("title", searchDto.getTitle(), MatchMode.ANYWHERE)).add(Restrictions.ilike("title", searchDto.getTitle(), MatchMode.ANYWHERE)));
		}

		if (!Strings.isNullOrEmpty(searchDto.getIsPrivate())) {
			if ("Yes".equals(searchDto.getIsPrivate())) {
				addEq(dc, "isPrivate", Boolean.TRUE);
			} else {
				addEq(dc, "isPrivate", Boolean.FALSE);
			}
		}

		if (!Strings.isNullOrEmpty(searchDto.getIsDelisted())) {
			if ("Yes".equals(searchDto.getIsDelisted())) {
				addEq(dc, "isDelisted", Boolean.TRUE);
			} else {
				addEq(dc, "isDelisted", Boolean.FALSE);
			}
		}

		if (!Strings.isNullOrEmpty(searchDto.getIsCurrentlyDisplay())) {
			if ("Yes".equals(searchDto.getIsCurrentlyDisplay())) {
				addLe(dc, "effectiveDate", LocalDate.now());
				addGe(dc, "expiryDate", LocalDate.now());

			} else {
				addLt(dc, "effectiveDate", LocalDate.now());
				addLt(dc, "expiryDate", LocalDate.now());
			}
		}

		if (searchDto.getEffectiveDateFrom() != null) {
			addGe(dc, "effectiveDate", searchDto.getEffectiveDateFrom());

		}
		if (searchDto.getEffectiveDateTo() != null) {
			addLe(dc, "effectiveDate", searchDto.getEffectiveDateTo());
		}

		if (searchDto.getExpiryDateFrom() != null) {
			addGe(dc, "expiryDate", searchDto.getExpiryDateFrom());
		}

		if (searchDto.getExpiryDateTo() != null) {
			addLe(dc, "expiryDate", searchDto.getExpiryDateTo());
		}

		return dc;
	}

	public Category getDetailsById(Integer id, boolean fromAEM) {
		var dc = DetachedCriteria.forClass(Category.class);
		if (fromAEM) {
			dc.add(Restrictions.and(Restrictions.eq("isPrivate", Boolean.FALSE)));
		}
		dc.add(Restrictions.and(Restrictions.eq("id", id)));
		dc.addOrder(Order.desc("effectiveDate"));
		dc.addOrder(Order.desc("id"));

		return getFirst(dc);
	}

	public List<CategoryListing> getAllCategoryListingDetailsById(Integer categoryId, boolean fromAEM) {
		var dc = DetachedCriteria.forClass(CategoryListing.class);
		dc.add(Restrictions.and(Restrictions.eq("categoryId", categoryId)));
		return getList(dc);
	}

	public CategoryListing getCategoryListingDetailsById(Integer id) {
		var dc = DetachedCriteria.forClass(CategoryListing.class);
		dc.add(Restrictions.and(Restrictions.eq("id", id)));
		return getFirst(dc);
	}

	public List<CategoryListing> getCategoryListingDetailsByCategoryId(Integer categoryId, String type, boolean isPublic) {
		var dc = DetachedCriteria.forClass(CategoryListing.class);
		dc.add(Restrictions.and(Restrictions.eq("categoryId", categoryId)));

		if (type == null) {
			if (isPublic == true) {
				LocalDate todayDate = LocalDate.now();
				dc.add(Restrictions.and(Restrictions.le("effectiveDate", todayDate)).add(Restrictions.ge("expiryDate", todayDate)));
			}
		} else if (type != null) {
			try {
				String getType = "%" + type.split("_")[1] + "%";
				dc.add(Restrictions.and(Restrictions.like("type.code", getType)));
			} catch (Exception e) {
			}
			if (isPublic == true) {
				LocalDate todayDate = LocalDate.now();
				dc.add(Restrictions.and(Restrictions.le("effectiveDate", todayDate)).add(Restrictions.ge("expiryDate", todayDate)));
			}
		}
		dc.addOrder(Order.desc("effectiveDate"));
		dc.addOrder(Order.desc("id"));
		addDtoProjections(dc, CategoryItemDto.class);
		return getList(dc);
	}

	Date getDateWithoutTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	Date getTomorrowDate(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, 1);
		return cal.getTime();
	}

}
