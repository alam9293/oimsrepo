package gov.stb.tag.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.Application;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TaFilingConditionExtensionAssessment;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;

@Repository
public class CommonRepository extends BaseRepository {

	public User getLicenseeUserByUserId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("travelAgent", "ta", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ta.licence", "tal", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ta.operatingAddress", "opAddr", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ta.displayAddress", "displayAddr", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	public List<Application> getApplicationsByIds(List<Integer> applicationIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		addIn(dc, "id", applicationIds);
		return getList(dc);
	}

	public List<Application> getPendingApplicationsByStatuses(List<Status> pendingStatuses) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "lastAction.status.code", pendingStatuses.stream().map(Status::getCode).collect(Collectors.toList()));
		return getList(dc);
	}

	public List<Workflow> getPendingWorkflowsByStatuses(List<Status> pendingStatuses) {
		DetachedCriteria dc = DetachedCriteria.forClass(Workflow.class);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "lastAction.status.code", pendingStatuses.stream().map(Status::getCode).collect(Collectors.toList()));
		return getList(dc);
	}

	public List<Workflow> getWorkflowsByIds(List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(Workflow.class);
		addIn(dc, "id", ids);
		return getList(dc);
	}

	public List<TaFilingConditionExtensionAssessment> getExtensionAssessmentByIds(List<Integer> assessIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingConditionExtensionAssessment.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.in("id", assessIds));
		return getList(dc);
	}

	public Type getTypeCodeTaTgList(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.in("code", code));

		return getFirst(dc);
	}

	public List<Status> getAllStatuses(String[] codes, Boolean isActive) {
		DetachedCriteria dc = DetachedCriteria.forClass(Status.class);
		dc.add(Restrictions.in("code", codes));
		dc.add(Restrictions.eq("isActive", isActive));
		return getList(dc);
	}

	public List<Type> getAllTypes(String[] codes, Boolean isActive) {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.in("code", codes));
		dc.add(Restrictions.eq("isActive", isActive));
		return getList(dc);
	}

	public List<Type> getDocTypeListByKey(String key) {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.in("code", key));
		dc.add(Restrictions.eq("isActive", true));
		return getList(dc);
	}

}
