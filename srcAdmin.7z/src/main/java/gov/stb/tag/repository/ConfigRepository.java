package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.config.ConfigSearchDto;
import gov.stb.tag.model.EmailTemplate;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.WaiveType;

@Repository
public class ConfigRepository extends BaseRepository {

	// Types
	public List<Type> getEditableCategoryTypes() {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.eq("isEditable", true));
		dc.add(Restrictions.isNull("category"));
		return getList(dc);
	}

	public List<Type> getEditableCategoryTypeLabel(ConfigSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.isNotNull("category"));
		if (searchDto.getSelectedCategory() != null) {
			dc.add(Restrictions.eq("category.code", searchDto.getSelectedCategory()));
		}
		return getList(dc);
	}

	public List<Type> getTypesByCategoryCode(ConfigSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.eq("isEditable", true));

		if (searchDto.getSelectedCategory() != null) {
			dc.add(Restrictions.eq("category.code", searchDto.getSelectedCategory()));
		}
		if (searchDto.getSelectedTypeLabel() != null) {
			dc.add(Restrictions.eq("code", searchDto.getSelectedTypeLabel()));
		}
		dc.addOrder(Order.asc("ordinal"));
		return getList(dc);
	}

	public Type getTypeByCode(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);

		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

	// Status
	public List<Type> getEditableCategoryStatuses() {

		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.eq("isEditable", true));
		dc.add(Restrictions.eq("category.code", Codes.TypeCategories.STATUS));

		return getList(dc);
	}

	public List<Status> getStatusesByCategoryCode(ConfigSearchDto searchDto) {

		DetachedCriteria dc = DetachedCriteria.forClass(Status.class);
		dc.add(Restrictions.eq("isEditable", true));

		var subCriteria = DetachedCriteria.forClass(Type.class);
		subCriteria.add(Restrictions.eq("isEditable", true));

		if (searchDto.getSelectedCategory() != null) {
			subCriteria.add(Restrictions.eq("code", searchDto.getSelectedCategory()));
		}
		subCriteria.setProjection(Projections.property("code"));
		dc.add(Subqueries.propertyIn("category", subCriteria));

		dc.addOrder(Order.asc("ordinal"));
		return getList(dc);
	}

	public Status getStatusByCode(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Status.class);

		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

	// System Parameter
	public List<Type> getEditableCategorySysParameter() {

		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.eq("isEditable", true));
		dc.add(Restrictions.eq("category.code", Codes.TypeCategories.DATA));

		return getList(dc);
	}

	public List<SystemParameter> getSysParameterByCategoryCode(ConfigSearchDto searchDto) {

		DetachedCriteria dc = DetachedCriteria.forClass(SystemParameter.class);
		dc.add(Restrictions.eq("isEditable", true));

		var subCriteria = DetachedCriteria.forClass(Type.class);
		subCriteria.add(Restrictions.eq("isEditable", true));

		if (searchDto.getSelectedCategory() != null) {
			subCriteria.add(Restrictions.eq("code", searchDto.getSelectedCategory()));
		}
		subCriteria.setProjection(Projections.property("code"));
		dc.add(Subqueries.propertyIn("dataType", subCriteria));

		dc.addOrder(Order.asc("ordinal"));
		return getList(dc);
	}

	public SystemParameter getSystemParameterByCode(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(SystemParameter.class);

		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

	// Email
	public List<EmailTemplate> getEmailName() {
		DetachedCriteria dc = DetachedCriteria.forClass(EmailTemplate.class);
		dc.add(Restrictions.eq("isActive", true));
		dc.addOrder(Order.asc("name"));
		return getList(dc);
	}

	public EmailTemplate getEmailDetail(ConfigSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(EmailTemplate.class);
		if (searchDto.getSelectedEmail() != null) {
			dc.add(Restrictions.eq("code", searchDto.getSelectedEmail()));
		}
		return getFirst(dc);
	}

	public List<WaiveType> getWaiverTypes() {
		DetachedCriteria dc = DetachedCriteria.forClass(WaiveType.class);
		return getList(dc);
	}
}
