package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import gov.stb.tag.model.*;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.CeTaskSearchDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.RainbowCardDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.dashboard.AlertItemDto;
import gov.stb.tag.dto.dashboard.AlertSearchDto;
import gov.stb.tag.dto.dashboard.TgPendingActionsItemDto;
import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@Repository
public class DashboardRepository extends CommonRepository {

	public List<Alert> getAlerts() {
		DetachedCriteria dc = DetachedCriteria.forClass(Alert.class);
		return getList(dc);
	}

	public List<ListableDto> getTaPendingApplicationsCount(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.in("lastAction.status.code", Lists.newArrayList(Codes.Statuses.TA_APP_RFA)));
		dc.add(Restrictions.eq("licence.id", licenceId));

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("lastAction.status.code"));
		projections.add(Projections.property("lastAction.status.code"), "key");
		projections.add(Projections.rowCount(), "data");

		dc.setProjection(projections);
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));

		return getList(dc);
	}

	public List<RainbowCardDto> getOfficerPendingActionsCount(String assignedOfficerLoginId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TA)));
		dc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TG)));
		dc.add(Restrictions.eq("assignee.loginId", assignedOfficerLoginId));

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("appType.code"));
		projections.add(Projections.property("appType.code"), "typeCode");
		projections.add(Projections.property("appType.label"), "typeLabel");
		projections.add(Projections.rowCount(), "count");
		dc.setProjection(projections);
		dc.addOrder(Order.asc("appType.ordinal"));
		dc.setResultTransformer(Transformers.aliasToBean(RainbowCardDto.class));
		List<RainbowCardDto> taskList = getList(dc);

		DetachedCriteria wkfdc = DetachedCriteria.forClass(Workflow.class);
		wkfdc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		wkfdc.createAlias("type", "wkfType", JoinType.LEFT_OUTER_JOIN);
		wkfdc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_TA)));
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_TG)));
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.FOR_STB_CE)));
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_PAY)));
		wkfdc.add(Restrictions.eq("assignee.loginId", assignedOfficerLoginId));
		ProjectionList wkfprojections = Projections.projectionList();
		wkfprojections.add(Projections.groupProperty("wkfType.code"));
		wkfprojections.add(Projections.property("wkfType.code"), "typeCode");
		wkfprojections.add(Projections.property("wkfType.label"), "typeLabel");
		wkfprojections.add(Projections.rowCount(), "count");
		wkfdc.setProjection(wkfprojections);
		wkfdc.addOrder(Order.asc("wkfType.ordinal"));
		wkfdc.setResultTransformer(Transformers.aliasToBean(RainbowCardDto.class));

		taskList.addAll(getList(wkfdc));

		return taskList;
	}

	public List<RainbowCardDto> getTeamPendingActionsCount(String taTgType) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TA)));
		dc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TG)));
		addEq(dc, "taTgType", taTgType);

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("appType.code"));
		projections.add(Projections.property("appType.code"), "typeCode");
		projections.add(Projections.property("appType.label"), "typeLabel");
		projections.add(Projections.rowCount(), "count");

		dc.setProjection(projections);
		dc.addOrder(Order.asc("appType.ordinal"));
		dc.setResultTransformer(Transformers.aliasToBean(RainbowCardDto.class));

		List<RainbowCardDto> taskList = getList(dc);

		// For workflow pending actions
		List<String> wkfPendingApprovalStatuses = Lists.newArrayList();
		wkfPendingApprovalStatuses.addAll(Codes.PendingApprovalStatuses.TA);
		wkfPendingApprovalStatuses.addAll(Codes.PendingApprovalStatuses.TG);

		DetachedCriteria wkfdc = DetachedCriteria.forClass(Workflow.class);
		wkfdc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		wkfdc.createAlias("type", "wkfType", JoinType.LEFT_OUTER_JOIN);
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_TA)));
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_TG)));
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_PAY)));
		wkfdc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.WorkflowStatuses.FOR_STB_CE)));
		addIn(wkfdc, "categoryType", Arrays.asList(taTgType, Codes.WorkflowCategoryType.PAY));
		if (taTgType != null) {
			if (taTgType.equals(Codes.TaTgType.TA)) {
				wkfdc.add(Restrictions.ne("type.code", Codes.Workflow.PAY_WKFLW_REFUND_TG));
			} else if (taTgType.equals(Codes.TaTgType.TG)) {
				wkfdc.add(Restrictions.ne("type.code", Codes.Workflow.PAY_WKFLW_REFUND_TA));
			}
		}

		ProjectionList wkfprojections = Projections.projectionList();
		wkfprojections.add(Projections.groupProperty("wkfType.code"));
		wkfprojections.add(Projections.property("wkfType.code"), "typeCode");
		wkfprojections.add(Projections.property("wkfType.label"), "typeLabel");
		wkfprojections.add(Projections.rowCount(), "count");
		wkfdc.setProjection(wkfprojections);
		wkfdc.addOrder(Order.asc("wkfType.ordinal"));
		wkfdc.setResultTransformer(Transformers.aliasToBean(RainbowCardDto.class));

		taskList.addAll(getList(wkfdc));

		return taskList;
	}

	public Long getWorkpassExpiryCount(LocalDate byDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		// filter by workpass holder only
		dc.add(Restrictions.not(Restrictions.ilike("uin", "S", MatchMode.START)));
		dc.add(Restrictions.not(Restrictions.ilike("uin", "T", MatchMode.START)));
		dc.add(Restrictions.in("lic.status.code", Codes.TgStatuses.WP_ACTIVE));
		if (byDate != null) {
			addLe(dc, "workPassExpiryDate", byDate);
		}
		dc.setProjection(Projections.rowCount());
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount;
	}


	public Long getTgStipendFollowUpRequiredByFinance() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TG_APP_APPROVED));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.add(Restrictions.eq("hasFollowUpRequiredByFinance", true));

		dc.setProjection(Projections.rowCount());
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount;
	}

	public Long getShortfallLetterPendingIssuanceCount() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		// filter by approved net value, letter issued date is null
		dc.add(Restrictions.isNull("letterIssuedDate"));
		dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
		dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));

		dc.setProjection(Projections.rowCount());
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount;
	}

	public Long getTaLicencePendingPrintingCount(Integer loginUserId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_APPROVED));
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		addIn(dc, "type.code", Codes.ApplicationTypes.TA_APP_LICENCE_PRINT_TYPES);
		addEq(dc, "assignee.id", loginUserId);
		addEq(dc, "licencePrintStatus.code", Codes.Statuses.TA_PRINT_PENDING);

		dc.setProjection(Projections.rowCount());
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount;
	}

	public List<ListableDto> getPaymentRequestCountByStatuses(Object[] statusCodes) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "status.code", statusCodes);

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("status.code"));
		projections.add(Projections.count("id"), "data");
		projections.add(Projections.property("status.code"), "key");
		projections.add(Projections.property("status.label"), "label");
		dc.setProjection(projections);
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));

		return getList(dc);
	}

	public List<TaApplicationItemDto> getPendingActionList(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_RFA));
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.addOrder(Order.desc("submissionDate"));
		addDtoProjections(dc, TaApplicationItemDto.class);
		return getList(dc);
	}

	public List<TgPendingActionsItemDto> getTgPendingActionList(Integer licenceId) {
		DetachedCriteria dc = getTgPendingActionDC(licenceId);
		addDtoProjections(dc, TgPendingActionsItemDto.class);
		return getList(dc);
	}

	public Integer getTgPendingActionCount(Integer licenceId) {
		DetachedCriteria dc = getTgPendingActionDC(licenceId);
		addDtoProjections(dc, TgPendingActionsItemDto.class);
		return getList(dc).size();
	}

	private DetachedCriteria getTgPendingActionDC(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);

		Conjunction conj = Restrictions.conjunction(); // AND
		conj.add(Restrictions.eq("licencePrintStatus.code", Codes.Statuses.PRINT_PENDING_COLLECTION));
		conj.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TG_APP_APPROVED));

		Disjunction disj = Restrictions.disjunction(); // OR
		disj.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TG_APP_RFA));
		disj.add(Restrictions.eq("licencePrintStatus.code", Codes.Statuses.PRINT_PENDING_PAYMENT));
		disj.add(conj);
		dc.add(disj);

		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.addOrder(Order.desc("submissionDate"));
		return dc;
	}

	public Long getTgLicencePendingPrintingCount() {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TG_APP_APPROVED));
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));
		dc.add(Restrictions.not(Restrictions.in("type.code",
				new ArrayList<>(List.of(Codes.ApplicationTypes.TG_APP_CANCELLATION, Codes.ApplicationTypes.TG_APP_MRC_SUBMISSION, Codes.ApplicationTypes.TG_APP_PDC_SUBMISSION)))));
		addEq(dc, "licencePrintStatus.code", Statuses.PRINT_PENDING_PRINTING);

		dc.setProjection(Projections.rowCount());
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount;
	}

	public ResultDto<AlertItemDto> getUserAlerts(Integer userId, String taTgType, AlertSearchDto searchDto) {
		DetachedCriteria alertQuery = generateUserAlertsDc(userId, taTgType);
		addDtoProjections(alertQuery, AlertItemDto.class);
		return search(alertQuery, searchDto, true);
	}

	public List<Alert> getUserAlerts(Integer userId, String taTgType) {
		DetachedCriteria alertQuery = generateUserAlertsDc(userId, taTgType);
		return getList(alertQuery);
	}

	public Long getTotalAlertsUnread(Integer userId, String taTgType) {
		DetachedCriteria userAlertQuery = DetachedCriteria.forClass(User.class);
		if (Codes.TaTgType.TA.equals(taTgType)) {
			userAlertQuery.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
			userAlertQuery.createAlias("travelAgent.alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		} else if (Codes.TaTgType.TG.equals(taTgType)) {
			userAlertQuery.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
			userAlertQuery.createAlias("touristGuide.alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		} else if (Codes.TaTgType.TP.equals(taTgType)) {
			userAlertQuery.createAlias("tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
			userAlertQuery.createAlias("tgTrainingProvider.alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		} else {
			userAlertQuery.createAlias("alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		}
		userAlertQuery.add(Restrictions.eq("id", userId));
		userAlertQuery.setProjection(Projections.property("alerts.id"));

		DetachedCriteria alertQuery = DetachedCriteria.forClass(Alert.class);
		alertQuery.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		alertQuery.add(Subqueries.propertyIn("id", userAlertQuery));
		alertQuery.add(Restrictions.eq("status.code", Codes.AlertStatus.UNREAD));
		alertQuery.setProjection(Projections.count("id"));
		return getFirst(alertQuery);
	}

	private DetachedCriteria generateUserAlertsDc(Integer userId, String taTgType) {
		DetachedCriteria userAlertQuery = DetachedCriteria.forClass(User.class);
		if (Codes.TaTgType.TA.equals(taTgType)) {
			userAlertQuery.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
			userAlertQuery.createAlias("travelAgent.alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		} else if (Codes.TaTgType.TG.equals(taTgType)) {
			userAlertQuery.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
			userAlertQuery.createAlias("touristGuide.alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		} else if (Codes.TaTgType.TP.equals(taTgType)) {
			userAlertQuery.createAlias("tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
			userAlertQuery.createAlias("tgTrainingProvider.alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		} else {
			userAlertQuery.createAlias("alerts", "alerts", JoinType.LEFT_OUTER_JOIN);
		}
		userAlertQuery.add(Restrictions.eq("id", userId));
		userAlertQuery.setProjection(Projections.property("alerts.id"));

		DetachedCriteria alertQuery = DetachedCriteria.forClass(Alert.class);
		alertQuery.createAlias("module", "module", JoinType.LEFT_OUTER_JOIN);
		alertQuery.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		alertQuery.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		alertQuery.add(Subqueries.propertyIn("id", userAlertQuery));
		alertQuery.add(Restrictions.ne("status.code", Codes.AlertStatus.DELETED));
		alertQuery.addOrder(Order.desc("createdDate"));

		return alertQuery;
	}

	public ResultDto<CeTask> searchCeTask(CeTaskSearchDto searchDto, Integer assignedOfficerLoginId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("oic", "oic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("forCase", "forCase", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));
		addEq(dc, "uenUin", searchDto.getUenUin());
		addLike(dc, "forCase.caseNo", searchDto.getCaseNo());
		addLike(dc, "assignee.name", searchDto.getAssignee());
		addLike(dc, "oic.name", searchDto.getOic());
		addLike(dc, "details", searchDto.getDetails());
		if (!Strings.isNullOrEmpty(searchDto.getSla())) {
			String operator = getOperator(searchDto.getSla().trim());
			String operatorVal = getOperatorValue(searchDto.getSla().trim());
			switch (operator) {
			case Codes.Operator.GT:
				addGt(dc, "slaExpiryDate", LocalDate.now().plusDays(Integer.parseInt(operatorVal)));
				break;
			case Codes.Operator.GE:
				addGe(dc, "slaExpiryDate", LocalDate.now().plusDays(Integer.parseInt(operatorVal)));
				break;
			case Codes.Operator.LT:
				addLt(dc, "slaExpiryDate", LocalDate.now().plusDays(Integer.parseInt(operatorVal)));
				break;
			case Codes.Operator.LE:
				addLe(dc, "slaExpiryDate", LocalDate.now().plusDays(Integer.parseInt(operatorVal)));
				break;
			case Codes.Operator.EQUAL:
			default:
				addEq(dc, "slaExpiryDate", LocalDate.now().plusDays(Integer.parseInt(operatorVal)));
				break;
			}
		}
		addEq(dc, "status.code", searchDto.getStatus());
		if (assignedOfficerLoginId != null) {
			dc.add(Restrictions.disjunction().add(Restrictions.eq("assignee.id", assignedOfficerLoginId)).add(Restrictions.eq("oic.id", assignedOfficerLoginId)));
		}
		if (!Strings.isNullOrEmpty(searchDto.getName())) {
			dc.add(Restrictions.disjunction().add(Restrictions.like("name", searchDto.getName(), MatchMode.ANYWHERE))
					.add(Restrictions.like("licence.licenceNo", searchDto.getName(), MatchMode.ANYWHERE)));
		}
		if (searchDto.getOrderProperty() == null) {
			dc.addOrder(Order.desc("createdDate"));
		}
		return search(dc, searchDto, true);
	}

	private String getOperator(String searchText) {
		String op = Codes.Operator.EQUAL;
		for (int i = 0; i < searchText.length(); i++) {
			if (StringUtils.isNumeric(searchText.substring(i))) {
				if (i > 0) {
					return searchText.substring(0, i);
				}
				return op;
			}
		}
		return op;
	}

	private String getOperatorValue(String searchText) {
		for (int i = 0; i < searchText.length(); i++) {
			if (StringUtils.isNumeric(searchText.substring(i))) {
				return searchText.substring(i);
			}
		}
		return "0";
	}
}
