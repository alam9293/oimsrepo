package gov.stb.tag.repository;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.emailing.EmailBroadcastSearchDto;
import gov.stb.tag.dto.emailing.EmailingItemDto;
import gov.stb.tag.model.EmailBroadcast;

@Repository
public class EmailBroadcastRepository extends CommonRepository {

	public ResultDto<EmailingItemDto> getAll(String type, EmailBroadcastSearchDto searchDto) {

		DetachedCriteria dc = DetachedCriteria.forClass(EmailBroadcast.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("type.code", Codes.EmailBroadcast.get(type.toUpperCase())));
		addEq(dc, "isActive", searchDto.isActive());

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("id"));
		}

		addDtoProjections(dc, EmailingItemDto.class);
		return search(dc, searchDto, true);
	}

}
