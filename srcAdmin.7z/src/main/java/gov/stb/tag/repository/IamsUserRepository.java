package gov.stb.tag.repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.iams.IamsRoleDto;
import gov.stb.tag.dto.iams.IamsUserDto;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.User;
import org.hibernate.criterion.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class IamsUserRepository extends CommonRepository {

	/**
	 * Get STB user by login ID
	 * 
	 * @param loginId
	 * @return
	 */
	public User getUserByLoginId(String loginId) {
		return getUserByLoginId(loginId, null);
	}

	public User getUserByLoginId(String loginId, String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("loginId", loginId));
		if (uen != null) {
			dc.add(Restrictions.eq("uen", uen));
		} else {
			dc.add(Restrictions.isNull("uen"));
		}
		dc.add(Restrictions.eq("type.code", Codes.UserTypes.USER_STB));
		return getFirst(dc);
	}

	/**
	 * Get all STB users
	 *
	 */
	public List<IamsUserDto> getAllUsers() {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("type.code", Codes.UserTypes.USER_STB));
		addDtoProjections(dc, IamsUserDto.class);
		return getList(dc);
	}

	/**
	 * Get all roles
	 *
	 */
	public List<IamsRoleDto> getAllRoles() {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		addDtoProjections(dc, IamsRoleDto.class);
		return getList(dc);
	}

	/**
	 * Get role by code
	 *
	 * @param code
	 * @return
	 */
	public Role getRoleByCode(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}
}
