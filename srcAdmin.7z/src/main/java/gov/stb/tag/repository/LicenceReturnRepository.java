package gov.stb.tag.repository;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.licencereturn.LicenceReturnBatchItemDto;
import gov.stb.tag.dto.licencereturn.LicenceReturnBatchSearchDto;
import gov.stb.tag.model.LicenceReturnBatch;

@Repository
public class LicenceReturnRepository extends BaseRepository {

	public ResultDto<LicenceReturnBatchItemDto> getPendingList(LicenceReturnBatchSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(LicenceReturnBatch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		if (!searchDto.getAllRecords()) {
			addEq(dc, "status.code", Codes.Statuses.LCRTN_PENDING);
		}

		addLike(dc, "travelAgent.uen", searchDto.getUen());
		addLike(dc, "travelAgent.name", searchDto.getName());
		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addLe(dc, "dueDate", searchDto.getDeadlineTo());
		addGe(dc, "dueDate", searchDto.getDeadlineFrom());
		addEq(dc, "status.code", searchDto.getStatus());

		addDtoProjections(dc, LicenceReturnBatchItemDto.class);
		return search(dc, searchDto, true);

	}

	public LicenceReturnBatch getBatchRecord(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(LicenceReturnBatch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licences", "licences", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);

	}

	public LicenceReturnBatch getBatchRecordByApp(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(LicenceReturnBatch.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licences", "licences", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);

	}

}
