package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.payment.PaymentRefundSearchDto;
import gov.stb.tag.model.PaymentRefund;
import gov.stb.tag.model.PaymentRequest;

@Repository
public class PaymentRefundRepository extends BaseRepository {

	public PaymentRefund getPaymentRefund(String billRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRefund.class);
		dc.add(Restrictions.eq("billRefNo", billRefNo));
		return getFirst(dc);
	}

	public PaymentRefund getPaymentRefundNotRejected(String billRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRefund.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("billRefNo", billRefNo));
		dc.add(Restrictions.ne("lastAction.status.code", Codes.Statuses.PAY_WKFLW_REJ));
		return getFirst(dc);
	}

	public ResultDto<PaymentRefund> getPaymentRequests(PaymentRefundSearchDto searchDto, List<String> viewableTypes) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRefund.class);

		var subCriteria = DetachedCriteria.forClass(PaymentRequest.class);
		subCriteria.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		subCriteria.add(Restrictions.in("type.code", viewableTypes));
		subCriteria.setProjection(Projections.property("billRefNo"));
		subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		dc.add(Subqueries.propertyIn("billRefNo", subCriteria));

		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		if (!searchDto.getAllRecords()) {
			dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.PAY_WKFLW_PEND_APPR));
		}
		addLike(dc, "billRefNo", searchDto.getBillRefNo());
		return search(dc, searchDto, true);
	}
}
