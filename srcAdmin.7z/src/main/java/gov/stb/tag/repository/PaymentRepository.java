package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.payment.PaymentRequestItemDto;
import gov.stb.tag.dto.payment.PaymentRequestSearchDto;
import gov.stb.tag.dto.payment.PaymentTxnSearchDto;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentStatusSpan;
import gov.stb.tag.model.PaymentTxn;

@Repository
public class PaymentRepository extends BaseRepository {

	public PaymentRequest getPaymentRequest(String billRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.add(Restrictions.eq("billRefNo", billRefNo));
		return getFirst(dc);
	}

	public List<PaymentRequest> getPaymentRequestByTxn(Integer txnId) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("paymentTxns", "paymentTxns", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("paymentTxns.id", txnId));
		return getList(dc);
	}

	public ResultDto<PaymentRequestItemDto> getPaymentRequests(PaymentRequestSearchDto searchDto, List<String> viewableTypes) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastTxn", "lastTxn", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "type.code", viewableTypes);
		addLike(dc, "billRefNo", searchDto.getBillRefNo() == null ? "" : searchDto.getBillRefNo().trim());
		addLike(dc, "refNo", searchDto.getRefNo() == null ? "" : searchDto.getRefNo().trim());
		addLike(dc, "payerUinUen", searchDto.getPayerUinUen() == null ? "" : searchDto.getPayerUinUen().trim());
		addLike(dc, "payerName", searchDto.getPayerName() == null ? "" : searchDto.getPayerName().trim());
		addEq(dc, "payableAmount", searchDto.getPayableAmount());
		addEq(dc, "type.code", searchDto.getTypeCode());
		addEq(dc, "status.code", searchDto.getStatusCode());
		addEq(dc, "lastTxn.status.code", searchDto.getLastTxnStatusCode());
		addEq(dc, "lastTxn.paymentType.code", searchDto.getPaymentType());
		if (searchDto.getTxnDateTo() != null) {
			addLt(dc, "lastTxn.txnDate", searchDto.getTxnDateTo().plusDays(1));
		}

		addGe(dc, "lastTxn.txnDate", searchDto.getTxnDateFrom());

		if (searchDto.getPaymentTxnId() != null) {
			dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			dc.createAlias("paymentTxns", "paymentTxns");
			addEq(dc, "paymentTxns.id", searchDto.getPaymentTxnId());
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("lastTxn.txnDate"));
		}

		addDtoProjections(dc, PaymentRequestItemDto.class);
		return search(dc, searchDto, true);
	}

	public ResultDto<PaymentTxn> getPaymentTxns(PaymentTxnSearchDto searchDto, String userUinUen) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentTxn.class);
		dc.createAlias("paymentType", "paymentType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("paymentRequests", "paymentRequests", JoinType.LEFT_OUTER_JOIN);

		if (searchDto.getTxnDateTo() != null) {
			addLt(dc, "txnDate", searchDto.getTxnDateTo().plusDays(1));

		}
		addGe(dc, "txnDate", searchDto.getTxnDateFrom());
		addEq(dc, "id", searchDto.getId());
		addEq(dc, "status.code", searchDto.getStatus());
		addEq(dc, "paymentRequests.billRefNo", searchDto.getBillRefNo());
		addEq(dc, "paymentRequests.payerUinUen", userUinUen);
		addNe(dc, "paymentRequests.type.code", Codes.TgPaymentRequestTypes.PAYREQ_TG_STIPEND);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("txnDate"));
		}
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return search(dc, searchDto, true);
	}

	public List<PaymentRequest> getPaymentRequestsForPaymentByPayerId(String payerUinUen) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.PAYREQ_NOT_PAID));
		addEq(dc, "isPrePayment", false);
		addEq(dc, "payerUinUen", payerUinUen);
		dc.addOrder(Order.asc("createdDate"));
		return getList(dc);
	}

	public PaymentRequest getPaymentRequest(String billRefNo, String payerUinUen) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		addEq(dc, "billRefNo", billRefNo);
		addEq(dc, "payerUinUen", payerUinUen);

		return getFirst(dc);
	}

	public PaymentTxn getPrevPaymentTxn(Integer currentPaymentTxnId, Integer paymentRequestId) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentTxn.class);
		dc.createAlias("paymentRequests", "paymentRequests");
		dc.add(Restrictions.ne("id", currentPaymentTxnId));
		dc.add(Restrictions.eq("paymentRequests.id", paymentRequestId));
		dc.addOrder(Order.desc("txnDate"));
		return getFirst(dc);
	}

	public PaymentRequest getPaymentRequestsForPaymentTypeByPayerId(String payerUinUen, String paymentTypeCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		addEq(dc, "payerUinUen", payerUinUen);
		addEq(dc, "type.code", paymentTypeCode);
		dc.addOrder(Order.asc("createdDate"));
		return getFirst(dc);
	}

	public ResultDto<PaymentStatusSpan> getPaymentStatusSpans(Integer payReqId, WorkflowActionSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentStatusSpan.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("files", "files", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("paymentRequest", "paymentRequest", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("paymentRequest.id", payReqId));
		dc.addOrder(Order.desc("createdDate"));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return search(dc, searchDto, true);
	}

	public List<PaymentStatusSpan> getPaymentStatusSpans(Integer payReqId) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentStatusSpan.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("files", "files", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("paymentRequest", "paymentRequest", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("paymentRequest.id", payReqId));
		dc.addOrder(Order.desc("createdDate"));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public Licence getLicenceByLicenceNo(String licenceNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.eq("licenceNo", licenceNo));

		return getFirst(dc);
	}

	public String getPaymentTxnContinueUrl(Integer txnId) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentTxn.class);
		dc.add(Restrictions.eq("id", txnId));
		dc.setProjection(Projections.property("continueUrl"));
		return getFirst(dc);
	}
}
