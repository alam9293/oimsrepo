package gov.stb.tag.repository;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.Job;

@Repository
public class ReportRepository extends BaseRepository {

	public Job getByClassName(String name) {
		DetachedCriteria dc = DetachedCriteria.forClass(Job.class);
		dc.add(Restrictions.eq("className", name));
		return getFirst(dc);
	}

}
