package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFyUpdate;
import gov.stb.tag.model.TaLicenceCessation;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.User;

@Repository
public class TestRepository extends BaseRepository {

	public Object getNumberOfTaCandidateUser() {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "roles", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("roles.code", Codes.Roles.TA_CANDIDATE));

		dc.setProjection(Projections.rowCount());
		return getProjectedFirstValue(dc);

	}

	public ApplicationFile getFirstPassportPhoto() {
		DetachedCriteria dc = DetachedCriteria.forClass(ApplicationFile.class);
		dc.createAlias("file", "file", JoinType.INNER_JOIN);
		dc.add(Restrictions.eq("documentType.code", Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO));

		dc.addOrder(Order.desc("createdDate"));
		return getFirst(dc);
	}

	public Boolean uenUsed(String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("uen", uen));
		User user = getFirst(dc);

		if (user == null) {
			return false;
		} else {
			return true;

		}
	}

	public Boolean uinUsedByTgCdd(String uin) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCandidate.class);
		dc.add(Restrictions.eq("uin", uin));
		TgCandidate cdd = getFirst(dc);

		if (cdd == null) {
			return false;
		} else {
			return true;

		}
	}

	public TgCourse getTgMrc() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("tgTrainingProvider", "tgTrainingProvider", JoinType.INNER_JOIN);
		dc.add(Restrictions.eq("type.code", Codes.Types.TP_COURSE_MRC));
		dc.add(Restrictions.eq("tgTrainingProvider.id", 1));
		return getFirst(dc);
	}

	public List<TgCourse> getTgPdc() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("tgTrainingProvider", "tgTrainingProvider", JoinType.INNER_JOIN);
		dc.add(Restrictions.eq("type.code", Codes.Types.TP_COURSE_PDC));
		dc.add(Restrictions.eq("tgTrainingProvider.id", 1));
		return getList(dc);
	}

	public List<TouristGuide> getTouristGuides(List<String> uins) {
		DetachedCriteria dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.add(Restrictions.in("uin", uins));
		return getList(dc);
	}

	public List<TgTrainingProvider> getTrainingProvider() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		return getList(dc);
	}

	public List<Licence> getTaLicencesByExpiryDate(LocalDate expiryDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		dc.add(Restrictions.eq("expiryDate", expiryDate));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_ACTIVE));
		return getList(dc);
	}

	public List<TouristGuide> getActiveTouristGuides() {
		DetachedCriteria dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.status.code", Codes.Statuses.TG_ACTIVE));
		return getList(dc);
	}

	public List<CeTaCheckScheduleItem> getApprovedScheduleItem() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaCheckScheduleItem.class);
		addEq(dc, "isApproved", Boolean.TRUE);
		addEq(dc, "isDeleted", Boolean.FALSE);
		addLt(dc, "scheduledDate", LocalDate.now());
		addEq(dc, "checkType.code", Codes.Types.TA_CHECK_TATI);

		DetachedCriteria ceTaCheckDc = DetachedCriteria.forClass(CeTaCheck.class);
		ceTaCheckDc.createAlias("ceTaCheckScheduleItem", "ceTaCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		addEq(ceTaCheckDc, "isDeleted", Boolean.FALSE);
		ceTaCheckDc.setProjection(Projections.property("ceTaCheckScheduleItem.id"));
		ceTaCheckDc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

		dc.add(Subqueries.propertyNotIn("id", ceTaCheckDc));

		dc.add(Subqueries.notExists(ceTaCheckDc));

		return getList(dc);
	}

	public List<Licence> getLicenceTarR7bInfringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("tarR7bInfringement", "tarR7bInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR7bInfringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR7bInfringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<Licence> getLicenceTarR8Infringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("tarR8Infringement", "tarR8Infringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR8Infringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR8Infringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<TaFilingCondition> getFilingTarR141Infringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("tarR141Infringement", "tarR141Infringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR141Infringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR141Infringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<TaFyUpdate> getTarR13Infringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFyUpdate.class);
		dc.createAlias("tarR13Infringement", "tarR13Infringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR13Infringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR13Infringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<TaLicenceCessation> getTarR7aInfringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceCessation.class);
		dc.createAlias("tarR7aInfringement", "tarR7aInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR7aInfringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR7aInfringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<TaNetValueShortfall> getTarR9Infringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("tarR9Infringement", "tarR9Infringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR9Infringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR9Infringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<TaStakeholder> getTarR153bInfringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("tarR153bInfringement", "tarR153bInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR153bInfringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR153bInfringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<TaStakeholderApplication> getTarR153aInfringement() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholderApplication.class);
		dc.createAlias("tarR153aInfringement", "tarR153aInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("tarR153aInfringement"));

		DetachedCriteria ceTaskSubCriteria = DetachedCriteria.forClass(CeTask.class);
		ceTaskSubCriteria.add(Restrictions.isNotNull("forCase"));
		ceTaskSubCriteria.setProjection(Projections.property("forCase.id"));

		dc.add(Subqueries.propertyNotIn("tarR153aInfringement.ceCase.id", ceTaskSubCriteria));

		return getList(dc);
	}

	public List<CeCaseInfringer> getUtaCeCaseInfringer() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringer.class);
		addIsNull(dc, "licence");
		addEq(dc, "idType.code", Codes.Types.CE_ID_TYPE_ENTITY);
		addEq(dc, "isDeleted", false);
		return getList(dc);
	}

	public List<TaStakeholder> getAllKe() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		dc.addOrder(Order.asc("licence.id"));
		dc.addOrder(Order.asc("appointedDate"));
		return getList(dc);
	}

	public List<TaNetValueShortfall> getUnfulfiledShortfallAfterDueDate() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueRectification", "taNetValueRectification", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_WKFLW_APPROVED));
		dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
		dc.add(Restrictions.isNull("tarR9Infringement"));
		dc.add(Restrictions.in("licence.status.code", Codes.TaStatuses.GENERALLY_ACTIVE));

		Conjunction unfulfilPastDueDate = Restrictions.conjunction();
		unfulfilPastDueDate.add(Restrictions.lt("rectificationDueDate", LocalDate.now()));
		unfulfilPastDueDate.add(Restrictions.isNull("extendedDueDate"));
		unfulfilPastDueDate.add(Restrictions.isNull("taNetValueRectification"));

		Conjunction unfulfilPastExtendedDueDate = Restrictions.conjunction();
		unfulfilPastExtendedDueDate.add(Restrictions.lt("extendedDueDate", LocalDate.now()));
		unfulfilPastExtendedDueDate.add(Restrictions.isNotNull("extendedDueDate"));
		unfulfilPastExtendedDueDate.add(Restrictions.isNull("taNetValueRectification"));

		Conjunction rectifiedPastDueDate = Restrictions.conjunction();
		rectifiedPastDueDate.add(Restrictions.lt("extendedDueDate", LocalDate.now()));
		rectifiedPastDueDate.add(Restrictions.isNotNull("extendedDueDate"));
		rectifiedPastDueDate.add(Restrictions.gtProperty("taNetValueRectification.rectifiedDate", "rectificationDueDate"));

		Conjunction rectifiedPastExtendedDueDate = Restrictions.conjunction();
		rectifiedPastExtendedDueDate.add(Restrictions.lt("extendedDueDate", LocalDate.now()));
		rectifiedPastExtendedDueDate.add(Restrictions.isNotNull("extendedDueDate"));
		rectifiedPastExtendedDueDate.add(Restrictions.gtProperty("taNetValueRectification.rectifiedDate", "extendedDueDate"));

		Disjunction disjunctions = Restrictions.disjunction();
		disjunctions.add(unfulfilPastDueDate);
		disjunctions.add(unfulfilPastExtendedDueDate);
		disjunctions.add(rectifiedPastDueDate);
		disjunctions.add(rectifiedPastExtendedDueDate);
		dc.add(disjunctions);

		return getList(dc);
	}
}
