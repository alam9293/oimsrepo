package gov.stb.tag.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.dashboard.UserProfileItemDto;
import gov.stb.tag.dto.dashboard.UserProfileSearchDto;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Function;
import gov.stb.tag.model.PasswordHistory;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.User;

@Repository
public class UserRepository extends CommonRepository {

	/**
	 * Get user by login ID
	 * 
	 * @param loginId
	 * @return
	 */
	public User getUserByLoginId(String loginId) {
		return getUserByLoginId(loginId, null);
	}

	public User getUserByLoginId(String loginId, String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("loginId", loginId));
		if (uen != null) {
			dc.add(Restrictions.eq("uen", uen));
		} else {
			dc.add(Restrictions.isNull("uen"));
		}
		return getFirst(dc);
	}

	/**
	 * Get user by id join roles
	 * 
	 * @param id
	 * @return User
	 */
	public User getUserWithRolesById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	/**
	 * Get user by Email Address
	 * 
	 * @param emailAddress
	 * @return
	 */
	public User getUserByEmailAddress(String emailAddress) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("emailAddress", emailAddress));
		return getFirst(dc);
	}

	public User getUserByLoginIdOrEmailAddress(String loginId, String emailAddress) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.disjunction().add(Restrictions.eq("loginId", loginId)).add(Restrictions.eq("emailAddress", emailAddress)));
		return getFirst(dc);
	}

	public User getUserWithValidLoginCredential(String loginId, String uen, String type) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("type", "t", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("r.functions", "f", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("loginId", loginId));
		dc.add(Restrictions.eq("type.code", type));
		if (Codes.UserTypes.USER_PUBLIC.equals(type)) {
			dc.add(Restrictions.disjunction().add(Restrictions.eq("type.code", Codes.UserTypes.USER_PUBLIC)).add(Restrictions.eq("type.code", Codes.UserTypes.USER_PUBLIC_PORTAL)));
		} else {
			dc.add(Restrictions.eq("type.code", type));
		}
		dc.add(Restrictions.in("status.code", UserHelper.withLoginCredentialStatuses()));
		addEq(dc, "uen", uen);

		return getFirst(dc);
	}

	/**
	 * Get user by login ID and with valid login credentials
	 * 
	 * @param loginId
	 * @return
	 */
	public User getUserWithValidLoginCredential(String loginId, String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("r.functions", "f", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("loginId", loginId));
		dc.add(Restrictions.in("status.code", UserHelper.withLoginCredentialStatuses()));
		if (uen != null && !uen.equals(Codes.SpCp.NO_UEN)) {
			addEq(dc, "uen", uen);
		} else {
			dc.add(Restrictions.isNull("uen"));
		}

		return getFirst(dc);
	}

	/**
	 * Get user by id, along with the roles and functions
	 * 
	 * @param id
	 * @return
	 */
	public User getUserWithRoleAndFunctions(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("r.functions", "f", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("f.module", "m", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	/**
	 * Get list of users by user ids
	 * 
	 * @param userIds
	 * @return
	 */
	public List<User> getUsers(Set<Integer> userIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.in("id", userIds));
		return getList(dc);
	}

	public List<User> getUsers(String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("uen", uen));
		return getList(dc);
	}

	public Role getRoleWithFunctions(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		dc.createAlias("functions", "f", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

	public Role getRole(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

	public User getUserWithPasswordHistories(Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("passwordHistories", "p", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", userId));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

		return getFirst(dc);
	}

	public boolean isToChangePassword(Integer userId, Integer daysToExpire) {
		DetachedCriteria dc = DetachedCriteria.forClass(PasswordHistory.class);
		dc.add(Restrictions.eq("user.id", userId));
		dc.addOrder(Order.desc("createdDate"));
		PasswordHistory passwordHistory = getFirst(dc);
		return passwordHistory == null || LocalDateTime.now().minusDays(daysToExpire).isAfter(passwordHistory.getCreatedDate());
	}

	/**
	 * Get list of active users
	 * 
	 * @param userIds
	 * @return
	 */
	public List<User> getActiveUsers() {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		return getList(dc);
	}

	/**
	 * Get list of users by candidate id
	 *
	 * @param tgCandidateId
	 * @return
	 */
	public User getUserByTgCandidateId(Integer tgCandidateId) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("tgCandidate.id", tgCandidateId));
		return getFirst(dc);
	}

	/**
	 * Get list of active users by roles
	 * 
	 * @param roleCodes
	 * @return
	 */
	public List<User> getActiveUsersByRoles(List<String> roleCodes) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		dc.add(Restrictions.in("r.code", roleCodes));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<ListableDto> getListableActiveUsersByRoles(List<String> roleCodes) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		dc.add(Restrictions.in("r.code", roleCodes));
		dc.addOrder(Order.desc("r.code"));
		dc.addOrder(Order.asc("name"));

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.property("id"), "key");
		projections.add(Projections.property("name"), "label");
		projections.add(Projections.property("loginId"), "otherLabel");
		dc.setProjection(Projections.distinct(projections));

		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));
		return getList(dc);
	}

	/**
	 * Get list of active users by role
	 * 
	 * @param roleCode
	 * @return
	 */
	public List<User> getActiveUsersByRole(String roleCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		dc.add(Restrictions.eq("r.code", roleCode));
		return getList(dc);
	}

	public ResultDto<UserProfileItemDto> getUsersList(UserProfileSearchDto dto, boolean toPaginate) {
		var dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("type.code", Codes.UserTypes.USER_STB));

		if (dto.getRoles() != null) {
			var subCriteria = DetachedCriteria.forClass(User.class);
			subCriteria.createAlias("roles", "role", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.in("role.code", dto.getRoles()));
			subCriteria.setProjection(Projections.property("id"));

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}

		if (!Strings.isNullOrEmpty(dto.getLoginId())) {
			addLike(dc, "loginId", dto.getLoginId());
		}
		if (!Strings.isNullOrEmpty(dto.getName())) {
			addLike(dc, "name", dto.getName());
		}
		if (!Strings.isNullOrEmpty(dto.getEmailAddress())) {
			addLike(dc, "emailAddress", dto.getEmailAddress());
		}
		if (!Strings.isNullOrEmpty(dto.getTaAssigneeChars())) {
			for (String s : dto.getAssigneeChars()) {
				addLike(dc, "taAssigneeChars", s);
			}
		}

		if (dto.getDepartment() != null) {
			addEq(dc, "department.code", dto.getDepartment());
		}
		if (dto.getStatus() != null) {
			addEq(dc, "status.code", dto.getStatus());
		}
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return search(dc, dto, toPaginate);
	}

	public List<Function> getModFunction(UserProfileSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Function.class);
		dc.createAlias("module", "module", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.in("module.code", searchDto.getModuleList()));

		if (!Strings.isNullOrEmpty(searchDto.getFunction())) {
			addEq(dc, "code", searchDto.getFunction().trim());
		}

		dc.addOrder(Order.asc("module.code"));
		dc.addOrder(Order.asc("label"));
		return getList(dc);
	}

	public List<Role> getRolesByFunction(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		dc.createAlias("functions", "f", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("f.code", code));
		return getList(dc);
	}

	public List<Role> getAllRoles() {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		dc.addOrder(Order.asc("code"));
		return getList(dc);
	}

	public List<User> getFinanceUsers() {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "role", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("role.code", Codes.Roles.FINANCE));
		return getList(dc);
	}
}
