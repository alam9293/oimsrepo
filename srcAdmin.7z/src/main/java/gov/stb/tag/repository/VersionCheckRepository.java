package gov.stb.tag.repository;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.persister.entity.EntityPersister;
import org.springframework.stereotype.Repository;

@Repository
public class VersionCheckRepository extends BaseRepository {

	private static final String ENTITY_PACKAGE = "gov.stb.tag.model.";

	public String getCurrentVersion(String entityName, String entityId) {
		Map<String, String> map = getCurrentVersions(entityName, Arrays.asList(entityId));
		return map.get(entityId);
	}

	public Map<String, String> getCurrentVersions(String entityName, List<String> entityIds) {
		try {
			Class<?> clazz = Class.forName(ENTITY_PACKAGE + entityName);
			DetachedCriteria dc = DetachedCriteria.forClass(clazz);
			EntityPersister entityPersister = getEntityPersister(clazz);
			String idProperty = entityPersister.getIdentifierPropertyName();
			if (entityPersister.getIdentifierType().getName().equalsIgnoreCase("integer")) {
				List<Integer> entityIntIds = entityIds.stream().map(entityId -> Integer.valueOf(entityId)).collect(Collectors.toList());
				dc.add(Restrictions.in(idProperty, entityIntIds));
			} else {
				dc.add(Restrictions.in(idProperty, entityIds));
			}
			dc.setProjection(Projections.projectionList().add(Property.forName(idProperty)).add(Property.forName("version")));
			List<Object[]> rows = getProjectedList(dc);
			Map<String, String> map = new HashMap<>();
			rows.forEach(row -> map.put(row[0] + "", row[1] + ""));
			return map;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private EntityPersister getEntityPersister(Class<?> clazz) {
		return ((SessionFactoryImplementor) getSessionFactory()).getMetamodel().entityPersister(clazz);
	}

}
