package gov.stb.tag.repository;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.WorkflowFileSearchDto;
import gov.stb.tag.dto.workflow.TaWorkflowSearchDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowFile;
import gov.stb.tag.model.WorkflowStepAssignment;

@Repository
public class WorkflowRepository extends CommonRepository {

	public DetachedCriteria filter(TaWorkflowSearchDto searchDto, DetachedCriteria dc, Integer userId) {

		addLike(dc, "travelAgent.name", searchDto.getName());
		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addLike(dc, "travelAgent.uen", searchDto.getUen());
		addIn(dc, "lastAction.status.code", searchDto.getApplicationStatuses());
		addEq(dc, "type.code", searchDto.getApplicationType());
		addLike(dc, "assignee.name", searchDto.getAssignedOfficer());
		if (searchDto.getMyApplications() == true) {
			addEq(dc, "assignee.id", userId);
		}
		return dc;
	}

	public ResultDto<WorkflowAction> getWorkflowActionsListByWorkflowId(Integer workflowId, WorkflowActionSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowAction.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("recommendation", "recommendation", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("files", "files", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("workflow.id", workflowId));
		dc.addOrder(Order.desc("createdDate"));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return search(dc, searchDto, true);
	}

	public ResultDto<WorkflowFile> getWorkflowFilesListByWorkflowId(Integer workflowId, WorkflowFileSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowFile.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("file", "file", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("workflow.id", workflowId));
		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		dc.addOrder(Order.desc("createdDate"));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return search(dc, searchDto, false);
	}

	/**
	 * Get Document code, label, instructions details into AttachmentDto from document list
	 * 
	 * @param docTypeList
	 * @return
	 */
	public List<AttachmentDto> getSupportingDocList(Object[] docTypeList, FileHelper fileHelper) {
		List<AttachmentDto> dtoFileList = new ArrayList<AttachmentDto>();
		List<Type> dtoList = new ArrayList<Type>();

		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		addIn(dc, "code", docTypeList);
		dc.addOrder(Order.asc("label"));
		dtoList = listByDetachedCriteria(dc);

		for (Type row : dtoList) {
			dtoFileList.add(AttachmentDto.buildFromDocType(row));
		}

		return dtoFileList;
	}

	/**
	 * Get All files and build into DTO for a application
	 * 
	 * @param applicationId
	 * @return
	 */
	public List<AttachmentDto> getFiles(Integer workflowId, FileHelper fileHelper) {
		List<WorkflowFile> dtoList = new ArrayList<WorkflowFile>();
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowFile.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("file", "file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("documentType", "documentType", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		addEq(dc, "workflow.id", workflowId);
		dc.addOrder(Order.asc("documentType.label"));
		dtoList = listByDetachedCriteria(dc);

		List<AttachmentDto> fileDtoList = new ArrayList<AttachmentDto>();

		for (WorkflowFile row : dtoList) {
			if (row.getFile() != null) {
				fileDtoList.add(AttachmentDto.buildFromWorkflowFile(row, fileHelper));
			}
		}

		return fileDtoList;

	}

	public List<WorkflowStepAssignment> getWorkflowStepAssignmentsByWkflwType(String wkflwTypeCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStepAssignment.class);
		dc.createAlias("workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowConfig.appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "appOrWkflwType.code", wkflwTypeCode);
		addIsNull(dc, "workflow");
		return getList(dc);
	}

	public Workflow getWorkflowById(Integer workflowId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Workflow.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStepAssignments", "workflowStepAssignments", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStepAssignments.workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStepAssignments.workflowStep", "workflowStep", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStep.roles", "roles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowFiles", "workflowFiles", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "id", workflowId);
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getFirst(dc);
	}

	public List<WorkflowStepAssignment> getFirstLevelWorkflowSteps(Object[] wkflwTypeCodes) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStepAssignment.class);
		dc.createAlias("workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowConfig.appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStep", "workflowStep", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "workflowStep.level", 1);
		addIn(dc, "appOrWkflwType.code", wkflwTypeCodes);
		addIsNull(dc, "workflow");
		return getList(dc);
	}

}
