package gov.stb.tag.repository.ce;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeCaseAppealRepository extends BaseRepository {

	public CeCaseAppeal getAppealById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseAppeal.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "id", id);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getFirst(dc);
	}

	public List<CeCaseAppeal> getDraftAppealsByInfringementIds(List<Integer> infringementIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseAppeal.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addIn(dc, "ceCaseInfringement.id", infringementIds);
		dc.add(Restrictions.or(Restrictions.isNull("workflow"), Restrictions.eq("workflow.isDraft", true)));
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getList(dc);
	}

	public CeCaseAppeal getDraftAppealByCaseId(Integer caseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseAppeal.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);

		addIsNotNull(dc, "workflow");
		dc.add(Restrictions.or(Restrictions.eq("status.code", Statuses.CE_WKFLW_ROUTED), Restrictions.eq("workflow.isDraft", true)));
		addEq(dc, "ceCase.id", caseId);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getFirst(dc);
	}

	public List<CeCaseAppeal> getAppealsByWorkflowId(Integer workflowId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseAppeal.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "workflow.id", workflowId);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<CeCaseAppeal> getApprovedAppealsByInfringementId(Integer infringementId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseAppeal.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "status.code", Statuses.CE_WKFLW_APPR);
		addEq(dc, "ceCaseInfringement.id", infringementId);
		dc.addOrder(Order.desc("id"));
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getList(dc);
	}

	public List<CeCaseAppeal> getAllProcessAppealsByInfringementIds(List<Integer> infringementIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseAppeal.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addIsNotNull(dc, "workflow");
		addIsNotNull(dc, "workflow.lastAction");
		addIn(dc, "ceCaseInfringement.id", infringementIds);
		dc.addOrder(Order.desc("id"));
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}
}
