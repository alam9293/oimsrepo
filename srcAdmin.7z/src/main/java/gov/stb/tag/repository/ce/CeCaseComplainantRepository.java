package gov.stb.tag.repository.ce;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.CeCaseComplainant;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeCaseComplainantRepository extends BaseRepository {

	public List<CeCaseComplainant> getCeCaseComplainantsByIds(List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseComplainant.class);
		dc.add(Restrictions.in("id", ids));
		addEq(dc, "isDeleted", false);
		return getList(dc);
	}

}
