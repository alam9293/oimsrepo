package gov.stb.tag.repository.ce;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeCaseInfringementRepository extends BaseRepository {

	public CeCaseInfringement getCeCaseInfringementById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		addEq(dc, "id", id);
		addEq(dc, "isDeleted", false);
		return getFirst(dc);
	}

	public List<CeCaseInfringement> getCeCaseInfringementsByIds(List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		addIn(dc, "id", ids);
		addEq(dc, "isDeleted", false);
		return getList(dc);
	}

	public List<CeCaseInfringement> getCeCaseInfringementsByCaseId(Integer caseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		dc.add(Restrictions.eq("ceCase", caseId));
		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		return getList(dc);
	}

}
