package gov.stb.tag.repository.ce;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeCaseInfringerRepository extends BaseRepository {

	public CeCaseInfringer getCeCaseInfringerById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringer.class);
		dc.add(Restrictions.eq("id", id));
		addEq(dc, "isDeleted", false);
		return getFirst(dc);
	}

	public List<CeCaseInfringer> getOtherInfringersByUenUins(List<String> uenUins, List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringer.class);
		addIn(dc, "uenUin", uenUins);
		addIsNotNull(dc, "uenUin");
		if (CollectionUtils.isNotEmpty(ids)) {
			addNotIn(dc, "id", ids);
		}
		addEq(dc, "isDeleted", false);
		return getList(dc);
	}

	public CeCaseInfringer getCeCaseInfringerByUenUin(String uenUin) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringer.class);
		dc.add(Restrictions.eq("uenUin", uenUin));
		addEq(dc, "isDeleted", false);

		dc.addOrder(Order.desc("updatedDate"));
		return getFirst(dc);
	}

	public List<CeCaseInfringer> getOtherInfringersByUenUinsAndCaseId(List<String> uenUins, Integer currentCaseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringer.class);
		dc.createAlias("ceCaseInfringements", "ceCaseInfringements", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringements.ceOriginatingCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "uenUin", uenUins);
		addIsNotNull(dc, "uenUin");
		if (currentCaseId != null) {
			dc.add(Restrictions.ne("ceCase.id", currentCaseId));
		}
		addEq(dc, "isDeleted", false);
		return getList(dc);
	}

	public CeCaseInfringer getCeCaseInfringerByUin(String uin) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringer.class);
		dc.add(Restrictions.eq("uenUin", uin));
		dc.add(Restrictions.eq("idType.code", Codes.defendantIdType.INDIVIDUAL));
		dc.add(Restrictions.eq("isDeleted", false));
		dc.addOrder(Order.desc("updatedBy"));
		return getFirst(dc);
	}

}
