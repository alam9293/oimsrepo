package gov.stb.tag.repository.ce;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.model.CeCaseRescind;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeCaseRescindRepository extends BaseRepository {

	public CeCaseRescind getRescindById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseRescind.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "id", id);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getFirst(dc);
	}

	public List<CeCaseRescind> getDraftRescindsByInfringementIds(List<Integer> infringementIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseRescind.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addIn(dc, "ceCaseInfringement.id", infringementIds);
		dc.add(Restrictions.or(Restrictions.isNull("workflow"), Restrictions.eq("workflow.isDraft", true)));
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getList(dc);
	}

	public List<CeCaseRescind> getAllProcessRescindsByInfringementIds(List<Integer> infringementIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseRescind.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addIsNotNull(dc, "workflow");
		addIsNotNull(dc, "workflow.lastAction");
		addIn(dc, "ceCaseInfringement.id", infringementIds);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		dc.addOrder(Order.desc("id"));
		return getList(dc);
	}

	public List<CeCaseRescind> getRescindsByWorkflowId(Integer workflowId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseRescind.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "workflow.id", workflowId);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public CeCaseRescind getDraftRescindByCaseId(Integer caseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseRescind.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);

		addIsNotNull(dc, "workflow");
		dc.add(Restrictions.or(Restrictions.eq("status.code", Statuses.CE_WKFLW_ROUTED), Restrictions.eq("workflow.isDraft", true)));
		addEq(dc, "ceCase.id", caseId);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getFirst(dc);
	}

	public List<CeCaseRescind> getPendingOrApprovedRescindsByInfringementIds(List<Integer> infringementIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseRescind.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addIn(dc, "ceCaseInfringement.id", infringementIds);
		addIsNotNull(dc, "workflow");
		addIsNotNull(dc, "workflow.lastAction");
		addNe(dc, "status.code", Statuses.CE_WKFLW_REJ);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		dc.addOrder(Order.desc("id"));
		return getList(dc);
	}
}
