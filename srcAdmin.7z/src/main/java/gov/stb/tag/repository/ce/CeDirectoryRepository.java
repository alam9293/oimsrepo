package gov.stb.tag.repository.ce;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.directory.CeDirectoryItemDto;
import gov.stb.tag.dto.ce.directory.CeDirectorySearchDto;
import gov.stb.tag.dto.ce.directory.CeInfringementForPublicDto;
import gov.stb.tag.dto.ce.directory.CeInfringementForTgPublicDto;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeDirectoryRepository extends BaseRepository {

	public ResultDto<CeDirectoryItemDto> getList(CeDirectorySearchDto searchDto, Integer userId) {

		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);

		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer.idType", "idType", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("ceProvision", "ceProvision", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceProvision.chapter", "chapter", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("outcome", "outcome", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCase.oic", "oic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCase.status", "caseStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceOriginatingCase", "ceOriginatingCase", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "idType.code", searchDto.getIdTypeCode());
		addLike(dc, "ceCaseInfringer.name", searchDto.getName());
		addEq(dc, "ceCaseInfringer.uenUin", searchDto.getUenUin());
		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addLike(dc, "ceProvision.section", searchDto.getSection());
		if (!Strings.isNullOrEmpty(searchDto.getCaseNo())) {
			dc.add(Restrictions.disjunction().add(Restrictions.ilike("ceCase.caseNo", searchDto.getCaseNo(), MatchMode.ANYWHERE))
					.add(Restrictions.ilike("ceOriginatingCase.caseNo", searchDto.getCaseNo(), MatchMode.ANYWHERE)));
		}
		addEq(dc, "caseStatus.code", searchDto.getCaseStatusCode());
		if (searchDto.getMyTask() != null && searchDto.getMyTask() == true) {
			addEq(dc, "oic.id", userId);
		} else {
			addLike(dc, "oic.name", searchDto.getOicName());
		}
		addGt(dc, "infringedDate", toLocalDateTime(searchDto.getInfringedDateFrom()));
		addLt(dc, "infringedDate", toLocalDateTimeEnd(searchDto.getInfringedDateTo()));
		addIn(dc, "outcome.code", searchDto.getOutcomeCodes());
		addGt(dc, "outcomeDate", toLocalDateTime(searchDto.getOutcomeDateFrom()));
		addLt(dc, "outcomeDate", toLocalDateTimeEnd(searchDto.getOutcomeDateTo()));
		addEq(dc, "ceCase.isIp", searchDto.getIsIp());
		addEq(dc, "isDeleted", Boolean.FALSE);
		addEq(dc, "ceCaseInfringer.isDeleted", Boolean.FALSE);

		if (searchDto.getMyTask() == null) {
			dc.addOrder(Order.desc("ceCase.createdDate"));
		} else {
			dc.addOrder(Order.asc("ceCase.caseNo"));
		}
		dc.addOrder(Order.asc("ceCaseInfringer.name"));
		addDtoProjections(dc, CeDirectoryItemDto.class);
		return search(dc, searchDto, true);

	}

	private LocalDateTime toLocalDateTime(LocalDate localDate) {
		return localDate != null ? localDate.atStartOfDay() : null;
	}

	private LocalDateTime toLocalDateTimeEnd(LocalDate localDate) {
		return localDate != null ? localDate.atStartOfDay().plusDays(1) : null;
	}

	public List<CeInfringementForPublicDto> getPast5YearsInfringements(String uenUin) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer.idType", "idType", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("ceProvision", "ceProvision", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceProvision.chapter", "chapter", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("outcome", "outcome", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastDecision", "lastDecision", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "ceCaseInfringer.uenUin", uenUin);
		addIsNotNull(dc, "outcome");
		addIn(dc, "outcome.code", Codes.CeRecommendation.EXTERNAL_OUTCOME);
		addGe(dc, "outcomeDate", LocalDate.of(2018, 1, 1).atStartOfDay());
		addGe(dc, "outcomeDate", LocalDate.now().minusYears(5).atStartOfDay());
		addEq(dc, "isDeleted", Boolean.FALSE);
		addEq(dc, "ceCaseInfringer.isDeleted", Boolean.FALSE);

		addDtoProjections(dc, CeInfringementForPublicDto.class);

		return getList(dc);
	}

	public List<CeInfringementForTgPublicDto> getTgPast5YearsInfringements(String uenUin) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer.licence", "licence", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("ceProvision", "ceProvision", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("readWiths", "readWiths", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "ceCaseInfringer.uenUin", uenUin);
		addIsNotNull(dc, "outcome");
		dc.add(Restrictions.geProperty("infringedDate", "licence.issueDate"));

		Disjunction myQueryDisjunc = Restrictions.disjunction();
		Conjunction myQueryConjunc = Restrictions.conjunction();

		myQueryConjunc.add(Restrictions.in("outcome.code", Codes.CeRecommendation.EXTERNAL_TG_OUTCOME_MINOR));
		myQueryConjunc.add(Restrictions.ge("outcomeDate", LocalDate.now().minusYears(1).atStartOfDay()));

		myQueryDisjunc.add(myQueryConjunc);
		myQueryDisjunc.add(Restrictions.in("outcome.code", Codes.CeRecommendation.EXTERNAL_TG_OUTCOME_MAJOR));
		dc.add(myQueryDisjunc);

		addEq(dc, "isDeleted", Boolean.FALSE);
		addEq(dc, "ceCaseInfringer.isDeleted", Boolean.FALSE);

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("id"));
		addDtoProjections(dc, CeInfringementForTgPublicDto.class, false, projections);

		dc.addOrder(Order.desc("infringedDate"));

		return getList(dc);
	}

}
