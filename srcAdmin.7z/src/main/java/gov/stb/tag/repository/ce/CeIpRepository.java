package gov.stb.tag.repository.ce;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseComposition;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.Licence;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeIpRepository extends BaseRepository {

	public CeCase getCeCase(Integer ipId) {

		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);

		dc.createAlias("oic", "oic", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("ceCaseComplainants", "ceCaseComplainants", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("ceCaseExternalIps", "ceCaseExternalIps", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInternalIps", "ceCaseInternalIps", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "id", ipId);

		return getFirst(dc);
	}

	public List<CeCaseInfringement> getCeCaseInfringements(Integer ipId) {

		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);

		dc.createAlias("ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("readWiths", "readWiths", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceProvision", "ceProvision", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "isDeleted", false);

		addEq(dc, "ceCase.id", ipId);

		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

		dc.addOrder(Order.desc("ceCaseInfringer.uenUin"));
		dc.addOrder(Order.asc("createdDate"));

		return getList(dc);
	}

	public List<CeCaseComposition> getCompositions(Integer ipId) {
		DetachedCriteria dc = queryCompo();

		addEq(dc, "ceCase.id", ipId);

		return getList(dc);
	}

	public List<CeCaseComposition> getPendingCompositions(Integer ipId) {

		DetachedCriteria dc = queryCompo();

		addEq(dc, "ceCase.id", ipId);

		addIn(dc, "lastActionStatus.code", Codes.Statuses.CE_WKFLW_PEND_APPR, Codes.Statuses.CE_WKFLW_ROUTED);

		/*
		 * Disjunction myQueryDisjunc = Restrictions.disjunction(); myQueryDisjunc.add(Restrictions.in("lastActionStatus.code", Codes.Statuses.CE_WKFLW_PEND_APPR, Codes.Statuses.CE_WKFLW_ROUTED));
		 * myQueryDisjunc.add(Restrictions.in("waiveLastActionStatus.code", Codes.Statuses.CE_WKFLW_PEND_APPR, Codes.Statuses.CE_WKFLW_ROUTED)); dc.add(myQueryDisjunc);
		 */

		return getList(dc);
	}

	public CeCaseInfringer getInfringer(String uenUin) {

		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringer.class);
		dc.add(Restrictions.eq("uenUin", uenUin));

		return getFirst(dc);
	}

	public CeCase getRevIp(String caseNo) {

		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);
		dc.add(Restrictions.eq("isIp", true));
		dc.add(Restrictions.eq("caseNo", caseNo));

		return getFirst(dc);
	}

	public Licence getLicenceByLicenceNo(String licenceNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.eq("licenceNo", licenceNo));

		return getFirst(dc);
	}

	private DetachedCriteria queryCompo() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseComposition.class);
		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer.ceCaseInfringements", "ceCaseInfringements", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringements.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "lastActionStatus", JoinType.LEFT_OUTER_JOIN);

		// dc.createAlias("waiveWorkflow", "waiveWorkflow", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("waiveWorkflow.lastAction", "waiveLastAction", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("waiveLastAction.status", "waiveLastActionStatus", JoinType.LEFT_OUTER_JOIN);

		return dc;
	}
}
