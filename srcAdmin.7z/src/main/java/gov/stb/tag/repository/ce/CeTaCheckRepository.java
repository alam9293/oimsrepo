package gov.stb.tag.repository.ce;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckQn;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.CommonRepository;

@Repository
public class CeTaCheckRepository extends CommonRepository {

	public List<CeTaCheckQn> getCeTatiCheckQns() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaCheckQn.class);
		dc.add(Restrictions.eq("isActive", Boolean.TRUE));
		dc.addOrder(Order.asc("ordinal"));

		return getList(dc);
	}

	public CeTaCheck getCheckFromSchedule(Integer scheduleId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaCheck.class);
		dc.createAlias("ceTaCheckScheduleItem", "ceTaCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("ceTaCheckScheduleItem.id", scheduleId));
		return getFirst(dc);
	}

	public List<Type> getTypes(String[] classifications, boolean isActive) {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.add(Restrictions.in("code", classifications));
		dc.add(Restrictions.eq("isActive", isActive));
		return getList(dc);

	}

	public List<CeTaCheck> getCeTaCheckByAcknowledgementStatus(Boolean isAcknowledged) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaCheck.class);
		dc.createAlias("ceTaCheckScheduleItem", "ceTaCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "isAcknowledged", isAcknowledged);
		addEq(dc, "isDeleted", Boolean.FALSE);
		addEq(dc, "isDraft", Boolean.FALSE);
		addEq(dc, "ceTaCheckScheduleItem.checkType.code", Codes.Types.TA_CHECK_TATI);
		dc.add(Restrictions.ne("isCompliant.code", Codes.FLAGS.FLAG_N));
		dc.add(Restrictions.isNotNull("ceCase.id"));
		dc.addOrder(Order.asc("ceCase.createdDate"));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<CeTaCheck> getCeTaCheckByIds(List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaCheck.class);
		dc.createAlias("ceTaCheckScheduleItem", "ceTaCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "id", ids);
		return getList(dc);
	}
}
