package gov.stb.tag.repository.ce;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.ta.schedule.CeTaCheckScheduleSearchTaDto;
import gov.stb.tag.model.CeTaCheckSchedule;
import gov.stb.tag.model.ViewCeTaCheckSchedulableItem;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeTaCheckScheduleRepository extends BaseRepository {

	public ResultDto<ViewCeTaCheckSchedulableItem> getTaList(CeTaCheckScheduleSearchTaDto searchDto, boolean toPaginate) {
		DetachedCriteria dc = DetachedCriteria.forClass(ViewCeTaCheckSchedulableItem.class);

		addLike(dc, "taName", searchDto.getTaName());
		addLike(dc, "licenceNo", searchDto.getLicenceNo());
		addLike(dc, "uen", searchDto.getUen());
		addGe(dc, "licenceCeasedDate", searchDto.getLicenceCeasedDate());
		addEq(dc, "licenceExpiryDate", searchDto.getLicenceExpiryDate());
		addEq(dc, "licenceStatusCode", searchDto.getLicenceStatus());
		addLike(dc, "building", searchDto.getBuilding());
		addLike(dc, "street", searchDto.getStreet());
		addStartWith(dc, "postal", searchDto.getPostal());
		addIn(dc, "premiseTypeCode", searchDto.getPremisesType());
		addEq(dc, "addressTypeCode", searchDto.getAddressType());
		addEq(dc, "branchStatusCode", searchDto.getBranchStatus());
		addIn(dc, "noOfReds", searchDto.getNoOfReds());
		addEq(dc, "lastAaFilingStatusCode", searchDto.getLastAaFilingStatus());
		addIn(dc, "serviceTypeCode", searchDto.getServiceType());
		addIn(dc, "lastTatiCheckIsCompliantCode", searchDto.getLastTatiCheckIsCompliant());
		if (!Strings.isNullOrEmpty(searchDto.getLastTatiCheckDone())) {
			if (Codes.Constants.YES.equalsIgnoreCase(searchDto.getLastTatiCheckDone())) {
				dc.add(Restrictions.isNotNull("lastTatiCheckDate"));
			} else if (Codes.Constants.NO.equalsIgnoreCase(searchDto.getLastTatiCheckDone())) {
				dc.add(Restrictions.isNull("lastTatiCheckDate"));
			}
		}
		if (!Strings.isNullOrEmpty(searchDto.getLastCheckDone())) {
			addEq(dc, "lastCheckDone", Codes.Constants.YES.equalsIgnoreCase(searchDto.getLastCheckDone()) ? Boolean.TRUE : Boolean.FALSE);
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.asc("taName"));
		}

		return search(dc, searchDto, toPaginate);
	}

	public CeTaCheckSchedule getTaCheckSchedule(Integer year, Integer month) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaCheckSchedule.class);
		dc.add(Restrictions.eq("month", month));
		dc.add(Restrictions.eq("year", year));

		return getFirst(dc);
	}

	public ViewCeTaCheckSchedulableItem getTaCheckSchedulableItem(Integer addressId) {
		DetachedCriteria dc = DetachedCriteria.forClass(ViewCeTaCheckSchedulableItem.class);
		dc.add(Restrictions.eq("addressId", addressId));

		return getFirst(dc);
	}

}
