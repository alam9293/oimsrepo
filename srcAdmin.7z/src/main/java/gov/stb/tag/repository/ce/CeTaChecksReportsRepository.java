package gov.stb.tag.repository.ce;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportsSearchDto;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.repository.CommonRepository;

@Repository
public class CeTaChecksReportsRepository extends CommonRepository {

	public ResultDto<CeTaCheckScheduleItem> getCeTaScheduleChecks(CeTaCheckReportsSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaCheckScheduleItem.class);
		dc.createAlias("eoUser", "eoUser", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaCheck", "ceTaCheck", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("checkType", "checkType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("addressType", "addressType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaCheck.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isApproved", Boolean.TRUE));
		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		addLike(dc, "eoUser.name", searchDto.getAssignedOfficer());

		if (searchDto.getMyApplications() == true) {
			addEq(dc, "eoUser.id", userId);
		}
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("scheduledDate"));
		}
		if (!Strings.isNullOrEmpty(searchDto.getIsDraft())) {
			addIsNotNull(dc, "ceTaCheck.id");
			addEq(dc, "ceTaCheck.isDraft", Boolean.valueOf(searchDto.getIsDraft()));
		}
		addLike(dc, "taName", searchDto.getTaName());
		addGe(dc, "scheduledDate", searchDto.getScheduledDateFrom());
		addLe(dc, "scheduledDate", searchDto.getScheduledDateTo());

		addIn(dc, "checkType.code", searchDto.getTypes());

		return search(dc, searchDto, true);
	}

	public Licence getLicenceFromLicNo(String licenceNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.eq("licenceNo", licenceNo));

		return getFirst(dc);
	}

	public Stakeholder getTastakeholderFromUin(String uin) {
		DetachedCriteria dc = DetachedCriteria.forClass(Stakeholder.class);
		dc.add(Restrictions.eq("uin", uin));

		return getFirst(dc);
	}

	public List<ListableDto> getPersonRoleFromUin(String uin) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "stakeholder.uin", uin);
		addIsNotNull(dc, "role.code");
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		dc.addOrder(Order.asc("role.ordinal"));

		ProjectionList roleProjections = Projections.projectionList();
		roleProjections.add(Projections.property("role.code"), "key");
		roleProjections.add(Projections.property("role.label"), "label");
		dc.setProjection(roleProjections);
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));
		return getList(dc);

	}

}
