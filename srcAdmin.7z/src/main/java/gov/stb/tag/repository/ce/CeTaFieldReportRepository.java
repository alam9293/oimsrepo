package gov.stb.tag.repository.ce;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.cases.CeComplianceCheckDto;
import gov.stb.tag.dto.ce.cases.CeComplianceCheckSearchDto;
import gov.stb.tag.model.CeTaFieldReport;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeTaFieldReportRepository extends BaseRepository {

	public List<CeTaFieldReport> getAllCeTaFieldReportsByIds(List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaFieldReport.class);
		addIn(dc, "id", ids);
		return getList(dc);
	}

	public CeTaFieldReport getFieldReportFromScheduleItem(Integer ceTaCheckScheduleItemId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaFieldReport.class);
		dc.createAlias("ceTaCheckScheduleItem", "ceTaCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "ceTaCheckScheduleItem.id", ceTaCheckScheduleItemId);
		return getFirst(dc);
	}

	public ResultDto<CeComplianceCheckDto> getTaFieldReports(CeComplianceCheckSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTaFieldReport.class);
		dc.createAlias("ceTaCheckScheduleItem", "ceTaCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaCheckScheduleItem.eoUser", "eoUser", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaCheckScheduleItem.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);

		addLike(dc, "eoUser.name", searchDto.getConductedBy());
		addLike(dc, "name", searchDto.getName());
		addEq(dc, "uinPassportNo", searchDto.getUin());
		addLike(dc, "travelAgent.name", searchDto.getCompanyName());
		addEq(dc, "travelAgent.uen", searchDto.getUen());
		addEq(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addGe(dc, "createdDate", searchDto.getConductedDateFrom());
		if (searchDto.getConductedDateTo() != null) {
			addLt(dc, "createdDate", searchDto.getConductedDateTo().plusDays(1));
		}

		return CeComplianceCheckDto.buildFromModels(search(dc, searchDto, true));
	}

}
