package gov.stb.tag.repository.ce;

import java.time.LocalDate;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.CeTgCheckSchedule;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeTgCheckScheduleRepository extends BaseRepository {

	public CeTgCheckSchedule getSchedule(Integer year, LocalDate fromDate) {

		DetachedCriteria dc = DetachedCriteria.forClass(CeTgCheckSchedule.class);
		dc.createAlias("ceTgCheckScheduleItems", "ceTgCheckScheduleItems", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTgCheckScheduleItems.ceTgCheckScheduleItemLocations", "ceTgCheckScheduleItemLocations", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTgCheckScheduleItemLocations.meridiem", "meridiem", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("year", year));
		dc.add(Restrictions.eq("fromDate", fromDate));

		dc.addOrder(Order.asc("ceTgCheckScheduleItems.scheduleDate"));
		dc.addOrder(Order.asc("meridiem.ordinal"));

		return getFirst(dc);
	}

}
