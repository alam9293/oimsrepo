package gov.stb.tag.repository.ce;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.tg.checkreports.CeTgCheckReportSearchDto;
import gov.stb.tag.model.CeTgCheckSchedule;
import gov.stb.tag.model.CeTgCheckScheduleItemLocation;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeTgChecksReportsRepository extends BaseRepository {

	public List<ListableDto> getApprovedScheduledYears() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTgCheckSchedule.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.CE_WKFLW_APPR));
		ProjectionList yearProjections = Projections.projectionList();
		yearProjections.add(Projections.groupProperty("year"));
		yearProjections.add(Projections.property("year"), "key");
		yearProjections.add(Projections.property("year"), "data");
		dc.setProjection(yearProjections);
		dc.addOrder(Order.desc("year"));
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));

		return getList(dc);
	}

	public List<CeTgCheckSchedule> getApprovedScheduleByYear(Integer year) {

		DetachedCriteria dc = DetachedCriteria.forClass(CeTgCheckSchedule.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("year", year));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.CE_WKFLW_APPR));

		return getList(dc);
	}

	public ResultDto<CeTgCheckScheduleItemLocation> getCeTgScheduleItemLocations(CeTgCheckReportSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTgCheckScheduleItemLocation.class);
		dc.createAlias("ceTgCheckScheduleItem", "ceTgCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("meridiem", "meridiem", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("location", "location", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTgCheckScheduleItem.ceTgCheckSchedule", "ceTgCheckSchedule", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTgCheckSchedule.workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		dc.add(Restrictions.eq("ceTgCheckScheduleItem.isApproved", Boolean.TRUE));
		dc.add(Restrictions.eq("ceTgCheckScheduleItem.isDeleted", Boolean.FALSE));
		dc.add(Restrictions.le("ceTgCheckScheduleItem.scheduleDate", LocalDate.now()));

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("ceTgCheckScheduleItem.scheduleDate"));
		}

		addIn(dc, "meridiem.code", searchDto.getMeridiemTypes());
		addIn(dc, "location.code", searchDto.getLocationTypes());

		if (searchDto.getScheduleDateFrom() != null || searchDto.getScheduleDateTo() != null) {
			if (searchDto.getScheduleDateFrom() != null) {
				addGe(dc, "ceTgCheckScheduleItem.scheduleDate", searchDto.getScheduleDateFrom());
			}
			if (searchDto.getScheduleDateTo() != null) {
				addLe(dc, "ceTgCheckScheduleItem.scheduleDate", searchDto.getScheduleDateTo());
			}
		}

		if (ArrayUtils.isNotEmpty(searchDto.getEoUsers())) {
			var subCriteria = DetachedCriteria.forClass(CeTgCheckScheduleItemLocation.class);
			subCriteria.createAlias("ceTgCheckScheduleItem", "ceTgCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
			subCriteria.createAlias("ceTgCheckScheduleItem.eoUsers", "eoUsers", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.in("eoUsers.id", searchDto.getEoUsers()));
			subCriteria.setProjection(Projections.property("id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}

		return search(dc, searchDto, true);
	}

}
