package gov.stb.tag.repository.ce;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.cases.CeComplianceCheckDto;
import gov.stb.tag.dto.ce.cases.CeComplianceCheckSearchDto;
import gov.stb.tag.model.CeTgFieldReport;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class CeTgFieldReportRepository extends BaseRepository {

	public ResultDto<CeComplianceCheckDto> getTgFieldReports(CeComplianceCheckSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTgFieldReport.class);
		dc.createAlias("eoUser", "eoUser", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);

		addLike(dc, "eoUser.name", searchDto.getConductedBy());
		addLike(dc, "touristGuide.name", searchDto.getName());
		addEq(dc, "touristGuide.uin", searchDto.getUin());
		addEq(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addGe(dc, "createdDate", searchDto.getConductedDateFrom());
		if (searchDto.getConductedDateTo() != null) {
			addLt(dc, "createdDate", searchDto.getConductedDateTo().plusDays(1));
		}

		return CeComplianceCheckDto.buildFromModels(search(dc, searchDto, true));
	}

	public CeTgFieldReport getTgCheckFromScheduleLocation(Integer scheduleLocationId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTgFieldReport.class);
		dc.createAlias("ceTgCheckScheduleItemLocation", "ceTgCheckScheduleItemLocation", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("ceTgCheckScheduleItemLocation.id", scheduleLocationId));
		return getFirst(dc);
	}


}
