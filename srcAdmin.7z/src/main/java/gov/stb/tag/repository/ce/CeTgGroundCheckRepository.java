package gov.stb.tag.repository.ce;

import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckDto;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckQn;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTgCheck;
import gov.stb.tag.repository.BaseRepository;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CeTgGroundCheckRepository extends BaseRepository {

	public CeTgCheck getTgCheckFromScheduleLocation(Integer scheduleLocationId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTgCheck.class);
		dc.createAlias("ceTgCheckScheduleItemLocation", "ceTgCheckScheduleItemLocation", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("ceTgCheckScheduleItemLocation.id", scheduleLocationId));
		return getFirst(dc);
	}

}
