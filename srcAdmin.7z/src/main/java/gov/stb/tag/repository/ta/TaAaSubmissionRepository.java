package gov.stb.tag.repository.ta;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licenceAa.TaLicenceAaDto;
import gov.stb.tag.dto.ta.licenceAa.TaLicenceAaItemDto;
import gov.stb.tag.dto.ta.licenceAa.TaLicenceAaSearchDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaAaSubmission;

@Repository
public class TaAaSubmissionRepository extends TaApplicationRepository {

	public ResultDto<TaLicenceAaItemDto> getPendingList(TaLicenceAaSearchDto searchDto, Integer userId, boolean pagination) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "type.code", Codes.ApplicationTypes.TA_APP_AA_SUBMISSION);

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		dc.add(Restrictions.ne("isDeleted", true));
		filter(searchDto, dc, userId);
		addDtoProjections(dc, TaLicenceAaItemDto.class);

		return search(dc, searchDto, pagination);
	}

	public TaLicenceAaDto getAaSubmissionFromAppId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "application.id", id);
		dc.add(Restrictions.ne("application.isDeleted", true));
		addDtoProjections(dc, TaLicenceAaDto.class);
		return getFirst(dc);

	}

	public TaAaSubmission updateAaDetails(TaLicenceAaDto dto, TaAaSubmission aaModel, Cache cache) {
		if (dto.getIsEdit() || dto.isOfflineSubmission()) {
			aaModel.setRevenue(dto.getRevenue());
			aaModel.setOtherIncome(dto.getOtherIncome());
			aaModel.setGrossProfitLoss(dto.getGrossProfitLoss());
			aaModel.setNetProfitLoss(dto.getNetProfitLoss());
			aaModel.setDividendsPaid(dto.getDividendsPaid());
			aaModel.setBankBalance(dto.getBankBalance());
			aaModel.setCashCashEquiv(dto.getCashCashEquiv());
			aaModel.setTradeReceivables(dto.getTradeReceivables());
			aaModel.setTradeSecurities(dto.getTradeSecurities());
			aaModel.setAmtOwnByDir(dto.getAmtOwnByDir());
			aaModel.setNonCurrentAssets(dto.getNonCurrentAssets());
			aaModel.setCurrentAssets(dto.getCurrentAssets());
			aaModel.setAccProfitLoss(dto.getAccProfitLoss());
			aaModel.setTotalEquity(dto.getTotalEquity());
			aaModel.setNonCurrentLiabilities(dto.getNonCurrentLiabilities());
			aaModel.setCurrentLiabilities(dto.getCurrentLiabilities());
			aaModel.setAuditorOpinion(cache.getType(dto.getAuditorOpinionCode()));

			aaModel.setNetProfitMargin(dto.getNetProfitMargin());
			aaModel.setQuickRatio(dto.getQuickRatio());
			aaModel.setDebtEquityRatio(dto.getDebtEquityRatio());
			aaModel.setProfitScRatio(dto.getProfitScRatio());
			aaModel.setNetValue(dto.getNetValue());
			aaModel.setShortfall(dto.getShortfall());
		}
		aaModel.setCapital(dto.getCapital());
		aaModel.setTotalLiabilities(dto.getTotalLiabilities());
		aaModel.setTotalAssets(dto.getTotalAssets());

		return aaModel;
	}

}
