package gov.stb.tag.repository.ta;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.abpr.TaAbprSubmissionItemDto;
import gov.stb.tag.dto.ta.abpr.TaAbprSubmissionSearchDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaAbprSubmission;

@Repository
public class TaAbprSubmissionRepository extends TaApplicationRepository {

	public ResultDto<TaAbprSubmissionItemDto> getPendingList(TaAbprSubmissionSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "type.code", Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}

		filter(searchDto, dc, userId);
		dc.add(Restrictions.ne("isDeleted", true));
		addDtoProjections(dc, TaAbprSubmissionItemDto.class);

		return search(dc, searchDto, true);
	}

	public TaAbprSubmission getApplication(Integer applicationId, Integer taId, Boolean isPending) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAbprSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taSpecializedMarkets", "taSpecializedMarkets", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taBusinessOperations", "taBusinessOperations", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taFocusAreas", "taFocusAreas", JoinType.LEFT_OUTER_JOIN);

		// dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.type", "type", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "type.code", Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION);
		if (isPending) {
			// addIn(dc, "lastAction.status.code", Codes.PendingTaActionStatuses.TA);

			Criterion pendingApproval = Restrictions.in("lastAction.status.code", Codes.PendingTaActionStatuses.TA);
			Criterion draft = Restrictions.eq("application.isDraft", true);
			dc.add(Restrictions.or(pendingApproval, draft));
		}
		if (applicationId != null) {
			dc.add(Restrictions.eq("application.id", applicationId));
		}
		if (taId != null) {
			dc.add(Restrictions.eq("travelAgent.id", taId));
		}
		dc.addOrder(Order.desc("createdDate"));
		dc.add(Restrictions.ne("application.isDeleted", true));

		return getFirst(dc);
	}
}
