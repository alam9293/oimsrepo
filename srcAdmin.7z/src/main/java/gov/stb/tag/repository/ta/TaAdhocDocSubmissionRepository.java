package gov.stb.tag.repository.ta;

import com.google.common.base.Strings;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.adhocdoc.ma.TaAdhocDocItemDto;
import gov.stb.tag.dto.ta.adhocdoc.ma.TaAdhocDocSearchDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaAdhocDocSubmission;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

@Repository
public class TaAdhocDocSubmissionRepository extends TaApplicationRepository {

	public ResultDto<TaAdhocDocItemDto> getPendingList(TaAdhocDocSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "type.code", ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		dc.add(Restrictions.ne("isDeleted", true));
		filter(searchDto, dc, userId);
		addDtoProjections(dc, TaAdhocDocItemDto.class);

		return search(dc, searchDto, true);
	}

	public TaAdhocDocSubmission getApplication(Integer appId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAdhocDocSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", appId));
		return getFirst(dc);
	}
}
