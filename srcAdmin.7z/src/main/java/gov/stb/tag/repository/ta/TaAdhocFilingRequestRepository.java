package gov.stb.tag.repository.ta;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.filingrequest.TaAdhocFilingRequestSearchDto;
import gov.stb.tag.model.TaAdhocFilingRequest;
import gov.stb.tag.repository.WorkflowRepository;

@Repository
public class TaAdhocFilingRequestRepository extends WorkflowRepository {

	public ResultDto<TaAdhocFilingRequest> getList(TaAdhocFilingRequestSearchDto searchDto, Integer userId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaAdhocFilingRequest.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("createdDate"));
		}

		if (searchDto.getExcludeRequestId() != null) {
			addNe(dc, "id", searchDto.getExcludeRequestId());
		}

		if (searchDto.getLicenceId() != null) {
			addEq(dc, "licence.id", searchDto.getLicenceId());
		} else {
			filter(searchDto, dc, userId);
			addEq(dc, "reqType.code", searchDto.getReqType());
		}

		if (searchDto.getApproveDateFrom() != null || searchDto.getApproveDateTo() != null) {
			dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
			if (searchDto.getApproveDateFrom() != null) {
				addGe(dc, "lastAction.createdDate", searchDto.getApproveDateFrom());
			}
			if (searchDto.getApproveDateTo() != null) {
				addLt(dc, "lastAction.createdDate", searchDto.getApproveDateTo().plusDays(1));
			}
		}

		return search(dc, searchDto, true);
	}

	public List<TaAdhocFilingRequest> getAdhocRequestPendingTa(Integer licenceId, String filingType, Integer filingRedIdToExclude) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAdhocFilingRequest.class);
		dc.createAlias("reqType", "reqType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addNe(dc, "id", filingRedIdToExclude);
		addEq(dc, "licence.id", licenceId);
		addEq(dc, "reqType.code", filingType);
		addNotIn(dc, "lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_TA);
		dc.addOrder(Order.desc("dueDate"));
		return getList(dc);
	}

}
