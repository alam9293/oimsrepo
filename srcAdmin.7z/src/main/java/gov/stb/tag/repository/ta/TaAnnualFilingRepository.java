package gov.stb.tag.repository.ta;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TaAnnualFilingRepository extends BaseRepository {

	public TaFilingCondition getPreviousTaAnnualFiling(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		addIn(dc, "status.code", Lists.newArrayList(Codes.Statuses.TA_FILING_APPROVED, Codes.Statuses.TA_FILING_PEND_APPROVAL, Codes.Statuses.TA_FILING_RFA));
		addIn(dc, "appType.code", Lists.newArrayList(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION)); // get only the system generated filing, to exclude
																																					// the ad-hoc filing
		dc.addOrder(Order.desc("fyEndDate"));

		return getFirst(dc);
	}

	public TaFilingCondition getTaAnnualFilingPendingTA(Integer licenceId, String appTypeCode, boolean hasPendingTaStatus, boolean isProcessing) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);

		filterTaAnnualFilingPendingTA(dc, licenceId, hasPendingTaStatus, isProcessing);
		addEq(dc, "applicationType.code", appTypeCode);

		return getFirst(dc);
	}

	public TaFilingCondition getTaAnnualFilingPendingTA(Integer licenceId, Object[] appTypeCodes, boolean hasPendingTaStatus, boolean isProcessing) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);

		filterTaAnnualFilingPendingTA(dc, licenceId, hasPendingTaStatus, isProcessing);
		addIn(dc, "applicationType.code", appTypeCodes);

		return getFirst(dc);
	}


	public List<TaFilingCondition> getTaAnnualFilingByFye(Integer licenceId, LocalDate fyEndDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "ta", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "licence.id", licenceId);
		addGe(dc, "fyEndDate", fyEndDate);
		addIn(dc, "status.code", Codes.PendingTaActionStatuses.SUBMISSIONS);
		addIn(dc, "appType.code", Lists.newArrayList(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION)); // get only the system generated filing, to exclude
																																					// the ad-hoc filing

		return getList(dc);
	}

	public List<TaFilingCondition> getTaFilingsPendingTa(Integer licenceId, Object[] appTypes) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "licence.id", licenceId);
		addIn(dc, "status.code", Codes.PendingTaActionStatuses.ANNUAL_FILING);
		addIn(dc, "appType.code", appTypes);
		dc.addOrder(Order.desc("fyEndDate"));

		return getList(dc);
	}

	public TaAnnualFilingDto getTaAnnualFilingByAaSubmissionId(Integer aaSubmissionId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.lastExtension", "lastExtension", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "id", aaSubmissionId);
		addDtoProjections(dc, TaAnnualFilingDto.class);
		return getFirst(dc);
	}

	public List<TaFilingCondition> getTaFilingConditionsByType(Integer licenceId, String appType, Object[] years) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.ne("status.code", Codes.Statuses.TA_FILING_VOID));
		addEq(dc, "applicationType.code", appType);
		if (years != null) {
			addIn(dc, "fy", years);
		}
		dc.addOrder(Order.desc("fyEndDate"));
		return getList(dc);
	}

	public List<TaFilingCondition> getUnfulfilledTaFilingConditions(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.in("status.code", Codes.PendingTaActionStatuses.SUBMISSIONS));

		dc.addOrder(Order.asc("applicationType.code"));
		dc.addOrder(Order.asc("dueDate"));
		return getList(dc);
	}

	public List<TaAaSubmission> getAaFromFilingId(Object[] objects) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "taAnnualFiling.id", objects);
		return getList(dc);

	}

	public List<TaAaSubmission> getAaPreviousFiling(Integer licenceId, Integer limitNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.status", "status", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "licence.id", licenceId);
		addIn(dc, "status.code", Statuses.TA_FILING_APPROVED);

		if (limitNo != null) {
			dc.addOrder(Order.desc("taAnnualFiling.fyEndDate"));
			return getListLimit(dc, limitNo);
		}
		return getList(dc);
	}

	public TaAbprSubmission getAbprPreviousFiling(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAbprSubmission.class);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.status", "status", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "licence.id", licenceId);
		addIn(dc, "status.code", Statuses.TA_FILING_APPROVED);
		dc.addOrder(Order.desc("taAnnualFiling.fyEndDate"));
		return getFirst(dc);
	}

	public List<ListableDto> getAllFilingTypes(Object[] types) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);

		addIn(dc, "applicationType.code", types);

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.property("applicationType.code"), "key");
		projections.add(Projections.property("applicationType.label"), "label");
		dc.setProjection(Projections.distinct(projections));

		dc.addOrder(Order.asc("applicationType.label"));
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));

		return getList(dc);
	}

	public void filterTaAnnualFilingPendingTA(DetachedCriteria dc, Integer licenceId, boolean hasPendingTaStatus, boolean isProcessing) {
		addEq(dc, "licence.id", licenceId);

		if (hasPendingTaStatus) { // is pending TA submission
			addIn(dc, "status.code", Codes.PendingTaActionStatuses.ANNUAL_FILING);
			dc.addOrder(Order.asc("fyEndDate"));
		}

		if (isProcessing) { // is pending STB approval
			addIn(dc, "status.code", Codes.Statuses.TA_FILING_PEND_APPROVAL);
			dc.addOrder(Order.desc("fyEndDate"));
		}
	}
}
