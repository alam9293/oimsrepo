package gov.stb.tag.repository.ta;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.ta.application.TaApplicationBasicDto;
import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;
import gov.stb.tag.dto.ta.application.TaApplicationSearchItemDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.CommonRepository;

@Repository
public class TaApplicationRepository extends CommonRepository {

	public ResultDto<TaApplicationSearchItemDto> getList(TaApplicationSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.RIGHT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.type", "type", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.ne("application.isDeleted", Boolean.TRUE));
		dc.add(Restrictions.eq("application.taTgType", Codes.TaTgType.TA));
		filterApplicationAll(searchDto, dc, userId);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		addDtoProjections(dc, TaApplicationSearchItemDto.class);
		return search(dc, searchDto, true);
	}

	public DetachedCriteria filterApplicationAll(TaApplicationSearchDto searchDto, DetachedCriteria dc, Integer userId) {
		if (!Strings.isNullOrEmpty(searchDto.getName())) {
			Disjunction name = Restrictions.disjunction();
			Criterion nameTA = Restrictions.ilike("travelAgent.name", searchDto.getName(), MatchMode.ANYWHERE);
			Criterion nameCreation = Restrictions.ilike("companyName", searchDto.getName(), MatchMode.ANYWHERE);
			name.add(nameTA);
			name.add(nameCreation);
			dc.add(name);
		}
		if (!Strings.isNullOrEmpty(searchDto.getUen())) {
			Disjunction uen = Restrictions.disjunction();
			Criterion uenTA = Restrictions.ilike("travelAgent.uen", searchDto.getUen(), MatchMode.ANYWHERE);
			Criterion uenCreation = Restrictions.ilike("uen", searchDto.getUen(), MatchMode.ANYWHERE);
			uen.add(uenTA);
			uen.add(uenCreation);
			dc.add(uen);
		}

		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addEq(dc, "licence.id", searchDto.getLicenceId());
		addLike(dc, "application.applicationNo", searchDto.getApplicationNo());

		addEq(dc, "lastAction.status.code", searchDto.getApplicationStatus());
		addIn(dc, "lastAction.status.code", searchDto.getApplicationStatuses());
		addEq(dc, "type.code", searchDto.getApplicationType());

		if (searchDto.getSubmissionDateTo() != null) {
			addLt(dc, "application.submissionDate", searchDto.getSubmissionDateTo().plusDays(1));
		}

		if (searchDto.getSubmissionDateFrom() != null) {
			addGe(dc, "application.submissionDate", searchDto.getSubmissionDateFrom());
		}

		addLike(dc, "assignee.name", searchDto.getAssignedOfficer());

		if (searchDto.getMyApplications() == true) {
			addEq(dc, "application.assignee.id", userId);
		}

		if (!Strings.isNullOrEmpty(searchDto.getExcludeSubmissionType())) {
			addNotIn(dc, "type.code", searchDto.getExcludeSubmissionType());
			addNotIn(dc, "lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_TA);
		}

		return dc;
	}

	public DetachedCriteria filter(TaApplicationSearchDto searchDto, DetachedCriteria dc, Integer userId) {

		addLike(dc, "travelAgent.name", searchDto.getName());

		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addEq(dc, "licence.id", searchDto.getLicenceId());
		addLike(dc, "applicationNo", searchDto.getApplicationNo());

		addLike(dc, "travelAgent.uen", searchDto.getUen());

		addEq(dc, "lastAction.status.code", searchDto.getApplicationStatus());
		addIn(dc, "lastAction.status.code", searchDto.getApplicationStatuses());
		addNotIn(dc, "lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TA);// show pending only

		addEq(dc, "type.code", searchDto.getApplicationType());

		if (searchDto.getSubmissionDateTo() != null) {
			addLt(dc, "submissionDate", searchDto.getSubmissionDateTo().plusDays(1));
		}

		if (searchDto.getSubmissionDateFrom() != null) {
			addGe(dc, "submissionDate", searchDto.getSubmissionDateFrom());
		}

		addLike(dc, "assignee.name", searchDto.getAssignedOfficer());

		if (searchDto.getMyApplications() == true) {
			addEq(dc, "assignee.id", userId);
		}

		return dc;
	}

	/**
	 * Get latest application details by licence id and application type
	 * 
	 * @param licenceId
	 * @return
	 */
	public Application getApplicationFromLicenceId(Integer licenceId, String applicationType) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		addEq(dc, "type.code", applicationType);
		dc.add(Restrictions.ne("isDeleted", true));
		dc.addOrder(Order.desc("updatedDate"));
		return getFirst(dc);

	}

	/**
	 * Get a specific application that pending TA action from licence ID
	 * 
	 * @param licenceId,
	 *            applicationTypeCode
	 * @return
	 */
	public Application getPendingApplicationFromLicenceId(Integer licenceId, String applicationType) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "lastAction.status", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		addEq(dc, "type.code", applicationType);
		dc.add(Restrictions.disjunction().add(Restrictions.in("lastAction.status.code", Codes.PendingTaActionStatuses.TA)).add(Restrictions.eq("isDraft", Boolean.TRUE)));
		dc.add(Restrictions.ne("isDeleted", true));
		dc.addOrder(Order.desc("updatedDate"));
		return getFirst(dc);
	}

	public Application getPendingApplicationFromLicenceId(Integer licenceId, Object[] applicationTypes) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "lastAction.status", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		addIn(dc, "type.code", applicationTypes);
		dc.add(Restrictions.disjunction().add(Restrictions.in("lastAction.status.code", Codes.PendingTaActionStatuses.TA)).add(Restrictions.eq("isDraft", Boolean.TRUE)));
		dc.add(Restrictions.ne("isDeleted", true));
		dc.addOrder(Order.desc("updatedDate"));
		return getFirst(dc);
	}

	/**
	 * Get a specific application that pending TA action from licence ID
	 * 
	 * @param licenceId,
	 *            applicationTypeCode objects
	 * @return
	 */
	public Application getPendingApplicationsFromLicenceId(Integer licenceId, Object[] applicationType, Boolean isDraft) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "lastAction.status", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		addIn(dc, "type.code", applicationType);
		if (isDraft) {
			dc.add(Restrictions.disjunction().add(Restrictions.in("lastAction.status.code", Codes.PendingTaActionStatuses.TA)).add(Restrictions.eq("isDraft", isDraft)));
		} else {
			addIn(dc, "lastAction.status.code", Codes.PendingTaActionStatuses.TA);
			addEq(dc, "isDraft", isDraft);
		}
		dc.add(Restrictions.ne("isDeleted", Boolean.TRUE));
		dc.addOrder(Order.desc("updatedDate"));
		return getFirst(dc);
	}

	/**
	 * Get All files and build into DTO for a application
	 * 
	 * @param applicationId
	 * @return
	 */
	public List<FileDto> getFiles(Integer applicationId, FileHelper fileHelper) {
		List<ApplicationFile> dtoList = new ArrayList<ApplicationFile>();
		DetachedCriteria dc = DetachedCriteria.forClass(ApplicationFile.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("file", "file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("documentType", "documentType", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		addEq(dc, "application.id", applicationId);
		dc.addOrder(Order.asc("documentType.label"));
		dtoList = listByDetachedCriteria(dc);

		List<FileDto> fileDtoList = new ArrayList<FileDto>();

		for (ApplicationFile row : dtoList) {
			if (row.getFile() != null) {
				fileDtoList.add(FileDto.buildFromFile(row.getFile(), row.getDocumentType(), fileHelper));
			}
		}

		return fileDtoList;

	}

	public List<ApplicationFile> getModelFiles(Integer applicationId) {
		List<ApplicationFile> dtoList = new ArrayList<ApplicationFile>();
		DetachedCriteria dc = DetachedCriteria.forClass(ApplicationFile.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("file", "file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("documentType", "documentType", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		addEq(dc, "application.id", applicationId);
		dc.addOrder(Order.asc("documentType.label"));
		dtoList = listByDetachedCriteria(dc);

		return dtoList;

	}

	/**
	 * Get Document code, label, instructions details into FileDTO from document list
	 * 
	 * @param docTypeList
	 * @return
	 */
	public List<FileDto> getSupportingDocList(Object[] docTypeList, FileHelper fileHelper) {
		List<FileDto> dtoFileList = new ArrayList<FileDto>();
		List<Type> dtoList = new ArrayList<Type>();

		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		addIn(dc, "code", docTypeList);
		dc.addOrder(Order.asc("label"));
		dtoList = listByDetachedCriteria(dc);

		for (Type row : dtoList) {
			dtoFileList.add(FileDto.buildFromFile(null, row, fileHelper));
		}

		return dtoFileList;
	}

	public ResultDto<WorkflowAction> getWorkflowActionsList(Integer applicationId, WorkflowActionSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowAction.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("files", "files", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("application.id", applicationId));
		dc.addOrder(Order.desc("createdDate"));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return search(dc, searchDto, true);
	}

	public TaApplicationBasicDto getApplicationBasic(Integer applicationId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class, "application");
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", applicationId));
		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.ne("application.isDeleted", Boolean.TRUE));
		dc.add(Restrictions.eq("application.taTgType", Codes.TaTgType.TA));

		addDtoProjections(dc, TaApplicationBasicDto.class);
		return getFirst(dc);
	}

	public List<Application> getApplicationByIds(List<Integer> applicationIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		addIn(dc, "id", applicationIds);
		dc.add(Restrictions.eq("isDraft", Boolean.FALSE));
		dc.add(Restrictions.eq("isDeleted", Boolean.FALSE));
		return getList(dc);
	}
}
