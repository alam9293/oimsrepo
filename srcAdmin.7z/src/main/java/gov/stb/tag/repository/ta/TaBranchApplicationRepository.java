package gov.stb.tag.repository.ta;

import java.util.List;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.branchapplication.TaBranchApplicationItemDto;
import gov.stb.tag.dto.ta.branchapplication.TaBranchApplicationSearchDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaBranchApplication;

@Repository
public class TaBranchApplicationRepository extends TaApplicationRepository {

	public ResultDto<TaBranchApplicationItemDto> getPendingList(TaBranchApplicationSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("appType.code", Codes.ApplicationTypes.TA_APP_BRANCH));
		filter(searchDto, dc, userId);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		addDtoProjections(dc, TaBranchApplicationItemDto.class);
		return search(dc, searchDto, true);
	}

	public List<TaBranchApplication> getApplications(Integer id, Integer travelAgentId, String applicationStatus) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranchApplication.class);
		dc.createAlias("tenancyDoc", "tenancyDoc", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taBranchApplicationBatch", "taBranchApplicationBatch", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taBranchApplicationBatch.appFeePaymentRequest", "appFeePaymentRequest", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taBranchApplicationBatch.application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taBranch", "taBranch", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("address", "address", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taBranch", "taBranch", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.ne("status.code", (Codes.Statuses.TA_BRANCH_PROCESSING_DELETED)));

		if (applicationStatus != null) {
			// dc.add(Restrictions.eq("application.status.code", applicationStatus));
			dc.add(Restrictions.in("lastAction.status.code", applicationStatus));
		}
		if (id != null) {
			dc.add(Restrictions.eq("application.id", id));
		}
		if (travelAgentId != null) {
			dc.add(Restrictions.eq("travelAgent.id", travelAgentId));
		}
		return getList(dc);
	}

	public List<TaBranch> getBranchesByStatus(Integer id, List<String> status) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("address", "address", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.in("status.code", status));
		dc.add(Restrictions.eq("licence.id", id));
		return getList(dc);
	}

	public List<TaBranchApplication> getPendingBranches(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranchApplication.class);
		dc.createAlias("taBranchApplicationBatch", "taBranchApplicationBatch", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taBranchApplicationBatch.application", "application", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taBranchApplicationBatch.appFeePaymentRequest", "appFeePaymentRequest", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taBranch", "taBranch", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taBranch.address", "address", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		Criterion pendingApproval = Restrictions.eq("status.code", Codes.Statuses.TA_BRANCH_PROCESSING_APPROVAL);
		Criterion pendingUpdate = Restrictions.eq("status.code", Codes.Statuses.TA_BRANCH_PROCESSING_UPDATE);
		Criterion pendingCessaed = Restrictions.eq("status.code", Codes.Statuses.TA_BRANCH_PROCESSING_CESSATION);
		Criterion pendingRFA = Restrictions.eq("status.code", Codes.Statuses.TA_APP_RFA);

		// Criterion pendingPayment = Restrictions.ne("appFeePaymentRequest.status.code", Codes.Statuses.PAYREQ_SETTLED);

		// dc.add(Restrictions.or(pendingApproval, pendingUpdate, pendingCessaed, pendingRFA, pendingPayment));
		dc.add(Restrictions.or(pendingApproval, pendingUpdate, pendingCessaed, pendingRFA));
		dc.add(Restrictions.eq("licence.id", id));
		return getList(dc);
	}

}
