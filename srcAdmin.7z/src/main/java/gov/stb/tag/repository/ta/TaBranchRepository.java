package gov.stb.tag.repository.ta;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TaBranchRepository extends BaseRepository {

	public List<TaBranch> getBranchesByLicenceNo(String licenceNo) {
		var dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.like("licence.licenceNo", licenceNo, MatchMode.ANYWHERE));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_BRANCH_ACTIVE));

		return getList(dc);
	}

	public TaBranch updateBranchELicenceFlag(TaBranch taBranch) {
		logger.info("TaBranchRepository IsDownloadable PENDING_REQUEST- " + Codes.ELicenceDownloadRequest.PENDING_REQUEST);
		taBranch.setIsDownloadable(Codes.ELicenceDownloadRequest.PENDING_REQUEST);
		saveOrUpdate(taBranch);
		return taBranch;
	}

	public TaBranch approveBranchELicenceRequest(TaBranch taBranch) {
		logger.info("TaBranchRepository IsDownloadable APPROVE- " + Codes.ELicenceDownloadRequest.APPROVE);
		taBranch.setIsDownloadable(Codes.ELicenceDownloadRequest.APPROVE);
		saveOrUpdate(taBranch);
		return taBranch;
	}

	public TaBranch updateBranchELicToReqNeed(TaBranch taBranch) {
		logger.info("TaBranchRepository IsDownloadable NEED_TO_REQUEST- " + Codes.ELicenceDownloadRequest.NEED_TO_REQUEST);
		taBranch.setIsDownloadable(Codes.ELicenceDownloadRequest.NEED_TO_REQUEST);
		saveOrUpdate(taBranch);
		return taBranch;
	}

	public TaBranch resetBranchELicenceRequest(TaBranch taBranch) {
		logger.info("TaBranchRepository IsDownloadable RESET- " + Codes.ELicenceDownloadRequest.RESET);
		taBranch.setIsDownloadable(Codes.ELicenceDownloadRequest.RESET);
		saveOrUpdate(taBranch);
		return taBranch;
	}
}
