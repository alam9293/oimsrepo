package gov.stb.tag.repository.ta;

import org.springframework.stereotype.Repository;

import gov.stb.tag.repository.BaseRepository;

@Repository
public class TaDashboardRepository extends BaseRepository {

}
