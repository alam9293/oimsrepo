package gov.stb.tag.repository.ta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.travelagent.TravelAgentItemDto;
import gov.stb.tag.dto.ta.travelagent.TravelAgentSearchDto;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TaDirectoryRepository extends BaseRepository {

	protected final static String OPTION_All = "ALL";

	public ResultDto<TravelAgentItemDto> getTaListByFilters(TravelAgentSearchDto searchDto) {
		return search(createDetachedCriteria(searchDto), searchDto, true);
	}

	public List<TravelAgent> getTaListByFiltersWithoutPagination(TravelAgentSearchDto searchDto) {
		return getList(createDetachedCriteria(searchDto));
	}

	private DetachedCriteria createDetachedCriteria(TravelAgentSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TravelAgent.class);

		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);

		if (!StringUtils.isBlank(searchDto.getType()) && !OPTION_All.equals(searchDto.getType())) {
			dc.add(Restrictions.and(Restrictions.eq("licence.tier.code", searchDto.getType())));
		}

		if (!CollectionUtils.isEmpty(searchDto.getService()) && !searchDto.getService().contains(OPTION_All)) {
			var subCriteria = DetachedCriteria.forClass(TravelAgent.class);
			subCriteria.createAlias("inboundServices", "is", JoinType.LEFT_OUTER_JOIN);
			subCriteria.createAlias("outboundServices", "os", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.or(Restrictions.in("is.code", searchDto.getService())).add(Restrictions.in("os.code", searchDto.getService())));
			subCriteria.setProjection(Projections.property("id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}

		if (!CollectionUtils.isEmpty(searchDto.getStatus())) {

			if (!searchDto.getStatus().contains(OPTION_All)) {
				List<String> statuses = new ArrayList<>();

				for (String status : searchDto.getStatus()) {
					if (status.contains("|")) {
						String[] statusSplit = status.split("\\|");
						statuses.addAll(Arrays.asList(statusSplit));
					} else {
						statuses.add(status);
					}
				}
				dc.add(Restrictions.in("licence.status.code", statuses));
			}

		} else {
			List<String> statuses = new ArrayList<>();
			statuses.add(Codes.Statuses.TA_ACTIVE);
			statuses.add(Codes.Statuses.TA_PEND_REVOCATION);
			statuses.add(Codes.Statuses.TA_PEND_SUSPENSION);
			dc.add(Restrictions.in("licence.status.code", statuses));
		}

		if (!StringUtils.isBlank(searchDto.getName())) {
			dc.add(Restrictions.or(Restrictions.ilike("name", searchDto.getName(), MatchMode.ANYWHERE), (Restrictions.ilike("licence.licenceNo", searchDto.getName(), MatchMode.ANYWHERE))));
		}

		if (!StringUtils.isBlank(searchDto.getLicenceName()) && StringUtils.isBlank(searchDto.getMobileName())) {
			dc.add(Restrictions.or(Restrictions.ilike("name", searchDto.getLicenceName(), MatchMode.ANYWHERE),
					(Restrictions.ilike("licence.licenceNo", searchDto.getLicenceName(), MatchMode.ANYWHERE))));
		}

		if (StringUtils.isBlank(searchDto.getLicenceName()) && !StringUtils.isBlank(searchDto.getMobileName())) {
			dc.add(Restrictions.or(Restrictions.ilike("name", searchDto.getMobileName(), MatchMode.ANYWHERE),
					(Restrictions.ilike("licence.licenceNo", searchDto.getMobileName(), MatchMode.ANYWHERE))));
		}

		if (!StringUtils.isBlank(searchDto.getLicenceNo())) {
			dc.add(Restrictions.like("licence.licenceNo", searchDto.getLicenceNo(), MatchMode.ANYWHERE));
		}

		dc.addOrder(Order.asc("name"));

		return dc;
	}

	public TravelAgent getTaDetailByLicenceNo(String licenceNo) {
		var dc = DetachedCriteria.forClass(TravelAgent.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);

		if (!StringUtils.isBlank(licenceNo)) {
			dc.add(Restrictions.like("licence.licenceNo", licenceNo, MatchMode.ANYWHERE));
		}

		return getFirst(dc);
	}
}
