package gov.stb.tag.repository.ta;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceRequestDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceRequestItemDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceRequestSearchDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaELicenceRequest;

@Repository
public class TaELicenceRequestRepository extends TaApplicationRepository {

	public TaELicenceRequest updateELicenceReqDetails(TaELicenceRequestDto dto, TaELicenceRequest taELicenceReqModel) {
		taELicenceReqModel.setReason(dto.getReason());
		return taELicenceReqModel;
	}

	public Licence updateELicenceFlag(TaELicenceRequestDto dto, Licence licenceModel) {
		licenceModel.setIsDownloadable(Codes.ELicenceDownloadRequest.PENDING_REQUEST);
		saveOrUpdate(licenceModel);
		return licenceModel;
	}

	public Licence approveELicenceRequest(Licence licenceModel) {
		licenceModel.setIsDownloadable(Codes.ELicenceDownloadRequest.APPROVE);
		saveOrUpdate(licenceModel);
		return licenceModel;
	}

	public TaELicenceRequest getPendingApplication(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaELicenceRequest.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		dc.add(Restrictions.disjunction().add(Restrictions.in("status.code", Codes.PendingTaActionStatuses.TA)));
		dc.addOrder(Order.desc("updatedDate"));

		return getFirst(dc);
	}

	public TaELicenceRequestDto getELicenceRequestByAppId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaELicenceRequest.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "application.id", id);
		dc.addOrder(Order.desc("application.updatedDate"));
		addDtoProjections(dc, TaELicenceRequestDto.class);
		return getFirst(dc);
	}

	public ResultDto<TaELicenceRequestItemDto> getPendingList(TaELicenceRequestSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("appType.code", Codes.ApplicationTypes.TA_APP_ELICENCE_REQUEST));
		filter(searchDto, dc, userId);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		addDtoProjections(dc, TaELicenceRequestItemDto.class);
		return search(dc, searchDto, true);

	}

	public Licence updateELicToReqNeed(Licence licenceModel) {
		licenceModel.setIsDownloadable(Codes.ELicenceDownloadRequest.NEED_TO_REQUEST);
		saveOrUpdate(licenceModel);
		return licenceModel;
	}

	public Licence resetELicenceRequest(Licence licenceModel) {
		licenceModel.setIsDownloadable(Codes.ELicenceDownloadRequest.RESET);
		saveOrUpdate(licenceModel);
		return licenceModel;
	}

	public Licence updateELicenceViewFlag(Licence licenceModel, boolean isAllReset) {
		licenceModel.setIsViewable(Codes.ELicenceView.VIEW);
		if (isAllReset) {
			licenceModel.setIsDownloadable(Codes.ELicenceDownloadRequest.RESET);
		}
		saveOrUpdate(licenceModel);
		return licenceModel;
	}
}
