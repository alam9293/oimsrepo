package gov.stb.tag.repository.ta;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.WorkflowStatuses;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingSearchDto;
import gov.stb.tag.dto.ta.filingamend.TaLicenceFilingAmendSearchDto;
import gov.stb.tag.model.TaAdhocFilingRequest;
import gov.stb.tag.model.TaFilingConditionAmendment;
import gov.stb.tag.repository.WorkflowRepository;

@Repository
public class TaFilingAmendmentRepository extends WorkflowRepository {

	public ResultDto<TaFilingConditionAmendment> getList(TaLicenceFilingSearchDto searchDto, Integer userId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingConditionAmendment.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addIsNotNull(dc, "id");
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("createdDate"));
		}

		if (searchDto.getLicenceId() != null || searchDto.getFilingTypes() != null) {

			addEq(dc, "licence.id", searchDto.getLicenceId());
			if (searchDto.getExcludeAssessmentId() != null) {
				addNe(dc, "id", searchDto.getExcludeAssessmentId());
			}
			if (searchDto.getFilingTypes() != null) {
				dc.createAlias("taFilingConditionExtensions.taFilingCondition", "taFilingCondition", JoinType.LEFT_OUTER_JOIN);
				dc.createAlias("taFilingConditionExtensions.taFilingCondition.applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);
				addIn(dc, "applicationType.code", searchDto.getFilingTypes());
				addIn(dc, "lastAction.status.code", WorkflowStatuses.NOT_PENDING_STB_TA);
			}

			dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		} else {
			dc.createAlias("workflow.lastAction.type", "type", JoinType.LEFT_OUTER_JOIN);
			filter(searchDto, dc, userId);
		}

		if (searchDto.getApproveDateFrom() != null || searchDto.getApproveDateTo() != null) {
			dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
			if (searchDto.getApproveDateFrom() != null) {
				addGe(dc, "lastAction.createdDate", searchDto.getApproveDateFrom());
			}
			if (searchDto.getApproveDateTo() != null) {
				addLt(dc, "lastAction.createdDate", searchDto.getApproveDateTo().plusDays(1));
			}
		}

		return search(dc, searchDto, true);
	}

	public List<TaAdhocFilingRequest> getAdhocRequestPendingTa(TaLicenceFilingAmendSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingConditionAmendment.class);
		dc.createAlias("ammendmentType", "ammendmentType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addNe(dc, "id", searchDto.getExcludeAmendId());
		addEq(dc, "licence.id", searchDto.getLicenceId());
		addNotIn(dc, "lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_TA);
		addEq(dc, "reqType.code", searchDto.getAmmendTypeCode());
		dc.addOrder(Order.desc("dueDate"));
		return getList(dc);
	}

	public TaFilingConditionAmendment getAmendments(Integer licenceId, Integer filingId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingConditionAmendment.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.type", "type", JoinType.LEFT_OUTER_JOIN);
		addNotIn(dc, "lastAction.status.code", Codes.WorkflowStatuses.NOT_PENDING_STB_TA);
		addIn(dc, "licence.id", licenceId);

		if (filingId != null) {
			dc.createAlias("taFilingConditionExtensions", "taFilingConditionExtensions", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("taFilingConditionExtensions.taFilingCondition", "taFilingCondition", JoinType.LEFT_OUTER_JOIN);
			addIn(dc, "taFilingCondition.id", filingId);
		}

		dc.addOrder(Order.desc("updatedDate"));
		return getFirst(dc);

	}

}
