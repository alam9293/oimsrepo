package gov.stb.tag.repository.ta;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.fye.TaChangeFyeItemDto;
import gov.stb.tag.dto.ta.fye.TaChangeFyeSearchDto;
import gov.stb.tag.dto.ta.fye.TaFyDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFyUpdate;

@Repository
public class TaFyeUpdateRepository extends TaApplicationRepository {

	public ResultDto<TaChangeFyeItemDto> getPendingList(TaChangeFyeSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("appType.code", Codes.ApplicationTypes.TA_APP_FY_UPDATE));
		filter(searchDto, dc, userId);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		addDtoProjections(dc, TaChangeFyeItemDto.class);
		return search(dc, searchDto, true);

	}

	public TaFyUpdate getApplication(Integer applId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFyUpdate.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", applId));
		return getFirst(dc);
	}

	public TaFyUpdate getPendingApplication(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFyUpdate.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.or(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.TA), Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_RFA)));
		return getFirst(dc);

	}

	/**
	 * Get the unique list of fy end date based on AA and ABPR Annual Filings
	 * 
	 * @param licenceId
	 * @return
	 */
	public List<TaFyDto> getFys(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class, "mainAf");
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.not(Restrictions.in("status.code", Lists.newArrayList(Codes.Statuses.TA_FILING_APPROVED, Codes.Statuses.TA_FILING_VOID))));
		addIn(dc, "applicationType.code", Lists.newArrayList(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION)); // get only the system generated filing, to
																																							// exclude the ad-hoc filing

		DetachedCriteria sub_criteria = DetachedCriteria.forClass(TaFilingCondition.class, "subAf");
		sub_criteria.add(Restrictions.eq("licence.id", licenceId));
		sub_criteria.add(Restrictions.in("status.code", Lists.newArrayList(Codes.Statuses.TA_FILING_APPROVED)));
		addIn(sub_criteria, "applicationType.code", Lists.newArrayList(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION));
		sub_criteria.add(Property.forName("mainAf.fyEndDate").eqProperty(Property.forName("subAf.fyEndDate")));
		sub_criteria.setProjection(Projections.property("subAf.id"));

		dc.add(Subqueries.notExists(sub_criteria));
		dc.addOrder(Order.asc("fyEndDate"));
		addDtoProjections(dc, TaFyDto.class, true);
		return getList(dc);
	}

	public TaAaSubmission getTaAaSubmissionByFilingId(Integer filingId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("taAnnualFiling.id", filingId));
		dc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Lists.newArrayList(Codes.Statuses.TA_APP_APPROVED, Codes.Statuses.TA_APP_REJECTED))));
		return getFirst(dc);
	}

	public TaAbprSubmission getTaAbprSubmissionByFilingId(Integer filingId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaAbprSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("taAnnualFiling.id", filingId));
		dc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Lists.newArrayList(Codes.Statuses.TA_APP_APPROVED, Codes.Statuses.TA_APP_REJECTED))));

		return getFirst(dc);
	}

	public TaAaSubmission getDraftTaAaSubmissionByFilingId(Integer filingId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("taAnnualFiling.id", filingId));
		dc.add(Restrictions.eq("application.isDraft", Boolean.TRUE));
		return getFirst(dc);
	}

	public TaAbprSubmission getDraftTaAbprSubmissionByFilingId(Integer filingId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaAbprSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("taAnnualFiling.id", filingId));
		dc.add(Restrictions.eq("application.isDraft", Boolean.TRUE));

		return getFirst(dc);
	}
}
