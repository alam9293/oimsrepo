package gov.stb.tag.repository.ta;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licencemanageke.TaLicenceKeDetailsDto;
import gov.stb.tag.dto.ta.licencemanageke.TaLicenceKeItemDto;
import gov.stb.tag.dto.ta.licencemanageke.TaLicenceKeSearchDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;

@Repository
public class TaKeApplicationRepository extends TaApplicationRepository {

	@Autowired
	protected CacheHelper cache;

	public static final Object[] TaKeAppType = { Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS, Codes.ApplicationTypes.TA_APP_KE_RESIGN, Codes.ApplicationTypes.TA_APP_KE_REASSIGN,
			Codes.ApplicationTypes.TA_APP_KE_ASSIGN };

	public ResultDto<TaLicenceKeItemDto> getPendingList(TaLicenceKeSearchDto searchDto, Integer userId) {

		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}

		filter(searchDto, dc, userId);
		if (!Strings.isNullOrEmpty(searchDto.getAppType())) {
			addEq(dc, "type.code", searchDto.getAppType());
		} else {
			addIn(dc, "type.code", TaKeAppType);
		}

		addDtoProjections(dc, TaLicenceKeItemDto.class);

		return search(dc, searchDto, true);

	}

	public TaStakeholderApplication updateTaStakeholderAppFromAppDto(TaLicenceKeDetailsDto dto, TaStakeholderApplication stakeholderAppModel, CacheHelper cache, Application appModel,
			TaStakeholder keDetails) {
		stakeholderAppModel.setType(cache.getType(dto.getKeAppType()));
		stakeholderAppModel.setRole(cache.getType(Codes.TaStakeholderRoles.STKHLD_KE));

		StakeholderDto basicDto = new StakeholderDto();
		AddressDto addDto = new AddressDto();

		if (Codes.ApplicationTypes.TA_APP_KE_ASSIGN.equalsIgnoreCase(stakeholderAppModel.getType().getCode())
				|| Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(stakeholderAppModel.getType().getCode())
				|| Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS.equalsIgnoreCase(stakeholderAppModel.getType().getCode())) {
			basicDto = dto.getNewStakeholderDto();
			addDto = dto.getNewStakeholderDto().getAddress();
			if (dto.getIsMyInfoPopulated()) {
				stakeholderAppModel.setIsMyInfoPopulated(dto.getIsMyInfoPopulated());
			} else {
				stakeholderAppModel.setIsMyInfoPopulated(Boolean.FALSE);
			}

		} else {
			basicDto = dto.getStakeholderDto();
			addDto = dto.getStakeholderDto().getAddress();
		}
		if (Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(stakeholderAppModel.getType().getCode())
				|| Codes.ApplicationTypes.TA_APP_KE_RESIGN.equalsIgnoreCase(stakeholderAppModel.getType().getCode())) {
			if (dto.getTaKeStakeholder().getResignedDate() == null) {
				stakeholderAppModel.setResignedDate(LocalDate.now());
			} else {
				stakeholderAppModel.setResignedDate(dto.getTaKeStakeholder().getResignedDate());
			}

		}
		// TaStakeholderDto taDto = dto.getTaStakeholders();
		stakeholderAppModel.setUin(basicDto.getUin());
		stakeholderAppModel.setName(basicDto.getStakeholderName());
		if (basicDto.getSex().getKey() != null) {
			stakeholderAppModel.setSex(cache.getType(basicDto.getSex().getKey().toString()));
		}
		if (basicDto.getNationality().getKey() != null) {
			stakeholderAppModel.setNationality(cache.getType(basicDto.getNationality().getKey().toString()));
		}
		if (basicDto.getHighestEduLevel().getKey() != null) {
			stakeholderAppModel.setHighestEduLevel(cache.getType(basicDto.getHighestEduLevel().getKey().toString()));
		}
		if (basicDto.getDesignation().getKey() != null) {
			stakeholderAppModel.setDesignation(cache.getType(basicDto.getDesignation().getKey().toString()));
		}
		stakeholderAppModel.setDob(basicDto.getDob());
		stakeholderAppModel.setContactNo(basicDto.getContactNo());

		stakeholderAppModel.setOfficeNo(basicDto.getOfficeNo());
		stakeholderAppModel.setResidentialNo(basicDto.getResidentialNo());

		stakeholderAppModel.setEmail(basicDto.getEmail());
		stakeholderAppModel.setOtherDesignation(basicDto.getOtherDesignation());
		stakeholderAppModel.setRole(cache.getType(Codes.TaStakeholderRoles.STKHLD_KE));
		stakeholderAppModel.setType(cache.getType(dto.getKeAppType()));
		stakeholderAppModel.setAppointedDate(dto.getNewTaStakeholderDto().getAppointedDate());

		if (addDto != null) {
			Address addmodel = new Address();

			addmodel.setPostal(addDto.getPostal());
			addmodel.setStreet(addDto.getStreet());
			addmodel.setBuilding(addDto.getBuilding());
			addmodel.setBlock(addDto.getBlock());
			addmodel.setFloor(addDto.getFloor());
			addmodel.setUnit(addDto.getUnit());
			addmodel.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			saveOrUpdate(addmodel);

			stakeholderAppModel.setAddress(addmodel);
		}

		stakeholderAppModel.setApplication(appModel);
		if (keDetails.getId() != null) {
			stakeholderAppModel.setTaStakeholder(keDetails);// Save current TA stakeholder KE into application
		}

		return stakeholderAppModel;
	}

	public TaStakeholderApplication getKeAppFromAppId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholderApplication.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholder", "taStakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("previousValue", "previousValue", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taKeDeclarations", "taKeDeclarations", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("address", "address", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholder.stakeholder", "taStakeholder.stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholder.taKeDeclarations", "taStakeholder.taKeDeclarations", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "application.id", id);
		dc.add(Restrictions.ne("application.isDeleted", Boolean.TRUE));

		return getFirst(dc);
	}

	public List<TaStakeholder> getTaStakeholdersFromStakeholder(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "stakeholder.id", id);
		// addNe(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		return getList(dc);
	}

	public Stakeholder updateStakeholderModelFromStakeholderAppModel(Stakeholder currentStakeholderModel, TaStakeholderApplication keAppModel) {

		TaStakeholderApplication basicModel = keAppModel;
		// TaStakeholderDto taDto = dto.getTaStakeholders();
		currentStakeholderModel.setUin(basicModel.getUin());
		currentStakeholderModel.setName(basicModel.getName());
		currentStakeholderModel.setSex(cache.getType(basicModel.getSex().getKey().toString()));
		currentStakeholderModel.setNationality(cache.getType(basicModel.getNationality().getKey().toString()));
		currentStakeholderModel.setDob(basicModel.getDob());
		currentStakeholderModel.setContactNo(basicModel.getContactNo());

		currentStakeholderModel.setOfficeNo(basicModel.getOfficeNo());
		currentStakeholderModel.setResidentialNo(basicModel.getResidentialNo());

		currentStakeholderModel.setEmail(basicModel.getEmail());
		currentStakeholderModel.setHighestEduLevel(cache.getType(basicModel.getHighestEduLevel().getKey().toString()));
		currentStakeholderModel.setDesignation(cache.getType(basicModel.getDesignation().getKey().toString()));
		currentStakeholderModel.setOtherDesignation(basicModel.getOtherDesignation());

		Address addNew = new Address();
		addNew = keAppModel.getAddress();

		currentStakeholderModel.setAddress(addNew);
		return currentStakeholderModel;
	}

	public TaLicenceKeDetailsDto compareUserUinAndKeUin(TaLicenceKeDetailsDto resultDto, String userUin, String currentKeUin) {
		// Check if current logged in user is KE
		if (!Strings.isNullOrEmpty(userUin)) {
			if (userUin.equalsIgnoreCase(currentKeUin)) {
				resultDto.setApplicantIsKe(Boolean.TRUE);
				// resultDto.setIsMyInfoPopulated(Boolean.TRUE);
			} else {
				resultDto.setApplicantIsKe(Boolean.FALSE);
				// resultDto.setIsMyInfoPopulated(Boolean.FALSE);
			}
		}
		resultDto.setIsMyInfoPopulated(Boolean.FALSE);
		return resultDto;
	}

	public List<TaKeDeclarationsDto> getStakeholderAppClause(Integer id) {
		List<TaKeDeclaration> clauseList = new ArrayList<TaKeDeclaration>();
		DetachedCriteria dc = DetachedCriteria.forClass(TaKeDeclaration.class);
		dc.createAlias("taKeyExecutiveApplication", "taKeyExecutiveApplication", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taKeClause", "taKeClause", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "taKeyExecutiveApplication.id", id);
		dc.addOrder(Order.asc("taKeClause.ordinal"));
		clauseList = listByDetachedCriteria(dc);

		List<TaKeDeclarationsDto> declareDtoList = new ArrayList<TaKeDeclarationsDto>();

		for (TaKeDeclaration row : clauseList) {
			declareDtoList.add(TaKeDeclarationsDto.buildClauseOnly(cache, row.getTaKeClause()));
		}

		return declareDtoList;
	}

	public TaStakeholder getTaStakeholderFromUin(String uin, String name) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		// addEq(dc, "licence.id", licenceId);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		addEq(dc, "stakeholder.uin", uin);
		addEq(dc, "stakeholder.name", name);

		return getFirst(dc);
	}

	public TaStakeholder getTaStakeholderFromStakeholder(String uin, String name, Integer licenceId, Integer stakeholderId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		addEq(dc, "stakeholder.uin", uin);
		addEq(dc, "stakeholder.name", name);
		addEq(dc, "stakeholder.id", stakeholderId);
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));

		return getFirst(dc);
	}

	public StakeholderDto retrieveSnapshotIntoDto(TaStakeholderApplication prevValue, StakeholderDto shDto) {
		shDto.setAddress(AddressDto.buildFromAddress(cache, prevValue.getAddress()));
		shDto = new StakeholderDto(cache, prevValue);
		return shDto;
	}

}
