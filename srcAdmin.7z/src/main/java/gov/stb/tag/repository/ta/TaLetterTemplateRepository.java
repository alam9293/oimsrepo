package gov.stb.tag.repository.ta;

import gov.stb.tag.model.LetterTemplate;
import gov.stb.tag.repository.BaseRepository;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TaLetterTemplateRepository extends BaseRepository {

    public List<LetterTemplate> getLetterTemplates() {
        DetachedCriteria dc = DetachedCriteria.forClass(LetterTemplate.class);
        dc.add(Restrictions.eq("isActive", true));
        dc.addOrder(Order.asc("name"));
        return getList(dc);
    }

    public LetterTemplate getLetterTemplateDetail(String code) {
        DetachedCriteria dc = DetachedCriteria.forClass(LetterTemplate.class);
        dc.add(Restrictions.eq("code", code));
        return getFirst(dc);
    }

}
