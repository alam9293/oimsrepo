package gov.stb.tag.repository.ta;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licencecreation.TaLicenceCreationItemDto;
import gov.stb.tag.dto.ta.licencecreation.TaLicenceCreationSearchDto;
import gov.stb.tag.model.TaLicenceCreation;

@Repository
public class TaLicenceCreationRepository extends TaApplicationRepository {
	public TaLicenceCreation getPendingApplication(String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.INNER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("registeredAddress", "registeredAddress", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("operatingAddress", "operatingAddress", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taKeyExecutive", "taKeyExecutive", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taSpecializedMarkets", "taSpecializedMarkets", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taBusinessOperations", "taBusinessOperations", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taFocusAreas", "taFocusAreas", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders", "taStakeholders", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("uen", uen));
		// dc.add(Restrictions.or(Restrictions.eq("application.isDraft", true),
		// Restrictions.and(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_APPROVED),
		// Restrictions.or(Restrictions.eq("licenceFeeStatus.code", Codes.Statuses.PAYREQ_NOT_PAID), Restrictions.eq("licenceFeeStatus.code", Codes.Statuses.PAYREQ_PAID))),
		// Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.TA), Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_RFA),
		// Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_PENDING_OA)));
		dc.add(Restrictions.eq("isConcluded", false));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);

	}

	public ResultDto<TaLicenceCreationItemDto> getPendingList(TaLicenceCreationSearchDto searchDto, Integer userId, boolean pagination) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.type", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("appType.code", Codes.ApplicationTypes.TA_APP_CREATION));
		addNotIn(dc, "lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TA);// show pending only
		addLike(dc, "companyName", searchDto.getName());
		addLike(dc, "uen", searchDto.getUen());
		addLike(dc, "application.applicationNo", searchDto.getApplicationNo());
		addEq(dc, "lastAction.status.code", searchDto.getApplicationStatus());
		addIn(dc, "lastAction.status.code", searchDto.getApplicationStatuses());
		addEq(dc, "appType.code", searchDto.getApplicationType());
		if (searchDto.getSubmissionDateTo() != null) {
			addLt(dc, "application.submissionDate", searchDto.getSubmissionDateTo().plusDays(1));
		}

		addGe(dc, "application.submissionDate", searchDto.getSubmissionDateFrom());
		addLike(dc, "assignee.name", searchDto.getAssignedOfficer());
		if (searchDto.getMyApplications() == true) {
			addEq(dc, "application.assignee.id", userId);
		}
		if (searchDto.getLicenceNo() != null) {
			dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
			addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		}
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		dc.add(Restrictions.ne("application.isDeleted", true));
		addDtoProjections(dc, TaLicenceCreationItemDto.class);
		return search(dc, searchDto, pagination);

	}

	public TaLicenceCreation getApplication(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.INNER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("registeredAddress", "registeredAddress", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("operatingAddress", "operatingAddress", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taKeyExecutive", "taKeyExecutive", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taSpecializedMarkets", "taSpecializedMarkets", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taBusinessOperations", "taBusinessOperations", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taFocusAreas", "taFocusAreas", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders", "taStakeholders", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);

	}

	public List<TaLicenceCreation> getAllPendingApplications() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.TA));
		return getList(dc);
	}

}
