package gov.stb.tag.repository.ta;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licenceprint.TaLicencePrintItemDto;
import gov.stb.tag.dto.ta.licenceprint.TaLicencePrintSearchDto;
import gov.stb.tag.model.Application;

@Repository
public class TaLicencePrintRepository extends TaApplicationRepository {

	public ResultDto<TaLicencePrintItemDto> getList(TaLicencePrintSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_APPROVED));
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		addIn(dc, "type.code", Codes.ApplicationTypes.TA_APP_LICENCE_PRINT_TYPES);
		addLike(dc, "travelAgent.name", searchDto.getName());
		addLike(dc, "travelAgent.uen", searchDto.getUen());
		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addEq(dc, "licence.expiryDate", searchDto.getLicenceExpiryDate());

		addLike(dc, "applicationNo", searchDto.getApplicationNo());
		addEq(dc, "type.code", searchDto.getApplicationType());
		addIsNotNull(dc, "licencePrintStatus.code");
		addNe(dc, "licencePrintStatus.code", Codes.Statuses.TA_PRINT_NA);
		addEq(dc, "licencePrintStatus.code", searchDto.getLicencePrintStatus());
		addLike(dc, "assignee.name", searchDto.getAssignedOfficer());

		if (searchDto.getMyApplications() == true) {
			addEq(dc, "assignee.id", userId);
		}
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("lastAction.updatedDate"));
		}
		addDtoProjections(dc, TaLicencePrintItemDto.class);
		return search(dc, searchDto, true);
	}
}
