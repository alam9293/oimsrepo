package gov.stb.tag.repository.ta;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.constant.Codes.TaFilingStatuses;
import gov.stb.tag.constant.Codes.TaStatuses;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingSearchDto;
import gov.stb.tag.dto.ta.licence.TaCpfArrearDto;
import gov.stb.tag.dto.ta.licence.TaLicenceItemDto;
import gov.stb.tag.dto.ta.licence.TaLicencePersonnelItemDto;
import gov.stb.tag.dto.ta.licence.TaLicencePersonnelSearchDto;
import gov.stb.tag.dto.ta.licence.TaLicenceSearchDto;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaCpfArrear;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.util.DateUtil;

@Repository
public class TaLicenceRepository extends TaApplicationRepository {

	// CR12207
	public SystemParameter getJobParameter(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(SystemParameter.class);
		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

	// CR12207
	public List<TaFilingCondition> getPendingTaAnnualFilingSubmissionsByLicenceId(String startDate, Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "applicationType.code", ApplicationTypes.FOR_TA_FILING_REMINDER);
		addIn(dc, "status.code", TaFilingStatuses.FOR_TA_FILING_REMINDER);
		addIn(dc, "licence.status.code", TaStatuses.GENERALLY_ACTIVE);
		dc.add(Restrictions.ge("createdDate", DateUtil.parseDateTime(startDate)));
		dc.add(Restrictions.eq("licence.id", licenceId));
		// dc.addOrder(Order.asc("licence.id"));
		return getList(dc);
	}

	// CR12207
	public TaLicenceRenewalExerciseTa getTaByLicenceId(Integer id) {
		LocalDate current_date = LocalDate.now();
		int current_Year = current_date.getYear();

		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("taAaFilingCondition1", "taAaFilingCondition1", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAaFilingCondition2", "taAaFilingCondition2", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("taNetValueShortfallAa1", "taNetValueShortfallAa1", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueShortfallAa2", "taNetValueShortfallAa2", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("taAbprFilingCondition1", "taAbprFilingCondition1", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAbprFilingCondition2", "taAbprFilingCondition2", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("taNetValueShortfallMa1", "taNetValueShortfallMa1", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueShortfallMa2", "taNetValueShortfallMa2", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "taLicenceRenewalExercise.year", current_Year);
		addEq(dc, "licence.id", id);

		return getFirst(dc);
	}

	public Licence getLicence(Integer licenceId, Boolean joinLicences, Boolean joinTaAddresses) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		if (joinTaAddresses) {
			dc.createAlias("travelAgent.registeredAddress", "registeredAddress", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("travelAgent.operatingAddress", "operatingAddress", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("travelAgent.displayAddress", "displayAddress", JoinType.LEFT_OUTER_JOIN);
		}
		if (joinLicences) {
			dc.createAlias("travelAgent.licences", "licences", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("licences.travelAgent", "licences.travelAgent", JoinType.LEFT_OUTER_JOIN);
		}
		dc.add(Restrictions.eq("id", licenceId));
		return getFirst(dc);
	}

	public List<TaFilingCondition> getAbprFys(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", id));
		dc.add(Restrictions.eq("applicationType.code", Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_FILING_APPROVED));
		dc.addOrder(Order.desc("fyEndDate"));
		return getList(dc);
	}

	public TaAbprSubmission getAbpr(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAbprSubmission.class);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taSpecializedMarkets", "taSpecializedMarkets", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taBusinessOperations", "taBusinessOperations", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFocusAreas", "taFocusAreas", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("appStatus.code", Codes.Statuses.TA_APP_APPROVED));
		dc.add(Restrictions.eq("taAnnualFiling.id", id));
		return getFirst(dc);
	}

	public List<TaAaSubmission> getFinancialAa(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("applicationType.code", Codes.ApplicationTypes.TA_APP_AA_SUBMISSION));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_FILING_APPROVED));
		dc.add(Restrictions.eq("licence.id", id));
		dc.add(Restrictions.eq("appStatus.code", Codes.Statuses.TA_APP_APPROVED));
		dc.addOrder(Order.desc("taAnnualFiling.fyEndDate"));
		return getList(dc);

	}

	public List<TaMaSubmission> getFinancialMa(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaMaSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFilingCondition", "taFilingCondition", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFilingCondition.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFilingCondition.applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFilingCondition.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("applicationType.code", Codes.ApplicationTypes.TA_APP_MA_SUBMISSION));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_FILING_APPROVED));
		dc.add(Restrictions.eq("licence.id", id));
		dc.add(Restrictions.eq("appStatus.code", Codes.Statuses.TA_APP_APPROVED));
		dc.addOrder(Order.desc("asAtDate"));
		return getList(dc);

	}

	public ResultDto<TaLicenceItemDto> getTaLicences(TaLicenceSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		filter(searchDto, dc);

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("issueDate"));
		}

		addDtoProjections(dc, TaLicenceItemDto.class);
		return search(dc, searchDto, true);

	}

	public ResultDto<TaLicencePersonnelItemDto> getPersonnels(TaLicencePersonnelSearchDto searchDto, Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", id));

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.asc("resignedDate"));
			dc.addOrder(Order.asc("role.ordinal"));
		}

		addDtoProjections(dc, TaLicencePersonnelItemDto.class);
		return search(dc, searchDto, true);

	}

	public TaStakeholder getPersonnel(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);

	}

	public List<StatusSpan> getStatusSpan(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(StatusSpan.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("licence.taTgType", Codes.TaTgType.TA));
		dc.addOrder(Order.desc("startDate"));

		return getList(dc);
	}

	public ResultDto<TaCpfArrearDto> getTaCpfArrears(TaLicenceSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaCpfArrear.class);
		dc.add(Restrictions.eq("uen", searchDto.getUen()));
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("responseDate"));
		}
		addDtoProjections(dc, TaCpfArrearDto.class);
		return search(dc, searchDto, true);
	}

	private DetachedCriteria filter(TaLicenceSearchDto searchDto, DetachedCriteria dc) {

		if (!Strings.isNullOrEmpty(searchDto.getName())) {
			dc.add(Restrictions.disjunction().add(Restrictions.ilike("travelAgent.name", searchDto.getName(), MatchMode.ANYWHERE))
					.add(Restrictions.ilike("travelAgent.formerName", searchDto.getName(), MatchMode.ANYWHERE)));
		}

		addLike(dc, "licenceNo", searchDto.getLicenceNo());

		addLike(dc, "travelAgent.uen", searchDto.getUen());

		addEq(dc, "tier.code", searchDto.getTier());

		addLe(dc, "issueDate", searchDto.getIssueDateTo());

		addGe(dc, "issueDate", searchDto.getIssueDateFrom());

		addLe(dc, "ceasedDate", searchDto.getCessationDateTo());

		addGe(dc, "ceasedDate", searchDto.getCessationDateFrom());

		addEq(dc, "status.code", searchDto.getStatusCode());

		return dc;
	}

	public List<Licence> getActiveTaLicences() {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "status.code", Codes.TaStatuses.GENERALLY_ACTIVE);
		return getList(dc);
	}

	public ResultDto<TaAnnualFilingDto> getAllTaFilingConditions(TaLicenceFilingSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "applicationType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastExtension", "lastExtension", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);

		if (searchDto.getLicenceId() != null) {
			addEq(dc, "licence.id", searchDto.getLicenceId());
		}

		if (searchDto.getFilingTypes() != null) {
			addIn(dc, "applicationType.code", searchDto.getFilingTypes());
		}

		dc.addOrder(Order.desc("dueDate"));
		dc.addOrder(Order.desc("applicationType.label"));
		ResultDto<TaFilingCondition> result = search(dc, searchDto, true);

		ResultDto<TaAnnualFilingDto> resultDto = new ResultDto<TaAnnualFilingDto>();

		resultDto.setTotal(result.getTotal());
		resultDto.setResult(result.getResult());
		resultDto.setSuccessFlag(result.getSuccessFlag());
		Object[] records = new Object[result.getModels().size()];
		resultDto.setRecords(records);
		int i = 0;
		if (result.getModels().size() > 0) {
			for (TaFilingCondition row : result.getModels()) {
				records[i++] = TaAnnualFilingDto.build(row);
			}
		}

		return resultDto;
	}
}
