package gov.stb.tag.repository.ta;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.abpr.TaBusinessOperationDto;
import gov.stb.tag.dto.ta.licencetierswitch.TaLicenceTierSwitchDto;
import gov.stb.tag.dto.ta.licencetierswitch.TaLicenceTierSwitchItemDto;
import gov.stb.tag.dto.ta.licencetierswitch.TaLicenceTierSwitchSearchDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaBusinessOperation;
import gov.stb.tag.model.TaLicenceTierSwitch;

@Repository
public class TaLicenceTierSwitchRepository extends TaApplicationRepository {

	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	protected CacheHelper cache;
	@Autowired
	protected Properties properties;

	public ResultDto<TaLicenceTierSwitchItemDto> getPendingList(TaLicenceTierSwitchSearchDto searchDto, Integer userId) {

		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "type.code", Codes.ApplicationTypes.TA_APP_TIER_SWITCH);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}

		filter(searchDto, dc, userId);
		addDtoProjections(dc, TaLicenceTierSwitchItemDto.class);

		return search(dc, searchDto, true);

	}

	public TaLicenceTierSwitchDto getTierSwitchByAppId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceTierSwitch.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "application.id", id);
		dc.addOrder(Order.desc("application.updatedDate"));
		addDtoProjections(dc, TaLicenceTierSwitchDto.class);
		return getFirst(dc);
	}

	public TaLicenceTierSwitch updateTierSwitchDetails(TaLicenceTierSwitchDto dto, TaLicenceTierSwitch tierSwitcModel) {
		tierSwitcModel.setOldLicenceTier(cache.getType(dto.getOldLicenceTierCode()));
		tierSwitcModel.setNewLicenceTier(cache.getType(dto.getNewLicenceTierCode()));
		tierSwitcModel.setStartDate(dto.getNewTierStartDate());

		return tierSwitcModel;
	}

	public TaLicenceTierSwitch updateBusinessOperations(TaLicenceTierSwitchDto dto, TaLicenceTierSwitch tierSwitcModel) {
		for (TaBusinessOperationDto boDto : dto.getTaBusinessOperations()) {
			TaBusinessOperation bo = new TaBusinessOperation();
			if (boDto.getId() == null) {
				bo.setInboundPercent(boDto.getInboundPercent());
				bo.setOutboundPercent(boDto.getOutboundPercent());
				bo.setService(cache.getType(boDto.getService().getKey().toString()));
				bo.setTaLicenceTierSwitch(tierSwitcModel);
			} else {
				bo = get(TaBusinessOperation.class, boDto.getId());
				bo.setInboundPercent(boDto.getInboundPercent());
				bo.setOutboundPercent(boDto.getOutboundPercent());
				bo.setService(cache.getType(boDto.getService().getKey().toString()));
			}
			saveOrUpdate(bo);
		}

		for (TaBusinessOperationDto boDto : dto.getNewTaBusinessOperations()) {
			TaBusinessOperation bo = new TaBusinessOperation();
			if (boDto.getId() == null) {
				bo.setInboundPercent(boDto.getInboundPercent());
				bo.setOutboundPercent(boDto.getOutboundPercent());
				bo.setService(cache.getType(boDto.getService().getKey().toString()));
				bo.setNewTaLicenceTierSwitch(tierSwitcModel);
			} else {
				bo = get(TaBusinessOperation.class, boDto.getId());
				bo.setInboundPercent(boDto.getInboundPercent());
				bo.setOutboundPercent(boDto.getOutboundPercent());
				bo.setService(cache.getType(boDto.getService().getKey().toString()));
			}
			saveOrUpdate(bo);
		}

		List<Integer> toDeleteList = dto.getToDeletebusinessRows();
		if (toDeleteList != null && !toDeleteList.isEmpty()) {
			for (Integer id : toDeleteList) {
				if (id != null) {
					TaBusinessOperation item = new TaBusinessOperation();
					item = get(TaBusinessOperation.class, id);
					if (item != null) {
						delete(item);
					}
				}
			}
		}

		return tierSwitcModel;
	}

	public TaLicenceTierSwitchDto buildBusinessOperationsIntoDto(TaLicenceTierSwitchDto resultDto) {
		List<TaBusinessOperation> bo = new ArrayList<>();
		List<TaBusinessOperationDto> boDto = new ArrayList<>();

		DetachedCriteria dc = DetachedCriteria.forClass(TaBusinessOperation.class);
		dc.createAlias("taLicenceTierSwitch", "taLicenceTierSwitch", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "taLicenceTierSwitch.id", resultDto.getId());
		bo = getList(dc);

		for (TaBusinessOperation aBO : bo) {
			boDto.add(TaBusinessOperationDto.buildFromBO(cache, aBO));
		}
		resultDto.setTaBusinessOperations(boDto);

		List<TaBusinessOperation> newBo = new ArrayList<>();
		List<TaBusinessOperationDto> newBoDto = new ArrayList<>();

		DetachedCriteria dc2 = DetachedCriteria.forClass(TaBusinessOperation.class);
		dc2.createAlias("newTaLicenceTierSwitch", "newTaLicenceTierSwitch", JoinType.LEFT_OUTER_JOIN);
		addEq(dc2, "newTaLicenceTierSwitch.id", resultDto.getId());
		newBo = getList(dc2);

		for (TaBusinessOperation aBO : newBo) {
			newBoDto.add(TaBusinessOperationDto.buildFromBO(cache, aBO));
		}
		resultDto.setNewTaBusinessOperations(newBoDto);

		return resultDto;
	}

	public TaLicenceTierSwitch getTierSwitchModelAllEntity(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceTierSwitch.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "id", id);
		return getFirst(dc);
	}

	public TaLicenceTierSwitch getPendingTierSwitch(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceTierSwitch.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", id);
		dc.add(Restrictions.disjunction().add(Restrictions.in("status.code", Codes.PendingTaActionStatuses.TA)).add(Restrictions.eq("application.isDraft", Boolean.TRUE))
				.add(Restrictions.and(Restrictions.eq("pendingSwitch", Boolean.TRUE), Restrictions.eq("status.code", Codes.Statuses.TA_APP_APPROVED))));
		dc.addOrder(Order.desc("updatedDate"));

		return getFirst(dc);
	}

}
