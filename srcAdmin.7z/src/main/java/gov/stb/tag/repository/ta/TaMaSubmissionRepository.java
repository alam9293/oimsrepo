package gov.stb.tag.repository.ta;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.ma.TaMaItemDto;
import gov.stb.tag.dto.ta.ma.TaMaSearchDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaMaSubmission;

@Repository
public class TaMaSubmissionRepository extends TaApplicationRepository {

	public ResultDto<TaMaItemDto> getPendingList(TaMaSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);

		if (searchDto.getFilingTypes() != null && searchDto.getFilingTypes().length > 0) {
			addIn(dc, "type.code", searchDto.getFilingTypes());
		} else {
			addIn(dc, "type.code", ApplicationTypes.TA_MA_FILING_TYPES);
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		dc.add(Restrictions.ne("isDeleted", true));
		filter(searchDto, dc, userId);
		addDtoProjections(dc, TaMaItemDto.class);

		return search(dc, searchDto, true);
	}

	public TaMaSubmission getApplication(Integer applId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaMaSubmission.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", applId));
		return getFirst(dc);
	}
}
