package gov.stb.tag.repository.ta;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.shortfallRectification.TaShortfallRectificationItemDto;
import gov.stb.tag.dto.ta.shortfallRectification.TaShortfallRectificationSearchDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TaNetValueRectification;

@Repository
public class TaNetValueRectificationRepository extends TaApplicationRepository {

	public ResultDto<TaShortfallRectificationItemDto> getPendingList(TaShortfallRectificationSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("appType.code", Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION));

		filter(searchDto, dc, userId);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		addDtoProjections(dc, TaShortfallRectificationItemDto.class);
		return search(dc, searchDto, true);

	}

	public TaNetValueRectification getApplication(Integer applId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueRectification.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", applId));
		return getFirst(dc);
	}

	public TaNetValueRectification getPendingApplication(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueRectification.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		// dc.add(Restrictions.or(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.TA), Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_RFA)));
		dc.add(Restrictions.not(Restrictions.in("lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_TA)));
		return getFirst(dc);

	}

}
