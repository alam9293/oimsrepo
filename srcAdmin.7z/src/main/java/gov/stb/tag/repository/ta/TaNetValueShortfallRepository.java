package gov.stb.tag.repository.ta;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallSearchDto;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TaNetValueShortfallRepository extends BaseRepository {

	@Deprecated
	public void saveNewShortfall(Workflow workflow, TaAaSubmission aaModel, Type shortfallType) {
		TaNetValueShortfall taNetValueShortfalls = new TaNetValueShortfall();
		taNetValueShortfalls.setWorkflow(workflow);
		taNetValueShortfalls.setTaAaSubmission(aaModel);
		taNetValueShortfalls.setAmount(aaModel.getShortfall());
		taNetValueShortfalls.setType(shortfallType);
		save(taNetValueShortfalls);
	}

	@Deprecated
	public void saveNewShortfall(Workflow workflow, TaMaSubmission maModel, Type shortfallType) {
		TaNetValueShortfall taNetValueShortfalls = new TaNetValueShortfall();
		taNetValueShortfalls.setWorkflow(workflow);
		taNetValueShortfalls.setTaMaSubmission(maModel);
		taNetValueShortfalls.setAmount(maModel.getShortfall());
		taNetValueShortfalls.setType(shortfallType);
		save(taNetValueShortfalls);
	}

	public ResultDto<TaNetValueShortfall> getList(TaNetValueShortfallSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueRectification", "taNetValueRectification", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addLike(dc, "travelAgent.name", searchDto.getName());
		addLike(dc, "travelAgent.uen", searchDto.getUen());
		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addEq(dc, "lastAction.status.code", searchDto.getShortfallStatus());
		addIn(dc, "lastAction.status.code", searchDto.getShortfallStatuses());
		addGe(dc, "rectificationDueDate", searchDto.getRectificationDueDateFrom());
		addLe(dc, "rectificationDueDate", searchDto.getRectificationDueDateTo());

		if (Codes.Constants.YES.equalsIgnoreCase(searchDto.getLetterPendingIssuanceStatus())) {
			dc.add(Restrictions.isNull("letterIssuedDate"));
			dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
			dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
		} else if (Codes.Constants.NO.equalsIgnoreCase(searchDto.getLetterPendingIssuanceStatus())) {
			dc.add(Restrictions.isNotNull("letterIssuedDate"));
		}

		if (searchDto.getRectificationStatus() != null) {
			if (searchDto.getRectificationStatus().equalsIgnoreCase(Codes.Constants.NA)) {
				Disjunction disjunction = Restrictions.disjunction();
				disjunction.add(Restrictions.ne("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
				disjunction.add(Restrictions.ne("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
				dc.add(disjunction);
			} else if (searchDto.getRectificationStatus().equalsIgnoreCase(Codes.Constants.YES)) {
				dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
				dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
				dc.createAlias("taNetValueRectification.application", "application", JoinType.LEFT_OUTER_JOIN);
				dc.createAlias("application.lastAction", "rectLastStatus", JoinType.LEFT_OUTER_JOIN);
				addEq(dc, "rectLastStatus.status.code", Statuses.TA_APP_APPROVED);

			} else if (searchDto.getRectificationStatus().equalsIgnoreCase(Codes.Constants.NO)) {
				dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
				dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
				dc.createAlias("taNetValueRectification.application", "application", JoinType.LEFT_OUTER_JOIN);
				dc.createAlias("application.lastAction", "rectLastStatus", JoinType.LEFT_OUTER_JOIN);
				dc.add(Restrictions.disjunction().add(Restrictions.isNull("taNetValueRectification")).add(Restrictions.ne("rectLastStatus.status.code", Statuses.TA_APP_APPROVED)));
			}
		}

		if (searchDto.getApproveDateFrom() != null || searchDto.getApproveDateTo() != null) {
			dc.add(Restrictions.eq("", Statuses.TA_WKFLW_APPROVED));
			dc.createAlias("taNetValueRectification.application", "application", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("application.lastAction", "rectLastStatus", JoinType.LEFT_OUTER_JOIN);
			addGe(dc, "rectLastStatus.createdDate", searchDto.getRectificationDueDateFrom().atStartOfDay());
			addLt(dc, "rectLastStatus.createdDate", searchDto.getRectificationDueDateTo().plusDays(1).atStartOfDay());
		}

		if (searchDto.getShortfallFor() != null) {
			if (searchDto.getShortfallFor().equalsIgnoreCase(ApplicationTypes.TA_APP_AA_SUBMISSION)) {
				dc.add(Restrictions.isNotNull("taAaSubmission"));
			} else if (searchDto.getShortfallFor().equalsIgnoreCase(ApplicationTypes.TA_APP_MA_SUBMISSION)) {
				dc.add(Restrictions.isNotNull("taMaSubmission"));
			}
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.asc("status.ordinal"));
			dc.addOrder(Order.desc("rectificationDueDate"));
		}

		return search(dc, searchDto, true);
	}

	public TaNetValueShortfall getImposedShortfallByLicenceIdAndFiling(Integer id, Integer aaFilingId, Integer maFilingId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		if (aaFilingId != null) {
			dc.createAlias("taAaSubmission", "taAaSubmission", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("taAaSubmission.taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
			dc.add(Restrictions.eq("taAnnualFiling.id", aaFilingId));
		}
		if (maFilingId != null) {
			dc.createAlias("taMaSubmission", "taMaSubmission", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("taMaSubmission.taFilingCondition", "taFilingCondition", JoinType.LEFT_OUTER_JOIN);
			dc.add(Restrictions.eq("taFilingCondition.id", maFilingId));
		}
		// dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
		// dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
		dc.add(Restrictions.eq("licence.id", id));
		return getFirst(dc);

	}

	public List<TaNetValueShortfall> getUnfulfilledShortfall(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueRectification", "taNetValueRectification", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueRectification.application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "appLastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
		dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("taNetValueRectification")).add(Restrictions.ne("appLastAction.status.code", Statuses.TA_APP_APPROVED)));
		dc.addOrder(Order.asc("parentShortfall.id"));
		return getList(dc);
	}

	public List<TaNetValueShortfall> getUnsubmittedShortfall(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		// dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
		// dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
		dc.add(Restrictions.isNull("taNetValueRectification"));
		return getList(dc);
	}

	public List<TaNetValueShortfall> getOtherUnsubmittedShortfall(Integer licenceId, Integer rectificationId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
		dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
		dc.add(Restrictions.isNull("taNetValueRectification"));

		return getList(dc);
	}

	public List<TaAaSubmission> getAaWithShortfall() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("taAnnualFiling", "taAnnualFiling", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNotNull("shortfall"));
		addNe(dc, "shortfall", BigDecimal.valueOf(0));
		addGe(dc, "taAnnualFiling.fy", 2017);
		addEq(dc, "status.code", Statuses.TA_ACTIVE);
		return getList(dc);
	}

	public TaNetValueShortfall getShortfallByAaSubmissionId(Integer aaSubmissionId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("taAaSubmission", "taAaSubmission", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueRectification", "taNetValueRectification", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.ne("lastAction.status.code", Statuses.TA_WKFLW_REJECTED));
		dc.add(Restrictions.eq("taAaSubmission.id", aaSubmissionId));
		return getFirst(dc);
	}

	public TaNetValueShortfall getShortfallByMaSubmissionId(Integer maSubmissionId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("taMaSubmission", "taMaSubmission", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taNetValueRectification", "taNetValueRectification", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.ne("lastAction.status.code", Statuses.TA_WKFLW_REJECTED));
		dc.add(Restrictions.eq("taMaSubmission.id", maSubmissionId));
		dc.addOrder(Order.desc("createdDate"));
		return getFirst(dc);
	}

	public TaNetValueShortfall getShortfallByParentId(Integer shortfallId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("parentShortfall.id", shortfallId));
		return getFirst(dc);
	}

	public TaNetValueShortfall getShortfallByShortfallId(Integer shortfallId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", shortfallId));
		return getFirst(dc);
	}

}
