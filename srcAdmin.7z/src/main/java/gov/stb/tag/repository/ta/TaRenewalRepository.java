package gov.stb.tag.repository.ta;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;
import com.google.common.collect.Maps;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalItemDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalSearchDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.AaFilingForRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.AaSubmissionForRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.AbprFilingForRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaLicenceRenewalExerciseGroupDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaRenewalTaSearchDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TravelAgentForRenewalDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaLicenceRenewal;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaLicenceRenewalExerciseParam;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;

@Repository
public class TaRenewalRepository extends TaApplicationRepository {

	public ResultDto<TaLicenceRenewalItemDto> getPendingList(TaLicenceRenewalSearchDto searchDto, Integer userId, boolean toPaginate) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "type.code", Codes.ApplicationTypes.TA_APP_RENEWAL);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("submissionDate"));
		}
		dc.add(Restrictions.ne("isDeleted", true));
		filter(searchDto, dc, userId);
		addDtoProjections(dc, TaLicenceRenewalItemDto.class);

		return search(dc, searchDto, toPaginate);
	}

	public TaLicenceRenewal getRenewalSubmissionFromAppId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "application.id", id);
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public List<TaLicenceRenewal> getLicencesToRenew(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExerciseTa", "taLicenceRenewalExerciseTa", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExerciseTa.taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isConcluded", false));
		addEq(dc, "lastAction.status.code", Codes.Statuses.TA_APP_APPROVED);
		addEq(dc, "licence.id", id);
		return getList(dc);
	}

	public List<TravelAgentForRenewalDto> getTaDueForRenewal(int year) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		addIn(dc, "status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "expiryDate", LocalDate.of(year, 12, 31));
		dc.addOrder(Order.asc("id"));
		addDtoProjections(dc, TravelAgentForRenewalDto.class);
		return getList(dc);
	}

	public List<Licence> getTaLicencesDueForRenewal(int year) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		addIn(dc, "status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "expiryDate", LocalDate.of(year, 12, 31));
		dc.addOrder(Order.asc("id"));
		return getList(dc);
	}

	public List<TaStakeholder> getKeyExecutivesForTaDueForRenewal(int year) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("role", "r", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "s", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("r.code", Codes.TaStakeholderRoles.STKHLD_KE));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		dc.add(Restrictions.le("appointedDate", LocalDate.now()));
		dc.add(Restrictions.eq("lic.taTgType", Codes.TaTgType.TA));
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<ListableDto> getTaOutstandingPayments() {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.PAYREQ_NOT_PAID));
		dc.add(Restrictions.isNotNull("payerUinUen"));

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("payerUinUen"));
		projections.add(Projections.sum("payableAmount"), "data");
		projections.add(Projections.property("payerUinUen"), "key");

		dc.setProjection(projections);
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));
		return getList(dc);
	}

	public List<AaFilingForRenewalDto> getTaAaAnnualFilingByFyeDate(int year) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAaSubmission", "aa", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAaSubmission.application", "app", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAaSubmission.application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.status", "licStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAaSubmission.application.lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "fyEndDate", renewalExercise.getFyeCutOffDate());
		addGe(dc, "fyEndDate", LocalDate.of(year - 5, 12, 31));
		addEq(dc, "applicationType.code", Codes.ApplicationTypes.TA_APP_AA_SUBMISSION);
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		dc.add(Restrictions.disjunction().add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_APPROVED)).add(Restrictions.isNull("aa.id")));

		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("fyEndDate"));
		addDtoProjections(dc, AaFilingForRenewalDto.class);
		return getList(dc);
	}

	public List<TaFilingCondition> getTaAaFilingByFyeDate(int year) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAaSubmission", "aa", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "fyEndDate", renewalExercise.getFyeCutOffDate());
		addGe(dc, "fyEndDate", LocalDate.of(year - 4, 12, 31));
		addEq(dc, "applicationType.code", Codes.ApplicationTypes.TA_APP_AA_SUBMISSION);
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		addNotIn(dc, "status.code", Statuses.TA_FILING_VOID);
		// dc.add(Restrictions.disjunction().add(Restrictions.not(Restrictions.eq("status.code", Statuses.TA_FILING_VOID))));

		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("fyEndDate"));
		return getList(dc);
	}

	public List<AbprFilingForRenewalDto> getTaAbprAnnualFilingByFyeDate(int year) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAbprSubmission", "abpr", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAbprSubmission.application", "app", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAbprSubmission.application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.status", "licStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAbprSubmission.application.lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "fyEndDate", renewalExercise.getFyeCutOffDate());
		addGe(dc, "fyEndDate", LocalDate.of(year - 5, 12, 31));
		addEq(dc, "applicationType.code", Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION);
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		addNotIn(dc, "status.code", Statuses.TA_FILING_VOID);
		// dc.add(Restrictions.disjunction().add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_APPROVED)).add(Restrictions.isNull("abpr.id")));

		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("fyEndDate"));
		addDtoProjections(dc, AbprFilingForRenewalDto.class);
		return getList(dc);
	}

	public List<TaFilingCondition> getTaAbprFilingByFyeDate(Integer year) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "fyEndDate", renewalExercise.getFyeCutOffDate());
		addGe(dc, "fyEndDate", LocalDate.of(year - 4, 12, 31));
		addEq(dc, "applicationType.code", Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION);
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		addNotIn(dc, "status.code", Statuses.TA_FILING_VOID);
		// dc.add(Restrictions.disjunction().add(Restrictions.not(Restrictions.eq("status.code", Statuses.TA_FILING_VOID))));
		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("fyEndDate"));
		return getList(dc);
	}

	public List<TaFilingCondition> getTaAdhocMaFilingByFyeDate(Integer year, LocalDate renewalStartDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "fyEndDate", renewalExercise.getFyeCutOffDate());
		addEq(dc, "applicationType.code", Codes.ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION);
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addGe(dc, "createdDate", (renewalStartDate.minusMonths(6)).atStartOfDay());

		addNotIn(dc, "status.code", Statuses.TA_FILING_VOID);
		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("fyEndDate"));
		return getList(dc);
	}

	public List<TaFilingCondition> getTaMaFilingByFyeDate(Integer year, LocalDate renewalStartDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaFilingCondition.class);
		dc.createAlias("licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "fyEndDate", renewalExercise.getFyeCutOffDate());
		addEq(dc, "applicationType.code", Codes.ApplicationTypes.TA_APP_MA_SUBMISSION);
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addGe(dc, "createdDate", (renewalStartDate.minusMonths(6)).atStartOfDay());

		addNotIn(dc, "status.code", Statuses.TA_FILING_VOID);
		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("fyEndDate"));
		return getList(dc);
	}

	public List<AaSubmissionForRenewalDto> getTaAaSubmissionByFyeDate(int year) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("taAnnualFiling", "af", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("application", "app", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence.status", "licStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "af.fyEndDate", renewalExercise.getFyeCutOffDate().minusYears(5));
		addGe(dc, "af.fyEndDate", LocalDate.of(year - 5, 12, 31));
		addEq(dc, "af.applicationType.code", Codes.ApplicationTypes.TA_APP_AA_SUBMISSION);
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TA_APP_APPROVED));

		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("af.fyEndDate"));
		addDtoProjections(dc, AaSubmissionForRenewalDto.class);
		return getList(dc);
	}

	public List<TaAaSubmission> getTaAaSubmissionModelByFyeDate(Integer year, String status) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAaSubmission.class);
		dc.createAlias("taAnnualFiling", "af", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("application", "app", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence.status", "licStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "af.fyEndDate", renewalExercise.getFyeCutOffDate().minusYears(5));
		addGe(dc, "af.fyEndDate", LocalDate.of(year - 4, 12, 31));
		addEq(dc, "af.applicationType.code", Codes.ApplicationTypes.TA_APP_AA_SUBMISSION);
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);

		if (status != null) {
			dc.add(Restrictions.eq("lastAction.status.code", status));
		}

		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("af.fyEndDate"));
		return getList(dc);
	}

	public List<TaAbprSubmission> getTaAbprSubmissionModelByFyeDate(Integer year, Integer status) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaAbprSubmission.class);
		dc.createAlias("taAnnualFiling", "af", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("application", "app", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taAnnualFiling.licence.status", "licStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "af.fyEndDate", renewalExercise.getFyeCutOffDate().minusYears(5));
		addGe(dc, "af.fyEndDate", LocalDate.of(year - 5, 12, 31));
		addEq(dc, "af.applicationType.code", Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION);
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);

		if (status != null) {
			dc.add(Restrictions.eq("lastAction.status.code", status));
		}

		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("af.fyEndDate"));
		return getList(dc);
	}

	public List<TaMaSubmission> getTaMaSubmissionModelByFyeDate(Integer year, Integer status) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaMaSubmission.class);
		dc.createAlias("taFilingCondition", "af", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFilingCondition.licence", "lic", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFilingCondition.applicationType", "appType", JoinType.LEFT_OUTER_JOIN);

		dc.createAlias("application", "app", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taFilingCondition.licence.status", "licStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction.status", "appStatus", JoinType.LEFT_OUTER_JOIN);

		// addGe(dc, "af.fyEndDate", renewalExercise.getFyeCutOffDate().minusYears(5));
		addIn(dc, "af.applicationType.code", Arrays.asList(Codes.ApplicationTypes.TA_APP_MA_SUBMISSION, Codes.ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION));
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);

		if (status != null) {
			dc.add(Restrictions.eq("lastAction.status.code", status));
		}

		dc.addOrder(Order.asc("lic.licenceNo"));
		dc.addOrder(Order.desc("af.fyEndDate"));
		return getList(dc);
	}

	public List<TaNetValueShortfall> getApprovedTaShortfallModelByFyeDate(int year, String appType) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.licence", "lic", JoinType.LEFT_OUTER_JOIN);

		if (appType.equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION)) {
			dc.createAlias("taAaSubmission", "taAaSubmission", JoinType.LEFT_OUTER_JOIN);
			dc.add(Restrictions.isNotNull("taAaSubmission.id"));
		}

		if (appType.equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_MA_SUBMISSION) || appType.equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION)) {
			dc.createAlias("taMaSubmission", "taMaSubmission", JoinType.LEFT_OUTER_JOIN);
			dc.add(Restrictions.isNotNull("taMaSubmission.id"));
		}

		// addGe(dc, "af.fyEndDate", renewalExercise.getFyeCutOffDate().minusYears(5));
		addIn(dc, "lic.status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "lic.expiryDate", LocalDate.of(year, 12, 31));
		addEq(dc, "lic.taTgType", Codes.TaTgType.TA);
		addGe(dc, "rectificationDueDate", LocalDate.of(year - 5, 12, 31));
		dc.add(Restrictions.eq("lastAction.status.code", Statuses.TA_WKFLW_APPROVED));
		dc.add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE));
		dc.addOrder(Order.asc("lic.licenceNo"));
		return getList(dc);
	}

	public TaLicenceRenewal updateRenewalDetails(TaLicenceRenewalDto dto, TaLicenceRenewal renewalModel, CacheHelper cache, Application appModel) {
		if (renewalModel == null) {
			renewalModel = new TaLicenceRenewal();
		}
		renewalModel.setApplication(appModel);
		renewalModel.setLateRemarks(dto.getLateRemarks());
		TaLicenceRenewalExerciseTa a = get(TaLicenceRenewalExerciseTa.class, dto.getTaLicenceRenewalExerciseTaId());
		renewalModel.setTaLicenceRenewalExerciseTa(a);
		saveOrUpdate(renewalModel);

		a.setTaLicenceRenewal(renewalModel);
		saveOrUpdate(a);

		List<TaKeDeclaration> declarations = new ArrayList<>();
		for (TaKeDeclarationsDto declarationDto : dto.getTaKeDeclarationsForRenewal()) {
			TaKeDeclaration declaration = new TaKeDeclaration();
			if (declarationDto.getId() == null) {
				declaration = new TaKeDeclaration();
				declaration.setOptionSelected(declarationDto.getSelectedOption());
				if (declarationDto.getSelectedOption().equalsIgnoreCase(declarationDto.getOptionsToPrompt())) {
					declaration.setRemarks(declarationDto.getRemarks());
				} else {
					declaration.setRemarks(null);
				}
				declaration.setTaKeClause(cache.getTaKeClause(Integer.parseInt(declarationDto.getClause().getKey().toString())));
				declaration.setTaKeyExecutive(get(TaStakeholder.class, dto.getTaKeStakeholder().getTaStakeholderId()));
				declaration.setTaLicenceRenewal(renewalModel);
				declarations.add(declaration);
			} else {
				declaration = get(TaKeDeclaration.class, declarationDto.getId());
				declaration.setOptionSelected(declarationDto.getSelectedOption());
				if (declarationDto.getSelectedOption().equalsIgnoreCase(declarationDto.getOptionsToPrompt())) {
					declaration.setRemarks(declarationDto.getRemarks());
				} else {
					declaration.setRemarks(null);
				}
			}
			saveOrUpdate(declaration);
		}

		return renewalModel;
	}

	public List<TaLicenceRenewalExercise> getRenewalYears() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExercise.class);
		dc.addOrder(Order.desc("year"));
		dc.addOrder(Order.desc("id"));
		return getList(dc);
	}

	public TaLicenceRenewalExercise updateRenewalExercise(TaLicenceRenewalExercise renewalExerciseModel, TaLicenceRenewalExerciseGroupDto renewalExerciseDto, Integer newYearToCreate,
			CacheHelper cacheHelper, WorkflowHelper workflowHelper) {
		if (renewalExerciseDto == null && newYearToCreate != null) {
			Map<String, List<String>> renewalCycleDates = getRenewalCycleDates(cacheHelper);
			renewalExerciseModel.setStartDate(LocalDate.of(newYearToCreate, Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_START).get(1)),
					Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_START).get(0))));
			renewalExerciseModel.setEndDate(LocalDate.of(newYearToCreate, Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_END).get(1)),
					Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_END).get(0))));
			renewalExerciseModel.setFyeCutOffDate(LocalDate.of(newYearToCreate, Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_FYE_CUT).get(1)),
					Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_FYE_CUT).get(0))));
			renewalExerciseModel
					.setDefaultRequestedMaAsAtDate(LocalDate.of(newYearToCreate, Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_RECOMMENDED_MA).get(1)),
							Integer.parseInt(renewalCycleDates.get(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_RECOMMENDED_MA).get(0))));
			renewalExerciseModel.setYearRetrieveFromStartDate();
		} else {
			renewalExerciseModel.setStartDate(renewalExerciseDto.getRenewalStartDate());
			renewalExerciseModel.setEndDate(renewalExerciseDto.getRenewalEndDate());
			renewalExerciseModel.setFyeCutOffDate(renewalExerciseDto.getFyeCutOffDate());
			renewalExerciseModel.setDefaultRequestedMaAsAtDate(renewalExerciseDto.getRequestedMaAsAtDate());
			// renewalExerciseModel.setYearRetrieveFromStartDate(); //#STBTAGPROD-687 User do not want renewal year to follow renewal start date coz they say 1 year only have 1 renewal
		}
		// if (renewalExerciseModel.getWorkflow() == null) {
		// renewalExerciseModel.setWorkflow(workflowHelper.saveNewWorkflow(Codes.Workflow.TA_WKFLW_RENEW_EX, null, null, null, Boolean.FALSE, null));
		// }

		return renewalExerciseModel;
	}

	public Map<String, List<String>> getRenewalCycleDates(CacheHelper cacheHelper) {
		Map<String, List<String>> renewalCycleDates = Maps.newHashMap();
		String startCycleText = cacheHelper.getSystemParameter(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_START).getValue();
		String endCycleText = cacheHelper.getSystemParameter(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_END).getValue();
		String fyeCutOffText = cacheHelper.getSystemParameter(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_FYE_CUT).getValue();
		String recommendedMAText = cacheHelper.getSystemParameter(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_RECOMMENDED_MA).getValue();

		List<String> startCycleStrList = Arrays.asList(startCycleText.split(","));
		List<String> endCycleStrList = Arrays.asList(endCycleText.split(","));
		List<String> fyeCutOffStrList = Arrays.asList(fyeCutOffText.split(","));
		List<String> recommendedMAStrList = Arrays.asList(recommendedMAText.split(","));

		renewalCycleDates.put(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_START, startCycleStrList);
		renewalCycleDates.put(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_END, endCycleStrList);
		renewalCycleDates.put(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_FYE_CUT, fyeCutOffStrList);
		renewalCycleDates.put(Codes.SystemParameters.TA_DEFAULT_LICENCE_RENEWAL_RECOMMENDED_MA, recommendedMAStrList);
		return renewalCycleDates;
	}

	public TaLicenceRenewalExerciseTa getTaLicenceRenewalExerciseTa(Integer renewalExerciseModelId, Integer licenceId, Boolean approved) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "taLicenceRenewalExercise.id", renewalExerciseModelId);
		if (approved) {
			addIn(dc, "status.code", Statuses.TA_WKFLW_APPROVED);
		}
		addIn(dc, "licence.id", licenceId);
		// dc.addOrder(Order.desc("name"));
		return getFirst(dc);
	}

	// get all previous renewalCount
	public List<TaLicenceRenewalExerciseTa> getTaLicenceRenewalExerciseTaByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		addIn(dc, "licence.id", licenceId);
		dc.addOrder(Order.asc("id"));
		return getList(dc);
	}

	public ResultDto<TaLicenceRenewalExerciseTa> getTaLicenceRenewalExerciseTa(TaRenewalTaSearchDto searchDto, boolean toPaginate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "taLicenceRenewalExercise.id", searchDto.getRenewalExerciseId());
		if (searchDto.getRenewalTypeCode() != null) {
			addIn(dc, "type.code", searchDto.getRenewalTypeCode());
		}
		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addLike(dc, "travelAgent.uen", searchDto.getUen());
		addLike(dc, "travelAgent.name", searchDto.getName());
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.asc("travelAgent.name"));
		}
		return search(dc, searchDto, toPaginate);
	}

	public Long getTaDueForRenewalCount(int year) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		addIn(dc, "status.code", Codes.TaStatuses.RENEWAL_ACTIVE);
		addEq(dc, "expiryDate", LocalDate.of(year, 12, 31));
		dc.setProjection(Projections.rowCount());
		return (Long) getProjectedFirstValue(dc);
	}

	public Long getTaLicenceRenewalTypeCount(String renewalTypeCode, Integer renewalExerciseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "type.code", renewalTypeCode);
		addIn(dc, "taLicenceRenewalExercise.id", renewalExerciseId);
		dc.setProjection(Projections.rowCount());
		return (Long) getProjectedFirstValue(dc);
	}

	public Long getTaLicenceRenewalStatusCount(String renewalStatusCode, Integer renewalExerciseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "status.code", renewalStatusCode);
		addIn(dc, "taLicenceRenewalExercise.id", renewalExerciseId);
		dc.setProjection(Projections.rowCount());
		return (Long) getProjectedFirstValue(dc);
	}

	public List<ListableDto> getTaLicenceRenewalStatusesCount(Integer renewalExerciseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.status", "status", JoinType.LEFT_OUTER_JOIN);
		// addIn(dc, "status.code", renewalStatusCode);
		addIn(dc, "taLicenceRenewalExercise.id", renewalExerciseId);
		dc.setProjection(Projections.rowCount());

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("status.code"));
		projections.add(Projections.property("status.code"), "key");
		projections.add(Projections.property("status.label"), "label");
		projections.add(Projections.rowCount(), "data");

		dc.setProjection(projections);
		dc.addOrder(Order.asc("status.ordinal"));
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));

		return getList(dc);
	}

	public Long getTaRenewalCount(Boolean hasRenewed, Integer renewalExerciseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewal", "taLicenceRenewal", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewal.application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewal.application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewal.application.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "taLicenceRenewalExercise.id", renewalExerciseId);
		if (hasRenewed) {
			dc.add(Restrictions.isNotNull("taLicenceRenewal.id"));
			addIn(dc, "status.code", Statuses.TA_APP_APPROVED);
		} else {
			dc.add(Restrictions.disjunction().add(Restrictions.isNull("taLicenceRenewal.id")).add(Restrictions.ne("status.code", Statuses.TA_APP_APPROVED)));
		}
		dc.setProjection(Projections.rowCount());
		return (Long) getProjectedFirstValue(dc);
	}

	public TaLicenceRenewalExercise getApprovedRenewalExerciseFromYear(Integer year) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExercise.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "year", year);
		// TODO: Uncomment below after testing
		addIn(dc, "status.code", Statuses.TA_WKFLW_APPROVED);
		dc.addOrder(Order.desc("year"));
		return getFirst(dc);
	}

	public TaLicenceRenewalExercise getRenewalExerciseFromYear(Integer year) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExercise.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addNotIn(dc, "status.code", Statuses.TA_WKFLW_REJECTED);
		addIn(dc, "year", year);
		return getFirst(dc);
	}

	public TaLicenceRenewalExerciseTa getTaLicenceRenewalExerciseTaForYear(Integer licenceId, LocalDate date) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "licence.id", licenceId);
		addIn(dc, "taLicenceRenewalExercise.year", date.getYear());
		addLe(dc, "taLicenceRenewalExercise.startDate", date);
		addLe(dc, "taLicenceRenewalExercise.endDate", LocalDate.of(date.getYear(), 12, 31));
		addIn(dc, "status.code", Statuses.TA_WKFLW_APPROVED);
		// dc.addOrder(Order.desc("name"));
		return getFirst(dc);
	}

	public TaLicenceRenewalExerciseParam getExerciseParam(Integer renewalExerciseId, Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseParam.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "taLicenceRenewalExercise.id", renewalExerciseId);
		addEq(dc, "licence.id", licenceId);
		return getFirst(dc);
	}

	public List<TaLicenceRenewalExerciseTa> getTaLicenceRenewalExerciseTas(Integer renewalExerciseModelId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "taLicenceRenewalExercise.id", renewalExerciseModelId);
		// dc.addOrder(Order.desc("name"));
		return getList(dc);
	}

	public List<TaLicenceRenewalExerciseTa> getTaPastRenewalCycle(Integer licenceId, Integer limit, Integer yearBase) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise", "taLicenceRenewalExercise", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taLicenceRenewalExercise.workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addLt(dc, "taLicenceRenewalExercise.year", yearBase);
		addIn(dc, "licence.id", licenceId);
		addIn(dc, "status.code", Statuses.TA_WKFLW_APPROVED);
		dc.addOrder(Order.desc("taLicenceRenewalExercise.year"));

		if (limit != null) {
			return getListLimit(dc, limit);
		}
		return getList(dc);
	}

	public List<TaLicenceRenewalExercise> getRenewalExerciseNotRejectedByYear(Integer year) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExercise.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "year", year);
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("status.code")).add(Restrictions.ne("status.code", Statuses.TA_WKFLW_REJECTED)));
		return getList(dc);

	}

	public TaLicenceRenewalExerciseTa getRenewalTaFromFiling(TaFilingCondition filing) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceRenewalExerciseTa.class);

		if (filing.getApplicationType().getCode().equalsIgnoreCase(ApplicationTypes.TA_APP_MA_SUBMISSION)
				|| filing.getApplicationType().getCode().equalsIgnoreCase(ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION)) {
			dc.createAlias("maFilingCondition", "maFilingCondition", JoinType.LEFT_OUTER_JOIN);
			addIn(dc, "maFilingCondition.id", filing.getId());
		}
		return getFirst(dc);
	}

}
