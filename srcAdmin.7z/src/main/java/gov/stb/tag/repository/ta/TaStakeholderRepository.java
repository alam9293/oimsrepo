package gov.stb.tag.repository.ta;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.stakeholder.PersonnelDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderItemDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderSearchDto;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaStakeholder;

@Repository
public class TaStakeholderRepository extends TaApplicationRepository {

	public ResultDto<TaStakeholderItemDto> getPersonnels(TaStakeholderSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Stakeholder.class);
		dc.addOrder(Order.asc("name"));

		addLike(dc, "name", searchDto.getName());
		addLike(dc, "uin", searchDto.getUin());
		addLike(dc, "companyUen", searchDto.getUen());
		addLe(dc, "dob", searchDto.getDobTo());
		addGe(dc, "dob", searchDto.getDobFrom());
		addLe(dc, "companyIncorporatedDate", searchDto.getCompanyIncorporatedDateTo());
		addGe(dc, "companyIncorporatedDate", searchDto.getCompanyIncorporatedDateFrom());

		addDtoProjections(dc, TaStakeholderItemDto.class);
		return search(dc, searchDto, true);

	}

	public Stakeholder getPersonnel(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(Stakeholder.class);
		dc.add(Restrictions.eq("id", id));
		dc.createAlias("taStakeholders", "taStakeholders", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		return getFirst(dc);

	}

	public List<PersonnelDto> getPersonnelByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		dc.add(Restrictions.ne("role.code", Codes.TaStakeholderRoles.STKHLD_KE));
		addDtoProjections(dc, PersonnelDto.class);
		return getList(dc);
	}

	public List<TaStakeholder> getFullPersonnelByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.ne("role.code", Codes.TaStakeholderRoles.STKHLD_KE));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		return getList(dc);
	}

	public TaStakeholder getPersonnelParticulars(Integer taStakeholderId, Boolean loadLicence) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.add(Restrictions.eq("id", taStakeholderId));
		dc.createAlias("role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		if (loadLicence) {
			dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
			dc.createAlias("licence.travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		}

		return getFirst(dc);
	}
}
