package gov.stb.tag.repository.ta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.TravelAgentBasicDto;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.repository.TaCommonRepository;

@Repository
public class TravelAgentRepository extends TaCommonRepository {

	public List<TravelAgentBasicDto> getActiveTravelAgentsBasic() {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TA));
		addIn(dc, "status.code", Codes.TaStatuses.GENERALLY_ACTIVE);
		addDtoProjections(dc, TravelAgentBasicDto.class);
		return getList(dc);
	}

	public List<TaStakeholder> getKeyExecutives() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("role", "r", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "s", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("r.code", Codes.TaStakeholderRoles.STKHLD_KE));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		dc.add(Restrictions.le("appointedDate", LocalDate.now()));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<TaBranch> getBranchesByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<TaBranch> getBranchesByLicenceId(Integer licenceId, String branchStatusNot) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		if (branchStatusNot != null) {
			dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
			addNotIn(dc, "status.code", branchStatusNot);
		}
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<TaBranch> getBranchesByLicenceIdStatus(Integer licenceId, String branchStatus) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		if (branchStatus != null) {
			dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
			addIn(dc, "status.code", branchStatus);
		}
		addIsNull(dc, "ceasedDate");
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<TaBranch> getActiveBranchesByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("address", "address", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "status.code", Codes.Statuses.TA_BRANCH_ACTIVE);
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<TravelAgent> getTravelAgents() {
		DetachedCriteria dc = DetachedCriteria.forClass(TravelAgent.class);
		return getList(dc);
	}

	public TravelAgent getTaByUen(String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(TravelAgent.class);
		dc.add(Restrictions.eq("uen", uen));
		return getFirst(dc);
	}

	public Boolean isActiveTa(String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "licenceStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("travelAgent.uen", uen));
		dc.add(Restrictions.eq("licenceStatus.code", Codes.Statuses.TA_ACTIVE));
		Licence licence = getFirst(dc);
		if (licence == null) {
			return false;
		} else {
			return true;
		}
	}

	public Stakeholder getSameStakeholder(String uin) {
		DetachedCriteria dc = DetachedCriteria.forClass(Stakeholder.class);
		dc.add(Restrictions.or(Restrictions.eq("uin", uin), Restrictions.eq("companyUen", uin)));
		return getFirst(dc);
	}

	public boolean compareUserUinAndKeUin(String userUin, String currentKeUin) {
		// Check if current logged in user is KE
		if (!Strings.isNullOrEmpty(userUin)) {
			if (userUin.equalsIgnoreCase(currentKeUin)) {
				return (Boolean.TRUE);
				// resultDto.setIsMyInfoPopulated(Boolean.TRUE);
			} else {
				return (Boolean.FALSE);
				// resultDto.setIsMyInfoPopulated(Boolean.FALSE);
			}
		}
		return (Boolean.FALSE);
	}

	public Long getBranchCount(Integer id, String status) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.in("status.code", status));
		dc.add(Restrictions.eq("licence.id", id));
		dc.setProjection(Projections.rowCount());
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount;
	}

	public BigDecimal getTaOutstandingPaymentAmount(String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.PAYREQ_NOT_PAID));
		dc.add(Restrictions.eq("payerUinUen", uen));
		addEq(dc, "isPrePayment", false);
		dc.setProjection(Projections.sum("payableAmount"));

		return getFirst(dc);
	}

	public TravelAgent getTravelAgentByLicenceId(Integer licenceId) {
		var dc = DetachedCriteria.forClass(TravelAgent.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("operatingAddress", "operatingAddress", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("displayAddress", "displayAddress", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		return getFirst(dc);
	}

}
