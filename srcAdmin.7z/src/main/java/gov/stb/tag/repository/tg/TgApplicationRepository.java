package gov.stb.tag.repository.tg;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.tg.application.TgApplicationSearchDto;
import gov.stb.tag.dto.tg.application.TgApplicationSearchItemDto;
import gov.stb.tag.dto.tg.application.TgCourseApplicationSearchItemDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TgCourseCreation;
import gov.stb.tag.model.TgLicenceCreation;
import gov.stb.tag.model.TgStipend;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgApplicationRepository extends BaseRepository {

	public Application getSingleApplication(String appNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.add(Restrictions.eq("applicationNo", appNo));
		dc.add(Restrictions.ne("isDeleted", true));
		return getFirst(dc);
	}

	public Application getSingleApplicationById(Integer appId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.add(Restrictions.eq("id", appId));
		dc.add(Restrictions.ne("isDeleted", true));
		return getFirst(dc);
	}

	public Integer getAllRfaAppByTgId(Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowActions", "workflowActions", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("workflowActions.status.code", Codes.Statuses.TG_APP_RFA));
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));
		dc.add(Restrictions.eq("touristGuide.id", tgId));
		return getList(dc).size();
	}

	public Integer getAllPendingCollectionByTgId(Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowActions", "workflowActions", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licencePrintStatus.code", Codes.Statuses.PRINT_PENDING_COLLECTION));
		dc.add(Restrictions.eq("workflowActions.status.code", Codes.Statuses.TG_APP_APPROVED));
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));
		dc.add(Restrictions.eq("touristGuide.id", tgId));
		return getList(dc).size();
	}

	public ResultDto<TgApplicationSearchItemDto> getTgApplicationsList(TgApplicationSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.RIGHT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.eq("application.taTgType", Codes.TaTgType.TG));

		addIn(dc, "type.code", Codes.ApplicationTypes.TG_APP_CREATION, Codes.ApplicationTypes.TG_APP_RENEWAL, Codes.ApplicationTypes.TG_APP_PERSON_UPDATE, Codes.ApplicationTypes.TG_APP_CANCELLATION,
				Codes.ApplicationTypes.TG_APP_REPLACEMENT, Codes.ApplicationTypes.TG_APP_REINSTATEMENT, Codes.ApplicationTypes.TG_APP_STIPEND);

		filterApplicationAll(searchDto, dc);

		addDtoProjections(dc, TgApplicationSearchItemDto.class);
		return search(dc, searchDto, true);
	}

	public ResultDto<TgCourseApplicationSearchItemDto> getTgCourseApplicationsList(TgApplicationSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseCreation.class);
		dc.createAlias("tgTrainingProvider", "tgCourseCreationTp", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application", "application", JoinType.RIGHT_OUTER_JOIN);
		dc.createAlias("application.tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.tgCourse.tgTrainingProvider", "tgCourseTp", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.eq("application.taTgType", Codes.TaTgType.TG));

		addIn(dc, "type.code", Codes.ApplicationTypes.TG_APP_COURSE_RENEWAL, Codes.ApplicationTypes.TG_APP_COURSE_CREATION);

		filterCourseApplicationAll(searchDto, dc);

		addDtoProjections(dc, TgCourseApplicationSearchItemDto.class);
		return search(dc, searchDto, true);
	}

	public DetachedCriteria filterApplicationAll(TgApplicationSearchDto searchDto, DetachedCriteria dc) {
		if (!Strings.isNullOrEmpty(searchDto.getName())) {
			Disjunction name = Restrictions.disjunction();
			Criterion nameTG = Restrictions.ilike("touristGuide.name", searchDto.getName(), MatchMode.ANYWHERE);
			Criterion nameCreation = Restrictions.ilike("name", searchDto.getName(), MatchMode.ANYWHERE);
			name.add(nameTG);
			name.add(nameCreation);
			dc.add(name);
		}

		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addLike(dc, "licence.tier.code", searchDto.getLicenceType());
		addEq(dc, "type.code", searchDto.getApplicationType());

		commonFilter(searchDto, dc);
		return dc;
	}

	public DetachedCriteria filterCourseApplicationAll(TgApplicationSearchDto searchDto, DetachedCriteria dc) {
		if (!Strings.isNullOrEmpty(searchDto.getName())) {
			Disjunction name = Restrictions.disjunction();
			Criterion courseName = Restrictions.ilike("tgCourse.name", searchDto.getName(), MatchMode.ANYWHERE);
			Criterion nameCreation = Restrictions.ilike("name", searchDto.getName(), MatchMode.ANYWHERE);
			name.add(courseName);
			name.add(nameCreation);
			dc.add(name);
		}
		if (!Strings.isNullOrEmpty(searchDto.getTgTrainingProviderName())) {
			Disjunction tp = Restrictions.disjunction();
			Criterion tpName = Restrictions.ilike("tgCourseTp.name", searchDto.getTgTrainingProviderName(), MatchMode.ANYWHERE);
			Criterion tpNameCreation = Restrictions.ilike("tgCourseCreationTp.name", searchDto.getTgTrainingProviderName(), MatchMode.ANYWHERE);
			tp.add(tpName);
			tp.add(tpNameCreation);
			dc.add(tp);
		}

		addEq(dc, "type.code", searchDto.getApplicationType());

		commonFilter(searchDto, dc);
		return dc;
	}

	public DetachedCriteria filter(TgApplicationSearchDto searchDto, DetachedCriteria dc, boolean isLicenceCreation) {

		if (isLicenceCreation) {
			addLike(dc, "name", searchDto.getName());
			addLike(dc, "uin", searchDto.getNricFin());
		} else {
			addLike(dc, "touristGuide.name", searchDto.getName());
			addLike(dc, "touristGuide.uin", searchDto.getNricFin());
			addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		}

		addNotIn(dc, "lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TG);
		addLike(dc, "assignee.name", searchDto.getAssignedOfficer());

		commonFilter(searchDto, dc);
		return dc;
	}

	public DetachedCriteria filterCourse(TgApplicationSearchDto searchDto, DetachedCriteria dc, boolean isCourseCreation) {

		if (isCourseCreation) {
			addLike(dc, "name", searchDto.getName());
			addLike(dc, "tgTrainingProvider.name", searchDto.getTgTrainingProviderName());
		} else {
			addLike(dc, "tgCourse.name", searchDto.getName());
			addLike(dc, "tgCourse.tgTrainingProvider.name", searchDto.getTgTrainingProviderName());
		}

		addNotIn(dc, "lastAction.status.code", Codes.PendingApprovalStatuses.NOT_PENDING_STB_TG);
		addLike(dc, "assignee.name", searchDto.getAssignedOfficer());

		commonFilter(searchDto, dc);
		return dc;
	}

	public DetachedCriteria commonFilter(TgApplicationSearchDto searchDto, DetachedCriteria dc) {
		addEq(dc, "application.taTgType", Codes.TaTgType.TG);
		addIn(dc, "lastAction.status.code", searchDto.getStatuses());
		addLike(dc, "application.applicationNo", searchDto.getApplicationNo());
		if (searchDto.getSubmissionDateTo() != null) {
			addLt(dc, "application.submissionDate", searchDto.getSubmissionDateTo().plusDays(1));
		}

		if (!Strings.isNullOrEmpty(searchDto.getApplicationType()) && searchDto.getApplicationType().equals(Codes.ApplicationTypes.TG_APP_STIPEND)) {
			if (Boolean.TRUE.equals(searchDto.isPendingFollowUp())) {
				addEq(dc, "lastAction.type.code", Codes.WorkflowActionTypes.FOLLOW_UP);
			} else if (Boolean.FALSE.equals(searchDto.isPendingFollowUp())) {
				addNe(dc, "lastAction.type.code", Codes.WorkflowActionTypes.FOLLOW_UP);
			}

			if (searchDto.getHasFollowUpRequiredByFinance() != null) {
				var subCriteria = DetachedCriteria.forClass(TgStipend.class);
				subCriteria.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
				subCriteria.add(Restrictions.eq("hasFollowUpRequiredByFinance", searchDto.getHasFollowUpRequiredByFinance()));
				subCriteria.setProjection(Projections.property("application.id"));
				subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

				dc.add(Subqueries.propertyIn("application.id", subCriteria));
			}
		}

		addGe(dc, "application.submissionDate", searchDto.getSubmissionDateFrom());
		addNe(dc, "application.isDeleted", true);

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("application.submissionDate"));
		}
		return dc;
	}

	public ResultDto<WorkflowAction> getWorkflowActionsList(Integer applicationId, WorkflowActionSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowAction.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("files", "files", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("application.id", applicationId));
		dc.addOrder(Order.desc("createdDate"));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return search(dc, searchDto, true);
	}

	public DetachedCriteria inProcessAppFilter(DetachedCriteria dc) {
		dc.add(Restrictions.or(Restrictions.eq("application.isDraft", true))
				.add(Restrictions.and(Restrictions.ne("currentStatus.code", Codes.Statuses.TG_APP_APPROVED), Restrictions.ne("currentStatus.code", Codes.Statuses.TG_APP_REJECTED))));
		addNe(dc, "application.isDeleted", true);
		return dc;
	}
}
