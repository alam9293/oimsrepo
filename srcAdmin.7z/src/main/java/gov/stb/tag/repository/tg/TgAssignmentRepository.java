package gov.stb.tag.repository.tg;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentItemDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentSearchDto;
import gov.stb.tag.model.TgAssignment;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgAssignmentRepository extends BaseRepository {

	public ResultDto<TgAssignmentItemDto> getAssignments(TgAssignmentSearchDto searchDto, Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgAssignment.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("employmentSource", "employmentSource", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgAssignmentDates", "tgAssignmentDates", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("touristGuide.id", tgId));
		// filter for deleted assignment
		dc.add(Restrictions.eq("isDeleted", searchDto.isDeleted()));
		// filter by current cycle where assignment date must be more than licence start date
		if (searchDto.isCurrentCycle()) {
			dc.add(Restrictions.leProperty("licence.startDate", "startDate"));
		}
		if (searchDto.getYear() != null) {
			addGe(dc, "startDate", LocalDate.of(searchDto.getYear(), 1, 1));
			addLe(dc, "startDate", LocalDate.of(searchDto.getYear(), 12, 31));
		} else {
			addGe(dc, "startDate", searchDto.getStartDate());
			addLe(dc, "startDate", searchDto.getEndDate());
		}

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("id"));
		projections.add(Projections.sum("tgAssignmentDates.noOfHours"), "totalHours");
		projections.add(Projections.property("id"), "assignmentId");
		projections.add(Projections.property("startDate"), "startDate");
		projections.add(Projections.property("endDate"), "endDate");
		projections.add(Projections.property("type.label"), "assignmentType");
		projections.add(Projections.property("tourTypeOther"), "assignmentTypeOther");
		projections.add(Projections.property("employmentSource.label"), "employmentSource");
		projections.add(Projections.property("employmentSourceTypeOther"), "employmentSourceOther");
		projections.add(Projections.property("companyName"), "companyName");
		projections.add(Projections.property("feeReceived"), "feeReceived");
		projections.add(Projections.property("createdDate"), "submissionDate");

		dc.setProjection(projections);
		dc.setResultTransformer(Transformers.aliasToBean(TgAssignmentItemDto.class));

		return search(dc, searchDto, true, projections);
	}

	public List<TgAssignment> getAllCurrentAssignments(Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgAssignment.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", tgId));
		// filter for deleted assignment
		dc.add(Restrictions.eq("isDeleted", false));
		// filter by current cycle where assignment date must be more than licence start date
		dc.add(Restrictions.leProperty("licence.startDate", "startDate"));
		return getList(dc);
	}

	public List<TgAssignment> getAllPrevCycleAssignments(Integer tgId, LocalDate prevStartDate, LocalDate prevExpiryDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgAssignment.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", tgId));
		// filter for deleted assignment
		dc.add(Restrictions.eq("isDeleted", false));
		// filter by current cycle where assignment date must be more than licence start date
		dc.add(Restrictions.and(Restrictions.ge("startDate", prevStartDate)));
		dc.add(Restrictions.and(Restrictions.le("startDate", prevExpiryDate)));
		return getList(dc);
	}

	public BigDecimal getTotalCurrentAssignmentHours(Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgAssignment.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgAssignmentDates", "tgAssignmentDates", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("touristGuide.id", tgId));
		// filter for deleted assignment
		dc.add(Restrictions.eq("isDeleted", false));
		// filter by current cycle where assignment date must be more than licence start date
		dc.add(Restrictions.leProperty("licence.startDate", "startDate"));

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.sum("tgAssignmentDates.noOfHours"), "totalHours");
		dc.setProjection(projections);

		Object result = getFirst(dc);
		return (BigDecimal) result;
	}

	public TgAssignment getSingleAssignment(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgAssignment.class);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}
}
