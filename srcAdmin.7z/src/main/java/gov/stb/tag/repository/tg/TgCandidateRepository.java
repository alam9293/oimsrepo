package gov.stb.tag.repository.tg;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.candidate.TgCandidateSearchDto;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TgLicenceTierSwitch;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgCandidateRepository extends BaseRepository {

	public ResultDto<TgCandidate> getTgCandidates(TgCandidateSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCandidate.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastCandidateResult", "lastCandidateResult", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastCandidateResult.tgTrainingProvider", "tp", JoinType.LEFT_OUTER_JOIN);

		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addEq(dc, "lastCandidateResult.isDirectIssuance", searchDto.isDirectIssuance());
		addEq(dc, "lastCandidateResult.tier.code", searchDto.getTier());
		addEq(dc, "lastCandidateResult.specializedArea.code", searchDto.getSpecializedArea());
		addEq(dc, "lastCandidateResult.result.code", searchDto.getResult());
		addLike(dc, "lastCandidateResult.name", searchDto.getName());
		addEq(dc, "tp.id", searchDto.getTrainingProvider());

		if (searchDto.getExamDateTo() != null) {
			addLt(dc, "lastCandidateResult.examDate", searchDto.getExamDateTo().plusDays(1));
		}
		if (searchDto.getExamDateFrom() != null) {
			addGe(dc, "lastCandidateResult.examDate", searchDto.getExamDateFrom());
		}

		if (!Strings.isNullOrEmpty(searchDto.getUin())) {
			dc.add(Restrictions.disjunction().add(Restrictions.ilike("uin", searchDto.getUin(), MatchMode.ANYWHERE)).add(Restrictions.ilike("formerUin", searchDto.getUin(), MatchMode.ANYWHERE)));
		}

		if (!Strings.isNullOrEmpty(searchDto.getTestLanguage())) {
			var subCriteria = DetachedCriteria.forClass(TgCandidate.class);
			subCriteria.createAlias("lastCandidateResult", "lastCandidateResult", JoinType.LEFT_OUTER_JOIN);
			subCriteria.createAlias("lastCandidateResult.diGuidingLanguages", "diGuidingLanguages", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.eq("diGuidingLanguages.code", searchDto.getTestLanguage()));
			subCriteria.setProjection(Projections.property("lastCandidateResult.id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Restrictions.disjunction().add(Restrictions.eq("lastCandidateResult.guidingLanguage.code", searchDto.getTestLanguage()))
					.add(Subqueries.propertyIn("lastCandidateResult.id", subCriteria)));
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("lastCandidateResult.updatedDate"));
		}

		return search(dc, searchDto, true);
	}

	public TgCandidate getTgCandidateByUin(String uin) {
		var dc = DetachedCriteria.forClass(TgCandidate.class);
		dc.createAlias("lastCandidateResult", "lastCandidateResult", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.disjunction().add(Restrictions.eq("uin", uin)).add(Restrictions.eq("formerUin", uin)));
		return getFirst(dc);
	}

	public TgCandidate getTgCandidateById(Integer tcId) {
		var dc = DetachedCriteria.forClass(TgCandidate.class);
		dc.createAlias("lastCandidateResult", "lastCandidateResult", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", tcId));
		dc.addOrder(Order.asc("lastCandidateResult.examDate"));
		return getFirst(dc);
	}

	public TgCandidateResult getTgCandidateResultById(Integer tgCandidateResultId) {
		var dc = DetachedCriteria.forClass(TgCandidateResult.class);
		dc.createAlias("tgCandidate", "tgCandidate", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", tgCandidateResultId));
		return getFirst(dc);
	}

	public TgLicenceTierSwitch getTgLicenceTierSwitchById(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceTierSwitch.class);
		dc.createAlias("tgCandidateResult", "tgCandidateResult", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("tgCandidateResult.id", id));
		return getFirst(dc);
	}
}
