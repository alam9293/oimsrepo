package gov.stb.tag.repository.tg;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.TgCourseAttendanceDetail;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgCourseAttendanceDetailRepository extends BaseRepository {

	public List<TgCourseAttendanceDetail> getTgCourseAttendance() {
		var dc = DetachedCriteria.forClass(TgCourseAttendanceDetail.class);
		return getList(dc);
	}

	public List<TgCourseAttendanceDetail> getTgCourseAttendanceDetailsByIds(List<Integer> ids) {
		var dc = DetachedCriteria.forClass(TgCourseAttendanceDetail.class);
		dc.add(Restrictions.in("id", ids));
		return getList(dc);
	}

	public Integer checkDuplicateLicenceNo(Integer touristGuideId, Integer attendanceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendanceDetail.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", touristGuideId));
		dc.add(Restrictions.eq("tgCourseAttendance.id", attendanceId));
		dc.add(Restrictions.eq("isDeleted", false));
		return getList(dc).size();
	}

}
