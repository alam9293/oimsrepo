package gov.stb.tag.repository.tg;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgCourseAttendanceRepository extends BaseRepository {

	public List<TgCourseAttendance> getTgCourseAttendance() {
		var dc = DetachedCriteria.forClass(TgCourseAttendance.class);
		return getList(dc);
	}

	public Boolean hasExistingAttendanceForCourse(String courseCode, LocalDate startDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("tgCourse.code", courseCode));
		dc.add(Restrictions.eq("attendedDate", startDate));
		dc.add(Restrictions.eq("isDeleted", false));
		TgCourseAttendance tga = getFirst(dc);
		return tga != null;
	}
}
