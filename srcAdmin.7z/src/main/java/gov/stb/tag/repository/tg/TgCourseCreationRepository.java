package gov.stb.tag.repository.tg;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.coursecreation.TgCourseCreationItemDto;
import gov.stb.tag.dto.tg.coursecreation.TgCourseCreationSearchDto;
import gov.stb.tag.model.TgCourseCreation;

@Repository
public class TgCourseCreationRepository extends TgApplicationRepository {

	public TgCourseCreation getTgCourseCreationById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("id", id));
		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.eq("application.isDeleted", Boolean.FALSE));

		return getFirst(dc);
	}

	public TgCourseCreation getTgCourseCreationByAppId(Integer appId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("application.id", appId));
		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.eq("application.isDeleted", Boolean.FALSE));

		return getFirst(dc);
	}

	public ResultDto<TgCourseCreationItemDto> getPendingList(TgCourseCreationSearchDto searchDto) {
		var dc = DetachedCriteria.forClass(TgCourseCreation.class);
		dc.createAlias("tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		filterCourse(searchDto, dc, true);
		addDtoProjections(dc, TgCourseCreationItemDto.class);
		return search(dc, searchDto, true);
	}

}
