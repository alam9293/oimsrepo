package gov.stb.tag.repository.tg;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.tg.coursecriteria.TgCourseCriteriaDto;
import gov.stb.tag.model.TgCourseCriteria;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgCourseCriteriaRepository extends BaseRepository {

	public List<TgCourseCriteriaDto> getActiveCourseCriteriaListDto() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseCriteria.class);
		dc.add(Restrictions.eq("isActive", Boolean.TRUE));
		dc.addOrder(Order.asc("ordinal"));
		addDtoProjections(dc, TgCourseCriteriaDto.class);
		return getList(dc);
	}

	public List<TgCourseCriteriaDto> getAllCourseCriteria() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseCriteria.class);
		addDtoProjections(dc, TgCourseCriteriaDto.class);
		dc.addOrder(Order.asc("ordinal"));
		return getList(dc);
	}

	public List<TgCourseCriteria> getActiveCourseCriteria() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseCriteria.class);
		dc.add(Restrictions.eq("isActive", Boolean.TRUE));
		dc.addOrder(Order.asc("ordinal"));
		return getList(dc);
	}
}
