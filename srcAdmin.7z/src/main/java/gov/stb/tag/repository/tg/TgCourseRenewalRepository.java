package gov.stb.tag.repository.tg;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.TgCourseRenewal;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgCourseRenewalRepository extends BaseRepository {

	public TgCourseRenewal getValidTgCourseRenewalApplication(String courseCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);

		List<String> statuses = Lists.newArrayList(Codes.Statuses.TG_APP_APPROVED, Codes.Statuses.TG_APP_RFA);
		statuses.addAll(Codes.PendingApprovalStatuses.TG);
		dc.add(Restrictions.eq("tgCourse.code", courseCode));
		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.eq("application.isDeleted", Boolean.FALSE));
		dc.add(Restrictions.in("lastAction.status.code", statuses));

		return getFirst(dc);
	}

	public TgCourseRenewal getTgCourseRenewalByAppId(Integer appId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("application.id", appId));
		dc.add(Restrictions.eq("application.isDraft", Boolean.FALSE));
		dc.add(Restrictions.eq("application.isDeleted", Boolean.FALSE));

		return getFirst(dc);
	}
}
