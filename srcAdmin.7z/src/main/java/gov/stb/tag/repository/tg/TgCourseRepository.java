package gov.stb.tag.repository.tg;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.TimeZone;

import gov.stb.tag.model.TgLicenceRenewal;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.TgCourseSubsidyDto;
import gov.stb.tag.dto.tg.course.TgCourseAttendanceSearchDto;
import gov.stb.tag.dto.tg.course.TgCourseDateDto;
import gov.stb.tag.dto.tg.course.TgCourseDto;
import gov.stb.tag.dto.tg.course.TgCourseItemDto;
import gov.stb.tag.dto.tg.course.TgCourseResultDto;
import gov.stb.tag.dto.tg.course.TgCourseSearchDto;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgCourseSubsidy;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgCourseRepository extends BaseRepository {

	public ResultDto<TgCourseItemDto> getTgCourses(TgCourseSearchDto searchDto) throws UnsupportedEncodingException {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("tgTrainingProvider", "tp", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("Category", "Category", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("language", "language", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isDeleted", false));

		addLike(dc, "name", searchDto.getName());
		addEq(dc, "approvedStartDate", searchDto.getApprovedStartDate());
		addEq(dc, "approvedEndDate", searchDto.getApprovedEndDate());
		addEq(dc, "noOfHours", searchDto.getNoOfHours());
		addEq(dc, "Category.code", searchDto.getCategoryCode());
		addEq(dc, "type.code", searchDto.getTypeCode());
		addEq(dc, "language.code", searchDto.getLanguageCode());
		addEq(dc, "tp.id", searchDto.getTrainingProviderId());

		if (searchDto.getTrainingProviderName() != null) {
			searchDto.setTrainingProviderName(URLDecoder.decode(searchDto.getTrainingProviderName(), "UTF-8"));
			addLike(dc, "tp.name", searchDto.getTrainingProviderName());
		}

		dc.addOrder(Order.desc("approvedStartDate"));

		addDtoProjections(dc, TgCourseItemDto.class);

		return search(dc, searchDto, true);
	}

	public TgCourseDto getTgCourseByCode(String courseCode) {
		var dc = DetachedCriteria.forClass(TgCourse.class);
		dc.add(Restrictions.eq("code", courseCode));

		addDtoProjections(dc, TgCourseDto.class);

		return getFirst(dc);
	}

	public TgCourse getTgCourseWithTpByCode(String courseCode) {
		var dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("code", courseCode));
		return getFirst(dc);
	}

	public TgCourse getTgCourseByTypeAndTpId(String courseType, Integer tpId) {
		var dc = DetachedCriteria.forClass(TgCourse.class);
		dc.add(Restrictions.eq("type.code", courseType));
		dc.add(Restrictions.eq("tgTrainingProvider.id", tpId));
		dc.addOrder(Order.desc("createdDate"));
		return getFirst(dc);
	}

	public ResultDto<TgCourseResultDto> getAllListOfCourseByTgId(TgCourseAttendanceSearchDto searchDto, Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendanceDetails", "tgCourseAttendanceDetails", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendanceDetails.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendanceDetails.result", "examResult", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", tgId));
		dc.add(Restrictions.eq("tgCourseAttendanceDetails.isDeleted", false));
		dc.add(Restrictions.eq("tgCourse.type.code", searchDto.getType()));

		if (searchDto.getYear() != null) {
			addGe(dc, "attendedDate", LocalDate.of(searchDto.getYear(), 1, 1));
			addLe(dc, "attendedDate", LocalDate.of(searchDto.getYear(), 12, 31));
		} else {
			addGe(dc, "attendedDate", searchDto.getStartDate());
			addLe(dc, "attendedDate", searchDto.getEndDate());
		}

		dc.addOrder(Order.desc("attendedDate"));

		return search(dc, searchDto, true);
	}

	public ResultDto<TgCourseResultDto> getAllListOfCourse(TgCourseAttendanceSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.Category", "Category", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.language", "language", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.type", "type", JoinType.LEFT_OUTER_JOIN);

		addIn(dc, "tgTrainingProvider.id", searchDto.getTgTrainingProviderIds());
		addIn(dc, "Category.code", searchDto.getCategoryTypeCodes());
		addIn(dc, "language.code", searchDto.getLanguageTypeCodes());
		addEq(dc, "type.code", searchDto.getType());
		if (searchDto.getStartDate() != null) {
			addGe(dc, "attendedDate", searchDto.getStartDate());
		} else {
			addGe(dc, "attendedDate", LocalDate.now());
		}
		addLe(dc, "attendedEndDate", searchDto.getEndDate());

		if (!Strings.isNullOrEmpty(searchDto.getCourseName())) {
			addLike(dc, "tgCourse.name", searchDto.getCourseName());
		}

		dc.add(Restrictions.eq("isDeleted", false));

		dc.addOrder(Order.asc("attendedDate"));

		return search(dc, searchDto, true);
	}

	public ResultDto<TgCourseResultDto> getCurrentListOfCourseByTgId(TgCourseAttendanceSearchDto searchDto, Integer tgId) {
		DetachedCriteria dc = setCurrentListOfAttendanceByTgId(tgId, searchDto.getType(), null);
		return search(dc, searchDto, true);
	}

	public List<TgCourseAttendance> getListOfCourseAttendanceByTgId(String courseType, Integer tgId) {
		DetachedCriteria dc = setCurrentListOfAttendanceByTgId(tgId, courseType, null);
		return getList(dc);
	}

	public List<TgCourseAttendance> getPrevCycleListOfCourseAttendanceByTgId(String courseType, Integer tgId, LocalDate prevStartDate, LocalDate prevExpiryDate) {
		DetachedCriteria dc = setPrevCycleListOfAttendanceByTgId(tgId, courseType, null, prevStartDate, prevExpiryDate);
		return getList(dc);
	}


	public List<TgCourse> getListOfCourseByTgId(String courseType, Integer tgId) {
		DetachedCriteria dc = setCurrentListOfCourseByTgId(tgId, courseType, null);
		return getList(dc);
	}

	public List<TgCourse> getPrevCycleListOfCourseByTgId(String courseType, Integer tgId, LocalDate prevStartDate, LocalDate prevExpiryDate) {
		DetachedCriteria dc = setPrevCycleListOfCourseByTgId(tgId, courseType, null, prevStartDate, prevExpiryDate);
		return getList(dc);
	}

	public List<TgCourse> getListOfAttendedCourseByTgId(String courseType, Integer tgId) {
		DetachedCriteria dc = setCurrentListOfCourseByTgId(tgId, courseType, Codes.Types.ATTENDED);
		return getList(dc);
	}

	public List<TgCourse> getListOfCourseByTpId(String attendedDate, Integer tpId) {
		LocalDate selectedDate;
		if (attendedDate.equals("null")) {
			selectedDate = LocalDate.now();
		} else {
			selectedDate = LocalDate.ofInstant(Instant.ofEpochMilli(Long.valueOf(attendedDate)), TimeZone.getDefault().toZoneId());
		}
		var dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("tgTrainingProvider.id", tpId));
		dc.add(Restrictions.and(Restrictions.le("approvedStartDate", selectedDate)));
		dc.add(Restrictions.and(Restrictions.ge("approvedEndDate", selectedDate)));
		dc.add(Restrictions.eq("type.code", Codes.Types.TP_COURSE_PDC));
		return getList(dc);
	}

	public ResultDto<TgCourseResultDto> getListOfCourseDetails(TgCourseAttendanceSearchDto searchDto, Integer id, String courseType) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("tgCourse.type.code", courseType));
		dc.add(Restrictions.eq("isDeleted", false));
		if (id != null) {
			dc.add(Restrictions.eq("tgTrainingProvider.id", id));
		}

		if (searchDto.getCourseCode() != null && !searchDto.getCourseCode().equals("")) {
			dc.add(Restrictions.eq("tgCourse.code", searchDto.getCourseCode()));
		}

		if (searchDto.getCourseDate() != null) {
			var courseDate = searchDto.getCourseDate();
			dc.add(Restrictions.and(Restrictions.between("attendedDate", courseDate, courseDate.plusDays(1))));
		}

		dc.addOrder(Order.desc("attendedDate"));

		return search(dc, searchDto, true);
	}

	public TgCourseAttendance getCourseAttendanceById(Integer id, Integer tpId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		if (tpId != null) {
			dc.add(Restrictions.eq("tgTrainingProvider.id", tpId));
		}
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	public String getTgName(String licenceNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.licenceNo", licenceNo));
		dc.setProjection(Projections.property("name"));
		return getFirst(dc);
	}

	public List<TgCourseSubsidyDto> getTgCourseSubsidyByCode(String courseCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseSubsidy.class);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("tgCourse.code", courseCode));
		dc.addOrder(Order.asc("type.ordinal"));

		addDtoProjections(dc, TgCourseSubsidyDto.class);

		return getList(dc);
	}

	public ResultDto<TgCourseItemDto> getTpCourses(TgCourseSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("tgTrainingProvider", "tp", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("Category", "Category", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("language", "language", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isDeleted", false));
		dc.add(Restrictions.eq("tp.id", searchDto.getTrainingProviderId()));

		addLike(dc, "name", searchDto.getName());
		addGe(dc, "approvedStartDate", searchDto.getApprovedStartDate());
		addLe(dc, "approvedEndDate", searchDto.getApprovedEndDate());
		addEq(dc, "noOfHours", searchDto.getNoOfHours());
		addEq(dc, "Category.code", searchDto.getCategoryCode());
		addEq(dc, "type.code", searchDto.getTypeCode());
		addEq(dc, "language.code", searchDto.getLanguageCode());
		dc.addOrder(Order.desc("approvedStartDate"));

		addDtoProjections(dc, TgCourseItemDto.class);

		return search(dc, searchDto, true);
	}

	public List<TgCourseDateDto> getTgCourseDates(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class);
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "tgCourse.code", code);

		dc.add(Restrictions.ge("attendedDate", LocalDate.now()));

		dc.addOrder(Order.asc("attendedDate"));

		addDtoProjections(dc, TgCourseDateDto.class, true);

		return getList(dc);
	}

	private DetachedCriteria setCurrentListOfAttendanceByTgId(Integer tgId, String courseType, String attendanceType) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class, "tgCourseAttendances");
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendanceDetails", "tgCourseAttendanceDetails", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendanceDetails.result", "examResult", JoinType.LEFT_OUTER_JOIN);
		setCurrentListOfCourseByTgId(dc, tgId, courseType, attendanceType);
		return dc;
	}

	private DetachedCriteria setPrevCycleListOfAttendanceByTgId(Integer tgId, String courseType, String attendanceType, LocalDate prevStartDate, LocalDate prevExpiryDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourseAttendance.class, "tgCourseAttendances");
		dc.createAlias("tgCourse", "tgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourse.tgTrainingProvider", "tgTrainingProvider", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendanceDetails", "tgCourseAttendanceDetails", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendanceDetails.result", "examResult", JoinType.LEFT_OUTER_JOIN);
		setPrevCycleListOfCourseByTgId(dc, tgId, courseType, attendanceType, prevStartDate, prevExpiryDate);
		return dc;
	}

	private DetachedCriteria setCurrentListOfCourseByTgId(Integer tgId, String courseType, String attendanceType) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class, "tgCourse");
		dc.createAlias("tgCourseAttendances", "tgCourseAttendances", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendances.tgCourseAttendanceDetails", "tgCourseAttendanceDetails", JoinType.LEFT_OUTER_JOIN);
		setCurrentListOfCourseByTgId(dc, tgId, courseType, attendanceType);
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return dc;
	}

	private DetachedCriteria setPrevCycleListOfCourseByTgId(Integer tgId, String courseType, String attendanceType, LocalDate prevStartDate, LocalDate prevExpiryDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class, "tgCourse");
		dc.createAlias("tgCourseAttendances", "tgCourseAttendances", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgCourseAttendances.tgCourseAttendanceDetails", "tgCourseAttendanceDetails", JoinType.LEFT_OUTER_JOIN);
		setPrevCycleListOfCourseByTgId(dc, tgId, courseType, attendanceType, prevStartDate, prevExpiryDate);
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return dc;
	}

	private DetachedCriteria setCurrentListOfCourseByTgId(DetachedCriteria dc, Integer tgId, String courseType, String attendanceType) {
		dc.createAlias("tgCourseAttendanceDetails.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", tgId));
		dc.add(Restrictions.eq("tgCourseAttendanceDetails.isDeleted", false));
		dc.add(Restrictions.eq("tgCourse.type.code", courseType));
		// filter by current cycle where attended date must be more than licence start date
		dc.add(Restrictions.leProperty("licence.startDate", "tgCourseAttendances.attendedDate"));
		if (attendanceType != null) {
			dc.add(Restrictions.eq("tgCourseAttendanceDetails.attendance.code", attendanceType));
		}

		return dc;
	}

	private DetachedCriteria setPrevCycleListOfCourseByTgId(DetachedCriteria dc, Integer tgId, String courseType, String attendanceType, LocalDate prevStartDate, LocalDate prevExpiryDate) {
		dc.createAlias("tgCourseAttendanceDetails.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", tgId));
		dc.add(Restrictions.eq("tgCourseAttendanceDetails.isDeleted", false));
		dc.add(Restrictions.eq("tgCourse.type.code", courseType));
		// filter by previous cycle where attended date must be more than licence start date
		dc.add(Restrictions.and(Restrictions.ge("tgCourseAttendances.attendedDate", prevStartDate)));
		dc.add(Restrictions.and(Restrictions.le("tgCourseAttendances.attendedDate", prevExpiryDate)));
		if (attendanceType != null) {
			dc.add(Restrictions.eq("tgCourseAttendanceDetails.attendance.code", attendanceType));
		}

		return dc;
	}

	public TgCourse getNextCycleTgCourse(String courseCode, LocalDate courseStartDate) {
		DetachedCriteria parent_sub_criteria = DetachedCriteria.forClass(TgCourse.class);
		parent_sub_criteria.add(Restrictions.eq("code", courseCode));
		parent_sub_criteria.setProjection(Projections.property("parentTgCourse.code"));

		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("parentTgCourse", "parentTgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.disjunction().add(Subqueries.propertyEq("parentTgCourse.code", parent_sub_criteria)).add(Restrictions.eq("parentTgCourse.code", courseCode)));
		dc.add(Restrictions.gt("approvedStartDate", courseStartDate));
		dc.addOrder(Order.asc("approvedStartDate"));

		return getFirst(dc);
	}

	public List<TgCourseItemDto> getTgCourseCycles(String courseCode) {
		DetachedCriteria parent_sub_criteria = DetachedCriteria.forClass(TgCourse.class);
		parent_sub_criteria.add(Restrictions.eq("code", courseCode));
		parent_sub_criteria.setProjection(Projections.property("parentTgCourse.code"));

		DetachedCriteria dc = DetachedCriteria.forClass(TgCourse.class);
		dc.createAlias("parentTgCourse", "parentTgCourse", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.disjunction().add(Subqueries.propertyEq("parentTgCourse.code", parent_sub_criteria)).add(Restrictions.eq("parentTgCourse.code", courseCode)));
		dc.addOrder(Order.desc("approvedStartDate"));

		addDtoProjections(dc, TgCourseItemDto.class);
		return getList(dc);
	}

	public Integer getTouristGuideIdByLicenceNo(String licenceNo) {
		var dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.licenceNo", licenceNo));
		dc.add(Restrictions.eq("licence.taTgType", Codes.TaTgType.TG));
		dc.setProjection(Projections.property("id"));
		return getFirst(dc);
	}

}
