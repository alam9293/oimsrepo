package gov.stb.tag.repository.tg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.touristguide.TouristGuideItemDto;
import gov.stb.tag.dto.tg.touristguide.TouristGuideSearchDto;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgDirectoryRepository extends BaseRepository {

	protected final static String OPTION_All = "ALL";

	public ResultDto<TouristGuideItemDto> getTgListByFilter(TouristGuideSearchDto dto) {
		var dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);

		if (!CollectionUtils.isEmpty(dto.getName())) {
			String name = dto.getName().iterator().next();
			dc.add(Restrictions.or(Restrictions.ilike("name", name, MatchMode.ANYWHERE)).add(Restrictions.ilike("aliasName", name, MatchMode.ANYWHERE)));
		}

		if (!StringUtils.isBlank(dto.getLicenceNo())) {
			dc.add(Restrictions.eq("licence.licenceNo", StringUtils.leftPad(dto.getLicenceNo(), 4, "0")));
		}

		if (!StringUtils.isBlank(dto.getCategory()) && !OPTION_All.equals(dto.getCategory())) {
			List<String> categories = new ArrayList<>();

			categories.add(dto.getCategory());
			if (Codes.Types.TG_TIER_AREA.equalsIgnoreCase(dto.getCategory()) || Codes.Types.TG_TIER_GENERAL.equalsIgnoreCase(dto.getCategory())) {
				categories.add(Codes.Types.TG_TIER_GENERAL_AREA);

			} else if (Codes.Types.TG_TIER_GENERAL_AREA.equalsIgnoreCase(dto.getCategory())) {
				categories.add(Codes.Types.TG_TIER_AREA);
				categories.add(Codes.Types.TG_TIER_GENERAL);
			}

			dc.add(Restrictions.in("licence.tier.code", categories));
		}

		if (!StringUtils.isBlank(dto.getStatus())) {
			String status = dto.getStatus();
			if (!OPTION_All.equals(status)) {
				List<String> statuses = new ArrayList<>();

				if (status.contains("|")) {
					String[] statusSplit = status.split("\\|");
					statuses.addAll(Arrays.asList(statusSplit));
				} else {
					statuses.add(status);
				}
				dc.add(Restrictions.in("licence.status.code", statuses));
			}

		} else {
			if (CollectionUtils.isEmpty(dto.getName())) {
				dc.add(Restrictions.eq("licence.status.code", Codes.Statuses.TG_ACTIVE));
			}
		}

		if (!StringUtils.isBlank(dto.getLanguage()) && !OPTION_All.equals(dto.getLanguage())) {
			var subCriteria = DetachedCriteria.forClass(TouristGuide.class);
			subCriteria.createAlias("guidingLanguages", "language", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.eq("language.code", dto.getLanguage()));
			subCriteria.setProjection(Projections.property("id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}

		if (!StringUtils.isBlank(dto.getArea()) && !OPTION_All.equals(dto.getArea())) {
			var subCriteria = DetachedCriteria.forClass(TouristGuide.class);
			subCriteria.createAlias("specializedAreas", "area", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.eq("area.code", dto.getArea()));
			subCriteria.setProjection(Projections.property("id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}
		dc.add(Restrictions.eq("hasPassedOn", Boolean.FALSE));
		dc.addOrder(Order.asc("licence.licenceNo"));
		return search(dc, dto, true);
	}

}
