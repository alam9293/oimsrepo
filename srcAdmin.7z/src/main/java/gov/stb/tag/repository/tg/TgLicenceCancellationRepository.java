package gov.stb.tag.repository.tg;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.TgLicenceCancellation;

@Repository
public class TgLicenceCancellationRepository extends TgApplicationRepository {

	public TgLicenceCancellation getApplication(String uin) {
		var dc = DetachedCriteria.forClass(TgLicenceCancellation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		addLike(dc, "touristGuide.uin", uin);
		inProcessAppFilter(dc);
		return getFirst(dc);
	}

	public TgLicenceCancellation getApplicationById(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceCancellation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public TgLicenceCancellation getTgLicenceCancellationByApplicationId(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceCancellation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);
	}
}
