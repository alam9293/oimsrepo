package gov.stb.tag.repository.tg;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licencecreation.TgLicenceCreationItemDto;
import gov.stb.tag.dto.tg.licencecreation.TgLicenceCreationSearchDto;
import gov.stb.tag.model.TgLicenceCreation;

@Repository
public class TgLicenceCreationRepository extends TgApplicationRepository {

	public ResultDto<TgLicenceCreationItemDto> getPendingList(TgLicenceCreationSearchDto searchDto) {
		var dc = DetachedCriteria.forClass(TgLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		filter(searchDto, dc, true);
		addDtoProjections(dc, TgLicenceCreationItemDto.class);
		return search(dc, searchDto, true);
	}

	public TgLicenceCreation getApplication(String uin) {
		var dc = DetachedCriteria.forClass(TgLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "uin", uin);
		inProcessAppFilter(dc);
		return getFirst(dc);
	}

	public TgLicenceCreation getLicenceCreationByApplicationId(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);
	}

	public TgLicenceCreation getLicenceCreationById(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "id", id);
		addNe(dc, "application.isDeleted", true);
		return getFirst(dc);
	}

	public TgLicenceCreation getCreation(int licenceCreationId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceCreation.class);
		dc.add(Restrictions.eq("id", licenceCreationId));

		return getFirst(dc);
	}
}
