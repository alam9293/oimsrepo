package gov.stb.tag.repository.tg;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licenceprint.TgLicencePrintSearchDto;
import gov.stb.tag.dto.tg.licenceprinting.TgLicencePrintingItemDto;
import gov.stb.tag.model.Application;

@Repository
public class TgLicencePrintRepository extends TgApplicationRepository {

	public ResultDto<TgLicencePrintingItemDto> getAllListByLicencePrintStatus(TgLicencePrintSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Application.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TG_APP_APPROVED));
		dc.add(Restrictions.not(Restrictions.in("type.code", new ArrayList<>(List.of(Codes.ApplicationTypes.TG_APP_CANCELLATION, Codes.ApplicationTypes.TG_APP_MRC_SUBMISSION,
				Codes.ApplicationTypes.TG_APP_PDC_SUBMISSION, Codes.ApplicationTypes.TG_APP_COURSE_RENEWAL)))));
		dc.add(Restrictions.not(Restrictions.in("licencePrintStatus.code",
				new ArrayList<>(List.of(Codes.Statuses.PRINT_LICENCE_COLLECTED, Codes.Statuses.PRINT_NOT_REQUIRED, Codes.Statuses.PRINT_PENDING_APPROVAL, Codes.Statuses.PRINT_PENDING_PAYMENT)))));
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));

		if (!StringUtils.isBlank(searchDto.getApplicationNo())) {
			dc.add(Restrictions.and(Restrictions.ilike("applicationNo", searchDto.getApplicationNo(), MatchMode.ANYWHERE)));
		}

		if (!StringUtils.isBlank(searchDto.getApplicationType())) {
			dc.add(Restrictions.eq("type.code", searchDto.getApplicationType()));
		}

		if (!StringUtils.isBlank(searchDto.getLicenceNo())) {
			dc.add(Restrictions.and(Restrictions.ilike("licence.licenceNo", searchDto.getLicenceNo(), MatchMode.ANYWHERE)));
		}

		if (!StringUtils.isBlank(searchDto.getLicenceType())) {
			dc.add(Restrictions.eq("licence.tier.code", searchDto.getLicenceType()));
		}

		if (!StringUtils.isBlank(searchDto.getName())) {
			dc.add(Restrictions.and(Restrictions.ilike("touristGuide.name", searchDto.getName(), MatchMode.ANYWHERE)));
		}

		if (!StringUtils.isBlank(searchDto.getLicencePrintStatus())) {
			dc.add(Restrictions.eq("licencePrintStatus.code", searchDto.getLicencePrintStatus()));
		}

		if (searchDto.getDateSendVendor() != null) {
			dc.add(Restrictions.eq("sendToVendorDate", searchDto.getDateSendVendor()));
		}

		if (searchDto.getPendingCollectionStartDate() != null) {
			dc.add(Restrictions.eq("pendingCollectionStartDate", searchDto.getPendingCollectionStartDate()));
		}

		if (searchDto.getPendingCollectionEndDate() != null) {
			dc.add(Restrictions.eq("pendingCollectionEndDate", searchDto.getPendingCollectionEndDate()));
		}
		addDtoProjections(dc, TgLicencePrintingItemDto.class);
		return search(dc, searchDto, true);
	}

	public String getColourByDate(int expiryMonth, int expiryYear) {
		String hql = "SELECT colour FROM tg_print_colours where MONTH(date) = " + expiryMonth + " and YEAR(date) = " + expiryYear;
		Query query = createSQLQuery(hql);
		List<String> resultList = query.list();
		return resultList.get(0);
	}
}
