package gov.stb.tag.repository.tg;

import org.springframework.stereotype.Repository;

import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgLicenceReinstatementRepository extends BaseRepository {

}
