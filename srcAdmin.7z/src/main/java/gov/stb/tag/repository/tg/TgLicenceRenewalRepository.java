package gov.stb.tag.repository.tg;

import java.time.LocalDate;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalItemDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalSearchDto;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgLicenceRenewal;

@Repository
public class TgLicenceRenewalRepository extends TgApplicationRepository {

	public ResultDto<TgLicenceRenewalItemDto> getPendingListByFilter(TgLicenceRenewalSearchDto searchDto) {

		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "application.type.code", searchDto.getApplicationType());
		filter(searchDto, dc, false);
		addDtoProjections(dc, TgLicenceRenewalItemDto.class);
		return search(dc, searchDto, true);

	}

	public Licence getLicence(int userId) {

		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.user", "user", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("user.id", userId));

		return getFirst(dc);
	}

	public TgLicenceRenewal getDraftRenewal(int userId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class, "renewal");
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.user", "user", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("user.id", userId));

		dc.add(Restrictions.eqProperty("previousLicenceStartDate", "licence.startDate"));
		dc.add(Restrictions.eqProperty("previousLicenceExpiryDate", "licence.expiryDate"));

		return getFirst(dc);
	}

	public TgLicenceRenewal getRenewalByLicenceId(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eqProperty("previousLicenceStartDate", "licence.startDate"));
		dc.add(Restrictions.eqProperty("previousLicenceExpiryDate", "licence.expiryDate"));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public TgLicenceRenewal getRenewal(int renewalId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class, "renewal");
		dc.add(Restrictions.eq("id", renewalId));

		return getFirst(dc);
	}

	public TgLicenceRenewal getRenewalByApplication(int applicationId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class, "renewal");
		dc.createAlias("application", "app", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("app.id", applicationId));

		return getFirst(dc);
	}

	// get submitted licence renewal by application id
	public TgLicenceRenewal getTgLicenceRenewalByApplicationId(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);
	}

	public TgLicenceRenewal getRfaRenewal(int userId, LocalDate expiryDate) {

		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class, "renewal");
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.user", "user", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("user.id", userId));

		dc.add(Restrictions.in("lastAction.status.code", Codes.Statuses.TG_APP_RFA));

		// if application is renewal
		if (LocalDate.now().isBefore(expiryDate)) {
			dc.add(Restrictions.eqProperty("licenceStartDate", "licence.startDate"));
			dc.add(Restrictions.eqProperty("licenceExpiryDate", "licence.expiryDate"));
		} else {
			dc.add(Restrictions.eqProperty("previousLicenceStartDate", "licence.startDate"));
			dc.add(Restrictions.eqProperty("previousLicenceExpiryDate", "licence.expiryDate"));
		}


		return getFirst(dc);
	}

}
