package gov.stb.tag.repository.tg;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licencereplacement.TgLicenceReplacementItemDto;
import gov.stb.tag.dto.tg.licencereplacement.TgLicenceReplacementSearchDto;
import gov.stb.tag.model.TgLicenceReplacement;

@Repository
public class TgLicenceReplacementRepository extends TgApplicationRepository {

	public ResultDto<TgLicenceReplacementItemDto> getPendingList(TgLicenceReplacementSearchDto searchDto) {
		var dc = DetachedCriteria.forClass(TgLicenceReplacement.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		filter(searchDto, dc, false);
		addDtoProjections(dc, TgLicenceReplacementItemDto.class);
		return search(dc, searchDto, true);
	}

	public TgLicenceReplacement getApplication(String uin) {
		var dc = DetachedCriteria.forClass(TgLicenceReplacement.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "touristGuide.uin", uin);
		inProcessAppFilter(dc);
		dc.addOrder(Order.desc("createdDate"));
		return getFirst(dc);
	}

	public TgLicenceReplacement getApplicationById(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceReplacement.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public TgLicenceReplacement getTgLicenceReplacementByApplicationId(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceReplacement.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);
	}
}
