package gov.stb.tag.repository.tg;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licence.TgLicenceSearchDto;
import gov.stb.tag.dto.tg.tgInfo.TgInfoResultDto;
import gov.stb.tag.dto.tg.tgInfo.TgInfoSearchDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgInfo;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgLicenceRepository extends BaseRepository {

	@Autowired
	protected CacheHelper cache;

	public ResultDto<Licence> getListOfTgLicence(TgLicenceSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));

		if (searchDto.getLicenceNo() != null && !searchDto.getLicenceNo().equals("")) {
			dc.add(Restrictions.and(Restrictions.ilike("licenceNo", searchDto.getLicenceNo(), MatchMode.ANYWHERE)));
		}

		if (searchDto.getName() != null && !searchDto.getName().equals("")) {
			dc.add(Restrictions.and(Restrictions.ilike("touristGuide.name", searchDto.getName(), MatchMode.ANYWHERE)));
		}

		if (searchDto.getLanguage() != null && !searchDto.getLanguage().equals("")) {
			var subCriteria = DetachedCriteria.forClass(Licence.class);
			subCriteria.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
			subCriteria.createAlias("touristGuide.guidingLanguages", "guidingLanguages", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.eq("guidingLanguages.code", searchDto.getLanguage()));
			subCriteria.setProjection(Projections.property("id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}

		if (searchDto.getLicenceType() != null && !searchDto.getLicenceType().equals("")) {
			dc.add(Restrictions.eq("tier.code", searchDto.getLicenceType()));
		}

		if (searchDto.getExpiryDate() != null && !searchDto.getExpiryDate().equals("")) {
			var expiryDate = searchDto.getExpiryDate();
			dc.add(Restrictions.and(Restrictions.between("expiryDate", expiryDate, expiryDate.plusDays(1))));
		}

		if (searchDto.getLicenceStatus() != null && !searchDto.getLicenceStatus().equals("")) {
			dc.add(Restrictions.eq("status.code", searchDto.getLicenceStatus()));
		}

		if (Boolean.TRUE.equals(searchDto.getWorkPassHolder())) {
			// filter by workpass holder only
			dc.add(Restrictions.not(Restrictions.ilike("touristGuide.uin", "S", MatchMode.START)));
			dc.add(Restrictions.not(Restrictions.ilike("touristGuide.uin", "T", MatchMode.START)));

			if (searchDto.getWorkPassExpiryDateTo() != null) {
				addLe(dc, "touristGuide.workPassExpiryDate", searchDto.getWorkPassExpiryDateTo());
			}

			if (searchDto.getWorkPassExpiryDateFrom() != null) {
				addGe(dc, "touristGuide.workPassExpiryDate", searchDto.getWorkPassExpiryDateFrom());
			}
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("issueDate"));
		}

		return search(dc, searchDto, true);
	}

	public List<Licence> getListOfTgLicenceForMailingLabels(TgLicenceSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));

		if (searchDto.getLicenceNo() != null && !searchDto.getLicenceNo().equals("")) {
			dc.add(Restrictions.and(Restrictions.ilike("licenceNo", searchDto.getLicenceNo(), MatchMode.ANYWHERE)));
		}

		if (searchDto.getName() != null && !searchDto.getName().equals("")) {
			dc.add(Restrictions.and(Restrictions.ilike("touristGuide.name", searchDto.getName(), MatchMode.ANYWHERE)));
		}

		if (searchDto.getLanguage() != null && !searchDto.getLanguage().equals("")) {
			var subCriteria = DetachedCriteria.forClass(Licence.class);
			subCriteria.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
			subCriteria.createAlias("touristGuide.guidingLanguages", "guidingLanguages", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.eq("guidingLanguages.code", searchDto.getLanguage()));
			subCriteria.setProjection(Projections.property("id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}

		if (searchDto.getLicenceType() != null && !searchDto.getLicenceType().equals("")) {
			dc.add(Restrictions.eq("tier.code", searchDto.getLicenceType()));
		}

		if (searchDto.getExpiryDate() != null && !searchDto.getExpiryDate().equals("")) {
			var expiryDate = searchDto.getExpiryDate();
			dc.add(Restrictions.and(Restrictions.between("expiryDate", expiryDate, expiryDate.plusDays(1))));
		}

		if (searchDto.getLicenceStatus() != null && !searchDto.getLicenceStatus().equals("")) {
			dc.add(Restrictions.eq("status.code", searchDto.getLicenceStatus()));
		}

		if (Boolean.TRUE.equals(searchDto.getWorkPassHolder())) {
			// filter by workpass holder only
			dc.add(Restrictions.not(Restrictions.ilike("touristGuide.uin", "S", MatchMode.START)));
			dc.add(Restrictions.not(Restrictions.ilike("touristGuide.uin", "T", MatchMode.START)));

			if (searchDto.getWorkPassExpiryDateTo() != null) {
				addLe(dc, "touristGuide.workPassExpiryDate", searchDto.getWorkPassExpiryDateTo());
			}

			if (searchDto.getWorkPassExpiryDateFrom() != null) {
				addGe(dc, "touristGuide.workPassExpiryDate", searchDto.getWorkPassExpiryDateFrom());
			}
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("issueDate"));
		}

		return getList(dc);
	}

	public Licence getSingleLicence(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	public Licence getLicenceByLicenceNo(String licenceNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.eq("licenceNo", licenceNo));
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));

		return getFirst(dc);
	}

	public List<Licence> getTgLicences(TgLicenceSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));

		if (!Strings.isNullOrEmpty(searchDto.getLicenceNo())) {
			dc.add(Restrictions.and(Restrictions.ilike("licenceNo", searchDto.getLicenceNo(), MatchMode.ANYWHERE)));
		}

		if (!Strings.isNullOrEmpty(searchDto.getName())) {
			dc.add(Restrictions.and(Restrictions.ilike("touristGuide.name", searchDto.getName(), MatchMode.ANYWHERE)));
		}

		if (!Strings.isNullOrEmpty(searchDto.getLicenceStatus())) {
			dc.add(Restrictions.eq("status.code", searchDto.getLicenceStatus()));
		}

		if (searchDto.getResidentialStatuses() != null) {
			dc.createAlias("touristGuide.residentialStatus", "residentialStatus", JoinType.LEFT_OUTER_JOIN);
			addIn(dc, "residentialStatus.code", searchDto.getResidentialStatuses());
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.asc("licenceNo"));
		}

		return getList(dc);
	}

	public ResultDto<TgInfoResultDto> getTgInfoDetails(TgInfoSearchDto searchDto, Integer touristGuideId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgInfo.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", touristGuideId));
		dc.add(Restrictions.eq("isDeleted", false));

		dc.addOrder(Order.desc("updatedDate"));

		return search(dc, searchDto, true);
	}

}
