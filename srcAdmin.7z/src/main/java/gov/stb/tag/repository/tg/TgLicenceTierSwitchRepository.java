package gov.stb.tag.repository.tg;

import gov.stb.tag.model.TgLicenceTierSwitch;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

@Repository
public class TgLicenceTierSwitchRepository extends TgApplicationRepository {

	public TgLicenceTierSwitch getLicenceTierSwitchById(Integer id) {
		var dc = DetachedCriteria.forClass(TgLicenceTierSwitch.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "id", id);
		addNe(dc, "application.isDeleted", true);
		return getFirst(dc);
	}

	public TgLicenceTierSwitch getTgLicenceTierSwitchByResultId(Integer resultId) {
		var dc = DetachedCriteria.forClass(TgLicenceTierSwitch.class);
		dc.createAlias("tgCandidateResult", "result", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.add(Restrictions.eq("result.id", resultId));
		return getFirst(dc);
	}

	public TgLicenceTierSwitch getPendingTierSwitchByUin(String uin) {
		var dc = DetachedCriteria.forClass(TgLicenceTierSwitch.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "touristGuide.uin", uin);
		addEq(dc, "pendingSwitch", true);
		addNe(dc, "application.isDeleted", true);
		return getFirst(dc);
	}
}
