package gov.stb.tag.repository.tg;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptItemDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSearchDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotItemDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotLanguageCountDto;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgMlptSlot;

@Repository
public class TgMlptRepository extends TgApplicationRepository {

	/* MLPT Schedule */

	public ResultDto<TgMlptItemDto> getMlpts(TgMlptSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlpt.class);
		addEq(dc, "name", searchDto.getName());
		addEq(dc, "regStartDate", searchDto.getRegStartDate());
		addEq(dc, "regEndDate", searchDto.getRegEndDate());
		addEq(dc, "mlptStartDate", searchDto.getMlptStartDate());
		addEq(dc, "mlptEndDate", searchDto.getMlptEndDate());
		dc.addOrder(Order.desc("mlptStartDate"));

		addDtoProjections(dc, TgMlptItemDto.class);

		return search(dc, searchDto, true);
	}

	public TgMlptDto getMlpt(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlpt.class);
		addEq(dc, "id", id);

		addDtoProjections(dc, TgMlptDto.class);

		return getFirst(dc);
	}

	public Boolean hasExistingMlptDates(LocalDate regStartDate, LocalDate mlptEndDate, Integer idToExclude) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlpt.class);

		Conjunction regConjunction = Restrictions.conjunction();
		regConjunction.add(Restrictions.le("regStartDate", regStartDate));
		regConjunction.add(Restrictions.ge("mlptEndDate", regStartDate));

		Conjunction mlptConjunction = Restrictions.conjunction();
		mlptConjunction.add(Restrictions.le("regStartDate", mlptEndDate));
		mlptConjunction.add(Restrictions.ge("mlptEndDate", mlptEndDate));

		Disjunction objDisjunction = Restrictions.disjunction();
		objDisjunction.add(regConjunction);
		objDisjunction.add(mlptConjunction);
		dc.add(objDisjunction);

		addNe(dc, "id", idToExclude);

		return getFirst(dc) != null;
	}

	public TgMlpt getNearestOpenMlpt() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlpt.class);
		dc.add(Restrictions.ge("regEndDate", LocalDate.now()));
		dc.addOrder(Order.asc("regStartDate"));
		return getFirst(dc);
	}

	/* MLPT Registration */
	public List<TgLicenceMlptRegistration> getMlptRegistrationsByTgAndTgMlpt(Integer touristGuideId, Integer tgMlptId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", touristGuideId));

		if (tgMlptId != null) {
			addEq(dc, "tgMlpt.id", tgMlptId);
		}

		return getList(dc);
	}

	public TgLicenceMlptRegistration getConfirmedMlptRegistration(Integer touristGuideId, Integer tgMlptId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", touristGuideId));
		dc.add(Restrictions.eq("tgMlpt.id", tgMlptId));
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.eq("application.isDeleted", false));

		return getFirst(dc);
	}

	public TgLicenceMlptRegistration getPrintPendPayMlptRegistration(Integer touristGuideId, Integer tgMlptId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", touristGuideId));
		dc.add(Restrictions.eq("tgMlpt.id", tgMlptId));
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.eq("application.isDeleted", false));
		dc.add(Restrictions.eq("application.licencePrintStatus.code", Codes.Statuses.PRINT_PENDING_PAYMENT));

		return getFirst(dc);
	}

	public List<TgLicenceMlptRegistration> getCurrentMlptRegistrationsByTgAndTgMlpt(Integer touristGuideId, Integer tgMlptId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", touristGuideId));
		dc.add(Restrictions.eq("tgMlpt.id", tgMlptId));
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.eq("application.isDeleted", false));
		dc.add(Restrictions.ge("tgMlpt.mlptEndDate", LocalDate.now()));
		return getList(dc);
	}

	public TgLicenceMlptRegistration getLatestRegistrationByTgAndTgMlpt(Integer touristGuideId, Integer tgMlptId) {
		var dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "touristGuide.id", touristGuideId);
		addEq(dc, "tgMlpt.id", tgMlptId);
		dc.addOrder(Order.desc("createdDate"));
		return getFirst(dc);
	}

	public TgLicenceMlptRegistration getTgMlptRegistrationByUin(String uin) {
		var dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.uin", uin));
		inProcessAppFilter(dc);
		return getFirst(dc);
	}

	public TgLicenceMlptRegistration getLatestTgMlptRegistrationByUin(String uin) {
		var dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.uin", uin));
		dc.addOrder(Order.desc("createdDate"));
		return getFirst(dc);
	}

	public TgLicenceMlptRegistration getTgMlptRegistrationById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceMlptRegistration.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	/* MLPT Slot */

	public List<TgMlptSlotItemDto> getMlptSlots(Integer mlptId) {
		return getMlptSlots(mlptId, "startTime");
	}

	public List<TgMlptSlotItemDto> getMlptSlots(Integer mlptId, String ordering) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlptSlot.class);
		dc.createAlias("tgLicenceMlptRegistration", "tgLicenceMlptRegistration", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		addEq(dc, "tgMlpt.id", mlptId);
		dc.addOrder(Order.asc(ordering));
		dc.addOrder(Order.asc("createdDate"));
		addDtoProjections(dc, TgMlptSlotItemDto.class);

		return getList(dc);
	}

	public TgMlptSlotDto getMlptSlot(Integer slotId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlptSlot.class);
		dc.createAlias("tgLicenceMlptRegistration", "tgLicenceMlptRegistration", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		addEq(dc, "id", slotId);

		addDtoProjections(dc, TgMlptSlotDto.class);

		return getFirst(dc);
	}

	public List<TgMlptSlotItemDto> getCurrentMlptSlotForReinstatement(Integer tgId, LocalDateTime startDate, LocalDateTime endDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlptSlot.class);
		dc.createAlias("tgLicenceMlptRegistration", "tgLicenceMlptRegistration", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		addEq(dc, "licence.id", tgId);
		dc.add(Restrictions.ge("startTime", startDate));
		dc.add(Restrictions.le("startTime", endDate));

		addDtoProjections(dc, TgMlptSlotDto.class);

		return getList(dc);
	}

	public List<TgMlptSlotLanguageCountDto> getLanguageGroupByMlptSlot(Integer mlptId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgMlptSlot.class);
		dc.createAlias("tgLicenceMlptRegistration", "tgLicenceMlptRegistration", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.tgMlpt", "tgMlpt", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgLicenceMlptRegistration.application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		addEq(dc, "tgMlpt.id", mlptId);

		ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Property.forName("guidingLanguage.code").group(), "guidingLanguageCode");
		projectionList.add(Projections.rowCount(), "count");
		dc.setProjection(projectionList);
		dc.setResultTransformer(Transformers.aliasToBean(TgMlptSlotLanguageCountDto.class));

		dc.addOrder(Order.desc("count"));

		return getList(dc);
	}

	public Licence getLicenceByTgId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", id));

		return getFirst(dc);
	}

}
