package gov.stb.tag.repository.tg;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.particularUpdate.ParticularUpdateItemDto;
import gov.stb.tag.dto.tg.particularUpdate.ParticularUpdateSearchDto;
import gov.stb.tag.model.TgPersonUpdate;
import gov.stb.tag.model.TouristGuide;

@Repository
public class TgPersonUpdateRepository extends TgApplicationRepository {

	public ResultDto<ParticularUpdateItemDto> getPendingListByFilter(ParticularUpdateSearchDto searchDto) {
		var dc = DetachedCriteria.forClass(TgPersonUpdate.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		filter(searchDto, dc, false);
		addDtoProjections(dc, ParticularUpdateItemDto.class);
		return search(dc, searchDto, true);
	}

	public TouristGuide getSingleParticular(Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", tgId));
		dc.add(Restrictions.eq("status.code", "TG_A"));
		return getFirst(dc);
	}

	public TgPersonUpdate getTgPersonUpdate(Integer tpuId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgPersonUpdate.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", tpuId));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public TgPersonUpdate getTgPersonUpdateDetails(String uin) {
		var dc = DetachedCriteria.forClass(TgPersonUpdate.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "uin", uin);
		inProcessAppFilter(dc);
		return getFirst(dc);
	}

	public TgPersonUpdate getTgPersonUpdateDetails(Integer id) {
		var dc = DetachedCriteria.forClass(TgPersonUpdate.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", id));
		dc.add(Restrictions.and(Restrictions.ne("currentStatus.code", Codes.Statuses.TG_APP_APPROVED), Restrictions.ne("currentStatus.code", Codes.Statuses.TG_APP_REJECTED),
				Restrictions.ne("currentStatus.code", Codes.Statuses.TG_APP_RFA)));
		addNe(dc, "application.isDeleted", true);
		return getFirst(dc);
	}

	public TgPersonUpdate getTgPersonUpdateDetailsByApplicationId(Integer id) {
		var dc = DetachedCriteria.forClass(TgPersonUpdate.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastAction.status", "currentStatus", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);
	}

}
