package gov.stb.tag.repository.tg;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.stipend.TgStipendConfigSearchDto;
import gov.stb.tag.dto.tg.stipend.TgStipendItemDto;
import gov.stb.tag.dto.tg.stipend.TgStipendSearchDto;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgStipend;
import gov.stb.tag.model.TgStipendConfig;

@Repository
public class TgStipendRepository extends TgApplicationRepository {

	public ResultDto<TgStipendItemDto> getPendingList(TgStipendSearchDto searchDto, Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("application.submissionDate"));
		}
		filter(searchDto, dc, false);
		addDtoProjections(dc, TgStipendItemDto.class);
		return search(dc, searchDto, true);
	}

	public ResultDto<TgStipendItemDto> getApprovedList(TgStipendSearchDto searchDto, Boolean toPaginate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.taTgType", Codes.TaTgType.TG));
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TG_APP_APPROVED));
		dc.add(Restrictions.ne("application.isDeleted", true));

		addEq(dc, "isPendingFollowUp", searchDto.isPendingFollowUp());
		addLike(dc, "touristGuide.name", searchDto.getName());
		addLike(dc, "touristGuide.uin", searchDto.getNricFin());
		addLike(dc, "licence.licenceNo", searchDto.getLicenceNo());
		addLike(dc, "application.applicationNo", searchDto.getApplicationNo());
		addGe(dc, "application.submissionDate", searchDto.getSubmissionDateFrom());
		addGe(dc, "lastAction.createdDate", searchDto.getApproveDateFrom());

		if (searchDto.getApproveDateTo() != null) {
			addLt(dc, "lastAction.createdDate", searchDto.getApproveDateTo().plusDays(1));
		}

		if (searchDto.getSubmissionDateTo() != null) {
			addLt(dc, "application.submissionDate", searchDto.getSubmissionDateTo().plusDays(1));
		}

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("application.submissionDate"));
		}

		addDtoProjections(dc, TgStipendItemDto.class);
		return search(dc, searchDto, toPaginate);
	}

	public TgStipend getTgStipend(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public TgStipend getTgStipendByApplication(Integer appId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", appId));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public List<TgStipend> getTgStipendByConfig(Integer configId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgStipendConfig", "tgStipendConfig", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("tgStipendConfig.id", configId));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getList(dc);
	}

	public List<TgStipend> getTgStipendByApplications(List<Integer> appIds, TgStipendSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.assignee", "assignee", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "application.id", appIds);
		dc.add(Restrictions.ne("application.isDeleted", true));

		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("application.submissionDate"));
		} else {
			Order orderInSearchDto = null;
			orderInSearchDto = searchDto.getOrder().equals("asc") ? Order.asc(searchDto.getOrderProperty()) : Order.desc(searchDto.getOrderProperty());
			dc.addOrder(orderInSearchDto);
		}

		return getList(dc);
	}

	public TgStipend getTgStipendByBillRefNo(String billRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("appBillRefNo", billRefNo));
		dc.add(Restrictions.ne("application.isDeleted", true));
		return getFirst(dc);
	}

	public TgStipend getTgStipendByTgAndPeriod(Integer touristGuideId, Integer configId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipend.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence.touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tgStipendConfig", "tgStipendConfig", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", touristGuideId));
		dc.add(Restrictions.eq("tgStipendConfig.id", configId));
		// dc.add(Restrictions.ne("lastAction.status.code", Codes.Statuses.TG_APP_REJECTED));
		dc.add(Restrictions.ne("application.isDeleted", true));
		dc.addOrder(Order.desc("id"));
		return getFirst(dc);
	}

	public TgStipendConfig getStipendConfig(TgStipendConfigSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipendConfig.class);
		dc.add(Restrictions.eq("forAppeal", searchDto.getForAppeal()));
		addEq(dc, "id", searchDto.getId());
		dc.addOrder(Order.desc("id"));
		return getFirst(dc);
	}

	public TgStipendConfig getLatestStipendConfig(Boolean forAppeal, Integer tgId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgStipendConfig.class);
		dc.createAlias("appealTgs", "appealTgs", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "forAppeal", forAppeal);
		if (forAppeal) {
			if (tgId != null) {
				dc.add(Restrictions.eq("appealTgs.id", tgId));
			}
		}
		dc.addOrder(Order.desc("id"));
		return getFirst(dc);
	}

	public List<Licence> getTgs(List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "touristGuide.id", ids);
		addNe(dc, "status.code", Statuses.TG_ACTIVE);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));

		return getList(dc);
	}

}
