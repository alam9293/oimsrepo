package gov.stb.tag.repository.tg;

import java.util.Arrays;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.trainingprovider.TgTrainingProviderItemDto;
import gov.stb.tag.dto.tg.trainingprovider.TgTrainingProviderSearchDto;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TgTrainingProviderRepository extends BaseRepository {

	public List<TgTrainingProvider> getTrainingProviders() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		addEq(dc, "isDeleted", false);

		return getList(dc);
	}

	public List<TgTrainingProvider> getTrainingProviders(String tgCourseTypeCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		addEq(dc, "isDeleted", false);

		if (Codes.Types.TP_COURSE_PDC.equals(tgCourseTypeCode)) {
			dc.add(Restrictions.eq("isPdc", true));
		} else if (Codes.Types.TP_COURSE_MRC.equals(tgCourseTypeCode)) {
			dc.add(Restrictions.eq("isMrc", true));
		}

		return getList(dc);
	}

	public TgTrainingProvider getTrainingProviderByUen(String uen) {
		var dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		dc.add(Restrictions.eq("uen", uen));
		return getFirst(dc);
	}

	public List<TgTrainingProvider> getActiveTrainingProvider() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		addEq(dc, "isDeleted", false);

		return getList(dc);
	}

	public List<TgTrainingProvider> getActiveTrainingProviderForPDC() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		dc.add(Restrictions.eq("isPdc", true));
		addEq(dc, "isDeleted", false);

		return getList(dc);
	}

	public List<TgTrainingProvider> getAtoTrainingProviders() {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		addEq(dc, "isAto", true);
		addEq(dc, "isDeleted", false);

		return getList(dc);
	}

	public ResultDto<TgTrainingProviderItemDto> getList(TgTrainingProviderSearchDto searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		addLike(dc, "uen", searchDto.getUen());
		addLike(dc, "name", searchDto.getName());
		addLike(dc, "contactPerson", searchDto.getContactPerson());
		addEq(dc, "status.code", searchDto.getStatus());
		if (searchDto.getTpTypes() != null) {
			Disjunction result = Restrictions.disjunction();

			List<String> types = Arrays.asList(searchDto.getTpTypes());
			if (types.contains("pdc")) {
				result.add(Restrictions.eq("isPdc", true));
			}

			if (types.contains("mrc")) {
				result.add(Restrictions.eq("isMrc", true));
			}

			if (types.contains("ato")) {
				result.add(Restrictions.eq("isAto", true));
			}

			dc.add(result);
		}
		addEq(dc, "isDeleted", false);
		if (Strings.isNullOrEmpty(searchDto.getOrderProperty())) {
			dc.addOrder(Order.desc("updatedDate"));
		}
		addDtoProjections(dc, TgTrainingProviderItemDto.class);
		return search(dc, searchDto, true);

	}

	public TgTrainingProvider getTgTrainingProviderById(Integer tpId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgTrainingProvider.class);
		addEq(dc, "id", tpId);
		return getFirst(dc);
	}
}
