package gov.stb.tag.repository.tg;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.BaseRepository;

@Repository
public class TouristGuideRepository extends BaseRepository {

	public TouristGuide getTouristGuideByUin(String uin) {
		var dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.add(Restrictions.eq("uin", uin));
		return getFirst(dc);
	}

	public TouristGuide getTouristGuideByLicenceId(Integer licenceId) {
		var dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.add(Restrictions.eq("licence.id", licenceId));
		return getFirst(dc);
	}

	public List<TouristGuide> getTouristGuides() {
		DetachedCriteria dc = DetachedCriteria.forClass(TouristGuide.class);
		return getList(dc);
	}

	public TouristGuide getTouristGuideByUserId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("user", "user", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("user.id", id));
		return getFirst(dc);
	}

	public List<StatusSpan> getStatusSpan(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(StatusSpan.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("licence.taTgType", Codes.TaTgType.TG));
		dc.addOrder(Order.desc("startDate"));

		return getList(dc);
	}

	public List<CeCaseInfringement> getTgInfringements(String uin) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("ceCaseInfringer.uenUin", uin));
		dc.addOrder(Order.desc("infringedDate"));
		return getList(dc);
	}

	public List<TouristGuide> getTouristGuidesByLicenceId(Integer[] ids) {
		var dc = DetachedCriteria.forClass(TouristGuide.class);
		addIn(dc, "id", ids);
		return getList(dc);
	}
}
