package gov.stb.tag.util;

@FunctionalInterface
public interface ContentBuilder<T> {

	public String[] build(T object);

}
