package gov.stb.tag.util;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.google.common.collect.Lists;
import com.opencsv.CSVWriter;

public class CsvUtil {

	@SuppressWarnings("resource")
	public static void export(HttpServletResponse response, String[] header, List<String[]> contents) throws IOException {

		response.setContentType("text/csv");

		try (OutputStream bos = new BufferedOutputStream(response.getOutputStream()); OutputStreamWriter ow = new OutputStreamWriter(bos); CSVWriter writer = new CSVWriter(ow);) {
			if (header != null) {
				writer.writeNext(header);
			}
			writer.writeAll(contents);

			writer.flush();

		}

	}

	public static <T> void export(HttpServletResponse response, String[] header, Collection<T> rawDatas, ContentBuilder<T> builder) throws IOException {

		List<String[]> contents = Lists.newArrayListWithExpectedSize(rawDatas.size());

		for (T t : rawDatas) {
			String[] stringArray = builder.build(t);
			contents.add(stringArray);
		}

		export(response, header, contents);
	}

}
