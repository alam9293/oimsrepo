package gov.stb.tag.util;

public class EmailUtil {

}
