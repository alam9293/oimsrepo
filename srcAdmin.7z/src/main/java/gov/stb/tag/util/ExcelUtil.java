package gov.stb.tag.util;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {

	public static void createHeaderRow(XSSFSheet sheet, String[] headers) {
		XSSFRow row = sheet.createRow(0);
		XSSFFont font = sheet.getWorkbook().createFont();
		XSSFCellStyle style = sheet.getWorkbook().createCellStyle();
		font.setBold(true);
		style.setFont(font);
		for (int i = 0; i < headers.length; i++) {
			XSSFCell cell = row.createCell(i, CellType.STRING);
			cell.setCellValue(headers[i]);
			cell.setCellStyle(style);
		}
	}

	public static void createHeaderRow(XSSFSheet sheet, String[] headers, int rowTo) {
		XSSFFont font = sheet.getWorkbook().createFont();
		XSSFCellStyle style = sheet.getWorkbook().createCellStyle();
		font.setBold(true);
		style.setFont(font);
		style.setBorderBottom(BorderStyle.MEDIUM);
		style.setVerticalAlignment(VerticalAlignment.TOP);

		for (int i = 0; i < headers.length; i++) {
			for (int j = 0; j <= rowTo; j++) {
				XSSFRow row = sheet.getRow(j) == null ? sheet.createRow(j) : sheet.getRow(j);
				XSSFCell cell = row.createCell(i, CellType.STRING);
				cell.setCellValue(headers[i]);
				if (i == (headers.length - 1)) {
					XSSFCellStyle style2 = sheet.getWorkbook().createCellStyle();
					style2.cloneStyleFrom(style);
					style2.setBorderRight(BorderStyle.MEDIUM);
					cell.setCellStyle(style2);
				} else {
					cell.setCellStyle(style);
				}

			}
			sheet.addMergedRegion(new CellRangeAddress(0, rowTo, i, i));
		}

	}

	// public static CellStyle createDateStyle(XSSFWorkbook workbook) {
	// CellStyle cellStyle = workbook.createCellStyle();
	// CreationHelper creationHelper = workbook.getCreationHelper();
	// cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat(DateUtil.DATE_FORMAT_PATTERN));
	// return cellStyle;
	// }
	//
	// public static CellStyle createDateTimeStyle(XSSFWorkbook workbook) {
	// CellStyle cellStyle = workbook.createCellStyle();
	// CreationHelper creationHelper = workbook.getCreationHelper();
	// cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat(DateUtil.DATE_TIME_FORMAT_PATTERN));
	// return cellStyle;
	// }

	public static XSSFCell createCell(int index, XSSFRow row, CellStyle cellStyle) {
		XSSFCell cell = row.createCell(index);
		cell.setCellStyle(cellStyle);
		return cell;
	}

	public static void export(XSSFWorkbook workbook, HttpServletResponse response, String contentType) throws IOException {
		workbook.write(response.getOutputStream());
		response.setContentType(contentType);
		response.setHeader("Content-Disposition", "attachment");
		response.flushBuffer();
		workbook.close();
	}
}
