package gov.stb.tag.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageConfig;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class QRCodeGenerator {

	protected transient static Logger logger = LoggerFactory.getLogger(QRCodeGenerator.class);

	public static byte[] getQRCodeImage(String text, int width, int height, int offColor) throws WriterException, IOException {
		MatrixToImageConfig con;
		Map<EncodeHintType, Object> hintMap = new HashMap<EncodeHintType, Object>();
		hintMap.put(EncodeHintType.MARGIN, new Integer(1));
		BitMatrix bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, width, height, hintMap);
		ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
		if (offColor == 0) {
			con = new MatrixToImageConfig(0xFF000002, 0xFFFFFFFF);
		} else {
			con = new MatrixToImageConfig(0xFF000002, offColor);
		}

		MatrixToImageWriter.writeToStream(bitMatrix, "PNG", pngOutputStream, con);
		byte[] pngData = pngOutputStream.toByteArray();
		return pngData;
	}

	public static BufferedImage createQrCode(String content, int qrCodeWidth, int qrCodeHeight, ErrorCorrectionLevel eccLevel) {
		BufferedImage img = null;
		try {
			QRCodeWriter qrCodeWriter = new QRCodeWriter();
			Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable();
			BitMatrix bitMatrix;

			hintMap.put(EncodeHintType.ERROR_CORRECTION, eccLevel);
			bitMatrix = qrCodeWriter.encode(content, BarcodeFormat.QR_CODE, qrCodeWidth, qrCodeHeight, hintMap);
			int matrixWidth = bitMatrix.getWidth();
			img = new BufferedImage(matrixWidth, matrixWidth, 1);
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("WriterException :" + e.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Exception :" + e.getMessage());
		}

		return img;
	}

	private static String encodeToString(BufferedImage image, String type) throws IOException {
		try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
			ImageIO.write(image, type, bos);
			byte[] imageBytes = bos.toByteArray();
			return Base64.getEncoder().encodeToString(imageBytes);
		}
	}

	public static void main(String[] args) {
		String qrcode = "";
		BufferedImage res = createQrCode("https://trust.stb.gov.sg/site/content/tagaem/landing-page/travel-agent/travel-agent-details.html?licenceNo=03240", 200, 200, ErrorCorrectionLevel.M);
		try {
			qrcode = encodeToString(res, "png");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("qrcode is " + qrcode);

		byte[] image = new byte[0];
		try {
			image = QRCodeGenerator.getQRCodeImage("https://trust.stb.gov.sg/site/content/tagaem/landing-page/travel-agent/travel-agent-details.html?licenceNo=03240", 100, 100, 0);
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String qrcode1 = Base64.getEncoder().encodeToString(image);
		System.out.println("qrcode1 is " + qrcode1);
	}
}
