import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard, PristineGuard } from './common/guard';

const routes: Routes = [
    { path: '', loadChildren: './main/main.module#MainModule' }
]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: [AuthGuard, PristineGuard]
})

export class AppRoutingModule { }
