import { LayoutModule } from '@angular/cdk/layout';
import { OverlayModule } from '@angular/cdk/overlay';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatChipsModule, MatDialogModule, MatGridListModule, MatSnackBarModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { FlexLayoutModule } from '@angular/flex-layout';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ErrorInterceptor, JwtInterceptor, VersionCheckInterceptor, EncodeHttpParamsInterceptor } from './common/helper';
import { LoaderInterceptorService } from './common/helper/loader.interceptor';
import { AssigneeDialogComponent } from './common/modules/assignee-dialog/assignee-dialog.component';
import { AssigneeDialogModule } from './common/modules/assignee-dialog/assignee-dialog.module';
import { ErrorDialogComponent } from './common/modules/error-dialog/errordialog.component';
import { LoaderComponent } from './common/modules/loader/loader.component';
import { SuccessSnackbarComponent } from './common/modules/success-snackbar/success-snackbar.component';
import { SuccessSnackbarModule } from './common/modules/success-snackbar/success-snackbar.module';
import { AlertService } from './common/services/alert.service';
import { ErrorDialogService } from './common/services/errordialog.service';
import { SidenavService } from './common/services/sidenavService.service';

@NgModule({
    declarations: [AppComponent, LoaderComponent, ErrorDialogComponent,],
    imports: [
        FlexLayoutModule,
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        LayoutModule,
        OverlayModule,
        HttpClientModule,
        ReactiveFormsModule,
        MatDialogModule,
        MatSnackBarModule,
        MatChipsModule,
        MatGridListModule,
        AssigneeDialogModule,
        SuccessSnackbarModule,
        DragDropModule,
        ScrollingModule
    ],
    providers: [
        ErrorDialogService,
        AlertService,
        SidenavService,
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: VersionCheckInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptorService, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: EncodeHttpParamsInterceptor, multi: true }
    ],
    entryComponents: [ErrorDialogComponent, AssigneeDialogComponent, SuccessSnackbarComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }
