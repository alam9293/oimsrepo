import { environment } from '../../environments/environment';

export const apiBaseUrl = environment.apiAppUrl + '/webservice-admin/api/v1';
export const qlikSenseUrl = environment.qlikSenseUrl;
export const maxLengthStr = 255;
export const maxLengthNumerals = 16;
export const maxLengthRemarks = 5000;
export const maxLengthText = 65535;
export const MAX_FILE_SIZE = 20971520;
export const MIN_FILE_SIZE = 92165;
export const nextBtnTxt = "Next";
export const previewBtnTxt = "Confirm";
export const EMAIL_BROADCAST_TOTAL_MAX_FILE_SIZE = 5242880;

export const DASHBOARD = '/dashboard';

export const TA = 'ta';
export const TG = 'tg';
export const CE = 'ce';

export const dateFormat1 = "dd MMMM yyyy";

export class HttpStatus {
    public static BAD_REQUEST = 400;
    public static UNAUTHORIZED = 401;
    public static FORBIDDEN = 403;
    public static UNAVAILABLE = 503;
    public static CONFLICT = 409;
    public static INTERNAL_SERVER_ERROR = 505;
}

export class SgdrmAddressFieldsSize {
    public static BLOCK = 10;
    public static STREET = 32;
    public static FLOOR = 3;
    public static UNIT = 5;
    public static BUILDING = 66;
    public static POSTAL = 6;
}

export class SgdrmEmailFieldsSize {
    public static LOCAL = 64;
    public static ATSIGN = 1;
    public static DOMAIN = 255;
    public static FULL = 320;
}
export class SgdrmPhoneFieldsSize {
    public static FULL = 16;
}

export const showDebugError = true;


export let SystemParameters = {
    TA_SHORTFALL_DEFAULT_NO_OF_DAYS: 'TA_SHORTFALL_DEFAULT_NO_OF_DAYS',
    CE_TATI_CHECK_INFO: 'CE_TATI_CHECK_INFO',
    CE_TA_CHECKS_DECLARATION: 'CE_TA_CHECKS_DECLARATION',
    CE_TG_FIELD_REPORT_DECLARATION: 'CE_TG_FIELD_REPORT_DECLARATION',
    BYPASS_IAMS: 'BYPASS_IAMS',
}

export let defaultOptionsDropDown = [{ key: '', label: '' }, { key: true, label: 'Yes' }, { key: false, label: 'No' }];

export let defaultOptionsRadio = [{ key: true, label: 'Yes' }, { key: false, label: 'No' }];

export class Messages {
    public static ERR_MSG_GENERIC = "System error occurred. Please contact administrator.";
    public static GENERIC_CONFIRM = "Are you sure you want to proceed?";
    public static APPROVAL_CONFIRM = "Action: Approve";
    public static FORWARD_CONFIRM = "Action: Forward for Approval";
    public static RFA_CONFIRM = "Action: Return for Action";
    public static REJECTION_CONFIRM = "Action: Reject";
    public static GENERIC_SUCCCESS = "Changes saved successfully. ";
    public static PASSWORD_RESET_SUCCESS = 'Password successfully reset.';
    public static NOTE_SAVED_SUCCESS = 'Note successfully saved.';
    public static ACTION_DEFAULT = "Application successfully ";
    public static ACTION_DEFAULT_SUBMISSION = "This submission is successfully ";
    public static ACTION_REASSIGN_DEFAULT = "Successfully re-assigned.";
    public static SHORTFALL_DUEDATE_DEFAULT = 'Rectification due dates are projected as +' + SystemParameters.TA_SHORTFALL_DEFAULT_NO_OF_DAYS + ' days from today\'s date except for Edited Due Date.';
    public static MANAGE_SHORTFALL_REDIRECT_TITLE = 'Redirect to Manage Net Value Shortfall';
    public static MANAGE_SHORTFALL_REDIRECT_MSG = 'The %applicationType% submission has shortfall amount of <u>%shortfallAmount%</u>.<br/>Click on Confirm to be redirected to manage net value shortfall.'
    public static MSG_OTHER_DOC = "Please name your documents clearly before uploading";

    // CPF Medisave
    public static MSG_CPF_NA = 'Not Applicable';
    public static MSG_CPF_ERROR = "CPF medisave service currently is not available";
    public static MSG_CPF_INVALID = "Invalid CPF Account";
    public static MSG_CPF_NO_OUTSTANDING = "No";
    public static MSG_CPF_OUTSTANDING = 'Yes';

}

export class CommonErrorMessages {
    public static REQUIRED = "Input required";
    public static MAX_LENGTH_GENERAL = "Input too long";
    public static MAX_LENGTH = "Input too long (Max. " + maxLengthStr + ")";
    public static MAX_LENGTH_REMARKS = "Input too long (Max. " + maxLengthRemarks + ")";
    public static MIN_VALUE = "Input too small (Min. 0)";
    public static REQUIRED_MSG = "Mandatory Field";
    public static MAX_LENGTH_NUMERALS = "Input too long (Max. " + maxLengthNumerals + ")";
    public static MSG_INCOMPLETE_FORM = "Please check the values for all mandatory fields.";
    public static MSG_MIN_SELECTION = "Please select at least one option";
    public static SELECT_SAME_STATUS_APP = "Please select applications with same status.";
    public static DATA_BEFORE_MIN = "Date input is before the minimum date allowed.";
    public static DATA_AFTER_MAX = "Date input is after the maximum date allowed.";
    public static PENDING_APPROVAL_ONLY = "Please select application which is pending approval.";
    public static CAN_DEACTIVATE = "Changes you made may not be saved.";
    public static TOTAL_MAX_FILE_SIZE = "Total max file size exceeded.";
}

export class commonErrorMessages {
    public static require = "Input required";
    public static maxLength = "Input too long (Max. " + maxLengthStr + ")";
    public static minValue = "Input too small (Min. 0)";
    public static startGreaterEndDate = "Start date must not be after end date";
    public static invalidHour = "Input must be smaller or equal to 24 hours";
    public static noAddress = "Enter the address here";
    public static maxBlockLength = "Input too long (Max. " + SgdrmAddressFieldsSize.BLOCK + ")";
    public static maxStreetLength = "Input too long (Max. " + SgdrmAddressFieldsSize.STREET + ")";
    public static maxFloorLength = "Input too long (Max. " + SgdrmAddressFieldsSize.FLOOR + ")";
    public static maxUnitLength = "Input too long (Max. " + SgdrmAddressFieldsSize.UNIT + ")";
    public static maxPostalLength = "Input too long (Max. " + SgdrmAddressFieldsSize.POSTAL + ")";
    public static maxBuildingLength = "Input too long (Max. " + SgdrmAddressFieldsSize.BUILDING + ")";
    public static invalidEmailFormat = "Email is not in the correct format";
    public static invalidEmailLength = "Email length is wrong (Max. Local: " + SgdrmEmailFieldsSize.LOCAL + ", At Sign: " + SgdrmEmailFieldsSize.ATSIGN + ", Domain: " + SgdrmEmailFieldsSize.DOMAIN + ")";
    public static maxEmailLength = "Input too long (Max. " + SgdrmEmailFieldsSize.FULL + ")";
    public static onlyAlphaNumericPattern = "Input cannot contain special characters";
    public static onlyNumericPattern = "Input cannot contain alphabet characters";
    public static maxPhoneLength = "Input too long (Max. " + SgdrmPhoneFieldsSize.FULL + ")";
}

export class TaAlertMessages {
    public static APP_SUBMIT_SUCCESS = "Application Submitted. Application Reference No. ";
    public static MSG_INCOMPLETE_FORM = CommonErrorMessages.MSG_INCOMPLETE_FORM;
    public static APP_CHECHBOX_AT_LEAST_1 = "Please check at least 1 option to process";
    public static MSG_FORM_INVALID = "Submission form is invalid. Please check the error highlighted in red.";
    public static MSG_FORM_VALID = "Submission form validated.";
}

export class TaFrontEndUrl {
    public static TA_LICENCE = "/ta-licence-view";
    public static TA_APP_COMPANY_UPDATE = "/ta-company-update-view";
    public static TA_APP_ABPR_SUBMISSION = '/ta-abpr-view';
    public static TA_APP_AA_SUBMISSION = '/ta-aa-view';
    public static TA_APP_BRANCH = '/ta-branch-view';
    public static TA_APP_TIER_SWITCH = '/ta-switch-view';
    public static TA_APP_REPLACEMENT = '/ta-replace-view';
    public static TA_APP_CESSATION = '/ta-cease-view';
    public static TA_APP_FY_UPDATE = '/ta-fye-view';
    public static TA_APP_KE_UPD_DETAILS = '/ta-ke-update-view';
    public static TA_APP_KE_REASSIGN = '/ta-ke-update-view';
    public static TA_APP_KE_ASSIGN = '/ta-ke-update-view';
    public static TA_APP_KE_RESIGN = '/ta-ke-update-view';
    public static TA_APP_CREATION = '/ta-main-view';
    public static TA_APP_RENEWAL = '/ta-renewal-view';
    public static TA_APP_NET_VALUE_RECTIFICATION = '/ta-shortfall-fulfilment-view';
    public static TA_APP_MA_SUBMISSION = '/ta-ma-view';
    public static TA_RECTIFICATION_SHORTFALL = "/ta-shortfall-fulfilment-view";
    public static TA_MANAGE_SHORTFALL = "/ta-manage-shortfall-view";
    public static TA_MANAGE_FILING = "/ta-manage-filing-view";
    public static TA_ADHOC_FILING_REQUEST = "/ta-filing-request-view";
    public static TA_APP_ADHOC_MA_SUBMISSION = '/ta-ma-view';
    public static TA_APP_ADHOC_DOC_SUBMISSION = '/ta-adhoc-doc-view';
    public static TA_MANAGE_FILING_AMENDMENT = "/ta-manage-filing-amend-view";
    public static TA_APP_ELICENCE_REQUEST = '/ta-e-licence-view';
}

export class TgFrontEndUrl {
    public static TG_APP_CREATION = '/tg-application-view/app';
    public static TG_APP_CANCELLATION = '/tg/cancel-view/app';
    public static TG_APP_RENEWAL = '/tg-renewal-view/app';
    public static TG_APP_REINSTATEMENT = '/tg-reinstate-view/app';
    public static TG_APP_REPLACEMENT = '/tg/lost-licence-view/app';
    public static TG_APP_PERSON_UPDATE = '/tg/update-particulars-view/app';
    public static TG_APP_MRC_SUBMISSION = '';
    public static TG_APP_PDC_SUBMISSION = '';
    public static TG_APP_COURSE_RENEWAL = '/tg-tp-course-renewal/app';
    public static TG_APP_COURSE_CREATION = '/tg-tp-course-creation/app';
    public static TG_APP_STIPEND = '/tg-stipend-view';
}

export class CeFrontEndUrl {
    public static TA_TATI_COMPLIANCE_REPORT = '/ce-tati-check-view';
    public static TA_FIELD_REPORT = '/ce-ta-field-report-view';
    public static TG_GROUND_OBSERVATION_REPORT = '/ce-ground-check-view';
    public static TG_FIELD_REPORT = '/ce-tg-field-report';
    public static CE_TA_CASE = '/ce-case/ta';
}

export class FrontEndListingUrl {
    public static TA_APP_COMPANY_UPDATE = "/ta-company-update-list";
    public static TA_APP_ABPR_SUBMISSION = '/ta-abpr-list';
    public static TA_APP_AA_SUBMISSION = '/ta-aa-list';
    public static TA_APP_BRANCH = '/ta-branch-list';
    public static TA_APP_TIER_SWITCH = '/ta-switch-list';
    public static TA_APP_REPLACEMENT = '/ta-replace-list';
    public static TA_APP_CESSATION = '/ta-cease-list';
    public static TA_APP_FY_UPDATE = '/ta-fye-list';
    public static TA_APP_KE_UPD_DETAILS = '/ta-ke-update-list';
    public static TA_APP_KE = '/ta-ke-update-list';
    public static TA_APP_CREATION = '/ta-main-list';
    public static TA_APP_RENEWAL = '/ta-renewal-list';
    public static TA_APP_NET_VALUE_RECTIFICATION = '/ta-shortfall-fulfilment-list';
    public static TA_APP_MA_SUBMISSION = '/ta-ma-list';
    public static TA_MANAGE_FILING = "/ta-manage-filing-list";
    public static TA_ADHOC_FILING_REQUEST = "/ta-filing-request-list";
    public static TA_APP_ADHOC_MA_SUBMISSION = '/ta-ma-list';
    public static TA_APP_ADHOC_DOC_SUBMISSION = '/ta-adhoc-doc-list';
    public static TA_APP_ELICENCE_REQUEST = '/ta-e-licence-list';
    public static TA_WKFLW_ADHOC_MA_REQ = '/ta-filing-request-list';
    public static TA_WKFLW_ADHOC_DOC_REQ = '/ta-filing-request-list';

    public static TA_WKFLW_SHORTFALL = '/ta-manage-shortfall-list';
    public static TA_WKFLW_RENEW_EX = '/ta-renewal-exercise';
    public static TA_WKFLW_EXTENSION_PREM = '/ta-manage-filing-list';
    public static TA_WKFLW_EXTENSION_DETL = '/ta-manage-filing-list';
    public static TA_WKFLW_FILING_AMEND = '/ta-manage-filing-amend-list';

    public static TG_APP_CREATION = "/tg-application-list";
    public static TG_APP_CANCELLATION = '/tg/cancel-list';
    public static TG_APP_RENEWAL = '/tg-renewal-list';
    public static TG_APP_REINSTATEMENT = '/tg-reinstate-list';
    public static TG_APP_REPLACEMENT = '/tg/lost-licence-list';
    public static TG_APP_PERSON_UPDATE = '/tg/update-particulars-list';
    public static TG_APP_STIPEND = '/tg-stipend-list';
    public static TG_APP_MRC_SUBMISSION = '';
    public static TG_APP_PDC_SUBMISSION = '';
    public static TG_APP_COURSE_CREATION = '/tg-tp-course-creation-list';

    public static CE_WKFLW_TA_SCHEDULE = '/ce-ta-checks-schedule';
    public static CE_TA_CHECKS_REPORTS_LIST = '/ce-ta-checks-reports-list';
    public static CE_WKFLW_TG_SCHEDULE = '/ce-tg-checks-schedule';

    public static CE_TG_CHECKS_REPORTS = '/ce-tg-checks-reports';

    public static PAY_WKFLW_REFUND_TA = '/payment-refund-list';
    public static PAY_WKFLW_REFUND_TG = '/payment-refund-list';
}

export class DashboardOtherAlertUrl {
    public static DASHBOARD_WORKPASS_EXPIRY_ALERT = '/tg-licence-search-list';
    public static DASHBOARD_SHORTFALL_LETTER_PEND_ISSUANCE = FrontEndListingUrl.TA_WKFLW_SHORTFALL;
    public static DASHBOARD_PAYMENT_PAID = '/payment-request-list/PAYREQ_P';
    public static DASHBOARD_PAYMENT_PEND_REFUND = '/payment-request-list/PAYREQ_PR';
    public static DASHBOARD_PAYMENT_PEND_DISBURSEMENT = '/payment-request-list/PAYREQ_PD';
    public static DASHBOARD_TA_LICENCE_PEND_PRINTING = '/ta-licence-print-list';
    public static DASHBOARD_TG_LICENCE_PEND_PRINTING = '/tg-licence-printing-list';
    public static DASHBOARD_STIPEND_FOLLOW_UP_REQUIRED = '/tg-all-applications';
}

export class TaApiUrl {
    public static TA_LICENCES = "/ta/licences"
    public static TA_APPLICATION = "/ta/applications";
    public static TA_TIER_SWITCH = "/ta/tier-switches";
    public static TA_KE = "/ta/ke";
    public static TA_AA = "/ta/audited-accounts";
    public static TA_ABPR = "/ta/abprs";
    public static TA_COMPANY_UPDATE = "/ta/company-updates";
    public static TA_BRANCH_APPLICATION = "/ta/branch-applications";
    public static TA_LICENCE_CESSATION = "/ta/cessations";
    public static TA_LICENCE_REPLACEMENT = "/ta/replacement";
    public static TA_FYE = "/ta/fye";
    public static TA_REPORT = "/reports/ta";
    public static TA_RNW = "/ta/renewals";
    public static TA_RNW_EXERCISE = "/ta/renewal-exercise";
    public static TA_MA = "/ta/management-accounts";
    public static TA_SHORTFALL_FULFILLMENT = "/ta/ta-shortfall-fulfillment";
    public static TA_NETVALUE_SHORTFALL = "/ta/ta-rectification-shortfall"
    public static TA_FILING_EXTEND = "/ta/manage-filing";
    public static TA_LICENCE_PRINT = "/ta/licence-printing";
    public static TA_ADHOC_FILING_REQUEST = "/ta/filing-request";
    public static TA_ADHOC_DOC = "/ta/adhoc-filing-doc";
    public static TA_FILING_AMEND = "/ta/manage-filing-amend";
    public static TA_ELICENCE_REQUEST = "/ta/elicence-request";
}

export class TgAPiUrl {
    public static TG_APPLICATION = "/tg/applications";
    public static TG_CREATION = "/tg/creations";
    public static TG_RENEWAL = "/tg/licence-renewals";
    public static TG_ASSIGNMENT = "/tg/assignments";
    public static TG_PARTICULARS = "/tg/particulars";
    public static TG_CANCEL = "/tg/cancel";
    public static TG_UPDATE_PARTICULARS = "/tg/particulars";
    public static TG_REPLACE = "/tg/replace";
    public static TG_PRINT = "/tg/licence-printing";
    public static TG_LICENCE = "/tg/licences";
    public static TG_CANDIDATE = "/tg/candidates";
    public static TG_CSE = "/tg/course";
    public static TG_CSES = "/tg/courses";
    public static TP_PDC = "/tp/pdc";
    public static TP_MRC = "/tp/mrc";
    public static TG_REPORT = "/reports/tg";
    public static TG_TRAINING_PROVIDER = "/tg/training-provider";
    public static TG_COURSE_CRITERIA = "/tg/course-criteria";
    public static TG_COURSE_RENEWAL = '/tg/course-renewal';
    public static TG_COURSE_CREATION = '/tg/course-creation';
    public static TG_STIPEND = "/tg/stipend";
    public static TG_STIPEND_CONFIG = "/tg/stipend/config";
    public static TG_INFO = "/tg/info";
}

export class CeApiUrl {
    public static TA_CHECK_SCHEDULE = "/ce/ta-check-schedules";
    public static TA_TATI_CHECK = "/ce/tati-check";
    public static TA_CHECKS_REPORTS = "/ce/ta-checks-reports";
    public static TA_FIELD_REPORT = "/ce/ta-field-report";
    public static TG_CHECKS_SCHEDULE = "/ce/tg-check-schedules";
    public static CE_CASE = "/ce/case";
    public static CE_IP = "/ce/ip";
    public static CE_DIRECTORY = "/ce/directory";
    public static TG_CHECKS_REPORTS = "/ce/tg-checks-reports";
    public static TG_GROUND_CHECK = "/ce/tg-ground-check";
    public static TG_FIELD_REPORT = "/ce/tg-field-report";
    public static CE_PROVISION = "/ce/provision";
}

export class SigndocUrl {
    public static PRELOAD = environment.signdocWebUrl + "/rest/v5/documents/refid/";
    public static SHOWGUI = environment.signdocWebUrl + "/signdoc/showgui?locale=en&id=";
    public static VIEW = environment.signdocWebUrl + "/load/bydms?docid=";
}

export class Statuses {
    public static PAYREQ_NOT_PAID = "PAYREQ_N";
    public static PAYREQ_PAID = "PAYREQ_P";
    public static PAYREQ_SETTLED = "PAYREQ_S";
    public static PAYREQ_VOID = "PAYREQ_V";
    public static PAYREQ_PENDING_REFUNDED = "PAYREQ_PR";
    public static PAYREQ_REFUNDED = "PAYREQ_R";
    public static PAYREQ_PENDING_DISBURSEMENT = "PAYREQ_PD";
    public static PAYREQ_DISBURSED = "PAYREQ_DISBURSED";

    public static PAYTXN_SUCCESSFUL = "PAYTXN_S";

    public static LCRTN_FULFILLED = "LCRTN_F";
    public static LCRTN_VOID = "LCRTN_V";
    public static LCRTN_PENDING = "LCRTN_P";

    public static PRINT_PENDING_PRINTING = "PRINT_PP";
    public static PRINT_SUBMIT_PRINT = "PRINT_SP";
    public static PRINT_PENDING_COLLECTION = "PRINT_PC";
    public static PRINT_LICENCE_COLLECTED = "PRINT_C";
    public static PRINT_NOT_REQUIRED = "PRINT_N";
    public static PRINT_PENDING_APPROVAL = "PRINT_PA";
    public static PRINT_PEND_PAY = "PRINT_PEND_PAY";

    public static LICENCE_ACTIVE = "TG_A";
    public static LICENCE_DELICENCED = "TG_I";
    public static LICENCE_SUSPENDED = "TG_S";
    public static LICENCE_REVOKED = "TG_R";

    public static USER_ACTIVE = "USER_A";
    public static USER_INACTIVE = "USER_I";

    public static TG_CANDIDATE_RESULT_COMPETENT = "TG_CANDIDATE_RESULT_COMPETENT";
    public static STAT_CE_SUBMISSION_PENDING = "STAT_CE_SUBMISSION_PENDING";
    public static STAT_CE_SUBMISSION_SUBMITTED = "STAT_CE_SUBMISSION_SUBMITTED";
    public static STAT_CE_SUBMISSION_DRAFT = "STAT_CE_SUBMISSION_DRAFT";
}

export class LicenceStatuses {
    public static TA_ACTIVE = "TA_A";
    public static TA_INACTIVE = "TA_I"; // Licensed but Inactive
    public static TA_REVOKED = "TA_R";
    public static TA_SUSPENDED = "TA_S";
    public static TA_CEASED = "TA_C";
    public static TA_LAPSED = "TA_L";
    public static TA_PEND_SUSPENSION = "TA_PS";
    public static TA_PEND_REVOCATION = "TA_PR";
}

export class ApplicationStatuses {
    public static TA_APP_PENDING_APPROVAL = "TA_APP_PA";
    public static TA_APP_PENDING_PO = "TA_APP_PEND_PO";
    public static TA_APP_PENDING_VO = "TA_APP_PEND_VO";
    public static TA_APP_PEND_CNE_CO = "TA_APP_PEND_CNE_CO";
    public static TA_APP_PENDING_AO = "TA_APP_PEND_AO";
    public static TA_APP_PENDING_HOD = "TA_APP_PEND_HOD";
    public static TA_APP_PENDING_HODIV = "TA_APP_PEND_HODIV";
    public static TA_APP_APPROVED = "TA_APP_APPR";
    public static TA_APP_RFA = "TA_APP_RFA";
    public static TA_APP_REJECTED = "TA_APP_REJ";
    public static TA_APP_DRAFT = "TA_APP_DRAFT";
    public static TA_APP_SAVE = "TA_APP_SAVE";
    public static TA_APP_NEW = "TA_APP_NEW";

    public static TG_APP_PENDING_APPROVAL = "TG_APP_PA";
    public static TG_APP_PENDING_PO = "TG_APP_PEND_PO";
    public static TG_APP_PENDING_AO = "TG_APP_PEND_AO";
    public static TG_APP_PENDING_HODIV = "TG_APP_PEND_HODIV";
    public static TG_APP_APPROVED = "TG_APP_APPR";
    public static TG_APP_RFA = "TG_APP_RFA";
    public static TG_APP_REJECTED = "TG_APP_REJ";

}

export class STAT_WKFLW {
    public static TA_WKFLW_NEW = "TA_WKFLW_NEW"
    public static TA_WKFLW_PEND_PO = "TA_WKFLW_PEND_PO"
    public static TA_WKFLW_PEND_VO = "TA_WKFLW_PEND_VO"
    public static TA_WKFLW_PEND_AO = "TA_WKFLW_PEND_AO"
    public static TA_WKFLW_PEND_HOD = "TA_WKFLW_PEND_HOD"
    public static TA_WKFLW_PEND_HODIV = "TA_WKFLW_PEND_HODIV"
    public static TA_WKFLW_APPR = "TA_WKFLW_APPR"
    public static TA_WKFLW_REJ = "TA_WKFLW_REJ"
    public static TG_WKFLW_PEND_PO = "TG_WKFLW_PEND_PO"
    public static TG_WKFLW_PEND_AO = "TG_WKFLW_PEND_AO"
    public static TG_WKFLW_PEND_HODIV = "TG_WKFLW_PEND_HODIV"
    public static TG_WKFLW_APPR = "TG_WKFLW_APPR"
    public static TG_WKFLW_REJ = "TG_WKFLW_REJ"

    public static CE_WKFLW_NEW = "CE_WKFLW_NEW"; // not used in data, used to retrive label to show "New" statues
    public static CE_WKFLW_PEND_APPR = "CE_WKFLW_PEND_APPR";
    public static CE_WKFLW_PEND_SUPP = "CE_WKFLW_PEND_SUPP";
    public static CE_WKFLW_APPR = "CE_WKFLW_APPR";
    public static CE_WKFLW_REJ = "CE_WKFLW_REJ";
    public static CE_WKFLW_ROUTED = "CE_WKFLW_ROUTED";

    public static PAY_WKFLW_PEND_APPR = "PAY_WKFLW_PEND_APPR";
}

export class ApplicationRoles {
    public static TA_PO = "TA_PO";
    public static TA_VO = "TA_VO";
    public static CNE_CO = "CNE_CO";
    public static TA_AO = "TA_AO";
    public static TA_HOD = "TA_HOD";
    // public static TA_HODIV = "HODIV";
    public static TG_PO = "TG_PO";
    public static TG_AO = "TG_AO";
    public static HODIV = "HODIV";
    public static FINANCE = "FINANCE";
}

export class applicationStatusList {
    public static statusList: Map<string, string[]> = new Map([
        [ApplicationStatuses.TA_APP_REJECTED, ["rejected", "reject"]],
        [ApplicationStatuses.TA_APP_APPROVED, ["approved", "approve"]],
        [ApplicationStatuses.TA_APP_RFA, ["returned for action", "rfa"]],
        [ApplicationStatuses.TA_APP_SAVE, ["saved", "save"]],
    ])
}
export class ApplicationTypes {
    public static TA_APP_BRANCH = "TA_APP_BRANCH";
    public static TA_APP_CREATION = "TA_APP_CREATION";
    public static TA_APP_TIER_SWITCH = "TA_APP_TIER_SWITCH";
    public static TA_APP_CESSATION = "TA_APP_CESSATION";
    public static TA_APP_KE_UPD_DETAILS = "TA_APP_KE_UPD_DETAILS";
    public static TA_APP_KE_RESIGN = "TA_APP_KE_RESIGN";
    public static TA_APP_KE_REASSIGN = "TA_APP_KE_REASSIGN";
    public static TA_APP_KE_ASSIGN = "TA_APP_KE_ASSIGN";
    public static TA_APP_RENEWAL = "TA_APP_RENEWAL";
    public static TA_APP_REPLACEMENT = 'TA_APP_REPLACEMENT';
    public static TA_APP_COMPANY_UPDATE = 'TA_APP_COMPANY_UPDATE';

    public static TG_APP_CREATION = "TG_APP_CREATION";
    public static TG_APP_RENEWAL = "TG_APP_RENEWAL";
    public static TG_APP_REINSTATEMENT = "TG_APP_REINSTATEMENT";
    public static TG_APP_REPLACEMENT = "TG_APP_REPLACEMENT";
    public static TG_APP_PERSON_UPDATE = "TG_APP_PERSON_UPDATE";
    public static TG_APP_CANCELLATION = "TG_APP_CANCELLATION";
    public static TG_APP_MRC_SUBMISSION = "TG_APP_MRC_SUBMISSION";
    public static TG_APP_PDC_SUBMISSION = "TG_APP_PDC_SUBMISSION";
    public static TG_APP_MLPT_REGISTRATION = "TG_APP_MLPT_REGISTRATION";
    public static TG_APP_SWITCH_TIER = "TG_APP_SWITCH_TIER";
    public static TG_APP_COURSE_RENEWAL = "TG_APP_COURSE_RENEWAL";
    public static TG_APP_COURSE_CREATION = "TG_APP_COURSE_CREATION";
    public static TG_APP_STIPEND = "TG_APP_STIPEND";

    public static TA_APP_LICENCE_PRINT_TYPES = [ApplicationTypes.TA_APP_BRANCH, ApplicationTypes.TA_APP_CREATION, ApplicationTypes.TA_APP_TIER_SWITCH, ApplicationTypes.TA_APP_RENEWAL, ApplicationTypes.TA_APP_REPLACEMENT, ApplicationTypes.TA_APP_COMPANY_UPDATE];
}

export class WorkflowTypes {
    public static TA_WKFLW_SHORTFALL = "TA_WKFLW_SHORTFALL";
    public static TA_WKFLW_EXTENSION_DETL = "TA_WKFLW_EXTENSION_DETL";
    public static TA_WKFLW_EXTENSION_PREM = "TA_WKFLW_EXTENSION_PREM";
    public static TA_WKFLW_ADHOC_MA_REQ = "TA_WKFLW_ADHOC_MA_REQ";
    public static TA_WKFLW_ADHOC_DOC_REQ = "TA_WKFLW_ADHOC_DOC_REQ";
    public static TA_WKFLW_FILING_AMEND = "TA_WKFLW_FILING_AMEND";
    public static CE_WKFLW_TA_SCHEDULE = "CE_WKFLW_TA_SCHEDULE";
    public static CE_WKFLW_TG_SCHEDULE = "CE_WKFLW_TG_SCHEDULE";
    public static CE_WKFLW_TA_CASE_TASK_RECOMMEND = "CE_WKFLW_TA_CASE_TASK_RECOMMEND";
    public static CE_WKFLW_TA_CASE_TASK_DECISION = "CE_WKFLW_TA_CASE_TASK_DECISION";
    public static CE_WKFLW_TA_CASE_TASK_APPEAL = "CE_WKFLW_TA_CASE_TASK_APPEAL";
    public static CE_WKFLW_TA_CASE_TASK_RESCIND = "CE_WKFLW_TA_CASE_TASK_RESCIND";
    public static CE_WKFLW_TA_CASE_TASK_LIFT = "CE_WKFLW_TA_CASE_TASK_LIFT";
    public static CE_WKFLW_TA_IP_COMPO_IMPOSE = "CE_WKFLW_TA_IP_COMPO_IMPOSE";
    public static CE_WKFLW_TA_IP_COMPO_WAIVE = "CE_WKFLW_TA_IP_COMPO_WAIVE";
    public static CE_WKFLW_TG_CASE_TASK_RECOMMEND = "CE_WKFLW_TG_CASE_TASK_RECOMMEND";
    public static CE_WKFLW_TG_CASE_TASK_DECISION = "CE_WKFLW_TG_CASE_TASK_DECISION";
    public static CE_WKFLW_TG_CASE_TASK_APPEAL = "CE_WKFLW_TG_CASE_TASK_APPEAL";
    public static CE_WKFLW_TG_CASE_TASK_RESCIND = "CE_WKFLW_TG_CASE_TASK_RESCIND";
    public static CE_WKFLW_TG_CASE_TASK_LIFT = "CE_WKFLW_TG_CASE_TASK_LIFT";
    public static CE_WKFLW_TG_FIELD_REPORT = "CE_WKFLW_TG_FIELD_REPORT";
    public static CE_WKFLW_TG_IP_COMPO_IMPOSE = "CE_WKFLW_TG_IP_COMPO_IMPOSE";
    public static CE_WKFLW_TG_IP_COMPO_WAIVE = "CE_WKFLW_TG_IP_COMPO_WAIVE";
    public static PAY_WKFLW_REFUND_TA = "PAY_WKFLW_REFUND_TA";
    public static PAY_WKFLW_REFUND_TG = "PAY_WKFLW_REFUND_TG";
}

export class PaymentTypes {
    public static VISA = "PAY_V";
    public static MASTERCARD = "PAY_M";
    public static PAYNOW = "PAY_P";
    public static CASH_CHEQUE = "PAY_C";
    public static INTERBANK_TXF = "PAY_I";
    public static GIRO = "PAY_G";
}

export class PaymentReqTypes {
    public static PAYREQ_TG_STIPEND = "PAYREQ_TG_STIPEND";
}

export class CePaymentRequestTypes {
    public static PAYREQ_CE_COMPOSITION = "PAYREQ_CE_COMPOSITION";
    public static PAYREQ_CE_AFP = "PAYREQ_CE_AFP";
}

export class PAGINATION {
    public static SIZE_OPTTIONS = [5, 10, 20, 50];
    public static DEFAULT_PAGE_SIZE = 10;
}

export const TaReplacementOtherReason = 'TA_RESN_REPLACE_O';
export const TaCessationOtherReason = 'TA_RESN_CEASE_O';

export class DocumentTypes {
    public static TA_DOC_BANK = "TA_DOC_BANK";
    public static TA_DOC_KE_RESUME = "TA_DOC_KE_RESUME";
    public static TA_DOC_CEASE_DIRECTOR_RESOLUTION = "TA_DOC_CEASE_DIRECTOR_RESOLUTION";
    public static TA_DOC_POLICE_REPORT = "TA_DOC_POLICE_REPORT";
    public static TA_DOC_MGMT_ACC = "TA_DOC_MGMT_ACC";
    public static TA_DOC_AUDIT_REPORT = "TA_DOC_AUDIT_REPORT";
    public static TA_DOC_OTHERS = "TA_DOC_O";
    public static TA_DOC_BRANCH = "TA_DOC_BRANCH";
    public static TA_DOC_EXTENSION_EMAIL_REQUEST = "TA_DOC_EXTENSION_EMAIL_REQUEST";
    public static TA_DOC_EMAIL_BROADCAST = "TA_DOC_EMAIL_BROADCAST";
    public static TA_DOC_TENANCY = "TA_DOC_TENANCY";
    public static TA_DOC_ACRA_BIZ = "TA_DOC_ACRA_BIZ";
    public static TA_DOC_MANAGEMENT_ACCOUNTS = "TA_DOC_MANAGEMENT_ACCOUNTS";

    public static TG_DOC_MEDICAL_65 = "TG_DOC_MED";
    public static TG_DOC_PASSPORT_PHOTO = "TG_DOC_PHOTO";
    public static TG_DOC_POLICE_REPORT = "TG_DOC_POLICE";
    public static TG_DOC_WORK_PASS = "TG_DOC_WP";
    public static TG_DOC_OTHERS = "TG_DOC_O";
    public static BULLETIN_DOC = "BULLETIN_DOC";

    public static CE_TA_CHECK_INVOICE = "CE_TA_CHECK_INVOICE";
    public static CE_DOC_OTHERS = "CE_DOC_O";
    public static CE_TG_GROUND_CHECK = "CE_TG_GROUND_CHECK";
    public static CE_TG_FIELD_REPORT = "CE_TG_FIELD_REPORT";
    public static CE_TATI_CHECKLIST = "CE_TATI_CHECKLIST";
    public static CE_TATI_CHECKLIST_INV = "CE_TA_CHECKLIST_INV";
    public static CE_TA_FIELD_REPORT = "CE_TA_FIELD_REPORT";
    public static CE_COMPO_LETTER = "CE_COMPO_LETTER";
    public static TA_DOC_SHORTFALL_LETTER_SYSTEM = "TA_DOC_SHORTFALL_LETTER_SYSTEM";
}

export class TpCourseTypes {
    public static pdc = "TP_CSE_P";
    public static mrc = "TP_CSE_M";
}

export class RenewalTypes {
    public static RENEWAL = "TG_RENEWAL";
    public static REINSTATE = "TG_REINSTATE";
}

export class renewalStatusCode {
    public static renewalBlank = "RENEWAL_BLANK";
    public static renewalTick = "RENEWAL_TICK";
    public static renewalGrey = "RENEWAL_GREY";
    public static renewalGreyTemp = "RENEWAL_GREY_TEMP";
    public static renewalHide = "RENEWAL_HIDE";
}
export class AddressTypes {
    public static ADDR_FOREIGN = "ADDR_F";
    public static ADDR_LOCAL = "ADDR_L";
}

export class NumericalRepresent {
    public static NEG_INFINIY_BIG_DECIMAL = -999999999999999;
    public static POS_INFINIY_BIG_DECIMAL = 999999999999999;
}

export class StringRepresent {
    public static NEG_INFINIY = "Negative Infinity";
    public static POS_INFINIY = "Positive Infinity";
}

export class commonTypes {
    public static OCCP_OTHERS = "Others";
}

export class TaRenewalTypes {
    public static TA_RENEW_EXPRESS = "TA_RENEW_EX_EXP";
    public static TA_RENEW_CUSTOMISED = "TA_RENEW_EX_CUS";
}

export class TaAnnualFilingStatus {
    public static TA_FILING_PS = "TA_FILING_PS";
    public static TA_FILING_PA = 'TA_FILING_PA';
    public static TA_FILING_RFA = 'TA_FILING_RFA';
    public static TA_FILING_LATE = 'TA_FILING_LATE';
    public static TA_FILING_APPR = 'TA_FILING_APPR';
}

export class ManageShortfall {
    public static AA_SHORTFALL = "AA_SHORTFALL";
    public static MA_SHORTFALL = 'MA_SHORTFALL';
    public static FULL_SHORTFALL = 'FULL_SHORTFALL';
    public static INCREMENTAL_SHORTFALL = 'INCREMENTAL_SHORTFALL';
    public static TA_FILING_APPR = 'TA_FILING_APPR';
    public static WKFLW_CASE_PA = 'WKFLW_CASE_PA';
    public static WKFLW_CASE_APPR = 'WKFLW_CASE_APPR';
    public static WKFLW_CASE_REJ = 'WKFLW_CASE_REJ';
}

export class BulletinTypeCode {
    public static TA = "BULLETIN_TA";
    public static TG = "BULLETIN_TG";
    public static CE = "BULLETIN_TG";
    public static GENERAL = "BULLETIN_GENERAL";
}

export class ResourcesTypeCode {                 //Manage Resource STBPROD1206
    public static TA = "RESOURCES_TA";
    public static TG = "RESOURCES_TG";
    public static GENERAL = "RESOURCES_GENERAL";
}

export class TaLicencePrintStatuses {
    public static TA_PRINT_PENDING = 'TA_PRINT_PENDING';
    public static TA_PRINT_PRINTED = 'TA_PRINT_PRINTED';
    public static TA_PRINT_NOT_REQUIRED = 'TA_PRINT_NOT_REQUIRED';
}

export class MasterDataSelection {
    public static TYPES = "TYPES";
    public static STATUSES = "STATUSES";
    public static SYSTEM_PARAMETERS = "SYSTEM_PARAMETERS";
    public static EMAIL = "EMAIL";
    public static WAIVER = "WAIVER";
}

export class DataType {
    public static DATA_DT = "DATA_DT";
    public static DATA_NUM = "DATA_NUM";
    public static DATA_STR = "DATA_STR";
}



export class dashboardTypeCode {
    public static TA = "TA";
    public static TG = "TG";
    public static TACDD = "TACDD";
    public static TP = "TP";
    public static AEM = "AEM";
}

export class TgCommonTypes {
    public static ATTENDANCE_ABSENT = "TP_ATN_ABS";
    public static ATTENDANCE_ATTENDED = "TP_ATN_ATN";
    public static TG_OCCUPATION = "OCCP_O";
    public static TG_AREA = "TG_TIER_A";
    public static TG_GENERAL_AREA = "TG_TIER_GA";
    public static TG_GENERAL = "TG_TIER_G";
    public static TG_TAXI = "TG_TIER_T";
    public static TG_RESD_WP = "RESD_W";
}



export class TgLicenceRenewalErrorMessage {
    public static MED_65_REQUIRED = "Please upload medical report";
    public static WORK_PASS_REQUIRED = "Please upload work pass";
    public static SUPPORTING_DOC_REQUIRED = "Please upload supporting document(s)";
    public static PHOTO_REQUIRED = "Please upload photo";
}

export class TgCommonErrorMessage {
    public static INPUT_REQUIRED = "Input required";
    public static INVALID_POSTAL_CODE = "Invalid postal code";
    public static INPUT_LENGTH_MIN_6 = "Input too short (Min. 6)";
    public static INPUT_LENGTH_8 = "Input only allowed 8 characters";
    public static INVALID_MOBILE_NO = "Invalid mobile no.";
    public static INVALID_EMAIL = "Email is not in the correct format";
    public static INPUT_LENGTH_MAX = "Input too long (Max. " + maxLengthStr + ")";
    public static INVALID_NAME = "Invalid name";
    public static INVALID_SCORE = "Invalid score";
    public static INVALID_MAX_SCORE = "Max score is not allowed to be smaller than score"
    public static INVALID_LICENCE_NO = "Invalid licence no.";
    public static INVALID_PHOTO_DIMENSION = "Photo width and height has to be 400px and 514px respectively";
    public static INVALID_PHOTO_RESOLUTION = "Minimum photo resolution has to be 96dpi";
    public static MIN_PHOTO_SIZE = "Minimum file size has to be 90KB";
    public static MAX_PHOTO_SIZE = "Uploaded file size cannot exceed 1MB";
}

export class TaValidationMessages {
    public static MIN_PERCENT = "Minimum value is 0";
    public static MAX_PERCENT = "Maximum value is 100";
    public static SUM_INBOUND_OPERATIONS = "Sum of all inbound operations should be 0% or 100%";
    public static SUM_OUTBOUND_OPERATIONS = "Sum of all outbound operations should be 0% or 100%";
    public static DUPLICATED_VALUES = "Duplicate values are not allowed";
    public static DIGIT_LENGTH = 'Max numerical amount is 16 digits'
    public static REQUIRED = "Mandatory field";
    public static EDH_REQUIRED = "Mandatory field, please update with ACRA";
    public static DATE_BEFORE_MIN = "Date input is before the minimum date allowed";
    public static DATE_AFTER_MAX = "Date input is after the maximum date allowed";
}

export class TaABPRErrorMessage {
    public static TA_MAX_AMOUNT_LENGTH = 'Max numerical amount is 16 digits'
    public static TA_MAX_INTEGER_LENGTH = 'Max numerical amount is 9 digits'

    public static TA_INVALID_NICHE_BUSINESS_TYPE = "Niche licence cannot do accommodation and air ticketing business type";
    public static TA_INVALID_NICHE_OUTBOUND = "Niche licence cannot do outbound business";
    public static TA_MISSING_ROWS = "Rows should not be empty";
    public static TA_MISSING_TOTAL_INBOUND = "Total inbound % cannot be empty";
    public static TA_MISSING_TOTAL_OUTBOUND = "Total outbound % cannot be empty";
    public static TA_MISSING_BUSINESS = "Mandatory field";
    public static TA_MISSING_FOCUS = "Mandatory field";
    public static TA_MISSING_ANSWER = "Mandatory field";
    public static TA_INVALID_ANSWER = "Yes is not allowed if amount is 0";
    public static TA_INVALID_INBOUND_ANSWER = "As your inbound operations was indicated as 0% in the previous section, selection should be empty or 'No'";
    public static TA_INVALID_OUTBOUND_ANSWER = "As your outbound operations was indicated as 0% in the previous section, selection should be empty or 'No'";
    public static TA_MISSING_BOTH_CHECKBOXES = "Select a checkbox";
    public static TA_MISSING_COUNTRY = "Mandatory field";
    public static TA_MISSING_PERCENTAGE = "Mandatory field";
    public static TA_REPEATED_BUSINESS = "Duplicate values is not allowed";
    public static TA_NOT_MATCHED_PERCENTAGE_INBOUND_OUTBOUND = "Inbound and outbound operations should add up to be 100%";

    public static TA_NOT_MATCHED_PERCENTAGE_INBOUND_OPERATIONS = "Sum of all source countries' inbound operations should be 100%";
    public static TA_NOT_MATCHED_PERCENTAGE_OUTBOUND_OPERATIONS = "Sum of all destination countries' outbound operations should be 100%";
    public static TA_NOT_MATCHED_ZERO_INBOUND = "Inbound percentage should be 0 when outbound is 100%";
    public static TA_NOT_MATCHED_ZERO_OUTBOUND = "Outbound percentage should be 0 when inbound is 100%";
    public static TA_NOT_MATCHED_ZERO_INBOUND_OPERATIONS = "Values in this section should be 0 when inbound operations is 0%";
    public static TA_NOT_MATCHED_ZERO_OUTBOUND_OPERATIONS = "Values in this section should be 0 when outbound operations is 0%";
    public static TA_REQUIRE_INBOUND_OPERATIONS = "Inbound value is mandatory when inbound operations > 0%";
    public static TA_REQUIRE_OUTBOUND_OPERATIONS = "Outbound value is mandatory when outbound operations > 0%";
    public static TA_NOT_REQUIRE_INBOUND_OPERATIONS = "Inbound value should be zero when inbound operations is 0%";
    public static TA_NOT_REQUIRE_OUTBOUND_OPERATIONS = "Outbound value should be zero when outbound operations is 0%";
    public static TA_NOT_MATCHED_ZERO_INBOUND_OPERATIONS_CHECKBOX = "Inbound checkbox should be unchecked when inbound operations is 0%";
    public static TA_NOT_MATCHED_ZERO_OUTBOUND_OPERATIONS_CHECKBOX = "Outbound checkbox should be unchecked when outbound operations is 0%";
    public static TA_NOT_MATCHED_TRUE_INBOUND_OPERATIONS_CHECKBOX = "Inbound checkbox mandatory as your inbound operation > 0%";
    public static TA_NOT_MATCHED_TRUE_OUTBOUND_OPERATIONS_CHECKBOX = "Outbound checkbox mandatory as your outbound operation > 0%";

    public static TA_MISSING_SERVICE = 'Please fill up service list below with applicable service type.'
}

export class WorkflowStepType {
    public static WKFLW_STEP_TA_APPLICATION = "WKFLW_STEP_TA_APP";
    public static WKFLW_STEP_TA = "WKFLW_STEP_TA";
    public static WKFLW_STEP_TG_APPLICATION = "WKFLW_STEP_TG_APP";
    public static WKFLW_STEP_TG = "WKFLW_STEP_TG";
    public static WKFLW_STEP_CE = "WKFLW_STEP_CE";
}
export class WorkflowActionType {
    public static WKFLW_ACT_FWD = "WKFLW_ACT_FWD";
    public static WKFLW_ACT_APPR = "WKFLW_ACT_APPR";
    public static WKFLW_ACT_REJ = "WKFLW_ACT_REJ";
    public static WKFLW_ACT_REASSIGN = "WKFLW_ACT_REASSIGN";
    public static WKFLW_ACT_ROUTE = "WKFLW_ACT_ROUTE";
    public static WKFLW_ACT_SUBM = "WKFLW_ACT_SUBM";
    public static WKFLW_ACT_FOLLOW_UP = "WKFLW_ACT_FOLLOW_UP";
}

export let workflowAction = {
    approve: { name: 'approve', label: 'Approve', message: 'approved.' },
    forward: { name: 'approve', label: 'Forward for Approval', message: 'forwarded for approval.' },
    rfa: { name: 'rfa', label: 'Return for Action', message: 'returned to [TATG] for action.' },
    reject: { name: 'reject', label: 'Reject', message: 'rejected.' },
    save: { name: 'update', label: 'Save Changes', message: 'saved changes.' },
    route: { name: 'route', label: 'Route Back to...', message: ' routed back.' },
    rescind: { name: 'rescind', label: 'Rescind', message: 'rescinded.' },
    edit: { name: 'edit', label: 'Route back for edit', message: 'routed back for edit.' },
    submit: { name: 'submit', label: 'Forward for Approval', message: 'submitted for approval.' },
    routeOic: { name: 'route', label: 'Route Back to OIC', message: ' routed back to OIC.' },
    support: { name: 'approve', label: 'Support', message: 'supported.' },
    email: { name: 'email', label: 'Send Email', message: 'emailed.' },
    followup: { name: 'follow-up', label: 'Follow Up', message: 'returned to TG for action.' },
}

export let ShortfallDates = {
    dueDate: { fieldName: 'dueDate', title: 'Update Due Date', uri: '/update/due-dates', subtitle: 'Please select rectification due date.' },
    letterIssuedDate: { fieldName: 'letterIssuedDate', title: 'Update Letter Issued Date', uri: '/update/letter-isssued-dates', subtitle: 'Please select rectification letter issued date.' },
    extendedDueDate: { fieldName: 'extendedDueDate', title: 'Extend Due Date', uri: '/extend', message: 'Email will be sent out to TA upon successfully saved.', subtitle: 'Please select extended rectification due date.' },
}

export class TypeCategories {
    public static APP_RECOMMEND = "APP_RECOMMEND";
    public static MOD = "MOD";
    public static CE_ID_TYPE = "CE_ID_TYPE";
    public static CE_COMPLAINANT = "CE_COMPLAINANT";
    public static CE_OUTCOME = "CE_OUTCOME";
    public static CE_OUTCOME_IP = "CE_OUTCOME_IP";
    public static TG_AGE_GROUP = "TG_AGE_GROUP";
    public static TG_LANG = "TG_LANG";
    public static NAT = "NAT";
    public static CE_CASE_DOC = "CE_CASE_DOC";
    public static OCCUPATIONS = "OCCP";
    public static RESIDENTIAL_STATUS = "RESD";
    public static WORK_PASS_TYPE = "PASS";
}

export class StatusCategories {
    public static STAT_CE_CASE = "STAT_CE_CASE";
    public static STAT_PAYREQ = "STAT_PAYREQ";
}

export class RecommendationTypes {
    public static RECOMMEND_IMPOSE = "RECOMMEND_IMP";

    public static APP_RECOMMEND_APPR = "APP_RECOMMEND_APPR";
    public static APP_RECOMMEND_REJ = "APP_RECOMMEND_REJ";
}

export class mlptAllocationStatus {
    public static TG_MLPT_ALLOC_DRAFT = "TG_MLPT_ALLOC_DRAFT";
    public static TG_MLPT_ALLOC_PUB = "TG_MLPT_ALLOC_PUB";
}

export const PENDING_STATUS = [
    ApplicationStatuses.TA_APP_PENDING_PO,
    ApplicationStatuses.TA_APP_PENDING_VO,
    ApplicationStatuses.TA_APP_PEND_CNE_CO,
    ApplicationStatuses.TA_APP_PENDING_AO,
    ApplicationStatuses.TA_APP_PENDING_HOD,
    ApplicationStatuses.TA_APP_PENDING_HODIV,
    ApplicationStatuses.TG_APP_PENDING_PO,
    ApplicationStatuses.TG_APP_PENDING_AO,
    ApplicationStatuses.TG_APP_PENDING_HODIV,
    STAT_WKFLW.TA_WKFLW_PEND_PO,
    STAT_WKFLW.TA_WKFLW_PEND_VO,
    STAT_WKFLW.TA_WKFLW_PEND_AO,
    STAT_WKFLW.TA_WKFLW_PEND_HOD,
    STAT_WKFLW.TA_WKFLW_PEND_HODIV,
    STAT_WKFLW.TG_WKFLW_PEND_PO,
    STAT_WKFLW.TG_WKFLW_PEND_AO,
    STAT_WKFLW.TG_WKFLW_PEND_HODIV
];

export class Module {
    public static MODULE_TG_CREATION = "CREATION";
    public static MODULE_TG_RENEWAL = "RENEWAL";
    public static MODULE_TG_REPLACEMENT = "REPLACEMENT";
    public static MODULE_TG_PERSON_UPDATE = "PERSON_UPDATE";
    public static MODULE_TG_COURSE_CREATION = "COURSE_CREATION";
    public static MODULE_TG_ALL_APPLICATION = "ALL_LIC";
    public static MODULE_TG_ALL_COURSE_APPLICATION = "ALL_COURSE";
    public static MODULE_TG_STIPEND = "STIPEND";
}

export class cpfMedisave {
    public static CPF_MEDISAVE_YES = "CPF_MEDI_Y";
    public static CPF_MEDISAVE_NO = "CPF_MEDI_N";
    public static CPF_MEDISAVE_INVALID = "CPF_MEDI_I";
    public static CPF_MEDISAVE_ERROR = "CPF_MEDI_E";
}

export class TaStatuses {
    public static ACTIVE = ['TA_A', 'TA_PS', 'TA_I', 'TA_PR', 'TA_PRN'];
    public static INACTIVE = ['TA_C', 'TA_L'];
    public static SUSPEND = ['TA_S'];
    public static REVOKED = ['TA_R'];
    public static PENDING_RENEWAL = "TA_PRN";
}

export class TaTypes {
    public static STKHLD_KE = 'STKHLD_KE';
    public static TA_SHORTFALL_FULL = 'TA_SHORTFALL_FULL';
}

export class EmailPlaceHolder {
    public static CNE_UPON_TA_SUBMISSION = ['${app_link} - Application Link', '${app_type} - Application Type', '${app_ref} - Application Reference', '${app_submission_date} - Application Submission Date', '${ke_name} - KE Name', '${officer_name} - Officer Name', '${officer_department} - Officer Department', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static CNE_RECT_SHORTFALL_UPON_REJECT = ['${app_link} - Application Link', '${app_type} - Application Type', '${app_ref} - Application Reference', '${app_submission_date} - Application Submission Date', '${ke_name} - KE Name', '${rectification_due_date} - Rectification Due Date', '${officer_name} - Officer Name', '${officer_department} - Officer Department', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static CNE_UPON_TA_SUBMISSION_APPROVAL = ['${app_link} - Application Link', '${app_ref} - Application Reference', '${app_submission_date} - Application Submission Date', '${app_type} - Application Type', '${ke_name} - KE Name', '${officer_name} - Officer Name', '${officer_department} - Officer Department', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static CNE_UPON_TA_SUBMISSION_RFA = ['${app_link} - Application Link', '${app_ref} - Application Reference', '${app_submission_date} - Application Submission Date', '${app_type} - Application Type', '${ke_name} - KE Name', '${officer_name} - Officer Name', '${officer_department} - Officer Department', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static CNE_UPON_SHORTFALL_EXTENSION_APPROVAL = ['${app_link} - Application Link', '${ke_name} - KE Name', '${officer_name} - Officer Name', '${officer_department} - Officer Department', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static TG_MLPT_SLOT_ALLOCATED = ['${mlpt_allocations} - MLPT Allocations', '${tg_name} - TG Name'];
    public static TG_MLPT_SLOT_RESULT = ['${mlpt_results} - MLPT Results', '${tg_name} - TG Name'];
    public static USER_LOGIN_DETAILS = ['${login_id} - Login ID', '${password} - Password', '${user_name} - User Name'];
    public static TG_PORTAL_ID_ENABLED = ['${tg_name} - TG Name', '${tg_nric} - TG NRIC'];
    public static TG_APP_DRAFT = ['${app_link} - Application Link', '${tg_name} - TG Name'];
    public static TG_NEW_APP_SUBMIT = ['${app_link} - Application Link', '${tg_name} - TG Name'];
    public static PAYMENT_RECEIPT = ['${pay_amt} -  Payment Amount', '${pay_req_type} - Payment Request Type', '${pay_txn_id} - Payment Transation ID', '${pay_date} -  Payment Date'];
    public static TA_FILING_REMINDER_1 = ['${company_name} - Company Name', '${officer_name} - Officer Name'];
    public static TA_FILING_REMINDER_2 = ['${company_name} - Company Name', '${outstanding_submission} - Outstanding Submission', '${outstanding_submission_list} - Outstanding Submission List', '${officer_name} - Officer Name'];
    public static TA_FILING_REMINDER_3 = ['${company_name} - Company Name', '${outstanding_submission} - Outstanding Submission', '${outstanding_submission_with_date} - Outstanding Submission with Date', '${officer_name} - Officer Name'];
    public static TA_FILING_REMINDER_4 = ['${company_name} - Company Name', '${outstanding_submission} - Outstanding Submission', '${outstanding_submission_with_date} - Outstanding Submission with Date', '${officer_name} - Officer Name'];
    public static TA_FILING_REMINDER_5 = ['${company_name} - Company Name', '${outstanding_submission} - Outstanding Submission', '${outstanding_submission_with_date} - Outstanding Submission with Date', '${officer_name} - Officer Name'];
    public static TA_KE_DECLARATION = ['${app_link} - Application Link', '${ke_uin} - KE UIN', '${ta_name} - TA Name'];
    public static TA_LICENCE_CREATION_DRAFT = ['${app_link} - Application Link', '${ta_licence_creation_appname} - TA Licence Creation Application Name', '${ta_name} - TA Name', '${ta_uen} - TA Uen', '${ta_licence_creation_draft_expiry} - TA Licence Creation Draft Expiry'];
    public static TA_LICENCE_RENEWAL_REMINDER_MONTHLY = ['${licence_expiry_date} - Licence Expiry Date', '${renewal_exercise_end_date} - Renewal Exercise End Date'];
    public static TA_LICENCE_EXPIRY_NOTICE = ['${licence_expiry_date_after} - Licence Expiry Date After'];
    public static TA_UPON_APPROVAL = ['${app_link} - Application Link', '${app_ref} - Application Reference', '${app_type} - Application Type', '${ta_name} - TA Name'];
    public static TA_LICENCE_CREATION_APPROVAL = ['${app_link} - Application Link', '${ta_licence_creation_appname} - TA Licence Creation Application Name', '${ta_name} - TA Name', '${ta_uen} - TA Uen'];
    public static TA_LICENCE_RENEWAL_APPROVAL = ['${app_amount} - Application Amount', '${app_link} - Application Link', '${app_ref} - Application Reference', '${sec_main_app_amount} - Section Main Application Amount'];
    public static TA_LICENCE_STATUS_UPDATE = ['${ta_name} - TA Name', '${ta_licence_update_action} - TA Licence Update Action'];
    public static TA_LICENCE_CREATION_APPROVAL_IPA = ['${app_link} - Application Link', '${ta_licence_creation_appname} - TA Licence Creation Application Name', '${ta_name} - TA Name', '${ta_uen} - TA Uen'];
    public static TA_UPON_REJECTION = ['${app_link} - Application Link', '${app_ref} - Application Reference', '${app_type} - Application Type', '${ta_name} - TA Name'];
    public static TA_UPON_RFA = ['${app_link} - Application Link', '${app_ref} - Application Reference', '${app_type} - Application Type', '${ta_name} - TA Name'];
    public static TA_LICENCE_CREATION_SUBMISSION = ['${app_link} - Application Link', '${ta_licence_creation_appname} - TA Licence Creation Application Name', '${ta_name} - TA Name', '${ta_uen} - TA Uen'];
    public static TA_LICENCE_RENEWAL_REMINDER_START = ['${licence_expiry_date} - Licence Expiry Date', '${renewal_exercise_end_date} - Renewal Exercise End Date'];
    public static TA_LICENCE_RENEWAL_REMINDER_DEADLINE = ['${licence_expiry_date} - Licence Expiry Date', '${licence_expiry_date_after} - Licence Expiry Date After', '${renewal_exercise_late_date} - Renewal Exercise Late Date', '${renewal_exercise_start_date} - Renewal Exercise Start Date', '${renewal_exercise_year} - Renewal Exercise Year'];
    public static TA_APP_ADHOC_MA_SUBMISSION_NOTIFY = ['${app_type} - Application Type', '${ta_name} - TA Name', '${due_date} - Submission Due Date', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static TA_APP_ADHOC_DOC_SUBMISSION_NOTIFY = ['${app_type} - Application Type', '${ta_name} - TA Name', '${due_date} - Submission Due Date', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static TA_FILING_CONDITION_CHANGE_NOTIFY = ['${amended_filing_list} - List of submissions with amendment details', '${ta_name} - TA Name', '${stb_organisation} - STB Organisation', '${ta_support_email} - TA Support Email'];
    public static TG_LICENCE_CANCEL = ['${app_link} - Application Link', '${app_type} - Application Type', '${tg_name} - TG Name'];
    public static TG_APPLY_MLPT = ['${mlpt_start_date} - MLPT Start Date', '${mlpt_end_date} - MLPT End Date', '${tg_name} - TG Name', '${tg_test_language} - TG Test Language'];
    public static TG_UPON_APPROVAL = ['${app_link} - Application Link', '${app_ref} - Application Reference', '${app_type} - Application Type', '${tg_name} - TG Name'];
    public static TG_LICENCE_COLLECT = ['${app_type} - Application Type', '${collection_start_date} - Collection Start Date', '${collection_end_date} - Collection End Date', '${tg_name} - TG Name', '${tg_workpass_type} - TG Workpass Type'];
    public static TG_LICENCE_STATUS_UPDATE = ['${licence_update_action}', '${tg_name} - TG Name'];
    public static TG_UPON_REJECTION = ['${app_link} - Application Link', '${app_type} - Application Type', '${tg_name} - TG Name', '${tg_remark}'];
    public static TG_UPON_RFA = ['${app_link} - Application Link', '${app_type} - Application Type', '${tg_name} - TG Name', '${tg_remark}'];
    public static TG_CHECK_SCHEDULE_REMINDER = ['${period} - Period'];
    public static TA_CHECK_SCHEDULE_REMINDER = ['${period} - Period'];
    public static PAYMENT_REFUND_APPROVAL = ['${pay_ref_no} - Payment Reference No.', '${pay_ref_amt} - Payment Reference Amount'];
    public static CNE_CASE_LETTER_ISSUANCE = ['${defendant} - Defendant', '${infringement_list} - Infringement List'];
    public static CNE_COMPO_LETTER = ['${defendant} - Defendant', '${infringement_list} - Infringement List'];
    public static TG_LIC_EXPIRY_REMINDER_1 = ['${tg_salutation} - TG Salutation', '${tg_name} - TG Name', '${tg_lic_expiry_date} - TG Licence Expiry Date', '${tg_support_email} - TG Support Email'];
    //public static TG_LIC_EXPIRY_REMINDER_2 = ['${tg_salutation} - TG Salutation', '${tg_name} - TG Name', '${tg_lic_expiry_date} - TG Licence Expiry Date', '${tg_support_email} - TG Support Email'];
    public static TG_LIC_EXPIRY_REMINDER_3 = ['${tg_salutation} - TG Salutation', '${tg_name} - TG Name', '${tg_lic_expiry_date} - TG Licence Expiry Date', '${effective_date} - Effective Date (Expiry Date + 1 day)', '${tg_support_email} - TG Support Email'];
    public static TA_LICENCE_RENEWAL_APPROVAL_WAIVED = ['${app_link} - Application Link', '${app_ref} - Application Reference'];
    public static TG_COURSE_UPON_REJECTION = ['${app_link} - Application Link', '${app_type} - Application Type', '${tp_name} - TP Name', , '${tg_course_name} - TG Course Name', '${tg_remark}'];
    public static TG_COURSE_UPON_APPROVAL = ['${app_link} - Application Link', '${app_type} - Application Type', '${tp_name} - TP Name', '${tg_course_name} - TG Course Name'];
    public static TG_RENEWAL_SUBMISSION = ['${app_type} - Application Type', '${tg_name} - TG Name', '${app_ref} - Application Reference'];
    public static TG_LIC_EXPIRED_NOTIFICATION = ['${tg_salutation} - TG Salutation', '${tg_name} - TG Name', '${tg_lic_expiry_date} - TG Licence Expiry Date', '${current_date} - Current Date in format MMMM YYYY', '${effective_date} - Effective Date (Expiry Date + 1 day)', '${tg_support_email} - TG Support Email'];
    public static ATG_PRACTICAL_ASSESSMENT_FEE = ['${tg_salutation} - TG Salutation', '${tg_name} - TG Name', '${bill_ref_no} - Payment Bill Reference No', '${public_portal_url} - Trust Portal Payment Page', '${tg_support_email} - TG Support Email'];
    public static TG_LICENCE_SWITCH_TIER_FEE = ['${tg_salutation} - TG Salutation', '${tg_name} - TG Name', '${app_link} - Application Link', '${app_type} - Application Type', '${app_ref} - Application Reference', '${tg_support_email} - TG Support Email', '${specialisationArea} - Area of specialisation '];
}

export class LetterTemplatePlaceholder {
    public static TA_SHORTFALL_LETTER = ['${ke_name} - KE Name', '${ta_name} - TA Name', '${ta_uen} - TA Uen', '${licence_no} - Licence No.', '${shortfall_for} - Shortfall For', '${fye} - FYE Date', '${ta_mfr} - MFR', '${rectification_due_date} - Rectification Due Date', '${shortfall_amt} - Shortfall Amount', '${ta_support_email} - TA Support Email'];
}

export class ceOutcome {
    public static CE_OUTCOME_NOD = "CE_OUTCOME_NOD";
    public static CE_OUTCOME_NFA = "CE_OUTCOME_NFA";
    public static CE_OUTCOME_CAUTION = "CE_OUTCOME_CAUTION";
    public static CE_OUTCOME_CIRCULAR = "CE_OUTCOME_CIRCULAR";
    public static CE_OUTCOME_COUNSEL = "CE_OUTCOME_COUNSEL";
    public static CE_OUTCOME_AFP = "CE_OUTCOME_AFP";
    public static CE_OUTCOME_SUSPEND = "CE_OUTCOME_SUSPEND";
    public static CE_OUTCOME_REVOKE = "CE_OUTCOME_REVOKE";
    public static CE_OUTCOME_OPEN_IP = "CE_OUTCOME_OPEN_IP";
    public static CE_OUTCOME_TAG_IP = "CE_OUTCOME_TAG_IP";
    public static CE_OUTCOME_CONDITION = "CE_OUTCOME_CONDITION";
    public static CE_OUTCOME_KIV = "CE_OUTCOME_KIV";
    public static CE_OUTCOME_RECHECK = "CE_OUTCOME_RECHECK";
}

export class department {
    public static DEPARTMENT_TA = "DEPT_TA";
    public static DEPARTMENT_TG = "DEPT_TG";
}

export class caseType {
    public static TA = "TA";
    public static TG = "TG";
}

export class caseCategory {
    public static CASE = "case";
    public static IP = "ip";
}

export class ceCheckType {
    public static TA_CHECK_TATI = "TA_CHECK_TATI";
    public static TA_CHECK_ADHOC = "TA_CHECK_ADHOC";
    public static TA_CHECK_NON_RENEWAL = "TA_CHECK_NON_RENEWAL";
}

export class RevIpType {
    public static INTERNAL = "INTERNAL";
    public static EXTERNAL = "EXTERNAL";
}

export const RevIpTypes = [
    { key: "INTERNAL", label: 'STB' },
    { key: "EXTERNAL", label: 'External' }
]

export class AppealResult {
    public static CE_APPEAL_RESULT_PEND = "CE_APPEAL_RESULT_PEND";
    public static CE_APPEAL_RESULT_REJ = "CE_APPEAL_RESULT_REJ";
    public static CE_APPEAL_RESULT_ACD = "CE_APPEAL_RESULT_ACD";
    public static CE_APPEAL_RESULT_NO_APPEAL = "CE_APPEAL_RESULT_NO";
}

export class CeCaseStatus {
    public static CLOSED = "CE_CASE_CLOSED";
}

export class payReqStatus {
    public static PAYREQ_N = "PAYREQ_N";
    public static PAYREQ_W = "PAYREQ_W";
    public static PAYREQ_DISBURSED = "PAYREQ_DISBURSED";
}

export class tgScheduleLocation {
    public static OTHERS = "CE_TG_SCHEDULE_LOCATION_O";
}

export class TaFilingRequestTypes {
    public static TA_REQ_ADHOC_DOCS = "TA_REQ_ADHOC_DOCS";
    public static TA_REQ_ADHOC_MA = "TA_REQ_ADHOC_MA";
}

export let FileExt = {
    SIGN_DOC_ATTACHMENT: { ext: [".jpg", ".jpeg", ".gif", ".png", ".pdf"], errorMsg: 'Only jpg, jpeg, gif, png, pdf are allowed' },
}

export class TgInfoType {
    public static COMPLIMENT = "360_COMPLIMENT";
    public static COMPLAINT = "360_COMPLAINT";
    public static OTHERS = "360_OTHERS";
}

export let defaultTgFieldReportTemplates = [
    {
        label: 'Failing to Display Licence',
        value: 'On XXXDate at about XXXTime hrs, OEO XXXName and I spotted the above subject conducting guiding services to a group of ' +
            'XXXNationality tourists at XXXLocation.\n\n' +
            'Subject was seen gathering the group and provided commentary in XXXLanguage about XXXPlace. After observing for a while, ' +
            'it was realised that the subject was not donning any TG badge while guiding.\n\n' +
            'At about XXXTime hrs, we approached the subject at XXXLocation and established that he/she is a licensed TG by STB. ' +
            'I was then shown his/her badge bearing number XXXNumber and took a photograph of it in his/her presence. ' +
            'Subject claimed that he/she had XXXReasons.\n\n' +
            'I explained to him/her the importance of wearing his/her badge and that administrative actions may be taken against him/her ' +
            'for failing to do so. Subject acknowledged that he/she will comply with the regulations when providing guiding services ' +
            'in future.\n\n' +
            'This report is submitted for administrative actions.\n\nThat\'s all.'
    },
    {

        label: 'Unapproved Guiding Language',
        value: 'On XXXDate at about XXXTime hrs, OEO XXXName and I spotted the above subject conducting guiding services to a group of ' +
            'XXXNationality tourists at XXXLocation.\n\n' +
            'At about XXXTime hrs, we approached the subject and requested to look at his/her license. The subject complied and we were ' +
            'shown his/her TG badge bearing badge number XXXNumber. However, the approved language on the badge was XXXLanguage while the ' +
            'subject was seen giving commentary in XXXLanguage throughout the tour. I took a photograph of the subject\'s TG badge in ' +
            'his/her presence and explained that he/she is only supposed to guide in the approved language and that administrative actions' +
            'may be taken against him/her for failing to do so. Subject explained that he/she understands and will comply.\n\n' +
            'This report is submitted for administrative actions.\n\nThat\'s all.'
    },
    {
        label: 'Unlicensed TG',
        value: 'On XXXDay at around XXXTime hrs, OEO XXXName and I were deployed at XXXLocation to enforce the legislation under the purview ' +
            'of Singapore Tourism Board Act.\n\n' +
            'At about XXXTime hrs, I spotted a XXXMale/Female subject in XXXDescription, leading a group of about XXXNumber XXXNationality ' +
            'tourist at XXXLocation.\n\n' +
            'He/she was seen leading this group of tourists from XXXLocation and XXXLocation. He was observed to be providing commentary and ' +
            'explanation in XXXLanguage to them on the description, culture and architecture of the XXXplace. During the journey, the subject ' +
            'was seen to have continuously gestured towards the XXXObject to this group. Photographs of his/her actions were taken.\n\n' +
            'When the group arrived at XXXLocation, we approached the subject and identified ourselves as STB enforcement officers. ' +
            'During the conversation, the subject shared that this group was from XXXCountry and they will be in Singapore for a ' +
            'XXXNumber-day XXXTours/Holidays. During their stay here, he/she would be bringing them to various attractions for sightseeing ' +
            'and to explain on the XXXObject. Other locations that they will be visiting over the next XXXNumber days were XXXLocation. ' +
            'I explained that his/her services and actions could possible contravene the STB Act and would require his/her attendance ' +
            'at STB to assist in further investigation.\n\n' +
            'The subject was established to be XXXName bearing NRIC No. XXXNumber with contact number XXXNumber. ' +
            'An OTA was served for his/her attendance at STB on XXXDate at Time.\n\nThat\'s all.'
    },
    {
        label: 'Other Offences',
        value: ''
    }
];

export const paymentAmountCurrencyMaskConfig = {
    align: "left",
    allowNegative: true,
    allowZero: true,
    decimal: ".",
    precision: 2,
    prefix: "S$ ",
    suffix: "",
    thousands: ",",
    nullable: true
};

export let TaEmailBroadcastPlaceholders = [
    { key: 'ta_name', label: 'TA Name' },
    { key: 'ta_uen', label: 'TA UEN' },
    { key: 'Licence_no', label: 'Licence No' },
    { key: "Recipient_name", label: "Recipient's Name" },
    { key: "Recipient_home_address", label: "Recipient's Address" },
    { key: "Recipient_designation", label: "Recipient's Designation" },
    { key: 'ke_name', label: 'KE Name' },
    { key: 'Salutation_Sir_Mdm', label: 'Sir/Madam' },
    { key: 'Salutation_Mr_Ms', label: 'Mr./Ms.' },
    { key: 'Main_operating_address', label: 'Main licence operating address' },
    { key: 'Main_registered_address', label: 'Main licence registered address' },
    { key: 'Licence_type', label: 'Licence Type' },
    { key: 'Licence_status', label: 'Licence Status' },
    { key: 'Director_name', label: 'Director(s) Name' },
];

export const TgEmailBroadcastPlaceholders = [
    { key: 'tg_name', label: 'TG Name' },
];

export let MasterConfigDescription = [
    { key: 'ADDR', label: 'Type Of Address' },
    { key: 'APP_RECOMMEND', label: 'Type of Application Recommedation' },
    { key: 'BC', label: 'Type of Business Constitution (Business Entity Details)' },
    { key: 'BULLETIN', label: 'Type of Bulletin' },
    { key: 'CE_ACT', label: 'Type Of C&E Action' },
    { key: 'CE_APPEAL_RESULT', label: 'Type of CE Appeal Result' },
    { key: 'CE_CASE_DOC', label: 'Type Of C&E Case Document' },
    { key: 'CE_CHAPTER', label: 'Type Of C&E Chapter' },
    { key: 'CE_COMPLAINANT', label: 'Type Of C&E Complainant' },
    { key: 'CE_DOC', label: 'Type Of C&E Document' },
    { key: 'CE_ID_TYPE', label: 'Type Of C&E ID' },
    { key: 'CE_OEO', label: 'Type Of C&E OEO (Manage TG Checks Schedule)' },
    { key: 'CE_OUTCOME', label: 'Type Of C&E Outcome' },
    { key: 'CE_OUTCOME_IP', label: 'Type Of C&E Outcome IP' },
    { key: 'CE_SUB_OEO', label: 'Type Of C&E Sub OEO' },
    { key: 'CE_TA_FIELD_REPORT_CLASS', label: 'Classification/nature of case or compliance issues' },
    { key: 'CE_TASK', label: 'Type Of C&E Task' },
    { key: 'CE_TG_SCHEDULE_LOCATION', label: 'Schedule Location Of C&E TG (Manage TG Checks Schedule - Location)' },
    { key: 'CE_TG_SCHEDULE_MERIDIEM', label: 'Schedule Meridiem Of C&E TG (Manage TG Checks Schedule - Shift)' },
    { key: 'CE_WKFLW', label: 'C&E Workflow' },
    { key: 'CTRY', label: 'Country' },
    { key: 'DATA', label: 'Type Of Data' },
    { key: 'DEPT', label: 'Department' },
    { key: 'EDU', label: 'The Level of Education' },
    { key: 'EMAIL_COUNTDOWN_PREPOSITION', label: 'The Preposition Of Email Countdown' },
    { key: 'EMAIL_COUNTDOWN_UNIT', label: 'Unit Of Email Countdown' },
    { key: 'EMAIL_FREQUENCY', label: 'Email Frequency' },
    { key: 'FLAG', label: 'Flag(Y/N/NA)' },
    { key: 'FOB', label: 'Form Of Business (Business Entity Details)' },
    { key: 'MARI', label: 'Marital Status' },
    { key: 'MOD', label: 'Module' },
    { key: 'NAT', label: 'Nationality' },
    { key: 'OCCP', label: 'Occupation' },
    { key: 'PA', label: 'Type Of Principle Activities (Business Entity Details)' },
    { key: 'PASS', label: 'Type Of Work Pass' },
    { key: 'PAY_WKFLW', label: 'Payment Workflow' },
    { key: 'PAYREQ', label: 'Type Of Payment Request' },
    { key: 'PREM', label: 'Premise Type (Registered or Operating Address)' },
    { key: 'RACE', label: 'Race' },
    { key: 'RECOMMEND', label: 'Type Of Recommendation Action For Net Value Shortfall' },
    { key: 'RESD', label: 'Residential Status' },
    { key: 'SAL', label: 'Salutation' },
    { key: 'SEX', label: 'Sex' },
    { key: 'SOE', label: 'Status Of Establishment' },
    { key: 'STAT', label: 'Type of Status' },
    { key: 'STKHLD_ROLE', label: 'Roles of Stakeholder (Personnel Particulars - Role in Company)' },
    { key: 'TA_ADDR', label: 'Travel Agent Address Type' },
    { key: 'TA_APP', label: 'Travel Agent Application Type' },
    { key: 'TA_APPR', label: 'Travel Agent Approval Mode' },
    { key: 'TA_AREA', label: 'Area Of Focus For Travel Agent in ABPR' },
    { key: 'TA_AUDITOR_OPINION', label: 'Opinions of Travel Agent Auditor in AA' },
    { key: 'TA_CHECK', label: 'Travel Agent Check' },
    { key: 'TA_DOC', label: 'Document Type Of Travel Agent' },
    { key: 'TA_FUNC_ACT', label: 'Travel Agent Functions and Activities in ABPR' },
    { key: 'TA_LRTN', label: 'Travel Agent Licence Return Type' },
    { key: 'TA_RENEW_EX', label: 'Travel Agent Licence Renew Type' },
    { key: 'TA_RESN_CEASE', label: 'Travel Agent Licence Cessation Reasons' },
    { key: 'TA_RESN_REPLACE', label: 'Travel Agent Licence Replacement Reasons' },
    { key: 'TA_SEGM', label: 'Travel Agent Segmentation (Business Entity Details - Travel Agent Main Segmentation)' },
    { key: 'TA_SERV', label: 'Travel Agent Service Type in ABPR - Type of Service' },
    { key: 'TA_SHORTFALL', label: 'Type Of Travel Agent Shortfall' },
    { key: 'TA_TIER', label: 'Travel Agent Licence Tier' },
    { key: 'TA_WKFLW', label: 'Travel Agent Workflow' },
    { key: 'TG_AGE_GROUP', label: 'Tourist Guide Age Group' },
    { key: 'TG_APP', label: 'Tourist Guide Application Type' },
    { key: 'TG_AREA', label: 'Tourist Guide Areas Of Specialisation (TG Licence Application)' },
    { key: 'TG_CSE', label: 'Tourist Guide Course Type (Manage Course)' },
    { key: 'TG_CSE_CAT', label: 'Tourist Guide Course Category (Manage Course -  Category)' },
    { key: 'TG_DOC', label: 'Tourist Guide Document Type' },
    { key: 'TG_EMP', label: 'Tourist Guide Employment Source (Assignments - Source of Employment)' },
    { key: 'TG_ITINERARY', label: 'Tourist Guide Itinerary (Manage Candidate - Selected Itinerary)' },
    { key: 'TG_LANG', label: 'Tourist Guide Guiding Languages (Manage Course and Candidate)' },
    { key: 'TG_RESULT', label: 'Tourist Guide Course Result' },
    { key: 'TG_TIER', label: 'Tourist Guide Licence Tier' },
    { key: 'TG_TOUR', label: 'Tour Type Of Tourist Guide (Assignments - Type of Assignment)' },
    { key: 'TGLS_EDU', label: 'Education Qualification Level of Tourist Guide' },
    { key: 'TGLS_NAT', label: 'Nationality of Tourist Guide' },
    { key: 'TP_ATN', label: 'Training Provider Course Attendance' },
    { key: 'TP_CSE', label: 'Training Provider Course Type' },
    { key: 'USER', label: 'Type of User' },
    { key: 'WKFLW_ACT', label: 'Workflow Action Type' },
    { key: 'WKFLW_STEP', label: 'Workflow Step' },
    { key: 'EDH_ADDR', label: 'Type Of EDH Address' },
    { key: 'EDH_BC', label: 'EDH Business Constitution ' },
    { key: 'EDH_FOB', label: 'EDH Entity Type (Form of Business)' },
    { key: 'EDH_PA', label: 'EDH Principle Activity Code' },
    { key: 'EDH_ROLE', label: 'EDH Roles' },
    { key: 'EDH_SOE_BN', label: 'EDH Entity Status for Entity Type BN' },
    { key: 'EDH_SOE_CC', label: 'EDH Entity Status for Entity Type CC' },
    { key: 'EDH_SOE_CD', label: 'EDH Entity Status for Entity Type CD' },
    { key: 'EDH_SOE_CH', label: 'EDH Entity Status for Entity Type CH' },
    { key: 'EDH_SOE_CL', label: 'EDH Entity Status for Entity Type CL' },
    { key: 'EDH_SOE_CM', label: 'EDH Entity Status for Entity Type CM' },
    { key: 'EDH_SOE_CP', label: 'EDH Entity Status for Entity Type CP' },
    { key: 'EDH_SOE_CS', label: 'EDH Entity Status for Entity Type CS' },
    { key: 'EDH_SOE_CX', label: 'EDH Entity Status for Entity Type CX' },
    { key: 'EDH_SOE_DP', label: 'EDH Entity Status for Entity Type DP' },
    { key: 'EDH_SOE_FB', label: 'EDH Entity Status for Entity Type FB' },
    { key: 'EDH_SOE_FC', label: 'EDH Entity Status for Entity Type FC' },
    { key: 'EDH_SOE_FM', label: 'EDH Entity Status for Entity Type FM' },
    { key: 'EDH_SOE_FN', label: 'EDH Entity Status for Entity Type FN' },
    { key: 'EDH_SOE_FS', label: 'EDH Entity Status for Entity Type FS' },
    { key: 'EDH_SOE_GA', label: 'EDH Entity Status for Entity Type GA' },
    { key: 'EDH_SOE_GB', label: 'EDH Entity Status for Entity Type GB' },
    { key: 'EDH_SOE_GS', label: 'EDH Entity Status for Entity Type GS' },
    { key: 'EDH_SOE_HS', label: 'EDH Entity Status for Entity Type HS' },
    { key: 'EDH_SOE_LC', label: 'EDH Entity Status for Entity Type LC' },
    { key: 'EDH_SOE_LL', label: 'EDH Entity Status for Entity Type LL' },
    { key: 'EDH_SOE_LP', label: 'EDH Entity Status for Entity Type LP' },
    { key: 'EDH_SOE_MB', label: 'EDH Entity Status for Entity Type MB' },
    { key: 'EDH_SOE_MC', label: 'EDH Entity Status for Entity Type MC' },
    { key: 'EDH_SOE_MD', label: 'EDH Entity Status for Entity Type MD' },
    { key: 'EDH_SOE_MH', label: 'EDH Entity Status for Entity Type MH' },
    { key: 'EDH_SOE_MM', label: 'EDH Entity Status for Entity Type MM' },
    { key: 'EDH_SOE_MQ', label: 'EDH Entity Status for Entity Type MQ' },
    { key: 'EDH_SOE_NB', label: 'EDH Entity Status for Entity Type NB' },
    { key: 'EDH_SOE_NR', label: 'EDH Entity Status for Entity Type NR' },
    { key: 'EDH_SOE_PA', label: 'EDH Entity Status for Entity Type PA' },
    { key: 'EDH_SOE_PB', label: 'EDH Entity Status for Entity Type PB' },
    { key: 'EDH_SOE_PF', label: 'EDH Entity Status for Entity Type PF' },
    { key: 'EDH_SOE_RF', label: 'EDH Entity Status for Entity Type RF' },
    { key: 'EDH_SOE_RP', label: 'EDH Entity Status for Entity Type RP' },
    { key: 'EDH_SOE_SM', label: 'EDH Entity Status for Entity Type SM' },
    { key: 'EDH_SOE_SS', label: 'EDH Entity Status for Entity Type SS' },
    { key: 'EDH_SOE_TC', label: 'EDH Entity Status for Entity Type TC' },
    { key: 'EDH_SOE_TR', label: 'EDH Entity Status for Entity Type TR' },
    { key: 'EDH_SOE_TU', label: 'EDH Entity Status for Entity Type TU' },
    { key: 'EDH_SOE_UF', label: 'EDH Entity Status for Entity Type UF' },
    { key: 'EDH_SOE_UL', label: 'EDH Entity Status for Entity Type UL' },
    { key: 'EDH_SOE_VH', label: 'EDH Entity Status for Entity Type VH' },
    { key: 'EDH_SOE_XL', label: 'EDH Entity Status for Entity Type XL' },
    { key: 'MYINFO_CTRY', label: 'MyInfo Country' },
    { key: 'MYINFO_EDU', label: 'MyInfo Education Level' },
    { key: 'MYINFO_MARI', label: 'MyInfo Marital Status' },
    { key: 'MYINFO_NAT', label: 'MyInfo Nationality' },
    { key: 'MYINFO_OCCP', label: 'MyInfo Occupation' },
    { key: 'MYINFO_RACE', label: 'MyInfo Race' },
    { key: 'MYINFO_RESD', label: 'MyInfo Residential Status' },
    { key: 'MYINFO_SEX', label: 'MyInfo Sex' },
    { key: 'MYINFO_WPSTATUS', label: 'MyInfo WorkPass Status' },
    { key: 'STAT_ALERT', label: 'Alert Status' },
    { key: 'STAT_CE_CASE', label: 'Status Of C&E Case' },
    { key: 'STAT_CE_SUBMISSION', label: 'Status Of C&E Submission' },
    { key: 'STAT_CE_TA_', label: 'Status Of C&E Task' },
    { key: 'STAT_CE_TASK', label: 'Status Of C&E Task' },
    { key: 'STAT_CE_WKFLW', label: 'C&E Workflow Status' },
    { key: 'STAT_CPF_MEDI', label: 'CPF Medisave Status' },
    { key: 'STAT_DOC_TRF', label: 'Status Of Document Transfer' },
    { key: 'STAT_EMAIL', label: 'Email Status' },
    { key: 'STAT_JOB', label: 'Batch Job Status' },
    { key: 'STAT_LCRTN', label: 'Licence Returned Status' },
    { key: 'STAT_PAY_WKFLW', label: 'Payment Workflow Status' },
    { key: 'STAT_PAYREQ', label: 'Payment Request Status' },
    { key: 'STAT_PAYTXN', label: 'Payment Transaction Status' },
    { key: 'STAT_PRINT', label: 'Status Of Licence Printing' },
    { key: 'STAT_TA', label: 'Travel Agent Licence Status' },
    { key: 'STAT_TA_APP', label: 'Travel Agent Application Workflow Status' },
    { key: 'STAT_TA_BRANCH', label: 'Travel Agent Branch Licence Status' },
    { key: 'STAT_TA_FILING', label: 'Travel Agent Annual Filing Status' },
    { key: 'STAT_TA_WKFLW', label: 'Travel Agent Workflow Status' },
    { key: 'STAT_TG', label: 'Tourist Guide Licence Status' },
    { key: 'STAT_TG_APP', label: 'Tourist Guide Application Workflow Status' },
    { key: 'STAT_TG_CANDIDATE_RESULT', label: 'Tourist Guide Candidate Result Status' },
    { key: 'STAT_TG_CSE', label: 'Tourist Guide Course Status' },
    { key: 'STAT_TG_MLPT', label: 'Tourist Guide MLPT Result Status' },
    { key: 'STAT_TG_MLPT_ALLOC', label: 'Tourist Guide MLPT Allocation Status' },
    { key: 'STAT_TG_TYPE', label: 'Tourist Guide Licence Type' },
    { key: 'STAT_TG_WKFLW', label: 'Tourist Guide Workflow Status' },
    { key: 'STAT_TXF', label: 'File Transfer Status' },
    { key: 'STAT_TXF_PUB', label: 'File Transfer to Public Status' },
    { key: 'STAT_USER', label: 'User Status' },
    { key: 'PAY', label: 'Payment Method' }
];

export class TaLicenceTier {
    public static TA_TIER_G = "TA_TIER_G";
    public static TA_TIER_N = "TA_TIER_N";
}

export class ELicenceView {
    public static HIDE = 0;
    public static VIEW = 1;
}