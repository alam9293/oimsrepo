import { Directive, ElementRef, Input, SimpleChanges } from '@angular/core';
import { NgControl } from '@angular/forms';
import { WorkflowHelper } from '../helper';

@Directive({
    selector: '[disableControlIfNotPendingUser]'
})
export class DisableControlIfNotPendingUserDirective {

    @Input() set disableControlIfNotPendingUser(status: string) {
        if (status) {
            if (!this.workflowHelper.isPendingCurrentUser(status, null)) {
                this.ngControl.control.disable();
            }
        }
    }

    constructor(private ngControl: NgControl, private workflowHelper: WorkflowHelper) {
    }

    ngOnChanges(changes: SimpleChanges) {

    }

}