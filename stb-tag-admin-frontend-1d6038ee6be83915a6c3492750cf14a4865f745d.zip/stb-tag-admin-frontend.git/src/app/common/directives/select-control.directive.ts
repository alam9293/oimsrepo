import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

/**
 * This directive will check if the selected value of opiton is empty and set the value to null instead of undefined
 * 
 */
@Directive({
    selector: '[appSelectControl]'
})
export class SelectControlDirective {

    ngOnInit() { }

    constructor(private control: NgControl) { }

    @HostListener('selectionChange', ['$event'])
    someMethod() {
        if (this.control.value) {
        } else {
            this.control.control.setValue('');
        }
    }
}
