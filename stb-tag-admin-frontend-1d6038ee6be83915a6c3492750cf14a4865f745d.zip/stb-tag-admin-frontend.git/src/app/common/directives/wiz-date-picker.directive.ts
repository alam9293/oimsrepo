import { Directive, HostListener } from '@angular/core';
import { DateUtil } from '../helper';
import { NgControl } from '@angular/forms';

@Directive({
    selector: '[appWizDatePicker]'
})
export class WizDatePickerDirective {

    ngOnInit() { }

    constructor(private control: NgControl) { }

    @HostListener('dateChange', ['$event'])
    dateChange() {
        if (this.control.value && this.control.value.isValid()) {
            let serverDate = this.control.value.format(DateUtil.DATE_FORMAT);
            this.control.control.setValue(serverDate);
        } else {
            this.control.control.setValue('');
        }
    }
}
