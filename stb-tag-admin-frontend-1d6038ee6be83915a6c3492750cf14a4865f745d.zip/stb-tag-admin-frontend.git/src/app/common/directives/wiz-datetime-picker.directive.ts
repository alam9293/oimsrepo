import { Directive, HostListener } from '@angular/core';
import { DateUtil } from '../helper';
import { NgControl } from '@angular/forms';

@Directive({
    selector: '[appWizDatetimePicker]'
})
export class WizDatetimePickerDirective {

    ngOnInit() { }

    constructor(private control: NgControl) { }

    @HostListener('dateChange', ['$event'])
    dateChange() {
        if (this.control.value && this.control.value.isValid()) {
            let serverDate = this.control.value.format(DateUtil.DATETIME_FORMAT);
            this.control.control.setValue(serverDate);
        } else {
            this.control.control.setValue('');
        }
    }
}
