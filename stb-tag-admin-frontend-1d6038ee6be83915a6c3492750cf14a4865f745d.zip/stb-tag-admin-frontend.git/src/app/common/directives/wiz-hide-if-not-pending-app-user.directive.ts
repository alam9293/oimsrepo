import { Directive, ElementRef, Input, SimpleChanges } from '@angular/core';

import { WorkflowHelper } from '../helper';

@Directive({
    selector: '[appWizHideIfNotPendingAppUser]'
})
export class AppWizHideIfNotPendingAppUser {
    @Input('appWizHideIfNotPendingAppUser') toCheckRfa: string;
    @Input('appStatus') appStatus: string;
    constructor(
        private el: ElementRef,
        private workflowHelper: WorkflowHelper
    ) { }

    ngOnInit() {
    }
    

    ngOnChanges(changes: SimpleChanges) {
        if (this.appStatus) {
            if (!this.workflowHelper.isPendingCurrentUser(this.appStatus, this.toCheckRfa == "true")) {
                this.el.nativeElement.style.display = 'none';
            }
        }
    }
}
