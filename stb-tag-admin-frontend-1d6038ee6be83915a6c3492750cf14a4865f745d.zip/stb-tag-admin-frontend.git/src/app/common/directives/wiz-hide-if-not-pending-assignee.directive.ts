import { Directive, ElementRef, Input, SimpleChanges } from '@angular/core';
import { WorkflowHelper } from '../helper';
import { AuthenticationService } from '../services';

@Directive({
    selector: '[appWizHideIfNotPendingAssignee]'
})
export class AppWizHideIfNotPendingAssignee {
    @Input('appWizHideIfNotPendingAssignee') assigneeId: number;
    @Input('wfcStatus') wfcStatus: string;
    @Input('appWizHideIfUnauthorized') permission: string | string[]; // Required permission passed in

    constructor(
        private el: ElementRef,
        private workflowHelper: WorkflowHelper,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.workflowHelper.isFinalApprovedOrRejectedStatus(this.wfcStatus)) {
            if (this.authenticationService.hasPermission(this.permission)) {
                this.unhideElement();
            }
        } else {
            if (this.assigneeId) {
                if (this.workflowHelper.isPendingAssignee(this.wfcStatus, this.assigneeId) && this.authenticationService.hasPermission(this.permission)) {
                    this.unhideElement();
                } else {
                    this.el.nativeElement.style.display = 'none';
                }
            } else {
                if (this.authenticationService.hasPermission(this.permission)) {
                    this.unhideElement();
                }
            }
        }
    }

    unhideElement() {
        if (this.el.nativeElement.style.display === "none") {
            this.el.nativeElement.style.display = "inline-block";
        }
    }
}
