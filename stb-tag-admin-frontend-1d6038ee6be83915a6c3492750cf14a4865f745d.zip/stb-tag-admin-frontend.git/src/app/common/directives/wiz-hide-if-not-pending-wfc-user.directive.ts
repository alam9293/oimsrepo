import { Directive, ElementRef, Input, SimpleChanges } from '@angular/core';
import { WorkflowHelper } from '../helper';

@Directive({
    selector: '[appWizHideIfNotPendingWfcUser]'
})
export class AppWizHideIfNotPendingWfcUser {
    @Input('appWizHideIfNotPendingWfcUser') wfcStatus: string;
    constructor(
        private el: ElementRef,
        private workflowHelper: WorkflowHelper
    ) { }

    ngOnInit() {
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.wfcStatus) {
            if (!this.workflowHelper.isPendingCurrentUser(this.wfcStatus, null)) {
                this.el.nativeElement.style.display = 'none';
            } else {
                if (this.el.nativeElement.style.display === "none") {
                    this.el.nativeElement.style.display = "inline-block";
                }
            }
        }
    }
}
