import { Directive, ElementRef, OnInit, Input } from '@angular/core';
import { AuthenticationService } from '../services'
@Directive({
    selector: '[appWizHideIfUnauthorized]'
})
export class WizHideIfUnauthorizedDirective {
    @Input('appWizHideIfUnauthorized') permission: string | string[]; // Required permission passed in
    constructor(
        private el: ElementRef,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
        if (!this.authenticationService.hasPermission(this.permission)) {
            this.el.nativeElement.style.display = 'none';
        }
    }
}
