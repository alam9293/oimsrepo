import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../constants';
import { ErrorDialogService } from '../services/errordialog.service'
import { CommonService } from '../services';
import { FormBuilder } from '@angular/forms';
import * as FileSaver from 'file-saver';

@Injectable({
    providedIn: 'root'
})
export class FileUtil {

    constructor(private http: HttpClient, public errorDialogService: ErrorDialogService, private commonService: CommonService, private fb: FormBuilder,
    ) { }

    exportForDesktop(data: any, fileName: string) { //this method can use for desktop can download csv. for tablet the download outcome user does not like
        // const blob = new Blob([data], { type: 'application/octet-stream' });
        // var link = document.createElement('a');
        // link.href = window.URL.createObjectURL(blob);
        // link.download = fileName;
        // link.click();

        const blob = new Blob([data], { type: data.type });
        if (window.navigator.msSaveOrOpenBlob) //IE & Edge
        {
            //msSaveBlob only available for IE & Edge
            window.navigator.msSaveBlob(blob, fileName);
        }
        else //Chrome & FF
        {
            const url = window.URL.createObjectURL(blob);
            const anchor = document.createElement("a");
            anchor.href = url;
            anchor.download = fileName;
            document.body.appendChild(anchor); //For FF
            anchor.click();
            //It's better to remove the elem
            document.body.removeChild(anchor);
        }
    }

    export(data: any, fileName: string) { //this method can use for tablet but csv cannot download
        console.log('test');
        const blob = new Blob([data], { type: data.type });
        var lowercaseFileName = fileName.toLowerCase();
        if (fileName.match('msg')) {
            FileSaver.saveAs(blob, fileName);
        } else {
            if (window.navigator.msSaveOrOpenBlob) { //IE & Edge
                window.navigator.msSaveBlob(blob, fileName);
            } else if ((navigator.userAgent.match('CriOS') || navigator.userAgent.match('Chrome'))) { //Chrome iOS
                if ((lowercaseFileName.match('pdf') || lowercaseFileName.match('img') || lowercaseFileName.match('jpg') || lowercaseFileName.match('jpeg') || lowercaseFileName.match('gif') || lowercaseFileName.match('png') || lowercaseFileName.match('zip') || lowercaseFileName.match('jfif') || lowercaseFileName.match('bmp') || lowercaseFileName.match('docx') || lowercaseFileName.match('doc'))) {
                    var url = window.URL.createObjectURL(blob);
                    window.open(url, '_blank');
                } else {
                    var reader = new FileReader();
                    reader.onloadend = function () { window.open(reader.result as string); };
                    reader.readAsDataURL(blob);

                }
            } else if (window.navigator.userAgent.match(/iPad/i) || window.navigator.userAgent.match(/iPhone/i)) { //Safari & Opera iOS
                var url = window.URL.createObjectURL(blob);
                window.open(url, "_blank");
                //window.location.href = url;
            } else {  //include ff
                const url = window.URL.createObjectURL(blob);
                const anchor = document.createElement("a");
                anchor.href = url;
                anchor.download = fileName;
                document.body.appendChild(anchor); //For FF
                anchor.click();
                //It's better to remove the elem
                document.body.removeChild(anchor);
            }
        }
    }

    // formatBytes(bytes,decimals)
    formatBytes(a, b) { if (0 == a) return "0 Bytes"; var c = 1024, d = b || 2, e = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"], f = Math.floor(Math.log(a) / Math.log(c)); return parseFloat((a / Math.pow(c, f)).toFixed(d)) + " " + e[f] }


    downloadFile(file) {
        this.download(file.id, file.hash).subscribe(data => {
            this.export(data, file.originalName);
        });
    }

    download(fileId: number, hash): Observable<any> {
        if (fileId != null && hash != null) {
            return this.http.get<any>(cnst.apiBaseUrl + '/file/download/' + fileId + '/' + hash, { responseType: 'blob' as 'json' });
        }
    }

    upload(type: string, file: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildFormData(type, file);
        if (file.size <= maxFileSize) {
            return this.http.post(cnst.apiBaseUrl + '/file/upload', formData);
        } else {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
            });
            throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
        }
    }


    uploadAttachment(attachment: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildAttachmentFormData(attachment);
        if (attachment.file) {
            if (attachment.file.size <= maxFileSize) {
                return this.http.post(cnst.apiBaseUrl + '/file/upload', formData);
            } else {
                this.errorDialogService.openDialog({
                    reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
                });
                throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
            }
        } else {
            return this.http.post(cnst.apiBaseUrl + '/file/upload', formData);
        }
    }

    updateAttachment(dto) {
        return this.http.post(cnst.apiBaseUrl + '/file/upload/updateAttachment', dto);
    }
    updateFiles(dto) {
        return this.http.post(cnst.apiBaseUrl + '/file/upload/updateFiles', dto);
    }
    uploadAsAttachment(type: string, file: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildFormData(type, file);
        if (file.size <= maxFileSize) {
            return this.http.post(cnst.apiBaseUrl + '/file/upload/asAttachment', formData);
        } else {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
            });
            throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
        }
    }

    uploadToTransferToInternet(type: string, file: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildFormData(type, file);
        if (file.size <= maxFileSize) {
            return this.http.post(cnst.apiBaseUrl + '/file/upload/transfer-to-internet', formData);
        } else {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
            });
            throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
        }
    }

    uploadLicenceReturnDocs(licenceReturnBatchId: number, file: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildFormData(cnst.DocumentTypes.TA_DOC_OTHERS, file);
        if (file.size <= maxFileSize) {
            return this.http.post(cnst.apiBaseUrl + '/file/upload/licence-return-batch-file/' + licenceReturnBatchId, formData);
        } else {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
            });
            throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
        }
    }

    uploadBulletinFile(type: string, file: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildFormData(type, file);
        if (file.size <= maxFileSize) {
            return this.http.post(cnst.apiBaseUrl + '/file/upload/bulletin-file/', formData);
        } else {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
            });
            throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
        }
    }



    delete(deletedFiles: any) {
        return this.http.post(cnst.apiBaseUrl + '/file/delete', deletedFiles);
    }

    buildFormData(type, file) {

        var formDataObj = new FormData();
        formDataObj.append('docType', type);
        formDataObj.append('file', file);
        return formDataObj;
    }

    exceedMaxSize(file: any, definedMaxSize?: any) {
        if ((definedMaxSize && file.size >= definedMaxSize) || file.size > cnst.MAX_FILE_SIZE) {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot exceed " + this.formatBytes(definedMaxSize ? definedMaxSize : cnst.MAX_FILE_SIZE, 2) + "."
            });
            return true;
        }
        return false;
    }

    exceedMinSize(file: any) {
        if (file.size < cnst.MIN_FILE_SIZE) {
            this.errorDialogService.openDialog({
                reason: "Uploaded file size cannot be below " + this.formatBytes(cnst.MIN_FILE_SIZE, 2) + "."
            });
            return true;
        }
        return false;
    }

    saveAttachment(workflowId: number, attachment: any) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        var formData = this.buildAttachmentFormData(attachment);
        if (attachment.file) {
            if (attachment.file.size <= maxFileSize) {
                return this.http.post(cnst.apiBaseUrl + '/file/upload/workflow-file/' + workflowId, formData);
            } else {
                this.errorDialogService.openDialog({
                    reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
                });
                throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
            }
        } else {
            return this.http.post(cnst.apiBaseUrl + '/file/upload/workflow-file/' + workflowId, formData);
        }
    }

    saveWorkflowFiles(workflowId: number, attachments: any[], deletedIds: any[]) {
        var maxFileSize = cnst.MAX_FILE_SIZE;
        attachments.forEach(attachment => {
            if (attachment.file) {
                if (attachment.file.size <= maxFileSize) {

                } else {
                    this.errorDialogService.openDialog({
                        reason: "Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + "."
                    });
                    throw new Error("Uploaded file size cannot exceed " + this.formatBytes(maxFileSize, 2) + ".");
                }
            }
        });
        var obj = { workflowFiles: [], deletedWorkflowFileIds: deletedIds };
        attachments.forEach(attachment => {
            obj.workflowFiles.push({ workflowFileId: attachment.workflowFileId, description: attachment.description, docTypeCode: attachment.docTypeCode });
        });

        return this.http.post(cnst.apiBaseUrl + '/file/upload/workflow-files/' + workflowId, obj);
    }

    deleteAttachment(deletedIds: any) {
        return this.http.post(cnst.apiBaseUrl + '/file/delete/workflow-file', deletedIds);
    }

    buildAttachmentFormData(attachment: any) {
        var formData = new FormData();
        Object.keys(attachment).forEach(key => {
            if (attachment[key] != null) {
                formData.append(key, attachment[key]);
            }
        });
        return formData;
    }

    populateAttachmentFormGroup(x) {
        return this.fb.group({
            id: x ? x.id : [],
            originalName: x ? x.originalName : [],
            description: x ? x.description : [],
            createdDate: x ? x.createdDate : [],
            createdBy: x ? x.createdBy : [],
            docType: x ? x.docType : [],
            hash: x ? x.hash : [],
            readableFileSize: x ? x.readableFileSize : []
        });
    }
}