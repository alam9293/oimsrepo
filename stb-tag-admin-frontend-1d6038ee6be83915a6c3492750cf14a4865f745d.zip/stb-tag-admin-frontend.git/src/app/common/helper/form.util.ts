import { Injectable } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators, ValidatorFn, FormArray, FormControl } from '@angular/forms';

import * as cnst from '../constants';
import { NumeralUtil } from './numeral.util';
import { CommonService } from '../services';

@Injectable({
    providedIn: 'root'
})
export class FormUtil {

    constructor(private commonService: CommonService,) { }

    /**
  * Marks all controls in a form group as touched
  * @param formGroup - The form group to touch
  */
    markFormGroupTouched(formGroup: FormGroup) {
        formGroup.markAsTouched();
        Object.keys(formGroup.controls).map(x => formGroup.controls[x]).forEach(control => {
            control.markAsTouched();

            if ((control as FormGroup).controls) {
                this.markFormGroupTouched((control as FormGroup));
            }
        });
    }

    unionList(list, key, unionMap: Map<String, String>) {
        var retVal = "";
        if (list) {
            var listSize = JSON.stringify(list).replace("[]", "").length;
            if (listSize && key) {
                list.forEach(element => {
                    if (element.key == key) {
                        retVal = element.label;
                    }
                });

                //for inactive type
                if (retVal === "") {
                    if (unionMap.get(key) == null) {
                        unionMap.set(key, key);
                        this.commonService.getFormList(key).subscribe(data => {
                            if (data[0]) {
                                list.push(data[0]);
                            }
                        });
                    }
                }
            }
        }
        return list;
    }

    unionStatusList(list, key, unionMap: Map<String, String>) {
        var retVal = "";
        if (list) {
            var listSize = JSON.stringify(list).replace("[]", "").length;
            if (listSize && key) {
                list.forEach(element => {
                    if (element.key == key) {
                        retVal = element.label;
                    }
                });

                //for inactive status
                if (retVal === "") {
                    if (unionMap.get(key) == null) {
                        unionMap.set(key, key);
                        this.commonService.getFormStatusList(key).subscribe(data => {
                            if (data[0]) {
                                list.push(data[0]);
                            }
                        });
                    }
                }
            }
        }
        return list;
    }

    unionArrayList(list, key, tempList: Map<String, String>) {
        if (list) {
            var listSize = JSON.stringify(list).replace("[]", "").length;
            if (listSize && key) {
                key.forEach(keyElement => {
                    var retVal = "";
                    list.forEach(element => {
                        if (element.key == keyElement) {
                            retVal = element.label;
                        }
                    });

                    //for inactive status
                    if (retVal === "" && keyElement) {
                        if (tempList.get(keyElement) == null) {
                            tempList.set(keyElement, keyElement);
                            this.commonService.getFormList(keyElement).subscribe(data => {
                                if (data[0]) {
                                    list.push(data[0]);
                                }
                            });
                        }
                    }
                });
            }
        }
        return list;
    }

    /**
    * Return the label of the code
    * @param list - The code list
    *  @param key - The code 
    */
    getLabelFromKey(list, key) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.key == key) {
                    retVal = element.label;
                }
            });
        }
        return retVal;
    }

    getDataFromKey(list, key) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.key == key) {
                    retVal = element.data;
                }
            });
        }
        return retVal;
    }

    setDisplayValueWhenNull(value) {

        return this.setDisplayValueWhenNullWithValue(value, null);
    }

    setDisplayValueWhenNullWithValue(value, displayValue) {
        if (!displayValue) {
            displayValue = '-';
        }

        if (!value) {
            value = displayValue;
        }
        return value;
    }

    /**
    * Return the form group for file dto
    * @param fb - FormBuilder
    *  @param isRequired - is file is a required document
    */
    initiateFileForm(fb: FormBuilder, isRequired: any) {
        return (fb.group({
            id: [''],
            publicFileId: [''],
            originalName: ['', isRequired ? Validators.required : ''],
            processedName: [''],
            docType: [''],
            extension: [''],
            path: [''],
            size: [''],
            hash: [''],
            documentInstructions: [''],
            documentTypeLabel: [''],
            description: [''],
            readableFileSize: [''],
            hasTemplate: [],
        })
        )
    }

    /**
   * Return the form group for attachment dto
   * @param fb - FormBuilder
   *  @param isRequired - is file is a required document
   */
    initiateAttachmentDtoForm(fb: FormBuilder, isRequired: any) {
        return (fb.group({
            id: [''],
            workflowFileId: [''],
            publicFileId: [''],
            originalName: ['', isRequired ? Validators.required : ''],
            processedName: [''],
            docTypeCode: [''],
            extension: [''],
            path: [''],
            size: [''],
            hash: [''],
            documentInstructions: [''],
            documentTypeLabel: [''],
            description: [''],
            readableFileSize: [''],
            createdBy: [''],
            createdDate: [],
        })
        )
    }

    /**
  * Return the form group for file dto
  * @param fb - FormBuilder
  *  @param x - file data
  */
    populateAttachmentFormGroup(fb: FormBuilder, x) {
        return fb.group({
            id: x ? x.id : [],
            originalName: x ? x.originalName : [],
            description: x ? x.description : [],
            createdDate: x ? x.createdDate : [],
            createdBy: x ? x.createdBy : [],
            docType: x ? x.docType : [],
            hash: x ? x.hash : [],
            readableFileSize: x ? x.readableFileSize : []
        });
    }

    clearFileDetails(file) {
        file.get('id').patchValue('');
        file.get('originalName').patchValue('');
        file.get('processedName').patchValue('');
        file.get('publicFileId').patchValue('');
        file.get('path').patchValue('');
        file.get('readableFileSize').patchValue('');
        file.get('size').patchValue('');
    }

    getFormValidationErrors(form: FormGroup) {
        Object.keys(form.controls).forEach(key => {
            const controlErrors: ValidationErrors = form.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }

    // listableForm(fb: FormBuilder) {
    //     return (
    //         fb.group({
    //             key: ['', Validators.required],
    //             label: [''],
    //             otherLabel: [''],
    //             type: []
    //         })
    //     )
    // }

    listableFormWithValue(fb: FormBuilder, listableDto) {
        if (listableDto) {
            return fb.group({
                key: [listableDto.key, Validators.required],
                label: [listableDto.label],
                otherLabel: [listableDto.otherLabel],
                type: [listableDto.type]
            });
        }
        else {
            return fb.group({
                key: ['', Validators.required],
                label: [''],
                otherLabel: [''],
                type: []
            });
        }
    }

    listableFormWithValueNoValidation(fb: FormBuilder, listableDto) {
        if (listableDto) {
            return fb.group({
                key: [listableDto.key],
                label: [listableDto.label],
                otherLabel: [listableDto.otherLabel],
                type: [listableDto.type]
            });
        }
        else {
            return fb.group({
                key: [''],
                label: [''],
                otherLabel: [''],
                type: []
            });
        }
    }

    listableForm(fb: FormBuilder, req: boolean) {
        return (
            fb.group({
                key: ['', req ? Validators.required : null],
                label: [''],
                otherLabel: [''],
                type: []
            })
        )
    }

    addressFormOptional(fb: FormBuilder, isReq) {
        return (
            fb.group({
                addressId: [''],
                postal: [''],
                street: ['', isReq ? Validators.required : null],
                building: ['',],
                block: ['', isReq ? Validators.required : null],
                floor: ['',],
                unit: [],
                premisesType: this.listableForm(fb, isReq),
                type: this.listableForm(fb, isReq),
                foreignLine1: [],
                foreignLine2: [],
                foreignLine3: []
            })
        )
    }

    idComparator(o1: any, o2: any): boolean {
        if (o1 && o2) {
            return o1.id === o2.id;
        } else {
            return false;
        }
    }

    keyComparator(o1: any, o2: any): boolean {
        if (o1 && o2) {
            return o1.id === o2.id;
        } else {
            return false;
        }
    }

    /**
* Update all controls in a form group
* @param formGroup - The form group to update
*/
    validateAllFormControl(formGroup: FormGroup) {
        Object.keys(formGroup.controls).map(x => formGroup.controls[x]).forEach(control => {
            control.updateValueAndValidity();
            if ((control as FormGroup).controls) {
                this.validateAllFormControl((control as FormGroup));
            }
        });
    }

    validateAllFormFields(formGroup: FormGroup) {         //{1}
        Object.keys(formGroup.controls).forEach(field => {  //{2}
            const control = formGroup.get(field);             //{3}
            if (control instanceof FormControl) {             //{4}
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup) {        //{5}
                this.validateAllFormFields(control);            //{6}
            }
        });
    }

    removeAllValidators(form: FormGroup) {
        Object.keys(form.controls).map(x => form.controls[x]).forEach(control => {
            control.clearValidators();
            control.updateValueAndValidity();
            if ((control as FormGroup).controls) {
                this.removeAllValidators((control as FormGroup));
            }
        });
        // for (const key in form.controls) {
        //      form.get(key).clearValidators();
        //      form.get(key).updateValueAndValidity();

        // }
    }
}

export function ValidateRichTextIsEmpty(control: AbstractControl) {
    if (control.value && control.value.replace("<p>", "").replace("</p>", "").replace("<br>", "") == "") {
        return { required: true };
    }

    return null;
}

export function ValidateRichTextMaxLengthVarChar(control: AbstractControl) {
    if (control.value && control.value.length > cnst.maxLengthStr) {
        return { maxlength: true };
    }
    return null;
}

export function ValidateRichTextMaxLengthText(control: AbstractControl) {
    if (control.value && control.value.length > cnst.maxLengthText) {
        return { maxlength: true };
    }
    return null;
}

export function ValidateDigitMaxLength(control: AbstractControl) {
    var value = control.value;
    if (value) {
        value = '' + value;
        value = value.replace(NumeralUtil.ALPHABET_CHAR, "");
        value = value.replace(NumeralUtil.SPECIAL_CHAR, "");
        value = value.replace(/[-,]/g, '');

        if (value.length > 16) {
            return { maxlength: true };
        }
    }
    return null;
}

export function ValidateEmail(control: AbstractControl) {
    var value = control.value;
    if (value) {
        var local = value.split("@")[0];
        var atSign = value.split("@");
        var domain = value.split("@")[1];
        if (atSign.length != 2) {
            return { invalidEmailFormat: true };
        } else if (local.length > cnst.SgdrmEmailFieldsSize.LOCAL || domain.length > cnst.SgdrmEmailFieldsSize.DOMAIN) {
            return { invalidEmailLength: true };
        } else {
            return null
        }
    }
    return null;
}

export function MinSelectedCheckboxes(minLength) {
    const validator: ValidatorFn = (formArray: FormArray) => {
        const totalSelected = formArray.controls
            .map(control => control.value)
            .reduce((prev, next) => next ? prev + next : prev, 0);
        return totalSelected >= minLength ? null : { 'required': true };
    };

    return validator;
}
