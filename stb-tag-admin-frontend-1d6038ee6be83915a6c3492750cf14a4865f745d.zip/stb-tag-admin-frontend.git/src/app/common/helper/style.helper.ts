import { Injectable } from '@angular/core';
import * as cnst from '../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class StyleHelper {
    cnst = cnst;

    constructor() { }

    statusCodeCssClass(statusCode: String) {
        if (!statusCode) {
            return;
        }
        // return css class based on status type
        switch (statusCode) {
            case cnst.ApplicationStatuses.TA_APP_APPROVED:
            case cnst.ApplicationStatuses.TG_APP_APPROVED:
            case cnst.STAT_WKFLW.TG_WKFLW_APPR:
            case cnst.STAT_WKFLW.TA_WKFLW_APPR:
            case 'Yes':
                return 'approved';
            case cnst.ApplicationStatuses.TA_APP_REJECTED:
            case cnst.ApplicationStatuses.TG_APP_REJECTED:
            case cnst.STAT_WKFLW.TG_WKFLW_REJ:
            case cnst.STAT_WKFLW.TA_WKFLW_REJ:
            case 'No':
                return 'rejected';
            case cnst.ApplicationStatuses.TG_APP_RFA:
            case cnst.ApplicationStatuses.TA_APP_RFA:
                return 'rfa';
            default: return 'pending';
        }
    }

    statusCssClass(statusCode: String) {
        if (!statusCode) {
            return;
        }
        // return css class based on status type
        switch (statusCode) {
            case 'Yes':
                return 'approved';
            case 'No':
                return 'rejected';
            default: return 'na';
        }
    }

    taLicenceStatusCss(licenceStatusCode: string) {
        if (cnst.TaStatuses.ACTIVE.includes(licenceStatusCode)) {
            return 'active';
        } else if (cnst.TaStatuses.INACTIVE.includes(licenceStatusCode)) {
            return 'ceased';
        } else if (cnst.TaStatuses.SUSPEND.includes(licenceStatusCode)) {
            return 'suspended';
        } else if (cnst.TaStatuses.REVOKED.includes(licenceStatusCode)) {
            return 'revoked';
        }
        return 'active';
    }

    taLicencePrintStatusCss(licencePrintStatusCode: string) {
        switch (licencePrintStatusCode) {
            case cnst.TaLicencePrintStatuses.TA_PRINT_PENDING:
                return 'pending';
            case cnst.TaLicencePrintStatuses.TA_PRINT_PRINTED:
                return 'approved';
            default: return 'not-required';
        }
    }

}
