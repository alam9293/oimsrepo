import { Injectable } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';

@Injectable({
    providedIn: 'root'
})
export class TaFormHelperUtil {

    constructor() { }

    minLengthArray(min: number) {
        return (c: AbstractControl): { [key: string]: any } => {
            if (c.value.length >= min)
                return null;
            return { 'minLengthArray': { valid: false } };
        }
    }

    duplicatedSelectionValidator(selected: string): ValidatorFn {
        return (control: FormArray): { [key: string]: any } => {
            const array = control.value;
            let servicesList = [];
            let sortedServicesList = [];
            if (array && array.length > 1) {
                for (var i = 0; i < (array.length); i++) {
                    if (array[i] && array[i][selected].key) {
                        servicesList.push(array[i][selected].key);
                    }
                }
                sortedServicesList = servicesList.slice().sort();
                for (var i = 0; i < sortedServicesList.length - 1; i++) {
                    if (sortedServicesList[i + 1] == sortedServicesList[i]) {
                        return { 'duplicatedSelectionError': true };
                    }
                }
            } else {
                return null;
            }
        }
    }

    missingSelectionValidator(operationAmount: string, selection: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let option = group.controls[selection];
            let opAmount = group.controls[operationAmount];
            if (opAmount) {
                if ((parseInt(opAmount.value, 10) > 0 && option.value === '')) {
                    group.controls[selection].setErrors({ 'required': true });
                    return {
                        'requiredSelectionError': true
                    };
                } else if ((parseInt(opAmount.value, 10) == 0 || opAmount.value == null) && option.value === true) {
                    group.controls[selection].setErrors({ 'invalid': true });
                    return {
                        'invalidSelectionError': true
                    };
                }
                else {
                    if (option.errors && (option.errors['required'] || option.errors['invalid'])) {
                        option.updateValueAndValidity();
                    }
                    return null;
                }
            }
        }
    }

    bothZeroValuesValidator(selected1: string, selected2: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            if (group.controls[selected1] && group.controls[selected2]) {
                const value1 = (group.controls[selected1].value ? group.controls[selected1].value : 0);
                const value2 = (group.controls[selected2].value ? group.controls[selected2].value : 0);
                if ((parseInt(value1, 10) == 0) && ((parseInt(value2, 10) == 0))) {
                    group.controls[selected1].setErrors({ 'required': true });
                    group.controls[selected2].setErrors({ 'required': true });
                    return {
                        [errorName]: true
                    };
                } else {
                    if (group.controls[selected1].errors && group.controls[selected1].errors['required']) {
                        group.controls[selected1].setErrors({ 'required': null });
                        group.controls[selected1].updateValueAndValidity();
                    }
                    if (group.controls[selected2].errors && group.controls[selected2].errors['required']) {
                        group.controls[selected2].setErrors({ 'required': null });
                        group.controls[selected2].updateValueAndValidity();
                    }
                }
            }

            return null;
        }
    }

    crossZeroValuesValidator(compareValue: string, base: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            var value1 = group.controls[compareValue].value;
            var baseValue = group.controls[base];
            if (value1 instanceof String) {
            } else {
                value1 = '' + value1; // convert to string
            }
            const num1 = (value1).replace(/,/g, '');
            if (value1 && baseValue) {
                if ((parseInt(num1) > 0) && ((parseFloat(baseValue.value) == 0))) {
                    return {
                        [errorName + 'NotZeroError']: true
                    };
                } else if ((parseInt(num1) == 0) && ((parseFloat(baseValue.value) > 0))) {
                    return {
                        [errorName + 'RequireValueError']: true
                    };
                }
            }
            return null;
        }
    }


    totalValidator(selected: any): ValidatorFn {
        return (control: FormArray): { [key: string]: any } => {
            const array = control.value;
            let total = 0;
            if (array) {
                for (var i = 0; i < array.length; i++) {
                    total = total + array[i][selected];
                }
                if (total != 100) {
                    var errorType = selected + 'TotalError'
                    return {
                        [errorType]: true
                    };
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
    };

    zeroValuePercentageValidator(baseValue: string, formList: string, formName: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let sumInbound = 0;
            let ctrl = <FormArray>group.controls[formList];

            if (ctrl) {
                for (var i = 0; i < ctrl.length; i++) {
                    sumInbound = sumInbound + (ctrl.value[i][formName] ? ctrl.value[i][formName] : 0);
                }
                let sum = group.controls[baseValue];
                let sumCount = parseFloat(sum.value) ? parseFloat(sum.value).toFixed(2) : 0;
                //check if operation = 0, the sum of service operation % should be 0
                if ((!isNaN(parseFloat(sum.value))) && sumCount == 0 && parseFloat(sumInbound.toFixed(2)) != 0) {
                    return {
                        [errorName]: true
                    };
                }
            }
            return null;
        }
    }

    hundredValuePercentageValidator(baseValue: string, formList: string, formName: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let sumInbound = 0;
            let ctrl = <FormArray>group.controls[formList];

            if (ctrl) {
                for (var i = 0; i < ctrl.length; i++) {
                    sumInbound = sumInbound + (ctrl.value[i][formName] ? ctrl.value[i][formName] : 0);
                }
                let sum = group.controls[baseValue];
                let sumCount = parseFloat(sum.value) ? parseFloat(sum.value).toFixed(2) : 0;
                //check if operation > 0, the sum of service operation % should be 100
                if ((!isNaN(parseFloat(sum.value))) && sumCount > 0 && parseFloat(sumInbound.toFixed(2)) != 100) {
                    return {
                        [errorName]: true
                    };
                }
            }
            return null;
        }
    }

    selectionCrossValueValidator(operationAmount: AbstractControl, ): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let opAmount = operationAmount.value;
            let option = group.value;
            if ((parseInt(opAmount, 10) == 0) && (option === true)) {
                group.setErrors({ 'invalid': true });
                return {
                    'invalid': true
                };
            } else {
                if (group.errors && group.errors['invalid']) {
                    group.setErrors({ 'invalid': null });
                    group.updateValueAndValidity();
                }
                return null;
            }
        }
    }

    matchingInboundOutboundCheckValidator(boundSum: string, boundKey: string, formName: string, errorGroup: string, errorZeroGroup: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let checkedSum = 0;
            let ctrl = <FormArray>group.controls[boundKey];
            ctrl.controls.forEach(x => {
                checkedSum += x.get(formName).value == true ? 1 : 0;
            });
            let checked = checkedSum > 0;
            let sum = group.controls[boundSum].value;
            if ((!isNaN(parseInt(sum, 10))) && sum == 0 && ctrl.controls.length > 0 && checked != false) {
                return {
                    [errorZeroGroup]: true
                };
            }
            else if ((!isNaN(parseInt(sum, 10))) && sum != 0 && ctrl.controls.length > 0 && checked == false) {
                return {
                    [errorGroup]: true
                };
            }
            else {
                return null;
            }
        }
    }

    passengerHandledRequiredValidator(baseValue: string, boundKey: string, formName: string, errorGroup: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let array = <FormArray>group.controls[boundKey];
            if (array.controls) {
                let totalPer = array.controls.reduce(function (prev, cur) {
                    return prev + (cur.get(formName).value ? cur.get(formName).value : 0);
                }, 0);

                if (totalPer == 0 && group.controls[baseValue].value > 0) {
                    return {
                        [errorGroup]: true
                    };
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
    }

    passengerHandledNotRequiredValidator(baseValue: string, boundKey: string, formName: string, errorGroup: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let array = <FormArray>group.controls[boundKey];
            if (array.controls) {
                let totalPer = array.controls.reduce(function (prev, cur) {
                    return prev + (cur.get(formName).value ? cur.get(formName).value : 0);
                }, 0);

                if (totalPer > 0 && group.controls[baseValue].value == 0) {
                    return {
                        [errorGroup]: true
                    };
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
    }
}


