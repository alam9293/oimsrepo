import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class VersionCheckInterceptor implements HttpInterceptor {

    constructor() { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(tap((resp: HttpEvent<any>) => {
            if (resp instanceof HttpResponse) {
                this.cacheHeader(resp.headers.get("Version-Check"), "VC-");
                this.cacheHeader(resp.headers.get("Version-Check-Listing"), "VCL-");
            }
        }));
    }

    // e.g. Version-Check: Application,EncryptedApplicationIdVersion,TgLicenceCreation,EncryptedTgLicenceCreationIdVersion
    cacheHeader(headerValue: string, keyPrefix: string) {
        if (headerValue) {
            let values = headerValue.split(",");
            for (let i = 0; i < values.length; i++) {
                sessionStorage.setItem(keyPrefix + values[i], values[++i]);
            }
        }
    }
}