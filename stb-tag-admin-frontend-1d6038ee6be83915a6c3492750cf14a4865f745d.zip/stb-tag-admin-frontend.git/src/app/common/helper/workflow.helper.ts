import { SelectionModel } from '@angular/cdk/collections';
import { Injectable } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

import * as cnst from '../constants';
import { User } from '../models';
import { AssigneeDialogComponent } from '../modules/assignee-dialog/assignee-dialog.component';
import { AuthenticationService, CommonService } from '../services';
import { WorkflowService } from '../services/workflow.service';

@Injectable({
    providedIn: 'root'
})
export class WorkflowHelper {

    selection = new SelectionModel<any>(true, []);

    constructor(private authenticationService: AuthenticationService,
        private router: Router,
        private dialog: MatDialog,
        private commonService: CommonService,
        private snackBar: MatSnackBar,
        private workflowService: WorkflowService,) { }

    public get currentUserValue(): User {
        return this.authenticationService.currentUserValue;
    }

    public get currentUserAppPendingStatus(): string[] {
        let roleCode: string = this.currentUserValue.selectedRole.key;
        switch (roleCode) {
            case cnst.ApplicationRoles.TA_PO: return [cnst.ApplicationStatuses.TA_APP_PENDING_PO];
            case cnst.ApplicationRoles.TA_VO: return [cnst.ApplicationStatuses.TA_APP_PENDING_VO];
            case cnst.ApplicationRoles.CNE_CO: return [cnst.ApplicationStatuses.TA_APP_PEND_CNE_CO];
            case cnst.ApplicationRoles.TA_AO: return [cnst.ApplicationStatuses.TA_APP_PENDING_AO];
            case cnst.ApplicationRoles.TA_HOD: return [cnst.ApplicationStatuses.TA_APP_PENDING_HOD];
            case cnst.ApplicationRoles.TG_PO: return [cnst.ApplicationStatuses.TG_APP_PENDING_PO];
            case cnst.ApplicationRoles.TG_AO: return [cnst.ApplicationStatuses.TG_APP_PENDING_AO];
            case cnst.ApplicationRoles.HODIV: return [cnst.ApplicationStatuses.TA_APP_PENDING_HODIV, cnst.ApplicationStatuses.TG_APP_PENDING_HODIV];
            default: return null;
        }
    }

    public get currentUserWfcPendingStatus(): string[] {
        let roleCode: string = this.currentUserValue.selectedRole.key;
        switch (roleCode) {
            case cnst.ApplicationRoles.TA_PO: return [cnst.STAT_WKFLW.TA_WKFLW_PEND_PO]
            case cnst.ApplicationRoles.TA_VO: return [cnst.STAT_WKFLW.TA_WKFLW_PEND_VO]
            case cnst.ApplicationRoles.TA_AO: return [cnst.STAT_WKFLW.TA_WKFLW_PEND_AO]
            case cnst.ApplicationRoles.TA_HOD: return [cnst.STAT_WKFLW.TA_WKFLW_PEND_HOD]
            case cnst.ApplicationRoles.TG_PO: return [cnst.STAT_WKFLW.TG_WKFLW_PEND_PO]
            case cnst.ApplicationRoles.TG_AO: return [cnst.STAT_WKFLW.TG_WKFLW_PEND_AO]
            case cnst.ApplicationRoles.HODIV: return [cnst.STAT_WKFLW.TA_WKFLW_PEND_HODIV, cnst.STAT_WKFLW.TG_WKFLW_PEND_HODIV]
            default: return null;
        }
    }

    isFinalApprovedOrRejectedStatus(status: string): boolean {
        return status == cnst.ApplicationStatuses.TA_APP_APPROVED
            || status == cnst.ApplicationStatuses.TA_APP_REJECTED
            || status == cnst.STAT_WKFLW.TA_WKFLW_APPR
            || status == cnst.STAT_WKFLW.TA_WKFLW_REJ
            || status == cnst.STAT_WKFLW.CE_WKFLW_APPR
            || status == cnst.STAT_WKFLW.CE_WKFLW_REJ
            || status == cnst.STAT_WKFLW.TG_WKFLW_APPR
            || status == cnst.STAT_WKFLW.TG_WKFLW_REJ
            || status == cnst.ApplicationStatuses.TG_APP_APPROVED
            || status == cnst.ApplicationStatuses.TG_APP_REJECTED;
    }

    isPendingCurrentUser(currentStatus: string, toCheckRfa: boolean): boolean {
        let bypassRfaResponse: boolean = false;
        if (toCheckRfa) {
            // special logic where PO can proceed an RFA application even if TA/TG has not RFA an RFA-ed app
            if (currentStatus === cnst.ApplicationStatuses.TA_APP_RFA) {
                bypassRfaResponse = (this.currentUserValue.selectedRole.key === cnst.ApplicationRoles.TA_PO);
            } else if (currentStatus === cnst.ApplicationStatuses.TG_APP_RFA) {
                bypassRfaResponse = (this.currentUserValue.selectedRole.key === cnst.ApplicationRoles.TG_PO);
            }
        }

        // normal logic to check if specified app status is pending the current user role
        return bypassRfaResponse || (this.currentUserAppPendingStatus != null && this.currentUserAppPendingStatus.includes(currentStatus)) || (this.currentUserWfcPendingStatus != null && this.currentUserWfcPendingStatus.includes(currentStatus));
    }

    isPendingAssignee(currentStatus: string, assigneeId: number): boolean {
        return this.authenticationService.currentUserValue.id == assigneeId && !this.isFinalApprovedOrRejectedStatus(currentStatus);
    }

    isAllSelected(rows: any) {
        const numSelected = this.selection.selected.length;
        const numRows = rows.length;
        return numSelected === numRows;
    }

    masterToggle(rows: any) {
        this.isAllSelected(rows) ? this.selection.clear() : rows.forEach(row => this.selection.select(row));
    }

    reAssignSelected(taTg: string) {
        return new Promise(resolve => {
            if (this.selection.selected.length < 1) {
                this.commonService.popSnackbar('Please select at least 1 record', 'error-snackbar');
            } else {

                let appIds = [];
                let workflowIds = [];
                let statusCodes = [];
                let hasError: boolean = false;
                this.selection.selected.forEach(row => {
                    if (row.applicationId) {
                        appIds.push(row.applicationId);
                    }
                    if (row.workflowId) {
                        workflowIds.push(row.workflowId);
                    }
                    if (!cnst.PENDING_STATUS.includes(row.statusCode)) {
                        hasError = true;
                        return;
                    }

                    if (!statusCodes.includes(row.statusCode)) {
                        statusCodes.push(row.statusCode);
                    }

                });

                if (hasError) {
                    this.commonService.popSnackbar(cnst.CommonErrorMessages.PENDING_APPROVAL_ONLY, 'error-snackbar');
                } else {
                    // if statusCodes more than one that means applications with different status are selected which is not allowed
                    if (statusCodes.length > 1) {
                        this.commonService.popSnackbar(cnst.CommonErrorMessages.SELECT_SAME_STATUS_APP, 'error-snackbar');
                    } else {

                        let assigneeDialogComponent = this.dialog.open(AssigneeDialogComponent, {
                            data: {
                                status: statusCodes[0]
                            }
                        });

                        assigneeDialogComponent.afterClosed().subscribe(result => {
                            if (result.decision) {
                                let input = {
                                    applicationIds: appIds,
                                    reAssignedOfficerId: result.officerId,
                                    workflowIds: workflowIds,
                                    internalRemarks: result.internalRemarks
                                }

                                this.commonService.reAssignOfficer(input, taTg).subscribe(data => {
                                    this.selection = new SelectionModel<any>(true, []);
                                    this.commonService.popSnackbar(cnst.Messages.ACTION_REASSIGN_DEFAULT, 'success-snackbar');
                                    resolve(true);
                                });
                            }
                        });

                    }
                }

            }
        });

    }

    reAssignCEWorkflow(statusCode: string, workflowId: number, workflowType: string) {
        return new Promise(resolve => {
            var assigneeDialogComponent;

            if (statusCode == cnst.STAT_WKFLW.CE_WKFLW_ROUTED) {
                assigneeDialogComponent = this.dialog.open(AssigneeDialogComponent, {
                    data: {
                        byRole: true,
                        roleCode: this.currentUserValue.selectedRole.key
                    }
                });
            } else {
                assigneeDialogComponent = this.dialog.open(AssigneeDialogComponent, {
                    data: {
                        status: statusCode,
                        workflowType: workflowType
                    }
                });
            }

            assigneeDialogComponent.afterClosed().subscribe(result => {
                if (result.decision) {
                    let input = {
                        workflowId: workflowId,
                        reAssignedOfficerId: result.officerId,
                        internalRemarks: result.internalRemarks
                    }

                    this.workflowService.reAssignOfficer(input).subscribe(data => {
                        this.selection = new SelectionModel<any>(true, []);
                        this.commonService.popSnackbar(cnst.Messages.ACTION_REASSIGN_DEFAULT, 'success-snackbar');
                        resolve(true);
                    });
                }
            });

        });
    }

    validateWorkflow(data: any, isAssigneeValidationRequired: boolean): boolean {
        var hasError = false;

        data.forEach(f => {

            var hasLevel = false,
                noAssignee = false,
                level = null,
                levelAssignee = null;

            for (var item in f.steps) {

                if (item.indexOf('Assignee') < 0) {
                    level = f.steps[item];
                    levelAssignee = f.steps[item + 'Assignee'];

                    if (isAssigneeValidationRequired) {
                        if (level == true) {
                            hasLevel = true;

                            if (levelAssignee == null) {
                                noAssignee = true;
                                break;
                            }
                        }
                    } else {
                        if (level == true) {
                            hasLevel = true;
                        }
                    }
                }
            }

            if (hasLevel == false) {
                hasError = true;

                f.error = true;
                f.errorMessage = 'Please tick at least one approval level.';
            } if (noAssignee == true) {
                hasError = true;

                f.error = true;
                f.errorMessage = 'Please select default assignee.';
            } else if (hasLevel == true && noAssignee == false) {
                f.error = false;
                f.errorMessage = '';
            }
        });

        if (!hasError) {
            return true;
        }
    }

    updateWorkflow(data: any, workflowStepType: string) {
        this.workflowService.updateWorkflow(data, workflowStepType).subscribe(data => {
            this.commonService.popSnackbar(cnst.Messages.GENERIC_SUCCCESS, 'success-snackbar');
        });
    }

    public get allowToEditWorkflow(): boolean {
        return !this.authenticationService.checkPermission('WORKFLOW_UPD');
    }

    isPendingSubmission(statusCode: string, hasEditedAfterApproved?: boolean): boolean {
        return statusCode == cnst.STAT_WKFLW.CE_WKFLW_ROUTED || (hasEditedAfterApproved && !this.isPendingApproval(statusCode)) || statusCode == cnst.STAT_WKFLW.CE_WKFLW_NEW;
    }
    isPendingApproval(statusCode: string): boolean {
        return statusCode == cnst.STAT_WKFLW.CE_WKFLW_PEND_APPR || statusCode == cnst.STAT_WKFLW.CE_WKFLW_PEND_SUPP;
    }
    isNew(statusCode: string): boolean {
        return statusCode == cnst.STAT_WKFLW.CE_WKFLW_NEW;
    }
    isApproved(statusCode: string): boolean {
        return statusCode == cnst.STAT_WKFLW.CE_WKFLW_APPR;
    }
    isRouted(statusCode: string): boolean {
        return statusCode == cnst.STAT_WKFLW.CE_WKFLW_ROUTED;
    }
}
