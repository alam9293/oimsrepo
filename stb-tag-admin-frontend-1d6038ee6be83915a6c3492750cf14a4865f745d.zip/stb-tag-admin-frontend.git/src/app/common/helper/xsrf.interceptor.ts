import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpXsrfTokenExtractor } from '@angular/common/http';
import { Observable } from 'rxjs';

// Requirements for Angular to auto-add X-XSRF-TOKEN requires the following (not all are documented):
// 1. A cookie with XSRF-TOKEN must be found for the Angular app (Note: Cookie are tied by domain)
// 2. Path="/" (Global cookie for the entire app)
// 3. HttpOnly is false
// 4. Only applies to POST
// 5. POST url must be relative instead of absolute (Note: We have been using absolute path. Because of that, we have to create this 
// manual interceptor. In order for relative to work, both frontend and backend must be deployed under the same env (same domain). 

// TODO: Currently, setCookieDomain() is only available in Spring Security Web 5.2, which is not out yet. As a result, cookie returned 
// from server (domain = localhost:9090) cannot be found by angular (domain = localhost:4200). Hence, XSRF is disabled for localhost 
// and only works for other env where both backend and frontend reside under the same domain.
 
@Injectable()
export class XsrfInterceptor implements HttpInterceptor {

    constructor(private tokenExtractor: HttpXsrfTokenExtractor) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (req.method === 'POST' || req.method === 'PUT' || req.method === 'DELETE' || req.method === 'PATCH') {
            let token = this.tokenExtractor.getToken() as string;
            // console.log('XSRF-TOKEN: ' + token);
            if (token !== null) {
                const headerName = 'X-XSRF-TOKEN';
                if (!req.headers.has(headerName)) {
                    req = req.clone({ headers: req.headers.set(headerName, token) });
                }
            }
        }
        return next.handle(req);
    }
}