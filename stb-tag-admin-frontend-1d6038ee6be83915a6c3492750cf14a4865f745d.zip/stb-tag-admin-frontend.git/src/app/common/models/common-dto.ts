export class ListableDto {
    key: string;
    label: string
}

export class LicenseeDto {
    name: string;
    licenceNumber: string;
}

export class User {
    id: number;
    loginId: string;
    name: string;
    licensee: LicenseeDto;
    status: ListableDto;
    selectedRole: ListableDto;
    roles: ListableDto[];
    permissions: ListableDto[];
    lastLoginDate: string;
    token: string;
    department: ListableDto[];
    autoLogin: boolean;
}

export class TravelAgentDto {
    name: string;
    id: string;
    uen: string;
    licenceId: string;
    licenceNo: string;
}

export class TourisGuideDto {
    name: string;
    tgId: string;
    licenceId: string;
    licenceNo: string;
    tgIdString: string;
}