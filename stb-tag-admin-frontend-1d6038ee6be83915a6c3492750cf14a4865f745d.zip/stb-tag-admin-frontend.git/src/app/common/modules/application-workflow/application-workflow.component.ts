import { Component, OnInit, Input, ViewChild, SimpleChanges } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { TaApplicationService } from './application-workflow.service';
import { FileUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-application-workflow',
    templateUrl: './application-workflow.component.html',
    styleUrls: ['./application-workflow.component.scss']
})
export class ApplicationWorkflowComponent implements OnInit {

    @Input() taTg: string;
    @Input() id: number;
    @Input() workflowId: number;
    @Input() payReqId: number;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    workflowActionRecords = [];
    workflowActionRecordsColumns = ['no', 'date', 'actionType', 'actionBy', 'status', 'remarks'];
    paymentStatusSpanRecordsColumns = ['no', 'date', 'actionBy', 'status', 'remarks'];
    cnst = cnst;

    constructor(
        private service: TaApplicationService,
        private fileUtil: FileUtil
    ) { }

    ngOnInit() {
        if (this.id || this.workflowId || this.payReqId) {
            this.loadWorkflowActions();
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id || this.workflowId || this.payReqId) {
            this.loadWorkflowActions();
        } else {
            this.workflowActionRecords = [];
        }
    }

    loadWorkflowActions() {
        setTimeout(() => {
            let mergedDto = {
                'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
                'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
                'orderProperty': this.sort.active ? this.sort.active : '',
                'order': this.sort.direction,
            };
            if (this.id || this.workflowId || this.payReqId) {
                this.service.getWorkflowActions(this.id, this.workflowId, this.payReqId, mergedDto, this.taTg).subscribe(data => {
                    this.workflowActionRecords = data.records;
                    this.paginator.length = data.total;
                });
            } else {
                this.workflowActionRecords = [];
            }
        });
    }

    toShowRecommendation(data) {
        return data.recommendationCode && (data.actionTypeCode === cnst.WorkflowActionType.WKFLW_ACT_FWD || data.actionTypeCode === cnst.WorkflowActionType.WKFLW_ACT_APPR || data.actionTypeCode === cnst.WorkflowActionType.WKFLW_ACT_REJ)
    }

    toShowAssignee(data) {
        return data.assignee && (data.actionTypeCode === cnst.WorkflowActionType.WKFLW_ACT_FWD || data.actionTypeCode === cnst.WorkflowActionType.WKFLW_ACT_SUBM || data.actionTypeCode === cnst.WorkflowActionType.WKFLW_ACT_REASSIGN || data.actionTypeCode === cnst.WorkflowActionType.WKFLW_ACT_ROUTE)
    }
}
