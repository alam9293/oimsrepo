import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';

@Injectable({
    providedIn: 'root'
})
export class TaApplicationService {

    constructor(private http: HttpClient) { }

    getWorkflowActions(applicationId: number, workflowId: number, payReqId: number, searchDto, taTg: string): Observable<any> {
        if (applicationId) {
            return this.http.get<any>(cnst.apiBaseUrl + '/' + taTg + '/applications/view/' + applicationId + '/workflow-actions', { params: searchDto });
        } else if (workflowId) {
            return this.http.get<any>(cnst.apiBaseUrl + '/workflow/workflow-actions/view/' + workflowId, { params: searchDto });
        } else if (payReqId) {
            return this.http.get<any>(cnst.apiBaseUrl + '/payment/requests/view/status-spans/' + payReqId, { params: searchDto });
        }
    }
}
