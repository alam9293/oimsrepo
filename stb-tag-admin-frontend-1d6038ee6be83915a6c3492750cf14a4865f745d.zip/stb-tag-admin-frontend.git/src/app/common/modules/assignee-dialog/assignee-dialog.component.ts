import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import * as cnst from '../../constants';
import { WorkflowService } from '../../services/workflow.service';
import { AuthenticationService } from '../../services';

@Component({
    selector: 'app-assignee-dialog',
    templateUrl: './assignee-dialog.component.html',
    styleUrls: ['./assignee-dialog.component.scss']
})
export class AssigneeDialogComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<AssigneeDialogComponent>,
        private formBuilder: FormBuilder,
        private workflowService: WorkflowService,
        private authenticationService: AuthenticationService) { }

    cnst = cnst;
    form = this.formBuilder.group({
        officerId: [''],
        internalRemarks: []
    });
    showInternal: boolean = false;
    officers: any = [];

    showAssignToMe: boolean = false;

    ngOnInit() {
        if (this.data) {
            if (this.data.byRole) {
                this.workflowService.getOfficerListByRole(this.data.roleCode).subscribe(data => {
                    this.officers = data;
                    this.checkCurrentUserInUserList(this.officers);
                });
            } else if (this.data.workflowType) {
                this.workflowService.getOfficerListByStatusAndWorkflowType(this.data.status, this.data.workflowType).subscribe(data => {
                    this.officers = data;
                    this.checkCurrentUserInUserList(this.officers);
                });
            } else {
                this.workflowService.getOfficerListByStatus(this.data.status).subscribe(data => {
                    this.officers = data;
                    this.checkCurrentUserInUserList(this.officers);
                });
            }

        }
    }

    checkCurrentUserInUserList(officers) {
        var currentUserId = this.authenticationService.currentUserValue.id;
        officers.forEach(element => {
            if (element.id === currentUserId) {
                this.showAssignToMe = true;
            }
        });
    }

    close(decision: boolean) {
        let obj = {
            decision: decision,
            officerId: this.form.controls['officerId'].value,
            internalRemarks: this.form.controls['internalRemarks'].value
        };

        this.dialogRef.close(obj);
    }

    assignToMe() {
        this.form.get('officerId').setValue(this.authenticationService.currentUserValue.id);
    }


}
