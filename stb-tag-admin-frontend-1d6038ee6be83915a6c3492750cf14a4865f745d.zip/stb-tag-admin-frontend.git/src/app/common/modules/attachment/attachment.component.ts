import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { MatTable } from '@angular/material';
import { FileUtil } from 'src/app/common/helper';

import * as cnst from '../../../common/constants';
import { CommonService } from '../../services';

@Component({
    selector: 'attachment',
    templateUrl: './attachment.component.html',
    styleUrls: ['./attachment.component.scss']
})
export class AttachmentComponent implements OnInit {

    @ViewChild(MatTable) _matTables;
    @Input() showUpdate: boolean;
    @Input() toDisable: boolean; // do not hard code, if toDisable is not specified, the button will be enabled. To disable, specify toDisable = true when using the component
    @Input() doNotShowHeader: boolean;
    @Input() docType: string;
    @Input() extsAllowed: any;
    @Input() totalMaxSize: any;

    othAttachmentColumns = ['originalName', 'description', 'fileSize', 'createdDate', 'action'];

    cnst = cnst;

    attachmentForm: FormGroup;
    selectedFile: File;

    constructor(
        private fb: FormBuilder,
        public fileUtil: FileUtil,
        private commonService: CommonService,
    ) { }

    ngOnInit() {
        this.initForm();
    }

    get attachments() {
        return this.attachmentForm.get('attachments') as FormArray;
    }

    get deletedAttachements() {
        return this.attachmentForm.get('deletedAttachements') as FormArray;
    }

    get deletedAttachementIds() {
        return this.attachmentForm.get('deletedAttachementIds') as FormArray;
    }

    get f() {
        return this.attachmentForm;
    }

    set(data) {
        if (data) {
            this.initForm();
            data.forEach(u => {
                this.addAttachment(u);
            });
        }
    }

    initForm() {
        this.attachmentForm = this.fb.group({
            attachments: this.fb.array([]),
            deletedAttachements: this.fb.array([]),
            deletedAttachementIds: this.fb.array([])
        })
    }

    addAttachment(data) {
        this.attachments.push(
            this.populateAttachmentFormGroup(data)
        );
        this._matTables.renderRows();
    }

    updateAttachments() {
        this.fileUtil.updateFiles(this.attachments.value).subscribe(data => {
            this.set(data);
        });
    }

    deleteAttachment(rowIndex) {
        var attachment = this.attachments.at(rowIndex);

        this.deletedAttachements.push(attachment);
        this.deletedAttachementIds.push(attachment.get('id'));

        this.attachments.removeAt(rowIndex);
        this._matTables.renderRows();
        this.attachmentForm.markAsDirty();
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (this.selectedFile) {
            var extension = this.selectedFile.name.substr(this.selectedFile.name.lastIndexOf('.')).toLowerCase();
            if (!this.extsAllowed || cnst.FileExt.SIGN_DOC_ATTACHMENT.ext.includes(extension)) {
                if (!this.fileUtil.exceedMaxSize(this.selectedFile, this.totalMaxSize)) {
                    if (this.totalMaxSize) { //Check if there is a total max file size limit
                        var sum = this.selectedFile.size;
                        for (var i = 0; i < this.attachments.length; i++) {
                            sum += this.attachments.value[i].size;
                        }
                    }
                    if (this.totalMaxSize && sum >= this.totalMaxSize) {
                        this.commonService.popSnackbar(cnst.CommonErrorMessages.TOTAL_MAX_FILE_SIZE, 'error-snackbar');
                    } else {
                        this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                            this.attachments.push(
                                this.populateAttachmentFormGroup(data)
                            );
                            this._matTables.renderRows();
                        });
                    }
                }
            } else {
                this.commonService.popSnackbar(cnst.FileExt.SIGN_DOC_ATTACHMENT.errorMsg, 'error-snackbar');
            }
            this.attachmentForm.markAsDirty();
        }
    }

    populateAttachmentFormGroup(x) {
        return this.fb.group({
            id: x ? x.id : [],
            originalName: x ? x.originalName : [],
            description: x ? x.description : [],
            createdDate: x ? x.createdDate : [],
            createdBy: x ? x.createdBy : [],
            docType: x ? x.docType : [],
            hash: x ? x.hash : [],
            readableFileSize: x ? x.readableFileSize : [],
            size: x ? x.size : []
        });
    }

}
