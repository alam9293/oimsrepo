import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
    selector: 'app-back',
    templateUrl: './back.component.html',
    styleUrls: ['./back.component.scss']
})
export class BackComponent implements OnInit {

    @Input() link: string;

    constructor(private router: Router, private location: Location) { }

    ngOnInit() { }

    back() {
        if (this.link) {
            this.router.navigate([this.link]);
        } else {
            this.location.back();
        }

    }
}
