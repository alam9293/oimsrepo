import { Component, Inject, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import * as cnst from '../../../common/constants';
import { FileUtil, WorkflowHelper } from '../../helper';
import { CommonService } from '../../services/common.service';
import { WorkflowService } from '../../services/workflow.service';

@Component({
    selector: 'app-confirmation-dialog',
    templateUrl: './confirmation-dialog.component.html',
    styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
        private workflowHelper: WorkflowHelper,
        private workflowService: WorkflowService,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private fileUtil: FileUtil
    ) { }
    cnst = cnst;
    form: FormGroup;
    showInternal: boolean = false;
    selectedFile: File;
    files: SupportingDocument[];
    recommendTypes = [];
    showUser: boolean = false;
    supporterWorkflowConfig: any;
    approverWorkflowConfig: any;

    roles: any;
    users: any;

    ngOnInit() {
        this.initForm();

        if (!this.data) {
            this.data = {};
        } else {

            // retrieve role list based on current user pending status for route back action
            this.getCurrentUserPendingStatus();
            if (this.data.action === cnst.workflowAction.route && this.data.appType != null && this.data.currentStatusCode != null) {
                this.workflowService.getRoleListToBeReturned(this.data).subscribe(data => {
                    this.roles = data.roles;

                    if (this.roles.length == 1) {
                        this.form.get('routeStatus').setValue(this.roles[0].startStatusCode);
                        this.routeChanged(this.roles[0].startStatusCode);
                    }

                });
            }

            if (this.data.recommendationType) {
                this.commonService.getTypesByCategoryCode(this.data.recommendationType).subscribe(data => {
                    this.recommendTypes = data;
                });
            }

            if (this.data.recommendation) {
                this.form.get('recommendationCode').setValidators([Validators.required]);
            } else {
                this.form.get('recommendationCode').setValidators(null);
            }

            if (this.data.workflowConfig) {
                let supporterWorkflowConfig = this.data.workflowConfig.filter(value => value.startStatusCode == cnst.STAT_WKFLW.CE_WKFLW_PEND_SUPP);
                let approverWorkflowConfig = this.data.workflowConfig.filter(value => value.startStatusCode == cnst.STAT_WKFLW.CE_WKFLW_PEND_APPR || value.startStatusCode == cnst.STAT_WKFLW.PAY_WKFLW_PEND_APPR);

                if (supporterWorkflowConfig.length > 0) {
                    this.supporterWorkflowConfig = supporterWorkflowConfig[0];
                    this.form.get('supporterId').setValidators([Validators.required]);
                    this.form.get('supporterId').setValue(this.supporterWorkflowConfig.defaultAssignee);
                } else {
                    this.form.get('supporterId').setValidators(null);
                }

                if (approverWorkflowConfig.length > 0) {
                    this.approverWorkflowConfig = approverWorkflowConfig[0];
                    this.form.get('approverId').setValidators([Validators.required]);
                    this.form.get('approverId').setValue(this.approverWorkflowConfig.defaultAssignee);
                } else {
                    this.form.get('approverId').setValidators(null);
                }
            }

            if (this.data.internalRemarks && !this.data.externalRemarks) {
                this.showHideInternal();
            }

            if (this.data.supporterId) {
                this.form.get('supporterId').setValue(this.data.supporterId);
            }

            if (this.data.approverId) {
                this.form.get('approverId').setValue(this.data.approverId);
            }
        }
    }

    onFileChanged(event) {
        if (event.target.value) {
            this.selectedFile = event.target.files[0];
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                const fileDto = this.formBuilder.group({
                    file: [this.selectedFile],
                    fileName: [this.selectedFile.name],
                    fileDescription: ['']
                });
                this.supportingDocuments.push(fileDto);
            }
            event.target.value = '';
        }
    }

    routeChanged(selectedOption) {
        let role = this.roles.find(({ startStatusCode }) => startStatusCode == selectedOption);
        this.users = role.users;
        this.form.get('assignee').setValue(role.defaultAssignee);
        this.showUser = true;
    }

    removeFile(index) {
        this.supportingDocuments.removeAt(index);
    }

    get supportingDocuments() {
        return this.form.get('supportingDocuments') as FormArray;
    }

    initForm() {
        this.form = this.formBuilder.group({
            routeStatus: [''],
            assignee: [''],
            recommendationCode: [''],
            internalRemarks: [''],
            externalRemarks: [''],
            supportingDocuments: this.formBuilder.array([]),
            supporterId: [''],
            approverId: ['']
        });
    }

    showHideInternal() {
        this.showInternal = !this.showInternal;

        if (this.showInternal && this.data.externalRemarks) {
            this.form.get('internalRemarks').setValidators([Validators.required]);
            this.form.get('internalRemarks').updateValueAndValidity();
        } else {
            this.form.get('internalRemarks').setValidators(null);
            this.form.get('internalRemarks').updateValueAndValidity();
        }
    }

    showHideExternal() {
        var notIncludedStatuses = [cnst.ApplicationStatuses.TA_APP_PENDING_HODIV, cnst.ApplicationStatuses.TG_APP_PENDING_HODIV, cnst.STAT_WKFLW.TA_WKFLW_PEND_HODIV, cnst.STAT_WKFLW.TG_WKFLW_PEND_HODIV];

        this.getCurrentUserPendingStatus();
        return this.data.externalRemarks && this.data.action != cnst.workflowAction.route && !notIncludedStatuses.includes(this.data.currentStatusCode);
    }

    getCurrentUserPendingStatus() {
        var currentUserPendingStatus = this.data.statusCode;
        if (!currentUserPendingStatus && this.data.appType) {
            currentUserPendingStatus = this.workflowHelper.currentUserAppPendingStatus;
            if (this.data.appType === cnst.WorkflowTypes.TA_WKFLW_SHORTFALL) {
                currentUserPendingStatus = this.workflowHelper.currentUserWfcPendingStatus;
            }

            if (currentUserPendingStatus && currentUserPendingStatus.length > 1) {
                if (this.data.appType.indexOf('TA_') == 0) {
                    currentUserPendingStatus = currentUserPendingStatus[0];
                } else {
                    currentUserPendingStatus = currentUserPendingStatus[1];
                }
            }
        }

        this.data.currentStatusCode = currentUserPendingStatus;
    }

    close(decision: boolean) {

        if (this.data.action === cnst.workflowAction.rfa) {
            if (this.data.taTg === cnst.TA) {
                this.form.get('routeStatus').setValue(cnst.ApplicationStatuses.TA_APP_RFA);
            } else {
                this.form.get('routeStatus').setValue(cnst.ApplicationStatuses.TG_APP_RFA);
            }
        }

        let obj = {
            decision: decision,
            params: this.form.getRawValue(),
            files: this.supportingDocuments.value,
        };
        this.dialogRef.close(obj);
    }
}

export interface SupportingDocument {
    fileDescription: String;
    file: File;
}
