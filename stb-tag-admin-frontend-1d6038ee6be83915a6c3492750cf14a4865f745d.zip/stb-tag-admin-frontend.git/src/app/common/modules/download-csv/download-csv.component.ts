import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DownloadCsvService } from './download-csv.service';
import { AuthenticationService } from '../../../common/services';
import * as moment from 'moment';
import { DateUtil } from 'src/app/common/helper';

@Component({
    selector: 'app-download-csv',
    templateUrl: './download-csv.component.html',
    styleUrls: ['./download-csv.component.scss']
})
export class DownloadCsvComponent implements OnInit {

    @Input() fileName: string;
    @Output() method = new EventEmitter<any>();
    @Input() permission: string | string[];

    constructor(private service: DownloadCsvService, private authenticationService: AuthenticationService) { }

    hasPermission: boolean;
    ngOnInit() {
        if (this.permission) {
            this.hasPermission = this.authenticationService.hasPermission(this.permission);
        } else {
            this.hasPermission = true; // default to always has permission
        }
    }

    onClick() {
        this.method.emit(data => {
            var blob = new Blob([data], {
                type: 'text/csv'
            });

            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blob, this.fileName);
            } else {
                let fileURL = window.URL.createObjectURL(blob);
                let downloadLink = document.createElement('a');
                downloadLink.href = fileURL;
                downloadLink.download = this.fileName + '_' + moment(new Date()).format(DateUtil.DATE_FORMAT) + '.csv';
                downloadLink.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
                setTimeout(function () {
                    window.URL.revokeObjectURL(fileURL);
                    downloadLink.remove();
                }, 100);
            }
        });
    }
}
