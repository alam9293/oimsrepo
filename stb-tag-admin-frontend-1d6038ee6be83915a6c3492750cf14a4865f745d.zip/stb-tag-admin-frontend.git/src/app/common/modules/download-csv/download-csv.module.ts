import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatDividerModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DownloadCsvComponent } from './download-csv.component';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatDividerModule,
        FlexLayoutModule,
    ],
    declarations: [DownloadCsvComponent],
    exports: [DownloadCsvComponent]
})
export class DownloadCsvModule { }
