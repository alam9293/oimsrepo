import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';

@Injectable({
    providedIn: 'root'
})
export class DownloadCsvService {

    baseApi: string = cnst.apiBaseUrl + '/file';
    constructor(private http: HttpClient) { }

    download(url: string, dto: any): Observable<any> {
        return this.http.post<any>(url, { params: dto });
    }
}
