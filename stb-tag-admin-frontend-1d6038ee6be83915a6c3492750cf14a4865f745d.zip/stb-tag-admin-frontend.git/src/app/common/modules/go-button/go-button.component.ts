import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'go-button',
    templateUrl: './go-button.component.html',
    styleUrls: ['./go-button.component.scss']
})
export class GoButtonComponent implements OnInit {

    static lastListingId: string;
    static lastClickedKey: string;
    @Input() listingId: string;
    @Input() key: string;
    @Input() label: string;
    @Input() url: string;
    @Input() param?: any;
    @Input() disable?: any;

    constructor() { }

    ngOnInit() { }

    getLastClickedKey() {
        if (GoButtonComponent.lastListingId === this.listingId) {
            return GoButtonComponent.lastClickedKey;
        }
    }

    setAsLastClickedKey() {
        GoButtonComponent.lastListingId = this.listingId;
        GoButtonComponent.lastClickedKey = this.key;
    }

    public static clearLastClicked() {
        GoButtonComponent.lastListingId = null;
        GoButtonComponent.lastClickedKey = null;
    }
}
