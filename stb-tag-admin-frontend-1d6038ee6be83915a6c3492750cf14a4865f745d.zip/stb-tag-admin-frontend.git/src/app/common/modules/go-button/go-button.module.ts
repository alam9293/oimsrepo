import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatButtonModule, MatIconModule } from '@angular/material';
import { GoButtonComponent } from './go-button.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        MatButtonModule,
        MatIconModule
    ],
    declarations: [GoButtonComponent,],
    exports: [GoButtonComponent]
})
export class GoButtonModule { }
