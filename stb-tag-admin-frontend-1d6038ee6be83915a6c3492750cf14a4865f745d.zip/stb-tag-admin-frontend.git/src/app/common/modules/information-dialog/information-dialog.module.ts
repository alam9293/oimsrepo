import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatDividerModule, } from '@angular/material';
import { InformationDialogComponent } from './information-dialog.component';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatDividerModule,
        FlexLayoutModule
    ],
    declarations: [InformationDialogComponent],
    exports: [InformationDialogComponent]
})
export class InformationDialogModule { }

