import { Component, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ConfirmationDialogComponent } from '../../confirmation-dialog/confirmation-dialog.component';
import { MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { CommonService } from '../../../services';
import { MasterDataConfigService } from '../master-data.service';
import * as cnst from '../../../constants';
import * as Quill from 'quill';

@Component({
    selector: 'app-email-config',
    templateUrl: './email-config.component.html',
    styleUrls: ['./email-config.component.scss']
})
export class EmailConfigComponent implements OnInit {
    @ViewChild(MatSort) sort: MatSort;
    dialogRef: MatDialogRef<any>;
    cnst = cnst;
    emailDetails: any = {};
    filter: any = {};
    canProceed: boolean = false;

    constructor(
        private service: MasterDataConfigService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar,
        private formBuilder: FormBuilder,
    ) { }

    emails: any;
    form = this.formBuilder.group({
        subject: [''],
        body: [''],
        isActive: [''],
        code: [''],
        name: [''],
    });
    quill = new Quill('#editor', {
        theme: 'snow'
    });
    quillBody = new Quill('#editorBody', {
        theme: 'snow'
    });

    ngOnInit() {
        this.formatQuillEditorIcon();
        this.loadEmailName();
    }

    loadEmailName() {
        this.service.getEmailName().subscribe(data => {
            this.emails = data;
            this.filter.selectedEmail = this.emails[0].code;
            this.loadEmailDetails();
        });
    }


    loadEmailDetails() {
        this.service.loadEmailDetails(this.filter).subscribe(data => {
            this.emailDetails = data;
            this.form.patchValue(data);
            this.commonService.cacheSearchDto(this.filter);

            //for quill editor
            this.cleanEditorCache();
            this.loadQuillEditorSubject();
            this.loadQuillEditorBody();
        });
    }

    cleanEditorCache() {
        //remove all the cache html
        var fieldDiv = document.getElementById('editor');
        var fieldDivBody = document.getElementById('editorBody');
        fieldDiv.innerHTML = fieldDivBody.innerHTML = "";
        var elements = document.getElementsByClassName("ql-toolbar ql-snow");
        while (elements.length > 0) {
            elements[0].parentNode.removeChild(elements[0]);
        }
    }

    loadQuillEditorSubject() {
        console.log("email ::" + this.filter.selectedEmail);
        this.quill = new Quill('#editor', {
            theme: 'snow',
            modules: {
                toolbar: {
                    container:
                        [
                            [{ 'placeholder': this.changePlaceholder(this.filter.selectedEmail) }, 'clean']
                        ],
                    handlers: {
                        "placeholder": function (value) {
                            if (value) {
                                value = value.substr(0, value.indexOf("}") + 1);
                                const cursorPosition = this.quill.getSelection().index;
                                this.quill.insertText(cursorPosition, value);
                                this.quill.setSelection(cursorPosition + value.length);
                            }
                        }
                    }
                }
            }
        });

        const placeholderPickerItems = Array.prototype.slice.call(document.querySelectorAll('.ql-placeholder .ql-picker-item'));
        placeholderPickerItems.forEach(item => item.textContent = item.dataset.value);

        document.querySelector('.ql-placeholder .ql-picker-label').innerHTML = 'Insert placeholder' + '&nbsp;&nbsp;&nbsp;&nbsp;'
            + document.querySelector('.ql-placeholder .ql-picker-label').innerHTML;

        this.quill.clipboard.dangerouslyPasteHTML(0, this.emailDetails.subject);
    }

    loadQuillEditorBody() {
        this.quillBody = new Quill('#editorBody', {
            theme: 'snow',
            modules: {
                toolbar: {
                    container:
                        [
                            [{ 'placeholderBody': this.changePlaceholder(this.filter.selectedEmail) },
                            { 'header': [1, 2, 3, 4, 5, 6, false] },
                                'bold', 'italic', 'underline',
                            { 'list': 'ordered' },
                            { 'list': 'bullet' },
                            { 'align': ['left', 'right', 'center'] },
                                'link', 'clean']],
                    handlers: {
                        "placeholderBody": function (value) {
                            if (value) {
                                value = value.substr(0, value.indexOf("}") + 1);
                                const cursorPosition = this.quill.getSelection().index;
                                this.quill.insertText(cursorPosition, value);
                                this.quill.setSelection(cursorPosition + value.length);
                            }
                        }
                    }
                },
            }
        });

        const placeholderPickerItems = Array.prototype.slice.call(document.querySelectorAll('.ql-placeholderBody .ql-picker-item'));
        placeholderPickerItems.forEach(item => item.textContent = item.dataset.value);

        document.querySelector('.ql-placeholderBody .ql-picker-label').innerHTML
            = document.querySelector('.ql-placeholder .ql-picker-label').innerHTML;

        this.quillBody.clipboard.dangerouslyPasteHTML(0, this.emailDetails.body);
    }

    updateEmail() {
        this.form.get('subject').setValue(this.quill.container.firstChild.innerHTML.trim());
        this.form.get('body').setValue(this.quillBody.container.firstChild.innerHTML.trim());
        this.validateField();
        if (this.canProceed) {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: "Update Confirmation"
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.service.updateEmail(this.form.value).subscribe(data => {
                        this.loadEmailDetails();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    });
                }
            });
            this.commonService.clearSystemCache().subscribe();
        }
    }

    validateField() {
        this.canProceed = true;
        var subject = this.form.get('subject').value.replace("<p>", "").replace("</p>", "").replace("<br>", "");
        var body = this.form.get('body').value.replace("<p>", "").replace("</p>", "").replace("<br>", "");
        if (subject == "" || body == "") {
            this.canProceed = false;
            this.commonService.popSnackbar("All input field must not be empty.", 'error-snackbar');
        } else {
            if (subject.length > 255) {
                this.canProceed = false;
                this.commonService.popSnackbar("Subject input too long (Max. 255)", 'error-snackbar');
            }
        }
    }

    onChangeEmail() {
        this.loadEmailDetails();
    }

    checkPermission(functionCode: string) {
        return this.service.checkPermission(functionCode);
    }

    changePlaceholder(selectedEmail) {
        if (!selectedEmail) {
            return;
        }
        let placeholders = cnst.EmailPlaceHolder[selectedEmail];
        return placeholders ? placeholders : [];
    }

    formatQuillEditorIcon() {
        var Align = Quill.import('attributors/style/align');
        var icons = Quill.import('ui/icons');

        icons.align['left'] = icons.align['']; // set icon for 'left' option, otherwise it's replaced with 'undefined' text
        Align.whitelist = ['left', 'center', 'right']; // add explicit 'left' option
    }
}
