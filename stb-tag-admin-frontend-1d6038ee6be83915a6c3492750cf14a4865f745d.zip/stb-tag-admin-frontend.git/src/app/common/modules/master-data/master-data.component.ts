import { Component, OnInit } from '@angular/core';
import * as cnst from '../../constants';

@Component({
    selector: 'app-master-data',
    templateUrl: './master-data.component.html',
    styleUrls: ['./master-data.component.scss']
})
export class MasterDataComponent implements OnInit {

    constructor() { }
    cnst = cnst;

    masterDataSelection: any = this.cnst.MasterDataSelection.TYPES;

    ngOnInit() {
    }

}
