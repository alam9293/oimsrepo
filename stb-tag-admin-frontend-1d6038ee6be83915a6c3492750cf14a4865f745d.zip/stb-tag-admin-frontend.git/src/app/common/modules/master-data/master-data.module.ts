import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatButtonToggleModule, MatCardModule, MatDividerModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatIconModule, MatSelectModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MasterDataComponent } from './master-data.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatPaginatorModule, MatSortModule, MatTableModule, MatDialogModule, MatDatepickerModule, MatCheckboxModule } from '@angular/material';
import { TypesConfigComponent } from './types-config/types-config.component';
import { StatusesConfigComponent } from './statuses-config/statuses-config.component';
import { SystemParameterConfigComponent } from './system-parameter-config/system-parameter-config.component';
import { EmailConfigComponent } from './email-config/email-config.component';
import { BackModule } from '../back/back.module';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { RouterModule } from '@angular/router';
import { EditorModule } from 'primeng/editor';
import { WaiverConfigComponent } from './waiver-config/waiver-config.component';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatDividerModule,
        MatCardModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        RouterModule,
        BackModule,
        DragDropModule,
        ScrollingModule,
        MatDatepickerModule,
        EditorModule,
        MatCheckboxModule
    ],
    declarations: [MasterDataComponent, TypesConfigComponent, StatusesConfigComponent, SystemParameterConfigComponent, EmailConfigComponent, WaiverConfigComponent],
    exports: [MasterDataComponent],
    entryComponents: []
})
export class MasterDataModule { }

