import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';
import { AuthenticationService } from '../../../common/services';
import * as _ from 'lodash';

@Injectable({
    providedIn: 'root'
})
export class MasterDataConfigService {

    constructor(private http: HttpClient, private authenticationService: AuthenticationService) { }

    //Types
    public getEditableCategoryTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/get-editable-category-types');
    }

    public getEditableCategoryTypeLabel(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/get-editable-category-types-label', { params: searchDto });
    }

    public loadEditableTypeList(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/types/view', { params: searchDto });
    }

    public updateTypes(rows: any): Observable<any> {
        let formData: FormData = new FormData();

        formData.append('list', new Blob(
            [JSON.stringify(rows)],
            { type: 'application/json' }
        ));
        return this.http.post(cnst.apiBaseUrl + '/config/update-types/', formData);
    }

    public saveTypes(dto: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/config/save-types/', dto);
    }

    //Statues
    public getEditableCategoryStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/get-editable-category-statuses');
    }

    public loadEditableStatusList(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/statuses/view', { params: searchDto });
    }

    public updateStatuses(rows: any): Observable<any> {
        let formData: FormData = new FormData();

        formData.append('list', new Blob(
            [JSON.stringify(rows)],
            { type: 'application/json' }
        ));
        return this.http.post(cnst.apiBaseUrl + '/config/update-statuses/', formData);
    }

    public saveStatuses(dto: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/config/save-statuses/', dto);
    }

    //System Parameter
    public loadEditableSysParameterList(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/sys-parameter/view', { params: searchDto });
    }

    public updateSysParameter(rows: any): Observable<any> {
        let formData: FormData = new FormData();

        formData.append('list', new Blob(
            [JSON.stringify(rows)],
            { type: 'application/json' }
        ));
        return this.http.post(cnst.apiBaseUrl + '/config/update-sys-parameter/', formData);
    }

    //Email
    public getEmailName(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/get-email-name');
    }

    public loadEmailDetails(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/email-detail/view', { params: searchDto });
    }

    public updateEmail(emailDetails: any): Observable<any> {
        let formData: FormData = new FormData();

        formData.append('dto', new Blob(
            [JSON.stringify(emailDetails)],
            { type: 'application/json' }
        ));
        return this.http.post(cnst.apiBaseUrl + '/config/update-email/', formData);
    }

    public checkPermission(functionCode: string): boolean {
        return this.authenticationService.checkPermission(functionCode);
    }

    // Payment Waiver
    getWaiverTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/config/master-data/waiver-types');
    }

    updateWaiverTypes(formData: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/config/update-waiver-types', formData);
    }
}
