import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import * as cnst from '../../../../common/constants';
import { CommonService } from '../../../../common/services';

@Component({
    selector: 'app-master-dialog',
    templateUrl: './master-dialog.component.html',
    styleUrls: ['./master-dialog.component.scss']
})
export class MasterDialogComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<MasterDialogComponent>,
        private formBuilder: FormBuilder,
        private commonService: CommonService) { }

    cnst = cnst;
    category: any;
    categories: any;
    pageType: any;
    form = this.formBuilder.group({
        label: ['', [Validators.maxLength(255), Validators.required]],
        otherLabel: ['', [Validators.maxLength(255)]],
        isActive: [''],
        categoryCode: ['']
    });

    ngOnInit() {
        if (!this.data) {
            this.data = {};
        }
        this.pageType = this.data.pageType;
        this.category = this.data.category;
        this.categories = this.data.categories;
        this.loadCommonTypes();
    }

    loadCommonTypes() {
        this.form.get('categoryCode').setValue(this.category);
    };

    close(decision: boolean) {
        let obj = {
            decision: decision,
            params: this.form.value
        };

        this.dialogRef.close(obj);
    }



}
