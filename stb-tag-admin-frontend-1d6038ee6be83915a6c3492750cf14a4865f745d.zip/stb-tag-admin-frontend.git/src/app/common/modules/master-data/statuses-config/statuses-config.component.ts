import { Component, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragHandle } from '@angular/cdk/drag-drop';
import { CommonService } from '../../../../common/services';
import { MasterDataConfigService } from '../master-data.service';
import { MatTable } from '@angular/material/table';
import * as cnst from '../../../../common/constants';
import { MasterDialogComponent } from '../../../../common/modules/master-data/master-dialog/master-dialog.component';

@Component({
    selector: 'app-statuses-config',
    templateUrl: './statuses-config.component.html',
    styleUrls: ['./statuses-config.component.scss']
})
export class StatusesConfigComponent implements OnInit {
    @ViewChild('table') table: MatTable<string[]>;
    @ViewChild(MatSort) sort: MatSort;
    dialogRef: MatDialogRef<any>;
    rows = [];
    filter: any = {};
    masterConfigDescList: any;
    configMap = new Map<string, string>();
    displayedColumns = ['Ordinal', 'StatusCode', 'StatusLabel', 'OtherLabel', 'Active'];

    constructor(
        private service: MasterDataConfigService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar
    ) { }

    categories: any;

    ngOnInit() {
        this.masterConfigDescList = cnst.MasterConfigDescription;
        this.masterConfigDescList.forEach(ele => {
            this.configMap.set(ele.key, ele.label);
        });
        this.loadEditableCategory();
    }

    loadEditableStatusList() {
        this.service.loadEditableStatusList(this.filter).subscribe(data => {
            this.rows = data;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    mapMasterDesc() {
        return this.configMap.get(this.filter.selectedCategory);
    }

    loadEditableCategory() {
        this.service.getEditableCategoryStatuses().subscribe(data => {
            this.categories = data;
            this.filter.selectedCategory = this.categories[0].key;
            this.loadEditableStatusList();
        });
    }

    updateStatuses() {
        if (this.validateStatusLabel) {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: "Update Confirmation"
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.service.updateStatuses(this.rows).subscribe(data => {
                        this.loadEditableStatusList();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    });
                }
            });
            this.commonService.clearSystemCache().subscribe();
        } else {
            alert("All status label must be filled");
        }
    }

    onChangeCategory() {
        this.loadEditableStatusList();
    }

    get validateStatusLabel() {
        var result = true;
        this.rows.forEach(item => {
            if (item.label == "") {
                result = false;
            }
        })
        return result;
    }

    dropTable(event: CdkDragDrop<string[]>) {
        const prevIndex = this.rows.findIndex((d) => d === event.item.data);
        moveItemInArray(this.rows, prevIndex, event.currentIndex);
        this.table.renderRows();
    }

    checkPermission(functionCode: string) {
        return this.service.checkPermission(functionCode);
    }
}
