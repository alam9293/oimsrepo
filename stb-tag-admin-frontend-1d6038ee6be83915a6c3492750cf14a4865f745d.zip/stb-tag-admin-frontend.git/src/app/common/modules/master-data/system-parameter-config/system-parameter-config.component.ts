import { Component, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { CommonService } from '../../../../common/services';
import { MasterDataConfigService } from '../master-data.service';
import { DatePipe } from '@angular/common';
import { MatTable } from '@angular/material/table';
import * as cnst from '../../../constants';

@Component({
    selector: 'app-system-parameter-config',
    templateUrl: './system-parameter-config.component.html',
    styleUrls: ['./system-parameter-config.component.scss']
})
export class SystemParameterConfigComponent implements OnInit {
    @ViewChild(MatSort) sort: MatSort;
    dialogRef: MatDialogRef<any>;
    cnst = cnst;
    rows = [];
    filter: any = {};
    displayedColumns = ['Code', 'Description', 'Value'];

    constructor(
        private service: MasterDataConfigService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar
    ) { }

    categories: any;

    ngOnInit() {
        this.loadEditableSystemParameterList();
    }

    loadEditableSystemParameterList() {
        this.service.loadEditableSysParameterList(this.filter).subscribe(data => {
            this.rows = data;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    updateSystemParameter() {
        if (this.validateSysParameterValue) {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: "Update Confirmation"
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.service.updateSysParameter(this.rows).subscribe(data => {
                        this.loadEditableSystemParameterList();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    });
                }
            });
            this.commonService.clearSystemCache().subscribe();
        } else {
            alert("All value must be filled");
        }
    }

    onChangeCategory() {
        this.loadEditableSystemParameterList();
    }

    get validateSysParameterValue() {
        var result = true;
        this.rows.forEach(item => {
            if (item.value == "" || item.value == null) {
                result = false;
            }

            if (item.categoryCode == cnst.DataType.DATA_DT) {
                item.value = new DatePipe('en-US').transform(item.value, 'dd-MMM-yyyy');
            }
        })
        return result;
    }

    checkPermission(functionCode: string) {
        return this.service.checkPermission(functionCode);
    }
}
