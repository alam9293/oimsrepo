import { Component, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragHandle } from '@angular/cdk/drag-drop';
import { CommonService } from '../../../../common/services';
import { MasterDataConfigService } from '../master-data.service';
import { MatTable } from '@angular/material/table';
import * as cnst from '../../../../common/constants';
import { MasterDialogComponent } from '../../../../common/modules/master-data/master-dialog/master-dialog.component';

@Component({
    selector: 'app-types-config',
    templateUrl: './types-config.component.html',
    styleUrls: ['./types-config.component.scss']
})
export class TypesConfigComponent implements OnInit {
    @ViewChild('table') table: MatTable<string[]>;
    @ViewChild(MatSort) sort: MatSort;
    dialogRef: MatDialogRef<any>;
    rows = [];
    filter: any = {};
    displayedColumns = ['Ordinal', 'TypeCode', 'TypeLabel', 'OtherLabel', 'Active'];
    masterConfigDescList: any;
    configMap = new Map<string, string>();
    cnst = cnst;

    constructor(
        private service: MasterDataConfigService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar
    ) { }

    categories: any;
    typeLabel: any;

    ngOnInit() {
        this.masterConfigDescList = cnst.MasterConfigDescription;
        this.masterConfigDescList.forEach(ele => {
            this.configMap.set(ele.key, ele.label);
        });
        this.loadEditableCategory();
    }

    loadEditableTypeList() {
        this.service.loadEditableTypeList(this.filter).subscribe(data => {
            this.rows = data;
            this.commonService.cacheSearchDto(this.filter);
            if (this.filter.selectedCategory === 'TA_SALES_CHANNEL') {
                if (this.displayedColumns.length < 6) {
                    this.displayedColumns.push('FootNote');
                }
            } else {
                if (this.displayedColumns.length > 5) {
                    this.displayedColumns.pop();
                }
            }
        });
    }

    loadEditableCategory() {
        this.service.getEditableCategoryTypes().subscribe(data => {
            this.categories = data;
            this.filter.selectedCategory = this.categories[0].key;
            this.loadEditableTypeList();
        });
    }

    updateTypes() {
        if (this.validateTypeLabel) {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: "Update Confirmation"
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.service.updateTypes(this.rows).subscribe(data => {
                        this.loadEditableTypeList();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    });
                }
            });
            this.commonService.clearSystemCache().subscribe();
        } else {
            alert("All type label must be filled");
        }
    }

    onChangeCategory() {
        this.loadEditableTypeList();
    }

    mapMasterDesc() {
        return this.configMap.get(this.filter.selectedCategory);
    }


    onChangeTypeLabel() {
        this.loadEditableTypeList();
    }

    openAddTypesDialog() {
        let masterTypesDialofRef = this.dialog.open(MasterDialogComponent, {
            data: {
                category: this.filter.selectedCategory,
                categories: this.categories,
                pageType: "Type"
            }
        });

        masterTypesDialofRef.afterClosed().subscribe(data => {
            if (data.decision) {
                this.service.saveTypes(data.params).subscribe(
                    dataReturn => {
                        this.loadEditableTypeList();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    });
            }
        });
        this.commonService.clearSystemCache().subscribe();
    }

    get validateTypeLabel() {
        var result = true;
        this.rows.forEach(item => {
            if (item.label == "") {
                result = false;
            }
        })
        return result;
    }

    dropTable(event: CdkDragDrop<string[]>) {
        const prevIndex = this.rows.findIndex((d) => d === event.item.data);
        moveItemInArray(this.rows, prevIndex, event.currentIndex);
        this.table.renderRows();
    }

    checkPermission(functionCode: string) {
        return this.service.checkPermission(functionCode);
    }
}
