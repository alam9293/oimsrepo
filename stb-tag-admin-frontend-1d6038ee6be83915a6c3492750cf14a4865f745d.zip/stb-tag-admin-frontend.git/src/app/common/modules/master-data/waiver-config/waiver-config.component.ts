import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTable } from '@angular/material';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import * as cnst from '../../../../common/constants';
import { CommonService } from 'src/app/common/services';
import { MasterDataConfigService } from '../master-data.service';

@Component({
    selector: 'app-waiver-config',
    templateUrl: './waiver-config.component.html',
    styleUrls: ['./waiver-config.component.scss']
})
export class WaiverConfigComponent implements OnInit {

    @ViewChild(MatTable) _matTables;
    displayedColumns = ['type', 'isWaive'];
    form: FormGroup;
    cnst = cnst;

    constructor(
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private masterDataConfigService: MasterDataConfigService,
    ) { }

    ngOnInit() {
        this.loadWaiverTypes();
    }

    loadWaiverTypes() {
        this.buildForm();
        this.masterDataConfigService.getWaiverTypes().subscribe(data => {
            data.forEach(element => {
                this.addRow(element);
            });
        })
    }

    buildForm() {
        this.form = this.formBuilder.group({
            formArr: this.formBuilder.array([])
        })
    }

    addRow(value) {
        let row = this.formBuilder.group({
            key: [''],
            label: [''],
            data: [''],
        });
        if (value) {
            row.patchValue(value);
        }
        this.formArr.push(row);
        this._matTables.renderRows();
    }

    saveWaiverTypesConfig() {
        this.masterDataConfigService.updateWaiverTypes(this.formArr.value).subscribe(data => {
            this.form.markAsPristine();
            this.commonService.popSnackbar(null, 'success-snackbar');
            this.loadWaiverTypes();
        })
    }

    get formArr(): FormArray {
        return this.form.get('formArr') as FormArray;
    }
}
