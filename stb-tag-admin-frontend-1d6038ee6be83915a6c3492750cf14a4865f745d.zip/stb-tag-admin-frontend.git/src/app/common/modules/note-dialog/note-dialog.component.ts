import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import { FileUtil, FormUtil } from '../../../common/helper';

@Component({
    selector: 'app-note-dialog',
    templateUrl: './note-dialog.component.html',
    styleUrls: ['./note-dialog.component.scss']
})
export class NoteDialogComponent implements OnInit {

    constructor(public fileUtil: FileUtil, public dialogRef: MatDialogRef<NoteDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any, private formBuilder: FormBuilder) { }

    selectedFile: File;
    files: SupportingDocument[];
    note: any = {};
    form: FormGroup;
    emptyMsg: String = "*One of the input field must not be empty";
    maxLength: String = "Input Too Long (Max. 255)";
    ngOnInit() {
        if (!this.data) {
            this.data = {};
        }

        this.form = this.formBuilder.group({
            internalRemarks: ['', Validators.maxLength(255)],
            fileDoc: ['']
        }, {
            validator: Validators.compose(
                [
                    this.matchingAnyValidator("internalRemarks", "fileDoc", "missingAnyValue"),
                ]
            )
        }
        );
    }
    matchingAnyValidator(internalRemarks: string, fileDoc: string, errorGroup: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let linternalRemarks = group.controls[internalRemarks];
            let lfileDoc = group.controls[fileDoc];
            if ((linternalRemarks.value == null || (linternalRemarks.value || '').trim().length === 0) && (lfileDoc.value || 0) === 0) {
                return {
                    [errorGroup]: true
                };
            } else {

            }
        }
    }
    isEmptyOrSpaces(str: string) {
        return str === null || str.match(/^ *$/) !== null;
    }
    onFileChanged(event) {
        if (event.target.value) {
            this.selectedFile = event.target.files[0];
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                if (this.files == undefined) {
                    this.files = [{ fileDescription: '', file: this.selectedFile }];
                } else {
                    this.files.push({ fileDescription: '', file: this.selectedFile });
                }
                this.form.controls['fileDoc'].setValue(this.files.length);
                event.target.value = '';
            }
        }

    }

    removeArrayItem(files, element) {
        var index = files.indexOf(element);
        files.splice(index, 1);
        this.form.controls['fileDoc'].setValue(this.files.length);
        (<HTMLInputElement>document.getElementById("noteDialogNewInput")).value = '';
    }
    validateAllFormFields(formGroup: FormGroup) {         //{1}
        Object.keys(formGroup.controls).forEach(field => {  //{2}
            const control = formGroup.get(field);             //{3}
            if (control instanceof FormControl) {             //{4}
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup) {        //{5}
                this.validateAllFormFields(control);            //{6}
            }
        });
    }
    close(decision: boolean) {
        //  console.log(this.form.value);
        this.form.controls['fileDoc'].setValue(this.files ? this.files.length : 0);
        this.validateAllFormFields(this.form);
        if (!decision || this.form.valid) {
            // console.log(this.form.value);
            this.note['files'] = this.files;
            this.note['internalRemarks'] = this.form.controls['internalRemarks'].value;
            let obj = {
                decision: decision,
                params: this.note
            };
            this.dialogRef.close(obj);
        }
        else {

        }

    }
}

export interface SupportingDocument {
    fileDescription: String;
    file: File;
}
