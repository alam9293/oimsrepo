import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { PaymentRefundService } from '../../../main/payment-refund/payment-refund.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import * as cnst from '../../constants';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { MatDialog, MatDialogRef } from '@angular/material';
import { CommonService } from '../../services';
import { WorkflowService } from 'src/app/common/services/workflow.service';
import { Router } from '@angular/router';
import { ApplicationWorkflowComponent } from '../../../common/modules/application-workflow/application-workflow.component';

@Component({
    selector: 'app-payment-refund-details',
    templateUrl: './payment-refund-details.component.html',
    styleUrls: ['./payment-refund-details.component.scss']
})
export class PaymentRefundDetailsComponent implements OnInit {
    @Input() billRefNo: any;
    @Input() id: any;
    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;
    private dialogRef: MatDialogRef<any>;
    cnst = cnst;

    constructor(private service: PaymentRefundService,
        private formBuilder: FormBuilder,
        private dialog: MatDialog,
        private commonService: CommonService,
        private workflowService: WorkflowService,
        private router: Router, ) { }
    form: FormGroup = this.formBuilder.group({
        payerName: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
        billRefNo: ['', [Validators.required]],
        refundAmount: ['', [Validators.required, Validators.min(1), Validators.max(100000)]],
        bankAccountNo: ['', Validators.maxLength(cnst.maxLengthStr)],
    });
    paymentRefund: any = {};
    ngOnInit() {
        if (this.id) {
            this.service.getPaymentRefundById(this.id).subscribe(data => {
                this.paymentRefund = data;
                this.form.patchValue(data);
                if (data.status) {
                    this.form.disable();
                }
                if (this.workflowComp) {
                    this.workflowComp.loadWorkflowActions();
                }
            });
        } else {
            this.service.getPaymentRefund(this.billRefNo).subscribe(data => {
                this.paymentRefund = data;
                this.form.patchValue(data);
                if (data.status) {
                    this.form.disable();
                }
            });
        }

    }

    save() {
        if (this.form.invalid) {
            this.commonService.popSnackbar("Please ensure all mandatory fields have been fulfilled", null);
        } else {
            let workflowConfigService;
            if (this.paymentRefund.payReqTypeCode.includes('PAYREQ_TG')) {
                workflowConfigService = this.workflowService.getCeWorkflowConfigByType(cnst.WorkflowTypes.PAY_WKFLW_REFUND_TG);
            } else {
                workflowConfigService = this.workflowService.getCeWorkflowConfigByType(cnst.WorkflowTypes.PAY_WKFLW_REFUND_TA);
            }
            workflowConfigService.subscribe(data => {
                let dialogData: any = {
                    internalRemarks: true,
                    externalRemarks: false,
                    workflowConfig: data,
                    files: true
                }
                this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                    data: dialogData
                });
                this.dialogRef.afterClosed().subscribe(result => {
                    if (result.decision) {
                        let obj = this.commonService.buildFormData({ ...this.form.value, ...result.params }, result.files);
                        this.service.savePaymentRefund(obj).subscribe(data => {
                            let routerlink = '/payment-refund-view-id/' + data.id;
                            this.router.navigate([routerlink]);
                            this.commonService.popSnackbar(cnst.Messages.GENERIC_SUCCCESS, 'success-snackbar');
                        }, error => {
                            this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                        });
                    }
                });
            });
        }

    }

}
