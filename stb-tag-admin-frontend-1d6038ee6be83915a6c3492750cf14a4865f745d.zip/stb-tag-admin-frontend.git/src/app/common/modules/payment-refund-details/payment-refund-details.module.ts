import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatSelectModule, MatSortModule, MatTableModule, MatTabsModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { PaymentRefundDetailsComponent } from './payment-refund-details.component';
import { ApplicationWorkflowModule } from '../application-workflow/application-workflow.module';
import { NgxCurrencyModule } from 'ngx-currency';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        RouterModule,
        ReactiveFormsModule,
        ApplicationWorkflowModule,
        NgxCurrencyModule

    ],
    declarations: [PaymentRefundDetailsComponent],
    exports: [PaymentRefundDetailsComponent],
    entryComponents: []
})
export class PaymentRefundDetailsModule { }

