import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { WizDatetimePickerDirective, WizDatePickerDirective, WizTimePickerDirective } from '../directives';
import { KeyFilterPipe, wizDatePipe, PreviousValuePipe } from '../pipes';



@NgModule({
    imports: [CommonModule],
    declarations: [KeyFilterPipe, wizDatePipe, PreviousValuePipe, WizDatetimePickerDirective, WizDatePickerDirective, WizTimePickerDirective],
    exports: [KeyFilterPipe, wizDatePipe, PreviousValuePipe, WizDatetimePickerDirective, WizDatePickerDirective, WizTimePickerDirective]
})
export class SharedModule { }
