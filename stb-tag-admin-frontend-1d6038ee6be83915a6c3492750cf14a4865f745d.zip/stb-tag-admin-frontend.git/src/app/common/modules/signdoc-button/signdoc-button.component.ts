import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ViewChild, Input, ElementRef } from '@angular/core';
import * as cnst from '../../constants';

@Component({
    selector: 'signdoc-button',
    templateUrl: './signdoc-button.component.html',
    styleUrls: ['./signdoc-button.component.scss']
})
export class SigndocButtonComponent implements OnInit {

    @Input() toDisable: boolean;
    @Input() hasSigned: boolean;
    @Input() exportPdfToSignUrl: string;
    @Input() signdocId: string;
    @ViewChild('form') form: ElementRef;
    @ViewChild('docId') docId: ElementRef;

    constructor(private http: HttpClient) { }

    ngOnInit() { }

    initSigndocProcess() {
        this.http.post(cnst.apiBaseUrl + this.exportPdfToSignUrl, null, { responseType: 'text' }).subscribe(refId => {
            this.http.get<SigndocActivatePreLoadResp>(cnst.SigndocUrl.PRELOAD + refId, {
                headers: new HttpHeaders({
                    'Content-Type': 'application/json'
                })
            }).subscribe(resp => {
                this.form.nativeElement.action = cnst.SigndocUrl.SHOWGUI + resp.restLoadId.value;
                this.form.nativeElement.submit();
            })
        });
    }

    viewSigndoc() {
        this.form.nativeElement.action = cnst.SigndocUrl.VIEW + this.signdocId;
        this.form.nativeElement.submit();
    }

}
export class SigndocActivatePreLoadResp {
    restLoadId: RestLoadId;
}
export class RestLoadId {
    type: string;
    value: string;
}