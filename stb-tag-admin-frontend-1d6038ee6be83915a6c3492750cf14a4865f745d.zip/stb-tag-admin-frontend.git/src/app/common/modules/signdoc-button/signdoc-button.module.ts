import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatButtonModule, MatIconModule } from '@angular/material';
import { SigndocButtonComponent } from './signdoc-button.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        MatButtonModule,
        MatIconModule
    ],
    declarations: [SigndocButtonComponent,],
    exports: [SigndocButtonComponent]
})
export class SigndocButtonModule { }
