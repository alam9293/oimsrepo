import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatIconModule, MatDividerModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { SuccessSnackbarComponent } from './success-snackbar.component';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDividerModule,
        MatFormFieldModule,
        MatInputModule,
        FlexLayoutModule
    ],
    declarations: [SuccessSnackbarComponent],
    exports: [SuccessSnackbarComponent]
})
export class SuccessSnackbarModule { }

