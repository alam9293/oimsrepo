import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatButtonModule, MatIconModule, MatDividerModule } from '@angular/material';
import { TaElicencePreviewDialogComponent } from './ta-elicence-preview-dialog.component';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDividerModule,
        MatDialogModule
    ],
    declarations: [TaElicencePreviewDialogComponent],
    exports: [TaElicencePreviewDialogComponent]
})
export class TaElicencePreviewDialogModule { }
