import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';

@Injectable({
    providedIn: 'root'
})
export class TaElicenceDialogService {

    constructor(private http: HttpClient) { }

    download(dto: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.TaApiUrl.TA_ELICENCE_REQUEST + '/download', dto, { responseType: 'blob' });
    }

    getTaELicenceDetails(licenceId: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/ta/elicence-request/getTaELicenceDetails', { licenceId: licenceId }, { responseType: 'json' });
    }
}
