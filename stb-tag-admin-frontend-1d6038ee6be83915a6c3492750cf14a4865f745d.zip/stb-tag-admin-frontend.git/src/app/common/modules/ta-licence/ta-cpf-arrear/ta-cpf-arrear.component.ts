import { Component, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import * as cnst from '../../../../common/constants';
import { TaLicenceService } from '../ta-licence.service';
import { DateUtil } from './../../../helper/date.util';

@Component({
    selector: 'app-ta-cpf-arrear',
    templateUrl: './ta-cpf-arrear.component.html',
    styleUrls: ['./ta-cpf-arrear.component.scss']
})
export class TaCpfArrearComponent implements OnInit {

    @Input() id: number;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    cpfArrearRecords = [];
    cpfArrearColumns = ['no', 'forMonth', 'hasCpfArrear'];
    cnst = cnst;
    DateUtil = DateUtil;

    constructor(private service: TaLicenceService, private dateUtil: DateUtil) { }

    ngOnInit() {
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.load();
        }
    }

    load() {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active ? this.sort.active : '',
            'order': this.sort.direction,
        };
        this.service.getCpfArrears(this.id, mergedDto).subscribe(data => {
            this.cpfArrearRecords = data.records;
            this.paginator.length = data.total;
        });
    }

}
