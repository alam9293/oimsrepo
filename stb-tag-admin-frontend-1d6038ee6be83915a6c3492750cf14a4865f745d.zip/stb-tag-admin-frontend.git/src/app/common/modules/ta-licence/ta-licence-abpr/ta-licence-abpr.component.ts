import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { TaLicenceService } from '../ta-licence.service';
import { MatTableDataSource } from '@angular/material';
import * as _ from 'lodash';
import { NumeralUtil } from '../../../../common/helper';

@Component({
    selector: 'app-ta-licence-abpr',
    templateUrl: './ta-licence-abpr.component.html',
    styleUrls: ['./ta-licence-abpr.component.scss']
})
export class TaLicenceAbprComponent implements OnInit {
    @Input() id: number;
    fys = [];
    abpr: any = {};
    selectedFy: number;
    msInboundDataSource = new MatTableDataSource<any>();
    msInboundDisplayedColumns = ['no', 'country', 'percentage'];
    msOutboundDataSource = new MatTableDataSource<any>();
    msOutboundDisplayedColumns = ['no', 'country', 'percentage'];
    boDataSource = new MatTableDataSource<any>();
    boDisplayedColumns = ['no', 'services', 'inbound', 'inboundOwn', 'outbound', 'outboundOwn'];
    aofDataSource = new MatTableDataSource<any>();
    aofDisplayedColumns = ['no', 'areaOfFocus', 'inbound', 'outbound', 'hasOp', 'remarks'];
    totalBoDataSource = new MatTableDataSource<any>();
    totalBoDisplayedColumns = ['type', 'amt', 'percent'];
    phDataSource = new MatTableDataSource<any>();
    phDisplayedColumns = ['type', 'inboundAmt', 'inboundPer', 'outboundAmt', 'outboundPer'];
    faDataSource = new MatTableDataSource<any>();
    faDisplayedColumns = ['no', 'question', 'inbound', 'outbound'];
    otherDataSource = new MatTableDataSource<any>();
    otherDisplayedColumns = ['no', 'type', 'value'];

    constructor(private service: TaLicenceService) { }

    ngOnInit() {

        this.service.getAbprFys(this.id).subscribe(data => {
            this.fys = data;
            if (this.fys.length > 0) {
                this.selectedFy = this.fys[0].key;
                this.loadAbpr();
            }

        });

    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.service.getAbprFys(this.id).subscribe(data => {
                this.fys = data;
                if (this.fys.length > 0) {
                    this.selectedFy = this.fys[0].key;
                    this.loadAbpr();
                }

            });
        }
    }

    loadAbpr() {
        this.service.getAbpr(this.selectedFy).subscribe(data => {
            this.abpr = data;
            this.msInboundDataSource = data.inboundms;
            this.msOutboundDataSource = data.outboundms;
            this.boDataSource = data.bo;
            this.aofDataSource = data.aof;
            if (data.aof && data.aof.length > 0) {
                let firstAof = data.aof[0];
                if (firstAof.inbound == null && firstAof.outbound == null) {
                    this.aofDisplayedColumns = ['no', 'areaOfFocus', 'hasOp', 'remarks'];
                } else {
                    this.aofDisplayedColumns = ['no', 'areaOfFocus', 'inbound', 'outbound', 'remarks'];
                }
            }
            this.faDataSource = data.fa;
            let totalBo: any = [{ type: 'Inbound', amt: data.inboundOp, percent: data.inboundOpPercent },
            { type: 'Outbound', amt: data.outboundOp, percent: data.outboundOpPercent }];
            this.totalBoDataSource = totalBo;
            let ph: any = [{ type: 'Group', inboundAmt: data.inboundGrpPax, inboundPer: data.inboundGrpPaxPercent, outboundAmt: data.outboundGrpPax, outboundPer: data.outboundGrpPaxPercent },
            { type: 'FITs', inboundAmt: data.inboundFitPax, inboundPer: data.inboundFitPaxPercent, outboundAmt: data.outboundFitPax, outboundPer: data.outboundFitPaxPercent }];
            this.phDataSource = ph;
            let others: any = [{ type: 'Number of Staff Employed', value: data.noOfEmployee },
            { type: 'Operating cost incurred', value: data.operatingCost, isNumeral: true },
            { type: 'Depreciation of Fixed Assets', value: data.depreciation, isNumeral: true },
            { type: 'Remuneration', value: data.remuneration, isNumeral: true },
            { type: 'Indirect Tax', value: data.indirectTax, isNumeral: true },
            { type: 'Any overseas branches?', value: data.hasOverseasBranch === true ? 'Yes' : 'No', isNumeral: false }];
            this.otherDataSource = others;
        });
    }

    getBoTotalInboundAmount() {
        let total: number = 0;
        _.forEach(this.boDataSource, function (value) {
            total += Number(NumeralUtil.parseNumeric(value.inbound));
        }.bind(this));
        return total;
    }

    getBoTotalOutboundAmount() {
        let total = 0;
        _.forEach(this.boDataSource, function (value) {
            total += Number(NumeralUtil.parseNumeric(value.outbound));
        }.bind(this));
        return total;
    }

    getMsTotalInboundAmount() {
        let total = 0;
        _.forEach(this.msInboundDataSource, function (value) {
            total += value.percentage;
        }.bind(this));
        return total;
    }

    getMsTotalOutboundAmount() {
        let total = 0;
        _.forEach(this.msOutboundDataSource, function (value) {
            total += value.percentage;
        }.bind(this));
        return total;
    }
}
