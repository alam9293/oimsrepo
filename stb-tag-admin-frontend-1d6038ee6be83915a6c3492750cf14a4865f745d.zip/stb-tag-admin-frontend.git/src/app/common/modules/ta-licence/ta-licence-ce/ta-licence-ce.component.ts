import { Component, OnInit, SimpleChanges, Input, ViewChild } from '@angular/core';
import { TaLicenceService } from '../ta-licence.service';
import { CeCaseRelevantOffencesComponent } from '../../../../main/ce/ce-case/ce-case-relevant-offences/ce-case-relevant-offences.component';
@Component({
    selector: 'app-ta-licence-ce',
    templateUrl: './ta-licence-ce.component.html',
    styleUrls: ['./ta-licence-ce.component.scss']
})
export class TaLicenceCeComponent implements OnInit {

    @Input() id: number;
    @ViewChild(CeCaseRelevantOffencesComponent) ceCaseRelevantOffencesComponent: CeCaseRelevantOffencesComponent;

    constructor(public taLicenceService: TaLicenceService) { }

    ngOnInit() {
        this.load();
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.load();
        }
    }

    load() {
        this.taLicenceService.getPastInfringements(this.id).subscribe(data => {
            this.ceCaseRelevantOffencesComponent.loadDetails(data);
        })
    }

}
