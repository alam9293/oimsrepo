import { Component, OnInit, Input, Inject, ViewChild, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { TaLicenceService } from '../ta-licence.service';
import { MatTableDataSource, MatDialogRef, MatDialog, MAT_DIALOG_DATA, MatSort } from '@angular/material';
import { FormUtil } from '../../../../common/helper';
import * as cnst from '../../../constants'
@Component({
    selector: 'app-ta-licence-details',
    templateUrl: './ta-licence-details.component.html',
    styleUrls: ['./ta-licence-details.component.scss']
})
export class TaLicenceDetailsComponent implements OnInit {
    @Input() id: number;
    cnst = cnst;
    activeBranches = new MatTableDataSource<any>();
    formerBranches = [];
    branchesDisplayColumns = ['no', 'address', 'status'];
    licence: any = { tier: {}, formOfBusiness: {}, businessConstitution: {}, principleActivity: {}, secondaryPrincipleActivity: {}, placeIncorporated: {}, statusOfEstablishment: {}, taSegmentation: {}, registeredAddress: { premisesType: {}, type: {} }, operatingAddress: { premisesType: {} }, activeBranches: {}, displayAddress: { premisesType: {} } };
    constructor(private service: TaLicenceService, public dialog: MatDialog, public formUtil: FormUtil) { }

    ngOnInit() {
        this.service.getDetails(this.id).subscribe(data => {
            console.log('details');
            this.licence = data;
            this.activeBranches = data.activeBranches;
            this.formerBranches = data.formerBranches;
        });

    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.service.getDetails(this.id).subscribe(data => {
                console.log('details');
                this.licence = data;
                this.activeBranches = data.activeBranches;
                this.formerBranches = data.formerBranches;
            });
        }
    }

    openCeasedDialog() {
        this.dialog.open(DialogTaCeasedBranches, {
            data: this.formerBranches,
            width: '800px',
            height: '600px'
        });
    }

    getDetails() {
        let data = this.licence;
        return data;
    }

}

@Component({
    selector: 'ta-ceased-branches-dialog',
    templateUrl: 'ta-ceased-branches-dialog.html'
})
export class DialogTaCeasedBranches {

    constructor(
        public dialogRef: MatDialogRef<DialogTaCeasedBranches>, @Inject(MAT_DIALOG_DATA) public data: any) { }

    ceased = this.data;
    ceasedDataSource = new MatTableDataSource(this.ceased);
    ceasedDisplayedColumns = ['no', 'address', 'ceasedDate'];

    @ViewChild(MatSort) sort: MatSort;

    onNoClick(): void {
        this.dialogRef.close();
    }

    ngOnInit() {
        this.ceasedDataSource.sort = this.sort;
        this.ceasedDataSource.sortingDataAccessor = (item, property) => {
            switch (property) {
                case 'ceasedDate': return new Date(item['ceasedDate']);
                default: return item[property];
            }
        };
    }
}
