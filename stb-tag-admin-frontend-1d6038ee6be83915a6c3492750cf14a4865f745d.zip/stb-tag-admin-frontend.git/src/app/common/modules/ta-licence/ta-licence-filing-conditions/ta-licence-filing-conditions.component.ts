import { Component, Input, OnInit, ViewChild, SimpleChanges } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/common/services';
import * as cnst from '../../../../common/constants';
import { StyleHelper } from '../../../../common/helper';
import { TaLicenceService } from '../ta-licence.service';


@Component({
  selector: 'app-ta-licence-filing-conditions',
  templateUrl: './ta-licence-filing-conditions.component.html',
  styleUrls: ['./ta-licence-filing-conditions.component.scss']
})
export class TaLicenceFilingConditionsComponent implements OnInit {

  @Input() id: number;
  // @Input() listingId: string;
  filter: any = {};
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  rows = [];
  cnst = cnst;
  subscription: Subscription;
  myApplications: boolean = true;
  displayedColumns = ['no', 'type', 'refFy', 'fyStartDate', 'fyEndDate', 'recAsAt', 'dueDate', 'extendedDueDate', 'status'];
  filingTypes: any = [];

  constructor(private commonService: CommonService,
    private service: TaLicenceService,
    public styleHelper: StyleHelper) { }

  ngOnInit() {
    this.load(false);
    this.loadCommonTypes();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.id) {
      this.load(false);
    }
  }

  load(fromInit: boolean): void {
    this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromInit, null);
    this.setMyApplicationsAndDefaultAppStatus(fromInit);
    this.service.getLicenceFilingConditions(this.filter).subscribe(data => {
      this.rows = data.records;
      this.paginator.length = data.total;
      this.commonService.cacheSearchDto(this.filter);
    });

  }

  setMyApplicationsAndDefaultAppStatus(fromInit: boolean) {
    if (this.id) {
      this.filter.myApplications = false;
      this.filter.licenceId = this.id ? this.id : '';
    }
  }

  loadCommonTypes() {
    this.commonService.getTaFilingConditionTypes().subscribe(data => this.filingTypes = data);
  }

  clearFilter() {
    this.filter.filingTypes = [];
    this.load(false)
  }


}
