import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { TaLicenceService } from '../ta-licence.service';
import * as cnst from '../../../../common/constants';

@Component({
    selector: 'app-ta-licence-finance',
    templateUrl: './ta-licence-finance.component.html',
    styleUrls: ['./ta-licence-finance.component.scss']
})
export class TaLicenceFinanceComponent implements OnInit {
    @Input() id: number;

    aaRecords = [];
    maRecords = [];
    aaRecordsColumns = ['no', 'fy', 'fyp', 'capital', 'revenue', 'netValue', 'shortfall', 'netProfitLoss', 'accProfitLoss'];
    maRecordsColumns = ['no', 'asatDate', 'capital', 'totalAssets', 'totalLiabilities', 'netValue', 'shortfall'];
    cnst = cnst;

    constructor(private service: TaLicenceService) { }

    ngOnInit() {
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.load();
        }
    }

    load() {
        this.service.getFinancialAa(this.id).subscribe(data => {
            this.aaRecords = data;
        });
        this.service.getFinancialMa(this.id).subscribe(data => {
            this.maRecords = data;
        });
    }
}