import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { TaLicenceService } from '../ta-licence.service';
@Component({
    selector: 'app-ta-licence-past',
    templateUrl: './ta-licence-past.component.html',
    styleUrls: ['./ta-licence-past.component.scss']
})
export class TaLicencePastComponent implements OnInit {
    @Input() id: number;
    record: any = { otherLicences: {} };
    otherLicences = new MatTableDataSource<any>();
    otherLicencesColumns = ['no', 'licenceNo', 'issueDate', 'ceasedDate', 'status'];

    statusSpan: any = [];
    statusSpanColumns = ['no', 'status', 'startDate', 'endDate', 'tier', 'updatedBy', 'updatedDate', 'remarks'];

    constructor(private service: TaLicenceService) { }

    ngOnInit() {
        this.load();
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.load();
        }
    }

    load() {
        this.service.getPast(this.id).subscribe(data => {
            this.record = data;
            this.otherLicences = data.otherLicences;
        });
        this.service.getStatusSpan(this.id).subscribe(data => {
            this.statusSpan = data;
        });
    }

}
