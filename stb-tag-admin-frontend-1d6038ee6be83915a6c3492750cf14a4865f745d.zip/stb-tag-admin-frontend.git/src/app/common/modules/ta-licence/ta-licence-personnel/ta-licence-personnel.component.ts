import { Component, OnInit, Input, ViewChild, Inject, SimpleChanges } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { TaPersonnelDialogComponent } from '../../ta-personnel-dialog/ta-personnel-dialog.component';
import { TaLicenceService } from '../ta-licence.service';
import { FormUtil, DateUtil } from '../../../../common/helper';
import * as cnst from '../../../../common/constants';

@Component({
    selector: 'app-ta-licence-personnel',
    templateUrl: './ta-licence-personnel.component.html',
    styleUrls: ['./ta-licence-personnel.component.scss']
})
export class TaLicencePersonnelComponent implements OnInit {
    @Input() id: number;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    personnels: any = [];
    ke: any = { particulars: { sex: {}, nationality: {}, address: { type: {} }, highestEduLevel: {}, designation: {} }, involvements: [{ role: {}, designation: {}, highestEduLevel: {}, taKeDeclarations: [{ clause: {} }] }] };
    personnelRecords = new MatTableDataSource<any>();
    personnelRecordsColumns = ['no', 'name', 'ID', 'role', 'appointedDate', 'resignedDate', 'info'];
    cnst = cnst;
    constructor(private service: TaLicenceService, public dialog: MatDialog, public formUtil: FormUtil) { }

    ngOnInit() {
        this.loadPersonnals();
        this.loadKe();
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.loadPersonnals();
            this.loadKe();
        }
    }

    loadPersonnals() {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active ? this.sort.active : '',
            'order': this.sort.direction,
        };
        this.service.getPersonnels(this.id, mergedDto).subscribe(data => {
            this.personnels = data.records;
            this.personnelRecords = data.records;
            this.paginator.length = data.total;
        });
    }

    loadKe() {
        this.service.getKe(this.id).subscribe(data => this.ke = data);
    }

    isTodayOrFutureDate(date: any) {
        return date && DateUtil.parseDate(date).isSameOrAfter(DateUtil.getNowAsStartOfDay());
    }

    isFutureDate(date: any) {
        return date && DateUtil.parseDate(date).isAfter(DateUtil.getNowAsStartOfDay());
    }

    personnelDialogRef: MatDialogRef<TaPersonnelDialogComponent>;
    openTaPersonnelDetailsDialog(id) {
        this.personnelDialogRef = this.dialog.open(TaPersonnelDialogComponent, {
            data: {
                id: id,
                height: '600px',
                width: '800px',
            }
        });
    }
}