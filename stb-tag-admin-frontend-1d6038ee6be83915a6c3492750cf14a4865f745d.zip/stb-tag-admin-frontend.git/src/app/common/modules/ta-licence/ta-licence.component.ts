import { Component, OnInit, Input, ViewChild, EventEmitter, Output, } from '@angular/core';
import { MatPaginator, MatSort, MatDialog } from '@angular/material';
import { AuthenticationService } from '../../../common/services';
import { TaLicenceDetailsComponent } from '../../../common/modules/ta-licence/ta-licence-details/ta-licence-details.component';

@Component({
    selector: 'app-ta-licence',
    templateUrl: './ta-licence.component.html',
    styleUrls: ['./ta-licence.component.scss']
})
export class TaLicenceComponent implements OnInit {
    @Input() id: number;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(TaLicenceDetailsComponent) taLicenceDetails: TaLicenceDetailsComponent;
    tabLoaded: any[] = [0];

    constructor(public dialog: MatDialog, private authenticationService: AuthenticationService) { }
    app: string;
    ngOnInit() {
    }

    public checkPermission(functionCode: string): boolean {
        return this.authenticationService.checkPermission(functionCode);
    }

    getData() {
        return this.taLicenceDetails.getDetails();
    }

}
