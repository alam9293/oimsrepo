import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';
import { MatButtonModule, MatDialogModule, MatDividerModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatSelectModule, MatSortModule, MatTableModule, MatTabsModule, MatTooltipModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { CeCaseRelevantOffencesModule } from '../../../main/ce/ce-case/ce-case-relevant-offences/ce-case-relevant-offences.module';
import { TaLicenceAbprComponent } from './ta-licence-abpr/ta-licence-abpr.component';
import { DialogTaCeasedBranches, TaLicenceDetailsComponent } from './ta-licence-details/ta-licence-details.component';
import { TaLicenceFinanceComponent } from './ta-licence-finance/ta-licence-finance.component';
import { TaLicencePastComponent } from './ta-licence-past/ta-licence-past.component';
import { TaLicencePersonnelComponent } from './ta-licence-personnel/ta-licence-personnel.component';
import { TaLicenceComponent } from './ta-licence.component';
import { TaLicenceCeComponent } from './ta-licence-ce/ta-licence-ce.component';
import { TaCpfArrearComponent } from './ta-cpf-arrear/ta-cpf-arrear.component';
import { SharedModule } from '../shared.module';
import { TaLicenceFilingConditionsComponent } from './ta-licence-filing-conditions/ta-licence-filing-conditions.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        RouterModule,
        CeCaseRelevantOffencesModule,
        SharedModule,
        MatTooltipModule
    ],
    declarations: [TaLicenceComponent, TaLicenceDetailsComponent, TaLicenceFinanceComponent, TaLicenceAbprComponent, TaLicencePersonnelComponent, DialogTaCeasedBranches, TaLicencePastComponent, TaLicenceCeComponent, TaCpfArrearComponent, TaLicenceFilingConditionsComponent],
    exports: [TaLicenceComponent],
    entryComponents: [DialogTaCeasedBranches]
})
export class TaLicenceModule { }

