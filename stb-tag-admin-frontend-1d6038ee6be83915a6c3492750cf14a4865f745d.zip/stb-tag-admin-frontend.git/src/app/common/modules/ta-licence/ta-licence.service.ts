import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';

@Injectable({
    providedIn: 'root'
})
export class TaLicenceService {

    constructor(private http: HttpClient) { }

    getDetails(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/view/details/' + id);
    }

    getAbprFys(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/abpr/view/fys/' + id);
    }
    getAbpr(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/abpr/view/' + id);
    }
    getFinancialAa(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/financial/view/aa/' + id);
    }
    getFinancialMa(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/financial/view/ma/' + id);
    }
    getPersonnels(id: number, searchDto): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/personnels/view/' + id, { params: searchDto });
    }

    getPersonnel(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/personnels/view/personnel/' + id);
    }
    getKe(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/personnels/view/ke/' + id);
    }
    getPast(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/past-history/view/' + id);
    }
    getStatusSpan(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/past-history/view/status-span/' + id);
    }
    getPastInfringements(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/past-infringements/view/' + id);
    }
    getCpfArrears(id: number, searchDto): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/cpf-arrears/view/' + id, { params: searchDto });
    }
    getLicenceFilingConditions(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/ta/licences/filing-conditions/view', { params: searchDto });
    }
}
