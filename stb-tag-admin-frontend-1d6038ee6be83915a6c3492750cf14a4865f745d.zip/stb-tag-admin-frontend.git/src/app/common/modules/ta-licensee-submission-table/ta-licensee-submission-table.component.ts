import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, } from '@angular/material';
import * as cnst from '../../../common/constants';
import { TaLicenseeSubmissionTableService } from './ta-licensee-submission-table.service';
import { StyleHelper } from '../../helper';

@Component({
    selector: 'app-ta-licensee-submission-table',
    templateUrl: './ta-licensee-submission-table.component.html',
    styleUrls: ['./ta-licensee-submission-table.component.scss']
})
export class TaLicenseeSubmissionTableComponent implements OnInit {

    @Input() dataSource: any = [];
    @Input() columnsToDisplay: any = [];
    @Input() licenceId: number;
    @Input() excludeSubmissionType: string;
    myApplications: boolean = false; // default to show all applications
    filter: any = {};

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    rows = [];
    cnst = cnst;

    constructor(
        public styleHelper: StyleHelper, private service: TaLicenseeSubmissionTableService, ) { }

    ngOnInit() {
        this.loadTaApplications();
    }

    loadTaApplications() {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active ? this.sort.active : '',
            'order': this.sort.direction,
            'myApplications': this.myApplications,
            'excludeSubmissionType': this.excludeSubmissionType,
            'licenceId': this.licenceId,
            ...this.filter
        };
        this.service.getList(mergedDto).subscribe(data => {
            data.records.forEach(element => {
                element.url = cnst.TaFrontEndUrl[element.type] + "/" + element.applicationId;
            });
            this.rows = data.records;
            this.paginator.length = data.total;
        });
    }

}
