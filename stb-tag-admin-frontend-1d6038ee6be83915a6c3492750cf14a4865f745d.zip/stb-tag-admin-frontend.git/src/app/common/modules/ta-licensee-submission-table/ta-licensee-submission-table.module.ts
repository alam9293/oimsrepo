import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatDividerModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatIconModule, MatSelectModule, MatTooltipModule, MatButtonToggleModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatPaginatorModule, MatSortModule, MatTableModule, MatDialogModule } from '@angular/material';
import { TaLicenseeSubmissionTableComponent } from './ta-licensee-submission-table.component'
import { RouterModule } from '@angular/router';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule
    ],
    declarations: [TaLicenseeSubmissionTableComponent],
    exports: [TaLicenseeSubmissionTableComponent]
})
export class TaLicenseeSubmissionTableModule { }
