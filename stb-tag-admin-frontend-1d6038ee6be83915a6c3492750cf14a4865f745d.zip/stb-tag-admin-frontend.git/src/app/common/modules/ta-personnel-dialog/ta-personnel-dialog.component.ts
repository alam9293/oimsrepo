import { Component, OnInit, Inject, Input } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormUtil } from '../../../common/helper';
import { TaLicenceService } from '../ta-licence/ta-licence.service';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-ta-personnel-dialog',
    templateUrl: './ta-personnel-dialog.component.html',
    styleUrls: ['./ta-personnel-dialog.component.scss']
})
export class TaPersonnelDialogComponent implements OnInit {

    cnst = cnst;

    constructor(
        public dialogRef: MatDialogRef<TaPersonnelDialogComponent>,
        public formUtil: FormUtil,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private service: TaLicenceService,
    ) { }

    personnel: any = { particulars: { sex: {}, nationality: {}, address: { type: {} } }, involvements: [{ role: {} }] };
    ngOnInit() {

        if (!this.data) {
            this.data = {};
        }

        setTimeout(() => {
            this.service.getPersonnel(this.data.id).subscribe(data => {
                this.personnel = data;
            });
        });
    }
}
