import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatIconModule, MatDividerModule, MatFormFieldModule, MatInputModule } from '@angular/material';
import { TaPersonnelDialogComponent } from './ta-personnel-dialog.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatPaginatorModule, MatSortModule, MatTableModule, MatDialogModule } from '@angular/material';
import { RouterModule } from '@angular/router';

@NgModule({
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDividerModule,
        MatFormFieldModule,
        MatInputModule,
        FlexLayoutModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatPaginatorModule
    ],
    declarations: [TaPersonnelDialogComponent],
    exports: [TaPersonnelDialogComponent]
})
export class TaPersonnelDialogModule { }

