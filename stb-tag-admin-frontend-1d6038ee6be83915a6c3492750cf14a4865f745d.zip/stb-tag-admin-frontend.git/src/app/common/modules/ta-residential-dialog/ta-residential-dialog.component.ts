import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../../common/services';
import { FileUtil, FormUtil } from '../../../common/helper';
import { CroppieDialogComponent } from '../../../main/croppie/croppie-dialog/croppie-dialog.component';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
    selector: 'app-ta-residential-dialog',
    templateUrl: './ta-residential-dialog.component.html',
    styleUrls: ['./ta-residential-dialog.component.scss']
})
export class TaResidentialDialogComponent implements OnInit {

    cnst = cnst;
    premises_types = [];
    data: any;

    constructor(
        @Inject(MAT_DIALOG_DATA) public detail: any,
        public dialogRef: MatDialogRef<TaResidentialDialogComponent>,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        public dialog: MatDialog,
        private _sanitizer: DomSanitizer,
        public formUtil: FormUtil,) { }

    ngOnInit() {
        this.data = this.getDefault();
        console.log("detail :" + this.detail);
        this.loadCommonTypes();
        if (this.detail != null) {
            this.data.displayName = this.detail.displayName;
            this.data.displayAddr = this.detail.displayAddress;
        }
    }

    getDefault() {
        return { displayName: '', displayAddr: {} };
    }

    loadCommonTypes() {
        this.commonService.getPremiseTypes().subscribe(data => {
            this.premises_types = data;
        });
    }

    close(decision: boolean) {
        let obj = {
            decision: decision,
            params: this.data
        };
        this.dialogRef.close(obj);
    }
}
