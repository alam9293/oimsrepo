import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../../common/services';
import { FileUtil, FormUtil } from '../../../common/helper';

@Component({
    selector: 'app-tg-elicence-dialog',
    templateUrl: './tg-elicence-dialog.component.html',
    styleUrls: ['./tg-elicence-dialog.component.scss']
})
export class TgELicenceDialogComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<TgELicenceDialogComponent>,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        public dialog: MatDialog,
        public formUtil: FormUtil,
    ) { }

    cnst = cnst;
    isWorkPassHolder: Boolean;
    form = this.formBuilder.group({
        id: [],
        displayName: ['', [Validators.maxLength(cnst.maxLengthStr)]],
        displayEmployerName: [''],
        displaySecondName: ['', [Validators.maxLength(cnst.maxLengthStr)]],
        displaySecondEmployerName: ['']
    });

    ngOnInit() {
        this.form.patchValue(this.data);
        this.isWorkPassHolder = !this.data.nric.toLowerCase().startsWith("s") && !this.data.nric.toLowerCase().startsWith("t");
        if (!this.isWorkPassHolder) {
            this.form.get("displayEmployerName").setValue(null);
            this.form.get("displaySecondEmployerName").setValue(null);
        }
    }

    close(decision: boolean) {
        let obj = {
            decision: decision,
            params: this.form.value
        };
        this.dialogRef.close(obj);
    }
}
