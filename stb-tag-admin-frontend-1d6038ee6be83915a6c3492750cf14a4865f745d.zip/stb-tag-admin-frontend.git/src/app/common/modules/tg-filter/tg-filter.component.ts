import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import * as _ from 'lodash';

import * as cnst from '../../../common/constants';
import { WorkflowHelper } from '../../helper';
import { CommonService, AuthenticationService } from '../../services';

@Component({
    selector: 'app-tg-filter',
    templateUrl: './tg-filter.component.html',
    styleUrls: ['./tg-filter.component.scss']
})
export class TgFilterComponent implements OnInit {

    @Input() module: string;
    filter: any = {};
    applicationStatuses: any = [];
    applicationTypes: any = [];
    tgCourseApplicationTypes: any = [];
    tgApplicationTypes: any = [];
    cnst = cnst;

    showLicenceNo: boolean = true;
    showAssignedOfficer: boolean = true;
    showAppType: boolean = false;
    showNricFin: boolean = true;
    showTpName: boolean = false;
    showPendingFollowUp: boolean = false;
    isFinanceRole: boolean = false;

    constructor(
        private authenticationService: AuthenticationService,
        private workflowHelper: WorkflowHelper,
        private commonService: CommonService) { }

    ngOnInit() {
        this.isFinanceRole = this.authenticationService.currentUserValue && this.authenticationService.currentUserValue.selectedRole.key == cnst.ApplicationRoles.FINANCE
        if (this.module == cnst.Module.MODULE_TG_CREATION) {
            this.showLicenceNo = false;
        } else if (this.module == cnst.Module.MODULE_TG_ALL_APPLICATION || this.module == cnst.Module.MODULE_TG_ALL_COURSE_APPLICATION) {
            this.showAppType = true;
            this.showAssignedOfficer = false;
            this.showNricFin = false;
        } else if (this.module == cnst.Module.MODULE_TG_STIPEND && this.isFinanceRole) {
            this.showPendingFollowUp = true;
        }

        if (this.module == cnst.Module.MODULE_TG_COURSE_CREATION || this.module == cnst.Module.MODULE_TG_ALL_COURSE_APPLICATION) {
            this.showLicenceNo = false;
            this.showNricFin = false;
            this.showTpName = true;
        }
    }

    setDefaultAppStatus() {
        let status = this.workflowHelper.currentUserAppPendingStatus;
        if (status) {
            this.filter.statuses = status;
        }
    }

    loadCommonTypes(module: string) {

        this.commonService.getTgApplicationStatuses().subscribe(data => {
            if (module == cnst.Module.MODULE_TG_ALL_APPLICATION || module == cnst.Module.MODULE_TG_ALL_COURSE_APPLICATION) {
                this.applicationStatuses = data;
            } else {
                var notIncludeStatuses = [cnst.ApplicationStatuses.TG_APP_APPROVED, cnst.ApplicationStatuses.TG_APP_RFA, cnst.ApplicationStatuses.TG_APP_REJECTED];
                this.applicationStatuses = _.filter(data, function (status) {
                    return !notIncludeStatuses.includes(status.key);
                });
            }
        });

        if (module == cnst.Module.MODULE_TG_ALL_APPLICATION || module == cnst.Module.MODULE_TG_ALL_COURSE_APPLICATION) {
            var notIncludeAppTypes = [cnst.ApplicationTypes.TG_APP_MRC_SUBMISSION, cnst.ApplicationTypes.TG_APP_PDC_SUBMISSION,
            cnst.ApplicationTypes.TG_APP_MLPT_REGISTRATION, cnst.ApplicationTypes.TG_APP_SWITCH_TIER,
            cnst.ApplicationTypes.TG_APP_COURSE_RENEWAL, cnst.ApplicationTypes.TG_APP_COURSE_CREATION,
            ];
            var courseAppTypes = [cnst.ApplicationTypes.TG_APP_COURSE_RENEWAL, cnst.ApplicationTypes.TG_APP_COURSE_CREATION];

            this.commonService.getTgApplicationTypes().subscribe(data => {
                this.tgCourseApplicationTypes = _.filter(data, function (applicationType) {
                    return courseAppTypes.includes(applicationType.key);
                });
                this.tgApplicationTypes = _.filter(data, function (applicationType) {
                    return !notIncludeAppTypes.includes(applicationType.key);
                });
                this.toggleCommonTypes();
            });
        }
    }

    toggleCommonTypes() {
        if (this.module == cnst.Module.MODULE_TG_ALL_COURSE_APPLICATION) {
            this.applicationTypes = this.tgCourseApplicationTypes;
            this.showLicenceNo = false;
            this.showTpName = true;
        } else if (this.module == cnst.Module.MODULE_TG_ALL_APPLICATION) {
            this.applicationTypes = this.tgApplicationTypes;
            this.showLicenceNo = true;
            this.showTpName = false;
        }

        // clear filter if not in list
        var keylists = this.applicationTypes.map(key => key.key);
        if (!keylists.includes(this.filter.applicationType)) {
            delete this.filter.applicationType;
        }
    }
}
