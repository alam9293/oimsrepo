import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../../common/services';
import { FileUtil, FormUtil } from '../../../common/helper';

@Component({
    selector: 'app-tg-info-details-dialog',
    templateUrl: './tg-info-details-dialog.component.html',
    styleUrls: ['./tg-info-details-dialog.component.scss']
})
export class TgInfoDetailsDialogComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        @Inject(MAT_DIALOG_DATA) public licenceId: any,
        public dialogRef: MatDialogRef<TgInfoDetailsDialogComponent>,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        public dialog: MatDialog,
        public formUtil: FormUtil,
    ) { }
    cnst = cnst;
    title: any;
    tgInfoTypes: any;
    selectedFile: File;
    selectedFiles: any = [];
    unionMap = new Map<string, string>();
    form = this.formBuilder.group({
        id: [],
        touristGuideId: [],
        licenceId: [],
        personName: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
        companyName: ['', [Validators.maxLength(cnst.maxLengthStr)]],
        typeCode: [''],
        typeOther: [''],
        details: ['', [Validators.required, Validators.maxLength(cnst.maxLengthRemarks)]],
        files: [],
        totalDoc: [''],
        deletedFileIds: [[]]
    });

    ngOnInit() {
        this.commonService.getTgInfoTypes().subscribe(data => this.tgInfoTypes = data);
        this.form.get('licenceId').setValue(this.licenceId.licenceId);
        var tgInfo = this.data.tgInfo;
        if (tgInfo == '-1') {//new
            this.title = 'Add Person Providing the Feedback';
        } else {
            this.title = 'Edit Case Details';
            this.form.patchValue(tgInfo);
            if (tgInfo.files) {
                this.selectedFiles = tgInfo.files;
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            }
        }
    }

    onCategoryChange() {
        if (this.form.get('typeCode').value == cnst.TgInfoType.OTHERS) {
            this.form.get('typeOther').setValidators([Validators.required, Validators.maxLength(cnst.maxLengthStr)]);
            this.form.get('typeOther').updateValueAndValidity();
        } else {
            this.form.get('typeOther').setValidators(null);
            this.form.get('typeOther').updateValueAndValidity();
            this.form.get('typeOther').setValue(null);
        }
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                this.selectedFiles.push(data);
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            });
        }
    }

    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.form.get('totalDoc').setValue(this.selectedFiles.length);
        const deletedIdArray = this.form.get('deletedFileIds').value;
        deletedIdArray.push(doc.id);
    }

    close(decision: boolean) {
        this.form.patchValue({
            files: this.selectedFiles
        });
        let obj = {
            decision: decision,
            params: this.form.value
        };
        this.dialogRef.close(obj);
    }
}
