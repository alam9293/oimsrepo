import { Component, OnInit, Input, ViewChild, SimpleChanges } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { TgLicencePrintDetailsService } from './tg-licence-print-details.service';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-tg-licence-print-details',
    templateUrl: './tg-licence-print-details.component.html',
    styleUrls: ['./tg-licence-print-details.component.scss']
})
export class TgLicencePrintDetailsComponent implements OnInit {

    @Input() id: number;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    licencePrintDetails: any = {};
    cnst = cnst;

    constructor(
        private service: TgLicencePrintDetailsService
    ) { }

    ngOnInit() {
        if (this.id) {
            this.loadTgLicencePrintDetails();
        }
    }

    loadTgLicencePrintDetails() {
        this.service.getLicencePrintDetails(this.id).subscribe(data => {
            this.licencePrintDetails = data;
        });
    }
}