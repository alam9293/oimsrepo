import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatDividerModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatIconModule, MatSelectModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatPaginatorModule, MatSortModule, MatTableModule, MatDialogModule, MatTooltipModule } from '@angular/material';
import { TgLicencePrintDetailsComponent } from './tg-licence-print-details.component';
import { RouterModule } from '@angular/router';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        RouterModule
    ],
    declarations: [TgLicencePrintDetailsComponent],
    exports: [TgLicencePrintDetailsComponent]
})
export class TgLicencePrintDetailsModule { }
