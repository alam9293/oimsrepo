import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';

@Injectable({
    providedIn: 'root'
})
export class TgLicencePrintDetailsService {

    constructor(private http: HttpClient) { }

    getLicencePrintDetails(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_APPLICATION + '/view/licence-print-details/' + applicationId);
    }
}
