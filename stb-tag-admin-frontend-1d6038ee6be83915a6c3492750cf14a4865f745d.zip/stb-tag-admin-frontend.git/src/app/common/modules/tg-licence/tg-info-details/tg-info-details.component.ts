import { Component, OnInit, SimpleChanges, ViewChild, Input } from '@angular/core';
import * as cnst from '../../../../common/constants';
import { ConfirmationDialogComponent } from '../../confirmation-dialog/confirmation-dialog.component';
import { TgInfoDetailsDialogComponent } from '../../../../common/modules/tg-info-details-dialog/tg-info-details-dialog.component';
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogRef,
    MatDrawer,
    MatPaginator,
    MatSnackBar,
    MatSort,
    MatTableDataSource,
    MatTable,
} from '@angular/material';
import { TgLicenceService } from '../tg-licence.service'
import { CommonService, AuthenticationService } from '../../../../common/services';
import { FileUtil, FormUtil } from '../../../../common/helper';

@Component({
    selector: 'app-tg-info-details',
    templateUrl: './tg-info-details.component.html',
    styleUrls: ['./tg-info-details.component.scss']
})
export class TgInfoDetailsComponent implements OnInit {
    @Input() id: any;
    @ViewChild(MatTable) _matTables;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(MatSort) sort: MatSort;
    tgInfoRows = new MatTableDataSource<any>();
    tgInfoDisplayedColumns = ['no', 'personName', 'companyName', 'category', 'details', 'attachments', 'updatedBy', 'updatedDate', 'action'];
    filter: any = {};
    cnst = cnst;

    constructor(
        private tgLicenceService: TgLicenceService,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        private dialog: MatDialog,
        public authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
        this.loadDetails(false);
    }

    loadDetails(fromCache: boolean) {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.id);
        this.tgLicenceService.getTgInfo(this.filter, this.id).subscribe(data => {
            this.tgInfoRows.data = data.records;
            this.paginator.length = data.total;
        });
    }

    deleteTgInfo(tgInfoId: any) {
        let dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: "Delete Case"
            }
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.tgLicenceService.deleteTgInfo(tgInfoId).subscribe(data => {
                    this.loadDetails(false);
                    this.commonService.popSnackbar(null, 'success-snackbar');
                });
            }
        });
    }

    openTgInfoDetailsViewDialog(tgInfo: any) {
        let dialogRef = this.dialog.open(TgInfoDetailsDialogComponent, {
            data: {
                tgInfo: tgInfo,
                licenceId: this.id
            },
            height: '600px',
            width: '650px',
            autoFocus: true
        });
        dialogRef.disableClose = true;
        dialogRef.afterClosed().subscribe(data => {
            if (data.decision) {
                this.tgLicenceService.saveTgInfo(data.params).subscribe(data => {
                    this.loadDetails(false);
                    this.commonService.popSnackbar(null, 'success-snackbar');
                });
            }
        });
    }
}
