import { Component, OnInit, SimpleChanges, ViewChild, Input } from '@angular/core';
import { TgLicenceService } from '../tg-licence.service';
import { CeCaseRelevantOffencesComponent } from 'src/app/main/ce/ce-case/ce-case-relevant-offences/ce-case-relevant-offences.component';

@Component({
    selector: 'app-tg-licence-ce',
    templateUrl: './tg-licence-ce.component.html',
    styleUrls: ['./tg-licence-ce.component.scss']
})
export class TgLicenceCeComponent implements OnInit {

    @Input() id: number;
    @ViewChild(CeCaseRelevantOffencesComponent) ceCaseRelevantOffencesComponent: CeCaseRelevantOffencesComponent;

    constructor(public tgLicenceService: TgLicenceService) { }

    ngOnInit() {
        this.load();
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.id) {
            this.load();
        }
    }

    load() {
        this.tgLicenceService.getPastInfringements(this.id).subscribe(data => {
            this.ceCaseRelevantOffencesComponent.loadDetails(data);
        })
    }

}
