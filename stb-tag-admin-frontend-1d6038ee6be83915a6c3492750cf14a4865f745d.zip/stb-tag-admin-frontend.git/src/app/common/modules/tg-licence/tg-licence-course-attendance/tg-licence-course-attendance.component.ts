import { Component, OnInit, Input, ViewChild, ViewChildren, QueryList } from '@angular/core';
import * as cnst from '../../../../common/constants';
import { MatPaginator, MatSort, MatTableDataSource, MatSortable } from '@angular/material';
import { TgLicenceService } from '../tg-licence.service';
import { DomSanitizer } from '@angular/platform-browser';
import { FormControl } from '@angular/forms';
import { DateUtil } from 'src/app/common/helper';


@Component({
    selector: 'app-tg-licence-course-attendance',
    templateUrl: './tg-licence-course-attendance.component.html',
    styleUrls: ['./tg-licence-cource-attendance.component.scss']
})
export class TgLicenceCourseAttendanceComponent implements OnInit {
    @Input() id: number;
    @ViewChild('pdcPaginator', { read: MatPaginator }) pdcPaginator: MatPaginator;
    @ViewChild('mrcPaginator', { read: MatPaginator }) mrcPaginator: MatPaginator;
    @ViewChild('assignmentPaginator', { read: MatPaginator }) assignmentPaginator: MatPaginator;
    @ViewChildren(MatSort) sorts = new QueryList<MatSort>();
    cnst = cnst;
    mrcFilter: any = {};
    pdcFilter: any = {};
    assignmentFilter: any = {};
    listOfMRCCourseDataSource = new MatTableDataSource<any>();
    listOfMRCCourseDisplayedColumns = ['serialNo', 'tpName', 'courseName', 'attendedDate', 'score', 'scorePercentage', 'result'];
    listOfPDCCourseDataSource = new MatTableDataSource<any>();
    listOfPDCCourseDisplayedColumns: string[] = ['serialNo', 'tpName', 'courseName', 'attendedDate', 'attendance'];
    tgAssignmentDataSource = new MatTableDataSource<any>();
    tgAssignmentDisplayedColumns = ['serialNo', 'assignmentDate', 'assignmentEndDate', 'tourType', 'totalHours', 'empSrc', 'companyName', 'feeReceived', 'submissionDate'];
    pdcStartIndex: number = 0;
    mrcStartIndex: number = 0;
    assignmentStartIndex: number = 0;
    selectionGroup: any;
    selected: number = 0;
    years: any = [];
    todayDate = DateUtil.getNow();
    showDateRange: any = [false, false, false];

    constructor(private tgLicenceService: TgLicenceService, private _sanitizer: DomSanitizer) { }

    ngOnInit() {
        this.loadPastYears();
    }

    ngAfterViewInit(): void {
        this.loadListOfMRCCourseDetails('current');
    }

    onTabChange(event) {
        this.selected = event;
        if (this.selected == 0) {
            this.loadListOfMRCCourseDetails('current');
        } else if (this.selected == 1) {
            this.loadListOfPDCCourseDetails('current');
        } else if (this.selected == 2) {
            this.loadTgAssignment('current');
        }
    }

    loadPastYears() {
        this.tgLicenceService.getPastYears(3, this.id).subscribe(data => {
            this.years = data;
            this.mrcFilter.year = data[0].key;
            this.pdcFilter.year = data[0].key;
            this.assignmentFilter.year = data[0].key;
        });
    }

    loadListOfMRCCourseDetails(selection: String) {
        this.mrcFilter.type = cnst.TpCourseTypes.mrc;
        var paginator = this.mrcPaginator;
        var sort = this.sorts.toArray()[0];
        var sortProperty;
        var sortOrder;
        if (!sort.active) {
            sortProperty = 'attendedDate';
            sortOrder = 'desc';
        } else {
            sortProperty = sort.active;
            sortOrder = sort.direction;
        }
        let mergedDto = {
            'pageSize': (paginator.pageSize ? paginator.pageSize : paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sortProperty,
            'order': sortOrder,
            ...this.mrcFilter
        };

        if (selection == 'current') {
            this.tgLicenceService.getCurrentCycleAttendance(mergedDto, this.id, 'mrc').subscribe(data => {
                this.listOfMRCCourseDataSource = data.records;
                paginator.length = data.total;
                this.mrcStartIndex = paginator.pageIndex * paginator.pageSize;
            });
        } else {
            this.tgLicenceService.getListOfCourseDetails(mergedDto, this.id).subscribe(data => {
                this.listOfMRCCourseDataSource = data.records;
                paginator.length = data.total;
                this.mrcStartIndex = paginator.pageIndex * paginator.pageSize;
            });
        }
    }

    loadListOfPDCCourseDetails(selection: String) {
        this.pdcFilter.type = cnst.TpCourseTypes.pdc;
        var paginator = this.pdcPaginator;
        var sort = this.sorts.toArray()[1];
        var sortProperty;
        var sortOrder;
        if (!sort.active) {
            sortProperty = 'attendedDate';
            sortOrder = 'desc';
        } else {
            sortProperty = sort.active;
            sortOrder = sort.direction;
        }
        let mergedDto = {
            'pageSize': (paginator.pageSize ? paginator.pageSize : paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sortProperty ? sortProperty : '',
            'order': sortOrder,
            ...this.pdcFilter
        };

        if (selection == 'current') {
            this.tgLicenceService.getCurrentCycleAttendance(mergedDto, this.id, 'pdc').subscribe(data => {
                this.listOfPDCCourseDataSource = data.records;
                paginator.length = data.total;
                this.pdcStartIndex = paginator.pageIndex * paginator.pageSize;
            });
        } else {
            this.tgLicenceService.getListOfCourseDetails(mergedDto, this.id).subscribe(data => {
                this.listOfPDCCourseDataSource = data.records;
                paginator.length = data.total;
                this.pdcStartIndex = paginator.pageIndex * paginator.pageSize;
            });
        }
    }

    loadTgAssignmentByYear(year: number) {
        this.assignmentFilter.year = year;
        this.loadTgAssignment('');
    }

    loadTgAssignment(selection: String) {
        this.assignmentFilter.isDeleted = false;
        var paginator = this.assignmentPaginator;
        var sort = this.sorts.toArray()[2];
        var sortProperty;
        var sortOrder;
        if (!sort.active) {
            sortProperty = 'startDate';
            sortOrder = 'desc';
        } else {
            sortProperty = sort.active;
            sortOrder = sort.direction;
        }
        if (selection == 'deleted') {
            this.assignmentFilter.isDeleted = true;
            this.clearTgAssignmentFilter();
        }
        if (selection == 'dateRange') {
            this.assignmentFilter.year = '';
        }
        let mergedDto = {
            'pageSize': (paginator.pageSize ? paginator.pageSize : paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sortProperty ? sortProperty : '',
            'order': sortOrder,
            ...this.assignmentFilter
        };

        if (selection == 'current') {
            this.tgLicenceService.getCurrentAssignments(mergedDto, this.id).subscribe(data => {
                this.tgAssignmentDataSource = data.records;
                paginator.length = data.total;
                this.assignmentStartIndex = paginator.pageIndex * paginator.pageSize;
            });
        } else {
            this.tgLicenceService.getAssignmentList(mergedDto, this.id).subscribe(data => {
                this.tgAssignmentDataSource = data.records;
                paginator.length = data.total;
                this.assignmentStartIndex = paginator.pageIndex * paginator.pageSize;
            });
        }
    }
    clearTgAssignmentFilter() {
        this.assignmentFilter.year = '';
        this.assignmentFilter.startDate = '';
        this.assignmentFilter.endDate = '';
    }

    clearTgPdcFilter() {
        this.pdcFilter.year = '';
        this.pdcFilter.startDate = '';
        this.pdcFilter.endDate = '';
    }

    clearTgMrcFilter() {
        this.mrcFilter.year = '';
        this.mrcFilter.startDate = '';
        this.mrcFilter.endDate = '';
    }
}
