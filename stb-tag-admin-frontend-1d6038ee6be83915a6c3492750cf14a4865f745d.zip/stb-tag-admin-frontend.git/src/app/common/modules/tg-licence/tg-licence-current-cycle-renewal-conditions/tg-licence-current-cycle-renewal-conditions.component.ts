import { Component, OnInit, Input, ViewChildren, QueryList } from '@angular/core';
import * as cnst from '../../../../common/constants';
import { MatPaginator, MatSort } from '@angular/material';
import { TgLicenceService } from '../tg-licence.service';
import { FileUtil } from '../../../../common/helper';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
    selector: 'app-tg-licence-current-cycle-renewal-conditions',
    templateUrl: './tg-licence-current-cycle-renewal-conditions.component.html',
    styleUrls: ['./tg-licence-current-cycle-renewal-conditions.component.scss']
})
export class TgLicenceCurrentCycleRenewalConditionsComponent implements OnInit {
    @Input() id: number;
    constructor(private tgLicenceService: TgLicenceService, private fileUtil: FileUtil,
        private _sanitizer: DomSanitizer) { }
    @ViewChildren(MatPaginator) paginators = new QueryList<MatPaginator>();
    @ViewChildren(MatSort) sorts = new QueryList<MatSort>();
    cnst = cnst;
    PDCdisplayedColumns: string[] = ['serialNo', 'tpName', 'courseName', 'attendedDate', 'noOfHours'];
    MRCdisplayedColumns: string[] = ['serialNo', 'tpName', 'courseName', 'attendedDate', 'score', 'scoreInPercent', 'result'];
    tgAssignmentDisplayedColumns = ['serialNo', 'assignmentDate', 'tourType', 'totalHours', 'empSrc', 'companyName', 'feeReceived'];
    listOfPdcDataSource = [];
    listOfMrcDataSource = [];
    tgAssignmentDataSource = [];
    pdcStartIndex: number = 0;
    mrcStartIndex: number = 0;
    assignmentStartIndex: number = 0;
    currentRenewal: any = { appFee: {}, status: {} };
    currentConditions: any = {};
    imageSrc: any = "assets/images/tg_photo.png";


    ngOnInit() {

    }

    ngAfterViewInit(): void {
        this.loadListOfMrc();
        this.loadListOfPdc();
        this.loadTgAssignment();
        this.loadOthers();
        this.loadConditions();
    }

    loadListOfMrc() {
        var paginator = this.paginators.toArray()[0];
        var sort = this.sorts.toArray()[0];
        let mergedDto = {
            'pageSize': paginator.pageSize,
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sort.active,
            'order': sort.direction,
        };

        this.tgLicenceService.getCurrentCycleAttendance(mergedDto, this.id, 'mrc').subscribe(data => {
            this.listOfMrcDataSource = data.records;
            paginator.length = data.total;
            this.mrcStartIndex = paginator.pageIndex * paginator.pageSize;
        });

    }
    loadListOfPdc() {
        var paginator = this.paginators.toArray()[1];
        var sort = this.sorts.toArray()[1];

        let mergedDto = {
            'pageSize': paginator.pageSize,
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sort.active,
            'order': sort.direction,
        };

        this.tgLicenceService.getCurrentCycleAttendance(mergedDto, this.id, 'pdc').subscribe(data => {
            this.listOfPdcDataSource = data.records;
            paginator.length = data.total;
            this.pdcStartIndex = paginator.pageIndex * paginator.pageSize;
        });

    }
    loadTgAssignment() {
        var paginator = this.paginators.toArray()[2];
        var sort = this.sorts.toArray()[2];
        var sortProperty;
        var sortOrder;
        if (!sort.active) {
            sortProperty = 'startDate';
            sortOrder = 'desc';
        } else {
            sortProperty = sort.active;
            sortOrder = sort.direction;
        }
        let mergedDto = {
            'pageSize': paginator.pageSize,
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'orderProperty': sortProperty,
            'order': sortOrder
        };

        this.tgLicenceService.getCurrentAssignments(mergedDto, this.id).subscribe(data => {
            this.tgAssignmentDataSource = data.records;
            paginator.length = data.total;
            this.assignmentStartIndex = paginator.pageIndex * paginator.pageSize;
        });

    }
    loadOthers() {
        this.tgLicenceService.getCurrentOthers(this.id).subscribe(data => {
            this.currentRenewal = data;
            if (!this.currentRenewal.appFee) {
                this.currentRenewal = { appFee: {}, ...this.currentRenewal }
            }

            if (data.photo) {
                this.fileUtil.download(data.photo.id, data.photo.hash).subscribe(data => {
                    const reader = new FileReader();
                    reader.onload = (e: any) => {
                        this.imageSrc = this._sanitizer.bypassSecurityTrustUrl(e.target.result);
                    };
                    reader.readAsDataURL(data);
                });
            }
        });
    }
    loadConditions() {
        this.tgLicenceService.getCurrentConditions(this.id).subscribe(data => {
            this.currentConditions = data;
        });
    }
    downloadFile(doc) {
        this.fileUtil.download(doc.id, doc.hash).subscribe(data => {
            this.fileUtil.export(data, doc.originalName);
        });
    }

}
