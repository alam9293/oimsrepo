import { Component, OnInit, Input } from '@angular/core';
import { TgLicenceService } from '../tg-licence.service';
import { FormUtil, FileUtil } from '../../../../common/helper';
import { DomSanitizer } from '@angular/platform-browser';
import * as cnst from '../../../constants'
@Component({
    selector: 'app-tg-licence-details',
    templateUrl: './tg-licence-details.component.html',
    styleUrls: ['./tg-licence-details.component.scss']
})
export class TgLicenceDetailsComponent implements OnInit {
    @Input() id: number;
    cnst = cnst;
    tgLicence: any = {};
    photoUrl: any;
    constructor(private service: TgLicenceService, public formUtil: FormUtil, private _sanitizer: DomSanitizer,
        private fileUtil: FileUtil) { }

    ngOnInit() {
        this.service.getDetails(this.id).subscribe(data => {
            this.tgLicence = data;
            if (data.photo && data.photo.id != null) {
                this.fileUtil.download(data.photo.id, data.photo.hash).subscribe(data => {
                    const reader = new FileReader();
                    reader.onload = (e: any) => {
                        this.photoUrl = this._sanitizer.bypassSecurityTrustUrl(e.target.result);
                    };
                    reader.readAsDataURL(data);
                });
            } else {
                this.photoUrl = "assets/images/tg_photo.png";
            }
        });

    }

}

