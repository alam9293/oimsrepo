import { Component, OnInit, Input } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { TgLicenceService } from '../tg-licence.service';

@Component({
    selector: 'app-tg-licence-status-span',
    templateUrl: './tg-licence-status-span.component.html',
    styleUrls: ['./tg-licence-status-span.component.scss']
})
export class TgLicenceStatusSpanComponent implements OnInit {
    @Input() id: number;
    statusSpan: any = [];
    statusSpanColumns = ['no', 'status', 'startDate', 'endDate', 'tier', 'updatedBy', 'updatedDate', 'remarks'];


    constructor(
        private tgLicenceService: TgLicenceService
    ) { }

    ngOnInit() {
        this.load();
    }

    load() {
        this.tgLicenceService.getStatusSpan(this.id).subscribe(data => {
            this.statusSpan = data;
        });
    }

}
