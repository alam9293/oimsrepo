import { Component, OnInit, Input, ViewChild, } from '@angular/core';
import { MatPaginator, MatSort, MatDialog } from '@angular/material';
import { TgLicenceService } from './tg-licence.service';
import { AuthenticationService } from '../../../common/services';

@Component({
    selector: 'app-tg-licence',
    templateUrl: './tg-licence.component.html',
    styleUrls: ['./tg-licence.component.scss']
})
export class TgLicenceComponent implements OnInit {
    @Input() id: number;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    tabLoaded: any[] = [0];

    constructor(public dialog: MatDialog, private authenticationService: AuthenticationService) { }
    app: string;
    ngOnInit() {
    }

    public checkPermission(functionCode: string): boolean {
        return this.authenticationService.checkPermission(functionCode);
    }


}
