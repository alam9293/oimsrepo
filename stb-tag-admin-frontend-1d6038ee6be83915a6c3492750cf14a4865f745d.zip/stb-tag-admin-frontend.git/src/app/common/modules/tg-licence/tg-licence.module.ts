import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';
import { MatButtonModule, MatButtonToggleModule, MatCardModule, MatCheckboxModule, MatDatepickerModule, MatDialogModule, MatDividerModule, MatExpansionModule, MatFormFieldModule, MatIconModule, MatInputModule, MatPaginatorModule, MatSelectModule, MatSortModule, MatTableModule, MatTabsModule } from '@angular/material';
import { RouterModule } from '@angular/router';
import { CeCaseRelevantOffencesModule } from '../../../main/ce/ce-case/ce-case-relevant-offences/ce-case-relevant-offences.module';
import { SharedModule } from '../shared.module';
import { TgLicenceCeComponent } from './tg-licence-ce/tg-licence-ce.component';
import { TgLicenceCourseAttendanceComponent } from './tg-licence-course-attendance/tg-licence-course-attendance.component';
import { TgLicenceCurrentCycleRenewalConditionsComponent } from './tg-licence-current-cycle-renewal-conditions/tg-licence-current-cycle-renewal-conditions.component';
import { TgLicenceDetailsComponent } from './tg-licence-details/tg-licence-details.component';
import { TgLicenceStatusSpanComponent } from './tg-licence-status-span/tg-licence-status-span.component';
import { TgLicenceComponent } from './tg-licence.component';
import { TgInfoDetailsComponent } from './tg-info-details/tg-info-details.component';
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        MatCheckboxModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatExpansionModule,
        MatDatepickerModule,
        RouterModule,
        SharedModule,
        CeCaseRelevantOffencesModule
    ],
    declarations: [
        TgLicenceComponent,
        TgLicenceDetailsComponent,
        TgLicenceCurrentCycleRenewalConditionsComponent,
        TgLicenceCourseAttendanceComponent,
        TgLicenceStatusSpanComponent,
        TgLicenceCeComponent,
        TgInfoDetailsComponent
    ],
    exports: [TgLicenceComponent],
    entryComponents: []
})
export class TgLicenceModule { }

