import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';

@Injectable({
    providedIn: 'root'
})
export class TgLicenceService {

    constructor(private http: HttpClient) { }

    public getDetails(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + "/view/" + id);
    }
    public getCurrentCycleAttendance(searchDto: any, id: number, type: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + '/view/current-cycle-attendance/' + id + '/' + type, { params: searchDto });
    }
    public getCurrentAssignments(searchDto: any, id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + '/view/current-cycle-assignments/' + id, { params: searchDto });
    }
    public getCurrentOthers(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + '/view/current-cycle-others/' + id);
    }
    public getCurrentConditions(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + '/view/current-cycle-conditions/' + id);
    }
    public getPastYears(number: number, licenceId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + '/view/' + licenceId + '/past-years/' + number);
    }

    public getListOfCourseDetails(searchDto: any, licenceId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_CSE + '/view/' + licenceId, { params: searchDto });
    }
    public getAssignmentList(searchDto: any, licenceId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_ASSIGNMENT + '/view/licence/' + licenceId, { params: searchDto });
    }
    public getStatusSpan(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + '/status-span/view/' + id);
    }
    public getPastInfringements(id: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_LICENCE + '/past-infringements/view/' + id);
    }

    public getTgInfo(searchDto: any, licenceId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_INFO + '/view/' + licenceId, { params: searchDto });
    }

    public deleteTgInfo(tgInfoId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_INFO + '/delete/' + tgInfoId);
    }
    public saveTgInfo(dto: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(dto)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_INFO + '/save', formData);
    }
}
