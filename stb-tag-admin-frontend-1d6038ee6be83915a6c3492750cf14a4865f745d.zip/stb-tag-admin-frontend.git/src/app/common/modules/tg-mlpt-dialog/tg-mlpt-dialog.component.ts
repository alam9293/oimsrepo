import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../../common/services';
import { FileUtil, FormUtil } from '../../../common/helper';
import { CroppieDialogComponent } from '../../../main/croppie/croppie-dialog/croppie-dialog.component';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
    selector: 'app-tg-mlpt-dialog',
    templateUrl: './tg-mlpt-dialog.component.html',
    styleUrls: ['./tg-mlpt-dialog.component.scss']
})
export class TgMlptDialogComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<TgMlptDialogComponent>,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        public dialog: MatDialog,
        private _sanitizer: DomSanitizer,
        public formUtil: FormUtil,
    ) { }

    form = this.formBuilder.group({
        sendSceduleToTg: [false]
    });

    ngOnInit() {
    }


    close(decision: boolean) {
        let obj = {
            decision: decision,
            params: this.form.value
        };

        this.dialogRef.close(obj);
    }
}
