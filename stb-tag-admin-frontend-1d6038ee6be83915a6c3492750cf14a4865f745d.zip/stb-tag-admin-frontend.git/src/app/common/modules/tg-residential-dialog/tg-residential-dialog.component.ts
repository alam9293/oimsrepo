import { Component, Inject, Input, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors, ValidatorFn, FormGroupDirective, NgForm, FormArray } from '@angular/forms';
import * as cnst from '../../../common/constants';
import { CommonService } from '../../../common/services';
import { FileUtil, FormUtil } from '../../../common/helper';
import { CroppieDialogComponent } from '../../../main/croppie/croppie-dialog/croppie-dialog.component';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
    selector: 'app-tg-residential-dialog',
    templateUrl: './tg-residential-dialog.component.html',
    styleUrls: ['./tg-residential-dialog.component.scss']
})
export class TgResidentialDialogComponent implements OnInit {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<TgResidentialDialogComponent>,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        public dialog: MatDialog,
        private _sanitizer: DomSanitizer,
        public formUtil: FormUtil,
    ) { }

    cnst = cnst;
    residentialStatuses: any;
    occupations: any;
    workPassTypes: any;
    isWorkPassHolder: Boolean;
    imageSrc: any = "./assets/images/tg_photo.png";
    photo: File;
    form = this.formBuilder.group({
        id: [],
        photo: [],
        name: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
        nric: ['', [Validators.maxLength(10), Validators.required, Validators.pattern(/^[a-zA-Z0-9]*$/)]],
        residentialStatus: ['', Validators.required],
        employerName: [''],
        occupation: [''],
        occupationOther: [''],
        workPassType: [''],
        workpassExpiryDate: [''],
        isPaymentRequired: ['']
    });

    ngOnInit() {
        this.form.get("nric").valueChanges.subscribe(val => {
            this.isWorkPassHolder = !val.toLowerCase().startsWith("s") && !val.toLowerCase().startsWith("t");

            if (this.isWorkPassHolder) {
                this.form.get("employerName").setValidators(Validators.required);
                this.form.get("occupation").setValidators(Validators.required);
                this.form.get("workPassType").setValidators(Validators.required);
                this.form.get("workpassExpiryDate").setValidators(Validators.required);
            }
            else {
                this.form.get("employerName").clearValidators();
                this.form.get("occupation").clearValidators();
                this.form.get("workPassType").clearValidators();
                this.form.get("workpassExpiryDate").clearValidators();
            }
            this.form.get("employerName").updateValueAndValidity();
            this.form.get("occupation").updateValueAndValidity();
            this.form.get("workPassType").updateValueAndValidity();
            this.form.get("workpassExpiryDate").updateValueAndValidity();
        });

        this.form.patchValue(this.data);

        if (this.data.id) { //update
            if (this.data.photo) {
                this.fileUtil.download(this.data.photo.id, this.data.photo.hash).subscribe(data => {
                    const reader = new FileReader();
                    reader.onload = (e: any) => {
                        this.imageSrc = this._sanitizer.bypassSecurityTrustUrl(e.target.result);
                    };
                    reader.readAsDataURL(data);
                });
            }
        }
        else { //new
            this.form.get("photo").setValue(null);
            this.form.get("residentialStatus").setValue(this.data.residentialStatusCode);
            this.form.get("occupation").setValue(this.data.occupationCode);
            this.form.get("workPassType").setValue(this.data.workPassTypeCode);
        }

        this.loadCommonTypes();
    }

    loadCommonTypes() {
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.RESIDENTIAL_STATUS).subscribe(data => {
            this.residentialStatuses = [];
            for (let residential of data) {
                if (residential.key != 'RESD_N' && residential.key != 'RESD_U' && residential.key != 'RESD_A') {
                    this.residentialStatuses.push(residential);
                }
            }
            let residentialStatus = this.form.get("residentialStatus").value;
            if (residentialStatus == 'RESD_N' || residentialStatus == 'RESD_U' || residentialStatus == 'RESD_A') {
                this.residentialStatuses.push({ key: residentialStatus, label: this.formUtil.getLabelFromKey(data, residentialStatus) });
            }
        });
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.OCCUPATIONS).subscribe(data => this.occupations = data);
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.WORK_PASS_TYPE).subscribe(data => this.workPassTypes = data);
    };

    close(decision: boolean) {
        let obj = {
            decision: decision,
            params: this.form.value
        };

        this.dialogRef.close(obj);
    }

    openCropDialog() {
        let dialog = this.dialog.open(CroppieDialogComponent);
    }

    onPhotoChanged(event: any) {
        var fileValid = true;
        this.imageSrc = "./assets/images/tg_photo.png";
        this.photo = event.target.files[0];
        if (this.fileUtil.exceedMaxSize(this.photo)) {
            fileValid = false;
            this.form.get('photo').setErrors({ 'maxFileSize': true });
        }
        else if (this.fileUtil.exceedMinSize(this.photo)) {
            fileValid = false;
            this.form.get('photo').setErrors({ 'minFileSize': true });
        }
        if (fileValid && event.target.files && event.target.files[0]) {
            var form = this.form;
            var photo = this.photo;
            var fileUtil = this.fileUtil;
            const reader = new FileReader();
            reader.readAsDataURL(event.target.files[0]);
            reader.onload = (e: any) => {
                let self = this;
                var image = new Image();
                image.src = e.target.result;
                image.onload = function () {
                    if (image.width != 400 || image.height != 514) {
                        form.get('photo').setErrors({ 'invalidWidthHeight': true });
                    }
                    else {
                        form.get('photo').setErrors(null);
                        self.imageSrc = e.target.result;
                        fileUtil.uploadToTransferToInternet(cnst.DocumentTypes.TG_DOC_PASSPORT_PHOTO, photo).subscribe(data => {
                            form.patchValue({
                                photo: data
                            });
                        });
                    }
                };

            };
        }
    }

}
