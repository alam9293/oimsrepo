import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import * as cnst from '../../constants';
import { TgStipendService } from 'src/app/main/tg/tg-stipend-process/tg-stipend.service';
import { FileUtil } from '../../helper';
import { AuthenticationService, CommonService } from '../../services';
import { NoteDialogComponent } from '../note-dialog/note-dialog.component';
import { MatDialogRef, MatDialog } from '@angular/material';
import { PaymentService } from '../../../main/payment/payment.service'
import { Router } from '@angular/router';

@Component({
    selector: 'app-tg-stipend-details',
    templateUrl: './tg-stipend-details.component.html',
    styleUrls: ['./tg-stipend-details.component.scss']
})
export class TgStipendDetailsComponent implements OnInit {
    @Input() billRefNo: any;
    @Input() appId: any;
    @Input() payStatus: any;
    isFinanceRole: boolean = false;
    hasSaveNotePermission: boolean = false;
    application: any = { applicationStatus: { key: '', label: '' }, licenceStatus: { key: '', label: '' }, licenceTier: { key: '', label: '' }, residentialStatus: { key: '', label: '' } };
    cnst = cnst;

    constructor(
        private tgStipendService: TgStipendService,
        private dialog: MatDialog,
        private fileUtil: FileUtil,
        private authenticationService: AuthenticationService,
        private commonService: CommonService,
        private paymentService: PaymentService,
        private router: Router
    ) { }

    ngOnInit() {
        this.isFinanceRole = this.authenticationService.currentUserValue && this.authenticationService.currentUserValue.selectedRole.key == cnst.ApplicationRoles.FINANCE;
        if (this.authenticationService.hasPermission("TG_STIPEND_NOTE_SAVE")) {
            this.hasSaveNotePermission = true;
        }
        if (this.appId) {
            this.loadByAppId();
        } else if (this.billRefNo) {
            this.loadByBillRefNo();
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.appId) {
            this.loadByAppId();
        } else if (this.billRefNo || (this.billRefNo && this.payStatus)) {
            this.loadByBillRefNo();
        }

    }

    loadByAppId(): void {
        this.tgStipendService.getDetails(this.appId).subscribe(data => {
            this.application = data;
        });
    }

    loadByBillRefNo(): void {
        this.tgStipendService.getDetailsByBillRefNo(this.billRefNo).subscribe(data => {
            this.application = data;
        });
    }

    noteDialofRef: MatDialogRef<NoteDialogComponent>;
    openNoteDialogForFinance() {
        this.noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });

        this.noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.tgStipendService.saveNoteByFinance(result.params, this.application.applicationId).subscribe(
                    data => {
                        let routerlink = '/payment-request-view/' + this.billRefNo;
                        this.router.navigate([routerlink]);
                        this.commonService.popSnackbar(cnst.Messages.GENERIC_SUCCCESS, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }
}
