import { Component, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import * as cnst from '../../constants';
import { FileUtil } from '../../helper';
import { CommonService } from '../../services';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { WorkflowFileService } from './workflow-file.service';

@Component({
    selector: 'app-workflow-file',
    templateUrl: './workflow-file.component.html',
    styleUrls: ['./workflow-file.component.scss']
})
export class WorkflowFileComponent implements OnInit {

    @Input() workflowId: number;
    @Input() taTg: string;
    @Input() workflowType: string;
    @Input() toDisable: boolean;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    displayedColumns = ['file', 'docType', 'description', 'size', 'createdDate', 'action'];
    cnst = cnst;
    form: FormGroup;
    workflowFileRecords = new MatTableDataSource<any>();
    deletedWorkflowFileIds: any = [];
    docTypes = [];

    constructor(
        private workflowFileService: WorkflowFileService,
        private fileUtil: FileUtil,
        private formBuilder: FormBuilder,
        public dialog: MatDialog,
        public commonService: CommonService,
    ) { }

    ngOnInit() {
        if (this.workflowId) {
            this.loadWorkflowFiles();
        }
        if (this.workflowType) {
            this.commonService.getTypesByCategoryCode(this.workflowType).subscribe(data => {
                this.docTypes = data.filter(type => type.key !== cnst.DocumentTypes.TA_DOC_SHORTFALL_LETTER_SYSTEM);
            })
        }
    }

    get workflowFiles() {
        return this.form.get('workflowFiles') as FormArray;
    }

    initForm() {
        this.form = this.formBuilder.group({
            workflowFiles: this.formBuilder.array([]),
        });
    }

    loadWorkflowFiles() {
        this.initForm();
        let mergedDto = {
            'pageSize': cnst.PAGINATION.DEFAULT_PAGE_SIZE,
            'startIndex': 0,
            'orderProperty': '',
            'order': '',
        };

        this.workflowFileService.getWorkflowFiles(this.workflowId, mergedDto, this.taTg).subscribe(data => {
            this.workflowFileRecords = new MatTableDataSource<any>(data.records);
            data.records.forEach(item => {
                this.workflowFiles.push(this.setWorkflowFileFormArray(null, item));
            })
        });
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.workflowId) {
            this.loadWorkflowFiles();
        }
    }

    onFileChanged(event) {
        let selectedFile = event.target.files[0];
        let attachment = this.setWorkflowFileFormArray(selectedFile, null);
        // upload immediately?
        this.fileUtil.saveAttachment(this.workflowId, attachment.value).subscribe(data => {
            this.loadWorkflowFiles();
        });
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    removeAttachment(rowIndex) {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Delete Attachment: ' + this.workflowFiles.value[rowIndex].originalName,
                internalRemarks: false,
                externalRemarks: false,
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                let deletedWorkflowFileIds = [this.workflowFiles.value[rowIndex].workflowFileId]
                this.fileUtil.deleteAttachment(deletedWorkflowFileIds).subscribe(data => {
                    this.loadWorkflowFiles();
                });
            }
        });
    }

    save() {
        this.fileUtil.saveWorkflowFiles(this.workflowId, this.workflowFiles.value, this.deletedWorkflowFileIds).subscribe(data => {
            this.loadWorkflowFiles();
        });
    }

    updateAttachment(rowIndex) {
        this.fileUtil.saveAttachment(this.workflowId, this.workflowFiles.value[rowIndex]).subscribe(data => {
            this.loadWorkflowFiles();
        });
    }

    setWorkflowFileFormArray(selectedFile: any, attachment: any) {
        if (selectedFile) {
            return this.formBuilder.group({
                file: [selectedFile],
                id: [''],
                workflowFileId: [''],
                originalName: [selectedFile.name],
                description: [''],
                docTypeCode: [''],
                documentTypeLabel: [''],
                readableFileSize: [''],
                size: [selectedFile.size],
                createdBy: [''],
                createdDate: [''],
            });
        } else if (attachment) {
            return this.formBuilder.group({
                id: [attachment.id],
                workflowFileId: [attachment.workflowFileId],
                originalName: [attachment.originalName],
                description: [{ value: attachment.description, disabled: this.toDisable }],
                docTypeCode: [{ value: attachment.docTypeCode, disabled: this.toDisable }],
                documentTypeLabel: [attachment.documentTypeLabel],
                readableFileSize: [attachment.readableFileSize],
                size: [attachment.size],
                createdBy: [attachment.createdBy],
                createdDate: [attachment.createdDate],
            });
        }
    }
}
