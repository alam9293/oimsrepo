import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatDividerModule, MatTabsModule, MatFormFieldModule, MatInputModule, MatIconModule, MatSelectModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatPaginatorModule, MatSortModule, MatTableModule, MatDialogModule, MatTooltipModule } from '@angular/material';
import { WorkflowFileComponent } from './workflow-file.component';
import { RouterModule } from '@angular/router';
import { FileSizeModule } from 'ngx-filesize';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        RouterModule,
        FileSizeModule
    ],
    declarations: [WorkflowFileComponent],
    exports: [WorkflowFileComponent]
})
export class WorkflowFileModule { }
