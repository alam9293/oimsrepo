import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../constants';

@Injectable({
    providedIn: 'root'
})
export class WorkflowFileService {

    constructor(private http: HttpClient) { }

    getWorkflowFiles(workflowId: number, searchDto, taTg: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/workflow/workflow-files/view/' + workflowId, { params: searchDto });
    }
}
