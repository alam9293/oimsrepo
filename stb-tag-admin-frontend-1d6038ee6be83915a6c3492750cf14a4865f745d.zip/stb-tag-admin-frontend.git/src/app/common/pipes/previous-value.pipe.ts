import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';


@Pipe({ name: 'previousValue' })
export class PreviousValuePipe implements PipeTransform {
    transform(value: string) {
        return _.isNil(value) || value == '' ? '' : 'Previous: '.concat(value);
    }
}