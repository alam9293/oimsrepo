import { Pipe, PipeTransform } from '@angular/core';
import { DateUtil } from '../helper/';

@Pipe({
    name: 'wizdate'
})

export class wizDatePipe implements PipeTransform {
    transform(value: string, format: string = ""): string {
        if (!value || value === "") return "";
        return DateUtil.parseDateTime(value).format(format);
    }
}