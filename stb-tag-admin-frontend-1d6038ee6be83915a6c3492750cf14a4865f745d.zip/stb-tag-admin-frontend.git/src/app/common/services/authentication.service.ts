import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as cnst from '../constants';
import { User } from '../models';
import * as _ from 'lodash';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;
    //private permissions: Array<ListableDto>;

    constructor(private http: HttpClient) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(sessionStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    login(loginId: string, password: string) {

        return this.http.post<any>(cnst.apiBaseUrl + '/users/authenticate/admin', { loginId, password })
            .pipe(map(auth => {
                // login successful if there's a jwt token in the response
                if (auth.user && auth.auth) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    auth.user.token = sessionStorage.getItem('jwt-token');
                    sessionStorage.setItem('currentUser', JSON.stringify(auth.user));
                    this.currentUserSubject.next(auth.user);
                }
                return auth;
            }));
    }

    loginSSO() {

        return this.http.get<any>(cnst.apiBaseUrl + '/users/authenticate-sso')
            .pipe(map(auth => {
                // login successful if there's a jwt token in the response
                if (auth.user && auth.auth) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    auth.user.token = sessionStorage.getItem('jwt-token');
                    sessionStorage.setItem('currentUser', JSON.stringify(auth.user));
                    this.currentUserSubject.next(auth.user);
                }
                return auth;
            }));
    }

    loginQlikSense() {
        return this.http.get<any>(cnst.apiBaseUrl + '/users/login-qliksense', { responseType: 'text' as 'json' });
    }

    switchRole(roleCode: string) {
        return this.http.post<any>(cnst.apiBaseUrl + '/dashboard/current-user/roles/switch', roleCode)
            .pipe(map(user => {
                if (user) {
                    user.token = sessionStorage.getItem('jwt-token');
                    sessionStorage.setItem('currentUser', JSON.stringify(user));
                    sessionStorage.removeItem('searchDto');
                    this.currentUserSubject.next(user);
                }
                return user;
            }));
    }

    logout() {
        // remove user from local storage to log user out
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('jwt-token');
        sessionStorage.removeItem('searchDto');
        this.currentUserSubject.next(null);
    }

    getCurrentUser() {
        return this.http.get<any>(cnst.apiBaseUrl + '/users/current');
    }

    public checkPermission(functionCode: string) {
        if (this.currentUserValue.permissions && this.currentUserValue.permissions.find(permission => {
            return permission.key === functionCode;
        })) {
            return true;
        }
        return false;
    }

    hasPermission(functionCode: string | string[]) {
        if (functionCode) {
            if (typeof functionCode == 'string') {
                return this.checkPermission(functionCode);
            } else {
                var result = false;
                _.forEach(functionCode, function (value) {
                    if (this.checkPermission(value)) {
                        result = true;
                        return;
                    }
                }.bind(this));
                return result;
            }
        }
        return false;
    }
}
