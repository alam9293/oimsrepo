import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatPaginator, MatSnackBar, MatSort, MatTableDataSource } from '@angular/material';
import { Observable } from 'rxjs';
import * as cnst from '../constants';
import { GoButtonComponent } from '../modules/go-button/go-button.component';
import { SuccessSnackbarComponent } from '../modules/success-snackbar/success-snackbar.component';
import { ListableDto } from "../../common/models/common-dto";
@Injectable({
    providedIn: 'root'
})
export class CommonService {

    constructor(private http: HttpClient, private snackBar: MatSnackBar) { }
    getCountries(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/countries');
    }
    getMaritalStatus(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/marital-statuses');
    }
    getNationalities(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/nationalities');
    }
    getPaymentTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/payment-types');
    }
    getPaymentRequestTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/payment-request-types');
    }
    getPremiseTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/premise-types');
    }
    getRaces(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/races');
    }
    getResidentialStatus(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/residential-statuses');
    }
    getSexes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/sexes');
    }
    getPrincipleActivities(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/principle-activities');
    }
    getFormOfBusiness(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/form-of-business');
    }
    getBusinessConstitution(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/business-constitution');
    }
    getEstablishmentStatus(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/establishment-statuses');
    }
    getTaApplicationTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-application-types');
    }
    getTaApprovalTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-approval-types');
    }
    getTaFocusAreas(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-focus-areas');
    }
    getTaSegmentations(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-segmentations');
    }
    getTaServices(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-services');
    }
    getTaLicenceTiers(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-licence-tiers');
    }
    getTaAuditorOpinions(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-auditor-opinions');
    }
    getTaCessationReasons(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-reasons-for-cessation');
    }
    getTaReplacementReasons(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-reasons-for-replacement');
    }
    getTgApplicationTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-application-types');
    }
    getTgSpecialisedAreas(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-specialised-areas');
    }
    getTgCourseTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-course-types');
    }
    getTgDocumentTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-document-types');
    }
    getTgGuidingLanguages(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-guiding-languages');
    }
    getTgDeclaredOffenceTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-declared-offence-types');
    }
    getTgLicenceTiers(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-licence-tiers');
    }
    getTgCandidateResults(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-candidate-results');
    }
    getTgCandidateItineraries(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-candidate-itineraries');
    }
    getTgMlptResults(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-mlpt-results');
    }
    getTgTrainingProviders(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-training-providers');
    }
    getTgAtoTrainingProviders(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-training-providers/ato');
    }
    getPaymentRequestStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/payment-request-statuses');
    }
    getPaymentTxnStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/payment-txn-statuses');
    }
    getTaApplicationStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-application-statuses');
    }
    getTaKeAppType(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-ke-app-type');
    }
    getTaLicenceStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-licence-statuses');
    }
    getTgApplicationStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-application-statuses');
    }
    getTgLicenceStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-licence-statuses');
    }
    getTgCourseStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-course-statuses');
    }
    getTgCourseCategoryTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-course-category-types');
    }
    getUserStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/user-statuses');
    }
    getReturnStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/return-statuses');
    }
    getPrintStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/print-statuses');
    }
    getTaLicencePrintStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-print-statuses');
    }
    getTaWorkflowStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-workflow-statuses');
    }
    getTgWorkflowStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-workflow-statuses');
    }
    getTaShortfallTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-shortfall-types');
    }
    getRecommendTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/recommend-types');
    }
    getSystemParameter(code) {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/system-parameter/' + code);
    }
    getTaApplicationPendingStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-app-pending-statuses');
    }
    getTypesByCategoryCode(categoryCode: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/types/' + categoryCode);
    }
    getStatusesByCategoryCode(categoryCode: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/statuses/' + categoryCode);
    }
    getStatusByCode(code: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/status/' + code);
    }
    getCEPendingStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-pending-statuses');
    }
    getAddressType(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/address-types');
    }
    public reAssignOfficer(input: any, taTg: string) {
        return this.http.post(cnst.apiBaseUrl + '/' + taTg + '/applications/re-assign', input);
    }
    getFlags(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/flags');
    }
    getRoles(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/user-roles');
    }
    getDepartment(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/department');
    }
    getModule(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/module');
    }
    getFunctions(module: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/function/' + module);
    }
    getBulletinTypeCodeList(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/type-code-list');
    }
    getBulletinTypeCodeTaTgList(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/type-code-tatg-list');
    }
    getFilingStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/filing-statuses');
    }
    getTaBranchStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-branch-statuses');
    }
    getTaAddressTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-address-types');
    }
    getTaServicesTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-service-types');
    }
    getTaCheckTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-check-types');
    }
    getCeTgScheduleMeridiemTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-tg-schedule-meridiem-types');
    }
    getCeTgScheduleLocationTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-tg-schedule-location-types');
    }
    getCeOeoTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-oeo-types');
    }
    getAllCeOeoTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/all-ce-oeo-types');
    }
    getCeTaEoUsers(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-ta-eo-users');
    }
    getCeTaAuxEoUsers(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-ta-aux-eo-users');
    }
    getCeOffenceProvisions(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-offence-provisions');
    }
    getCeOutcomes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-outcomes');
    }
    getCeOutcomesIp(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-outcomes-ip');
    }
    getCeTaskTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-task-types');
    }
    getCeTaskStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-task-statuses');
    }
    getCeLetters(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-letters');
    }
    getCeTaCheckStatuses(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-ta-check-statuses');
    }
    getCeTaFieldReportClassifications(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-ta-field-report-classifications');
    }
    getCeAppealResults(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-appeal-results');
    }
    getCeProvisionChapters(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-provision-chapters');
    }
    getTgAgeGroups(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-age-groups');
    }
    getCeCaseOicUsers(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ce-case-oic-users');
    }
    clearSystemCache(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/clear-system-cache');
    }
    getEmailBroadcastFreq(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/email-broadcast-frequency');
    }
    getFormList(key: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/formList/' + key);
    }
    getFormStatusList(key: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/formStatusList/' + key);
    }
    getTgCourseSubsidies(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-course-subsidies');
    }
    getTaFilingRequestTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-filing-request-types');
    }
    getTaFilingConditionTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-filing-condition-types');
    }
    getTaMaFilingConditionTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-ma-filing-condition-types');
    }
    getTaFilingAmendTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/ta-filing-amend-types');
    }

    getFirstLevelWorkflowsForCurrentUser(input: any, selectedRoleCode: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/first-level-workflow-types/' + input + '/' + selectedRoleCode);
    }

    getBypassIams(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/iams-sso');
    }

    getTgInfoTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/common/tg-info-types');
    }

    public getSearchDto(paginator: MatPaginator, sort: MatSort, filter: any, fromCache: boolean, listingId: string): any {
        let searchDto: any;

        // to get previous matching searchDto from cache to handle navigation from Details back to Listing page
        if (fromCache) {
            let searchDtoString = sessionStorage.getItem(listingId);
            if (searchDtoString) {
                searchDto = JSON.parse(searchDtoString);
                if (searchDto && searchDto.listingId === listingId) {
                    paginator.pageSize = searchDto.pageSize;
                    paginator.pageIndex = searchDto.startIndex / searchDto.pageSize;
                    sort.direction = searchDto.order;
                    sort.active = searchDto.orderProperty;
                    searchDto.isFromCache = true;
                    return searchDto;
                }
            }
        }

        // no previous matching searchDto found in cache or function call is a brand new search
        searchDto = {
            ...filter,
            'isFromCache': false,
            'listingId': listingId,
            'pageSize': (paginator.pageSize ? paginator.pageSize : (paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE)),
            'startIndex': paginator.pageIndex * paginator.pageSize,
            'order': sort.direction,
            'orderProperty': sort.active,
        };
        if (!searchDto.order) {
            delete searchDto.orderProperty;
        }
        return searchDto;
    }
    public cacheSearchDto(searchDto: any) {
        // only cache new search dto, which will clear what was last clicked
        if (!searchDto.isFromCache) {
            GoButtonComponent.clearLastClicked();
            if (searchDto.listingId) {
                sessionStorage.setItem(searchDto.listingId, JSON.stringify(searchDto));
            }
        }
    }
    public setResultDto(paginator: MatPaginator, rows: MatTableDataSource<any>, data: any) {
        rows.data = data.records;
        paginator.length = data.total;
    }
    public popSnackbar(message: string, panelClass: string) {
        this.snackBar.openFromComponent(SuccessSnackbarComponent, {
            duration: 5000,
            data: { message },
            panelClass: panelClass,
        });
    }
    public getLastDashboardView(defaultVal?: any): any {
        let currentDashboardView: any = defaultVal ? defaultVal : {};
        let currentDashboardViewString = sessionStorage.getItem('dashboardView');
        if (currentDashboardViewString) {
            currentDashboardView = JSON.parse(currentDashboardViewString);
        }
        return currentDashboardView;
    }
    public cacheDashboardView(dashboardView) {
        sessionStorage.setItem('dashboardView', JSON.stringify(dashboardView));
    }

    spanRow(key, accessor, data): any {
        var spans = [];
        for (let i = 0; i < data.length;) {
            let currentValue = accessor(data[i]);
            let count = 1;

            for (let j = i + 1; j < data.length; j++) {
                if (currentValue != accessor(data[j])) {
                    break;
                }

                count++;
            }

            if (!spans[i]) {
                spans[i] = {};
            }

            spans[i][key] = count;
            i += count;
        }

        return spans;
    }

    getRowSpan(col, index, spans) {
        return spans[index] && spans[index][col];
    }

    updateForm(data, key, spans) {
        for (let i = 0; i < data.length; i++) {
            if (this.getRowSpan(key, i, spans)) {
                let temp = data[i][key];
                for (let j = 1; j < this.getRowSpan(key, i, spans); j++) {
                    data[j][key] = temp;
                }
                i + this.getRowSpan(key, i, spans);
            }
        };
    }

    buildFormData(params: any, docs: any) {

        var formData = new FormData();
        Object.keys(params).forEach(key => formData.append(key, params[key]));

        const files: Array<File> = docs;
        if (files) {
            for (let i = 0; i < files.length; i++) {
                formData.append("files", files[i]['file']);
                formData.append("fileDescription", files[i]['fileDescription']);
            }
        }
        return formData;
    }
}