import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatSnackBarVerticalPosition } from '@angular/material';
import { ErrorDialogComponent } from '../modules/error-dialog/errordialog.component';
import { AuthenticationService } from './authentication.service';
import { Router } from '@angular/router';
import * as cnst from '../../common/constants';

@Injectable()
export class ErrorDialogService {
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    constructor(public dialog: MatDialog, public snackBar: MatSnackBar, private router: Router, private authenticationService: AuthenticationService) { }
    openDialog(data): void {
        const dialogRef = this.dialog.open(ErrorDialogComponent, {
            width: '',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            if (data.status === cnst.HttpStatus.UNAUTHORIZED) {
                // auto logout if 401 response returned from api
                if (this.dialog) {
                    this.dialog.closeAll();
                }
                this.authenticationService.logout();
                this.router.navigate(['/login']);
            }
        });
    }

    openErrorSnackBar(data) {
        this.snackBar.open(data.reason, 'X', {
            panelClass: ['error-snack'],
            verticalPosition: 'top',
        });
    }
}
