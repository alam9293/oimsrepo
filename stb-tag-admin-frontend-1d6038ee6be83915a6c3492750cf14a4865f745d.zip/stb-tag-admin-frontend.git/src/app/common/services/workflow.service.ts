import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../constants';

@Injectable({
    providedIn: 'root'
})
export class WorkflowService {

    constructor(private http: HttpClient) { }
    retrieveWorkflows(workflowStepType: String): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/workflow/view/' + workflowStepType);
    }

    getRoleListToBeReturned(returnRoleDto: any): Observable<any> {

        let data = {
            currentStatusCode: returnRoleDto.currentStatusCode,
            appType: returnRoleDto.appType,
            companyName: returnRoleDto.companyName ? returnRoleDto.companyName : null
        }
        return this.http.get<any>(cnst.apiBaseUrl + '/workflow/return/role', { params: data });
    }

    getOfficerListByStatus(startStatusCode: String): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/workflow/officer/' + startStatusCode);
    }

    getOfficerListByStatusAndWorkflowType(startStatusCode: String, workflowType: String): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/workflow/officer/' + startStatusCode + '/' + workflowType);
    }

    getOfficerListByRole(roleCode: String): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/workflow/officer/role/' + roleCode);
    }

    public updateWorkflow(workflowItemDto: any, workflowStepType: String) {
        return this.http.post(cnst.apiBaseUrl + '/workflow/update/' + workflowStepType, workflowItemDto);
    }

    getCeWorkflowConfigByType(appOrWkflwTypeCode: String): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/workflow/ce/' + appOrWkflwTypeCode);
    }

    public reAssignOfficer(input: any) {
        return this.http.post(cnst.apiBaseUrl + '/workflow/ce/re-assign', input);
    }
}