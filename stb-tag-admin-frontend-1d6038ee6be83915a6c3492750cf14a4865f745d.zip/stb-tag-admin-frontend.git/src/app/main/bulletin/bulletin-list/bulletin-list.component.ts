import { SelectionModel } from '@angular/cdk/collections';
import { SuccessSnackbarComponent } from '../../../common/modules/success-snackbar/success-snackbar.component';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { BulletinService } from '../bulletin-service'
import { CommonService } from '../../../common/services'
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-bulletin-list',
    templateUrl: './bulletin-list.component.html',
    styleUrls: ['./bulletin-list.component.scss'],
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
            state('expanded', style({ height: '*' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ],
})
export class BulletinListComponent implements OnInit {

    constructor(
        private route: ActivatedRoute,
        private bulletinService: BulletinService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar
    ) { }

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    rows = [];
    dataSource = [];
    selection = new SelectionModel<any>(true, []);
    columnsToDisplay = ['title', 'isPrivate', 'effectiveDate', 'expiryDate', 'currentlyDisplayed', 'updatedBy', 'edit'];
    listingId = "bulletin-list";
    expandedElement: any = {};
    bulletinTypeCode: string;
    filter: any = {};
    cnst = cnst;

    ngOnInit() {
        this.bulletinTypeCode = this.route.snapshot.data.bulletinTypeCode;
        this.loadBulletins(true);
    }

    loadBulletins(fromCache: boolean) {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.listingId);

        this.bulletinService.getAllBulletinsList(this.filter, this.bulletinTypeCode).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }
}
