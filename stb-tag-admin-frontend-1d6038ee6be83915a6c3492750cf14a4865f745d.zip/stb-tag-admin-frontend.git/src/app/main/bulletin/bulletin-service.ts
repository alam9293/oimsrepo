import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../common/constants';
import { AuthenticationService } from '../../common/services';

@Injectable({
    providedIn: 'root'
})
export class BulletinService {

    constructor(private http: HttpClient,
        private authenticationService: AuthenticationService) { }

    getAllBulletinsList(searchDto: any, type: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/bulletin/list-all/' + type, { params: searchDto });
    }

    getBulletinDetails(bulletinId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/bulletin/view/' + bulletinId);
    }

    saveBulletin(bulleinDetail: any, deletedList: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(bulleinDetail)],
            { type: 'application/json' }
        ));

        var deletedBlob = new Blob(
            [JSON.stringify(deletedList)],
            { type: 'application/json' }
        );
        formData.append('deletedFiles', deletedBlob);

        return this.http.post(cnst.apiBaseUrl + '/bulletin/save/', formData);
    }

    public get allowToSaveBulletin(): boolean {
        return this.authenticationService.checkPermission('BULLETIN_SAVE');
    }
}