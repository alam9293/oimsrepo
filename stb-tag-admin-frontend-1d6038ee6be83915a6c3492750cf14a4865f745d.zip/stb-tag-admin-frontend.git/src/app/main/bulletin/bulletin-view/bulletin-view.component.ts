import { Component, OnInit, ViewChild, HostListener, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SuccessSnackbarComponent } from '../../../common/modules/success-snackbar/success-snackbar.component';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
import { ToolbarService, LinkService, ImageService, HtmlEditorService, RichTextEditorComponent } from '@syncfusion/ej2-angular-richtexteditor';
import { BulletinService } from '../bulletin-service'
import { CommonService } from '../../../common/services'
import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil } from '../../../common/helper';
import { DateValidator } from '../../../common/validators';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
    selector: 'app-bulletin-view',
    templateUrl: './bulletin-view.component.html',
    styleUrls: ['./bulletin-view.component.scss'],
    providers: [ToolbarService, LinkService, ImageService, HtmlEditorService]
})
export class BulletinViewComponent implements OnInit {
    public Editor = ClassicEditor;
    public config = { toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'inserttable', 'undo', 'redo'] };

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private dialog: MatDialog,
        private snackBar: MatSnackBar,
        private bulletinService: BulletinService,
        private fileUtil: FileUtil,
        private commonService: CommonService,
        public formUtil: FormUtil
    ) { }

    cnst = cnst;
    form = this.formBuilder.group({
        title: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
        content: ['', [Validators.required]],
        typeCode: ['', Validators.required],
        isPrivate: [''],
        effectiveDate: ['', Validators.required],
        expiryDate: ['', Validators.required],
        id: [''],
        files: [],
        totalDoc: [''],
    }, { validator: DateValidator.dateLessThan("effectiveDate", "expiryDate") });
    isNew: boolean = false;
    selectedFile: File;
    selectedFiles: any = [];
    bulletinId: number;
    bulletin: any = {};
    typeList: any = [];
    adminDeletedFiles: any = [];
    unionMap = new Map<string, string>();

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        if (this.route.snapshot.url.toString() === 'bulletin-new') {
            this.isNew = true;
            this.loadSelectedType(false);
        } else {
            this.bulletinId = +this.route.snapshot.paramMap.get('id');
            this.form.get('id').setValue(this.bulletinId);
            this.loadBulletinDetails();
        }
        this.allowToSave();
    }

    loadBulletinDetails() {
        this.bulletinService.getBulletinDetails(this.bulletinId).subscribe(data => {
            this.bulletin = data;
            this.form.patchValue(data);
            this.isNew = false;
            this.loadSelectedType(data.isPrivate);
            if (data.files) {
                this.selectedFiles = data.files;
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            }
        });
    }

    saveBulletin() {
        this.form.patchValue({
            files: this.selectedFiles
        });
        this.bulletinService.saveBulletin(this.form.value, this.adminDeletedFiles).subscribe(
            bulletinId => {
                this.commonService.popSnackbar(null, 'success-snackbar');
                this.form.markAsPristine(); // to prevent triggering PristineGuard
                this.router.navigate(['/bulletin-view/' + bulletinId]);
            });
    }

    load() {
        var isPublicPrivate = this.form.get('isPrivate').value;
        this.loadSelectedType(isPublicPrivate);

        if (isPublicPrivate) {
            var index = this.form.get('typeCode').value.indexOf('GENERAL');
            if (index != -1) {
                this.form.get('typeCode').setValue('');
            }
        }
    }

    loadSelectedType(isPublicPrivate: Boolean) {
        if (isPublicPrivate) {
            this.commonService.getBulletinTypeCodeTaTgList().subscribe(data => this.typeList = data);
        } else {
            this.commonService.getBulletinTypeCodeList().subscribe(data => this.typeList = data);
        }
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.uploadBulletinFile(type, this.selectedFile).subscribe(data => {
                this.selectedFiles.push(data);
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            });
        }
    }

    downloadFile(doc) {
        var fileId = doc.id,
            fileName = doc.originalName;

        this.fileUtil.download(fileId, doc.hash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.form.get('totalDoc').setValue(this.selectedFiles.length);
        this.adminDeletedFiles.push(doc.id);
    }

    allowToSave() {
        var allowSave = this.bulletinService.allowToSaveBulletin;
        if (allowSave == true) {
            this.form.enable();
        } else {
            this.form.disable();
        }
    }

    textChanged() {
        var title = this.form.get("title").value;
        var splitStr = title.toLowerCase().split(' ');
        for (var i = 0; i < splitStr.length; i++) {
            splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
        }
        this.form.get("title").setValue(splitStr.join(' '));
    }
}
