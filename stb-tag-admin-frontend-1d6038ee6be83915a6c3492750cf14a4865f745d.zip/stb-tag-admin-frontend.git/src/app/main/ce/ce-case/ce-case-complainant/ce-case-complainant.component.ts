import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatPaginator, MatSort, MatTable } from '@angular/material';
import { FileUtil, FormUtil, ValidateEmail } from 'src/app/common/helper';
import { CommonService } from 'src/app/common/services';

import * as cnst from '../../../../common/constants';

@Component({
    selector: 'ce-case-complainant',
    templateUrl: './ce-case-complainant.component.html',
    styleUrls: ['./ce-case-complainant.component.scss']
})
export class CeCaseComplainantComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) complainantPaginator: MatPaginator;
    @ViewChild(MatTable) _matTables;

    complainantColumns = ['name', 'contactNo', 'emailAddress', 'address', 'attachment', 'action'];

    cnst = cnst;
    complainantForm: FormGroup = this.fb.group({
        complainants: this.fb.array([]),
        deletedComplainants: this.fb.array([])
    });

    selectedFile: File;
    selectedFiles: any = [];

    buttonDisabled: boolean = false;
    addressType: any;

    constructor(private dialog: MatDialog, private fb: FormBuilder, public formUtil: FormUtil, public fileUtil: FileUtil, private commonService: CommonService) {
    }

    ngOnInit() {
        this.initForm();

        this.commonService.getAddressType().subscribe(data => {
            this.addressType = data;
        })
    }

    set(data) {
        if (data) {
            this.initForm();

            data.forEach(u => {
                this.addComplainant(u);
            });
        }
    }

    initForm() {
        this.complainantForm = this.fb.group({
            complainants: this.fb.array([]),
            deletedComplainants: this.fb.array([])
        })
    }

    addComplainant(data) {
        var complainants = this.complainantForm.get('complainants') as FormArray;
        complainants.push(
            this.populateComplainantFormGroup(data)
        );

        if (data) {
            this.selectedFiles.push(data.attachment);
        }

        this._matTables.renderRows();
    }

    deleteComplainant(rowIndex) {

        var complainants = this.complainantForm.get('complainants') as FormArray;
        var complainant = complainants.at(rowIndex);

        if (complainant.get('id').value) {
            var deletedComplainants = this.complainantForm.get('deletedComplainants') as FormArray;
            deletedComplainants.push(complainant);
        }

        complainants.removeAt(rowIndex);
        this.selectedFiles.splice(rowIndex, 1);
        this._matTables.renderRows();
    }

    populateComplainantFormGroup(x) {

        var complainant = this.fb.group({
            id: x ? x.id : [],
            name: [x ? x.name : '', Validators.required],
            contactNo: [x ? x.contactNo : '', Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)],
            emailAddress: [x ? x.emailAddress : '', [Validators.maxLength(320), ValidateEmail]],
            residentialType: x ? x.residentialType : [],
            postalCode: [x ? x.postalCode : '', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            block: [x ? x.block : '', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            street: [x ? x.street : '', Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)],
            building: [x ? x.building : '', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
            level: [x ? x.level : '', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            unit: [x ? x.unit : '', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.UNIT), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
            foreignLine1: x ? x.foreignLine1 : [],
            foreignLine2: x ? x.foreignLine2 : [],
            foreignLine3: x ? x.foreignLine3 : [],
            address: x ? x.address : [],
            attachment: x ? [x.attachment] : [],
            deletedAttachment: [],
        });

        complainant.get('residentialType').valueChanges.subscribe(val => {
            if (complainant.get('residentialType').value == cnst.AddressTypes.ADDR_LOCAL) {
                complainant.get('foreignLine1').setValue(null);
                complainant.get('foreignLine2').setValue(null);
                complainant.get('foreignLine3').setValue(null);
            } else {
                complainant.get('postalCode').setValue(null);
                complainant.get('block').setValue(null);
                complainant.get('street').setValue(null);
                complainant.get('building').setValue(null);
                complainant.get('level').setValue(null);
                complainant.get('unit').setValue(null);
            }
        });

        return complainant;
    }

    setValidators(form: any, fields: any) {
        for (var item in fields) {
            form.get(item).setValidators(fields[item]);
            form.get(item).updateValueAndValidity();
        }
    }

    onFileChanged(event, type, rowIndex) {
        var complainants = this.complainantForm.get('complainants') as FormArray;
        var complainant = complainants.at(rowIndex);
        var attachment = complainant.get('attachment');

        var attachments: any = [];
        if (attachment.value) {
            attachments = attachment.value;
        }

        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                attachments.push(data);
                this.selectedFiles[rowIndex] = attachments;
                attachment.setValue(attachments);
            });
        }
    }

    deleteAttachment(rowIndex, fileIndex) {

        var complainants = this.complainantForm.get('complainants') as FormArray;
        var complainant = complainants.at(rowIndex);

        var affectedComplainantFileList = this.selectedFiles[rowIndex];
        var removedFile = affectedComplainantFileList[fileIndex];

        var deletedAttachment = complainant.get('deletedAttachment');
        var deletedAttachments: any = [];
        if (deletedAttachment.value) {
            deletedAttachments = deletedAttachment.value;
        }
        deletedAttachments.push(removedFile);
        deletedAttachment.setValue(deletedAttachments);

        var attachment = complainant.get('attachment');
        affectedComplainantFileList.splice(fileIndex, 1);
        attachment.setValue(affectedComplainantFileList);
    }

}