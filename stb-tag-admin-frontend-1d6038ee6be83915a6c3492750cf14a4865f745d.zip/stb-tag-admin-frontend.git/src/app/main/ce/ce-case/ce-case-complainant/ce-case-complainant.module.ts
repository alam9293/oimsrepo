import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
    MatRadioModule,
    MatListModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';

import { CeCaseComplainantComponent } from './ce-case-complainant.component';
import { SharedModule } from 'src/app/common/modules/shared.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule,
        MatDatepickerModule,
        MatSidenavModule,
        SharedModule,
        MatRadioModule
    ],
    declarations: [CeCaseComplainantComponent,],
    exports: [CeCaseComplainantComponent,],
    entryComponents: [],
})
export class CeCaseComplainantModule { }
