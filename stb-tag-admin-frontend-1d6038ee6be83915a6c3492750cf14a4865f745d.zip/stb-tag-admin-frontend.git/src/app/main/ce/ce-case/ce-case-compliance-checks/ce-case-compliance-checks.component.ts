import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { MatDialog, MatDialogRef, MatDrawer, MatPaginator, MatSort, MatTable, MAT_DIALOG_DATA } from '@angular/material';
import { AuthenticationService, CommonService } from 'src/app/common/services';

import * as cnst from '../../../../common/constants';
import { CeCaseService } from '../ce-case.service';

@Component({
    selector: 'ce-case-compliance-checks',
    templateUrl: './ce-case-compliance-checks.component.html',
    styleUrls: ['./ce-case-compliance-checks.component.scss']
})
export class CeCaseComplianceChecksComponent implements OnInit {
    @ViewChild(MatTable) _matTables;

    complianceCheckColumns = ['conductDate', 'complianceCheck', 'conductBy', 'remarks', 'action'];

    complianceChecksForm: FormGroup;

    deletedComplianceChecks = [];

    cnst = cnst;

    constructor(private dialog: MatDialog, private fb: FormBuilder) { }

    ngOnInit() {
        this.initForm();
    }

    initForm() {
        this.complianceChecksForm = this.fb.group({
            complianceChecks: this.fb.array([]),
            deletedComplianceChecks: this.fb.array([])
        })
    }

    set(data) {
        if (data) {
            this.initForm();

            data.forEach(u => {
                this.addComplianceCheck(u);
            });
        }
    }

    openAddComplianceChecksDialog() {
        var complianceChecks = this.complianceChecksForm.get('complianceChecks') as FormArray;
        let dialogAddComplianceChecks = this.dialog.open(DialogAddComplianceChecks, {
            data: {
                selectedItems: complianceChecks.value
            },
            panelClass: 'full-screen-modal',
        });

        dialogAddComplianceChecks.afterClosed().subscribe(result => {
            if (result) {
                this.initForm();
                var newChecks = this.complianceChecksForm.get('complianceChecks') as FormArray;
                if (result.selectedItems) {
                    result.selectedItems.forEach(element => {
                        newChecks.push(this.populateComplianceChecksFormGroup(element));
                    });
                }
                this._matTables.renderRows();
            }
        });
    }

    addComplianceCheck(data) {
        var complianceChecks = this.complianceChecksForm.get('complianceChecks') as FormArray;
        complianceChecks.push(
            this.populateComplianceChecksFormGroup(data)
        );
        this._matTables.renderRows();
    }

    deleteComplianceCheck(control, index) {
        var deletedCheck = control.at(index);
        if (deletedCheck.get('ceCaseId') != null) {
            this.deletedComplianceChecks.push(deletedCheck.value);
        }

        control.removeAt(index);
        this._matTables.renderRows();
    }

    populateComplianceChecksFormGroup(x) {
        return this.fb.group({
            id: x ? x.id : [],
            conductedDate: x ? x.conductedDate : [],
            uin: x ? x.uin : [],
            uen: x ? x.uen : [],
            licenceNo: x ? x.licenceNo : [],
            name: x ? x.name : [],
            companyName: x ? x.companyName : [],
            conductedBy: x ? x.conductedBy : [],
            remarks: x ? x.remarks : [],
            ceCaseId: x ? x.ceCaseId : [],
            type: x ? x.type : [],
            nameForDisplay: x ? x.nameForDisplay : []
        });
    }
}

@Component({
    selector: 'dialog-add-compliance-checks',
    styleUrls: ['./ce-case-compliance-checks.component.scss'],
    templateUrl: 'ce-case-add-compliance-check-dialog.html',
})
export class DialogAddComplianceChecks implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(MatSort) sort: MatSort;

    listingId = "ce-case-compliance-checks";
    filter: any = {};
    rows = [];
    cnst = cnst;
    selectedItems = [];

    displayedColumns = [];

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<DialogAddComplianceChecks>,
        public authService: AuthenticationService,
        private commonService: CommonService,
        private ceCaseService: CeCaseService) { }

    ngOnInit() {
        this.matDrawer.toggle();

        if (this.data.selectedItems) {
            this.selectedItems = this.data.selectedItems;
        }

        if (this.showUEN()) {
            this.displayedColumns = ['no', 'conductedDate', 'conductedBy', 'uin', 'name', 'uen', 'companyName', 'licenceNo', 'action'];
        } else {
            this.displayedColumns = ['no', 'conductedDate', 'conductedBy', 'uin', 'name', 'licenceNo', 'action'];
        }
    }

    loadChecks() {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, false, this.listingId);
        this.ceCaseService.searchComplianceChecks(this.filter).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    addItemToArray(element, array) {
        array.push(element);
    }

    disabledIfAdded(element) {
        return this.selectedItems.filter(selectedItem => selectedItem.id == element.id).length > 0;
    }

    closeDialog(decision) {
        if (decision) {
            this.dialogRef.close({ selectedItems: this.selectedItems });
        } else {
            this.dialogRef.close();
        }
    }

    showUEN(): boolean {
        return this.authService.currentUserValue.department['key'] == cnst.department.DEPARTMENT_TA;
    }
}