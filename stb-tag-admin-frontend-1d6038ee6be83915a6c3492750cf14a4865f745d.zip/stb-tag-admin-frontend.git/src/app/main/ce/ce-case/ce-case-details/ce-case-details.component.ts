import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';

import * as cnst from '../../../../common/constants';
import { AttachmentComponent } from '../../../../common/modules/attachment/attachment.component';
import { CeCaseComplainantComponent } from '../ce-case-complainant/ce-case-complainant.component';
import { CeCaseComplianceChecksComponent } from '../ce-case-compliance-checks/ce-case-compliance-checks.component';
import { CeCaseOffencesComponent } from '../ce-case-offences/ce-case-offences.component';
import { CeCaseRelevantOffencesComponent } from '../ce-case-relevant-offences/ce-case-relevant-offences.component';
import { CeCaseTaskDialogComponent } from '../ce-case-task-dialog/ce-case-task-dialog.component';
import { CeCaseService } from '../ce-case.service';

@Component({
    selector: 'ce-case-details',
    templateUrl: './ce-case-details.component.html',
    styleUrls: ['./ce-case-details.component.scss']
})
export class CeCaseDetailsComponent implements OnInit {

    @ViewChild(CeCaseComplainantComponent) ceCaseComplainantComponent: CeCaseComplainantComponent;
    @ViewChild(CeCaseOffencesComponent) ceCaseOffencesComponent: CeCaseOffencesComponent;
    @ViewChild(CeCaseComplianceChecksComponent) ceCaseComplianceChecksComponent: CeCaseComplianceChecksComponent;
    @ViewChild(AttachmentComponent) ceCaseAttachmentsComponent: AttachmentComponent;
    @ViewChild(CeCaseRelevantOffencesComponent) ceCaseRelevantOffencesComponent: CeCaseRelevantOffencesComponent;

    ceCase: any = { isNew: true, isOic: true, isPendingApproval: false };
    caseForm: FormGroup;
    cnst = cnst;

    buttonDisabled: boolean = false;
    fromIp: boolean = false;

    changeOffences: any;

    constructor(
        private dialog: MatDialog,
        private ceCaseService: CeCaseService,
        private fb: FormBuilder) { }

    ngOnInit() {
        // this.initForm();
    }

    initForm() {
        this.caseForm = this.ceCaseService.initCaseForm();
    }

    changeOffence($event) {
        this.ceCaseRelevantOffencesComponent.reload($event);
    }

    loadCase(data: any, fromIp: boolean) {
        this.fromIp = fromIp;
        this.initForm();
        this.caseForm.patchValue(data);

        this.ceCase = data;
        this.ceCaseComplainantComponent.set(data.complainants);
        this.ceCaseComplianceChecksComponent.set(data.complianceChecks);
        this.ceCaseOffencesComponent.set(data);
        this.ceCaseAttachmentsComponent.set(data.othAttachments);
        this.ceCaseRelevantOffencesComponent.loadDetails(data.othInfringements);

        if (data.taggedCaseNo != null || fromIp || (data.isPendingApproval && !data.isRoutedBack)) {
            this.caseForm.disable();
            this.buttonDisabled = true;

            this.ceCaseComplainantComponent.complainantForm.disable();
            this.ceCaseComplainantComponent.buttonDisabled = true;

            this.ceCaseOffencesComponent.buttonDisabled = true;
            if (data.taggedCaseNo != null) {
                this.ceCaseOffencesComponent.isTaggedCase = true;
            }

            this.ceCaseAttachmentsComponent.attachmentForm.disable();
            this.ceCaseAttachmentsComponent.toDisable = true;
        }
    }

    enableForm() {
        this.caseForm.enable();
        this.buttonDisabled = false;

        this.ceCaseComplainantComponent.complainantForm.enable();
        this.ceCaseComplainantComponent.buttonDisabled = false;

        this.ceCaseOffencesComponent.buttonDisabled = false;
        this.ceCaseOffencesComponent.isTaggedCase = false;

        this.ceCaseAttachmentsComponent.attachmentForm.enable();
        this.ceCaseAttachmentsComponent.toDisable = false;
    }

    getFormData() {
        if (this.ceCaseComplainantComponent.complainantForm) {
            this.caseForm.get('complainants').setValue(this.ceCaseComplainantComponent.complainantForm.get('complainants').value);
            this.caseForm.get('deletedComplainants').setValue(this.ceCaseComplainantComponent.complainantForm.get('deletedComplainants').value);
        }

        if (this.ceCaseComplianceChecksComponent.complianceChecksForm) {
            this.caseForm.get('complianceChecks').setValue(this.ceCaseComplianceChecksComponent.complianceChecksForm.get('complianceChecks').value);
            this.caseForm.get('deletedComplianceChecks').setValue(this.ceCaseComplianceChecksComponent.deletedComplianceChecks);
        }

        if (this.ceCaseOffencesComponent.offenceForm) {
            this.caseForm.get('infringements').setValue(this.ceCaseOffencesComponent.offenceForm.get('infringements').value);
            this.caseForm.get('deletedInfringements').setValue(this.ceCaseOffencesComponent.offenceForm.get('deletedInfringements').value);
        }

        if (this.ceCaseAttachmentsComponent.attachmentForm) {
            this.caseForm.get('othAttachments').setValue(this.ceCaseAttachmentsComponent.attachmentForm.get('attachments').value);
            this.caseForm.get('othDeletedAttachments').setValue(this.ceCaseAttachmentsComponent.attachmentForm.get('deletedAttachements').value);
        }

        return this.caseForm.value;
    }

    openCeTaskDialog(workflowId, appOrWkflwTypeCode, fromCreateCaseTaskButton) {

        this.caseForm.patchValue(this.getFormData());

        var currWorkflow = this.caseForm.get('currentWorkflow');
        currWorkflow.get('appOrWkflwTypeCode').setValue(appOrWkflwTypeCode);
        if (workflowId != null) {
            currWorkflow.get('workflowId').setValue(workflowId);
        }

        var offenceComp = this.ceCaseOffencesComponent;
        let dialogCaseTask = this.dialog.open(CeCaseTaskDialogComponent, {
            data: {
                appOrWkflwTypeCode: appOrWkflwTypeCode,
                offenceProvisions: offenceComp.offenceProvisions,
                offenceProvisionMap: offenceComp.offenceProvisionMap,
                recommendations: offenceComp.recommendations,
                appealResults: offenceComp.appealResults,
                form: this.caseForm,
                fromCreateCaseTaskButton: fromCreateCaseTaskButton
            },
            panelClass: 'full-screen-modal',
        });

        dialogCaseTask.afterClosed().subscribe(result => {
            if (result) {
                this.loadCase(result, false);
            }
        });
    }

    isTaType() {
        return this.caseForm.get('taTgType').value == cnst.caseType.TA;
    }

    // only OIC can create case task, and
    // have at least one infringement, and
    // is not pending approval
    // is pending approval but status is route back
    showCreateCaseTaskButton() {
        var infringements = this.ceCaseService.getFormArray(this.ceCaseOffencesComponent.offenceForm, 'infringements');
        //return this.ceCase.isOic && !this.ceCase.isPendingApproval && infringements.length > 0;
        return !this.ceCase.isPendingApproval && infringements.length > 0; // allow other officer to submit recommendation for case also in case the oic go on leave
    }
}
