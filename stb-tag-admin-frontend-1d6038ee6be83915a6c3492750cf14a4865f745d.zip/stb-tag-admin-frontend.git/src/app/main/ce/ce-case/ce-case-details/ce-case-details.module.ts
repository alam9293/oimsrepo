import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';

import { AttachmentModule } from '../../../../common/modules/attachment/attachment.module';
import { CeCaseComplainantModule } from '../ce-case-complainant/ce-case-complainant.module';
import { CeCaseComplianceChecksModule } from '../ce-case-compliance-checks/ce-case-compliance-checks.module';
import { CeCaseOffencesModule } from '../ce-case-offences/ce-case-offences.module';
import { CeCaseRelevantOffencesModule } from '../ce-case-relevant-offences/ce-case-relevant-offences.module';
import { CeCaseDetailsComponent } from './ce-case-details.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule,
        MatDatepickerModule,
        MatSidenavModule,
        MatMenuModule,
        MatCheckboxModule,
        MatExpansionModule,

        CeCaseComplainantModule,
        CeCaseOffencesModule,
        CeCaseComplianceChecksModule,
        AttachmentModule,
        CeCaseRelevantOffencesModule,
    ],
    declarations: [CeCaseDetailsComponent],
    exports: [CeCaseDetailsComponent],
    entryComponents: [],
})
export class CeCaseDetailsModule { }
