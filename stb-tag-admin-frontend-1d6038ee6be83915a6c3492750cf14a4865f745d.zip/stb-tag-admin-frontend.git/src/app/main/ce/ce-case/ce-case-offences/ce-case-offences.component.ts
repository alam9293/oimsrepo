import { SelectionModel } from '@angular/cdk/collections';
import { Component, ElementRef, Inject, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import {
    MAT_DIALOG_DATA,
    MatDialog,
    MatDialogRef,
    MatMenuTrigger,
    MatPaginator,
    MatSort,
    MatTable,
} from '@angular/material';
import { DateUtil, FileUtil } from 'src/app/common/helper';
import { CommonService, AuthenticationService } from 'src/app/common/services';

import * as cnst from '../../../../common/constants';
import { CeDirectoryListDialogComponent } from '../../ce-directory/ce-directory-list.component';
import { CeCaseService } from '../ce-case.service';

@Component({
    selector: 'ce-case-offences',
    templateUrl: './ce-case-offences.component.html',
    styleUrls: ['./ce-case-offences.component.scss']
})
export class CeCaseOffencesComponent implements OnInit {

    @ViewChild(MatTable) _matTables;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) offencePaginator: MatPaginator;

    @Output() caseOffencesEvent = new EventEmitter<any>();

    offenceColumns = ['offenderName', 'offenceDate', 'offenceProvision', 'recommendation', 'outcome', 'action'];

    offenceProvisions: any;
    offenceProvisionMap = new Map<any, any>();
    recommendations: any;
    appealResults: any;

    selection = new SelectionModel<any>(true, []);
    cnst = cnst;

    offenceForm: FormGroup = this.fb.group({
        infringements: this.fb.array([]),
        deletedInfringements: this.fb.array([]),
    });;

    spans = [];


    ceCase: any;
    caseNo = null;
    taTgType = null;
    buttonDisabled: boolean = false;
    isTaggedCase: boolean = false;

    tempForm: FormGroup = this.fb.group({
        reload: []
    })

    constructor(
        public authService: AuthenticationService,
        private dialog: MatDialog,
        private fb: FormBuilder,
        public commonService: CommonService,
        public ceCaseService: CeCaseService,
        public fileUtil: FileUtil) { }

    ngOnInit() {
        // this.initForm();

        this.commonService.getCeOutcomes().subscribe(data => { this.recommendations = data });
        this.commonService.getCeAppealResults().subscribe(data => { this.appealResults = data });
    }

    initForm() {
        this.offenceForm = this.fb.group({
            infringements: this.fb.array([]),
            deletedInfringements: this.fb.array([]),
        });
    }

    set(data) {
        this.ceCase = data;
        this.caseNo = data.caseNo;
        this.taTgType = data.taTgType;
        if (data.infringements) {
            this.initForm();
            data.infringements.forEach(u => {
                this.addOffence(u);
            });
        }
    }

    addOffence(data) {
        var infringements = this.offenceForm.get('infringements') as FormArray;
        infringements.push(
            this.ceCaseService.populateOffenceFormGroup(data, null)
        );
        this.renderTable();
    }

    openAddOffenceDialog() {
        let dialogAddOffence = this.dialog.open(DialogAddOffence, {
            data: {
                offence: this.offenceForm,
                offenceProvisions: this.offenceProvisions,
                offenceProvisionMap: this.offenceProvisionMap,
                recommendations: this.recommendations,
                taTgType: this.taTgType,
            },
            panelClass: 'full-screen-modal',
        });

        dialogAddOffence.afterClosed().subscribe(result => {
            if (result) {
                this.updateOffenceForm(result);
            }
        });
    }

    editOffence(uenUin) {
        let dialogAddOffence = this.dialog.open(DialogAddOffence, {
            data: {
                offence: this.offenceForm,
                uenUin: uenUin,
                offenceProvisions: this.offenceProvisions,
                offenceProvisionMap: this.offenceProvisionMap,
                recommendations: this.recommendations,
            }, panelClass: 'full-screen-modal',
        });

        dialogAddOffence.afterClosed().subscribe(result => {
            if (result) {
                this.updateOffenceForm(result);
            }
        });
    }

    updateOffenceForm(result) {
        this.offenceForm = result.form;
        this.renderTable();

        this.offencesChangeEventEmit();
    }

    deleteOffence(control, index) {
        var deletedInfringement = control.at(index);
        if (deletedInfringement.get('infringementId') != null) {
            var deletedInfringements = this.offenceForm.get('deletedInfringements') as FormArray;
            deletedInfringements.push(deletedInfringement);
        }

        control.removeAt(index);
        this.renderTable();

        this.offencesChangeEventEmit();
    }

    offencesChangeEventEmit() {
        if (!this.ceCase) {
            var caseForm = this.ceCaseService.initCaseForm();
            if (this.authService.currentUserValue.department['key'] == cnst.department.DEPARTMENT_TG) {
                caseForm.get('taTgType').setValue(cnst.caseType.TG);
            } else {
                caseForm.get('taTgType').setValue(cnst.caseType.TA);
            }
            this.ceCase = caseForm.value;
        }

        for (const field in this.offenceForm.controls) {
            this.ceCase[field] = this.offenceForm.get(field).value;
        }

        this.caseOffencesEvent.emit(this.ceCase);
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.offenceForm.get('infringements').value.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.offenceForm.get('infringements').value.forEach(row => this.selection.select(row));
    }

    showHideDetails(rowIndex, outcomes): boolean {
        var infringements = this.offenceForm.get('infringements') as FormArray;
        var infringement = infringements.at(rowIndex);
        var recommendation = infringement.get('recommendation').get('recommendation');

        if (recommendation.value) {
            var outcomeKey = recommendation.value['key'];
            return outcomes.includes(outcomeKey);
        }
    }

    renderTable() {
        this._matTables.renderRows();
        this.spans = this.commonService.spanRow('offenderName', d => d.offenderName, this.offenceForm.get("infringements").value);
    }
}


@Component({
    selector: 'dialog-add-offence',
    templateUrl: 'ce-case-add-offence-dialog.html',
    styleUrls: ['./ce-case-offences.component.scss']
})
export class DialogAddOffence implements OnInit {

    @ViewChild(MatTable) _matTables;
    @ViewChild(MatMenuTrigger) clickLetterMenuTrigger: MatMenuTrigger;
    @ViewChild('ceLetter') ceLetter: ElementRef;

    selection = new SelectionModel<any>(true, []);

    offenceProvisions: any;
    offenceProvisionMap = new Map<any, any>();
    recommendations: any;
    taTgType: any;

    selectedFile: File;
    selectedFiles: any;

    cnst = cnst;

    offenceColumns = ['select', 'offenceDate', 'offenceProvision', 'recommendation', 'details', 'letterIssuance', 'letterIssuanceDate', 'action'];

    offenderUenUin: any;
    offenderName: any;
    offenderLicenceId: any;

    todayDate = DateUtil.getNow();

    allOffenderForm = this.fb.group({
        infringements: this.fb.array([]),
        deletedInfringements: this.fb.array([]),
    });

    currentOffenderForm = this.fb.group({
        infringements: this.fb.array([]),
        deletedInfringements: this.fb.array([]),
    });

    otherOffenderForm = this.fb.group({
        infringements: this.fb.array([]),
        deletedInfringements: this.fb.array([]),
    });

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<DialogAddOffence>,
        private dialog: MatDialog,
        public ceCaseService: CeCaseService,
        private fb: FormBuilder,
        private commonService: CommonService,
        private fileUtil: FileUtil) { }

    ngOnInit() {
        this.offenceProvisions = this.data.offenceProvisions;
        this.offenceProvisionMap = this.data.offenceProvisionMap;
        this.recommendations = this.data.recommendations;
        this.taTgType = this.data.taTgType;

        if (this.data.offence) {
            this.allOffenderForm = this.data.offence;
        }

        if (this.data.uenUin) {
            this.offenderUenUin = this.data.uenUin;
            this.getDetailsFromForm(this.offenderUenUin);
        }
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.currentOffenderForm.get('infringements').value.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.currentOffenderForm.get('infringements').value.forEach(row => this.selection.select(row));
    }

    closeDialog(decision) {
        if (decision) {
            var currentOffenderInfringements = this.ceCaseService.getFormArray(this.currentOffenderForm, 'infringements');

            // set all current editing offenders uen/uin and name
            for (let i = 0; i < currentOffenderInfringements.length; i++) {
                currentOffenderInfringements.at(i).get("offenderUenUin").setValue(this.offenderUenUin);
                currentOffenderInfringements.at(i).get("offenderName").setValue(this.offenderName);
                currentOffenderInfringements.at(i).get("licenceId").setValue(this.offenderLicenceId);
            }

            // combine current editing offender with other offender if exists
            var othOffenderInfringements = this.ceCaseService.getFormArray(this.otherOffenderForm, 'infringements');
            for (let i = 0; i < othOffenderInfringements.length; i++) {
                currentOffenderInfringements.push(othOffenderInfringements.at(i));
            }

            // combine all deleted infringements if exists
            var deletedInfringements = this.ceCaseService.getFormArray(this.allOffenderForm, 'deletedInfringements');
            var currentDeletedInfringements = this.ceCaseService.getFormArray(this.currentOffenderForm, 'deletedInfringements');
            for (let i = 0; i < deletedInfringements.length; i++) {
                currentDeletedInfringements.push(deletedInfringements.at(i));
            }

            let result = {
                decision: decision,
                form: this.currentOffenderForm
            };

            this.dialogRef.close(result);
        } else {
            this.dialogRef.close();
        }
    }

    addOffence() {
        var infringements = this.ceCaseService.getFormArray(this.currentOffenderForm, 'infringements');
        infringements.push(
            this.ceCaseService.populateOffenceFormGroup(null, null)
        );
        this._matTables.renderRows();
    }

    deleteOffence(control, index) {
        var deletedInfringement = control.at(index);
        if (deletedInfringement.get('infringementId') != null) {
            var deletedInfringements = this.ceCaseService.getFormArray(this.currentOffenderForm, 'deletedInfringements');
            deletedInfringements.push(deletedInfringement);
        }

        control.removeAt(index);
        this._matTables.renderRows();
    }

    loadOffenderDetails(event) {

        var uenUin = event.target.value;
        var toCallBackend = this.getDetailsFromForm(uenUin);

        if (toCallBackend) {
            if (uenUin != null && uenUin != "") {
                this.ceCaseService.loadOffenderDetails(uenUin, this.taTgType).subscribe(data => {
                    if (data) {
                        this.offenderName = data.name;
                        this.offenderLicenceId = data.licenceId;
                    }
                });
            }
        }

        this._matTables.renderRows();
    }

    getDetailsFromForm(uenUin): boolean {
        var toCallBackend = true;
        var allOffenders = this.ceCaseService.getFormArray(this.allOffenderForm, 'infringements');

        if (allOffenders && allOffenders.length > 0) {

            var currentOffenderInfringements = this.resetForm(this.currentOffenderForm, 'infringements');
            var othOffenderInfringements = this.resetForm(this.otherOffenderForm, 'infringements');

            for (let i = 0; i < allOffenders.length; i++) {
                var offenderUenUin = allOffenders.at(i).get("offenderUenUin").value;
                if (offenderUenUin == uenUin) {
                    toCallBackend = false;
                    this.offenderName = allOffenders.at(i).get("offenderName").value;
                    this.offenderLicenceId = allOffenders.at(i).get("licenceId").value;
                    currentOffenderInfringements.push(
                        this.ceCaseService.populateOffenceFormGroup(allOffenders.at(i).value, null)
                    );
                } else {
                    othOffenderInfringements.push(
                        this.ceCaseService.populateOffenceFormGroup(allOffenders.at(i).value, null)
                    );
                }
            }
        }

        return toCallBackend;
    }

    showHideDetails(rowIndex, outcomes): boolean {
        var infringements = this.ceCaseService.getFormArray(this.currentOffenderForm, 'infringements');
        var infringement = infringements.at(rowIndex);
        var recommendation = infringement.get('recommendation').get('recommendation');

        if (recommendation.value) {
            var outcomeKey = recommendation.value['key'];

            return outcomes.includes(outcomeKey);
        }
    }

    resetForm(form: FormGroup, field: string): FormArray {
        var infringements = this.ceCaseService.getFormArray(form, field);
        infringements.reset();

        return infringements;
    }

    isFormValid() {
        return this.offenderUenUin != null && this.offenderUenUin != '' && this.offenderName != null && this.offenderName != '' && this.currentOffenderForm.get('infringements').valid;
    }

    directoryDialog: MatDialogRef<CeDirectoryListDialogComponent>;
    outcomeChanged(selectedOption, data) {
        if (selectedOption == cnst.ceOutcome.CE_OUTCOME_TAG_IP) {
            this.directoryDialog = this.dialog.open(CeDirectoryListDialogComponent, {
                data: {
                    title: "Select IP",
                    isIp: true,
                    internalItemCaseNo: []
                }, panelClass: 'full-screen-modal',
            });
            this.directoryDialog.afterClosed().subscribe(result => {
                if (result) {
                    data.get('recommendation').get('taggedIpCaseNo').setValue(result.caseNo);
                } else {
                    data.get('recommendation').get('recommendation').setValue(null);
                }
            });
        }
    }

    caseTaskLetterChanged(event) {
        this.ceCaseService.onCeLetterChanged(event, cnst.DocumentTypes.CE_DOC_OTHERS, this.currentOffenderForm, this.selection, 'recommendation');
        this.ceLetter.nativeElement.value = null;
    }

}