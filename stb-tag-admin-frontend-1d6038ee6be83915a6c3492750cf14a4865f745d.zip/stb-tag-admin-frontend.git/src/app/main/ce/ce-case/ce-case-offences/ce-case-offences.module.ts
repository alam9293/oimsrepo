import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/common/modules/shared.module';

import { CeDirectoryListDialogComponent } from '../../ce-directory/ce-directory-list.component';
import { CeCaseOffencesComponent } from './ce-case-offences.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule,
        MatDatepickerModule,
        MatSidenavModule,
        MatMenuModule,
        MatCheckboxModule,
        SharedModule,

    ],
    declarations: [CeCaseOffencesComponent],
    exports: [CeCaseOffencesComponent],
    entryComponents: [CeDirectoryListDialogComponent],
})
export class CeCaseOffencesModule { }
