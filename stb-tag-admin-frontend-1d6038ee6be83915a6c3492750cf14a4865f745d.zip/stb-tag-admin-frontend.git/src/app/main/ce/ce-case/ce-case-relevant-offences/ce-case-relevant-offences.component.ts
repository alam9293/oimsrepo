import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import { CommonService, AuthenticationService } from 'src/app/common/services';

import * as cnst from '../../../../common/constants';
import { CeCaseService } from '../ce-case.service';

@Component({
    selector: 'ce-case-relevant-offences',
    templateUrl: './ce-case-relevant-offences.component.html',
    styleUrls: ['./ce-case-relevant-offences.component.scss']
})
export class CeCaseRelevantOffencesComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) relevantOffencePaginator: MatPaginator;

    relevantOffenceDataSource = [];
    relevantOffenceColumns = ['offenderName', 'caseNo', 'caseStatus', 'offenceProvision', 'recommendation', 'outcome', 'outcomeDate'];

    cnst = cnst;
    spans = [];

    constructor(
        public commonService: CommonService,
        public ceCaseService: CeCaseService,
        public authenticationService: AuthenticationService) {
    }

    ngOnInit() {

    }

    reload(caseOffences) {
        if (caseOffences) {
            this.ceCaseService.reloadRelevantInfringements(caseOffences).subscribe(data => {
                if (data.othInfringements) {
                    this.relevantOffenceDataSource = data.othInfringements;
                    this.spans = this.commonService.spanRow('offenderName', d => d.offenderName, this.relevantOffenceDataSource);
                } else {
                    this.relevantOffenceDataSource = [];
                }
            });
        }
    }

    loadDetails(data) {
        if (data) {
            this.relevantOffenceDataSource = data;
            this.spans = this.commonService.spanRow('offenderName', d => d.offenderName, this.relevantOffenceDataSource);
        }
    }

    hasPermission(code) {
        return this.authenticationService.hasPermission(code);
    }

}

