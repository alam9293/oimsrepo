import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
    MatMenuModule,
    MatCheckboxModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';

import { CeCaseRelevantOffencesComponent } from './ce-case-relevant-offences.component';
import { SharedModule } from 'src/app/common/modules/shared.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule,
        MatDatepickerModule,
        MatSidenavModule,
        MatMenuModule,
        MatCheckboxModule,
        SharedModule
    ],
    declarations: [CeCaseRelevantOffencesComponent,],
    exports: [CeCaseRelevantOffencesComponent],
    entryComponents: [],
})
export class CeCaseRelevantOffencesModule { }
