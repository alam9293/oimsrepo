import { SelectionModel } from '@angular/cdk/collections';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatMenuTrigger, MatTable } from '@angular/material';
import { DateUtil, FileUtil } from 'src/app/common/helper';
import { CommonService } from 'src/app/common/services';
import { WorkflowService } from 'src/app/common/services/workflow.service';

import * as cnst from '../../../../common/constants';
import { CeDirectoryListDialogComponent } from '../../ce-directory/ce-directory-list.component';
import { CeCaseService } from '../ce-case.service';

@Component({
    selector: 'ce-case-task-dialog',
    templateUrl: './ce-case-task-dialog.component.html',
    styleUrls: ['./ce-case-task-dialog.component.scss']
})
export class CeCaseTaskDialogComponent implements OnInit {

    @ViewChild(MatMenuTrigger) clickLetterMenuTrigger: MatMenuTrigger;
    @ViewChild('infringementMatTable') infringementMatTable: MatTable<any>;
    @ViewChild('attachMatTable') attachMatTable: MatTable<any>;
    @ViewChild('ceLetter') ceLetter: ElementRef;
    @ViewChild('fileInput1') fileInput1: ElementRef;

    cnst = cnst;

    // dropdown
    offenceProvisions: any;
    offenceProvisionMap = new Map<any, any>();
    recommendations: any;
    supporters: any;
    approvers: any;
    appealResults: any;
    docTypes: any;
    isAllHidden: boolean = true;

    // form
    caseTaskLabel: string;
    tabLabel: string;
    fieldGroupForLetter: string;
    defaultSupporterId: any;
    defaultApproverId: any;

    selection = new SelectionModel<any>(true, []);

    selectedFile: File;
    files: SupportingDocument[];

    formData: any = { currentWorkflow: { workflowId: null } };
    offenceColumns = [];
    spans = [];

    fromCreateCaseTaskButton: boolean = true;
    todayDate = DateUtil.getNow();

    docColumns = ['docName', 'docType', 'docDescription', 'createdDate', 'fileSize', 'action'];

    ceTaskForm = this.fb.group({
        infringements: this.fb.array([]),
        currentWorkflow: this.fb.group({
            workflowId: [],
            caseTaskStatus: [],
            workflowAssessment: [],
            internalRemarks: [],
            assigneeId: [],
            assigneeName: [],
            sla: [],
            appOrWkflwType: [],
            appOrWkflwTypeCode: [],

            approverId: [],
            supporterId: [],
            workflowFiles: this.fb.array([]),
            deletedWorkflowFiles: this.fb.array([]),

            isAssignee: [false],
            isFinalApproval: [false],
            isInGroup: [false],
            isFromCreateCaseTask: [],
        }),
        assessment: [],
        mitigatingFactors: [],
        aggravatingFactors: [],
    });

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        private fileUtil: FileUtil,
        public dialogRef: MatDialogRef<CeCaseTaskDialogComponent>,
        private dialog: MatDialog,
        private fb: FormBuilder,
        public commonService: CommonService,
        public ceCaseService: CeCaseService,
        private workflowService: WorkflowService) { }

    ngOnInit() {
        this.fromCreateCaseTaskButton = this.data.fromCreateCaseTaskButton;
        this.offenceProvisions = this.data.offenceProvisions;
        this.offenceProvisionMap = this.data.offenceProvisionMap;
        this.appealResults = this.data.appealResults;
        this.filterRecommendationOptions(this.data.appOrWkflwTypeCode);

        setTimeout(() => {
            this.commonService.getTypesByCategoryCode(cnst.TypeCategories.CE_CASE_DOC).subscribe(data => {
                this.docTypes = data;
            })
        });

        if (this.data.appOrWkflwTypeCode) {
            var labels = this.ceCaseService.populateCeTaskLabel(this.data.appOrWkflwTypeCode);
            if (labels) {
                this.caseTaskLabel = labels.caseTaskLabel;
                this.tabLabel = labels.tabLabel;
                this.fieldGroupForLetter = labels.fieldGroupForLetter;
                this.offenceColumns = labels.offenceColumns;
            }

            setTimeout(() => {

                var form = this.data.form;
                if (form) {
                    var formVal = form.value;

                    this.ceCaseService.loadcaseTask(formVal, formVal.taTgType).subscribe(result => {
                        this.formData = result;
                        this.patchValueToForm(result);

                        if (this.fromCreateCaseTaskButton) {
                            this.workflowService.getCeWorkflowConfigByType(this.data.appOrWkflwTypeCode).subscribe(workflow => {
                                workflow.forEach(element => {
                                    var taskFrom = this.ceTaskForm.get('currentWorkflow');
                                    if (element.startStatusCode == cnst.STAT_WKFLW.CE_WKFLW_PEND_SUPP) {
                                        this.supporters = element;
                                        this.defaultSupporterId = element.defaultAssignee;
                                        this.setDefaultAssignee();
                                        if (result.currentWorkflow.workflowId != null) {
                                            taskFrom.get('supporterId').setValue(result.currentWorkflow.supporterId);
                                        } else {
                                            taskFrom.get('supporterId').setValue(element.defaultAssignee);
                                        }
                                    } else if (element.startStatusCode == cnst.STAT_WKFLW.CE_WKFLW_PEND_APPR) {
                                        this.approvers = element;
                                        this.defaultApproverId = element.defaultAssignee;
                                        this.setDefaultAssignee();
                                        if (result.currentWorkflow.workflowId != null) {
                                            taskFrom.get('approverId').setValue(result.currentWorkflow.approverId);
                                        } else {
                                            taskFrom.get('approverId').setValue(element.defaultAssignee);
                                        }
                                    }
                                });

                                // if current task is MTI Appeal
                                // default support Id will be empty and approver will be deyna(TA)/Choon Kiat(TG) which is default supporter set in system parameter table
                                if (result.currentWorkflow.workflowId == null) {
                                    var taskFrom = this.ceTaskForm.get('currentWorkflow');
                                    var workflowTypeCode = taskFrom.get('appOrWkflwTypeCode').value;
                                    if (workflowTypeCode == cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_APPEAL || workflowTypeCode == cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_APPEAL) {
                                        taskFrom.get('supporterId').setValue(null);
                                        taskFrom.get('approverId').setValue(this.defaultSupporterId);
                                    }
                                }

                                // manually trigger value changes so that the system will set default assignee based on all selected outcome
                                this.ceTaskForm.get('infringements').updateValueAndValidity();

                            });
                        }

                    });
                }
            });
        }
    }

    filterRecommendationOptions(appOrWkflwTypeCode) {
        var excludedOptions = [cnst.ceOutcome.CE_OUTCOME_OPEN_IP, cnst.ceOutcome.CE_OUTCOME_TAG_IP];
        switch (appOrWkflwTypeCode) {
            case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
            case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
                this.recommendations = this.data.recommendations;
                break;
            case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_DECISION:
            case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_DECISION:
                this.recommendations = this.data.recommendations.filter(value => !excludedOptions.includes(value.key));
                break;
            case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_APPEAL:
            case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_APPEAL:
                this.recommendations = this.data.recommendations.filter(value => !excludedOptions.includes(value.key));
                break;
        }

    }

    saveCase(action) {
        var valid = true;
        if (action == 'submit') {

            var taskFrom = this.ceTaskForm.get('currentWorkflow');
            var workflowTypeCode = taskFrom.get('appOrWkflwTypeCode').value;
            if (workflowTypeCode == cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND || workflowTypeCode == cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND) {
                var isSingleApproval = this.validateApprovalLevel();
                if (isSingleApproval && taskFrom.get('supporterId').value && taskFrom.get('approverId').value) {
                    valid = false;
                    this.commonService.popSnackbar('Only 1 approval level is allowed.', 'error-snackbar');
                }
            }

            if (valid && taskFrom.get('supporterId').value == taskFrom.get('approverId').value) {
                valid = false;
                this.commonService.popSnackbar('Case Support and Case Approval cannot be the same officer.', 'error-snackbar');
            }
        }

        if (valid) {
            this.patchForm();
            this.ceCaseService.saveCase(this.formData, action).subscribe(
                data => {
                    this.ceCaseService.createCeTask(data, action).subscribe();
                    this.ceCaseService.loadCase(data.id, data.taTgType).subscribe(
                        data => {
                            this.commonService.popSnackbar(null, 'success-snackbar');
                            this.dialogRef.close(data);
                        });
                });
        }

    }

    patchForm() {
        this.ceTaskForm.get('currentWorkflow').get('isFromCreateCaseTask').setValue(true);
        for (const field in this.ceTaskForm.controls) {
            this.formData[field] = this.ceTaskForm.get(field).value;
        }
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.ceTaskForm.get('infringements').value.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.ceTaskForm.get('infringements').value.forEach(row => this.selection.select(row));
    }

    showHideDetails(rowIndex, outcomes, field, childField): boolean {
        var infringements = this.ceCaseService.getFormArray(this.ceTaskForm, 'infringements');
        var infringement = infringements.at(rowIndex);
        var fieldCtrl = infringement.get(field).get(childField);

        if (fieldCtrl.value) {
            var outcomeKey = fieldCtrl.value['key'];
            return outcomes.includes(outcomeKey);
        }
    }

    resetForm(form: FormGroup, field: string): FormArray {
        var infringements = this.ceCaseService.getFormArray(form, field);
        infringements.reset();

        return infringements;
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                var workflowFiles = this.ceTaskForm.get('currentWorkflow').get('workflowFiles') as FormArray;
                workflowFiles.push(
                    this.ceCaseService.populateAttachmentFormGroup(data)
                );
                this.renderAttachMatTable();
            });
        }
        this.fileInput1.nativeElement.value = null;
    }

    validateSelected() {
        if (this.selection.selected.length < 1) {
            this.commonService.popSnackbar('Please select at least 1 record', 'error-snackbar');
            this.clickLetterMenuTrigger.closeMenu();
        }
    }

    deleteAttachment(rowIndex) {
        var currentWorkflow = this.ceTaskForm.get('currentWorkflow') as FormGroup;
        var workflowFiles = this.ceCaseService.getFormArray(currentWorkflow, 'workflowFiles');
        var workflowFile = workflowFiles.at(rowIndex);

        var deletedWorkflowFiles = this.ceCaseService.getFormArray(currentWorkflow, 'deletedWorkflowFiles');
        deletedWorkflowFiles.push(workflowFile);

        workflowFiles.removeAt(rowIndex);
        this.renderAttachMatTable();
    }

    patchValueToForm(formData) {
        for (const field in this.ceTaskForm.controls) {
            if (field == "infringements") {
                if (formData[field] != null) {
                    var infringements = this.ceTaskForm.get(field) as FormArray;
                    formData[field].forEach(element => {
                        var offence = this.ceCaseService.populateOffenceFormGroup(element, this.data.appOrWkflwTypeCode);
                        infringements.push(offence);
                    });
                    this.infringementMatTable.renderRows();
                }
            } else if (field == "currentWorkflow") {
                if (formData[field] != null) {
                    var childCtrl = this.ceTaskForm.get(field)['controls'];
                    for (const childField in childCtrl) {
                        if (childField == 'workflowFiles') {
                            if (formData[field][childField] != null) {
                                var workflowFiles = this.ceTaskForm.get(field).get(childField) as FormArray;
                                formData[field][childField].forEach(element => {
                                    workflowFiles.push(this.ceCaseService.populateAttachmentFormGroup(element));
                                });
                                this.renderAttachMatTable();
                            }
                        } else {
                            if (formData[field][childField] != null) {
                                this.ceTaskForm.get(field).get(childField).setValue(formData[field][childField]);
                            }
                        }
                    }
                }
            } else {
                this.ceTaskForm.get(field).setValue(formData[field]);
            }
        }

        // check whether all infringements are hidden
        // if no, set isAllHidden to false so that Save and Forward For Approval button will be disabled
        var infringements = this.ceCaseService.getFormArray(this.ceTaskForm, 'infringements');
        for (let control of infringements.controls) {
            var isHide = this.fromCreateCaseTaskButton ? this.hideCompletedInfringement(control, this.fieldGroupForLetter) : !this.isBelongsToCeCaseTask(control, this.fieldGroupForLetter);
            if (!isHide) {
                this.isAllHidden = false;
            }
        }

        this.spans = this.commonService.spanRow('offenderName', d => d.offenderName, this.ceTaskForm.get("infringements").value);
    }

    isRecommendationTask() {
        var workflowType = this.formData.currentWorkflow.appOrWkflwTypeCode;
        return workflowType == cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND || workflowType == cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND;
    }

    caseTaskLetterChanged(event) {
        this.ceCaseService.onCeLetterChanged(event, cnst.DocumentTypes.CE_DOC_OTHERS, this.ceTaskForm, this.selection, this.fieldGroupForLetter);
        this.ceLetter.nativeElement.value = null;
    }

    isBelongsToCeCaseTask(row, fieldName) {
        if (row.value['isCompleted']) {
            return false;
        } else {
            var parentField = row.value[fieldName];
            var currentWorkflow = this.ceTaskForm.get('currentWorkflow');
            return parentField['workflowId'] != null && currentWorkflow.get('workflowId').value != null && parentField['workflowId'] == currentWorkflow.get('workflowId').value;
        }
    }

    hideCompletedInfringement(row, fieldName) {

        var isCompleted = row.value['isCompleted'];
        var completeOutcomes = [
            cnst.ceOutcome.CE_OUTCOME_NOD,
            cnst.ceOutcome.CE_OUTCOME_NFA,
            cnst.ceOutcome.CE_OUTCOME_CAUTION,
            cnst.ceOutcome.CE_OUTCOME_CIRCULAR,
            cnst.ceOutcome.CE_OUTCOME_COUNSEL,
            cnst.ceOutcome.CE_OUTCOME_TAG_IP,
            cnst.ceOutcome.CE_OUTCOME_OPEN_IP
        ];

        if (row.value['isConcluded'] && fieldName != 'rescind') {
            return true;
        }

        // if recommendation/rescind, show all infringements
        if (fieldName == 'recommendation' || fieldName == 'rescind') {
            return false;
        }

        // for impose decision, 
        else if (fieldName == 'decision') {

            // do not show when the recommendation is direct outcome
            var recomm = row.value['recommendation']['recommendation'];
            if (recomm != null && completeOutcomes.includes(recomm.key)) {
                return true;
            }

            // if infringement is completed, show if this infringement has decision
            if (isCompleted) {
                var decision = row.value['decision']['decision'];
                if (decision != null) {
                    return false;
                }
            }
        }

        // for MTI Appeal
        else if (fieldName == 'result') {
            // if infringement is completed, show if this infringement has appeal result
            if (isCompleted) {
                var result = row.value['result']['newDecision'];
                if (result != null) {
                    return false;
                }
            }
        }

        return isCompleted;
    }

    disableDecisionOption(data, recomm) {
        if (data.get("outcome").value != null) {
            var excludedDecisions = [cnst.ceOutcome.CE_OUTCOME_KIV, cnst.ceOutcome.CE_OUTCOME_NOD, cnst.ceOutcome.CE_OUTCOME_NFA, cnst.ceOutcome.CE_OUTCOME_CAUTION, cnst.ceOutcome.CE_OUTCOME_CIRCULAR, cnst.ceOutcome.CE_OUTCOME_COUNSEL];
            switch (data.get("outcome").value.key) {
                case cnst.ceOutcome.CE_OUTCOME_REVOKE:
                    excludedDecisions.concat([cnst.ceOutcome.CE_OUTCOME_AFP, cnst.ceOutcome.CE_OUTCOME_SUSPEND]);
                    return excludedDecisions.includes(recomm.key);
                case cnst.ceOutcome.CE_OUTCOME_SUSPEND:
                    excludedDecisions.concat([cnst.ceOutcome.CE_OUTCOME_AFP]);
                    return excludedDecisions.includes(recomm.key);
                case cnst.ceOutcome.CE_OUTCOME_AFP:
                    return excludedDecisions.includes(recomm.key);
                case cnst.ceOutcome.CE_OUTCOME_TAG_IP:
                case cnst.ceOutcome.CE_OUTCOME_OPEN_IP:
                    return true;
            }
        }

        return false;
    }

    isIpRelated(data) {
        var outcome = data.get("outcome").value.key;
        return outcome == cnst.ceOutcome.CE_OUTCOME_TAG_IP || outcome == cnst.ceOutcome.CE_OUTCOME_OPEN_IP;
    }

    directoryDialog: MatDialogRef<CeDirectoryListDialogComponent>;
    outcomeChanged(selectedOption, data, parentField) {
        if (selectedOption == cnst.ceOutcome.CE_OUTCOME_TAG_IP) {
            this.directoryDialog = this.dialog.open(CeDirectoryListDialogComponent, {
                data: {
                    title: "Select IP",
                    isIp: true,
                    internalItemCaseNo: []
                }, panelClass: 'full-screen-modal',
            });
            this.directoryDialog.afterClosed().subscribe(result => {
                if (result) {
                    data.get(parentField).get('taggedIpCaseNo').setValue(result.caseNo);
                } else {
                    data.get(parentField).get(parentField).setValue(null);
                }
            });
        }
    }

    isFormValid() {
        var infringements = this.ceCaseService.getFormArray(this.ceTaskForm, 'infringements');

        var isValid = true;
        for (let control of infringements.controls) {
            if (!control.value.isConcluded && !control.value.isCompleted) {
                isValid = control.valid;

                if (!isValid) {
                    return isValid;
                }
            }
        }

        return isValid;
    }

    disableSaveButton() {
        return this.isAllHidden;
    }

    disableForwardButton() {
        return !this.isFormValid() || this.isAllHidden || this.noAssignee();
    }

    noAssignee() {
        var currWorkflow = this.ceTaskForm.get('currentWorkflow');
        return (currWorkflow.get('supporterId').value == null || currWorkflow.get('supporterId').value == '') && (currWorkflow.get('approverId').value == null || currWorkflow.get('approverId').value == '');
    }

    setDefaultAssignee() {
        var taskFrom = this.ceTaskForm.get('currentWorkflow');
        var workflowTypeCode = taskFrom.get('appOrWkflwTypeCode').value;

        // to check whether all infringement outcome is NOD/NFA/Caution/Counsel/IP related
        // if yes, then default support Id will be empty and approver will be deyna(TA)/Choon Kiat(TG) which is default supporter set in system parameter table
        // if no, then default support Id will be deyna/choon kiat(default supporter) and approver will be kenneth(default approver)
        // this logic only applicable for recommendation
        if (workflowTypeCode == cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND || workflowTypeCode == cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND) {
            this.ceTaskForm.get('infringements').valueChanges.subscribe(val => {
                var isSingleApproval = this.validateApprovalLevel();
                if (isSingleApproval) {
                    taskFrom.get('supporterId').setValue(null);
                    taskFrom.get('approverId').setValue(this.defaultSupporterId);
                } else {
                    taskFrom.get('supporterId').setValue(this.defaultSupporterId);
                    taskFrom.get('approverId').setValue(this.defaultApproverId);
                }
            });
        }
    }

    // to check whether the submission is single approval
    validateApprovalLevel(): boolean {
        var isSingleApproval = true;
        this.ceTaskForm.get('infringements').value.forEach(element => {
            var selectedOutcome;
            var singleApprovalOutcome = [cnst.ceOutcome.CE_OUTCOME_NOD, cnst.ceOutcome.CE_OUTCOME_NFA, cnst.ceOutcome.CE_OUTCOME_CAUTION, cnst.ceOutcome.CE_OUTCOME_CIRCULAR, cnst.ceOutcome.CE_OUTCOME_COUNSEL, cnst.ceOutcome.CE_OUTCOME_OPEN_IP, cnst.ceOutcome.CE_OUTCOME_TAG_IP, cnst.ceOutcome.CE_OUTCOME_CONDITION];
            switch (this.data.appOrWkflwTypeCode) {
                case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
                case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
                    selectedOutcome = element.recommendation.recommendation;
                    break;
                case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_DECISION:
                case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_DECISION:
                    selectedOutcome = element.decision.decision;
                    break;
                case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_APPEAL:
                case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_APPEAL:
                    selectedOutcome = element.result.newDecision;
                    break;
            }

            if (selectedOutcome == null || !singleApprovalOutcome.includes(selectedOutcome.key)) {
                isSingleApproval = false;
            }
        });

        return isSingleApproval;
    }

    get attachments() {
        return this.ceTaskForm.get('currentWorkflow').get('workflowFiles') as FormArray;
    }

    renderAttachMatTable() {
        if (this.attachMatTable) {
            this.attachMatTable.renderRows();
        }
    }
}

export interface SupportingDocument {
    fileDescription: String;
    file: File;
}
