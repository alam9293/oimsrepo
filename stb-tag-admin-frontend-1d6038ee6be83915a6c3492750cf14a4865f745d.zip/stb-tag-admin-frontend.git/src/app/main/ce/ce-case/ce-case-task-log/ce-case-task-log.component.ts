import { Component, Inject, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormArray, FormBuilder } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef, MatTable } from '@angular/material';
import { FileUtil } from 'src/app/common/helper';

import * as cnst from '../../../../common/constants';
import { CeCaseService } from '../ce-case.service';

@Component({
    selector: 'ce-case-task-log',
    templateUrl: './ce-case-task-log.component.html',
    styleUrls: ['./ce-case-task-log.component.scss']
})
export class CeCaseTaskLogComponent implements OnInit {

    @Input() caseId: number;
    @Input() taTgType: string;

    caseTaskLogs = [];
    taskSummaryColumns = ['approvedDate', 'caseTask', 'caseTaskStatus', 'forOffence', 'taskDetails', 'letterIssuance'];
    cnst = cnst;

    constructor(
        public fileUtil: FileUtil,
        private dialog: MatDialog,
        public ceCaseService: CeCaseService) {
    }

    ngOnInit() {
        if (this.caseId) {
            this.loadCaseTaskLog();
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.caseId) {
            this.loadCaseTaskLog();
        } else {
            this.caseTaskLogs = [];
        }
    }

    loadCaseTaskLog() {
        setTimeout(() => {
            if (this.caseId && this.taTgType) {
                this.ceCaseService.loadCaseTaskLog(this.caseId, this.taTgType).subscribe(data => {
                    this.caseTaskLogs = data;
                });
            }
        });
    }

    viewCaseTaskLog(caseTaskType, workflowId) {
        let dialogCaseTaskLogDetails = this.dialog.open(DialogCaseTaskLogDetails, {
            data: {
                wkflwTypeCode: caseTaskType,
                workflowId: workflowId,
                taTgType: this.taTgType,
                caseId: this.caseId
            },
            panelClass: 'full-screen-modal',
        });

        dialogCaseTaskLogDetails.afterClosed().subscribe();
    }

}

@Component({
    selector: 'dialog-case-task-log-detail',
    styleUrls: ['./ce-case-task-log.component.scss'],
    templateUrl: 'ce-case-task-log-detail-dialog.html',
})
export class DialogCaseTaskLogDetails implements OnInit {

    @ViewChild(MatTable) _matTables;

    caseTaskLabel: string;
    tabLabel: string;
    fieldGroupForLetter: string;
    offenceColumns = [];
    cnst = cnst;

    formData: any = { currentWorkflow: { workflowId: null } };

    ceTaskForm = this.fb.group({
        infringements: this.fb.array([]),
        currentWorkflow: this.fb.group({
            workflowId: [],
            caseTaskStatus: [],
            workflowAssessment: [],
            internalRemarks: [],
            assigneeId: [],
            assigneeName: [],
            sla: [],
            appOrWkflwType: [],
            appOrWkflwTypeCode: [],

            approverId: [],
            supporterId: [],
            workflowFiles: this.fb.array([]),
            deletedWorkflowFiles: this.fb.array([]),

            isAssignee: [false],
            isFinalApproval: [false],
            isInGroup: [false],
        }),
        assessment: [],
        mitigatingFactors: [],
        aggravatingFactors: [],
    });

    docDataSource = [];
    docColumns = ['docName', 'docType', 'docDescription', 'createdDate', 'fileSize'];

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<DialogCaseTaskLogDetails>,
        private ceCaseService: CeCaseService,
        public fileUtil: FileUtil,
        private fb: FormBuilder,
    ) { }

    ngOnInit() {
        if (this.data.wkflwTypeCode) {
            var labels = this.ceCaseService.populateCeTaskLabel(this.data.wkflwTypeCode);
            if (labels) {
                this.caseTaskLabel = labels.caseTaskLabel;
                this.tabLabel = labels.tabLabel;
                this.fieldGroupForLetter = labels.fieldGroupForLetter;
                this.offenceColumns = labels.offenceColumns;
            }

            setTimeout(() => {
                this.loadCaseTaskLogDetail(this.data);
            });

        }

    }

    loadCaseTaskLogDetail(data) {
        this.ceCaseService.loadCaseTaskLogDetail(data.workflowId, data.wkflwTypeCode, data.taTgType, data.caseId).subscribe(data => {
            this.formData = data;
            this.docDataSource = data['currentWorkflow']['workflowFiles'];
            this.patchValueToForm(data);
        });
    }

    patchValueToForm(formData) {
        for (const field in this.ceTaskForm.controls) {
            if (field == "infringements") {
                if (formData[field] != null) {
                    var infringements = this.ceTaskForm.get(field) as FormArray;
                    formData[field].forEach(element => {
                        infringements.push(this.ceCaseService.populateOffenceFormGroup(element, null));
                    });
                    this._matTables.renderRows();
                }
            } else if (field == "currentWorkflow") {
                if (formData[field] != null) {
                    var childCtrl = this.ceTaskForm.get(field)['controls'];
                    for (const childField in childCtrl) {

                        if (childField == 'workflowFiles') {
                            if (formData[field][childField] != null) {
                                var workflowFiles = this.ceTaskForm.get(field).get(childField) as FormArray;
                                formData[field][childField].forEach(element => {
                                    workflowFiles.push(this.ceCaseService.populateAttachmentFormGroup(element));
                                });
                            }
                        } else {
                            if (formData[field][childField] != null) {
                                this.ceTaskForm.get(field).get(childField).setValue(formData[field][childField]);
                            }
                        }
                    }
                }
            } else {
                this.ceTaskForm.get(field).setValue(formData[field]);
            }
        }

        this.ceTaskForm.disable();
    }

    showHideDetails(rowIndex, outcomes, field, childField): boolean {
        var infringements = this.ceCaseService.getFormArray(this.ceTaskForm, 'infringements');
        var infringement = infringements.at(rowIndex);
        var fieldCtrl = infringement.get(field).get(childField);

        if (fieldCtrl.value) {
            var outcomeKey = fieldCtrl.value['key'];
            return outcomes.includes(outcomeKey);
        }
    }

}
