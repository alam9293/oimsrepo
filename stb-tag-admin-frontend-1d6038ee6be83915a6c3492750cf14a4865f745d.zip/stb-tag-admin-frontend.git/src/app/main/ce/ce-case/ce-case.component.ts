import { Component, OnInit, ViewChild, SimpleChanges, Input } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { FileUtil, WorkflowHelper } from 'src/app/common/helper';
import { ConfirmationDialogComponent } from 'src/app/common/modules/confirmation-dialog/confirmation-dialog.component';
import { AuthenticationService, CommonService } from 'src/app/common/services';

import * as cnst from '../../../common/constants';
import { CeDirectoryListDialogComponent } from '../ce-directory/ce-directory-list.component';
import { CeCaseDetailsComponent } from './ce-case-details/ce-case-details.component';
import { CeCaseService } from './ce-case.service';
import { CeCaseTaskLogComponent } from './ce-case-task-log/ce-case-task-log.component';

@Component({
    selector: 'ce-case',
    templateUrl: './ce-case.component.html',
    styleUrls: ['./ce-case.component.scss']
})
export class CeCaseComponent implements OnInit {

    @ViewChild(CeCaseDetailsComponent) ceCaseDetailsComponent: CeCaseDetailsComponent;
    @ViewChild(CeCaseTaskLogComponent) caseTaskLogComp: CeCaseTaskLogComponent;
    @Input() caseId: any;
    @Input() taTgType: any;

    cnst = cnst;

    offenceSummaryColumns = ['offender', 'forOffence', 'taskDetails', 'letterIssuance'];
    docColumns = ['docName', 'docType', 'docDescription', 'createdDate', 'fileSize'];

    constructor(
        private dialog: MatDialog,
        private route: ActivatedRoute,
        private fb: FormBuilder,
        private commonService: CommonService,
        private workflowHelper: WorkflowHelper,
        public authService: AuthenticationService,
        public ceCaseService: CeCaseService,
        public fileUtil: FileUtil) { }

    ngOnInit() {
        this.ceCaseDetailsComponent.initForm();

        var caseForm = this.ceCaseDetailsComponent.caseForm;
        var caseId = +this.route.snapshot.paramMap.get('id');
        var taTgType = this.route.snapshot.paramMap.get('taTgType');
        if (caseId) {
            this.loadCase(caseId, taTgType, false);
        } else {
            if (this.authService.currentUserValue.department['key'] == cnst.department.DEPARTMENT_TG) {
                this.ceCaseDetailsComponent.ceCaseOffencesComponent.taTgType = cnst.caseType.TG;
                caseForm.get('taTgType').setValue(cnst.caseType.TG);
                caseForm.get('currentWorkflow').get('appOrWkflwTypeCode').setValue(cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND);
            } else {
                this.ceCaseDetailsComponent.ceCaseOffencesComponent.taTgType = cnst.caseType.TA;
                caseForm.get('taTgType').setValue(cnst.caseType.TA);
                caseForm.get('currentWorkflow').get('appOrWkflwTypeCode').setValue(cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND);
            }

            this.loadProvisions(caseForm.get('taTgType').value);
        }

        caseForm.get('taTgType').valueChanges.subscribe(val => {
            this.loadProvisions(val);
        });
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.caseId && this.taTgType) {
            this.loadCase(this.caseId, this.taTgType, true);
        }
    }

    loadProvisions(taTgType) {
        this.ceCaseService.getCeProvisions(taTgType).subscribe(data => {
            var offenceComponent = this.ceCaseDetailsComponent.ceCaseOffencesComponent;

            offenceComponent.offenceProvisions = data;
            data.forEach(u => {
                var chapters = [];
                chapters = offenceComponent.offenceProvisionMap.get(u.chapter.label);

                if (chapters) {
                    chapters.push(u);
                    offenceComponent.offenceProvisionMap.set(u.chapter.label, chapters);
                } else {
                    offenceComponent.offenceProvisionMap.set(u.chapter.label, [u]);
                }
            })
        });
    }

    loadCase(caseId: number, taTgType, fromIp) {
        if (caseId && taTgType) {
            this.ceCaseService.loadCase(caseId, taTgType).subscribe(
                data => {
                    this.patchDtoToForm(data, fromIp);
                    this.loadProvisions(data.taTgType);
                }
            );
        }
    }

    saveCase(action) {
        var caseForm = this.combCaseFormValue();
        this.ceCaseService.saveCase(caseForm.value, action).subscribe(
            data => {
                this.ceCaseService.createCeTask(data, action).subscribe();
                this.loadCase(data.id, data.taTgType, false);
                this.commonService.popSnackbar(null, 'success-snackbar');
            },
            error => {
            }
        );
    }

    patchDtoToForm(data, fromIp) {
        this.ceCaseDetailsComponent.loadCase(data, fromIp);
    }

    edit(ceTaskWorkflow) {
        this.openCeTaskDialog(ceTaskWorkflow.workflowId, ceTaskWorkflow.appOrWkflwTypeCode, false);
    }

    openCeTaskDialog(workflowId, appOrWkflwTypeCode, fromCreateCaseTaskButton) {
        this.ceCaseDetailsComponent.openCeTaskDialog(workflowId, appOrWkflwTypeCode, fromCreateCaseTaskButton);
    }

    showCaseTaskInfo() {
        return this.ceCase != null && this.ceCase.isPendingApproval && this.ceCase.taggedCaseNo == null;
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog(action, ceTaskWorkflow) {

        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                internalRemarks: true,
                externalRemarks: false,
                action: action,
                appType: ceTaskWorkflow.appOrWkflwTypeCode,
                supporterId: ceTaskWorkflow.supporterId,
                approverId: ceTaskWorkflow.approverId
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.ceCaseService.submitAction(result.params, ceTaskWorkflow.workflowId, action.name).subscribe(
                    data => {
                        this.loadCase(this.ceCase.id, this.ceCase.taTgType, false);
                        this.caseTaskLogComp.loadCaseTaskLog();
                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', this.ceCase.taTgType), 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    reAssign(ceTaskWorkflow) {
        this.workflowHelper.reAssignCEWorkflow(ceTaskWorkflow.caseTaskStatus.key, ceTaskWorkflow.workflowId, ceTaskWorkflow.appOrWkflwTypeCode).then(data => {
            if (data) {
                this.loadCase(this.ceCase.id, this.ceCase.taTgType, false);
            }
        })
    }

    get ceCase() {
        return this.ceCaseDetailsComponent.ceCase;
    }

    directoryDialog: MatDialogRef<CeDirectoryListDialogComponent>;
    tagToCase() {
        this.directoryDialog = this.dialog.open(CeDirectoryListDialogComponent, {
            data: {
                title: "Select Case",
                isIp: false,
                internalItemCaseNo: [this.ceCaseDetailsComponent.ceCase.caseNo],
            },
            panelClass: 'full-screen-modal',
        });
        this.directoryDialog.afterClosed().subscribe(result => {
            if (result.caseNo) {
                this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                    data: {
                        title: 'Tag to Case ID: ' + result.caseNo,
                        internalRemarks: false,
                        externalRemarks: false,
                    }
                });

                this.dialogRef.afterClosed().subscribe(confirm => {
                    if (confirm.decision) {
                        var caseForm = this.combCaseFormValue();
                        caseForm.get('taggedCaseNo').setValue(result.caseNo);
                        this.ceCaseService.tagCase(caseForm.value).subscribe(
                            data => {
                                this.loadCase(data.id, data.taTgType, false);
                                this.commonService.popSnackbar(null, 'success-snackbar');
                            },
                            error => {
                            }
                        );
                    }
                });
            }
        });
    }

    untagCase() {

        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Untag Case from Case ID: ' + this.ceCase.taggedCaseNo,
                internalRemarks: false,
                externalRemarks: false,
            }
        });

        this.dialogRef.afterClosed().subscribe(confirm => {
            if (confirm.decision) {
                var caseForm = this.combCaseFormValue();
                this.ceCaseService.untagCase(caseForm.value).subscribe(
                    data => {
                        this.loadCase(data.id, data.taTgType, false);
                        this.ceCaseDetailsComponent.enableForm();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                    }
                );
            }
        });
    }

    combCaseFormValue() {
        var caseForm = this.ceCaseDetailsComponent.caseForm;
        var appOrWkflwTypeCode = caseForm.get('currentWorkflow').get('appOrWkflwTypeCode');
        if (appOrWkflwTypeCode.value == null) {
            appOrWkflwTypeCode.setValue((this.ceCase.taTgType == cnst.caseType.TA) ? cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND : cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND);
        }
        caseForm.patchValue(this.ceCaseDetailsComponent.getFormData());

        return caseForm;
    }

    showTagButton() {
        return this.ceCase.id != null && this.ceCase.isNew && (!this.ceCase.isPendingApproval || (this.ceCase.isPendingApproval && this.ceCase.isRoutedBack)) && !this.ceCase.hasChildCase && this.ceCase.status.key != cnst.CeCaseStatus.CLOSED;
    }

    showUntagButton() {
        return this.ceCase.taggedCaseNo != null && !this.ceCase.isPendingApproval && this.ceCase.status.key != cnst.CeCaseStatus.CLOSED;
    }

    disableSaveButton() {
        return !this.ceCaseDetailsComponent.ceCaseComplainantComponent.complainantForm.valid || this.ceCaseDetailsComponent.buttonDisabled;
    }

    isTaType() {
        var caseForm = this.ceCaseDetailsComponent.caseForm;
        return caseForm.get('taTgType').value == cnst.caseType.TA;
    }
}
