import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
    MatCardModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';

import { CeCaseComponent } from './ce-case.component';
import { BackModule } from 'src/app/common/modules/back/back.module';
import { CeCaseDetailsModule } from './ce-case-details/ce-case-details.module';
import { CeCaseTaskLogModule } from './ce-case-task-log/ce-case-task-log.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule,
        MatDatepickerModule,
        MatSidenavModule,
        MatMenuModule,
        MatCheckboxModule,
        MatExpansionModule,
        BackModule,
        MatCardModule,

        CeCaseDetailsModule,
        CeCaseTaskLogModule,
    ],
    declarations: [CeCaseComponent],
    exports: [CeCaseComponent],
    entryComponents: [],
})
export class CeCaseModule { }
