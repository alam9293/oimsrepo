import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { DateUtil, FileUtil } from 'src/app/common/helper';

import * as cnst from '../../../common/constants';
import * as moment from 'moment';

@Injectable({
    providedIn: 'root'
})
export class CeCaseService {

    constructor(
        private http: HttpClient,
        private fb: FormBuilder,
        private fileUtil: FileUtil) { }

    loadOffenderDetails(uenUin: string, taTgType: string): Observable<any> {
        return this.http.get(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/' + taTgType.toLowerCase() + '/load-offender-details/' + uenUin);
    }

    getCeProvisions(taTgType: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.CE_PROVISION + '/view/dropdown/' + taTgType);
    }

    saveCase(formData: any, action: string): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/' + action, formData);
    }

    createCeTask(formData: any, action: string): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/' + action + '/create-ce-task', formData);
    }

    tagCase(formData: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/save/tag', formData);
    }

    untagCase(formData: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/save/untag', formData);
    }

    loadCase(caseId: number, taTgType: string): Observable<any> {
        return this.http.get(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/' + taTgType.toLowerCase() + '/' + caseId);
    }

    searchComplianceChecks(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/ta/search-compliance-checks', { params: searchDto });
    }

    loadcaseTask(formData: any, taTgType: string): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/' + taTgType.toLowerCase() + '/load-case-task', formData);
    }

    searchComplainant(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/search-complainant', { params: searchDto });
    }

    public submitAction(params: any, id: any, action: any) {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/' + action + '/' + id, params);
    }

    loadCaseTaskLog(caseId: number, taTgType: string): Observable<any> {
        return this.http.get(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/' + taTgType.toLowerCase() + '/load-case-task-log/' + caseId);
    }

    loadCaseTaskLogDetail(workflowId: number, workflowTypeCode: string, taTgType: string, caseId: number): Observable<any> {
        return this.http.get(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/' + taTgType.toLowerCase() + '/load-log-details/' + workflowTypeCode + '/' + workflowId + '/' + caseId);
    }

    reloadRelevantInfringements(formData: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.CE_CASE + '/view/' + formData.taTgType.toLowerCase() + '/relevant-infringements', formData);
    }

    getToolTipData(rowIndex, form, offenceProvision) {
        if (form != null) {
            var infringements = this.getFormArray(form, 'infringements');
            var infringement = infringements.at(rowIndex);
            offenceProvision = infringement.get('offenceProvision');

            if (offenceProvision.value) {
                return offenceProvision.value['description'];
            }
        }

        return offenceProvision.description;
    }

    initCaseForm() {
        return this.fb.group({
            id: [],
            caseNo: [],
            status: [],
            oic: [],
            createdDate: [],
            crmNo: [],
            taTgType: [],
            assessment: [],
            mitigatingFactors: [],
            aggravatingFactors: [],
            complainants: [],
            deletedComplainants: [],
            infringements: [],
            deletedInfringements: [],
            complianceChecks: [],
            deletedComplianceChecks: [],
            othAttachments: [],
            othDeletedAttachments: [],
            taggedCaseNo: [],

            workflows: [],
            currentWorkflow: this.fb.group({
                workflowId: [],
                caseTaskStatus: [],
                workflowAssessment: [],
                internalRemarks: [],
                assigneeId: [],
                assigneeName: [],
                sla: [],
                appOrWkflwType: [],
                appOrWkflwTypeCode: [],

                approverId: [],
                supporterId: [],
                workflowFiles: [],
                deletedWorkflowFiles: [],

                isAssignee: [false],
                isFinalApproval: [false],
                isInGroup: [false],
            }),
            isNew: [true],
            isOic: [],
            isPendingApproval: [],
        });
    }


    populateOffenceFormGroup(x, caseTaskType) {

        var recommendation = x ? x.recommendation : null;
        var decision = x ? x.decision : null;
        var result = x ? x.result : null;
        var rescind = x ? x.rescind : null;

        var offence = this.fb.group({
            offenderId: x ? x.offenderId : [],
            offenderUenUin: x ? x.offenderUenUin : [],
            offenderName: x ? x.offenderName : [],
            licenceId: x ? x.licenceId : [],
            infringementId: x ? x.infringementId : [],
            offenceDate: x ? x.offenceDate : null,
            offenceProvision: x ? [x.offenceProvision, Validators.required] : [null, Validators.required],
            recommendation: this.fb.group({
                recommendationId: recommendation ? recommendation.recommendationId : [],
                recommendation: recommendation ? recommendation.recommendation : [],
                taggedIpCaseNo: recommendation ? recommendation.taggedIpCaseNo : [],
                penaltyAmount: recommendation ? recommendation.penaltyAmount : [],
                penaltyStartDate: recommendation ? recommendation.penaltyStartDate : [],
                penaltyEndDate: recommendation ? recommendation.penaltyEndDate : [],
                toEmailLetter: recommendation ? recommendation.toEmailLetter : [false],
                letterIssuance: recommendation ? recommendation.letterIssuance : [],
                letterIssuanceDate: recommendation ? recommendation.letterIssuanceDate : [],
                workflowId: recommendation ? recommendation.workflowId : [],
                workflowStatus: recommendation ? recommendation.workflowStatus : [],
                deletedLetterIssuance: recommendation && recommendation.deletedLetterIssuance ? [recommendation.deletedLetterIssuance] : [],
                approvedDate: recommendation ? recommendation.approvedDate : [],
            }, {
                validator: this.outcomeValidator('recommendation', caseTaskType)
            }),
            decision: this.fb.group({
                decisionId: decision ? decision.decisionId : [],
                showCause: decision ? decision.showCause : [],
                showCauseDate: decision ? decision.showCauseDate : [],
                decision: decision ? decision.decision : [],
                taggedIpCaseNo: decision ? decision.taggedIpCaseNo : [],
                penaltyAmount: decision ? decision.penaltyAmount : [],
                penaltyStartDate: decision ? decision.penaltyStartDate : [],
                penaltyEndDate: decision ? decision.penaltyEndDate : [],
                toEmailLetter: decision ? decision.toEmailLetter : [false],
                letterIssuance: decision ? decision.letterIssuance : [],
                letterIssuanceDate: decision ? decision.letterIssuanceDate : [],
                workflowId: decision ? decision.workflowId : [],
                workflowStatus: decision ? decision.workflowStatus : [],
                deletedLetterIssuance: decision ? decision.deletedLetterIssuance : [],
                approvedDate: decision ? decision.approvedDate : [],
            }, {
                validator: this.outcomeValidator('decision', caseTaskType)
            }),
            result: this.fb.group({
                resultId: result ? result.resultId : [],
                result: result ? result.result : [],
                appealDate: result ? result.appealDate : [],
                appealRespondByDate: result ? result.appealRespondByDate : [],
                respondedDate: result ? result.respondedDate : [],
                newDecision: result ? result.newDecision : [],
                penaltyAmount: result ? result.penaltyAmount : [],
                penaltyStartDate: result ? result.penaltyStartDate : [],
                penaltyEndDate: result ? result.penaltyEndDate : [],
                toEmailLetter: result ? result.toEmailLetter : [false],
                letterIssuance: result ? result.letterIssuance : [],
                letterIssuanceDate: result ? result.letterIssuanceDate : [],
                workflowId: result ? result.workflowId : [],
                workflowStatus: result ? result.workflowStatus : [],
                deletedLetterIssuance: result ? result.deletedLetterIssuance : [],
                approvedDate: result ? result.approvedDate : [],
            }, {
                validator: [this.outcomeValidator('newDecision', caseTaskType), this.appealResultValidator()]
            }),
            rescind: this.fb.group({
                rescindId: rescind ? rescind.rescindId : [],
                toEmailLetter: rescind ? rescind.toEmailLetter : [false],
                letterIssuanceDate: rescind ? rescind.letterIssuanceDate : [],
                letterIssuance: rescind ? rescind.letterIssuance : [],
                workflowId: rescind ? rescind.workflowId : [],
                workflowStatus: rescind ? rescind.workflowStatus : [],
                deletedLetterIssuance: rescind ? rescind.deletedLetterIssuance : []
            }),
            hasApprovedPastRecommendation: x ? x.hasApprovedPastRecommendation : [false],
            workflowStatus: x ? x.workflowStatus : [],
            outcome: x ? x.outcome : [],
            finalOutcomeDetails: x ? x.finalOutcomeDetails : [],
            ipCaseId: x ? x.ipCaseId : [],
            isPendingApproval: x ? x.isPendingApproval : [false],
            caseNo: x ? x.caseNo : [],
            taggedCaseNo: x ? x.taggedCaseNo : [],
            taggedCaseId: x ? x.taggedCaseId : [],
            taggedCaseType: x ? x.taggedCaseType : [],
            isCompleted: x ? x.isCompleted : [false],
            isConcluded: x ? x.isConcluded : [false],
        });

        return offence;
    }

    populateAttachmentFormGroup(x) {
        return this.fb.group({
            id: x ? x.id : [],
            originalName: x ? x.originalName : [],
            description: x ? x.description : [],
            createdDate: x ? x.createdDate : [],
            createdBy: x ? x.createdBy : [],
            docType: x ? x.docType : [],
            documentTypeLabel: x ? x.documentTypeLabel : [],
            hash: x ? x.hash : [],
            readableFileSize: x ? x.readableFileSize : [],
        });
    }

    // field = outcome of recommendation / impose decision / appeal
    // newDecision is outcome of appeal
    outcomeValidator(field, caseTaskType) {
        return (control) => {
            var outcome = control.value[field];

            if (caseTaskType != null) {
                var recommendationTypes = [cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND, cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND];
                if (recommendationTypes.includes(caseTaskType) && field == 'recommendation' && outcome == null) {
                    return { outcomeRequired: true };
                }

                var decisionTypes = [cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_DECISION, cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_DECISION];
                if (decisionTypes.includes(caseTaskType) && field == 'decision' && outcome == null) {
                    return { outcomeRequired: true };
                }

                var appealTypes = [cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_APPEAL, cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_APPEAL];
                if (appealTypes.includes(caseTaskType) && field == 'newDecision' && outcome == null) {
                    return { outcomeRequired: true };
                }
            }

            // for appeal
            // if appeal result is Rejected / Acceded / No Appeal, outcome of appeal will be mandatory
            if (field == 'newDecision') {
                var result = control.value['result'];
                if (result != null && result.key != cnst.AppealResult.CE_APPEAL_RESULT_PEND && outcome == null) {
                    return { outcomeRequired: true };
                }
            }

            // validation below is related to outcome and details
            // for example, if AFP is selected, amount is mandatory
            if (outcome != null) {
                if (outcome.key == cnst.ceOutcome.CE_OUTCOME_AFP) {

                    var needValidate = false;
                    if (field == 'newDecision') {
                        var result = control.value['result'];
                        if (result != null && result.key != cnst.AppealResult.CE_APPEAL_RESULT_PEND) {
                            needValidate = true;
                        }
                    } else {
                        needValidate = true;
                    }

                    if (needValidate) {
                        var amt = control.value.penaltyAmount;
                        if (amt == null || amt == '') {
                            return { amtRequired: true };
                        }
                    }

                } else if (field == 'newDecision' && outcome.key == cnst.ceOutcome.CE_OUTCOME_SUSPEND) {

                    var result = control.value['result'];
                    if (result != null && result.key != cnst.AppealResult.CE_APPEAL_RESULT_PEND) {
                        var startReq = false;
                        var endReq = false;

                        var startDate = control.value.penaltyStartDate;
                        if (startDate == null || startDate == '') {
                            startReq = true;
                        }

                        var endDate = control.value.penaltyEndDate;
                        if (endDate == null || endDate == '') {
                            endReq = true;
                        }

                        if (startReq && endReq) {
                            return { startDateRequired: true, endDateRequired: true };
                        } else if (startReq && !endReq) {
                            return { startDateRequired: true };
                        } else if (!startReq && endReq) {
                            return { endDateRequired: true };
                        }

                        if (!startReq && !endReq) {
                            var startDt = DateUtil.parseDate(startDate);
                            var endDt = DateUtil.parseDate(endDate);

                            if (endDt.isBefore(startDt)) {
                                return { invalidStartGreaterEndDate: true };
                            }

                            if (moment(endDt).diff(startDt, 'months', true) > 6) {
                                return { moreThanSixMonths: true };
                            }
                        }
                    }

                } else if (field == 'newDecision' && outcome.key == cnst.ceOutcome.CE_OUTCOME_REVOKE) {
                    var result = control.value['result'];
                    if (result != null && result.key != cnst.AppealResult.CE_APPEAL_RESULT_PEND) {
                        var startDate = control.value.penaltyStartDate;
                        if (startDate == null || startDate == '') {
                            return { startDateRequired: true };
                        }
                    }
                }
            }

            return null;
        }
    }

    appealResultValidator() {
        return (control) => {
            var result = control.value['result'];
            if (result != null && result.key != cnst.AppealResult.CE_APPEAL_RESULT_NO_APPEAL) {

                if (result.key == cnst.AppealResult.CE_APPEAL_RESULT_PEND) {
                    var appealReq = false;
                    var respondByReq = false;

                    var appealDate = control.value.appealDate;
                    if (appealDate == null || appealDate == '') {
                        appealReq = true;
                    }

                    var appealRespondByDate = control.value.appealRespondByDate;
                    if (appealRespondByDate == null || appealRespondByDate == '') {
                        respondByReq = true;
                    }

                    if (appealReq && respondByReq) {
                        return { appealDateRequired: true, respondDateRequired: true };
                    } else if (appealReq && !respondByReq) {
                        return { appealDateRequired: true };
                    } else if (!appealReq && respondByReq) {
                        return { respondDateRequired: true };
                    }

                    if (!appealReq && !respondByReq) {
                        var appealDt = DateUtil.parseDate(appealDate);
                        var respondDt = DateUtil.parseDate(appealRespondByDate);

                        if (respondDt.isBefore(appealDt)) {
                            return { invalidAppealGreaterRespondDate: true };
                        }

                    }
                }

            }
        }
    }

    selectedFile: File;
    onCeLetterChanged(event, type, form, selection, fieldGroup) {
        this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                var infringements = this.getFormArray(form, 'infringements');
                selection.selected.forEach(element => {
                    var infringement = infringements.controls.filter(u => {
                        return u.value.offenderUenUin == element.offenderUenUin && u.value.offenderName == element.offenderName && u.value.offenceDate == element.offenceDate
                            && u.value.offenceProvision == element.offenceProvision;
                    })[0];
                    var letterIssuances = infringement.get(fieldGroup).get('letterIssuance');

                    if (letterIssuances.value) {
                        var removeFile = letterIssuances.value;

                        var deletedLetterIssuances = infringement.get(fieldGroup).get('deletedLetterIssuance');
                        var deletedLetterIssuanceList: any = [];
                        if (deletedLetterIssuances.value) {
                            deletedLetterIssuanceList = deletedLetterIssuances.value.length == undefined ? [deletedLetterIssuances.value] : deletedLetterIssuances.value;
                        }
                        deletedLetterIssuanceList.push(removeFile);
                        deletedLetterIssuances.setValue(deletedLetterIssuanceList);
                    }

                    infringement.get(fieldGroup).get('toEmailLetter').setValue(false);
                    letterIssuances.setValue(data);
                });
                selection.clear();
            });
        }
    }

    deleteCeLetter(rowIndex, form, fieldGroup) {

        var infringements = this.getFormArray(form, 'infringements');
        var infringement = infringements.at(rowIndex);

        var letterIssuances = infringement.get(fieldGroup).get('letterIssuance');
        var removeFile = letterIssuances.value;

        var deletedLetterIssuances = infringement.get(fieldGroup).get('deletedLetterIssuance');
        var deletedLetterIssuanceList: any = [];
        if (deletedLetterIssuances.value) {
            deletedLetterIssuanceList = deletedLetterIssuances.value.length == undefined ? [deletedLetterIssuances.value] : deletedLetterIssuances.value;
        }
        deletedLetterIssuanceList.push(removeFile);
        deletedLetterIssuances.setValue(deletedLetterIssuanceList);

        infringement.get(fieldGroup).get('toEmailLetter').setValue(false);
        letterIssuances.setValue(null);
    }

    getFormArray(form: FormGroup, field: string): FormArray {
        return form.get(field) as FormArray;
    }

    compareId(o1: any, o2: any): boolean {
        if (o1 != null && o2 != null) {
            return o1.id === o2.id;
        }
    }

    compareKey(o1: any, o2: any): boolean {
        if (o1 != null && o2 != null) {
            return o1.key === o2.key;
        }
    }

    populateCeTaskLabel(appOrWkflwTypeCode) {
        switch (appOrWkflwTypeCode) {
            case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RECOMMEND:
            case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RECOMMEND:
                return {
                    caseTaskLabel: "Recommendation",
                    tabLabel: "Recommendation",
                    fieldGroupForLetter: 'recommendation',
                    offenceColumns: ['select', 'offender', 'offenceDate', 'offenceProvision', 'recommendation', 'details', 'letterIssuanceRecomm', 'letterIssuanceDateRecomm']
                }
            case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_DECISION:
            case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_DECISION:
                return {
                    caseTaskLabel: "Show Cause / Impose Decision",
                    tabLabel: "Assessment",
                    fieldGroupForLetter: 'decision',
                    offenceColumns: ['select', 'offender', 'offenceDate', 'offenceProvision', 'recommDetailCombine', 'showCause', 'decision', 'decisionDetails', 'letterIssuanceDeci', 'letterIssuanceDateDeci'],
                }
            case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_APPEAL:
            case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_APPEAL:
                return {
                    caseTaskLabel: "Upload Appeal Result",
                    tabLabel: "Appeal Result",
                    fieldGroupForLetter: 'result',
                    offenceColumns: ['select', 'offender', 'offenceDate', 'offenceProvision', 'decisionDetailCombine', 'appealResult', 'newDecision', 'newDecisionDetails', 'letterIssuanceResult', 'letterIssuanceDateResult'],
                }
            case cnst.WorkflowTypes.CE_WKFLW_TA_CASE_TASK_RESCIND:
            case cnst.WorkflowTypes.CE_WKFLW_TG_CASE_TASK_RESCIND:
                return {
                    caseTaskLabel: "Rescind Letter",
                    tabLabel: "Assessment",
                    fieldGroupForLetter: 'rescind',
                    offenceColumns: ['select', 'offender', 'offenceDate', 'offenceProvision', 'letterIssuanceResc', 'letterIssuanceDateResc'],
                }
        }

        return null;
    }

    ableToEdit(data, checkPastRecommendation, checkIp) {
        var canEdit = data.get('isCompleted').value != true;

        if (canEdit) {
            canEdit = data.get('isPendingApproval').value != true;
        }

        if (canEdit && checkPastRecommendation) {
            canEdit = data.get('hasApprovedPastRecommendation').value != true;
        }

        if (canEdit && checkIp) {
            canEdit = data.get('ipCaseId').value == null;
        }

        return canEdit;
    }

}