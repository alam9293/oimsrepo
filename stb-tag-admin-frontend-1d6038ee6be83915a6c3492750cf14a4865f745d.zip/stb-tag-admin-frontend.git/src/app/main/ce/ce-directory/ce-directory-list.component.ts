import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatPaginator, MatSort, MatSortable, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CeDirectoryService } from './ce-directory.service';
import { AuthenticationService } from '../../../common/services';
import { CommonService } from '../../../common/services'
import * as cnst from '../../../common/constants';
import * as _ from 'lodash';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'ce-directory-list',
    templateUrl: './ce-directory-list.component.html',
    styleUrls: ['./ce-directory-list.component.scss']
})
export class CeDirectoryListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    listingId = 'ce-directory';
    rows = [];
    selection = new SelectionModel<any>(true, []);
    displayedColumns = ['licenceNo', 'name', 'provisionLabel', 'outcomeLabel', 'outcomeDate', 'oicName', 'caseStatusLabel', 'caseNo'];
    filter: any = {};
    cnst = cnst;
    caseStatuses: [];
    outcomes: [];
    public title;
    public isDialog = false;
    public isManageIp = false;
    public myTask: boolean = this.commonService.getLastDashboardView().viewMode == 'my';;
    public category;

    constructor(
        private ceDirectoryService: CeDirectoryService,
        private commonService: CommonService,
        private authenticationService: AuthenticationService,
        private route: ActivatedRoute,
    ) { }

    ngOnInit() {
        this.category = this.route.snapshot.paramMap.get('category');
        if (this.category) {
            this.filter.isIp = this.category == cnst.caseCategory.IP;
            this.displayedColumns = ['caseNo', 'licenceNo', 'name', 'provisionLabel', 'outcomeLabel', 'outcomeDate', 'oicName', 'caseStatusLabel'];
            if (this.filter.isIp) {
                this.listingId = 'ce-directory-ip';
                this.title = "Manage Investigation Paper"
                this.isManageIp = true;
            }
        }

        this.getList(true);
        this.loadCommonTypes();
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.rows.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.rows.forEach(row => this.selection.select(row));
    }

    setMyApplicationsAndDefaultAppStatus(fromInit: boolean) {
        if (this.filter.isFromCache) {
            this.myTask = this.filter.myTask; // as long as cache is found for this listingId, use the cache and toggle myApplications flag
        } else {
            this.filter.myTask = this.myTask; // if not, searchDto should include myApplications flag before firing to server            
        }
    }

    getList(fromCache: boolean) {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.listingId);
        if (this.category) {
            this.setMyApplicationsAndDefaultAppStatus(fromCache);
        }
        this.ceDirectoryService.getList(this.filter).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            if (!this.isDialog) {
                this.commonService.cacheSearchDto(this.filter);
            }
        });
    }

    loadCommonTypes() {
        this.commonService.getStatusesByCategoryCode(cnst.StatusCategories.STAT_CE_CASE).subscribe(data => this.caseStatuses = data);
        this.commonService.getCeOutcomesIp().subscribe(data => this.outcomes = data);
    }

    hasPermission(code) {
        return this.authenticationService.hasPermission(code) && !this.isDialog;
    }

}

@Component({
    selector: 'ce-directory-list-dialog',
    templateUrl: './ce-directory-list.component.html',
    styleUrls: ['./ce-directory-list.component.scss']
})
export class CeDirectoryListDialogComponent extends CeDirectoryListComponent {

    constructor(
        @Inject(MAT_DIALOG_DATA) public data: any,
        public dialogRef: MatDialogRef<CeDirectoryListComponent>,
        ceDirectoryService: CeDirectoryService,
        commonService: CommonService,
        authenticationService: AuthenticationService
    ) {
        super(ceDirectoryService, commonService, authenticationService, null);
    }

    ngOnInit() {
        this.isDialog = true;
        this.title = this.data.title;
        this.filter.isIp = this.data.isIp;
        this.displayedColumns = ['select', 'caseNo', 'licenceNo', 'name', 'provisionLabel', 'outcomeLabel', 'outcomeDate', 'oicName', 'caseStatusLabel'];
        this.getList(false);
        this.loadCommonTypes();
    }

    isDisabled(caseNo) {
        return this.data.internalItemCaseNo.find(function (x) { return x == caseNo }) != null;
    }

    close(caseNo) {
        let obj = {
            caseNo: caseNo
        };
        this.dialogRef.close(obj);
    }

}
