import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { VersionCheckUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';
import * as _ from 'lodash';

@Injectable({
    providedIn: 'root'
})
export class CeDirectoryService {

    public courseTypeUrl: any;

    constructor(private http: HttpClient) { }

    getList(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.CE_DIRECTORY + "/search", { params: searchDto });
    }

    getProvisionDropdown(): Observable<any> {
        return this.http.get(cnst.apiBaseUrl + cnst.CeApiUrl.CE_PROVISION + '/view/dropdown/read-with');
    }
}
