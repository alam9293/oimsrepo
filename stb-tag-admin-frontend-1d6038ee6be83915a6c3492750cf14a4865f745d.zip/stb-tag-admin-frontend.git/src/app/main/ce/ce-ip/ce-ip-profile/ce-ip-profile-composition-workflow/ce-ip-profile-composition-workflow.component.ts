import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from '../../../../../common/services';
import { MatTable } from '@angular/material';
import { MatSnackBar, MatDialog, MatDialogRef } from '@angular/material';

import * as cnst from '../../../../../common/constants';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { FormUtil, WorkflowHelper } from '../../../../../common/helper';
import { WorkflowService } from 'src/app/common/services/workflow.service';
import { ConfirmationDialogComponent } from 'src/app/common/modules/confirmation-dialog/confirmation-dialog.component';
import { CeIpService } from '../../ce-ip.service';

@Component({
    selector: 'ce-ip-profile-composition-workflow',
    templateUrl: './ce-ip-profile-composition-workflow.component.html',
    styleUrls: ['./ce-ip-profile-composition-workflow.component.scss']
})
export class CeIpProfileCompositionWorkflowComponent implements OnInit {

    @ViewChild(MatTable) _matTables;

    tableColumns = ['name', 'email', 'description', 'amount', 'dueDate', 'billRefNo', 'status', 'remarks'];

    cnst = cnst;
    form: FormGroup;
    statuses;
    isDisabled = false;

    constructor(
        private fb: FormBuilder,
        private formUtil: FormUtil,
        public dialog: MatDialog,
        private commonService: CommonService,
        private ceIpService: CeIpService,
        private workflowService: WorkflowService,
        private workflowHelper: WorkflowHelper,
    ) {
    }

    ngOnInit() {
        this.commonService.getStatusesByCategoryCode(cnst.StatusCategories.STAT_PAYREQ).subscribe(data => this.statuses = data);

        this.initForm();
    }

    get id() {
        return this.form.get('id').value;
    }

    get taTgType() {
        return this.form.get('taTgType').value;
    }

    get ceCaseTask() {
        return this.form.get("workflow").value;
    }

    get items() {
        return this.form.get('compositions') as FormArray;
    }

    get deletedId() {
        return this.form.get('deletedId').value;
    }

    initForm() {
        this.form = this.fb.group({
            id: [],
            taTgType: [],
            compositions: this.fb.array([]),
            workflow: this.fb.group({
                workflowId: [],
                caseTaskStatus: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                workflowAssessment: [],
                internalRemarks: [],
                assigneeId: [],
                assigneeName: [],
                sla: [],
                appOrWkflwType: [],
                appOrWkflwTypeCode: [],

                approverId: [],
                supporterId: [],
                workflowFiles: [],
                deletedWorkflowFiles: [],

                isAssignee: [false],
                isFinalApproval: [false],
                isInGroup: [false],
            }),
            internalRemarks: [''],
            approverId: [''],
            supporterId: ['']
        })
    }

    set(id, isDisabled) {
        this.form.get("id").setValue(id);
        this.isDisabled = isDisabled;
        this.load();
    }

    load() {
        this.ceIpService.loadCompoWorkflow(this.id).subscribe(data => {
            if (data.id) {
                this.initForm();
                this.form.patchValue(data);
                data.compositions.forEach(u => {
                    this.add(u);
                });
                if (this.isDisabled) {
                    this.items.disable();
                }
            }
        });
    }

    add(item) {
        this.items.push(
            this.toFormGroup(item)
        );
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog(action, ceTaskWorkflow) {

        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                internalRemarks: true,
                externalRemarks: false,
                action: action,
                appType: ceTaskWorkflow.appOrWkflwTypeCode,
                supporterId: ceTaskWorkflow.supporterId,
                approverId: ceTaskWorkflow.approverId
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.form.patchValue(result.params);
                this.ceIpService.submitAction(this.form.value, action.name).subscribe(
                    data => {
                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', this.taTgType), 'success-snackbar');
                        location.reload();
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    reAssign() {
        let workFlowType = this.taTgType == cnst.TA.toUpperCase ? cnst.WorkflowTypes.CE_WKFLW_TA_IP_COMPO_IMPOSE : cnst.WorkflowTypes.CE_WKFLW_TG_IP_COMPO_IMPOSE;
        this.workflowHelper.reAssignCEWorkflow(this.ceCaseTask.caseTaskStatus.key, this.ceCaseTask.workflowId, workFlowType).then(data => {
            if (data) {
                this.load();
            }
        })
    }
    isPendingSubmission(): boolean {
        return this.workflowHelper.isPendingSubmission(this.ceCaseTask.caseTaskStatus.key, this.ceCaseTask.hasEditedAfterApproved);
    }
    isPendingApproval(): boolean {
        return this.workflowHelper.isPendingApproval(this.ceCaseTask.caseTaskStatus.key);
    }

    toFormGroup(x) {
        if (x) {
            return this.fb.group({
                id: [x.id],
                infringerId: [x.infringerId],
                name: [x.name],
                uenUin: [x.uenUin],
                email: [x.email],
                description: [x.description],
                amount: [x.amount],
                dueDate: [x.dueDate],
                billRefNo: [x.billRefNo],
                status: this.formUtil.listableFormWithValueNoValidation(this.fb, x.status),
                remarks: [x.remarks],
                letter: [],//this.fileUtil.buildAttachmentFormData(x.letter)],
                checked: [false]
            });
        }
        else {
            return this.fb.group({
                id: [''],
                infringerId: [''],
                name: [''],
                uenUin: [''],
                email: [''],
                description: [''],
                amount: [''],
                dueDate: [''],
                billRefNo: [''],
                status: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                remarks: [''],
                letter: [''],
                checked: [false]
            });
        }
    }
}

export interface data {
    id: number;
    name: string;
    uenUin: string;
    email: string;
    description: string;
    amount: number;
    dueDate: string;
    billRefNo: string;
    status: { key: string, label: string };
    remarks: string;
    letter: string;
}

const DATA: data[] = [
    { id: 1, name: 'Lee Yew Chong', uenUin: 'SXXXX5566A', email: 'lee@wizvision.com', description: '2 counts of offences.\nanything else.', amount: 10000, dueDate: '01-Dec-2019', billRefNo: '', status: null, remarks: '', letter: '' },
    { id: 2, name: 'ABC Pte Ltd', uenUin: '152201459', email: '', description: '', amount: null, dueDate: '', billRefNo: '', status: null, remarks: '', letter: '' },
];