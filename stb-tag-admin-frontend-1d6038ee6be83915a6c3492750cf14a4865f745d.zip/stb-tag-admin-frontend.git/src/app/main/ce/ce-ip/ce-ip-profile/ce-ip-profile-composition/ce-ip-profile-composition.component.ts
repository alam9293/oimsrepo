import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from '../../../../../common/services';
import { MatTable } from '@angular/material';
import { MatSnackBar, MatDialog } from '@angular/material';

import * as cnst from '../../../../../common/constants';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { FormUtil, WorkflowHelper, FileUtil } from '../../../../../common/helper';
import { WorkflowService } from 'src/app/common/services/workflow.service';
import { ConfirmationDialogComponent } from 'src/app/common/modules/confirmation-dialog/confirmation-dialog.component';
import { CeIpService } from '../../ce-ip.service';

@Component({
    selector: 'ce-ip-profile-composition',
    templateUrl: './ce-ip-profile-composition.component.html',
    styleUrls: ['./ce-ip-profile-composition.component.scss']
})
export class CeIpProfileCompositionComponent implements OnInit {

    @ViewChild(MatTable) _matTables;

    tableColumns = ['select', 'name', 'email', 'description', 'amount', 'dueDate', 'billRefNo', 'status', 'remarks', 'letter'];

    cnst = cnst;
    form: FormGroup;
    statuses;

    isDisabled = false;

    constructor(
        private fb: FormBuilder,
        private formUtil: FormUtil,
        public dialog: MatDialog,
        private commonService: CommonService,
        private ceIpService: CeIpService,
        private workflowService: WorkflowService,
        public workflowHelper: WorkflowHelper,
        public fileUtil: FileUtil
    ) {
    }

    ngOnInit() {
        this.commonService.getStatusesByCategoryCode(cnst.StatusCategories.STAT_PAYREQ).subscribe(data => this.statuses = data);

        this.initForm();
    }

    get id() {
        return this.form.get('id').value;
    }

    get taTgType() {
        return this.form.get('taTgType').value;
    }

    get ceCaseTask() {
        return this.form.get("workflow").value;
    }

    get items() {
        return this.form.get('compositions') as FormArray;
    }

    get deletedId() {
        return this.form.get('deletedId').value;
    }

    initForm() {
        this.form = this.fb.group({
            id: [],
            taTgType: [],
            compositions: this.fb.array([]),
            workflow: this.fb.group({
                workflowId: [],
                caseTaskStatus: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                workflowAssessment: [],
                internalRemarks: [],
                lastActionBy: [],
                assigneeId: [],
                assigneeName: [],
                sla: [],
                appOrWkflwType: [],
                appOrWkflwTypeCode: [],

                approverId: [],
                supporterId: [],
                workflowFiles: [],
                deletedWorkflowFiles: [],

                isAssignee: [false],
                isFinalApproval: [false],
                isInGroup: [false],
            }),
            internalRemarks: [''],
            approverId: [''],
            supporterId: ['']
        });

        this.form.get("")
    }

    set(id, isDisabled) {
        this.form.get("id").setValue(id);
        this.isDisabled = isDisabled;
        this.load();
    }

    load() {
        this.ceIpService.loadCompo(this.id).subscribe(data => {
            if (data) {
                this.initForm();
                this.form.patchValue(data);
                data.compositions.forEach(u => {
                    this.add(u);
                });

                if (this.isDisabled) {
                    this.items.disable();
                }
            }
        });
    }

    add(item) {
        this.items.push(
            this.toFormGroup(item)
        );
        this._matTables.renderRows();
    }

    submit(action) {
        if (this.form.valid) {
            let workflowType = this.taTgType == cnst.TA.toUpperCase() ? cnst.WorkflowTypes.CE_WKFLW_TA_IP_COMPO_IMPOSE : cnst.WorkflowTypes.CE_WKFLW_TG_IP_COMPO_IMPOSE;

            let dialogData: any = {
                title: 'Action: ' + action.label,
                internalRemarks: true,
                externalRemarks: false,
                action: action,
                taTg: cnst.CE,
                appType: workflowType
            }
            if (!this.ceCaseTask.isFinalApproval && action.name != 'route') {
                this.workflowService.getCeWorkflowConfigByType(workflowType).subscribe(data => {
                    // get routing officers
                    dialogData.workflowConfig = data;
                    this.submission(dialogData, action);
                })
            } else {
                this.submission(dialogData, action);
            }
        }
        else {
            this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
        }
    }

    submission(dialogData, action) {
        let confirmationDialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: dialogData
        });
        confirmationDialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.form.patchValue(result.params);
                let data = this.form.value;
                data.compositions = data.compositions.filter(item => { return item.checked == true });
                this.ceIpService.submitAction(data, action.name).subscribe(
                    data => {
                        location.reload();
                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'IP'), 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    }
                );
            }
        });
    }

    email() {
        let action = cnst.workflowAction.email;
        this.ceIpService.submitAction(this.form.value, action.name).subscribe(
            data => {
                this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'IP'), 'success-snackbar');
                this.load();
            },
            error => {
                this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
            }
        );
    }

    toFormGroup(x) {
        if (x) {
            return this.fb.group({
                id: [x.id],
                infringerId: [x.infringerId],
                name: [x.name],
                uenUin: [x.uenUin],
                email: [x.email],
                description: [x.description],
                amount: [x.amount],
                dueDate: [x.dueDate],
                billRefNo: [x.billRefNo],
                status: this.formUtil.listableFormWithValueNoValidation(this.fb, x.status),
                currStatus: this.formUtil.listableFormWithValueNoValidation(this.fb, x.status),
                remarks: [x.remarks],
                letter: this.fileUtil.populateAttachmentFormGroup(x.letter),
                checked: [x.checked],
                isEditable: [x.isEditable],
                isApproved: [x.isApproved]
            });
        }
        else {
            return this.fb.group({
                id: [''],
                infringerId: [''],
                name: [''],
                uenUin: [''],
                email: [''],
                description: [''],
                amount: [''],
                dueDate: [''],
                billRefNo: [''],
                status: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                currStatus: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                remarks: [''],
                letter: this.fileUtil.populateAttachmentFormGroup(null),
                checked: [false],
                isEditable: [false],
                isApproved: [false]
            });
        }
    }

    isPendingSubmission(): boolean {
        return this.workflowHelper.isPendingSubmission(this.ceCaseTask.caseTaskStatus.key, this.ceCaseTask.hasEditedAfterApproved);
    }
    isPendingApproval(): boolean {
        return this.workflowHelper.isPendingApproval(this.ceCaseTask.caseTaskStatus.key);
    }
    isNew(): boolean {
        return this.workflowHelper.isNew(this.ceCaseTask.caseTaskStatus.key);
    }
    isApproved(): boolean {
        return this.workflowHelper.isApproved(this.ceCaseTask.caseTaskStatus.key);
    }
    isRouted(): boolean {
        return this.workflowHelper.isRouted(this.ceCaseTask.caseTaskStatus.key);
    }

    onFileChanged(event, letter) {
        var selectedFile = event.target.files[0];
        var extension = selectedFile.name.substr(selectedFile.name.lastIndexOf('.'));
        if (cnst.FileExt.SIGN_DOC_ATTACHMENT.ext.includes(extension)) {
            if (!this.fileUtil.exceedMaxSize(selectedFile)) {
                this.fileUtil.upload(cnst.DocumentTypes.CE_COMPO_LETTER, selectedFile).subscribe(data => {
                    letter.patchValue(data);
                    this._matTables.renderRows();
                });
            }
        } else {
            this.commonService.popSnackbar(cnst.FileExt.SIGN_DOC_ATTACHMENT.errorMsg, 'error-snackbar');
        }
    }

    checked(row) {
        if (row.get("checked").value) {
            row.get("email").setValidators([Validators.required, Validators.email]);
            row.get("amount").setValidators([Validators.required]);
            row.get("dueDate").setValidators([Validators.required]);
        }
        else {
            row.get("email").setValidators(null);
            row.get("amount").setValidators(null);
            row.get("dueDate").setValidators(null);
        }
        row.get("email").updateValueAndValidity();
        row.get("amount").updateValueAndValidity();
        row.get("dueDate").updateValueAndValidity();
    }

    isChecked() {
        let compositions = this.items.value.filter(item => { return item.checked == true });
        return compositions.length > 0;
    }

    isWaived() {
        let compositions = this.items.value.filter(item => { return item.checked == true && item.currStatus.key == cnst.payReqStatus.PAYREQ_W });
        return compositions.length > 0;
    }
}

export interface data {
    id: number;
    name: string;
    uenUin: string;
    email: string;
    description: string;
    amount: number;
    dueDate: string;
    billRefNo: string;
    status: { key: string, label: string };
    remarks: string;
    letter: string;
}

const DATA: data[] = [
    { id: 1, name: 'Lee Yew Chong', uenUin: 'SXXXX5566A', email: 'lee@wizvision.com', description: '2 counts of offences.\nanything else.', amount: 10000, dueDate: '01-Dec-2019', billRefNo: '', status: null, remarks: '', letter: '' },
    { id: 2, name: 'ABC Pte Ltd', uenUin: '152201459', email: '', description: '', amount: null, dueDate: '', billRefNo: '', status: null, remarks: '', letter: '' },
];