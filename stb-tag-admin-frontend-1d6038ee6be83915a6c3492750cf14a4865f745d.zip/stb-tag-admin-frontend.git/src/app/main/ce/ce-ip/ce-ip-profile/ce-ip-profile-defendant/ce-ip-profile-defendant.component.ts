import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { FormUtil } from '../../../../../common/helper';
import { MatTable } from '@angular/material';

import * as cnst from '../../../../../common/constants';
import { CommonService } from 'src/app/common/services';
import { CeIpService } from '../../ce-ip.service';
import * as moment from 'moment';

@Component({
    selector: 'ce-ip-profile-defendant',
    templateUrl: './ce-ip-profile-defendant.component.html',
    styleUrls: ['./ce-ip-profile-defendant.component.scss']
})
export class CeIpProfileDefendantComponent implements OnInit {

    @ViewChild(MatTable) _matTables;

    tableColumns = ['entityDetails', 'noOfCount', 'offenceDate', 'offenceCode', 'readWithOffence', 'offenceDescription', 'location', 'outcome', 'sentencing', 'countCase', 'outcomeDate', 'action'];

    form: FormGroup;
    cnst = cnst;

    idTypes;
    outcomeTypes;
    nationalityTypes;
    ageGroupTypes;
    guidingLanguageProvidedTypes;
    provisionChapterMap = new Map<string, any>();
    provisionMap = new Map<string, any>();
    spans = [];
    isTg;
    isDisabled = false;
    unionMap = new Map<string, string>();

    constructor(
        private fb: FormBuilder,
        private ceIpService: CeIpService,
        public commonService: CommonService,
        private formUtil: FormUtil,
    ) {

    }

    ngOnInit() {
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.CE_ID_TYPE).subscribe(data => this.idTypes = data);
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.NAT).subscribe(data => this.nationalityTypes = data);
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.TG_AGE_GROUP).subscribe(data => this.ageGroupTypes = data);
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.TG_LANG).subscribe(data => this.guidingLanguageProvidedTypes = data);
        this.commonService.getCeOutcomesIp().subscribe(data => this.outcomeTypes = data);

        this.initForm();

        this.items.valueChanges.subscribe(val => {
            this.commonService.updateForm(val, 'name', this.spans);
            this.commonService.updateForm(val, 'uenUin', this.spans);
            this.commonService.updateForm(val, 'category', this.spans);
        });
    }

    get items() {
        return this.form.get('items') as FormArray;
    }

    get deletedId() {
        return this.form.get('deletedId').value;
    }

    initForm() {
        this.form = this.fb.group({
            items: this.fb.array([]),
            deletedId: [[]]
        });
    }

    set(data: any, taTgType) {
        this.ceIpService.getProvisionDropdown(taTgType).subscribe(provisions => {
            provisions.forEach(x => {
                this.setProvision(x);
            });

            if (data) {
                this.initForm();
                data.forEach(u => {
                    this.addItem(u);
                });
            }

            this.isTg = taTgType == cnst.TG.toUpperCase();
            if (!this.isTg) {
                this.tableColumns = ['entityDetails', 'noOfCount', 'offenceDate', 'offenceCode', 'readWithOffence', 'offenceDescription', 'outcome', 'sentencing', 'countCase', 'outcomeDate', 'action'];
            }

            if (this.isDisabled) {
                this.items.disable();
            }

            this.renderTable();
        });
    }

    add(item) {
        this.addItem(item);
        this.renderTable();
    }

    addItem(x) {
        if (x) {
            let isProvisionIneffective = this.isIneffectiveOffenceProvision(x.provision);

            // add ineffective offence provision to dropdown
            if (isProvisionIneffective) {
                this.setProvision(x.provision);
            }

            // add ineffective readwith to dropdown
            x.provisionsReadWith.forEach(readWith => {
                if (isProvisionIneffective || this.isIneffectiveOffenceProvision(readWith)) {
                    let offenceProvision = this.getProvision(x.provision.id);
                    if (offenceProvision) {
                        offenceProvision.readWiths.push(readWith);
                    }
                }
            });

            this.items.push(this.fb.group({
                id: [x.id],
                infringerId: [x.infringerId],
                idType: this.formUtil.listableFormWithValueNoValidation(this.fb, x.idType),
                name: [x.name],
                uenUin: [x.uenUin],
                licenceNo: [x.licenceNo],
                licenceNos: [[x.licenceNo]],
                category: [x.category],
                nationality: this.formUtil.listableFormWithValueNoValidation(this.fb, x.nationality),
                ageGroup: this.formUtil.listableFormWithValueNoValidation(this.fb, x.ageGroup),
                guidingLanguageProvided: this.formUtil.listableFormWithValueNoValidation(this.fb, x.guidingLanguageProvided),
                ipOffenceCount: [x.ipOffenceCount],
                offenceDate: [x.offenceDate],
                ceOriginatingCaseNo: [x.ceOriginatingCaseNo],
                provision: this.toProvisionForm(x.provision),
                provisionsReadWith: [x.provisionsReadWith],
                outcome: this.formUtil.listableFormWithValue(this.fb, x.outcome),
                ipSentencingDetails: [x.ipSentencingDetails],
                ipCourtCaseNo: [x.ipCourtCaseNo],
                outcomeDate: [x.outcomeDate, Validators.required],
                location: [x.location],
            }));
        }
        else {
            this.items.push(this.fb.group({
                id: [],
                infringerId: [],
                idType: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                name: [],
                uenUin: [],
                licenceNo: [],
                licenceNos: [],
                category: [],
                nationality: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                ageGroup: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                guidingLanguageProvided: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                ipOffenceCount: [],
                offenceDate: [],
                ceOriginatingCaseNo: [],
                provision: this.toProvisionForm(null),
                provisionsReadWith: [],
                outcome: this.formUtil.listableFormWithValue(this.fb, null),
                ipSentencingDetails: [],
                ipCourtCaseNo: [],
                outcomeDate: ['', Validators.required],
                location: [],
            }));
        }
    }

    duplicate(x, pos) {
        this.items.insert(pos + 1, this.fb.group({
            id: [],
            infringerId: [x.infringerId],
            idType: this.formUtil.listableFormWithValueNoValidation(this.fb, x.idType),
            name: [x.name],
            uenUin: [x.uenUin],
            licenceNo: [x.licenceNo],
            licenceNos: [x.licenceNos],
            category: [x.category],
            nationality: this.formUtil.listableFormWithValueNoValidation(this.fb, x.nationality),
            ageGroup: this.formUtil.listableFormWithValueNoValidation(this.fb, x.ageGroup),
            guidingLanguageProvided: this.formUtil.listableFormWithValueNoValidation(this.fb, x.guidingLanguageProvided),
            ipOffenceCount: [x.ipOffenceCount],
            offenceDate: [],
            ceOriginatingCaseNo: [],
            provision: this.toProvisionForm(x.provision),
            provisionsReadWith: [x.provisionsReadWith],
            outcome: this.formUtil.listableFormWithValue(this.fb, x.outcome),
            ipSentencingDetails: [x.ipSentencingDetails],
            ipCourtCaseNo: [x.ipCourtCaseNo],
            outcomeDate: [x.outcomeDate, Validators.required],
            location: [x.location],
        }));

        this.renderTable();
    }

    addOffence(x, pos) {
        this.items.insert(pos + this.spans[pos]['uenUin'], this.fb.group({
            id: [],
            infringerId: [x.infringerId],
            idType: this.formUtil.listableFormWithValueNoValidation(this.fb, x.idType),
            name: [x.name],
            uenUin: [x.uenUin],
            licenceNo: [x.licenceNo],
            licenceNos: [x.licenceNos],
            category: [x.category],
            nationality: this.formUtil.listableFormWithValueNoValidation(this.fb, x.nationality),
            ageGroup: this.formUtil.listableFormWithValueNoValidation(this.fb, x.ageGroup),
            guidingLanguageProvided: this.formUtil.listableFormWithValueNoValidation(this.fb, x.guidingLanguageProvided),
            ipOffenceCount: [],
            offenceDate: [],
            ceOriginatingCaseNo: [],
            provision: this.toProvisionForm(null),
            provisionsReadWith: [],
            outcome: this.formUtil.listableFormWithValue(this.fb, null),
            ipSentencingDetails: [],
            ipCourtCaseNo: [],
            outcomeDate: ['', Validators.required],
            location: [],
        }));

        this.renderTable();
    }

    deleteRow(rowIndex) {
        var item = this.items.at(rowIndex);

        if (item.get('id').value) {
            this.deletedId.push(item.get('id').value);
        }
        this.items.removeAt(rowIndex);

        this.renderTable();
    }

    renderTable() {
        this.spans = this.commonService.spanRow('uenUin', d => d.uenUin, this.items.value);
        this._matTables.renderRows();
    }

    getProvision(key) {
        return this.provisionMap.get(key);
    }

    getProvisionLabel(key) {
        let provision = this.getProvision(key);
        return provision ? provision.chapter.label + ": " + provision.section : [];
    }

    getProvisionReadWiths(key) {
        let provision = this.getProvision(key);
        return provision ? provision.readWiths : [];
    }

    getProvisionDescription(key) {
        let provision = this.getProvision(key);
        return provision ? provision.description : '-';
    }

    setProvision(provision) {
        let offenceProvision = this.provisionMap.get(provision.id);

        if (offenceProvision == null) {
            this.provisionMap.set(provision.id, provision);

            var chapters = this.provisionChapterMap.get(provision.chapter.label);
            if (chapters) {
                chapters.push(provision);
            } else {
                this.provisionChapterMap.set(provision.chapter.label, [provision]);
            }
        }
    }

    isIneffectiveOffenceProvision(provision) {
        return provision != null && provision.ineffectiveDate != null && moment(provision.ineffectiveDate, 'DD-MMM-YYY') < moment() ? true : false;
    }

    toProvisionForm(provision) {
        if (provision) {
            return this.fb.group({
                id: [provision.id]
            });
        }
        else {
            return this.fb.group({
                id: []
            });
        }
    }

    search(rowIndex) {
        let item = this.items.at(rowIndex);
        let itemValue = item.value;

        this.ceIpService.search(itemValue.idType.key, itemValue.uenUin).subscribe(data => {
            item.patchValue(data);
        });
    }

    disabled() {
        this.items.disable();
        this.isDisabled = true;
    }

}

export interface RelevantOffences {
    id: number,
    name: string,
    uenUin: string,
    category: string,
    ipOffenceCount: number,
    provision: string,
    provisionsReadWith: string,
    provisionLabel: string,
    outcome: string,
    ipSentencingDetails: string,
    ipCourtCaseNo: string,
    outcomeDate: string,
}

const DATA_REL_OFFENCES: RelevantOffences[] = [
    { id: 1, name: 'Lee Yew Chong', uenUin: 'SXXXX5566A', category: null, ipOffenceCount: 3, provision: null, provisionsReadWith: null, provisionLabel: 'Unlicensed TG', outcome: null, ipSentencingDetails: '', ipCourtCaseNo: '', outcomeDate: '01-Oct-2019' },
    { id: 1, name: 'Lee Yew Chong', uenUin: 'SXXXX5566A', category: null, ipOffenceCount: 3, provision: null, provisionsReadWith: null, provisionLabel: '', outcome: null, ipSentencingDetails: '$10,000', ipCourtCaseNo: 'MSC', outcomeDate: '01-Oct-2019' },
    { id: 2, name: 'ABC Pte Ltd', uenUin: '152201459', category: null, ipOffenceCount: 3, provision: null, provisionsReadWith: null, provisionLabel: 'Unlicensed TA', outcome: null, ipSentencingDetails: '$25,000', ipCourtCaseNo: 'MSC', outcomeDate: '01-Oct-2019' },
    { id: 2, name: 'ABC Pte Ltd', uenUin: '152201459', category: null, ipOffenceCount: 3, provision: null, provisionsReadWith: null, provisionLabel: '', outcome: null, ipSentencingDetails: '', ipCourtCaseNo: '', outcomeDate: '01-Oct-2019' },
];
