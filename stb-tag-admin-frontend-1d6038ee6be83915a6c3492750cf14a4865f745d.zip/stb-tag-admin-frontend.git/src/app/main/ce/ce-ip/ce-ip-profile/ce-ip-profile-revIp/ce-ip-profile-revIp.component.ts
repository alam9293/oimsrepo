import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from '../../../../../common/services';
import { MatTable, MatDialog, MatDialogRef } from '@angular/material';
import { CeDirectoryListDialogComponent } from '../../../ce-directory/ce-directory-list.component';

import * as cnst from '../../../../../common/constants';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { FormUtil } from '../../../../../common/helper';
import { CeIpService } from '../../ce-ip.service';

@Component({
    selector: 'ce-ip-profile-revIp',
    templateUrl: './ce-ip-profile-revIp.component.html',
    styleUrls: ['./ce-ip-profile-revIp.component.scss']
})
export class CeIpProfileRevIpComponent implements OnInit {

    @ViewChild(MatTable) _matTables
    dialogRef: MatDialogRef<any>;
    tableColumns = ['createdOn', 'type', 'caseId', 'caseStatus', 'caseOic', 'caseOicContactNo', 'action'];

    cnst = cnst;
    form: FormGroup;
    types;
    caseStatuses;
    caseNo;
    isDisabled = false;

    constructor(
        private fb: FormBuilder,
        private formUtil: FormUtil,
        private commonService: CommonService,
        private ceIpService: CeIpService,
        private dialog: MatDialog,
    ) {
    }

    ngOnInit() {
        this.initForm();
        this.types = cnst.RevIpTypes;
    }

    get items() {
        return this.form.get('items') as FormArray;
    }

    get deletedId() {
        return this.form.get('deletedId').value;
    }

    initForm() {
        this.form = this.fb.group({
            items: this.fb.array([]),
            deletedId: [[]]
        });
    }

    set(data: any, caseNo) {
        if (data) {
            this.initForm();
            data.forEach(u => {
                this.add(u);
            });
        }
        this.caseNo = caseNo;
    }

    setCaseStatuses(caseStatuses) {
        this.caseStatuses = caseStatuses;
    }

    add(item) {
        this.items.push(
            this.toFormGroup(item)
        );
        this._matTables.renderRows();
    }

    deleteRow(rowIndex) {

        var item = this.items.at(rowIndex);

        if (item.get('id').value && item.get('typeCode').value == cnst.RevIpType.EXTERNAL) {
            this.deletedId.push(item.get('id').value);
        }
        this.items.removeAt(rowIndex);

        this._matTables.renderRows();

    }

    toFormGroup(x) {
        if (x) {
            return this.fb.group({
                id: [x.id],
                createdOn: [x.createdOn],
                typeCode: [x.typeCode],
                caseNo: [x.caseNo],
                status: this.formUtil.listableFormWithValueNoValidation(this.fb, x.status),
                oic: [x.oic],
                oicContactNumber: [x.oicContactNumber],
            });
        }
        else {
            return this.fb.group({
                id: [''],
                createdOn: [''],
                typeCode: [''],
                caseNo: [''],
                status: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                oic: [''],
                oicContactNumber: [''],
            });
        }
    }

    isExternal(row) {
        return row.value.typeCode == cnst.RevIpType.EXTERNAL;
    }

    addInternal() {
        let internalItemCaseNo = this.items.value.filter(item => { return item.typeCode == cnst.RevIpType.INTERNAL }).map(item => { return item.caseNo });
        internalItemCaseNo.push(this.caseNo);

        this.dialogRef = this.dialog.open(CeDirectoryListDialogComponent, {
            data: {
                title: "Select IP",
                isIp: true,
                internalItemCaseNo: internalItemCaseNo,
            },
            panelClass: 'full-screen-modal',
        });
        this.dialogRef.afterClosed().subscribe(result => {
            if (result.caseNo) {
                this.ceIpService.getRevIp(result.caseNo).subscribe(data => {
                    this.add(data);
                });
            }
        });
    }

    addExternal() {
        this.items.push(
            this.fb.group({
                id: [''],
                createdOn: [''],
                typeCode: [cnst.RevIpType.EXTERNAL],
                caseNo: [''],
                status: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                oic: [''],
                oicContactNumber: [''],
            })
        );
        this._matTables.renderRows();
    }

    disabled() {
        this.items.disable();
        this.isDisabled = true;
    }
}