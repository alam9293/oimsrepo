import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonService } from '../../../../../common/services';
import { MatTable } from '@angular/material';

import * as cnst from '../../../../../common/constants';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { FormUtil } from '../../../../../common/helper';

@Component({
    selector: 'ce-ip-profile-witness',
    templateUrl: './ce-ip-profile-witness.component.html',
    styleUrls: ['./ce-ip-profile-witness.component.scss']
})
export class CeIpProfileWitnessComponent implements OnInit {

    @ViewChild(MatTable) _matTables;

    tableColumns = ['name', 'idType', 'idNumber', 'userType', 'action'];

    cnst = cnst;
    form: FormGroup;
    idTypes;
    complainantTypes;
    isDisabled = false;

    constructor(
        private fb: FormBuilder,
        private formUtil: FormUtil,
        private commonService: CommonService,
    ) {
    }

    ngOnInit() {
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.CE_ID_TYPE).subscribe(data => this.idTypes = data);
        this.commonService.getTypesByCategoryCode(cnst.TypeCategories.CE_COMPLAINANT).subscribe(data => this.complainantTypes = data);

        this.initForm();
    }

    get items() {
        return this.form.get('items') as FormArray;
    }

    get deletedId() {
        return this.form.get('deletedId').value;
    }

    initForm() {
        this.form = this.fb.group({
            items: this.fb.array([]),
            deletedId: [[]]
        });
    }

    set(data: any) {
        if (data) {
            this.initForm();
            data.forEach(u => {
                this.add(u);
            });
        }
    }

    add(item) {
        this.items.push(
            this.toFormGroup(item)
        );
        this._matTables.renderRows();
    }

    deleteRow(rowIndex) {

        var item = this.items.at(rowIndex);

        if (item.get('id').value) {
            this.deletedId.push(item.get('id').value);
        }
        this.items.removeAt(rowIndex);

        this._matTables.renderRows();

    }

    disabled() {
        this.items.disable();
        this.isDisabled = true;
    }

    toFormGroup(x) {
        if (x) {
            return this.fb.group({
                id: [x.id],
                name: [x.name],
                idType: this.formUtil.listableFormWithValueNoValidation(this.fb, x.idType),
                uenUin: [x.uenUin],
                type: this.formUtil.listableFormWithValueNoValidation(this.fb, x.type),
            });
        }
        else {
            return this.fb.group({
                id: [''],
                name: [''],
                idType: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
                uenUin: [''],
                type: this.formUtil.listableFormWithValueNoValidation(this.fb, null),
            });
        }
    }
}

export interface data {
    id: number;
    name: string;
    idType: string;
    uenUin: string;
    type: string;
}

const DATA: data[] = [
    { id: 1, name: 'Ashrul', idType: 'UIN', uenUin: 'SXXXX555A', type: 'Complainant - STB' },
    { id: 2, name: 'Dadada', idType: 'UEN', uenUin: '123123123123123', type: 'Witness' },
];