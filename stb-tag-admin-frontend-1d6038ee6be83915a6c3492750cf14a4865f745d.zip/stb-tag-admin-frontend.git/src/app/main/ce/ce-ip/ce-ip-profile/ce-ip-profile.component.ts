import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormUtil } from '../../../../common/helper';
import { CeIpProfileWitnessComponent } from './ce-ip-profile-witness/ce-ip-profile-witness.component';
import { CeIpProfileDefendantComponent } from './ce-ip-profile-defendant/ce-ip-profile-defendant.component';
import { CeIpProfileRevIpComponent } from './ce-ip-profile-revIp/ce-ip-profile-revIp.component';
import { CeIpProfileCompositionComponent } from './ce-ip-profile-composition/ce-ip-profile-composition.component';
import { CeIpProfileCompositionWorkflowComponent } from './ce-ip-profile-composition-workflow/ce-ip-profile-composition-workflow.component';

import * as cnst from '../../../../common/constants';

@Component({
    selector: 'ce-ip-profile',
    templateUrl: './ce-ip-profile.component.html',
    styleUrls: ['./ce-ip-profile.component.scss']
})
export class CeIpProfileComponent implements OnInit {

    @ViewChild(CeIpProfileWitnessComponent) private ceIpProfileWitnessComponent: CeIpProfileWitnessComponent;
    @ViewChild(CeIpProfileDefendantComponent) private ceIpProfileDefendantComponent: CeIpProfileDefendantComponent;
    @ViewChild(CeIpProfileRevIpComponent) private ceIpProfileRevIpComponent: CeIpProfileRevIpComponent;
    @ViewChild(CeIpProfileCompositionComponent) private ceIpProfileCompositionComponent: CeIpProfileCompositionComponent;
    @ViewChild(CeIpProfileCompositionWorkflowComponent) private ceIpProfileCompositionWorkflowComponent: CeIpProfileCompositionWorkflowComponent;

    form;

    constructor(
        private fb: FormBuilder,
        private formUtil: FormUtil
    ) {
    }

    ngOnInit() {
        this.form = this.fb.group({
            complainants: [],
            deletedComplainants: [],
            infringements: [],
            deletedInfringements: [],
            revIps: [],
            deletedRevIps: [],
            othAttachments: [],
            othDeletedAttachments: [],
            compositions: []
        });
    }

    set(data: any, caseStatuses) {
        let isDisabled = data.status.key == cnst.CeCaseStatus.CLOSED;
        this.ceIpProfileWitnessComponent.set(data.complainants);
        this.ceIpProfileDefendantComponent.set(data.infringements, data.taTgType);
        this.ceIpProfileRevIpComponent.set(data.revIps, data.caseNo);
        this.ceIpProfileRevIpComponent.setCaseStatuses(caseStatuses);
        this.ceIpProfileCompositionComponent.set(data.id, isDisabled);
        this.ceIpProfileCompositionWorkflowComponent.set(data.id, isDisabled);

        if (isDisabled) {
            this.ceIpProfileWitnessComponent.disabled();
            this.ceIpProfileDefendantComponent.disabled();
            this.ceIpProfileRevIpComponent.disabled();
        }
    }

    isValid() {
        this.formUtil.markFormGroupTouched(this.ceIpProfileDefendantComponent.form);
        return this.ceIpProfileDefendantComponent.form.valid;
    }

    getFormData() {
        this.form.get('complainants').setValue(this.ceIpProfileWitnessComponent.items.value);
        this.form.get('deletedComplainants').setValue(this.ceIpProfileWitnessComponent.deletedId);
        this.form.get('infringements').setValue(this.ceIpProfileDefendantComponent.items.value);
        this.form.get('deletedInfringements').setValue(this.ceIpProfileDefendantComponent.deletedId);
        this.form.get('revIps').setValue(this.ceIpProfileRevIpComponent.items.value);
        this.form.get('deletedRevIps').setValue(this.ceIpProfileRevIpComponent.deletedId);
        this.form.get('compositions').setValue(this.ceIpProfileCompositionComponent.items.value)
        return this.form;
    }

}


