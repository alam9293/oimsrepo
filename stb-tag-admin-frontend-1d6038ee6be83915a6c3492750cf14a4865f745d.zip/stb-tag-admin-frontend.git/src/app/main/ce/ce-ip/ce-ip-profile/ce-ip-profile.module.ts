import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MainMaterialModule } from './../../../main.material';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';
import { BackModule } from '../../../../common/modules/back/back.module';

import { CeIpProfileComponent } from './ce-ip-profile.component';
import { CeIpProfileWitnessComponent } from './ce-ip-profile-witness/ce-ip-profile-witness.component';
import { CeIpProfileDefendantComponent } from './ce-ip-profile-defendant/ce-ip-profile-defendant.component';
import { CeIpProfileCompositionComponent } from './ce-ip-profile-composition/ce-ip-profile-composition.component';
import { CeIpProfileCompositionWorkflowComponent } from './ce-ip-profile-composition-workflow/ce-ip-profile-composition-workflow.component';
import { CeIpProfileRevIpComponent } from './ce-ip-profile-revIp/ce-ip-profile-revIp.component';
import { SharedModule } from 'src/app/common/modules/shared.module';
import { NgxCurrencyModule } from 'ngx-currency';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MainMaterialModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule,
        BackModule,
        MatDatepickerModule,
        MatSidenavModule,
        SharedModule,
        NgxCurrencyModule
    ],
    declarations: [
        CeIpProfileComponent,
        CeIpProfileWitnessComponent,
        CeIpProfileDefendantComponent,
        CeIpProfileCompositionComponent,
        CeIpProfileRevIpComponent,
        CeIpProfileCompositionWorkflowComponent,
    ],
    exports: [CeIpProfileComponent,],
    entryComponents: [],
})
export class CeIpProfileModule { }
