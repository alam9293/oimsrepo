import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { DateUtil } from 'src/app/common/helper';
import { AuthenticationService } from 'src/app/common/services';
import { CommonService } from '../../../common/services';

import * as cnst from '../../../common/constants';
import { CeIpProfileComponent } from './ce-ip-profile/ce-ip-profile.component';
import { AttachmentComponent } from '../../../common/modules/attachment/attachment.component';
import { CeIpService } from './ce-ip.service';
import { FormUtil } from '../../../common/helper';

@Component({
    selector: 'ce-ip',
    templateUrl: './ce-ip.component.html',
    styleUrls: ['./ce-ip.component.scss']
})
export class CeIpComponent implements OnInit, AfterViewInit {

    @ViewChild(CeIpProfileComponent) ceIpProfileComponent: CeIpProfileComponent;
    @ViewChild(AttachmentComponent) attachmentComponent: AttachmentComponent;

    activeTab: number = 1;

    cnst = cnst;

    ceCase: any = { caseId: null, taTgType: null };
    caseStatuses;
    todayDate = moment(new Date()).format(DateUtil.DATE_FORMAT);
    isDisabled = false;

    form = this.fb.group({
        id: [],
        caseNo: [],
        status: this.formUtil.listableFormWithValue(this.fb, null),
        oic: [],
        createdDate: [],
        isComplex: [],

        complainants: [],
        deletedComplainants: [],
        infringements: [],
        deletedInfringements: [],
        revIps: [],
        deletedRevIps: [],
        compositions: [],
        othAttachments: [],
        othDeletedAttachments: []
    });

    constructor(
        private route: ActivatedRoute,
        private fb: FormBuilder,
        public authService: AuthenticationService,
        private ceIpService: CeIpService,
        private commonService: CommonService,
        private formUtil: FormUtil) { }

    ngOnInit() {
        this.commonService.getStatusesByCategoryCode(cnst.StatusCategories.STAT_CE_CASE).subscribe(data => this.caseStatuses = data);
        this.form.get("id").setValue(+this.route.snapshot.paramMap.get('id'));
    }

    ngAfterViewInit() {
        this.loadCase();
    }

    get caseId() {
        return this.form.get("id").value;
    }

    loadCase() {
        this.ceIpService.loadCase(this.caseId).subscribe(
            data => {
                this.ceCase = data;
                this.form.patchValue(data);
                this.isDisabled = this.form.value.status.key == cnst.CeCaseStatus.CLOSED;
                this.ceIpProfileComponent.set(data, this.caseStatuses);
                this.attachmentComponent.set(data.othAttachments);
            },
            error => {

            }
        );
    }

    saveCase() {
        if (this.form.value.status.key == cnst.CeCaseStatus.CLOSED) {
            if (this.ceIpProfileComponent.isValid()) {
                this.isDisabled = true;
                this.save();
            }
            else {
                this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
            }
        }
        else {
            this.save();
        }
    }

    save() {
        this.form.patchValue(this.ceIpProfileComponent.getFormData().value);
        this.form.get('othAttachments').setValue(this.attachmentComponent.attachments.value);
        this.form.get('othDeletedAttachments').setValue(this.attachmentComponent.deletedAttachements.value);
        console.log(this.form)
        this.ceIpService.saveCase(this.form.value).subscribe(
            data => {
                this.loadCase();
                this.commonService.popSnackbar(null, 'success-snackbar');
            },
            error => {
            }
        );
    }

}
