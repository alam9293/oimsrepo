import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatTooltipModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';
import { BackModule } from '../../../common/modules/back/back.module';
import { MainMaterialModule } from './../../main.material';

import { CeIpComponent } from './ce-ip.component';
import { CeIpProfileModule } from './ce-ip-profile/ce-ip-profile.module';
import { SharedModule } from 'src/app/common/modules/shared.module';
import { AttachmentModule } from '../../../common/modules/attachment/attachment.module';
import { CeCaseDetailsModule } from '../ce-case/ce-case-details/ce-case-details.module';
import { CeCaseModule } from '../ce-case/ce-case.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MainMaterialModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatTabsModule,
        MatIconModule,
        MatInputModule,
        FlexLayoutModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSortModule,
        MatTableModule,
        MatDialogModule,
        MatTooltipModule,
        MatButtonToggleModule,
        RouterModule,
        BackModule,
        MatDatepickerModule,
        MatSidenavModule,
        SharedModule,
        CeIpProfileModule,
        AttachmentModule,
        CeCaseModule,
    ],
    declarations: [
        CeIpComponent,
    ],
    exports: [
        CeIpComponent,
    ],
    entryComponents: [],
})
export class CeIpModule { }
