import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class CeIpService {

    baseUrl = cnst.apiBaseUrl + cnst.CeApiUrl.CE_IP;

    constructor(private http: HttpClient) { }

    loadCase(caseId: number): Observable<any> {
        return this.http.get(this.baseUrl + '/view/' + caseId);
    }

    loadCompo(caseId: number): Observable<any> {
        return this.http.get(this.baseUrl + '/view/composition/' + caseId);
    }

    loadCompoWorkflow(caseId: number): Observable<any> {
        return this.http.get(this.baseUrl + '/view/composition-workflow/' + caseId);
    }

    getRevIp(caseNo: any): Observable<any> {
        return this.http.get(this.baseUrl + '/view/relevant', { params: { caseNo: caseNo } });
    }

    search(idTypeCode, uenUin): Observable<any> {
        return this.http.get(this.baseUrl + '/view/licence/' + idTypeCode + '/' + uenUin);
    }

    saveCase(formData: any): Observable<any> {
        return this.http.post(this.baseUrl + '/save', formData);
    }

    submitAction(formData: any, action: string) {
        return this.http.post(this.baseUrl + '/composition/' + action + '/' + formData.id, formData);
    }

    getProvisionDropdown(taTgType): Observable<any> {
        return this.http.get(cnst.apiBaseUrl + cnst.CeApiUrl.CE_PROVISION + '/view/dropdown/provision-read-with/' + taTgType);
    }

}