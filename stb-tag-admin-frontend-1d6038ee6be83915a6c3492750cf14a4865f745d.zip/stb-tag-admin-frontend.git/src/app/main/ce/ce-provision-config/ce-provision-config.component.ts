import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { CommonService } from '../../../common/services';
import { CeProvisionConfigService } from './ce-provision-config.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatPaginator, MatSort } from '@angular/material';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import * as cnst from '../../../common/constants';
import * as _ from 'lodash';
import { FormUtil } from '../../../common/helper';

@Component({
    selector: 'app-ce-provision-config',
    templateUrl: './ce-provision-config.component.html',
    styleUrls: ['./ce-provision-config.component.scss']
})
export class CeProvisionConfigComponent implements OnInit {

    constructor(private commonService: CommonService,
        private service: CeProvisionConfigService,
        public dialog: MatDialog, public formUtil: FormUtil) { }
    chapters: any = [];
    selectedChapter: any;
    provisionList: any = [];
    readWithList: any = [];
    displayedColumns = ['no', 'section', 'label', 'description', 'effectiveDate', 'inEffectiveDate', 'isOffence', 'isReadWithOnly', 'edit'];
    displayedTable: any = 'PROVISIONS';

    ngOnInit() {
        this.commonService.getCeProvisionChapters().subscribe(data => {
            this.chapters = data;
            this.selectedChapter = this.chapters[0].key;
            this.loadProvisions();
        });
    }

    loadProvisions() {

        this.service.getProvisions(this.selectedChapter).subscribe(data => {

            this.readWithList = [];
            this.provisionList = [];
            for (let record of data) {
                if (record.isReadWithOnly) {
                    this.readWithList.push(record);
                } else {
                    this.provisionList.push(record);
                }
            }

        });
    }

    openInactiveProvisionDialog() {
        let dialog = this.dialog.open(InactiveCeProvisionConfigComponent, {
            data: { selectedChapter: this.selectedChapter, readwithOrProvision: this.displayedTable, chapters: this.chapters },
        });
        dialog.afterClosed().subscribe(result => {
            if (result && result.toRefresh) {
                this.loadProvisions();
            }
        });
    }

    updateProvision(i) {
        if (this.displayedTable == 'PROVISIONS') {
            this.openEditProvisionDialog(this.provisionList[i]);

        } else {
            this.openEditProvisionDialog(this.readWithList[i]);
        }
    }

    addProvision() {
        this.openEditProvisionDialog({});
    }
    openEditProvisionDialog(provision) {
        let dialog = this.dialog.open(EditCeProvisionConfigComponent, {
            data: { chapters: this.chapters, provision: provision, selectedChapter: this.selectedChapter },
        });
        dialog.afterClosed().subscribe(result => {
            if (result && result.toRefresh) {
                this.loadProvisions();
            }
        });
    }

}


@Component({
    selector: 'dialog-inactive-ce-provision',
    templateUrl: './dialog-inactive-ce-provision.html',
    styleUrls: ['./ce-provision-config.component.scss']
})
export class InactiveCeProvisionConfigComponent implements OnInit {

    constructor(private commonService: CommonService, private service: CeProvisionConfigService,
        public dialogRef: MatDialogRef<InactiveCeProvisionConfigComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog) { }

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    provisionList: any = [];
    displayedColumns = ['no', 'section', 'label', 'description', 'effectiveDate', 'inEffectiveDate', 'isOffence', 'isReadWithOnly', 'edit'];
    selectedChapter: any;
    readwithOrProvision: any;
    filter: any = {};
    cnst = cnst;
    chapters: [];
    toRefresh: Boolean = false;

    ngOnInit() {
        this.dialogRef.disableClose = true;
        this.selectedChapter = this.data.selectedChapter;
        this.readwithOrProvision = this.data.readwithOrProvision;
        this.chapters = this.data.chapters;
        this.loadInactiveProvision();

    }

    loadInactiveProvision() {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, false, null);
        this.service.getInactiveProvisions(this.selectedChapter, this.readwithOrProvision, this.filter).subscribe(data => {
            this.provisionList = data.records;
            this.paginator.length = data.total;
        });
    }

    updateProvision(i) {
        this.openEditProvisionDialog(this.provisionList[i]);
    }

    openEditProvisionDialog(provision) {
        let dialog = this.dialog.open(EditCeProvisionConfigComponent, {
            data: { chapters: this.chapters, provision: provision, selectedChapter: this.selectedChapter },
        });
        dialog.afterClosed().subscribe(result => {
            if (result && result.toRefresh) {
                this.loadInactiveProvision();
                this.toRefresh = true;
            }
        });
    }
    closeDialog() {
        this.dialogRef.close({ toRefresh: this.toRefresh });
    }
}

@Component({
    selector: 'dialog-edit-ce-provision',
    templateUrl: './dialog-edit-ce-provision.html',
    styleUrls: ['./ce-provision-config.component.scss']
})
export class EditCeProvisionConfigComponent implements OnInit {

    constructor(private commonService: CommonService, private service: CeProvisionConfigService,
        public dialogRef: MatDialogRef<EditCeProvisionConfigComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any, private formBuilder: FormBuilder, public formUtil: FormUtil) { }


    cnst = cnst;
    chapters: any = [];
    selectedChapter: any;
    provision: FormGroup = this.formBuilder.group({
        id: [''],
        section: ['', Validators.required],
        label: [''],
        description: [''],
        isOffence: [false],
        isReadWithOnly: [false],
        effectiveDate: ['', Validators.required],
        ineffectiveDate: [''],
        chapter: this.formBuilder.group({
            key: ['', Validators.required],
            label: ['']
        }),
        readWiths: [],
    });
    readWithsOptions: any = [];
    readWithsOptionsGroped: any = [{ 'groupName': 'Active', items: [] }, { 'groupName': 'Inactive', items: [] }];


    ngOnInit() {
        this.dialogRef.disableClose = true;
        this.selectedChapter = this.data.selectedChapter;
        this.chapters = this.data.chapters;
        this.patchProvision(this.data.provision);

        // getting ReadWiths for drop down list option. 
        // results are group into "inactive" and "active" for better aesthetic view in the drop down list
        this.service.getAllReadWithsByChapters(this.selectedChapter).subscribe(data => {
            this.readWithsOptions = data;
            data.forEach(element => {
                if (element.otherLabel == 'active') {
                    this.readWithsOptionsGroped[0].items.push(element);
                } else {
                    this.readWithsOptionsGroped[1].items.push(element);

                }
            });
        });
    }

    patchProvision(provision) {
        // 1. patching direct details
        this.provision.patchValue(provision);

        // 2. patching ReadWiths
        let readWiths = [];
        if (provision.readWiths) {
            provision.readWiths.forEach(readWith => {
                readWiths.push(readWith.id);
            });
        }
        this.provision.get('readWiths').patchValue(readWiths);


    }

    saveProvision() {
        // 1. checking if form is valid
        if (this.provision.valid) {

            // 2. reconstructing ReadWiths into DTO format
            let readWithsArray = [];
            this.provision.get('readWiths').value.forEach(readWith => {
                readWithsArray.push({ id: readWith });
            });
            this.provision.get('readWiths').patchValue(readWithsArray);

            // 3. calling backend to save
            this.service.saveProvision(this.provision.value).subscribe(data => {
                this.commonService.popSnackbar(null, 'success-snackbar');
                this.closeDialog(true);
            }, error => {
                this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
            });
        }

    }

    closeDialog(toRefresh) {
        this.dialogRef.close({ toRefresh: toRefresh });
    }


}