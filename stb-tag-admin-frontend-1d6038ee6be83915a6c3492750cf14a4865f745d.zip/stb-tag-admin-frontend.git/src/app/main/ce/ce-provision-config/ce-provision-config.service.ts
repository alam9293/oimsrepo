import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class CeProvisionConfigService {

    baseUrl = cnst.apiBaseUrl + cnst.CeApiUrl.CE_PROVISION;

    constructor(private http: HttpClient) { }

    getProvisions(chapter): Observable<any> {
        return this.http.get(this.baseUrl + '/view/' + chapter);
    }

    getInactiveProvisions(chapter, readwithOrProvision, searchDto): Observable<any> {
        return this.http.get(this.baseUrl + '/view/inactive/' + chapter + '/' + readwithOrProvision, { params: searchDto });
    }

    getAllReadWithsByChapters(chapter): Observable<any> {
        return this.http.get(this.baseUrl + '/view/dropdown/read-with-only/' + chapter);
    }

    saveProvision(provision: any): Observable<any> {
        return this.http.post(this.baseUrl + '/save', provision);
    }

}