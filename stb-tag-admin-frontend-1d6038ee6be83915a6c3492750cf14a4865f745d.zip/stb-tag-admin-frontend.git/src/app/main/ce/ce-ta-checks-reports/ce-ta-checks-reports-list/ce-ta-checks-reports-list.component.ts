import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import * as cnst from '../../../../common/constants';
import { CeTaChecksReportsListService } from './ce-ta-checks-reports-list.service';
import { WorkflowHelper, StyleHelper } from '../../../../common/helper';
import { CommonService } from 'src/app/common/services';
@Component({
    selector: 'app-ce-ta-checks-reports-list',
    templateUrl: './ce-ta-checks-reports-list.component.html',
    styleUrls: ['./ce-ta-checks-reports-list.component.scss']
})
export class CeTaChecksReportsListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    listingId = "ce-ta-checks-reports-list";
    myApplications: boolean = true;
    types: any = [];
    filter: any = {};
    cnst = cnst;
    displayedColumns = ['no', 'scheduledDate', 'eoUser', 'taName', 'addressType', 'checkType', 'tatiCheckId', 'fieldReportId', 'caseId'];
    rows = [];

    constructor(
        private ceTaChecksReportsListService: CeTaChecksReportsListService,
        public workflowHelper: WorkflowHelper,
        private commonService: CommonService,
        public styleHelper: StyleHelper,
    ) { }

    ngOnInit() {
        this.loadCeScheduleList(true);
        //Check type
        this.commonService.getTaCheckTypes().subscribe(data => {
            this.types = data;
        });
    }

    setMyApplicationsAndDefaultAppStatus(fromInit: boolean) {
        if (this.filter.isFromCache) {
            this.myApplications = this.filter.myApplications; // as long as cache is found for this listingId, use the cache and toggle myApplications flag
        } else {
            this.filter.myApplications = this.myApplications; // if not, searchDto should include myApplications flag before firing to server
            if (fromInit) {
                if (status) {
                    this.filter.applicationStatuses = status; // if this is a new init (fromInit + no cache), set default app status
                }
            }
        }
    }

    loadCeScheduleList(fromInit: boolean): void {
        this.workflowHelper.selection = new SelectionModel<any>(true, []);
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromInit, this.listingId);
        this.setMyApplicationsAndDefaultAppStatus(fromInit);
        this.ceTaChecksReportsListService.getCeScheduleList(this.filter).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }
}
