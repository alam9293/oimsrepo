import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class CeTaFieldReportService {

    constructor(private http: HttpClient) { }

    loadTaFieldReport(searchData): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TA_FIELD_REPORT + '/view/', { params: searchData });
    }

    save(params: any) {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TA_FIELD_REPORT + '/save', params);
    }

    updateSignDocResult(searchData): Observable<any> {
        return this.http.post<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TA_FIELD_REPORT + '/submit/update-sign-doc-result/', searchData);
    }
}
