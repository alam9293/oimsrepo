import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators, ValidatorFn, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { FormUtil, MinSelectedCheckboxes } from 'src/app/common/helper';
import { CommonService, AuthenticationService } from 'src/app/common/services';
import * as cnst from '../../../../common/constants';
import { CeTaChecksReportsListService } from '../ce-ta-checks-reports-list/ce-ta-checks-reports-list.service';
import { CeTaFieldReportService } from './ce-ta-field-report-view.component.service';
import { ListableDto } from 'src/app/common/models';
import { AttachmentComponent } from '../../../../common/modules/attachment/attachment.component';
import { Location } from '@angular/common';
import { MatDialogRef, MatDialog } from '@angular/material';
// import { TasklistDialogComponent } from 'src/app/common/modules/tasklist/tasklist.component';
@Component({
    selector: 'app-ce-ta-field-report-view',
    templateUrl: './ce-ta-field-report-view.component.html',
    styleUrls: ['./ce-ta-field-report-view.component.scss']
})
export class CeTaFieldReportViewComponent implements OnInit {
    @ViewChild(AttachmentComponent) ceTaFieldReportAttachmentsComponent: AttachmentComponent;
    dialogRef: MatDialogRef<any>;
    dataSearch: any = {};
    cnst = cnst;
    form: FormGroup;
    declarationText: any
    nationalities: any;
    premisesTypes: any;
    addressTypes: any;
    auxEoUsers: any;
    application: any = { disableEdit: false, submissionStatus: { key: '', label: '' } };
    ceProvisionForm: any;
    classifications: ListableDto[] = [];;
    classificationObject$;
    currentUser: any;
    constructor(
        private route: ActivatedRoute,
        private fb: FormBuilder,
        private formUtil: FormUtil,
        private commonService: CommonService,
        private ceTaFieldReportService: CeTaFieldReportService,
        private ceTaChecksReportsListService: CeTaChecksReportsListService,
        public authenticationService: AuthenticationService,
        private location: Location,
        private dialog: MatDialog,
    ) { }
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        //Ta classifications
        this.classifications = this.route.snapshot.data.classifications;
        this.loadMasterData();
        this.initiateForm(false);
        if (this.route.snapshot.queryParamMap.get('ceTaCheckScheduleItemId')) {
            this.dataSearch.ceTaCheckScheduleItemId = this.route.snapshot.queryParamMap.get('ceTaCheckScheduleItemId')
        }
        if (this.route.snapshot.queryParamMap.get('ceCaseId')) {
            this.dataSearch.ceCaseId = this.route.snapshot.queryParamMap.get('ceCaseId')
        }
        if (this.route.snapshot.queryParamMap.get('ceTaFieldReportId')) {
            this.dataSearch.ceTaFieldReportId = this.route.snapshot.queryParamMap.get('ceTaFieldReportId')
        }
        if (this.route.snapshot.queryParamMap.get('sdweb_result')) {
            this.dataSearch.sdweb_result = this.route.snapshot.queryParamMap.get('sdweb_result')
        }
        if (this.route.snapshot.queryParamMap.get('sdweb_docid')) {
            this.dataSearch.sdweb_docid = this.route.snapshot.queryParamMap.get('sdweb_docid')
        }
        if (this.route.snapshot.queryParamMap.get('sdweb_result')) {
            this.updateSignDocResult(this.dataSearch);
        } else {
            if (this.dataSearch) {
                this.loadTaFieldReport(this.dataSearch);
            }
        }
    }

    // openAddTaDialog() {
    //     const addTaDialogRef = this.addTaDialogService.openDialog(
    //         {
    //             masterData: this.masterData, scheduleItems: this.editableScheduleComp.rows.data, scheduler: this.schedule.oic
    //         }
    //     );

    //     addTaDialogRef.afterClosed().subscribe(result => {
    //         if (result) {
    //             this.editableScheduleItems = result.scheduleItems;
    //         }
    //     });
    // }

    get f() {
        return this.form.controls;
    }

    get adressFormControl() {
        return (this.form.get('taDetailsDto.addressDto') as FormGroup).controls
    }

    get personDetailsForm() {
        return (this.form.get('personDetailsDto') as FormGroup)
    }

    get taDetailsForm() {
        return (this.form.get('taDetailsDto') as FormGroup)
    }

    get auxEoFormControl() {
        return (this.form.get('auxEo') as FormGroup).controls
    }

    get ceClassificationForms() {
        return this.form.get('ceClassificationDtos') as FormArray
    }

    get taDetailsFormControls() {
        return (this.form.get('taDetailsDto') as FormGroup).controls
    }

    loadTaFieldReport(searchData) {
        this.ceTaFieldReportService.loadTaFieldReport(searchData).subscribe(data => {
            this.application = data;
            this.setupForm(this.application);
        }, error => {

        })
    }

    updateSignDocResult(searchData) {
        this.ceTaFieldReportService.updateSignDocResult(searchData).subscribe(data => {
            this.loadTaFieldReport(searchData);
            if (searchData.sdweb_result === "success") {
                var msg = '';
                msg = 'Field report submitted successfully and case is created.';
                this.commonService.popSnackbar(msg, 'success-snackbar');
            }
        }, error => {

        })
    }

    private setupForm(application: any) {
        this.form.patchValue(application);
        if (application.ceClassificationDtos) {
            application.ceClassificationDtos.forEach(item => {
                this.ceProvisionForm = this.initiateProvisionForm();
                this.ceProvisionForm.patchValue(item);
                this.ceClassificationForms.push(this.ceProvisionForm);
            });
        }

        if (this.classifications) {
            this.classifications.forEach((o, i) => {
                const control = new FormControl(application.classificationsSelected ? application.classificationsSelected.includes(o.key) : false); // if selected set to true, else false
                (this.ceClassificationForms).push(control);
            });
        }

        (this.ceClassificationForms).valueChanges.subscribe(values => {
            var index = this.classifications.length - 1; //see if the last classification (Others) is selected
            if (!values[index]) {
                this.form.get('otherClassification').patchValue(null);
            }
        });

        if (application.attachments) {
            this.ceTaFieldReportAttachmentsComponent.set(application.attachments);
        }
        if (!this.authenticationService.hasPermission('CE_FIELD_REPORT_SAVE') || this.application.disableEdit) {
            this.form.disable();
        }
        if (this.application.submissionStatus.key === cnst.Statuses.STAT_CE_SUBMISSION_SUBMITTED) {
            this.form.get('isChecked').patchValue(true);
        }
        if (this.dataSearch.ceTaCheckScheduleItemId) {
            this.form.get('toRevisit').setValidators([Validators.required]);
        }

    }
    initiateProvisionForm(): any {
        return (this.fb.group({
            id: '',
            isYes: false,
        }, {}));
    }

    initiateForm(isChecked) {
        this.form = this.fb.group({
            isChecked: isChecked,
            toSubmit: false,
            toRevisit: [null,],
            ceTaCheckScheduleItemId: '',
            caseNo: '',
            ceCaseId: '',

            ceTaFieldReportId: [,],
            isAcknowledged: [,],
            taDetailsDto: this.taDetailsDto(this.fb),

            personDetailsDto: this.personDetailsDto(this.fb),
            travelAgentOfficerName: [],
            auxEo: this.formUtil.listableForm(this.fb, false),
            details: '',
            classificationsSelected: '',
            ceClassificationDtos: new FormArray([], MinSelectedCheckboxes(1)),
            otherClassification: '',
            attachments: [],
            deletedAttachements: [],
        });
    }

    taDetailsDto(fb: FormBuilder) {
        return (
            fb.group({
                addressType: this.formUtil.listableForm(this.fb, false),
                addressDto: this.formUtil.addressFormOptional(this.fb, false),

                licenceNo: ['',],
                uen: ['',],
                taName: ['',],
                taContactNo: ['',],
            })
        )
    }

    personDetailsDto(fb: FormBuilder) {
        return (
            fb.group({
                uinPassportNo: ['',],
                name: ['',],
                role: ['',],
                personContactNo: ['',],
                // nationality: this.formUtil.listableForm(this.fb, false),
            })
        )
    }

    loadMasterData() {
        //Ta classifications
        //  this.commonService.getCeTaFieldReportClassifications().subscribe(data => { this.classifications = data });
        //Yes,No, NA flag
        this.commonService.getNationalities().subscribe(data => { this.nationalities = data });
        //premises types
        this.commonService.getPremiseTypes().subscribe(data => { this.premisesTypes = data; });
        //ta address types
        this.commonService.getTaAddressTypes().subscribe(data => { this.addressTypes = data; });
        //EO users
        this.commonService.getCeTaAuxEoUsers().subscribe(data => { this.auxEoUsers = data; });

        //Declaration text
        this.commonService.getSystemParameter(cnst.SystemParameters.CE_TA_CHECKS_DECLARATION).subscribe(data => {
            this.declarationText = data.label;
        });

    }

    searchByLicenceNo(licenceNo) {
        this.ceTaChecksReportsListService.getTaDetailsFromLicenceNo(licenceNo).subscribe(data => {
            this.taDetailsForm.reset();
            this.taDetailsForm.patchValue(data)
        }, error => {

        })
    }

    searchByUin(uin) {
        this.ceTaChecksReportsListService.getPersonDetailsFromUin(uin).subscribe(data => {
            this.personDetailsForm.reset();
            this.personDetailsForm.patchValue(data)
        }, error => {

        })
    }


    submit(toSubmit) {
        this.form.get('toSubmit').patchValue(toSubmit);
        this.formUtil.markFormGroupTouched(this.form);
        if ((toSubmit && this.form.get('isChecked') && this.form.valid) || !toSubmit) {
            if (this.ceTaFieldReportAttachmentsComponent.attachmentForm) {
                this.form.get('attachments').setValue(this.ceTaFieldReportAttachmentsComponent.attachments.value);
                this.form.get('deletedAttachements').setValue(this.ceTaFieldReportAttachmentsComponent.deletedAttachementIds.value);
            }
            const selectedClassifications = this.form.value.ceClassificationDtos
                .map((v, i) => v ? this.classifications[i].key : null)
                .filter(v => v !== null);
            this.form.get('classificationsSelected').patchValue(selectedClassifications);
            this.ceTaFieldReportService.save(this.form.value).subscribe(searchDto => {
                this.form.markAsPristine();
                this.initiateForm(this.form.get('isChecked'));
                this.dataSearch.ceTaFieldReportId = searchDto['ceTaFieldReportId'];
                if (searchDto['ceCaseId']) {
                    this.dataSearch.ceCaseId = searchDto['ceCaseId'];
                }
                this.loadTaFieldReport(this.dataSearch);
                if (toSubmit) {
                    this.location.back();
                }
                this.commonService.popSnackbar(toSubmit ? 'Field report submitted successfully.' : 'Field report saved successfully.', 'success-snackbar');
            }),
                error => {
                    this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                };
        } else {
            this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
        }

    }

    // addCase() {
    //     // let internalItemCaseNo = this.items.value.filter(item => { return item.typeCode == cnst.RevIpType.INTERNAL }).map(item => { return item.caseNo });
    //     // internalItemCaseNo.push(this.caseNo);

    //     this.dialogRef = this.dialog.open(TasklistDialogComponent, {
    //         data: {
    //             title: "Select IP",
    //             isIp: true,
    //             //  internalItemCaseNo: internalItemCaseNo
    //         },
    //         panelClass: 'full-screen-modal',
    //     });
    //     this.dialogRef.afterClosed().subscribe(result => {
    //         //if (result.caseNo) {
    //         //  this.ceIpService.getRevIp(result.caseNo).subscribe(data => {
    //         //      this.add(data);
    //         //  });
    //         //}
    //     });
    // }

    disableSubmit() {
        return !this.application.ceTaFieldReportId || !this.form.value.isChecked || !this.form.pristine || !this.ceTaFieldReportAttachmentsComponent.f.pristine;
    }
}