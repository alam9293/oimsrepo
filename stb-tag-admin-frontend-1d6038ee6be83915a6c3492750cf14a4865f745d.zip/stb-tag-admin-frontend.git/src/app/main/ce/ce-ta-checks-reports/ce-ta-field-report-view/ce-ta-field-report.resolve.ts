import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { CommonService } from 'src/app/common/services';
import { ListableDto } from "../../../../common/models/common-dto";

@Injectable({
    providedIn: 'root'
})
export class CeTaFieldReportViewResolve implements Resolve<ListableDto[]> {
    constructor(private commonService: CommonService) { }

    resolve(route: ActivatedRouteSnapshot): Observable<ListableDto[]> {
        return this.commonService.getCeTaFieldReportClassifications();
    }
}  