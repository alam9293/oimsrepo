import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialogRef, MatDialog } from '@angular/material';
import * as cnst from '../../../../common/constants';
import { CeTatiCheckAckService } from './ce-tati-check-ack.service'
import { WorkflowHelper, StyleHelper } from '../../../../common/helper';
import { CommonService } from 'src/app/common/services';
import { ConfirmationDialogComponent } from 'src/app/common/modules/confirmation-dialog/confirmation-dialog.component';

@Component({
    selector: 'app-ce-tati-check-ack',
    templateUrl: './ce-tati-check-ack.component.html',
    styleUrls: ['./ce-tati-check-ack.component.scss']
})
export class CeTatiCheckAckComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    listingId = "ce-ta-checks-reports-list";
    scheduleYears: any = [];
    scheduleMonths: any = [];
    filter: any = {};
    cnst = cnst;
    displayedColumns = ['select', 'no', 'checkedDate', 'taName', 'licenceNo', 'uen', 'isCompliant', 'eoUser', 'tatiCheckId', 'ceCaseId', 'daysLeftToAcknowledge'];
    rows = new MatTableDataSource<any>();
    selection = new SelectionModel<any>(true, []);

    constructor(
        private ceTatiCheckAckService: CeTatiCheckAckService,
        public workflowHelper: WorkflowHelper,
        private commonService: CommonService,
        public styleHelper: StyleHelper,
        private dialog: MatDialog,
    ) { }

    ngOnInit() {
        this.loadTaTiForAcknowledgement();
    }

    ngAfterViewInit(): void {
        // Sorting with nested objects
        this.rows.sortingDataAccessor = (item, property) => {
            switch (property) {
                case 'taName': return item.taDetailsDto.taName;
                case 'licenceNo': return item.taDetailsDto.licenceNo;
                case 'uen': return item.taDetailsDto.uen;
                case 'isCompliant': return item.isCompliant.label;
                case 'caseNo': return item.caseNo;
                case 'createdDate': return item.daysLeftToAcknowledge;
                case 'eoUser': return item.eoUserDto.name;
                default: return item[property];
            }
        };
        this.rows.sort = this.sort;
    }

    loadTaTiForAcknowledgement(): void {
        this.paginator.pageSize = this.paginator.pageSize ? this.paginator.pageSize : cnst.PAGINATION.DEFAULT_PAGE_SIZE;

        this.ceTatiCheckAckService.getListForAcknowledgement(false).subscribe(data => {
            this.rows.data = data;
            this.rows.paginator = this.paginator;
            this.rows.sort = this.sort;
        })
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.rows.data.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.rows.data.forEach(row => this.selection.select(row));
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    acknowledgeSelected() {
        if (this.selection.selected.length < 1) {
            this.commonService.popSnackbar('Please select at least 1 record', 'error-snackbar');
        } else {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: 'Action: Acknowledge TATI Checks as Compliant',
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    let ids = [];
                    this.selection.selected.forEach(row => {
                        ids.push(row.ceTaCheckId);
                    });
                    this.ceTatiCheckAckService.acknowledgeCeTaCheck(ids).subscribe(
                        data => {
                            this.selection.clear();
                            this.loadTaTiForAcknowledgement();
                            this.commonService.popSnackbar(null, 'success-snackbar');
                        })
                }
            });
        }
    }
}
