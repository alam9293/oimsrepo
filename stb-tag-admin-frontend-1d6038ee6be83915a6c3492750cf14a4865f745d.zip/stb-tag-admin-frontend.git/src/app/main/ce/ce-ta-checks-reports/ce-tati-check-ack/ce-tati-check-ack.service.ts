import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class CeTatiCheckAckService {

    constructor(private http: HttpClient) { }

    getListForAcknowledgement(isAcknowledged): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TA_TATI_CHECK + '/view/acknowledgement/' + isAcknowledged);
    }

    acknowledgeCeTaCheck(ids): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TA_TATI_CHECK + '/acknowledge', ids);
    }

}
