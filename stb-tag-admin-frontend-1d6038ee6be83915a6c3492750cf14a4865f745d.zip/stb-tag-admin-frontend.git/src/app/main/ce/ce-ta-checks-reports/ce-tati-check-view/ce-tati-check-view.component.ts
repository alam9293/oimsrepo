import { Component, HostListener, OnInit, ViewChild, ViewChildren, QueryList, ViewContainerRef, ComponentFactory, ComponentFactoryResolver } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { CommonService, AuthenticationService } from 'src/app/common/services';
import * as cnst from '../../../../common/constants';
import { FileUtil, FormUtil } from '../../../../common/helper';
import { CeTaChecksReportsListService } from '../ce-ta-checks-reports-list/ce-ta-checks-reports-list.service';
import { CeTatiCheckViewService } from './ce-tati-check-view.service';
import { Location } from '@angular/common';
import { AttachmentComponent } from 'src/app/common/modules/attachment/attachment.component';
@Component({
    selector: 'app-ce-tati-check-view',
    templateUrl: './ce-tati-check-view.component.html',
    styleUrls: ['./ce-tati-check-view.component.scss']
})

export class CeTatiCheckViewComponent {
    @ViewChild('att') ceTaCheckAttachmentsComponent: AttachmentComponent;
    dataSearch: any = {};
    declarationText: any
    introDescription: any;
    hideRequired: any = false;
    form: FormGroup;
    signDoc: FormGroup = this.fb.group({
        docid: "2019-10-24_6-6-23_559",
        template: "TrapezaOpenJointAccounts.pdf",
        resulturl: "https://trust-dev.stb.gov.sg/sdweb/result/index?showoptions=true",
    })
    application: any = { ceTaCheckType: { key: '' }, submissionStatus: { key: '', label: '' }, eoUserDto: { loginId: '' }, isCompliant: {} };
    tatiCheckQnForm: FormGroup;
    taCheckDocumentForm: FormGroup;
    fileForm: FormGroup;
    cnst = cnst;
    flagList: any;
    premisesTypes: any;
    addressTypes: any;
    eoUsers: any;
    // checkStatuses: any;
    selectedFile: File;
    fileColumns = ['fileName', 'description', 'fileSize', 'details', 'Action'];
    constructor(
        private route: ActivatedRoute,
        private fb: FormBuilder,
        private formUtil: FormUtil,
        private ceTatiCheckViewService: CeTatiCheckViewService,
        private commonService: CommonService,
        public fileUtil: FileUtil,
        private ceTaChecksReportsListService: CeTaChecksReportsListService,
        private location: Location,
        private authenticationService: AuthenticationService,
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.initiateForm(false);
        this.loadMasterData();
        if (this.route.snapshot.queryParamMap.get('ceTaCheckScheduleItemId')) {
            this.dataSearch.ceTaCheckScheduleItemId = this.route.snapshot.queryParamMap.get('ceTaCheckScheduleItemId')
        }
        if (this.route.snapshot.queryParamMap.get('ceTaCheckId')) {
            this.dataSearch.ceTaCheckId = this.route.snapshot.queryParamMap.get('ceTaCheckId')
        }
        if (this.route.snapshot.queryParamMap.get('sdweb_result')) {
            this.dataSearch.sdweb_result = this.route.snapshot.queryParamMap.get('sdweb_result')
        }
        if (this.route.snapshot.queryParamMap.get('sdweb_docid')) {
            this.dataSearch.sdweb_docid = this.route.snapshot.queryParamMap.get('sdweb_docid')
        }
        if (this.route.snapshot.queryParamMap.get('sdweb_result')) {
            this.updateSignDocResult(this.dataSearch);
        } else {
            if (this.dataSearch) {
                this.loadTaCheck(this.dataSearch);
            }
        }
    }

    loadTaCheck(searchData) {
        this.ceTatiCheckViewService.loadTatiComplianceCheck(searchData).subscribe(data => {
            this.application = data;
            this.setupForm(this.application);

        }, error => {

        })
    }

    updateSignDocResult(searchData) {
        this.ceTatiCheckViewService.updateSignDocResult(searchData).subscribe(data => {
            this.loadTaCheck(searchData);
            if (searchData.sdweb_result === "success") {
                var msg = '';
                msg = 'Result of check submitted successfully and case is created.';
                this.commonService.popSnackbar(msg, 'success-snackbar');
            }
        }, error => {

        })
    }

    get f() {
        return this.form.controls;
    }

    get qnForms() {
        return this.form.get('ceTaCheckQnResponseDto') as FormArray
    }

    get generalQnForms() {
        return this.form.get('ceTaCheckQnResponseGeneralDto') as FormArray
    }

    get documentForms() {
        return this.form.get('ceTaCheckDocumentDto') as FormArray
    }

    get fileForms() {
        return this.form.get('files') as FormArray
    }

    get adressFormControl() {
        return (this.form.get('taDetailsDto.addressDto') as FormGroup).controls
    }

    get auxEoFormControl() {
        return (this.form.get('auxEo') as FormGroup).controls
    }

    get premisesTypeFormControl() {
        return (this.form.get('taDetailsDto.addressDto.premisesType') as FormGroup).controls
    }

    get taDetailsFormControls() {
        return (this.form.get('taDetailsDto') as FormGroup).controls
    }

    get taDetailsForm() {
        return (this.form.get('taDetailsDto') as FormGroup)
    }

    initiateForm(isChecked) {
        this.form = this.fb.group({
            isChecked: isChecked,
            toSubmit: false,
            ceTaCheckScheduleItemId: '',
            scheduleMonth: '',
            scheduleyear: '',

            ceTaCheckId: [,],
            isAcknowledged: [,],
            lastAcknowledgedDate: [,],
            toRevisit: [null, Validators.required],
            taDetailsDto: this.taDetailsDto(this.fb),
            taStaffName: ['',],
            taStaffDesignation: '',
            checkedDate: '',
            eoUserDto: this.fb.group({
                id: [''],
                name: [''],
            }),
            auxEo: this.formUtil.listableForm(this.fb, true),
            remarks: '',

            ceTaCheckQnResponseDto: this.fb.array([]),
            ceTaCheckQnResponseGeneralDto: this.fb.array([]),
            ceTaCheckDocumentDto: this.fb.array([]),
            checkDocumentsToDelete: this.fb.array([]),
            files: [],
            filesToDelete: this.fb.array([])
        });
    }

    taDetailsDto(fb: FormBuilder) {
        return (
            fb.group({
                addressType: this.formUtil.listableForm(this.fb, false),
                addressDto: this.formUtil.addressFormOptional(this.fb, false),
                licenceNo: ['', Validators.required],
                uen: ['', Validators.required],
                taName: ['', Validators.required],
                taKeUin: ['',],
                taKeName: ['',],
            })
        )
    }

    initiateTatiCheckQnForm() {
        return (this.fb.group({
            ceTaCheckQnId: '',
            ceTaCheckResponseId: '',
            isGeneral: '',
            isYes: false,
            remarks: '',
        }, {}));
    }

    initiateCheckDoc() {
        return (this.fb.group({
            id: '',
            invoiceBookingNo: '',
            totalPrice: '',
            noOfPax: '',
            paymentDepositMade: '',
            depositPricePerPax: '',
            isConsumerInformed: this.formUtil.listableForm(this.fb, true),
            files: this.fb.array([]),
            filesToDelete: this.fb.array([]),
            remarks: '',
        }, {}));
    }

    private setupForm(application: any) {
        this.form.patchValue(application);
        if (application.ceTaCheckType.key == cnst.ceCheckType.TA_CHECK_TATI) {
            this.form.get('taDetailsDto.addressDto.unit').setValidators([Validators.required]);
        } else {
            this.formUtil.removeAllValidators(this.form.get('auxEo') as FormGroup)
            this.formUtil.removeAllValidators(this.form.get('taDetailsDto') as FormGroup)
            this.hideRequired = true;
        }

        if (application.ceTaCheckQnResponseDto) {
            application.ceTaCheckQnResponseDto.forEach(item => {
                this.tatiCheckQnForm = this.initiateTatiCheckQnForm();
                this.tatiCheckQnForm.patchValue(item);
                this.qnForms.push(this.tatiCheckQnForm);
            });
        }
        if (application.ceTaCheckQnResponseGeneralDto) {
            application.ceTaCheckQnResponseGeneralDto.forEach(item => {
                this.tatiCheckQnForm = this.initiateTatiCheckQnForm();
                this.tatiCheckQnForm.patchValue(item);
                this.generalQnForms.push(this.tatiCheckQnForm);
            });
        }
        if (application.ceTaCheckDocumentDto) {
            application.ceTaCheckDocumentDto.forEach(item => {
                this.taCheckDocumentForm = this.initiateCheckDoc();
                this.taCheckDocumentForm.patchValue(item);
                if (this.taCheckDocumentForm.value.paymentDepositMade && this.taCheckDocumentForm.value.noOfPax) {
                    this.taCheckDocumentForm.get('depositPricePerPax').patchValue(this.taCheckDocumentForm.value.paymentDepositMade / this.taCheckDocumentForm.value.noOfPax);
                } else {
                    this.taCheckDocumentForm.get('depositPricePerPax').patchValue(0);
                }
                if (item.files) {
                    item.files.forEach(element => {
                        (this.taCheckDocumentForm.get('files') as FormArray).push(this.formUtil.populateAttachmentFormGroup(this.fb, element));
                    });
                }
                this.documentForms.push(this.taCheckDocumentForm);
            });

        }

        if (application.files) {

            this.ceTaCheckAttachmentsComponent.set(application.files);
        }

        if (!this.authenticationService.hasPermission('CE_TATI_SAVE') || this.application.disableEdit) {
            this.form.disable();
        }
        if (!this.application.isDraft) {
            this.form.get('isChecked').patchValue(true);
        }

    }

    addDocument() {
        this.taCheckDocumentForm = this.initiateCheckDoc();
        this.documentForms.push(this.taCheckDocumentForm);
        this.form.markAsDirty();
    }

    removeDocument(docDetails, index) {
        if (docDetails.controls.id.value) {
            (this.form.get('checkDocumentsToDelete') as FormArray).push(this.fb.control(docDetails.controls.id.value));
        }
        this.documentForms.removeAt(index);
        this.form.markAsDirty();
    }

    loadMasterData() {
        //Yes,No, NA flag
        this.commonService.getFlags().subscribe(data => { this.flagList = data });
        //premises types
        this.commonService.getPremiseTypes().subscribe(data => { this.premisesTypes = data; });
        //ta address types
        this.commonService.getTaAddressTypes().subscribe(data => { this.addressTypes = data; });
        //EO users
        this.commonService.getCeTaAuxEoUsers().subscribe(data => { this.eoUsers = data; });
        //Ta Compliance report introduction
        this.commonService.getSystemParameter(cnst.SystemParameters.CE_TATI_CHECK_INFO).subscribe(data => {
            this.introDescription = data.label;
        });
        //Declaration text
        this.commonService.getSystemParameter(cnst.SystemParameters.CE_TA_CHECKS_DECLARATION).subscribe(data => {
            this.declarationText = data.label;
        });
        // this.commonService.getCeTaCheckStatuses().subscribe(data => {
        //     this.checkStatuses = data;
        // })
    }

    countDepositPerPax(doc, i) {
        if (doc.controls.paymentDepositMade.value && doc.controls.noOfPax.value) {
            this.documentForms.at(i).get('depositPricePerPax').patchValue(doc.controls.paymentDepositMade.value / doc.controls.noOfPax.value);
        } else {
            this.documentForms.at(i).get('depositPricePerPax').patchValue(0);
        }
    }

    isPristine() {
        if (!this.form.pristine) {
            return false;
        }
        // if(){

        // }
    }

    submit(toSubmit) {
        console.log(this.form);
        this.form.get('toSubmit').patchValue(toSubmit);
        this.formUtil.markFormGroupTouched(this.form);
        if ((toSubmit && this.form.get('isChecked') && this.form.valid) || !toSubmit) {
            if (this.ceTaCheckAttachmentsComponent.attachmentForm) {
                this.form.get('files').setValue(this.ceTaCheckAttachmentsComponent.attachments.value);
                this.ceTaCheckAttachmentsComponent.deletedAttachementIds.controls.forEach(item => {
                    this.filesToDeleteIds.push(item);
                });
                // this.form.get('filesToDelete').setValue(this.ceTaCheckAttachmentsComponent.deletedAttachementIds.value);
            }

            this.ceTatiCheckViewService.save(this.form.value).subscribe(resultDto => {
                this.form.markAsPristine();
                this.initiateForm(this.form.get('isChecked'));
                this.dataSearch = { 'ceTaCheckId': resultDto['ceTaCheckId'] };
                this.loadTaCheck(this.dataSearch);
                var msg = '';
                if (resultDto['caseId']) {
                    msg = 'Result of check submitted successfully and case is created.';
                } else {
                    msg = 'Result of check submitted successfully.';
                }
                this.commonService.popSnackbar(+ toSubmit ? msg : 'Result of check saved successfully', 'success-snackbar');
                if (toSubmit) {
                    this.location.back();
                }
            }),
                error => {
                    this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                };
        } else {
            this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
        }
    }

    searchByLicenceNo(licenceNo) {
        this.ceTaChecksReportsListService.getTaDetailsFromLicenceNo(licenceNo).subscribe(data => {
            this.taDetailsForm.reset();
            this.form.get('taDetailsDto').patchValue(data)
        }, error => {

        })
    }

    onFileChanged(event, type, i) {
        this.selectedFile = event.target.files[0];
        var extension = this.selectedFile.name.substr(this.selectedFile.name.lastIndexOf('.'));
        if (cnst.FileExt.SIGN_DOC_ATTACHMENT.ext.includes(extension)) {
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                    this.documentFormFiles(i).push(this.formUtil.populateAttachmentFormGroup(this.fb, data));
                });
            }
            this.form.markAsDirty();
        } else {
            this.commonService.popSnackbar(cnst.FileExt.SIGN_DOC_ATTACHMENT.errorMsg, 'error-snackbar');
        }
    }

    disableSubmit() {
        return !this.application.ceTaCheckId || !this.form.value.isChecked || !this.form.pristine || !this.ceTaCheckAttachmentsComponent.f.pristine || !this.form.valid;
    }

    deleteInvAttachment(i, j, file) {
        this.documentFormFiles(i).removeAt(j);
        // this.documentFormFilesToDelete(i).push(file.value.id);
        this.filesToDeleteIds.push(file.get('id'))
        this.form.markAsDirty();
    }

    documentFormFiles(i) {
        return this.documentForms.at(i).get('files') as FormArray;
    }

    documentFormFilesToDelete(i) {
        return this.documentForms.at(i).get('filesToDelete') as FormArray
    }

    get filesToDeleteIds() {
        return this.form.get('filesToDelete') as FormArray;
    }
}
