import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class CeTatiCheckViewService {

    constructor(private http: HttpClient) { }

    loadTatiComplianceCheck(searchData): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TA_TATI_CHECK + '/view/', { params: searchData });
    }

    save(params: any) {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TA_TATI_CHECK + '/save', params);
    }

    updateSignDocResult(searchData): Observable<any> {
        return this.http.post<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TA_TATI_CHECK + '/submit/update-sign-doc-result/', searchData);
    }

}
