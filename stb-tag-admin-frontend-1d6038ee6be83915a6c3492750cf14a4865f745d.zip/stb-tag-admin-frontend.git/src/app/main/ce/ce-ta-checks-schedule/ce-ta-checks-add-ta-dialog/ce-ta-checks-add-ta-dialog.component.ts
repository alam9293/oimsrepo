import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatPaginator, MatSort, MAT_DIALOG_DATA } from '@angular/material';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as cnst from '../../../../common/constants';
import { FormUtil } from '../../../../common/helper';
import { CommonService, AuthenticationService } from '../../../../common/services';
import { CeTaChecksScheduleService } from '../ce-ta-checks-schedule.service';
import { ScheduleItem } from '../ce-ta-checks-schedule.dto';

@Component({
    selector: 'app-ce-ta-checks-add-ta-dialog',
    templateUrl: './ce-ta-checks-add-ta-dialog.component.html',
    styleUrls: ['./ce-ta-checks-add-ta-dialog.component.scss']
})
export class CeTaChecksAddTaDialogComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    constructor(
        public dialogRef: MatDialogRef<CeTaChecksAddTaDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private authenticationService: AuthenticationService,
        private ceTaChecksScheduleService: CeTaChecksScheduleService,
        public formUtil: FormUtil
    ) { }

    /** control for the selected search type */
    public searchTypeMultiCtrl: FormControl = new FormControl();

    /** control for the MatSelect filter keyword */
    public searchTypeFilterCtrl: FormControl = new FormControl();

    /** list of search types filtered by search keyword */
    public filteredSearchTypes: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

    /** Subject that emits when the component has been destroyed. */
    protected _onDestroy = new Subject<void>();

    /** list of search filters */
    protected searchTypes: any = [
        { key: 'taName', label: 'Name', dataType: 'text' },
        { key: 'licenceNo', label: 'Licence No.', dataType: 'text' },
        { key: 'uen', label: 'UEN', dataType: 'text' },
        { key: 'building', label: 'Building', dataType: 'text' },
        { key: 'street', label: 'Street', dataType: 'text' },
        { key: 'postal', label: 'Postal', dataType: 'text' },
        { key: 'premisesType', label: 'Premises Type', dataType: 'multiselect', data: this.data.masterData.premisesTypes },
        { key: 'addressType', label: 'Address Type', dataType: 'select', data: this.data.masterData.addressTypes },
        {
            key: 'noOfReds', label: 'No. of Reds', dataType: 'multiselect', data: [
                { key: '0', label: '0' },
                { key: '1', label: '1' },
                { key: '2', label: '2' },
                { key: '3', label: '3' },
                { key: '4', label: '4' }]
        },
        { key: 'lastAaFilingStatus', label: 'Last AA Filing Status', dataType: 'select', data: this.data.masterData.filingStatuses },
        { key: 'lastTatiCheckIsCompliant', label: 'Last TATI Check Is Compliant?', dataType: 'multiselect', data: this.data.masterData.tatiCompliantOutcomes },
        { key: 'lastTatiCheckDone', label: 'Last TATI Check Done?', dataType: 'select', data: this.data.masterData.checkDoneFlags },
        { key: 'lastCheckDone', label: 'Is Check Done Before?', dataType: 'select', data: this.data.masterData.checkDoneFlags },
        { key: 'licenceCeasedDate', label: 'Licence Ceased Date', dataType: 'datePicker' },
        { key: 'licenceExpiryDate', label: 'Licence Expiry Date', dataType: 'datePicker' },
        { key: 'licenceStatus', label: 'Main Licence Status', dataType: 'select', data: this.data.masterData.licenceStatuses },
        { key: 'branchStatus', label: 'Branch Status', dataType: 'select', data: this.data.masterData.branchStatuses },
        { key: 'serviceType', label: 'Services', dataType: 'multiselect', data: this.data.masterData.serviceTypes },
    ];
    displayedColumns = [
        'taName', 'licenceNo', 'uen', 'building', 'street',
        'postal', 'block', 'floorUnit', 'premisesType', 'addressType',
        'lastAaFilingFyEndDate', 'noOfReds', 'lastAaFilingStatus', 'lastTatiCheckIsCompliant', 'lastTatiCheckDate',
        'lastCheckDone', 'licenceCeasedDate', 'licenceExpiryDate', 'licenceStatus', 'branchStatus',
        'serviceType', 'add'
    ];
    masterData = this.data.masterData;
    scheduler = this.data.scheduler;
    listingId = "ce-ta-checks-add-ta-dialog";
    filter: any = {};
    rows = [];
    filterForm: FormGroup;
    form: FormGroup;
    cnst = cnst;
    selectedScheduleItems: ScheduleItem[] = [];
    scheduleItems: ScheduleItem[] = this.data.scheduleItems;

    ngOnInit() {
        this.initFilterForm();

        // set initial selection
        this.searchTypeMultiCtrl.setValue(this.searchTypes.slice(0, 8));

        // load the initial search types list
        this.filteredSearchTypes.next(this.searchTypes.slice());

        // listen for search field value changes
        this.searchTypeFilterCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterSearchParamMulti();
            });

        this.loadTaApplications(true);
    }

    ngOnDestroy() {
        this._onDestroy.next();
        this._onDestroy.complete();
    }

    initFilterForm() {
        this.filterForm = this.formBuilder.group({
            taName: [''],
            uen: [''],
            licenceNo: [''],
            building: [''],
            street: [''],
            postal: [''],
            premisesType: [''],
            addressType: [''],
            noOfReds: [''],
            lastAaFilingStatus: [''],
            lastTatiCheckIsCompliant: [''],
            lastTatiCheckDone: [''],
            lastCheckDone: [''],
            licenceCeasedDate: [''],
            licenceExpiryDate: [''],
            licenceStatus: [''],
            branchStatus: [''],
            serviceType: [''],
        });
        this.form = this.formBuilder.group({
            checkType: ['', Validators.required]
        });
    };

    loadTaApplications(fromCache: boolean): void {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filterForm.value, fromCache, this.listingId);
        if (fromCache) {
            let filtersFromCache = this.searchTypes.filter(filter => Object.keys(this.filter).includes(filter.key));
            this.searchTypeMultiCtrl.setValue(filtersFromCache);
        }
        this.searchTypes.forEach(element => {
            if (this.searchTypeMultiCtrl.value.indexOf(element) < 0) {
                delete this.filter[element.key];
            }
        });
        this.filterForm.patchValue(this.filter);
        if (!fromCache) {
            this.ceTaChecksScheduleService.getTaList(this.filter).subscribe(data => {
                this.rows = data.records;
                this.paginator.length = data.total;
                this.commonService.cacheSearchDto(this.filter);
            });
        }
    }

    protected filterSearchParamMulti() {
        if (!this.searchTypes) {
            return;
        }
        // get the search keyword
        let search = this.searchTypeFilterCtrl.value;
        if (!search) {
            this.filteredSearchTypes.next(this.searchTypes.slice());
            return;
        } else {
            search = search.toLowerCase();
        }
        // filter the search types
        this.filteredSearchTypes.next(
            this.searchTypes.filter(searchType => searchType.label.toLowerCase().indexOf(search) > -1)
        );
    }
    addItemToArray(element, array) {
        array.push(element);
    }
    hasTaAddressInSchedule(addressId: number) {
        let scheduleItems = this.scheduleItems.concat(this.selectedScheduleItems);
        return scheduleItems.length > 0 && scheduleItems.filter(scheduleItem => scheduleItem.addressId == addressId).length > 0;
    }
    addAllItems() {
        this.ceTaChecksScheduleService.getAllTaList(this.filter).subscribe(data => {
            let allAddedAddressIds = [];
            let thisRoundAdded: number = 0;
            let scheduleItems = this.scheduleItems.concat(this.selectedScheduleItems);
            scheduleItems.forEach(item => {
                allAddedAddressIds = allAddedAddressIds.concat(item.addressId);
            });
            data.records.forEach(record => {
                if (!allAddedAddressIds.includes(record.addressId)) {
                    this.selectedScheduleItems = this.selectedScheduleItems.concat(record);
                    allAddedAddressIds = allAddedAddressIds.concat(record.addressId);
                    thisRoundAdded++;
                }
            });
            if (thisRoundAdded == 0) {
                this.commonService.popSnackbar('No additional TA to be selected.', 'error-snackbar');
            } else {
                this.commonService.popSnackbar('Additional of ' + thisRoundAdded + ' TA selected.', 'success-snackbar');
            }
        });
    }
    closeDialog(decision) {
        if (decision) {
            if (this.selectedScheduleItems.length == 0) {
                this.commonService.popSnackbar('Please select at least one TA.', 'error-snackbar');
                return;
            }
            if (!this.form.valid) {
                this.formUtil.markFormGroupTouched(this.form);
                this.commonService.popSnackbar('Please select type of check.', 'error-snackbar');
                return;
            }
            let defaultEo = this.masterData.eoUsers ? this.masterData.eoUsers.filter(eo => eo.key == (this.scheduler.key ? this.scheduler.key : this.authenticationService.currentUserValue.id)) : []; // default to scheduler

            this.selectedScheduleItems.forEach(element => {
                element.checkType = this.masterData.checkTypes.filter(data => data.key == this.form.get('checkType').value)[0];
                element.eo = defaultEo.length > 0 ? defaultEo[0] : {};
                element.auxEo = {};
            });
            this.dialogRef.close({ scheduleItems: this.selectedScheduleItems });
        } else {
            this.dialogRef.close();
        }
    }
}
