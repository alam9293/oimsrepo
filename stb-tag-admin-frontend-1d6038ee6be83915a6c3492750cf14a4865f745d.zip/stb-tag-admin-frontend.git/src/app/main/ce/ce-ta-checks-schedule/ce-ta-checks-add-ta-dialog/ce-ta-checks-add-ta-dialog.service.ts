import { Injectable } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material';
import { CeTaChecksAddTaDialogComponent } from './ce-ta-checks-add-ta-dialog.component';

@Injectable({
    providedIn: 'root'
})
export class CeTaChecksAddTaDialogService {

    private dialogRef: MatDialogRef<CeTaChecksAddTaDialogComponent>;

    constructor(public dialog: MatDialog) { }

    openDialog(data: any): MatDialogRef<CeTaChecksAddTaDialogComponent> {

        if (this.dialogRef) {
            this.dialogRef.close();
        }

        this.dialogRef = this.dialog.open(CeTaChecksAddTaDialogComponent, {
            data: data,
            panelClass: 'full-screen-modal',
        });

        this.dialogRef.afterClosed().subscribe(result => {

        });

        return this.dialogRef;
    }
}
