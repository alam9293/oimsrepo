import { Component, OnInit, ViewChild, SimpleChanges, Input, EventEmitter, Output } from '@angular/core';
import { MatSort, MatTableDataSource } from '@angular/material';
import { FormUtil, DateUtil } from '../../../../common/helper';
import { CommonService } from '../../../../common/services';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';

@Component({
    selector: 'app-ce-ta-checks-schedule-listing',
    templateUrl: './ce-ta-checks-schedule-listing.component.html',
    styleUrls: ['./ce-ta-checks-schedule-listing.component.scss']
})
export class CeTaChecksScheduleListingComponent implements OnInit {

    @Input() data: any;
    @Input() isEditable: number;
    @Input() schedule: any;
    displayedColumns = [
        'taName', 'licenceNo', 'uen', 'building', 'street',
        'postal', 'block', 'floorUnit', 'premisesType', 'addressType',
        'lastAaFilingFyEndDate', 'noOfReds', 'lastAaFilingStatus', 'lastTatiCheckIsCompliant', 'lastTatiCheckDate',
        'lastCheckDone', 'licenceExpiryDate', 'licenceStatus', 'branchStatus', 'serviceType',
        'checkType', 'eo', 'auxEo', 'scheduledDate', 'error',
        'remove'
    ];
    masterData: any = { checkTypes: [], ceOeoTypes: [], eoUsers: [] };
    rows = new MatTableDataSource<any>();
    form: FormGroup;
    scheduleItemsTobeDeleted: number[] = [];
    minDate: any;
    maxDate: any;
    showErrorMsg: boolean = false;

    @ViewChild(MatSort) sort: MatSort;
    constructor(
        public formUtil: FormUtil,
        public commonService: CommonService,
        private formBuilder: FormBuilder,
    ) { }

    ngOnInit() {
        this.initForm();
        this.loadMasterData();
    }

    ngAfterViewInit(): void {
        // Sorting with nested objects
        this.rows.sortingDataAccessor = (item, property) => {
            switch (property) {
                case 'checkType.label': return item.checkType.label;
                case 'eo.label': return item.eo.label;
                case 'auxEo.label': return item.auxEo.label;
                default: return item[property];
            }
        };
        this.rows.sort = this.sort;
    }

    loadMasterData() {
        //Check Types
        this.commonService.getTaCheckTypes().subscribe(data => {
            this.masterData.checkTypes = data;
        });
        //EO users
        this.commonService.getCeTaEoUsers().subscribe(data => {
            this.masterData.eoUsers = data;
        });
        //OEO
        this.commonService.getCeTaAuxEoUsers().subscribe(data => {
            this.masterData.ceOeoTypes = data;
        })
    }
    initForm() {
        this.form = this.formBuilder.group({
            scheduleItems: this.formBuilder.array([]),
        });
    }
    get scheduleItems() {
        return this.form.get('scheduleItems') as FormArray;
    }
    ngOnChanges(changes: SimpleChanges) {
        if (this.data && this.form) {
            this.data.forEach(element => {
                this.scheduleItems.push(this.setScheduleItemFormArray(element));
            });
            // clear sorting
            this.sort.active = "";
            this.sort.direction = "";
            this.rows.data = this.scheduleItems.value;
        }
        if (this.schedule) {
            this.minDate = DateUtil.parseDate(this.schedule.minDate);
            this.maxDate = DateUtil.parseDate(this.schedule.maxDate);
        }
        if (this.isEditable == 0) {
            this.displayedColumns = this.displayedColumns.filter(col => col !== 'error' && col !== 'remove');
        }
    }
    setScheduleItemFormArray(data) {
        const scheduleItem = this.formBuilder.group({
            id: [],
            addressId: [],
            taName: [],
            uen: [],
            licenceNo: [],
            block: [],
            floorUnit: [],
            building: [],
            street: [],
            postal: [],
            premisesType: [],
            addressType: [],
            noOfReds: [],
            lastAaFilingFyEndDate: [],
            lastAaFilingStatus: [],
            tatiOutcome: [],
            lastTatiCheckDate: [],
            lastTatiCheckStatus: [],
            licenceCeasedDate: [],
            licenceExpiryDate: [],
            licenceStatus: [],
            branchStatus: [],
            serviceType: [],
            checkType: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            eo: this.formBuilder.group({
                key: [, Validators.required],
                label: ['']
            }),
            auxEo: this.formBuilder.group({
                key: [, Validators.required],
                label: ['']
            }),
            scheduledDate: ['', Validators.required],
            isEditable: [''],
        });
        scheduleItem.patchValue(data);
        return scheduleItem;
    }
    removeScheduleItem(itemTobeRemoved) {
        if (itemTobeRemoved.id) {
            this.scheduleItemsTobeDeleted.push(itemTobeRemoved.id);
            this.scheduleItems.removeAt(this.scheduleItems.value.findIndex(item => item.id === itemTobeRemoved.id));
            this.rows.data = this.rows.data.filter(row => {
                return row.id != itemTobeRemoved.id;
            });
        } else {
            this.scheduleItems.removeAt(this.scheduleItems.value.findIndex(item => item.addressId === itemTobeRemoved.addressId));
            this.rows.data = this.rows.data.filter(row => {
                return row.addressId != itemTobeRemoved.addressId;
            });
        }
        this.rows._updateChangeSubscription();
    }
    clearScheduleItems() {
        while (0 !== this.scheduleItems.length) {
            this.scheduleItems.removeAt(0);
        }
    }
    showErrorMessage(showErrorMsg) {
        this.showErrorMsg = showErrorMsg;
    }
    isEditableItem(scheduleItem): boolean {
        return this.isEditable == 1 && scheduleItem && scheduleItem.isEditable;
    }
}
