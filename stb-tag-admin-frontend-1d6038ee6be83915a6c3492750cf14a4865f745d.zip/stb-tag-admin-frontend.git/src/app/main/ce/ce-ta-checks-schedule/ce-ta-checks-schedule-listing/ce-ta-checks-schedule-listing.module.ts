import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '../../../../common/modules/shared.module';
import { MainMaterialModule } from '../../../main.material';
import { CeTaChecksScheduleListingComponent } from './ce-ta-checks-schedule-listing.component';

@NgModule({
    imports: [
        CommonModule,
        MainMaterialModule,
        SharedModule
    ],
    declarations: [CeTaChecksScheduleListingComponent],
    exports: [CeTaChecksScheduleListingComponent,],
    entryComponents: [],
})
export class CeTaChecksScheduleListingModule { }
