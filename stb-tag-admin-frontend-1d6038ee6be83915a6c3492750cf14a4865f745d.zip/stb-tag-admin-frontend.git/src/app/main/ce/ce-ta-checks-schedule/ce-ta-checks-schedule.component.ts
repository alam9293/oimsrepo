import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { MatDialog, MatSnackBar } from '@angular/material';
import { ConfirmationDialogComponent } from 'src/app/common/modules/confirmation-dialog/confirmation-dialog.component';
import { WorkflowService } from 'src/app/common/services/workflow.service';
import * as cnst from '../../../common/constants';
import { DateUtil, FormUtil, WorkflowHelper } from '../../../common/helper';
import { ApplicationWorkflowComponent } from '../../../common/modules/application-workflow/application-workflow.component';
import { NoteDialogComponent } from '../../../common/modules/note-dialog/note-dialog.component';
import { CommonService } from '../../../common/services';
import { CeTaChecksAddTaDialogService } from './ce-ta-checks-add-ta-dialog/ce-ta-checks-add-ta-dialog.service';
import { CeTaChecksScheduleListingComponent } from './ce-ta-checks-schedule-listing/ce-ta-checks-schedule-listing.component';
import { ScheduleItem } from './ce-ta-checks-schedule.dto';
import { CeTaChecksScheduleService } from './ce-ta-checks-schedule.service';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-ce-ta-checks-schedule',
    templateUrl: './ce-ta-checks-schedule.component.html',
    styleUrls: ['./ce-ta-checks-schedule.component.scss']
})
export class CeTaChecksScheduleComponent implements OnInit {

    constructor(
        private formBuilder: FormBuilder,
        private commonService: CommonService,
        private snackBar: MatSnackBar,
        public formUtil: FormUtil,
        public dateUtil: DateUtil,
        public dialog: MatDialog,
        public workflowHelper: WorkflowHelper,
        private addTaDialogService: CeTaChecksAddTaDialogService,
        private ceTaChecksScheduleService: CeTaChecksScheduleService,
        private workflowService: WorkflowService,
        private route: ActivatedRoute,
    ) { }

    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;
    @ViewChild('editableCeTaChecksScheduleListing') editableScheduleComp: CeTaChecksScheduleListingComponent;
    @ViewChild('approvedCeTaChecksScheduleListing') approvedScheduleComp: CeTaChecksScheduleListingComponent;

    years: number[] = [];
    calMonths = [
        { key: 1, label: 'Jan' },
        { key: 2, label: 'Feb' },
        { key: 3, label: 'Mar' },
        { key: 4, label: 'Apr' },
        { key: 5, label: 'May' },
        { key: 6, label: 'Jun' },
        { key: 7, label: 'Jul' },
        { key: 8, label: 'Aug' },
        { key: 9, label: 'Sep' },
        { key: 10, label: 'Oct' },
        { key: 11, label: 'Nov' },
        { key: 12, label: 'Dec' }
    ];
    activeTab: number = 1;
    masterData: any = { premisesTypes: [], addressTypes: [], filingStatuses: [], checkDoneFlags: [], licenceStatuses: [], branchStatuses: [], serviceTypes: [], checkTypes: [] };
    editableScheduleItems: ScheduleItem[] = [];
    form: FormGroup;
    cnst = cnst;
    schedule: any = { status: {}, workflow: {}, lastAction: {}, lastApprovedAction: {}, lastEditAction: {}, oic: {}, };
    approvedSchedule: any = {}

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.editableScheduleComp.form.pristine;
    }

    ngOnInit() {
        this.initForm();
        this.loadMasterData();
        let queryParams = this.route.snapshot.queryParams;
        Object.keys(queryParams).forEach(key => {
            this.form.get(key).setValue(queryParams[key]);
        });
    }

    ngAfterViewInit() {
        this.loadSchedule(false);
    }

    loadMasterData() {

        //premises types
        this.commonService.getPremiseTypes().subscribe(data => {
            this.masterData.premisesTypes = data;
        });
        //ta address types
        this.commonService.getTaAddressTypes().subscribe(data => {
            this.masterData.addressTypes = data;
        });
        //filing statuses
        this.commonService.getFilingStatuses().subscribe(data => {
            this.masterData.filingStatuses = data;
        });
        //TATI outcomes
        this.commonService.getFlags().subscribe(data => {
            this.masterData.tatiCompliantOutcomes = data;
        });
        //Last check done
        this.masterData.checkDoneFlags = [{ key: 'YES', label: 'Yes' }, { key: 'NO', label: 'No' },];
        //licence statuses
        this.commonService.getTaLicenceStatuses().subscribe(data => {
            this.masterData.licenceStatuses = data;
        });
        //branch statuses
        this.commonService.getTaBranchStatuses().subscribe(data => {
            this.masterData.branchStatuses = data;
        });
        //services
        this.commonService.getTaServicesTypes().subscribe(data => {
            this.masterData.serviceTypes = data;
        });
        //Check type
        this.commonService.getTaCheckTypes().subscribe(data => {
            this.masterData.checkTypes = data;
        });
        //EO users
        this.commonService.getCeTaEoUsers().subscribe(data => {
            this.masterData.eoUsers = data;
        });
    }
    searchSchedule(reloadWorkflowlog: boolean) {
        if (!this.editableScheduleComp.form.pristine) {
            let decision = confirm(cnst.CommonErrorMessages.CAN_DEACTIVATE);
            if (!decision) return;
        }
        this.loadSchedule(reloadWorkflowlog);
    }
    loadSchedule(reloadWorkflowlog: boolean) {

        this.ceTaChecksScheduleService.loadSchedule(this.form.get('year').value, this.form.get('month').value).subscribe(data => {
            this.years = data.years;
            this.form.patchValue(data);
            this.schedule = data;
            this.reloadScheduleData(data);
            if (reloadWorkflowlog && this.workflowComp) {
                this.workflowComp.loadWorkflowActions();
            }
        }, error => {
            this.schedule = { status: {}, workflow: {}, lastAction: {}, lastApprovedAction: {}, lastEditAction: {}, oic: {}, scheduleItems: [] };
            this.reloadScheduleData(this.schedule);
        })
    }
    reloadScheduleData(data: any) {
        this.editableScheduleComp.clearScheduleItems(); // clear the form array and pass new list
        this.editableScheduleItems = data.scheduleItems.filter(item => { return !item.isApproved });
        this.editableScheduleComp.showErrorMessage(false);

        this.approvedScheduleComp.clearScheduleItems(); // clear the form array and pass new list            
        this.approvedSchedule = data.scheduleItems.filter(item => { return item.isApproved });
    }
    initForm() {
        this.form = this.formBuilder.group({
            id: [],
            month: ['', Validators.required],
            year: ['', Validators.required],
            internalRemarks: [''],
            approverId: [''],
            supporterId: ['']
        });
    }
    get scheduleItems() {
        return this.form.get('scheduleItems') as FormArray;
    }
    openAddTaDialog() {
        const addTaDialogRef = this.addTaDialogService.openDialog({ masterData: this.masterData, scheduleItems: this.editableScheduleComp.rows.data, scheduler: this.schedule.oic });

        addTaDialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.editableScheduleItems = result.scheduleItems;
            }
        });
    }
    openNoteDialog() {
        const noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });
        noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.ceTaChecksScheduleService.saveNote(result.params, this.schedule.workflow.workflowId).subscribe(
                    data => {
                        this.workflowComp.loadWorkflowActions();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }
    validateForm(draft: boolean): boolean {
        if (this.form.get('scheduleItems')) {
            this.form.removeControl('scheduleItems');
            this.form.removeControl('scheduleItemsTobeDeleted');
        }
        this.form.addControl('scheduleItems', this.formBuilder.array(this.editableScheduleComp.scheduleItems.value));
        this.form.addControl('scheduleItemsTobeDeleted', this.formBuilder.array(this.editableScheduleComp.scheduleItemsTobeDeleted));
        let toProceed: boolean = true;
        this.editableScheduleComp.scheduleItems.controls.forEach(ctrl => {
            if (ctrl.get('scheduledDate').hasError('matDatepickerMin')) {
                this.commonService.popSnackbar(cnst.CommonErrorMessages.DATA_BEFORE_MIN, 'error-snackbar');
                toProceed = false;
                return;
            } else if (ctrl.get('scheduledDate').hasError('matDatepickerMax')) {
                this.commonService.popSnackbar(cnst.CommonErrorMessages.DATA_AFTER_MAX, 'error-snackbar');
                toProceed = false;
                return;
            }
        });
        if (!toProceed) {
            return false;
        }
        if ((!draft && !this.editableScheduleComp.form.valid) || !this.form.valid) {
            this.formUtil.markFormGroupTouched(this.form);
            this.formUtil.markFormGroupTouched(this.editableScheduleComp.form);
            this.editableScheduleComp.showErrorMessage(true);
            this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
            return false;
        } else {
            return true;
        }
    }
    submitAction(draft: boolean, action?: any) {
        if (this.validateForm(draft)) {
            let warning = '';
            if (action && action.name != 'route' && (!this.form.get('scheduleItems') || this.form.get('scheduleItems').value.length == 0)) {
                warning = 'There are no schedule checks for the month, are you sure you want to proceed?';
            }
            if (action) {
                let dialogData: any = {
                    title: 'Action: ' + action.label,
                    internalRemarks: true,
                    externalRemarks: false,
                    action: action,
                    taTg: cnst.CE,
                    appType: cnst.WorkflowTypes.CE_WKFLW_TA_SCHEDULE,
                    warning: warning
                }
                if (!this.schedule.workflow.isFinalApproval && action.name != 'route') {
                    this.workflowService.getCeWorkflowConfigByType(cnst.WorkflowTypes.CE_WKFLW_TA_SCHEDULE).subscribe(data => {
                        // get routing officers
                        dialogData.workflowConfig = data;
                        let confirmationDialogRef = this.dialog.open(ConfirmationDialogComponent, {
                            data: dialogData
                        });
                        confirmationDialogRef.afterClosed().subscribe(result => {
                            if (result.decision) {
                                this.form.patchValue(result.params);
                                this.ceTaChecksScheduleService.submitAction(this.form.value, action.name).subscribe(
                                    data => {
                                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TA'), 'success-snackbar');
                                        this.editableScheduleComp.form.markAsPristine();
                                        this.loadSchedule(true);
                                    },
                                    error => {
                                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                                    }
                                );
                            }
                        });
                    })
                } else {
                    let confirmationDialogRef = this.dialog.open(ConfirmationDialogComponent, {
                        data: dialogData
                    });
                    confirmationDialogRef.afterClosed().subscribe(result => {
                        if (result.decision) {
                            this.form.patchValue(result.params);
                            this.ceTaChecksScheduleService.submitAction(this.form.value, action.name).subscribe(
                                data => {
                                    this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TA'), 'success-snackbar');
                                    this.editableScheduleComp.form.markAsPristine();
                                    this.loadSchedule(true);
                                },
                                error => {
                                    this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                                }
                            );
                        }
                    });
                }
            } else {
                this.saveSchedule();
            }
        }
    }
    saveSchedule() {
        this.ceTaChecksScheduleService.saveSchedule(this.form.value).subscribe(
            data => {
                this.commonService.popSnackbar(null, 'success-snackbar');
                this.editableScheduleComp.form.markAsPristine();
                this.loadSchedule(true);
            },
            error => {
                this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
            }
        );
    }
    reAssign() {
        this.workflowHelper.reAssignCEWorkflow(this.schedule.status.key, this.schedule.workflow.workflowId, null).then(data => {
            if (data) {
                this.loadSchedule(true);
            }
        })
    }
    isPendingSubmission(): boolean {
        return this.schedule.id && this.workflowHelper.isPendingSubmission(this.schedule.status.key, this.schedule.hasEditedAfterApproved);
    }
    isPendingApproval(): boolean {
        return this.workflowHelper.isPendingApproval(this.schedule.status.key);
    }
    isNew(): boolean {
        return this.workflowHelper.isNew(this.schedule.status.key);
    }
    isApproved(): boolean {
        return this.workflowHelper.isApproved(this.schedule.status.key);
    }
}
