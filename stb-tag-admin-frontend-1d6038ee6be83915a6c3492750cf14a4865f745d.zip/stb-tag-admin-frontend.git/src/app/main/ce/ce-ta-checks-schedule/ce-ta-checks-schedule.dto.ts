export class ScheduleItem {
    id: number;
    addressId: number;
    taName: string;
    uen: string;
    licenceNo: string;
    block: string;
    floorUnit: string;
    building: string;
    street: string;
    postal: string;
    premisesType: string;
    addressType: string;
    noOfReds: number;
    lastAaFilingFyEndDate: string;
    lastAaFilingStatus: string;
    tatiOutcome: string;
    lastTatiCheckDate: string;
    lastTatiCheckStatus: string;
    licenceCeasedDate: string;
    licenceExpiryDate: string;
    licenceStatus: string;
    branchStatus: string;
    serviceType: string;
    checkType: any = {};
    eo: any = {};
    auxEo: any = {};
    scheduledDate: string
} 