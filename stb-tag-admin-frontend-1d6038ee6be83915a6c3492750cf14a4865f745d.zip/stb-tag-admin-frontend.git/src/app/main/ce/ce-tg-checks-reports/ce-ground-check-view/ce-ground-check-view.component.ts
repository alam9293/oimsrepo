import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { CommonService, AuthenticationService } from 'src/app/common/services';
import * as cnst from '../../../../common/constants';
import { FileUtil, FormUtil } from '../../../../common/helper';
import { CeGroundCheckViewService } from './ce-ground-check-view.service';
import { AttachmentComponent } from 'src/app/common/modules/attachment/attachment.component';
@Component({
    selector: 'app-ce-ground-check-view',
    templateUrl: './ce-ground-check-view.component.html',
    styleUrls: ['./ce-ground-check-view.component.scss']
})
export class CeGroundCheckViewComponent implements OnInit {
    @ViewChild('att') attachmentsComponent: AttachmentComponent;
    declarationText: any
    introDescription: any;
    form: FormGroup;
    report: any = { disableEdit: false, shift: { key: '', label: '' }, location: { key: '', label: '' } };
    groundCheckForm: FormGroup;
    fileForm: FormGroup;
    cnst = cnst;
    flagList: any;
    selectedFile: File;
    fileColumns = ['fileName', 'description', 'fileSize', 'details', 'Action'];
    constructor(
        private route: ActivatedRoute,
        private fb: FormBuilder,
        private formUtil: FormUtil,
        public authService: AuthenticationService,
        private ceGroundCheckViewService: CeGroundCheckViewService,
        private commonService: CommonService,
        private fileUtil: FileUtil,
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        this.initiateForm();
        if (this.route.snapshot.paramMap.get('checkScheduleItemLocationId') != 'null') {
            this.loadTgGroundCheck(+this.route.snapshot.paramMap.get('checkScheduleItemLocationId'));
        }
    }

    get fileForms() {
        return this.form.get('files') as FormArray
    }

    get f() {
        return this.form.controls;
    }

    initiateForm() {
        this.form = this.fb.group({
            toSubmit: false,
            scheduleItemLocationId: '',
            ceTgCheckId: [],
            noOfGrpWithTg: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfGrpWithoutTg: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfGrpWithExpert: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfStudGrpWithTg: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfStudGrpWithTchr: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfStudGrpWithStud: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfMiceGrpWithTg: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfMiceGrpWithExpat: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfCruiseWithTg: ['', Validators.compose([Validators.required, Validators.min(0)])],
            noOfCruiseWithoutTg: ['', Validators.compose([Validators.required, Validators.min(0)])],
            files: [],
            filesToDelete: [],
        }, {
            validator: Validators.compose([ValidateTotalWithTG, ValidateTotalWithoutTG])
        });
    }

    listenMinNoValidator() {
        this.form.get('noOfGrpWithTg').valueChanges.subscribe(
            val => {
                this.form.updateValueAndValidity();
            });

        this.form.get('noOfGrpWithoutTg').valueChanges.subscribe(
            val => {
                this.form.updateValueAndValidity();
            });
    }

    getTgGroundCheck(tgCheckId) {
        this.ceGroundCheckViewService.loadTgGroundCheck(tgCheckId).subscribe(data => {
            this.report = data;
            this.setupForm(this.report);

        }, error => {

        })
    }

    loadTgGroundCheck(scheduleItemLocationId) {
        this.ceGroundCheckViewService.loadTgGroundCheck(scheduleItemLocationId).subscribe(data => {
            this.report = data;
            this.setupForm(this.report);
        }, error => {

        })
    }

    private setupForm(report: any) {
        this.form.patchValue(report);

        if (report.files) {
            this.attachmentsComponent.set(report.files);
        }

        if (this.report.disableEdit) {
            this.form.disable();
        }
    }

    submit(toSubmit) {
        this.form.get('toSubmit').patchValue(toSubmit);
        this.formUtil.markFormGroupTouched(this.form);
        if ((toSubmit && this.form.valid) || !toSubmit) {
            if (this.attachmentsComponent.attachmentForm) {
                this.form.get('files').setValue(this.attachmentsComponent.attachments.value);
                this.form.get('filesToDelete').setValue(this.attachmentsComponent.deletedAttachementIds.value);
            }

            this.ceGroundCheckViewService.save(this.form.value).subscribe(scheduleItemLocationId => {
                this.form.markAsPristine();
                this.initiateForm();
                this.loadTgGroundCheck(scheduleItemLocationId);
                this.commonService.popSnackbar('Ground Checks Observation ' + (toSubmit ? 'submitted' : 'saved') + ' successfully.', 'success-snackbar');
            }),
                error => {
                    this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                };
        } else {
            this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
        }
    }
}

export function ValidateTotalWithTG(group: FormGroup) {
    let noOfGrpWithTg = group.get("noOfGrpWithTg").value;
    let noOfCruiseWithTg = group.get("noOfCruiseWithTg").value;
    let noOfMiceGrpWithTg = group.get("noOfMiceGrpWithTg").value;
    let noOfStudGrpWithTg = group.get("noOfStudGrpWithTg").value;
    let totalGrpWithTg = noOfCruiseWithTg + noOfMiceGrpWithTg + noOfStudGrpWithTg;
    if (noOfGrpWithTg < totalGrpWithTg) {
        return { minNoOfGrpWithTg: true };
    }
    return null;
}

export function ValidateTotalWithoutTG(group: FormGroup) {
    let noOfGrpWithoutTg = group.get("noOfGrpWithoutTg").value;
    let noOfCruiseWithoutTg = group.get("noOfCruiseWithoutTg").value;
    let noOfGrpWithExpert = group.get("noOfGrpWithExpert").value;
    let noOfMiceGrpWithExpat = group.get("noOfMiceGrpWithExpat").value;
    let noOfStudGrpWithStud = group.get("noOfStudGrpWithStud").value;
    let noOfStudGrpWithTchr = group.get("noOfStudGrpWithTchr").value;
    let totalGrpWithoutTg = noOfCruiseWithoutTg + noOfGrpWithExpert + noOfMiceGrpWithExpat + noOfStudGrpWithStud + noOfStudGrpWithTchr;
    if (noOfGrpWithoutTg < totalGrpWithoutTg) {
        return { minNoOfGrpWithoutTg: true };
    }
    return null;
}
