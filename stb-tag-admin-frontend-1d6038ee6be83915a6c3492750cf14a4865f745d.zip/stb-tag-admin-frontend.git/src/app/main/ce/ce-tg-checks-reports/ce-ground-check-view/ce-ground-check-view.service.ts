import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class CeGroundCheckViewService {

    constructor(private http: HttpClient) { }

    loadTgGroundCheck(checkScheduleItemLocationId): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_GROUND_CHECK + '/view/' + checkScheduleItemLocationId);
    }

    save(params: any) {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TG_GROUND_CHECK + '/save', params);
    }

}
