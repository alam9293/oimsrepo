import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';
import * as cnst from '../../../../common/constants';
import { CeTgChecksReportsListService } from './ce-tg-checks-reports-list.service';
import { WorkflowHelper } from '../../../../common/helper';
import { CommonService } from 'src/app/common/services';
import * as moment from 'moment';

@Component({
    selector: 'app-ce-tg-checks-reports-list',
    templateUrl: './ce-tg-checks-reports-list.component.html',
    styleUrls: ['./ce-tg-checks-reports-list.component.scss']
})
export class CeTgChecksReportsListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    listingId = "ce-tg-checks-reports-list";
    scheduleYears: any = [];
    scheduleWeeks: any = [];
    meridiemTypes: any = [];
    locationTypes: any = [];
    eoUsers: any = [];
    filter: any = {};
    cnst = cnst;
    displayedColumns = ['no', 'scheduleDate', 'shift', 'location', 'eoUsers', 'tgCheckId', 'tgFieldReports'];
    rows = [];
    todayDate = moment();

    constructor(
        private ceTgCheckReportListService: CeTgChecksReportsListService,
        public workflowHelper: WorkflowHelper,
        private commonService: CommonService,
    ) { }

    ngOnInit() {
        this.loadCeScheduleList(true);

        // populate filter dropdowns
        this.ceTgCheckReportListService.getYears().subscribe(data => this.scheduleYears = data);
        this.ceTgCheckReportListService.getEoUsers().subscribe(data => this.eoUsers = data);
        this.commonService.getCeTgScheduleMeridiemTypes().subscribe(data => this.meridiemTypes = data);
        this.commonService.getCeTgScheduleLocationTypes().subscribe(data => this.locationTypes = data);
        
    }

    selectYear() {
        if (this.filter.scheduleYear) {
            this.getWeeksByYear(this.filter.scheduleYear); 
        } else {
            // reset weeks filter when year filter has no value
            this.filter.scheduleWeek = {};
            this.scheduleWeeks = [];
        }
           
    }

    getWeeksByYear(year) {
        this.filter.scheduleWeek = {};
        this.ceTgCheckReportListService.getWeeksByYear(year).subscribe(data => {
            this.scheduleWeeks = data;
        });
    }

    loadCeScheduleList(fromInit: boolean): void {
        this.workflowHelper.selection = new SelectionModel<any>(true, []);
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromInit, this.listingId);
        this.ceTgCheckReportListService.getCeScheduleList(this.filter).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

}
