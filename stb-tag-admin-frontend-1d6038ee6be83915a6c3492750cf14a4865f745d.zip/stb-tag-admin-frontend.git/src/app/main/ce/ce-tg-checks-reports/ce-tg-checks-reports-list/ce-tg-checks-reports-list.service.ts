import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class CeTgChecksReportsListService {
    constructor(private http: HttpClient) { }

    getYears(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_REPORTS + '/list/get-years/');
    }

    getWeeksByYear(year): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_REPORTS + '/list/get-weeks/' + year);
    }

    getEoUsers(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_REPORTS + '/list/get-eos/');
    }

    getCeScheduleList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_REPORTS + '/list/', { params: searchDto });
    }

}