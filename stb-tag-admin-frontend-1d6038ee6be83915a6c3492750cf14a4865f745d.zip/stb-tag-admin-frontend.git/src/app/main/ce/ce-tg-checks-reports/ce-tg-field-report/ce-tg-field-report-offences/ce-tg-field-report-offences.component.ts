import { Component, OnInit, SimpleChanges, Input, ViewChild } from '@angular/core';
import { CeCaseRelevantOffencesComponent } from '../../../ce-case/ce-case-relevant-offences/ce-case-relevant-offences.component';
import { CeTgFieldReportService } from '../ce-tg-field-report.service';

@Component({
    selector: 'app-ce-tg-field-report-offences',
    templateUrl: './ce-tg-field-report-offences.component.html',
    styleUrls: ['./ce-tg-field-report-offences.component.scss']
})
export class CeTgFieldReportOffencesComponent implements OnInit {

    @Input() uin: any;
    @ViewChild(CeCaseRelevantOffencesComponent) ceCaseRelevantOffencesComponent: CeCaseRelevantOffencesComponent;

    constructor(public ceTgFieldReportService: CeTgFieldReportService) { }

    ngOnInit() {
        if (this.uin) {
            this.load();
        }
    }

    load() {
        this.ceTgFieldReportService.getPastInfringements(this.uin).subscribe(data => {
            this.ceCaseRelevantOffencesComponent.loadDetails(data);
        })
    }

}
