import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild, ViewChildren, QueryList } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormArray, FormControl, AbstractControl } from '@angular/forms';
import { FormUtil } from 'src/app/common/helper';
import * as cnst from '../../../../../common/constants';
import { CommonService } from 'src/app/common/services';
import { Observable } from 'rxjs';
import { TravelAgentDto } from 'src/app/common/models';
import { MatAutocompleteSelectedEvent, MatTable, MatSort, MatPaginator } from '@angular/material';
import { CeTgFieldReportService } from '../ce-tg-field-report.service';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
    selector: 'ce-tg-field-report-tg',
    templateUrl: './ce-tg-field-report-tg.component.html',
    styleUrls: ['./ce-tg-field-report-tg.component.scss']
})
export class CeTgFieldReportTgComponent implements OnInit {

    @ViewChildren(MatTable) _matTables: QueryList<MatTable<string>>;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) offencePaginator: MatPaginator;

    myControl = new FormControl();
    report: any = { disableEdit: false };
    tgDetails: any;
    filteredTravelAgents: Observable<TravelAgentDto[]>;
    cnst = cnst;
    nationalities: any;
    languages: any;
    travelAgents: any;
    tgDetailsForm: FormGroup;
    offenceProvisionMap = new Map<any, any>();
    offenceProvisionChapterMap = new Map<any, any>();
    recommendations: any;
    tgAgeGroups: any;
    onChange: any = () => { };
    onTouched: any = () => { };
    selection = new SelectionModel<any>(true, []);

    offenceColumns = ['offenceProvision', 'readWith', 'description', 'recommendation', 'action'];

    constructor(
        private fb: FormBuilder,
        private formUtil: FormUtil,
        private commonService: CommonService,
        private ceTgFieldReportService: CeTgFieldReportService,
    ) { }

    ngOnInit() {
        this.initForm();
        this.loadMasterData();
        this.loadProvisions();

        // this.ceTgFieldReportService.getTravelAgents().subscribe(data => {
        //     this.travelAgents = data;
        //     this.filteredTravelAgents = this.myControl.valueChanges
        //         .pipe(
        //             startWith<string | TravelAgentDto>(''),
        //             map(value => typeof value === 'string' ? value : value.name),
        //             map(name => name ? this._filter(name) : this.travelAgents.slice())
        //         );
        // });
    }

    get f() {
        return this.tgDetailsForm.controls;
    }

    get tgDetailsForms() {
        return this.tgDetailsForm.get('tgDetailsDtos') as FormArray
    }

    infringementForms(tgDetailsIndex) {
        return this.tgDetailsForms.at(tgDetailsIndex).get('infringements') as FormArray
    }

    displayFn(ta?: TravelAgentDto): string | undefined {
        return ta ? ta.name + ' (TA' + ta.licenceNo + ')' : undefined;
    }

    private _filter(name: string): TravelAgentDto[] {
        const filterValue = name.toLowerCase();

        return this.travelAgents.filter(travelAgent => (travelAgent.name + ' (TA' + travelAgent.licenceNo + ')').toLowerCase().includes(filterValue));
    }

    onTravelAgentChanged(event: MatAutocompleteSelectedEvent, rowIndex) {
        var selectedTa = event.option.value;

        var tgDetails = this.tgDetailsForms.at(rowIndex);
        tgDetails.get('taName').setValue(selectedTa.name);
    }

    set(data) {
        if (data && data.tgDetailsDtos) {
            this.report = data;
            this.initForm();

            data.tgDetailsDtos.forEach(u => {
                this.addTgDetails(u);
            });

            if (this.report.disableEdit) {
                this.tgDetailsForm.disable();
            }

            if (this.report.status.key === cnst.Statuses.STAT_CE_SUBMISSION_DRAFT) {
                this.formUtil.markFormGroupTouched(this.tgDetailsForm);
            }
        }
    }

    initForm() {
        this.tgDetailsForm = this.fb.group({
            tgDetailsDtos: this.fb.array([], Validators.required),
            deletedTgDetailsDtos: this.fb.array([])
        })
    }

    populateTgDetailsFormGroup(x) {
        var tgDtoForm: FormGroup;
        tgDtoForm = this.fb.group({
            ceTgFieldReportTgId: x ? x.ceTgFieldReportTgId : [],
            uin: x ? x.uin : [], // Not required to cater for UTG
            passportNo: [x ? x.passportNo : null, Validators.required],
            name: [x ? x.name : null, Validators.required],
            contactNo: [x ? x.contactNo : null, Validators.required],
            role: [x ? x.role : null, Validators.required],
            // nameOfTA: x ? this.fb.group({ name: [x.nameOfTA], }) : this.fb.group({ name: [''], }),
            taName: [x ? x.taName : null, Validators.required],
            nationality: x ? this.formUtil.listableFormWithValue(this.fb, x.nationality) : this.formUtil.listableForm(this.fb, true),
            vehicleNo: [x ? x.vehicleNo : null, Validators.required],
            noOfTourists: [x ? x.noOfTourists : null, Validators.required],
            touristNationality: x ? this.formUtil.listableFormWithValue(this.fb, x.touristNationality) : this.formUtil.listableForm(this.fb, true),
            guidingLanguageProvided: x ? this.formUtil.listableFormWithValue(this.fb, x.guidingLanguageProvided) : this.formUtil.listableForm(this.fb, true),
            noOfAntecedentRecords: [x ? x.noOfAntecedentRecords : null, Validators.required],
            ageGroup: x ? this.formUtil.listableFormWithValue(this.fb, x.ageGroup) : this.formUtil.listableForm(this.fb, true),
            licenceId: x ? x.licenceId : [],
            licenceNo: x ? x.licenceNo : [],
            licenceStatus: x ? this.formUtil.listableFormWithValueNoValidation(this.fb, x.licenceStatus) : this.formUtil.listableForm(this.fb, false),
            approvedLanguages: x ? x.approvedLanguages : [],
            hasValidLicence: x ? x.hasValidLicence : [null, Validators.required],
            licenceExpiryDate: x ? x.licenceExpiryDate : [],
            isLicenceDisplayed: x ? x.isLicenceDisplayed : [],
            isPictureTallied: x ? x.isPictureTallied : [],
            isLanguageApproved: x ? x.isLanguageApproved : [],
            hasSearchedTg: x && x.licenceId ? true : false,
            infringements: x ? this.createInfringementArray(x) : this.fb.array([], Validators.required),
            deletedInfringements: this.fb.array([]),
        })

        if (x && x.licenceId) {
            this.disableFields(tgDtoForm);
        }

        return tgDtoForm;
    }

    createInfringementArray(x) {
        var formArray: FormArray = this.fb.array([], Validators.required);
        x.infringements.forEach(item => {
            let isProvisionIneffective = this.isIneffectiveOffenceProvision(item.offenceProvision);
            let isReadWithIneffective = this.isIneffectiveOffenceProvision(item.readWith);

            // add ineffective offence provision to dropdown
            if (isProvisionIneffective) {
                this.setProvision(item.offenceProvision);
            }

            // add ineffective readwith to dropdown
            if ((isProvisionIneffective && item.readWith) || isReadWithIneffective) {
                let offenceProvision = this.getOffenceProvision(item.offenceProvision.id);
                if (offenceProvision) {
                    offenceProvision.readWiths.push(item.readWith);
                }
            }

            formArray.push(this.populateOffenceFormGroup(item))
        });
        return formArray;
    }

    isIneffectiveOffenceProvision(provision) {
        return provision != null && provision.ineffectiveDate != null && moment(provision.ineffectiveDate, 'DD-MMM-YYY') < moment() ? true : false;
    }

    addTgDetails(data) {
        this.tgDetailsForms.push(
            this.populateTgDetailsFormGroup(data)
        );
    }

    deleteTgDetails(rowIndex) {
        var tgDetails = this.tgDetailsForms.at(rowIndex);

        if (tgDetails.get('ceTgFieldReportTgId').value) {
            (this.tgDetailsForm.get('deletedTgDetailsDtos') as FormArray).push(this.tgDetailsForms.at(rowIndex).get('ceTgFieldReportTgId'));
        }

        this.tgDetailsForms.removeAt(rowIndex);
    }

    loadTgDetails(data: any) {
        this.initForm();
        this.tgDetailsForms.patchValue(data);
    }

    searchByUin(uin, rowIndex) {
        var tgDetails = this.tgDetailsForms.at(rowIndex);

        this.ceTgFieldReportService.getTgDetailsFromUin(uin).subscribe(data => {
            this.setLicenseeDetails(tgDetails, data, rowIndex);
        }, error => {
            tgDetails.get('hasValidLicence').setValue("false");
            tgDetails.get('hasValidLicence').disable();
            tgDetails.get('licenceNo').setValue("");
            tgDetails.get('licenceNo').disable();
        })
    }

    searchByLicence(licenceNo, rowIndex) {
        var tgDetails = this.tgDetailsForms.at(rowIndex);

        this.ceTgFieldReportService.getLicenceDetailsFromLicenceNo(licenceNo).subscribe(data => {
            this.setLicenseeDetails(tgDetails, data, rowIndex);
        }, error => {
            tgDetails.get('hasValidLicence').setValue("false");
            tgDetails.get('hasValidLicence').disable();
        })
    }

    setLicenseeDetails(tgDetails, data, rowIndex) {
        tgDetails.get('name').patchValue(data.name);
        tgDetails.get('contactNo').patchValue(data.contactNo);
        tgDetails.get('uin').patchValue(data.uin);
        tgDetails.get('ageGroup').patchValue(data.ageGroup);
        tgDetails.get('nationality').patchValue(data.nationality);
        tgDetails.get('licenceNo').patchValue(data.licenceNo);
        tgDetails.get('licenceId').patchValue(data.licenceId);
        tgDetails.get('approvedLanguages').patchValue(data.approvedLanguages);
        tgDetails.get('licenceStatus').patchValue(data.licenceStatus);
        tgDetails.get('licenceExpiryDate').patchValue(data.licenceExpiryDate);

        this.disableFields(tgDetails);
        this.toggleHasValidLicence(data, rowIndex);
        tgDetails.get('hasValidLicence').disable();
        tgDetails.get('hasSearchedTg').setValue(true);
    }

    toggleHasValidLicence(data, rowIndex) {
        var tgDetails = this.tgDetailsForms.at(rowIndex);
        if (data && data.licenceStatus.key == cnst.Statuses.LICENCE_ACTIVE) {
            tgDetails.get('hasValidLicence').setValue("true");
            tgDetails.get('isLicenceDisplayed').setValidators(Validators.required);
            tgDetails.get('isPictureTallied').setValidators(Validators.required);
            tgDetails.get('isLanguageApproved').setValidators(Validators.required);
        } else {
            tgDetails.get('hasValidLicence').setValue("false");
            tgDetails.get('isLicenceDisplayed').setValidators(null);
            tgDetails.get('isPictureTallied').setValidators(null);
            tgDetails.get('isLanguageApproved').setValidators(null);
            tgDetails.get('nationality').enable();
            tgDetails.get('ageGroup').enable();
        }
        this.formUtil.markFormGroupTouched(this.tgDetailsForm);
    }

    disableFields(tgDetails) {
        tgDetails.get('uin').disable();
        tgDetails.get('name').disable();
        tgDetails.get('nationality').disable();
        tgDetails.get('licenceNo').disable();
        tgDetails.get('hasValidLicence').disable();
        tgDetails.get('ageGroup').disable();
    }

    loadMasterData() {
        this.commonService.getNationalities().subscribe(data => { this.nationalities = data });
        this.commonService.getTgAgeGroups().subscribe(data => { this.tgAgeGroups = data });
        this.ceTgFieldReportService.getTravelAgents().subscribe(data => { this.travelAgents = data; });
        this.commonService.getTgGuidingLanguages().subscribe(data => { this.languages = data });

        this.commonService.getCeOutcomes().subscribe(data => this.recommendations = _.filter(data, function (type) {
            return type.key !== cnst.ceOutcome.CE_OUTCOME_TAG_IP && type.key !== cnst.ceOutcome.CE_OUTCOME_CONDITION && type.key !== cnst.ceOutcome.CE_OUTCOME_KIV
                && type.key !== cnst.ceOutcome.CE_OUTCOME_RECHECK;
        }));

    }

    /*
    * Provision
    */

    addOffence(data, tgDetailsIndex) {
        var tgDetails = this.tgDetailsForms.at(tgDetailsIndex);
        var infringements = tgDetails.get('infringements') as FormArray;
        var _matTable = this._matTables.toArray()[tgDetailsIndex];
        infringements.push(
            this.populateOffenceFormGroup(data)
        );
        this.renderTable(_matTable);
    }

    populateOffenceFormGroup(x) {
        return this.fb.group({
            infringementId: x && x.infringementId ? x.infringementId : [],
            offenceProvision: [x && x.offenceProvision ? x.offenceProvision : { id: '' }, ValidateEmptyString],
            readWith: x && x.readWith ? x.readWith : [],
            recommendation: [x && x.recommendation ? x.recommendation : null, Validators.required]
        });
    }

    deleteOffence(tgDetailsIndex, index) {
        var tgDetails = this.tgDetailsForms.at(tgDetailsIndex);
        var infringements = tgDetails.get('infringements') as FormArray;
        var _matTable = this._matTables.toArray()[tgDetailsIndex];
        var deletedInfringement = infringements.at(index);
        if (deletedInfringement.get('infringementId').value) {
            var deletedInfringements = tgDetails.get('deletedInfringements') as FormArray;
            deletedInfringements.push(deletedInfringement.get('infringementId'));
        }

        infringements.removeAt(index);
        this.renderTable(_matTable);
    }

    loadProvisions() {
        this.ceTgFieldReportService.getCeProvisions().subscribe(data => {
            data.forEach(x => {
                this.setProvision(x);
            });
        });
    }

    setProvision(provision) {
        let offenceProvision = this.offenceProvisionMap.get(provision.id);

        if (offenceProvision == null) {
            this.offenceProvisionMap.set(provision.id, provision);

            var chapters = this.offenceProvisionChapterMap.get(provision.chapter.label);
            if (chapters) {
                chapters.push(provision);
            } else {
                this.offenceProvisionChapterMap.set(provision.chapter.label, [provision]);
            }
        }
    }

    getToolTipData(tgDetailsIndex, rowIndex, offenceProvision) {
        var tgDetails = this.tgDetailsForms.at(tgDetailsIndex);
        if (tgDetails != null) {
            var infringements = tgDetails.get('infringements') as FormArray;
            var infringement = infringements.at(rowIndex);
            offenceProvision = infringement.get('offenceProvision');

            if (offenceProvision.value) {
                return offenceProvision.value['label'];
            }
        }

        return offenceProvision.label;
    }

    getToolTipDescription(tgDetailsIndex, rowIndex, readWith) {
        var tgDetails = this.tgDetailsForms.at(tgDetailsIndex);
        if (tgDetails != null) {
            var infringements = tgDetails.get('infringements') as FormArray;
            var infringement = infringements.at(rowIndex);
            readWith = infringement.get('readWith');

            if (readWith.value) {
                return readWith.value['section'] + ' : ' + readWith.value['description'];
            }
        }

        return readWith.description;
    }
    renderTable(_matTable) {
        _matTable.renderRows();
    }

    compareId(o1: any, o2: any): boolean {
        if (o1 != null && o2 != null) {
            return o1.id === o2.id;
        }
    }

    compareReadWith(o1: any, o2: any): boolean {
        if (o1 && o2) {
            return o1.id === o2.id;
        } else {
            return false;
        }
    }

    compareKey(o1: any, o2: any): boolean {
        if (o1 != null && o2 != null) {
            return o1.key === o2.key;
        }
    }

    getOffenceProvision(id) {
        return this.offenceProvisionMap.get(id);
    }

    getOffenceProvisionReadWiths(id) {
        let offenceProvision = this.getOffenceProvision(id);
        return offenceProvision ? offenceProvision.readWiths : [];
    }

    getOffenceProvisionDescription(id) {
        let offenceProvision = this.getOffenceProvision(id);
        return offenceProvision ? offenceProvision.description : '-';
    }

    offenceProvisionChanged(tgDetailsIndex, rowIndex) {
        var tgDetails = this.tgDetailsForms.at(tgDetailsIndex);
        if (tgDetails != null) {
            var infringements = tgDetails.get('infringements') as FormArray;
            var infringement = infringements.at(rowIndex);
            if (infringement.get('readWith').value) {
                infringement.get('readWith').setValue([]);
            }
        }
    }
}

export function ValidateEmptyString(control: AbstractControl) {
    let offenceProvisionId = control.value.id;
    if (offenceProvisionId == null || offenceProvisionId === '') {
        return { required: true };
    }
    return null;
}