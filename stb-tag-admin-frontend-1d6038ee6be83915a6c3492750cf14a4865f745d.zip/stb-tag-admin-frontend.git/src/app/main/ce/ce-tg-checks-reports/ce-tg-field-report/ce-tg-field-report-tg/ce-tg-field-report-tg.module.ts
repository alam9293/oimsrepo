import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    MatButtonModule,
    MatButtonToggleModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSidenavModule,
    MatSortModule,
    MatTableModule,
    MatTooltipModule,
    MatExpansionModule,
    MatCardModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatCheckboxModule,
} from '@angular/material';
import { RouterModule } from '@angular/router';

import { CeTgFieldReportTgComponent } from './ce-tg-field-report-tg.component';
import { SharedModule } from 'src/app/common/modules/shared.module';
import { CeCaseRelevantOffencesModule } from '../../../ce-case/ce-case-relevant-offences/ce-case-relevant-offences.module';
import { CeTgFieldReportOffencesComponent } from '../ce-tg-field-report-offences/ce-tg-field-report-offences.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        FlexLayoutModule,
        RouterModule,
        SharedModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatDatepickerModule,
        MatDialogModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        MatSelectModule,
        MatSidenavModule,
        MatSortModule,
        MatTableModule,
        MatTooltipModule,
        MatExpansionModule,
        MatCardModule,
        MatRadioModule,
        MatAutocompleteModule,
        MatCheckboxModule,
        CeCaseRelevantOffencesModule
    ],
    declarations: [CeTgFieldReportTgComponent, CeTgFieldReportOffencesComponent],
    exports: [CeTgFieldReportTgComponent,],
    entryComponents: [],
})
export class CeTgFieldReportTgModule { }
