import { Component, HostListener, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { FormUtil, DateUtil } from 'src/app/common/helper';
import { CommonService, AuthenticationService } from 'src/app/common/services';
import * as cnst from '../../../../common/constants';
import { CeTgFieldReportService } from './ce-tg-field-report.service';
import { CeTgFieldReportTgComponent } from './ce-tg-field-report-tg/ce-tg-field-report-tg.component';
import { AttachmentComponent } from 'src/app/common/modules/attachment/attachment.component';

@Component({
    selector: 'app-ce-tg-field-report',
    templateUrl: './ce-tg-field-report.component.html',
    styleUrls: ['./ce-tg-field-report.component.scss']
})
export class CeTgFieldReportViewComponent implements OnInit {

    @ViewChild(CeTgFieldReportTgComponent) ceTgFieldReportTgComponent: CeTgFieldReportTgComponent;
    @ViewChild('att') attachmentsComponent: AttachmentComponent;

    cnst = cnst;
    form: FormGroup;
    report: any = { disableEdit: false, shift: { key: '', label: '' }, location: { key: '', label: '' } };
    declarationText: any;
    ceProvisionForm: any;
    personDetailForm: any;
    approvers: any;
    isValid: Boolean = false;
    allValid: boolean = false;
    fileForm: FormGroup;
    selectedFile: File;
    todayDate = DateUtil.getNow();
    fileColumns = ['fileName', 'description', 'fileSize', 'details', 'Action'];

    constructor(
        private route: ActivatedRoute,
        private fb: FormBuilder,
        private formUtil: FormUtil,
        public authService: AuthenticationService,
        private commonService: CommonService,
        private ceTgFieldReportService: CeTgFieldReportService,
        private router: Router,
        private authenticationService: AuthenticationService,
        private cdRef: ChangeDetectorRef,
    ) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        // this.router.routeReuseStrategy.shouldReuseRoute = () => false; 
        this.router.onSameUrlNavigation = 'reload';

        this.initiateForm();
        this.loadMasterData();
        if (this.route.snapshot.url[1].toString() === 'new') {
            this.newTgFieldReport(+this.route.snapshot.paramMap.get('checkScheduleItemLocationId'));
        } else if (this.route.snapshot.paramMap.get('tgFieldReportId') != 'null') {
            this.loadTgFieldReport(+this.route.snapshot.paramMap.get('tgFieldReportId'));
        }
    }

    ngAfterViewInit() {
        this.loadApproval();
    }

    ngAfterViewChecked() {
        this.cdRef.detectChanges();
    }

    get f() {
        return this.form.controls;
    }

    get fileForms() {
        return this.form.get('files') as FormArray
    }

    newTgFieldReport(checkScheduleItemLocationId) {
        this.ceTgFieldReportService.newTgFieldReport(checkScheduleItemLocationId).subscribe(data => {
            this.report = data;
            this.setupForm(this.report);
        }, error => {

        })
    }

    loadTgFieldReport(fieldReportId) {
        this.ceTgFieldReportService.loadTgFieldReport(fieldReportId).subscribe(data => {
            this.report = data;
            this.setupForm(this.report);
            this.ceTgFieldReportTgComponent.set(data);
        }, error => {

        })
    }

    private setupForm(report: any) {
        this.initiateForm();
        this.form.patchValue(report);

        if (report.files) {
            this.attachmentsComponent.set(report.files);
        }

        if (!this.authenticationService.hasPermission('CE_TG_FIELD_REPORT_SAVE') || this.report.disableEdit) {
            this.form.disable();
        }

        if (this.report.status.key === cnst.Statuses.STAT_CE_SUBMISSION_DRAFT) {
            this.formUtil.markFormGroupTouched(this.form);
        }

    }

    initiateForm() {
        this.form = this.fb.group({
            toSubmit: false,
            ceTgCheckScheduleItemLocationId: '',
            ceTgFieldReportId: '',
            tgDetailsDtos: [[], Validators.required],
            deletedTgDetailsDtos: [],
            detailsTemplate: [],
            details: [null, Validators.required],
            hasConflictInterest: [null, Validators.required],
            infringedTime: [null, Validators.required],
            remarks: [],
            files: [],
            filesToDelete: [],
            eoUser: [],
            approverId: [null, Validators.required], // Approved By
        });
    }

    loadMasterData() {
        this.commonService.getSystemParameter(cnst.SystemParameters.CE_TG_FIELD_REPORT_DECLARATION).subscribe(data => {
            this.declarationText = data.label;
        });
    }

    patchToTgDetailsForm(data) {
        this.ceTgFieldReportTgComponent.loadTgDetails(data);
    }

    loadApproval() {
        this.ceTgFieldReportService.getCeApprovingOfficer().subscribe(data => {
            data.forEach(element => {
                this.approvers = element;

                if (this.report.approverId) {
                    this.form.get('approverId').setValue(this.report.approverId);
                } else {
                    this.form.get('approverId').setValue(element.defaultAssignee);
                }

            });
        });
    }

    getFormData() {
        if (this.ceTgFieldReportTgComponent.tgDetailsForm) {
            this.form.get('tgDetailsDtos').setValue(this.ceTgFieldReportTgComponent.tgDetailsForm.getRawValue().tgDetailsDtos);
            this.form.get('deletedTgDetailsDtos').setValue(this.ceTgFieldReportTgComponent.tgDetailsForm.getRawValue().deletedTgDetailsDtos);
            this.isValid = this.form.valid && this.ceTgFieldReportTgComponent.tgDetailsForm.valid;
        } else {
            this.isValid = this.form.valid;
        }

        return this.form.value;
    }

    submit(toSubmit) {
        this.form.get('toSubmit').patchValue(toSubmit);

        this.formUtil.markFormGroupTouched(this.form);
        this.form.patchValue(this.getFormData());

        if ((toSubmit && this.form.valid && this.isValid) || !toSubmit) {

            if (this.attachmentsComponent.attachmentForm) {
                this.form.get('files').setValue(this.attachmentsComponent.attachments.value);
                this.form.get('filesToDelete').setValue(this.attachmentsComponent.deletedAttachementIds.value);
            }

            this.ceTgFieldReportService.save(this.form.value).subscribe(reportId => {
                this.form.markAsPristine();
                this.commonService.popSnackbar(toSubmit ? 'Field report submitted successfully.' : 'Field report saved successfully.', 'success-snackbar');
                this.router.navigate([cnst.CeFrontEndUrl.TG_FIELD_REPORT + '/' + reportId]);
            }),
                error => {
                    this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                };
        } else {
            this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
        }

    }

    onChangeHasConflictInterest(event) {
        if (event.value === 'true') {
            this.form.get('remarks').setValidators(null);
        }
        if (event.value === 'false') {
            this.form.get('remarks').setValidators(Validators.required);
        }
        this.form.get('remarks').updateValueAndValidity();
    }

    populateTemplate(value) {
        this.form.get('details').setValue(value);
    }
}
