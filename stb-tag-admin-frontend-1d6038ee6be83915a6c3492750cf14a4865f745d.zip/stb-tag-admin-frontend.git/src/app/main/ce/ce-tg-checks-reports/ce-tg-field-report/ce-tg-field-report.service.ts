import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class CeTgFieldReportService {

    constructor(private http: HttpClient) { }

    loadTgFieldReport(tgFieldReportId): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/view/' + tgFieldReportId);
    }

    newTgFieldReport(checkScheduleItemLocationId): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/view/new/' + checkScheduleItemLocationId);
    }

    getPastInfringements(uin: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/view/past-infringements/' + uin);
    }

    save(params: any) {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/save', params);
    }

    getTgDetailsFromUin(uin: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/search/tg/' + uin);
    }

    getLicenceDetailsFromLicenceNo(licenceNo: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/search/tg-licence/' + licenceNo);
    }

    getTravelAgents(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/search/travel-agents');
    }

    getCeApprovingOfficer(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_FIELD_REPORT + '/search/ao');
    }

    getCeProvisions(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.CE_PROVISION + '/view/dropdown/provision-read-with/TG');
    }
}
