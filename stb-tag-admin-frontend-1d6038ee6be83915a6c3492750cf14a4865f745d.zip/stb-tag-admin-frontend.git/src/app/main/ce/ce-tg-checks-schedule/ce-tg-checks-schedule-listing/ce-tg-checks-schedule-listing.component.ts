import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatSort, MatTableDataSource } from '@angular/material';
import { FormBuilder, FormGroup, FormArray, Validators, AbstractControl } from '@angular/forms';
import { CeTgChecksScheduleService } from '../ce-tg-checks-schedule.service';
import { CommonService } from '../../../../common/services'
import { DateUtil } from '../../../../common/helper/date.util';
import * as cnst from '../../../../common/constants';
import { FormUtil } from '../../../../common/helper';

@Component({
    selector: 'app-ce-tg-checks-schedule-listing',
    templateUrl: './ce-tg-checks-schedule-listing.component.html',
    styleUrls: ['./ce-tg-checks-schedule-listing.component.scss']
})
export class CeTgChecksScheduleListingComponent implements OnInit {

    @Input() year: any;
    @Input() fromDate: any;
    @Input() isEditable: number;
    cnst = cnst;

    form: FormGroup;
    ceTgCheckScheduleItems;

    displayedColumns = [
        'date', 'shift', 'location', 'checks', 'remarks', 'eo', 'oeo', 'error'
    ];

    meridiemTypes;
    locationTypes;
    oeoTypes;
    oeoTypesMap = new Map<string, string>();
    eoList;
    eoListMap = new Map<number, string>();
    oeoUnionMap = new Map<string, string>();

    showErrorMsg: boolean = false;

    @ViewChild(MatSort) sort: MatSort;
    constructor(
        private ceTgChecksScheduleService: CeTgChecksScheduleService,
        private commonService: CommonService,
        private formBuilder: FormBuilder,
        private dateUtil: DateUtil,
        public formUtil: FormUtil
    ) { }

    ngOnInit() {

        this.initForm();

        this.commonService.getCeTgScheduleMeridiemTypes().subscribe(data => this.meridiemTypes = data);
        this.commonService.getCeTgScheduleLocationTypes().subscribe(data => this.locationTypes = data);
        this.commonService.getCeOeoTypes().subscribe(data => {
            this.oeoUnionMap = new Map<string, string>();
            this.oeoTypes = data;
            /*data.forEach(x => {
                this.oeoTypesMap.set(x.key, x.label);
            });*/
        });

        //To cater inActive type
        this.commonService.getAllCeOeoTypes().subscribe(data => {
            data.forEach(x => {
                this.oeoTypesMap.set(x.key, x.label);
            });
        });
        this.ceTgChecksScheduleService.getEo().subscribe(data => {
            this.eoList = data;
            data.forEach(x => {
                this.eoListMap.set(x.key, x.label);
            });
        });

        this.loadSchedule(this.year, this.fromDate);

    }

    initForm() {
        this.form = this.formBuilder.group({
            id: [],
            year: [this.year],
            fromDate: [this.fromDate],
            ceTgCheckScheduleItems: this.formBuilder.array([]),
        });
    }

    get scheduleItems() {
        return this.form.get('ceTgCheckScheduleItems') as FormArray;
    }

    loadSchedule(year, fromDate) {
        this.ceTgChecksScheduleService.loadSchedule(year, fromDate).subscribe(data => {
            this.initForm();
            data.ceTgCheckScheduleItems = data.ceTgCheckScheduleItems.filter(item => { return this.isEditable == 1 ? !item.isApproved : item.isApproved });
            this.form.patchValue(data);

            this.ceTgCheckScheduleItems = data.ceTgCheckScheduleItems;

            let control = <FormArray>this.form.get('ceTgCheckScheduleItems');
            this.ceTgCheckScheduleItems.forEach(x => {
                let isEmptyItemLocation = x.ceTgCheckScheduleItemLocations.length == 0;
                control.push(this.formBuilder.group({
                    id: [x.id],
                    scheduleDate: [x.scheduleDate],
                    remarks: [x.remarks, isEmptyItemLocation ? Validators.required : ''],
                    eoUsers: [x.eoUsers, isEmptyItemLocation ? '' : Validators.required],
                    oeoUsers: [x.oeoUsers, isEmptyItemLocation ? '' : Validators.required],
                    ceTgCheckScheduleItemLocations: this.formBuilder.array(x.ceTgCheckScheduleItemLocations.map(y => this.formBuilder.group({
                        id: y.id,
                        meridiem: this.addListable(y.meridiem),
                        location: this.addListable(y.location)
                    }))),
                    ceTgCheckScheduleItemLocationsToBeDeleted: [[]],
                    isEditable: ['']
                }));
            });
        });
    }

    addListable(listableDto) {
        if (listableDto) {
            return this.formBuilder.group({
                key: [listableDto.key, Validators.required],
                label: [listableDto.label]
            });
        }
        else {
            return this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            });
        }
    }

    saveDraft() {
        this.ceTgChecksScheduleService.saveSchedule(this.form.value).subscribe(
            data => {
                this.commonService.popSnackbar(null, 'success-snackbar');
                this.loadSchedule(this.year, this.fromDate);
            },
            error => {
                this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
            }
        );
    }

    getItemLocationCount(index) {
        let itemLocationControl = <FormArray>this.scheduleItems.at(index).get('ceTgCheckScheduleItemLocations');

        return itemLocationControl.value.filter(item => { return (item.location.key && item.meridiem.key) && item.location.key != cnst.tgScheduleLocation.OTHERS }).length;

    }

    addItemLocation(index) {
        let itemControl = this.scheduleItems.at(index);
        let itemLocationControl = <FormArray>itemControl.get('ceTgCheckScheduleItemLocations');

        itemLocationControl.push(this.formBuilder.group({
            id: [],
            meridiem: this.addListable(null),
            location: this.addListable(null)
        }));

        this.updateItemLocationValidator(itemControl);
    }

    removeItemLocation(itemIndex, itemLocationIndex) {
        let itemControl = this.scheduleItems.at(itemIndex);
        let itemLocationControl = <FormArray>itemControl.get('ceTgCheckScheduleItemLocations');
        let itemLocationToBeDeleted = itemControl.get('ceTgCheckScheduleItemLocationsToBeDeleted').value;
        let itemLocation = itemLocationControl.at(itemLocationIndex);

        itemLocationControl.removeAt(itemLocationIndex);
        if (itemLocation.get('id').value) {
            itemLocationToBeDeleted.push(itemLocation.get('id').value);
        }

        this.updateItemLocationValidator(itemControl);

    }

    updateItemLocationValidator(itemControl) {
        let itemLocationControl = <FormArray>itemControl.get('ceTgCheckScheduleItemLocations');

        if (itemLocationControl.value.length == 0) {
            itemControl.get('eoUsers').clearValidators();
            itemControl.get('oeoUsers').clearValidators();
            itemControl.get('remarks').setValidators(Validators.required);
        }
        else {
            itemControl.get('eoUsers').setValidators(Validators.required);
            itemControl.get('oeoUsers').setValidators(Validators.required);
            itemControl.get('remarks').clearValidators();
        }
        itemControl.get('eoUsers').updateValueAndValidity();
        itemControl.get('oeoUsers').updateValueAndValidity();
        itemControl.get('remarks').updateValueAndValidity();
    }

    showErrorMessage(showErrorMsg) {
        this.showErrorMsg = showErrorMsg;
    }

    isEditableItem(scheduleItem): boolean {
        return this.isEditable == 1 && scheduleItem && scheduleItem.isEditable;
    }

    mapEo(key: number) {
        return this.eoListMap.get(key);
    }

    mapOeo(key: string) {
        return this.oeoTypesMap.get(key);
    }
}
