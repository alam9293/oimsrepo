import { CommonModule } from '@angular/common';
import { MainMaterialModule } from '../../../main.material';
import { NgModule } from '@angular/core';
import { CeTgChecksScheduleListingComponent } from './ce-tg-checks-schedule-listing.component';

@NgModule({
    imports: [
        CommonModule,
        MainMaterialModule
    ],
    declarations: [CeTgChecksScheduleListingComponent,],
    exports: [CeTgChecksScheduleListingComponent,],
    entryComponents: [],
})
export class CeTgChecksScheduleListingModule { }
