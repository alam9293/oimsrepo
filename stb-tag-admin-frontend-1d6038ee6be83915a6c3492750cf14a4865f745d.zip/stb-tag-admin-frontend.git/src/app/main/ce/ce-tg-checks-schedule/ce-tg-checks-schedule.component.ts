import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { FormUtil, WorkflowHelper } from '../../../common/helper';
import { CommonService } from '../../../common/services';
import { CeTgChecksScheduleService } from './ce-tg-checks-schedule.service';
import * as cnst from '../../../common/constants';
import { FormGroup, FormBuilder, Validators, } from '@angular/forms';
import { ApplicationWorkflowComponent } from '../../../common/modules/application-workflow/application-workflow.component';
import { CeTgChecksScheduleListingComponent } from './ce-tg-checks-schedule-listing/ce-tg-checks-schedule-listing.component';
import { ConfirmationDialogComponent } from 'src/app/common/modules/confirmation-dialog/confirmation-dialog.component';
import { NoteDialogComponent } from '../../../common/modules/note-dialog/note-dialog.component';
import { WorkflowService } from 'src/app/common/services/workflow.service';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-ce-tg-checks-schedule',
    templateUrl: './ce-tg-checks-schedule.component.html',
    styleUrls: ['./ce-tg-checks-schedule.component.scss']
})
export class CeTgChecksScheduleComponent implements OnInit {

    constructor(
        private fb: FormBuilder,
        private commonService: CommonService,
        private ceTgChecksScheduleService: CeTgChecksScheduleService,
        private snackBar: MatSnackBar,
        public formUtil: FormUtil,
        public dialog: MatDialog,
        public workflowHelper: WorkflowHelper,
        private workflowService: WorkflowService,
        private route: ActivatedRoute,

    ) { }

    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;
    @ViewChild('approvedCeTgChecksScheduleListing') approvedCeTgChecksScheduleListingComponent: CeTgChecksScheduleListingComponent;
    @ViewChild('editableCeTgChecksScheduleListing') editableCeTgChecksScheduleListingComponent: CeTgChecksScheduleListingComponent;

    cnst = cnst;
    form;
    years;
    fromDates;
    activeTab: number = 1;

    schedule: any = { status: {}, workflow: {}, lastAction: {}, lastApprovedAction: {}, lastEditAction: {}, oic: {}, };

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.editableCeTgChecksScheduleListingComponent.form.pristine;
    }

    ngOnInit() {
        this.initForm();
        this.ceTgChecksScheduleService.getYears().subscribe(data => this.years = data);
        this.getFromDates();
        let queryParams = this.route.snapshot.queryParams;
        Object.keys(queryParams).forEach(key => {
            this.form.get(key).setValue(queryParams[key]);
        });
    }

    ngAfterViewInit() {
        this.loadSchedule(false);
    }

    initForm() {
        this.form = this.fb.group({
            id: [],
            fromDate: [moment().day('Monday').add(7, 'days').format('DD-MMM-YYYY'), Validators.required],
            year: [moment().year(), Validators.required],
            internalRemarks: [''],
            approverId: [''],
            supporterId: ['']
        });
    }

    selectYear() {
        this.form.get("fromDate").setValue('');
        this.getFromDates();
    }

    getFromDates() {
        this.ceTgChecksScheduleService.getFromDates(this.form.get('year').value).subscribe(data => this.fromDates = data);
    }

    openNoteDialog() {
        const noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });
        noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.ceTgChecksScheduleService.saveNote(result.params, this.schedule.workflow.workflowId).subscribe(
                    data => {
                        this.workflowComp.loadWorkflowActions();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    searchSchedule(reloadWorkflowlog: boolean) {
        if (!this.editableCeTgChecksScheduleListingComponent.form.pristine) {
            let decision = confirm(cnst.CommonErrorMessages.CAN_DEACTIVATE);
            if (!decision) return;
        }
        this.loadSchedule(reloadWorkflowlog);
    }

    loadSchedule(reloadWorkflowlog: boolean) {

        this.ceTgChecksScheduleService.loadSchedule(this.form.get('year').value, this.form.get('fromDate').value).subscribe(data => {
            this.form.patchValue(data);
            this.schedule = data;
        });

        this.approvedCeTgChecksScheduleListingComponent.loadSchedule(this.form.get('year').value, this.form.get('fromDate').value);
        this.editableCeTgChecksScheduleListingComponent.loadSchedule(this.form.get('year').value, this.form.get('fromDate').value);
        this.editableCeTgChecksScheduleListingComponent.showErrorMessage(false);

        if (reloadWorkflowlog && this.workflowComp) {
            this.workflowComp.loadWorkflowActions();
        }
    }

    saveDraft() {
        this.editableCeTgChecksScheduleListingComponent.saveDraft();
    }
    validateForm(draft: boolean): boolean {
        if (this.form.get('ceTgCheckScheduleItems')) {
            this.form.removeControl('ceTgCheckScheduleItems');
        }
        this.form.addControl('ceTgCheckScheduleItems', this.fb.array(this.editableCeTgChecksScheduleListingComponent.scheduleItems.value));
        if ((!draft && !this.editableCeTgChecksScheduleListingComponent.form.valid) || !this.form.valid) {
            this.formUtil.markFormGroupTouched(this.form);
            this.formUtil.markFormGroupTouched(this.editableCeTgChecksScheduleListingComponent.form);
            this.editableCeTgChecksScheduleListingComponent.showErrorMessage(true);
            this.commonService.popSnackbar(cnst.CommonErrorMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
            return false;
        } else {
            return true;
        }
    }
    submitAction(draft: boolean, action?: any) {

        if (this.validateForm(draft)) {
            if (action) {
                let dialogData: any = {
                    title: 'Action: ' + action.label,
                    internalRemarks: true,
                    externalRemarks: false,
                    action: action,
                    taTg: cnst.CE,
                    appType: cnst.WorkflowTypes.CE_WKFLW_TG_SCHEDULE
                }
                if (!this.schedule.workflow.isFinalApproval && action.name != 'route') {
                    this.workflowService.getCeWorkflowConfigByType(cnst.WorkflowTypes.CE_WKFLW_TG_SCHEDULE).subscribe(data => {
                        // get routing officers
                        dialogData.workflowConfig = data;
                        let confirmationDialogRef = this.dialog.open(ConfirmationDialogComponent, {
                            data: dialogData
                        });
                        confirmationDialogRef.afterClosed().subscribe(result => {
                            if (result.decision) {
                                this.form.patchValue(result.params);
                                this.ceTgChecksScheduleService.submitAction(this.form.value, action.name).subscribe(
                                    data => {
                                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TG'), 'success-snackbar');
                                        this.editableCeTgChecksScheduleListingComponent.form.markAsPristine();
                                        this.loadSchedule(true);
                                    },
                                    error => {
                                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                                    }
                                );
                            }
                        });
                    })
                } else {
                    let confirmationDialogRef = this.dialog.open(ConfirmationDialogComponent, {
                        data: dialogData
                    });
                    confirmationDialogRef.afterClosed().subscribe(result => {
                        if (result.decision) {
                            this.form.patchValue(result.params);
                            this.ceTgChecksScheduleService.submitAction(this.form.value, action.name).subscribe(
                                data => {
                                    this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TG'), 'success-snackbar');
                                    this.editableCeTgChecksScheduleListingComponent.form.markAsPristine();
                                    this.loadSchedule(true);
                                },
                                error => {
                                    this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                                }
                            );
                        }
                    });
                }
            } else {
                this.saveSchedule();
            }
        }
    }

    saveSchedule() {
        this.ceTgChecksScheduleService.saveSchedule(this.form.value).subscribe(
            data => {
                this.commonService.popSnackbar(null, 'success-snackbar');
                this.editableCeTgChecksScheduleListingComponent.form.markAsPristine();
                this.loadSchedule(true);
            },
            error => {
                this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
            }
        );
    }

    reAssign() {
        this.workflowHelper.reAssignCEWorkflow(this.schedule.status.key, this.schedule.workflow.workflowId, null).then(data => {
            if (data) {
                this.loadSchedule(true);
            }
        })
    }
    isPendingSubmission(): boolean {
        return this.schedule.id && this.workflowHelper.isPendingSubmission(this.schedule.status.key, this.schedule.hasEditedAfterApproved);
    }
    isPendingApproval(): boolean {
        return this.workflowHelper.isPendingApproval(this.schedule.status.key);
    }
    isNew(): boolean {
        return this.workflowHelper.isNew(this.schedule.status.key);
    }
    isApproved(): boolean {
        return this.workflowHelper.isApproved(this.schedule.status.key);
    }
}
