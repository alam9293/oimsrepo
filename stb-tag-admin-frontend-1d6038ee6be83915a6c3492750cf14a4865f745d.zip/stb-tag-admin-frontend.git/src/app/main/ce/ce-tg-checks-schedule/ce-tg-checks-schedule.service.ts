import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient, } from '@angular/common/http';
import * as cnst from '../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class CeTgChecksScheduleService {

    constructor(private http: HttpClient) { }

    loadSchedule(year, fromDate): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_SCHEDULE + '/view/' + year + '/' + fromDate);
    }
    getEo(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_SCHEDULE + '/view/eo');
    }
    getYears(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_SCHEDULE + '/view/years');
    }
    getFromDates(year): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_SCHEDULE + '/view/fromDates/' + year);
    }

    saveSchedule(formData: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_SCHEDULE + '/save', formData);
    }

    submitAction(formData: any, action: string) {
        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_SCHEDULE + '/' + action + '/' + formData.id, formData);
    }

    saveNote(params: any, id: any): Observable<any> {

        const files: Array<File> = params.files;

        let formData: FormData = new FormData();
        formData.append('workflowId', id);
        formData.append('internalRemarks', params.internalRemarks);

        if (files) {
            for (let i = 0; i < files.length; i++) {
                formData.append("files", files[i]['file']);
                formData.append("fileDescription", files[i]['fileDescription']);
            }
        }

        return this.http.post(cnst.apiBaseUrl + cnst.CeApiUrl.TG_CHECKS_SCHEDULE + '/notes/save', formData);
    }
}