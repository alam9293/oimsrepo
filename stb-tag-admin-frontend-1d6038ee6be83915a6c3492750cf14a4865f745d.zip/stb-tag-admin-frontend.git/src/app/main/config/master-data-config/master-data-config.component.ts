import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-data-config',
  templateUrl: './master-data-config.component.html',
  styleUrls: ['./master-data-config.component.scss']
})
export class MasterDataConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
