import { Component, OnInit, Input, Output, ViewChild, OnChanges, forwardRef, Injectable, Inject } from '@angular/core';
import { NgxCroppieComponent } from 'ngx-croppie';
import { CroppieOptions } from 'croppie';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FileUtil } from '../../../common/helper';

@Injectable({
    providedIn: 'root'
})
@Component({
    selector: 'app-croppie-form-control',
    templateUrl: './croppie-form-control.component.html',
    styleUrls: ['./croppie-form-control.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CroppieFormControlComponent),
            multi: true
        }
    ]
})

/* Implement the OnInit, OnChanges and ControlValueAccessor interfaces */
export class CroppieFormControlComponent implements OnInit, OnChanges, ControlValueAccessor {
    /* Pass the height of the image to this component */
    @Input()
    public imgCropToHeight = '514';

    /* Pass the width of the image to this component */
    @Input()
    public imgCropToWidth = '400';

    /* Return type of our image */
    @Input()
    private responseType: 'blob' | 'base64' = 'base64';

    /* Our cropped image and the value of our image controller */
    public croppieImage;

    /* Options for the cropped image type and size */
    //error will occur if type is change to this.responseType
    public outputoption = { type: 'blob', size: { width: this.imgCropToWidth, height: this.imgCropToHeight } };

    fileOriginalName: string;
    displayUploadBtn: boolean = true;
    uploadBtnText: string = "Upload";
    imageSrc: any = "./assets/images/tg_photo.png";

    /* Element to paint our form control */
    @ViewChild('ngxCroppie')
    ngxCroppie: NgxCroppieComponent;

    constructor(public dialogRef: MatDialogRef<CroppieFormControlComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private fileUtil: FileUtil, ) { }

    ngOnInit() {
        /* Size the outputoptions of our cropped imaged - whether is base64 or blob */
        this.outputoption = { type: this.responseType, size: { width: this.imgCropToWidth, height: this.imgCropToHeight } };
    }

    ngOnChanges(changes: any) {
        if (this.croppieImage) {
            return;
        }

        if (!changes.imageUrl) {
            return;
        }
        if (!changes.imageUrl.previousValue && changes.imageUrl.currentValue) {
            this.croppieImage = changes.imageUrl.currentValue;
            this.propagateChange(this.croppieImage);
        }
    }

    /**
     * Options for croppie, you can learn more about this here -> https://foliotek.github.io/Croppie/
     */

    public get croppieOptions(): CroppieOptions {
        const opts: CroppieOptions = {};
        opts.viewport = {
            width: parseInt(this.imgCropToWidth, 10) / 2,
            height: parseInt(this.imgCropToHeight, 10) / 2
        };
        opts.boundary = {
            width: parseInt(this.imgCropToWidth, 10) / 2 + 50,
            height: parseInt(this.imgCropToHeight, 10) / 2 + 50
        };
        opts.enforceBoundary = true;

        return opts;
    }

    /**
     * Event to be activated when you select an image
     */
    imageUploadEvent(evt: any) {
        if (!evt.target) {
            return;
        }
        if (!evt.target.files) {
            return;
        }

        if (evt.target.files.length !== 1) {
            return;
        }

        var file = evt.target.files[0];
        if (
            file.type !== 'image/jpeg' &&
            file.type !== 'image/png' &&
            file.type !== 'image/gif' &&
            file.type !== 'image/jpg'
        ) {
            return;
        }
        else {
            var lastDotPosition = file.name.lastIndexOf(".");
            if (lastDotPosition !== -1) {
                this.fileOriginalName = file.name.substr(0, lastDotPosition);
            }
        }

        const fr = new FileReader();
        fr.onloadend = loadEvent => {
            this.croppieImage = fr.result.toString();
            this.displayUploadBtn = false;
        };
        fr.readAsDataURL(file);
    }

    newImageResultFromCroppie(img: string) {
        this.croppieImage = img;
        this.propagateChange(this.croppieImage);
    }

    /* Takes the value  */
    writeValue(value: any) {
        if (value !== undefined || value == 'undefined') {
            this.croppieImage = value;
            this.propagateChange(this.croppieImage);
        }
    }

    propagateChange = (_: any) => { };

    registerOnChange(fn) {
        this.propagateChange = fn;
    }

    registerOnTouched() { }

    cropImage() {
        const reader = new FileReader();
        reader.readAsDataURL(this.croppieImage);
        reader.onload = (e: any) => {
            this.imageSrc = e.target.result;
        }
        this.fileUtil.export(this.croppieImage, this.fileOriginalName + " cropped.png");
        // flush property
        this.displayUploadBtn = true;
        this.uploadBtnText = "Re-Upload";
        this.writeValue(null);
    }

    closeDialog() {
        console.log("close clicked");
        this.dialogRef.close();
    }
}
