export interface AlertDto {
    id: number;
    createdDate: string;
    module: string;
    type: string;
    message: string;
    url: string;
}

export class CardMatIcon {
    public static TA_APP_COMPANY_UPDATE = "business_center";
    public static TA_APP_ABPR_SUBMISSION = 'monetization_on';
    public static TA_APP_AA_SUBMISSION = 'account_balance';
    public static TA_APP_BRANCH = 'business';
    public static TA_APP_TIER_SWITCH = 'swap_horiz';
    public static TA_APP_REPLACEMENT = 'report_problem';
    public static TA_APP_CESSATION = 'remove_circle';
    public static TA_APP_FY_UPDATE = 'date_range';
    public static TA_APP_CREATION = 'add_circle';
    public static TA_APP_RENEWAL = 'refresh';
    public static TA_APP_KE_UPD_DETAILS = 'person';
    public static TA_APP_KE_REASSIGN = 'person';
    public static TA_APP_KE_ASSIGN = 'person';
    public static TA_APP_KE_RESIGN = 'person';
    public static TA_APP_KE = 'person';
    public static TA_APP_NET_VALUE_RECTIFICATION = 'trending_down';
    public static TA_APP_MA_SUBMISSION = 'account_balance';
    public static TA_APP_ADHOC_MA_SUBMISSION = 'account_balance';
    public static TA_APP_ADHOC_DOC_SUBMISSION = 'file_copy';

    public static TA_WKFLW_SHORTFALL = 'trending_down';
    public static TA_WKFLW_RENEW_EX = 'refresh';
    public static TA_WKFLW_EXTENSION_PREM = 'schedule';
    public static TA_WKFLW_EXTENSION_DETL = 'schedule'
    public static TA_WKFLW_ADHOC_MA_REQ = 'assignment';
    public static TA_WKFLW_ADHOC_DOC_REQ = 'assignment';
    public static TA_WKFLW_FILING_AMEND = 'restore_page'

    public static TG_APP_CREATION = "add_circle";
    public static TG_APP_CANCELLATION = 'bar_chart';
    public static TG_APP_RENEWAL = 'refresh';
    public static TG_APP_REINSTATEMENT = 'rotate_right';
    public static TG_APP_REPLACEMENT = 'report_problem';
    public static TG_APP_PERSON_UPDATE = 'person';
    public static TG_APP_MRC_SUBMISSION = 'sms';
    public static TG_APP_PDC_SUBMISSION = 'sms';
    public static TG_APP_COURSE_CREATION = 'school';
    public static TG_APP_STIPEND = 'monetization_on';

    public static DASHBOARD_PAYMENT_PAID = 'monetization_on';
    public static DASHBOARD_PAYMENT_PEND_REFUND = 'monetization_on';
    public static DASHBOARD_PAYMENT_PEND_DISBURSEMENT = 'monetization_on';
    public static DASHBOARD_SHORTFALL_LETTER_PEND_ISSUANCE = 'email';
    public static DASHBOARD_TA_LICENCE_PEND_PRINTING = 'print';
    public static DASHBOARD_STIPEND_FOLLOW_UP_REQUIRED = 'contact_mail';
}

export class CardMatColor {
    public static DASHBOARD_PAYMENT_PAID = 'red';
    public static DASHBOARD_PAYMENT_PEND_REFUND = 'orange';
    public static DASHBOARD_PAYMENT_PEND_DISBURSEMENT = 'green';
}

export const MOCK_STB_ALERTS: AlertDto[] = [
    { id: 1, createdDate: '05-Apr-2018', module: 'TA', type: 'Switch of Licence Tier', message: 'ABC Travels has not submitted since 7 days after Returned for action.', url: '#' },
    { id: 1, createdDate: '05-Apr-2018', module: 'TA', type: 'Switch of Licence Tier', message: 'JapanGo Pte Ltd has paid Licence fee of $400. You may proceed to print the licence.', url: '#' },
    { id: 1, createdDate: '01-Apr-2018', module: 'TG', type: 'Licence Creation', message: 'Sisters Travel Pte Ltd has not paid Licence Fee of $400 since 7 days after approval.', url: '#' },
    { id: 1, createdDate: '28-Jan-2018', module: 'TG', type: 'Licence Creation', message: 'Chan Brothers Travel Pte Ltd has paid Licence Fee of $400. You may proceed to print the licence.', url: '#' },
    { id: 1, createdDate: '28-Jan-2018', module: 'System', type: null, message: 'Some message from a system trigger job that does not have a particular Reference ID.', url: '#' }];
