import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator, MatSort } from '@angular/material';
import * as cnst from '../../common/constants';
import { CommonService, AuthenticationService } from '../../common/services';
import { CardMatIcon, CardMatColor } from './dashboard-dto';
import { DashboardService } from './dashboard.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
    @ViewChild('ceTaskPaginator', { read: MatPaginator }) ceTaskPaginator: MatPaginator;
    @ViewChild(MatSort) ceTaskSort: MatSort;
    pendingActions: any = [];
    otherPendingActions: any = [];
    displayedColumns = ['index', 'createdDate', 'message', 'type', 'remove'];
    resultsLength = 0;
    isLoadingResults = true;
    isRateLimitReached = false;
    cnst = cnst;
    cardMatIcon = CardMatIcon;
    cardBgColor = CardMatColor;
    cardMatColor = ['red', 'orange', 'green', 'blue', 'yellow', 'purple'];
    filter: any = {};
    ceFilter: any = {};
    myTasks: boolean = true;
    ceTasks = [];
    ceTaskDisplayedColumns = ['caseNo', 'status', 'name', 'details', 'sla', 'assignee', 'oic'];
    ceTaskFilterColumns = ['filterCaseNo', 'filterStatus', 'filterName', 'filterDetails', 'filterSla', 'filterAssignee', 'filterOic'];
    viewTypes: any = [];
    dashboardView: any = { viewTypes: [], viewMode: 'my' };
    ceFilterForm: FormGroup;
    ceTaskTypes = [];
    ceTaskStatuses = [];
    ceTaskListingId = 'ce-tasks';
    ceFilterFormInitialData = {
        name: [''],
        caseNo: [''],
        assignee: [''],
        oic: [''],
        sla: [''],
        status: [''],
        details: ['']
    };

    constructor(
        private commonService: CommonService,
        private dashboardService: DashboardService,
        private formBuilder: FormBuilder,
        private authenticationService: AuthenticationService,
    ) { }

    cacheDashboardView() {
        this.commonService.cacheDashboardView(this.dashboardView);
    }
    refreshDashboardView() {
        this.loadPendingApplications();
        this.loadCeTask(false, true)
        this.cacheDashboardView();
    }
    ngOnInit() {
        this.buildForm();
        this.loadMasterData();

        if (this.hasPermission('USR_DASHBOARD_CE_TASK')) {
            this.viewTypes.push({ key: 'ce-task', label: 'C&E Triggers & Tasks' });
        }
        this.viewTypes.push({ key: 'pending-task', label: 'Outstanding Tasks' });

        this.dashboardView = this.commonService.getLastDashboardView(this.dashboardView);
        if (this.dashboardView.viewTypes.length == 0) {
            if (this.hasPermission('USR_DASHBOARD_CE_TASK')) {
                this.dashboardView.viewTypes.push('ce-task');
            }
            this.dashboardView.viewTypes.push('pending-task');// default selected
        }

        this.loadPendingApplications();

        this.ceFilter = this.commonService.getSearchDto(this.ceTaskPaginator, this.ceTaskSort, this.ceFilterForm.value, true, this.ceTaskListingId);
        this.ceFilterForm.patchValue(this.ceFilter);
        this.loadCeTask(false, true);
    }
    ngAfterViewInit() {

    }
    loadMasterData() {
        this.commonService.getCeTaskTypes().subscribe(data => {
            this.ceTaskTypes = data;
        });
        this.commonService.getCeTaskStatuses().subscribe(data => {
            this.ceTaskStatuses = data;
        });
    }
    buildForm() {
        this.ceFilterForm = this.formBuilder.group(this.ceFilterFormInitialData);
        this.ceFilterForm.valueChanges.pipe(debounceTime(400), distinctUntilChanged()).subscribe(data => {
            this.loadCeTask(false, true);
        });
    }
    loadPendingApplications() {
        if (this.dashboardView.viewTypes.includes('pending-task')) {
            this.dashboardService.getPendingActions(this.dashboardView.viewMode).subscribe(data => this.pendingActions = data);
            this.dashboardService.getOtherPendingActions(this.dashboardView.viewMode).subscribe(data => this.otherPendingActions = data);
        }
    }

    loadCeTask(fromCache: boolean, resetPageIndex?: boolean) {
        if (this.dashboardView.viewTypes.includes('ce-task')) {
            setTimeout(() => { // must put this, otherwise will fire hundreds api call...
                if (resetPageIndex) {
                    this.ceTaskPaginator.pageIndex = 0;
                }
                this.ceFilter = this.commonService.getSearchDto(this.ceTaskPaginator, this.ceTaskSort, this.ceFilterForm.value, fromCache, this.ceTaskListingId);
                this.dashboardService.getCeTasks(this.dashboardView.viewMode, this.ceFilter).subscribe(data => {
                    this.ceTasks = data.records;
                    this.ceTaskPaginator.length = data.total;
                    this.commonService.cacheSearchDto(this.ceFilter);
                });
            });
        }
    }

    setParams(params): any {
        let dto = {};
        Object.keys(params).forEach(key => dto[key] = params[key]);
        return dto;
    }

    hasPermission(permission): boolean {
        return this.authenticationService.hasPermission(permission);
    }

    clearCeFilter() {
        this.ceFilterForm.patchValue(this.ceFilterFormInitialData);
    }
}
