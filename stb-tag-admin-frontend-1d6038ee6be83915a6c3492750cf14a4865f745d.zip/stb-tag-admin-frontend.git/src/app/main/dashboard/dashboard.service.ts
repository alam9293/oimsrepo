import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as dto from './dashboard-dto';
import * as cnst from '../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {

    constructor(private http: HttpClient) { }

    getAlerts(searchDto: any): Observable<any> {
        return this.http.get<any[]>(cnst.apiBaseUrl + '/dashboard/alerts', { params: searchDto });
    }

    getPendingActions(selection: string): Observable<any[]> {
        return this.http.get<any[]>(cnst.apiBaseUrl + '/dashboard/officer/pending-actions/' + selection);
    }

    getOtherPendingActions(selection: string): Observable<any[]> {
        return this.http.get<any[]>(cnst.apiBaseUrl + '/dashboard/officer/other-pending-actions/' + selection);
    }

    getCeTasks(selection: string, searchDto: any): Observable<any> {
        return this.http.get<any[]>(cnst.apiBaseUrl + '/dashboard/officer/ce-tasks/' + selection, { params: searchDto });
    }

    deleteAlert(id: number) {
        return this.http.post(cnst.apiBaseUrl + '/dashboard/alerts/delete/' + id, null);
    }
}
