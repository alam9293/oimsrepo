import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as cnst from '../../../common/constants';
import { EmailBroadcastService } from '../email-broadcast.service';
import { MatPaginator, MatSort } from '@angular/material';
import { WorkflowHelper } from 'src/app/common/helper';
import { SelectionModel } from '@angular/cdk/collections';
import { CommonService } from 'src/app/common/services';
@Component({
  selector: 'app-email-broadcast-list-component',
  templateUrl: './email-broadcast-list.component.html',
  styleUrls: ['./email-broadcast-list.component.scss']
})
export class EmailBroadcastListComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  emailType = this.route.snapshot.queryParamMap.get('emailType');
  cnst = cnst;
  filter: any = {};
  listingId = "email-broadcast-list-" + this.emailType;
  displayedColumns = ['no', 'subject', 'isActive', 'startDate', 'endDate', 'isRecurring', 'nextEmailDate', 'lastSentDateTime', 'edit'];
  rows = [];
  accessType: string;
  constructor(
    private route: ActivatedRoute,
    private emailBroadcastService: EmailBroadcastService,
    public workflowHelper: WorkflowHelper,
    private commonService: CommonService, ) { }

  ngOnInit() {
    this.loadList(true);
    if (this.emailType === cnst.TG) {
      this.accessType = 'TG_EMAIL_BROADCAST_UPDATE'
    }
    if (this.emailType === cnst.TA) {
      this.accessType = 'TA_EMAIL_BROADCAST_UPDATE'
      this.displayedColumns.push('status');
    }
  }

  loadList(fromInit: boolean): void {
    this.workflowHelper.selection = new SelectionModel<any>(true, []);
    this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromInit, this.listingId);
    this.emailBroadcastService.getEmailList(this.filter, this.emailType).subscribe(data => {
      this.rows = data.records;
      this.paginator.length = data.total;
      this.commonService.cacheSearchDto(this.filter);
    });
  }

}
