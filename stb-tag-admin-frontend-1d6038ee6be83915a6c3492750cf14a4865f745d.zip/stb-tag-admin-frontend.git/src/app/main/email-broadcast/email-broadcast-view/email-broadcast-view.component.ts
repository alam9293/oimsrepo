import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { MatDialog, MatDialogRef, MatDrawer } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import insertTextAtCursor from 'insert-text-at-cursor';
import { Observable } from 'rxjs';
import { FormUtil, DateUtil } from 'src/app/common/helper';
import { AttachmentComponent } from 'src/app/common/modules/attachment/attachment.component';
import { ConfirmationDialogComponent } from 'src/app/common/modules/confirmation-dialog/confirmation-dialog.component';
import { CommonService, AlertService } from 'src/app/common/services';
import * as cnst from '../../../common/constants';
import { EmailBroadcastService } from '../email-broadcast.service';
import { Location } from '@angular/common';
import * as Quill from 'quill';

@Component({
    selector: 'app-email-broadcast-view-component',
    templateUrl: './email-broadcast-view.component.html',
    styleUrls: ['./email-broadcast-view.component.scss']
})
export class EmailBroadcastViewComponent implements OnInit {
    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(AttachmentComponent) emailAttachmentsComponent: AttachmentComponent;
    constructor(
        private route: ActivatedRoute,
        private commonService: CommonService,
        private fb: FormBuilder,
        private emailBroadcastService: EmailBroadcastService,
        private formUtil: FormUtil,
        private dialog: MatDialog,
        private alertService: AlertService,
        private location: Location,
    ) { }
    subjectPlaceholder: string;
    placeholderList: any;
    placeholders: any;
    frequencyList: any;
    emailType = this.route.snapshot.queryParamMap.get('emailType');
    accessType: string;
    cnst = cnst;
    dataSearch: any = {};
    minEndDate: any;
    form: FormGroup;
    application: any = {};
    languageList: any = [];
    licenceTypeList: any = [];
    licenceStatusList: any = [];
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }
    quill = new Quill('#editor', {
        theme: 'snow'
    });

    ngOnInit() {
        this.matDrawer.toggle();
        this.initiateForm();
        this.loadCommonTypes();
        if (this.route.snapshot.queryParamMap.get('id')) {
            this.dataSearch.id = this.route.snapshot.queryParamMap.get('id')
        }
        this.formatQuillEditorIcon();
        this.loadEmail();
    }

    loadCommonTypes() {
        this.commonService.getEmailBroadcastFreq().subscribe(data => this.frequencyList = data);
        if (this.emailType === cnst.TG) {
            this.commonService.getTgGuidingLanguages().subscribe(data => this.languageList = data);
            this.commonService.getTgLicenceTiers().subscribe(data => this.licenceTypeList = data);
            this.commonService.getTgLicenceStatuses().subscribe(data => this.licenceStatusList = data);
            this.accessType = 'TG_EMAIL_BROADCAST_UPDATE'
            this.placeholderList = cnst.TgEmailBroadcastPlaceholders
            this.placeholders = this.placeholderList.map(placeholder => placeholder.key);
            this.form.get('licenceStatuses').setValidators([Validators.required]);
        }
        if (this.emailType === cnst.TA) {
            this.accessType = 'TA_EMAIL_BROADCAST_UPDATE'
            this.placeholderList = cnst.TaEmailBroadcastPlaceholders
            this.placeholders = this.placeholderList.map(placeholder => placeholder.key);
            this.form.get('licenceStatuses').clearValidators();
        }
        this.form.get('licenceStatuses').updateValueAndValidity();
    }

    get freqFormControl() {
        return (this.form.get('frequency') as FormGroup).controls
    }


    initiateForm() {
        this.form = this.fb.group({
            isActive: [,],
            toSend: [,],
            id: '',
            subject: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            content: ['', [Validators.required, Validators.maxLength(cnst.maxLengthText)]],
            isRecurring: [,],
            startDate: [,],
            endDate: [,],
            frequency: this.formUtil.listableForm(this.fb, false),
            emailType: this.formUtil.listableForm(this.fb, false),
            licenceIds: [,],
            files: [],
            deletedFiles: [],
            licenceStatuses: [],
            tiers: [],
            guidingLanguages: [],
        });

    }

    loadEmail() {
        this.emailBroadcastService.loadEmail(this.dataSearch, this.emailType).subscribe(data => {
            this.application = data;
            this.setupForm(this.application);
            this.form.get('startDate').setValidators([Validators.required, ValidateStartDate(DateUtil.parseDate(this.application.startDate))]);
            this.form.get('startDate').updateValueAndValidity();

            this.form.get('isRecurring').valueChanges.subscribe(val => {
                if (val) {
                    this.form.get('endDate').setValidators([Validators.required]);
                    this.form.get('frequency.key').setValidators([Validators.required]);
                } else {
                    this.form.get('endDate').clearValidators();
                    this.form.get('frequency.key').clearValidators();
                }
                this.form.get('endDate').updateValueAndValidity();
                this.form.get('frequency.key').updateValueAndValidity();
            });

            this.form.get('isActive').valueChanges.subscribe(val => {
                if (val) {
                    this.form.get('startDate').setValidators([Validators.required, ValidateStartDate(DateUtil.parseDate(this.application.startDate))]);
                } else {
                    this.form.get('startDate').clearValidators();
                }
                this.form.get('startDate').updateValueAndValidity();
            });

            this.form.get('startDate').valueChanges.subscribe(val => {
                if (val) {
                    this.minEndDate = DateUtil.parseDate(val).add(1, 'day');
                } else {
                    this.minEndDate = this.application.minStartDate
                }
            });

            this.loadQuillEditor();
            if (this.application.isSending) {
                this.form.disable();
                this.alertService.error("Email sending is in progress, no changes can be made until the sending is completed.");
                this.quill.enable(false);
            }
        }, error => {

        })
    }

    formatQuillEditorIcon() {
        var Align = Quill.import('attributors/style/align');
        var icons = Quill.import('ui/icons');

        icons.align['left'] = icons.align['']; // set icon for 'left' option, otherwise it's replaced with 'undefined' text
        Align.whitelist = ['left', 'center', 'right']; // add explicit 'left' option
    }

    loadQuillEditor() {
        this.cleanEditorCache();
        this.quill = new Quill('#editor', {
            theme: 'snow',
            modules: {
                table: true,
                history: {
                    delay: 1000
                },
                toolbar: {
                    container:
                        [
                            [{ 'placeholder': this.placeholders },
                            { 'header': [1, 2, 3, 4, 5, 6, false] },
                                'bold', 'italic', 'underline',
                            { 'list': 'ordered' },
                            { 'list': 'bullet' },
                            { 'align': ['left', 'right', 'center'] },
                                'link', 'clean'], ['table', 'column-left', 'column-right', 'row-above', 'row-below', 'row-remove', 'column-remove']],
                    handlers: {
                        "placeholder": function (value) {
                            if (value) {
                                value = "${" + value + "}";
                                const cursorPosition = this.quill.getSelection().index;
                                this.quill.insertText(cursorPosition, value);
                                this.quill.setSelection(cursorPosition + value.length);
                                var bounds = this.quill.getBounds(10, 20);
                                this.quill.container.scrollTop = bounds.left;
                            }
                        }
                    }
                }
            }
        });

        this.buildTableFunction();

        const placeholderPickerItems = Array.prototype.slice.call(document.querySelectorAll('.ql-placeholder .ql-picker-item'));
        placeholderPickerItems.forEach(item => item.textContent = item.dataset.value);

        document.querySelector('.ql-placeholder .ql-picker-label').innerHTML = 'Insert placeholder' + '&nbsp;&nbsp;&nbsp;&nbsp;'
            + document.querySelector('.ql-placeholder .ql-picker-label').innerHTML;

        this.quill.clipboard.dangerouslyPasteHTML(0, this.form.get('content').value);
    }

    buildTableFunction() {
        let table = this.quill.getModule('table');
        Quill.register(table, true);

        document.querySelectorAll('.ql-column-left').forEach(button => {
            button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-left-square" viewBox="0 0 16 16"><path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/><path d="M10.205 12.456A.5.5 0 0 0 10.5 12V4a.5.5 0 0 0-.832-.374l-4.5 4a.5.5 0 0 0 0 .748l4.5 4a.5.5 0 0 0 .537.082z"/></svg>'
            button.addEventListener('click', () => {
                table.insertColumnLeft();
            });
        });

        document.querySelectorAll('.ql-column-right').forEach(button => {
            button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-right-square" viewBox="0 0 16 16"><path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/><path d="M5.795 12.456A.5.5 0 0 1 5.5 12V4a.5.5 0 0 1 .832-.374l4.5 4a.5.5 0 0 1 0 .748l-4.5 4a.5.5 0 0 1-.537.082z"/></svg>';
            button.addEventListener('click', () => {
                table.insertColumnRight();
            });
        });

        document.querySelectorAll('.ql-row-above').forEach(button => {
            button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-up-square" viewBox="0 0 16 16"><path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/><path d="M3.544 10.705A.5.5 0 0 0 4 11h8a.5.5 0 0 0 .374-.832l-4-4.5a.5.5 0 0 0-.748 0l-4 4.5a.5.5 0 0 0-.082.537z"/></svg>';
            button.addEventListener('click', () => {
                table.insertRowAbove();
            });
        });

        document.querySelectorAll('.ql-row-below').forEach(button => {
            button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down-square" viewBox="0 0 16 16"><path d="M3.626 6.832A.5.5 0 0 1 4 6h8a.5.5 0 0 1 .374.832l-4 4.5a.5.5 0 0 1-.748 0l-4-4.5z"/><path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm15 0a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2z"/></svg>'
            button.addEventListener('click', () => {
                table.insertRowBelow();
            });
        });

        document.querySelectorAll('.ql-row-remove').forEach(button => {
            button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dash-square" viewBox="0 0 16 16"><path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/><path d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8z"/></svg>';
            button.addEventListener('click', () => {
                table.deleteRow();
            });
        });

        document.querySelectorAll('.ql-column-remove').forEach(button => {
            button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-square" viewBox="0 0 16 16"><path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/><path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg>';
            button.addEventListener('click', () => {
                table.deleteRow();
            });
        });
    }

    cleanEditorCache() {
        //remove all the cache html
        var fieldDiv = document.getElementById('editor');
        fieldDiv.innerHTML = "";
        var elements = document.getElementsByClassName("ql-toolbar ql-snow");
        while (elements.length > 0) {
            elements[0].parentNode.removeChild(elements[0]);
        }
    }

    private setupForm(application: any) {
        this.form.patchValue(application);
        if (application.files) {
            this.emailAttachmentsComponent.set(application.files);
        }
        this.form.markAsPristine();
    }

    validateField() {
        var content = this.form.get('content').value.replace("<p>", "").replace("</p>", "").replace("<br>", "");
        if (content == "") {
            this.commonService.popSnackbar("Content must not be empty.", 'error-snackbar');
            throw Error("Content must not be empty.");
        }
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    saveAndSend(toSend) {
        this.form.get('toSend').setValue(toSend);
        this.form.get('content').setValue('<style type="text/css">table, th, td {border: 1px solid black;}</style>' + this.quill.container.firstChild.innerHTML.trim());
        this.validateField();
        this.formUtil.markFormGroupTouched(this.form);
        console.log(this.form);
        if (this.form.valid) {
            if (this.emailAttachmentsComponent.attachmentForm) {
                this.form.get('files').setValue(this.emailAttachmentsComponent.attachments.value);
                this.form.get('deletedFiles').setValue(this.emailAttachmentsComponent.deletedAttachementIds.value);
            }
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: toSend ? "The email broadcast will be sent immediately." : "Update Confirmation"
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result && result.decision) {
                    this.emailBroadcastService.save(this.form.value, this.emailType).subscribe(
                        data => {
                            this.dataSearch.id = data['id'];
                            this.form.reset();
                            this.loadEmail();
                            if (toSend) {
                                this.emailBroadcastService.send(this.dataSearch, this.emailType).subscribe(
                                    data => {

                                    });
                            }
                            var msg = cnst.Messages.GENERIC_SUCCCESS
                            if (data['isSending']) {
                                msg += 'Email sending is in progress.';
                                if (this.emailType === cnst.TA) {
                                    this.form.markAsPristine();
                                    this.location.back();
                                }
                            }
                            this.commonService.popSnackbar(data['snackbarMessage'] ? data['snackbarMessage'] : msg, data['snackbarMessage'] ? 'warn-snackbar' : 'success-snackbar');
                        },
                        error => {
                            this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                        });
                }
            });
        } else {
            this.commonService.popSnackbar(cnst.TaAlertMessages.MSG_INCOMPLETE_FORM, 'error-snackbar');
        }
    }
    insertPlaceholder(elId, placeholder) {
        if (placeholder) {
            const el = document.getElementById(elId);
            insertTextAtCursor(el, '${' + placeholder + '}');
        }
    }
}

export function ValidateStartDate(date) {
    const validator: ValidatorFn = (control: AbstractControl) => {
        var value = DateUtil.parseDate(control.value);
        var today = DateUtil.getNow();
        return value && date && DateUtil.differenceInDay(date, value) != 0 && value.isBefore(today) ? { 'invalidDate': true } : null;
    };
    return validator;
}