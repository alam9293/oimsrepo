import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../common/constants';
import { AuthenticationService } from '../../common/services';

@Injectable({
    providedIn: 'root'
})
export class EmailBroadcastService {

    constructor(private http: HttpClient,
        private authenticationService: AuthenticationService) { }

    getEmailList(searchDto: any, type: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/email-broadcast/' + type + '/search/', { params: searchDto });
    }

    loadEmail(searchData, type: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/email-broadcast/' + type + '/view/', { params: searchData });
    }

    save(params: any, type: string) {
        return this.http.post(cnst.apiBaseUrl + '/email-broadcast/' + type + '/update', params);
    }

    send(params: any, type: string) {
        return this.http.post(cnst.apiBaseUrl + '/email-broadcast/' + type + '/update/send-email', params);
    }

}