import { Component, OnInit, HostListener, SimpleChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService, AlertService, CommonService } from '../../common/services';
import { LoginService } from './login.service';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { first } from 'rxjs/operators';
import * as cnst from '../../common/constants';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    returnUrl: string;
    error = '';
    loginForm: any = {};
    autoLogin: boolean = false;
    cnst = cnst;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private commonService: CommonService,
        private loginService: LoginService,
        private alertService: AlertService
    ) {
        // redirect to home if already logged in
        if (this.authenticationService.currentUserValue) {
            this.router.navigate(['/']);
        }
    }

    ngOnInit() {
        this.authenticationService.logout();
        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

        this.commonService.getBypassIams().subscribe(data => {
            this.autoLogin = data;
            if (this.autoLogin) {
                this.loginSSO();
            }
        });
    }

    onLogin() {
        this.error = '';
        if (this.loginForm.username && this.loginForm.password && !this.autoLogin) {
            this.authenticationService.login(this.loginForm.username, this.loginForm.password)
                .pipe(first())
                .subscribe(
                    data => {
                        if (data.auth) {
                            this.router.navigate([this.returnUrl]);
                        } else {
                            this.error = data.reason;
                        }
                    },
                    error => {
                        this.error = error;
                    });
        } else {
            this.error = 'User Name and Password are mandatory';
        }
    }

    loginSSO() {
        this.error = '';
        if (this.autoLogin) {
            this.authenticationService.loginSSO()
                .pipe(first())
                .subscribe(
                    data => {
                        if (data.auth) {
                            this.router.navigate([this.returnUrl]);
                        } else {
                            this.error = data.reason;
                        }
                    },
                    error => {
                        this.error = error.error.message;
                    });
        }
    }

    result: any = {};
    setDate() {
        this.loginService.setDate(this.loginForm).subscribe(data => {
            this.result = data;
            console.log('set date result:' + JSON.stringify(this.result, null, 2));
            this.loginForm.datetime = this.result.datetime;
            this.loginForm.date = this.result.date;
        })
    }

    getDate() {
        this.loginService.getDate(this.loginForm).subscribe(data => {
            this.result = data;

            console.log('get date result:' + JSON.stringify(this.result, null, 2));
            this.loginForm.datetime = this.result.datetime;
            this.loginForm.date = this.result.date;
        })
    }
}
