import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class LoginService {

    constructor(private http: HttpClient) { }

    setDate(searchDto: any): Observable<any> {
        return this.http.post<any>(cnst.apiBaseUrl + '/test/set-date', searchDto);
    }
    getDate(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/test/get-date', { params: searchDto });
    }
}
