// Others
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import * as cnst from '../common/constants';
// TA
import { TaLicenceListComponent } from './ta/ta-licence/ta-licence-list/ta-licence-list.component';
import { TaLicenceViewComponent } from './ta/ta-licence/ta-licence-view/ta-licence-view.component';
import { TaApplicationListComponent } from './ta/ta-application/ta-application-list/ta-application-list.component';
import { TaMainListComponent } from './ta/ta-main-process/ta-main-list/ta-main-list.component';
import { TaMainViewComponent } from './ta/ta-main-process/ta-main-view/ta-main-view.component';
import { TaCeaseListComponent } from './ta/ta-cessation-process/ta-cease-list/ta-cease-list.component';
import { TaCeaseViewComponent } from './ta/ta-cessation-process/ta-cease-view/ta-cease-view.component';
import { TaSwitchListComponent } from './ta/ta-switch-process/ta-switch-list/ta-switch-list.component';
import { TaSwitchViewComponent } from './ta/ta-switch-process/ta-switch-view/ta-switch-view.component';
import { TaReplaceListComponent } from './ta/ta-replacement-process/ta-replace-list/ta-replace-list.component';
import { TaReplaceViewComponent } from './ta/ta-replacement-process/ta-replace-view/ta-replace-view.component';
import { TaBranchListComponent } from './ta/ta-branch-process/ta-branch-list/ta-branch-list.component';
import { TaBranchViewComponent } from './ta/ta-branch-process/ta-branch-view/ta-branch-view.component';
import { TaPersonnelListComponent } from './ta/ta-personnel/ta-personnel-list/ta-personnel-list.component';
import { TaPersonnelViewComponent } from './ta/ta-personnel/ta-personnel-view/ta-personnel-view.component';
import { TaShortfallFulfilmentListComponent } from './ta/ta-shortfall-fulfillment/ta-shortfall-fulfilment-list/ta-shortfall-fulfilment-list.component';
import { TaShortfallFulfilmentViewComponent } from './ta/ta-shortfall-fulfillment/ta-shortfall-fulfilment-view/ta-shortfall-fulfilment-view.component';
import { TaAbprListComponent } from './ta/ta-abpr-process/ta-abpr-list/ta-abpr-list.component';
import { TaAbprViewComponent } from './ta/ta-abpr-process/ta-abpr-view/ta-abpr-view.component';
import { TaPortalComponent } from './system/portal/ta-portal/ta-portal.component';
import { TaPortalApplyPreambleComponent } from './system/portal/ta-portal/ta-portal-apply/ta-portal-apply-preamble/ta-portal-apply-preamble.component';
import { TaPortalApplyFormComponent } from './system/portal/ta-portal/ta-portal-apply/ta-portal-apply-form/ta-portal-apply-form.component';
import { TaKeUpdateListComponent } from './ta/ta-ke-update/ta-ke-update-list/ta-ke-update-list.component';
import { TaKeUpdateViewComponent } from './ta/ta-ke-update/ta-ke-update-view/ta-ke-update-view.component';
import { TaAaListComponent } from './ta/ta-aa-process/ta-aa-list/ta-aa-list.component';
import { TaAaViewComponent } from './ta/ta-aa-process/ta-aa-view/ta-aa-view.component';
import { TaFyeListComponent } from './ta/ta-fye-process/ta-fye-list/ta-fye-list.component';
import { TaFyeViewComponent } from './ta/ta-fye-process/ta-fye-view/ta-fye-view.component';
import { TaPortalPersonnelListComponent } from './system/portal/ta-portal/ta-portal-personnel-list/ta-portal-personnel-list.component';
import { TaCompanyUpdateViewComponent } from './ta/ta-company-update/ta-company-update-view/ta-company-update-view.component';
import { TaCompanyUpdateListComponent } from './ta/ta-company-update/ta-company-update-list/ta-company-update-list.component';
import { TaOfflineAaComponent } from './ta/ta-offline-aa/ta-offline-aa.component';
import { TaReturnListComponent } from './ta/ta-return-licence/ta-return-list/ta-return-list.component';
import { TaReturnViewComponent } from './ta/ta-return-licence/ta-return-view/ta-return-view.component';
import { TaRenewalListComponent } from './ta/ta-renewal-process/ta-renewal-list/ta-renewal-list.component';
import { TaRenewalViewComponent } from './ta/ta-renewal-process/ta-renewal-view/ta-renewal-view.component';
import { TaRenewalExerciseComponent } from './ta/ta-renewal-exercise/ta-renewal-exercise.component';
import { TaMaListComponent } from './ta/ta-ma-process/ta-ma-list/ta-ma-list.component';
import { TaMaViewComponent } from './ta/ta-ma-process/ta-ma-view/ta-ma-view.component';
import { TaWorkflowProcessComponent } from './ta/ta-workflow-process/ta-workflow-process.component';
import { TaManageShortfallListComponent } from './ta/ta-manage-shortfall-process/ta-manage-shortfall-list/ta-manage-shortfall-list.component';
import { TaManageShortfallViewComponent } from './ta/ta-manage-shortfall-process/ta-manage-shortfall-view/ta-manage-shortfall-view.component';
import { TaManageFilingListComponent } from './ta/ta-manage-filing-process/ta-manage-filing-list/ta-manage-filing-list.component';
import { TaManageFilingViewComponent } from './ta/ta-manage-filing-process/ta-manage-filing-view/ta-manage-filing-view.component';
import { TaLicencePrintListComponent } from './ta/ta-licence-print/ta-licence-print-list/ta-licence-print-list.component';
import { TaOfflineAbprComponent } from './ta/ta-offline-abpr/ta-offline-abpr.component';
import { TaOfflineCessationComponent } from './ta/ta-offline-cessation/ta-offline-cessation.component';
import { TaOfflineCompanyUpdateComponent } from './ta/ta-offline-company-update/ta-offline-company-update.component';
import { TaFilingRequestListComponent } from './ta/ta-filing-request-process/ta-filing-request-list/ta-filing-request-list.component';
import { TaFilingRequestViewComponent } from './ta/ta-filing-request-process/ta-filing-request-view/ta-filing-request-view.component';
import { TaAdhocDocListComponent } from './ta/ta-adhoc-doc-process/ta-adhoc-doc-list/ta-adhoc-doc-list.component';
import { TaAdhocDocViewComponent } from './ta/ta-adhoc-doc-process/ta-adhoc-doc-view/ta-adhoc-doc-view.component';
import { TaELicenceListComponent } from './ta/ta-e-licence/ta-e-licence-list/ta-e-licence-list.component';
import { TaELicenceViewComponent } from './ta/ta-e-licence/ta-e-licence-view/ta-e-licence-view.component';

// TG
import { TgPortalComponent } from './system/portal/tg-portal/tg-portal.component';
import { TgAllApplicationsComponent } from './tg/tg-all-applications/tg-all-applications.component';
import { TgApplicationListComponent } from './tg/tg-application-process/tg-application-list/tg-application-list.component';
import { TgApplicationViewComponent } from './tg/tg-application-process/tg-application-view/tg-application-view.component';
import { TgRenewalListComponent } from './tg/tg-renewal-process/tg-renewal-list/tg-renewal-list.component';
import { TgRenewalViewComponent } from './tg/tg-renewal-process/tg-renewal-view/tg-renewal-view.component';
import { TgLostLicenceListComponent } from './tg/tg-lost-licence-process/tg-lost-licence-list/tg-lost-licence-list.component';
import { TgLostLicenceViewComponent } from './tg/tg-lost-licence-process/tg-lost-licence-view/tg-lost-licence-view.component';
import { TgCancelViewComponent } from './tg/tg-cancel-process/tg-cancel-view/tg-cancel-view.component';
import { TgUpdateParticularsListComponent } from './tg/tg-update-particulars/tg-update-particulars-list/tg-update-particulars-list.component';
import { TgUpdateParticularsViewComponent } from './tg/tg-update-particulars/tg-update-particulars-view/tg-update-particulars-view.component';
import { TgLicencePrintingListComponent } from './tg/tg-licence-printing-process/tg-licence-printing-list/tg-licence-printing-list.component';
import { TgLicenceSearchListComponent } from './tg/tg-licence-search/tg-licence-search-list/tg-licence-search-list.component';
import { TgLicenceSearchViewComponent } from './tg/tg-licence-search/tg-licence-search-view/tg-licence-search-view.component';
import { TgCourseListComponent } from './tg/tg-course-process/tg-course-list/tg-course-list.component';
import { TgCourseViewComponent } from './tg/tg-course-process/tg-course-view/tg-course-view.component';
import { TgCandidateListComponent } from './tg/tg-candidate-process/tg-candidate-list/tg-candidate-list.component';
import { TgCandidateViewComponent } from './tg/tg-candidate-process/tg-candidate-view/tg-candidate-view.component';
import { TgMlptAllocateComponent } from './tg/tg-mlpt-process/tg-mlpt-allocate/tg-mlpt-allocate.component';
import { TgMlptCreateListComponent } from './tg/tg-mlpt-process/tg-mlpt-create/tg-mlpt-create-list/tg-mlpt-create-list.component';
import { TgMlptCreateViewComponent } from './tg/tg-mlpt-process/tg-mlpt-create/tg-mlpt-create-view/tg-mlpt-create-view.component';
import { TgMlptUpdateComponent } from './tg/tg-mlpt-process/tg-mlpt-update/tg-mlpt-update.component';
import { TgWorkflowProcessComponent } from './tg/tg-workflow-process/tg-workflow-process.component';
import { TgTrainingProviderListComponent } from './tg/tg-tp-process/tg-tp-list/tg-tp-list.component';
import { TgTrainingProviderViewComponent } from './tg/tg-tp-process/tg-tp-view/tg-tp-view.component';
import { TgCourseCriteriaComponent } from './tg/tg-course-criteria/tg-course-criteria.component';
import { TgTpCourseRenewalViewComponent } from './tg/tg-tp-course-renewal/tg-tp-course-renewal-view/tg-tp-course-renewal-view.component';
import { TgTpCourseCreationViewComponent } from './tg/tg-tp-course-creation-process/tg-tp-course-creation-view/tg-tp-course-creation-view.component';
import { TgTpCourseCreationListComponent } from './tg/tg-tp-course-creation-process/tg-tp-course-creation-list/tg-tp-course-creation-list.component';

//CE
import { CeTaChecksScheduleComponent } from './ce/ce-ta-checks-schedule/ce-ta-checks-schedule.component';
import { CeTaChecksReportsListComponent } from './ce/ce-ta-checks-reports/ce-ta-checks-reports-list/ce-ta-checks-reports-list.component';
import { CeTatiCheckViewComponent } from './ce/ce-ta-checks-reports/ce-tati-check-view/ce-tati-check-view.component';
import { CeTaFieldReportViewComponent } from './ce/ce-ta-checks-reports/ce-ta-field-report-view/ce-ta-field-report-view.component';
import { CeTgChecksScheduleComponent } from './ce/ce-tg-checks-schedule/ce-tg-checks-schedule.component';
import { CeCaseComponent } from './ce/ce-case/ce-case.component';
import { CeIpComponent } from './ce/ce-ip/ce-ip.component';
import { CeDirectoryListComponent } from './ce/ce-directory/ce-directory-list.component';
import { CeTgChecksReportsListComponent } from './ce/ce-tg-checks-reports/ce-tg-checks-reports-list/ce-tg-checks-reports-list.component';
import { CeGroundCheckViewComponent } from './ce/ce-tg-checks-reports/ce-ground-check-view/ce-ground-check-view.component';
import { CeTgFieldReportViewComponent } from './ce/ce-tg-checks-reports/ce-tg-field-report/ce-tg-field-report.component';
import { CeTatiCheckAckComponent } from './ce/ce-ta-checks-reports/ce-tati-check-ack/ce-tati-check-ack.component';
import { CeProvisionConfigComponent } from './ce/ce-provision-config/ce-provision-config.component';

//Payment
import { PaymentRequestListComponent } from './payment/payment-request/payment-request-list/payment-request-list.component';
import { PaymentRequestViewComponent } from './payment/payment-request/payment-request-view/payment-request-view.component';
import { PaymentRefundViewComponent } from './payment-refund/payment-refund-view/payment-refund-view.component';
import { PaymentRefundListComponent } from './payment-refund/payment-refund-list/payment-refund-list.component';
//Report
import { TaReportListComponent } from './report/ta/report-list/report-list.component';
//Bulletin
import { BulletinListComponent } from './bulletin/bulletin-list/bulletin-list.component';
import { BulletinViewComponent } from './bulletin/bulletin-view/bulletin-view.component';

//Manage Resource STBPROD1206
import { ResourcesListComponent } from './resources/resources-list/resources-list.component';
import { ResourcesViewComponent } from './resources/resources-view/resources-view.component';

//User Account
import { UserAccountListComponent } from './system/user/user-account-list/user-account-list.component';
import { UserAccountViewComponent } from './system/user/user-account-view/user-account-view.component';
//User Access
import { UserAccessListComponent } from './system/user/user-access-list/user-access-list.component';

import { LoginComponent } from './login/login.component';
import { AuthGuard, PristineGuard } from './../common/guard';

import { TgReportListComponent } from './report/tg/report-list/report-list.component';
import { MasterDataConfigComponent } from '../main/config/master-data-config/master-data-config.component';
import { CeTaFieldReportViewResolve } from './ce/ce-ta-checks-reports/ce-ta-field-report-view/ce-ta-field-report.resolve';

import { EmailBroadcastListComponent } from './email-broadcast/email-broadcast-list/email-broadcast-list.component';
import { EmailBroadcastViewComponent } from './email-broadcast/email-broadcast-view/email-broadcast-view.component';
import { TgStipendListComponent } from './tg/tg-stipend-process/tg-stipend-list/tg-stipend-list.component';
import { TgStipendViewComponent } from './tg/tg-stipend-process/tg-stipend-view/tg-stipend-view.component';
import { TgStipendConfigViewComponent } from './tg/tg-stipend-process/tg-stipend-config-view/tg-stipend-config-view.component';
import { TaManageFilingAmendmentListComponent } from './ta/ta-manage-filing-amendment-process/ta-manage-filing-amendment-list/ta-manage-filing-amendment-list.component';
import { TaManageFilingAmendmentViewComponent } from './ta/ta-manage-filing-amendment-process/ta-manage-filing-amendment-view/ta-manage-filing-amendment-view.component';
import { TaLetterTemplateViewComponent } from './ta/ta-letter-template/ta-letter-template-view/ta-letter-template-view.component';



const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: '',
        component: MainComponent,
        canActivate: [AuthGuard],
        children: [
            // Others
            { path: '', redirectTo: 'dashboard' },
            { path: 'dashboard', component: DashboardComponent },
            // TA
            { path: 'ta-licence-list', component: TaLicenceListComponent },
            { path: 'ta-licence-view/:id', component: TaLicenceViewComponent },
            { path: 'ta-application-list', component: TaApplicationListComponent },
            { path: 'ta-main-list', component: TaMainListComponent },
            { path: 'ta-main-view/:id', component: TaMainViewComponent, },
            { path: 'ta-cease-list', component: TaCeaseListComponent },
            { path: 'ta-cease-view/:id', component: TaCeaseViewComponent, },
            { path: 'ta-switch-list', component: TaSwitchListComponent },
            { path: 'ta-switch-view/:id', component: TaSwitchViewComponent },
            { path: 'ta-replace-list', component: TaReplaceListComponent },
            { path: 'ta-replace-view/:id', component: TaReplaceViewComponent },
            { path: 'ta-branch-list', component: TaBranchListComponent },
            { path: 'ta-branch-view/:id', component: TaBranchViewComponent },
            { path: 'ta-ke-update-list', component: TaKeUpdateListComponent },
            { path: 'ta-ke-update-view/:id', component: TaKeUpdateViewComponent },
            { path: 'ta-fye-list', component: TaFyeListComponent },
            { path: 'ta-fye-view/:id', component: TaFyeViewComponent },
            { path: 'ta-aa-list', component: TaAaListComponent },
            { path: 'ta-aa-view/:id', component: TaAaViewComponent },
            { path: 'ta-offline-aa', component: TaOfflineAaComponent },
            { path: 'ta-personnel-list', component: TaPersonnelListComponent },
            { path: 'ta-personnel-view/:id', component: TaPersonnelViewComponent },
            { path: 'ta-company-update-list', component: TaCompanyUpdateListComponent },
            { path: 'ta-company-update-view/:id', component: TaCompanyUpdateViewComponent },
            { path: 'ta-abpr-list', component: TaAbprListComponent },
            { path: 'ta-abpr-view/:id', component: TaAbprViewComponent },
            { path: 'ta-shortfall-fulfilment-list', component: TaShortfallFulfilmentListComponent },
            { path: 'ta-shortfall-fulfilment-view/:id', component: TaShortfallFulfilmentViewComponent },
            { path: 'ta-return-list', component: TaReturnListComponent },
            { path: 'ta-return-view/:id', component: TaReturnViewComponent },
            { path: 'ta-renewal-list', component: TaRenewalListComponent },
            { path: 'ta-renewal-view/:id/:licenceId', component: TaRenewalViewComponent },
            { path: 'ta-renewal-exercise', component: TaRenewalExerciseComponent },
            { path: 'ta-ma-list', component: TaMaListComponent },
            { path: 'ta-ma-view/:id', component: TaMaViewComponent },
            { path: 'ta-workflow-process', component: TaWorkflowProcessComponent },
            { path: 'ta-manage-shortfall-list', component: TaManageShortfallListComponent },
            { path: 'ta-manage-shortfall-view', component: TaManageShortfallViewComponent, canDeactivate: [PristineGuard] },
            { path: 'ta-manage-shortfall-view/:id', component: TaManageShortfallViewComponent, canDeactivate: [PristineGuard] },
            { path: 'ta-manage-filing-list', component: TaManageFilingListComponent },
            { path: 'ta-manage-filing-view', component: TaManageFilingViewComponent },
            { path: 'ta-manage-filing-view/:id', component: TaManageFilingViewComponent },
            { path: 'ta-licence-print-list', component: TaLicencePrintListComponent },
            { path: 'ta-offline-abpr', component: TaOfflineAbprComponent, canDeactivate: [PristineGuard] },
            { path: 'ta-offline-cessation', component: TaOfflineCessationComponent, canDeactivate: [PristineGuard] },
            { path: 'ta-offline-company-update', component: TaOfflineCompanyUpdateComponent, canDeactivate: [PristineGuard] },
            { path: 'ta-filing-request-list', component: TaFilingRequestListComponent },
            { path: 'ta-filing-request-view', component: TaFilingRequestViewComponent, canDeactivate: [PristineGuard] },
            { path: 'ta-adhoc-doc-list', component: TaAdhocDocListComponent },
            { path: 'ta-adhoc-doc-view/:id', component: TaAdhocDocViewComponent },
            { path: 'ta-manage-filing-amend-list', component: TaManageFilingAmendmentListComponent },
            { path: 'ta-manage-filing-amend-view', component: TaManageFilingAmendmentViewComponent },
            { path: 'ta-manage-filing-amend-view/:id', component: TaManageFilingAmendmentViewComponent },
            { path: 'ta-letter-template', component: TaLetterTemplateViewComponent },
            { path: 'ta-e-licence-list', component: TaELicenceListComponent },
            { path: 'ta-e-licence-view/:id', component: TaELicenceViewComponent },

            // TA.obsolete
            { path: 'ta-portal', component: TaPortalComponent },
            { path: 'ta-portal-apply-preamble', component: TaPortalApplyPreambleComponent },
            { path: 'ta-portal-apply-form', component: TaPortalApplyFormComponent },
            { path: 'ta-portal-personnel-list', component: TaPortalPersonnelListComponent },
            // TG
            { path: 'tg-all-applications', component: TgAllApplicationsComponent },
            { path: 'tg-application-list', component: TgApplicationListComponent },
            { path: 'tg-application-view/:id', component: TgApplicationViewComponent },
            { path: 'tg-application-view/app/:appId', component: TgApplicationViewComponent },
            { path: 'tg-renewal-list', component: TgRenewalListComponent },
            { path: 'tg-renewal-view/:id', component: TgRenewalViewComponent },
            { path: 'tg-renewal-view/app/:appId', component: TgRenewalViewComponent },
            { path: 'tg-reinstate-list', component: TgRenewalListComponent },
            { path: 'tg-reinstate-view/:id', component: TgRenewalViewComponent },
            { path: 'tg-reinstate-view/app/:appId', component: TgRenewalViewComponent },
            { path: 'tg/lost-licence-list', component: TgLostLicenceListComponent },
            { path: 'tg/lost-licence-view', component: TgLostLicenceViewComponent },
            { path: 'tg/lost-licence-view/:id', component: TgLostLicenceViewComponent },
            { path: 'tg/lost-licence-view/app/:appId', component: TgLostLicenceViewComponent },
            { path: 'tg/cancel-view', component: TgCancelViewComponent },
            { path: 'tg/cancel-view/:id', component: TgCancelViewComponent },
            { path: 'tg/cancel-view/app/:appId', component: TgCancelViewComponent },
            { path: 'tg/update-particulars-list', component: TgUpdateParticularsListComponent },
            { path: 'tg/update-particulars-view/:id', component: TgUpdateParticularsViewComponent },
            { path: 'tg/update-particulars-view/app/:appId', component: TgUpdateParticularsViewComponent },
            { path: 'tg-licence-printing-list', component: TgLicencePrintingListComponent },
            { path: 'tg-licence-search-list', component: TgLicenceSearchListComponent },
            { path: 'tg-licence-search-view/:id', component: TgLicenceSearchViewComponent },
            { path: 'tg-course-list', component: TgCourseListComponent },
            { path: 'tg-course-new', component: TgCourseViewComponent, canDeactivate: [PristineGuard] },
            { path: 'tg-course-new/:tpId/:courseType', component: TgCourseViewComponent, canDeactivate: [PristineGuard] },
            { path: 'tg-course-view/:code', component: TgCourseViewComponent },
            { path: 'tg-candidate-list', component: TgCandidateListComponent },
            { path: 'tg-candidate-new', component: TgCandidateViewComponent },
            { path: 'tg-switch-tier/:id', component: TgCandidateViewComponent },
            { path: 'tg-candidate-view/:id', component: TgCandidateViewComponent },
            { path: 'tg-candidate-view/result/:resultId', component: TgCandidateViewComponent },
            { path: 'tg-mlpt-allocate', component: TgMlptAllocateComponent },
            { path: 'tg-mlpt-create-list', component: TgMlptCreateListComponent },
            { path: 'tg-mlpt-create-new', component: TgMlptCreateViewComponent, canDeactivate: [PristineGuard] },
            { path: 'tg-mlpt-create-view/:mlptId', component: TgMlptCreateViewComponent },
            { path: 'tg-mlpt-update', component: TgMlptUpdateComponent },
            { path: 'tg-workflow-process', component: TgWorkflowProcessComponent },
            { path: 'tg-tp-list', component: TgTrainingProviderListComponent },
            { path: 'tg-tp-new', component: TgTrainingProviderViewComponent, canDeactivate: [PristineGuard] },
            { path: 'tg-tp-view/:id', component: TgTrainingProviderViewComponent },
            { path: 'tg-course-criteria', component: TgCourseCriteriaComponent },
            { path: 'tg-tp-course-renewal/app/:appId', component: TgTpCourseRenewalViewComponent },
            { path: 'tg-tp-course-creation-list', component: TgTpCourseCreationListComponent },
            { path: 'tg-tp-course-creation/app/:appId', component: TgTpCourseCreationViewComponent },

            { path: 'tg-stipend-list', component: TgStipendListComponent },
            { path: 'tg-stipend-view/:id', component: TgStipendViewComponent },
            { path: 'tg-stipend-config-view', component: TgStipendConfigViewComponent, canDeactivate: [PristineGuard], data: { forAppeal: false } },
            { path: 'tg-stipend-appeal-config-view', component: TgStipendConfigViewComponent, canDeactivate: [PristineGuard], data: { forAppeal: true } },
            // TG.obsolete
            { path: 'tg-portal', component: TgPortalComponent },
            // Payment
            { path: 'payment-request-list', component: PaymentRequestListComponent },
            { path: 'payment-request-list/:status', component: PaymentRequestListComponent },
            { path: 'payment-request-new', component: PaymentRequestViewComponent, canDeactivate: [PristineGuard] },
            { path: 'payment-request-view/:billRefNo', component: PaymentRequestViewComponent },
            { path: 'payment-refund-view/:billRefNo', component: PaymentRefundViewComponent },
            { path: 'payment-refund-view-id/:id', component: PaymentRefundViewComponent },
            { path: 'payment-refund-list', component: PaymentRefundListComponent },
            // Report
            { path: 'ta-report-list', component: TaReportListComponent },
            { path: 'tg-report-list', component: TgReportListComponent },
            // Bulletin
            { path: 'bulletin-list-ta', component: BulletinListComponent, data: { bulletinTypeCode: cnst.BulletinTypeCode.TA } },
            { path: 'bulletin-list-tg', component: BulletinListComponent, data: { bulletinTypeCode: cnst.BulletinTypeCode.TG } },
            { path: 'bulletin-list-tg', component: BulletinListComponent, data: { bulletinTypeCode: cnst.BulletinTypeCode.CE } },
            { path: 'bulletin-new', component: BulletinViewComponent, canDeactivate: [PristineGuard] },
            { path: 'bulletin-view/:id', component: BulletinViewComponent },

            //Manage Resource STBPROD1206
            { path: 'resources-list-ta', component: ResourcesListComponent, data: { resourcesTypeCode: cnst.ResourcesTypeCode.TA } },
            { path: 'resources-list-tg', component: ResourcesListComponent, data: { resourcesTypeCode: cnst.ResourcesTypeCode.TG } },
            { path: 'resources-new', component: ResourcesViewComponent, canDeactivate: [PristineGuard] },
            { path: 'resources-view/:id1/:id2', component: ResourcesViewComponent },
            { path: 'resources-view/:id1', component: ResourcesViewComponent },

            // Email Broadcast
            { path: 'email-broadcast', component: EmailBroadcastListComponent },
            { path: 'email-broadcast-view', component: EmailBroadcastViewComponent, canDeactivate: [PristineGuard] },
            // Config
            { path: 'config-master-data', component: MasterDataConfigComponent },
            // User Account
            { path: 'user-account-list', component: UserAccountListComponent },
            { path: 'user-account-view/:id', component: UserAccountViewComponent },
            { path: 'user-account-new', component: UserAccountViewComponent, canDeactivate: [PristineGuard] },
            // User Access
            { path: 'user-access-list', component: UserAccessListComponent },
            // CE
            { path: 'ce-ta-checks-schedule', component: CeTaChecksScheduleComponent, canDeactivate: [PristineGuard] },
            { path: 'ce-ta-checks-reports-list', component: CeTaChecksReportsListComponent },
            { path: 'ce-tati-check-view', component: CeTatiCheckViewComponent, canDeactivate: [PristineGuard] },
            {
                path: 'ce-ta-field-report-view', component: CeTaFieldReportViewComponent, canDeactivate: [PristineGuard], resolve: {
                    classifications: CeTaFieldReportViewResolve
                }
            },
            { path: 'ce-tati-check-ack', component: CeTatiCheckAckComponent },
            { path: 'ce-tg-checks-schedule', component: CeTgChecksScheduleComponent, canDeactivate: [PristineGuard] },
            { path: 'ce-case', component: CeCaseComponent },
            { path: 'ce-case/:taTgType/:id', component: CeCaseComponent },
            { path: 'ce-ip/:id', component: CeIpComponent },
            { path: 'ce-directory', component: CeDirectoryListComponent },
            { path: 'ce-directory/:category', component: CeDirectoryListComponent },
            { path: 'ce-tg-checks-reports', component: CeTgChecksReportsListComponent },
            { path: 'ce-ground-check-view/:checkScheduleItemLocationId', component: CeGroundCheckViewComponent },
            { path: 'ce-tg-field-report/new/:checkScheduleItemLocationId', component: CeTgFieldReportViewComponent },
            { path: 'ce-tg-field-report/:tgFieldReportId', component: CeTgFieldReportViewComponent },
            { path: 'ce-provision-config', component: CeProvisionConfigComponent },
        ]
    }];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class MainRoutingModule { }
