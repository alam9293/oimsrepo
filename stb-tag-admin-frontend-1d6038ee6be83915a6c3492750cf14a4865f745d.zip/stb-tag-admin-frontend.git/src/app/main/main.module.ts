// Materials
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
import { EditorModule } from 'primeng/editor';
import { ChartsModule } from 'ng2-charts';
import { NgxCurrencyModule } from 'ngx-currency';
import { FileSizeModule } from 'ngx-filesize';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { NgxCroppieModule } from 'ngx-croppie';
import { CroppieDialogComponent } from './croppie/croppie-dialog/croppie-dialog.component';
import { CroppieFormControlComponent } from './croppie/croppie-form-control/croppie-form-control.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';

// Directives
import { AlertComponent } from '../common/directives/alert.directive';
import { DisableControlIfNotPendingUserDirective } from '../common/directives/disable-control-if-not-pending-user';
import { DisableControlDirective } from '../common/directives/disable-control.directive';
import { SelectControlDirective } from '../common/directives/select-control.directive';
import { WizAuditAmountDirective } from '../common/directives/wiz-audit-amount.directive';
import { AppWizHideIfNotPendingAppUser } from '../common/directives/wiz-hide-if-not-pending-app-user.directive';
import { AppWizHideIfNotPendingWfcUser } from '../common/directives/wiz-hide-if-not-pending-wfc-user.directive';
import { WizHideIfUnauthorizedDirective } from '../common/directives/wiz-hide-if-unauthorized.directive';
import { AppWizHideIfNotPendingAssignee } from '../common/directives/wiz-hide-if-not-pending-assignee.directive';

// Common Modules
import { ApplicationWorkflowModule } from '../common/modules/application-workflow/application-workflow.module';
import { BackModule } from '../common/modules/back/back.module';
import { ConfirmationDialogComponent } from '../common/modules/confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogModule } from '../common/modules/confirmation-dialog/confirmation-dialog.module';
import { DownloadCsvModule } from '../common/modules/download-csv/download-csv.module';
import { GoButtonModule } from '../common/modules/go-button/go-button.module';
import { SigndocButtonModule } from '../common/modules/signdoc-button/signdoc-button.module';
import { NoteDialogComponent } from '../common/modules/note-dialog/note-dialog.component';
import { CasenoteDialogModule } from '../common/modules/note-dialog/note-dialog.module';
import { SharedModule } from '../common/modules/shared.module';
import { StatModule } from '../common/modules/stat/stat.module';
import { WorkflowFileModule } from '../common/modules/workflow-file/workflow-file.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { MainRoutingModule } from './main-routing.module';
import { MainComponent } from './main.component';
import { MainMaterialModule } from './main.material';
import { MainMomentModule } from './main.moment';
import { SideBarComponent } from './menu/side-bar/side-bar.component';
import { TopMenuComponent } from './menu/top-menu/top-menu.component';
import { MasterDataModule } from '../common/modules/master-data/master-data.module';
import { MasterDialogComponent } from '../common/modules/master-data/master-dialog/master-dialog.component';
import { MasterDialogModule } from '../common/modules/master-data/master-dialog/master-dialog.module';
import { MatSelectSearchModule } from '../common/modules/mat-select-search/mat-select-search.module';

//Bulletin
import { BulletinListComponent } from './bulletin/bulletin-list/bulletin-list.component';
import { BulletinViewComponent } from './bulletin/bulletin-view/bulletin-view.component';

//Manage Resource STBPROD1206
import { ResourcesListComponent } from './resources/resources-list/resources-list.component';
import { ResourcesViewComponent } from './resources/resources-view/resources-view.component';

//User Account
import { UserAccountListComponent } from './system/user/user-account-list/user-account-list.component';
import { UserAccountViewComponent } from './system/user/user-account-view/user-account-view.component';

//User Access
import { UserAccessListComponent } from './system/user/user-access-list/user-access-list.component';

// Payment
import { PaymentRequestListComponent } from './payment/payment-request/payment-request-list/payment-request-list.component';
import {
    DialogPaymentTxnSave,
    PaymentRequestViewComponent,
} from './payment/payment-request/payment-request-view/payment-request-view.component';
import { PaymentRefundDetailsModule } from '../common/modules/payment-refund-details/payment-refund-details.module';

// Report
import { TaReportListComponent } from './report/ta/report-list/report-list.component';
import { TgReportListComponent } from './report/tg/report-list/report-list.component';

//TA
import { TaLicenceModule } from '../common/modules/ta-licence/ta-licence.module';
import {
    TaLicenseeSubmissionTableModule,
} from '../common/modules/ta-licensee-submission-table/ta-licensee-submission-table.module';
import { TaPersonnelDialogComponent } from '../common/modules/ta-personnel-dialog/ta-personnel-dialog.component';
import { TaPersonnelDialogModule } from '../common/modules/ta-personnel-dialog/ta-personnel-dialog.module';
import { TgResidentialDialogComponent } from '../common/modules/tg-residential-dialog/tg-residential-dialog.component';
import { TgResidentialDialogModule } from '../common/modules/tg-residential-dialog/tg-residential-dialog.module';
import { TgMlptDialogComponent } from '../common/modules/tg-mlpt-dialog/tg-mlpt-dialog.component';
import { TgMlptDialogModule } from '../common/modules/tg-mlpt-dialog/tg-mlpt-dialog.module';
import { TgELicenceDialogComponent } from '../common/modules/tg-elicence-dialog/tg-elicence-dialog.component';
import { TgELicenceDialogModule } from '../common/modules/tg-elicence-dialog/tg-elicence-dialog.module';
import { TgELicencePreviewDialogComponent } from '../common/modules/tg-elicence-preview-dialog/tg-elicence-preview-dialog.component';
import { TgELicencePreviewDialogModule } from '../common/modules/tg-elicence-preview-dialog/tg-elicence-preview-dialog.module';
import { TgInfoDetailsDialogComponent } from '../common/modules/tg-info-details-dialog/tg-info-details-dialog.component';
import { TgInfoDetailsDialogModule } from '../common/modules/tg-info-details-dialog/tg-info-details-dialog.module';
import {
    DialogApplicationMode,
    DialogLicenceTier,
    TaPortalApplyFormComponent,
} from './system/portal/ta-portal/ta-portal-apply/ta-portal-apply-form/ta-portal-apply-form.component';
import {
    TaPortalApplyPreambleComponent,
} from './system/portal/ta-portal/ta-portal-apply/ta-portal-apply-preamble/ta-portal-apply-preamble.component';
import {
    DialogTaPersonnelDetailsComponent,
} from './system/portal/ta-portal/ta-portal-personnel-list/dialog-ta-personnel-details/dialog-ta-personnel-details.component';
import {
    TaPortalPersonnelListComponent,
} from './system/portal/ta-portal/ta-portal-personnel-list/ta-portal-personnel-list.component';
import { TaPortalComponent } from './system/portal/ta-portal/ta-portal.component';
import { TgPortalComponent } from './system/portal/tg-portal/tg-portal.component';
import { TaAaListComponent } from './ta/ta-aa-process/ta-aa-list/ta-aa-list.component';
import { TaAaViewComponent } from './ta/ta-aa-process/ta-aa-view/ta-aa-view.component';
import { TaAbprListComponent } from './ta/ta-abpr-process/ta-abpr-list/ta-abpr-list.component';
import { TaAbprViewComponent } from './ta/ta-abpr-process/ta-abpr-view/ta-abpr-view.component';
import { TaApplicationListComponent } from './ta/ta-application/ta-application-list/ta-application-list.component';
import { TaBranchListComponent } from './ta/ta-branch-process/ta-branch-list/ta-branch-list.component';
import { TaBranchViewComponent } from './ta/ta-branch-process/ta-branch-view/ta-branch-view.component';
import { TaCeaseListComponent } from './ta/ta-cessation-process/ta-cease-list/ta-cease-list.component';
import { TaCeaseViewComponent } from './ta/ta-cessation-process/ta-cease-view/ta-cease-view.component';
import {
    TaCompanyUpdateListComponent,
} from './ta/ta-company-update/ta-company-update-list/ta-company-update-list.component';
import {
    TaCompanyUpdateViewComponent,
} from './ta/ta-company-update/ta-company-update-view/ta-company-update-view.component';
import { TaFyeListComponent } from './ta/ta-fye-process/ta-fye-list/ta-fye-list.component';
import { TaFyeViewComponent } from './ta/ta-fye-process/ta-fye-view/ta-fye-view.component';
import { TaKeUpdateListComponent } from './ta/ta-ke-update/ta-ke-update-list/ta-ke-update-list.component';
import { TaKeUpdateViewComponent } from './ta/ta-ke-update/ta-ke-update-view/ta-ke-update-view.component';
import { TaLicenceListComponent } from './ta/ta-licence/ta-licence-list/ta-licence-list.component';
import { TaLicenceViewComponent } from './ta/ta-licence/ta-licence-view/ta-licence-view.component';
import { TaMaListComponent } from './ta/ta-ma-process/ta-ma-list/ta-ma-list.component';
import { TaMaViewComponent } from './ta/ta-ma-process/ta-ma-view/ta-ma-view.component';
import { TaMainListComponent } from './ta/ta-main-process/ta-main-list/ta-main-list.component';
import { DialogPersonnel, TaMainViewComponent } from './ta/ta-main-process/ta-main-view/ta-main-view.component';
import {
    TaManageFilingListComponent,
} from './ta/ta-manage-filing-process/ta-manage-filing-list/ta-manage-filing-list.component';
import {
    TaManageFilingListingTableModule,
} from './ta/ta-manage-filing-process/ta-manage-filing-listing-table/ta-manage-filing-listing-table.module';
import {
    TaManageFilingViewComponent,
} from './ta/ta-manage-filing-process/ta-manage-filing-view/ta-manage-filing-view.component';
import {
    DialogEditDate,
    TaManageShortfallListComponent,
} from './ta/ta-manage-shortfall-process/ta-manage-shortfall-list/ta-manage-shortfall-list.component';
import {
    TaManageShortfallViewComponent,
} from './ta/ta-manage-shortfall-process/ta-manage-shortfall-view/ta-manage-shortfall-view.component';
import { TaOfflineAaComponent } from './ta/ta-offline-aa/ta-offline-aa.component';
import { TaPersonnelListComponent } from './ta/ta-personnel/ta-personnel-list/ta-personnel-list.component';
import { TaPersonnelViewComponent } from './ta/ta-personnel/ta-personnel-view/ta-personnel-view.component';
import {
    DialogManagementAccountsRequest,
} from './ta/ta-renewal-exercise/ta-renewal-exercise-group/ta-renewal-exercise-group.component';
import {
    TaRenewalExerciseGroupModule,
} from './ta/ta-renewal-exercise/ta-renewal-exercise-group/ta-renewal-exercise-group.module';
import { TaRenewalExerciseComponent } from './ta/ta-renewal-exercise/ta-renewal-exercise.component';
import { TaRenewalListComponent } from './ta/ta-renewal-process/ta-renewal-list/ta-renewal-list.component';
import { TaRenewalViewComponent } from './ta/ta-renewal-process/ta-renewal-view/ta-renewal-view.component';
import { TaReplaceListComponent } from './ta/ta-replacement-process/ta-replace-list/ta-replace-list.component';
import { TaReplaceViewComponent } from './ta/ta-replacement-process/ta-replace-view/ta-replace-view.component';
import { TaReturnListComponent } from './ta/ta-return-licence/ta-return-list/ta-return-list.component';
import { TaReturnViewComponent } from './ta/ta-return-licence/ta-return-view/ta-return-view.component';
import { TaSwitchListComponent } from './ta/ta-switch-process/ta-switch-list/ta-switch-list.component';
import { TaSwitchViewComponent } from './ta/ta-switch-process/ta-switch-view/ta-switch-view.component';
import { TaWorkflowProcessComponent } from './ta/ta-workflow-process/ta-workflow-process.component';
import { TaLicencePrintListComponent } from './ta/ta-licence-print/ta-licence-print-list/ta-licence-print-list.component';
import { TaOfflineAbprComponent } from './ta/ta-offline-abpr/ta-offline-abpr.component';
import { TaOfflineCessationComponent } from './ta/ta-offline-cessation/ta-offline-cessation.component';
import { TaOfflineCompanyUpdateComponent } from './ta/ta-offline-company-update/ta-offline-company-update.component';
import { TaFilingRequestListComponent } from './ta/ta-filing-request-process/ta-filing-request-list/ta-filing-request-list.component';
import {
    TaFilingRequestListingTableModule
} from './ta/ta-filing-request-process/ta-filing-request-listing-table/ta-filing-request-listing-table.module';
import { TaFilingRequestViewComponent } from './ta/ta-filing-request-process/ta-filing-request-view/ta-filing-request-view.component';
import { TaAdhocDocListComponent } from './ta/ta-adhoc-doc-process/ta-adhoc-doc-list/ta-adhoc-doc-list.component';
import { TaAdhocDocViewComponent } from './ta/ta-adhoc-doc-process/ta-adhoc-doc-view/ta-adhoc-doc-view.component';
import { TaManageFilingAmendmentListComponent } from './ta/ta-manage-filing-amendment-process/ta-manage-filing-amendment-list/ta-manage-filing-amendment-list.component';
import { TaManageFilingAmendmentViewComponent } from './ta/ta-manage-filing-amendment-process/ta-manage-filing-amendment-view/ta-manage-filing-amendment-view.component';
import { TaManageFilingAmendmentListingTableModule } from './ta/ta-manage-filing-amendment-process/ta-manage-filing-amendment-listing-table/ta-manage-filing-amendment-listing-table.module';
import { TaELicenceListComponent } from './ta/ta-e-licence/ta-e-licence-list/ta-e-licence-list.component';
import { TaELicenceViewComponent } from './ta/ta-e-licence/ta-e-licence-view/ta-e-licence-view.component';
import { TaResidentialDialogModule } from '../common/modules/ta-residential-dialog/ta-residential-dialog.module';
import { TaResidentialDialogComponent } from '../common/modules/ta-residential-dialog/ta-residential-dialog.component';
import { TaElicencePreviewDialogModule } from '../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.module';

// TG
import { TgFilterComponent } from '../common/modules/tg-filter/tg-filter.component';
import { TgFilterModule } from '../common/modules/tg-filter/tg-filter.module';
import { TgLicenceModule } from '../common/modules/tg-licence/tg-licence.module';
import { TgLicencePrintDetailsModule } from '../common/modules/tg-licence-print-details/tg-licence-print-details.module';
import { TgAllApplicationsComponent } from './tg/tg-all-applications/tg-all-applications.component';
import { TgApplicationListComponent } from './tg/tg-application-process/tg-application-list/tg-application-list.component';
import { TgApplicationViewComponent } from './tg/tg-application-process/tg-application-view/tg-application-view.component';
import { TgCancelViewComponent } from './tg/tg-cancel-process/tg-cancel-view/tg-cancel-view.component';
import { TgCandidateListComponent } from './tg/tg-candidate-process/tg-candidate-list/tg-candidate-list.component';
import { TgCandidateViewComponent } from './tg/tg-candidate-process/tg-candidate-view/tg-candidate-view.component';
import { TgCourseListComponent } from './tg/tg-course-process/tg-course-list/tg-course-list.component';
import {
    DialogTgCourseAttendanceDetailsView,
    TgCourseViewComponent,
} from './tg/tg-course-process/tg-course-view/tg-course-view.component';
import {
    DialogLicencePrinting,
    TgLicencePrintingListComponent,
} from './tg/tg-licence-printing-process/tg-licence-printing-list/tg-licence-printing-list.component';
import {
    TgLicenceSearchListComponent,
} from './tg/tg-licence-search/tg-licence-search-list/tg-licence-search-list.component';
import {
    TgLicenceSearchViewComponent,
} from './tg/tg-licence-search/tg-licence-search-view/tg-licence-search-view.component';
import {
    TgLostLicenceListComponent,
} from './tg/tg-lost-licence-process/tg-lost-licence-list/tg-lost-licence-list.component';
import {
    TgLostLicenceViewComponent,
} from './tg/tg-lost-licence-process/tg-lost-licence-view/tg-lost-licence-view.component';
import { TgMlptAllocateComponent } from './tg/tg-mlpt-process/tg-mlpt-allocate/tg-mlpt-allocate.component';
import { DialogTgMlptChangeDate } from './tg/tg-mlpt-process/tg-mlpt-allocate/tg-mlpt-change-date-dialog.component';
import { DialogTgMlptUpdateResult } from './tg/tg-mlpt-process/tg-mlpt-allocate/tg-mlpt-update-result-dialog.component';
import {
    TgMlptCreateListComponent,
} from './tg/tg-mlpt-process/tg-mlpt-create/tg-mlpt-create-list/tg-mlpt-create-list.component';
import {
    TgMlptCreateViewComponent,
} from './tg/tg-mlpt-process/tg-mlpt-create/tg-mlpt-create-view/tg-mlpt-create-view.component';
import { TgMlptUpdateComponent } from './tg/tg-mlpt-process/tg-mlpt-update/tg-mlpt-update.component';
import { TgRenewalListComponent } from './tg/tg-renewal-process/tg-renewal-list/tg-renewal-list.component';
import { TgRenewalViewComponent } from './tg/tg-renewal-process/tg-renewal-view/tg-renewal-view.component';
import { TgTrainingProviderListComponent } from './tg/tg-tp-process/tg-tp-list/tg-tp-list.component';
import { TgTrainingProviderViewComponent } from './tg/tg-tp-process/tg-tp-view/tg-tp-view.component';
import {
    TgUpdateParticularsListComponent,
} from './tg/tg-update-particulars/tg-update-particulars-list/tg-update-particulars-list.component';
import {
    TgUpdateParticularsViewComponent,
} from './tg/tg-update-particulars/tg-update-particulars-view/tg-update-particulars-view.component';
import { TgWorkflowProcessComponent } from './tg/tg-workflow-process/tg-workflow-process.component';
import { TgCourseCriteriaComponent } from './tg/tg-course-criteria/tg-course-criteria.component';
import { TgTpCourseRenewalViewComponent } from './tg/tg-tp-course-renewal/tg-tp-course-renewal-view/tg-tp-course-renewal-view.component';
import { TgTpCourseCreationViewComponent } from './tg/tg-tp-course-creation-process/tg-tp-course-creation-view/tg-tp-course-creation-view.component';
import { TgTpCourseCreationListComponent } from './tg/tg-tp-course-creation-process/tg-tp-course-creation-list/tg-tp-course-creation-list.component';
import { TgCourseRenewalCycleComponent } from './tg/tg-course-process/tg-course-renewal-cycle/tg-course-renewal-cycle.component';
import { TgStipendListComponent } from './tg/tg-stipend-process/tg-stipend-list/tg-stipend-list.component';
import { TgStipendViewComponent } from './tg/tg-stipend-process/tg-stipend-view/tg-stipend-view.component';
import { TgStipendConfigViewComponent } from './tg/tg-stipend-process/tg-stipend-config-view/tg-stipend-config-view.component';
import { TgStipendDetailsModule } from '../common/modules/tg-stipend-details/tg-stipend-details.module';

//ce
import {
    TaShortfallFulfilmentListComponent,
} from './ta/ta-shortfall-fulfillment/ta-shortfall-fulfilment-list/ta-shortfall-fulfilment-list.component';
import {
    TaShortfallFulfilmentViewComponent,
} from './ta/ta-shortfall-fulfillment/ta-shortfall-fulfilment-view/ta-shortfall-fulfilment-view.component';
import { CeTaChecksScheduleComponent } from './ce/ce-ta-checks-schedule/ce-ta-checks-schedule.component';
import { CeTaChecksScheduleListingModule } from './ce/ce-ta-checks-schedule/ce-ta-checks-schedule-listing/ce-ta-checks-schedule-listing.module';
import { CeTaChecksAddTaDialogComponent } from './ce/ce-ta-checks-schedule/ce-ta-checks-add-ta-dialog/ce-ta-checks-add-ta-dialog.component';
import { CeTaChecksAddTaDialogService } from './ce/ce-ta-checks-schedule/ce-ta-checks-add-ta-dialog/ce-ta-checks-add-ta-dialog.service';
import { CeTgChecksScheduleComponent } from './ce/ce-tg-checks-schedule/ce-tg-checks-schedule.component';
import { CeTgChecksScheduleListingModule } from './ce/ce-tg-checks-schedule/ce-tg-checks-schedule-listing/ce-tg-checks-schedule-listing.module';
import { DialogAddOffence } from './../main/ce/ce-case/ce-case-offences/ce-case-offences.component';
import { CeTatiCheckViewComponent } from './ce/ce-ta-checks-reports/ce-tati-check-view/ce-tati-check-view.component';
import { CeTaChecksReportsListComponent } from './ce/ce-ta-checks-reports/ce-ta-checks-reports-list/ce-ta-checks-reports-list.component';
import { CeCaseDetailsModule } from './ce/ce-case/ce-case-details/ce-case-details.module';
import { DialogAddComplianceChecks } from './ce/ce-case/ce-case-compliance-checks/ce-case-compliance-checks.component';
import { CeCaseTaskDialogComponent } from './ce/ce-case/ce-case-task-dialog/ce-case-task-dialog.component';
import { CeIpModule } from './ce/ce-ip/ce-ip.module';
import { CeDirectoryListComponent, CeDirectoryListDialogComponent } from './ce/ce-directory/ce-directory-list.component';
import { CeTgChecksReportsListComponent } from './ce/ce-tg-checks-reports/ce-tg-checks-reports-list/ce-tg-checks-reports-list.component';
import { CeTaFieldReportViewComponent } from './ce/ce-ta-checks-reports/ce-ta-field-report-view/ce-ta-field-report-view.component';
import { CeGroundCheckViewComponent } from './ce/ce-tg-checks-reports/ce-ground-check-view/ce-ground-check-view.component';
import { CeTgFieldReportViewComponent } from './ce/ce-tg-checks-reports/ce-tg-field-report/ce-tg-field-report.component';
import { CeTatiCheckAckComponent } from './ce/ce-ta-checks-reports/ce-tati-check-ack/ce-tati-check-ack.component';
import { CeTgFieldReportTgModule } from './ce/ce-tg-checks-reports/ce-tg-field-report/ce-tg-field-report-tg/ce-tg-field-report-tg.module';
import { CeCaseRelevantOffencesModule } from './ce/ce-case/ce-case-relevant-offences/ce-case-relevant-offences.module';
import { CeProvisionConfigComponent, InactiveCeProvisionConfigComponent, EditCeProvisionConfigComponent } from './ce/ce-provision-config/ce-provision-config.component';
import { CeCaseTaskLogModule } from './ce/ce-case/ce-case-task-log/ce-case-task-log.module';
import { AttachmentModule } from '../common/modules/attachment/attachment.module';
import { DialogCaseTaskLogDetails } from './ce/ce-case/ce-case-task-log/ce-case-task-log.component';
import { AttachmentComponent } from '../common/modules/attachment/attachment.component';
import { CeCaseModule } from './ce/ce-case/ce-case.module';

// Master Config
import { MasterDataConfigComponent } from './config/master-data-config/master-data-config.component';

import { PaymentRefundViewComponent } from './payment-refund/payment-refund-view/payment-refund-view.component';
import { PaymentRefundListComponent } from './payment-refund/payment-refund-list/payment-refund-list.component';
import { EmailBroadcastViewComponent } from './email-broadcast/email-broadcast-view/email-broadcast-view.component';
import { EmailBroadcastListComponent } from './email-broadcast/email-broadcast-list/email-broadcast-list.component';
import { TaLetterTemplateViewComponent } from './ta/ta-letter-template/ta-letter-template-view/ta-letter-template-view.component';
import { TaElicencePreviewDialogComponent } from '../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.component';
export const customCurrencyMaskConfig = {
    align: "right",
    allowNegative: true,
    allowZero: true,
    decimal: ".",
    precision: 0,
    prefix: "S$ ",
    suffix: "",
    thousands: ",",
    nullable: true
};


@NgModule({
    imports: [
        // Materials
        CommonModule,
        FlexLayoutModule,
        FormsModule,
        ReactiveFormsModule,
        MainMaterialModule,
        MainMomentModule,
        ChartsModule,
        DragDropModule,
        ScrollingModule,
        NgxCroppieModule,
        // Common Modules
        BackModule,
        GoButtonModule,
        SigndocButtonModule,
        ConfirmationDialogModule,
        MasterDataModule,
        StatModule,
        TaLicenceModule,
        TgLicenceModule,
        TgLicencePrintDetailsModule,
        CasenoteDialogModule,
        ApplicationWorkflowModule,
        DownloadCsvModule,
        TaPersonnelDialogModule,
        TgResidentialDialogModule,
        TgMlptDialogModule,
        TaRenewalExerciseGroupModule,
        TaLicenseeSubmissionTableModule,
        TaManageFilingListingTableModule,
        TaFilingRequestListingTableModule,
        TgFilterModule,
        WorkflowFileModule,
        MasterDialogModule,
        MatSelectSearchModule,
        PaymentRefundDetailsModule,
        TgStipendDetailsModule,
        TaManageFilingAmendmentListingTableModule,
        TaResidentialDialogModule,
        TaElicencePreviewDialogModule,

        // Others
        MainRoutingModule,
        RichTextEditorAllModule,
        EditorModule,
        NgxCurrencyModule.forRoot(customCurrencyMaskConfig),
        SharedModule,
        FileSizeModule,
        CKEditorModule,
        NgxMatSelectSearchModule,
        TgELicenceDialogModule,
        TgELicencePreviewDialogModule,
        TgInfoDetailsDialogModule,

        // CE
        CeTaChecksScheduleListingModule,
        CeTgChecksScheduleListingModule,
        CeCaseDetailsModule,
        CeIpModule,
        CeTgFieldReportTgModule,
        CeCaseRelevantOffencesModule,
        CeCaseTaskLogModule,
        AttachmentModule,
        CeCaseModule,
    ],
    declarations: [
        // Others
        MainComponent,
        TopMenuComponent,
        SideBarComponent,
        DashboardComponent,
        DialogEditDate,
        CroppieFormControlComponent,
        CroppieDialogComponent,
        DialogEditDate,

        // Directives
        WizHideIfUnauthorizedDirective,
        AppWizHideIfNotPendingAssignee,
        AppWizHideIfNotPendingAppUser,
        AppWizHideIfNotPendingWfcUser,
        WizAuditAmountDirective,
        AlertComponent,
        SelectControlDirective,
        DisableControlDirective,
        DisableControlIfNotPendingUserDirective,
        // TA
        TaLicenceListComponent,
        TaLicenceViewComponent,
        TaApplicationListComponent,
        TaMainListComponent,
        TaMainViewComponent,
        TaCeaseListComponent,
        TaCeaseViewComponent,
        TaSwitchListComponent,
        TaSwitchViewComponent,
        TaReplaceListComponent,
        TaReplaceViewComponent,
        TaBranchListComponent,
        TaBranchViewComponent,
        TaPersonnelListComponent,
        TaPersonnelViewComponent,
        TaShortfallFulfilmentListComponent,
        TaShortfallFulfilmentViewComponent,
        TaAbprListComponent,
        TaAbprViewComponent,
        DialogTaPersonnelDetailsComponent,
        DialogLicenceTier,
        TaPortalComponent,
        TaPortalApplyPreambleComponent,
        TaPortalApplyFormComponent,
        TaPortalPersonnelListComponent,
        TaKeUpdateListComponent,
        TaKeUpdateViewComponent,
        DialogApplicationMode,
        TaCompanyUpdateViewComponent,
        TaCompanyUpdateListComponent,
        TaOfflineAaComponent,
        DialogPersonnel,
        TaRenewalListComponent,
        TaRenewalViewComponent,
        TaRenewalExerciseComponent,
        TaMaListComponent,
        TaMaViewComponent,
        TaWorkflowProcessComponent,
        TaManageShortfallListComponent,
        TaManageShortfallViewComponent,
        DialogManagementAccountsRequest,
        TaManageFilingListComponent,
        TaManageFilingViewComponent,
        TaLicencePrintListComponent,
        TaOfflineAbprComponent,
        TaOfflineCessationComponent,
        TaOfflineCompanyUpdateComponent,
        TaFilingRequestListComponent,
        TaFilingRequestViewComponent,
        TaAdhocDocListComponent,
        TaAdhocDocViewComponent,
        TaManageFilingAmendmentListComponent,
        TaManageFilingAmendmentViewComponent,
        TaLetterTemplateViewComponent,
        TaELicenceListComponent,
        TaELicenceViewComponent,

        // TG
        TgAllApplicationsComponent,
        TgApplicationListComponent,
        TgApplicationViewComponent,
        TgRenewalListComponent,
        TgRenewalViewComponent,
        TgLostLicenceListComponent,
        TgCancelViewComponent,
        TgPortalComponent,
        TgLostLicenceViewComponent,
        TaAaListComponent,
        TaAaViewComponent,
        TaFyeListComponent,
        TaFyeViewComponent,
        LoginComponent,
        TgUpdateParticularsListComponent,
        TgUpdateParticularsViewComponent,
        TgLicencePrintingListComponent,
        DialogLicencePrinting,
        TgLicenceSearchListComponent,
        TgLicenceSearchViewComponent,
        TgCourseListComponent,
        TgCourseViewComponent,
        DialogTgCourseAttendanceDetailsView,
        TgCandidateListComponent,
        TgCandidateViewComponent,
        TgMlptAllocateComponent,
        DialogTgMlptUpdateResult,
        DialogTgMlptChangeDate,
        TgWorkflowProcessComponent,
        TgTrainingProviderListComponent,
        TgTrainingProviderViewComponent,
        TgMlptCreateListComponent,
        TgMlptCreateViewComponent,
        TgMlptUpdateComponent,
        TgMlptCreateListComponent,
        TgMlptCreateViewComponent,
        TgMlptUpdateComponent,
        TgCourseCriteriaComponent,
        TgTpCourseRenewalViewComponent,
        TgCourseRenewalCycleComponent,

        // Payment
        PaymentRequestListComponent,
        PaymentRequestViewComponent,
        DialogPaymentTxnSave,
        TaReturnListComponent,
        TaReturnViewComponent,
        // Report
        TaReportListComponent,
        TgReportListComponent,
        // Bulletin
        BulletinListComponent,
        BulletinViewComponent,

        //Manage Resource STBPROD1206
        ResourcesListComponent,
        ResourcesViewComponent,

        //User Account
        UserAccountListComponent,
        UserAccountViewComponent,
        //User Access
        UserAccessListComponent,

        //CE
        CeTaChecksScheduleComponent,
        CeTaChecksAddTaDialogComponent,
        CeTgChecksScheduleComponent,
        DialogAddOffence,
        CeTatiCheckViewComponent,
        CeTaChecksReportsListComponent,
        DialogAddComplianceChecks,
        CeCaseTaskDialogComponent,
        CeDirectoryListComponent,
        CeDirectoryListDialogComponent,
        CeTgChecksReportsListComponent,
        CeTaFieldReportViewComponent,
        CeGroundCheckViewComponent,
        CeTgFieldReportViewComponent,
        CeTatiCheckAckComponent,
        CeProvisionConfigComponent,
        InactiveCeProvisionConfigComponent,
        EditCeProvisionConfigComponent,
        DialogCaseTaskLogDetails,

        // Master Config
        MasterDataConfigComponent,

        PaymentRefundViewComponent,
        PaymentRefundListComponent,
        EmailBroadcastListComponent,
        EmailBroadcastViewComponent,
        TgTpCourseCreationViewComponent,
        TgTpCourseCreationListComponent,
        TgStipendListComponent,
        TgStipendViewComponent,
        TgStipendConfigViewComponent,


    ], entryComponents: [
        // Common
        ConfirmationDialogComponent,
        NoteDialogComponent,
        TaPersonnelDialogComponent,
        TgResidentialDialogComponent,
        TgMlptDialogComponent,
        DialogEditDate,
        TgFilterComponent,
        MasterDialogComponent,
        CroppieFormControlComponent,
        CroppieDialogComponent,
        TgELicenceDialogComponent,
        TgELicencePreviewDialogComponent,
        TgInfoDetailsDialogComponent,
        TaResidentialDialogComponent,
        TaElicencePreviewDialogComponent,

        // TA
        DialogLicenceTier,
        DialogApplicationMode,
        DialogPersonnel,
        DialogManagementAccountsRequest,
        //TG
        DialogLicencePrinting,
        DialogTgCourseAttendanceDetailsView,
        DialogTgMlptUpdateResult,
        DialogTgMlptChangeDate,

        // Payment
        DialogPaymentTxnSave,

        //CE
        CeTaChecksAddTaDialogComponent,
        DialogAddOffence,
        DialogAddComplianceChecks,
        CeCaseTaskDialogComponent,
        InactiveCeProvisionConfigComponent,
        EditCeProvisionConfigComponent,
        DialogCaseTaskLogDetails, CeDirectoryListDialogComponent, AttachmentComponent],
    providers: [CeTaChecksAddTaDialogService]

})
export class MainModule { }