import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../common/services';
import { User, ListableDto } from '../../../common/models'
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-side-bar',
    templateUrl: './side-bar.component.html',
    styleUrls: ['./side-bar.component.scss']
})
export class SideBarComponent implements OnInit {
    @Output() sidenavClose = new EventEmitter();
    currentUser: User;
    cnst = cnst;

    constructor(private router: Router,
        private authenticationService: AuthenticationService) { }

    ngOnInit() {

        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
            });
        }
    }

    onLoggedout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }

    showMenuItem(functionCode: string | string[]) {
        return this.authenticationService.hasPermission(functionCode);
    }

    switchRole(role: ListableDto) {
        if (this.currentUser.selectedRole.key !== role.key) {
            this.authenticationService.switchRole(role.key).subscribe(data => {
                this.currentUser = data;
                this.router.navigate(['/']);
            });
        }
    }

    public onSidenavClose = () => {
        this.sidenavClose.emit();
    }

    loginQlikSense() {
        this.authenticationService.loginQlikSense().subscribe(qsUrl => {
            window.open(qsUrl, "_blank");
        });
    }
}

