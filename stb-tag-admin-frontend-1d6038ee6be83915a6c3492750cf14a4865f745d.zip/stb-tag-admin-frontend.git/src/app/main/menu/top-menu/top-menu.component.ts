import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../common/services';
import { User, ListableDto } from '../../../common/models'
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-top-menu',
    templateUrl: './top-menu.component.html',
    styleUrls: ['./top-menu.component.scss']
})
export class TopMenuComponent implements OnInit {
    @Output() public sidenavToggle = new EventEmitter();
    currentUser: User;
    cnst = cnst;

    constructor(
        private router: Router,
        private authenticationService: AuthenticationService
    ) { }

    ngOnInit() {
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
        } else {
            this.authenticationService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
            });
        }
    };

    loginQlikSense() {
        this.authenticationService.loginQlikSense().subscribe(qsUrl => {
            window.open(qsUrl, "_blank");
        });
    }

    onLoggedout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }

    showMenuItem(functionCode: string | string[]) {
        return this.authenticationService.hasPermission(functionCode);
    }

    switchRole(role: ListableDto) {
        if (this.currentUser.selectedRole.key !== role.key) {
            this.authenticationService.switchRole(role.key).subscribe(data => {
                this.currentUser = data;
                this.router.navigate(['/']);
            });
        }
    }

    public onToggleSidenav = () => {
        this.sidenavToggle.emit();
    }
}
