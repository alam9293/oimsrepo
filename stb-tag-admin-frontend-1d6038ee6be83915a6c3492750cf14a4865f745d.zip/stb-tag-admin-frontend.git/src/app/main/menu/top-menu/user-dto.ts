export class User {
    id: number;
    loginId: string;
    name: string;
    status: { key: string, label: string };
    role: { key: string, label: string };
    assignedRolesCodes: string[];
}