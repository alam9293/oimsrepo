import { Component, OnInit, ViewChild } from '@angular/core';
import { PaymentRefundService } from '../payment-refund.service';
import { CommonService } from '../../../common/services'
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-payment-refund-list',
    templateUrl: './payment-refund-list.component.html',
    styleUrls: ['./payment-refund-list.component.scss']
})
export class PaymentRefundListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    constructor(private service: PaymentRefundService,
        private commonService: CommonService,
        private route: ActivatedRoute) { }
    paymentRefunds: any = [];
    filter: any = {};
    listingId = 'payment-refund-list';
    rows = new MatTableDataSource<any>();
    cnst = cnst;
    displayedColumns = ['no', 'billRefNo', 'refNo', 'type', 'refundAmount', 'status', 'submissionDate', 'assignedOfficer'];
    allRecords: boolean = false;

    ngOnInit() {
        this.loadPaymentRefund(true);
    }

    loadPaymentRefund(fromCache) {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.listingId);
        if (this.filter.isFromCache) {
            this.allRecords = this.filter.allRecords;
        } else {
            this.filter.allRecords = this.allRecords;
        }
        if (fromCache) {
            let filterParams = this.route.snapshot.queryParams;
            Object.keys(filterParams).forEach(key => {
                if (Object.keys(this.filter).indexOf(key) <= -1 || !this.filter[key]) {
                    this.filter[key] = filterParams[key];
                }
            });
        }

        this.service.getPaymentRefunds(this.filter).subscribe(data => {
            this.commonService.setResultDto(this.paginator, this.rows, data);
            this.commonService.cacheSearchDto(this.filter);
            this.paymentRefunds = data;

        });
    }

    toggle() {
        this.loadPaymentRefund(false);
    }

}
