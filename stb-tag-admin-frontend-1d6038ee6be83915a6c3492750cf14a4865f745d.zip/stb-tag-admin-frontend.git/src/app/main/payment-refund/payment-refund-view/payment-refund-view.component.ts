import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDrawer, MatDialog, MatSnackBar, MatDialogRef } from '@angular/material';
import { PaymentRefundService } from '../payment-refund.service';
import * as cnst from '../../../common/constants';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { PaymentRefundDetailsComponent } from '../../../common/modules/payment-refund-details/payment-refund-details.component';
import { CommonService } from '../../../common/services/common.service';
import { NoteDialogComponent } from '../../../common/modules/note-dialog/note-dialog.component';

@Component({
    selector: 'app-payment-refund-view',
    templateUrl: './payment-refund-view.component.html',
    styleUrls: ['./payment-refund-view.component.scss']
})
export class PaymentRefundViewComponent implements OnInit {
    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(PaymentRefundDetailsComponent) paymentRefundDetailsComponent: PaymentRefundDetailsComponent;
    private dialogRef: MatDialogRef<any>
    constructor(private route: ActivatedRoute,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private service: PaymentRefundService,
        private commonService: CommonService) { }
    cnst = cnst;
    paymentRefund: any = {};

    ngOnInit() {
        if (!this.matDrawer.opened) {
            this.matDrawer.toggle();
        }
        if (this.route.snapshot.paramMap.get('id')) {
            this.service.getPaymentRefundById(this.route.snapshot.paramMap.get('id')).subscribe(data => {
                this.paymentRefund = data;
            });
        } else {
            this.service.getPaymentRefund(this.route.snapshot.paramMap.get('billRefNo')).subscribe(data => {
                this.paymentRefund = data;
            });
        }
    }

    save() {
        this.paymentRefundDetailsComponent.save();
    }

    submitAction(action) {
        let dialogData: any = {
            internalRemarks: true,
            externalRemarks: false,
            files: true
        }
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: dialogData
        });
        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                let obj = this.commonService.buildFormData({ ...result.params }, result.files);
                this.service.submitAction(obj, action.name, this.route.snapshot.paramMap.get('id')).subscribe(data => {
                    this.ngOnInit();
                    this.paymentRefundDetailsComponent.ngOnInit();
                    this.commonService.popSnackbar(cnst.Messages.GENERIC_SUCCCESS, 'success-snackbar');
                }, error => {
                    this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                });
            }
        });
    }

    openNoteDialog() {
        const noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });
        noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.service.saveNote(result.params, this.paymentRefund.workflowId).subscribe(
                    data => {
                        this.ngOnInit();
                        this.paymentRefundDetailsComponent.ngOnInit();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

}
