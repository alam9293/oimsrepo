import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../common/constants';
import * as _ from 'lodash';

@Injectable({
    providedIn: 'root'
})
export class PaymentRefundService {

    constructor(private http: HttpClient) { }

    getPaymentRefund(billRefNo): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/payment-refund/view/' + billRefNo);
    }
    getPaymentRefundById(id): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/payment-refund/view/id/' + id);
    }
    savePaymentRefund(obj): Observable<any> {
        return this.http.post<any>(cnst.apiBaseUrl + '/payment-refund/save', obj);
    }
    getPaymentRefunds(searchDto): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/payment-refund/view', { params: searchDto });
    }
    submitAction(obj, action, id): Observable<any> {
        return this.http.post<any>(cnst.apiBaseUrl + '/payment-refund/' + action + '/' + id, obj);
    }
    saveNote(params: any, id: any): Observable<any> {

        const files: Array<File> = params.files;

        let formData: FormData = new FormData();
        formData.append('workflowId', id);
        formData.append('internalRemarks', params.internalRemarks);

        if (files) {
            for (let i = 0; i < files.length; i++) {
                formData.append("files", files[i]['file']);
                formData.append("fileDescription", files[i]['fileDescription']);
            }
        }

        return this.http.post(cnst.apiBaseUrl + '/payment-refund/notes/save', formData);
    }
}
