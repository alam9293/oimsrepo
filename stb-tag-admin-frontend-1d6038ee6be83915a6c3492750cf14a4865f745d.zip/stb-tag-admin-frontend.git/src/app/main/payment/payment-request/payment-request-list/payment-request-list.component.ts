import { SelectionModel } from '@angular/cdk/collections';
import { SuccessSnackbarComponent } from '../../../../common/modules/success-snackbar/success-snackbar.component';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { PaymentService } from '../../payment.service';
import { CommonService } from '../../../../common/services'
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';
import { ActivatedRoute } from '@angular/router';
import { DialogPaymentTxnSave } from '../payment-request-view/payment-request-view.component';

@Component({
    selector: 'app-payment-request-list',
    templateUrl: './payment-request-list.component.html',
    styleUrls: ['./payment-request-list.component.scss']
})
export class PaymentRequestListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    txnDialogRef: MatDialogRef<any>;
    rows = new MatTableDataSource<any>();
    selection = new SelectionModel<any>(true, []);
    displayedColumns = ['select', 'billRefNo', 'refNo', 'type', 'payerUinUen', 'payerName', 'payableAmount', 'status', 'lastTxnStatus', 'lastTxnDate', 'lastTxnId', 'lastTxnPaymentTypeLabel'];
    listingId = 'payment-request-list';
    filter: any = {};
    cnst = cnst;
    paymentRequestTypes: any = [];
    paymentRequestStatuses: any = [];
    paymentTxnStatuses: any = [];
    paymentTypes: any = [];

    constructor(
        private paymentService: PaymentService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar,
        private route: ActivatedRoute
    ) { }

    ngOnInit() {
        if (this.route.snapshot.paramMap.get('status')) {
            this.filter.statusCode = this.route.snapshot.paramMap.get('status');
            this.loadPaymentRequests(false);

        } else {
            this.loadPaymentRequests(true);

        }
        this.loadCommonTypes();
    }

    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.rows.data.length;
        return numSelected === numRows;
    }

    masterToggle() {
        this.isAllSelected() ? this.selection.clear() : this.rows.data.forEach(row => this.selection.select(row));
    }

    loadPaymentRequests(fromCache: boolean) {

        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.listingId);

        if (fromCache) {
            let filterParams = this.route.snapshot.queryParams;
            Object.keys(filterParams).forEach(key => {
                if (Object.keys(this.filter).indexOf(key) <= -1 || !this.filter[key]) {
                    this.filter[key] = filterParams[key];
                }
            });
        }

        this.paymentService.getPaymentRequests(this.filter).subscribe(data => {
            this.commonService.setResultDto(this.paginator, this.rows, data);
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    loadCommonTypes() {
        this.paymentService.getPaymentRequestTypes().subscribe(data => this.paymentRequestTypes = data);
        this.commonService.getPaymentRequestStatuses().subscribe(data => this.paymentRequestStatuses = data);
        this.commonService.getPaymentTxnStatuses().subscribe(data => this.paymentTxnStatuses = data);
        this.commonService.getPaymentTypes().subscribe(data => this.paymentTypes = data);
    }

    checkSelectedHasSuccessTxn(): string[] {
        let invalid = [];
        this.selection.selected.forEach(row => {
            if (!row.lastTxnStatusCode || row.lastTxnStatusCode != cnst.Statuses.PAYTXN_SUCCESSFUL) {
                invalid.push(row.billRefNo);
            }
        });
        return invalid;
    }
    checkCurrentStatus(statusCode): string[] {
        let invalid = [];
        if (statusCode == 'paid') {
            this.selection.selected.forEach(row => {
                if (row.statusCode != cnst.Statuses.PAYREQ_NOT_PAID) {
                    invalid.push(row.billRefNo);
                }
            });
        } else if (statusCode == 'settled') {
            this.selection.selected.forEach(row => {
                if (row.statusCode != cnst.Statuses.PAYREQ_PAID) {
                    invalid.push(row.billRefNo);
                }
            });
        } else if (statusCode == cnst.Statuses.PAYREQ_DISBURSED) {
            this.selection.selected.forEach(row => {
                if (row.statusCode != cnst.Statuses.PAYREQ_PENDING_DISBURSEMENT) {
                    invalid.push(row.billRefNo);
                }
            });
        } else if (statusCode == cnst.Statuses.PAYREQ_REFUNDED) {
            this.selection.selected.forEach(row => {
                if (row.statusCode != cnst.Statuses.PAYREQ_PENDING_REFUNDED) {
                    invalid.push(row.billRefNo);
                }
            });
        }

        return invalid;
    }

    setSelectedItemsStatusWithPayType(status: string, statusCode: string) {
        if (this.selection.selected.length < 1) {
            this.commonService.popSnackbar('Please select at least 1 record', 'error-snackbar');
        } else {
            let checkArray = this.checkCurrentStatus(statusCode);
            if (checkArray.length > 0) {
                this.commonService.popSnackbar('These payment request are not allowed to be set to ' + status + '. Please untick them before submitting: ' + checkArray.toString(), 'error-snackbar');
            } else {
                this.openPaymentTxnDialog(this.selection.selected, statusCode);
            }
        }

    }

    openPaymentTxnDialog(selections, statusCode) {
        let dataToPassToTxnDialog = {};

        dataToPassToTxnDialog = { multipleUpdate: true, payReqItems: selections, type: statusCode, resultantStatusCode: cnst.Statuses.PAYREQ_DISBURSED };
        this.txnDialogRef = this.dialog.open(DialogPaymentTxnSave, {
            data: dataToPassToTxnDialog,
            height: '500px',
            width: '800px',
        });
        this.txnDialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.loadPaymentRequests(true);
                this.commonService.popSnackbar(null, 'success-snackbar');
                if (this.selection) {
                    this.selection.clear();
                }
            }
        });


    }

    setSelectedItemsStatus(status: string, statusCode: string) {
        if (this.selection.selected.length < 1) {
            this.commonService.popSnackbar('Please select at least 1 record', 'error-snackbar');
        } else if (this.checkCurrentStatus(statusCode).length > 0) {
            let refNos = "";
            let array = this.checkCurrentStatus(statusCode);
            array.forEach(element => {
                refNos = refNos + element + ',';
            });
            this.commonService.popSnackbar('These payment request are not allowed to be set to ' + status + '. Please untick them before submitting: ' + refNos.slice(0, refNos.length - 1), 'error-snackbar');
        } else if (this.checkSelectedHasSuccessTxn().length > 0) {
            let refNos = "";
            let array = this.checkSelectedHasSuccessTxn();
            array.forEach(element => {
                refNos = refNos + element + ',';
            });
            this.commonService.popSnackbar('These payment request does not have a successful transaction. Please untick them before submitting: ' + refNos.slice(0, refNos.length - 1), 'error-snackbar');
        } else {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: 'Confirm update selected statuses to "' + status + '"?',
                    internalRemarks: true,
                    externalRemarks: false,
                    files: true
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    let ids = [];
                    this.selection.selected.forEach(row => {
                        ids.push(row.id);
                    });
                    let obj = this.commonService.buildFormData({ ...result.params, ids: [ids] }, result.files);
                    this.paymentService.updatePaymentRequestStatus(obj, statusCode).subscribe(
                        data => {
                            this.selection.clear();
                            this.loadPaymentRequests(true);
                            this.commonService.popSnackbar(null, 'success-snackbar');
                        })
                }
            });
        }
    }
}
