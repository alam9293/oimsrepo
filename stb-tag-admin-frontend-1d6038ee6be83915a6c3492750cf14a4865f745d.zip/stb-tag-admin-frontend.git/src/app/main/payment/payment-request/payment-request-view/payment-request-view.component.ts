import { Component, OnInit, ViewChild, HostListener, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDrawer, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatTableDataSource, ErrorStateMatcher } from '@angular/material';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { PaymentService } from '../../payment.service';
import { PaymentRefundService } from '../../../payment-refund/payment-refund.service';
import { CommonService } from '../../../../common/services';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';
import { NoteDialogComponent } from '../../../../common/modules/note-dialog/note-dialog.component';
import { ApplicationWorkflowComponent } from '../../../../common/modules/application-workflow/application-workflow.component';



@Component({
    selector: 'app-payment-request-view',
    templateUrl: './payment-request-view.component.html',
    styleUrls: ['./payment-request-view.component.scss']
})
export class PaymentRequestViewComponent implements OnInit {

    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;
    billRefNo: string;
    dialogRef: MatDialogRef<any>;
    paymentRequest: any = { lastTxn: {} };
    paymentRequestTypes: any = [];
    paymentTxnRows = new MatTableDataSource<any>();
    paymentTxnDisplayedColumns = ['id', 'txnDate', 'status', 'amount', 'paymentType', 'remarks', 'delete'];
    isNew: boolean = false;
    hasSuccessfulTxn: boolean = false;
    paymentDisbursed: any;
    cnst = cnst;
    subscription: Subscription;
    form = this.formBuilder.group({
        refNo: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
        typeCode: ['', Validators.required], // isNew only
        type: [''], // !isNew only
        isPayerCompany: [''],
        payerUinUen: ['', [Validators.required, Validators.maxLength(10), Validators.pattern(/^[a-zA-Z0-9]*$/)]],
        payerName: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
        description: ['', Validators.maxLength(cnst.maxLengthStr)],
        remarks: ['', Validators.maxLength(cnst.maxLengthStr)],
        payableAmount: ['', [Validators.required, Validators.min(1), Validators.max(100000)]],
        userField2: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]]
    });

    constructor(private route: ActivatedRoute, private router: Router, private formBuilder: FormBuilder, private dialog: MatDialog, private snackBar: MatSnackBar,
        private paymentService: PaymentService, private commonService: CommonService, private paymentRefundService: PaymentRefundService) {
        this.subscription = paymentService.reloadCommand$.subscribe(
            reload => {
                this.loadPaymentRequest();
            });

    }

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnDestroy(): void {
        //Called once, before the instance is destroyed.
        //Add 'implements OnDestroy' to the class.
        this.subscription.unsubscribe();
    }

    ngOnInit() {
        this.paymentTxnRows.sort = this.sort;
        this.loadCommonStatuses();
        if (this.route.snapshot.url.toString() === 'payment-request-new') {
            this.isNew = true;
            this.form.enable();
            this.loadCePaymentRequestTypes();
        } else {
            this.billRefNo = this.route.snapshot.paramMap.get('billRefNo');
            this.loadPaymentRequest();
        }
        this.matDrawer.toggle();
    }

    loadPaymentRequest() {
        this.paymentService.getPaymentRequest(this.billRefNo).subscribe(data => {
            this.paymentRequest = data;
            this.form.patchValue(data);
            this.form.disable();
            this.paymentTxnRows.data = data.paymentTxns;
            this.checkForSuccessfulTxn();
            this.isNew = false;
        });
    }

    checkForSuccessfulTxn() {
        if (this.paymentRequest.lastTxn && this.paymentRequest.lastTxn.statusCode == cnst.Statuses.PAYTXN_SUCCESSFUL) {
            this.hasSuccessfulTxn = true;
        } else {
            this.hasSuccessfulTxn = false;
        }
        console.log(this.hasSuccessfulTxn);
    }

    loadCePaymentRequestTypes() {
        this.paymentService.getPaymentRequestTypes().subscribe(data => this.paymentRequestTypes = _.filter(data, function (type) {
            return type.key === cnst.CePaymentRequestTypes.PAYREQ_CE_AFP || type.key === cnst.CePaymentRequestTypes.PAYREQ_CE_COMPOSITION;
        }));
    }

    savePaymentRequest() {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Save Confirmation',
            }
        });
        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.paymentService.savePaymentRequest(this.form.value).subscribe(
                    billRefNo => {
                        this.commonService.popSnackbar(null, 'success-snackbar');
                        this.form.markAsPristine(); // to prevent triggering PristineGuard
                        this.router.navigate(['/payment-request-view/' + billRefNo]);
                    })
            }
        });
    }

    updatePaymentRequestStatus(status: string, statusCode: string) {
        if (statusCode == 'paid' && !this.hasSuccessfulTxn) {
            this.openPaymentTxnDialog(statusCode);
        } else if (statusCode == cnst.Statuses.PAYREQ_REFUNDED || statusCode == cnst.Statuses.PAYREQ_DISBURSED) {
            this.openPaymentTxnDialog(statusCode);
        } else {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: 'Confirm update status to "' + status + '"?',
                    internalRemarks: true,
                    externalRemarks: false,
                    files: true
                }
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    let obj = this.commonService.buildFormData({ ...result.params, ids: [this.paymentRequest.id] }, result.files);
                    this.paymentService.updatePaymentRequestStatus(obj, statusCode).subscribe(
                        data => {
                            this.loadPaymentRequest();
                            if (this.workflowComp) {
                                this.workflowComp.loadWorkflowActions();
                            }
                            this.commonService.popSnackbar(null, 'success-snackbar');
                        })
                }
            });
        }

    }
    openNoteDialog() {
        const noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });
        noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.paymentService.saveNote(result.params, this.paymentRequest.id).subscribe(
                    data => {
                        if (this.workflowComp) {
                            this.workflowComp.loadWorkflowActions();
                        }
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    openPaymentTxnDialog(statusCode) {
        let dataToPassToTxnDialog = {};
        if (statusCode == cnst.Statuses.PAYREQ_REFUNDED) {
            this.paymentRefundService.getPaymentRefund(this.paymentRequest.billRefNo).subscribe(data => {
                dataToPassToTxnDialog = { amt: data.refundAmount, billRefNo: this.paymentRequest.billRefNo, type: cnst.Statuses.PAYREQ_REFUNDED, resultantStatusCode: statusCode };
                this.dialogRef = this.dialog.open(DialogPaymentTxnSave, {
                    data: dataToPassToTxnDialog,
                    height: '500px',
                    width: '800px',
                });
                this.dialogRef.afterClosed().subscribe(result => {
                    if (result.decision) {
                        this.loadPaymentRequest();
                        if (this.workflowComp) {
                            this.workflowComp.loadWorkflowActions();
                        }
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    }
                });
            });
        } else if (statusCode == cnst.Statuses.PAYREQ_DISBURSED) {
            dataToPassToTxnDialog = { billRefNo: this.paymentRequest.billRefNo, amt: this.paymentRequest.payableAmount, type: statusCode, resultantStatusCode: statusCode };
            this.dialogRef = this.dialog.open(DialogPaymentTxnSave, {
                data: dataToPassToTxnDialog,
                height: '500px',
                width: '800px',
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.loadPaymentRequest();
                    if (this.workflowComp) {
                        this.workflowComp.loadWorkflowActions();
                    }
                    this.commonService.popSnackbar(null, 'success-snackbar');
                }
            });
        } else {
            dataToPassToTxnDialog = { billRefNo: this.paymentRequest.billRefNo, amt: this.paymentRequest.payableAmount, type: 'paid', resultantStatusCode: cnst.Statuses.PAYREQ_PAID };
            this.dialogRef = this.dialog.open(DialogPaymentTxnSave, {
                data: dataToPassToTxnDialog,
                height: '500px',
                width: '800px',
            });
            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.loadPaymentRequest();
                    if (this.workflowComp) {
                        this.workflowComp.loadWorkflowActions();
                    }
                    this.commonService.popSnackbar(null, 'success-snackbar');
                }
            });
        }

    }

    deletePaymentTxn(paymentTxnId: number) {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Confirm delete transaction with ID "' + paymentTxnId + '"?',
            }
        });
        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.paymentService.deletePaymentTxn(paymentTxnId).subscribe(
                    data => {
                        this.loadPaymentRequest();
                        if (this.workflowComp) {
                            this.workflowComp.loadWorkflowActions();
                        }
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    })
            }
        });
    }

    loadCommonStatuses() {
        this.commonService.getStatusByCode(cnst.payReqStatus.PAYREQ_DISBURSED).subscribe(data => {
            this.paymentDisbursed = data;
        });
    }

}

@Component({
    selector: 'dialog-payment-txn-save',
    templateUrl: 'payment-txn-save-dialog.html'
})
export class DialogPaymentTxnSave implements OnInit {
    paymentRequestStatuses: any = [];
    offlinePaymentTypes: any = [];
    cnst = cnst;
    paymentTxnForm = this.formBuilder.group({
        amount: ['', []],
        paymentTypeCode: [cnst.PaymentTypes.GIRO, Validators.required],
        resultantStatusCode: [cnst.Statuses.PAYREQ_PAID, Validators.required],
        remarks: ['', Validators.maxLength(cnst.maxLengthStr)],
        payReqItems: []
    });
    parentData: any = {};

    constructor(private formBuilder: FormBuilder, private paymentService: PaymentService, private commonService: CommonService, private snackBar: MatSnackBar, public dialogRef: MatDialogRef<DialogPaymentTxnSave>, @Inject(MAT_DIALOG_DATA) public data: any) { }

    ngOnInit() {
        this.parentData = this.data;
        this.commonService.getPaymentRequestStatuses().subscribe(data => this.paymentRequestStatuses = _.filter(data, function (type) {
            return type.key !== cnst.Statuses.PAYREQ_NOT_PAID && type.key !== cnst.Statuses.PAYREQ_VOID;
        }));
        console.log(this.data);
        if (this.data.type === cnst.Statuses.PAYREQ_DISBURSED || this.data.type === cnst.Statuses.PAYREQ_REFUNDED) {
            this.commonService.getPaymentTypes().subscribe(data => this.offlinePaymentTypes = _.filter(data, function (type) {
                return type.key !== cnst.PaymentTypes.VISA && type.key !== cnst.PaymentTypes.MASTERCARD && type.key !== cnst.PaymentTypes.PAYNOW && type.key !== cnst.PaymentTypes.INTERBANK_TXF;
            }));
        } else {
            this.commonService.getPaymentTypes().subscribe(data => this.offlinePaymentTypes = _.filter(data, function (type) {
                return type.key !== cnst.PaymentTypes.VISA && type.key !== cnst.PaymentTypes.MASTERCARD;
            }));
        }
        if (this.data.multipleUpdate) {
            this.paymentTxnForm.get('payReqItems').setValue(this.data.payReqItems);
        } else {
            this.paymentTxnForm.get('amount').setValidators([Validators.required, Validators.min(1), Validators.max(100000)]);
            this.paymentTxnForm.get('amount').updateValueAndValidity();
            this.paymentTxnForm.get('amount').setValue(this.data.amt);
        }

    }


    savePaymentTxn() {
        if (this.data.type == cnst.Statuses.PAYREQ_REFUNDED) {
            this.paymentTxnForm.get('resultantStatusCode').setValue(cnst.Statuses.PAYREQ_REFUNDED);
        } else {
            this.paymentTxnForm.get('resultantStatusCode').setValue(this.data.resultantStatusCode);
        }
        if (this.data.multipleUpdate) {
            this.paymentService.savePaymentTxns(this.paymentTxnForm.value).subscribe(
                paymentTxnId => {
                    this.close(true);
                })
        } else {
            this.paymentService.savePaymentTxn(this.data.billRefNo, this.paymentTxnForm.value).subscribe(
                paymentTxnId => {
                    this.close(true);
                })
        }
    }

    close(decision: boolean) {
        let obj = {
            decision: decision,
        };
        this.dialogRef.close(obj);
    }
}
