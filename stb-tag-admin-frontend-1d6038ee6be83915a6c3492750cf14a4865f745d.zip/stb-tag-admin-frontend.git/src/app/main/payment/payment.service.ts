import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { VersionCheckUtil } from '../../common/helper';
import * as cnst from '../../common/constants';
import * as _ from 'lodash';

@Injectable({
    providedIn: 'root'
})
export class PaymentService {

    constructor(private http: HttpClient) { }

    getPaymentRequestTypes(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/payment/requests/view/payment-request-types');
    }

    getPaymentRequests(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + '/payment/requests/view', { params: searchDto });
    }

    getPaymentRequest(billRefNo: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/payment/requests/view/' + billRefNo);
    }

    savePaymentRequest(dto: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/payment/requests/save', dto, { responseType: 'text' });
    }

    updatePaymentRequestStatus(obj, statusCode: string): Observable<any> {
        return this.http.post<any>(cnst.apiBaseUrl + '/payment/requests/update-status/' + statusCode, obj, VersionCheckUtil.getHeaderForListing('PaymentRequest'));
    }

    savePaymentTxn(billRefNo: string, dto: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/payment/txns/save/' + billRefNo, dto, { responseType: 'text' });
    }
    savePaymentTxns(selections: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/payment/txns/save/multiple', selections, { responseType: 'text' });
    }

    deletePaymentTxn(paymentTxnId: number): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/payment/txns/delete/' + paymentTxnId, null, { responseType: 'text' });
    }
    saveNote(params: any, id: any): Observable<any> {

        const files: Array<File> = params.files;

        let formData: FormData = new FormData();
        formData.append('payReqId', id);
        formData.append('internalRemarks', params.internalRemarks);

        if (files) {
            for (let i = 0; i < files.length; i++) {
                formData.append("files", files[i]['file']);
                formData.append("fileDescription", files[i]['fileDescription']);
            }
        }

        return this.http.post(cnst.apiBaseUrl + '/payment/requests/notes/save', formData);
    }

    // Observable string sources
    private reloadCommandSource = new Subject<string>();

    // Observable string streams
    reloadCommand$ = this.reloadCommandSource.asObservable();
    reloadPaymentRequest() {
        this.reloadCommandSource.next();
    }


}
