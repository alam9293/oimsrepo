import { Component, OnInit } from '@angular/core';
import { ReportService } from './report-list.service';
import { FileUtil } from '../../../../common/helper';
@Component({
    selector: 'app-report-list',
    templateUrl: './report-list.component.html',
    styleUrls: ['./report-list.component.scss']
})
export class TaReportListComponent implements OnInit {

    constructor(
        private reportService: ReportService,
        private fileUtil: FileUtil
    ) { }

    reports: any[] = [];
    lastRunDate: any;

    ngOnInit() {
        this.reportService.getReportLastGenerationDate().subscribe(data => { this.lastRunDate = data; })
        this.reportService.getReports().subscribe(data => {
            this.reports = data;
        });
    }

    downloadReport(report) {
        this.reportService.downloadReport(report.reportName).subscribe(data => {
            this.fileUtil.exportForDesktop(data, report.fileName);
        });
    }
}
