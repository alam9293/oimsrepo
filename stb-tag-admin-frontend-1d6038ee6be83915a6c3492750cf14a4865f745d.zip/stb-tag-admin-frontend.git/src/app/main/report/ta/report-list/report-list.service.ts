import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient, } from '@angular/common/http';
import * as cnst from '../../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class ReportService {

    constructor(private http: HttpClient) { }

    getReportLastGenerationDate(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TaApiUrl.TA_REPORT + '/view/last-run');
    }

    getReports(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TaApiUrl.TA_REPORT + '/view');
    }

    downloadReport(reportName: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TaApiUrl.TA_REPORT + '/download/' + reportName, { responseType: 'blob' as 'json' });
    }

}