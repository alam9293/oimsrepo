import { Component, OnInit } from '@angular/core';

import { FileUtil } from '../../../../common/helper';
import { ReportService } from './report-list.service';

@Component({
    selector: 'app-report-list',
    templateUrl: './report-list.component.html',
    styleUrls: ['./report-list.component.scss']
})
export class TgReportListComponent implements OnInit {

    constructor(
        private reportService: ReportService,
        private fileUtil: FileUtil
    ) { }


    ngOnInit() {
    }

    downloadReport() {
        this.reportService.downloadActiveTg().subscribe(data => {
            this.fileUtil.exportForDesktop(data, 'Active Tourist Guide.xlsx');
        });
    }
}
