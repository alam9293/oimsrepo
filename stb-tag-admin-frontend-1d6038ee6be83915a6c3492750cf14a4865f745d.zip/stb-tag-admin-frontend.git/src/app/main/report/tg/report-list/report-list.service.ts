import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import * as cnst from '../../../../common/constants';


@Injectable({
    providedIn: 'root'
})
export class ReportService {

    constructor(private http: HttpClient) { }

    downloadActiveTg(): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TgAPiUrl.TG_REPORT + '/download/active-tg', { responseType: 'blob' as 'json' });
    }

}