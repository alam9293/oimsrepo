import { SelectionModel } from '@angular/cdk/collections';
import { SuccessSnackbarComponent } from '../../../common/modules/success-snackbar/success-snackbar.component';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { ResourcesService } from '../resources-service'
import { CommonService } from '../../../common/services'
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-resources-list',
    templateUrl: './resources-list.component.html',
    styleUrls: ['./resources-list.component.scss'],
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
            state('expanded', style({ height: '*' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ],
})
export class ResourcesListComponent implements OnInit {

    constructor(
        private route: ActivatedRoute,
        private resourcesService: ResourcesService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar
    ) { }

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    rows = [];
    dataSource = [];
    selection = new SelectionModel<any>(true, []);
    columnsToDisplay = ['title', 'isPrivate', 'effectiveDate', 'expiryDate', 'currentlyDisplayed', 'updatedBy', 'edit'];
    listingId = "resources-list";
    expandedElement: any = {};
    resourcesTypeCode: string;
    filter: any = {};
    cnst = cnst;

    ngOnInit() {
        this.resourcesTypeCode = this.route.snapshot.data.resourcesTypeCode;
        console.log(this.resourcesTypeCode);
        this.loadResources(true);
    }

    loadResources(fromCache: boolean) {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.listingId);

        this.resourcesService.getAllResourcesList(this.filter, this.resourcesTypeCode).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }
}
