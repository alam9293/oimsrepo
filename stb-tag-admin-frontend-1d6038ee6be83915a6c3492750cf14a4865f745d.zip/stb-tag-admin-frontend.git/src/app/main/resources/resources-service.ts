import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../common/constants';
import { AuthenticationService } from '../../common/services';

@Injectable({
    providedIn: 'root'
})
export class ResourcesService {

    constructor(private http: HttpClient,
        private authenticationService: AuthenticationService) { }

    getAllResourcesList(searchDto: any, type: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/category/get-all-categorys/' + type, { params: searchDto });
    }

    getResourcesDetails(category: number, type: string): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/category/view/' + category + '/' + type);
    }

    saveResources(bulleinDetail: any, categoryList: any, deleteCategoryList: any, categoryListDeletedFiles: any, categoryIconDeletedFiles: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('categoryDto', new Blob(
            [JSON.stringify(bulleinDetail)],
            { type: 'application/json' }
        ));

        var categoryListData = new Blob(
            [JSON.stringify(categoryList)],
            { type: 'application/json' }
        );
        formData.append('categoryListDto', categoryListData);

        var deleteCategory = new Blob(
            [JSON.stringify(deleteCategoryList)],
            { type: 'application/json' }
        );
        formData.append('deleteCategoryList', deleteCategory);

        var categoryListDeleted = new Blob(
            [JSON.stringify(categoryListDeletedFiles)],
            { type: 'application/json' }
        );
        formData.append('categoryListDeletedFiles', categoryListDeleted);

        var categoryIconDeleted = new Blob(
            [JSON.stringify(categoryIconDeletedFiles)],
            { type: 'application/json' }
        );
        formData.append('categoryIconDeletedFiles', categoryIconDeleted);
        return this.http.post(cnst.apiBaseUrl + '/category/save/', formData);
    }

    public get allowToSaveBulletin(): boolean {
        return this.authenticationService.checkPermission('BULLETIN_SAVE');
    }
}