import { Component, OnInit, ViewChild, HostListener, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SuccessSnackbarComponent } from '../../../common/modules/success-snackbar/success-snackbar.component';
import { ConfirmationDialogComponent } from '../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
import { ToolbarService, LinkService, ImageService, HtmlEditorService, RichTextEditorComponent } from '@syncfusion/ej2-angular-richtexteditor';
import { ResourcesService } from '../resources-service'
import { CommonService } from '../../../common/services'
import { Observable } from 'rxjs';
import * as cnst from '../../../common/constants';
import { FileUtil, FormUtil } from '../../../common/helper';
import { DateValidator } from '../../../common/validators';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AuthenticationService } from '../../../common/services';
import { User, ListableDto } from '../../../common/models'

@Component({
    selector: 'app-resources-view',
    templateUrl: './resources-view.component.html',
    styleUrls: ['./resources-view.component.scss'],
    providers: [ToolbarService, LinkService, ImageService, HtmlEditorService]
})
export class ResourcesViewComponent implements OnInit {
    public Editor = ClassicEditor;
    public config = { toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'inserttable', 'undo', 'redo'] };


    currentUser: User;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private dialog: MatDialog,
        private snackBar: MatSnackBar,
        private resourcesService: ResourcesService,
        private fileUtil: FileUtil,
        private commonService: CommonService,
        public formUtil: FormUtil,
        private authenticationService: AuthenticationService
    ) { }

    cnst = cnst;
    form = this.formBuilder.group({
        title: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
        //content: ['', [Validators.required]],
        //type: ['BULLETIN_GENERAL'],
        isPrivate: [''],
        effectiveDate: ['', Validators.required],
        expiryDate: ['', Validators.required],
        id: [''],
        hash: [''],
        originalFilename: ['', Validators.required],
        fileId: [''],
    }, { validator: DateValidator.dateLessThan("effectiveDate", "expiryDate") });
    isNew: boolean = false;
    selectedFile: File;
    selectedFiles: any = [];
    categoryId: number;
    typeTAorTG: string;
    category: any = {};
    typeList: any = [];
    adminDeletedFiles: any = [];
    unionMap = new Map<string, string>();

    categoryDeletedFiles: number[] = [];
    categoryIconDeletedFiles: number[] = [];
    //CategoryList
    deleteCategoryList: any = [];
    categoryListForm = this.formBuilder.group({
        categoryList: this.formBuilder.array([])
    });

    isTaTg = 'TA';

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {

        //console.log(sessionStorage.getItem('currentUser'));
        console.log(this.authenticationService.currentUserValue);
        if (this.authenticationService.currentUserValue.selectedRole.key.includes('TA')) {
            this.isTaTg = 'TA';
            this.typeTAorTG = 'BULLETIN_TA';
        } else if (this.authenticationService.currentUserValue.selectedRole.key.includes('TG')) {
            this.isTaTg = 'TG';
            this.typeTAorTG = 'BULLETIN_TG';
        }

        if (this.route.snapshot.url.toString() === 'resources-new') {
            this.isNew = true;
            this.loadSelectedType(false);
        } else {
            this.categoryId = +this.route.snapshot.paramMap.get('id1');
            // this.typeTAorTG = this.route.snapshot.paramMap.get('id2');
            this.form.get('id').setValue(this.categoryId);
            this.loadBulletinDetails();
        }
        this.allowToSave();
    }

    //CategoryList
    get categoryList(): FormArray {
        return this.categoryListForm.get('categoryList') as FormArray;
    }

    buildCategoryList(categoryListData) {
        var form = this.formBuilder.group({
            id: [categoryListData.id],
            categoryId: [categoryListData.categoryId],
            fileId: [categoryListData.fileId],
            ordinal: [categoryListData.ordinal],
            originalFilename: [categoryListData.originalFilename, Validators.required],
            hash: [categoryListData.hash],
            title: [categoryListData.title, [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            type: [categoryListData.type],
            effectiveDate: [categoryListData.effectiveDate, Validators.required],
            expiryDate: [categoryListData.expiryDate, Validators.required],
            fileIconId: [categoryListData.fileIconId],
            hashIcon: [categoryListData.hashIcon],
            originalIconFilename: [categoryListData.originalIconFilename, Validators.required],
        }, { validator: DateValidator.dateLessThan("effectiveDate", "expiryDate") });

        this.categoryList.push(form);
    }

    addNewCategoryListItems() {
        var form = this.formBuilder.group({
            id: [],
            categoryId: [],
            type: ['BULLETIN_GENERAL'],
            fileId: [],
            ordinal: [],
            originalFilename: ['', Validators.required],
            hash: [''],
            title: ['', [Validators.required, Validators.maxLength(cnst.maxLengthStr)]],
            effectiveDate: ['', Validators.required],
            expiryDate: ['', Validators.required],
            fileIconId: [''],
            hashIcon: [''],
            originalIconFilename: ['', Validators.required],
        }, { validator: DateValidator.dateLessThan("effectiveDate", "expiryDate") });
        this.categoryList.push(form);
    }


    add = function () {
        this.addNewCategoryListItems();
    }

    remove = function (index: number, form) {

        var records = this.categoryList.at(index);
        if (records.get('id').value !== null) {
            this.deleteCategoryList.push(records.get('id').value);
        }
        this.categoryList.removeAt(index);
    }
    onListingIconFileChanged(event, fileForm) {
        console.log('onListingIconFileChanged');
        //this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(event.target.files[0])) {
            var extension = event.target.files[0].type;
            console.log(extension);
            if (extension.includes('jpeg')) {
                this.fileUtil.uploadBulletinFile("jpeg", event.target.files[0]).subscribe(data => {
                    //this.selectedFiles.push(data);
                    //this.form.get('totalDoc').setValue(this.selectedFiles.length);
                    let returnFileDto = JSON.parse(JSON.stringify(data));
                    fileForm.get('originalIconFilename').patchValue(returnFileDto.originalName);
                    fileForm.get('fileIconId').patchValue(returnFileDto.id);
                    fileForm.get('hashIcon').patchValue(returnFileDto.hash);
                });
            }

            if (extension.includes('png')) {
                this.fileUtil.uploadBulletinFile("png", event.target.files[0]).subscribe(data => {
                    //this.selectedFiles.push(data);
                    //this.form.get('totalDoc').setValue(this.selectedFiles.length);
                    let returnFileDto = JSON.parse(JSON.stringify(data));
                    fileForm.get('originalIconFilename').patchValue(returnFileDto.originalName);
                    fileForm.get('fileIconId').patchValue(returnFileDto.id);
                    fileForm.get('hashIcon').patchValue(returnFileDto.hash);
                });
            }

        }
    }

    onIconFileChanged(event, fileForm) {
        //this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(event.target.files[0])) {
            var extension = event.target.files[0].type;
            console.log(extension);
            if (extension.includes('jpeg')) {
                this.fileUtil.uploadBulletinFile("jpeg", event.target.files[0]).subscribe(data => {
                    //this.selectedFiles.push(data);
                    //this.form.get('totalDoc').setValue(this.selectedFiles.length);
                    let returnFileDto = JSON.parse(JSON.stringify(data));
                    fileForm.get('originalFilename').patchValue(returnFileDto.originalName);
                    fileForm.get('fileId').patchValue(returnFileDto.id);
                    fileForm.get('hash').patchValue(returnFileDto.hash);
                });
            }

            if (extension.includes('png')) {
                this.fileUtil.uploadBulletinFile("png", event.target.files[0]).subscribe(data => {
                    //this.selectedFiles.push(data);
                    //this.form.get('totalDoc').setValue(this.selectedFiles.length);
                    let returnFileDto = JSON.parse(JSON.stringify(data));
                    fileForm.get('originalFilename').patchValue(returnFileDto.originalName);
                    fileForm.get('fileId').patchValue(returnFileDto.id);
                    fileForm.get('hash').patchValue(returnFileDto.hash);
                });
            }

        }
    }

    onCategoryFileChanged(event, fileForm) {
        //this.selectedFile = event.target.files[0];
        if (!this.fileUtil.exceedMaxSize(event.target.files[0])) {
            var extension = event.target.files[0].type;
            console.log(extension);
            if (extension.includes('pdf') || extension.includes('PDF')) {
                this.fileUtil.uploadBulletinFile("pdf", event.target.files[0]).subscribe(data => {
                    //this.selectedFiles.push(data);
                    //this.form.get('totalDoc').setValue(this.selectedFiles.length);
                    let returnFileDto = JSON.parse(JSON.stringify(data));
                    fileForm.get('originalFilename').patchValue(returnFileDto.originalName);
                    fileForm.get('fileId').patchValue(returnFileDto.id);
                    fileForm.get('hash').patchValue(returnFileDto.hash);
                });
            }
        }
    }


    downloadListFile(fileForm) {
        console.log('downloading');
        var fileId = fileForm.get('fileId').value,
            fileName = fileForm.get('originalFilename').value,
            fileHash = fileForm.get('hash').value;

        this.fileUtil.download(fileId, fileHash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }

    downloadIconFile(fileForm) {
        console.log('downloading');
        var fileId = fileForm.get('fileId').value,
            fileName = fileForm.get('originalFilename').value,
            fileHash = fileForm.get('hash').value;

        this.fileUtil.download(fileId, fileHash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }
    downloadListingIconFile(fileForm) {
        console.log('downloading');
        var fileId = fileForm.get('fileIconId').value,
            fileName = fileForm.get('originalIconFilename').value,
            fileHash = fileForm.get('hashIcon').value;

        this.fileUtil.download(fileId, fileHash).subscribe(data => {
            this.fileUtil.export(data, fileName);
        });
    }
    removeListFile(fileForm) {
        if (fileForm.get('fileId') != "") {
            this.categoryDeletedFiles.push(fileForm.get('id').value);
        }
        fileForm.get('originalFilename').patchValue("");
        fileForm.get('fileId').patchValue("");
        fileForm.get('hash').patchValue("");
    }

    removeIconListFile(fileForm) {
        if (fileForm.get('fileIconId') != "") {
            this.categoryIconDeletedFiles.push(fileForm.get('id').value);
        }
        fileForm.get('originalIconFilename').patchValue("");
        fileForm.get('fileIconId').patchValue("");
        fileForm.get('hashIcon').patchValue("");
    }
    //

    loadBulletinDetails() {
        this.resourcesService.getResourcesDetails(this.categoryId, this.typeTAorTG).subscribe(data => {
            console.log('loading');
            this.category = data;
            this.form.patchValue(data);
            //this.categoryList.patchValue(data);
            var JSONObject = JSON.parse(JSON.stringify(data));
            var categoryList = JSONObject["categoryList"];
            categoryList.forEach(bindData => {
                this.buildCategoryList(bindData);
            });

            this.isNew = false;
            this.loadSelectedType(data.isPrivate);
            if (data.files) {
                this.selectedFiles = data.files;
                this.form.get('totalDoc').setValue(this.selectedFiles.length);
            }
        });
    }

    saveResources() {
        /*this.form.patchValue({
            files: this.selectedFiles
        });*/
        console.log('Saving');
        //categoryDeletedRecords
        //CategoryListDeletedFiles
        this.resourcesService.saveResources(this.form.value, this.categoryList.value, this.deleteCategoryList, this.categoryDeletedFiles, this.categoryIconDeletedFiles).subscribe(
            categoryId => {
                this.commonService.popSnackbar(null, 'success-snackbar');
                this.form.markAsPristine(); // to prevent triggering PristineGuard
                this.router.navigate(['/resources-view/' + categoryId]);
            });
    }

    /*load() {
        var isPublicPrivate = this.form.get('isPrivate').value;
        this.loadSelectedType(isPublicPrivate);

        if (isPublicPrivate) {
            var index = this.form.get('typeCode').value.indexOf('GENERAL');
            if (index != -1) {
                this.form.get('typeCode').setValue('');
            }
        }
    }*/

    loadSelectedType(isPublicPrivate: Boolean) {
        if (isPublicPrivate) {
            this.commonService.getBulletinTypeCodeTaTgList().subscribe(data => this.typeList = data);
        } else {
            this.commonService.getBulletinTypeCodeList().subscribe(data => this.typeList = data);
        }
    }



    removeFile(doc) {
        this.selectedFiles.splice(this.selectedFiles.indexOf(doc), 1);
        this.form.get('totalDoc').setValue(this.selectedFiles.length);
        this.adminDeletedFiles.push(doc.id);
    }

    allowToSave() {
        var allowSave = this.resourcesService.allowToSaveBulletin;
        if (allowSave == true) {
            this.form.enable();
        } else {
            this.form.disable();
        }
    }

    textChanged() {
        var title = this.form.get("title").value;
        var splitStr = title.toLowerCase().split(' ');
        for (var i = 0; i < splitStr.length; i++) {
            splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
        }
        this.form.get("title").setValue(splitStr.join(' '));
    }
}
