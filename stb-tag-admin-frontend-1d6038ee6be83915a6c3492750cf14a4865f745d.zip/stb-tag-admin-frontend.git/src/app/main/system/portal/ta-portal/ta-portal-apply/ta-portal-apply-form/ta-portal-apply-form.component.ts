import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import * as dto from './ta-portal-apply-form-dto';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Observable, } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
    selector: 'app-ta-portal-apply-form',
    templateUrl: './ta-portal-apply-form.component.html',
    styleUrls: ['./ta-portal-apply-form.component.scss']
})
export class TaPortalApplyFormComponent implements OnInit {

    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    thirdFormGroup: FormGroup;
    fourthFormGroup: FormGroup;
    fifthFormGroup: FormGroup;
    genders: dto.ListableDto[];
    nationalities: dto.ListableDto[];
    licence_tiers: dto.ListableDto[];
    application_modes: dto.ListableDto[];
    principle_activities: dto.ListableDto[];


    constructor(private _formBuilder: FormBuilder, public dialog: MatDialog) { }

    ngOnInit() {

        this.genders = dto.GENDERS;
        this.nationalities = dto.NATIONALITY;
        this.licence_tiers = dto.LICENCE_TIER;
        this.application_modes = dto.APPLICATION_MODE;
        this.principle_activities = dto.PRINCIPLE_ACTIVITIES;

        this.firstFormGroup = this._formBuilder.group({
            firstCtrl: ['', Validators.required]
        });
        this.secondFormGroup = this._formBuilder.group({
            secondCtrl: ['', Validators.required]
        });
        this.thirdFormGroup = this._formBuilder.group({
            thirdCtrl: ['', Validators.required]
        });
        this.fourthFormGroup = this._formBuilder.group({
            fourthCtrl: ['', Validators.required]
        });
        this.fifthFormGroup = this._formBuilder.group({
            fifthCtrl: ['', Validators.required]
        });


    }


    openDialogLicenceTier(): void {
        const dialogRef = this.dialog.open(DialogLicenceTier, {

        });
    }

    openDialogApplicationMode(): void {
        const dialogRef = this.dialog.open(DialogApplicationMode, {

        });
    }

}

@Component({
    selector: 'dialog-licence-tier',
    template: '\
    <div>\
    <h1 mat-dialog-title>Types of Licence Tier:</h1>\
    <mat-divider></mat-divider>\
    <div mat-dialog-content>\
    <h4>General Licence:</h4>\
    The holder of the a general licence can carry on the business of any or more of the following:<br>\
    <ul>\
     <li>Supplying any person a right to travel on any conveyance</li>\
     <li>Supplying any person -\
         <ul>\
             <li>a right to travel on any conveyance to; and </li>\
              <li> a right to accomodation at a hotel or similar boarding premises at, </li>\
         </ul>\
        one more places, whether in Singapore or elsewhere;\
    </li>\
    <li> purchasing, or reserving, for resale to a person a right to travel on any conveyance; </li>\
    <li> supplying any tour(whether or not organised by the licence) to any other person </li>\
     </ul><br>\
     Travel agents conducting any other activity beyond what is described in the scope of a Niche Licence should apply for a General Licence.<br> The General Licence has minimum financial requirements of $100,000. \
     <br><br>\
     <h4>Niche Licence:</h4>\
     The holder of the niche licence can supply only tours of within Singapore without any right of accomodation<br><br>\
     Travel agents who intend to sell, arrange or advertise only tours within Singapore, <br>that provide conveyance to participants but without any right of accommodation (e.g. sit-in coach tours) can apply for a Niche licence.​ <br>The Niche Licence has lower minimum financial requirements of $50,000.\
    </div>\
    </div>'
})
export class DialogLicenceTier {

    constructor(
        public dialogRef: MatDialogRef<DialogLicenceTier>) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

}

@Component({
    selector: 'dialog-application-mode',
    template: '\
    <div>\
    <h1 mat-dialog-title>Types of Application Mode:</h1>\
    <mat-divider></mat-divider>\
    <div mat-dialog-content>\
    <h4>Final Approval:</h4>\
    The holder of the a general licence can carry on the business of any or more of the following:<br>\
     Travel agents conducting any other activity beyond what is described in the scope of a Niche Licence should apply for a General Licence.<br> The General Licence has minimum financial requirements of $100,000. \
     <br><br>\
     <h4>In-Principle Approval:</h4>\
     The holder of the niche licence can supply only tours of within Singapore without any right of accomodation<br><br>\
     Travel agents who intend to sell, arrange or advertise only tours within Singapore, <br>that provide conveyance to participants but without any right of accommodation (e.g. sit-in coach tours) can apply for a Niche licence.​ <br>The Niche Licence has lower minimum financial requirements of $50,000.\
    </div>\
    </div>'
})
export class DialogApplicationMode {

    constructor(
        public dialogRef: MatDialogRef<DialogApplicationMode>) { }

    onNoClick(): void {
        this.dialogRef.close();
    }

}
