import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-ta-portal-apply-preamble',
    templateUrl: './ta-portal-apply-preamble.component.html',
    styleUrls: ['./ta-portal-apply-preamble.component.scss']
})
export class TaPortalApplyPreambleComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
