export interface PeriodicElementDto {
    id: number;
    name: string;
    weight: number;
    symbol: string;
}

export const MOCK_PERIODIC_ELEMENT: PeriodicElementDto = { id: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' };
