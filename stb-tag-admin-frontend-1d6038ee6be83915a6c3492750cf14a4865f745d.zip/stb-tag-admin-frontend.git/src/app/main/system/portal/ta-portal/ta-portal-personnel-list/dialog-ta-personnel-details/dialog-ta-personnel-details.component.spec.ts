import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogTaPersonnelDetailsComponent } from './dialog-ta-personnel-details.component';

describe('DialogTaPersonnelDetailsComponent', () => {
  let component: DialogTaPersonnelDetailsComponent;
  let fixture: ComponentFixture<DialogTaPersonnelDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogTaPersonnelDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogTaPersonnelDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
