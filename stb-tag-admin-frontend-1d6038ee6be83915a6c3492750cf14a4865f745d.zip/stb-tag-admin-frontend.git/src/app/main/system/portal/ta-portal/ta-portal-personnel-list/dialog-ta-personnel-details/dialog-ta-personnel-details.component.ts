import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-ta-personnel-details',
  templateUrl: './dialog-ta-personnel-details.component.html',
  styleUrls: ['./dialog-ta-personnel-details.component.scss']
})
export class DialogTaPersonnelDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
