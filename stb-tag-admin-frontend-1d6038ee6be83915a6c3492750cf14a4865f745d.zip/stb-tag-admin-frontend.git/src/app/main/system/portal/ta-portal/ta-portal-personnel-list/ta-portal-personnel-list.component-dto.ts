export interface PersonnelDetails {
    id: number;
    nric: string;
    name: string;
    appt: string;
    sharesHold: number;
    keyExec: string;
}