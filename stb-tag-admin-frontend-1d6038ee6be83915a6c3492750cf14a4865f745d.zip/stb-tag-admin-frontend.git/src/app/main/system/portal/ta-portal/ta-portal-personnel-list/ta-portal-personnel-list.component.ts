import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { DataService } from 'src/app/data.service';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { animate, state, style, transition, trigger } from '@angular/animations';
import * as dto from './ta-portal-personnel-list.component-dto';
import * as dtoCommon from 'src/app/data.dto';
@Component({
    selector: 'app-ta-portal-personnel-list',
    templateUrl: './ta-portal-personnel-list.component.html',
    styleUrls: ['./ta-portal-personnel-list.component.scss']
})

export class TaPortalPersonnelListComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    personnels: dtoCommon.PersonnelOverviewDto[];
    dataSource = new MatTableDataSource(this.data.getLicenseePersonnelList().data);
    //dataSource = new MatTableDataSource(dto.PersonnelList);
    displayedColumns = ['toggle', 'name', 'nric', 'appt', 'sharesHold', 'keyExec'];

    selection = new SelectionModel<dto.PersonnelDetails>(true, []);

    constructor(private data: DataService, public dialog: MatDialog) { }

    ngOnInit() {
        this.personnels = this.data.getLicenseePersonnelList().data;
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        console.log(this.dataSource);
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.dataSource.data.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.selection.clear() :
            this.dataSource.data.forEach(row => this.selection.select(row));
    }

    applyFilter(filterValue: string) {
        filterValue = filterValue.trim(); // Remove whitespace
        filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
        this.dataSource.filter = filterValue;
    }

    // openTaPersonnelDetailsDialog() {
    //     this.dialog.open(DialogDataExampleDialog, {
    //         data: {
    //             animal: 'panda'
    //         }
    //     });
    // }

}

// export interface DialogData {
//     animal: 'panda' | 'unicorn' | 'lion';
// }
// @Component({
//     selector: 'app-dialog-ta-personnel-details',
//     templateUrl: './dialog-ta-personnel-details/dialog-ta-personnel-details.component.html',
//     styleUrls: ['./dialog-ta-personnel-details/dialog-ta-personnel-details.component.scss']
// })
// export class DialogDataExampleDialog {
//     constructor(@Inject(MAT_DIALOG_DATA) public data: DialogData) { }
// }