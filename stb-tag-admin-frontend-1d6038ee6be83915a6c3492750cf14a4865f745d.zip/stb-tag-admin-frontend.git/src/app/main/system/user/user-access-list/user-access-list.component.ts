import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { UserAccessService } from '../user-access.service';
import { CommonService } from '../../../../common/services'
import * as _ from 'lodash';

@Component({
    selector: 'app-user-access-list',
    templateUrl: './user-access-list.component.html',
    styleUrls: ['./user-access-list.component.scss']
})
export class UserAccessListComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    dialogRef: MatDialogRef<any>;
    rows = [];
    displayedColumns = ['moduleLabel', 'functionLabel', 'role'];
    filter: any = {};
    moduleList: any = [];
    roleList: any = [];
    functionList: any = [];
    constructor(
        private userAccessService: UserAccessService,
        private commonService: CommonService,
        private dialog: MatDialog,
        private snackBar: MatSnackBar) { }

    ngOnInit() {
        this.retrieveRoleFunctions(true);
        this.loadCommonTypes();
    }

    retrieveRoleFunctions(fromCache: boolean) {
        this.userAccessService.getRoleFunction(this.filter).subscribe(data => {
            this.rows = data;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    saveFunctionRole() {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: "Update Confirmation"
            }
        });
        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.userAccessService.saveFunctionRole(this.rows).subscribe(data => {
                    this.commonService.popSnackbar(null, 'success-snackbar');
                    this.rows = data;
                });
            }
        });
    }

    loadCommonTypes() {
        this.commonService.getModule().subscribe(data => this.moduleList = data);
        this.commonService.getRoles().subscribe(data => {
            this.roleList = data;
            this.loadFunction();
        });
    }

    downloadAsCsv($event: any) {
        let mergedDto = {
            'orderProperty': this.sort.active ? this.sort.active : '',
            'order': this.sort.direction,
            ...this.filter
        };
        this.userAccessService.downloadAsCsv(mergedDto).subscribe($event);
    }

    loadFunction() {
        this.commonService.getFunctions(this.filter.module).subscribe(data => this.functionList = data);
    }

    clear() {
        this.filter = {};
        this.loadFunction();
    }
}