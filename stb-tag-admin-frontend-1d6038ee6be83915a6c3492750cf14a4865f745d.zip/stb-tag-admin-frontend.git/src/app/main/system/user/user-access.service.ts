import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';
import * as _ from 'lodash';
import { AuthenticationService } from 'src/app/common/services';

@Injectable({
    providedIn: 'root'
})
export class UserAccessService {

    constructor(private http: HttpClient,
        private authenticationService: AuthenticationService) { }

    getRoleFunction(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + '/users/access/search', { params: searchDto });
    }

    saveFunctionRole(rows: any): Observable<any> {
        let formData: FormData = new FormData();

        formData.append('list', new Blob(
            [JSON.stringify(rows)],
            { type: 'application/json' }
        ));
        return this.http.post(cnst.apiBaseUrl + '/users/access/save/', formData);
    }

    downloadAsCsv(dto: any): Observable<Blob> {
        return this.http.post<any>(cnst.apiBaseUrl + '/users/access/export-list', dto, { responseType: 'blob' as 'json' });
    }
}
