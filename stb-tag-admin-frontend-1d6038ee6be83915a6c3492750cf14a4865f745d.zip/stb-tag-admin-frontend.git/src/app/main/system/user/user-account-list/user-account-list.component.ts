import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { UserAccountService } from '../user-account.service';
import { CommonService } from '../../../../common/services'
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';

@Component({
    selector: 'app-user-account-list',
    templateUrl: './user-account-list.component.html',
    styleUrls: ['./user-account-list.component.scss']
})
export class UserAccountListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    rows = new MatTableDataSource<any>();
    displayedColumns = ['loginId', 'name', 'emailAddress', 'taAssigneeChars', 'role', 'department', 'status', 'edit'];
    listingId = 'user-account-list';
    filter: any = {};
    cnst = cnst;
    roleList: any = [];
    departmentList: any = [];
    statusList: any = [];

    constructor(private userAccountService: UserAccountService, private commonService: CommonService) { }

    ngOnInit() {
        this.loadUserAccounts(true);
        this.loadCommonTypes();
    }

    loadUserAccounts(fromCache: boolean) {
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.listingId);
        this.userAccountService.getUserAccounts(this.filter).subscribe(data => {
            this.commonService.setResultDto(this.paginator, this.rows, data);
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    loadCommonTypes() {
        this.commonService.getRoles().subscribe(data => this.roleList = data);
        this.commonService.getDepartment().subscribe(data => this.departmentList = data);
        this.commonService.getUserStatuses().subscribe(data => this.statusList = data);
    }

    downloadAsCsv($event: any) {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active ? this.sort.active : '',
            'order': this.sort.direction,
            ...this.filter
        };
        this.userAccountService.downloadAsCsv(mergedDto).subscribe($event);
    }
}