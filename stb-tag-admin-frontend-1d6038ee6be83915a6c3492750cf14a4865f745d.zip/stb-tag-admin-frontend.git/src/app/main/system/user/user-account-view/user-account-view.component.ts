import { Component, OnInit, ViewChild, HostListener, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDrawer, MatSort, MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatTableDataSource, ErrorStateMatcher } from '@angular/material';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { SuccessSnackbarComponent } from '../../../../common/modules/success-snackbar/success-snackbar.component';
import { FormUtil } from '../../../../common/helper';
import { UserAccountService } from '../user-account.service';
import { CommonService } from '../../../../common/services';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { Observable } from 'rxjs';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';

@Component({
    selector: 'app-user-account-view',
    templateUrl: './user-account-view.component.html',
    styleUrls: ['./user-account-view.component.scss']
})
export class UserAccountViewComponent implements OnInit {

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private userAccountService: UserAccountService,
        private commonService: CommonService
    ) { }

    cnst = cnst;
    roleList: any = [];
    form = this.formBuilder.group({
        id: [''],
        loginId: [{ value: '', disabled: true }],
        name: [{ value: '', disabled: true }],
        emailAddress: [{ value: '', disabled: true }],
        taAssigneeChars: ['', [Validators.maxLength(cnst.maxLengthStr), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
        status: [{ value: '', disabled: true }],
        department: [{ value: '', disabled: true }],
        userRoles: [this.roleList, Validators.required]
    });
    isNew: boolean = false;
    userId: number;
    name: String;
    user: any = {};
    selection: [];

    // HostListener to guard against browser refresh, close, etc.
    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return this.form.pristine;
    }

    ngOnInit() {
        if (this.route.snapshot.url.toString() === 'user-account-new') {
            this.isNew = true;
        } else {
            this.userId = +this.route.snapshot.paramMap.get('id');
            this.form.get('id').setValue(this.userId);
            this.loadUserDetails();
        }
        this.allowToSave();
        this.loadCommonTypes();
    }

    loadUserDetails() {
        this.userAccountService.getUserDetails(this.userId).subscribe(data => {
            this.user = data;
            this.name = data.name;
            this.selection = data.userRoles;
            this.form.patchValue(data);
            this.isNew = false;
        });
    }

    saveUser() {
        this.userAccountService.saveUser(this.form.value).subscribe(
            userId => {
                this.commonService.popSnackbar(null, 'success-snackbar');
                this.form.markAsPristine(); // to prevent triggering PristineGuard
                this.router.navigate(['/user-account-view/' + userId]);
            });
    }

    loadCommonTypes() {
        this.commonService.getRoles().subscribe(data => this.roleList = data);
    };

    allowToSave() {
        var allowSave = this.userAccountService.allowToSaveUser;
        if (allowSave == true) {
            this.form.get('taAssigneeChars').enable();
            this.form.get('userRoles').enable();
        } else {
            this.form.get('taAssigneeChars').disable();
            this.form.get('userRoles').disable();
        }
    }
}
