import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';
import * as _ from 'lodash';
import { AuthenticationService } from 'src/app/common/services';

@Injectable({
    providedIn: 'root'
})
export class UserAccountService {

    constructor(private http: HttpClient,
        private authenticationService: AuthenticationService) { }

    getUserDetails(userId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + '/users/accounts/view/' + userId);
    }

    getUserAccounts(searchDto: any): Observable<any> {
        searchDto = _(searchDto).omitBy(_.isUndefined).omitBy(_.isNull).value();
        return this.http.get<any>(cnst.apiBaseUrl + '/users/accounts/search', { params: searchDto });
    }

    saveUser(dto: any): Observable<any> {
        return this.http.post(cnst.apiBaseUrl + '/users/accounts/save', dto);
    }

    public get allowToSaveUser(): boolean {
        return this.authenticationService.checkPermission('USR_SAVE');
    }

    downloadAsCsv(dto: any): Observable<Blob> {
        return this.http.post<any>(cnst.apiBaseUrl + '/users/accounts/export-list', dto, { responseType: 'blob' as 'json' });
    }
}
