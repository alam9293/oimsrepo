import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { CommonService } from '../../../../common/services';
import * as cnst from '../../../../common/constants';
import * as _ from 'lodash';
import { TaAaListService } from './ta-aa-list.service';
import { WorkflowHelper, StyleHelper } from 'src/app/common/helper';
import { FileUtil } from '../../../../common/helper'
import { SelectionModel } from '@angular/cdk/collections';

@Component({
    selector: 'app-ta-aa-list',
    templateUrl: './ta-aa-list.component.html',
    styleUrls: ['./ta-aa-list.component.scss']
})
export class TaAaListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    rows = [];
    myApplications: boolean = this.commonService.getLastDashboardView().viewMode == 'my';
    listingId = "ta-aa-list";
    filter: any = {};
    applicationStatuses: any = [];
    cnst = cnst;
    displayedColumns = ['select', 'no', 'name', 'licenceNo', 'uen', 'applicationId', 'submissionDate', 'status', 'isOfflineSubmission', 'assignedOfficer'];

    constructor(public styleHelper: StyleHelper, private fileUtil: FileUtil, private commonService: CommonService, private taAaListService: TaAaListService, public workflowHelper: WorkflowHelper) { }

    ngOnInit() {
        this.loadCommonTypes();
        this.loadTaApplications(true);
    }

    setMyApplicationsAndDefaultAppStatus(fromInit: boolean) {
        if (this.filter.isFromCache) {
            this.myApplications = this.filter.myApplications; // as long as cache is found for this listingId, use the cache and toggle myApplications flag
        } else {
            this.filter.myApplications = this.myApplications; // if not, searchDto should include myApplications flag before firing to server
            if (fromInit) {
                let status = this.workflowHelper.currentUserAppPendingStatus;
                if (status) {
                    this.filter.applicationStatuses = status; // if this is a new init (fromInit + no cache), set default app status
                }
            }
        }
    }

    loadTaApplications(fromInit: boolean): void {
        this.workflowHelper.selection = new SelectionModel<any>(true, []);
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromInit, this.listingId);
        this.setMyApplicationsAndDefaultAppStatus(fromInit);
        this.taAaListService.getTaAaPendingList(this.filter).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    applyFilter(filterValue: string) {
        filterValue = filterValue.trim(); // Remove whitespace
        filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    }

    loadCommonTypes() {
        this.commonService.getTaApplicationPendingStatuses().subscribe(data => this.applicationStatuses = data);
    }

    downloadAsCsv($event: any) {
        let mergedDto = {
            'pageSize': (this.paginator.pageSize ? this.paginator.pageSize : this.paginator.pageSize = cnst.PAGINATION.DEFAULT_PAGE_SIZE),
            'startIndex': this.paginator.pageIndex * this.paginator.pageSize,
            'orderProperty': this.sort.active ? this.sort.active : '',
            'order': this.sort.direction,
            'myApplications': this.myApplications,
            ...this.filter
        };
        this.taAaListService.downloadAsCsv(mergedDto).subscribe($event);
    }

    reAssignSelected() {
        this.workflowHelper.reAssignSelected(cnst.TA).then(data => {
            if (data) {
                this.loadTaApplications(true);
            }
        })
    }
}