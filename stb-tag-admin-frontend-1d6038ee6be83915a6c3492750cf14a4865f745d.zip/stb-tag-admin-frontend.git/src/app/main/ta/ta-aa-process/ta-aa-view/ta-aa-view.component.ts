import { Component, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MatDrawer, MatSnackBar } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import * as cnst from '../../../../common/constants';
import { FileUtil, FormUtil, ValidateDigitMaxLength } from '../../../../common/helper';
import { ApplicationWorkflowComponent } from '../../../../common/modules/application-workflow/application-workflow.component';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { NoteDialogComponent } from '../../../../common/modules/note-dialog/note-dialog.component';
import { SuccessSnackbarComponent } from '../../../../common/modules/success-snackbar/success-snackbar.component';
import { CommonService } from '../../../../common/services';
import { TaAaViewService } from './ta-aa-view.service';
import { formatNumber } from '@angular/common';
import { TaElicencePreviewDialogComponent } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.component';
import { TaElicenceDialogService } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.service';

@Component({
    selector: 'app-ta-aa-view',
    templateUrl: './ta-aa-view.component.html',
    styleUrls: ['./ta-aa-view.component.scss']
})
export class TaAaViewComponent implements OnInit {

    constructor(
        private formUtil: FormUtil,
        private fb: FormBuilder,
        private fileUtil: FileUtil,
        private service: TaAaViewService,
        private route: ActivatedRoute,
        private router: Router,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private commonService: CommonService,
        private taELicenceDialogService: TaElicenceDialogService
    ) { }
    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;
    applicationId: number;
    application: any = { applicationStatus: {}, licenceStatus: {}, annualFilingDto: {}, shortfallDto: {} };
    cnst = cnst;
    edit = false;
    tabs: any[] = [];
    fileForm: FormGroup;
    auditorOpinionList: any;
    selectedFile: File;
    annualFilingDto = this.fb.group({
        fyStartDate: ['',],
        fyEndDate: '',
        dueDate: ['',],
        annualFilingId: ['',],
        hasAaToSubmit: ['',],
        annualFilingFy: ['',],
    })
    form = this.fb.group({});
    promptForShortfall: boolean = false;

    initializeForm() {
        this.form = this.fb.group({
            revenue: ['', [Validators.required, ValidateDigitMaxLength]],
            otherIncome: ['', [Validators.required, ValidateDigitMaxLength]],
            grossProfitLoss: ['', [Validators.required, ValidateDigitMaxLength]],
            netProfitLoss: ['', [Validators.required, ValidateDigitMaxLength]],
            dividendsPaid: ['', [Validators.required, ValidateDigitMaxLength]],
            bankBalance: ['', [Validators.required, ValidateDigitMaxLength]],
            cashCashEquiv: ['', [Validators.required, ValidateDigitMaxLength]],
            tradeReceivables: ['', [Validators.required, ValidateDigitMaxLength]],
            tradeSecurities: ['', [Validators.required, ValidateDigitMaxLength]],
            amtOwnByDir: ['', [Validators.required, ValidateDigitMaxLength]],
            nonCurrentAssets: ['', [Validators.required, ValidateDigitMaxLength]],
            currentAssets: ['', [Validators.required, ValidateDigitMaxLength]],
            totalAssets: ['', [Validators.required, ValidateDigitMaxLength]],
            capital: ['', [Validators.required, ValidateDigitMaxLength]],
            accProfitLoss: ['', [Validators.required, ValidateDigitMaxLength]],
            totalEquity: ['', [Validators.required, ValidateDigitMaxLength]],
            nonCurrentLiabilities: ['', [Validators.required, ValidateDigitMaxLength]],
            currentLiabilities: ['', [Validators.required, ValidateDigitMaxLength]],
            totalLiabilities: ['', [Validators.required, ValidateDigitMaxLength]],
            auditorOpinionCode: ['', [Validators.required]],
            aaSubmissionId: '',
            applicationId: '',
            licenceId: '',
            isEdit: true,
            isDraft: false,
            shortfall: '',
            annualFilingDto: this.annualFilingDto,
            files: this.fb.array([]),
            toDeleteFiles: this.fb.array([
                this.fb.control('')
            ]),
        });
    };

    // convenience getter for easy access to form fields
    get f() {
        return this.form.controls;
    }
    get fileForms() {
        return this.form.get('files') as FormArray
    }
    get annualFilingForm() {
        return this.form.get('annualFilingDto') as FormGroup
    }

    ngOnInit() {
        this.applicationId = +this.route.snapshot.paramMap.get('id');
        this.loadTaApplication();
        this.matDrawer.toggle();
    }


    loadTaApplication(): void {
        this.service.getTaAaApplication(this.applicationId).subscribe(
            data => {
                this.application = data;
                this.setupForm(this.application);
                if (this.promptForShortfall && this.application.shortfallDto) {
                    let dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                        data: {
                            title: cnst.Messages.MANAGE_SHORTFALL_REDIRECT_TITLE,
                            message: cnst.Messages.MANAGE_SHORTFALL_REDIRECT_MSG.replace('%applicationType%', this.application.applicationType.label).replace('%shortfallAmount%', 'S$ ' + formatNumber(this.application.shortfallDto.shortfallAmount, 'en-US', '1.0-0')),
                            internalRemarks: false,
                            externalRemarks: false,
                            action: '',
                            taTg: cnst.TA,
                            appType: this.application.applicationType.key
                        }
                    });

                    dialogRef.afterClosed().subscribe(result => {
                        if (result.decision) {
                            this.router.navigate([cnst.TaFrontEndUrl.TA_MANAGE_SHORTFALL + '/' + this.application.shortfallDto.id]);
                        }
                    });
                }
                this.promptForShortfall = false;
            }
        );
        this.loadWorkflowActions();
    }

    private setupForm(application: any) {
        this.initializeForm();
        this.form.patchValue(application);
        if (application.files) {
            application.files.forEach(item => {
                this.fileForm = this.fb.group({
                    id: [''],
                    publicFileId: [''],
                    originalName: ['', Validators.required],
                    processedName: [''],
                    docType: [''],
                    extension: [''],
                    path: [''],
                    size: [''],
                    hash: [''],
                    documentInstructions: [''],
                    documentTypeLabel: [''],
                    description: [''],
                    readableFileSize: [''],
                    hasTemplate: [],
                });
                this.fileForm.patchValue(item);
                this.fileForms.push(this.fileForm);
            });
        }
    }

    noteDialofRef: MatDialogRef<NoteDialogComponent>;
    openNoteDialog() {
        this.noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });

        this.noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.service.saveNote(result.params, this.applicationId).subscribe(
                    data => {
                        this.loadTaApplication();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog(action) {

        if (this.form.invalid && (action === cnst.workflowAction.approve || action === cnst.workflowAction.forward)) {
            this.commonService.popSnackbar("Please ensure all fields have been filled up before making approval", 'error-snackbar');
        } else {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    title: 'Action: ' + action.label,
                    internalRemarks: true,
                    externalRemarks: (this.application.isFinalApproval || action === cnst.workflowAction.rfa || action === cnst.workflowAction.reject),
                    action: action,
                    taTg: cnst.TA,
                    appType: this.application.applicationType.key,
                    companyName: this.application.name
                }
            });


            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.service.submitAction(result.params, this.application.aaSubmissionId, action.name).subscribe(
                        data => {
                            this.promptForShortfall = this.application.isFinalApproval && action === cnst.workflowAction.approve;
                            this.loadTaApplication();
                            this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TA'), 'success-snackbar');
                        }
                    );
                }
            });
        }

    }

    toggleEditApp() {
        this.edit = !this.edit;
        if (this.edit) {
            this.setupForm(this.application);
            if (!this.auditorOpinionList) {
                this.commonService.getTaAuditorOpinions().subscribe(data => this.auditorOpinionList = data);
            }
        }
    }

    saveEditedApplication() {
        this.formUtil.markFormGroupTouched(this.form);
        if (this.form.invalid) {
            this.commonService.popSnackbar("Please check all mandatory fields in the form.", 'error-snackbar');
        } else {
            this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
                data: {
                    message: 'Changes made will be saved to the submission',
                    title: 'Are you sure you want to save the changes?',
                    internalRemarks: true,
                }
            });

            this.dialogRef.afterClosed().subscribe(result => {
                if (result.decision) {
                    this.service.saveEditedApp({ internalRemarks: result.params.internalRemarks, ...this.form.value }).subscribe(
                        data => {
                            this.loadTaApplication();
                            this.edit = false;
                            this.commonService.popSnackbar('Changes successfully saved', 'success-snackbar');
                        },
                        error => {
                            this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                        });

                }
            });
        }
    }


    onPicked(input: HTMLInputElement, docType: string, index) {
        this.selectedFile = input.files[0];
        if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
            this.fileUtil.upload(docType, this.selectedFile).subscribe(data => {
                (this.form.get('files') as FormArray).setControl(index, this.setFile2FormGroup(data));
            });
        }
    }

    setFile2FormGroup(file: any) {
        let group = new FormGroup({});
        group = this.fb.group({
            id: [''],
            // publicFileId: [''],
            originalName: ['', Validators.required],
            processedName: [''],
            docType: [''],
            extension: [''],
            path: [''],
            size: [''],
            hash: [''],
            documentInstructions: [''],
            documentTypeLabel: [''],
            description: [''],
            readableFileSize: [''],
        });

        if (file.originalName) {
            group.patchValue(file);
        } else {
            group = this.fb.group({
                id: [''],
                originalName: ['', Validators.required],
                processedName: [],
                // publicFileId: [''],
                path: '',
                docType: file.docType,
                readableFileSize: '',
                size: '',
                documentTypeLabel: file.documentTypeLabel,
                documentInstructions: file.documentInstructions,
            });
        }
        return group;
    }



    toDeleteFile(file, index) {
        if (file.controls.originalName.value) {
            (this.form.get('toDeleteFiles') as FormArray).push(this.fb.control(file.controls.id.value));
            //this.application.toDeleteFiles.push(file.controls.id.value);
        }
        file.controls.originalName.value = null;
        (this.form.get('files') as FormArray).setControl(index, this.setFormGroupFile(file));


    }

    setFormGroupFile(file: FormGroup) {
        let group = new FormGroup({});
        if (file.controls.originalName.value) {
            group = this.fb.group({
                id: [file.controls.id.value],
                originalName: [file.controls.originalName.value, Validators.required],
                processedName: [file.controls.processedName.value],
                // publicFileId: [file.controls.publicFileId.value],
                path: [file.controls.path.value],
                docType: file.controls.docType.value,
                readableFileSize: file.controls.readableFileSize.value,
                size: file.controls.size.value,
                documentTypeLabel: file.controls.documentTypeLabel.value,
                documentInstructions: file.controls.documentInstructions.value,
            });
        } else {
            group = this.fb.group({
                id: [''],
                originalName: ['', Validators.required],
                processedName: '',
                // publicFileId: [''],
                path: '',
                docType: file.controls.docType.value,
                readableFileSize: '',
                size: '',
                documentTypeLabel: file.controls.documentTypeLabel.value,
                documentInstructions: file.controls.documentInstructions.value,

            });
        }
        return group;
    }

    loadWorkflowActions() {
        if (this.workflowComp) {
            this.workflowComp.loadWorkflowActions();
        }
    }

    openELicencePreview() {
        this.taELicenceDialogService.getTaELicenceDetails(this.application.licenceId).subscribe(res => {
            let elicenceDialogRef = this.dialog.open(TaElicencePreviewDialogComponent, {
                data: {
                    licence: res.licence,
                    address: res.displayAddr,
                    displayName: res.displayName,
                    qrCode: res.qrCode,
                    branchaddrlist: res.branchAddrList
                }
            });
        });

    }
}
