import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MatDrawer, MatSnackBar, MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';

import * as cnst from '../../../../common/constants';
import {
    ApplicationWorkflowComponent,
} from '../../../../common/modules/application-workflow/application-workflow.component';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { NoteDialogComponent } from '../../../../common/modules/note-dialog/note-dialog.component';
import { SuccessSnackbarComponent } from '../../../../common/modules/success-snackbar/success-snackbar.component';
import { TaElicencePreviewDialogComponent } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.component';
import { CommonService } from '../../../../common/services';
import { TaAbprViewService } from './ta-abpr-view.service';
import { TaElicenceDialogService } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.service';

@Component({
    selector: 'app-ta-abpr-view',
    templateUrl: './ta-abpr-view.component.html',
    styleUrls: ['./ta-abpr-view.component.scss']
})
export class TaAbprViewComponent implements OnInit {
    applicationId: number;
    application: any = { applicationStatus: {}, licenceStatus: {}, otherDocuments: [], reason: {}, taLicenceAnnualFilingDto: {} };
    applicationStatuses: any = [];
    cnst = cnst;
    tabs: any[] = [];

    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;

    //private bo = [];
    boDataSource = new MatTableDataSource<any>();
    boDisplayedColumns = ['no', 'services', 'inbound', 'inboundOwn', 'outbound', 'outboundOwn'];
    //private ph = [];
    phDataSource = new MatTableDataSource<any>();
    phDisplayedColumns = ['type', 'inboundAmt', 'inboundPer', 'outboundAmt', 'outboundPer'];

    private msInbound = [];
    msInboundDataSource = new MatTableDataSource(this.msInbound);
    msInboundDisplayedColumns = ['no', 'country', 'percentage'];
    private msOutbound = [];
    msOutboundDataSource = new MatTableDataSource(this.msOutbound);
    msOutboundDisplayedColumns = ['no', 'country', 'percentage'];

    private aof = [];
    aofDataSource = new MatTableDataSource(this.aof);
    aofDisplayedColumns = ['no', 'areaOfFocus', 'hasInboundOp', 'hasOutboundOp', 'remarks'];
    private fa = [];
    faDataSource = new MatTableDataSource<any>();
    faDisplayedColumns = ['no', 'question', 'inbound', 'outbound'];
    otherDataSource = new MatTableDataSource<any>();
    otherDisplayedColumns = ['no', 'type', 'value'];

    totalBoDataSource = new MatTableDataSource<any>();
    totalBoDisplayedColumns = ['type', 'amt', 'percent'];

    constructor(private route: ActivatedRoute, public dialog: MatDialog, public snackBar: MatSnackBar, private abprService: TaAbprViewService, private commonService: CommonService, private taELicenceDialogService: TaElicenceDialogService) { }

    ngOnInit() {
        this.applicationId = +this.route.snapshot.paramMap.get('id');
        this.matDrawer.toggle();
        this.msInboundDataSource.sort = this.sort;
        this.msOutboundDataSource.sort = this.sort;
        this.boDataSource.sort = this.sort;
        this.aofDataSource.sort = this.sort;
        this.loadApplication();
    }

    loadApplication() {
        this.abprService.getApplication(this.applicationId).subscribe(
            data => {
                console.log(data);
                this.application = data;
                this.msInbound = [];
                this.msOutbound = [];
                //this.bo = [];
                this.aof = [];
                this.fa = [];
                let totalBo: any = [{ type: 'Inbound', amt: data.inboundOp, percent: data.inboundOpPercent },
                { type: 'Outbound', amt: data.outboundOp, percent: data.outboundOpPercent }];
                this.totalBoDataSource = totalBo;

                let ph: any = [{ type: 'Group', inboundAmt: data.inboundGrpPax ? data.inboundGrpPax : 0, inboundPer: data.inboundGrpPaxPercent ? data.inboundGrpPaxPercent : 0, outboundAmt: data.outboundGrpPax ? data.outboundGrpPax : 0, outboundPer: data.outboundGrpPaxPercent ? data.outboundGrpPaxPercent : 0 },
                { type: 'FITs', inboundAmt: data.inboundFitPax ? data.inboundFitPax : 0, inboundPer: data.inboundFitPaxPercent ? data.inboundFitPaxPercent : 0, outboundAmt: data.outboundFitPax ? data.outboundFitPax : 0, outboundPer: data.outboundFitPaxPercent ? data.outboundFitPaxPercent : 0 }];
                this.phDataSource = ph;

                data.inboundRows.forEach(element => {
                    this.msInbound.push(element);
                });
                this.msInboundDataSource = new MatTableDataSource(this.msInbound);
                data.outboundRows.forEach(element => {
                    this.msOutbound.push(element);
                });
                this.msOutboundDataSource = new MatTableDataSource(this.msOutbound);
                this.boDataSource = data.businessRows;

                data.focusRows.forEach(element => {
                    this.aof.push(element);
                });
                this.aofDataSource = new MatTableDataSource(this.aof);
                if (this.aof && this.aof.length > 0) {
                    let firstAof = this.aof[0];
                    if (firstAof.bothInOutNull) {
                        this.aofDisplayedColumns = ['no', 'areaOfFocus', 'hasOp', 'remarks'];
                    } else {
                        this.aofDisplayedColumns = ['no', 'areaOfFocus', 'hasInboundOp', 'hasOutboundOp', 'remarks'];
                    }
                }
                data.functionRows.forEach(element => {
                    this.fa.push(element);
                });
                this.faDataSource = new MatTableDataSource(this.fa);

                let others: any = [{ type: 'Number of Staff Employed', value: data.noOfEmployee },
                { type: 'Operating cost incurred', value: data.operatingCost, isNumeral: true },
                { type: 'Depreciation of Fixed Assets', value: data.depreciation, isNumeral: true },
                { type: 'Remuneration', value: data.remuneration, isNumeral: true },
                { type: 'Indirect Tax', value: data.indirectTax, isNumeral: true },
                { type: 'Any overseas branches?', value: data.hasOverseasBranch === true ? 'Yes' : 'No' }];
                this.otherDataSource = others;

            }
        );
        this.loadWorkflowActions();
    }
    loadCommonTypes() {
        this.commonService.getTaApplicationStatuses().subscribe(data => this.applicationStatuses = _.filter(data, function (status) {
            return status.key != cnst.ApplicationStatuses.TA_APP_APPROVED && status.key != cnst.ApplicationStatuses.TA_APP_REJECTED;
        }));
    }
    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog(action) {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Action: ' + action.label,
                internalRemarks: true,
                externalRemarks: (this.application.isFinalApproval || action === cnst.workflowAction.rfa || action === cnst.workflowAction.reject),
                action: action,
                taTg: cnst.TA,
                appType: this.application.applicationType.key,
                companyName: this.application.name
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.abprService.submitAction(result.params, this.applicationId, action.name).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TA'), 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar('Error', null);
                    });

            }
        });
    }
    noteDialofRef: MatDialogRef<NoteDialogComponent>;
    openNoteDialog() {
        this.noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });

        this.noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.abprService.saveNote(result.params, this.applicationId).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    getMsTotalInboundAmount() {
        let total = 0;
        _.forEach(this.msInboundDataSource.data, function (value) {
            total += value.percentage;
        }.bind(this));
        return total;
    }

    getMsTotalOutboundAmount() {
        let total = 0;
        _.forEach(this.msOutboundDataSource.data, function (value) {
            total += value.percentage;
        }.bind(this));
        return total;
    }

    loadWorkflowActions() {
        if (this.workflowComp) {
            this.workflowComp.loadWorkflowActions();
        }
    }

    openELicencePreview() {
        this.taELicenceDialogService.getTaELicenceDetails(this.application.licenceId).subscribe(res => {
            let elicenceDialogRef = this.dialog.open(TaElicencePreviewDialogComponent, {
                data: {
                    licence: res.licence,
                    address: res.displayAddr,
                    displayName: res.displayName,
                    qrCode: res.qrCode,
                    branchaddrlist: res.branchAddrList
                }
            });
        });

    }
}
