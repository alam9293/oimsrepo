import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef, MatDrawer, MatSnackBar } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/common/services';
import * as cnst from '../../../../common/constants';
import { FileUtil } from '../../../../common/helper';
import { ApplicationWorkflowComponent } from '../../../../common/modules/application-workflow/application-workflow.component';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { NoteDialogComponent } from '../../../../common/modules/note-dialog/note-dialog.component';
import { TaAdhocDocService } from '../ta-adhoc-doc-service';
import { TaElicencePreviewDialogComponent } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.component';
import { TaElicenceDialogService } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.service';

@Component({
    selector: 'app-ta-adhoc-doc-view',
    templateUrl: './ta-adhoc-doc-view.component.html',
    styleUrls: ['./ta-adhoc-doc-view.component.scss']
})
export class TaAdhocDocViewComponent implements OnInit {

    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;

    applicationId: number;
    application: any = { applicationType: {}, filingDto: {}, applicationStatus: {}, licenceStatus: {}, otherDocuments: [], shortfall: 0, managementAccounts: {}, shortfallDto: { status: {} } };
    cnst = cnst;
    form: FormGroup;
    edit = false;

    constructor(
        private fb: FormBuilder,
        private route: ActivatedRoute,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private taAdhocDocService: TaAdhocDocService,
        private commonService: CommonService,
        private fileUtil: FileUtil,
        private taELicenceDialogService: TaElicenceDialogService
    ) { }

    ngOnInit() {
        this.initializeForm();
        this.applicationId = +this.route.snapshot.paramMap.get('id');
        this.loadApplication();
        this.matDrawer.toggle();
    }

    loadApplication() {
        this.taAdhocDocService.getApplication(this.applicationId).subscribe(data => {
            this.application = data;
        });

        this.loadWorkflowActions();
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog(action) {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Action: ' + action.label,
                internalRemarks: true,
                externalRemarks: (this.application.isFinalApproval || action === cnst.workflowAction.rfa || action === cnst.workflowAction.reject),
                action: action,
                taTg: cnst.TA,
                appType: this.application.applicationType.key,
                companyName: this.application.name
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.taAdhocDocService.submitAction(result.params, this.applicationId, action.name).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TA'), 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });

            }
        });
    }
    noteDialofRef: MatDialogRef<NoteDialogComponent>;
    openNoteDialog() {
        this.noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });

        this.noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.taAdhocDocService.saveNote(result.params, this.applicationId).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    loadWorkflowActions() {
        if (this.workflowComp) {
            this.workflowComp.loadWorkflowActions();
        }
    }

    initializeForm() {
        this.form = this.fb.group({
            applicationId: [''],
            filingDto: this.fb.group({
                annualFilingId: [''],
                dueDate: [''],
                remarks: ['']
            }),
            documents: this.fb.array([]),
        });
    };

    toggleEditApp() {
        this.edit = !this.edit;
        if (this.edit) {
            this.initializeForm();
            this.form.patchValue(this.application);
        }
    }

    openELicencePreview() {
        this.taELicenceDialogService.getTaELicenceDetails(this.application.licenceId).subscribe(res => {
            let elicenceDialogRef = this.dialog.open(TaElicencePreviewDialogComponent, {
                data: {
                    licence: res.licence,
                    address: res.displayAddr,
                    displayName: res.displayName,
                    qrCode: res.qrCode,
                    branchaddrlist: res.branchAddrList
                }
            });
        });

    }

}
