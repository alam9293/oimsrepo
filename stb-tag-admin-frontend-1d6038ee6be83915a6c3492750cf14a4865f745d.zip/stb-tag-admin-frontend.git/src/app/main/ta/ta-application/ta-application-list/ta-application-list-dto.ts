export interface PeriodicElementDto {
    id: number;
    name: string;
    uen: string;
    licenceNo: string;
    applicationId: string;
    applicationType: string;
    submissionDate: string;
    status: string;
    assignedOfficer: string;
}

export const MOCK_PERIODIC_ELEMENTS: PeriodicElementDto[] = [
    { id: 1, name: 'Condimentum Donec Corp.', uen: '53082647W', licenceNo: '1000890', applicationId: '20181001-37', applicationType: 'Main', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
    { id: 1, name: 'Ac Nulla Limited', uen: '52899290B', licenceNo: '1000891', applicationId: '20181001-38', applicationType: 'Branch', submissionDate: '20-Oct-2018', status: 'Returned for Action', assignedOfficer: 'John Tan' },
    { id: 1, name: 'Et Risus Company', uen: '53174060M', licenceNo: '1000892', applicationId: '20181001-39', applicationType: 'Cessation', submissionDate: '20-Oct-2018', status: 'Pending Approval', assignedOfficer: 'John Tan' },
    { id: 1, name: 'Sapien Inc.', uen: '53326497M', licenceNo: '1000893', applicationId: '20181001-40', applicationType: 'Replacement', submissionDate: '20-Oct-2018', status: 'Approved', assignedOfficer: 'John Tan' },
    { id: 1, name: 'A Magna Institute', uen: '53175575D', licenceNo: '1000894', applicationId: '20181001-41', applicationType: 'Switch', submissionDate: '20-Oct-2018', status: 'Approved', assignedOfficer: 'John Tan' },
    { id: 1, name: 'Quam Vel Incorporated', uen: '53334458A', licenceNo: '1000895', applicationId: '20181001-42', applicationType: 'Update of Company', submissionDate: '20-Oct-2018', status: 'Approved', assignedOfficer: 'John Tan' },
    { id: 1, name: 'ed Pharetra Felis Inc.', uen: '53312249W', licenceNo: '1000896', applicationId: '20181001-43', applicationType: 'Update of KE', submissionDate: '20-Oct-2018', status: 'Rejected', assignedOfficer: 'John Tan' },
];
