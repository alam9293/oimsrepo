import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDrawer, MatPaginator, MatSort } from '@angular/material';
import { WorkflowHelper, StyleHelper } from 'src/app/common/helper';

import * as cnst from '../../../../common/constants';
import { CommonService } from '../../../../common/services';
import { TaApplicationListService } from './ta-application-list.service';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
    selector: 'app-ta-application-list',
    templateUrl: './ta-application-list.component.html',
    styleUrls: ['./ta-application-list.component.scss']
})
export class TaApplicationListComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(MatSort) sort: MatSort;
    myApplications: boolean = false; // default to show all applications
    listingId = "ta-application-list";
    filter: any = {};
    applicationStatuses: any = [];
    applicationTypes: any = [];
    rows = [];
    cnst = cnst;

    /**
    * Return the label of the code
    * @param list - The code list
    *  @param key - The code 
    */
    getLabelFromKey(list, key) {
        var retVal = "";
        if (list) {
            list.forEach(element => {
                if (element.key == key) {
                    retVal = element.label;
                }
            });
        }
        return retVal;
    }

    displayedColumns = ['select', 'no', 'applicationId', 'type', 'name', 'licenceNo', 'uen', 'submissionDate', 'status', 'assignedOfficer'];
    constructor(private applicationService: TaApplicationListService, private commonService: CommonService, public workflowHelper: WorkflowHelper, public styleHelper: StyleHelper) { }

    ngOnInit() {
        this.matDrawer.toggle();
        this.loadTaApplications(true);
        this.loadCommonTypes();
    }

    loadTaApplications(fromCache: boolean) {
        this.workflowHelper.selection = new SelectionModel<any>(true, []);
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromCache, this.listingId);
        if (this.filter.isFromCache) {
            this.myApplications = this.filter.myApplications;
        } else {
            this.filter.myApplications = this.myApplications;
        }
        this.applicationService.getList(this.filter).subscribe(data => {
            data.records.forEach(element => {
                element.url = cnst.TaFrontEndUrl[element.type] + "/" + element.applicationId;
                if (element.type === cnst.ApplicationTypes.TA_APP_RENEWAL) {
                    element.url += "/" + element.licenceId;
                }
            });
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    loadCommonTypes() {
        this.commonService.getTaApplicationStatuses().subscribe(data => this.applicationStatuses = data);
        this.commonService.getTaApplicationTypes().subscribe(data => this.applicationTypes = data);
    }

    reAssignSelected() {
        this.workflowHelper.reAssignSelected(cnst.TA).then(data => {
            if (data) {
                this.loadTaApplications(true);
            }
        })
    }
}
