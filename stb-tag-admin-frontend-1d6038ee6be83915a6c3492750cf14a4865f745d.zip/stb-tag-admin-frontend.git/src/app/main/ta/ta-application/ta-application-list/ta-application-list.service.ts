import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaApplicationListService {

    constructor(private http: HttpClient) { }

    getList(searchDto: any): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TaApiUrl.TA_APPLICATION + '/view', { params: searchDto });
    }

}
