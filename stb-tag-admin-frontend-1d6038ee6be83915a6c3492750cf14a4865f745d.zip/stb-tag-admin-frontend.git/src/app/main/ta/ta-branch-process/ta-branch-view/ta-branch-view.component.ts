import { Component, OnInit, ViewChild } from '@angular/core';
import {
    MatDialog,
    MatDialogRef,
    MatDrawer,
    MatPaginator,
    MatSnackBar,
    MatSort,
    MatTableDataSource,
} from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { TaElicenceDialogService } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.service';
import { DataService } from 'src/app/data.service';

import * as cnst from '../../../../common/constants';
import { FileUtil } from '../../../../common/helper';
import {
    ApplicationWorkflowComponent,
} from '../../../../common/modules/application-workflow/application-workflow.component';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { NoteDialogComponent } from '../../../../common/modules/note-dialog/note-dialog.component';
import { SuccessSnackbarComponent } from '../../../../common/modules/success-snackbar/success-snackbar.component';
import { CommonService } from '../../../../common/services';
import { TaBranchViewService } from './ta-branch-view.service';
import { TaElicencePreviewDialogComponent } from '../../../../common/modules/ta-elicence-preview-dialog/ta-elicence-preview-dialog.component';

@Component({
    selector: 'app-ta-branch-view',
    templateUrl: './ta-branch-view.component.html',
    styleUrls: ['./ta-branch-view.component.scss']
})

export class TaBranchViewComponent implements OnInit {

    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;

    rows = new MatTableDataSource<any>();
    displayedColumnsTransaction = ['no', 'address', 'status', 'type', 'supportingDocuments', 'fee'];
    dataSource2 = new MatTableDataSource(this.data.getPendingApprovalBranchLicenceList().data);
    constructor(private snackBar: MatSnackBar, private data: DataService, public dialog: MatDialog, private route: ActivatedRoute, private fileUtil: FileUtil, private branchService: TaBranchViewService, private commonService: CommonService, private taELicenceDialogService: TaElicenceDialogService) { }
    feeCount = [];
    amountPayable: number = 0;
    applicationId: number;
    filter: any = {};
    application: any = { applicationStatus: {}, licenceStatus: {} };
    cnst = cnst;
    tabs: any[] = [];
    applicationStatuses: any = [];

    ngOnInit() {
        this.matDrawer.toggle();
        this.dataSource2.paginator = this.paginator;
        this.dataSource2.sort = this.sort;
        this.applicationId = +this.route.snapshot.paramMap.get('id');

        this.loadApplication();
        // this.loadTaApplications();
        this.loadCommonTypes();
    }

    loadApplication() {
        this.branchService.getApplication(this.applicationId).subscribe(data => {
            console.log(data);
            this.application = data;
            this.rows = data.taBranchApplicationDtoList;
            this.feeCount = data.taBranchApplicationDtoList;

            this.calculateAmountPayable();
        });
        this.loadWorkflowActions();
    }

    calculateAmountPayable(): void {
        this.amountPayable = 0;
        this.feeCount.forEach(element => {
            if (element.type == 'New') {
                this.amountPayable = this.amountPayable + 40;
            }
        });

    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog(action) {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Action: ' + action.label,
                internalRemarks: true,
                externalRemarks: (this.application.isFinalApproval || action === cnst.workflowAction.rfa || action === cnst.workflowAction.reject),
                action: action,
                taTg: cnst.TA,
                appType: this.application.applicationType.key,
                companyName: this.application.name
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.branchService.submitAction(result.params, this.applicationId, action.name).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TA'), 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });

            }
        });
    }
    loadCommonTypes() {
        this.commonService.getTaApplicationStatuses().subscribe(data => this.applicationStatuses = data);
    }
    noteDialofRef: MatDialogRef<NoteDialogComponent>;
    openNoteDialog() {
        this.noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });

        this.noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.branchService.saveNote(result.params, this.applicationId).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    loadWorkflowActions() {
        if (this.workflowComp) {
            this.workflowComp.loadWorkflowActions();
        }
    }

    openELicencePreview() {
        this.taELicenceDialogService.getTaELicenceDetails(this.application.licenceId).subscribe(res => {
            let elicenceDialogRef = this.dialog.open(TaElicencePreviewDialogComponent, {
                data: {
                    licence: res.licence,
                    address: res.displayAddr,
                    displayName: res.displayName,
                    qrCode: res.qrCode,
                    branchaddrlist: res.branchAddrList
                }
            });
        });

    }
}
