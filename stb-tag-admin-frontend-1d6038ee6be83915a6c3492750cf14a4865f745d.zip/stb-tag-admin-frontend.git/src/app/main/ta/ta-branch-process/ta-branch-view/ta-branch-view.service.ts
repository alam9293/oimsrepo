import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaBranchViewService {

    constructor(private http: HttpClient) { }

    getApplication(applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TaApiUrl.TA_BRANCH_APPLICATION + '/view/details/' + applicationId);
    }
    getApplications(searchDto: any, applicationId: number): Observable<any> {
        return this.http.get<any>(cnst.apiBaseUrl + cnst.TaApiUrl.TA_BRANCH_APPLICATION + '/view/list/' + applicationId, { params: searchDto });
    }
    submitAction(params: any, id: any, action: any) {
        return this.http.post(cnst.apiBaseUrl + cnst.TaApiUrl.TA_BRANCH_APPLICATION + '/' + action + "/" + id, params);
    }

    saveNote(params: any, id: any): Observable<any> {

        const files: Array<File> = params.files;

        let formData: FormData = new FormData();
        formData.append('applicationId', id);
        formData.append('internalRemarks', params.internalRemarks);

        if (files) {
            for (let i = 0; i < files.length; i++) {
                formData.append("files", files[i]['file']);
                formData.append("fileDescription", files[i]['fileDescription']);
            }
        }

        return this.http.post(cnst.apiBaseUrl + cnst.TaApiUrl.TA_BRANCH_APPLICATION + '/notes/save', formData);
    }
}
