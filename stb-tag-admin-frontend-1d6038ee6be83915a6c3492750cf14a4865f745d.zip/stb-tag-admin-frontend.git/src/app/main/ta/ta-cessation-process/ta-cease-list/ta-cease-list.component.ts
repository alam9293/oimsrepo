import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort } from '@angular/material';

import * as cnst from '../../../../common/constants';
import { WorkflowHelper, StyleHelper } from '../../../../common/helper';
import { CommonService } from '../../../../common/services';
import { TaCessationListService } from './ta-cease-list.service';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
    selector: 'app-ta-cease-list',
    templateUrl: './ta-cease-list.component.html',
    styleUrls: ['./ta-cease-list.component.scss'],
})

export class TaCeaseListComponent implements OnInit {

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    rows = [];
    displayedColumns = ['select', 'no', 'name', 'licenceNo', 'uen', 'applicationNo', 'submissionDate', 'status', 'isOfflineSubmission', 'assignedOfficer'];
    listingId = "ta-cease-list";
    filter: any = {};
    applicationStatuses: any = [];
    cnst = cnst;
    myApplications: boolean = this.commonService.getLastDashboardView().viewMode == 'my';

    constructor(
        private styleHelper: StyleHelper,
        private cessationService: TaCessationListService,
        private commonService: CommonService,
        public workflowHelper: WorkflowHelper) { }

    ngOnInit() {
        this.loadTaApplications(true);
        this.loadCommonTypes();
    }

    setMyApplicationsAndDefaultAppStatus(fromInit: boolean) {
        if (this.filter.isFromCache) {
            this.myApplications = this.filter.myApplications; // as long as cache is found for this listingId, use the cache and toggle myApplications flag
        } else {
            this.filter.myApplications = this.myApplications; // if not, searchDto should include myApplications flag before firing to server
            if (fromInit) {
                let status = this.workflowHelper.currentUserAppPendingStatus;
                if (status) {
                    this.filter.applicationStatuses = status; // if this is a new init (fromInit + no cache), set default app status
                }
            }
        }
    }

    loadTaApplications(fromInit: boolean) {
        this.workflowHelper.selection = new SelectionModel<any>(true, []);
        this.filter = this.commonService.getSearchDto(this.paginator, this.sort, this.filter, fromInit, this.listingId);
        this.setMyApplicationsAndDefaultAppStatus(fromInit);
        this.cessationService.getList(this.filter).subscribe(data => {
            this.rows = data.records;
            this.paginator.length = data.total;
            this.commonService.cacheSearchDto(this.filter);
        });
    }

    loadCommonTypes() {
        this.commonService.getTaApplicationPendingStatuses().subscribe(data => this.applicationStatuses = data);
    }
    reAssignSelected() {
        this.workflowHelper.reAssignSelected(cnst.TA).then(data => {
            if (data) {
                this.loadTaApplications(true);
            }
        })
    }
}
