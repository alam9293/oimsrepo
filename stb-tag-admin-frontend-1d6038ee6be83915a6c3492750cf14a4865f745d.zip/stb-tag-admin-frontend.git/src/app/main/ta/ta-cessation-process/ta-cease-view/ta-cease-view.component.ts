import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MatDrawer, MatSnackBar } from '@angular/material';
import { ActivatedRoute } from '@angular/router';

import * as cnst from '../../../../common/constants';
import { FileUtil } from '../../../../common/helper';
import {
    ApplicationWorkflowComponent,
} from '../../../../common/modules/application-workflow/application-workflow.component';
import { ConfirmationDialogComponent } from '../../../../common/modules/confirmation-dialog/confirmation-dialog.component';
import { NoteDialogComponent } from '../../../../common/modules/note-dialog/note-dialog.component';
import { CommonService } from '../../../../common/services';
import { TaCessationViewService } from './ta-cease-view.service';

@Component({
    selector: 'app-ta-cease-view',
    templateUrl: './ta-cease-view.component.html',
    styleUrls: ['./ta-cease-view.component.scss']
})
export class TaCeaseViewComponent implements OnInit {

    @ViewChild(MatDrawer) matDrawer: MatDrawer;
    @ViewChild(ApplicationWorkflowComponent) workflowComp: ApplicationWorkflowComponent;
    applicationId: number;
    application: any = { applicationStatus: {}, licenceStatus: {}, otherDocuments: [], reason: {}, licenceReturnedStatus: {} };
    cnst = cnst;
    tabs: any[] = [];
    licenceReturned: boolean = false;
    loadView: boolean = false;

    constructor(
        private route: ActivatedRoute,
        public dialog: MatDialog,
        public snackBar: MatSnackBar,
        private cessationService: TaCessationViewService,
        private commonService: CommonService,
        private fileUtil: FileUtil
    ) { }

    ngOnInit() {
        this.applicationId = +this.route.snapshot.paramMap.get('id');
        this.loadApplication();
        this.matDrawer.toggle();

    }

    loadApplication() {
        this.cessationService.getApplication(this.applicationId).subscribe(data => {
            this.application = data;
            this.loadView = true;
        });
        this.loadWorkflowActions();
    }

    dialogRef: MatDialogRef<ConfirmationDialogComponent>;
    openConfirmationDialog(action) {
        this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            data: {
                title: 'Action: ' + action.label,
                internalRemarks: true,
                externalRemarks: (this.application.isFinalApproval || action === cnst.workflowAction.rfa || action === cnst.workflowAction.reject),
                action: action,
                taTg: cnst.TA,
                appType: cnst.ApplicationTypes.TA_APP_CESSATION,
                companyName: this.application.name
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.cessationService.submitAction(result.params, this.applicationId, action.name, this.licenceReturned).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(cnst.Messages.ACTION_DEFAULT_SUBMISSION + action.message.replace('[TATG]', 'TA'), 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });

            }
        });
    }
    noteDialofRef: MatDialogRef<NoteDialogComponent>;
    openNoteDialog() {
        this.noteDialofRef = this.dialog.open(NoteDialogComponent, {
            data: {
                remarks: true,
            }
        });

        this.noteDialofRef.afterClosed().subscribe(result => {
            if (result.decision) {
                this.cessationService.saveNote(result.params, this.applicationId).subscribe(
                    data => {
                        this.loadApplication();
                        this.commonService.popSnackbar(null, 'success-snackbar');
                    },
                    error => {
                        this.commonService.popSnackbar(cnst.Messages.ERR_MSG_GENERIC, null);
                    });
            }
        });
    }

    loadWorkflowActions() {
        if (this.workflowComp) {
            this.workflowComp.loadWorkflowActions();
        }
    }
}