# use generateCsr.sh to generate csr file
	csr is generated and passed to PKI team 

# PKI team provided p7b files, used the following command to convert p7b to pem file
	openssl pkcs7 -inform DER -outform PEM -in batik-trust.stb.gov.sg.p7b -print_certs > batik-trust.stb.gov.sg_cert_bundle.cer
	openssl pkcs7 -inform DER -outform PEM -in batik-trust-dev.stb.gov.sg.p7b -print_certs > batik-trust-dev.stb.gov.sg_cert_bundle.cer
	openssl pkcs7 -inform DER -outform PEM -in batik-trust-stg.stb.gov.sg.p7b -print_certs > batik-trust-stg.stb.gov.sg_cert_bundle.cer
	openssl pkcs7 -inform DER -outform PEM -in batik-trust-uat.stb.gov.sg.p7b -print_certs > batik-trust-uat.stb.gov.sg_cert_bundle.cer

	note: after above command, we have to manually extract the bundle file, and split it into cert & chain-cert files respectively

# following are installed in the server (example: stg env) 
	SSLCertificateFile		batik-trust-stg.stb.gov.sg_cert.cer
	SSLCertificateKeyFile 	batik-trust-stg.stb.gov.sg.nopass.key
	SSLCertificateChainFile	batik-trust-stg.stb.gov.sg_chain_cert.cer

# restarting apachectl 
	currently when restart, it will prompt for cert passphrase.
	this has to manually key in until workaround is implemented. 


# verify cert at server
	openssl s_client -showcerts -connect batik-trust-stg.stb.gov.sg:443 > stg_openssl 2>&1
	openssl s_client -showcerts -connect batik-trust-uat.stb.gov.sg:443 > stg_openssl 2>&1
	openssl s_client -showcerts -connect batik-trust.stb.gov.sg:443 > stg_openssl 2>&1

# local testing chain cert 
	openssl verify -CAfile batik-trust.stb.gov.sg_chain_cert.cer batik-trust.stb.gov.sg_chain_cert.cer
	openssl verify -CAfile batik-trust.stb.gov.sg_chain_cert.cer batik-trust.stb.gov.sg_cert.cer
