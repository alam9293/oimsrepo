// QlikSense only way of association is by similar col name, it will attempt to associate and create unwanted synthetic keys (i.e. mapping tables).
// As a result, ALL our col names have to be unique, and we cannot use QUALIFY * because it looks ugly in the Analysis Tab.
UNQUALIFY *;

LIB CONNECT TO [stb_tag_admin_dev (tag-qlik_administrator)];
// LIB CONNECT TO [stb_tag_admin_uat (h8cc0509v_stbadmin)];
// LIB CONNECT TO [stb_tag_admin (h8cc0511v_stbadmin)];

// In Qlik universe, the BA user should join up the tables he wants. We will only pre-join master data and common tables such as addresses and files.
// To do multi-table join, the BA user can understand the relationships by browsing through the tables first before joining (e.g. applications -> licences -> touristGuides)

[(lic.) licences]:
SELECT licenceNo AS 'lic.licenceNo',
    lic.ceasedDate AS 'lic.ceasedDate',
    lic.expiryDate AS 'lic.expiryDate',
    IF(lic.isPendingCessation,'Yes','No') AS 'lic.isPendingCessation',
    lic.issueDate AS 'lic.issueDate',
    lic.startDate AS 'lic.startDate',
    lic.taTgType AS 'lic.taTgType',
    s.label AS 'lic.status',
    t.label AS 'lic.tier',
    lic.id AS 'licenceId'
FROM licences lic
LEFT JOIN statuses s ON s.code = statusCode
LEFT JOIN types t ON t.code = tierCode
WHERE lic.taTgType = 'TG' ;

[(apl.) ce_case_appeals]:
SELECT appealDate AS 'apl.appealDate',
    appealRespondByDate AS 'apl.appealRespondByDate',
    billExpiryDate AS 'apl.billExpiryDate',
    apl.billRefNo AS 'apl.billRefNo',
    letterIssuanceDate AS 'apl.letterIssuanceDate',
    penaltyAmount AS 'apl.penaltyAmount',
    penaltyStatusEndDate AS 'apl.penaltyStatusEndDate',
    penaltyStatusStartDate AS 'apl.penaltyStatusStartDate',
    respondedDate AS 'apl.respondedDate',
    IF(toEmailLetter,'Yes','No') AS 'apl.toEmailLetter',
    f.filename AS 'apl.letter',
    o.label AS 'apl.outcome',
    s.label AS 'apl.paymentStatus',
    r.label AS 'apl.result',
    was.label AS 'apl.status',
	payType.label AS 'apl.paymentType',
    pr.createdDate AS 'apl.financialImposeDate',
    pr.remarks AS 'apl.paymentRemarks',								
    ceCaseInfringementId,
	apl.id as ceCaseAppealId	
FROM ce_case_appeals apl
LEFT JOIN ce_case_infringements ifm ON ifm.id = apl.ceCaseInfringementId
LEFT JOIN ce_cases cs ON cs.id = ifm.ceCaseId
LEFT JOIN workflows w ON w.id = workflowId
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode
LEFT JOIN types r ON r.code = resultCode
LEFT JOIN statuses s ON s.code = paymentStatusCode
LEFT JOIN types o ON o.code = apl.outcomeCode
LEFT JOIN files f ON f.id = letterId
LEFT JOIN
    payment_requests pr ON pr.billRefNo = apl.billRefNo
        LEFT JOIN
    payment_txns pt ON pt.id = pr.lastTxnId
        LEFT JOIN
    payment_status_spans payStatusSpan ON payStatusSpan.paymentrequestid = pr.id
        AND payStatusSpan.statuscode = 'PAYREQ_P'
        LEFT JOIN
    statuses p ON p.code = pr.statusCode
        LEFT JOIN
    types payType ON payType.code = pt.paymentTypeCode
WHERE w.isDraft = false or w.isDraft is null
AND cs.taTgType = 'TG';

[(dc.) ce_case_decisions]:
SELECT billExpiryDate AS 'dc.billExpiryDate',
    dc.billRefNo AS 'dc.billRefNo',
    IF(hasInProgressAppeal,'Yes','No') AS 'dc.hasInProgressAppeal',
    IF(hasShowCause,'Yes','No') AS 'dc.hasShowCause',
    letterIssuanceDate AS 'dc.letterIssuanceDate',
    penaltyAmount AS 'dc.penaltyAmount',
    penaltyStatusEndDate AS 'dc.penaltyStatusEndDate',
    penaltyStatusStartDate AS 'dc.penaltyStatusStartDate',
    showCauseDate AS 'dc.showCauseDate',
    taggedIpCaseNo AS 'dc.taggedIpCaseNo',
    IF(toEmailLetter,'Yes','No') AS 'dc.toEmailLetter',
    f.filename AS 'dc.letter',
    o.label AS 'dc.outcome',
    p.label AS 'dc.paymentStatus',
    was.label AS 'dc.status',
    pr.createdDate AS 'dc.financialImposeDate',
    pr.remarks AS 'dc.paymentRemarks',
    pt.createdDate AS 'dc.paymentDate' ,
    payType.label AS 'dc.paymentType' ,
    dc.id AS 'ceCaseDecisionId',
    ceCaseInfringementId
FROM ce_case_decisions dc
LEFT JOIN ce_case_infringements ifm ON ifm.id = dc.ceCaseInfringementId
LEFT JOIN ce_cases cs ON cs.id = ifm.ceCaseId
LEFT JOIN workflows w ON w.id = workflowId
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode
LEFT JOIN statuses s ON s.code = paymentStatusCode
LEFT JOIN types o ON o.code = dc.outcomeCode
LEFT JOIN files f ON f.id = letterId
LEFT JOIN payment_requests pr ON pr.billRefNo = dc.billRefNo
LEFT JOIN payment_txns pt on pt.id=pr.lastTxnId and pr.statusCode in ('PAYREQ_P', 'PAYREQ_S','PAYREQ_PR','PAYREQ_R')
LEFT JOIN statuses p ON p.code = pr.statusCode
LEFT JOIN types payType ON payType.code = pt.paymentTypeCode
WHERE w.isDraft = false or w.isDraft is null
AND cs.taTgType = 'TG';

[(rec.) ce_case_recommendations]:
SELECT letterIssuanceDate AS 'rec.letterIssuanceDate',
    penaltyAmount AS 'rec.penaltyAmount',
    penaltyStatusEndDate AS 'rec.penaltyStatusEndDate',
    penaltyStatusStartDate AS 'rec.penaltyStatusStartDate',
    taggedIpCaseNo AS 'rec.taggedIpCaseNo',
    IF(toEmailLetter,'Yes','No') AS 'rec.toEmailLetter',
    f.filename AS 'rec.letter',
    o.label AS 'rec.outcome',
    was.label AS 'rec.status',
    rec.id AS 'ceCaseRecommendationId',
    ceCaseInfringementId
FROM ce_case_recommendations rec
LEFT JOIN ce_case_infringements ifm ON ifm.id = rec.ceCaseInfringementId
LEFT JOIN ce_cases cs ON cs.id = ifm.ceCaseId
LEFT JOIN workflows w ON w.id = workflowId
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode
LEFT JOIN types o ON o.code = rec.outcomeCode
LEFT JOIN files f ON f.id = letterId
WHERE w.isDraft = false or w.isDraft is null
AND cs.taTgType = 'TG';

[(rsc.) ce_case_rescinds]:
SELECT letterIssuanceDate AS 'rsc.letterIssuanceDate',
    IF(toEmailLetter,'Yes','No') AS 'rsc.toEmailLetter',
    f.filename AS 'rsc.letter',
    was.label AS 'rsc.status',
    ceCaseInfringementId
FROM ce_case_rescinds rsc
LEFT JOIN ce_case_infringements ifm ON ifm.id = rsc.ceCaseInfringementId
LEFT JOIN ce_cases cs ON cs.id = ifm.ceCaseId
LEFT JOIN workflows w ON w.id = workflowId
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode
LEFT JOIN files f ON f.id = letterId
WHERE w.isDraft = false or w.isDraft is null
AND cs.taTgType = 'TG';

// merged with ce_case_infringers to prevent circular references to ce_cases
[(ifm.) ce_case_infringements]:
SELECT 
    CASE
		WHEN cs.isIp AND IFNULL(ifm.ceOriginatingCaseId, ifm.ceCaseId) = ifm.ceCaseId THEN null
        WHEN cs.isIp AND IFNULL(ifm.ceOriginatingCaseId, ifm.ceCaseId) <> ifm.ceCaseId THEN ifm.ceOriginatingCaseId
		ELSE ifm.ceCaseId
	END AS 'ceCaseId',
    IF(cs.isIp, cs.id, null) AS 'ceIpCaseId',
    cs.isIp AS 'ifm.isIp',
	IF(cs.isIp&&ifm.ceOriginatingCaseId, true, false) AS 'ifm.isOpenIp',
	infringedDate AS 'ifm.offenceDate',
    ipCourtCaseNo AS 'ifm.ipCourtCaseNo',
    ipOffenceCount AS 'ifm.ipOffenceCount',
    ipSentencingDetails AS 'ifm.ipSentencingDetails',
    outcomeDate AS 'ifm.outcomeDate',
    MONTH(outcomeDate) AS 'ifm.outcomeDateMth',
    o.label AS 'ifm.outcome',
    IF(o.label != 'Advisory' AND o.label != 'Composition' AND o.label != 'Prosecution' AND o.label != 'Warning', 'Yes', 'No') AS 'ifm.isAdminOutcome',
    category AS 'ifm.defendantIpCategory',
    name AS 'ifm.defendantName',
    uenUin AS 'ifm.defendantUenUin',
    age.label AS 'ifm.defendantAgeGroup',
    glp.label AS 'ifm.defendantGuidingLanguageProvided',
    idt.label AS 'ifm.defendantIdType',
    n.label AS 'ifm.defendantNationality',
    -- lastDecisionId AS 'ceCaseDecisionId',
    -- lastRecommendationId AS 'ceCaseRecommendationId',
    -- GROUP_CONCAT(DISTINCT CONCAT(rwp.chapterCode,'-',rwp.section) SEPARATOR ', ') AS 'ifm.readWiths',
	IF(apl.id,'Yes','No') AS 'ifm.hasAppeal',
    ifm.id AS 'ceCaseInfringementId',
    ifmPrn.description AS 'ifm.description',
    ifmPrn.effectiveDate AS 'ifm.effectiveDate',
    ifmPrn.ineffectiveDate AS 'ifm.ineffectiveDate',
    IF(ifmPrn.isOffence,'Yes','No') AS 'ifm.isOffence',
    IF(ifmPrn.isReadWithOnly,'Yes','No') AS 'ifm.isReadWithOnly',
    ifmPrn.label AS 'ifm.label',
    ifmPrn.section AS 'ifm.section',
    ifmPrn.chapterCode AS 'ifm.chapterCode',
    ifmPrn.label AS 'ifm.chapter',
    ifg.licenceId
FROM ce_case_infringements ifm
LEFT JOIN ce_cases cs ON cs.id = ifm.ceCaseId
LEFT JOIN ce_case_infringers ifg ON ifg.id = ceCaseInfringerId
LEFT JOIN types o ON o.code = outcomeCode
LEFT JOIN types age ON age.code = ageGroupCode
LEFT JOIN types glp ON glp.code = guidingLanguageProvidedCode
LEFT JOIN types idt ON idt.code = idTypeCode
LEFT JOIN types n ON n.code = nationalityCode
-- LEFT JOIN ce_case_infringement$read_withs rw ON rw.ceCaseInfringementId = ifm.id
-- LEFT JOIN ce_provisions rwp ON rwp.id = rw.readWithsId
LEFT JOIN ce_case_appeals apl ON ifm.id = apl.ceCaseInfringementId
LEFT JOIN ce_provisions ifmPrn on ifmPrn.id = ifm.ceProvisionId
WHERE ifm.isDeleted = false
AND cs.taTgType = 'TG'
GROUP BY ifm.id;

[compo. ce_case_compositions]:
SELECT compo.amount AS 'compo.amount',
	compo.billRefNo AS 'compo.billRefNo',
    compo.description AS 'compo.description',
    compo.dueDate AS 'compo.dueDate',
    email AS 'compo.email',
    compo.remarks AS 'compo.remarks',
    compo.ceCaseInfringerId AS 'compo.ceCaseInfringerId',
    f.filename AS 'compo.letter',
    p.label AS 'compo.paymentStatus',
    was.label AS 'compo.status',
    name AS 'compo.defendantName',
    uenUin AS 'compo.defendantUenUin',
    pt.createdDate AS 'compo.paymentDate' ,
    payType.label AS 'compo.paymentType' ,
    -- ifgm.ceCaseId, 
    pr.id as paymentrequestid,
    ifgm.id as ceCaseInfringementId
FROM ce_case_compositions compo
LEFT JOIN workflows w ON w.id = workflowId
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode
LEFT JOIN files f ON f.id = letterId
LEFT JOIN ce_case_infringers ifg ON ifg.id = ceCaseInfringerId
LEFT JOIN ce_case_infringements ifgm ON ifg.id = ifgm.ceCaseInfringerId and ifgm.ceOriginatingCaseId =  ifg.ceCaseId
LEFT JOIN ce_cases cs ON cs.id = ifgm.ceCaseId
LEFT JOIN payment_requests pr ON pr.billRefNo = compo.billRefNo
LEFT JOIN payment_txns pt on pt.id=pr.lastTxnId and pr.statusCode in ('PAYREQ_P', 'PAYREQ_S','PAYREQ_PR','PAYREQ_R')
LEFT JOIN statuses p ON p.code = pr.statusCode
LEFT JOIN types payType on payType.code = pt.paymentTypeCode
WHERE w.isDraft = false or w.isDraft is null
AND cs.taTgType = 'TG';

[(compl.) ce_case_complainants]:
SELECT contactNo AS 'compl.contactNo',
    emailAddress AS 'compl.emailAddress',
    name AS 'compl.name',
    uenUin AS 'compl.uenUin',
    a.block AS 'compl.addrBlk',
    a.street AS 'compl.addrSt',
    a.building AS 'compl.addrBldg',
    a.floor AS 'compl.addrLvl',
    a.unit AS 'compl.addrUnit',
    a.postal AS 'compl.addrPostal',
    a.foreignLine1 AS 'compl.addrForeign1',
    a.foreignLine2 AS 'compl.addrForeign2',
    a.foreignLine3 AS 'compl.addrForeign3',
    idt.label AS 'compl.idType',
    t.label AS 'compl.type',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'compl.attachments',
    ceCaseId
FROM ce_case_complainants compl
LEFT JOIN ce_cases cs ON cs.id = compl.ceCaseId
LEFT JOIN types t ON t.code = typeCode
LEFT JOIN types idt ON idt.code = idTypeCode
LEFT JOIN addresses a ON a.id = addressId
LEFT JOIN ce_case_complainant$files cf ON cf.ceCaseComplainantId = compl.id
LEFT JOIN files f ON (f.id = cf.filesId AND f.isDeleted = false)
WHERE compl.isDeleted = false
AND cs.taTgType = 'TG'
GROUP BY compl.id;

[(cs.) ce_cases]:
SELECT cs.aggravatingFactors AS 'cs.aggravatingFactors',
    cs.assessment AS 'cs.assessment',
    cs.caseNo AS 'cs.caseNo',
    cs.crmRefNo AS 'cs.crmRefNo',
    IF(cs.isIP,'Yes','No') AS 'cs.isIP',
    cs.mitigatingFactors AS 'cs.mitigatingFactors',
    cs.taTgType AS 'cs.taTgType',
    cs.ceTaCheckId AS 'cs.ceTaCheckId',
    u.name AS 'cs.oic',
    s.label AS 'cs.status',
    tc.caseNo AS 'cs.taggedCaseNo',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'cs.attachments',
    GROUP_CONCAT(DISTINCT ripc.caseNo SEPARATOR ', ') AS 'cs.relevantIpCases',
    cs.createdDate AS 'cs.openDate',
    cs.ceTgFieldReportId,
    cs.ceTaCheckId,
    cs.id AS 'ceCaseId'
FROM ce_cases cs
LEFT JOIN users u ON u.id = cs.oicId
LEFT JOIN statuses s ON s.code = cs.statusCode
LEFT JOIN ce_cases tc ON tc.id = cs.taggedCaseId
LEFT JOIN ce_case$files csf ON csf.ceCaseId = cs.id
LEFT JOIN files f ON (f.id = csf.filesId AND f.isDeleted = false)
LEFT JOIN (
	SELECT ceCaseId, iipc.caseNo FROM ce_case$ce_cases iip
	LEFT JOIN ce_cases iipc ON iipc.id = iip.ceCaseInternalIpsId
	UNION
	SELECT ceCaseId, eipc.caseNo FROM ce_case_external_ips eipc
    WHERE isDeleted = false) ripc
    ON ripc.ceCaseId = cs.id
WHERE cs.taTgType = 'TG'
AND cs.isIp = false
GROUP BY cs.id;

[(ip) ce_ips]:
SELECT ip.aggravatingFactors AS 'ip.aggravatingFactors',
    ip.assessment AS 'ip.assessment',
    ip.caseNo AS 'ip.caseNo',
    ip.crmRefNo AS 'ip.crmRefNo',
    ip.mitigatingFactors AS 'ip.mitigatingFactors',
    ip.taTgType AS 'ip.taTgType',
    u.name AS 'ip.oic',
    s.label AS 'ip.status',
    tc.caseNo AS 'ip.taggedCaseNo',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'ip.attachments',
    GROUP_CONCAT(DISTINCT ripc.caseNo SEPARATOR ', ') AS 'ip.relevantIpCases',
    ip.createdDate AS 'ip.openDate',
    ip.id AS 'ceIpCaseId'
FROM ce_cases ip
LEFT JOIN users u ON u.id = ip.oicId
LEFT JOIN statuses s ON s.code = ip.statusCode
LEFT JOIN ce_cases tc ON tc.id = ip.taggedCaseId
LEFT JOIN ce_case$files csf ON csf.ceCaseId = ip.id
LEFT JOIN files f ON (f.id = csf.filesId AND f.isDeleted = false)
LEFT JOIN (
	SELECT ceCaseId, iipc.caseNo FROM ce_case$ce_cases iip
	LEFT JOIN ce_cases iipc ON iipc.id = iip.ceCaseInternalIpsId
	UNION
	SELECT ceCaseId, eipc.caseNo FROM ce_case_external_ips eipc
    WHERE isDeleted = false) ripc
    ON ripc.ceCaseId = ip.id
WHERE ip.isIp = true and ip.taTgType = 'TG'
GROUP BY ip.id;

[(pvn.) ce_provisions]:
SELECT pvn.description AS 'pvn.description',
    pvn.effectiveDate AS 'pvn.effectiveDate',
    pvn.ineffectiveDate AS 'pvn.ineffectiveDate',
    IF(pvn.isOffence,'Yes','No') AS 'pvn.isOffence',
    IF(pvn.isReadWithOnly,'Yes','No') AS 'pvn.isReadWithOnly',
    pvn.label AS 'pvn.label',
    pvn.section AS 'pvn.section',
    pvn.chapterCode AS 'pvn.chapterCode',
    pvn.label AS 'pvn.chapter',
    pvn.id AS 'ceProvisionId'
FROM ce_provisions pvn
LEFT JOIN types t ON t.code = chapterCode;

[(tgRpt.) ce_tg_field_report_tgs]:
SELECT tgRpt.approvedLanguages AS 'tgRpt.approvedLanguages',
	tgRpt.contactNo AS 'tgRpt.contactNo',
	IF(tgRpt.hasValidLicence,'Yes','No') AS 'tgRpt.hasValidLicence',
	IF(tgRpt.isLanguageApproved,'Yes','No') AS 'tgRpt.isLanguageApproved',
	IF(tgRpt.isLicenceDisplayed,'Yes','No') AS 'tgRpt.isLicenceDisplayed',
	IF(tgRpt.isPictureTallied,'Yes','No') AS 'tgRpt.isPictureTallied',
	tgRpt.licenceExpiryDate AS 'tgRpt.licenceExpiryDate',
	tgRpt.name AS 'tgRpt.name',
	tgRpt.noOfAntecedentRecords AS 'tgRpt.noOfAntecedentRecords',
	tgRpt.noOfTourists AS 'tgRpt.noOfTourists',
	tgRpt.passportNo AS 'tgRpt.passportNo',
	tgRpt.role AS 'tgRpt.role',
	tgRpt.taName AS 'tgRpt.taName',
	tgRpt.uin AS 'tgRpt.uin',
	tgRpt.vehicleNo AS 'tgRpt.vehicleNo',
	age.label AS 'tgRpt.ageGroup',
	glp.label AS 'tgRpt.guidingLanguageProvided',
	s.label AS 'tgRpt.licenceStatus',
	n.label AS 'tgRpt.nationality',
	tn.label AS 'tgRpt.touristNationality',
	fr.details AS 'tgRpt.reportDetails',
	fr.infringedDate AS 'tgRpt.reportDate',
	MONTH(fr.infringedDate) AS 'tgRpt.reportDateMth',
	YEAR(fr.infringedDate) AS 'tgRpt.reportDateYr',
	fr.remarks AS 'tgRpt.reportRemarks',
	fr.reportNo AS 'tgRpt.reportNo',
	eo.name AS 'tgRpt.eo',
	ao.name AS 'tgRpt.oeo',
	GROUP_CONCAT(DISTINCT CONCAT(p.chapterCode,'-',p.section,(CASE prw.chapterCode WHEN NULL THEN '' ELSE CONCAT(' r.w. ',prw.chapterCode,'-',prw.section) END),' (',o.label,')') SEPARATOR ', ') AS 'tgRpt.infringements',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'tgRpt.attachments',
    loc.label AS 'tgRpt.reportLocation',
	sloc.ceTgCheckScheduleItemId,
	-- tgRpt.licenceId, -- derived from this > ceCase > ceCaseInfringement > licence
	tgRpt.id AS 'ceTgFieldReportId'
FROM ce_tg_field_report_tgs tgRpt
LEFT JOIN ce_tg_field_reports fr ON fr.id = tgRpt.ceTgFieldReportId
LEFT JOIN ce_tg_check_schedule_item_locations sloc ON sloc.id = fr.ceTgCheckScheduleItemLocationId
LEFT JOIN types loc ON loc.code = sloc.locationCode
LEFT JOIN users eo ON eo.id = eoUserId
LEFT JOIN users ao ON ao.id = aoUserId
LEFT JOIN licences l ON l.id = tgRpt.licenceId
LEFT JOIN statuses s ON s.code = licenceStatusCode
LEFT JOIN types n ON n.code = nationalityCode
LEFT JOIN types tn ON tn.code = touristNationalityCode
LEFT JOIN types glp ON glp.code = guidingLanguageProvidedCode
LEFT JOIN types age ON age.code = ageGroupCode
LEFT JOIN ce_tg_field_report_tg_infringements ifm ON ifm.ceTgFieldReportTgId = tgRpt.id
LEFT JOIN ce_provisions p ON p.id = ifm.ceProvisionId
LEFT JOIN ce_provisions prw ON prw.id = ifm.readWithId
LEFT JOIN types o ON o.code = ifm.recommendedOutcomeCode
LEFT JOIN ce_tg_field_report$files rf ON rf.ceTgFieldReportId = tgRpt.id
LEFT JOIN files f ON (f.id = rf.filesId AND f.isDeleted = false)
WHERE fr.isDeleted = false
AND fr.isDraft = false
GROUP BY tgRpt.id;

[(tgSch.) ce_tg_check_schedule_items]:
SELECT remarks AS 'tgSch.remarks',
    scheduleDate AS 'tgSch.scheduleDate',
    schi.id AS 'tgSch.ceTgCheckScheduleItemId',
    sch.fromDate AS 'tgSch.scheduleStartDate',
    sch.toDate AS 'tgSch.scheduleEndDate',
    sch.year AS 'tgSch.scheduleYear',
    was.label AS 'tgSch.scheduleStatus',
    GROUP_CONCAT(DISTINCT CONCAT(loc.label,' (',m.label,')') SEPARATOR ', ') AS 'tgSch.locations',
    GROUP_CONCAT(DISTINCT eou.name SEPARATOR ', ') AS 'tgSch.eo',
    GROUP_CONCAT(DISTINCT oeou.label SEPARATOR ', ') AS 'tgSch.oeo',
    schi.id AS 'ceTgCheckScheduleItemId'
FROM ce_tg_check_schedule_items schi
LEFT JOIN ce_tg_check_schedules sch ON sch.id = schi.ceTgCheckScheduleId
LEFT JOIN ce_tg_check_schedule_item_locations sloc ON sloc.ceTgCheckScheduleItemid = schi.id
LEFT JOIN types loc ON loc.code = sloc.locationCode
LEFT JOIN types m ON m.code = sloc.meridiemCode
LEFT JOIN ce_tg_check_schedule_item$users eo ON eo.ceTgCheckScheduleItemid = schi.id
LEFT JOIN users eou ON eou.id = eo.eoUsersId
LEFT JOIN ce_tg_check_schedule_item$oeo_users oeo ON oeo.ceTgCheckScheduleItemid = schi.id
LEFT JOIN types oeou ON oeou.code = oeo.oeoUsersCode
LEFT JOIN workflows w ON w.id = sch.workflowId
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode
WHERE schi.isDeleted = false
AND schi.isApproved = true
GROUP BY schi.id;

[(tgChk.) ce_tg_checks]:
SELECT 
   tgChk.noOfGrpWithTg AS 'tgChk.noOfGrpWithTg',
    tgChk.noOfGrpWithoutTg AS 'tgChk.noOfGrpWithoutTg',
    tgChk.noOfGrpWithExpert AS 'tgChk.noOfGrpWithExpert',
    tgChk.noOfStudGrpWithTg AS 'tgChk.noOfStudGrpWithTg',
    tgChk.noOfStudGrpWithTchr AS 'tgChk.noOfStudGrpWithTchr',
    tgChk.noOfStudGrpWithStud AS 'tgChk.noOfStudGrpWithStud',
    tgChk.noOfMiceGrpWithTg AS 'tgChk.noOfMiceGrpWithTg',
    tgChk.noOfMiceGrpWithExpat AS 'tgChk.noOfMiceGrpWithExpat',
    tgChk.noOfCruiseWithTg AS 'tgChk.noOfCruiseWithTg',
    tgChk.noOfCruiseWithoutTg AS 'tgChk.noOfCruiseWithoutTg',
	noOfCombiWithTg AS 'tgChk.noOfCombiWithTg',
    noOfCombiWithoutTg AS 'tgChk.noOfCombiWithoutTg',
    loc.label AS 'tgChk.location',
    m.label AS 'tgChk.meridiem',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'tgChk.attachments',
    sloc.ceTgCheckScheduleItemId
FROM ce_tg_checks tgChk
LEFT JOIN ce_tg_check$files cf ON cf.ceTgCheckId = tgChk.id
LEFT JOIN files f ON (f.id = cf.filesId AND f.isDeleted = false)
LEFT JOIN ce_tg_check_schedule_item_locations sloc ON sloc.id = ceTgCheckScheduleItemLocationId
LEFT JOIN types loc ON loc.code = sloc.locationCode
LEFT JOIN types m ON m.code = sloc.meridiemCode
WHERE tgChk.isDeleted = false
AND tgChk.isDraft = false
GROUP BY tgChk.id;

[(tgChecks.) ce_tg_checks]:
SELECT 
    tgItem.scheduleDate AS 'tgChecks.scheduleDate',
    locType.label AS 'tgChecks.location',
    tgChecks.noOfGrpWithTg AS 'tgChecks.noOfGrpWithTg',
    tgChecks.noOfGrpWithoutTg AS 'tgChecks.noOfGrpWithoutTg',
    tgChecks.noOfGrpWithExpert AS 'tgChecks.noOfGrpWithExpert',
    tgChecks.noOfStudGrpWithTg AS 'tgChecks.noOfStudGrpWithTg',
    tgChecks.noOfStudGrpWithTchr AS 'tgChecks.noOfStudGrpWithTchr',
    tgChecks.noOfStudGrpWithStud AS 'tgChecks.noOfStudGrpWithStud',
    tgChecks.noOfMiceGrpWithTg AS 'tgChecks.noOfMiceGrpWithTg',
    tgChecks.noOfMiceGrpWithExpat AS 'tgChecks.noOfMiceGrpWithExpat',
    tgChecks.noOfCruiseWithTg AS 'tgChecks.noOfCruiseWithTg',
    tgChecks.noOfCruiseWithoutTg AS 'tgChecks.noOfCruiseWithoutTg'
FROM
    ce_tg_checks tgChecks
        LEFT JOIN
    ce_tg_check_schedule_item_locations tgLoc ON tgChecks.ceTgCheckScheduleItemLocationId = tgLoc.id
        LEFT JOIN
    ce_tg_check_schedule_items tgItem ON tgLoc.ceTgCheckScheduleItemId = tgItem.id
        LEFT JOIN
    types locType ON locType.code = tgLoc.locationCode;
    
[(ps.) payment_status_spans]:
SELECT 
    payReq.billRefNo AS 'ps.billRefNo', 
    paidStatus.createdDate AS 'ps.date',
	payReq.id as paymentrequestid
FROM
    payment_status_spans paidStatus
        LEFT JOIN
    payment_requests payReq ON payReq.id = paidStatus.paymentRequestId
WHERE
    paidStatus.statusCode = 'PAYREQ_P';
	
[(rw.) ce_case_infringement$read_withs]:
SELECT 
	rw.ceCaseInfringementId as ceCaseInfringementId, 
	GROUP_CONCAT(DISTINCT CONCAT(rwp.chapterCode,'-',rwp.section) SEPARATOR ', ') AS 'rw.readWiths'
FROM ce_case_infringement$read_withs rw
LEFT JOIN ce_provisions rwp ON rwp.id = rw.readWithsId 
group by rw.ceCaseInfringementId;

[(final.) ce_case_decisions]:
SELECT 
	IF(apl.id, apl.billExpiryDate ,  dc.billExpiryDate)as 'final.billExpiryDate',
	IF(apl.id, apl.billRefNo , dc.billRefNo)as 'final.billRefNo',
    IF(hasInProgressAppeal,'Yes','No') AS 'final.hasInProgressAppeal',
	IF(hasShowCause,'Yes','No') AS 'final.hasShowCause',
    IF(apl.id, apl.letterIssuanceDate , dc.letterIssuanceDate)as 'final.letterIssuanceDate',
    IF(apl.id, apl.penaltyAmount , dc.penaltyAmount)as 'final.penaltyAmount',
    IF(apl.id, apl.penaltyStatusStartDate , dc.penaltyStatusStartDate)as 'final.penaltyStatusStartDate',
	IF(apl.id, apl.penaltyStatusEndDate , dc.penaltyStatusEndDate)as 'final.penaltyStatusEndDate',
	showCauseDate AS 'final.showCauseDate',
    taggedIpCaseNo AS 'final.taggedIpCaseNo',
    IF(apl.id, 'No', IF(dc.toEmailLetter,'Yes','No'))as 'final.toEmailLetter',
    IF(apl.id, aplf.filename ,  f.filename)as 'final.letter',
	IF(apl.id, aplo.label ,   o.label)as 'final.outcome',
    IF(apl.id, aplp.label ,   p.label)as 'final.paymentStatus',
	IF(apl.id, aplwas.label ,   was.label)as 'final.status',
	IF(apl.id, aplpt.createdDate ,  pt.createdDate)as 'final.paymentDate',
	IF(apl.id, aplpayType.label ,  payType.label)as 'final.paymentType',
	IF(apl.id, aplpr.createdDate ,   pr.createdDate)as 'final.financialImposeDate',
    IF(apl.id, aplpr.remarks  ,   pr.remarks )as 'final.paymentRemarks',
	-- dc.id AS 'ceCaseDecisionId',
    dc.ceCaseInfringementId
FROM ce_case_decisions dc
LEFT JOIN ce_case_infringements ifm on ifm.id = dc.ceCaseInfringementId
LEFT JOIN ce_cases cs on cs.id = ifm.ceCaseId 
LEFT JOIN ce_case_appeals apl on apl.ceCaseDecisionId = dc.id
LEFT JOIN workflows w ON w.id = dc.workflowId 
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode
LEFT JOIN statuses s ON s.code = dc.paymentStatusCode
LEFT JOIN types o ON o.code = dc.outcomeCode
LEFT JOIN files f ON f.id = dc.letterId
LEFT JOIN payment_requests pr ON pr.billRefNo = dc.billRefNo
LEFT JOIN payment_txns pt on pt.id=pr.lastTxnId and pr.statusCode in ('PAYREQ_P', 'PAYREQ_S','PAYREQ_PR','PAYREQ_R')
LEFT JOIN statuses p ON p.code = pr.statusCode
LEFT JOIN types payType ON payType.code = pt.paymentTypeCode
LEFT JOIN workflows aplw ON aplw.id = apl.workflowId 
LEFT JOIN workflow_actions aplwa ON aplwa.id = aplw.lastActionId
LEFT JOIN statuses aplwas ON aplwas.code = aplwa.statusCode
LEFT JOIN statuses apls ON apls.code = apl.paymentStatusCode
LEFT JOIN types aplo ON aplo.code = apl.outcomeCode
LEFT JOIN files aplf ON aplf.id = apl.letterId
LEFT JOIN payment_requests aplpr ON aplpr.billRefNo = apl.billRefNo
LEFT JOIN payment_txns aplpt on aplpt.id=aplpr.lastTxnId and aplpr.statusCode in ('PAYREQ_P', 'PAYREQ_S','PAYREQ_PR','PAYREQ_R')
LEFT JOIN statuses aplp ON aplp.code = aplpr.statusCode
LEFT JOIN types aplpayType ON aplpayType.code = aplpt.paymentTypeCode
where cs.taTgType= 'TG'
and (w.isDraft = false or w.isDraft is null)
and (aplw.isDraft = false or aplw.isDraft is null);

// hide internal PK/FK to only show useful business data
TAG FIELD [ceCaseRecommendationId] WITH '$hidden';
TAG FIELD [ceCaseDecisionId] WITH '$hidden';
TAG FIELD [ceCaseInfringementId] WITH '$hidden';
TAG FIELD [ceCaseId] WITH '$hidden';
TAG FIELD [ceTgFieldReportId] WITH '$hidden';
TAG FIELD [ceTgCheckScheduleItemId] WITH '$hidden';
TAG FIELD [ceIpCaseId] WITH '$hidden';

// tag date fields as date
TAG FIELD [lic.ceasedDate],[lic.expiryDate],[lic.issueDate],[lic.startDate] with '$date';
TAG FIELD [apl.appealDate],[apl.appealRespondByDate],[apl.billExpiryDate],[apl.letterIssuanceDate],[apl.penaltyStatusEndDate],[apl.penaltyStatusStartDate],[apl.respondedDate] with '$date';
TAG FIELD [dc.billExpiryDate],[dc.letterIssuanceDate],[dc.penaltyStatusEndDate],[dc.penaltyStatusStartDate],[dc.showCauseDate],[dc.financialImposeDate] with '$date';
TAG FIELD [rec.letterIssuanceDate],[rec.penaltyStatusEndDate],[rec.penaltyStatusStartDate],[rsc.letterIssuanceDate] with '$date';
TAG FIELD [ifm.offenceDate],[ifm.outcomeDate],[compo.dueDate],[cs.openDate],[pvn.effectiveDate],[pvn.ineffectiveDate] with '$date';
TAG FIELD [tgRpt.licenceExpiryDate],[tgRpt.reportDate],[tgSch.scheduleDate],[tgSch.scheduleStartDate],[tgSch.scheduleEndDate] with '$date';
TAG FIELD [taChk.checkedDate],[taChk.lastAcknowledgedDate],[taSch.lastAaFilingFyEndDate],[taSch.licenceCeasedDate],[taSch.licenceExpiryDate],[taSch.scheduledDate],[tgChecks.scheduleDate],[ps.date] with '$date';
