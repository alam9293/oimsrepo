// QlikSense only way of association is by similar col name, it will attempt to associate and create unwanted synthetic keys (i.e. mapping tables).
// As a result, ALL our col names have to be unique, and we cannot use QUALIFY * because it looks ugly in the Analysis Tab.
UNQUALIFY *;

LIB CONNECT TO [stb_tag_admin_dev (tag-qlik_administrator)];
// LIB CONNECT TO [stb_tag_admin_uat (h8cc0509v_stbadmin)];
// LIB CONNECT TO [stb_tag_admin (h8cc0511v_stbadmin)];

// In Qlik universe, the BA user should join up the tables he wants. We will only pre-join master data and common tables such as addresses and files.
// To do multi-table join, the BA user can understand the relationships by browsing through the tables first before joining (e.g. applications -> licences -> touristGuides)

[(req.) payment_requests]:
SELECT 
    req.billRefNo AS 'req.billRefNo',
    req.description AS 'req.description',
    req.dueDate AS 'req.dueDate',
    IF(req.isPayerCompany,'Yes','No') AS 'req.isPayerCompany',
    IF(req.isPrePayment,'Yes','No') AS 'req.isPrePayment',
    req.payableAmount AS 'req.payableAmount',
    req.payerName AS 'req.payerName',
    req.payerUinUen AS 'req.payerUinUen',
    req.refNo AS 'req.refNo',
    req.remarks AS 'req.remarks',
    req.userField1 AS 'req.userField1',
    req.userField2 AS 'req.userField2',
    req.userField3 AS 'req.userField3',
    s.label AS 'req.status',
    t.label AS 'req.type',
    txn.id AS 'req.lastTxnId',
    txn.amount AS 'req.lastTxnAmount',
	txn.errorMsg AS 'req.lastTxnErrorMsg',
	txn.remarks AS 'req.lastTxnRemarks',
	txn.txnDate AS 'req.lastTxnDate',
	txn.validityDate AS 'req.lastTxnValidityDate',
    txnT.label AS 'req.lastTxnPaymentType',
	txnS.label AS 'req.lastTxnStatus',    
    req.id AS paymentRequestId,
    req.billRefNo
FROM payment_requests req
LEFT JOIN statuses s ON s.code = req.statusCode
LEFT JOIN types t ON t.code = req.typeCode
LEFT JOIN payment_txns txn ON txn.id = req.lastTxnId
LEFT JOIN statuses txnS ON txnS.code = txn.statusCode
LEFT JOIN types txnT ON txnT.code = txn.paymentTypeCode;

[(txn.) payment_txns]:
SELECT 
	id AS 'txn.id',
	amount AS 'txn.amount',
	errorMsg AS 'txn.errorMsg',
	remarks AS 'txn.remarks',
	txnDate AS 'txn.txnDate',
	validityDate AS 'txn.validityDate',
	t.label AS 'txn.paymentType',
	s.label AS 'txn.status',
    req.paymentRequestId
FROM payment_txns
LEFT JOIN types t ON t.code = paymentTypeCode
LEFT JOIN statuses s ON s.code = statusCode
LEFT JOIN payment_request$payment_txns req ON req.paymentTxnsId = id;

[(rfd.) payment_refunds]:
SELECT 
    bankAccountNo AS 'rfd.bankAccountNo',
    billRefNo AS 'rfd.billRefNo',
    payerName AS 'rfd.payerName',
    refundAmount AS 'rfd.refundAmount',
    was.label AS 'rfd.status',
    billRefNo
FROM payment_refunds
LEFT JOIN workflows w ON w.id = workflowId
LEFT JOIN workflow_actions wa ON wa.id = w.lastActionId
LEFT JOIN statuses was ON was.code = wa.statusCode;

// hide internal PK/FK to only show useful business data
TAG FIELD [paymentRequestId] WITH '$hidden';
TAG FIELD [billRefNo] WITH '$hidden';

// tag date fields as date
TAG FIELD [req.dueDate], [req.lastTxnDate], [req.lastTxnValidityDate], [txn.txnDate], [txn.validityDate] WITH '$date';
