// QlikSense only way of association is by similar col name, it will attempt to associate and create unwanted synthetic keys (i.e. mapping tables).
// As a result, ALL our col names have to be unique, and we cannot use QUALIFY * because it looks ugly in the Analysis Tab.
UNQUALIFY *;

LIB CONNECT TO [stb_tag_admin_dev (tag-qlik_administrator)];
// LIB CONNECT TO [stb_tag_admin_uat (h8cc0509v_stbadmin)];
// LIB CONNECT TO [stb_tag_admin (h8cc0511v_stbadmin)];

// In Qlik universe, the BA user should join up the tables he wants. We will only pre-join master data and common tables such as addresses and files.
// To do multi-table join, the BA user can understand the relationships by browsing through the tables first before joining (e.g. applications -> licences -> touristGuides)

[(aud.) audit_log]:
SELECT
	id AS 'aud.id',
    action AS 'aud.action',
    entityName AS 'aud.entityName',
    entityId AS 'aud.entityId',
    newValue AS 'aud.newValue',
    oldValue AS 'aud.oldValue',
    createdBy AS 'aud.createdBy',
    createdDate AS 'aud.createdDate'
FROM audit_logs
WHERE createdDate >= STR_TO_DATE('$(vFromDate)', '%d/%m/%Y')
AND createdDate <= STR_TO_DATE('$(vToDate)', '%d/%m/%Y');

[(email.) email_log]:
SELECT
	e.id AS 'email.id',
    e.subject AS 'email.subject',
    e.body AS 'email.body',
    e.receiver AS 'email.receiver',
    e.cc AS 'email.cc',
    e.attachments AS 'email.attachments',
    s.label AS 'email.status',
    et.name AS 'email.template',
    e.createdBy AS 'email.createdBy',
    e.createdDate AS 'email.createdDate'
FROM email_logs e
LEFT JOIN statuses s ON e.statusCode = s.code
LEFT JOIN email_templates et ON e.templateCode = et.code
WHERE e.createdDate >= STR_TO_DATE('$(vFromDate)', '%d/%m/%Y')
AND e.createdDate <= STR_TO_DATE('$(vToDate)', '%d/%m/%Y');
