// QlikSense only way of association is by similar col name, it will attempt to associate and create unwanted synthetic keys (i.e. mapping tables).
// As a result, ALL our col names have to be unique, and we cannot use QUALIFY * because it looks ugly in the Analysis Tab.
UNQUALIFY *;

LIB CONNECT TO [stb_tag_admin_dev (tag-qlik_administrator)];
// LIB CONNECT TO [stb_tag_admin_uat (h8cc0509v_stbadmin)];
// LIB CONNECT TO [stb_tag_admin (h8cc0511v_stbadmin)];

// In Qlik universe, the BA user should join up the tables he wants. We will only pre-join master data and common tables such as addresses and files.
// To do multi-table join, the BA user can understand the relationships by browsing through the tables first before joining (e.g. applications -> licences -> touristGuides)

[(lic.) licences]:
SELECT licenceNo AS 'lic.licenceNo',
    lic.ceasedDate AS 'lic.ceasedDate',
    lic.expiryDate AS 'lic.expiryDate',
    IF(lic.isPendingCessation,'Yes','No') AS 'lic.isPendingCessation',
    lic.issueDate AS 'lic.issueDate',
    lic.startDate AS 'lic.startDate',
    lic.taTgType AS 'lic.taTgType',
    s.label AS 'lic.status',
    t.label AS 'lic.tier',
    ke.appointedDate AS 'lic.keAppointedDate',
    ke.sharesHeld AS 'lic.keSharesHeld',
    kes.contactNo AS 'lic.keContactNo',
    kes.dob AS 'lic.keDob',
    kes.email AS 'lic.keEmail',
    kes.formerUin AS 'lic.keFormerUin',
    kes.name AS 'lic.keName',
    kes.officeNo AS 'lic.keOfficeNo',
    kes.otherDesignation AS 'lic.keOtherDesignation',
    kes.residentialNo AS 'lic.keResidentialNo',
    kes.uin AS 'lic.keUin',
    ad.block AS 'lic.keAddrBlk',
    ad.street AS 'lic.keAddrSt',
    ad.building AS 'lic.keAddrBldg',
    ad.floor AS 'lic.keAddrLvl',
    ad.unit AS 'lic.keAddrUnit',
    ad.postal AS 'lic.keAddrPostal',
    ad.foreignLine1 AS 'lic.keAddrForeign1',
    ad.foreignLine2 AS 'lic.keAddrForeign2',
    ad.foreignLine3 AS 'lic.keAddrForeign3',
    ap.label AS 'lic.keAddrPremiseType',
    ds.label AS 'lic.keDesignation',
    ed.label AS 'lic.keHighestEduLevel',
    nt.label AS 'lic.keNationality',
    sx.label AS 'lic.keSex',
    lic.id AS 'licenceId',
    case when s.code='TA_C'or s.code='TA_R'then toYearMonthDay(TIMESTAMPDIFF(DAY, lic.issueDate, lic.ceasedDate)) else toYearMonthDay(TIMESTAMPDIFF(DAY, lic.issueDate, now())) end as 'lic.yearsOfOperation',
    lic.travelAgentId
FROM licences lic
LEFT JOIN statuses s ON s.code = statusCode
LEFT JOIN types t ON t.code = tierCode
LEFT JOIN ta_stakeholders ke ON (ke.licenceId = lic.id AND ke.roleCode = 'STKHLD_KE' AND ke.resignedDate is not null)
LEFT JOIN stakeholders kes ON kes.id = ke.stakeholderId
LEFT JOIN addresses ad ON ad.id = kes.addressId
LEFT JOIN types ap ON ap.code = ad.premiseTypeCode
LEFT JOIN types ds ON ds.code = kes.designationCode
LEFT JOIN types ed ON ed.code = kes.highestEduLevelCode
LEFT JOIN types nt ON nt.code = kes.nationalityCode
LEFT JOIN types sx ON sx.code = kes.sexCode
WHERE taTgType = 'TA';

[(ta.) travel_agents]:
SELECT ta.name AS 'ta.taName',
	ta.uen AS 'ta.taUen',
    ta.contactNo AS 'ta.contactNo',
    ta.emailAddress AS 'ta.emailAddress',
    ta.faxNo AS 'ta.faxNo',
    ta.formerName AS 'ta.formerName',
    ta.fyeDate AS 'ta.fyeDate',
    ta.incorporatedDate AS 'ta.incorporatedDate',
    ta.paidUpCapital AS 'ta.paidUpCapital',
    ta.websiteUrl AS 'ta.websiteUrl',
    bc.label AS 'ta.businessConstitution',
    es.label AS 'ta.establishmentStatus',
    fb.label AS 'ta.formOfBusiness',
    ip.label AS 'ta.incorporatedPlace',    
    pa.label AS 'ta.principleActivities',
    spa.label AS 'ta.secondaryPrincipleActivities',
    ts.label AS 'ta.taSegmentation',
    oa.block AS 'ta.opAddrBlk',
    oa.street AS 'ta.opAddrSt',
    oa.building AS 'ta.opAddrBldg',
    oa.floor AS 'ta.opAddrLvl',
    oa.unit AS 'ta.opAddrUnit',
    oa.postal AS 'ta.opAddrPostal',
    oa.foreignLine1 AS 'ta.opAddrForeign1',
    oa.foreignLine2 AS 'ta.opAddrForeign2',
    oa.foreignLine3 AS 'ta.opAddrForeign3',
    oap.label AS 'ta.opAddrPremiseType',
    ra.block AS 'ta.regAddrBlk',
    ra.street AS 'ta.regAddrSt',
    ra.building AS 'ta.regAddrBldg',
    ra.floor AS 'ta.regAddrLvl',
    ra.unit AS 'ta.regAddrUnit',
    ra.postal AS 'ta.regAddrPostal',
    ra.foreignLine1 AS 'ta.regAddrForeign1',
    ra.foreignLine2 AS 'ta.regAddrForeign2',
    ra.foreignLine3 AS 'ta.regAddrForeign3',
    rap.label AS 'ta.regAddrPremiseType',
    -- getAddress(oa.addressTypeCode, oa.block, oa.street, oa.building, oa.floor, oa.unit, oa.postal, oa.foreignLine1, oa.foreignLine2, oa.foreignLine3) AS taOperatingAddress,
    -- getAddress(ra.addressTypeCode, ra.block, ra.street, ra.building, ra.floor, ra.unit, ra.postal, ra.foreignLine1, ra.foreignLine2, ra.foreignLine3) AS taRegisteredAddress,
    GROUP_CONCAT(DISTINCT ibst.label SEPARATOR ', ') AS 'ta.inboundServices',
    GROUP_CONCAT(DISTINCT obst.label SEPARATOR ', ') AS 'ta.outboundServices',
    ta.id AS 'travelAgentId'
FROM travel_agents ta
LEFT JOIN types bc ON bc.code = ta.businessConstitutionCode
LEFT JOIN types es ON es.code = ta.establishmentStatusCode
LEFT JOIN types fb ON fb.code = ta.formOfBusinessCode
LEFT JOIN types ip ON ip.code = ta.incorporatedPlaceCode
LEFT JOIN types pa ON pa.code = ta.principleActivitiesCode
LEFT JOIN types spa ON spa.code = ta.secondaryPrincipleActivitiesCode
LEFT JOIN types ts ON ts.code = ta.taSegmentationCode
LEFT JOIN addresses oa ON oa.id = operatingAddressId
LEFT JOIN types oap ON oap.code = oa.premiseTypeCode
LEFT JOIN addresses ra ON ra.id = registeredAddressId
LEFT JOIN types rap ON rap.code = ra.premiseTypeCode
LEFT JOIN travel_agent$inbound_services ibs ON ibs.travelAgentId = ta.id
LEFT JOIN types ibst ON ibst.code = ibs.inboundServicesCode
LEFT JOIN travel_agent$outbound_services obs ON obs.travelAgentId = ta.id
LEFT JOIN types obst ON obst.code = obs.outboundServicesCode
GROUP BY ta.id;

[(brn.) ta_branches]:
SELECT brn.ceasedDate AS 'brn.ceasedDate',
    brn.ceasedReason AS 'brn.ceasedReason',
    brn.issueDate AS 'brn.issueDate',
    a.block AS 'brn.addrBlk',
    a.street AS 'brn.addrSt',
    a.building AS 'brn.addrBldg',
    a.floor AS 'brn.addrLvl',
    a.unit AS 'brn.addrUnit',
    a.postal AS 'brn.addrPostal',
    a.foreignLine1 AS 'brn.addrForeign1',
    a.foreignLine2 AS 'brn.addrForeign2',
    a.foreignLine3 AS 'brn.addrForeign3',
    p.label AS 'brn.addrPremiseType',
    -- getAddress(a.addressTypeCode, a.block, a.street, a.building, a.floor, a.unit, a.postal, a.foreignLine1, a.foreignLine2, a.foreignLine3) AS 'brn.address',
    s.label AS 'brn.status',
    f.filename AS 'brn.tenancyDocFileName',
    f.size AS 'brn.tenancyDocFileSize',
    brn.id AS 'taBranchId',
    brn.licenceId
FROM ta_branches brn
LEFT JOIN addresses a ON a.id = brn.addressId
LEFT JOIN types p ON p.code = a.premiseTypeCode
LEFT JOIN statuses s ON s.code = brn.statusCode
LEFT JOIN files f ON f.id = brn.tenancyDocId;

[(stk.) ta_stakeholders]:
SELECT appointedDate AS 'stk.appointedDate',
    resignedDate AS 'stk.resignedDate',
    sharesHeld AS 'stk.sharesHeld',
    rl.label AS 'stk.role',
    s.companyIncorporatedDate AS 'stk.companyIncorporatedDate',
    s.companyUen AS 'stk.companyUen',
    s.contactNo AS 'stk.contactNo',
    s.dob AS 'stk.dob',
    s.email AS 'stk.email',
    s.formerUin AS 'stk.formerUin',
    IF(s.isCompany,'Yes','No') AS 'stk.isCompany',
    s.name AS 'stk.name',
    s.officeNo AS 'stk.officeNo',
    s.otherDesignation AS 'stk.otherDesignation',
    s.residentialNo AS 'stk.residentialNo',
    s.uin AS 'stk.uin',
    ad.block AS 'stk.addrBlk',
    ad.street AS 'stk.addrSt',
    ad.building AS 'stk.addrBldg',
    ad.floor AS 'stk.addrLvl',
    ad.unit AS 'stk.addrUnit',
    ad.postal AS 'stk.addrPostal',
    ad.foreignLine1 AS 'stk.addrForeign1',
    ad.foreignLine2 AS 'stk.addrForeign2',
    ad.foreignLine3 AS 'stk.addrForeign3',
    ap.label AS 'stk.addrPremiseType',
	-- getAddress(ad.addressTypeCode, ad.block, ad.street, ad.building, ad.floor, ad.unit, ad.postal, ad.foreignLine1, ad.foreignLine2, ad.foreignLine3) AS 'shd.address',
    ds.label AS 'stk.designation',
    ed.label AS 'stk.highestEduLevel',
    nt.label AS 'stk.nationality',
    sx.label AS 'stk.sex',
    tsh.licenceId
FROM ta_stakeholders tsh
LEFT JOIN stakeholders s ON s.id = tsh.stakeholderId
LEFT JOIN addresses ad ON ad.id = s.addressId
LEFT JOIN types ap ON ap.code = ad.premiseTypeCode
LEFT JOIN types ds ON ds.code = s.designationCode
LEFT JOIN types ed ON ed.code = s.highestEduLevelCode
LEFT JOIN types nt ON nt.code = s.nationalityCode
LEFT JOIN types sx ON sx.code = s.sexCode
LEFT JOIN types rl ON rl.code = tsh.roleCode;

[(cond.) ta_filing_conditions]:
SELECT cond.dueDate AS 'cond.dueDateOriginal',
    cond.fy AS 'cond.fy',
    IFNULL(e.extendedDueDate, cond.dueDate) AS 'cond.dueDate',
    cond.fyEndDate AS 'cond.fyEndDate',
    cond.fyStartDate AS 'cond.fyStartDate',
    cond.remarks AS 'cond.remarks',
    cond.requestedAsAtDate AS 'cond.requestedAsAtDate',
    t.label AS 'cond.applicationType',
    s.label AS 'cond.status',
    e.extendedDueDate AS 'cond.dueDateExtended',
    e.remarks AS 'cond.extensionRemarks',
    GROUP_CONCAT(DISTINCT oe.extendedDueDate SEPARATOR ', ') AS 'cond.dueDateExtendedOthers',
    cond.id AS 'taFilingConditionId',
    cond.licenceId,
    ccrType.label AS 'cond.lastRecommendedAction',
    cciOutcomeType.label AS 'cond.lastApprovedOutcome',
    pay.refNo as 'cond.paymentRefNo',
    pay.billRefNo AS 'cond.billRefNo',
    pay.payableAmount AS 'cond.payableAmount',
    payStatus.label AS 'cond.paymentStatus'
FROM ta_filing_conditions cond
LEFT JOIN types t ON t.code = cond.applicationTypeCode
LEFT JOIN statuses s ON s.code = cond.statusCode
LEFT JOIN ta_filing_condition_extensions e ON (e.id = cond.lastExtensionId AND e.toExtend)
LEFT JOIN ta_filing_condition_extensions oe ON (oe.taFilingConditionId = cond.id AND oe.toExtend AND oe.id <> cond.lastExtensionId)
LEFT JOIN ce_case_infringements cci ON (cci.id=cond.tarR141InfringementId)
LEFT JOIN ce_case_recommendations ccr ON (ccr.id=cci.lastRecommendationId)
LEFT JOIN types ccrType ON (ccrType.code=ccr.outcomeCode) 
LEFT JOIN types cciOutcomeType ON (cciOutcomeType.code=cci.outcomeCode)
LEFT JOIN ce_case_decisions ccd ON (ccd.id=cci.lastDecisionId)
LEFT JOIN payment_requests pay ON (pay.billRefNo=ccd.billRefNo)
LEFT JOIN statuses payStatus on (payStatus.code=pay.statusCode)
GROUP BY cond.id;

[(aa.) ta_aa_submissions]:
SELECT a.applicationNo AS 'aa.appNo',
	a.submissionDate AS 'aa.appSubmissionDate',
	ws.label AS 'aa.appStatus',
	w.createdDate AS 'aa.appStatusDate',
	accProfitLoss AS 'aa.accountingProfitLoss',
    amtOwnByDir AS 'aa.amtOwnByDirectors',
    bankBalance AS 'aa.bankBalance',
    capital AS 'aa.paidUpCapital',
    cashCashEquiv AS 'aa.cashAndCashEquivalents',
    currentAssets AS 'aa.currentAssets',
    currentLiabilities AS 'aa.currentLiabilities',
    debtEquityRatio AS 'aa.debtEquityRatio',
    dividendsPaid AS 'aa.dividendsPaid',
    grossProfitLoss AS 'aa.grossProfitLoss',
    IF(isDebtEquityRatioRed,'Yes','No') AS 'aa.isDebtEquityRatioRed',
    IF(isNetProfitMarginRed,'Yes','No') AS 'aa.isNetProfitMarginRed',
    IF(isProfitScRatioRed,'Yes','No') AS 'aa.isProfitScRatioRed',
    IF(isQuickRatioRed,'Yes','No') AS 'aa.isQuickRatioRed',
    noOfReds AS 'aa.noOfReds',
    netProfitLoss AS 'aa.netProfitLoss',
    netProfitMargin AS 'aa.netProfitMargin',
    netValue AS 'aa.netValue',
    nonCurrentAssets AS 'aa.nonCurrentAssets',
    nonCurrentLiabilities AS 'aa.nonCurrentLiabilities',
    otherIncome AS 'aa.otherIncome',
    profitScRatio AS 'aa.profitScRatio',
    quickRatio AS 'aa.quickRatio',
    revenue AS 'aa.revenue',
    shortfall AS 'aa.shortfallDefaultAmount',
    totalAssets AS 'aa.totalAssets',
    totalEquity AS 'aa.totalEquity',
    totalLiabilities AS 'aa.totalLiabilities',
    tradeReceivables AS 'aa.tradeReceivables',
    tradeSecurities AS 'aa.tradeSecurities',
    au.label AS 'aa.auditorOpinion',
    sf.amount AS 'aa.shortfallAmount',
    sf.extendedDueDate AS 'aa.shortfallRectiDueDateExt',
    sf.letterIssuedDate AS 'aa.shortfallLetterIssuedDate',
    sf.rectificationDueDate AS 'aa.shortfallRectiDueDateOrig',
    IFNULL(sf.extendedDueDate, sf.rectificationDueDate) AS 'aa.shortfallRectiDueDate',
    sf.remarks AS 'aa.shortfallRemarks',
    psf.amount 'aa.shortfallParentAmount',
    t.label AS 'aa.shortfallType',
    sfws.label AS 'aa.shortfallApprovalStatus',
    pay.refNo AS 'aa.shortfallPayRefNo',
    pay.billRefNo AS 'aa.shortfallBillRefNo',
    pay.payableAmount AS 'aa.shortfallPayableAmount',
    payStatus.label AS 'aa.shortfallPayStatus',
    aa.taAnnualFilingId AS 'taFilingConditionId',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'aa.attachments',
    recti.rectiAppNo AS 'aa.rectiAppNo',
	recti.rectiAppSubmissionDate AS 'aa.rectiAppSubmissionDate',
	recti.rectiAppStatus AS 'aa.rectiAppStatus',
	recti.rectiAppStatusDate AS 'aa.rectiAppStatusDate',
	recti.rectiAmount AS 'aa.rectiAmount',
	recti.rectifiedDate AS 'aa.rectifiedDate',
	recti.rectiAttachments AS 'aa.rectiAttachments'
    -- a.licenceId -- derived from taFilingCondition
FROM ta_aa_submissions aa
LEFT JOIN applications a ON a.id = aa.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN types au ON au.code = aa.auditorOpinionCode
LEFT JOIN ta_net_value_shortfalls sf ON sf.taAaSubmissionId = aa.id
LEFT JOIN workflows sfw ON sfw.id = sf.workflowId
LEFT JOIN workflow_actions sfwa ON sfwa.id = sfw.lastActionId
LEFT JOIN statuses sfws ON sfws.code = sfwa.statusCode
LEFT JOIN ta_net_value_shortfalls psf ON sf.parentShortfallId = psf.id
LEFT JOIN types t ON t.code = sf.typeCode
LEFT JOIN ce_case_infringements cci ON cci.id=sf.tarR9InfringementId
LEFT JOIN ce_case_decisions ccd ON ccd.id=cci.lastDecisionId
LEFT JOIN payment_requests pay ON pay.billRefNo=ccd.billRefNo
LEFT JOIN statuses payStatus ON payStatus.code=pay.statusCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
LEFT JOIN (
	SELECT a.applicationNo AS 'rectiAppNo',
		a.submissionDate AS 'rectiAppSubmissionDate',
		ws.label AS 'rectiAppStatus',
		w.createdDate AS 'rectiAppStatusDate',
		amount AS 'rectiAmount',
		rectifiedDate AS 'rectifiedDate',
		GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'rectiAttachments',
		recti.id AS taNetValueRectificationId
	FROM ta_net_value_rectifications recti
	LEFT JOIN applications a ON a.id = recti.applicationId
	LEFT JOIN workflow_actions w ON w.id = a.lastActionId
	LEFT JOIN statuses ws ON ws.code = w.statusCode
	LEFT JOIN application_files af ON af.applicationId = a.id
	LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
	WHERE a.isDeleted = false
	AND a.isDraft = false
	GROUP BY recti.id) recti ON sf.taNetValueRectificationId = recti.taNetValueRectificationId
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY aa.id;

[(abpr.) ta_abpr_submissions]:
SELECT a.applicationNo AS 'abpr.appNo',
	a.submissionDate AS 'abpr.appSubmissionDate',
	ws.label AS 'abpr.appStatus',
	w.createdDate AS 'abpr.appStatusDate',
	depreciation AS 'abpr.depreciation',
    IF(hasOverseasBranch,'Yes','No') AS 'abpr.hasOverseasBranch',
    inboundFitPax AS 'abpr.inboundFitPax',
    inboundFitPaxPercent AS 'abpr.inboundFitPaxPercent',
    inboundGrpPax AS 'abpr.inboundGrpPax',
    inboundGrpPaxPercent AS 'abpr.inboundGrpPaxPercent',
    inboundOp AS 'abpr.inboundOp',
    inboundOpPercent AS 'abpr.inboundOpPercent',
    indirectTax AS 'abpr.indirectTax',
    IF(isNilSubmission,'Yes','No') AS 'abpr.isNilSubmission',
    noOfEmployee AS 'abpr.noOfEmployee',
    operatingCost AS 'abpr.operatingCost',
    outboundFitPax AS 'abpr.outboundFitPax',
    outboundFitPaxPercent AS 'abpr.outboundFitPaxPercent',
    outboundGrpPax AS 'abpr.outboundGrpPax',
    outboundGrpPaxPercent AS 'abpr.outboundGrpPaxPercent',
    outboundOp AS 'abpr.outboundOp',
    outboundOpPercent AS 'abpr.outboundOpPercent',
    remuneration AS 'abpr.remuneration',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'abpr.attachments',
    abpr.id AS 'taAbprSubmissionId',
    taAnnualFilingId AS 'taFilingConditionId'
    -- a.licenceId -- derived from taFilingCondition
FROM ta_abpr_submissions abpr
LEFT JOIN applications a ON a.id = abpr.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY abpr.id;

[(abprB.) ta_business_operations]:
SELECT IF(isInboundOwned,'Yes','No') AS 'abprB.isInboundOwned',
    inbound AS 'abprB.inbound',
    inboundPercent AS 'abprB.inboundPercent',
    IF(isOutboundOwned,'Yes','No') AS 'abprB.isOutboundOwned',
    outbound AS 'abprB.outbound',
    outboundPercent AS 'abprB.outboundPercent',
    t.label AS 'abprB.service',
    taAbprSubmissionId
FROM ta_business_operations abprB
INNER JOIN ta_abpr_submissions abpr ON abpr.id = abprB.taAbprSubmissionId
LEFT JOIN applications a ON a.id = abpr.applicationId
LEFT JOIN types t ON t.code = serviceCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(abprF.) ta_focus_areas]:
SELECT hasOp AS 'abprF.hasOperations',
	hasInboundOp AS 'abprF.hasInboundOperations',
    hasOutboundOp AS 'abprF.hasOutboundOperations',
    otherFocusArea AS 'abprF.otherFocusArea',
   	remarks AS 'abprF.remarks',
    t.label AS 'abprF.focusArea',
    taAbprSubmissionId
FROM ta_focus_areas abprF
INNER JOIN ta_abpr_submissions abpr ON abpr.id = abprF.taAbprSubmissionId
LEFT JOIN applications a ON a.id = abpr.applicationId
LEFT JOIN types t ON t.code = focusAreaCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(abprA.) ta_function_activities]:
SELECT t.label AS 'abprA.question',
    IF(isInbound,'Yes','No') AS 'abprA.isInbound',
    IF(isOutbound,'Yes','No') AS 'abprA.isOutbound',
    taAbprSubmissionId
FROM ta_function_activities abprA
INNER JOIN ta_abpr_submissions abpr ON abpr.id = abprA.taAbprSubmissionId
LEFT JOIN applications a ON a.id = abpr.applicationId
LEFT JOIN types t ON t.code = questionCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(abprS.) ta_specialized_markets]:
SELECT IF(isInbound,'Yes','No') AS 'abprS.isInbound',
    percent AS 'abprS.percent',
    t.label AS 'abprS.country',
    taAbprSubmissionId
FROM ta_specialized_markets sm
INNER JOIN ta_abpr_submissions abpr ON abpr.id = taAbprSubmissionId
LEFT JOIN applications a ON a.id = abpr.applicationId
LEFT JOIN types t ON t.code = countryCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(brnApp.) ta_branch_applications]:
SELECT a.applicationNo AS 'brnApp.appNo',
	a.submissionDate AS 'brnApp.appSubmissionDate',
	ws.label AS 'brnApp.appStatus',
	w.createdDate AS 'brnApp.appStatusDate',
	tenancyEndDate AS 'brnApp.tenancyEndDate',
    tenancyStartDate AS 'brnApp.tenancyStartDate',
    ad.block AS 'brnApp.addrBlk',
    ad.street AS 'brnApp.addrSt',
    ad.building AS 'brnApp.addrBldg',
    ad.floor AS 'brnApp.addrLvl',
    ad.unit AS 'brnApp.addrUnit',
    ad.postal AS 'brnApp.addrPostal',
    ad.foreignLine1 AS 'brnApp.addrForeign1',
    ad.foreignLine2 AS 'brnApp.addrForeign2',
    ad.foreignLine3 AS 'brnApp.addrForeign3',
    ap.label AS 'brnApp.addrPremiseType',
    -- getAddress(ad.addressTypeCode, ad.block, ad.street, ad.building, ad.floor, ad.unit, ad.postal, ad.foreignLine1, ad.foreignLine2, ad.foreignLine3) AS 'brnApp.address',
    s.label AS 'brnApp.status',
    f.filename AS 'brnApp.tenancyDocFileName',
    f.size AS 'brnApp.tenancyDocFileSize',
    fs.label AS 'brnApp.tenancyDocTransferStatus',
    t.label AS 'brnApp.type',
    ba.appFeeBillRefNo AS 'brnApp.appFeebillRefNo',
    IF(ba.isConcluded,'Yes','No') AS 'brnApp.isConcluded',
    a.licenceId
FROM ta_branch_applications brnApp
LEFT JOIN ta_branch_application_batches ba ON ba.id = brnApp.taBranchApplicationBatchId
LEFT JOIN applications a ON a.id = ba.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN addresses ad ON ad.id = brnApp.addressId
LEFT JOIN types ap ON ap.code = ad.premiseTypeCode
LEFT JOIN statuses s ON s.code = brnApp.statusCode
LEFT JOIN types t ON t.code = brnApp.typeCode
LEFT JOIN files f ON f.id = brnApp.tenancyDocId
LEFT JOIN statuses fs ON fs.code = f.transferStatusCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(cyUpd.) ta_company_updates]:
SELECT a.applicationNo AS 'cyUpd.appNo',
	a.submissionDate AS 'cyUpd.appSubmissionDate',
	ws.label AS 'cyUpd.appStatus',
	w.createdDate AS 'cyUpd.appStatusDate',
    cyUpd.companyName AS 'cyUpd.newTaName',
    cyUpd.contactNo AS 'cyUpd.contactNo',
    cyUpd.emailAddress AS 'cyUpd.emailAddress',
    cyUpd.faxNo AS 'cyUpd.faxNo',
    cyUpd.paidUpCapital AS 'cyUpd.paidUpCapital',
    cyUpd.websiteUrl AS 'cyUpd.websiteUrl',
    bc.label AS 'cyUpd.businessConstitution',
    es.label AS 'cyUpd.establishmentStatus',
    fb.label AS 'cyUpd.formOfBusiness',
    ip.label AS 'cyUpd.incorporatedPlace',
    pa.label AS 'cyUpd.principleActivities',
    spa.label AS 'cyUpd.secondaryPrincipleActivities',
    ts.label AS 'cyUpd.taSegmentation',
    oa.block AS 'cyUpd.opAddrBlk',
    oa.street AS 'cyUpd.opAddrSt',
    oa.building AS 'cyUpd.opAddrBldg',
    oa.floor AS 'cyUpd.opAddrLvl',
    oa.unit AS 'cyUpd.opAddrUnit',
    oa.postal AS 'cyUpd.opAddrPostal',
    oa.foreignLine1 AS 'cyUpd.opAddrForeign1',
    oa.foreignLine2 AS 'cyUpd.opAddrForeign2',
    oa.foreignLine3 AS 'cyUpd.opAddrForeign3',
    oap.label AS 'cyUpd.opAddrPremiseType',
    ra.block AS 'cyUpd.regAddrBlk',
    ra.street AS 'cyUpd.regAddrSt',
    ra.building AS 'cyUpd.regAddrBldg',
    ra.floor AS 'cyUpd.regAddrLvl',
    ra.unit AS 'cyUpd.regAddrUnit',
    ra.postal AS 'cyUpd.regAddrPostal',
    ra.foreignLine1 AS 'cyUpd.regAddrForeign1',
    ra.foreignLine2 AS 'cyUpd.regAddrForeign2',
    ra.foreignLine3 AS 'cyUpd.regAddrForeign3',
    rap.label AS 'cyUpd.regAddrPremiseType',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'cyUpd.attachments',
    -- getAddress(oa.addressTypeCode, oa.block, oa.street, oa.building, oa.floor, oa.unit, oa.postal, oa.foreignLine1, oa.foreignLine2, oa.foreignLine3) AS 'cyUpd.operatingAddress',
    -- getAddress(ra.addressTypeCode, ra.block, ra.street, ra.building, ra.floor, ra.unit, ra.postal, ra.foreignLine1, ra.foreignLine2, ra.foreignLine3) AS 'cyUpd.registeredAddress',
    a.licenceId
FROM ta_company_updates cyUpd
LEFT JOIN applications a ON a.id = cyUpd.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN types bc ON bc.code = cyUpd.businessConstitutionCode
LEFT JOIN types es ON es.code = cyUpd.establishmentStatusCode
LEFT JOIN types fb ON fb.code = cyUpd.formOfBusinessCode
LEFT JOIN types ip ON ip.code = cyUpd.placeIncorporatedCode
LEFT JOIN types pa ON pa.code = cyUpd.principleActivitiesCode
LEFT JOIN types spa ON spa.code = cyUpd.secondaryPrincipleActivitiesCode
LEFT JOIN types ts ON ts.code = cyUpd.taSegmentationCode
LEFT JOIN addresses oa ON oa.id = cyUpd.operatingAddressId
LEFT JOIN types oap ON oap.code = oa.premiseTypeCode
LEFT JOIN addresses ra ON ra.id = cyUpd.registeredAddressId
LEFT JOIN types rap ON rap.code = ra.premiseTypeCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY cyUpd.id;

[(fyUpd.) ta_fy_updates]:
SELECT a.applicationNo AS 'fyUpd.appNo',
	a.submissionDate AS 'fyUpd.appSubmissionDate',
	ws.label AS 'fyUpd.appStatus',
	w.createdDate AS 'fyUpd.appStatusDate',
    fyStartDate AS 'fyUpd.fyStartDate',
    newFyeDate AS 'fyUpd.newFyeDate',
    oldFyeDate AS 'fyUpd.oldFyeDate',
    reason AS 'fyUpd.reason',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'fyUpd.attachments',
    a.licenceId
FROM ta_fy_updates fyUpd
LEFT JOIN applications a ON a.id = fyUpd.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY fyUpd.id;

[(crtn.) ta_licence_creations]:
SELECT a.applicationNo AS 'crtn.appNo',
	a.submissionDate AS 'crtn.appSubmissionDate',
	ws.label AS 'crtn.appStatus',
	w.createdDate AS 'crtn.appStatusDate',
	crtn.appDob AS 'crtn.appDob',
    crtn.appEmailAddress AS 'crtn.appEmailAddress',
    crtn.appFaxNo AS 'crtn.appFaxNo',
    crtn.appFeeBillRefNo AS 'crtn.appFeeBillRefNo',
    crtn.appMobileNo AS 'crtn.appMobileNo',
    crtn.appName AS 'crtn.appName',
    crtn.appOfficeNo AS 'crtn.appOfficeNo',
    crtn.appOtherDesignation AS 'crtn.appOtherDesignation',
    crtn.appResidentialNo AS 'crtn.appResidentialNo',
    crtn.appUin AS 'crtn.appUin',
    crtn.companyFormerName AS 'crtn.companyFormerName',
    crtn.companyName AS 'crtn.companyName',
    crtn.contactNo AS 'crtn.contactNo',
    crtn.currentBusinessWriteUp AS 'crtn.currentBusinessWriteUp',
    crtn.effectiveDate AS 'crtn.effectiveDate',
    crtn.emailAddress AS 'crtn.emailAddress',
    crtn.faxNo AS 'crtn.faxNo',
    crtn.fyeDate AS 'crtn.fyeDate',
    crtn.inboundOpPercent AS 'crtn.inboundOpPercent',
	IF(crtn.isAppKeyExecutive,'Yes','No') AS 'crtn.isAppKeyExecutive',
	IF(crtn.isConcluded,'Yes','No') AS 'crtn.isConcluded',
	IF(crtn.isEdhPopulated,'Yes','No') AS 'crtn.isEdhPopulated',
    IF(crtn.isMyInfoPopulated,'Yes','No') AS 'crtn.isMyInfoPopulated',
    IF(crtn.isOppAddSameAsRegAdd,'Yes','No') AS 'crtn.isOpAddrSameAsRegAddr',
    crtn.licenceFeeBillRefNo AS 'crtn.licenceFeeBillRefNo',
    crtn.officeNo AS 'crtn.officeNo',
    crtn.outboundOpPercent AS 'crtn.outboundOpPercent',
    crtn.paidUpCapital AS 'crtn.paidUpCapital',
    crtn.registrationDate AS 'crtn.registrationDate',
    crtn.residentialNo AS 'crtn.residentialNo',
    crtn.taBusinessWriteUp AS 'crtn.taBusinessWriteUp',
    crtn.uen AS 'crtn.uen',
    crtn.websiteUrl AS 'crtn.websiteUrl',
    dg.label AS 'crtn.appDesignation',
    nt.label AS 'crtn.appNationality',
    sx.label AS 'crtn.appSex',
    am.label AS 'crtn.applicationMode',
    bc.label AS 'crtn.businessConstitution',
    es.label AS 'crtn.establishmentStatus',
    fb.label AS 'crtn.formOfBusiness',
    tr.label AS 'crtn.licenceTier',
    ip.label AS 'crtn.placeIncorporated',
    pa.label AS 'crtn.principleActivities',
    spa.label As 'crtn.secondaryPrincipleActivities',
    ts.label AS 'crtn.taSegmentation',
	oa.block AS 'crtn.opAddrBlk',
    oa.street AS 'crtn.opAddrSt',
    oa.building AS 'crtn.opAddrBldg',
    oa.floor AS 'crtn.opAddrLvl',
    oa.unit AS 'crtn.opAddrUnit',
    oa.postal AS 'crtn.opAddrPostal',
    oa.foreignLine1 AS 'crtn.opAddrForeign1',
    oa.foreignLine2 AS 'crtn.opAddrForeign2',
    oa.foreignLine3 AS 'crtn.opAddrForeign3',
    oap.label AS 'crtn.opAddrPremiseType',
    ra.block AS 'crtn.regAddrBlk',
    ra.street AS 'crtn.regAddrSt',
    ra.building AS 'crtn.regAddrBldg',
    ra.floor AS 'crtn.regAddrLvl',
    ra.unit AS 'crtn.regAddrUnit',
    ra.postal AS 'crtn.regAddrPostal',
    ra.foreignLine1 AS 'crtn.regAddrForeign1',
    ra.foreignLine2 AS 'crtn.regAddrForeign2',
    ra.foreignLine3 AS 'crtn.regAddrForeign3',
    rap.label AS 'crtn.regAddrPremiseType',
	GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'crtn.attachments',
	crtn.id AS taLicenceCreationId
FROM ta_licence_creations crtn
LEFT JOIN applications a ON a.id = crtn.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN types dg ON dg.code = crtn.appDesignationCode
LEFT JOIN types nt ON nt.code = crtn.appNationalityCode
LEFT JOIN types sx ON sx.code = crtn.appSexCode
LEFT JOIN types am ON am.code = crtn.applicationModeCode
LEFT JOIN types bc ON bc.code = crtn.businessConstitutionCode
LEFT JOIN types es ON es.code = crtn.establishmentStatusCode
LEFT JOIN types fb ON fb.code = crtn.formOfBusinessCode
LEFT JOIN types tr ON tr.code = crtn.licenceTierCode
LEFT JOIN types ip ON ip.code = crtn.placeIncorporatedCode
LEFT JOIN types pa ON pa.code = crtn.principleActivitiesCode
LEFT JOIN types spa ON spa.code = crtn.secondaryPrincipleActivitiesCode
LEFT JOIN types ts ON ts.code = crtn.taSegmentationCode
LEFT JOIN addresses oa ON oa.id = operatingAddressId
LEFT JOIN types oap ON oap.code = oa.premiseTypeCode
LEFT JOIN addresses ra ON ra.id = registeredAddressId
LEFT JOIN types rap ON rap.code = ra.premiseTypeCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY crtn.id;

[(crtnB.) ta_business_operations]:
SELECT IF(isInboundOwned,'Yes','No') AS 'crtnB.isInboundOwned',
    inbound AS 'crtnB.inbound',
    inboundPercent AS 'crtnB.inboundPercent',
    IF(isOutboundOwned,'Yes','No') AS 'crtnB.isOutboundOwned',
    outbound AS 'crtnB.outbound',
    outboundPercent AS 'crtnB.outboundPercent',
    t.label AS 'crtnB.service',
    taLicenceCreationId
FROM ta_business_operations crtnB
INNER JOIN ta_licence_creations crtn ON crtn.id = crtnB.taLicenceCreationId
LEFT JOIN applications a ON a.id = crtn.applicationId
LEFT JOIN types t ON t.code = serviceCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(crtnF.) ta_focus_areas]:
SELECT hasOp AS 'crtnF.hasOperations',
	hasInboundOp AS 'crtnF.hasInboundOperations',
    hasOutboundOp AS 'crtnF.hasOutboundOperations',
    otherFocusArea AS 'crtnF.otherFocusArea',
   	remarks AS 'crtnF.remarks',
    t.label AS 'crtnF.focusArea',
    taLicenceCreationId
FROM ta_focus_areas crtnF
INNER JOIN ta_licence_creations crtn ON crtn.id = crtnF.taLicenceCreationId
LEFT JOIN applications a ON a.id = crtn.applicationId
LEFT JOIN types t ON t.code = focusAreaCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(crtnS.) ta_specialized_markets]:
SELECT IF(isInbound,'Yes','No') AS 'crtnS.isInbound',
    percent AS 'crtnS.percent',
    t.label AS 'crtnS.country',
    taLicenceCreationId
FROM ta_specialized_markets sm
INNER JOIN ta_licence_creations crtn ON crtn.id = taLicenceCreationId
LEFT JOIN applications a ON a.id = crtn.applicationId
LEFT JOIN types t ON t.code = countryCode
WHERE a.isDeleted = false
AND a.isDraft = false;

[(cess.) ta_licence_cessations]:
SELECT a.applicationNo AS 'cess.appNo',
	a.submissionDate AS 'cess.appSubmissionDate',
	ws.label AS 'cess.appStatus',
	w.createdDate AS 'cess.appStatusDate',
    effectiveDate AS 'cess.effectiveDate',
    IF(pendingBatchJob,'Yes','No') AS 'cess.isPendingBatchJob',
    t.label AS 'cess.reason',
    otherReason AS 'cess.otherReason',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'cess.attachments',
    a.licenceId
FROM ta_licence_cessations cess
LEFT JOIN applications a ON a.id = cess.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN types t ON t.code = reasonCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY cess.id;

[(rplc.) ta_licence_replacements]:
SELECT a.applicationNo AS 'rplc.appNo',
	a.submissionDate AS 'rplc.appSubmissionDate',
	ws.label AS 'rplc.appStatus',
	w.createdDate AS 'rplc.appStatusDate',
    billRefNo AS 'rplc.billRefNo',
    licenceReturnedDate AS 'rplc.licenceReturnedDate',
    otherReason AS 'rplc.otherReason',
    t.label AS 'rplc.reason',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'rplc.attachments',
    a.licenceId
FROM ta_licence_replacements rplc
LEFT JOIN applications a ON a.id = rplc.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN types t ON t.code = reasonCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY rplc.id;

[(swh.) ta_licence_tier_switches]:
SELECT a.applicationNo AS 'swh.appNo',
	a.submissionDate AS 'swh.appSubmissionDate',
	ws.label AS 'swh.appStatus',
	w.createdDate AS 'swh.appStatusDate',
    IF(pendingSwitch,'Yes','No') AS 'swh.isPendingSwitch',
    swh.startDate AS 'swh.startDate',
    n.label AS 'swh.newLicenceTier',
    o.label AS 'swh.oldLicenceTier',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'swh.attachments',
    a.licenceId
FROM ta_licence_tier_switches swh
LEFT JOIN applications a ON a.id = swh.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN types n ON n.code = newLicenceTierCode
LEFT JOIN types o ON o.code = oldLicenceTierCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY swh.id;

[(ma.) ta_ma_submissions]:
SELECT a.applicationNo AS 'ma.appNo',
	a.submissionDate AS 'ma.appSubmissionDate',
	ws.label AS 'ma.appStatus',
	w.createdDate AS 'ma.appStatusDate',
    ma.asAtDate AS 'ma.asAtDate',
    ma.netValue AS 'ma.netValue',
    ma.paidUpCapital AS 'ma.paidUpCapital',
    ma.shortfall AS 'ma.shortfallDefaultAmount',
    ma.totalAssets AS 'ma.totalAssets',
    ma.totalLiabilities AS 'ma.totalLiabilities',
    sf.amount AS 'ma.shortfallAmount',
    sf.extendedDueDate AS 'ma.shortfallRectiDueDateExt',
    sf.letterIssuedDate AS 'ma.shortfallLetterIssuedDate',
    sf.rectificationDueDate AS 'ma.shortfallRectiDueDateOrig',
    IFNULL(sf.extendedDueDate, sf.rectificationDueDate) AS 'ma.shortfallRectiDueDate',
    sf.remarks AS 'ma.shortfallRemarks',
    psf.amount 'ma.shortfallParentAmount',
    t.label AS 'ma.shortfallType',
    sfws.label AS 'ma.shortfallApprovalStatus',
    pay.refNo AS 'ma.shortfallPayRefNo',
    pay.billRefNo AS 'ma.shortfallBillRefNo',
    pay.payableAmount AS 'ma.shortfallPayableAmount',
    payStatus.label AS 'ma.shortfallPayStatus',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'ma.attachments',
    recti.rectiAppNo AS 'ma.rectiAppNo',
	recti.rectiAppSubmissionDate AS 'ma.rectiAppSubmissionDate',
	recti.rectiAppStatus AS 'ma.rectiAppStatus',
	recti.rectiAppStatusDate AS 'ma.rectiAppStatusDate',
	recti.rectiAmount AS 'ma.rectiAmount',
	recti.rectifiedDate AS 'ma.rectifiedDate',
	recti.rectiAttachments AS 'ma.rectiAttachments',
    a.licenceId
FROM ta_ma_submissions ma
LEFT JOIN applications a ON a.id = ma.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN ta_net_value_shortfalls sf ON sf.taMaSubmissionId = ma.id
LEFT JOIN workflows sfw ON sfw.id = sf.workflowId
LEFT JOIN workflow_actions sfwa ON sfwa.id = sfw.lastActionId
LEFT JOIN statuses sfws ON sfws.code = sfwa.statusCode
LEFT JOIN ta_net_value_shortfalls psf ON sf.parentShortfallId = psf.id
LEFT JOIN types t ON t.code = sf.typeCode
LEFT JOIN ce_case_infringements cci ON cci.id=sf.tarR9InfringementId
LEFT JOIN ce_case_decisions ccd ON ccd.id=cci.lastDecisionId
LEFT JOIN payment_requests pay ON pay.billRefNo=ccd.billRefNo
LEFT JOIN statuses payStatus ON payStatus.code=pay.statusCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
LEFT JOIN (
	SELECT a.applicationNo AS 'rectiAppNo',
		a.submissionDate AS 'rectiAppSubmissionDate',
		ws.label AS 'rectiAppStatus',
		w.createdDate AS 'rectiAppStatusDate',
		amount AS 'rectiAmount',
		rectifiedDate AS 'rectifiedDate',
		GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'rectiAttachments',
		recti.id AS taNetValueRectificationId
	FROM ta_net_value_rectifications recti
	LEFT JOIN applications a ON a.id = recti.applicationId
	LEFT JOIN workflow_actions w ON w.id = a.lastActionId
	LEFT JOIN statuses ws ON ws.code = w.statusCode
	LEFT JOIN application_files af ON af.applicationId = a.id
	LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
	WHERE a.isDeleted = false
	AND a.isDraft = false
	GROUP BY recti.id) recti ON sf.taNetValueRectificationId = recti.taNetValueRectificationId
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY ma.id;

[(stkApp.) ta_stakeholder_applications]:
SELECT a.applicationNo AS 'stkApp.appNo',
	a.submissionDate AS 'stkApp.appSubmissionDate',
	ws.label AS 'stkApp.appStatus',
	w.createdDate AS 'stkApp.appStatusDate',
    stkApp.appointedDate AS 'stkApp.appointedDate',
    stkApp.companyIncorporatedDate AS 'stkApp.companyIncorporatedDate',
    stkApp.companyUen AS 'stkApp.companyUen',
    stkApp.contactNo AS 'stkApp.contactNo',
    stkApp.dob AS 'stkApp.dob',
    stkApp.email AS 'stkApp.email',
    stkApp.formerUin AS 'stkApp.formerUin',
    IF(stkApp.isCompany,'Yes','No') AS 'stkApp.isCompany',
    IF(stkApp.isEdhPopulated,'Yes','No') AS 'stkApp.isEdhPopulated',
    IF(stkApp.isMyInfoPopulated,'Yes','No') AS 'stkApp.isMyInfoPopulated',
    stkApp.joinedDate AS 'stkApp.joinedDate',
    stkApp.name AS 'stkApp.name',
    stkApp.officeNo AS 'stkApp.officeNo',
    stkApp.otherDesignation AS 'stkApp.otherDesignation',
    stkApp.residentialNo AS 'stkApp.residentialNo',
    stkApp.resignedDate AS 'stkApp.resignedDate',
    stkApp.sharesHeld AS 'stkApp.sharesHeld',
    stkApp.uin AS 'stkApp.uin',
    ad.block AS 'stkApp.addrBlk',
    ad.street AS 'stkApp.addrSt',
    ad.building AS 'stkApp.addrBldg',
    ad.floor AS 'stkApp.addrLvl',
    ad.unit AS 'stkApp.addrUnit',
    ad.postal AS 'stkApp.addrPostal',
    ad.foreignLine1 AS 'stkApp.addrForeign1',
    ad.foreignLine2 AS 'stkApp.addrForeign2',
    ad.foreignLine3 AS 'stkApp.addrForeign3',
    ap.label AS 'stkApp.addrPremiseType',
    -- getAddress(ad.addressTypeCode, ad.block, ad.street, ad.building, ad.floor, ad.unit, ad.postal, ad.foreignLine1, ad.foreignLine2, ad.foreignLine3) AS 'stkApp.address',
    ds.label AS 'stkApp.designation',
    ed.label AS 'stkApp.highestEduLevel',
    nt.label AS 'stkApp.nationality',
    previousValueId AS 'stkApp.previousValueId',
    rl.label AS 'stkApp.role',
    sx.label AS 'stkApp.sex',
    t.label AS 'stkApp.type',
    GROUP_CONCAT(DISTINCT f.filename SEPARATOR ', ') AS 'stkApp.attachments',
    stkApp.taLicenceCreationId,
    a.licenceId
FROM ta_stakeholder_applications stkApp
LEFT JOIN applications a ON a.id = stkApp.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN addresses ad ON ad.id = stkApp.addressId
LEFT JOIN types ap ON ap.code = ad.premiseTypeCode
LEFT JOIN types ds ON ds.code = stkApp.designationCode
LEFT JOIN types ed ON ed.code = stkApp.highestEduLevelCode
LEFT JOIN types nt ON nt.code = stkApp.nationalityCode
LEFT JOIN types sx ON sx.code = stkApp.sexCode
LEFT JOIN types rl ON rl.code = stkApp.roleCode
LEFT JOIN types t ON t.code = stkApp.typeCode
LEFT JOIN application_files af ON af.applicationId = a.id
LEFT JOIN files f ON (f.id = af.fileId AND f.isDeleted = false)
WHERE a.isDeleted = false
AND a.isDraft = false
GROUP BY stkApp.id;

// hide internal PK/FK to only show useful business data
TAG FIELD [applicationId] WITH '$hidden';
TAG FIELD [licenceId] WITH '$hidden';
TAG FIELD [travelAgentId] WITH '$hidden';
TAG FIELD [taBranchId] WITH '$hidden';
TAG FIELD [stakeholderId] WITH '$hidden';
TAG FIELD [taFilingConditionId] WITH '$hidden';
TAG FIELD [taAbprSubmissionId] WITH '$hidden';
TAG FIELD [taLicenceCreationId] WITH '$hidden';
TAG FIELD [taLicenceTierSwitchId] WITH '$hidden';

// tag date fields as date
TAG FIELD [lic.ceasedDate], [lic.expiryDate], [lic.issueDate], [lic.startDate], [lic.keAppointedDate] with '$date';
TAG FIELD [ta.fyeDate], [ta.incorporatedDate], [brn.ceasedDate], [brn.issueDate], [stk.appointedDate], [stk.resignedDate], [stk.companyIncorporatedDate] with '$date';
TAG FIELD [cond.fyEndDate], [cond.fyStartDate], [cond.requestedAsAtDate] with '$date';
TAG FIELD [aa.appSubmissionDate], [aa.appStatusDate], [aa.shortfallLetterIssuedDate], [aa.shortfallRectiDueDate], [aa.rectiAppSubmissionDate], [aa.rectiAppStatusDate], [aa.rectifiedDate] with '$date';
TAG FIELD [abpr.appSubmissionDate], [abpr.appStatusDate], [brnApp.appStatusDate], [brnApp.tenancyEndDate], [brnApp.tenancyStartDate] with '$date';
TAG FIELD [cyUpd.appSubmissionDate], [cyUpd.appStatusDate], [fyUpd.appSubmissionDate], [fyUpd.appStatusDate], [fyUpd.fyStartDate], [fyUpd.newFyeDate], [fyUpd.oldFyeDate] with '$date';
TAG FIELD [crtn.appSubmissionDate], [crtn.appStatusDate], [crtn.effectiveDate], [crtn.fyeDate], [crtn.registrationDate] with '$date';
TAG FIELD [cess.appSubmissionDate], [cess.appStatusDate], [rplc.appSubmissionDate], [rplc.appStatusDate], [rplc.licenceReturnedDate] with '$date';
TAG FIELD [swh.appSubmissionDate], [swh.appStatusDate], [swh.startDate] with '$date';
TAG FIELD [ma.appSubmissionDate], [ma.appStatusDate], [ma.asAtDate], [ma.shortfallLetterIssuedDate], [ma.shortfallRectiDueDate], [ma.rectiAppSubmissionDate], [ma.rectiAppStatusDate], [ma.rectifiedDate] with '$date';
TAG FIELD [stkApp.appSubmissionDate], [stkApp.appStatusDate], [stkApp.appointedDate], [stkApp.companyIncorporatedDate], [stkApp.joinedDate], [stkApp.resignedDate] with '$date';
