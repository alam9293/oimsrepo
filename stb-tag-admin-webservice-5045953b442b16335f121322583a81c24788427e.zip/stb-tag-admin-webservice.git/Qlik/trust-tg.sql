// QlikSense only way of association is by similar col name, it will attempt to associate and create unwanted synthetic keys (i.e. mapping tables).
// As a result, ALL our col names have to be unique, and we cannot use QUALIFY * because it looks ugly in the Analysis Tab.
UNQUALIFY *;

LIB CONNECT TO [stb_tag_admin_dev (tag-qlik_administrator)];
// LIB CONNECT TO [stb_tag_admin_uat (h8cc0509v_stbadmin)];
// LIB CONNECT TO [stb_tag_admin (h8cc0511v_stbadmin)];

// In Qlik universe, the BA user should join up the tables he wants. We will only pre-join master data and common tables such as addresses and files.
// To do multi-table join, the BA user can understand the relationships by browsing through the tables first before joining (e.g. applications -> licences -> touristGuides)

[(lic.) licences]:
SELECT licenceNo AS 'lic.licenceNo',
	tg.name AS 'lic.tgName',
    tg.uin AS 'lic.tgUin',
    lic.ceasedDate AS 'lic.ceasedDate',
    lic.expiryDate AS 'lic.expiryDate',
    IF(lic.isPendingCessation,'Yes','No') AS 'lic.isPendingCessation',
    lic.issueDate AS 'lic.issueDate',
    lic.startDate AS 'lic.startDate',
    lic.taTgType AS 'lic.taTgType',
    s.label AS 'lic.status',
    t.label AS 'lic.tier',
    lic.id AS 'licenceId',
    lic.touristGuideId
FROM licences lic
LEFT JOIN tourist_guides tg ON tg.id = lic.touristGuideId
LEFT JOIN statuses s ON s.code = statusCode
LEFT JOIN types t ON t.code = tierCode
WHERE taTgType = 'TG';

[(tg.) tourist_guides]:
SELECT l.licenceNo AS 'tg.licenceNo',
	tg.name AS 'tg.tgName',
	tg.uin AS 'tg.tgUin',
    tg.aliasName AS 'tg.aliasName',
    tg.dob AS 'tg.dob',
    bc.label AS 'tg.birthCountry',
    tg.emailAddress AS 'tg.emailAddress',
    tg.employerName AS 'tg.employerName',
    tg.enforcementOutcome AS 'tg.enforcementOutcome',
    tg.formerUin AS 'tg.formerUin',
    GROUP_CONCAT(DISTINCT gl.label SEPARATOR ', ') AS 'tg.guidingLanguages',
    IF(tg.hasConsentEmailAddress,'Yes','No') AS 'tg.hasConsentEmailAddress',
    IF(tg.hasConsentMobileNo,'Yes','No') AS 'tg.hasConsentMobileNo',
    IF(tg.hasPassedOn,'Yes','No') AS 'tg.hasPassedOn',
    IF(tg.hasPersonUpdateAccess,'Yes','No') AS 'tg.hasPersonUpdateAccess',
    he.label AS 'tg.highestEduLevel',
    IF(tg.isMyInfoPopulated,'Yes','No') AS 'tg.isMyInfoPopulated',
    ms.label AS 'tg.maritalStatus',
    tg.mobileNo AS 'tg.mobileNo',
    na.label AS 'tg.nationality',
    oc.label AS 'tg.occupation',
    tg.occupationOther AS 'tg.occupationOther',
    tg.offenceDate AS 'tg.offenceDate',
    tg.offenceDeclaredDate AS 'tg.offenceDeclaredDate',
    tg.offenceType AS 'tg.offenceType',
    rc.label AS 'tg.race',
    rs.label AS 'tg.residentialStatus',
    ma.block AS 'tg.mailAddrBlk',
    ma.street AS 'tg.mailAddrSt',
    ma.building AS 'tg.mailAddrBldg',
    ma.floor AS 'tg.mailpAddrLvl',
    ma.unit AS 'tg.mailAddrUnit',
    ma.postal AS 'tg.mailAddrPostal',
    ma.foreignLine1 AS 'tg.mailAddrForeign1',
    ma.foreignLine2 AS 'tg.mailAddrForeign2',
    ma.foreignLine3 AS 'tg.mailAddrForeign3',
    ra.block AS 'tg.regAddrBlk',
    ra.street AS 'tg.regAddrSt',
    ra.building AS 'tg.regAddrBldg',
    ra.floor AS 'tg.regAddrLvl',
    ra.unit AS 'tg.regAddrUnit',
    ra.postal AS 'tg.regAddrPostal',
    ra.foreignLine1 AS 'tg.regAddrForeign1',
    ra.foreignLine2 AS 'tg.regAddrForeign2',
    ra.foreignLine3 AS 'tg.regAddrForeign3',
    sl.label AS 'tg.salutation',
    sx.label AS 'tg.sex',
    GROUP_CONCAT(DISTINCT ar.label SEPARATOR ', ') AS 'tg.specializedAreas',
    wp.label AS 'tg.workPassType',
    tg.workPassExpiryDate AS 'tg.workPassExpiryDate',
    toYearMonthDay(SUM(TIMESTAMPDIFF(DAY, ss.startDate, IFNULL(ss.endDate, now())))) AS 'tg.estimatedLengthOfService',
    tg.id AS 'touristGuideId'
FROM tourist_guides tg
LEFT JOIN types bc ON bc.code = birthCountryCode
LEFT JOIN types he ON he.code = highestEduLevelCode
LEFT JOIN types ms ON ms.code = maritalStatusCode
LEFT JOIN types na ON na.code = nationalityCode
LEFT JOIN types oc ON oc.code = occupationCode
LEFT JOIN types rc ON rc.code = raceCode
LEFT JOIN types rs ON rs.code = residentialStatusCode
LEFT JOIN types sl ON sl.code = salutationCode
LEFT JOIN types sx ON sx.code = sexCode
LEFT JOIN types wp ON wp.code = workPassTypeCode
LEFT JOIN addresses ma ON ma.id = mailingAddressId
LEFT JOIN addresses ra ON ra.id = registeredAddressId
LEFT JOIN tourist_guide$guiding_languages lang on tg.id = lang.touristGuideId
LEFT JOIN types gl on gl.code = lang.guidingLanguagesCode
LEFT JOIN tourist_guide$specialized_areas a on tg.id = a.touristGuideId
LEFT JOIN types ar on ar.code = a.specializedAreasCode
LEFT JOIN licences l ON l.touristGuideId = tg.id
LEFT JOIN status_spans ss ON (ss.licenceId = l.id AND ss.statusCode = 'TG_A')
GROUP BY tg.id;

[(asg.) tg_assignments]:
SELECT l.licenceNo AS 'asg.licenceNo',
    tg.name AS 'asg.tgName',
    tg.uin AS 'asg.tgUin',
    asg.startDate AS 'asg.startDate',
    asg.endDate AS 'asg.endDate',
    asg.feeReceived AS 'asg.feeReceived',
	asg.companyName AS 'asg.companyName',
    es.label AS 'asg.employmentSource',
    asg.employmentSourceTypeOther AS 'asg.employmentSourceTypeOther',
    la.label AS 'asg.language',
    at.label AS 'asg.type',
    asg.tourTypeOther AS 'asg.tourTypeOther',
    COUNT(asd.tgAssignmentId) AS 'asg.totalNoOfAssignments',
    SUM(asd.noOfHours) AS 'asg.totalNoOfHours',
    l.id AS licenceId,
    asg.id AS tgAssignmentId
FROM tg_assignments asg
LEFT JOIN tourist_guides tg ON tg.id = asg.touristGuideId
LEFT JOIN licences l ON l.touristGuideId = tg.id
LEFT JOIN types es on es.code = asg.employmentSourceCode
LEFT JOIN types la on la.code = asg.languageCode
LEFT JOIN types at on at.code = asg.typeCode
LEFT JOIN tg_assignment_dates asd ON asg.id = asd.tgAssignmentId
WHERE asg.isDeleted = false
GROUP BY asg.id;

[(asgd.) tg_assignments-dates]:
SELECT l.licenceNo AS 'asgd.licenceNo',
    tg.name AS 'asgd.tgName',
    tg.uin AS 'asgd.tgUin',
    asgd.date AS 'asgd.assignmentDate',
    asgd.noOfHours AS 'asgd.noOfHours',
    tgAssignmentId
FROM tg_assignment_dates asgd
INNER JOIN tg_assignments asg ON asgd.tgAssignmentId = asg.id
LEFT JOIN tourist_guides tg ON tg.id = asg.touristGuideId
LEFT JOIN licences l ON l.touristGuideId = tg.id
WHERE asg.isDeleted = false;

[(cdd.) tg_candidates]:
SELECT cdd.uin AS 'cdd.cddUin',
	cdd.formerUin AS 'cdd.cddFormerUin',
    l.licenceNo AS 'cdd.licenceNo',
    cdr.email AS 'cdd.lastResultEmail',
    cdr.examDate AS 'cdd.lastResultExamDate',
    cdr.name AS 'cdd.cddName',
    gl.label AS 'cdd.lastResultGuidingLanguage',
    res.label AS 'cdd.lastResult',
	iti.label AS 'cdd.lastResultSelectedItinerary',
	sa.label AS 'cdd.lastResultSpecializedArea',
    ti.label AS 'cdd.lastResultGuidingCategory',
    cdr.assessor AS 'cdd.lastResultAssessor',
    cdr.chiefAssessor AS 'cdd.lastResultChiefAssessor',
    cdr.deputyChiefAssessor AS 'cdd.lastResultDeputyChiefAssessor',
    cdr.remarks AS 'cdd.lastResultRemarks',
    cdr.directIssuanceDate AS 'cdd.lastResultDirectIssuanceDate',
    GROUP_CONCAT(dgl.label SEPARATOR ', ') AS 'cdd.lastResultDirectIssuanceGuidingLanguages',
    IF(isDirectIssuance,'Direct Issuance','Assessment Path') AS 'cdd.lastResultExamType',
    tp.name AS 'cdd.lastResultApprovedTrainingOrganisation',
    cdd.id AS tgCandidateId
FROM tg_candidates cdd
LEFT JOIN tg_candidate_results cdr ON cdr.id = cdd.lastCandidateResultId
LEFT JOIN licences l ON l.id = cdd.licenceId
LEFT JOIN tg_training_providers tp ON tp.id = tgTrainingProviderId
LEFT JOIN types gl ON gl.code = cdr.guidingLanguageCode
LEFT JOIN types res ON res.code = cdr.resultCode
LEFT JOIN types iti ON iti.code = cdr.selectedItineraryCode
LEFT JOIN types sa ON sa.code = cdr.specializedAreaCode
LEFT JOIN types ti ON ti.code = cdr.tierCode
LEFT JOIN tg_candidate_result$di_guiding_languages digl ON cdd.lastCandidateResultId = digl.tgCandidateResultId
LEFT JOIN types dgl ON dgl.code = digl.diGuidingLanguagesCode
GROUP BY cdd.id;

[(cddr.) tg_candidate_results]:
SELECT cdd.uin AS 'cddr.cddUin',
	cddr.email AS 'cddr.email',
    examDate AS 'cddr.examDate',
    cddr.name AS 'cddr.cddName',
    gl.label AS 'cddr.guidingLanguage',
    res.label AS 'cddr.result',
	iti.label AS 'cddr.selectedItinerary',
	sa.label AS 'cddr.specializedArea',
    ti.label AS 'cddr.tier',
    assessor AS 'cddr.assessor',
    chiefAssessor AS 'cddr.chiefAssessor',
    deputyChiefAssessor AS 'cddr.deputyChiefAssessor',
    remarks AS 'cddr.remarks',
    directIssuanceDate AS 'cddr.directIssuanceDate',
    GROUP_CONCAT(dgl.label SEPARATOR ', ') AS 'cddr.directIssuanceGuidingLanguages',
    IF(isDirectIssuance,'Direct Issuance','Assessment Path') AS 'cddr.examType',
    tp.name AS 'cddr.approvedTrainingOrganisation',
    cddr.id AS tgCandidateResultId,
    tgCandidateId,
    tgTrainingProviderId
FROM tg_candidate_results cddr
LEFT JOIN tg_candidates cdd ON cdd.id = tgCandidateId
LEFT JOIN tg_training_providers tp ON tp.id = tgTrainingProviderId
LEFT JOIN types gl ON gl.code = guidingLanguageCode
LEFT JOIN types res ON res.code = resultCode
LEFT JOIN types iti ON iti.code = selectedItineraryCode
LEFT JOIN types sa ON sa.code = specializedAreaCode
LEFT JOIN types ti ON ti.code = tierCode
LEFT JOIN tg_candidate_result$di_guiding_languages digl on cddr.id = digl.tgCandidateResultId
LEFT JOIN types dgl on dgl.code = digl.diGuidingLanguagesCode
GROUP BY cddr.id;

[(cdrf.) tg_candidate_result-files]:
SELECT cdd.uin AS 'cdrf.cddUin',
    cdr.name AS 'cdrf.cddName',
    f.filename AS 'cdrf.fileName',
    f.size AS 'cdrf.fileSize',
    cdrf.tgCandidateResultId
FROM tg_candidate_result$files cdrf
LEFT JOIN tg_candidate_results cdr ON cdr.id = cdrf.tgCandidateResultId
LEFT JOIN tg_candidates cdd ON cdd.id = cdr.tgCandidateId
LEFT JOIN files f ON f.id = cdrf.filesId;

[(cse.) tg_courses]:
SELECT cse.name AS 'cse.name',
	cse.approvedStartDate AS 'cse.approvedStartDate',
    cse.approvedEndDate AS 'cse.approvedEndDate',
    cse.noOfHours AS 'cse.noOfHours',
    cat.label AS 'cse.category',
    lang.label AS 'cse.language',
    t.label AS 'cse.type',
    tp.name AS 'cse.tgTrainingProviderName',
    run.noOfRuns AS 'cse.noOfRuns',
    COUNT(DISTINCT det.touristGuideId) AS 'cse.noOfTGs',
    cse.tgTrainingProviderId,
    cse.code AS tgCourseCode
FROM tg_courses cse
LEFT JOIN types cat ON cat.code = cse.CategoryCode
LEFT JOIN types lang ON lang.code = cse.languageCode
LEFT JOIN types t ON t.code = cse.typeCode
LEFT JOIN tg_training_providers tp ON tp.id = tgTrainingProviderId
LEFT JOIN (
	SELECT cse.name, languageCode, cse.tgTrainingProviderId, count(*) AS 'noOfRuns'
    FROM tg_courses cse
    WHERE cse.isDeleted = false
    GROUP BY cse.name, languageCode, cse.tgTrainingProviderId
) AS run ON run.name = cse.name
LEFT JOIN tg_course_attendances atd ON atd.tgCourseCode = cse.code
LEFT JOIN tg_course_attendance_details det ON (atd.id = det.tgCourseAttendanceId AND det.isDeleted = false)
WHERE cse.isDeleted = false
GROUP BY cse.code;

[(tca.) tg_course_attendances]:
SELECT cse.name AS 'tca.courseName',
    tca.attendedDate AS 'tca.attendedDate',
    tca.attendedEndDate AS 'tca.attendedEndDate',
    tca.id AS tgCourseAttendanceId,
    tca.tgCourseCode
FROM tg_course_attendances tca
LEFT JOIN applications a ON a.id = tca.applicationId
LEFT JOIN tg_courses cse ON cse.code = tca.tgCourseCode
WHERE tca.isDeleted = false AND a.isDeleted = false AND a.isDraft = false;

[(tcaf.) tg_course_attendance-files]:
SELECT cse.name AS 'tcaf.courseName',
	a.applicationNo AS 'tcaf.applicationNo',
    f.filename AS 'tcaf.fileName',
    f.size AS 'tcaf.fileSize',
    tcaf.tgCourseAttendanceId
FROM tg_course_attendance$files tcaf
LEFT JOIN tg_course_attendances tca ON tca.id = tcaf.tgCourseAttendanceId
LEFT JOIN applications a ON a.id = tca.applicationId
LEFT JOIN tg_courses cse ON cse.code = tca.tgCourseCode
LEFT JOIN files f ON f.id = tcaf.filesId;

[(det.) tg_course_attendance_details]:
SELECT l.licenceNo AS 'det.licenceNo',
	tg.name AS 'det.tgName',
	tg.uin AS 'det.tgUin',
    cse.name AS 'det.courseName',
    det.maxScore AS 'det.maxScore',
    det.score AS 'det.score',
    atd.label AS 'det.attendance',
    res.label AS 'det.result',
    t.label AS 'det.type',
    l.id AS licenceId,
    det.tgCourseAttendanceId
FROM tg_course_attendance_details det
LEFT JOIN tg_course_attendances tca ON tca.id = det.tgCourseAttendanceId
LEFT JOIN tg_courses cse ON cse.code = tca.tgCourseCode
LEFT JOIN tourist_guides tg ON tg.id = det.touristGuideId
LEFT JOIN licences l ON l.touristGuideId = tg.id
LEFT JOIN types atd ON atd.code = attendanceCode
LEFT JOIN types res ON res.code = resultCode
LEFT JOIN types t ON t.code = typeCode
WHERE det.isDeleted = false;

[(tp.) tg_training_providers]:
SELECT tp.contactNo AS 'tp.contactNo',
    tp.contactPerson AS 'tp.contactPerson',
    tp.email AS 'tp.email',
    IF(tp.isMrc,'Yes','No') AS 'tp.isMrc',
	IF(tp.isPdc,'Yes','No') AS 'tp.isPdc',
    IF(tp.isAto,'Yes','No') AS 'tp.isAto',
    tp.name AS 'tp.name',
    tp.uen AS 'tp.uen',
    tp.id AS tgTrainingProviderId
FROM tg_training_providers tp
WHERE tp.isDeleted = false AND tp.statusCode = 'USER_A';

[(tlc.) tg_licence_cancellations]:
SELECT a.applicationNo AS 'tlc.appNo',
    a.submissionDate AS 'tlc.appSubmissionDate',
    ws.label AS 'tlc.appStatus',
    w.createdDate AS 'tlc.appStatusDate',
	l.licenceNo AS 'tlc.licenceNo',
	tg.name AS 'tlc.tgName',
	tg.uin AS 'tlc.tgUin',
	a.licenceId
FROM tg_licence_cancellations tlc
LEFT JOIN applications a ON a.id = tlc.applicationId
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN licences l ON l.id = a.licenceId
LEFT JOIN tourist_guides tg ON tg.id = l.touristGuideId
WHERE a.isDeleted = false AND a.isDraft = false;

[(new.) tg_licence_creations]:
SELECT a.applicationNo AS 'new.appNo',
    a.submissionDate AS 'new.appSubmissionDate',
    ws.label AS 'new.appStatus',
    w.createdDate AS 'new.appStatusDate',
    lp.label AS 'new.licencePrintStatus',
	l.licenceNo AS 'new.licenceNo',
	new.name AS 'new.tgName',
	new.uin AS 'new.tgUin',
    new.aliasName AS 'new.aliasName',
    new.appFeeBillRefNo AS 'new.appFeeBillRefNo',
    new.dob AS 'new.dob',
    new.emailAddress AS 'new.emailAddress',
    new.employerName AS 'new.employerName',
    new.enforcementOutcome AS 'new.enforcementOutcome',
    IF(new.hasConsentEmailAddress,'Yes','No') AS 'new.hasConsentEmailAddress',
    IF(new.hasConsentMobileNo,'Yes','No') AS 'new.hasConsentMobileNo',
    IF(new.isMyInfoPopulated,'Yes','No') AS 'new.isMyInfoPopulated',
    new.mobileNo AS 'new.mobileNo',
    new.name AS 'new.name',
    new.occupationOther AS 'new.occupationOther',
    new.offenceDate AS 'new.offenceDate',
    new.offenceDeclaredDate AS 'new.offenceDeclaredDate',
    new.offenceType AS 'new.offenceType',
    new.uin AS 'new.uin',
    new.workpassExpiryDate AS 'new.workpassExpiryDate',
	bc.label AS 'new.birthCountry',
    he.label AS 'new.highestEduLevel',
    ms.label AS 'new.maritalStatus',
    na.label AS 'new.nationality',
    oc.label AS 'new.occupation',
    rc.label AS 'new.race',
    rs.label AS 'new.residentialStatus',
    sl.label AS 'new.salutation',
    sx.label AS 'new.sex',
    wp.label AS 'new.workPassType',
    mp.label AS 'new.medisavePaymentStatus',
    oa.block AS 'new.opAddrBlk',
    oa.street AS 'new.opAddrSt',
    oa.building AS 'new.opAddrBldg',
    oa.floor AS 'new.opAddrLvl',
    oa.unit AS 'new.opAddrUnit',
    oa.postal AS 'new.opAddrPostal',
    oa.foreignLine1 AS 'new.opAddrForeign1',
    oa.foreignLine2 AS 'new.opAddrForeign2',
    oa.foreignLine3 AS 'new.opAddrForeign3',
    ra.block AS 'new.regAddrBlk',
    ra.street AS 'new.regAddrSt',
    ra.building AS 'new.regAddrBldg',
    ra.floor AS 'new.regAddrLvl',
    ra.unit AS 'new.regAddrUnit',
    ra.postal AS 'new.regAddrPostal',
    ra.foreignLine1 AS 'new.regAddrForeign1',
    ra.foreignLine2 AS 'new.regAddrForeign2',
    ra.foreignLine3 AS 'new.regAddrForeign3',
    u.tgCandidateId
FROM tg_licence_creations new
LEFT JOIN applications a ON a.id = new.applicationId
LEFT JOIN statuses lp ON lp.code = a.licencePrintStatusCode
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN licences l ON l.id = a.licenceId
LEFT JOIN tourist_guides tg ON tg.id = l.touristGuideId
LEFT JOIN types bc ON bc.code = new.birthCountryCode
LEFT JOIN types he ON he.code = new.highestEduLevelCode
LEFT JOIN types ms ON ms.code = new.maritalStatusCode
LEFT JOIN types na ON na.code = new.nationalityCode
LEFT JOIN types oc ON oc.code = new.occupationCode
LEFT JOIN types rc ON rc.code = new.raceCode
LEFT JOIN types rs ON rs.code = new.residentialStatusCode
LEFT JOIN types sl ON sl.code = new.salutationCode
LEFT JOIN types sx ON sx.code = new.sexCode
LEFT JOIN types wp ON wp.code = new.workPassTypeCode
LEFT JOIN statuses mp ON mp.code = new.medisavePaymentStatusCode
LEFT JOIN addresses oa ON oa.id = new.operatingAddressId
LEFT JOIN addresses ra ON ra.id = new.registeredAddressId
LEFT JOIN users u ON u.id = new.userId
WHERE a.isDeleted = false AND a.isDraft = false;

[(ren.) tg_licence_renewals]:
SELECT a.applicationNo AS 'ren.appNo',
    a.submissionDate AS 'ren.appSubmissionDate',
    ws.label AS 'ren.appStatus',
    w.createdDate AS 'ren.appStatusDate',
    lp.label AS 'ren.licencePrintStatus',
	l.licenceNo AS 'ren.licenceNo',
	tg.name AS 'ren.tgName',
	tg.uin AS 'ren.tgUin',
    ren.appFeeBillRefNo AS 'ren.appFeeBillRefNo',
    IF(tg.uin like 'S%' or tg.uin like 'T%', IF(ren.cpfDeclared,'Yes','No'), 'NA') AS 'ren.cpfDeclared',
    ren.enforcementOutcome AS 'ren.enforcementOutcome',
    IF(ren.hasConsentEmailAddress,'Yes','No') AS 'ren.hasConsentEmailAddress',
    IF(ren.hasConsentMobileNo,'Yes','No') AS 'ren.hasConsentMobileNo',
    IF(ren.hasNoAssignment,'Yes','No') AS 'ren.hasNoAssignment',
    IF(ren.hasRfaCpf,'Yes','No') AS 'ren.hasRfaCpf',
    IF(ren.hasRfaMedicalReport,'Yes','No') AS 'ren.hasRfaMedicalReport',
    IF(ren.hasRfaNewPhoto,'Yes','No') AS 'ren.hasRfaNewPhoto',
    IF(ren.hasRfaWorkPass,'Yes','No') AS 'ren.hasRfaWorkPass',
    ren.licenceExpiryDate AS 'ren.renewalCycleExpiryDate',
    ren.licenceStartDate AS 'ren.renewalCycleStartDate',
    ren.medicalDate AS 'ren.medicalDate',
    ren.offenceDate AS 'ren.offenceDate',
    ren.offenceDeclaredDate AS 'ren.offenceDeclaredDate',
    ren.offenceType AS 'ren.offenceType',
    ren.previousLicenceExpiryDate AS 'ren.prevCycleExpiryDate',
    ren.previousLicenceStartDate AS 'ren.prevCycleStartDate',
    rt.label AS 'ren.type',
    mp.label AS 'ren.medisavePaymentStatus',
    IF(TIMESTAMPDIFF(YEAR, tg.dob, CURDATE()) < 65, 'NA', IF(hasMedicalReport.applicationId,'Yes','No')) AS 'ren.hasMedicalReport',
    IF(hasNewPhoto.applicationId,'Yes','No') AS 'ren.hasNewPhoto',
    IF(tg.uin like 'S%' or tg.uin like 'T%', 'NA', IF(hasWP.applicationId,'Yes','No')) AS 'ren.hasWorkPass',
    a.licenceId
FROM tg_licence_renewals ren
LEFT JOIN applications a ON a.id = ren.applicationId
LEFT JOIN statuses lp ON lp.code = a.licencePrintStatusCode
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN licences l ON l.id = a.licenceId
LEFT JOIN tourist_guides tg ON tg.id = l.touristGuideId
LEFT JOIN types rt ON rt.code = ren.typeCode
LEFT JOIN statuses mp ON mp.code = ren.medisavePaymentStatusCode
LEFT JOIN (
	SELECT applicationId, documentTypeCode from application_files af WHERE documentTypeCode = 'TG_DOC_MED'
) AS hasMedicalReport ON hasMedicalReport.applicationId = ren.applicationId
LEFT JOIN (
	SELECT applicationId, documentTypeCode from application_files af WHERE documentTypeCode = 'TG_DOC_PHOTO'
) AS hasNewPhoto ON hasNewPhoto.applicationId = ren.applicationId
LEFT JOIN (
	SELECT applicationId, documentTypeCode from application_files af WHERE documentTypeCode = 'TG_DOC_WP'
) AS hasWP ON hasWP.applicationId = ren.applicationId
WHERE a.isDeleted = false AND a.isDraft = false;

[(exp.) expiring_licences]:
SELECT licenceNo AS 'exp.licenceNo',
	tg.name AS 'exp.tgName',
    tg.uin AS 'exp.tgUin',
    tg.dob AS 'exp.dob',
    tg.mobileNo AS 'exp.mobileNo',
    tg.emailAddress AS 'exp.emailAddress',
    GROUP_CONCAT(DISTINCT gl.label SEPARATOR ', ') AS 'exp.guidingLanguages',
    lic.ceasedDate AS 'exp.ceasedDate',
    lic.expiryDate AS 'exp.expiryDate',
    IF(lic.isPendingCessation,'Yes','No') AS 'exp.isPendingCessation',
    lic.issueDate AS 'exp.issueDate',
    lic.startDate AS 'exp.startDate',
    s.label AS 'exp.status',
    t.label AS 'exp.tier',
    GROUP_CONCAT(DISTINCT ar.label SEPARATOR ', ') AS 'exp.specializedAreas',
    IFNULL(currentCycleNoOfAssignment, 0) as 'exp.currentCycleNoOfAssignment',
    IF(ISNULL(rnw.id), null, IF(rnw.hasNoAssignment,'Yes','No')) AS 'exp.hasNoAssignment',
    IF(ISNULL(rnw.id), null, IF(tg.uin like 'S%' or tg.uin like 'T%', IF(rnw.cpfDeclared,'Yes','No'), 'NA')) AS 'exp.cpfDeclared',
    IF(ISNULL(rnw.id), null, IF(TIMESTAMPDIFF(YEAR, tg.dob, CURDATE()) < 65, 'NA', IF(hasMedicalReport.applicationId,'Yes','No'))) AS 'exp.hasMedicalReport',
    IF(ISNULL(rnw.id), null, IF(hasNewPhoto.applicationId,'Yes','No')) AS 'exp.hasNewPhoto',
    IF(ISNULL(rnw.id), null, IF(tg.uin like 'S%' or tg.uin like 'T%', 'NA', IF(hasWP.applicationId,'Yes','No'))) AS 'exp.hasWorkPass',
    firstMRC.approvedStartDate AS 'exp.firstMRCStartDate',
    firstMRC.attendedDate AS 'exp.firstMRCAttendedDate',
    firstMRC.score AS 'exp.firstMRCScore',
    lastMRC.approvedStartDate AS 'exp.lastMRCStartDate',
    lastMRC.attendedDate AS 'exp.lastMRCAttendedDate',
    lastMRC.score AS 'exp.lastMRCScore',
    currentCyclePDC.totalHours AS 'exp.currentCyclePDCHours',
    ps.label AS 'exp.paymentStatus',
    IF(app.isDraft, 'Draft', ws.label) AS 'exp.appStatus',
	lp.label AS 'exp.licencePrintStatus',
    rs.label AS 'exp.residentialStatus',
    ra.block AS 'exp.regAddrBlk',
    ra.street AS 'exp.regAddrSt',
    ra.building AS 'exp.regAddrBldg',
    ra.floor AS 'exp.regAddrLvl',
    ra.unit AS 'exp.regAddrUnit',
    ra.postal AS 'exp.regAddrPostal',
    ra.foreignLine1 AS 'exp.regAddrForeign1',
    ra.foreignLine2 AS 'exp.regAddrForeign2',
    ra.foreignLine3 AS 'exp.regAddrForeign3'
FROM licences lic
LEFT JOIN tourist_guides tg ON tg.id = lic.touristGuideId
LEFT JOIN tourist_guide$specialized_areas a on tg.id = a.touristGuideId
LEFT JOIN tourist_guide$guiding_languages lang on tg.id = lang.touristGuideId
LEFT JOIN statuses s ON s.code = statusCode
LEFT JOIN types t ON t.code = tierCode
LEFT JOIN types ar on ar.code = a.specializedAreasCode
LEFT JOIN types gl on gl.code = lang.guidingLanguagesCode
LEFT JOIN (
	SELECT asg.touristGuideId, COUNT(date.tgAssignmentId) as currentCycleNoOfAssignment
	FROM tg_assignments asg
	LEFT JOIN tg_assignment_dates date on asg.id = date.tgAssignmentId
	LEFT JOIN licences lic on lic.touristGuideId = asg.touristGuideId
	WHERE asg.startDate >= lic.startDate
    GROUP BY asg.touristGuideId
) AS currentCycleAsg ON currentCycleAsg.touristGuideId = tg.id
LEFT JOIN (
	SELECT touristGuideId, atd.attendedDate, score, resultCode, cse.name, cse.approvedStartDate FROM tg_course_attendance_details det
	LEFT JOIN tg_course_attendances atd ON atd.id = det.tgCourseAttendanceId
	LEFT JOIN tg_courses cse ON cse.code = atd.tgCourseCode
    WHERE det.id IN (
		SELECT MIN(det.id) FROM tg_course_attendance_details det
			LEFT JOIN tg_course_attendances atd ON atd.id = det.tgCourseAttendanceId
			LEFT JOIN tg_courses cse ON cse.code = atd.tgCourseCode
			WHERE det.isDeleted = false AND atd.isDeleted = false AND cse.isDeleted = false AND cse.typeCode = 'TP_CSE_M'
			GROUP BY touristGuideId
    )
) AS firstMRC ON firstMRC.touristGuideId = tg.id
LEFT JOIN (
	SELECT touristGuideId, atd.attendedDate, score, resultCode, cse.name, cse.approvedStartDate FROM tg_course_attendance_details det
	LEFT JOIN tg_course_attendances atd ON atd.id = det.tgCourseAttendanceId
	LEFT JOIN tg_courses cse ON cse.code = atd.tgCourseCode
    WHERE det.id IN (
		SELECT max(det.id) FROM tg_course_attendance_details det
			LEFT JOIN tg_course_attendances atd ON atd.id = det.tgCourseAttendanceId
			LEFT JOIN tg_courses cse ON cse.code = atd.tgCourseCode
			WHERE det.isDeleted = false AND atd.isDeleted = false AND cse.isDeleted = false AND cse.typeCode = 'TP_CSE_M'
			GROUP BY touristGuideId
			HAVING COUNT(touristGuideId) > 1
    )
) AS lastMRC ON lastMRC.touristGuideId = tg.id
LEFT JOIN (
	SELECT MAX(ren.id) AS latestAppId, a.licenceId
		FROM tg_licence_renewals ren
		LEFT JOIN applications a ON a.id = ren.applicationId
		WHERE a.isDeleted = false
		GROUP BY a.licenceId
) AS latestRnw ON latestRnw.licenceId = lic.id
LEFT JOIN tg_licence_renewals rnw ON rnw.id = latestRnw.latestAppId
LEFT JOIN applications app ON rnw.applicationId = app.id
LEFT JOIN workflow_actions w ON w.id = app.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN statuses lp ON lp.code = app.licencePrintStatusCode
LEFT JOIN (
	SELECT det.touristGuideId, SUM(cse.noOfHours) AS totalHours FROM tg_course_attendance_details det
		LEFT JOIN tg_course_attendances atd ON atd.id = det.tgCourseAttendanceId
		LEFT JOIN tg_courses cse ON cse.code = atd.tgCourseCode
		LEFT JOIN licences lic on lic.touristGuideId = det.touristGuideId
		WHERE det.isDeleted = false AND atd.isDeleted = false AND cse.isDeleted = false AND cse.typeCode = 'TP_CSE_P'
		AND atd.attendedDate >= lic.startDate
		GROUP BY det.touristGuideId
) AS currentCyclePDC ON currentCyclePDC.touristGuideId = tg.id
LEFT JOIN (
	SELECT applicationId, documentTypeCode from application_files af WHERE documentTypeCode = 'TG_DOC_MED'
) AS hasMedicalReport ON hasMedicalReport.applicationId = rnw.applicationId
LEFT JOIN (
	SELECT applicationId, documentTypeCode from application_files af WHERE documentTypeCode = 'TG_DOC_PHOTO'
) AS hasNewPhoto ON hasNewPhoto.applicationId = rnw.applicationId
LEFT JOIN (
	SELECT applicationId, documentTypeCode from application_files af WHERE documentTypeCode = 'TG_DOC_WP'
) AS hasWP ON hasWP.applicationId = rnw.applicationId
LEFT JOIN payment_requests req ON req.billRefNo = rnw.appFeeBillRefNo
LEFT JOIN statuses ps ON req.statusCode = ps.code
LEFT JOIN addresses ra ON ra.id = tg.registeredAddressId
LEFT JOIN types rs ON rs.code = tg.residentialStatusCode
WHERE lic.taTgType = 'TG'
GROUP BY tg.id;

[(rep.) tg_licence_replacements]:
SELECT a.applicationNo AS 'rep.appNo',
    a.submissionDate AS 'rep.appSubmissionDate',
    ws.label AS 'rep.appStatus',
    w.createdDate AS 'rep.appStatusDate',
    lp.label AS 'rep.licencePrintStatus',
	l.licenceNo AS 'rep.licenceNo',
	tg.name AS 'rep.tgName',
	tg.uin AS 'rep.tgUin',
    rep.appFeeBillRefNo AS 'rep.appFeeBillRefNo',
    a.licenceId
FROM tg_licence_replacements rep
LEFT JOIN applications a ON a.id = rep.applicationId
LEFT JOIN statuses lp ON lp.code = a.licencePrintStatusCode
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN licences l ON l.id = a.licenceId
LEFT JOIN tourist_guides tg ON tg.id = l.touristGuideId
WHERE a.isDeleted = false AND a.isDraft = false;

[(tpu.) tg_person_updates]:
SELECT a.applicationNo AS 'tpu.appNo',
    a.submissionDate AS 'tpu.appSubmissionDate',
    ws.label AS 'tpu.appStatus',
    w.createdDate AS 'tpu.appStatusDate',
    lp.label AS 'tpu.licencePrintStatus',
	l.licenceNo AS 'tpu.licenceNo',
	tpu.name AS 'tpu.tgName',
	tpu.uin AS 'tpu.tgUin',
    tpu.aliasName AS 'tpu.aliasName',
    tpu.appFeeBillRefNo AS 'tpu.appFeeBillRefNo',
    tpu.dob AS 'tpu.dob',
    tpu.emailAddress AS 'tpu.emailAddress',
    tpu.employerName AS 'tpu.employerName',
    tpu.enforcementOutcome AS 'tpu.enforcementOutcome',
    IF(tpu.hasConsentEmailAddress,'Yes','No') AS 'tpu.hasConsentEmailAddress',
	IF(tpu.hasConsentMobileNo,'Yes','No') AS 'tpu.hasConsentMobileNo',
	IF(tpu.isMyInfoPopulated,'Yes','No') AS 'tpu.isMyInfoPopulated',
   	tpu.mobileNo AS 'tpu.mobileNo',
   	tpu.name AS 'tpu.name',
   	tpu.occupationOther AS 'tpu.occupationOther',
   	tpu.offenceDate AS 'tpu.offenceDate',
   	tpu.offenceDeclaredDate AS 'tpu.offenceDeclaredDate',
   	tpu.offenceType AS 'tpu.offenceType',
   	tpu.uin AS 'tpu.uin',
   	tpu.workpassExpiryDate AS 'tpu.workpassExpiryDate',
   	bc.label AS 'tpu.birthCountry',
   	he.label AS 'tpu.highestEduLevel',
   	ms.label AS 'tpu.maritalStatus',
   	na.label AS 'tpu.nationality',
   	oc.label AS 'tpu.occupation',
   	rc.label AS 'tpu.race',
   	rs.label AS 'tpu.residentialStatus',
   	sl.label AS 'tpu.salutation',
   	sx.label AS 'tpu.sex',
   	wp.label AS 'tpu.workPassType',
    oa.block AS 'tpu.opAddrBlk',
    oa.street AS 'tpu.opAddrSt',
    oa.building AS 'tpu.opAddrBldg',
    oa.floor AS 'tpu.opAddrLvl',
    oa.unit AS 'tpu.opAddrUnit',
    oa.postal AS 'tpu.opAddrPostal',
    oa.foreignLine1 AS 'tpu.opAddrForeign1',
    oa.foreignLine2 AS 'tpu.opAddrForeign2',
    oa.foreignLine3 AS 'tpu.opAddrForeign3',
    ra.block AS 'tpu.regAddrBlk',
    ra.street AS 'tpu.regAddrSt',
    ra.building AS 'tpu.regAddrBldg',
    ra.floor AS 'tpu.regAddrLvl',
    ra.unit AS 'tpu.regAddrUnit',
    ra.postal AS 'tpu.regAddrPostal',
    ra.foreignLine1 AS 'tpu.regAddrForeign1',
    ra.foreignLine2 AS 'tpu.regAddrForeign2',
    ra.foreignLine3 AS 'tpu.regAddrForeign3',
    a.licenceId
FROM tg_person_updates tpu
INNER JOIN applications a ON a.id = tpu.applicationId
LEFT JOIN statuses lp ON lp.code = a.licencePrintStatusCode
LEFT JOIN workflow_actions w ON w.id = a.lastActionId
LEFT JOIN statuses ws ON ws.code = w.statusCode
LEFT JOIN licences l ON l.id = a.licenceId
LEFT JOIN tourist_guides tg ON tg.id = l.touristGuideId
LEFT JOIN types bc ON bc.code = tpu.birthCountryCode
LEFT JOIN types he ON he.code = tpu.highestEduLevelCode
LEFT JOIN types ms ON ms.code = tpu.maritalStatusCode
LEFT JOIN types na ON na.code = tpu.nationalityCode
LEFT JOIN types oc ON oc.code = tpu.occupationCode
LEFT JOIN types rc ON rc.code = tpu.raceCode
LEFT JOIN types rs ON rs.code = tpu.residentialStatusCode
LEFT JOIN types sl ON sl.code = tpu.salutationCode
LEFT JOIN types sx ON sx.code = tpu.sexCode
LEFT JOIN types wp ON wp.code = tpu.workPassTypeCode
LEFT JOIN addresses oa ON oa.id = tpu.operatingAddressId
LEFT JOIN addresses ra ON ra.id = tpu.registeredAddressId
WHERE a.isDeleted = false AND a.isDraft = false;

[(mlpt.) tg_mlpts]:
SELECT mlpt.mlptEndDate AS 'mlpt.mlptEndDate',
    mlpt.mlptStartDate AS 'mlpt.mlptStartDate',
    mlpt.name AS 'mlpt.name',
    mlpt.regEndDate AS 'mlpt.regEndDate',
    mlpt.regStartDate AS 'mlpt.regStartDate',
    mlpt.remarks AS 'mlpt.remarks',
    al.label AS 'mlpt.allocationStatus',
    mlpt.id AS tgMlptId
FROM tg_mlpts mlpt
LEFT JOIN statuses al ON al.code = mlpt.allocationStatusCode
WHERE mlpt.isDeleted = false;

[(slot.) tg_mlpt_slots]:
SELECT mlpt.name AS 'slot.mlptName',
	l.licenceNo AS 'slot.licenceNo',
	tg.name AS 'slot.tgName',
	tg.uin AS 'slot.tgUin',
    slot.assessor AS 'slot.assessor',
    slot.chiefAssessor AS 'slot.chiefAssessor',
    slot.resultSentDate AS 'slot.resultSentDate',
    date(slot.startTime) AS 'slot.testDate',
    concat(time_format(startTime, '%H:%i'), ' - ', time_format((startTime + INTERVAL 30 MINUTE), '%H:%i')) AS 'slot.time',
    gl.label AS 'slot.testLanguage',
	res.label AS 'slot.resultStatus',
    slot.tgLicenceMlptRegistrationId
FROM tg_mlpt_slots slot
LEFT JOIN tg_licence_mlpt_registrations reg ON reg.id = slot.tgLicenceMlptRegistrationId
LEFT JOIN applications a ON a.id = reg.applicationId
LEFT JOIN licences l ON l.id = a.licenceId
LEFT JOIN tourist_guides tg ON tg.id = l.touristGuideId
LEFT JOIN tg_mlpts mlpt ON mlpt.id = reg.tgMlptId
LEFT JOIN types gl ON gl.code = slot.guidingLanguageCode
LEFT JOIN statuses res ON res.code = slot.resultStatusCode
WHERE a.isDeleted = false AND a.isDraft = false AND mlpt.isDeleted = false;

[(mreg.) tg_mlpt_registrations]:
SELECT mlpt.name AS 'mreg.mlptName',
	l.licenceNo AS 'mreg.licenceNo',
	tg.name AS 'mreg.tgName',
	tg.uin AS 'mreg.tgUin',
    mreg.appFeeBillRefNo AS 'mreg.mlptFeeBillRefNo',
    IF(mreg.isForReinstatement,'Yes','No') AS 'mreg.isForReinstatement',
    mreg.printFeeBillRefNo AS 'mreg.licencePrintFeeBillRefNo',
    lp.licencePrintStatus AS 'mreg.licencePrintStatus',
    a.licenceId,
    mreg.tgMlptId,
    mreg.id AS tgLicenceMlptRegistrationId
FROM tg_licence_mlpt_registrations mreg
INNER JOIN tg_mlpts mlpt ON mlpt.id = mreg.tgMlptId
LEFT JOIN applications a ON a.id = mreg.applicationId
LEFT JOIN (
	SELECT m.id AS 'tgMlptId', a.licenceId, ps.label AS 'licencePrintStatus'
    FROM applications a
    LEFT JOIN statuses ps on ps.code = licencePrintStatusCode
    LEFT JOIN tg_licence_mlpt_registrations mreg ON mreg.applicationId = a.id
    LEFT JOIN tg_mlpts m ON mreg.tgMlptId = m.id
    WHERE typeCode = 'TG_APP_MLPT_REGISTRATION' AND (licencePrintStatusCode is not null OR licencePrintStatusCode != 'PRINT_N')
    GROUP BY m.id, a.licenceId
) AS lp ON lp.tgMlptId = mlpt.id AND lp.licenceId = a.licenceId
LEFT JOIN licences l ON l.id = a.licenceId
LEFT JOIN tourist_guides tg ON tg.id = l.touristGuideId
WHERE a.isDeleted = false AND a.isDraft = false AND mlpt.isDeleted = false;


// hide internal PK/FK to only show useful business data
TAG FIELD [licenceId] WITH '$hidden';
TAG FIELD [tgCandidateId] WITH '$hidden';
TAG FIELD [tgCandidateResultId] WITH '$hidden';
TAG FIELD [tgCourseAttendanceId] WITH '$hidden';
TAG FIELD [tgCourseCode] WITH '$hidden';
TAG FIELD [tgMlptId] WITH '$hidden';
TAG FIELD [tgLicenceMlptRegistrationId] WITH '$hidden';
TAG FIELD [tgTrainingProviderId] WITH '$hidden';
TAG FIELD [lic.ceasedDate], [lic.expiryDate], [lic.issueDate], [lic.startDate], [tg.dob], [tg.offenceDeclaredDate], [tg.workPassExpiryDate],
[asg.startDate], [cdd.lastResultExamDate], [cdd.lastResultDirectIssuanceDate], [cddr.examDate], [cse.approvedStartDate], [cse.approvedEndDate],
[tca.attendedDate], [tca.attendedEndDate], [tlc.appSubmissionDate], [new.appSubmissionDate], [ren.appSubmissionDate], [rep.appSubmissionDate],
[tpu.appSubmissionDate], [mlpt.mlptStartDate], [mlpt.mlptEndDate], [mlpt.regStartDate], [mlpt.regEndDate], [slot.resultSentDate],
[exp.ceasedDate], [exp.expiryDate], [exp.issueDate], [exp.startDate], [exp.firstMRCStartDate], [exp.firstMRCAttendedDate],
[exp.lastMRCStartDate], [exp.lastMRCAttendedDate], [slot.testDate] WITH '$date';