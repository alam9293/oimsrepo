package com.wiz.security;

import java.util.Set;

import org.apache.logging.log4j.util.Strings;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

@SuppressWarnings("serial")
public class CustomAuthenticationToken extends UsernamePasswordAuthenticationToken {

	private String name;

	private String uen;

	private String roleCode;

	private String iamsIdToken;

	private String spIdToken;

	public CustomAuthenticationToken(String name, Object principal, String roleCode, String iamsIdToken, String spIdToken, Set<GrantedAuthority> authorities) {
		super(principal, null, authorities);
		this.name = getLoginIdFromAuthenticationName(name);
		this.uen = getUenFromAuthenticationName(name);
		this.roleCode = roleCode;
		this.iamsIdToken = iamsIdToken;
		this.spIdToken = spIdToken;

	}

	@Override
	public String getName() {
		return name;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public String getUen() {
		return uen;
	}

	public String getIamsIdToken() {
		return iamsIdToken;
	}

	public String getSpIdToken() {
		return spIdToken;
	}

	public void setSpIdToken(String spIdToken) {
		this.spIdToken = spIdToken;
	}

	public static String buildAuthenticationName(String loginId, String uen) {
		return loginId + (Strings.isNotEmpty(uen) ? "/" + uen : "");
	}

	public static String getLoginIdFromAuthenticationName(String name) {
		if (Strings.isNotBlank(name) && name.contains("/")) {
			return name.split("/")[0];
		} else {
			return name;
		}
	}

	public static String getUenFromAuthenticationName(String name) {
		if (Strings.isNotBlank(name) && name.contains("/")) {
			return name.split("/")[1];
		} else {
			return null;
		}
	}

}
