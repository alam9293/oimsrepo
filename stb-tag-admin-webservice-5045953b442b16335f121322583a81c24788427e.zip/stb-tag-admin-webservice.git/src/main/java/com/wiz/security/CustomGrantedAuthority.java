package com.wiz.security;

import org.springframework.security.core.GrantedAuthority;

@SuppressWarnings("serial")
public class CustomGrantedAuthority implements GrantedAuthority {

	private String resource;

	public CustomGrantedAuthority(String resource) {
		super();
		this.resource = resource;
	}

	@Override
	public String getAuthority() {

		return this.resource;
	}

}
