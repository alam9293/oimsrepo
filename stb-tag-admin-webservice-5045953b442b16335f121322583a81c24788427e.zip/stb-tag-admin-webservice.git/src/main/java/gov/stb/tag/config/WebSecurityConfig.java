package gov.stb.tag.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.wiz.security.JWTAuthenticationFilter;

import gov.stb.tag.constant.Properties;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	Properties properties;
	@Autowired
	private AuthenticationProvider authenticationProvider;

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(HttpMethod.OPTIONS).antMatchers(HttpMethod.POST, "/api/v1/users/authenticate/*").antMatchers(HttpMethod.POST, "/api/v1/users/authenticate-spcp/**")
				.antMatchers(HttpMethod.GET, "/api/v1/users/authenticate-sso").antMatchers(HttpMethod.POST, "/api/v1/file/update-file-txf").antMatchers(HttpMethod.GET, "/api/v1/common/**")
				.antMatchers(HttpMethod.GET, "/api/v1/payment/public/**").antMatchers(HttpMethod.POST, "/api/v1/payment/public/**").antMatchers(HttpMethod.GET, "/api/v1/bulletin/public/**")
				.antMatchers(HttpMethod.GET, "/api/v1/directory/ta/**").antMatchers(HttpMethod.GET, "/api/v1/directory/tg/**").antMatchers(HttpMethod.GET, "/api/v1/test/**")
				.antMatchers(HttpMethod.POST, "/api/v1/test/**").antMatchers(HttpMethod.GET, "/api/v1/uat-test/**").antMatchers(HttpMethod.POST, "/api/v1/uat-test/**")
				.antMatchers(HttpMethod.GET, "/api/v1/iams/**").antMatchers(HttpMethod.POST, "/api/v1/iams/**").antMatchers(HttpMethod.PUT, "/api/v1/iams/**")
				.antMatchers(HttpMethod.DELETE, "/api/v1/iams/**").antMatchers(HttpMethod.GET, "/api/v1/category/public-get-all-categorys/*").antMatchers(HttpMethod.GET, "/api/v1/file/download/**");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// cors() required for spring security to populate cors headers in 401 error response
		// csrf() not required as validating via JWT Authorization header is sufficient. If the JWT is stored in cookies (i.e. multi-tab), frontend will need to do
		// Cookie-to-Header, while backend to continue validating via the header. This is because an attacker cannot read cookie value due to the same-origin policy that exists in all browsers.
		http.cors().and().csrf().disable().authorizeRequests().anyRequest().authenticated().and().addFilterBefore(new JWTAuthenticationFilter("/api/**", authenticationManager()),
				UsernamePasswordAuthenticationFilter.class);
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider);
	}
}
