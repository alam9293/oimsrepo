package gov.stb.tag.constant;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Properties extends CommonProperties {

	private transient Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${tag.url.signdoc.preload}")
	public String signdocPreloadUrl;

	@Value("${tag.url.signdoc.result.ceTaFieldReport}")
	public String signdocCeTaFieldReportResultUrl;

	@Value("${tag.url.signdoc.result.ceTaCheck}")
	public String signdocCeTaCheckResultUrl;

	@Value("${tag.conf.showDebugMessage}")
	public Boolean showDebugMessage;

	@Value("${tag.conf.email}")
	public String email;

	@Value("${tag.conf.catchAllEmail}")
	public String catchAllEmail;

	@Value("${tag.conf.env}")
	public String appEnv;

	@Value("${tag.dir.download}")
	public String downloadDir;

	@Value("${tag.proxy.enabled}")
	public Boolean tagProxyEnabled;

	@Value("${tag.proxy.host}")
	public String tagProxyHost;

	@Value("${tag.proxy.port}")
	public Integer tagProxyPort;

	@Value("${cpf.apex.enabled}")
	public Boolean cpfApexEnabled;

	@Value("${cpf.apex.timestamp.offset.secs}")
	public Integer cpfApexTimestampOffsetSecs;

	@Value("${cpf.apex.ig.l2.baseApiUrl}")
	public String cpfApexIgL2BaseApiUrl;

	@Value("${cpf.apex.ig.l2.appId}")
	public String cpfApexIgL2AppId;

	@Value("${cpf.apex.ig.l2.realm}")
	public String cpfApexIgL2Realm;

	@Value("${cpf.apex.ig.l2.version}")
	public String cpfApexIgL2Version;

	@Value("${cpf.apex.ig.l2.alias}")
	public String cpfApexIgL2Alias;

	@Value("${cpf.apex.ig.l2.password}")
	public String cpfApexIgL2Password;

	@Value("${cpf.apex.ig.l2.keyStoreFilename}")
	public String cpfApexIgL2KeyStoreFilename;

	@Value("${cpf.api.medisavePaymentStatus}")
	public String cpfApiMedisavePaymentStatus;

	@Value("${wirecard.securityKey}")
	public String wirecardSecurityKey;

	@Value("${wirecard.mid}")
	public String wirecardMid;

	@Value("${wirecard.currency}")
	public String wirecardCurrency;

	@Value("${wirecard.transType}")
	public String wirecardTransType;

	@Value("${wirecard.rcard}")
	public String wirecardRcard;

	@Value("${wirecard.version}")
	public String wirecardVersion;

	@Value("${qs.host}")
	public String qsHost;

	@Value("${qs.virtualProxy}")
	public String qsVirtualProxy;

	@Value("${qs.jks.folder}")
	public String qsJksFolder;

	@Value("${qs.jks.password}")
	public String qsJksPassword;

	@Value("${qs.url}")
	public String qsUrl;

	@Value("${qs.userDirectory}")
	public String qsUserDirectory;

	@Value("${tag.dir.upload.report-ta-placeholder}")
	public String reportTaPlaceholderPath;

	@Value("${build.info.timestamp}")
	public String buildInfoTimestamp;

	@Value("${build.info.by}")
	public String buildInfoBy;

	@Value("${tag.dir.upload.licence-return}")
	public String licenceReturnUploadDir;

	@Value("${iams.auth.username}")
	public String iamsUsername;

	@Value("${iams.auth.password}")
	public String iamsPassword;

	@Value("${iams.sso.enabled}")
	public Boolean iamsSsoEnabled;

	@Value("${paynow.jwt.private.pem}")
	public String paynowJwtPrivatePem;

	@Value("${paynow.verify.jws.sign.public.pem}")
	public String paynowVerifyJwsSignPublicPem;

	@Value("${paynow.bypass.enabled}")
	public Boolean paynowByPassEnabled;

	@Value("${eNets.mid}")
	public String eNetsMid;

	@Value("${eNets.keyId}")
	public String eNetsKeyId;

	@Value("${eNets.secretKey}")
	public String eNetsSecretKey;

	@Value("${eNets.currency}")
	public String eNetsCurrency;

	@Value("${iams.apex.enabled}")
	public Boolean iamsApexEnabled;

	@Value("${iams.apex.ig.l0.baseApiUrl}")
	public String iamsApexIgL0BaseApiUrl;

	@Value("${iams.apex.eg.l1.baseApiUrl}")
	public String iamsApexEgL1BaseApiUrl;

	@Value("${iams.apex.eg.l1.appId}")
	public String iamsApexEgL1AppId;

	@Value("${iams.apex.eg.l1.realm}")
	public String iamsApexEgL1Realm;

	@Value("${iams.apex.eg.l1.version}")
	public String iamsApexEgL1Version;

	@Value("${iams.apex.eg.l1.secret}")
	public String iamsApexEgL1Secret;

	@Value("${iams.api.login}")
	public String iamsApiLogin;

	@Value("${iams.api.login.info}")
	public String iamsApiLoginInfo;

	@Value("${iams.api.allUser}")
	public String iamsApiAllUser;

	@Value("${iams.api.user}")
	public String iamsApiUser;

	@Value("${iams.password.manager.url}")
	public String iamsPasswordManagerUrl;

	@Value("${taELicence.qrUrl}")
	public String taELicenceQrUrl;

	@Value("${tag.dir.infographic}")
	public String infographic;

	@Value("${year}")
	public String year;

	@Value("${tag.dir.image}")
	public String imageDir;

	@Value("${tag.dir.font}")
	public String fontDir;

	@Value("${dashboardDate}")
	public String dashboardDate;

	@PostConstruct
	public void init() {
		logger.info("[conf] tag.conf.env: " + appEnv);
		logger.info("[conf] tag.conf.email: " + email);
		logger.info("[conf] tag.conf.catchAllEmail: " + catchAllEmail);
		logger.info("[conf] tag.dir.base: " + baseDir);
		logger.info("[conf] build.info.by: " + buildInfoBy);
		logger.info("[conf] build.info.timestamp: " + buildInfoTimestamp);
	}
}