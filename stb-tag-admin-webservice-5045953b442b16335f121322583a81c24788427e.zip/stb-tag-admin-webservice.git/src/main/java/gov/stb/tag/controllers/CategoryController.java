package gov.stb.tag.controllers;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.bulletin.BulletinSearchDto;
import gov.stb.tag.dto.bulletin.CategoryItemDto;
import gov.stb.tag.dto.bulletin.CategoryListDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Category;
import gov.stb.tag.model.CategoryListing;
import gov.stb.tag.repository.CategoryRepository;

@RestController
@RequestMapping(path = "/api/v1/category")
@Transactional
public class CategoryController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	FileHelper fileHelper;

	@RequestMapping(path = { "/public-get-all-categorys/{type}" }, method = RequestMethod.GET)
	public ResultDto<CategoryItemDto> getPublicAllCategorys(@PathVariable String type, BulletinSearchDto searchDto) {

		searchDto = new BulletinSearchDto();
		ResultDto<CategoryItemDto> allCategorys = categoryRepository.getAllCategorys(searchDto);

		for (Object cat : allCategorys.getRecords()) {
			Integer categoryId = ((CategoryItemDto) cat).getId();
			Category category = categoryRepository.getDetailsById(categoryId, false);

			CategoryItemDto dto = CategoryItemDto.buildFromCategory(cache, category, category.getCategory_listings());
			((CategoryItemDto) cat).setCategoryList(dto.getCategoryList());
			if (null != dto.getOriginalFilename() && null != dto.getHash() && null != dto.getFileId()) {
				((CategoryItemDto) cat).setOriginalFilename(dto.getOriginalFilename());
				((CategoryItemDto) cat).setHash(dto.getHash());
				((CategoryItemDto) cat).setFileId(dto.getFileId());
			}
		}

		return allCategorys;
	}

	@RequestMapping(path = { "/get-all-categorys/{type}" }, method = RequestMethod.GET)
	public ResultDto<CategoryItemDto> getAllCategorys(@PathVariable String type, BulletinSearchDto searchDto) {

		return categoryRepository.getAllCategorys(type, searchDto);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveBulletin(@RequestPart(name = "categoryDto") CategoryItemDto categoryDto, @RequestPart(name = "categoryListDto") List<CategoryListDto> categoryListDto,
			@RequestPart(name = "deleteCategoryList") List<Integer> deleteCategoryList, @RequestPart(name = "categoryListDeletedFiles") List<Integer> categoryListDeletedFiles,
			@RequestPart(name = "categoryIconDeletedFiles") List<Integer> categoryIconDeletedFiles) {

		for (Integer deletedRecords : deleteCategoryList) {
			CategoryListing retrieveExistingItem = categoryRepository.getCategoryListingDetailsById(deletedRecords);
			categoryRepository.delete(retrieveExistingItem);
		}

		for (Integer listDeletedFiles : categoryListDeletedFiles) {
			CategoryListing retrieveExistingItem = categoryRepository.getCategoryListingDetailsById(listDeletedFiles);
			if (retrieveExistingItem != null) {
				retrieveExistingItem.setHash(null);
				retrieveExistingItem.setFileId(null);
				retrieveExistingItem.setFileId(null);
				categoryRepository.save(retrieveExistingItem);
			}
		}

		Category category = new Category();
		if (categoryDto.getId() != null) {
			category = categoryRepository.getDetailsById(categoryDto.getId(), false);
			category = buildCategory(categoryDto, category);

			// Update
			for (CategoryListDto items : categoryListDto) {
				if (null != items.getId()) {
					CategoryListing retrieveExistingItem = categoryRepository.getCategoryListingDetailsById(items.getId());
					retrieveExistingItem.setFileId(items.getFileId());
					retrieveExistingItem.setTitle(items.getTitle());
					retrieveExistingItem.setType(commonRepository.getTypeCodeTaTgList(items.getType()));
					retrieveExistingItem.setOriginalFilename(items.getOriginalFilename());
					retrieveExistingItem.setExpiryDate(items.getExpiryDate());
					retrieveExistingItem.setEffectiveDate(items.getEffectiveDate());
					retrieveExistingItem.setHash(items.getHash());

					retrieveExistingItem.setFileIconId(items.getFileIconId());
					retrieveExistingItem.setHashIcon(items.getHashIcon());
					retrieveExistingItem.setOriginalIconFilename(items.getOriginalIconFilename());
					categoryRepository.save(retrieveExistingItem);
				} else {
					CategoryListing newItem = new CategoryListing();
					newItem.setFileId(items.getFileId());
					newItem.setCategories(category);
					newItem.setTitle(items.getTitle());
					newItem.setType(commonRepository.getTypeCodeTaTgList(items.getType()));
					newItem.setOriginalFilename(items.getOriginalFilename());
					newItem.setExpiryDate(items.getExpiryDate());
					newItem.setEffectiveDate(items.getEffectiveDate());
					newItem.setHash(items.getHash());

					newItem.setFileIconId(items.getFileIconId());
					newItem.setHashIcon(items.getHashIcon());
					newItem.setOriginalIconFilename(items.getOriginalIconFilename());

					categoryRepository.save(newItem);
				}
			}

		} else {
			category = buildCategory(categoryDto, category);
			categoryRepository.save(category);

			// Update
			for (CategoryListDto items : categoryListDto) {
				if (null != items.getId()) {
					CategoryListing retrieveExistingItem = categoryRepository.getCategoryListingDetailsById(items.getId());
					retrieveExistingItem.setFileId(items.getFileId());
					retrieveExistingItem.setTitle(items.getTitle());
					retrieveExistingItem.setType(commonRepository.getTypeCodeTaTgList(items.getType()));
					retrieveExistingItem.setOriginalFilename(items.getOriginalFilename());
					retrieveExistingItem.setExpiryDate(items.getExpiryDate());
					retrieveExistingItem.setEffectiveDate(items.getEffectiveDate());
					retrieveExistingItem.setHash(items.getHash());

					retrieveExistingItem.setFileIconId(items.getFileIconId());
					retrieveExistingItem.setHashIcon(items.getHashIcon());
					retrieveExistingItem.setOriginalIconFilename(items.getOriginalIconFilename());

					categoryRepository.save(retrieveExistingItem);
				} else {
					CategoryListing newItem = new CategoryListing();
					newItem.setFileId(items.getFileId());
					newItem.setCategories(category);
					newItem.setTitle(items.getTitle());
					newItem.setType(commonRepository.getTypeCodeTaTgList(items.getType()));
					newItem.setOriginalFilename(items.getOriginalFilename());
					newItem.setExpiryDate(items.getExpiryDate());
					newItem.setEffectiveDate(items.getEffectiveDate());
					newItem.setHash(items.getHash());

					newItem.setFileIconId(items.getFileIconId());
					newItem.setHashIcon(items.getHashIcon());
					newItem.setOriginalIconFilename(items.getOriginalIconFilename());
					categoryRepository.save(newItem);
				}
			}

		}

		return category.getId();
	}

	@RequestMapping(path = { "/view/{categoryId}/{type}", "/load/{categoryId}" }, method = RequestMethod.GET)
	public CategoryItemDto getCategoryDetail(@PathVariable Integer categoryId, @PathVariable String type) {

		// String[] newCategoryId = categoryId.split("_");
		return populateDetail(categoryId, false, type);
	}

	public Category buildCategory(CategoryItemDto dto, Category category) {
		category.setType(null);
		category.setPrivate(dto.getIsPrivate());
		category.setTitle(dto.getTitle());
		// category.setContent(dto.getContent());
		category.setEffectiveDate(dto.getEffectiveDate());
		category.setExpiryDate(dto.getExpiryDate());
		category.setFileId(dto.getFileId());
		category.setHash(dto.getHash());
		category.setOriginalFilename(dto.getOriginalFilename());
		return category;
	}

	private CategoryItemDto populateDetail(Integer id, boolean fromAEM, String type) {
		Category category = categoryRepository.getDetailsById(id, fromAEM);

		CategoryItemDto dto = CategoryItemDto.buildFromCategory(cache, category, category.getCategory_listings());
		return dto;
	}
}
