package gov.stb.tag.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.config.ConfigEmailItemDto;
import gov.stb.tag.dto.config.ConfigItemDto;
import gov.stb.tag.dto.config.ConfigSearchDto;
import gov.stb.tag.model.EmailTemplate;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.WaiveType;
import gov.stb.tag.repository.ConfigRepository;

@RestController
@RequestMapping(path = "/api/v1/config")
@Transactional
public class ConfigController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	ConfigRepository configRepository;

	// Types
	@RequestMapping(path = "/master-data/get-editable-category-types", method = RequestMethod.GET)
	public List<ListableDto> getEditableCategoryTypes() throws IOException {
		return toListableDtos(configRepository.getEditableCategoryTypes());
	}

	@RequestMapping(path = "/master-data/get-editable-category-types-label", method = RequestMethod.GET)
	public List<ListableDto> getEditableCategoryTypeLabel(ConfigSearchDto searchDto) throws IOException {
		return toListableDtos(configRepository.getEditableCategoryTypeLabel(searchDto));
	}

	@RequestMapping(path = "/master-data/types/view", method = RequestMethod.GET)
	public List<ConfigItemDto> getEditableTypesList(ConfigSearchDto searchDto) {
		List<ConfigItemDto> list = new ArrayList<ConfigItemDto>();
		var itemDto = new ConfigItemDto();
		List<Type> types = configRepository.getTypesByCategoryCode(searchDto);
		for (Type type : types) {
			itemDto = itemDto.buildConfigTypeItem(type);
			list.add(itemDto);
		}
		return list;
	}

	@RequestMapping(path = "/update-types", method = RequestMethod.POST)
	public List<ConfigItemDto> updateTypes(@RequestPart(name = "list") List<ConfigItemDto> list) {
		var itemDto = new ConfigItemDto();
		int ordinal = 1;

		if (list.size() > 0) {
			for (ConfigItemDto dto : list) {
				Type type = configRepository.getTypeByCode(dto.getCode());
				if (type != null) {
					type = itemDto.buildConfigTypeItem(dto, type, ordinal, null);
					ordinal++;
					configRepository.update(type);
				}
			}
		}
		return list;
	}

	@RequestMapping(value = "/save-types", method = RequestMethod.POST)
	public void saveTypes(@RequestBody ConfigItemDto dto) {
		var itemDto = new ConfigItemDto();
		ConfigSearchDto searchDto = new ConfigSearchDto();
		Type type = new Type();
		searchDto.setSelectedCategory(dto.getCategoryCode());
		int ordinal = configRepository.getTypesByCategoryCode(searchDto).size() + 1;
		dto.setCode("NEW_TYPE");
		type.setIsEditable(true);
		type = itemDto.buildConfigTypeItem(dto, type, ordinal, configRepository.getTypeByCode(dto.getCategoryCode()));

		configRepository.save(type);
	}

	// Statuses
	@RequestMapping(path = "/master-data/get-editable-category-statuses", method = RequestMethod.GET)
	public List<ListableDto> getEditableCategoryStatuses() throws IOException {
		return toListableDtos(configRepository.getEditableCategoryStatuses());
	}

	@RequestMapping(path = "/master-data/statuses/view", method = RequestMethod.GET)
	public List<ConfigItemDto> getEditableStatusesList(ConfigSearchDto searchDto) {
		List<ConfigItemDto> list = new ArrayList<ConfigItemDto>();
		var itemDto = new ConfigItemDto();
		List<Status> statuses = configRepository.getStatusesByCategoryCode(searchDto);
		for (Status status : statuses) {
			itemDto = itemDto.buildConfigStatusItem(status);
			list.add(itemDto);
		}
		return list;
	}

	@RequestMapping(path = "/update-statuses", method = RequestMethod.POST)
	public List<ConfigItemDto> updateStatuses(@RequestPart(name = "list") List<ConfigItemDto> list) {
		var itemDto = new ConfigItemDto();
		int ordinal = 1;

		if (list.size() > 0) {
			for (ConfigItemDto dto : list) {
				Status status = configRepository.getStatusByCode(dto.getCode());
				if (status != null) {
					status = itemDto.buildConfigStatusItem(dto, status, ordinal);
					ordinal++;
					configRepository.update(status);
				}
			}
		}
		return list;
	}

	// System Parameter
	@RequestMapping(path = "/master-data/sys-parameter/view", method = RequestMethod.GET)
	public List<ConfigItemDto> getEditableSysParameterList(ConfigSearchDto searchDto) {
		List<ConfigItemDto> list = new ArrayList<ConfigItemDto>();
		var itemDto = new ConfigItemDto();
		List<SystemParameter> sysParams = configRepository.getSysParameterByCategoryCode(searchDto);
		for (SystemParameter sys : sysParams) {
			itemDto = itemDto.buildConfigSysParameterItem(sys);
			list.add(itemDto);
		}
		return list;
	}

	@RequestMapping(path = "/update-sys-parameter", method = RequestMethod.POST)
	public List<ConfigItemDto> updateSysParameter(@RequestPart(name = "list") List<ConfigItemDto> list) {
		var itemDto = new ConfigItemDto();
		int ordinal = 1;

		if (list.size() > 0) {
			for (ConfigItemDto dto : list) {
				SystemParameter sys = configRepository.getSystemParameterByCode(dto.getCode());
				if (sys != null) {
					sys = itemDto.buildConfigStatusItem(dto, sys, ordinal);
					ordinal++;
					configRepository.update(sys);
				}
			}
		}
		return list;
	}

	// Email
	@RequestMapping(path = "/master-data/get-email-name", method = RequestMethod.GET)
	public List<ConfigEmailItemDto> getEmailName() throws IOException {
		List<EmailTemplate> result = configRepository.getEmailName();
		List<ConfigEmailItemDto> list = new ArrayList<ConfigEmailItemDto>();
		var itemDto = new ConfigEmailItemDto();

		for (EmailTemplate email : result) {
			ConfigEmailItemDto dto = new ConfigEmailItemDto();
			itemDto.buildConfigEmailItem(dto, email);
			list.add(dto);
		}
		return list;
	}

	@RequestMapping(path = "/master-data/email-detail/view", method = RequestMethod.GET)
	public ConfigEmailItemDto getEmailDetail(ConfigSearchDto searchDto) {
		var itemDto = new ConfigEmailItemDto();
		ConfigEmailItemDto dto = new ConfigEmailItemDto();
		itemDto.buildConfigEmailItem(dto, configRepository.getEmailDetail(searchDto));

		return dto;
	}

	@RequestMapping(path = "/update-email", method = RequestMethod.POST)
	public void updateEmail(@RequestPart(name = "dto") ConfigEmailItemDto dto) {
		var itemDto = new ConfigEmailItemDto();
		ConfigSearchDto searchDto = new ConfigSearchDto();

		searchDto.setSelectedEmail(dto.getCode());
		EmailTemplate email = configRepository.getEmailDetail(searchDto);
		if (email != null) {
			email = itemDto.buildEmailTemplate(dto, email);
			configRepository.update(email);
		}
	}

	@RequestMapping(path = "/master-data/waiver-types", method = RequestMethod.GET)
	public List<ListableDto> getWaiverTypes() {
		List<WaiveType> waiverTypes = configRepository.getWaiverTypes();
		List<ListableDto> resultDtos = Lists.newArrayList();
		waiverTypes.forEach(wType -> {
			resultDtos.add(new ListableDto(wType.getId(), cache.getLabel(wType.getType(), false), null, wType.getIsWaive(), null));
		});

		return resultDtos;
	}

	@RequestMapping(path = "/update-waiver-types", method = RequestMethod.POST)
	public void saveWaiverTypes(@RequestBody List<ListableDto> list) {
		for (ListableDto dto : list) {
			WaiveType waiveType = configRepository.get(WaiveType.class, dto.getKey());
			if (waiveType != null) {
				waiveType.setIsWaive(dto.getData().equals(Boolean.TRUE));
				configRepository.update(waiveType);
			}
		}
	}

}
