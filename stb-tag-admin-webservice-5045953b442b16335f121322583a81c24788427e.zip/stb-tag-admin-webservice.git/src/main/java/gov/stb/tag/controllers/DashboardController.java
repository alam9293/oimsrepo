package gov.stb.tag.controllers;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wiz.security.TokenAuthenticationService;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.DashboardPendingActionTypes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.dto.CeTaskDto;
import gov.stb.tag.dto.CeTaskSearchDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.RainbowCardDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.auth.AuthUserDto;
import gov.stb.tag.dto.dashboard.AlertItemDto;
import gov.stb.tag.dto.dashboard.AlertSearchDto;
import gov.stb.tag.dto.dashboard.LicenceDto;
import gov.stb.tag.dto.dashboard.TaDashboardDto;
import gov.stb.tag.dto.dashboard.TaSubmissionDueDto;
import gov.stb.tag.dto.dashboard.TgDashboardDto;
import gov.stb.tag.dto.dashboard.TgPendingActionsItemDto;
import gov.stb.tag.dto.dashboard.TgSideMenuDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.application.TaApplicationItemDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalChecklist;
import gov.stb.tag.dto.tg.mlpt.TgMlptRegistrationDto;
import gov.stb.tag.dto.tg.stipend.TgStipendDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.TaHelper;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Alert;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgStipend;
import gov.stb.tag.model.TgStipendConfig;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.DashboardRepository;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgAssignmentRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgLicenceRenewalRepository;
import gov.stb.tag.repository.tg.TgMlptRepository;
import gov.stb.tag.repository.tg.TgStipendRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/dashboard")
@Transactional
public class DashboardController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private DashboardRepository dashboardRepository;

	@Autowired
	PaymentRepository paymentRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	LicenceHelper licenceHelper;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	TgAssignmentRepository tgAssignmentRepository;

	@Autowired
	TgCourseRepository tgCourseRepository;

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	@Autowired
	TgLicenceRenewalRepository tgLicenceRenewalRepository;

	@Autowired
	TaRenewalRepository taRenewalRepository;
	@Autowired
	CacheHelper cacheHelper;
	@Autowired
	TaNetValueShortfallRepository taNetValueShortfallRepository;
	@Autowired
	TaHelper taHelper;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	TgMlptRepository mlptRepository;

	@Autowired
	TgHelper tgHelper;

	@Autowired
	TgStipendRepository tgStipendRepository;

	// ------ Start of shared services for all types of users ------//
	@RequestMapping(method = RequestMethod.POST, value = "/current-user/roles/switch")
	public AuthUserDto switchRole(@Validated @RequestBody String roleCode, HttpServletRequest request, HttpServletResponse response) {

		logger.info("My Role " + getSelectedRoleCode());
		logger.info("Request to switch role to " + roleCode);

		User user = userRepository.getUserWithRoleAndFunctions(getUser().getId());

		// validate requested role
		Role role = UserHelper.getRole(user.getRoles(), roleCode);
		if (role == null) {
			// means user doesn't assigned to the role
			throw new ValidationException("You are not granted to " + roleCode + " role.");
		}

		// now set the default to the new role
		user.setDefaultRole(role);

		logger.info("***** Switched role to " + user.getDefaultRole().getCode());

		// refresh the authentication
		TokenAuthenticationService.addAuthentication(request, response, user);

		return AuthUserDto.buildFromUser(cache, user, role);
	}

	@RequestMapping(path = "/alerts", method = RequestMethod.GET)
	public ResultDto<AlertItemDto> getAlerts(AlertSearchDto searchDto) {
		return dashboardRepository.getUserAlerts(getUser().getId(), getTaTgType(), searchDto);
	}

	@RequestMapping(path = "/alerts/delete/{id}", method = RequestMethod.POST)
	public void deleteAlert(@PathVariable Integer id) {
		Alert alert = dashboardRepository.get(Alert.class, id);
		alert.setStatus(cache.getStatus(Codes.AlertStatus.DELETED));
		dashboardRepository.update(alert);
	}

	@RequestMapping(path = "/alerts/read/{id}", method = RequestMethod.POST)
	public Long readSingleAlert(@PathVariable Integer id) {
		Alert alert = dashboardRepository.get(Alert.class, id);
		alert.setStatus(cache.getStatus(Codes.AlertStatus.READ));
		dashboardRepository.update(alert);
		return getUserTotalUnreadAlerts();
	}

	@RequestMapping(path = "/alerts/read", method = RequestMethod.POST)
	public Long readMultipleAlerts(@Validated @RequestBody Integer[] ids) {
		for (Integer id : ids) {
			Alert alert = dashboardRepository.get(Alert.class, id);
			alert.setStatus(cache.getStatus(Codes.AlertStatus.READ));
			dashboardRepository.update(alert);
		}
		return getUserTotalUnreadAlerts();
	}

	@RequestMapping(path = "/alerts/read/all", method = RequestMethod.GET)
	public Long readAllAlerts() {
		List<Alert> alerts = dashboardRepository.getUserAlerts(getUser().getId(), getTaTgType());
		for (Alert alert : alerts) {
			alert.setStatus(cache.getStatus(Codes.AlertStatus.READ));
		}
		dashboardRepository.update(alerts);
		return getUserTotalUnreadAlerts();
	}

	@RequestMapping(path = "/alerts/total-unread", method = RequestMethod.GET)
	public Long getTotalUnreadAlerts() {
		return getUserTotalUnreadAlerts();
	}

	@RequestMapping(method = RequestMethod.GET, value = "/officer/pending-actions/{dashboardView}")
	public List<RainbowCardDto> getOfficerDashboardElements(@PathVariable String dashboardView) {
		List<RainbowCardDto> result = Lists.newArrayList();
		String deptCode = getUser().getDepartment() != null ? getUser().getDepartment().getCode() : null;
		if (deptCode != null && Entities.anyEquals(getUser().getDepartment(), Codes.DepartmentType.TA, Codes.DepartmentType.TG, Codes.DepartmentType.TA_AND_TG)) {
			if (dashboardView.equals(DASHBOARD_DEPT)) {
				String taTgType = "";
				switch (deptCode) {
				case Codes.DepartmentType.TA:
					taTgType = Codes.TaTgType.TA;
					break;
				case Codes.DepartmentType.TG:
					taTgType = Codes.TaTgType.TG;
					break;
				case Codes.DepartmentType.TA_AND_TG:
					taTgType = null;
					break;
				}
				result = dashboardRepository.getTeamPendingActionsCount(taTgType);
			} else {
				result = dashboardRepository.getOfficerPendingActionsCount(getUser().getLoginId());
			}
		}

		// special handling for KE apps
		Integer count = 0;
		List<RainbowCardDto> toRemove = new ArrayList<>();
		for (RainbowCardDto aCard : result) {
			if (aCard.getTypeCode().equals(Codes.ApplicationTypes.TA_APP_KE_ASSIGN) || aCard.getTypeCode().equals(Codes.ApplicationTypes.TA_APP_KE_REASSIGN)
					|| aCard.getTypeCode().equals(Codes.ApplicationTypes.TA_APP_KE_RESIGN) || aCard.getTypeCode().equals(Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS)) {
				count = count + aCard.getCount().intValue();
				toRemove.add(aCard);
			}
		}
		if (count > 0) {
			result.removeAll(toRemove);
			result.add(new RainbowCardDto("TA_APP_KE", "Key Executive Management", null, count.longValue()));
		}

		return result;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/officer/other-pending-actions/{dashboardView}")
	public List<RainbowCardDto> getOfficerOtherDashboardElements(@PathVariable String dashboardView) {
		List<RainbowCardDto> result = Lists.newArrayList();

		if (Entities.equals(getUser().getDepartment(), Codes.DepartmentType.TG)) {
			// Show count of workpass holders whose workpass is going to expire in two weeks time
			Long workpassExpiryDays = Long.valueOf(cache.getSystemParameter(Codes.SystemParameters.TG_WORKPASS_EXPIRY_DAYS_TO_ALERT).getValue());
			LocalDate expiryByDate = LocalDate.now().plusDays(workpassExpiryDays);
			Long count = dashboardRepository.getWorkpassExpiryCount(expiryByDate);
			if (count.compareTo(0L) > 0) {
				RainbowCardDto workpassExpiryDto = new RainbowCardDto();
				workpassExpiryDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_WORKPASS_EXPIRY_ALERT);
				workpassExpiryDto.setTypeLabel("");
				workpassExpiryDto.setStatus("Work pass holders expiring in " + workpassExpiryDays + " days");
				workpassExpiryDto.setCount(count);
				// the following will pass the filter params to tg licence searchDto
				workpassExpiryDto.setParams(Maps.newHashMap());
				workpassExpiryDto.getParams().put("workPassExpiryDateTo", expiryByDate);
				workpassExpiryDto.getParams().put("workPassHolder", Boolean.TRUE);
				workpassExpiryDto.getParams().put("licenceStatus", Codes.Statuses.TG_ACTIVE);
				result.add(workpassExpiryDto);
			}

			// show count of pending printing
			Long countPrint = dashboardRepository.getTgLicencePendingPrintingCount();
			if (countPrint.compareTo(0L) > 0) {
				RainbowCardDto tgPendingPrintDto = new RainbowCardDto();
				tgPendingPrintDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_TG_LICENCE_PEND_PRINTING);
				tgPendingPrintDto.setTypeLabel("");
				tgPendingPrintDto.setStatus("TG licence pending printing");
				tgPendingPrintDto.setCount(countPrint);
				// the following will pass the filter params to ta licence printing searchDto
				tgPendingPrintDto.setParams(Maps.newHashMap());
				tgPendingPrintDto.getParams().put("licencePrintStatus", Statuses.PRINT_PENDING_PRINTING);
				result.add(tgPendingPrintDto);
			}

			// show count of stipends that required follow up by finance
			Long countFollowUpRequired = dashboardRepository.getTgStipendFollowUpRequiredByFinance();
			if (countFollowUpRequired.compareTo(0L) > 0) {
				RainbowCardDto tgStipendFollowUpRequiredDto = new RainbowCardDto();
				tgStipendFollowUpRequiredDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_STIPEND_FOLLOW_UP_REQUIRED);
				tgStipendFollowUpRequiredDto.setTypeLabel("");
				tgStipendFollowUpRequiredDto.setStatus("TG wage support RFA by finance");
				tgStipendFollowUpRequiredDto.setCount(countFollowUpRequired);
				// the following will pass the filter params to all application searchDto
				tgStipendFollowUpRequiredDto.setParams(Maps.newHashMap());
				tgStipendFollowUpRequiredDto.getParams().put("applicationType", Codes.ApplicationTypes.TG_APP_STIPEND);
				tgStipendFollowUpRequiredDto.getParams().put("hasFollowUpRequiredByFinance", Boolean.TRUE);
				result.add(tgStipendFollowUpRequiredDto);
			}
		}

		if (Entities.equals(getUser().getDepartment(), Codes.DepartmentType.FINANCE)) {
			List<ListableDto> payReqStatusesCount = dashboardRepository
					.getPaymentRequestCountByStatuses(Lists.newArrayList(Codes.Statuses.PAYREQ_PAID, Codes.Statuses.PAYREQ_PENDING_REFUND, Statuses.PAYREQ_PENDING_DISBURSEMENT).toArray());
			payReqStatusesCount.forEach(dto -> {
				RainbowCardDto paymentRequestDto = new RainbowCardDto();
				switch (dto.getKeyString()) {
				case Codes.Statuses.PAYREQ_PAID:
					paymentRequestDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_PAYMENT_PAID);
					break;
				case Codes.Statuses.PAYREQ_PENDING_REFUND:
					paymentRequestDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_PAYMENT_PEND_REFUND);
					break;
				case Statuses.PAYREQ_PENDING_DISBURSEMENT:
					paymentRequestDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_PAYMENT_PEND_DISBURSEMENT);
					break;
				}
				paymentRequestDto.setTypeLabel("");
				paymentRequestDto.setStatus("Payment requests are " + dto.getLabel());
				paymentRequestDto.setCount(Long.parseLong(dto.getData().toString()));
				// the following will pass the filter params to tg licence searchDto
				paymentRequestDto.setParams(Maps.newHashMap());
				paymentRequestDto.getParams().put("statusCode", dto.getKeyString());
				result.add(paymentRequestDto);
			});
		}

		if (Entities.equals(getUser().getDepartment(), Codes.DepartmentType.TA)) {
			Long count = dashboardRepository.getTaLicencePendingPrintingCount(dashboardView.equals(DASHBOARD_MY) ? getUser().getId() : null);
			if (count.compareTo(0L) > 0) {
				RainbowCardDto rainbowDto = new RainbowCardDto();
				rainbowDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_TA_LICENCE_PEND_PRINTING);
				rainbowDto.setTypeLabel("");
				rainbowDto.setStatus("TA licence pending printing");
				rainbowDto.setCount(count);
				// the following will pass the filter params to ta licence printing searchDto
				rainbowDto.setParams(Maps.newHashMap());
				rainbowDto.getParams().put("licencePrintStatus", Codes.Statuses.TA_PRINT_PENDING);
				rainbowDto.getParams().put("myApplications", dashboardView.equals(DASHBOARD_MY));
				result.add(rainbowDto);
			}
		}

		Boolean showTaOtherAction = Boolean.FALSE;
		if (Entities.equals(getUser().getDepartment(), Codes.DepartmentType.TA) && dashboardView.equals(DASHBOARD_DEPT)) {
			showTaOtherAction = Boolean.TRUE;
		} else if (Entities.equals(cache.getRole(getSelectedRoleCode()), Codes.Roles.TA_PROCESSING_OFFICER)) {
			showTaOtherAction = Boolean.TRUE;
		}

		if (showTaOtherAction) {
			// show count of approved net value shortfall but yet to set the letter issued date
			Long count = dashboardRepository.getShortfallLetterPendingIssuanceCount();
			if (count.compareTo(0L) > 0) {
				RainbowCardDto rainbowDto = new RainbowCardDto();
				rainbowDto.setTypeCode(DashboardPendingActionTypes.DASHBOARD_SHORTFALL_LETTER_PEND_ISSUANCE);
				rainbowDto.setTypeLabel("");
				rainbowDto.setStatus("Shortfall letter pending issuance");
				rainbowDto.setCount(count);
				// the following will pass the filter params to tg licence searchDto
				rainbowDto.setParams(Maps.newHashMap());
				rainbowDto.getParams().put("letterPendingIssuanceStatus", "YES");
				result.add(rainbowDto);
			}
		}

		return result;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/officer/ce-tasks/{dashboardView}")
	public ResultDto<CeTask> getOfficerCeTaskList(@PathVariable String dashboardView, CeTaskSearchDto searchDto) {
		ResultDto<CeTask> ceTaskResultDto = dashboardRepository.searchCeTask(searchDto, dashboardView.equals(DASHBOARD_MY) ? getUser().getId() : null);

		Object[] finalRecords = new Object[ceTaskResultDto.getRecords().length];
		var i = 0;
		for (CeTask ceTask : ceTaskResultDto.getModels()) {
			var dto = CeTaskDto.buildFromCeTask(cache, ceTask, userRepository.getRoleWithFunctions(getSelectedRoleCode()));
			finalRecords[i] = dto;
			i++;
		}
		ceTaskResultDto.setRecords(finalRecords);
		return ceTaskResultDto;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/licence")
	public LicenceDto getLicence() {
		User user = userRepository.getLicenseeUserByUserId(getUser().getId());
		if (!Objects.isNull(user.getTravelAgent())) {
			return LicenceDto.buildFromLicence(cache, user.getTravelAgent().getLicence());
		} else if (!Objects.isNull(user.getTouristGuide())) {
			return LicenceDto.buildFromLicence(cache, user.getTouristGuide().getLicence());
		}
		return null;
	}

	@RequestMapping(value = "/outstanding-payments", method = RequestMethod.GET)
	public List<PaymentRequestDto> getOutstandingPayments() {
		List<PaymentRequestDto> paymentRequestDto = new ArrayList<>();
		List<PaymentRequest> paymentRequests = Lists.newArrayList();

		User currentUser = userRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			paymentRequests = paymentRepository.getPaymentRequestsForPaymentByPayerId(currentUser.getTravelAgent().getUen());

		} else if (getSelectedRoleCode().equals(Codes.Roles.TG_PUBLIC) && !Objects.isNull(currentUser.getTouristGuide())) {
			paymentRequests = paymentRepository.getPaymentRequestsForPaymentByPayerId(currentUser.getTouristGuide().getUin());

			// append the outstanding payments for former uin also
			if (Strings.isNotEmpty(currentUser.getTouristGuide().getFormerUin())) {
				List<PaymentRequest> formerUinPayments = paymentRepository.getPaymentRequestsForPaymentByPayerId(currentUser.getTouristGuide().getFormerUin());
				if (CollectionUtils.isNotEmpty(formerUinPayments)) {
					paymentRequests.addAll(formerUinPayments);
				}
			}
		}

		paymentRequests.forEach(o -> paymentRequestDto.add(new PaymentRequestDto(cache, o, false)));
		return paymentRequestDto;
	}

	// --------- End Shared services for all types of users --------- //

	// --------- Start of web services for TA users --------- //
	@RequestMapping(method = RequestMethod.GET, value = "/ta")
	public TaDashboardDto getTaDashboardElements() {
		User user = userRepository.getLicenseeUserByUserId(getUser().getId());
		TaDashboardDto result = new TaDashboardDto();
		if (!Objects.isNull(user.getTravelAgent())) {
			TravelAgent ta = user.getTravelAgent();
			Licence licence = user.getTravelAgent().getLicence();

			Long pendingActionsCount = 0L;
			List<ListableDto> counts = dashboardRepository.getTaPendingApplicationsCount(licence.getId());
			if (CollectionUtils.isNotEmpty(counts)) {
				for (ListableDto count : counts) {
					if (Codes.Statuses.TA_APP_RFA.equals(count.getKey().toString())) {
						pendingActionsCount = (Long) count.getData();
					}
				}
			}
			result.setPendingActionsCount(pendingActionsCount);
			result.setOutstandingPaymentAmount(travelAgentRepository.getTaOutstandingPaymentAmount(ta.getUen()));
			result.setLicence(LicenceDto.buildFromLicence(cache, licence));

			/************** Check renewal status for renewal checklist ******************/
			LocalDate currentDate = LocalDate.now();
			Integer year = currentDate.getYear();

			TaLicenceRenewalExercise renewalExercise = taRenewalRepository.getApprovedRenewalExerciseFromYear(year);
			TaLicenceRenewalExerciseTa renewalExerciseTa = taRenewalRepository.getTaLicenceRenewalExerciseTaForYear(licence.getId(), currentDate);
			if (renewalExercise != null) {
				LocalDate renewalStartDate = renewalExercise.getStartDate();
				LocalDate renewalEndDate = renewalExercise.getEndDate();

				result.setRenewalStart(renewalStartDate);

				result.setRenewalEnd(renewalEndDate);

				// STBTAGPROD 1323 fix dashboard null error
				if (renewalExerciseTa != null) {
					if (renewalExerciseTa.getType() != null) {
						if (renewalExerciseTa.getType().getCode() != null) {
							if (renewalExerciseTa.getType().getCode().equals("TA_RENEW_EX_EXP")) {
								LocalDate currentdate = LocalDate.now();
								String date = currentdate.getYear() + properties.dashboardDate;
								result.setRenewalEnd(LocalDate.parse(date));
							}
						}
					}
				}

				TaLicenceRenewalChecklist renewalChecklist = new TaLicenceRenewalChecklist();

				if (result.getLicence().getExpiryDate().getYear() <= year && (currentDate.isAfter(renewalStartDate) || renewalStartDate.isEqual(currentDate))
						&& (currentDate.isEqual(LocalDate.of(year, 12, 31)) || (currentDate.isBefore(LocalDate.of(year, 12, 31))))) {
					result.setRenewalPeriod(Boolean.TRUE);

					renewalChecklist = taHelper.getTaRenewalChecklist(year, licence, renewalChecklist, result.getOutstandingPaymentAmount());
					result.setRenewalChecklist(renewalChecklist);
				}
				TaLicenceRenewalExerciseTa renewalTa = taRenewalRepository.getTaLicenceRenewalExerciseTa(renewalExercise.getId(), licence.getId(), Boolean.TRUE);
				if (renewalTa != null && renewalTa.getTaLicenceRenewal() != null
						&& !renewalTa.getTaLicenceRenewal().getApplication().getLastAction().getStatus().getCode().equalsIgnoreCase(Statuses.TA_APP_REJECTED)) {
					if (result.getRenewalChecklist() == null) {
						result.setRenewalChecklist(new TaLicenceRenewalChecklist());
					}
					result.setRenewalChecklist(TaLicenceRenewalChecklist.buildApplication(cacheHelper, appHelper, paymentHelper, renewalTa.getTaLicenceRenewal(), result.getRenewalChecklist()));
					result.setRenewalPeriod(Boolean.TRUE);
				}

			}
			/************** END renewal status for renewal checklist ******************/
			// Check submissions due
			Map<String, List<TaSubmissionDueDto>> submisionsMap = Maps.newLinkedHashMap();
			List<TaSubmissionDueDto> submissionDueList = Lists.newArrayList();

			// 1. AA and ABPR and MA
			List<TaFilingCondition> filings = taAnnualFilingRepository.getUnfulfilledTaFilingConditions(licence.getId());
			for (TaFilingCondition filing : filings) {
				submissionDueList.add(TaSubmissionDueDto.buildFromAnnualFiling(cache, filing));
			}

			// 2. Rectification of shortfall
			List<TaNetValueShortfall> shortfalls = taNetValueShortfallRepository.getUnfulfilledShortfall(licence.getId());
			if (CollectionUtils.isNotEmpty(shortfalls)) {
				logger.info("Licence no: {}, number of shortfalls: {}", licence.getLicenceNo(), shortfalls.size());
				TaSubmissionDueDto shortfallSubmissionDueDto = null;
				for (TaNetValueShortfall shortfall : shortfalls) {
					if (shortfallSubmissionDueDto == null) {
						// first shortfall
						shortfallSubmissionDueDto = TaSubmissionDueDto.buildFromShortfall(cache, shortfall);
					} else {
						// 2nd shortfall
						TaNetValueShortfall parentShortfall = shortfall.getParentShortfall();
						if (parentShortfall == null) {
							logger.info("2nd shortfall Id:{} is parent.", shortfall.getId());
						} else {
							logger.info("2nd shortfall Id:{} has parent shortfall Id: {}", shortfall.getId(), parentShortfall.getId());
							logger.info("2nd shortfall parent is the same as 1st shortfall? {}", parentShortfall.getId().compareTo(shortfallSubmissionDueDto.getTaFilingId()) == 0);
							// set the earliest due date
							LocalDate parentDueDate = parentShortfall.getExtendedDueDate() == null ? parentShortfall.getRectificationDueDate() : parentShortfall.getExtendedDueDate();
							shortfallSubmissionDueDto.setDueDate(DateUtil.getMinDate(parentDueDate, shortfallSubmissionDueDto.getDueDate()));
							TaSubmissionDueDto.setSubmissionStatus(cache, shortfallSubmissionDueDto);
						}
						shortfallSubmissionDueDto.setShortfallAmt(shortfallSubmissionDueDto.getShortfallAmt().add(shortfall.getAmount()));
					}
				}
				submissionDueList.add(shortfallSubmissionDueDto);
			}

			// reorder the submissions based on due date
			Collections.sort(submissionDueList, Comparator.comparing(TaSubmissionDueDto::getDueDate));

			// set the submission in dto
			if (CollectionUtils.isNotEmpty(submissionDueList)) {
				submissionDueList.forEach(submissionDue -> {
					String key = submissionDue.getType().getKey().toString();
					if (submisionsMap.containsKey(key)) {
						submisionsMap.get(key).add(submissionDue);
					} else {
						submisionsMap.put(key, Lists.newArrayList(submissionDue));
					}
				});
				List<ListableDto> listableSubmisionsDues = Lists.newArrayList();
				submisionsMap.keySet().forEach(key -> {
					logger.info("{} due on {}", key, DateUtil.format(submisionsMap.get(key).get(0).getDueDate()));
					listableSubmisionsDues.add(new ListableDto(key, cache.getLabel(cache.getType(key), true), null, submisionsMap.get(key), null));
				});
				result.setSubmissionDue(listableSubmisionsDues);
			}
		}

		return result;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/ta/pending-actions")
	public List<TaApplicationItemDto> getPendingActionList() {
		User user = userRepository.getLicenseeUserByUserId(getUser().getId());
		if (!Objects.isNull(user.getTravelAgent())) {
			Licence licence = user.getTravelAgent().getLicence();
			return dashboardRepository.getPendingActionList(licence.getId());
		}
		return null;
	}
	// --------- End of web services for TA users --------- //

	// --------- Start of web services for TG users --------- //

	@RequestMapping(method = RequestMethod.GET, value = "/tg/side-menu")
	public TgSideMenuDto getTgSideMenu() {
		User user = userRepository.getUserByLoginId(getUser().getLoginId());
		return new TgSideMenuDto(cache, user, fileHelper, licenceHelper);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/tg/top-notification")
	public TgDashboardDto getCountForTopNotification() {
		BigDecimal pdcHours = new BigDecimal(0);
		BigDecimal totalAssignmentHours = new BigDecimal(0);
		User user = userRepository.getUserByLoginId(getUser().getLoginId());
		Integer userTgLicenceId = user.getTouristGuide().getLicence().getId();
		Integer userTgId = getUser().getTouristGuide().getId();
		// calculate current licence period assignment
		totalAssignmentHours = tgAssignmentRepository.getTotalCurrentAssignmentHours(userTgId);
		List<TgCourse> listOfPdcByTgId = tgCourseRepository.getListOfAttendedCourseByTgId(Codes.Types.TP_COURSE_PDC, userTgId);
		for (TgCourse tgCourse : listOfPdcByTgId) {
			pdcHours = pdcHours.add(tgCourse.getNoOfHours());
		}
		Integer pendingApplicationCount = dashboardRepository.getTgPendingActionCount(userTgLicenceId);

		TgLicenceRenewal licenceRenewal = tgLicenceRenewalRepository.getDraftRenewal(getUser().getId());

		return new TgDashboardDto(cache, user, licenceRenewal, user.getTouristGuide().getLicence().getExpiryDate(), pendingApplicationCount, totalAssignmentHours, pdcHours);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/tg/pending-actions")
	public List<TgPendingActionsItemDto> getPendingTgActionList() {
		User user = userRepository.getLicenseeUserByUserId(getUser().getId());
		if (!Objects.isNull(user.getTouristGuide())) {
			Licence licence = user.getTouristGuide().getLicence();
			return dashboardRepository.getTgPendingActionList(licence.getId());
		}
		return null;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/tg/licence-expiry-date")
	public LocalDate getLicenceExpiryDate() {
		User user = userRepository.getUserByLoginId(getUser().getLoginId());
		TouristGuide tg = user.getTouristGuide();
		LocalDate licenceExpiryDate = tg.getLicence().getExpiryDate();
		return licenceExpiryDate;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/tg/mlpt")
	public TgMlptRegistrationDto getMlptRegistrations() {
		User user = userRepository.getUserByLoginId(getUser().getLoginId());
		TouristGuide tg = user.getTouristGuide();

		TgLicenceMlptRegistration latestRegistration = mlptRepository.getLatestTgMlptRegistrationByUin(tg.getUin());
		List<TgLicenceMlptRegistration> registrations = new ArrayList<>();
		TgMlpt tgMlpt = latestRegistration != null ? latestRegistration.getTgMlpt() : null;
		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();
		Boolean isCardPaymentSuccess = false;

		// check whether card payment is made
		if (latestRegistration != null && latestRegistration.getPrintFeeBillRefNo() != null) {
			PaymentRequest req = paymentHelper.getPaymentRequest(latestRegistration.getPrintFeeBillRefNo());
			PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
			isCardPaymentSuccess = paymentTxn != null ? paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)) : false;
		}

		if (latestRegistration != null && isCardPaymentSuccess == false) {
			registrations = mlptRepository.getCurrentMlptRegistrationsByTgAndTgMlpt(tg.getId(), tgMlpt.getId());
			dto = TgMlptRegistrationDto.buildDashboardNotification(cache, tgMlpt, registrations, paymentHelper);
		}

		return dto;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/tg/stipend")
	public TgStipendDto getStipendApplication() {
		User user = userRepository.getUserByLoginId(getUser().getLoginId());
		TouristGuide tg = user.getTouristGuide();
		TgStipendConfig config = tgStipendRepository.getLatestStipendConfig(false, null);

		TgStipendDto dto = new TgStipendDto();
		Boolean isEligible = config != null ? tgHelper.getStipendEligibility(tg, config) : false;

		TgStipend appliedStipend = null;

		appliedStipend = tgStipendRepository.getTgStipendByTgAndPeriod(tg.getId(), config.getId());
		if ((appliedStipend != null && appliedStipend.getApplication().getLastAction().getStatus().equals(cache.getStatus(Statuses.TG_APP_REJECTED)) || appliedStipend == null)) {
			// check if TG application was rejected
			config = tgStipendRepository.getLatestStipendConfig(true, tg.getId());// check if TG is one of the appeal successful TG
			isEligible = config != null ? tgHelper.getStipendEligibility(tg, config) : false;
			if (config != null) {
				appliedStipend = tgStipendRepository.getTgStipendByTgAndPeriod(tg.getId(), config.getId());
			}
		}

		dto = TgStipendDto.buildDashboardNotification(cache, appHelper, appliedStipend, isEligible, config);

		return dto;
	}

	// --------- End of web services for TG users --------- //

	// common functions //
	private Long getUserTotalUnreadAlerts() {
		return dashboardRepository.getTotalAlertsUnread(getUser().getId(), getTaTgType());
	}

	private String getTaTgType() {
		if (Codes.Roles.TA_PUBLIC.equals(getSelectedRoleCode())) {
			return Codes.TaTgType.TA;
		} else if (Codes.Roles.TG_PUBLIC.equals(getSelectedRoleCode())) {
			return Codes.TaTgType.TG;
		} else if (Codes.Roles.TP_PUBLIC.equals(getSelectedRoleCode())) {
			return Codes.TaTgType.TP;
		}

		return "";
	}

	// --- end common functions --- //
}
