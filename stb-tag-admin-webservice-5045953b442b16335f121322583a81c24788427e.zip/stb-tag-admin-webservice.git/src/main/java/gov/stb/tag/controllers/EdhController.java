package gov.stb.tag.controllers;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.edh.AppointmentDto;
import gov.stb.tag.dto.edh.EdhDto;
import gov.stb.tag.dto.edh.EdhEntityDto;
import gov.stb.tag.dto.edh.FinancialsDto;
import gov.stb.tag.dto.edh.ShareholderDto;
import gov.stb.tag.helper.EdhHelper;
import gov.stb.tag.model.User;

/**
 * A copy of EDH query result is stored, and subsequently retrieved for Gov data This is to eliminate the risk of user tampers the Gov data via form editing
 */
@RestController
@RequestMapping(path = "/api/v1/edh")
@Transactional
public class EdhController extends BaseController {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	EdhHelper edhHelper;

	@RequestMapping(method = RequestMethod.POST, value = "/snapshot" + Codes.Edh.API_ENTITY, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public EdhEntityDto saveEntitySnapshot(@RequestParam Map<String, String> body) throws UnsupportedEncodingException {
		String jsonText = body.get("jsonText");
		EdhEntityDto dto = saveRawResponse(new EdhEntityDto(), jsonText, Codes.Edh.API_ENTITY);
		return dto.hasError() ? dto : edhHelper.parseEntityRawResponse(dto, jsonText);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/snapshot" + Codes.Edh.API_ENTITY_APPOINTMENTS, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public EdhDto<AppointmentDto> saveEntityAppointmentsSnapshot(@RequestParam Map<String, String> body) {
		String jsonText = body.get("jsonText");
		EdhDto<AppointmentDto> dto = saveRawResponse(new EdhDto<AppointmentDto>(), jsonText, Codes.Edh.API_ENTITY_APPOINTMENTS);
		return dto.hasError() ? dto : edhHelper.parseEntityAppointmentsRawResponse(dto, jsonText);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/snapshot" + Codes.Edh.API_ENTITY_SHAREHOLDERS, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public EdhDto<ShareholderDto> saveEntityShareholdersSnapshot(@RequestParam Map<String, String> body) throws UnsupportedEncodingException {
		String jsonText = body.get("jsonText");
		EdhDto<ShareholderDto> dto = saveRawResponse(new EdhDto<ShareholderDto>(), jsonText, Codes.Edh.API_ENTITY_SHAREHOLDERS);
		return dto.hasError() ? dto : edhHelper.parseEntityShareholdersRawResponse(dto, jsonText);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/snapshot" + Codes.Edh.API_ENTITY_FINANCIALS, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public FinancialsDto saveEntityFinancialsSnapshot(@RequestParam Map<String, String> body) throws UnsupportedEncodingException {
		String jsonText = body.get("jsonText");
		FinancialsDto dto = saveRawResponse(new FinancialsDto(), jsonText, Codes.Edh.API_ENTITY_FINANCIALS);
		return dto.hasError() ? dto : edhHelper.parseEntityFinancialsRawResponse(dto, jsonText);
	}

	private <T extends EdhDto<?>> T saveRawResponse(T dto, String jsonText, String apiName) {
		User user = getUser();
		dto.setUen(user.getUen());
		if (Strings.isNullOrEmpty(jsonText)) {
			dto.setHasError(true);
			dto.setErrorMessage("saveRawResponse(): edh response is blank, uen: " + user.getUen() + ", apiName: " + apiName);
			logger.error("saveRawResponse(): edh response is blank, uen: " + user.getUen() + ", apiName: " + apiName);
		} else {
			try {
				jsonText = URLDecoder.decode(jsonText, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				dto.setHasError(true);
				dto.setErrorMessage(e.getMessage());
				logger.error("saveRawResponse(): " + e.getMessage());
			}
			edhHelper.saveRawResponse(user.getUen(), apiName, jsonText);
		}
		return dto;
	}
}
