package gov.stb.tag.controllers;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.EmailBroadcastType;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.emailing.EmailBroadcastSearchDto;
import gov.stb.tag.dto.emailing.EmailingDto;
import gov.stb.tag.dto.emailing.EmailingItemDto;
import gov.stb.tag.helper.EmailBroadcastHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.model.File;
import gov.stb.tag.repository.EmailBroadcastCommonRepository;
import gov.stb.tag.repository.EmailBroadcastRepository;
import gov.stb.tag.repository.FileRepository;

@RestController
@RequestMapping(path = "/api/v1/email-broadcast")
@Transactional
public class EmailBroadcastController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private EmailBroadcastRepository emailBroadcastRepository;
	@Autowired
	private FileRepository fileRepository;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	EmailBroadcastHelper emailBroadcastHelper;
	@Autowired
	ApplicationContext applicationContext;
	@Autowired
	EmailBroadcastCommonRepository emailBroadcastCommonRepository;

	@RequestMapping(path = { "/{type}/search" }, method = RequestMethod.GET)
	public ResultDto<EmailingItemDto> getAll(@PathVariable String type, EmailBroadcastSearchDto searchDto) {

		return emailBroadcastRepository.getAll(type, searchDto);
	}

	@RequestMapping(path = { "/{type}/view" }, method = RequestMethod.GET)
	public EmailingDto loadTatiComplianceCheck(@PathVariable String type, EmailBroadcastSearchDto searchDto) {
		EmailingDto resultDto = new EmailingDto();
		if (searchDto.getId() != null) {
			logger.info("Get email broadcast for id: {}", searchDto.getId());
			EmailBroadcast model = emailBroadcastRepository.get(EmailBroadcast.class, searchDto.getId());
			resultDto = EmailingDto.buildEmailingDtoFromModel(cache, model, resultDto, userRepository);
		} else {
			resultDto.setIsActive(Boolean.TRUE);
			resultDto.setIsRecurring(Boolean.FALSE);
			resultDto.setEmailType(new ListableDto(cache.getType(Codes.EmailBroadcast.get(type.toUpperCase()))));
			resultDto.setMinStartDate(LocalDate.now());
			resultDto.setIsSending(false);
		}
		resultDto.setSenderEmail(cache.getSystemParameterAsString(Codes.SupportEmail.get(type.toUpperCase())));

		return resultDto;
	}

	// to create/update
	@RequestMapping(value = "/{type}/update", method = RequestMethod.POST)
	public EmailingDto saveEmailBroadcast(@RequestBody EmailingDto dto) throws BeansException, ClassNotFoundException {
		EmailBroadcast model = new EmailBroadcast();
		if (dto.getId() != null) {
			logger.info("Update existing emailBroadcast with id: {}", dto.getId());
			model = emailBroadcastRepository.get(EmailBroadcast.class, dto.getId());
		}

		if (model.isSending() != null && model.isSending()) {
			if (dto.toSend()) {
				dto.setSnackbarMessage("Unable to update and send as email sending is already in progress.");
			} else {
				dto.setSnackbarMessage("Unable to update as email sending is in progress. Try again later.");
			}
		} else {

			model = updateEmailBroadcastValues(model, dto);

			List<Integer> toDeleteList = dto.getDeletedFiles();
			if (toDeleteList != null && !toDeleteList.isEmpty()) {
				for (Integer id : toDeleteList) {
					if (id != null) {
						File attachemnt = new File();
						attachemnt = fileHelper.getFile(id);
						if (attachemnt != null) {
							fileHelper.deleteFile(attachemnt);
						}
					}
				}
			}
			// Only update the description in the files
			fileHelper.updateFilesDescription(dto.getFiles());
			logger.info("Updated emailBroadcast with id: {}", model.getId());

			if (dto.toSend()) {
				model.setIsSending(true);
				dto.setIsSending(true);
			}

			emailBroadcastRepository.saveOrUpdate(model);
		}

		if (dto.getId() == null) {
			dto.setId(model.getId());
		}

		return dto;
	}

	// to send out email immed with new thread
	@RequestMapping(value = "/{type}/update/send-email", method = RequestMethod.POST)
	public void sendEmailBroadcast(@RequestBody EmailBroadcastSearchDto dto) throws BeansException, ClassNotFoundException {
		EmailBroadcast model = emailBroadcastRepository.get(EmailBroadcast.class, dto.getId());
		logger.info("User trigger to send email manually id: {}", model.getId());
		EmailBroadcastSend r = (EmailBroadcastSend) applicationContext.getBean(Class.forName("gov.stb.tag.controllers.EmailBroadcastSend"));
		r.setEmailBroadcastId(model.getId());
		new Thread(r).start();
		logger.info("Complete send email manually id: {}", model.getId());
	}

	private EmailBroadcast updateEmailBroadcastValues(EmailBroadcast model, EmailingDto dto) {
		model.setSubject(dto.getSubject().trim());
		model.setContent(dto.getContent().trim());
		model.setIsActive(dto.getIsActive());
		model.setIsRecurring(dto.getIsRecurring());
		model.setStartDate(dto.getStartDate());
		model.setType(cache.getType(dto.getEmailType().getKey().toString()));
		if (dto.getIsRecurring()) {
			model.setEndDate(dto.getEndDate());
			model.setFrquency(cache.getType(dto.getFrequency().getKey().toString()));
		} else {
			model.setEndDate(null);
			model.setFrquency(null);
		}

		if (dto.getFiles().size() > 0) {
			List<Integer> fileIds = dto.getFiles().parallelStream().map(FileDto::getId).collect(Collectors.toList());
			if (fileIds.size() > 0) {
				List<File> files = fileRepository.getFiles(fileIds);
				model.setFiles(new HashSet<>(files));
			}
		}

		if (dto.getEmailType().getKey().toString().equalsIgnoreCase(EmailBroadcastType.TG)) {
			if (dto.getLicenceStatuses() != null && dto.getLicenceStatuses().length > 0) {
				model.setLicenceStatuses(new HashSet<>(commonRepository.getAllStatuses(dto.getLicenceStatuses(), Boolean.TRUE)));
			}
			if (dto.getGuidingLanguages() != null && dto.getGuidingLanguages().length > 0) {
				model.setGuidingLanguages(new HashSet<>(commonRepository.getAllTypes(dto.getGuidingLanguages(), Boolean.TRUE)));
			}
			if (dto.getTiers() != null && dto.getTiers().length > 0) {
				model.setTiers(new HashSet<>(commonRepository.getAllTypes(dto.getTiers(), Boolean.TRUE)));
			}
		}

		// Calculate next email sending date.
		if (dto.getIsActive()) {
			LocalDate today = LocalDate.now();
			if (dto.getStartDate().isAfter(today)) {
				model.setNextEmailDate(dto.getStartDate());
			} else {
				if (dto.getIsRecurring()) {
					LocalDate newDate = emailBroadcastHelper.calculateNextDate(dto.getIsRecurring(), dto.getFrequency().getKey().toString(), dto.getStartDate());
					while ((newDate.isBefore(today) || newDate.isEqual(today)) && newDate.isBefore(dto.getEndDate())
							&& (emailBroadcastHelper.calculateNextDate(dto.getIsRecurring(), dto.getFrequency().getKey().toString(), newDate).isBefore(dto.getEndDate())
									|| emailBroadcastHelper.calculateNextDate(dto.getIsRecurring(), dto.getFrequency().getKey().toString(), newDate).isEqual(dto.getEndDate()))) {
						newDate = emailBroadcastHelper.calculateNextDate(dto.getIsRecurring(), dto.getFrequency().getKey().toString(), newDate);
					}
					if (newDate.isAfter(today) && (newDate.isBefore(dto.getEndDate()) || newDate.isEqual(dto.getEndDate()))) {
						model.setNextEmailDate(newDate);
					} else {
						model.setNextEmailDate(null);
					}
				} else {
					model.setNextEmailDate(null);
				}
			}
			if (model.getNextEmailDate() == null) {
				model.setIsActive(Boolean.FALSE);
			}
		} else {
			model.setNextEmailDate(null);
		}

		return model;
	}

}
