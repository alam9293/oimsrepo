package gov.stb.tag.controllers;

import java.time.LocalDate;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.helper.EmailBroadcastHelper;
import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.repository.EmailRepository;

@Component
public class EmailBroadcastSend implements Runnable {

	private static final Logger logger = LoggerFactory.getLogger(EmailBroadcastSend.class);
	@Autowired
	EmailRepository emailRepository;
	@Autowired
	EmailBroadcastHelper emailBroadcastHelper;

	private Integer emailBroadcastId;

	public Integer getEmailBroadcastId() {
		return emailBroadcastId;
	}

	public void setEmailBroadcastId(Integer emailBroadcastId) {
		this.emailBroadcastId = emailBroadcastId;
	}

	@Override
	@Transactional
	public void run() {

		EmailBroadcast model = emailRepository.get(EmailBroadcast.class, emailBroadcastId);
		logger.info("Start Email Broadcast Sent id: " + emailBroadcastId);
		try {
			model = emailBroadcastHelper.sendBroadcastEmail(model);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			model = emailBroadcastHelper.updateAfterSent(model, LocalDate.now());
			emailRepository.rebeginTransaction(); // to cater for "Transaction is not in progress" issue which is caused by forced commit batch job eg: TaFilingEmailNotificationJob
			emailRepository.update(model);
			emailRepository.commit(); // so that the model can still be updated even if email server failed to send
			emailRepository.rebeginTransaction();
			logger.info("End Email Broadcast Sent id: " + emailBroadcastId);
		}
	}

}
