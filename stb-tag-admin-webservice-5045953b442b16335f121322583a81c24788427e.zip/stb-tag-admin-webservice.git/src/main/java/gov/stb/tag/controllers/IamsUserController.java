package gov.stb.tag.controllers;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.dto.iams.IamsRoleDto;
import gov.stb.tag.dto.iams.IamsUserDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.IamsUserRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.io.IOException;
import java.util.*;

import org.apache.commons.codec.binary.Base64;


@RestController
@RequestMapping(path = "/api/v1/iams")
@Transactional
public class IamsUserController extends BaseController {
    protected transient Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    IamsUserRepository iamsUserRepository;

    // Create User
    @RequestMapping(method = RequestMethod.POST, value = "/users")
    public IamsUserDto createUser(@RequestBody IamsUserDto dto, HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Creating new user");
        if (dto == null) {
            logger.info("Unable to create user. IamsUserDto is required.");
            throw new ValidationException("Unable to create user.");
        } else {
            createUser(dto);
        }
        return dto;
    }

    // Get all users
    @RequestMapping(method = RequestMethod.GET, value = "/users")
    public List<IamsUserDto> getAllUsers(HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Retrieving all users");
        List<IamsUserDto> users = iamsUserRepository.getAllUsers();
        return users;
    }

    // Get user by login Id
    @RequestMapping(method = RequestMethod.GET, value = "/users/{loginId}")
    public IamsUserDto getUser(@PathVariable String loginId, HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Retrieving user with loginId:{}", loginId);
        User user = iamsUserRepository.getUserByLoginId(loginId);
        if (user == null) {
            logger.info("User with loginId:{} not found", loginId);
            throw new ValidationException("User with loginId:" + loginId + " not found.");
        }
        return new IamsUserDto(user);
    }

    // Update user by login id
    @RequestMapping(method = RequestMethod.PUT, value = "/users/{loginId}")
    public IamsUserDto updateUser(@PathVariable String loginId, @RequestBody IamsUserDto dto, HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Updating user with loginId:{}", loginId);

        User user = iamsUserRepository.getUserByLoginId(loginId);

        if (user == null) {
            logger.info("User with loginId:{} not found", loginId);
            throw new ValidationException("User with loginId:" + loginId + " not found.");
        } else if (dto == null) {
            logger.info("Unable to update user. IamsUserDto is required.");
            throw new ValidationException("Unable to update user.");
        } else {
            dto.setLoginId(loginId);
            updateUser(dto, user);
        }

        return dto;
    }

    // Delete user by login id
    @RequestMapping(method = RequestMethod.DELETE, value = "/users/{loginId}")
    public IamsUserDto deleteUser(@PathVariable String loginId, HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Deleting user with loginId:{}", loginId);
        User user = iamsUserRepository.getUserByLoginId(loginId);
        if (user == null) {
            logger.info("User with loginId:{} not found", loginId);
            throw new ValidationException("User with loginId:" + loginId + " not found.");
        } else {
            user.setStatus(cache.getStatus(Codes.Statuses.USER_INACTIVE));
        }
        return new IamsUserDto(user);
    }

    // Get all roles
    @RequestMapping(method = RequestMethod.GET, value = "/roles")
    public List<IamsRoleDto> getAllRoles(HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Retrieving all roles");
        List<IamsRoleDto> roles = iamsUserRepository.getAllRoles();
        return roles;
    }

    // Get role by code
    @RequestMapping(method = RequestMethod.GET, value = "/roles/{code}")
    public IamsRoleDto getRole(@PathVariable String code, HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Retrieving role with code:{}", code);
        Role role = iamsUserRepository.getRoleByCode(code);
        if (role == null) {
            logger.info("Role with code:{} not found", code);
            throw new ValidationException("Role with code:" + code + " not found.");
        }
        return new IamsRoleDto(role);
    }

    // Update user roles (assign/unassign)
    @RequestMapping(method = RequestMethod.PUT, value = "/user-roles/{loginId}")
    public List<IamsRoleDto> updateUserRoles(@PathVariable String loginId, @RequestBody List<IamsRoleDto> roleDtoList, HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Updating user roles with loginId:{}", loginId);

        User user = iamsUserRepository.getUserByLoginId(loginId);

        if (user == null) {
            logger.info("User with loginId:{} not found", loginId);
            throw new ValidationException("User with loginId:" + loginId + " not found.");
        } else {
            Set<Role> roles = new HashSet<>();

            for (IamsRoleDto dto : roleDtoList) {
                Role role = userRepository.getRole(dto.getCode());
                if (role == null) {
                    logger.info("Unable to update user roles. Role:{} does not exist.", dto.getCode());
                    throw new ValidationException("Unable to update user roles. Role does not exist:" + dto.getCode());
                }
                roles.add(role);
            }
            user.setRoles(roles);
        }

        return roleDtoList;
    }

    // Get user roles by login id
    @RequestMapping(method = RequestMethod.GET, value = "/user-roles/{loginId}")
    public List<IamsRoleDto> getUserRoles(@PathVariable String loginId, HttpServletRequest request) {
        authenticateRequest(request);
        logger.info("Retrieving user roles with loginId:{}", loginId);

        User user = iamsUserRepository.getUserByLoginId(loginId);
        List<IamsRoleDto> roleDtoList = new ArrayList<>();

        if (user == null) {
            logger.info("User with loginId:{} not found", loginId);
            throw new ValidationException("User with loginId:" + loginId + " not found.");
        }

        for (Role role : user.getRoles()) {
            roleDtoList.add(new IamsRoleDto(role));
        }

        return roleDtoList;
    }


    private User createUser(IamsUserDto dto) {
        validateIamsUserDto(dto, true);
        User user = iamsUserRepository.getUserByLoginId(dto.getLoginId().trim());

        if (user != null) {
            logger.info("Unable to create user. User with login ID:{} exist.", dto.getLoginId());
            throw new ValidationException("Unable to create user. User with login ID:" + dto.getLoginId() + " exist.");
        }

        user = new User();
        user.setLoginId(dto.getLoginId());
        setUserValue(dto, user);

        logger.info("User with login ID:{} created.", dto.getLoginId());

        return user;
    }

    private User updateUser(IamsUserDto dto, User user) {
        validateIamsUserDto(dto, false);
        setUserValue(dto, user);
        return user;
    }

    private void setUserValue(IamsUserDto dto, User user) {
        user.setEmailAddress(dto.getEmailAddress());
        user.setName(dto.getName());
        user.setDepartment(cache.getType(dto.getDepartmentCode()));
        user.setStatus(cache.getStatus(dto.getStatusCode()));
        user.setType(cache.getType(dto.getTypeCode()));
        iamsUserRepository.saveOrUpdate(user);
    }

    private void validateIamsUserDto(IamsUserDto dto, Boolean isNew) {
        String msg = null;
        if (StringUtils.isBlank(dto.getTypeCode())) {
            msg = "Unable to create user. Type Code is required.";
        } else if (!dto.getTypeCode().equals(Codes.UserTypes.USER_STB)) {
            logger.info("Unable to create user for user type:{}", dto.getTypeCode());
            throw new ValidationException("Unable to create user for user type:" + dto.getTypeCode());
        } else if (StringUtils.isBlank(dto.getLoginId()) && isNew) {
            msg = "Unable to create user. Login ID is required.";
        } else if (StringUtils.isBlank(dto.getEmailAddress())) {
            msg = "Unable to create user. Email address is required.";
        } else if (StringUtils.isBlank(dto.getName())) {
            msg = "Unable to create user. Name is required.";
        } else if (StringUtils.isBlank(dto.getDepartmentCode())) {
            msg = "Unable to create user. Department Code is required.";
        } else if (cache.getType(dto.getDepartmentCode()) == null) {
            msg = "Unable to create user. Department Code is invalid.";
        } else if (StringUtils.isBlank(dto.getStatusCode())) {
            msg = "Unable to create user. Status Code is required.";
        } else if (cache.getStatus(dto.getStatusCode()) == null) {
            msg = "Unable to create user. Status Code is invalid.";
        } else if (cache.getType(dto.getTypeCode()) == null) {
            msg = "Unable to create user. Type Code is invalid.";
        }

        if (!StringUtils.isBlank(msg)) {
            logger.info(msg);
            throw new ValidationException(msg);
        }
    }

    // Authenticate Basic Authentication
    public void authenticateRequest(HttpServletRequest request) {
        String authString = request.getHeader(Codes.Headers.BASIC_AUTH);
        if (!isUserAuthenticated(authString)) {
            throw new InsufficientAuthenticationException(Messages.Errors.LOGIN_PASSWORD_INCORRECT);
        }
    }

    private boolean isUserAuthenticated(String authString){
        if (StringUtils.isBlank(authString)) {
            return false;
        }

        // header value format will be "Basic encodedstring" for Basic
        // authentication. Example "Basic YWRtaW46YWRtaW4="
        final String encodedUserPassword = authString.replaceFirst("Basic" + " ", "");
        String usernameAndPassword = null;
        // Decode the data back to original
        try {
            byte[] decodedBytes = Base64.decodeBase64(encodedUserPassword);
            usernameAndPassword = new String(decodedBytes, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        final StringTokenizer tokenizer = new StringTokenizer(usernameAndPassword, ":");
        final String username = tokenizer.nextToken();
        final String password = tokenizer.nextToken();

        boolean authenticationStatus = properties.iamsUsername.equals(username) && properties.iamsPassword.equals(password);
        return authenticationStatus;
    }


}
