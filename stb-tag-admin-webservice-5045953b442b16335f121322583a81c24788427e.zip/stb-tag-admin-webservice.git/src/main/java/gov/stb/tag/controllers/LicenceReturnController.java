package gov.stb.tag.controllers;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.licencereturn.LicenceReturnBatchDto;
import gov.stb.tag.dto.licencereturn.LicenceReturnBatchItemDto;
import gov.stb.tag.dto.licencereturn.LicenceReturnBatchSearchDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceReturnHelper;
import gov.stb.tag.model.LicenceReturnBatch;
import gov.stb.tag.repository.LicenceReturnRepository;

@RestController
@RequestMapping(path = "/api/v1/licence-return")
@Transactional
public class LicenceReturnController extends BaseController {

	@Autowired
	LicenceReturnRepository licenceReturnRepository;
	@Autowired
	LicenceReturnHelper licenceReturnHelper;
	@Autowired
	FileHelper fileHelper;

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@RequestMapping(value = "/ta/view", method = RequestMethod.GET)
	public ResultDto<LicenceReturnBatchItemDto> getList(LicenceReturnBatchSearchDto searchDto) {

		return licenceReturnRepository.getPendingList(searchDto);

	}

	@RequestMapping(value = "/ta/view/{id}", method = RequestMethod.GET)
	public LicenceReturnBatchDto getBatchRecord(@PathVariable Integer id) {
		LicenceReturnBatch lrb = licenceReturnRepository.getBatchRecord(id);
		LicenceReturnBatchDto result = LicenceReturnBatchDto.build(cache, lrb, fileHelper);
		return result;
	}

	@RequestMapping(value = "/return/{id}", method = RequestMethod.POST)
	public void markAsReturned(@RequestBody List<Integer> licences, @PathVariable Integer id) {
		licenceReturnHelper.markAsReturned(licences, id);

	}

	@RequestMapping(value = "/void/{id}", method = RequestMethod.POST)
	public void markAsVoid(@PathVariable Integer id) {

		licenceReturnHelper.voidBatchRecord(id);

	}

}
