package gov.stb.tag.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.api.util.ApiSecurity.ApiUtilException;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.TestMoneyDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.AaFilingForRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.AaSubmissionForRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.AbprFilingForRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaLicenceRenewalExerciseGroupDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaLicenceRenewalExerciseParticipantDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TravelAgentForRenewalDto;
import gov.stb.tag.dto.test.TestDateDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.CpfHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PasswordHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.SmsHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.helper.signdoc.CeTaFieldReportPdfHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Bulletin;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.Job;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.SmsLog;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaBranchApplication;
import gov.stb.tag.model.TaBranchApplicationBatch;
import gov.stb.tag.model.TaBusinessOperation;
import gov.stb.tag.model.TaCompanyUpdate;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFocusArea;
import gov.stb.tag.model.TaFunctionActivity;
import gov.stb.tag.model.TaFyUpdate;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaLicenceCessation;
import gov.stb.tag.model.TaLicenceReplacement;
import gov.stb.tag.model.TaLicenceTierSwitch;
import gov.stb.tag.model.TaSpecializedMarket;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TgAssignment;
import gov.stb.tag.model.TgAssignmentDate;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgCourseAttendanceDetail;
import gov.stb.tag.model.TgLicenceCreation;
import gov.stb.tag.model.TgPersonUpdate;
import gov.stb.tag.model.TgPrintColour;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.BaseRepository;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.TaCommonRepository;
import gov.stb.tag.repository.TestRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaLicenceRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.repository.tg.TgCandidateRepository;
import gov.stb.tag.repository.tg.TgCourseAttendanceDetailRepository;
import gov.stb.tag.repository.tg.TgCourseAttendanceRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgLicenceCreationRepository;
import gov.stb.tag.repository.tg.TgLicencePrintRepository;
import gov.stb.tag.repository.tg.TgTrainingProviderRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.EncryptionUtil;

// TODO: FOR TESTING ONLY, TO BE REMOVED IN PRODUCTION
@RestController
@RequestMapping(path = "/api/v1/test")
@Transactional
public class TestController extends BaseController {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	BaseRepository baseRepository;

	@Autowired
	CommonRepository commonRepository;

	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	CpfHelper cpfHelper;

	@Autowired
	TaLicenceRepository taLicenceRepository;
	@Autowired
	TravelAgentRepository taRepository;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	TgCandidateRepository tgCandidateRepository;
	@Autowired
	TestRepository testRepository;
	@Autowired
	TouristGuideRepository tgRepository;
	@Autowired
	TgTrainingProviderRepository tpRepository;
	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgCourseAttendanceRepository tgCourseAttendanceRepository;
	@Autowired
	TgCourseAttendanceDetailRepository tgCourseAttendanceDetailRepository;
	@Autowired
	TgLicencePrintRepository tgLicencePrintRepository;
	@Autowired
	TgLicenceCreationRepository tgLicenceCreationRepository;
	@Autowired
	TaRenewalRepository taRenewalRepository;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	SmsHelper smsHelper;
	@Autowired
	Properties properties;
	@Autowired
	TaNetValueShortfallRepository taShortfallrepo;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;
	@Autowired
	TaCommonRepository taCommonRepository;
	@Autowired
	CeTaFieldReportPdfHelper ceTaFieldReportPdfHelper;

	private static String APLHABETS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	// http://localhost:9191/webservice-admin/api/v1/test/signdoc-pdf
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/signdoc-pdf")
	public String testSigndocPdf() {
		byte[] pdf = ceTaFieldReportPdfHelper.generatePdf(null);
		return ceTaFieldReportPdfHelper.preloadToSigndoc(pdf, "https://trust-dev.stb.gov.sg/sdweb/result/index?showoptions=true");
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-licence/{number}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-licence/{number}")
	public String createTaLicence(@PathVariable Integer number) {
		for (int i = 0; i < number; i++) {
			setTaLicence(true);
		}

		return number + " TA licences successfully created";

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-abpr/{number}/{fy}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-abpr/{licenceId}/{fy}")
	public String createTaAbpr(@PathVariable Integer licenceId, @PathVariable Integer fy) {
		Licence licence = testRepository.get(Licence.class, licenceId);

		// Application
		Application app = new Application();
		app.setLicence(licence);
		app.setIsDeleted(false);
		app.setTaTgType(Codes.TaTgType.TA);
		app.setSubmissionDate(LocalDateTime.now());
		app.setType(cache.getType(Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION));
		WorkflowAction wfa = new WorkflowAction();
		wfa.setApplication(app);
		wfa.setStatus(cache.getStatus(Codes.Statuses.TA_APP_APPROVED));

		// Annual Filing
		TaFilingCondition taf = new TaFilingCondition();
		taf.setApplicationType(cache.getType(Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION));
		taf.setFy(fy);
		taf.setFyStartDate(LocalDate.of(fy, 1, 1));
		taf.setFyEndDate(LocalDate.of(fy, 12, 31));
		taf.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_APPROVED));
		taf.setLicence(licence);

		// ABPR
		TaAbprSubmission abpr = new TaAbprSubmission();
		abpr.setInboundOpPercent(new BigDecimal(50));
		abpr.setOutboundOpPercent(new BigDecimal(50));
		abpr.setInboundOp(new BigDecimal(500));
		abpr.setOutboundOp(new BigDecimal(500));
		abpr.setInboundGrpPax(50);
		abpr.setInboundGrpPaxPercent(new BigDecimal(50));
		abpr.setInboundFitPax(50);
		abpr.setInboundFitPaxPercent(new BigDecimal(50));
		abpr.setOutboundFitPax(50);
		abpr.setOutboundFitPaxPercent(new BigDecimal(50));
		abpr.setOutboundGrpPax(50);
		abpr.setOutboundGrpPaxPercent(new BigDecimal(50));
		abpr.setOperatingCost(new BigDecimal(500));
		abpr.setNoOfEmployee(10);
		abpr.setDepreciation(new BigDecimal(0));
		abpr.setRemuneration(new BigDecimal(50));
		abpr.setIndirectTax(new BigDecimal(50));
		abpr.setHasOverseasBranch(false);
		List<TaSpecializedMarket> mss = new ArrayList<>();
		TaSpecializedMarket ms1 = new TaSpecializedMarket();
		ms1.setCountry(cache.getCountries().stream().findFirst().get());
		ms1.setIsInbound(true);
		ms1.setPercent(new BigDecimal(100));
		ms1.setTaAbprSubmission(abpr);
		mss.add(ms1);
		TaSpecializedMarket ms2 = new TaSpecializedMarket();
		ms2.setCountry(cache.getCountries().stream().findFirst().get());
		ms2.setIsInbound(false);
		ms2.setPercent(new BigDecimal(100));
		ms2.setTaAbprSubmission(abpr);
		mss.add(ms2);
		abpr.setTaSpecializedMarkets(new HashSet<>(mss));
		List<TaBusinessOperation> bos = new ArrayList<>();
		TaBusinessOperation bo1 = new TaBusinessOperation();
		bo1.setInboundPercent(new BigDecimal(50));
		bo1.setOutboundPercent(new BigDecimal(50));
		bo1.setInbound(new BigDecimal(500));
		bo1.setOutbound(new BigDecimal(500));
		bo1.setIsInboundOwned(true);
		bo1.setIsInboundOwned(false);
		bo1.setService(cache.getTaServices().stream().findFirst().get());
		bo1.setTaAbprSubmission(abpr);
		bos.add(bo1);
		abpr.setTaBusinessOperations(new HashSet<>(bos));
		List<TaFocusArea> aofs = new ArrayList<>();
		TaFocusArea aof1 = new TaFocusArea();
		aof1.setFocusArea(cache.getTaFocusAreas().stream().findFirst().get());
		aof1.setHasInboundOp(true);
		aof1.setHasOutboundOp(true);
		aof1.setRemarks("Some remarks");
		aof1.setTaAbprSubmission(abpr);
		aofs.add(aof1);
		abpr.setTaFocusAreas(new HashSet<>(aofs));
		List<TaFunctionActivity> fas = new ArrayList<>();
		TaFunctionActivity fa1 = new TaFunctionActivity();
		fa1.setQuestion(cache.getTaFunctionActivity().stream().findFirst().get());
		fa1.setIsInbound(true);
		fa1.setIsOutbound(true);
		fa1.setTaAbprSubmission(abpr);
		fas.add(fa1);
		abpr.setTaFunctionActivities(new HashSet<>(fas));
		abpr.setTaAnnualFiling(taf);
		abpr.setApplication(app);

		testRepository.save(wfa);
		app.setLastAction(wfa);
		testRepository.save(app);
		testRepository.save(taf);
		testRepository.save(abpr.getTaBusinessOperations());
		testRepository.save(abpr.getTaFocusAreas());
		testRepository.save(abpr.getTaSpecializedMarkets());
		testRepository.save(abpr.getTaFunctionActivities());
		testRepository.save(abpr);
		return "ABPR successfully added for licence no: " + licenceId + " of year: " + fy;

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-aa/{licenceId}/{fy}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-aa/{licenceId}/{fy}")
	public String createTaAA(@PathVariable Integer licenceId, @PathVariable Integer fy) {
		Licence licence = testRepository.get(Licence.class, licenceId);

		// Application
		Application app = new Application();
		app.setLicence(licence);
		app.setTaTgType(Codes.TaTgType.TA);
		app.setSubmissionDate(LocalDateTime.now());
		app.setType(cache.getType(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION));
		WorkflowAction wfa = new WorkflowAction();
		wfa.setApplication(app);
		wfa.setStatus(cache.getStatus(Codes.Statuses.TA_APP_APPROVED));

		// Annual Filing
		TaFilingCondition taf = new TaFilingCondition();
		taf.setApplicationType(cache.getType(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION));
		taf.setFy(fy);
		taf.setFyStartDate(LocalDate.of(fy, 1, 1));
		taf.setFyEndDate(LocalDate.of(fy, 12, 31));
		taf.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_APPROVED));
		taf.setLicence(licence);

		// AA
		TaAaSubmission aa = new TaAaSubmission();
		aa.setApplication(app);
		aa.setTaAnnualFiling(taf);
		aa.setCapital(new BigDecimal(200000));
		aa.setTotalAssets(new BigDecimal(200000));
		aa.setTotalLiabilities(new BigDecimal(0));
		aa.setRevenue(new BigDecimal(100000));

		testRepository.save(wfa);
		app.setLastAction(wfa);
		testRepository.save(app);
		testRepository.save(taf);
		testRepository.save(aa);
		return "AA successfully added for licence no: " + licenceId + " of year: " + fy;

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-licence/no-branch/{number}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-licence/no-branch/{number}")
	public String createTaLicenceWithoutBranches(@PathVariable Integer number) {
		for (int i = 0; i < number; i++) {
			setTaLicence(false);
		}

		return number + "TA licences successfully created";

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-cessation/{licenceId}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-cessation/{licenceId}")
	public String createTaCessation(@PathVariable Integer licenceId) {
		Application app = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_CESSATION, licenceId, false, false);
		appHelper.forward(app, true);

		TaLicenceCessation cessation = new TaLicenceCessation();
		cessation.setApplication(app);
		cessation.setReason(cache.getTypesByCategory("TA_RESN_CEASE").stream().filter(o -> !o.getCode().equals(Codes.Types.TA_REASON_CEASE_OTHERS)).findFirst().get());
		cessation.setEffectiveDate(LocalDate.now());
		baseRepository.save(cessation);

		return "TA Cessation Application successfully created";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-fye/{licenceId}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-fye/{licenceId}")
	public String createTaFyeUpdate(@PathVariable Integer licenceId) {
		Application app = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_FY_UPDATE, licenceId, false, false);
		appHelper.forward(app, true);

		TaFyUpdate fyAppl = new TaFyUpdate();
		fyAppl.setApplication(app);
		fyAppl.setFyStartDate(app.getLicence().getStartDate());
		fyAppl.setOldFyeDate(DateUtil.parseDate("06-Jan-2020"));
		fyAppl.setNewFyeDate(DateUtil.parseDate("31-Mar-2020"));
		fyAppl.setReason("Test Controller");
		baseRepository.save(fyAppl);

		return "TA Fy Update Application successfully created";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/update-ta-cessation/{applicationId}/{statusCode}
	@RequestMapping(method = RequestMethod.GET, value = "/update-ta-cessation/{applicationId}/{statusCode}")
	public String updateTaCessation(@PathVariable Integer applicationId, @PathVariable String statusCode) {
		Application app = baseRepository.get(Application.class, applicationId);
		appHelper.saveAction(app, statusCode);

		return "TA Cessation Application successfully updated from " + app.getLastAction().getPrevStatus().getLabel() + " to " + app.getLastAction().getStatus().getLabel();
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-switch-licence/{licenceId}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-switch-licence/{licenceId}")
	public String createTaSwitchLicence(@PathVariable Integer licenceId) {
		Application app = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_TIER_SWITCH, licenceId, false, false);
		appHelper.forward(app, true);

		TaLicenceTierSwitch tierSwitch = new TaLicenceTierSwitch();
		tierSwitch.setApplication(app);
		tierSwitch.setOldLicenceTier(cache.getType(Codes.Types.TA_TIER_GENERAL));
		tierSwitch.setNewLicenceTier(cache.getType(Codes.Types.TA_TIER_NICHE));
		baseRepository.save(tierSwitch);

		return "TA switch tier Application successfully created";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-replacement/{licenceId}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-replacement/{licenceId}")
	public String createTaReplacement(@PathVariable Integer licenceId) {
		Application app = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_REPLACEMENT, licenceId, false, false);
		appHelper.forward(app, true);

		TaLicenceReplacement tlr = new TaLicenceReplacement();
		tlr.setApplication(app);
		tlr.setReason(cache.getTypesByCategory("TA_RESN_CEASE").stream().filter(o -> !o.getCode().equals(Codes.Types.TA_REASON_REPLACE_OTHERS)).findFirst().get());
		PaymentRequest pr = paymentHelper.savePaymentRequest(app.getApplicationNo(), Codes.TaPaymentRequestTypes.PAYREQ_TA_REPLACEMENT, app.getLicence().getTravelAgent().getUen(),
				app.getLicence().getTravelAgent().getName(), new BigDecimal(10), null, null, true, true);
		tlr.setBillRefNo(pr.getBillRefNo());
		baseRepository.save(tlr);

		return "TA Replacement Application successfully created";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-branch-licence/{licenceId}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-branch-licence/{licenceId}")
	public String createTaBranchLicence(@PathVariable Integer licenceId) {
		SecureRandom r = new SecureRandom();
		Application application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_BRANCH, licenceId, false, false);
		appHelper.forward(application, true);

		TaBranchApplicationBatch taBranchApplicationBatch = new TaBranchApplicationBatch();
		taBranchApplicationBatch.setApplication(application);
		baseRepository.save(taBranchApplicationBatch);
		int numOfBranch = r.nextInt(10);

		for (int i = 0; i < numOfBranch; i++) {
			TaBranch taBranch = new TaBranch();
			taBranch.setLicence(baseRepository.get(Licence.class, licenceId));
			taBranch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_PROCESSING_APPROVAL));
			Address branchAdd = new Address();
			branchAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			String postalCode = "";
			for (int k = 0; k < 6; k++) {
				postalCode += r.nextInt(10);
			}
			branchAdd.setPostal(postalCode);
			branchAdd.setPremiseType(cache.getType("PREM_21"));
			branchAdd.setStreet("Sesame Street");
			String blk = "";
			for (int k = 0; k < 3; k++) {
				blk += r.nextInt(10);
			}
			branchAdd.setBlock(blk);

			TaBranchApplication taBranchApplication = new TaBranchApplication();
			taBranchApplication.setTaBranchApplicationBatch(taBranchApplicationBatch);
			taBranchApplication.setAddress(branchAdd);
			int count = r.nextInt(3);
			if (count == 0) {
				taBranchApplication.setType(cache.getType(Codes.Types.TA_APP_BRANCH_NEW));
			} else if (count == 1) {
				taBranchApplication.setType(cache.getType(Codes.Types.TA_APP_BRANCH_UPDATE));
			} else if (count == 2) {
				taBranchApplication.setType(cache.getType(Codes.Types.TA_APP_BRANCH_CEASE));
			}

			taBranchApplication.setStatus(cache.getStatus(Codes.Statuses.TA_APP_PENDING_PO));
			taBranchApplication.setTaBranch(taBranch);
			baseRepository.save(taBranch);
			baseRepository.save(branchAdd);
			baseRepository.save(taBranchApplication);
		}
		return "TA Branch Application successfully created";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-company-update/{licenceId}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-company-update/{licenceId}")
	public String createTaCompanyUpdate(@PathVariable Integer licenceId) {
		SecureRandom r = new SecureRandom();
		Application application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_COMPANY_UPDATE, licenceId, false, false);
		appHelper.forward(application, true);

		TaCompanyUpdate taCompanyUpdate = new TaCompanyUpdate();
		taCompanyUpdate.setApplication(application);

		Address operatingAddress = new Address();
		operatingAddress.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		String postalCode = "";
		for (int k = 0; k < 6; k++) {
			postalCode += r.nextInt(10);
		}
		operatingAddress.setPostal(postalCode);
		operatingAddress.setPremiseType(cache.getPremiseTypes().get(r.nextInt(cache.getPremiseTypes().size())));
		operatingAddress.setStreet("Sesame Street");
		String blk = "";
		for (int k = 0; k < 3; k++) {
			blk += r.nextInt(10);
		}
		operatingAddress.setBlock(blk);
		taCompanyUpdate.setOperatingAddress(operatingAddress);
		baseRepository.save(operatingAddress);

		Address registeredAddress = new Address();
		registeredAddress.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		String registeredAddressPostalCode = "";
		for (int k = 0; k < 6; k++) {
			registeredAddressPostalCode += r.nextInt(10);
		}
		registeredAddress.setPostal(registeredAddressPostalCode);
		registeredAddress.setPremiseType(cache.getPremiseTypes().get(r.nextInt(cache.getPremiseTypes().size())));
		registeredAddress.setStreet("Sesame Street");
		String registeredAddressBlk = "";
		for (int k = 0; k < 3; k++) {
			registeredAddressBlk += r.nextInt(10);
		}
		registeredAddress.setBlock(registeredAddressBlk);
		baseRepository.save(registeredAddress);
		taCompanyUpdate.setRegisteredAddress(registeredAddress);

		taCompanyUpdate.setPrincipleActivities(cache.getPrincipleActivities().get(r.nextInt(cache.getPrincipleActivities().size())));
		taCompanyUpdate.setSecondaryPrincipleActivities(cache.getPrincipleActivities().stream().filter(o -> !o.getCode().equals(taCompanyUpdate.getPrincipleActivities())).findFirst().get());
		// random uen
		String uen = "";
		for (int i = 0; i < 8; i++) {
			uen += r.nextInt(10);
		}
		uen += APLHABETS.charAt(r.nextInt(APLHABETS.length()));

		taCompanyUpdate.setCompanyName(uen.charAt(uen.length() - 1) + "TA " + uen);
		taCompanyUpdate.setPaidUpCapital(new BigDecimal(100000));
		taCompanyUpdate.setWebsiteUrl("http://www.wiz-elmo" + uen + ".com");
		taCompanyUpdate.setEmailAddress("wiz-elmo" + uen + "@wizvision.com");
		taCompanyUpdate.setContactNo("6666 6666");
		taCompanyUpdate.setEstablishmentStatus(cache.getEstablishmentStatuses().get(r.nextInt(cache.getEstablishmentStatuses().size())));
		taCompanyUpdate.setFormOfBusiness(cache.getFormOfBusiness().get(r.nextInt(cache.getFormOfBusiness().size())));
		taCompanyUpdate.setTaSegmentation(cache.getTaSegmentations().get(r.nextInt(cache.getTaSegmentations().size())));
		taCompanyUpdate.setPlaceIncorporated(cache.getCountries().get(r.nextInt(cache.getCountries().size())));

		baseRepository.save(taCompanyUpdate);
		return "TA Company Update successfully created";
	}

	public static List<Type> pickNRandomType(List<Type> lst, int n) {
		List<Type> copy = new LinkedList<Type>(lst);
		Collections.shuffle(copy);
		return copy.subList(0, n);
	}

	private void setTaLicence(Boolean withBranches) {
		SecureRandom r = new SecureRandom();
		TravelAgent ta = new TravelAgent();

		// random uen
		String uen = "";
		for (int i = 0; i < 8; i++) {
			uen += r.nextInt(10);
		}
		uen += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
		ta.setUen(uen);

		// random incorporated date
		int ranYear = r.nextInt(28) + 1990;
		int ranMonth = r.nextInt(12) + 1;
		int ranDate = r.nextInt(28) + 1;
		ta.setIncorporatedDate(LocalDate.of(ranYear, ranMonth, ranDate));

		// hard coded variables
		ta.setName(uen.charAt(uen.length() - 1) + "TA " + uen);
		ta.setPaidUpCapital(new BigDecimal(100000));
		ta.setWebsiteUrl("http://www.wiz-elmo.com");
		ta.setEmailAddress("wiz-elmo@wizvision.com");
		ta.setContactNo("6666 6666");
		ta.setFyeDate(LocalDate.now().minusYears(1).minusDays(1));
		ta.setPrincipleActivities(cache.getPrincipleActivities().stream().findFirst().get());
		ta.setSecondaryPrincipleActivities(cache.getPrincipleActivities().stream().filter(o -> !o.getCode().equals(ta.getPrincipleActivities())).findFirst().get());
		ta.setEstablishmentStatus(cache.getEstablishmentStatuses().stream().findFirst().get());
		ta.setIncorporatedPlace(cache.getCountries().stream().findFirst().get());
		ta.setFormOfBusiness(cache.getFormOfBusiness().stream().findFirst().get());
		ta.setTaSegmentation(cache.getTaSegmentations().stream().findFirst().get());
		ta.setBusinessConstitution(cache.getBusinessConstitution().stream().findFirst().get());

		// registered address
		Address registered = new Address();
		registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		registered.setPostal("000000");
		registered.setStreet("Sesame Street");
		registered.setBlock("10");
		registered.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		ta.setRegisteredAddress(registered);

		// operating address
		Address operating = new Address();
		operating.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		operating.setPostal("000000");
		operating.setStreet("Sesame Street");
		operating.setBlock("10");
		operating.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		ta.setOperatingAddress(operating);
		// set 10 payments
		for (int i = 0; i < 10; i++) {
			paymentHelper.savePaymentRequest("REFNO" + i, Codes.CePaymentRequestTypes.PAYREQ_CE_AFP, uen, ta.getName(), new BigDecimal(100), "This is a test description count : " + i, null, false,
					true);
		}

		// Set inbound/outbound services
		List<Type> inboundRandomPicks = pickNRandomType(cache.getTaServices(), 3);
		Set<Type> inboundServices = new HashSet<>(inboundRandomPicks);
		ta.setInboundServices(inboundServices);

		List<Type> outboundRandomPicks = pickNRandomType(cache.getTaServices(), 3);
		Set<Type> outboundServices = new HashSet<>(outboundRandomPicks);
		ta.setOutboundServices(outboundServices);

		// licence
		Licence licence = new Licence();
		licence.setTravelAgent(ta);
		licence.setTaTgType(Codes.TaTgType.TA);
		licence.setTier(cache.getType(Codes.Types.TA_TIER_GENERAL));
		licence.setExpiryDate(LocalDate.of(2019, 12, 31));
		licence.setStartDate(LocalDate.of(2017, 01, 01));
		licence.setIssueDate(LocalDate.of(2017, 01, 01));
		licence.setStatus(cache.getStatus(Codes.Statuses.TA_ACTIVE));

		// ke
		TaStakeholder ke = new TaStakeholder();
		ke.setAppointedDate(LocalDate.of(2000, 01, 01));
		ke.setLicence(licence);
		ke.setRole(cache.getType(Codes.TaStakeholderRoles.STKHLD_KE));
		Stakeholder keDetails = new Stakeholder();
		keDetails.setIsCompany(false);
		String nric = "";
		for (int k = 0; k < 7; k++) {
			nric += r.nextInt(10);
		}
		nric += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
		keDetails.setUin(nric);
		keDetails.setName("KE " + nric);
		int ranYear2 = r.nextInt(50) + 1960;
		int ranMonth2 = r.nextInt(12) + 1;
		int ranDate2 = r.nextInt(28) + 1;
		keDetails.setDob(LocalDate.of(ranYear2, ranMonth2, ranDate2));
		keDetails.setContactNo("6666 6666");
		keDetails.setHighestEduLevel(cache.getEducationLevels().stream().findFirst().get());
		keDetails.setDesignation(cache.getOccupations().stream().findFirst().get());
		keDetails.setSex(cache.getType(Codes.Types.SEX_M));
		keDetails.setNationality(cache.getNationalities().stream().findFirst().get());
		keDetails.setEmail("wiz-elmo@wizvision-tag.com");
		Address keAdd = new Address();
		keAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		keAdd.setPostal("000000");
		keAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		keAdd.setStreet("Sesame Street");
		keAdd.setBlock("10");
		keDetails.setAddress(keAdd);
		ke.setStakeholder(keDetails);

		List<TaKeDeclaration> declarations = new ArrayList<>();
		for (TaKeClause clause : cache.getTaKeClauses()) {
			TaKeDeclaration declaration = new TaKeDeclaration();
			declaration.setTaKeClause(clause);
			if (clause.isOptionsRequired()) {
				List<String> options = Arrays.asList(clause.getOptions().split("\\|"));
				declaration.setOptionSelected(options.stream().filter(o -> !o.equals(clause.getOptionsToPrompt())).findFirst().get());

			}
			declaration.setTaKeyExecutive(ke);
			declarations.add(declaration);

		}

		// stakeholders
		List<TaStakeholder> stakeholders = new ArrayList<>();
		for (int i = 0; i < 3; i++) {
			TaStakeholder taStakeholder = new TaStakeholder();
			taStakeholder.setAppointedDate(LocalDate.of(2000, 01, 01));
			taStakeholder.setSharesHeld(1000);
			taStakeholder.setLicence(licence);
			taStakeholder.setRole(cache.getStakeholderRoles().stream().filter(o -> !o.getCode().equals(Codes.TaStakeholderRoles.STKHLD_KE)).findFirst().get());
			Stakeholder stakeholder = new Stakeholder();
			stakeholder.setIsCompany(false);
			String stakeholderId = "";
			for (int k = 0; k < 7; k++) {
				stakeholderId += r.nextInt(10);
			}
			stakeholderId += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			stakeholder.setUin(stakeholderId);
			stakeholder.setName("Personnel " + stakeholderId);
			stakeholder.setSex(cache.getType(Codes.Types.SEX_M));
			stakeholder.setNationality(cache.getNationalities().stream().findFirst().get());
			Address stakeholderAdd = new Address();
			stakeholderAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			stakeholderAdd.setPostal("000000");
			stakeholderAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
			stakeholderAdd.setStreet("Sesame Street");
			stakeholderAdd.setBlock("10");
			stakeholder.setAddress(stakeholderAdd);
			taStakeholder.setStakeholder(stakeholder);
			stakeholders.add(taStakeholder);
		}

		// branch
		List<TaBranch> branches = new ArrayList<>();
		int branchCounts = withBranches ? 3 : 0;
		for (int i = 0; i < branchCounts; i++) {
			TaBranch branch = new TaBranch();
			branch.setLicence(licence);
			branch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_ACTIVE));
			Address branchAdd = new Address();
			branchAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			String postalCode = "";
			for (int k = 0; k < 6; k++) {
				postalCode += r.nextInt(10);
			}
			branchAdd.setPostal(postalCode);
			branchAdd.setPremiseType(cache.getType("PREM_21"));
			branchAdd.setStreet("Sesame Street");
			String blk = "";
			for (int k = 0; k < 3; k++) {
				blk += r.nextInt(10);
			}
			branchAdd.setBlock(blk);
			branch.setAddress(branchAdd);
			branches.add(branch);
		}

		// saving
		licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TA_ACTIVE);
		baseRepository.save(ta.getRegisteredAddress());
		baseRepository.save(ta.getOperatingAddress());
		baseRepository.save(licence);
		ta.setLicence(licence);
		baseRepository.save(ta);
		baseRepository.saveOrUpdate(keDetails.getAddress());
		baseRepository.saveOrUpdate(keDetails);
		baseRepository.saveOrUpdate(ke);
		baseRepository.save(declarations);
		stakeholders.stream().forEach(o -> {
			baseRepository.save(o.getStakeholder().getAddress());
			baseRepository.save(o.getStakeholder());
		});
		baseRepository.save(stakeholders);
		branches.stream().forEach(o -> baseRepository.save(o.getAddress()));
		baseRepository.save(branches);

		// Set other role for KE
		ke = new TaStakeholder();
		ke.setRole(cache.getStakeholderRoles().stream().findFirst().get());
		ke.setAppointedDate(LocalDate.of(2009, 01, 01));
		ke.setStakeholder(keDetails);
		baseRepository.save(ke);

		// baseRepository.save(ta);

	}

	public void createTaUser(String uen) {
		SecureRandom r = new SecureRandom();
		TravelAgent ta = new TravelAgent();

		ta.setUen(uen);

		// random incorporated date
		int ranYear = r.nextInt(28) + 1990;
		int ranMonth = r.nextInt(12) + 1;
		int ranDate = r.nextInt(28) + 1;
		ta.setIncorporatedDate(LocalDate.of(ranYear, ranMonth, ranDate));

		// hard coded variables
		ta.setName(uen.charAt(uen.length() - 1) + "TA " + uen);
		ta.setPaidUpCapital(new BigDecimal(100000));
		ta.setWebsiteUrl("http://www.wiz-elmo.com");
		ta.setEmailAddress("stb.testuser@wizvision.com");
		ta.setContactNo("6666 6666");
		ta.setFyeDate(LocalDate.now().minusYears(1).minusDays(1));
		ta.setPrincipleActivities(cache.getPrincipleActivities().stream().findFirst().get());
		ta.setSecondaryPrincipleActivities(cache.getPrincipleActivities().stream().filter(o -> !o.getCode().equals(ta.getPrincipleActivities())).findFirst().get());
		ta.setEstablishmentStatus(cache.getEstablishmentStatuses().stream().findFirst().get());
		ta.setIncorporatedPlace(cache.getCountries().stream().findFirst().get());
		ta.setFormOfBusiness(cache.getFormOfBusiness().stream().findFirst().get());
		ta.setTaSegmentation(cache.getTaSegmentations().stream().findFirst().get());
		ta.setBusinessConstitution(cache.getBusinessConstitution().stream().findFirst().get());

		// registered address
		Address registered = new Address();
		registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		registered.setPostal("000000");
		registered.setStreet("Sesame Street");
		registered.setBlock("10");
		registered.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		ta.setRegisteredAddress(registered);

		// operating address
		Address operating = new Address();
		operating.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		operating.setPostal("000000");
		operating.setStreet("Sesame Street");
		operating.setBlock("10");
		operating.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		ta.setOperatingAddress(operating);
		// set 10 payments
		for (int i = 0; i < 10; i++) {
			paymentHelper.savePaymentRequest("REFNO" + i, Codes.CePaymentRequestTypes.PAYREQ_CE_AFP, uen, ta.getName(), new BigDecimal(100), "This is a test description count : " + i, null, false,
					true);
		}

		// Set inbound/outbound services
		List<Type> inboundRandomPicks = pickNRandomType(cache.getTaServices(), 3);
		Set<Type> inboundServices = new HashSet<>(inboundRandomPicks);
		ta.setInboundServices(inboundServices);

		List<Type> outboundRandomPicks = pickNRandomType(cache.getTaServices(), 3);
		Set<Type> outboundServices = new HashSet<>(outboundRandomPicks);
		ta.setOutboundServices(outboundServices);

		// licence
		Licence licence = new Licence();
		licence.setTravelAgent(ta);
		licence.setTaTgType(Codes.TaTgType.TA);
		licence.setTier(cache.getType(Codes.Types.TA_TIER_GENERAL));
		licence.setExpiryDate(LocalDate.of(2019, 12, 31));
		licence.setStartDate(LocalDate.of(2017, 01, 01));
		licence.setIssueDate(LocalDate.of(2017, 01, 01));
		licence.setStatus(cache.getStatus(Codes.Statuses.TA_ACTIVE));

		// ke
		TaStakeholder ke = new TaStakeholder();
		ke.setAppointedDate(LocalDate.of(2000, 01, 01));
		ke.setLicence(licence);
		ke.setRole(cache.getType(Codes.TaStakeholderRoles.STKHLD_KE));
		Stakeholder keDetails = new Stakeholder();
		keDetails.setIsCompany(false);
		String nric = "";
		for (int k = 0; k < 7; k++) {
			nric += r.nextInt(10);
		}
		nric += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
		keDetails.setUin(nric);
		keDetails.setName("KE " + nric);
		int ranYear2 = r.nextInt(50) + 1960;
		int ranMonth2 = r.nextInt(12) + 1;
		int ranDate2 = r.nextInt(28) + 1;
		keDetails.setDob(LocalDate.of(ranYear2, ranMonth2, ranDate2));
		keDetails.setContactNo("6666 6666");
		keDetails.setHighestEduLevel(cache.getEducationLevels().stream().findFirst().get());
		keDetails.setDesignation(cache.getOccupations().stream().findFirst().get());
		keDetails.setSex(cache.getType(Codes.Types.SEX_M));
		keDetails.setNationality(cache.getNationalities().stream().findFirst().get());
		keDetails.setEmail("stb.testuser@wizvision.com");
		Address keAdd = new Address();
		keAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		keAdd.setPostal("000000");
		keAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		keAdd.setStreet("Sesame Street");
		keAdd.setBlock("10");
		keDetails.setAddress(keAdd);
		ke.setStakeholder(keDetails);

		List<TaKeDeclaration> declarations = new ArrayList<>();
		for (TaKeClause clause : cache.getTaKeClauses()) {
			TaKeDeclaration declaration = new TaKeDeclaration();
			declaration.setTaKeClause(clause);
			if (clause.isOptionsRequired()) {
				List<String> options = Arrays.asList(clause.getOptions().split("\\|"));
				declaration.setOptionSelected(options.stream().filter(o -> !o.equals(clause.getOptionsToPrompt())).findFirst().get());

			}
			declaration.setTaKeyExecutive(ke);
			declarations.add(declaration);

		}

		// stakeholders
		List<TaStakeholder> stakeholders = new ArrayList<>();
		for (int i = 0; i < 3; i++) {
			TaStakeholder taStakeholder = new TaStakeholder();
			taStakeholder.setAppointedDate(LocalDate.of(2000, 01, 01));
			taStakeholder.setSharesHeld(1000);
			taStakeholder.setLicence(licence);
			taStakeholder.setRole(cache.getStakeholderRoles().stream().filter(o -> !o.getCode().equals(Codes.TaStakeholderRoles.STKHLD_KE)).findFirst().get());
			Stakeholder stakeholder = new Stakeholder();
			stakeholder.setIsCompany(false);
			String stakeholderId = "";
			for (int k = 0; k < 7; k++) {
				stakeholderId += r.nextInt(10);
			}
			stakeholderId += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			stakeholder.setUin(stakeholderId);
			stakeholder.setName("Personnel " + stakeholderId);
			stakeholder.setSex(cache.getType(Codes.Types.SEX_M));
			stakeholder.setNationality(cache.getNationalities().stream().findFirst().get());
			Address stakeholderAdd = new Address();
			stakeholderAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			stakeholderAdd.setPostal("000000");
			stakeholderAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
			stakeholderAdd.setStreet("Sesame Street");
			stakeholderAdd.setBlock("10");
			stakeholder.setAddress(stakeholderAdd);
			taStakeholder.setStakeholder(stakeholder);
			stakeholders.add(taStakeholder);
		}

		// branch
		List<TaBranch> branches = new ArrayList<>();
		int branchCounts = 3;
		for (int i = 0; i < branchCounts; i++) {
			TaBranch branch = new TaBranch();
			branch.setLicence(licence);
			branch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_ACTIVE));
			Address branchAdd = new Address();
			branchAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			String postalCode = "";
			for (int k = 0; k < 6; k++) {
				postalCode += r.nextInt(10);
			}
			branchAdd.setPostal(postalCode);
			branchAdd.setPremiseType(cache.getType("PREM_21"));
			branchAdd.setStreet("Sesame Street");
			String blk = "";
			for (int k = 0; k < 3; k++) {
				blk += r.nextInt(10);
			}
			branchAdd.setBlock(blk);
			branch.setAddress(branchAdd);
			branches.add(branch);
		}

		// saving
		licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TA_ACTIVE);
		baseRepository.save(ta.getRegisteredAddress());
		baseRepository.save(ta.getOperatingAddress());
		baseRepository.save(licence);
		ta.setLicence(licence);
		baseRepository.save(ta);
		baseRepository.saveOrUpdate(keDetails.getAddress());
		baseRepository.saveOrUpdate(keDetails);
		baseRepository.saveOrUpdate(ke);
		baseRepository.save(declarations);
		stakeholders.stream().forEach(o -> {
			baseRepository.save(o.getStakeholder().getAddress());
			baseRepository.save(o.getStakeholder());
		});
		baseRepository.save(stakeholders);
		branches.stream().forEach(o -> baseRepository.save(o.getAddress()));
		baseRepository.save(branches);

		// Set other role for KE
		ke = new TaStakeholder();
		ke.setRole(cache.getStakeholderRoles().stream().findFirst().get());
		ke.setAppointedDate(LocalDate.of(2009, 01, 01));
		ke.setStakeholder(keDetails);
		baseRepository.save(ke);

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-condition/{appType}
	// TA_APP_AA_SUBMISSION, TA_APP_ABPR_SUBMISSION, or TA_APP_NET_VALUE_RECTIFICATION
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-condition/{appTypeCode}")
	public String createTaCondition(@PathVariable String appTypeCode) {

		if (!(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION.equalsIgnoreCase(appTypeCode) || Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION.equalsIgnoreCase(appTypeCode)
				|| Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION.equalsIgnoreCase(appTypeCode))) {
			return "Invalid Application code";
		}

		LocalDate currentDate = LocalDate.now();

		List<Licence> licences = taLicenceRepository.getActiveTaLicences();
		int count = 0;
		for (Licence licence : licences) {

			TravelAgent ta = new TravelAgent();
			ta = licence.getTravelAgent();

			LocalDate fyStartDate = null;
			LocalDate fyEndDate = null;

			// Check if previously TA submitted AA
			TaFilingCondition prevTaAnnualFiling = new TaFilingCondition();
			prevTaAnnualFiling = taAnnualFilingRepository.getPreviousTaAnnualFiling(licence.getId());
			if (prevTaAnnualFiling == null) {

				Period p = Period.between(ta.getIncorporatedDate(), currentDate);
				int years = p.getYears();
				int months = p.getMonths();

				if ((years * 12 + months) <= 18) {
					// newly incorporated company
					// treat as TA first time submit AA, FYE start = TA firstFYE

					fyStartDate = ta.getIncorporatedDate();
					fyEndDate = ta.getFyeDate();

				} else {
					// on-going business
					fyStartDate = ta.getLicence().getStartDate();
					fyEndDate = ta.getFyeDate();
				}

			} else if (prevTaAnnualFiling != null) {
				// string fye from fyDay, fyMonth
				fyStartDate = prevTaAnnualFiling.getFyEndDate().plusDays(1);
				fyEndDate = ta.getFyeDate();

			}

			// Check the date to create condition day is after the FY ended
			if (currentDate.isAfter(fyEndDate)) {

				// If prev TA submitted AA, create new condition for submission. When create condition even if TA did not submit previous AA also create new condition.
				// When TA view from fornt end, we can filter the AA to show the oldest not submitted AA only
				if (fyEndDate.isAfter(fyStartDate)) {
					appHelper.saveTaAnnualFiling(licence, fyStartDate, fyEndDate, appTypeCode, null);
					count++;
				}
			}

		}

		return count + " Annual Filing condition successfully created.";

	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
	 * TG
	 */

	// http://localhost:9191/webservice-admin/api/v1/test/create-tg-licence/{number}
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-licence/{number}")
	public String createTgLicence(@PathVariable Integer number) {
		int count = 0;

		for (int i = 0; i < number; i++) {
			setTgLicence(null);
			count++;
		}

		return count + " TG licences successfully created";

	}

	private TouristGuide createTg(String uin) {

		var tgCandidateResult = new TgCandidateResult();
		tgCandidateResult.setEmail("stb.testuser@wizvision.com");
		tgCandidateResult.setName("TG of " + uin);
		tgCandidateResult.setExamDate(LocalDate.of(2018, 12, 01));
		tgCandidateResult.setGuidingLanguage(cache.getType("TG_LANG_ENG"));
		// tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
		tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
		baseRepository.save(tgCandidateResult);

		Set<TgCandidateResult> results = new HashSet<>();
		results.add(tgCandidateResult);

		TgCandidate tgCandidate = new TgCandidate();
		tgCandidate.setUin(uin);
		tgCandidate.setTgCandidateResults(results);
		tgCandidate.setLastCandidateResult(tgCandidateResult);
		baseRepository.save(tgCandidate);

		tgCandidateResult.setTgCandidate(tgCandidate);

		User user = new User();
		user.setLoginId(uin);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName("TG of" + uin);
		user.setEmailAddress("stb.testuser@wizvision.com");
		user.setTgCandidate(tgCandidate);
		user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));
		baseRepository.save(user);

		TouristGuide tg = new TouristGuide();
		tg.setUin(uin);
		tg.setAliasName("Stanley");
		baseRepository.save(tg);
		user.setTouristGuide(tg);

		// licence
		Licence licence = new Licence();
		licence.setTouristGuide(tg);
		licence.setTaTgType(Codes.TaTgType.TG);
		licence.setTier(cache.getType(Codes.Types.TG_TIER_GENERAL));
		licence.setIssueDate(tgCandidateResult.getExamDate().minusYears(3));
		licence.setStartDate(tgCandidateResult.getExamDate());
		licence.setExpiryDate(tgCandidateResult.getExamDate().plusYears(3).minusDays(1));
		licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE);
		licence.setStatus(cache.getStatus(Codes.Statuses.TG_ACTIVE));
		baseRepository.save(licence);

		tg.setDob(LocalDate.of(1990, 1, 1));

		Set<Type> guidingLanguages = new HashSet<>();
		// Set<Type> specializedAreas = new HashSet<>();

		tg.setUser(user);
		tg.setLicence(licence);
		tg.setName("TG of " + uin);
		tg.setBirthCountry(cache.getType("CTRY_SG"));
		tg.setHighestEduLevel(cache.getType("EDU_5"));
		tg.setMaritalStatus(cache.getType("MARI_MR"));
		tg.setNationality(cache.getType("NAT_SG"));
		tg.setRace(cache.getType("RACE_CN"));
		tg.setResidentialStatus(cache.getType("RESD_C"));
		tg.setSalutation(cache.getType("SAL_MR"));
		tg.setSex(cache.getType("SEX_M"));
		tg.setMobileNo("8" + RandomStringUtils.randomNumeric(7));
		tg.setEmailAddress(user.getEmailAddress());
		tg.setHasConsentMobileNo(true);
		tg.setHasConsentEmailAddress(true);
		// tg.setPhoto(file);
		// tg.setWorkPassType(cache.getTypesByCategory(Codes.TypeCategories.WORK_PASS_TYPE).get(0));

		guidingLanguages.add(tgCandidateResult.getGuidingLanguage());
		guidingLanguages.add(cache.getType("TG_LANG_MAN"));
		// specializedAreas.add(tgCandidateResult.getSpecializedArea());

		tg.setGuidingLanguages(guidingLanguages);
		// tg.setSpecializedAreas(specializedAreas);

		// registered address
		Address registered = new Address();
		registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		registered.setPostal("381050");
		registered.setPremiseType(cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE).get(0));
		registered.setStreet("SIMS DRIVE");
		registered.setBuilding("SIMS VISTA");
		registered.setBlock("50A");
		registered.setFloor(RandomStringUtils.randomNumeric(2));
		registered.setUnit(RandomStringUtils.randomNumeric(2));
		tg.setRegisteredAddress(registered);
		tg.setMailingAddress(registered);

		baseRepository.save(tg.getRegisteredAddress());
		baseRepository.save(tg.getMailingAddress());

		return tg;
	}

	// to create dummy record for TG License Creation
	// http://localhost:9191/webservice-admin/api/v1/test/create-tg-application/{number}
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-application/{number}")
	public String createTgApplications(@PathVariable Integer number) {
		for (int i = 0; i < number; i++) {
			pumpTgAppData(i);
		}

		return "TG applications successfully created";
	}

	private void pumpTgAppData(int i) {

		var uin = "S" + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

		var tgCandidateResult = new TgCandidateResult();
		tgCandidateResult.setExamDate(LocalDate.of(2018, 11, 01));
		tgCandidateResult.setGuidingLanguage(cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE).get(0));
		tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
		tgCandidateResult.setEmail("tag-dev@wizvision.com");
		tgCandidateResult.setName("Candidate of " + uin);
		tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
		baseRepository.save(tgCandidateResult);

		Set<TgCandidateResult> results = new HashSet<>();
		results.add(tgCandidateResult);

		var tgCandidate = new TgCandidate();
		tgCandidate.setUin(uin);
		tgCandidate.setTgCandidateResults(results);
		tgCandidate.setLastCandidateResult(tgCandidateResult);
		baseRepository.save(tgCandidate);
		tgCandidateResult.setTgCandidate(tgCandidate);

		User user = new User();
		user.setLoginId(uin);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName("Candidate of " + tgCandidate.getUin());
		user.setEmailAddress("tag-dev@wizvision.com");
		user.setTgCandidate(tgCandidate);
		user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TG_CANDIDATE));
		baseRepository.save(user);

		// registered address
		var regAdd = new Address();
		regAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		regAdd.setPostal("381050");
		regAdd.setPremiseType(cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE).get(0));
		regAdd.setStreet("SIMS DRIVE");
		regAdd.setBuilding("SIMS VISTA");
		regAdd.setBlock("50A");
		regAdd.setFloor(RandomStringUtils.randomNumeric(2));
		regAdd.setUnit(RandomStringUtils.randomNumeric(2));
		baseRepository.save(regAdd);

		// operating address
		var opAddr = new Address();
		opAddr.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		opAddr.setPostal("381050");
		opAddr.setPremiseType(cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE).get(0));
		opAddr.setStreet("SIMS DRIVE");
		opAddr.setBuilding("SIMS VISTA");
		opAddr.setBlock("50A");
		opAddr.setFloor(RandomStringUtils.randomNumeric(2));
		opAddr.setUnit(RandomStringUtils.randomNumeric(2));
		baseRepository.save(opAddr);

		var workflowAction = new WorkflowAction();
		workflowAction.setStatus(cache.getStatus(Codes.Statuses.TG_APP_PENDING_PO));
		workflowAction.setPrevStatus(cache.getStatus(Codes.Statuses.TG_APP_PENDING_PO));
		baseRepository.save(workflowAction);

		var application = new Application();
		application.setTaTgType(Codes.TaTgType.TG);
		application.setLastAction(workflowAction);
		application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_CREATION));
		application.setSubmissionDate(LocalDateTime.now());
		application.setIsDraft(false);
		application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_APPROVAL));
		baseRepository.save(application);

		workflowAction.setApplication(application);
		baseRepository.update(workflowAction);

		var tlc = new TgLicenceCreation();
		tlc.setDob(LocalDate.of(1988, 01, 01));
		tlc.setEmailAddress(user.getEmailAddress());
		tlc.setEmployerName(RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(1).toUpperCase() + "Pte Ltd");
		tlc.setHasConsentEmailAddress(true);
		tlc.setHasConsentMobileNo(true);
		tlc.setMobileNo(RandomStringUtils.randomNumeric(8));
		tlc.setName(user.getName());
		tlc.setOccupation(cache.getTypesByCategory(Codes.TypeCategories.OCCUPATIONS).get(0));
		tlc.setUin(uin);
		tlc.setApplication(application);
		tlc.setBirthCountry(cache.getTypesByCategory(Codes.TypeCategories.COUNTRY).get(0));
		tlc.setHighestEduLevel(cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_LEVEL).get(0));
		tlc.setMaritalStatus(cache.getTypesByCategory(Codes.TypeCategories.MARITAL_STATUS).get(0));
		tlc.setNationality(cache.getTypesByCategory(Codes.TypeCategories.NATIONALITY).get(0));
		tlc.setOperatingAddress(opAddr);
		tlc.setRace(cache.getTypesByCategory(Codes.TypeCategories.RACE).get(0));
		tlc.setRegisteredAddress(regAdd);
		tlc.setOperatingAddress(opAddr);
		tlc.setResidentialStatus(cache.getTypesByCategory(Codes.TypeCategories.RESIDENTIAL_STATUS).get(0));
		tlc.setSalutation(cache.getTypesByCategory(Codes.TypeCategories.SALUTATION).get(0));
		tlc.setSex(cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
		tlc.setUser(user);
		tlc.setWorkPassType(cache.getType("TG_TIER_G"));
		baseRepository.save(tlc);

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-tg-user
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-user")
	public String createTgUsers() {

		List<String> existingUsers = Lists.newArrayList();
		userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));

		List<TouristGuide> tgs = new ArrayList<>();
		// create one user for each licensees
		tgs = tgRepository.getTouristGuides();

		int count = 0;
		for (TouristGuide tg : tgs) {
			String loginId;
			loginId = "TG-" + tg.getUin().toString();

			if (existingUsers.contains(loginId)) {
				continue;
			}

			User user = new User();
			user.setLoginId(loginId);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName("TG Licensee of " + tg.getUin());
			user.setEmailAddress(tg.getEmailAddress());
			user.setTouristGuide(tg);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));
			baseRepository.save(user);

			tg.setUser(user);
			tgRepository.update(tg);
			count++;
		}

		return count + " TG licensees successfully created.";
	}

	private String createTgUsers(List<String> uins) {

		List<String> existingUsers = Lists.newArrayList();
		userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));

		List<TouristGuide> tgs = new ArrayList<>();
		// create one user for each licensees
		tgs = testRepository.getTouristGuides(uins);

		int count = 0;
		for (TouristGuide tg : tgs) {
			String loginId;
			loginId = tg.getUin().toString();

			if (existingUsers.contains(loginId)) {
				continue;
			}

			User user = new User();
			user.setLoginId(loginId);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName("TG Licensee of " + tg.getUin());
			user.setEmailAddress(tg.getEmailAddress());
			user.setTouristGuide(tg);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));
			baseRepository.save(user);

			tg.setUser(user);
			tgRepository.update(tg);
			count++;
		}

		return count + " TG licensees successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/common/reset-password/{loginId}/{password}
	@RequestMapping(method = RequestMethod.GET, value = "/reset-password/{loginId}/{password}")
	public String resetPassword(@PathVariable String loginId, @PathVariable String password) {
		User user = userRepository.getUserByLoginId(loginId);
		if (user != null) {
			// generate salt and hashed password
			String salt = EncryptionUtil.generateSalt();
			String hashedPassword = PasswordHelper.encode(password, salt);
			// update user password
			user.setSalt(salt);
			user.setPassword(hashedPassword);
			userRepository.update(user);
			return user.getName() + "'s password has been updated to " + password;
		}
		return "No user found.";
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
	 * TA
	 */

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-user
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-user")
	public String createTaUsers() {

		List<String> existingUsers = Lists.newArrayList();
		userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));

		// create one user for each licensees
		List<TravelAgent> tas = taRepository.getTravelAgents();
		int count = 0;
		for (TravelAgent ta : tas) {
			String loginId = "TA-" + ta.getLicence().getId().toString();
			if (existingUsers.contains(loginId)) {
				continue;
			}

			User user = new User();
			user.setLoginId(loginId);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName("TA Licensee of " + ta.getUen());
			user.setEmailAddress(ta.getEmailAddress());
			user.setTravelAgent(ta);
			user.setUen(ta.getUen());
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TA_PUBLIC));
			baseRepository.save(user);
			count++;
		}

		return count + " TA licensees successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-make-payment
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-make-payment")
	public String createTaMakePayment() {

		// List<String> existingUsers = Lists.newArrayList();
		// userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));
		List<TravelAgent> travelAgentList = taRepository.getTravelAgents();
		int count = 0;
		for (TravelAgent travelAgent : travelAgentList) {

			for (int i = 0; i < 10; i++) {
				paymentHelper.savePaymentRequest("REFNO" + i, Codes.CePaymentRequestTypes.PAYREQ_CE_AFP, travelAgent.getUen(), travelAgent.getName(), new BigDecimal(100),
						"This is a test description count : " + i, null, false, true);
			}
			count++;
		}

		return count + " TA Payment for each TA successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-company-stakeholder
	@RequestMapping(method = RequestMethod.GET, value = "/create-company-stakeholder")
	public String createCompanyStakeholder() {
		// stakeholders
		List<TravelAgent> tas = taRepository.getTravelAgents();
		int count = 0;
		SecureRandom r = new SecureRandom();

		for (TravelAgent ta : tas) {

			TaStakeholder taStakeholder = new TaStakeholder();
			taStakeholder.setAppointedDate(LocalDate.of(2000, 01, 01));
			taStakeholder.setSharesHeld(1000);
			taStakeholder.setLicence(ta.getLicence());
			taStakeholder.setRole(cache.getStakeholderRoles().stream().filter(o -> o.getCode().equals(Codes.TaStakeholderRoles.STKHLD_SHAREHOLDER)).findFirst().get());
			Stakeholder stakeholder = new Stakeholder();
			stakeholder.setIsCompany(true);

			// random uen
			String uen = "";
			for (int i = 0; i < 8; i++) {
				uen += r.nextInt(10);
			}
			uen += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			stakeholder.setCompanyUen(uen);
			stakeholder.setName("Company " + uen);
			stakeholder.setSex(null);
			stakeholder.setNationality(null);

			// random incorporated date
			int ranYear = r.nextInt(28) + 1990;
			int ranMonth = r.nextInt(12) + 1;
			int ranDate = r.nextInt(28) + 1;
			stakeholder.setCompanyIncorporatedDate(LocalDate.of(ranYear, ranMonth, ranDate));

			Address stakeholderAdd = new Address();
			stakeholderAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			stakeholderAdd.setPostal("000000");
			stakeholderAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
			stakeholderAdd.setStreet("Sesame Street");
			stakeholderAdd.setBlock("10");
			stakeholder.setAddress(stakeholderAdd);
			taStakeholder.setStakeholder(stakeholder);

			baseRepository.save(stakeholderAdd);
			baseRepository.save(stakeholder);
			baseRepository.save(taStakeholder);
			count++;
		}

		return count + " Company Stakeholders successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ke-user
	@RequestMapping(method = RequestMethod.GET, value = "/create-ke-user")
	public String createKeUsers() {

		List<String> existingUsers = Lists.newArrayList();
		userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));

		// create one user for each key executive
		List<TaStakeholder> takes = taRepository.getKeyExecutives();
		int count = 0;
		for (TaStakeholder take : takes) {
			Stakeholder ke = take.getStakeholder();
			String loginId = ke.getUin();
			if (existingUsers.contains(loginId)) {
				continue;
			}

			User user = new User();
			user.setLoginId(loginId);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName(ke.getName());
			user.setEmailAddress(ke.getEmail());
			user.setTravelAgent(take.getLicence().getTravelAgent());
			user.setUen(take.getLicence().getTravelAgent().getUen());
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TA_PUBLIC));
			baseRepository.save(user);
			count++;
		}

		return count + " KE users successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-candidate-user/{count}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-candidate-user/{count}")
	public String createTaCandidateUsers(@PathVariable Integer count) {
		SecureRandom r = new SecureRandom();

		Integer index = ((Long) testRepository.getNumberOfTaCandidateUser()).intValue() + 1;

		// create one user for each licensees
		for (int i = 0; i < count; i++) {
			String loginId = "TA-CDD-" + index;

			User user = new User();
			user.setLoginId(loginId);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			String uen = "";
			for (int k = 0; k < 8; k++) {
				uen += r.nextInt(10);
			}
			uen += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			user.setUen(uen);
			user.setName("TA Candidate of " + uen);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TA_CANDIDATE));
			baseRepository.save(user);
			index++;

			User user2 = new User();
			user2.setLoginId(loginId + "-2");
			user2.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user2.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user2.setUen(uen);
			user2.setName("2nd TA Candidate of " + uen);
			user2.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user2.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user2.setRoles(Sets.newHashSet());
			user2.getRoles().add(cache.getRole(Codes.Roles.TA_CANDIDATE));
			baseRepository.save(user2);
			index++;
		}

		return count + " TA licensees successfully created.";
	}

	public String createTaCandidateUsers(String uen) {

		// create one user for each licensees

		String loginId = uen;

		User user = new User();
		user.setLoginId(loginId);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setUen(uen);
		user.setName("TA Candidate of " + uen);
		user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TA_CANDIDATE));
		baseRepository.save(user);

		User user2 = new User();
		user2.setLoginId(loginId + "-2");
		user2.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user2.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user2.setUen(uen);
		user2.setName("2nd TA Candidate of " + uen);
		user2.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user2.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user2.setRoles(Sets.newHashSet());
		user2.getRoles().add(cache.getRole(Codes.Roles.TA_CANDIDATE));
		baseRepository.save(user2);

		return " TA CDD successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-officers
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-officers")
	public String createTaOfficerUsers() {

		String loginId = "STB-TA";
		List<String> existingUsers = Lists.newArrayList();
		userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));

		if (existingUsers.contains(loginId)) {
			return loginId + " User existed.";
		}

		User user = new User();
		user.setLoginId(loginId);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName("Super TA Officer");
		user.setEmailAddress("tag-dev@wizvision.com");
		user.setType(cache.getType(Codes.UserTypes.USER_STB));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.setTaAssigneeChars("A B C");
		user.getRoles().add(cache.getRole(Codes.Roles.TA_PROCESSING_OFFICER));
		user.getRoles().add(cache.getRole(Codes.Roles.TA_VERIFYING_OFFICER));
		user.getRoles().add(cache.getRole(Codes.Roles.TA_APPROVING_OFFICER));
		user.getRoles().add(cache.getRole(Codes.Roles.HEAD_OF_DIVISION));
		baseRepository.save(user);

		user = new User();
		user.setLoginId("STB-VIEWER");
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName("Super User");
		user.setEmailAddress("tag-dev@wizvision.com");
		user.setType(cache.getType(Codes.UserTypes.USER_STB));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TA_VIEWER));
		baseRepository.save(user);

		return "TA officers successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-ta-officers-assignment
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-officers-assignment")
	public String createTaOfficerUsersWithAssignments() {

		Map<String, User> existingUsers = Maps.newHashMap();
		userRepository.getActiveUsers().forEach(u -> existingUsers.put(u.getLoginId(), u));

		int count = 0;
		String chars = "";
		String loginId = "";
		String name = "";

		// symbols + digit + A-C
		loginId = "STB-YVONNE";
		name = "Yvonne *-C";
		for (int c = 33; c <= 67; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		for (int c = 91; c <= 96; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		for (int c = 123; c <= 126; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		saveStbTaUser(existingUsers, loginId, name, chars);
		count++;

		// D - H
		chars = "";
		loginId = "STB-VERLIN";
		name = "Verlin D-H";
		for (int c = 68; c <= 72; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		saveStbTaUser(existingUsers, loginId, name, chars);
		count++;

		// I - M
		chars = "";
		loginId = "STB-SIEWHOON";
		name = "Siew Hoon I-M";
		for (int c = 73; c <= 77; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		saveStbTaUser(existingUsers, loginId, name, chars);
		count++;

		// N - R
		chars = "";
		loginId = "STB-YEETANG";
		name = "Yee Tang N-R";
		for (int c = 78; c <= 82; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		saveStbTaUser(existingUsers, loginId, name, chars);
		count++;

		// S - Z
		chars = "";
		loginId = "STB-DONLEE";
		name = "Don Lee S-Z";
		for (int c = 83; c <= 90; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		saveStbTaUser(existingUsers, loginId, name, chars);
		count++;

		return count + " TA officers successfully created.";
	}

	private void saveStbTaUser(Map<String, User> existingUsers, String loginId, String name, String chars) {
		User user = null;
		if (existingUsers.containsKey(loginId)) {
			user = existingUsers.get(loginId);
		} else {
			user = new User();
		}
		user.setLoginId(loginId);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName(name);
		user.setEmailAddress("tag-dev@wizvision.com");
		user.setType(cache.getType(Codes.UserTypes.USER_STB));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setTaAssigneeChars(chars);
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TA_PROCESSING_OFFICER));
		user.getRoles().add(cache.getRole(Codes.Roles.TA_VERIFYING_OFFICER));
		user.getRoles().add(cache.getRole(Codes.Roles.TA_APPROVING_OFFICER));
		user.getRoles().add(cache.getRole(Codes.Roles.HEAD_OF_DIVISION));
		baseRepository.save(user);
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-tg-officers
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-officers")
	public String createTgOfficerUsers() {

		String loginId = "STB-TG";
		List<String> existingUsers = Lists.newArrayList();
		userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));

		if (existingUsers.contains(loginId)) {
			return loginId + " User existed.";
		}

		User user = new User();
		user.setLoginId(loginId);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName("Super TG Officer");
		user.setEmailAddress("tag-dev@wizvision.com");
		user.setType(cache.getType(Codes.UserTypes.USER_STB));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TG_APPROVING_OFFICER));
		user.getRoles().add(cache.getRole(Codes.Roles.TG_PROCESSING_OFFICER));
		baseRepository.save(user);

		return "TG officers successfully created.";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-super-officers
	@RequestMapping(method = RequestMethod.GET, value = "/create-super-officers")
	public String createSuperOfficerUsers() {

		String loginId = "STB-SUPER";
		List<String> existingUsers = Lists.newArrayList();
		userRepository.getActiveUsers().forEach(u -> existingUsers.add(u.getLoginId()));

		if (existingUsers.contains(loginId)) {
			return loginId + " User existed.";
		}

		User user = new User();
		user.setLoginId(loginId);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName("Super Officer");
		user.setEmailAddress("tag-dev@wizvision.com");
		user.setType(cache.getType(Codes.UserTypes.USER_STB));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		cache.getRoles().forEach(r -> {
			if (!r.getCode().contains("PUB") && !r.getCode().contains("TG_CDD")) {
				user.getRoles().add(cache.getRole(r.getCode()));
			}
		});
		baseRepository.save(user);

		return "Super officer successfully created.";
	}

	private void setTgLicence(String hardCodedUin) {
		SecureRandom r = new SecureRandom();
		TouristGuide tg = new TouristGuide();

		String uin;
		if (hardCodedUin == null) {
			// random uin
			uin = "S";
			for (int i = 0; i < 7; i++) {
				uin += r.nextInt(10);
			}
			uin += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
		} else {
			uin = hardCodedUin;
		}

		tg.setUin(uin);

		// random DOB
		int ranYear = r.nextInt(28) + 1990;
		int ranMonth = r.nextInt(12) + 1;
		int ranDate = r.nextInt(28) + 1;
		tg.setDob(LocalDate.of(ranYear, ranMonth, ranDate));

		// hard coded variables
		tg.setName("TG " + uin);
		tg.setSex(cache.getType("SEX_M"));
		tg.setMaritalStatus(cache.getType("MARI_18"));
		tg.setRace(cache.getType("RACE_38"));
		tg.setNationality(cache.getType("NAT_31"));
		tg.setBirthCountry(cache.getType("NAT_31"));
		tg.setResidentialStatus(cache.getType("RESD_O"));
		tg.setEmailAddress("wiz-elmo@wizvision.com");
		tg.setMobileNo("6666 6666");
		tg.setEmployerName("Chan Brother Pte Ltd");

		// registered address
		Address registered = new Address();
		registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		registered.setPostal("000000");
		registered.setPremiseType(cache.getType("PREM_21"));
		registered.setStreet("Sesame Street");
		registered.setBlock("10");
		tg.setRegisteredAddress(registered);
		tg.setMailingAddress(registered);

		// licence
		Licence licence = new Licence();
		licence.setTouristGuide(tg);
		licence.setTaTgType(Codes.TaTgType.TG);
		licence.setTier(cache.getType(Codes.Types.TG_TIER_GENERAL));
		licence.setExpiryDate(LocalDate.of(2020, 01, 01));
		licence.setStatus(cache.getStatus(Codes.Statuses.TG_ACTIVE));

		// saving
		licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE);
		baseRepository.save(tg.getRegisteredAddress());
		baseRepository.save(tg.getMailingAddress());
		baseRepository.save(tg);
		baseRepository.save(licence);
		tg.setLicence(licence);
		baseRepository.save(tg);

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-tg-assignments
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-assignments")
	public String createTgAssignments() {
		String message = "";
		// create one user for each licensees
		List<TouristGuide> tgs = tgRepository.getTouristGuides();
		for (TouristGuide tg : tgs) {
			SecureRandom r = new SecureRandom();
			int count = r.nextInt(3);
			for (int i = 0; i < count; i++) {
				var ta = new TgAssignment();
				ta.setCompanyName("Chan Brother Pte Ltd");

				// random start date
				int ranYear = r.nextInt(18) + 2000;
				int ranMonth = r.nextInt(12) + 1;
				int ranDate = r.nextInt(25) + 1;
				ta.setStartDate(LocalDate.of(ranYear, ranMonth, ranDate));
				int noOfDays = r.nextInt(3) + 1;
				ta.setEndDate(LocalDate.of(ranYear, ranMonth, ranDate + noOfDays));
				ta.setFeeReceived(BigDecimal.valueOf(r.nextInt(100000)).movePointLeft(2));
				ta.setTouristGuide(tg);
				ta.setType(cache.getType("TOUR_CT"));
				baseRepository.save(ta);

				for (int j = 0; j < noOfDays + 1; j++) {
					var tad = new TgAssignmentDate();
					tad.setDate(LocalDate.of(ranYear, ranMonth, ranDate + j));
					tad.setNoOfHours(new BigDecimal(r.nextInt(24) + 1));
					tad.setTgAssignment(ta);
					baseRepository.save(tad);
				}
			}
			message += count + " TG assignments successfully created for TG-" + tg.getLicence().getId().toString() + System.lineSeparator();
		}
		return message;
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-payment-requests/5/S1234567A/DON
	@RequestMapping(method = RequestMethod.GET, value = "/create-payment-requests/{count}/{uinUen}/{name}")
	public String createPaymentRequests(@PathVariable Integer count, @PathVariable String uinUen, @PathVariable String name) {
		for (int i = 0; i < count; i++) {
			paymentHelper.savePaymentRequest("REFNO" + i, Codes.CePaymentRequestTypes.PAYREQ_CE_AFP, uinUen, name, new BigDecimal(100), "This is a test description.", null, false, true);
		}
		return count + " Payment Requests successfully created.";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/get-date")
	public TestDateDto getDate(TestDateDto dto) {

		logger.info(DateUtil.format(dto.getDatetime()));

		TestDateDto result = new TestDateDto();
		result.setDatetime(LocalDateTime.now());
		result.setDate(LocalDate.now());

		return result;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/set-date")
	public TestDateDto setDate(@RequestBody TestDateDto dto) {

		LocalDateTime datetime = dto.getDatetime();
		logger.info(DateUtil.format(datetime));
		dto.setDatetime(datetime.plusDays(2));

		LocalDate date = dto.getDate();
		logger.info(DateUtil.format(date));
		dto.setDate(date.plusDays(2));

		return dto;
	}

	@RequestMapping(method = RequestMethod.GET, value = { "/tg-login-user/{role}", "/tg-login-user/{role}/{type}" })
	public String pumpTgLoginUser(@PathVariable Optional<String> type, @PathVariable String role) {
		var uin = "";

		String sf = "STFG";
		Random rd = new Random();
		uin = sf.charAt(rd.nextInt(sf.length())) + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

		TgCandidate tgCandidate = null;
		if (role.equals("TG_CDD")) {
			var tgCandidateResult = new TgCandidateResult();
			tgCandidateResult.setEmail("stb.testuser@wizvision.com");
			tgCandidateResult.setName(uin + " User");
			tgCandidateResult.setExamDate(LocalDate.of(2018, 11, 01));
			tgCandidateResult.setGuidingLanguage(cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE).get(0));
			tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
			tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
			baseRepository.save(tgCandidateResult);

			Set<TgCandidateResult> results = new HashSet<>();
			results.add(tgCandidateResult);

			tgCandidate = new TgCandidate();
			tgCandidate.setUin(uin);
			tgCandidate.setTgCandidateResults(results);
			tgCandidate.setLastCandidateResult(tgCandidateResult);
			baseRepository.save(tgCandidate);

			tgCandidateResult.setTgCandidate(tgCandidate);
		}

		User user = new User();
		user.setLoginId(uin);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName(uin + " User");
		user.setEmailAddress("tag-dev@wizvision.com");
		if (tgCandidate != null) {
			user.setTgCandidate(tgCandidate);
			user.setType(cache.getType(type.get()));
		} else {
			user.setType(cache.getType("USER_STB"));
		}
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(role));
		baseRepository.save(user);

		return " TG user successfully created, nric : " + uin;
	}

	private String pumpTgCandidate(String uin) {

		TgCandidate tgCandidate = null;
		var tgCandidateResult = new TgCandidateResult();
		tgCandidateResult.setEmail("stb.testuser@wizvision.com");
		tgCandidateResult.setName(uin + " User");
		tgCandidateResult.setExamDate(LocalDate.of(2018, 11, 01));
		tgCandidateResult.setGuidingLanguage(cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE).get(0));
		tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
		tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
		baseRepository.save(tgCandidateResult);

		Set<TgCandidateResult> results = new HashSet<>();
		results.add(tgCandidateResult);

		tgCandidate = new TgCandidate();
		tgCandidate.setUin(uin);
		tgCandidate.setTgCandidateResults(results);
		tgCandidate.setLastCandidateResult(tgCandidateResult);
		baseRepository.save(tgCandidate);

		tgCandidateResult.setTgCandidate(tgCandidate);

		User user = new User();
		user.setLoginId(uin);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName(uin + " User");
		user.setEmailAddress("tag-dev@wizvision.com");
		if (tgCandidate != null) {
			user.setTgCandidate(tgCandidate);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		}
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TG_CANDIDATE));
		baseRepository.save(user);

		return " TG user successfully created, nric : " + uin;
	}

	// http://localhost:9191/webservice-admin/api/v1/test/tg-update-particulars
	@RequestMapping(method = RequestMethod.GET, value = "/tg-update-particulars")
	public String pumpUpdateParticularsApplications() {

		List<TgLicenceCreation> tlcList = baseRepository.getList(DetachedCriteria.forClass(TgLicenceCreation.class));

		for (TgLicenceCreation tlc : tlcList) {
			var workflowAction = new WorkflowAction();
			workflowAction.setStatus(cache.getStatus(Codes.Statuses.TG_APP_PENDING_PO));
			baseRepository.save(workflowAction);

			var application = new Application();
			application.setTaTgType(Codes.TaTgType.TG);
			application.setLastAction(workflowAction);
			application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_PERSON_UPDATE));
			application.setSubmissionDate(LocalDateTime.now());
			baseRepository.save(application);

			workflowAction.setApplication(application);
			baseRepository.update(workflowAction);

			var tpu = new TgPersonUpdate();
			tpu.setDob(LocalDate.of(1988, 01, 01));
			tpu.setEmailAddress(tlc.getEmailAddress());
			tpu.setEmployerName(tlc.getEmployerName());
			tpu.setHasConsentEmailAddress(tlc.hasConsentEmailAddress());
			tpu.setHasConsentMobileNo(tlc.hasConsentMobileNo());
			tpu.setMobileNo(tlc.getMobileNo());
			tpu.setName(tlc.getName());
			tpu.setOccupation(tlc.getOccupation());
			tpu.setUin(tlc.getUin());
			tpu.setApplication(application);
			tpu.setBirthCountry(tlc.getBirthCountry());
			tpu.setHighestEduLevel(tlc.getHighestEduLevel());
			tpu.setMaritalStatus(tlc.getMaritalStatus());
			tpu.setNationality(tlc.getNationality());
			tpu.setOperatingAddress(tlc.getOperatingAddress());
			tpu.setRace(tlc.getRace());
			tpu.setRegisteredAddress(tlc.getRegisteredAddress());
			tpu.setResidentialStatus(tlc.getResidentialStatus());
			tpu.setSalutation(tlc.getSalutation());
			tpu.setSex(tlc.getSex());
			tpu.setUin(tlc.getUin());
			baseRepository.save(tpu);
		}
		return "TG applications successfully created";
	}

	// can be removed 29 jan
	// http://localhost:9191/webservice-admin/api/v1/test/tg-print-colour
	@RequestMapping(method = RequestMethod.GET, value = "/tg-print-colour")
	public String pumpColourData() {
		List<String> colourList = Lists.newArrayList("Red", "Red", "Green", "Light Blue", "Yellow", "Purple", "Orange", "Dark Blue");
		List<LocalDate> dateList = Lists.newArrayList(LocalDate.of(2019, Month.FEBRUARY, 1), LocalDate.of(2019, Month.AUGUST, 1), LocalDate.of(2020, Month.FEBRUARY, 1),
				LocalDate.of(2020, Month.AUGUST, 1), LocalDate.of(2021, Month.FEBRUARY, 1), LocalDate.of(2021, Month.AUGUST, 1), LocalDate.of(2022, Month.FEBRUARY, 1),
				LocalDate.of(2022, Month.AUGUST, 1));

		for (int i = 0; i < colourList.size(); i++) {
			TgPrintColour tpc = new TgPrintColour();
			tpc.setColour(colourList.get(i));
			tpc.setDate(dateList.get(i));
			tgLicencePrintRepository.save(tpc);
		}

		return "Created " + colourList.size() + " Colours";
	}

	// create approved applications with licence status pending
	// http://localhost:9191/webservice-admin/api/v1/test/create-tg-with-application
	@RequestMapping(method = RequestMethod.POST, value = "/create-tg-with-application")
	public String createApp(@RequestPart("file") MultipartFile multipartFile) {

		gov.stb.tag.model.File file = fileHelper.saveFile("TG_DOC_PHOTO", multipartFile, true);

		String[] username = { "Percy", "Malena", "Randell", "Lavera", "Hunter", "Stacie", "Dorian", "Truman", "Elizabet", "Todd", "Lavinia", "Lyman", "Florene", "Roxana", "Dan", "Gita", "Luci",
				"Freddy", "Elvira", "Thersa" };
		String[] nricArray = { "S", "G" };
		String[] appCodeArray = { Codes.ApplicationTypes.TG_APP_CREATION, Codes.ApplicationTypes.TG_APP_RENEWAL, Codes.ApplicationTypes.TG_APP_REPLACEMENT,
				Codes.ApplicationTypes.TG_APP_PERSON_UPDATE };

		for (int i = 0; i < 20; i++) {

			var uin = nricArray[new Random().nextInt(nricArray.length)] + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

			var tgCandidateResult = new TgCandidateResult();
			tgCandidateResult.setEmail("stb.testuser@wizvision.com");
			tgCandidateResult.setName(username[i]);
			tgCandidateResult.setExamDate(LocalDate.of(2019, 8, 31));
			tgCandidateResult.setGuidingLanguage(cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE).get(0));
			tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
			tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
			baseRepository.save(tgCandidateResult);

			Set<TgCandidateResult> results = new HashSet<>();
			results.add(tgCandidateResult);

			TgCandidate tgCandidate = new TgCandidate();
			tgCandidate.setUin(uin);
			tgCandidate.setTgCandidateResults(results);
			tgCandidate.setLastCandidateResult(tgCandidateResult);
			baseRepository.save(tgCandidate);

			tgCandidateResult.setTgCandidate(tgCandidate);

			User user = new User();
			user.setLoginId(uin);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName(username[i]);
			user.setEmailAddress("stb.testuser@wizvision.com");
			user.setTgCandidate(tgCandidate);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));
			baseRepository.save(user);

			TouristGuide tg = new TouristGuide();
			tg.setUin(uin);
			baseRepository.save(tg);
			user.setTouristGuide(tg);

			// licence
			Licence licence = new Licence();
			licence.setTouristGuide(tg);
			licence.setTaTgType(Codes.TaTgType.TG);
			licence.setTier(cache.getType(Codes.Types.TG_TIER_GENERAL));
			licence.setStartDate(tgCandidateResult.getExamDate());
			licence.setExpiryDate(LocalDate.of(2022, 8, 31));
			licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE);
			licence.setStatus(cache.getStatus(Codes.Statuses.TG_ACTIVE));
			baseRepository.save(licence);

			// random DOB
			SecureRandom r = new SecureRandom();
			int ranYear = r.nextInt(28) + 1990;
			int ranMonth = r.nextInt(12) + 1;
			int ranDate = r.nextInt(28) + 1;
			tg.setDob(LocalDate.of(ranYear, ranMonth, ranDate));

			Set<Type> guidingLanguages = new HashSet<>();
			Set<Type> specializedAreas = new HashSet<>();

			tg.setSex(cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
			tg.setUser(user);
			tg.setLicence(licence);
			tg.setName(username[i]);
			tg.setBirthCountry(cache.getTypesByCategory(Codes.TypeCategories.COUNTRY).get(0));
			tg.setHighestEduLevel(cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_LEVEL).get(0));
			tg.setMaritalStatus(cache.getTypesByCategory(Codes.TypeCategories.MARITAL_STATUS).get(0));
			tg.setNationality(cache.getTypesByCategory(Codes.TypeCategories.NATIONALITY).get(0));
			tg.setRace(cache.getTypesByCategory(Codes.TypeCategories.RACE).get(0));
			tg.setResidentialStatus(cache.getTypesByCategory(Codes.TypeCategories.RESIDENTIAL_STATUS).get(0));
			tg.setSalutation(cache.getTypesByCategory(Codes.TypeCategories.SALUTATION).get(0));
			tg.setSex(cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
			tg.setMobileNo("8" + RandomStringUtils.randomNumeric(7));
			tg.setEmailAddress(user.getEmailAddress());
			tg.setHasConsentMobileNo(true);
			tg.setHasConsentEmailAddress(true);
			tg.setPhoto(file);
			tg.setWorkPassType(cache.getType(Codes.Types.TG_TIER_GENERAL));

			guidingLanguages.add(tgCandidateResult.getGuidingLanguage());
			specializedAreas.add(tgCandidateResult.getSpecializedArea());

			tg.setGuidingLanguages(guidingLanguages);
			tg.setSpecializedAreas(specializedAreas);

			// registered address
			Address registered = new Address();
			registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			registered.setPostal("381050");
			registered.setPremiseType(cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE).get(0));
			registered.setStreet("SIMS DRIVE");
			registered.setBuilding("SIMS VISTA");
			registered.setBlock("50A");
			registered.setFloor(RandomStringUtils.randomNumeric(2));
			registered.setUnit(RandomStringUtils.randomNumeric(2));
			tg.setRegisteredAddress(registered);
			tg.setMailingAddress(registered);

			baseRepository.save(tg.getRegisteredAddress());
			baseRepository.save(tg.getMailingAddress());

			WorkflowAction workflowAction = new WorkflowAction();
			workflowAction.setStatus(cache.getStatus(Codes.Statuses.TG_APP_APPROVED));
			workflowAction.setPrevStatus(cache.getStatus(Codes.Statuses.TG_APP_PENDING_PO));
			baseRepository.save(workflowAction);

			Application application = new Application();
			application.setTaTgType(Codes.TaTgType.TG);
			application.setLastAction(workflowAction);
			application.setType(cache.getType(appCodeArray[new Random().nextInt(appCodeArray.length)]));
			application.setSubmissionDate(LocalDateTime.now());
			application.setIsDraft(false);
			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));
			application.setLicence(licence);
			baseRepository.save(application);

			workflowAction.setApplication(application);
			baseRepository.update(workflowAction);

			TgLicenceCreation tlc = new TgLicenceCreation();
			tlc.setDob(LocalDate.of(1988, 01, 01));
			tlc.setEmailAddress(tg.getEmailAddress());
			tlc.setEmployerName(tg.getEmployerName());// RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(1).toUpperCase() + "Pte Ltd");
			tlc.setHasConsentEmailAddress(true);
			tlc.setHasConsentMobileNo(true);
			tlc.setMobileNo(tg.getMobileNo());// RandomStringUtils.randomNumeric(8));
			tlc.setName(tg.getName());
			tlc.setOccupation(tg.getOccupation());// cache.getTypesByCategory(Codes.TypeCategories.OCCUPATIONS).get(0));
			tlc.setUin(tg.getUin());
			tlc.setApplication(application);
			tlc.setBirthCountry(tg.getBirthCountry());// cache.getTypesByCategory(Codes.TypeCategories.COUNTRY).get(0));
			tlc.setHighestEduLevel(tg.getHighestEduLevel());// cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_LEVEL).get(0));
			tlc.setMaritalStatus(tg.getMaritalStatus());// cache.getTypesByCategory(Codes.TypeCategories.MARITAL_STATUS).get(0));
			tlc.setNationality(tg.getNationality());// cache.getTypesByCategory(Codes.TypeCategories.NATIONALITY).get(0));
			tlc.setOperatingAddress(tg.getMailingAddress());// opAddr);
			tlc.setRace(tg.getRace());// cache.getTypesByCategory(Codes.TypeCategories.RACE).get(0));
			tlc.setRegisteredAddress(tg.getRegisteredAddress());// regAdd);
			tlc.setResidentialStatus(tg.getResidentialStatus());// cache.getTypesByCategory(Codes.TypeCategories.RESIDENTIAL_STATUS).get(0));
			tlc.setSalutation(tg.getSalutation());// cache.getTypesByCategory(Codes.TypeCategories.SALUTATION).get(0));
			tlc.setSex(tg.getSex());// cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
			tlc.setUser(tg.getUser());
			tlc.setWorkPassType(tg.getWorkPassType());// cache.getType("TG_TIER_G"));
			baseRepository.save(tlc);
		}

		return 20 + " applications created";
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
	 * TP
	 */

	// http://localhost:9191/webservice-admin/api/v1/test/create-tp-user/{number}
	@RequestMapping(method = RequestMethod.GET, value = "/create-tp-user/{number}")
	public String createTpLicence(@PathVariable Integer number) {
		int count = 0;
		for (int i = 0; i < number; i++) {
			setTpLicence();
			count++;
		}
		return count + " TP licences successfully created";
	}

	private void setTpLicence() {
		TgTrainingProvider tp = new TgTrainingProvider();
		String uen = "S" + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();
		tp.setUen(uen);
		tp.setName("TP of " + uen);
		tp.setStatus(cache.getStatus("USER_A"));
		tpRepository.save(tp);

		User user = new User();
		user.setLoginId(uen);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName("TP of " + uen);
		user.setEmailAddress("wiz-elmo@wizvision.com");
		user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TP_PUBLIC));
		user.setTgTrainingProvider(tp);
		baseRepository.save(user);
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-pdc/{courseName}
	@RequestMapping(method = RequestMethod.GET, value = "/create-pdc/{courseName}")
	public String createPDC(@PathVariable String courseName) {
		TgCourse tc = new TgCourse();
		tc.setCode(RandomStringUtils.randomAlphabetic(4).toUpperCase());
		tc.setName(courseName);
		// tc.setCategory(null);
		tc.setLanguage(cache.getType("TG_LANG_391"));
		tc.setType(cache.getType("TP_CSE_P"));
		tc.setApprovedStartDate(LocalDate.of(2019, 1, 1));
		tc.setApprovedEndDate(LocalDate.of(2019, 12, 31));
		tc.setNoOfHours(new BigDecimal(8.0));
		List<TgTrainingProvider> tps = testRepository.getTrainingProvider();
		tc.setTgTrainingProvider(tps.get(0));
		tgCourseRepository.save(tc);
		return courseName + " has been created for PDC";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-mrc/{courseName}
	@RequestMapping(method = RequestMethod.GET, value = "/create-mrc/{courseName}")
	public String createMRC(@PathVariable String courseName) {
		TgCourse tc = new TgCourse();
		tc.setCode(RandomStringUtils.randomAlphabetic(4).toUpperCase());
		tc.setName(courseName);
		// tc.setCategory(null);
		tc.setLanguage(cache.getType("TG_LANG_391"));
		tc.setType(cache.getType("TP_CSE_M"));
		tc.setApprovedStartDate(LocalDate.of(2019, 1, 1));
		tc.setApprovedEndDate(LocalDate.of(2019, 12, 31));
		tc.setNoOfHours(new BigDecimal(8.0));
		List<TgTrainingProvider> tps = testRepository.getTrainingProvider();

		tc.setTgTrainingProvider(tps.get(0));
		tgCourseRepository.save(tc);
		return courseName + " has been created for MRC";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-course-attendance/{courseCode}
	@RequestMapping(method = RequestMethod.GET, value = "/create-course-attendance/{courseCode}")
	public String createCourseAttendance(@PathVariable String courseCode) {
		// random attended date
		SecureRandom r = new SecureRandom();
		int ranYear = r.nextInt(8) + 2010;
		int ranMonth = r.nextInt(12) + 1;
		int ranDate = r.nextInt(28) + 1;
		LocalDate attendedDate = LocalDate.of(ranYear, ranMonth, ranDate);
		TgCourseAttendance tca = new TgCourseAttendance();
		tca.setAttendedDate(attendedDate);
		TgCourse tc = tgCourseRepository.get(TgCourse.class, courseCode);
		tca.setTgCourse(tc);
		tgCourseAttendanceRepository.save(tca);
		List<TouristGuide> tgs = tgRepository.getTouristGuides();
		int count = 0;
		for (TouristGuide tg : tgs) {
			TgCourseAttendanceDetail tcad = new TgCourseAttendanceDetail();
			tcad.setTouristGuide(tg);
			// tcad.setAttendance(cache.getType("TP_ATN_ATN"));
			int score = r.nextInt(100);
			tcad.setScore(score);
			tcad.setMaxScore(100);
			if (score > 70) {
				tcad.setResult(cache.getType("TG_RESULT_P"));
			} else {
				tcad.setResult(cache.getType("TG_RESULT_F"));
			}
			tcad.setTgCourseAttendance(tca);
			tgCourseAttendanceDetailRepository.save(tcad);
			count++;
		}
		return count + " attendance created for " + tc.getName();
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/***************************** Bulletin *********************************************/
	@RequestMapping(method = RequestMethod.GET, value = "/create-bulletins/{type}/{isPrivate}")
	public String createBulletin(@PathVariable String type, @PathVariable Boolean isPrivate) {

		Map<String, String> titleList = new HashMap<String, String>();
		titleList.put("SS Scuba Convicted For Unlicenced Travel Agent Activities",
				"The Singapore Tourism Board (STB) would like to inform the public that SS Scuba Pte Ltd has been convicted in the State Courts on 28 November 2018 for carrying on the business of a travel agent without a valid travel agent licence in contravention of Section 6(1) of the Travel Agents Act (Chapter 334) SS Scuba faced 50 charges and was convicted and sentenced on 10 charges. The company was ordered to pay a total fine of S$14 000 The remaining 40 charges were taken into consideration in the sentencing.<br><br>\r\n"
						+ "SS Scuba's travel agent licence ceased in March 2014 Investigations revealed that despite not having a valid travel agent licence, SS Scuba continued to operate by selling and arranging trips to various overseas destinations from January 2015 to July 2016<br><br>\r\n"
						+ "STB takes a serious view against unlicensed travel agents and is committed to uphold the reputation of Singapore's tourism sector, and will not hesitate to take necessary action against those who contravened the legislation.<br><br>\r\n"
						+ "Under Section 6 of the pre-amended Travel Agents Act, which this case falls under. any person found guilty of carrying on the business of a travel agent without a valid travel agent licence faces a maximum fine of S$10.000 and/or imprisonment of up to two years. Under the amended Travel Agents Act that took effect on 1 January 2018, commission of the same offence now will carry a higher maximum fine of $25,000 and/or imprisonment of up to two years.<br><br>\r\n"
						+ "The public is advised to exercise due diligence when making travel arrangements For the latest list of licensed travel agents in Singapore. please visit the Travel Related Users System (TRUST) website,\r\n"
						+ "<a href=\"https://trust.yoursingapore.com\" target=\"blank_\"><span class=\"link_url\">https://trust.yoursingapore.com</span></a>. Travel agents may also emai the STB at <span class=\"link_url\">stb_ta@stb.gov.sg</span> for related licensing queries.");
		titleList.put("2016 Chinese New Year Light Up",
				"Organised by the Kreta Ayer-Kim Seng Citizens' Consultative Committee, this year's Chinese New Year Celebrations at Chinatown is themed \"Year of Prosperity & Success, 桃满花香牛车水, 灵猴迎春贺新岁\". From 16 January to 8 March 2016, this predominantly Chinese enclave will spring to life with 2,668 handcrafted lanterns in the shape of monkeys, peaches, spring blossoms and gold zodiac coins – the most number of customised lanterns to be produced for the street light-up. In partnership with the Singapore University of Technology and Design for the fifth time, the light-up will also feature 28 mechanical monkey lanterns. Other events include a festive bazaar, the Chinatown Chinese New Year Walking Trail, 9th International Lion Dance Competition, and Chinatown Chinese New Year Countdown Party. For more information, please visit&nbsp;<a href=\"http://www.chinatownfestivals.sg/\">www.chinatownfestivals.sg</a>.");
		titleList.put("STB & Spotify get people grooving to the Beats of Singapore",
				"The Singapore Tourism Board (STB) and Spotify, the world's most popular music streaming subscription service, have jointly rolled out.");
		titleList.put("STB's multi-year partnership with 50 Best brand",
				"The Singapore Tourism Board (STB) and William Reed Business Media (WRBM), owner of the acclaimed 50 Best brand, have entered into.");
		titleList.put("Vertical Line Pte Ltd - Revocation Of Travel Agent Licence",
				"The Singapore Tourism Board (STB) would like to inform the public that Vertical Line Pte Ltd (Vertical Line) [travel agent licence number.");
		titleList.put("Revocation Of Travel Agent Licence: Baba Travel",
				"The Singapore Tourism Board would like to inform the public that the Travel Agent licence of Baba Travel (TA Licence 01409) will be.");

		titleList.entrySet().forEach(o -> {
			Bulletin item = new Bulletin();
			item.setType(cache.getType(type));
			item.setTitle(o.getKey());
			item.setContent(o.getValue());
			item.setEffectiveDate(LocalDate.now());
			item.setExpiryDate(LocalDate.now().plusYears(1));
			if (isPrivate) {
				item.setPrivate(Boolean.TRUE);
			} else {
				item.setPrivate(Boolean.FALSE);
			}

			baseRepository.save(item);

		});

		return "6 Bulletins successfully created ";
	}

	/***************************** END Bulletin *********************************************/

	// http://localhost:9191/webservice-admin/api/v1/test/money
	@RequestMapping(method = RequestMethod.POST, value = "/money")
	public String testMoneyConverter(@Validated @RequestBody TestMoneyDto dto) {

		System.out.println(dto.getMoney());

		return dto.getMoney().toString();
	}

	// http://localhost:9191/webservice-admin/api/v1/test/money
	@RequestMapping(method = RequestMethod.GET, value = "/money")
	public TestMoneyDto testMoneyConverter() {
		TestMoneyDto dto = new TestMoneyDto();
		dto.setMoney(new BigDecimal("1000000"));

		return dto;
	}

	// http://localhost:9191/webservice-admin/api/v1/test/jobs/new
	@RequestMapping(method = RequestMethod.GET, value = "/jobs/new")
	public String createJobs() {

		Job job = new Job();
		job.setClassName("gov.stb.tag.job.TaAnnualFilingJob");
		job.setCronExpression("0 0 0 * * ?");
		job.setDescription("For creating TA Annual Filing");
		job.setIsActive(Boolean.TRUE);
		job.setScheduleDescription("Everyday 00:00");
		baseRepository.save(job);

		return "Jobs successfully created.";
	}

	/**
	 * This is to simulate MyInfo response, but without user session
	 *
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/person-basic/{uinfin}/")
	public String getMyInfo(@PathVariable String uinfin) {
		return "{\"name\": {\"lastupdated\": \"2015-06-01\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"Tan Eng Huat\"},\"hanyupinyinname\": {\"lastupdated\": \"2015-06-01\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"Chen Ying Fa\"},\"aliasname\": {\"lastupdated\": \"2015-06-01\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"Stanley\"},\"hanyupinyinaliasname\": {\"lastupdated\": \"2015-06-01\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"\"},\"marriedname\": {\"lastupdated\": \"2015-06-01\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"\"},\"sex\": {\"lastupdated\": \"2016-03-11\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"F\",\"desc\": \"Female\"},\"race\": {\"lastupdated\": \"2016-03-11\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"CN\",\"code\": \"CN\"},\"secondaryrace\": {\"lastupdated\": \"2017-08-25\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"EU\",\"desc\": \"European\"},\"dialect\": {\"lastupdated\": \"2016-03-11\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"SG\",\"desc\": \"Singaporean\"},\"nationality\": {\"lastupdated\": \"2016-03-11\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"SG\",\"desc\": \"Singaporean\"},\"dob\": {\"lastupdated\": \"2016-03-11\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"1958-05-17\"},\"birthcountry\": {\"lastupdated\": \"2016-03-11\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"SG\",\"desc\": \"Singaporean\"},\"residentialstatus\": {\"lastupdated\": \"2017-08-25\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"C\",\"desc\": \"Citizen\"},\"passportnumber\": {\"lastupdated\": \"2017-08-25\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"E35463874W\"},\"passportexpirydate\": {\"lastupdated\": \"2017-08-25\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"2020-01-01\"},\"regadd\": {\"type\": \"SG\",\"block\": {\"value\": \"548\"},\"building\": {\"value\": \"HDB-BEDOK\"},\"floor\": {\"value\": \"09\"},\"unit\": {\"value\": \"128\"},\"street\": {\"value\": \"BEDOK NORTH AVENUE 1\"},\"postal\": {\"value\": \"460548\"},\"country\": {\"code\": \"SG\",\"desc\": \"SINGAPORE\"},\"classification\": \"C\",\"source\": \"1\",\"lastupdated\": \"2019-03-26\"},\"mailadd\": {\"type\": \"SG\",\"block\": {\"value\": \"548\"},\"building\": {\"value\": \"HDB Bedok\"},\"floor\": {\"value\": \"09\"},\"unit\": {\"value\": \"128\"},\"street\": {\"value\": \"BEDOK NORTH AVENUE 1\"},\"postal\": {\"value\": \"460548\"},\"country\": {\"code\": \"SG\",\"desc\": \"SINGAPORE\"},\"classification\": \"C\",\"source\": \"1\",\"lastupdated\": \"2019-03-26\"},\"billadd\": {\"type\": \"SG\",\"block\": {\"value\": \"548\"},\"building\": {\"value\": \"HDB Bedok\"},\"floor\": {\"value\": \"09\"},\"unit\": {\"value\": \"128\"},\"street\": {\"value\": \"BEDOK NORTH AVENUE 1\"},\"postal\": {\"value\": \"460548\"},\"country\": {\"code\": \"SG\",\"desc\": \"SINGAPORE\"},\"classification\": \"C\",\"source\": \"1\",\"lastupdated\": \"2019-03-26\"},\"housingtype\": {\"code\": \"123\",\"desc\": \"TERRACE HOUSE\",\"classification\": \"C\",\"source\": \"1\",\"lastupdated\": \"2019-03-26\"},\"hdbtype\": {\"lastupdated\": \"2015-12-23\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"111\"},\"email\": {\"lastupdated\": \"2017-12-13\",\"source\": \"4\",\"classification\": \"C\",\"value\": \"stb.testuser@wizvision.com\"},\"homeno\": {\"code\": \"65\",\"prefix\": \"+\",\"lastupdated\": \"2017-11-20\",\"source\": \"2\",\"classification\": \"C\",\"nbr\": \"66132665\"},\"mobileno\": {\"prefix\": {\"value\": \"+\"},\"areacode\": {\"value\": \"65\"},\"nbr\": {\"value\": \"66132665\"},\"classification\": \"C\",\"source\": \"1\",\"lastupdated\": \"2019-03-26\"},\"marital\": {\"lastupdated\": \"2017-03-29\",\"source\": \"1\",\"classification\": \"C\",\"code\": \"1\",\"desc\": \"Single\"},\"marriagecertno\": {\"lastupdated\": \"2018-03-02\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"123456789012345\"},\"countryofmarriage\": {\"lastupdated\": \"2018-03-02\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"SG\"},\"marriagedate\": {\"lastupdated\": \"\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"\"},\"divorcedate\": {\"lastupdated\": \"\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"\"},\"childrenbirthrecords\": [{\"dialect\": \"HK\",\"race\": \"CN\",\"tob\": \"0901\",\"sex\": \"F\",\"source\": \"1\",\"classification\": \"C\",\"birthcertno\": \"S5562882C\",\"hanyupinyinname\": \"Cheng Pei Ni\",\"hanyupinyinaliasname\": \"\",\"marriedname\": \"\",\"aliasname\": \"\",\"dob\": \"2011-09-10\",\"name\": \"Jo Tan Pei Ni\",\"lastupdated\": \"2018-05-16\",\"secondaryrace\": \"\"},{\"dialect\": \"HK\",\"race\": \"CN\",\"tob\": \"2021\",\"sex\": \"F\",\"source\": \"1\",\"classification\": \"C\",\"birthcertno\": \"S8816582I\",\"hanyupinyinname\": \"Cheng Wei Ling\",\"hanyupinyinaliasname\": \"\",\"marriedname\": \"\",\"aliasname\": \"\",\"dob\": \"2015-07-18\",\"name\": \"Joyce Tan Wei Ling\",\"lastupdated\": \"2018-05-16\",\"secondaryrace\": \"\"},{\"dialect\": \"HK\",\"race\": \"CN\",\"tob\": \"0901\",\"sex\": \"F\",\"source\": \"1\",\"classification\": \"C\",\"birthcertno\": \"T0202564C\",\"hanyupinyinname\": \"Cheng Shu Hui\",\"hanyupinyinaliasname\": \"\",\"marriedname\": \"\",\"aliasname\": \"\",\"dob\": \"2012-09-10\",\"name\": \"Joycelyn Tan Shu Hui\",\"lastupdated\": \"2018-05-16\",\"secondaryrace\": \"\"}],\"relationships\": [{\"passportno\": \"\",\"name\": \"TAN AH MUI\",\"lastupdated\": \"2017-10-11\",\"source\": \"2\",\"classification\": \"C\",\"type\": \"REL201\",\"idno\": \"S9999999C\"},{\"passportno\": \"\",\"name\": \"TAN CHIN SOON\",\"lastupdated\": \"2017-10-11\",\"source\": \"2\",\"classification\": \"C\",\"type\": \"REL202\",\"idno\": \"S9999998E\"}],\"edulevel\": {\"lastupdated\": \"2017-10-11\",\"source\": \"2\",\"classification\": \"C\",\"code\": \"7\",\"desc\": \"BACHELOR'S OR EQUIVALENT\"},\"gradyear\": {\"lastupdated\": \"2017-10-11\",\"source\": \"2\",\"classification\": \"C\",\"value\": \"1978\"},\"schoolname\": {\"lastupdated\": \"2017-10-11\",\"source\": \"2\",\"classification\": \"C\",\"value\": \"T07GS3011J\",\"desc\": \"SIGLAP SECONDARY SCHOOL\"},\"occupation\": {\"code\": \"53201\",\"desc\": \"HEALTHCARE ASSISTANT\",\"value\": \"\",\"classification\": \"C\",\"source\": \"1\",\"lastupdated\": \"2019-03-26\"},\"employment\": {\"lastupdated\": \"2017-10-11\",\"source\": \"2\",\"classification\": \"C\",\"value\": \"ALPHA\"},\"workpassstatus\": {\"lastupdated\": \"2018-03-02\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"Live\"},\"passexpirydate\": {\"lastupdated\": \"2018-03-02\",\"source\": \"1\",\"classification\": \"C\",\"value\": \"2018-12-30\"},\"householdincome\": {\"high\": \"5999\",\"low\": \"5000\",\"lastupdated\": \"2017-10-24\",\"source\": \"2\",\"classification\": \"C\"},\"vehno\": {\"lastupdated\": \"\",\"source\": \"2\",\"classification\": \"C\",\"value\": \"\"}}";
	}

	// This is to simulate EDH Entity response, but without user session (EDH UEN Sample: 201600159C)
	@RequestMapping(method = RequestMethod.GET, value = "/entity/{uen}")
	public String getEdhEntity(@PathVariable String uen) {
		return "{\"basic\":{\"isRegisteredWithACRA\":true,\"isRedomiciledCompany\":false,\"entityStatusEffectiveDate\":\"2016-05-12\",\"changeOfAddressDate\":\"2016-05-12\",\"uen\":\"201600159C\",\"uenStatus\":\"R\",\"issuanceAgency\":\"ACRA\",\"entityName\":\"NILOOFER ZEBHA PRIVATE LTD.\",\"entityType\":\"FOB_LC\",\"entityStatusCode\":\"0\",\"entityStatusCodeDescription\":\"Live Company\",\"uenIssueDate\":\"2016-05-12\",\"relatedMainEntityUens\":[],\"registrationDate\":\"2016-05-12\",\"primaryActivityCode\":\"PA_79101\",\"primaryActivityDescription\":\"Travel agencies and tour operators (mainly inbound)\",\"additionalPrimaryActivityDescription\":\"Travel agencies and tour operators (mainly inbound)\"},\"addresses\":[{\"standard\":\"D\",\"postalCode\":118850,\"houseBlockNumber\":\"30\",\"streetName\":\"PASIR PANJANG HILL\",\"unformattedAddressLines\":[],\"careOfNames\":[],\"isInvalid\":false}],\"entityNames\":[],\"redomiciliation\":{},\"registrationNumbers\":[],\"appointments\":[{\"idType\":\"PASSPORT/OTHERS\",\"idNumber\":\"K7541125\"}],\"renewals\":[],\"shareholders\":[{\"idType\":\"PASSPORT/OTHERS\",\"idNumber\":\"K7541125\"}],\"uens\":[]}";
	}

	// This is to simulate EDH Entity Appointments response, but without user session (EDH UEN Sample: 201600159C)
	@RequestMapping(method = RequestMethod.GET, value = "/entity/{uen}/appointments")
	public String getEdhEntityAppointments(@PathVariable String uen) {
		return "[{\"category\":\"1\",\"positionHeld\":\"DI\",\"entryDate\":\"2016-05-12\",\"appointedPerson\":{\"idType\":\"4\",\"idNumber\":\"K7541125\",\"name\":\"Mary Su\",\"nationality\":\"ANTIGUA\",\"isDisqualified\":false},\"addressOfAppointed\":{\"source\":\"ACRA\",\"type\":\"Foreign\",\"alternateType\":\"Foreign Address\",\"unformattedAddressLines\":[\"FADS\",\"ASDFADSF\"],\"effectiveDate\":\"2018-07-23\",\"isInvalid\":false}}, {\"category\":\"1\",\"positionHeld\":\"DI\",\"entryDate\":\"2016-05-12\",\"appointedPerson\":{\"idType\":\"4\",\"idNumber\":\"K7541126\",\"name\":\"Alan Wong\",\"nationality\":\"ANTIGUA\",\"isDisqualified\":false},\"addressOfAppointed\":{\"source\":\"ACRA\",\"type\":\"Foreign\",\"alternateType\":\"Foreign Address\",\"unformattedAddressLines\":[\"FADS\",\"ASDFADSF\"],\"effectiveDate\":\"2018-07-23\",\"isInvalid\":false}}]";
	}

	// This is to simulate EDH Entity Shareholders response, but without user session (EDH UEN Sample: 201600159C)
	@RequestMapping(method = RequestMethod.GET, value = "/entity/{uen}/shareholders")
	public String getEdhEntityShareholders(@PathVariable String uen) {
		return "[{\"category\":\"1\",\"group\":\"000\",\"type\":\"1\",\"currency\":\"ALL\",\"allotedNumber\":100.0,\"allotedPerson\":{\"idType\":\"4\",\"idNumber\":\"K7541125\",\"name\":\"Mary Su\",\"nationality\":\"ANTIGUA\"},\"addressOfAlloted\":{\"source\":\"ACRA\",\"type\":\"Foreign\",\"unformattedAddressLines\":[\"FADS\",\"ASDFADSF\"],\"effectiveDate\":\"2018-07-23\",\"isInvalid\":false}}]";
	}

	// This is to simulate EDH Entity Financials response, but without user session (EDH UEN Sample: 201600159C)
	@RequestMapping(method = RequestMethod.GET, value = "/entity/{uen}/financials")
	public String getEdhEntityFinancials(@PathVariable String uen) {
		return "{\"agms\":[{}],\"annualDeclarations\":[],\"capitals\":[{\"type\":\"1\",\"capitalCurrency\":\"ALL\",\"capitalAllotedAmount\":150000.0,\"issuedCapitalAmount\":150000.0,\"paidUpCapitalAmount\":150000.0}]}";
	}

	// This is to simulate CPF MediSave Payment Status response, but without user session (Sample: S9902409G)
	@RequestMapping(method = RequestMethod.POST, value = "/cpf/sem/v1/getPaymentStatus")
	public String getMedisavePaymentStatus() {
		return "{\"RDXSEMPSOperationResponse\":{\"output_data\":{\"sempswo_eeacn_c\":\"S9902409G\",\"sempswo_con_id\":\"STB\",\"sempswo_guid\":\"123457890\",\"sempswo_pmt_sts\":\"Y\",\"sempswo_return_code\":\"0000\"}}}";
	}

	// This is to test get CPF MediSave Payment Status
	// http://localhost:9191/webservice-admin/api/v1/test/cpf/medisave-payment-statuses/S9902409G
	@RequestMapping(method = RequestMethod.GET, value = "/cpf/medisave-payment-statuses/{uinfin}")
	public String getMedisavePaymentStatus(@PathVariable String uinfin) {
		return cpfHelper.checkMedisavePaymentStatus(uinfin).getLabel();
	}

	// http://localhost:9191/webservice-admin/api/v1/test/cpf/generate-cpf-apex-header
	@RequestMapping(method = RequestMethod.GET, value = "/cpf/generate-cpf-apex-header")
	public String generateCpfApexHeader() throws ApiUtilException {
		String apiUrl = properties.cpfApexIgL2BaseApiUrl + properties.cpfApiMedisavePaymentStatus;
		return cpfHelper.generateCpfApexSignature(apiUrl);
	}

	// This is to create corresponding users for the spcp given test accounts
	// http://localhost:9191/webservice-admin/api/v1/test/create-spcp-accounts
	@RequestMapping(method = RequestMethod.GET, value = "/create-spcp-accounts")
	public String createSpcpAccounts() {

		createTg("S3000115Z");
		createTg("S3000116H");
		createTg("S3000117F");
		// createTgUsers(Arrays.asList("S3000115Z", "S3000116H", "S3000117F"));
		pumpTgCandidate("S3000118D");
		pumpTgCandidate("S3000119B");

		return "Accounts Created";
	}

	// This is to create corresponding users for the myinfo given test accounts
	// http://localhost:9191/webservice-admin/api/v1/test/create-myinfo-accounts
	@RequestMapping(method = RequestMethod.GET, value = "/create-myinfo-accounts")
	public String createMyInfoAccounts() {

		pumpTgCandidate("S6005037F");
		pumpTgCandidate("S6005041D");
		pumpTgCandidate("S6005039B");
		pumpTgCandidate("S6005065A");
		pumpTgCandidate("S6005036H");
		pumpTgCandidate("F1612354N");
		pumpTgCandidate("F1612360U");
		pumpTgCandidate("F1612358R");
		pumpTgCandidate("F1612362P");
		pumpTgCandidate("F1612353Q");

		return "Accounts Created";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/invoke-email-testing")
	public String invokeEmailTesting() {
		String subject = "[" + properties.appEnv + "] Test Email";
		String body = "body content";
		String recipient = "stb.testuser@wizvision.com";

		emailHelper.email(subject, body, recipient);
		return "Email Sent to " + recipient;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/invoke-sms-testing")
	public String invokeSmsTesting() throws UnsupportedEncodingException {
		String message = "Test SMS from " + properties.appEnv;

		// note: sms service only available in UAT/PROD
		SmsLog smsLog = smsHelper.sms("6596262137", message);
		return "SMS Status Code: " + smsLog.getStatus().getCode() + ". message: " + message;
	}

	// http://localhost:9191/webservice-admin/api/v1/test/prod-sample-data
	@RequestMapping(method = RequestMethod.GET, value = "/prod-sample-data")
	public String createSampleDataForProd() {
		pumpTgCandidate("S9620307A");
		createTaCandidateUsers("200002982E");
		createTg("S8405932C");
		createTg("S8876251G");
		createTg("S8477006Z");
		createTg("S8460807F");
		createTg("S8836513E");
		createTaUser("180299366K");
		return "Test data generated";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-tg/{count}
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg/{count}")
	public String createTg(@PathVariable Integer count) {
		for (Integer i = 0; i < count; i++) {

			SecureRandom r = new SecureRandom();
			String uin = "S";
			for (int k = 0; k < 7; k++) {
				uin += r.nextInt(10);
			}
			uin += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			createTg(uin);
		}

		return "Test data generated";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-tg-cdd/{count}
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-cdd/{count}")
	public String createTgCdd(@PathVariable Integer count) {
		for (Integer i = 0; i < count; i++) {

			SecureRandom r = new SecureRandom();
			String uin = "S";
			for (int k = 0; k < 7; k++) {
				uin += r.nextInt(10);
			}
			uin += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			pumpTgCandidate(uin);
		}

		return "Test data generated";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/renewal-exercise-group
	// inner method deprecated, do not use.
	@RequestMapping(method = RequestMethod.GET, value = "/renewal-exercise-group")
	public TaLicenceRenewalExerciseGroupDto getTaLicenceRenewalExerciseGroup() {
		TaLicenceRenewalExerciseGroupDto resultDto = new TaLicenceRenewalExerciseGroupDto();

		int yearOfRenewalExercise = LocalDate.now().getYear();
		LocalDate fyeCutOffDate = LocalDate.of(yearOfRenewalExercise, 3, 31);

		// Map the KE
		Map<String, ListableDto> keNameByLicenceNo = Maps.newHashMap();
		for (TaStakeholder tas : taRenewalRepository.getKeyExecutivesForTaDueForRenewal(yearOfRenewalExercise)) {
			if (!keNameByLicenceNo.containsKey(tas.getLicence().getLicenceNo())) {
				keNameByLicenceNo.put(tas.getLicence().getLicenceNo(), new ListableDto(tas.getId(), tas.getStakeholder().getName()));
			}
		}

		// Map the outstanding payment
		Map<String, BigDecimal> outstandingPaymentByUen = Maps.newHashMap();
		for (ListableDto paymentAmountDto : taRenewalRepository.getTaOutstandingPayments()) {
			if (!outstandingPaymentByUen.containsKey(paymentAmountDto.getKey())) {
				outstandingPaymentByUen.put(paymentAmountDto.getKey().toString(), (BigDecimal) paymentAmountDto.getData());
			}
		}

		// Map the AA Annual Filing
		Map<String, List<AaFilingForRenewalDto>> aaFilingByLicenceNo = Maps.newHashMap();
		for (AaFilingForRenewalDto aa : taRenewalRepository.getTaAaAnnualFilingByFyeDate(yearOfRenewalExercise)) {
			if (!aaFilingByLicenceNo.containsKey(aa.getLicenceNo())) {
				aaFilingByLicenceNo.put(aa.getLicenceNo(), Lists.newArrayList());
			}
			if (aaFilingByLicenceNo.get(aa.getLicenceNo()).size() < 2) { // check past 2 only
				if (Objects.equals(aa.getTaAnnualFilingStatusCode(), Codes.Statuses.TA_FILING_APPROVED)) {
					aaFilingByLicenceNo.get(aa.getLicenceNo()).add(aa);
				} else if (!aa.getFyEndDate().isAfter(fyeCutOffDate)) {
					aaFilingByLicenceNo.get(aa.getLicenceNo()).add(aa);
				} else {
					logger.info("Licence no: {} - Skip AA Filing for fye {}", aa.getLicenceNo(), aa.getFyEndDate());
				}
			}
		}

		// Map the ABPR Annual Filing
		Map<String, List<AbprFilingForRenewalDto>> abprFilingByLicenceNo = Maps.newHashMap();
		for (AbprFilingForRenewalDto abpr : taRenewalRepository.getTaAbprAnnualFilingByFyeDate(yearOfRenewalExercise)) {
			if (!abprFilingByLicenceNo.containsKey(abpr.getLicenceNo())) {
				abprFilingByLicenceNo.put(abpr.getLicenceNo(), Lists.newArrayList());
			}
			if (abprFilingByLicenceNo.get(abpr.getLicenceNo()).size() < 2) {
				if (Objects.equals(abpr.getTaAnnualFilingStatusCode(), Codes.Statuses.TA_FILING_APPROVED)) {
					abprFilingByLicenceNo.get(abpr.getLicenceNo()).add(abpr);
				} else if (!abpr.getFyEndDate().isAfter(fyeCutOffDate)) {
					abprFilingByLicenceNo.get(abpr.getLicenceNo()).add(abpr);
				} else {
					logger.info("Licence no: {} - Skip ABPR Filing for fye {}", abpr.getLicenceNo(), abpr.getFyEndDate());
				}
			}
		}

		// Map the approved AA Submission
		Map<String, List<AaSubmissionForRenewalDto>> aaSubmissionByLicenceNo = Maps.newHashMap();
		for (AaSubmissionForRenewalDto aa : taRenewalRepository.getTaAaSubmissionByFyeDate(yearOfRenewalExercise)) {
			if (!aaSubmissionByLicenceNo.containsKey(aa.getLicenceNo())) {
				aaSubmissionByLicenceNo.put(aa.getLicenceNo(), Lists.newArrayList(aa));
			} else {
				aaSubmissionByLicenceNo.get(aa.getLicenceNo()).add(aa);
			}
		}

		List<TravelAgentForRenewalDto> allTaDueForRenewal = taRenewalRepository.getTaDueForRenewal(yearOfRenewalExercise);

		for (TravelAgentForRenewalDto taBasic : allTaDueForRenewal) {
			TaLicenceRenewalExerciseParticipantDto participant = new TaLicenceRenewalExerciseParticipantDto();
			boolean isExpress = true;

			participant.setLicenceId(taBasic.getLicenceId());
			participant.setName(taBasic.getName());
			participant.setLicenceNo(taBasic.getLicenceNo());
			participant.setLicenceStatus(new ListableDto(taBasic.getLicenceStatusCode(), taBasic.getLicenceStatusLabel()));
			participant.setUen(taBasic.getUen());
			participant.setKeyExec(keNameByLicenceNo.get(taBasic.getLicenceNo()));
			participant.setFye(taBasic.getFye());
			participant.setAa(aaFilingByLicenceNo.get(taBasic.getLicenceNo()));
			participant.setAbpr(abprFilingByLicenceNo.get(taBasic.getLicenceNo()));
			participant.setOutstandingPayment(outstandingPaymentByUen.get(taBasic.getUen()));
			participant.setIsRequireMa(Boolean.FALSE.toString());

			// Check if Ta has fulfilled all the AA submissions
			if (CollectionUtils.isNotEmpty(aaFilingByLicenceNo.get(taBasic.getLicenceNo()))) {
				for (AaFilingForRenewalDto aa : aaFilingByLicenceNo.get(taBasic.getLicenceNo())) {
					if (!aa.getTaAnnualFilingStatusCode().equals(Codes.Statuses.TA_FILING_APPROVED)) {
						isExpress = false;
					} else {
						// if AA has shortfall, but not fulfill net value
						if (aa.getShortfall() != null && aa.getShortfall().compareTo(BigDecimal.ZERO) > 0) {
							isExpress = false;
						}
					}
				}
			} else {
				logger.info("AA filing for licence no: {} is empty", taBasic.getLicenceNo());
				isExpress = false;
				participant.setIsRequireMa(Boolean.TRUE.toString()); // No AA due, require MA to be submitted
			}

			// Check if Ta has fulfilled all the ABPR submissions
			if (!isExpress && CollectionUtils.isNotEmpty(abprFilingByLicenceNo.get(taBasic.getLicenceNo()))) {
				for (AbprFilingForRenewalDto abpr : abprFilingByLicenceNo.get(taBasic.getLicenceNo())) {
					if (!abpr.getTaAnnualFilingStatusCode().equals(Codes.Statuses.TA_FILING_APPROVED)) {
						isExpress = false;
					}
				}
			} else if (CollectionUtils.isEmpty(abprFilingByLicenceNo.get(taBasic.getLicenceNo()))) {
				logger.info("ABPR filing for licence no: {} is empty", taBasic.getLicenceNo());
				isExpress = false;
			}

			// Check if require MA
			if (!isExpress && !Boolean.valueOf(participant.getIsRequireMa())) {
				logger.info("Licence no: {} - Checking if require MA", taBasic.getLicenceNo());

				int criteriaMetCount = 0;
				List<AaSubmissionForRenewalDto> aaSubmissions = aaSubmissionByLicenceNo.get(taBasic.getLicenceNo());

				if (CollectionUtils.isNotEmpty(aaSubmissions)) {

					// Criteria 1: TA has 2 years of shortfall?
					int shortfallCount = 0;
					for (int index = 0; index < 2 && index < aaSubmissions.size(); index++) {
						if (aaSubmissions.get(index).getShortfall() != null && aaSubmissions.get(index).getShortfall().compareTo(BigDecimal.ZERO) > 0) {
							shortfallCount++;
						}
					}
					if (shortfallCount >= 2) {
						logger.info("Licence no: {} - Has 2 years shortfall", taBasic.getLicenceNo());
						criteriaMetCount += 1;
					}

					// Criteria 2: Shortfall > 30K?
					if (aaSubmissions.get(0).getShortfall() != null && aaSubmissions.get(0).getShortfall().compareTo(new BigDecimal(30000)) > 0) {
						logger.info("Licence no: {} - shortfall > 30K", taBasic.getLicenceNo());
						criteriaMetCount += 1;
					}

					// Criteria 3: Current Ratio < 1?
					BigDecimal currentRatio = BigDecimal.ZERO;
					if (!Objects.isNull(aaSubmissions.get(0).getCurrentAssets()) && !Objects.isNull(aaSubmissions.get(0).getCurrentLiabilities())
							&& aaSubmissions.get(0).getCurrentLiabilities().compareTo(BigDecimal.ZERO) != 0) {
						currentRatio = aaSubmissions.get(0).getCurrentAssets().divide(aaSubmissions.get(0).getCurrentLiabilities());
						if (currentRatio.compareTo(BigDecimal.ONE) < 0) {
							logger.info("Licence no: {} - Current Ratio < 1", taBasic.getLicenceNo());
							criteriaMetCount += 1;
						}
					}

				} else {
					logger.info("Licence no: {} - No AA submitted", taBasic.getLicenceNo());
				}

				if (criteriaMetCount >= 2) {
					participant.setIsRequireMa(Boolean.TRUE.toString());
				}
			}

			if (isExpress && Objects.isNull(outstandingPaymentByUen.get(taBasic.getUen())) && !Objects.isNull(keNameByLicenceNo.get(taBasic.getLicenceNo()))) {
				resultDto.getExpress().add(participant);
			} else {
				resultDto.getCustomised().add(participant);
			}

			// map the count by licence status
			/*
			 * if (resultDto.getTotalLicenceByStatus().containsKey(taBasic.getLicenceStatusCode())) { Integer count = resultDto.getTotalLicenceByStatus().get(taBasic.getLicenceStatusCode());
			 * resultDto.getTotalLicenceByStatus().put(taBasic.getLicenceStatusCode(), ++count); } else { resultDto.getTotalLicenceByStatus().put(taBasic.getLicenceStatusCode(), 1); }
			 */
		}

		resultDto.setSnapshotAsatDate(LocalDateTime.now());
		resultDto.setRenewalYear(yearOfRenewalExercise);
		resultDto.setRenewalStartDate(LocalDate.of(yearOfRenewalExercise, 8, 1));
		resultDto.setRenewalEndDate(LocalDate.of(yearOfRenewalExercise, 10, 31));
		resultDto.setFyeCutOffDate(LocalDate.of(yearOfRenewalExercise, 3, 31));
		resultDto.setTotalLicence(allTaDueForRenewal.size());
		resultDto.setTotalCustomised(resultDto.getCustomised().size());
		resultDto.setTotalExpress(resultDto.getExpress().size());
		resultDto.setTotalRenewed(0);
		resultDto.setTotalNotRenewed(allTaDueForRenewal.size());

		resultDto.getExpress().forEach(data -> logger.info("Express: {}", data.getLicenceNo()));
		resultDto.getCustomised().forEach(data -> logger.info("Customised: {}", data.getLicenceNo()));

		return resultDto;
	}

	// Patch shortfall table from AA short falls
	// http://localhost:9191/webservice-admin/api/v1/test/patch-shortfall-for-aa
	@RequestMapping(method = RequestMethod.GET, value = "/patch-shortfall-for-aa")
	public String getTaShortFall() {

		List<TaAaSubmission> allAaWithShortfall = taShortfallrepo.getAaWithShortfall();
		Integer count = 0;
		for (TaAaSubmission row : allAaWithShortfall) {
			if (taShortfallrepo.getShortfallByAaSubmissionId(row.getId()) == null) {
				Workflow workflow1 = new Workflow();
				workflow1.setLicence(row.getTaAnnualFiling().getLicence());
				workflow1.setType(cache.getType(Codes.Workflow.TA_WKFLW_SHORTFALL));
				workflow1.setCategoryType(Codes.WorkflowCategoryType.TA);
				workflow1.setAssignee(baseRepository.get(User.class, 6));
				taShortfallrepo.save(workflow1);

				WorkflowAction action = new WorkflowAction();
				action.setWorkflow(workflow1);
				action.setType(cache.getType(Codes.WorkflowActionTypes.SUBMIT));
				action.setStatus(cache.getStatus(Statuses.TA_WKFLW_APPROVED));
				action.setWorkflow(workflow1);
				action.setInternalRemarks("Data patch for UAT testing");
				baseRepository.save(action);

				workflow1.setLastAction(action);
				taShortfallrepo.save(workflow1);

				taShortfallrepo.saveNewShortfall(workflow1, row, cache.getType(Codes.Types.TA_SHORTFALL_FULL));

				logger.info("Saving Workflow TaAAshortfall - AAId: {}, Status: {}", row.getId(), workflow1.getLastAction().getStatus().getLabel());
				count++;
				// logger.info(count.toString());
			}

		}
		return "AA with shortfall created " + count;

	}

	// http://localhost:9191/webservice-admin/api/v1/test/create-dummy-tati-check
	@RequestMapping(method = RequestMethod.GET, value = "/create-dummy-tati-check")
	public String createTatiCheck() {
		List<CeTaCheck> created = Lists.newArrayList();
		testRepository.getApprovedScheduleItem().stream().forEach(scheduleItem -> {
			CeTaCheck tati = new CeTaCheck();
			tati.setCeTaCheckScheduleItem(scheduleItem);
			// tati.setStatus(cache.getStatus(Codes.CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED));
			tati.setIsDraft(Boolean.FALSE);
			scheduleItem.setToRevisit(Boolean.FALSE);
			// tati.setCheckStatus(cache.getStatus(Codes.CeCheckStatus.STAT_CE_TA_CHECK_COMPLETED));
			tati.setIsCompliant(cache.getType(Codes.FLAGS.FLAG_Y));
			tati.setAddress(scheduleItem.getAddress());
			tati.setAddressType(scheduleItem.getAddressType());
			tati.setLicenceNo(scheduleItem.getLicence().getLicenceNo());
			tati.setUen(scheduleItem.getLicence().getTravelAgent().getUen());
			tati.setTaName(scheduleItem.getTaName());
			tati.setCheckedDate(scheduleItem.getScheduledDate().atStartOfDay());
			tati.setTaStaffName(scheduleItem.getEoUser().getName());
			tati.setTaStaffDesignation("Manager");
			tati.setEoUser(scheduleItem.getEoUser());
			tati.setAuxEoUser(scheduleItem.getAuxEoUser());
			testRepository.save(tati);
			tati.setCeCase(ceCaseHelper.createCaseForTaTiCheck(tati, tati.getIsCompliant()));
			testRepository.save(tati);
			created.add(tati);

			// snapshot the last TATI check
			if (scheduleItem != null && !scheduleItem.toRevisit()) {
				if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_OP)) {
					scheduleItem.getLicence().getTravelAgent().setLastOpAddrTaCheck(tati);
					scheduleItem.getLicence().getTravelAgent().setIsLastOpAddrCheckDone(Boolean.TRUE);
				} else if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_REG)) {
					scheduleItem.getLicence().getTravelAgent().setLastRegAddrTaCheck(tati);
					scheduleItem.getLicence().getTravelAgent().setIsLastRegAddrCheckDone(Boolean.TRUE);
				} else if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_BRANCH)) {
					scheduleItem.getTaBranch().setLastTaCheck(tati);
					scheduleItem.getTaBranch().setIsLastCheckDone(Boolean.TRUE);
				}
			}
			testRepository.save(scheduleItem);
		});

		return "TATI checks created " + created.size();

	}

	// http://localhost:9191/webservice-admin/api/v1/test/patch-ce-tasks
	@RequestMapping(method = RequestMethod.GET, value = "/patch-ce-tasks")
	public String patchInfringementTask() {
		int[] numArr = { 0 };
		testRepository.getLicenceTarR7bInfringement().forEach(licence -> {
			CeTask ceTask = ceTaskHelper.createCeTaskForLicenceNotReturn(licence, licence.getCeasedDate(), Messages.CeTaskDetails.R7B_CESSATION_NO_RETURN_LICENCE,
					Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, Codes.CeProvisionSection.CESSATION_NO_RETURN_LICENCE, Codes.CeTaskTypes.CE_TASK_TAR_R7_B);
			ceTask.setForCase(licence.getTarR7bInfringement().getCeCase());
			numArr[0]++;
		});
		testRepository.getLicenceTarR8Infringement().stream().forEach(licence -> {
			CeTask ceTask = ceTaskHelper.createCeTaskForLicenceNotReturn(licence, licence.getCeasedDate(), Messages.CeTaskDetails.R8_REVOCATION_NO_RETURN_LICENCE,
					Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, Codes.CeProvisionSection.REVOCATION_NO_RETURN_LICENCE, Codes.CeTaskTypes.CE_TASK_TAR_R8);
			ceTask.setForCase(licence.getTarR8Infringement().getCeCase());
			numArr[0]++;
		});
		testRepository.getFilingTarR141Infringement().stream().forEach(filing -> {
			CeTask ceTask = ceTaskHelper.createCeTaskForAaOrAbpr(filing, Messages.CeTaskDetails.R141_FINANCIAL_REQUIREMENT_LATE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
			ceTask.setForCase(filing.getTarR141Infringement().getCeCase());
			numArr[0]++;
		});
		testRepository.getTarR13Infringement().stream().forEach(fyUpdate -> {
			CeTask ceTask = ceTaskHelper.createCeTaskForFye(fyUpdate, Messages.CeTaskDetails.R13_UPDATE_FYE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
			ceTask.setForCase(fyUpdate.getTarR13Infringement().getCeCase());
			numArr[0]++;
		});
		testRepository.getTarR7aInfringement().stream().forEach(cessation -> {
			Licence licence = cessation.getApplication().getLicence();
			CeTask ceTask = ceTaskHelper.createCeTaskForLicenceCeasedLate(licence, cessation.getEffectiveDate(), Messages.CeTaskDetails.R7A_CESSATION_LATE_SUBMISSION,
					Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, Codes.CeTaskTypes.CE_TASK_TAR_R7_A);
			ceTask.setForCase(cessation.getTarR7aInfringement().getCeCase());
			numArr[0]++;
		});
		testRepository.getTarR9Infringement().stream().forEach(shortfall -> {
			CeTask ceTask = ceTaskHelper.createCeTaskForShortfall(shortfall, Messages.CeTaskDetails.R9_SHORTFALL_LATE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
			ceTask.setForCase(shortfall.getTarR9Infringement().getCeCase());
			numArr[0]++;
		});
		testRepository.getTarR153bInfringement().stream().forEach(ke -> {
			TaStakeholder lastResignedKe = taCommonRepository.getTaLastResignedKe(ke.getLicence().getId());
			LocalDate dateSinceKeisVacant = lastResignedKe != null ? lastResignedKe.getResignedDate() : ke.getLicence().getIssueDate();
			CeTask ceTask = ceTaskHelper.createCeTaskForKeVacant(ke.getLicence(), dateSinceKeisVacant, Messages.CeTaskDetails.R15_3B_KE_VACANT, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
			ceTask.setForCase(ke.getTarR153bInfringement().getCeCase());
			numArr[0]++;
		});
		testRepository.getTarR153aInfringement().stream().forEach(tas -> {
			CeTask ceTask = ceTaskHelper.createCeTaskForKeLateSubmission(tas, Messages.CeTaskDetails.R15_3A_KE_RESIGN, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
			ceTask.setForCase(tas.getTarR153aInfringement().getCeCase());
			numArr[0]++;
		});

		return "CeTask created " + numArr[0];
	}

	// http://localhost:9191/webservice-admin/api/v1/test/zip-files
	@RequestMapping(method = RequestMethod.GET, value = "/zip-files")
	public String zipFiles() {
		List<String> srcFiles = Arrays.asList("C:/test/stb-tag/admin/zip-test/test1.txt", "C:/test/stb-tag/admin/zip-test/test2.txt");
		try {
			FileOutputStream fos = new FileOutputStream("C:/test/stb-tag/admin/zip-test/multiCompressed.zip");
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			for (String srcFile : srcFiles) {
				File fileToZip = new File(srcFile);
				zipFile(fileToZip, fileToZip.getName(), zipOut);
			}
			zipOut.close();
			fos.close();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return "end of zip file method";
	}

	// http://localhost:9191/webservice-admin/api/v1/test/zip-directory
	@RequestMapping(method = RequestMethod.GET, value = "/zip-directory")
	public String zipDirectory() {
		try {
			FileOutputStream fos = new FileOutputStream("C:/test/stb-tag/admin/zip-test/dirCompressed.zip");
			ZipOutputStream zipOut = new ZipOutputStream(fos);
			File fileToZip = new File("C:/test/stb-tag/admin/zip-test/zipTest");
			zipFile(fileToZip, fileToZip.getName(), zipOut);
			zipOut.close();
			fos.close();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return "end of zip directory method";
	}

	private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
		if (fileToZip.isHidden()) {
			return;
		}
		if (fileToZip.isDirectory()) {
			if (fileName.endsWith("/")) {
				zipOut.putNextEntry(new ZipEntry(fileName));
				zipOut.closeEntry();
			} else {
				zipOut.putNextEntry(new ZipEntry(fileName + "/"));
				zipOut.closeEntry();
			}
			File[] children = fileToZip.listFiles();
			for (File childFile : children) {
				zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
			}
			return;
		}
		FileInputStream fis = new FileInputStream(fileToZip);
		ZipEntry zipEntry = new ZipEntry(fileName);
		zipOut.putNextEntry(zipEntry);
		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zipOut.write(bytes, 0, length);
		}
		fis.close();
	}
}