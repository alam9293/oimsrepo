package gov.stb.tag.controllers;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.wiz.security.TokenAuthenticationService;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Bulletin;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseComplainant;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgCourseAttendanceDetail;
import gov.stb.tag.model.TgLicenceCreation;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgMlptSlot;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.BaseRepository;
import gov.stb.tag.repository.CeProvisionRepository;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.TestRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ta.TaLicenceCreationRepository;
import gov.stb.tag.repository.ta.TaLicenceRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgCandidateRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgTrainingProviderRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;

//TODO: FOR TESTING ONLY, TO BE REMOVED IN PRODUCTION
@RestController
@RequestMapping(path = "/api/v1/uat-test")
@Transactional
public class UatTestController extends BaseController {

	@Autowired
	BaseRepository baseRepository;
	@Autowired
	CommonRepository commonRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	TaLicenceRepository taLicenceRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TaLicenceCreationRepository taLicenceCreationRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	TgCandidateRepository tgCandidateRepository;
	@Autowired
	TestRepository testRepository;
	@Autowired
	TouristGuideRepository touristGuideRepository;
	@Autowired
	TgTrainingProviderRepository tgTrainingProviderRepository;
	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgApplicationRepository tgApplicationRepository;
	@Autowired
	CeProvisionRepository ceProvisionRepository;

	static String APLHABETS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	static StringBuilder msg = new StringBuilder();
	static Date now = new Date();
	static Integer roundNum = 1;

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-payment-requests/5/S1234567A/DON
	@RequestMapping(method = RequestMethod.GET, value = "/create-payment-requests/{count}/{uinUen}/{name}")
	public String createPaymentRequests(@PathVariable Integer count, @PathVariable String uinUen, @PathVariable String name) {
		for (int i = 0; i < count; i++) {
			paymentHelper.savePaymentRequest("REFNO" + i, Codes.CePaymentRequestTypes.PAYREQ_CE_AFP, uinUen, name, new BigDecimal(100), "This is a test description.", null, false, true);
		}
		return count + " Payment Requests successfully created.";
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/stb-ta-officers
	@RequestMapping(method = RequestMethod.GET, value = "/stb-ta-officers")
	public String createStbTaOfficers() {

		addTaOfficers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/ta-test-data
	@RequestMapping(method = RequestMethod.GET, value = "/ta-test-data")
	public String createTaTestData() {

		addTravelAgents();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/ta-users
	@RequestMapping(method = RequestMethod.GET, value = "/ta-users")
	public String createTaUsers() {

		addTaUsers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/ta-users-2
	@RequestMapping(method = RequestMethod.GET, value = "/ta-users-2")
	public String createTaUsers2() {

		addTaUsers2();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-ke-user
	@RequestMapping(method = RequestMethod.GET, value = "/create-ke-user")
	public String createKeUsers() {

		addKeUsers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-new-ke-user
	@RequestMapping(method = RequestMethod.GET, value = "/create-new-ke-user")
	public String createNewKeUsers() {

		addNewKeUsers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-company-stakeholders
	@RequestMapping(method = RequestMethod.GET, value = "/create-company-stakeholders")
	public String createCompanyStakeholders() {

		addCompanyStakeholders();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/stb-cne-officers
	@RequestMapping(method = RequestMethod.GET, value = "/stb-cne-officers")
	public String createStbCneOfficers() {

		addCneOfficers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/stb-finance-officers
	@RequestMapping(method = RequestMethod.GET, value = "/stb-finance-officers")
	public String createStbFinanceOfficers() {

		addFinanceOfficers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/uta-users
	@RequestMapping(method = RequestMethod.GET, value = "/uta-users")
	public String createUtaUsers() {

		addUtaUsers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/tg-users
	@RequestMapping(method = RequestMethod.GET, value = "/tg-users")
	public String createTgUsers() {

		addTgUsers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/tp-users
	@RequestMapping(method = RequestMethod.GET, value = "/tp-users")
	public String createTpUsers() {

		addTpUsers();

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-ma-filing-conditions
	@RequestMapping(method = RequestMethod.GET, value = "/create-ma-filing-conditions")
	public String createMaFilingConditions() {
		testRepository.getTaLicencesByExpiryDate(LocalDate.of(2020, 12, 31)).forEach(licence -> {
			TaFilingCondition filing = new TaFilingCondition();
			filing.setRequestedAsAtDate(LocalDate.now());
			filing.setApplicationType(cache.getType(Codes.ApplicationTypes.TA_APP_MA_SUBMISSION));
			filing.setDueDate(LocalDate.now().plusDays(28));
			filing.setLicence(licence);
			filing.setFy(LocalDate.now().getYear());
			filing.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_SUBMISSION));
			testRepository.save(filing);
			appendLn("OK. Licence: " + licence.getLicenceNo());
		});
		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/prefix-ta-name
	@RequestMapping(method = RequestMethod.GET, value = "/prefix-ta-name")
	public String prefixTaName() {
		String chars = "0123456789ABCDEFGHJKLMNPQRSTWXYZ";
		int i = 0;
		for (TravelAgent ta : travelAgentRepository.getTravelAgents()) {
			ta.setName(chars.charAt(i++) + ta.getName());
			if (i == chars.length()) {
				i = 0;
			}
			testRepository.save(ta);
			appendLn("OK. TA: " + ta.getName());
		}
		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/find-ke-vacant
	@RequestMapping(method = RequestMethod.GET, value = "/find-ke-vacant")
	public String findTaHasKeVacantForMoreThan3Months() {
		appendLn("TA Number, TA Name, Licence Status, Previous KE AppointedDate, Previous KE resigned date, New KE appointed date, Remarks");

		Map<String, List<TaStakeholder>> keListByLicenceNo = testRepository.getAllKe().stream().collect(Collectors.groupingBy(ke -> ke.getLicence().getLicenceNo()));
		keListByLicenceNo.entrySet().forEach(entry -> {
			logger.info("Processing licence no. {}", entry.getKey());
			TaStakeholder previousKe = null;
			TaStakeholder newKe = null;
			List<TaStakeholder> keList = entry.getValue().stream().sorted(Comparator.comparing(TaStakeholder::getResignedDate, Comparator.nullsLast(Comparator.naturalOrder())))
					.collect(Collectors.toList());
			for (int i = 0; i < keList.size(); i++) {
				newKe = keList.get(i);
				if (i > 0) {
					if (previousKe.getResignedDate() == null) {
						StringBuilder sb = new StringBuilder();
						sb.append(newKe.getLicence().getLicenceNo()).append(",");
						sb.append(newKe.getLicence().getTravelAgent().getName()).append(",");
						sb.append(cache.getLabel(newKe.getLicence().getStatus(), false)).append(",");
						sb.append(DateUtil.format(previousKe.getAppointedDate())).append(",");
						sb.append(",");
						sb.append(DateUtil.format(newKe.getAppointedDate())).append(",");
						sb.append("Previous KE has no resigned date");
						appendLn(sb.toString());

					} else if (newKe.getAppointedDate().isAfter(previousKe.getResignedDate().plusMonths(3))) {
						StringBuilder sb = new StringBuilder();
						sb.append(newKe.getLicence().getLicenceNo()).append(",");
						sb.append(newKe.getLicence().getTravelAgent().getName()).append(",");
						sb.append(cache.getLabel(newKe.getLicence().getStatus(), false)).append(",");
						sb.append(DateUtil.format(previousKe.getAppointedDate())).append(",");
						sb.append(DateUtil.format(previousKe.getResignedDate())).append(",");
						sb.append(DateUtil.format(newKe.getAppointedDate())).append(",");
						sb.append("New KE appointed more than 3 months later.");
						appendLn(sb.toString());
					}
				}
				previousKe = keList.get(i);
			}
		});

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/find-shortfall-infringement
	@RequestMapping(method = RequestMethod.GET, value = "/find-shortfall-infringement")
	public String findShortfallHasInfringement() {
		appendLn("TA Number, Shortfall Amount, Rectification Due Date, Extended Date, Rectified Date");

		testRepository.getUnfulfiledShortfallAfterDueDate().forEach(shortfall -> {
			StringBuilder sb = new StringBuilder();
			sb.append(shortfall.getWorkflow().getLicence().getLicenceNo()).append(",");
			sb.append(shortfall.getAmount()).append(",");
			sb.append(DateUtil.format(shortfall.getRectificationDueDate())).append(",");
			sb.append(shortfall.getExtendedDueDate() != null ? DateUtil.format(shortfall.getExtendedDueDate()) : "").append(",");
			if (shortfall.getTaNetValueRectification() != null) {
				sb.append(DateUtil.format(shortfall.getTaNetValueRectification().getRectifiedDate())).append(",");
			} else {
				sb.append("").append(",");
			}
			appendLn(sb.toString());
		});

		return msg.toString();
	}

	public String addMaFilingConditions() {
		init();

		return msg.toString();
	}

	// add functions
	public String addTaOfficers() {
		init();

		Map<String, User> existingUsers = getExistingUsers();
		List<String> taRoles = Lists.newArrayList(Codes.Roles.TA_PROCESSING_OFFICER, Codes.Roles.TA_VERIFYING_OFFICER, Codes.Roles.TA_APPROVING_OFFICER, Codes.Roles.TA_VIEWER);
		List<String> mgmtRoles = Lists.newArrayList(Codes.Roles.HEAD_OF_DIVISION, Codes.Roles.TA_APPROVING_OFFICER, Codes.Roles.TG_APPROVING_OFFICER, Codes.Roles.TG_VIEWER);
		List<String> cneRoles = Lists.newArrayList(Codes.Roles.CNE_COMPLIANCE_OFFICER, Codes.Roles.TA_CNE_ENFORCEMENT_OFFICER, Codes.Roles.CNE_INVESTIGATION_OFFICER, Codes.Roles.TA_VIEWER);
		List<String> allRoles = Lists.newArrayList();
		cache.getRoles().forEach(r -> {
			if (!r.getCode().contains("PUB") && !r.getCode().contains("TG_CDD")) {
				allRoles.add(r.getCode());
			}
		});

		String chars = "";
		String loginId = "";
		String name = "";

		loginId = "stb_baharudeen";
		name = "Baharudeen";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		loginId = "stb_chenkeongl";
		name = "Lim Chen Keong";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(mgmtRoles), null, null, null, null, null);

		loginId = "stb_alvinl";
		name = "Alvin Lim";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_brendal";
		name = "Brenda Loh";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(mgmtRoles), null, null, null, null, null);

		loginId = "stb_deynac";
		name = "Deyna Isaiah CHAN";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(mgmtRoles), null, null, null, null, null);

		loginId = "stb_noorulhudah";
		name = "noorulhudah";
		chars = "D E F G H I J K L M N";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_seowhwang";
		name = "Chua Seow Hwang";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_mervynl";
		name = "Mervyn Lee";
		chars = "0 1 2 3 4 5 6 7 8 9 A B C";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_lingleeo";
		name = "Ong Ling Lee";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(mgmtRoles), null, null, null, null, null);

		loginId = "stb_jeremyc";
		name = "Jeremy Chan Zhai Ming";
		chars = "O P Q R S T U V W X Y Z";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_janetf";
		name = "Janet Foo";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		loginId = "stb_gabrialt";
		name = "Gabriel Tan";
		chars = "O P Q R S T U V W X Y Z";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_austint";
		name = "Austin Tan";
		chars = "D E F G H I J K L M N";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_jinteckq";
		name = "Quek Jin Teck";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		loginId = "stb_kiansengn";
		name = "Ng Kian Seng";
		chars = "0 1 2 3 4 5 6 7 8 9 A B C";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		loginId = "stb_wiz";
		name = "Wizvision Support";
		chars = "";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(allRoles), null, null, null, null, null);

		return msg.toString();
	}

	// add functions
	public String addTaOfficersXX() {
		init();

		Map<String, User> existingUsers = getExistingUsers();
		List<String> taRoles = Lists.newArrayList(Codes.Roles.TA_PROCESSING_OFFICER, Codes.Roles.TA_VERIFYING_OFFICER, Codes.Roles.TA_APPROVING_OFFICER, Codes.Roles.HEAD_OF_DIVISION);

		String chars = "";
		String loginId = "";
		String name = "";

		// symbols + digit + A-C
		loginId = "STB-TAUSER1";
		name = "TA USER 1 A-C";
		for (int c = 33; c <= 64; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		for (int c = 91; c <= 96; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		for (int c = 123; c <= 126; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		for (int c = 65; c <= 67; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// D - F
		chars = "";
		loginId = "STB-DEYNA";
		name = "Deyna D-F";
		for (int c = 68; c <= 70; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// G - I
		chars = "";
		loginId = "STB-GABRIEL";
		name = "Gabriel Tan G-I";
		for (int c = 71; c <= 73; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// J - L
		chars = "";
		loginId = "STB-KIANSENG";
		name = "Kian Seng NG J-L";
		for (int c = 74; c <= 76; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// M - O
		chars = "";
		loginId = "STB-MERVYN";
		name = "Mervyn Lee M-O";
		for (int c = 77; c <= 79; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// P - R
		chars = "";
		loginId = "STB-TAUSER2";
		name = "TA USER 2 P-R";
		for (int c = 80; c <= 82; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// S - U
		chars = "";
		loginId = "STB-SEOWHWANG";
		name = "Seow Hwang CHUA  S-U";
		for (int c = 83; c <= 85; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// V - X
		chars = "";
		loginId = "STB-TAUSER3";
		name = "TA USER 3 V-X";
		for (int c = 86; c <= 88; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		// Y - Z
		chars = "";
		loginId = "STB-TAWIZ";
		name = "TA WIZ Y-Z";
		for (int c = 89; c <= 90; c++) {
			char upper = (char) c;
			chars = chars.concat(" " + upper);
		}
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(taRoles), null, null, null, null, null);

		return msg.toString();
	}

	public String addCneOfficers() {
		init();

		Map<String, User> existingUsers = getExistingUsers();
		List<String> cneRoles = Lists.newArrayList(Codes.Roles.CNE_COMPLIANCE_OFFICER, Codes.Roles.TA_CNE_ENFORCEMENT_OFFICER, Codes.Roles.CNE_INVESTIGATION_OFFICER, Codes.Roles.TA_VIEWER);

		String chars = "";
		String loginId = "";
		String name = "";

		loginId = "STB-BAHARUDEEN";
		name = "Baharudeen Ali MOHAMED KASSIM";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		loginId = "STB-CHENKEONG";
		name = "Chen Keong LIM";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		loginId = "STB-BRENDA";
		name = "Brenda LOH";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		loginId = "STB-JANET";
		name = "Janet FOO";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		loginId = "STB-ALVIN";
		name = "Alvin LIM";
		createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);

		return msg.toString();
	}

	public String addFinanceOfficers() {
		init();

		Map<String, User> existingUsers = getExistingUsers();
		List<String> cneRoles = Lists.newArrayList(Codes.Roles.FINANCE);

		String chars = "";
		String loginId = "";
		String name = "";

		for (int i = 0; i < 7; i++) {
			loginId = "STB-FIN" + (i + 1);
			name = "Finance User " + (i + 1);
			createTestUser(existingUsers, loginId, name, chars, Lists.newArrayList(cneRoles), null, null, null, null, null);
		}

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-ta-candidate-user/{count}
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-candidate-user/{count}")
	public String createTaCandidateUsers(@PathVariable Integer count) {
		init();
		SecureRandom r = new SecureRandom();

		// create one user for each licensees
		for (int i = 0; i < count; i++) {

			User user = new User();

			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			String uen = "";
			do {
				uen = "";
				for (int k = 0; k < 8; k++) {
					uen += r.nextInt(10);
				}
				uen += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			} while (testRepository.uenUsed(uen));
			user.setUen(uen);
			String loginId = uen + "-1";
			user.setLoginId(loginId);
			user.setName("TA Candidate of " + uen);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TA_CANDIDATE));
			baseRepository.save(user);

			appendLn(user.getLoginId());

			User user2 = new User();
			user2.setLoginId(uen + "-2");
			user2.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user2.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user2.setUen(uen);
			user2.setName("2nd TA Candidate of " + uen);
			user2.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user2.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user2.setRoles(Sets.newHashSet());
			user2.getRoles().add(cache.getRole(Codes.Roles.TA_CANDIDATE));
			baseRepository.save(user2);

			appendLn(user2.getLoginId());
		}

		appendLn(count + " TA licensees successfully created.");

		return msg.toString();
	}

	public String addTravelAgents() {
		init();
		Map<String, User> existingUsers = getExistingUsers();

		for (String loginId : existingUsers.keySet()) {
			User user = existingUsers.get(loginId);
			if (!Strings.isNullOrEmpty(user.getTaAssigneeChars())) {
				List<String> chars = Arrays.asList(user.getTaAssigneeChars().split(" "));
				for (String c : chars) {
					createTravelAgent(true, Codes.Types.TA_TIER_GENERAL, c);
					createTravelAgent(true, Codes.Types.TA_TIER_NICHE, c);
					createTravelAgent(false, Codes.Types.TA_TIER_GENERAL, c);
					createTravelAgent(false, Codes.Types.TA_TIER_NICHE, c);
				}
			}
		}
		return msg.toString();
	}

	public String addTaUsers() {
		init();
		Map<String, User> existingUsers = getExistingUsers();

		for (TravelAgent ta : getTravelAgents()) {
			int count = 0;
			createTestUser(existingUsers, ta.getLicence().getLicenceNo() + "-" + (++count), "TA User " + count + " of " + ta.getUen(), null, Lists.newArrayList(Codes.Roles.TA_PUBLIC), ta.getUen(), ta,
					null, null, null);
		}

		for (TaLicenceCreation pta : taLicenceCreationRepository.getAllPendingApplications()) {
			if (!Strings.isNullOrEmpty(pta.getAppUin())) {
				createTestUser(existingUsers, pta.getAppUin(), "PTA User of " + pta.getUen(), null, Lists.newArrayList(Codes.Roles.TA_CANDIDATE), pta.getUen(), null, null, null, null);
			}
		}

		return msg.toString();
	}

	public String addTgUsers() {
		init();
		Map<String, User> existingUsers = getExistingUsers();

		for (TouristGuide tg : touristGuideRepository.getTouristGuides()) {
			int count = 0;
			createTestUser(existingUsers, tg.getLicence().getLicenceNo() + "-" + (++count), "TG User " + count + " of " + tg.getUin(), null, Lists.newArrayList(Codes.Roles.TG_PUBLIC), null, null, tg,
					null, null);
		}

		return msg.toString();
	}

	public String addTaUsers2() {
		init();
		Map<String, User> existingUsers = getExistingUsers();

		for (TravelAgent ta : getTravelAgents()) {
			createTestUser(existingUsers, ta.getLicence().getLicenceNo() + "-2", "TA User 2 of " + ta.getUen(), null, Lists.newArrayList(Codes.Roles.TA_PUBLIC), ta.getUen(), ta, null, null, null);
		}

		return msg.toString();
	}

	public String addKeUsers() {
		init();
		Map<String, User> existingUsers = getExistingUsers();

		// create one user for each key executive
		for (TaStakeholder take : getKeyExecutives()) {
			Stakeholder ke = take.getStakeholder();
			String loginId = ke.getUin();
			TravelAgent ta = take.getLicence().getTravelAgent();
			createTestUser(existingUsers, loginId, ke.getName(), null, Lists.newArrayList(Codes.Roles.TA_PUBLIC), ta.getUen(), ta, null, null, null);
		}

		return msg.toString();
	}

	public String addNewKeUsers() {
		init();
		Map<String, User> existingUsers = getExistingUsers();
		SecureRandom r = new SecureRandom();
		for (TravelAgent ta : getTravelAgents()) {
			String[] sprPrefix = new String[] { "S", "T" };
			var localUin = sprPrefix[r.nextInt(2)] + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();
			createTestUser(existingUsers, localUin, "New Local KE for " + ta.getUen(), null, Lists.newArrayList(Codes.Roles.TA_PUBLIC), ta.getUen(), ta, null, null, null);

			String[] nonSprPrefix = new String[] { "F", "G" };
			var foreignUin = nonSprPrefix[r.nextInt(2)] + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();
			createTestUser(existingUsers, foreignUin, "New Foreign KE for " + ta.getUen(), null, Lists.newArrayList(Codes.Roles.TA_PUBLIC), ta.getUen(), ta, null, null, null);

			createTestUser(existingUsers, ta.getLicence().getLicenceNo() + "-2", "TA User 2 of " + ta.getUen(), null, Lists.newArrayList(Codes.Roles.TA_PUBLIC), ta.getUen(), ta, null, null, null);
		}
		return msg.toString();
	}

	public String addCompanyStakeholders() {
		init();
		SecureRandom r = new SecureRandom();
		for (TravelAgent ta : getTravelAgents()) {
			TaStakeholder taStakeholder = new TaStakeholder();
			taStakeholder.setAppointedDate(LocalDate.of(2000, 01, 01));
			taStakeholder.setSharesHeld(1000);
			taStakeholder.setLicence(ta.getLicence());
			taStakeholder.setRole(cache.getStakeholderRoles().stream().filter(o -> o.getCode().equals(Codes.TaStakeholderRoles.STKHLD_SHAREHOLDER)).findFirst().get());
			Stakeholder stakeholder = new Stakeholder();
			stakeholder.setIsCompany(true);

			// random uen
			String uen = "";
			for (int i = 0; i < 8; i++) {
				uen += r.nextInt(10);
			}
			uen += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			stakeholder.setCompanyUen(uen);
			stakeholder.setName("Company " + uen);
			stakeholder.setSex(null);
			stakeholder.setNationality(null);

			// random incorporated date
			int ranYear = r.nextInt(28) + 1990;
			int ranMonth = r.nextInt(12) + 1;
			int ranDate = r.nextInt(28) + 1;
			stakeholder.setCompanyIncorporatedDate(LocalDate.of(ranYear, ranMonth, ranDate));

			Address stakeholderAdd = new Address();
			stakeholderAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			stakeholderAdd.setPostal("000011");
			stakeholderAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
			stakeholderAdd.setStreet("Princess Street");
			stakeholderAdd.setBlock("11");
			stakeholder.setAddress(stakeholderAdd);
			taStakeholder.setStakeholder(stakeholder);

			baseRepository.save(stakeholderAdd);
			baseRepository.save(stakeholder);
			baseRepository.save(taStakeholder);

			appendLn("OK. Company TaStakeholder: " + stakeholder.getCompanyUen() + ", role: " + taStakeholder.getRole().getCode());
		}
		return msg.toString();
	}

	public String addUtaUsers() {
		init();
		Map<String, User> existingUsers = getExistingUsers();

		for (CeCaseInfringer uta : testRepository.getUtaCeCaseInfringer()) {
			createTestUser(existingUsers, uta.getUenUin(), uta.getName(), null, Lists.newArrayList(Codes.Roles.TA_CANDIDATE), uta.getUenUin(), null, null, null, null);
		}

		return msg.toString();
	}

	public String addTpUsers() {
		init();
		Map<String, User> existingUsers = getExistingUsers();

		for (TgTrainingProvider tp : testRepository.getTrainingProvider()) {
			createTestUser(existingUsers, tp.getUen(), tp.getName(), null, Lists.newArrayList(Codes.Roles.TP_PUBLIC), null, null, null, null, tp);
		}

		return msg.toString();
	}

	// init

	private void init() {
		msg = new StringBuilder();
		now = new Date();
	}

	private void appendHeader(String testItem, boolean isPositiveTest) {
		if (isPositiveTest) {
			msg.append("<b style='color:green'>");
		} else {
			msg.append("<b style='color:red'>");
		}
		msg.append(testItem);
		msg.append(":");
		msg.append("</b>");
		msg.append("<br />");
	}

	private void appendLn(String text) {
		msg.append(text);
		msg.append("<br />");
	}

	private void appendErrorLn(String text) {
		msg.append("<b style='color:red'>");
		msg.append(text);
		msg.append("</b>");
		msg.append("<br />");
	}

	// Create users
	private User createTestUser(Map<String, User> existingUsers, String loginId, String name, String chars, List<String> roles, String uen, TravelAgent ta, TouristGuide tg, TgCandidate tgCdd,
			TgTrainingProvider tp) {
		User user = null;
		String key = loginId;
		if (!Strings.isNullOrEmpty(uen)) {
			key = loginId + "|" + uen;
		}
		if (existingUsers.containsKey(key)) {
			user = existingUsers.get(key);
		} else {
			user = new User();
		}
		user.setLoginId(loginId);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName(name);
		user.setEmailAddress(loginId + "@wizvision-tag.com");
		if (!Objects.isNull(ta) || !Objects.isNull(tg) || !Objects.isNull(tgCdd) || !Objects.isNull(tp)) {
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		} else if (!Strings.isNullOrEmpty(uen)) {
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		} else {
			user.setType(cache.getType(Codes.UserTypes.USER_STB));
		}

		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setTaAssigneeChars(chars);
		user.setRoles(Sets.newHashSet());
		for (String role : roles) {
			user.getRoles().add(cache.getRole(role));
		}
		user.setTravelAgent(ta);
		user.setTouristGuide(tg);
		user.setTgTrainingProvider(tp);
		user.setUen(uen);
		baseRepository.save(user);

		appendLn("OK. User: " + user.getLoginId() + ", roles: " + user.getRoles().toString());

		return user;
	}

	// create travel agents
	private TravelAgent createTravelAgent(Boolean withBranches, String licenceType, String companyNamePrefix) {
		SecureRandom r = new SecureRandom();
		TravelAgent ta = new TravelAgent();

		// random uen
		String uen = "";
		for (int i = 0; i < 8; i++) {
			uen += r.nextInt(10);
		}
		uen += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
		ta.setUen(uen);

		// random incorporated date
		int ranYear = r.nextInt(18) + 2000;
		int ranMonth = r.nextInt(12) + 1;
		int ranDate = r.nextInt(28) + 1;
		ta.setIncorporatedDate(LocalDate.of(ranYear, ranMonth, ranDate));

		// hard coded variables
		ta.setName(companyNamePrefix + " Travel Of " + uen + " Pte Ltd");
		ta.setPaidUpCapital(new BigDecimal(100000));
		ta.setWebsiteUrl("http://www.wiz-elmo.com");
		ta.setEmailAddress("wiz-" + uen + "@wizvision-tag.com");
		ta.setContactNo("66666666");
		ta.setFyeDate(LocalDate.now().minusYears(1).minusDays(1));
		ta.setPrincipleActivities(cache.getPrincipleActivities().stream().findFirst().get());
		ta.setSecondaryPrincipleActivities(cache.getPrincipleActivities().stream().filter(o -> !o.getCode().equals(ta.getPrincipleActivities().getCode())).findFirst().get());
		ta.setEstablishmentStatus(cache.getEstablishmentStatuses().stream().findFirst().get());
		ta.setIncorporatedPlace(cache.getCountries().stream().findFirst().get());
		ta.setFormOfBusiness(cache.getFormOfBusiness().stream().findFirst().get());
		ta.setTaSegmentation(cache.getTaSegmentations().stream().findFirst().get());
		ta.setBusinessConstitution(cache.getBusinessConstitution().stream().findFirst().get());

		// registered address
		Address registered = new Address();
		registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		registered.setPostal("000000");
		registered.setPremiseType(cache.getType("PREM_21"));
		registered.setStreet("Sesame Street");
		registered.setBlock("10");
		registered.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		ta.setRegisteredAddress(registered);

		// operating address
		Address operating = new Address();
		operating.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		operating.setPostal("000000");
		operating.setPremiseType(cache.getType("PREM_21"));
		operating.setStreet("Sesame Street");
		operating.setBlock("10");
		operating.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		ta.setOperatingAddress(operating);

		// licence
		LocalDate licenceStartDate = LocalDate.of(2017, 01, 01);
		Licence licence = new Licence();
		licence.setTravelAgent(ta);
		licence.setTaTgType(Codes.TaTgType.TA);
		licence.setTier(cache.getType(licenceType));
		licence.setStartDate(licenceStartDate.isBefore(ta.getIncorporatedDate()) ? ta.getIncorporatedDate().plusDays(1) : licenceStartDate);
		licence.setExpiryDate(LocalDate.of(2020, 12, 31));
		licence.setIssueDate(licence.getStartDate());
		licence.setStatus(cache.getStatus(Codes.Statuses.TA_ACTIVE));

		// ke
		TaStakeholder ke = new TaStakeholder();
		ke.setAppointedDate(LocalDate.of(2000, 01, 01));
		ke.setLicence(licence);
		ke.setRole(cache.getType(Codes.TaStakeholderRoles.STKHLD_KE));
		Stakeholder keDetails = new Stakeholder();
		keDetails.setIsCompany(false);
		String nric = "S";
		for (int k = 0; k < 7; k++) {
			nric += r.nextInt(10);
		}
		nric += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
		keDetails.setUin(nric);
		keDetails.setName("KE " + nric);
		int ranYear2 = r.nextInt(50) + 1960;
		int ranMonth2 = r.nextInt(12) + 1;
		int ranDate2 = r.nextInt(28) + 1;
		keDetails.setDob(LocalDate.of(ranYear2, ranMonth2, ranDate2));
		keDetails.setContactNo("6666 6666");
		keDetails.setHighestEduLevel(cache.getEducationLevels().stream().findFirst().get());
		keDetails.setDesignation(cache.getOccupations().stream().findFirst().get());
		keDetails.setSex(cache.getType(Codes.Types.SEX_M));
		keDetails.setNationality(cache.getNationalities().stream().findFirst().get());
		keDetails.setEmail("wiz-elmo@wizvision-tag.com");
		Address keAdd = new Address();
		keAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		keAdd.setPostal("000000");
		keAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
		keAdd.setStreet("Sesame Street");
		keAdd.setBlock("10");
		keDetails.setAddress(keAdd);
		ke.setStakeholder(keDetails);
		List<TaKeDeclaration> declarations = new ArrayList<>();
		for (TaKeClause clause : cache.getTaKeClauses()) {
			TaKeDeclaration declaration = new TaKeDeclaration();
			declaration.setTaKeClause(clause);
			if (clause.isOptionsRequired()) {
				List<String> options = Arrays.asList(clause.getOptions().split("\\|"));
				declaration.setOptionSelected(options.stream().filter(o -> !o.equals(clause.getOptionsToPrompt())).findFirst().get());

			}
			declaration.setTaKeyExecutive(ke);
			declarations.add(declaration);

		}

		// stakeholders
		List<TaStakeholder> stakeholders = new ArrayList<>();
		for (int i = 0; i < 3; i++) {
			TaStakeholder taStakeholder = new TaStakeholder();
			taStakeholder.setAppointedDate(LocalDate.of(2000, 01, 01));
			taStakeholder.setSharesHeld(1000);
			taStakeholder.setLicence(licence);
			taStakeholder.setRole(cache.getStakeholderRoles().stream().filter(o -> !o.getCode().equals(Codes.TaStakeholderRoles.STKHLD_KE)).findFirst().get());
			Stakeholder stakeholder = new Stakeholder();
			stakeholder.setIsCompany(false);
			String stakeholderId = "";
			for (int k = 0; k < 7; k++) {
				stakeholderId += r.nextInt(10);
			}
			stakeholderId += APLHABETS.charAt(r.nextInt(APLHABETS.length()));
			stakeholder.setUin(stakeholderId);
			stakeholder.setName("Personnel " + stakeholderId);
			stakeholder.setSex(cache.getType(Codes.Types.SEX_M));
			stakeholder.setNationality(cache.getNationalities().stream().findFirst().get());
			Address stakeholderAdd = new Address();
			stakeholderAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			stakeholderAdd.setPostal("000000");
			stakeholderAdd.setPremiseType(cache.getPremiseTypes().stream().findFirst().get());
			stakeholderAdd.setStreet("Sesame Street");
			stakeholderAdd.setBlock("10");
			stakeholder.setAddress(stakeholderAdd);
			taStakeholder.setStakeholder(stakeholder);
			stakeholders.add(taStakeholder);
		}

		// branch
		List<TaBranch> branches = new ArrayList<>();
		int branchCounts = withBranches ? 3 : 0;
		for (int i = 0; i < branchCounts; i++) {
			TaBranch branch = new TaBranch();
			branch.setLicence(licence);
			branch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_ACTIVE));
			Address branchAdd = new Address();
			branchAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			String postalCode = "";
			for (int k = 0; k < 6; k++) {
				postalCode += r.nextInt(10);
			}
			branchAdd.setPostal(postalCode);
			branchAdd.setPremiseType(cache.getType("PREM_21"));
			branchAdd.setStreet("Sesame Street");
			String blk = "";
			for (int k = 0; k < 3; k++) {
				blk += r.nextInt(10);
			}
			branchAdd.setBlock(blk);
			branch.setAddress(branchAdd);
			branches.add(branch);
		}

		// saving
		licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TA_ACTIVE);
		baseRepository.save(ta.getRegisteredAddress());
		baseRepository.save(ta.getOperatingAddress());
		baseRepository.save(licence);
		ta.setLicence(licence);
		baseRepository.save(ta);
		baseRepository.save(keDetails.getAddress());
		baseRepository.save(keDetails);
		baseRepository.save(ke);
		baseRepository.save(declarations);
		stakeholders.stream().forEach(o -> {
			baseRepository.save(o.getStakeholder().getAddress());
			baseRepository.save(o.getStakeholder());
		});
		baseRepository.save(stakeholders);
		branches.stream().forEach(o -> baseRepository.save(o.getAddress()));
		baseRepository.save(branches);

		appendLn("OK. TravelAgent: " + ta.getName() + ", licence: " + ta.getLicence().getId());

		return ta;
	}

	public Map<String, User> getExistingUsers() {
		Map<String, User> existingUsers = Maps.newHashMap();
		userRepository.getActiveUsers().forEach(u -> {
			if (Strings.isNullOrEmpty(u.getUen())) {
				existingUsers.put(u.getLoginId(), u);
			} else {
				existingUsers.put(u.getLoginId() + "|" + u.getUen(), u);
			}
		});

		return existingUsers;
	}

	public List<TravelAgent> getTravelAgents() {
		return travelAgentRepository.getTravelAgents();
	}

	public List<TaStakeholder> getKeyExecutives() {
		return travelAgentRepository.getKeyExecutives();
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
	 * Tourist Guide
	 */

	static String[] englishName = { "Olivia", "Jessica", "Rebecca", "Matthew", "Nick", "Harrison", "Christopher", "Benedict", "Nathan", "Nelson", "Summer", "Winter", "Freedom", "Alex", "Winnie",
			"Yvonne", "Isobel", "Paige", "Emelly", "Sienna", "Alisha", "Brasil", "Jibby", "Isabel", "Harley", "Brandon", "Rosie" };

	static String[] surname = { "Ong", "Lee", "Cheng", "Ong", "Chuah", "Harrison", "Peng", "Lim", "Lee", "Chan", "Ng", "Cheng", "Sim", "Yap", "Eng", "Wong", "Ter", "Tee", "Tan" };

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/tg-login-user/USER_PUB/5
	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/tg-login-user/USER_PUB_POR/5
	@RequestMapping(method = RequestMethod.GET, value = { "/tg-login-user/{type}/{number}" })
	public String pumpTgCandidate(@PathVariable Optional<String> type, @PathVariable Integer number) {

		List<String> uins = new ArrayList<>();
		for (int i = 0; i < number; i++) {
			String sf = "STFG";

			Random rd = new Random();
			var uin = sf.charAt(rd.nextInt(sf.length())) + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

			int engIdx = new Random().nextInt(englishName.length);
			int surIdx = new Random().nextInt(surname.length);
			String name = englishName[engIdx] + " " + surname[surIdx];

			TgCandidate tgCandidate = null;

			var tgCandidateResult = new TgCandidateResult();
			tgCandidateResult.setEmail(englishName[engIdx] + surname[surIdx] + "@wizvision-tag.com");
			tgCandidateResult.setName(name);
			tgCandidateResult.setExamDate(LocalDate.of(2019, 01, 01));
			tgCandidateResult.setGuidingLanguage(cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE).get(0));
			// tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
			tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
			baseRepository.save(tgCandidateResult);

			Set<TgCandidateResult> results = new HashSet<>();
			results.add(tgCandidateResult);

			tgCandidate = new TgCandidate();
			tgCandidate.setUin(uin);
			tgCandidate.setTgCandidateResults(results);
			tgCandidate.setLastCandidateResult(tgCandidateResult);
			baseRepository.save(tgCandidate);

			tgCandidateResult.setTgCandidate(tgCandidate);

			User user = new User();
			user.setLoginId(uin);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName(name);
			user.setEmailAddress(englishName[engIdx] + surname[surIdx] + "@wizvision-tag.com");
			user.setTgCandidate(tgCandidate);
			user.setType(cache.getType(type.get()));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TG_CANDIDATE));
			baseRepository.save(user);

			uins.add(uin);
		}

		return "TG candidate(s) created successfully. NRIC/FIN : " + StringUtils.join(uins, ", ");
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/tg-stb-user/TG_PO/5
	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/tg-stb-user/TG_AO/5
	@RequestMapping(method = RequestMethod.GET, value = { "/tg-stb-user/{role}/{number}" })
	public String pumpTgStbUser(@PathVariable Integer number, @PathVariable String role) {

		List<String> uins = new ArrayList<>();
		for (int i = 0; i < number; i++) {
			var uin = "S" + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

			int engIdx = new Random().nextInt(englishName.length);
			int surIdx = new Random().nextInt(surname.length);
			String name = englishName[engIdx] + " " + surname[surIdx];

			User user = new User();
			user.setLoginId(uin);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName(name);
			user.setEmailAddress(englishName[engIdx] + surname[surIdx] + "@wizvision-tag.com");
			user.setType(cache.getType("USER_STB"));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(role));
			baseRepository.save(user);

			uins.add(uin);
		}

		return " TG STB user(s) created successfully. nric : " + StringUtils.join(uins, ", ");
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-tg-licence
	@RequestMapping(method = RequestMethod.POST, value = "/create-tg-licence/{number}")
	public String createTgLicence(@RequestPart("file") MultipartFile multipartFile, @PathVariable Integer number) {

		gov.stb.tag.model.File file = fileHelper.saveFile("TG_DOC_PHOTO", multipartFile, true);

		for (int i = 0; i < number; i++) {
			int engIdx = new Random().nextInt(englishName.length);
			int surIdx = new Random().nextInt(surname.length);
			String name = englishName[engIdx] + " " + surname[surIdx];

			// random DOB
			SecureRandom r = new SecureRandom();
			int ranYear = r.nextInt(28) + 1990;
			int ranMonth = r.nextInt(12) + 1;
			int ranDate = r.nextInt(28) + 1;

			createTg(name, file, LocalDate.of(ranYear, ranMonth, ranDate), "S", LocalDate.of(2019, 8, 31));
		}

		return msg.toString();

	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-tg-renewal-licence
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-renewal-licence")
	public String createTgLicenceWp() {

		gov.stb.tag.model.File file = testRepository.getFirstPassportPhoto().getFile();

		TgCourse mrc = testRepository.getTgMrc();
		List<TgCourse> pdcs = testRepository.getTgPdc();
		List<TgCourseAttendance> attendances = new ArrayList<TgCourseAttendance>();
		attendances.add(createTgCourseAttendance(mrc));
		attendances.add(createTgCourseAttendance(pdcs.get(0)));
		attendances.add(createTgCourseAttendance(pdcs.get(1)));
		attendances.add(createTgCourseAttendance(pdcs.get(2)));

		String[] guyName = { "Liam", "Noah", "William", "James", "Logan" };
		for (String name : guyName) {
			initRenewalTestData(name, file, attendances);
		}

		String[] girlName = { "Samantha", "Elizabeth", "Alexis", "Sarah", "Alyssa" };
		for (String name : girlName) {
			initReinstateTestData(name, file, attendances);
		}

		return msg.toString();

	}

	private void initRenewalTestData(String name, gov.stb.tag.model.File file, List<TgCourseAttendance> attendances) {
		TouristGuide tg = createTg(name, file, LocalDate.of(1939, 8, 31), "G", LocalDate.of(2016, 9, 1));
		for (TgCourseAttendance attendance : attendances) {
			createTgCourseAttendanceDetail(tg, attendance);
		}
	}

	private void initReinstateTestData(String name, gov.stb.tag.model.File file, List<TgCourseAttendance> attendances) {
		TouristGuide tg = createTg(name, file, LocalDate.of(1990, 8, 31), "S", LocalDate.of(2012, 9, 1));
		Licence lc = tg.getLicence();
		lc.setStatus(cache.getStatus(Codes.Statuses.TG_INACTIVE));
		baseRepository.saveOrUpdate(lc);
		for (TgCourseAttendance attendance : attendances) {
			createTgCourseAttendanceDetail(tg, attendance);
		}
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-tg-renewal-licence/demo
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-renewal-licence/demo")
	public String createTgLicenceDemo(HttpServletRequest request, HttpServletResponse response) {
		addAuthentication(request, response, "stb_tzeserno", null);

		gov.stb.tag.model.File file = testRepository.getFirstPassportPhoto().getFile();
		TouristGuide tg;

		TgCourse mrc = testRepository.getTgMrc();
		List<TgCourse> pdcs = testRepository.getTgPdc();
		List<TgCourseAttendance> attendances = new ArrayList<TgCourseAttendance>();
		attendances.add(createTgCourseAttendance(mrc));
		attendances.add(createTgCourseAttendance(pdcs.get(0)));
		attendances.add(createTgCourseAttendance(pdcs.get(1)));
		attendances.add(createTgCourseAttendance(pdcs.get(2)));

		createTg("Jack", file, LocalDate.of(1939, 8, 31), "S", LocalDate.of(2017, 9, 1));

		createTg("Samantha", file, LocalDate.of(1939, 8, 31), "G", LocalDate.of(2016, 9, 1));

		tg = createTg("Elizabeth", file, LocalDate.of(1990, 8, 31), "S", LocalDate.of(2015, 9, 1));
		createTgCourseAttendanceDetails(tg, attendances);

		tg = createTg("Alexis", file, LocalDate.of(1990, 8, 31), "S", LocalDate.of(2012, 9, 1));
		createTgCourseAttendanceDetails(tg, attendances);

		tg = createTg("Sarah", file, LocalDate.of(1990, 8, 31), "S", LocalDate.of(2009, 9, 1));
		createTgCourseAttendanceDetails(tg, attendances);

		return msg.toString();

	}

	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-renewal-licence/cto")
	public String createTgLicenceCto(HttpServletRequest request, HttpServletResponse response) {
		addAuthentication(request, response, "stb_tzeserno", null);

		gov.stb.tag.model.File file = testRepository.getFirstPassportPhoto().getFile();
		TouristGuide tg;

		TgCourse mrc = testRepository.getTgMrc();
		List<TgCourse> pdcs = testRepository.getTgPdc();
		List<TgCourseAttendance> attendances = new ArrayList<TgCourseAttendance>();
		attendances.add(createTgCourseAttendance(mrc, LocalDate.now().minusDays(30)));
		attendances.add(createTgCourseAttendance(pdcs.get(0), LocalDate.now().minusDays(20)));
		attendances.add(createTgCourseAttendance(pdcs.get(1), LocalDate.now().minusDays(10)));

		tg = createTg("Tan Eng Huat", file, LocalDate.of(1939, 8, 23), "S", LocalDate.of(2016, 9, 1));
		createTgCourseAttendanceDetails(tg, attendances);

		return msg.toString();

	}

	private void createTgCourseAttendanceDetails(TouristGuide tg, List<TgCourseAttendance> attendances) {
		for (TgCourseAttendance attendance : attendances) {
			createTgCourseAttendanceDetail(tg, attendance);
		}
	}

	private TgCourseAttendance createTgCourseAttendance(TgCourse tgCourse) {
		return createTgCourseAttendance(tgCourse, LocalDate.now().minusDays(10));
	}

	private TgCourseAttendance createTgCourseAttendance(TgCourse tgCourse, LocalDate date) {

		// create application
		Application application = new Application();
		application.setIsDraft(false);
		application.setSubmissionDate(LocalDateTime.now());
		application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
		application.setTaTgType(Codes.TaTgType.TG);
		application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_PDC_SUBMISSION));
		tgApplicationRepository.save(application);

		var workflowAction = appHelper.forward(application, true);
		application.setLastAction(workflowAction);

		// create course attendance
		TgCourseAttendance tca = new TgCourseAttendance();
		tca.setAttendedDate(date);
		tca.setAttendedEndDate(date);
		tca.setApplication(application);
		tca.setTgCourse(tgCourse);

		baseRepository.save(tca);
		return tca;
	}

	private TgCourseAttendanceDetail createTgCourseAttendanceDetail(TouristGuide tg, TgCourseAttendance tca) {

		TgCourseAttendanceDetail tcad = new TgCourseAttendanceDetail();
		tcad.setTouristGuide(tg);
		tcad.setAttendance(cache.getType("TP_ATN_ATN"));
		tcad.setDeleted(false);
		tcad.setScore(28);
		tcad.setResult(cache.getType(Codes.Types.TG_RESULT_PASS));
		tcad.setMaxScore(30);

		tcad.setTgCourseAttendance(tca);

		baseRepository.save(tcad);

		return tcad;

	}

	private TouristGuide createTg(String name, gov.stb.tag.model.File file, LocalDate dob, String uinStartChar, LocalDate startDate) {
		int dobYear = dob.getYear();
		String nricStart = "";
		if (dobYear < 1968) {
			nricStart = "1" + RandomStringUtils.randomNumeric(1);
		} else {
			nricStart = Integer.toString(dobYear).substring(0, 2);
		}
		var uin = uinStartChar + nricStart + RandomStringUtils.randomNumeric(5) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

		var tgCandidateResult = new TgCandidateResult();
		tgCandidateResult.setEmail("stb.testuser@wizvision.com");
		tgCandidateResult.setName(name);
		tgCandidateResult.setExamDate(startDate);
		tgCandidateResult.setGuidingLanguage(cache.getType("TG_LANG_ENG"));
		// tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
		tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
		baseRepository.save(tgCandidateResult);

		Set<TgCandidateResult> results = new HashSet<>();
		results.add(tgCandidateResult);

		TgCandidate tgCandidate = new TgCandidate();
		tgCandidate.setUin(uin);
		tgCandidate.setTgCandidateResults(results);
		tgCandidate.setLastCandidateResult(tgCandidateResult);
		baseRepository.save(tgCandidate);

		tgCandidateResult.setTgCandidate(tgCandidate);

		User user = new User();
		user.setLoginId(uin);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName(name);
		user.setEmailAddress("stb.testuser@wizvision.com");
		user.setTgCandidate(tgCandidate);
		user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));
		baseRepository.save(user);

		TouristGuide tg = new TouristGuide();
		tg.setUin(uin);
		tg.setAliasName("Stanley");
		baseRepository.save(tg);
		user.setTouristGuide(tg);

		// licence
		Licence licence = new Licence();
		licence.setTouristGuide(tg);
		licence.setTaTgType(Codes.TaTgType.TG);
		licence.setTier(cache.getType(Codes.Types.TG_TIER_GENERAL));
		licence.setIssueDate(tgCandidateResult.getExamDate().minusYears(3));
		licence.setStartDate(tgCandidateResult.getExamDate());
		LocalDate expiryDate = tgCandidateResult.getExamDate().plusYears(3).minusDays(1);
		licence.setExpiryDate(expiryDate);
		if (expiryDate.isAfter(LocalDate.now())) {
			licence.setStatus(cache.getStatus(Codes.Statuses.TG_ACTIVE));
		} else {
			licence.setStatus(cache.getStatus(Codes.Statuses.TG_INACTIVE));
		}
		baseRepository.save(licence);

		tg.setDob(dob);

		Set<Type> guidingLanguages = new HashSet<>();
		// Set<Type> specializedAreas = new HashSet<>();

		tg.setUser(user);
		tg.setLicence(licence);
		tg.setName(name);
		tg.setBirthCountry(cache.getType("CTRY_SG"));
		tg.setHighestEduLevel(cache.getType("EDU_5"));
		tg.setMaritalStatus(cache.getType("MARI_MR"));
		tg.setNationality(cache.getType("NAT_SG"));
		tg.setRace(cache.getType("RACE_CN"));
		tg.setResidentialStatus(cache.getType("RESD_C"));
		tg.setSalutation(cache.getType("SAL_MR"));
		tg.setSex(cache.getType("SEX_M"));
		tg.setMobileNo("8" + RandomStringUtils.randomNumeric(7));
		tg.setEmailAddress(user.getEmailAddress());
		tg.setHasConsentMobileNo(true);
		tg.setHasConsentEmailAddress(true);
		tg.setPhoto(file);
		// tg.setWorkPassType(cache.getTypesByCategory(Codes.TypeCategories.WORK_PASS_TYPE).get(0));

		guidingLanguages.add(tgCandidateResult.getGuidingLanguage());
		guidingLanguages.add(cache.getType("TG_LANG_MAN"));
		// specializedAreas.add(tgCandidateResult.getSpecializedArea());

		tg.setGuidingLanguages(guidingLanguages);
		// tg.setSpecializedAreas(specializedAreas);

		// registered address
		Address registered = new Address();
		registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		registered.setPostal("381050");
		registered.setPremiseType(cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE).get(0));
		registered.setStreet("SIMS DRIVE");
		registered.setBuilding("SIMS VISTA");
		registered.setBlock("50A");
		registered.setFloor(RandomStringUtils.randomNumeric(2));
		registered.setUnit(RandomStringUtils.randomNumeric(2));
		tg.setRegisteredAddress(registered);
		tg.setMailingAddress(registered);

		baseRepository.save(tg.getRegisteredAddress());
		baseRepository.save(tg.getMailingAddress());

		appendLn(name + " - " + uin + " - " + licence.getId());
		return tg;
	}

	// create approved applications with licence status pending
	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-tg-with-application
	@RequestMapping(method = RequestMethod.POST, value = "/create-tg-with-application")
	public String createApp(@RequestPart("file") MultipartFile multipartFile) {

		gov.stb.tag.model.File file = fileHelper.saveFile("TG_DOC_PHOTO", multipartFile, true);

		String[] username = { "Percy", "Malena", "Randell", "Lavera", "Hunter", "Stacie", "Dorian", "Truman", "Elizabet", "Todd", "Lavinia", "Lyman", "Florene", "Roxana", "Dan", "Gita", "Luci",
				"Freddy", "Elvira", "Thersa" };
		String[] nricArray = { "S", "G" };
		String[] appCodeArray = { Codes.ApplicationTypes.TG_APP_CREATION, Codes.ApplicationTypes.TG_APP_RENEWAL, Codes.ApplicationTypes.TG_APP_REPLACEMENT,
				Codes.ApplicationTypes.TG_APP_PERSON_UPDATE };

		for (int i = 0; i < 20; i++) {

			var uin = nricArray[new Random().nextInt(nricArray.length)] + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

			var tgCandidateResult = new TgCandidateResult();
			tgCandidateResult.setEmail("stb.testuser@wizvision.com");
			tgCandidateResult.setName(username[i]);
			tgCandidateResult.setExamDate(LocalDate.of(2019, 8, 31));
			tgCandidateResult.setGuidingLanguage(cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE).get(0));
			tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
			tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
			baseRepository.save(tgCandidateResult);

			Set<TgCandidateResult> results = new HashSet<>();
			results.add(tgCandidateResult);

			TgCandidate tgCandidate = new TgCandidate();
			tgCandidate.setUin(uin);
			tgCandidate.setTgCandidateResults(results);
			tgCandidate.setLastCandidateResult(tgCandidateResult);
			baseRepository.save(tgCandidate);

			tgCandidateResult.setTgCandidate(tgCandidate);

			User user = new User();
			user.setLoginId(uin);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName(username[i]);
			user.setEmailAddress("stb.testuser@wizvision.com");
			user.setTgCandidate(tgCandidate);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));
			baseRepository.save(user);

			TouristGuide tg = new TouristGuide();
			tg.setUin(uin);
			baseRepository.save(tg);
			user.setTouristGuide(tg);

			// licence
			Licence licence = new Licence();
			licence.setTouristGuide(tg);
			licence.setTaTgType(Codes.TaTgType.TG);
			licence.setTier(cache.getType(Codes.Types.TG_TIER_GENERAL));
			licence.setStartDate(tgCandidateResult.getExamDate());
			licence.setExpiryDate(LocalDate.of(2022, 8, 31));
			licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE);
			licence.setStatus(cache.getStatus(Codes.Statuses.TG_ACTIVE));
			baseRepository.save(licence);

			// random DOB
			SecureRandom r = new SecureRandom();
			int ranYear = r.nextInt(28) + 1990;
			int ranMonth = r.nextInt(12) + 1;
			int ranDate = r.nextInt(28) + 1;
			tg.setDob(LocalDate.of(ranYear, ranMonth, ranDate));

			Set<Type> guidingLanguages = new HashSet<>();
			Set<Type> specializedAreas = new HashSet<>();

			tg.setSex(cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
			tg.setUser(user);
			tg.setLicence(licence);
			tg.setName(username[i]);
			tg.setBirthCountry(cache.getTypesByCategory(Codes.TypeCategories.COUNTRY).get(0));
			tg.setHighestEduLevel(cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_LEVEL).get(0));
			tg.setMaritalStatus(cache.getTypesByCategory(Codes.TypeCategories.MARITAL_STATUS).get(0));
			tg.setNationality(cache.getTypesByCategory(Codes.TypeCategories.NATIONALITY).get(0));
			tg.setRace(cache.getTypesByCategory(Codes.TypeCategories.RACE).get(0));
			tg.setResidentialStatus(cache.getTypesByCategory(Codes.TypeCategories.RESIDENTIAL_STATUS).get(0));
			tg.setSalutation(cache.getTypesByCategory(Codes.TypeCategories.SALUTATION).get(0));
			tg.setSex(cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
			tg.setMobileNo("8" + RandomStringUtils.randomNumeric(7));
			tg.setEmailAddress(user.getEmailAddress());
			tg.setHasConsentMobileNo(true);
			tg.setHasConsentEmailAddress(true);
			tg.setPhoto(file);
			tg.setEmployerName("Chan Brother Pte Ltd");
			tg.setWorkPassType(cache.getTypesByCategory(Codes.TypeCategories.WORK_PASS_TYPE).get(0));

			guidingLanguages.add(tgCandidateResult.getGuidingLanguage());
			specializedAreas.add(tgCandidateResult.getSpecializedArea());

			tg.setGuidingLanguages(guidingLanguages);
			tg.setSpecializedAreas(specializedAreas);

			// registered address
			Address registered = new Address();
			registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			registered.setPostal("381050");
			registered.setPremiseType(cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE).get(0));
			registered.setStreet("SIMS DRIVE");
			registered.setBuilding("SIMS VISTA");
			registered.setBlock("50A");
			registered.setFloor(RandomStringUtils.randomNumeric(2));
			registered.setUnit(RandomStringUtils.randomNumeric(2));
			tg.setRegisteredAddress(registered);
			tg.setMailingAddress(registered);

			baseRepository.save(tg.getRegisteredAddress());
			baseRepository.save(tg.getMailingAddress());

			WorkflowAction workflowAction = new WorkflowAction();
			workflowAction.setStatus(cache.getStatus(Codes.Statuses.TG_APP_APPROVED));
			workflowAction.setPrevStatus(cache.getStatus(Codes.Statuses.TG_APP_PENDING_PO));
			baseRepository.save(workflowAction);

			Application application = new Application();
			application.setTaTgType(Codes.TaTgType.TG);
			application.setLastAction(workflowAction);
			application.setType(cache.getType(appCodeArray[new Random().nextInt(appCodeArray.length)]));
			application.setSubmissionDate(LocalDateTime.now());
			application.setIsDraft(false);
			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));
			application.setLicence(licence);
			baseRepository.save(application);

			workflowAction.setApplication(application);
			baseRepository.update(workflowAction);

			TgLicenceCreation tlc = new TgLicenceCreation();
			tlc.setDob(LocalDate.of(1988, 01, 01));
			tlc.setEmailAddress(tg.getEmailAddress());
			tlc.setEmployerName(tg.getEmployerName());// RandomStringUtils.randomNumeric(10) + RandomStringUtils.randomAlphabetic(1).toUpperCase() + "Pte Ltd");
			tlc.setHasConsentEmailAddress(true);
			tlc.setHasConsentMobileNo(true);
			tlc.setMobileNo(tg.getMobileNo());// RandomStringUtils.randomNumeric(8));
			tlc.setName(tg.getName());
			tlc.setOccupation(tg.getOccupation());// cache.getTypesByCategory(Codes.TypeCategories.OCCUPATIONS).get(0));
			tlc.setUin(tg.getUin());
			tlc.setApplication(application);
			tlc.setBirthCountry(tg.getBirthCountry());// cache.getTypesByCategory(Codes.TypeCategories.COUNTRY).get(0));
			tlc.setHighestEduLevel(tg.getHighestEduLevel());// cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_LEVEL).get(0));
			tlc.setMaritalStatus(tg.getMaritalStatus());// cache.getTypesByCategory(Codes.TypeCategories.MARITAL_STATUS).get(0));
			tlc.setNationality(tg.getNationality());// cache.getTypesByCategory(Codes.TypeCategories.NATIONALITY).get(0));
			tlc.setOperatingAddress(tg.getMailingAddress());// opAddr);
			tlc.setRace(tg.getRace());// cache.getTypesByCategory(Codes.TypeCategories.RACE).get(0));
			tlc.setRegisteredAddress(tg.getRegisteredAddress());// regAdd);
			tlc.setResidentialStatus(tg.getResidentialStatus());// cache.getTypesByCategory(Codes.TypeCategories.RESIDENTIAL_STATUS).get(0));
			tlc.setSalutation(tg.getSalutation());// cache.getTypesByCategory(Codes.TypeCategories.SALUTATION).get(0));
			tlc.setSex(tg.getSex());// cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
			tlc.setUser(tg.getUser());
			tlc.setWorkPassType(tg.getWorkPassType());// cache.getType("TG_TIER_G"));
			baseRepository.save(tlc);
		}

		return 20 + " applications created";
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-tg-renewal-test-data/{number}
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-renewal-test-data/{number}")
	public String createTgRenewalTestData(@PathVariable Integer number, HttpServletRequest request, HttpServletResponse response) {
		init();
		addAuthentication(request, response, "stb_tzeserno", null);
		gov.stb.tag.model.File file = testRepository.getFirstPassportPhoto().getFile();

		TgCourse mrc = testRepository.getTgMrc();
		List<TgCourse> pdcs = testRepository.getTgPdc();
		List<TgCourseAttendance> attendances = new ArrayList<TgCourseAttendance>();
		attendances.add(createTgCourseAttendance(mrc));
		attendances.add(createTgCourseAttendance(pdcs.get(0)));
		attendances.add(createTgCourseAttendance(pdcs.get(1)));
		attendances.add(createTgCourseAttendance(pdcs.get(2)));

		for (int i = 0; i < number; i++) {
			int engIdx = new Random().nextInt(englishName.length);
			int surIdx = new Random().nextInt(surname.length);
			String name = englishName[engIdx] + " " + surname[surIdx];

			initRenewalTestData(name, file, attendances);
		}

		return msg.toString();
	}

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-tg-reinstate-test-data/{number}
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-reinstate-test-data/{number}")
	public String createTgReinstateTestData(@PathVariable Integer number, HttpServletRequest request, HttpServletResponse response) {
		init();
		addAuthentication(request, response, "stb_tzeserno", null);
		gov.stb.tag.model.File file = testRepository.getFirstPassportPhoto().getFile();

		TgCourse mrc = testRepository.getTgMrc();
		List<TgCourse> pdcs = testRepository.getTgPdc();
		List<TgCourseAttendance> attendances = new ArrayList<TgCourseAttendance>();
		attendances.add(createTgCourseAttendance(mrc));
		attendances.add(createTgCourseAttendance(pdcs.get(0)));
		attendances.add(createTgCourseAttendance(pdcs.get(1)));
		attendances.add(createTgCourseAttendance(pdcs.get(2)));

		for (int i = 0; i < number; i++) {
			int engIdx = new Random().nextInt(englishName.length);
			int surIdx = new Random().nextInt(surname.length);
			String name = englishName[engIdx] + " " + surname[surIdx];

			initReinstateTestData(name, file, attendances);
		}

		return msg.toString();
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
	 * Training Provider
	 */

	// http://localhost:9191/webservice-admin/api/v1/uat-test/create-tp-user
	@RequestMapping(method = RequestMethod.GET, value = "/create-tp-user")
	public String createTpLicence() {
		List<String> uenList = new ArrayList<>();
		String[] nameList = new String[] { "Heidy", "Rowena", "Vertie", "Rosette", "Babara" };
		for (int i = 0; i < 5; i++) {
			TgTrainingProvider tp = new TgTrainingProvider();
			String uen = "S" + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();
			uenList.add(uen);
			tp.setUen(uen);
			tp.setName(nameList[i]);
			tp.setStatus(cache.getStatus("USER_A"));
			tp.setIsPdc(true);
			tp.setIsMrc(true);
			tgTrainingProviderRepository.save(tp);

			User user = new User();
			user.setLoginId(uen);
			user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
			user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
			user.setName(nameList[i]);
			user.setEmailAddress(uen + "@wizvision-tag.com");
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.setRoles(Sets.newHashSet());
			user.getRoles().add(cache.getRole(Codes.Roles.TP_PUBLIC));
			user.setTgTrainingProvider(tp);
			baseRepository.save(user);
		}
		return "TP licences created successfully. NRIC/FIN : " + StringUtils.join(uenList, ", ");
	}

	// http://localhost:9191/webservice-admin/api/v1/uat-test/create-mrc
	@RequestMapping(method = RequestMethod.GET, value = "/create-mrc")
	public String createMRC() {
		List<TgTrainingProvider> tps = tgTrainingProviderRepository.getTrainingProviders();
		for (int i = 0; i < 5; i++) {
			TgCourse tc = new TgCourse();
			tc.setCode(RandomStringUtils.randomAlphabetic(4).toUpperCase());
			tc.setName("MRC");
			// tc.setCategory(null);
			tc.setLanguage(cache.getType("TG_LANG_ENG"));
			tc.setType(cache.getType("TP_CSE_M"));
			tc.setApprovedStartDate(LocalDate.of(2019, 1, 1));
			tc.setApprovedEndDate(LocalDate.of(2019, 12, 31));
			// tc.setNoOfHours(new BigDecimal(7.0));
			tc.setTgTrainingProvider(tps.get(i));
			tgCourseRepository.save(tc);
		}
		return "MRC created for each TP";
	}

	// http://localhost:9191/webservice-admin/api/v1/uat-test/create-pdc
	@RequestMapping(method = RequestMethod.GET, value = "/create-pdc")
	public String createPDC() {
		String[] courseNameList = new String[] { "Development of Housing in Singapore", "Port of Singapore", "Singapore’s Urban Planning" };
		List<TgTrainingProvider> tps = tgTrainingProviderRepository.getTrainingProviders();
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 3; j++) {
				TgCourse tc = new TgCourse();
				tc.setCode(RandomStringUtils.randomAlphabetic(4).toUpperCase());
				tc.setName(courseNameList[j]);
				// tc.setCategory(null);
				tc.setLanguage(cache.getType("TG_LANG_ENG"));
				tc.setType(cache.getType("TP_CSE_P"));
				tc.setApprovedStartDate(LocalDate.of(2019, 1, 1));
				tc.setApprovedEndDate(LocalDate.of(2019, 12, 31));
				tc.setNoOfHours(new BigDecimal(7.0));
				tc.setTgTrainingProvider(tps.get(i));
				tgCourseRepository.save(tc);
			}
		}
		return "PDC created for each TP";
	}

	// http://localhost:9191/webservice-admin/api/v1/uat-test/create-mlpt-registrations/{mlptId}
	@RequestMapping(method = RequestMethod.GET, value = "/create-mlpt-registrations/{mlptId}")
	public String createMlptRegistrations(@PathVariable Integer mlptId) {
		Integer noOfRegistration = 30;
		String[] languages = { "TG_LANG_ENG", "TG_LANG_MAN" };

		List<TouristGuide> touristGuides = testRepository.getActiveTouristGuides();
		for (int i = 0; i < noOfRegistration; i++) {
			TouristGuide touristGuide = touristGuides.get(i);
			Boolean hasRegistered = false;
			TgLicenceMlptRegistration registration = null;

			for (int j = 0; j < languages.length; j++) {
				Type newLanguage = cache.getType(languages[j]);

				if (!isCurrLanguage(newLanguage, touristGuide.getGuidingLanguages())) {
					if (!hasRegistered) {
						Application application = new Application();
						application.setIsDraft(false);
						application.setSubmissionDate(LocalDateTime.now());
						application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
						application.setTaTgType(Codes.TaTgType.TG);
						application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION));
						application.setLicence(touristGuide.getLicence());
						baseRepository.save(application);

						registration = new TgLicenceMlptRegistration();
						registration.setTgMlpt(baseRepository.get(TgMlpt.class, mlptId));
						registration.setApplication(application);
						baseRepository.save(registration);

						hasRegistered = true;
					}

					TgMlptSlot slot = new TgMlptSlot();
					slot.setTgLicenceMlptRegistration(registration);
					slot.setGuidingLanguage(cache.getType(languages[j]));
					baseRepository.save(slot);
					appendLn(touristGuide.getName() + " - " + slot.getGuidingLanguage().getLabel());
				}
			}
		}
		return msg.toString();
	}

	// http://localhost:9191/webservice-admin/api/v1/uat-test/create-ips
	@RequestMapping(method = RequestMethod.GET, value = "/create-ips")
	public String createIps() {
		String msg = "";

		for (int i = 0; i < 5; i++) {
			msg += createTgIp();
			msg += createTaIp();
		}

		return msg;
	}

	// http://localhost:9191/webservice-admin/api/v1/uat-test/create-tg-ip
	@RequestMapping(method = RequestMethod.GET, value = "/create-tg-ip")
	public String createTgIp() {
		CeCase ceCase = new CeCase();
		ceCase.setIsIp(false);
		ceCase.setTaTgType("TG");

		CeCase ceIp = new CeCase();
		ceIp.setIsIp(true);
		ceIp.setTaTgType("TG");
		ceIp.setTaggedCase(ceCase);
		ceIp.setStatus(cache.getStatus("CE_CASE_LIVE"));
		ceIp.setOic(userRepository.getUserByLoginId("stb_chenkeongl"));

		CeCaseComplainant complainant = new CeCaseComplainant();
		complainant.setCeCase(ceIp);

		User user = userRepository.getUserByLoginId("stb_asrulfahmir");
		complainant.setName(user.getName());
		complainant.setIdType(cache.getType("CE_ID_TYPE_ENTITY"));
		complainant.setType(cache.getType("CE_COMPLAINANT_STB"));

		CeCaseInfringement infringement = new CeCaseInfringement();
		CeCaseInfringer infringer = new CeCaseInfringer();
		Licence licence = new Licence();

		infringement.setCeCase(ceIp);
		infringement.setCeOriginatingCase(ceCase);
		infringement.setInfringedDate(LocalDateTime.now().minusDays(10));

		infringement.setCeCaseInfringer(infringer);
		infringer.setName("Lee Yew Chong");
		infringer.setUenUin("S1234556A");
		infringer.setIdType(cache.getType("CE_ID_TYPE_INDIVIDUAL"));
		infringer.setLicence(licence);
		infringer.setAgeGroup(cache.getType("TG_AGE_GROUP_41_TO_50"));
		infringer.setNationality(cache.getType("NAT_SG"));
		infringer.setGuidingLanguageProvided(cache.getType("TG_LANG_ENG"));

		licence.setTaTgType("TG");

		infringement.setCeProvision(ceProvisionRepository.getCeProvisionBySection("S19B(1)(a)"));

		testRepository.save(ceCase);
		testRepository.save(ceIp);
		testRepository.save(infringement);
		testRepository.save(infringer);
		testRepository.save(licence);
		testRepository.save(complainant);

		return "IP " + ceIp.getId() + " created";
	}

	// http://localhost:9191/webservice-admin/api/v1/uat-test/create-ta-ip
	@RequestMapping(method = RequestMethod.GET, value = "/create-ta-ip")
	public String createTaIp() {
		CeCase ceCase = new CeCase();
		ceCase.setIsIp(false);
		ceCase.setTaTgType("TA");

		CeCase ceIp = new CeCase();
		ceIp.setIsIp(true);
		ceIp.setTaTgType("TA");
		ceIp.setTaggedCase(ceCase);
		ceIp.setStatus(cache.getStatus("CE_CASE_LIVE"));
		ceIp.setOic(userRepository.getUserByLoginId("stb_baharudeena"));

		CeCaseInfringement infringement = new CeCaseInfringement();
		CeCaseInfringer infringer = new CeCaseInfringer();
		Licence licence = new Licence();

		infringement.setCeCase(ceIp);
		infringement.setCeOriginatingCase(ceCase);
		infringement.setInfringedDate(LocalDateTime.now().minusDays(10));

		infringement.setCeCaseInfringer(infringer);
		infringer.setName("ABC Pte Ltd");
		infringer.setUenUin("152201459");
		infringer.setIdType(cache.getType("CE_ID_TYPE_ENTITY"));
		infringer.setLicence(licence);

		licence.setTaTgType("TA");

		infringement.setCeProvision(ceProvisionRepository.getCeProvisionBySection("S6(1)"));

		testRepository.save(ceCase);
		testRepository.save(ceIp);
		testRepository.save(infringement);
		testRepository.save(infringer);
		testRepository.save(licence);

		return "IP " + ceIp.getId() + " created";
	}

	private boolean isCurrLanguage(Type newLanguage, Set<Type> currLanguages) {
		for (Type currLanguage : currLanguages) {
			if (currLanguage.equals(newLanguage)) {
				return true;
			}
		}
		return false;
	}

	/***************************** Bulletin *********************************************/
	@RequestMapping(method = RequestMethod.GET, value = "/create-bulletins/{type}/{isPrivate}")
	public String createBulletin(@PathVariable String type, @PathVariable Boolean isPrivate) {

		Map<String, String> titleList = new HashMap<String, String>();
		titleList.put("SS Scuba Convicted For Unlicenced Travel Agent Activities",
				"The Singapore Tourism Board (STB) would like to inform the public that SS Scuba Pte Ltd has been convicted in the State Courts on 28 November 2018 for carrying on the business of a travel agent without a valid travel agent licence in contravention of Section 6(1) of the Travel Agents Act (Chapter 334) SS Scuba faced 50 charges and was convicted and sentenced on 10 charges. The company was ordered to pay a total fine of S$14 000 The remaining 40 charges were taken into consideration in the sentencing.<br><br>\r\n"
						+ "SS Scuba's travel agent licence ceased in March 2014 Investigations revealed that despite not having a valid travel agent licence, SS Scuba continued to operate by selling and arranging trips to various overseas destinations from January 2015 to July 2016<br><br>\r\n"
						+ "STB takes a serious view against unlicensed travel agents and is committed to uphold the reputation of Singapore's tourism sector, and will not hesitate to take necessary action against those who contravened the legislation.<br><br>\r\n"
						+ "Under Section 6 of the pre-amended Travel Agents Act, which this case falls under. any person found guilty of carrying on the business of a travel agent without a valid travel agent licence faces a maximum fine of S$10.000 and/or imprisonment of up to two years. Under the amended Travel Agents Act that took effect on 1 January 2018, commission of the same offence now will carry a higher maximum fine of $25,000 and/or imprisonment of up to two years.<br><br>\r\n"
						+ "The public is advised to exercise due diligence when making travel arrangements For the latest list of licensed travel agents in Singapore. please visit the Travel Related Users System (TRUST) website,\r\n"
						+ "<a href=\"https://trust.yoursingapore.com\" target=\"blank_\"><span class=\"link_url\">https://trust.yoursingapore.com</span></a>. Travel agents may also emai the STB at <span class=\"link_url\">stb_ta@stb.gov.sg</span> for related licensing queries.");
		titleList.put("2016 Chinese New Year Light Up",
				"Organised by the Kreta Ayer-Kim Seng Citizens' Consultative Committee, this year's Chinese New Year Celebrations at Chinatown is themed \"Year of Prosperity & Success, 桃满花香牛车水, 灵猴迎春贺新岁\". From 16 January to 8 March 2016, this predominantly Chinese enclave will spring to life with 2,668 handcrafted lanterns in the shape of monkeys, peaches, spring blossoms and gold zodiac coins – the most number of customised lanterns to be produced for the street light-up. In partnership with the Singapore University of Technology and Design for the fifth time, the light-up will also feature 28 mechanical monkey lanterns. Other events include a festive bazaar, the Chinatown Chinese New Year Walking Trail, 9th International Lion Dance Competition, and Chinatown Chinese New Year Countdown Party. For more information, please visit&nbsp;<a href=\"http://www.chinatownfestivals.sg/\">www.chinatownfestivals.sg</a>.");
		titleList.put("STB & Spotify get people grooving to the Beats of Singapore",
				"The Singapore Tourism Board (STB) and Spotify, the world's most popular music streaming subscription service, have jointly rolled out.");
		titleList.put("STB's multi-year partnership with 50 Best brand",
				"The Singapore Tourism Board (STB) and William Reed Business Media (WRBM), owner of the acclaimed 50 Best brand, have entered into.");
		titleList.put("Vertical Line Pte Ltd - Revocation Of Travel Agent Licence",
				"The Singapore Tourism Board (STB) would like to inform the public that Vertical Line Pte Ltd (Vertical Line) [travel agent licence number.");
		titleList.put("Revocation Of Travel Agent Licence: Baba Travel",
				"The Singapore Tourism Board would like to inform the public that the Travel Agent licence of Baba Travel (TA Licence 01409) will be.");

		titleList.entrySet().forEach(o -> {
			Bulletin item = new Bulletin();
			item.setType(cache.getType(type));
			item.setTitle(o.getKey());
			item.setContent(o.getValue());
			item.setEffectiveDate(LocalDate.now());
			item.setExpiryDate(LocalDate.now().plusYears(1));
			if (isPrivate) {
				item.setPrivate(Boolean.TRUE);
			} else {
				item.setPrivate(Boolean.FALSE);
			}

			baseRepository.save(item);

		});

		return "6 Bulletins successfully created ";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/bulletin", consumes = { "multipart/form-data" })
	public String patchBulletin(@RequestParam(name = "file", required = false) MultipartFile[] multipartFiles, @RequestParam("effectiveDate") String effectiveDate,
			@RequestParam("typeCode") String typeCode, @RequestPart("content") String content, @RequestParam("title") String title, @RequestParam("isPrivate") Boolean isPrivate,
			@RequestParam("expiryDate") String expiryDate) {

		Set<File> files = new HashSet<File>();
		for (MultipartFile multipartFile : multipartFiles) {
			files.add(fileHelper.saveFile("BULLETIN_DOC", multipartFile, false));
		}

		Bulletin bulletin = new Bulletin();
		bulletin.setContent(content);
		bulletin.setEffectiveDate(DateUtil.parseDate(effectiveDate));
		bulletin.setTitle(title);
		bulletin.setType(cache.getType(typeCode));
		bulletin.setPrivate(isPrivate);
		bulletin.setFiles(files);
		bulletin.setExpiryDate(DateUtil.parseDate(expiryDate));
		baseRepository.save(bulletin);

		return "bulletin inserted successfully.";
	}

	/***************************** END Bulletin *********************************************/

	// Only for performance test
	@RequestMapping(value = "/public/auto-complete-payment-process", method = { RequestMethod.GET, RequestMethod.POST })
	public void autoCompletePaymentProcess(HttpServletRequest request) throws NoSuchAlgorithmException {
		paymentHelper.autoCompletePaymentProcess(request);
	}

	private void addAuthentication(HttpServletRequest request, HttpServletResponse response, String loginId, String roleCode) {
		User u = userRepository.getUserByLoginId(loginId);
		User user = userRepository.getUserWithRoleAndFunctions(u.getId());

		if (roleCode != null) {
			Role role = UserHelper.getRole(user.getRoles(), roleCode);
			user.setDefaultRole(role);
		}

		TokenAuthenticationService.addAuthentication(request, response, user);
	}
}
