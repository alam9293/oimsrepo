package gov.stb.tag.controllers;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.wiz.security.TokenAuthenticationService;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.auth.AuthPubRequestDto;
import gov.stb.tag.dto.auth.AuthRequestDto;
import gov.stb.tag.dto.auth.AuthResponseDto;
import gov.stb.tag.dto.auth.AuthUserDto;
import gov.stb.tag.dto.dashboard.RoleFunctionItemDto;
import gov.stb.tag.dto.dashboard.UserProfileItemDto;
import gov.stb.tag.dto.dashboard.UserProfileSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PasswordHelper;
import gov.stb.tag.helper.QlikSenseHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Function;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.repository.tg.TgCandidateRepository;
import gov.stb.tag.repository.tg.TgTrainingProviderRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.CsvUtil;
import gov.stb.tag.util.PasswordUtil;

@RestController
@RequestMapping(path = "/api/v1/users")
@Transactional
public class UserController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private static final String SECRET = "ThisIsASecret123";
	private static final Integer DAYS_TO_PW_EXPIRY = 365;
	private static final Integer MAX_LOGIN_COUNT = 10;
	private static final Integer MS_DELAY_PER_COUNT = 1000;

	@Autowired
	UserRepository userRepository;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	PasswordHelper passwordHelper;
	@Autowired
	UserHelper userHelper;
	@Autowired
	QlikSenseHelper qlikSenseHelper;
	@Autowired
	TouristGuideRepository touristGuideRepository;
	@Autowired
	TgCandidateRepository tgCandidateRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TgTrainingProviderRepository tgTrainingProviderRepository;

	protected static final String[] ContentHeaders_User = new String[] { "Login Id", "Name", "Email Address", "Assigned Chars", "Department", "Roles Code", "Status" };

	// portal login / admin login
	@RequestMapping(method = RequestMethod.POST, value = "/authenticate/{type}")
	public AuthResponseDto authenticate(@Validated @RequestBody AuthRequestDto dto, @PathVariable String type, HttpServletRequest request, HttpServletResponse response) {
		Boolean byPassIams = !properties.iamsSsoEnabled;
		String userType = "admin".equals(type) ? Codes.UserTypes.USER_STB : "portal".equals(type) ? Codes.UserTypes.USER_PUBLIC_PORTAL : Codes.UserTypes.USER_PUBLIC;

		// throw exception for admin login when byPassIams flag is false
		if (Codes.UserTypes.USER_STB.equals(userType) && !byPassIams) {
			throw new InsufficientAuthenticationException(Messages.Errors.AUTH_NO_SSO_HEADER);
		}

		User user = userRepository.getUserWithValidLoginCredential(dto.getLoginId(), dto.getUen(), userType);
		return login(dto, userType, user, request, response, null, null, null);
	}

	// only to be called by server-to-server logic via APEX
	@RequestMapping(method = RequestMethod.POST, value = "/authenticate-spcp/{loginId}/{uen}/{dashboardTypeCode}")
	public AuthResponseDto authenticateSpCp(@RequestBody AuthPubRequestDto authPubRequestDto, @PathVariable String loginId, @PathVariable String uen, @PathVariable String dashboardTypeCode,
			HttpServletRequest request, HttpServletResponse response) {
		if (Strings.isNullOrEmpty(authPubRequestDto.getAuthSecret()) || !authPubRequestDto.getAuthSecret().equals(SECRET)) {
			throw new InsufficientAuthenticationException(Messages.Errors.LOGIN_SECRET_MISMATCH);
		}

		User user = userRepository.getUserWithValidLoginCredential(loginId, uen);
		if (user != null && Entities.equals(user.getType(), Codes.UserTypes.USER_STB)) {
			throw new InsufficientAuthenticationException(Messages.Errors.LOGIN_NOT_PUB);
		}

		// create new user if not found
		Role role = null;
		if (Objects.isNull(user)) {
			if (uen.equals(Codes.SpCp.NO_UEN)) {
				throw new InsufficientAuthenticationException(Messages.Errors.AUTH_NOT_TG);
			} else {
				user = createNewUser(loginId, uen);
				role = user.getDefaultRole();
			}

		} else {
			role = assignRole(user, dashboardTypeCode, uen);
		}

		AuthRequestDto authRequestDto = new AuthRequestDto();
		authRequestDto.setLoginId(loginId);
		authRequestDto.setUen(uen);

		return login(authRequestDto, Codes.UserTypes.USER_PUBLIC, user, request, response, role, authPubRequestDto.getIamsIdToken(), authPubRequestDto.getSpIdToken());
	}

	// admin IAMS SSO login
	@RequestMapping(method = RequestMethod.GET, value = "/authenticate-sso")
	public AuthResponseDto authenticateSso(HttpServletRequest request, HttpServletResponse response) {
		User user = null;
		AuthRequestDto dto = new AuthRequestDto();
		String ssoUserName = request.getHeader(Codes.Headers.STBSSO_USERNAME);

		// TODO: to remove
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = headerNames.nextElement();
			String value = request.getHeader(key);
			logger.info("authenticateSso() - headerName: {}, value: {}", key, value);
		}

		if (!Strings.isNullOrEmpty(ssoUserName)) {
			logger.info("authenticateSso() - Authenticating user with ssoUserName:{}", ssoUserName);
			// proceed to use header stbsso_user_name to search for user in db and login
			dto.setLoginId(ssoUserName);
			user = userRepository.getUserWithValidLoginCredential(ssoUserName, null);
		} else {
			logger.error("authenticateSso() - IAMS SSO header not found");
			return new AuthResponseDto(false, Codes.AuthenticationResponse.SSO_HEADER_NOT_FOUND, Messages.Errors.AUTH_NO_SSO_HEADER, null);
		}

		return login(dto, Codes.UserTypes.USER_STB, user, request, response, null, null, null);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/retrieve-current-login-iamsIdToken-and-logout")
	public String getIamsIdTokenAndLogout() {
		setInAuthenticated();
		String iamsIdToken = getIamsIdToken();
		if (iamsIdToken == null) {
			return "";
		} else {
			return iamsIdToken;
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "/retrieve-current-login-spIdToken")
	public String getIamsCurrentLoginIdToken() {
		String spIdToken = getSpIdToken();
		if (spIdToken == null) {
			return "";
		} else {
			return spIdToken;
		}
	}

	// qliksense login
	@RequestMapping(method = RequestMethod.GET, value = "/login-qliksense")
	public String loginQlikSense() {
		User user = getUser();
		if (user != null) {
			try {
				return qlikSenseHelper.getQlikTicketedUrl(user.getLoginId());
			} catch (IOException e) {
				logger.error(e.getMessage());
			}
		}
		return properties.qsUrl;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/retrieve-current-login-userid")
	public String getCurrentLoginUserId() {
		User user = getUser();
		if (user == null) {
			return "";
		} else {
			return user.getLoginId() + "," + user.getUen();
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "/current")
	public AuthUserDto getCurrentUser() {
		Role selectedRole = userRepository.getRoleWithFunctions(getSelectedRoleCode());
		AuthUserDto authUserDto = AuthUserDto.buildFromUser(cache, userRepository.getUserWithRoleAndFunctions(getUser().getId()), selectedRole);

		return authUserDto;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/current/extend-session")
	public void extendCurrentSession() {
		logger.info("Session extended for user " + getUser().getName());
	}

	private AuthResponseDto login(AuthRequestDto authRequestDto, String userType, User user, HttpServletRequest request, HttpServletResponse response, Role role, String iamsTokenId,
			String spTokenId) {
		String userInfo = userType + ", " + authRequestDto.getLoginId() + (Strings.isNullOrEmpty(authRequestDto.getUen()) ? "" : ", " + authRequestDto.getUen()).replaceAll("[\r\n]", "");
		Boolean byPassIams = !properties.iamsSsoEnabled;

		if (user == null) {
			// for loginId/uen mismatch, user type mismatch, user who don't have access, or SingPass user who is neither TG nor TG Candidate
			logger.info("No access for user: {}", userInfo);
			return new AuthResponseDto(false, Codes.AuthenticationResponse.USER_NO_ACCESS, Messages.Errors.LOGIN_NO_ACCESS, null);

		} else if (!Entities.equals(user.getStatus(), Codes.Statuses.USER_ACTIVE)) {
			// for user with non-active status
			logger.info("Non-active status for user: {}", userInfo);
			return new AuthResponseDto(false, Codes.AuthenticationResponse.USER_NO_ACCESS, Messages.Errors.LOGIN_NO_ACCESS, null);

		} else if (Codes.UserTypes.USER_STB.equals(userType) && byPassIams) {
			// require password validation for public portal ID && STB Admin
			if (Strings.isNullOrEmpty(user.getPassword()) || Strings.isNullOrEmpty(user.getSalt())) {
				// for user with null password or salt, possibly due to data issue
				logger.info("Empty password or salt for user: {}", userInfo);
				return new AuthResponseDto(false, Codes.AuthenticationResponse.PASSWORD_INCORRECT, Messages.Errors.LOGIN_PASSWORD_INCORRECT, null);

			} else if (!PasswordUtil.doPasswordsMatch(user.getPassword(), authRequestDto.getPassword(), user.getSalt())) {
				// for user password mismatch
				logger.info("Incorrect loginId or password for user: {}", userInfo);
				processFailLoginCount(userInfo, user);
				return new AuthResponseDto(false, Codes.AuthenticationResponse.PASSWORD_INCORRECT, Messages.Errors.LOGIN_PASSWORD_INCORRECT, null);
			}
		}

		logger.info("User authenticated: {}", userInfo);

		// if (Entities.equals(user.getType(), Codes.UserTypes.USER_PUBLIC_PORTAL)) {
		// user.setIsToChangePassword(userRepository.isToChangePassword(user.getId(), DAYS_TO_PW_EXPIRY));
		// }
		user.setLoginCount(null);
		user.setLastLoginDate(LocalDateTime.now());
		user.setIamsTokenId(iamsTokenId);
		user.setSpTokenId(spTokenId);
		userRepository.saveOrUpdate(user);

		TokenAuthenticationService.addAuthentication(request, response, user, role);
		AuthUserDto authUserDetails = AuthUserDto.buildFromUser(cache, user, role);
		String reason = Codes.UserTypes.USER_STB.equals(userType) && !byPassIams ? "IAMS SSO header verified." : "Password verified.";

		return new AuthResponseDto(true, Codes.AuthenticationResponse.AUTHENTICATED, reason, authUserDetails);
	}

	private void processFailLoginCount(String userInfo, User user) {
		Integer loginCount = user.getLoginCount() != null ? user.getLoginCount() : 0;
		loginCount++;
		if (loginCount > 1) {
			int delay = (loginCount - 1) * MS_DELAY_PER_COUNT;
			logger.info("Failed login count: {}. Delaying response: {} MS", loginCount, delay);
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
		}
		user.setLoginCount(loginCount);
		if (loginCount >= MAX_LOGIN_COUNT) {
			logger.info("Max. login attempts exceeded. User locked: {}", userInfo);
			user.setStatus(cache.getStatus(Codes.Statuses.USER_LOCKED));
		}
		userRepository.saveOrUpdate(user);
	}

	private User createNewUser(String loginId, String uen) {
		User user = null;
		if (uen.equals(Codes.SpCp.NO_UEN)) {
			// TouristGuide tg = tgRepository.getTouristGuideByUin(loginId);
			// if (Objects.isNull(tg)) {
			// // check tgCandidateResult
			// TgCandidate tgCdd = tgCddRepository.getTgCandidateByUin(loginId);
			// if (tgCdd != null) {
			// user = userHelper.createPublicUser(loginId, null, tgCdd.getLastCandidateResult().getName(), Lists.newArrayList(Codes.Roles.TG_CANDIDATE), null, null, tgCdd, null);
			// } else {
			// logger.info("SingPass user is authenticated but has no access to tag portal.");
			// }
			// } else {
			// user = userHelper.createPublicUser(loginId, null, tg.getName(), Lists.newArrayList(Codes.Roles.TG_PUBLIC), null, tg, null, null);
			// }
		} else {// has uen, create TA/TP public user
			TravelAgent ta = travelAgentRepository.getTaByUen(uen);
			if (Objects.isNull(ta)) {
				// check training provider
				TgTrainingProvider tp = tgTrainingProviderRepository.getTrainingProviderByUen(uen);
				if (tp != null) {
					user = userHelper.createPublicUser(loginId, uen, tp.getName(), userRepository.getRoleWithFunctions(Codes.Roles.TP_PUBLIC), null, null, null, tp);
				} else {
					user = userHelper.createPublicUser(loginId, uen, null, userRepository.getRoleWithFunctions(Codes.Roles.TA_CANDIDATE), null, null, null, null);
				}
			} else {
				user = userHelper.createPublicUser(loginId, uen, null, userRepository.getRoleWithFunctions(Codes.Roles.TA_PUBLIC), ta, null, null, null);
			}
		}
		if (user != null) {
			userRepository.save(user);
		}
		return user;
	}

	private Role assignRole(User user, String dashboardTypeCode, String uen) {
		Role role = null;
		if (dashboardTypeCode.equals("TACDD")) {

			// check if logged in user is TA. if is already TA, login as TA
			// else check if TA CDD role already exist. if not exist, add CDD role
			// login as TA CDD
			if (!user.getRoles().contains(cache.getRole(Codes.Roles.TA_PUBLIC))) {
				if (!user.getRoles().contains(cache.getRole(Codes.Roles.TA_CANDIDATE))) {
					user.getRoles().add(userRepository.getRoleWithFunctions(Codes.Roles.TA_CANDIDATE));
				}
				role = userRepository.getRoleWithFunctions(Codes.Roles.TA_CANDIDATE);
			} else {
				role = userRepository.getRoleWithFunctions(Codes.Roles.TA_PUBLIC);
			}

		} else if (dashboardTypeCode.equals("TA")) {

			// Check if role has TA
			// If do not have, check if it is valid TA
			// If not valid TA, throw exception

			if (user.getRoles().contains(cache.getRole(Codes.Roles.TA_PUBLIC))) {
				role = userRepository.getRoleWithFunctions(Codes.Roles.TA_PUBLIC);
			} else {
				TravelAgent ta = travelAgentRepository.getTaByUen(uen);
				if (!Objects.isNull(ta)) {
					user.getRoles().add(userRepository.getRoleWithFunctions(Codes.Roles.TA_PUBLIC));
					user.setTravelAgent(ta);
					role = userRepository.getRoleWithFunctions(Codes.Roles.TA_PUBLIC);
				} else {
					throw new ValidationException("User is not a valid TA. Please apply for a Travel Agent Licence instead");
				}

			}
		} else if (dashboardTypeCode.equals("TP")) {

			// Check if role has TP
			// If do not have, check if it is valid TP
			// If not valid TP, throw exception

			if (user.getRoles().contains(cache.getRole(Codes.Roles.TP_PUBLIC))) {
				role = userRepository.getRoleWithFunctions(Codes.Roles.TP_PUBLIC);
			} else {
				TgTrainingProvider tp = tgTrainingProviderRepository.getTrainingProviderByUen(uen);
				if (!Objects.isNull(tp)) {
					user.getRoles().add(userRepository.getRoleWithFunctions(Codes.Roles.TP_PUBLIC));
					user.setTgTrainingProvider(tp);
					user.setName(tp.getName());
					role = userRepository.getRoleWithFunctions(Codes.Roles.TP_PUBLIC);
				} else {
					throw new ValidationException("User is not a valid TP. Please contact STB Tourist Guide Licensing Team to access the system");
				}

			}
		} else if (dashboardTypeCode.equals("TG")) {
			// Check if role has TG CDD, then assign TG CDD
			// If do not have, check if it has TG
			// If not, throw exception

			if (user.getRoles().contains(cache.getRole(Codes.Roles.TG_CANDIDATE))) {
				role = userRepository.getRoleWithFunctions(Codes.Roles.TG_CANDIDATE);
			} else if (user.getRoles().contains(cache.getRole(Codes.Roles.TG_PUBLIC))) {
				role = userRepository.getRoleWithFunctions(Codes.Roles.TG_PUBLIC);
			} else {
				throw new ValidationException("User is not a valid TG or candidate");

			}

		}
		return role;
	}

	@RequestMapping(value = "/accounts/search", method = RequestMethod.GET)
	public ResultDto<UserProfileItemDto> getUsersList(UserProfileSearchDto searchDto) {
		buildTaAssigneeChars(searchDto);

		ResultDto<UserProfileItemDto> result = userRepository.getUsersList(searchDto, true);

		Object[] finalRecords = new Object[result.getRecords().length];
		var i = 0;
		for (Object obj : result.getRecords()) {
			User usr = (User) obj;
			var dto = UserProfileItemDto.setListOfUser(cache, usr);
			finalRecords[i] = dto;
			i++;
		}

		result.setRecords(finalRecords);
		return result;
	}

	private void buildTaAssigneeChars(UserProfileSearchDto searchDto) {
		if (!Strings.isNullOrEmpty(searchDto.getTaAssigneeChars())) {
			String chars = searchDto.getTaAssigneeChars().replace(" ", "").trim();
			List<String> charList = new ArrayList<>();
			for (int i = 0; i < chars.length(); i++) {
				charList.add(Character.toString(chars.charAt(i)));
			}
			searchDto.setAssigneeChars(charList);
		}
	}

	@RequestMapping(path = { "/accounts/view/{userId}" }, method = RequestMethod.GET)
	public UserProfileItemDto getUserDetail(@PathVariable Integer userId) {
		return populateDetail(userId);
	}

	private UserProfileItemDto populateDetail(Integer id) {
		User usr = userRepository.getUserWithRolesById(id);
		UserProfileItemDto dto = UserProfileItemDto.setListOfUser(cache, usr);

		return dto;
	}

	@RequestMapping(value = "/accounts/save", method = RequestMethod.POST)
	public Integer saveUser(@RequestBody UserProfileItemDto dto) {
		User usr = new User();

		if (dto.getId() != null) {
			usr = userRepository.getUserWithRolesById(dto.getId());

			usr = buildUser(usr, dto);
			userRepository.update(usr);
		}
		return usr.getId();
	}

	private User buildUser(User usr, UserProfileItemDto dto) {
		Set<Role> roles = new HashSet<>();

		for (String s : dto.getUserRoles()) {
			Role role = userRepository.getRole(s);
			roles.add(role);
		}
		usr.setRoles(roles);

		String chars = dto.getTaAssigneeChars().replace(" ", "");
		usr.setTaAssigneeChars(chars.replace("", " ").toUpperCase().trim());

		return usr;
	}

	@RequestMapping(value = "/access/search", method = RequestMethod.GET)
	public List<RoleFunctionItemDto> getUsersAccess(UserProfileSearchDto searchDto) {
		List<RoleFunctionItemDto> list = new ArrayList<>();

		buildRoleFunction(list, searchDto);

		return list;
	}

	private void buildRoleFunction(List<RoleFunctionItemDto> list, UserProfileSearchDto searchDto) {
		// 1. get all MOD function
		searchDto.setModuleList(new ArrayList<String>());
		if (!Strings.isNullOrEmpty(searchDto.getModule())) {
			searchDto.getModuleList().add(searchDto.getModule());
		} else {
			searchDto.setModuleList(Codes.Mod.MODLIST);
		}

		List<Function> functionList = userRepository.getModFunction(searchDto);

		// 2. get all Roles based on function
		for (Function f : functionList) {
			Boolean inList = false;
			RoleFunctionItemDto dto = new RoleFunctionItemDto();
			List<String> roleList = new ArrayList<String>();

			dto.setModuleCode(f.getModule().getCode());
			dto.setModuleLabel(f.getModule().getLabel());
			dto.setFunctionCode(f.getCode());
			dto.setFunctionLabel(f.getLabel());

			List<Role> roles = userRepository.getRolesByFunction(f.getCode());
			for (Role role : roles) {
				roleList.add(role.getCode());
				if (searchDto.getRoles() != null && searchDto.getRoles().length > 0) {
					for (Object s : searchDto.getRoles()) {
						if (s.equals(role.getCode())) {
							inList = true;
						}
					}
				} else {
					inList = true;
				}
			}

			if (inList == true || roles.isEmpty()) {
				dto.setRoles(roleList);
				list.add(dto);
			}

		}
	}

	@RequestMapping(value = "/access/save", method = RequestMethod.POST)
	public List<RoleFunctionItemDto> saveFunctionRole(@RequestPart(name = "list") List<RoleFunctionItemDto> list) {
		List<RoleFunctionItemDto> resultAdd = new ArrayList<>();
		List<RoleFunctionItemDto> resultRemove = new ArrayList<>();
		List<Role> allRole = userRepository.getAllRoles();
		List<Function> allFunction = cache.getFunctions();

		if (list != null) {
			for (RoleFunctionItemDto dto : list) {
				Function function = allFunction.stream().filter(f -> f.getCode() != null && f.getCode().contains(dto.getFunctionCode())).findAny().get();
				if (dto.getRoles() != null && !dto.getRoles().isEmpty()) {
					for (String roleCode : dto.getRoles()) {
						for (Role role : allRole) {
							if (role.getCode().equals(roleCode)) {
								buildAddRemoveList(resultAdd, role, function);
							} else {
								buildAddRemoveList(resultRemove, role, function);
							}
						}
					}
				} else {
					for (Role role : allRole) {
						buildAddRemoveList(resultRemove, role, function);
					}
				}
			}
		}

		saveAll(resultRemove, resultAdd);

		return list;
	}

	private void saveAll(List<RoleFunctionItemDto> resultRemove, List<RoleFunctionItemDto> resultAdd) {
		for (RoleFunctionItemDto t : resultRemove) {
			Role r = t.getRoleItem();
			r.getFunctions().remove(t.getFunctionItem());
			userRepository.update(r);
		}

		for (RoleFunctionItemDto t : resultAdd) {
			Role r = t.getRoleItem();
			r.getFunctions().add(t.getFunctionItem());
			userRepository.update(r);
		}
	}

	private void buildAddRemoveList(List<RoleFunctionItemDto> result, Role role, Function function) {
		RoleFunctionItemDto dto = new RoleFunctionItemDto();
		dto.setRoleItem(role);
		dto.setFunctionItem(function);
		result.add(dto);

	}

	@RequestMapping(value = "/accounts/export-list", method = RequestMethod.POST)
	public void exportUserAccountList(@RequestBody UserProfileSearchDto searchDto, HttpServletResponse response) throws IOException, ParseException {
		buildTaAssigneeChars(searchDto);
		ResultDto<UserProfileItemDto> result = userRepository.getUsersList(searchDto, false);
		List<String[]> contents = new ArrayList<>();
		var i = 0;
		for (Object obj : result.getRecords()) {
			User usr = (User) obj;
			var dto = UserProfileItemDto.setListOfUser(cache, usr);
			String[] content = new String[ContentHeaders_User.length];
			i = 0;
			content[i++] = dto.getLoginId();
			content[i++] = dto.getName();
			content[i++] = dto.getEmailAddress();
			content[i++] = dto.getTaAssigneeChars();
			content[i++] = dto.getDepartment();
			content[i++] = dto.getRole();
			content[i++] = dto.getStatus();
			contents.add(content);
		}
		CsvUtil.export(response, ContentHeaders_User, contents);
	}

	@RequestMapping(value = "/access/export-list", method = RequestMethod.POST)
	public void exportUserAccessList(@RequestBody UserProfileSearchDto searchDto, HttpServletResponse response) throws IOException, ParseException {
		List<Role> allRole = userRepository.getAllRoles();
		List<RoleFunctionItemDto> list = new ArrayList<>();
		List<String[]> contents = new ArrayList<>();
		buildRoleFunction(list, searchDto);

		int m = 2;
		int n = 0;
		String[] contentHeaders = new String[allRole.size() + m];
		String[] roleCode = new String[allRole.size()];
		contentHeaders[0] = "Module";
		contentHeaders[1] = "Function";

		for (Role r : allRole) {
			contentHeaders[m++] = r.getLabel();
			roleCode[n++] = r.getCode();
		}

		for (RoleFunctionItemDto dto : list) {
			String[] content = new String[contentHeaders.length];
			var i = 0;
			content[i++] = dto.getModuleLabel();
			content[i++] = dto.getFunctionLabel();

			for (String r : roleCode) {
				String con = "";
				for (String s : dto.getRoles()) {
					if (r.equals(s)) {
						con = "X";
					}
				}
				content[i++] = con;
			}
			contents.add(content);
		}
		CsvUtil.export(response, contentHeaders, contents);
	}
}