package gov.stb.tag.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.AssignDto;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.WorkflowFileSearchDto;
import gov.stb.tag.dto.dashboard.UserProfileDto;
import gov.stb.tag.dto.workflow.ReturnRoleDto;
import gov.stb.tag.dto.workflow.WorkflowConfigItemDto;
import gov.stb.tag.dto.workflow.WorkflowStepDto;
import gov.stb.tag.dto.workflow.WorkflowUserRoleDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowConfig;
import gov.stb.tag.model.WorkflowFile;
import gov.stb.tag.model.WorkflowStep;
import gov.stb.tag.model.WorkflowStepAssignment;
import gov.stb.tag.repository.BaseWorkflowHelperRepository;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.WorkflowRepository;

@RestController
@RequestMapping(path = "/api/v1/workflow")
@Transactional
public class WorkflowController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	BaseWorkflowHelperRepository baseWorkflowHelperRepository;

	@Autowired
	WorkflowRepository workflowRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	CommonRepository commonRepository;

	@Autowired
	CacheHelper cache;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	WorkflowHelper workflowHelper;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	CeTaskHelper ceTaskHelper;

	@RequestMapping(method = RequestMethod.GET, value = "/workflow-actions/view/{workflowId}")
	public ResultDto<WorkflowAction> getWorkflowActionsList(@PathVariable Integer workflowId, WorkflowActionSearchDto searchDto) {
		ResultDto<WorkflowAction> results = workflowRepository.getWorkflowActionsListByWorkflowId(workflowId, searchDto);
		var models = results.getModels();
		models.stream().forEach(u -> {
			var dto = new WorkflowActionDto(cache, u);
			results.getRecords()[models.indexOf(u)] = dto;
		});
		return results;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/workflow-files/view/{workflowId}")
	public ResultDto<WorkflowFile> getWorkflowFilesList(@PathVariable Integer workflowId, WorkflowFileSearchDto searchDto) {
		ResultDto<WorkflowFile> results = workflowRepository.getWorkflowFilesListByWorkflowId(workflowId, searchDto);
		var models = results.getModels();
		models.stream().forEach(u -> {
			var dto = AttachmentDto.buildFromWorkflowFile(u, fileHelper);
			results.getRecords()[models.indexOf(u)] = dto;
		});
		return results;
	}

	@RequestMapping(value = "/view/{workflowStepType}", method = RequestMethod.GET)
	public WorkflowConfigItemDto getWorkflow(@PathVariable String workflowStepType) {

		// 1. get all workflow steps
		List<WorkflowStep> workflowSteps = baseWorkflowHelperRepository.getWorkflowStepsByWorkflowStepType(workflowStepType);

		// 2. get all users based on workflow steps
		List<User> users = userRepository.getActiveUsersByRoles(workflowSteps.stream().map(u -> u.getRole().getCode()).collect(Collectors.toList()));

		// 3. get all workflow config setup
		List<WorkflowConfig> workflowConfigs = baseWorkflowHelperRepository.getWorkflowConfigsByStepType(workflowStepType);

		return WorkflowConfigItemDto.buildFromWorkflowConfigs(cache, workflowSteps, workflowConfigs, users, workflowStepType);
	}

	@RequestMapping(value = "/return/role", method = RequestMethod.GET)
	public WorkflowConfigItemDto getRoleListToBeReturned(ReturnRoleDto returnRoleDto) {

		WorkflowStep currentWorkflowStep = baseWorkflowHelperRepository.getWorkflowStepByStartStatusCode(returnRoleDto.getCurrentStatusCode());

		// to add all role which is under current role
		if (currentWorkflowStep != null) {
			List<WorkflowStepAssignment> workflowStepAssignments = baseWorkflowHelperRepository.getWorkflowStepAssignmentsByAppTypeAndCurrentLevel(returnRoleDto.getAppType(),
					currentWorkflowStep.getLevel());

			WorkflowConfigItemDto workflowConfigItemDto = new WorkflowConfigItemDto();
			if (CollectionUtils.isNotEmpty(workflowStepAssignments)) {
				List<WorkflowUserRoleDto> roles = new ArrayList<>();
				String[] stringOfRoles = new String[workflowStepAssignments.size()];
				workflowStepAssignments.forEach(u -> {
					WorkflowUserRoleDto dto = new WorkflowUserRoleDto();
					WorkflowStep workflowStep = u.getWorkflowStep();
					Role role = workflowStep.getRole();
					dto.setRole(role.getLabel());
					dto.setRoleCode(role.getCode());
					dto.setStartStatusCode(workflowStep.getStartStatus().getCode());
					dto.setDefaultAssignee(u.getUser() != null ? u.getUser().getId() : null);

					List<User> users = userRepository.getActiveUsersByRole(role.getCode());
					List<UserProfileDto> userProfileDtos = new ArrayList<>();

					String taCompanyName = returnRoleDto.getCompanyName().trim().replaceAll("[^a-zA-Z0-9]", "");
					users.forEach(user -> {
						UserProfileDto upDto = new UserProfileDto();
						upDto.setId(user.getId());
						upDto.setName(user.getName());
						userProfileDtos.add(upDto);

						User officer = workflowHelper.getAssigneeByChar(user, taCompanyName);
						if (officer != null) {
							dto.setDefaultAssignee(officer.getId());
						}
					});
					dto.setUsers(userProfileDtos);
					roles.add(dto);
					stringOfRoles[workflowStepAssignments.indexOf(u)] = role.getCode();
				});
				workflowConfigItemDto.setRoles(roles);
				workflowConfigItemDto.setStringOfRoles(stringOfRoles);
			}

			return workflowConfigItemDto;
		}

		return null;
	}

	@RequestMapping(value = { "/officer/{statusCode}", "/officer/{statusCode}/{appOrWkflwTypeCodeOptional}" }, method = RequestMethod.GET)
	public List<UserProfileDto> getOfficerListByStatus(@PathVariable String statusCode, @PathVariable Optional<String> appOrWkflwTypeCodeOptional) {
		WorkflowStep currentWorkflowStep = baseWorkflowHelperRepository.getWorkflowStepByStartStatusCode(statusCode);

		List<Role> roles = new ArrayList<>();
		if (currentWorkflowStep != null) {
			if (currentWorkflowStep.getRole() != null) {
				roles.add(currentWorkflowStep.getRole());
			} else {
				if (appOrWkflwTypeCodeOptional.isPresent()) {
					if (Codes.Workflow.CE_CASE.contains(appOrWkflwTypeCodeOptional.get())) {
						roles.addAll(currentWorkflowStep.getRoles().stream().filter(u -> !Codes.Roles.CNE_INVESTIGATION_OFFICER.equals(u.getCode())).collect(Collectors.toList()));
					}
				} else {
					roles.addAll(currentWorkflowStep.getRoles());
				}
			}

		} else {
			User currentUser = getUser();
			roles.add(currentUser.getDefaultRole());
		}

		List<User> users = userRepository.getActiveUsersByRoles(roles.stream().map(Role::getCode).collect(Collectors.toList()));

		List<UserProfileDto> dtoList = new ArrayList<>();
		users.forEach(u -> {
			dtoList.add(UserProfileDto.buildFromUser(cache, u, null));
		});

		return dtoList;
	}

	@RequestMapping(value = "/officer/role/{roleCode}", method = RequestMethod.GET)
	public List<UserProfileDto> getOfficerListByRole(@PathVariable String roleCode) {
		List<User> users = userRepository.getActiveUsersByRole(roleCode);

		List<UserProfileDto> dtoList = new ArrayList<>();
		users.forEach(u -> {
			dtoList.add(UserProfileDto.buildFromUser(cache, u, null));
		});

		return dtoList;
	}

	@RequestMapping(value = { "/ce/{appOrWkflwTypeCode}", "/ce/{appOrWkflwTypeCode}/{workflowId}" }, method = RequestMethod.GET)
	public List<WorkflowUserRoleDto> getCEWorkflowConfig(@PathVariable String appOrWkflwTypeCode, @PathVariable Optional<Integer> workflowId) {

		List<WorkflowStepAssignment> workflowStepAssignments = baseWorkflowHelperRepository.getWorkflowStepAssignmentsByAppTypeAndWorkflowId(appOrWkflwTypeCode, workflowId);

		List<WorkflowUserRoleDto> workflowUserRoleDtos = new ArrayList<>();
		for (WorkflowStepAssignment wsa : workflowStepAssignments) {
			WorkflowStep workflowStep = wsa.getWorkflowStep();

			Set<Role> roleSet = null;
			if (Codes.Workflow.CE_CASE.contains(appOrWkflwTypeCode)) {
				roleSet = workflowStep.getRoles().stream().filter(u -> !Codes.Roles.CNE_INVESTIGATION_OFFICER.equals(u.getCode())).collect(Collectors.toSet());
			} else {
				roleSet = workflowStep.getRoles();
			}
			List<User> users = userRepository.getActiveUsersByRoles(roleSet.stream().map(Role::getCode).collect(Collectors.toList()));

			WorkflowUserRoleDto dto = new WorkflowUserRoleDto();
			dto.setStartStatusCode(workflowStep.getStartStatus().getCode());
			dto.setDefaultAssignee(wsa.getUser().getId());

			if (CollectionUtils.isNotEmpty(users)) {
				List<UserProfileDto> userProfileDtos = new ArrayList<>();
				users.forEach(user -> {
					userProfileDtos.add(UserProfileDto.buildFromUser(cache, user, null));
				});
				dto.setUsers(userProfileDtos);
			}

			workflowUserRoleDtos.add(dto);
		}

		return workflowUserRoleDtos;
	}

	@RequestMapping(value = "/update/{workflowStepType}", method = RequestMethod.POST)
	public void getWorkflow(@RequestBody WorkflowStepDto[] dtoArray, @PathVariable String workflowStepType) {

		// 1. retrieve all related fields based on WKFLW_STEP_TA/TG_APP or WKFLW_STEP_TA/TG
		// 1.1 get all workflow steps
		List<WorkflowStep> workflowSteps = baseWorkflowHelperRepository.getWorkflowStepsByWorkflowStepType(workflowStepType);

		// 1.2 get all users based on workflow steps
		List<User> users = userRepository.getActiveUsersByRoles(workflowSteps.stream().map(u -> u.getRole().getCode()).collect(Collectors.toList()));

		// 1.3 get all workflow config setup
		List<WorkflowConfig> workflowConfigs = baseWorkflowHelperRepository.getWorkflowConfigsByStepType(workflowStepType);

		// 1.4 get all Workflow Step Assignments
		List<WorkflowStepAssignment> workflowStepAssignments = baseWorkflowHelperRepository.getWorkflowStepAssignmentsByStepType(workflowStepType);

		// 1.5 get all pending approval applications / workflows
		List<Application> pendingApplications = new ArrayList<>();
		List<Workflow> pendingWorkflows = new ArrayList<>();
		if (Codes.WorkflowStep.WKFLW_APPLICATION.contains(workflowStepType)) {
			pendingApplications = commonRepository.getPendingApplicationsByStatuses(workflowSteps.stream().map(WorkflowStep::getStartStatus).collect(Collectors.toList()));
		} else {
			pendingWorkflows = commonRepository.getPendingWorkflowsByStatuses(workflowSteps.stream().map(WorkflowStep::getStartStatus).collect(Collectors.toList()));
		}

		for (WorkflowStepDto dto : dtoArray) {

			String appOrWkflwTypeCode = dto.getApplicationTypeCode();

			// filter all related fields based on particular type eg TG_APP_CREATION
			WorkflowConfig workflowConfig = workflowConfigs.stream().filter(u -> u.getAppOrWkflwType().getCode().equals(appOrWkflwTypeCode)).findFirst().get();
			List<WorkflowStepAssignment> particularWkflwStepAssignments = workflowStepAssignments.stream().filter(u -> u.getWorkflowConfig().equals(workflowConfig)).collect(Collectors.toList());
			List<WorkflowStep> particularWkflwSteps = particularWkflwStepAssignments.stream().map(WorkflowStepAssignment::getWorkflowStep).collect(Collectors.toList());
			List<Application> particularPendingApplications = pendingApplications.stream().filter(u -> u.getType().equals(workflowConfig.getAppOrWkflwType())).collect(Collectors.toList());
			List<Workflow> particularPendingWorkflows = pendingWorkflows.stream().filter(u -> u.getType().equals(workflowConfig.getAppOrWkflwType())).collect(Collectors.toList());

			WorkflowStep existingFinalStep = particularWkflwSteps.get(particularWkflwSteps.size() - 1);

			List<WorkflowStep> updatedSteps = new ArrayList<>(); // to store all checked level
			TreeMap<Integer, User> involvedStepAssignmentMap = new TreeMap<>(); // to store all checked level togather with assigned officer
			TreeMap<String, Object> steps = dto.getSteps();

			WorkflowStep newFinalStep = new WorkflowStep();
			for (Map.Entry<String, Object> step : steps.entrySet()) {
				String key = step.getKey();

				if (key.indexOf("Assignee") < 0) {
					boolean isChecked = (boolean) step.getValue();

					if (isChecked) {
						Integer level = Integer.parseInt(key.replace("level", ""));
						WorkflowStep workflowStep = workflowSteps.stream().filter(u -> u.getLevel().equals(level)).findAny().get();
						newFinalStep = workflowStep;
						updatedSteps.add(workflowStep);

						User user = null;
						if (steps.get(key.concat("Assignee")) != null) {
							Integer userId = (Integer) steps.get(key.concat("Assignee"));
							user = users.stream().filter(u -> u.getId().equals(userId)).findAny().get();
						}
						involvedStepAssignmentMap.put(workflowStep.getId(), user);
					}
				}
			}

			// 2. Update all pending applications / workflows
			// 2.1 cascade update all pending applications / workflows
			Integer[] minLevel = { 0 };
			for (WorkflowStep ws : updatedSteps) {
				List<WorkflowStep> affectedWorkflowSteps = particularWkflwSteps.stream().filter(u -> u.getLevel() > minLevel[0] && u.getLevel() < ws.getLevel()).collect(Collectors.toList());
				List<Status> affectedStepStatuses = affectedWorkflowSteps.stream().map(WorkflowStep::getStartStatus).collect(Collectors.toList());

				if (CollectionUtils.isNotEmpty(particularPendingApplications)) {
					List<Application> affectedApplications = particularPendingApplications.stream().filter(u -> affectedStepStatuses.contains(u.getLastAction().getStatus()))
							.collect(Collectors.toList());
					appHelper.cascadeConfig(affectedApplications, null, ws.getStartStatus().getCode(), involvedStepAssignmentMap.get(ws.getId()));

				} else if (CollectionUtils.isNotEmpty(particularPendingWorkflows)) {
					List<Workflow> affectedWorkflows = particularPendingWorkflows.stream().filter(u -> affectedStepStatuses.contains(u.getLastAction().getStatus())).collect(Collectors.toList());
					workflowHelper.cascadeConfig(null, affectedWorkflows, ws.getStartStatus().getCode(), involvedStepAssignmentMap.get(ws.getId()));
				}

				minLevel[0] = ws.getLevel();
			}

			// 2.2 update remaining applications / workflows to new final step if new final step is different with existing final step
			if (!minLevel[0].equals(existingFinalStep.getLevel())) {
				List<WorkflowStep> affectedWorkflowSteps = particularWkflwSteps.stream().filter(u -> u.getLevel() > minLevel[0] && u.getLevel() <= existingFinalStep.getLevel())
						.collect(Collectors.toList());
				List<Status> affectedStepStatuses = affectedWorkflowSteps.stream().map(WorkflowStep::getStartStatus).collect(Collectors.toList());

				if (CollectionUtils.isNotEmpty(particularPendingApplications)) {
					List<Application> affectedApplications = particularPendingApplications.stream().filter(u -> affectedStepStatuses.contains(u.getLastAction().getStatus()))
							.collect(Collectors.toList());
					appHelper.cascadeConfig(affectedApplications, null, newFinalStep.getStartStatus().getCode(), involvedStepAssignmentMap.get(newFinalStep.getId()));

				} else if (CollectionUtils.isNotEmpty(particularPendingWorkflows)) {
					List<Workflow> affectedWorkflows = particularPendingWorkflows.stream().filter(u -> affectedStepStatuses.contains(u.getLastAction().getStatus())).collect(Collectors.toList());
					appHelper.cascadeConfig(null, affectedWorkflows, newFinalStep.getStartStatus().getCode(), involvedStepAssignmentMap.get(newFinalStep.getId()));
				}
			}

			// 3. Update Workflow Config, Workflow Step Assignment table
			// 3.1 update final step if final step is changed
			if (!workflowConfig.getFinalStep().getId().equals(newFinalStep.getId())) {
				workflowConfig.setFinalStep(newFinalStep);
			}

			// 3.2 insert, update, delete workflow step assignment
			// 3.2.1 delete if the step is unchecked
			List<WorkflowStepAssignment> deletedWorkflowStepAssignments = particularWkflwStepAssignments.stream().filter(u -> !updatedSteps.contains(u.getWorkflowStep())).collect(Collectors.toList());
			workflowRepository.delete(deletedWorkflowStepAssignments);

			// 3.2.2 add if new step is checked
			List<WorkflowStep> newStep = new ArrayList<>();
			for (WorkflowStep ws : updatedSteps) {
				Optional<WorkflowStepAssignment> workflowStepAssignmentOptional = particularWkflwStepAssignments.stream().filter(u -> u.getWorkflowStep().getId().equals(ws.getId())).findAny();
				if (!workflowStepAssignmentOptional.isPresent()) {
					newStep.add(ws);
				}
			}

			List<WorkflowStepAssignment> newWsaList = new ArrayList<>();
			for (WorkflowStep ws : newStep) {
				WorkflowStepAssignment wsa = new WorkflowStepAssignment();
				wsa.setWorkflowStep(ws);
				wsa.setWorkflowConfig(workflowConfig);
				wsa.setUser(involvedStepAssignmentMap.get(ws.getId()));
				newWsaList.add(wsa);
			}
			workflowRepository.save(newWsaList);

			// 3.2.3 Update only if assignee of existing step is changed
			List<WorkflowStepAssignment> existWorkflowStepAssignments = particularWkflwStepAssignments.stream().filter(u -> updatedSteps.contains(u.getWorkflowStep())).collect(Collectors.toList());
			for (WorkflowStepAssignment wsa : existWorkflowStepAssignments) {
				User user = involvedStepAssignmentMap.get(wsa.getWorkflowStep().getId());
				if (user != null && !wsa.getUser().equals(user)) {
					wsa.setUser(user);
				}
			}
			workflowRepository.saveOrUpdate(existWorkflowStepAssignments);
		}
	}

	/*
	 * Reassign CE Workflows to other Officer
	 */
	@RequestMapping(value = "/ce/re-assign", method = RequestMethod.POST)
	public void reAssignCEWorkflow(@RequestBody AssignDto dto) {
		Workflow workflow = workflowRepository.get(Workflow.class, dto.getWorkflowId());
		User assignee = userRepository.getUserWithRolesById(dto.getReAssignedOfficerId());
		workflowHelper.reAssign(workflow, assignee, dto.getInternalRemarks());
		ceTaskHelper.updateCeTaskAssignee(workflow);
	}

}
