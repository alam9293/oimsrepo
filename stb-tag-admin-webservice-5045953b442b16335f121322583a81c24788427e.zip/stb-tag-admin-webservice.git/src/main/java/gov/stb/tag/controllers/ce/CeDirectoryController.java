package gov.stb.tag.controllers.ce;

import java.io.IOException;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.directory.CeDirectoryItemDto;
import gov.stb.tag.dto.ce.directory.CeDirectorySearchDto;
import gov.stb.tag.dto.ce.directory.CeInfringementForPublicDto;
import gov.stb.tag.dto.ce.directory.CeInfringementForTgPublicDto;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.ce.CeDirectoryRepository;

@RestController
@RequestMapping(path = "/api/v1/ce/directory")
@Transactional
public class CeDirectoryController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeDirectoryRepository ceDirectoryRepository;
	@Autowired
	PaymentRepository paymentRepository;

	@RequestMapping(path = { "/search" }, method = RequestMethod.GET)
	public ResultDto<CeDirectoryItemDto> getCeDirectory(CeDirectorySearchDto searchDto) throws IOException {
		return ceDirectoryRepository.getList(searchDto, getUser().getId());
	}

	/**
	 * Access by public TA
	 */
	@RequestMapping(value = "/past-infringements", method = RequestMethod.GET)
	public List<CeInfringementForPublicDto> getCePastInfringementList() {
		List<CeInfringementForPublicDto> results = ceDirectoryRepository.getPast5YearsInfringements(getUser().getUen() != null ? getUser().getUen() : getUser().getLoginId());
		results.forEach(dto -> {
			if (!Strings.isNullOrEmpty(dto.getBillRefNo())) {
				PaymentRequest payReq = paymentRepository.getPaymentRequest(dto.getBillRefNo());
				if (payReq != null) {
					dto.setPaymentRequestStatus(new ListableDto(payReq.getStatus(), true));
				}
			}
		});
		return results;
	}

	/**
	 * Access by public TG
	 */
	@RequestMapping(value = "/past-infringements/tg", method = RequestMethod.GET)
	public List<CeInfringementForTgPublicDto> getCeTgPastInfringementList() {
		return ceDirectoryRepository.getTgPast5YearsInfringements(getUser().getLoginId());
	}

}
