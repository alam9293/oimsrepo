package gov.stb.tag.controllers.ce;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.EntitySearchDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.repository.CeProvisionRepository;

@RestController
@RequestMapping(path = "/api/v1/ce/provision")
@Transactional
public class CeProvisionController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeProvisionRepository ceProvisionRepository;

	@RequestMapping(path = "/view/dropdown/{taTgType}", method = RequestMethod.GET)
	public List<CeProvisionDto> getCeProvisionsDropdown(@PathVariable String taTgType) {
		String taProvisionChapters = cache.getSystemParameter(Codes.SystemParameters.CE_DEFAULT_TA_PROVISION_CHAPTER).getValue();
		String tgProvisionChapters = cache.getSystemParameter(Codes.SystemParameters.CE_DEFAULT_TG_PROVISION_CHAPTER).getValue();

		List<String> chapters = new ArrayList<>();
		if (Codes.TaTgType.TG.equals(taTgType)) {
			chapters.addAll(Arrays.asList(tgProvisionChapters.split(",")));
		} else {
			chapters.addAll(Arrays.asList(taProvisionChapters.split(",")));
		}

		List<CeProvisionDto> ceProvisionDtos = new ArrayList<CeProvisionDto>();
		List<CeProvision> ceOffenceProvisions = ceProvisionRepository.getAllCeProvisionsByChapter(chapters);
		ceOffenceProvisions.forEach(u -> ceProvisionDtos.add(new CeProvisionDto(cache, u)));
		return ceProvisionDtos;
	}

	@RequestMapping(path = "/view/dropdown/read-with", method = RequestMethod.GET)
	public List<CeProvisionDto> getCeProvisionsWithReadWithDropdown() {
		List<CeProvision> ceOffenceProvisions = ceProvisionRepository.getAllCeOffenceProvisions();
		return ceOffenceProvisions.stream().map(x -> new CeProvisionDto(cache, x, true)).collect(Collectors.toList());
	}

	@RequestMapping(path = "/view/dropdown/provision-read-with/{taTgType}", method = RequestMethod.GET)
	public List<CeProvisionDto> getCeProvisionsWithReadWithDropdownByChapter(@PathVariable String taTgType) {
		String taProvisionChapters = cache.getSystemParameter(Codes.SystemParameters.CE_DEFAULT_TA_PROVISION_CHAPTER).getValue();
		String tgProvisionChapters = cache.getSystemParameter(Codes.SystemParameters.CE_DEFAULT_TG_PROVISION_CHAPTER).getValue();

		List<String> chapters = new ArrayList<>();
		if (Codes.TaTgType.TG.equalsIgnoreCase(taTgType)) {
			chapters.addAll(Arrays.asList(tgProvisionChapters.split(",")));
		} else {
			chapters.addAll(Arrays.asList(taProvisionChapters.split(",")));
		}

		List<CeProvisionDto> ceProvisionDtos = new ArrayList<CeProvisionDto>();
		List<CeProvision> ceOffenceProvisions = ceProvisionRepository.getAllCeProvisionsByChapter(chapters);
		ceOffenceProvisions.forEach(u -> ceProvisionDtos.add(new CeProvisionDto(cache, u, true)));
		return ceProvisionDtos;
	}

	@RequestMapping(path = "/view/dropdown/read-with-only/{chapter}", method = RequestMethod.GET)
	public List<ListableDto> getCeReadWithsByChapter(@PathVariable String chapter) {
		List<CeProvision> ceReadWiths = ceProvisionRepository.getAllCeReadWithsByChapter(Arrays.asList(chapter));
		List<ListableDto> results = new ArrayList<>();
		for (CeProvision readWith : ceReadWiths) {
			results.add(new ListableDto(readWith.getId(), readWith.getSection(),
					readWith.getEffectiveDate().isAfter(LocalDate.now())
							|| (readWith.getIneffectiveDate() != null && (readWith.getIneffectiveDate().isBefore(LocalDate.now()) || readWith.getIneffectiveDate().isEqual(LocalDate.now())))
									? "inactive"
									: "active",
					readWith.getDescription(), null));
		}
		return results;
	}

	@RequestMapping(path = "/view/{chapter}", method = RequestMethod.GET)
	public List<CeProvisionDto> getCeProvisions(@PathVariable String chapter) {
		List<CeProvision> ceOffenceProvisions = ceProvisionRepository.getAllCeProvisionsByChapter(Arrays.asList(chapter), false);
		return ceOffenceProvisions.stream().map(x -> new CeProvisionDto(cache, x, true)).collect(Collectors.toList());
	}

	@RequestMapping(path = "/view/inactive/{chapter}/{readwithOrProvision}", method = RequestMethod.GET)
	public ResultDto<CeProvision> getInactiveCeProvisions(@PathVariable String chapter, @PathVariable String readwithOrProvision, EntitySearchDto searchDto) {
		ResultDto<CeProvision> ceOffenceProvisions = ceProvisionRepository.getInactiveCeProvisionsByChapter(Arrays.asList(chapter), searchDto, readwithOrProvision);

		Object[] finalRecords = new Object[ceOffenceProvisions.getRecords().length];
		var i = 0;
		for (CeProvision p : ceOffenceProvisions.getModels()) {
			var dto = new CeProvisionDto(cache, p, true);
			finalRecords[i] = dto;
			i++;
		}
		ceOffenceProvisions.setRecords(finalRecords);
		return ceOffenceProvisions;

	}

	@RequestMapping(path = "/save", method = RequestMethod.POST)
	public void saveCeProvision(@RequestBody CeProvisionDto dto) {

		// 1. Retrieve/Create CeProvision Object
		CeProvision provision;
		if (dto.getId() == null) {
			provision = new CeProvision();
		} else {
			provision = ceProvisionRepository.get(CeProvision.class, dto.getId());
		}

		// 2. Setting of CeProvision details
		provision.setChapter(cache.getType(dto.getChapter().getKey().toString()));
		provision.setSection(dto.getSection());
		provision.setLabel(dto.getLabel());
		provision.setDescription(dto.getDescription());
		provision.setEffectiveDate(dto.getEffectiveDate());
		provision.setIneffectiveDate(dto.getIneffectiveDate());
		provision.setIsOffence(dto.getIsOffence());
		provision.setIsReadWithOnly(dto.getIsReadWithOnly());

		// 3. Dealing with CeProvision's ReadWiths

		// 3.1 Deleting ReadWiths
		if (provision.getReadWiths() != null) {
			List<CeProvision> toRemoveList = new ArrayList<>();
			for (CeProvision x : provision.getReadWiths()) {
				Boolean toRemove = true;
				for (CeProvisionDto readWithDto : dto.getReadWiths()) {
					if (readWithDto.getId() == x.getId()) {
						toRemove = false;
						break;
					}
				}
				if (toRemove) {
					toRemoveList.add(x);
				}
			}
			provision.getReadWiths().removeAll(toRemoveList);
		}

		// 3.2 Adding ReadWiths
		for (CeProvisionDto readWith : dto.getReadWiths()) {
			if (!provision.getReadWiths().contains(ceProvisionRepository.get(CeProvision.class, readWith.getId()))) {
				provision.getReadWiths().add(ceProvisionRepository.get(CeProvision.class, readWith.getId()));
			}
		}

		// 4. Saving
		ceProvisionRepository.save(provision);
	}
}
