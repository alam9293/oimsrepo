package gov.stb.tag.controllers.ce;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.CeSubmissionStatus;
import gov.stb.tag.constant.Codes.FLAGS;
import gov.stb.tag.constant.Codes.SignDocResults;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckDocumentDto;
import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckDto;
import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckQnReponseDto;
import gov.stb.tag.dto.ce.ta.tacheck.CeTaCheckSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.helper.signdoc.CeTaCheckPdfHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckDocument;
import gov.stb.tag.model.CeTaCheckQn;
import gov.stb.tag.model.CeTaCheckQnResponse;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.TaCommonRepository;
import gov.stb.tag.repository.ce.CeTaCheckRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ce/tati-check")
@Transactional
public class CeTaCheckController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTaCheckRepository ceTaCheckRepository;
	@Autowired
	TaCommonRepository taCommonRepository;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	CeTaCheckPdfHelper ceTaCheckPdfHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;

	@RequestMapping(path = { "/view" }, method = RequestMethod.GET)
	public CeTaCheckDto loadTatiComplianceCheck(CeTaCheckSearchDto searchDto) {
		CeTaCheckDto resultDto = new CeTaCheckDto();
		User currentUser = ceTaCheckRepository.getLicenseeUserByUserId(getUser().getId());
		if (searchDto.getCeTaCheckId() != null) {
			logger.info("Get ceTaCheck for id: {}", searchDto.getCeTaCheckId());
			CeTaCheck ceTaCheckModel = ceTaCheckRepository.get(CeTaCheck.class, searchDto.getCeTaCheckId());
			resultDto = CeTaCheckDto.buildCheckDtoFromCheckModel(cache, ceTaCheckModel, resultDto, userRepository);
		} else if (searchDto.getCeTaCheckScheduleItemId() != null) {
			// check for existing
			logger.info("Get ceTaCheck for ceTaCheckScheduleId: {}", searchDto.getCeTaCheckScheduleItemId());
			CeTaCheck ceTaCheckModel = ceTaCheckRepository.getCheckFromSchedule(searchDto.getCeTaCheckScheduleItemId());
			if (ceTaCheckModel == null) {
				logger.info("No existing ceTaCheck, create new");
				CeTaCheckScheduleItem checkItemModel = ceTaCheckRepository.get(CeTaCheckScheduleItem.class, searchDto.getCeTaCheckScheduleItemId());
				Stakeholder stakeholderModel = new Stakeholder();
				stakeholderModel = taCommonRepository.getExistingKe(checkItemModel.getLicence().getId());
				List<CeTaCheckQn> checkQns = ceTaCheckRepository.getCeTatiCheckQns();
				resultDto = CeTaCheckDto.buildNewCheckDto(cache, checkItemModel, stakeholderModel, resultDto, checkQns, currentUser);
			} else {
				logger.info("Found existing ceTaCheck with id: {}", ceTaCheckModel.getId());
				resultDto = CeTaCheckDto.buildCheckDtoFromCheckModel(cache, ceTaCheckModel, resultDto, userRepository);
			}
		}
		if (!resultDto.getEoUserDto().getLoginId().equalsIgnoreCase(currentUser.getLoginId())
				|| (resultDto.getSubmissionStatus().getKey() != null && resultDto.getSubmissionStatus().getKey().toString().equalsIgnoreCase(CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED))) {
			resultDto.setDisableEdit(Boolean.TRUE);
			logger.info("Do not allow ceTaCheck to be edited");
		}

		return resultDto;
	}

	// to create/update ta check report
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public CeTaCheckDto saveTatiCheck(@RequestBody CeTaCheckDto dto) {
		CeTaCheck model = new CeTaCheck();
		CeTaCheckScheduleItem ceTaCheckScheduleItem = null;
		if (dto.getCeTaCheckId() != null) {
			logger.info("Update existing ceTaCheck with id: {}", dto.getCeTaCheckId());
			model = ceTaCheckRepository.get(CeTaCheck.class, dto.getCeTaCheckId());
		}
		if (dto.getCeTaCheckScheduleItemId() != null) {
			logger.info("Create new ceTaCheck with scheduleId: {}", dto.getCeTaCheckScheduleItemId());
			ceTaCheckScheduleItem = ceTaCheckRepository.get(CeTaCheckScheduleItem.class, dto.getCeTaCheckScheduleItemId());
		}
		model = updateCeCheckValues(model, dto, ceTaCheckScheduleItem);
		updateAttachments(dto.getFiles());

		ceTaCheckRepository.saveOrUpdate(model);
		logger.info("Updated ceTaCheck with id: {}", model.getId());
		dto = CeTaCheckDto.buildCheckDtoFromCheckModel(cache, model, new CeTaCheckDto(), userRepository);

		return dto;
	}

	// to submit ta check report with sign doc
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/submit/{ceTaCheckId}")
	public String updateSigndocPdf(@PathVariable Integer ceTaCheckId) {
		CeTaCheck model = ceTaCheckRepository.get(CeTaCheck.class, ceTaCheckId);
		model.setCheckedDate(LocalDateTime.now());
		CeTaCheckDto dto = CeTaCheckDto.buildCheckDtoFromCheckModel(cache, model, new CeTaCheckDto(), userRepository);
		if (!model.getCeTaCheckScheduleItem().toRevisit()) {
			model.setIsCompliant(checkTaCompliant(dto));
		}
		ceTaCheckRepository.saveOrUpdate(model);
		logger.info("Submit ce ta check with id: {}, checked date: {}", ceTaCheckId, model.getCheckedDate());
		byte[] pdf = ceTaCheckPdfHelper.generatePdf(CeTaCheckDto.buildCheckDtoFromCheckModel(cache, model, new CeTaCheckDto(), userRepository));

		return ceTaCheckPdfHelper.preloadToSigndoc(pdf, properties.signdocCeTaCheckResultUrl + model.getId());
	}

	@RequestMapping(path = { "/submit/update-sign-doc-result" }, method = RequestMethod.POST)
	public void updateSignDocResult(@RequestBody CeTaCheckSearchDto searchDto) {
		CeTaCheck model = ceTaCheckRepository.get(CeTaCheck.class, searchDto.getCeTaCheckId());
		if (model.isDraft()) {
			logger.info("Status of sign doc submisison {}, ceTaCheckId: {}", searchDto.getSdweb_result(), model.getId());
			if (searchDto.getSdweb_result().equalsIgnoreCase(SignDocResults.SUCCESS)) {
				model.setSigndocId(searchDto.getSdweb_docid());
				model.setIsDraft(Boolean.FALSE);
				if (model.getCeCase() == null) {
					// Create case for TATI
					model.setCeCase(ceCaseHelper.createCaseForTaTiCheck(model, model.getIsCompliant()));
					logger.info("Created new case with caseId: ", model.getCeCase().getId());
				}
				if (!model.getCeTaCheckScheduleItem().toRevisit()) {
					// snapshot the last TATI check
					CeTaCheckScheduleItem scheduleItem = model.getCeTaCheckScheduleItem();
					if (scheduleItem != null && !scheduleItem.toRevisit()) {
						if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_OP)) {
							scheduleItem.getLicence().getTravelAgent().setLastOpAddrTaCheck(model);
							scheduleItem.getLicence().getTravelAgent().setIsLastOpAddrCheckDone(Boolean.TRUE);
						} else if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_REG)) {
							scheduleItem.getLicence().getTravelAgent().setLastRegAddrTaCheck(model);
							scheduleItem.getLicence().getTravelAgent().setIsLastRegAddrCheckDone(Boolean.TRUE);
						} else if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_BRANCH)) {
							scheduleItem.getTaBranch().setLastTaCheck(model);
							scheduleItem.getTaBranch().setIsLastCheckDone(Boolean.TRUE);
						}
					}
					logger.info("Done snapshot the last TATI check id : {}", model.getId());
				}
			} else if (searchDto.getSdweb_result().equalsIgnoreCase(SignDocResults.CANCEL)) {
				model.setIsCompliant(null);
				logger.info("Submission of sign doc not done for taCheckId: {}", model.getId());
				// model.setCheckedDate(null);
			} else if (searchDto.getSdweb_result().equalsIgnoreCase(SignDocResults.ERROR)) {
				model.setIsCompliant(null);
				logger.error("ERROR Submission of sign doc for taCheckId: {}", model.getId());
				throw new ValidationException(DateUtil.format(LocalDateTime.now()) + " - Unable to archive signed document. Please contact administrator.");
			}

			ceTaCheckRepository.saveOrUpdate(model);
			// CeTaCheckDto resultDto = CeTaCheckDto.buildCheckDtoFromCheckModel(cache, model, new CeTaCheckDto(), userRepository);
		}
	}

	private void updateAttachments(List<AttachmentDto> filesDto) {
		if (CollectionUtils.isNotEmpty(filesDto)) {
			List<File> files = fileRepository.getFiles(filesDto.stream().map(AttachmentDto::getId).collect(Collectors.toList()));
			for (File file : files) {
				AttachmentDto fDto = filesDto.stream().filter(u -> u.getId().equals(file.getId())).findFirst().get();
				file.setDescription(fDto.getDescription());
			}
		}
	}

	@RequestMapping(path = { "/view/acknowledgement/{isAcknowledged}" }, method = RequestMethod.GET)
	public List<CeTaCheckDto> getListForAcknowledgement(@PathVariable String isAcknowledged) {
		List<CeTaCheckDto> resultDto = Lists.newArrayList();
		List<CeTaCheck> tatiChecks = ceTaCheckRepository.getCeTaCheckByAcknowledgementStatus(Boolean.TRUE.toString().equalsIgnoreCase(isAcknowledged));
		logger.info("View batch acknowledge compliant TAs : {}", tatiChecks.stream().map(CeTaCheck::getId).collect(Collectors.toList()));
		tatiChecks.stream().forEach(tatiCheck -> {
			resultDto.add(CeTaCheckDto.buildCheckDtoFromCheckModel(cache, tatiCheck, new CeTaCheckDto(), userRepository));
		});
		return resultDto;
	}

	@RequestMapping(path = { "/acknowledge" }, method = RequestMethod.POST)
	public void acknowledgeCeTaCheck(@RequestBody List<Integer> ceTaCheckIds) {
		List<CeTaCheck> tatiChecks = ceTaCheckRepository.getCeTaCheckByIds(ceTaCheckIds);
		logger.info("Batch acknowledge compliant TAs : {}", ceTaCheckIds);
		tatiChecks.stream().forEach(tatiCheck -> {
			CeCase ceCase = tatiCheck.getCeCase();
			User approver = workflowHelper.getAssigneeByChar(Codes.Roles.TA_HEAD_OF_DEPARTMENT, tatiCheck.getCeTaCheckScheduleItem().getLicence().getTravelAgent().getName());

			if (ceCase != null) {

				ceCase.getCeCaseInfringements().forEach(ceCaseInfringement -> {
					CeCaseRecommendation recomm = ceCaseInfringement.getLastRecommendation();
					if (recomm != null) {
						Workflow workflow = recomm.getWorkflow();
						if (!workflowHelper.hasFinalApproved(workflow)) {
							workflowHelper.forward(workflow, false, null, null, approver.getId(), false, null);
						}
						if (workflowHelper.hasFinalApproved(workflow) && ceCaseInfringement.getOutcome() == null) {
							boolean isCaseClosed = ceCaseHelper.processRecommendationDirectOutcome(Lists.newArrayList(recomm), ceCase);
							if (isCaseClosed) {
								ceTaskHelper.completeCeTaskByCeCase(ceCase, false);
								tatiCheck.setIsAcknowledged(Boolean.TRUE);
								tatiCheck.setLastAcknowledgedBy(getUser());
								tatiCheck.setLastAcknowledgedDate(LocalDate.now());
								ceTaCheckRepository.save(tatiCheck);
							} else {

								// to check whether current workflow is final approval stage
								// if final approval stage, system have to process the recommendation outcome
								if (workflowHelper.hasFinalApproved(workflow)) {
									isCaseClosed = ceCaseHelper.processRecommendationOutcome(Lists.newArrayList(recomm), ceCase);

									// if case is closed, system have to complete all the open ce task related to case
									if (isCaseClosed) {
										ceTaskHelper.completeCeTaskByCeCase(ceCase, false);
									}

								} else {
									// ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParameter, null);
								}
							}
						}
					}
				});

				// ceCase.getCeCaseInfringements().forEach(ceCaseInfringement -> {
				// CeCaseRecommendation recomm = ceCaseInfringement.getLastRecommendation();
				// Workflow workflow = recomm.getWorkflow();
				// if (!workflowHelper.hasFinalApproved(workflow)) {
				// workflowHelper.forward(workflow, false, null, null, approver.getId(), false, null);
				// }
				// if (workflowHelper.hasFinalApproved(workflow) && ceCaseInfringement.getOutcome() == null) {
				// // ceCaseHelper.processRecommendationOutcome(Lists.newArrayList(recomm), ceCase);
				// ceCaseHelper.processRecommendationDirectOutcome(Lists.newArrayList(recomm), ceCase);
				// ceCaseHelper.processRecommendationOutcome(Lists.newArrayList(recomm), ceCase);
				// ceTaskHelper.completeCeTaskByCeCase(ceCase, false);
				// tatiCheck.setIsAcknowledged(Boolean.TRUE);
				// tatiCheck.setLastAcknowledgedBy(getUser());
				// tatiCheck.setLastAcknowledgedDate(LocalDate.now());
				// ceTaCheckRepository.save(tatiCheck);
				// }
				// });
			}
		});
		logger.info("Batch acknowledge completed");
	}

	private CeTaCheck updateCeCheckValues(CeTaCheck model, CeTaCheckDto dto, CeTaCheckScheduleItem ceTaCheckScheduleItem) {
		model.setUpdatedDate(LocalDateTime.now());
		model.setCeTaCheckScheduleItem(ceTaCheckScheduleItem);
		Address addModel = null;
		if (dto.getTaDetailsDto().getAddressDto().getAddressId() != null) {
			addModel = ceTaCheckRepository.get(Address.class, dto.getTaDetailsDto().getAddressDto().getAddressId());
			addModel = AddressDto.buildAddressDtoToModel(cache, dto.getTaDetailsDto().getAddressDto(), addModel);
		} else {
			addModel = AddressDto.buildAddressDtoToModel(cache, dto.getTaDetailsDto().getAddressDto(), new Address());
		}
		ceTaCheckRepository.saveOrUpdate(addModel);
		if (dto.getToRevisit() != null) {
			model.getCeTaCheckScheduleItem().setToRevisit(dto.getToRevisit());
		}
		model.setAddress(addModel);
		model.setAddressType(cache.getType(dto.getTaDetailsDto().getAddressType().getKey().toString()));
		model.setLicenceNo(dto.getTaDetailsDto().getLicenceNo());
		model.setUen(dto.getTaDetailsDto().getUen());
		model.setTaName(dto.getTaDetailsDto().getTaName());
		model.setTaKeUin(dto.getTaDetailsDto().getTaKeUin());
		model.setTaKeName(dto.getTaDetailsDto().getTaKeName());
		model.setTaStaffName(dto.getTaStaffName());
		model.setTaStaffDesignation(dto.getTaStaffDesignation());
		model.setCheckedDate(dto.getCheckedDate());
		model.setRemarks(dto.getRemarks());
		model.setEoUser(ceTaCheckRepository.get(User.class, dto.getEoUserDto().getId()));
		model.setAuxEoUser(cache.getType(dto.getAuxEo().getKey().toString()));
		model.setRemarks(dto.getRemarks());
		if (dto.getFiles().size() > 0) {
			List<Integer> fileIds = dto.getFiles().parallelStream().map(AttachmentDto::getId).collect(Collectors.toList());
			if (fileIds.size() > 0) {
				List<File> files = fileRepository.getFiles(fileIds);
				model.setFiles(new HashSet<>(files));
			}
		}
		if (dto.getToSubmit()) {
			model.setIsDraft(Boolean.FALSE);
			// if (model.getIsAcknowledged()) { // To cater for resubmit
			// model.setIsAcknowledged(Boolean.FALSE);
			// model.setLastAcknowledgedBy(null);
			// model.setLastAcknowledgedDate(null);
			// }
		} else {
			model.setIsDraft(Boolean.TRUE);
		}

		ceTaCheckRepository.saveOrUpdate(model);

		ceTaCheckScheduleItem.setCeTaCheck(model);
		ceTaCheckRepository.saveOrUpdate(ceTaCheckScheduleItem);

		List<CeTaCheckQnResponse> qnResponses = new ArrayList<CeTaCheckQnResponse>();
		for (CeTaCheckQnReponseDto row : dto.getCeTaCheckQnResponseGeneralDto()) {
			CeTaCheckQnResponse responseModel = new CeTaCheckQnResponse();
			if (row.getCeTaCheckResponseId() != null) {
				responseModel = ceTaCheckRepository.get(CeTaCheckQnResponse.class, row.getCeTaCheckResponseId());
			}
			qnResponses.add(CeTaCheckQnReponseDto.buildReponseDtoToModel(responseModel, row, ceTaCheckRepository.get(CeTaCheckQn.class, row.getCeTaCheckQnId()), model));
		}
		for (CeTaCheckQnReponseDto row : dto.getCeTaCheckQnResponseDto()) {
			CeTaCheckQnResponse responseModel = new CeTaCheckQnResponse();
			if (row.getCeTaCheckResponseId() != null) {
				responseModel = ceTaCheckRepository.get(CeTaCheckQnResponse.class, row.getCeTaCheckResponseId());
			}
			qnResponses.add(CeTaCheckQnReponseDto.buildReponseDtoToModel(responseModel, row, ceTaCheckRepository.get(CeTaCheckQn.class, row.getCeTaCheckQnId()), model));
		}
		ceTaCheckRepository.save(qnResponses);

		List<CeTaCheckDocument> docs = new ArrayList<CeTaCheckDocument>();
		for (CeTaCheckDocumentDto row : dto.getCeTaCheckDocumentDto()) {
			CeTaCheckDocument docModel = new CeTaCheckDocument();
			if (row.getId() != null) {
				docModel = ceTaCheckRepository.get(CeTaCheckDocument.class, row.getId());
			}
			if (row.isValid(row)) {
				docs.add(CeTaCheckDocumentDto.buildDocumentDtoToModel(fileHelper, fileRepository, cache, row, docModel, model));
			}
		}
		if (docs.size() > 0) {
			ceTaCheckRepository.save(docs);
		}

		fileHelper.softDeleteFileList(dto.getFilesToDelete());

		List<Integer> checkDocDeleteList = dto.getCheckDocumentsToDelete();
		if (checkDocDeleteList != null && !checkDocDeleteList.isEmpty()) {
			for (Integer id : checkDocDeleteList) {
				if (id != null) {
					CeTaCheckDocument checkDoc = ceTaCheckRepository.get(CeTaCheckDocument.class, id);
					if (checkDoc.getFiles() != null) {
						ceTaCheckRepository.delete(checkDoc.getFiles());
					}
					ceTaCheckRepository.delete(checkDoc);
				}
			}
		}
		ceTaCheckRepository.saveOrUpdate(model.getCeTaCheckScheduleItem());
		return model;
	}

	private Type checkTaCompliant(CeTaCheckDto dto) {
		String isCompliant = null;
		Collections.sort(dto.getCeTaCheckQnResponseGeneralDto(), Comparator.comparing(CeTaCheckQnReponseDto::getOrdinal));
		Collections.sort(dto.getCeTaCheckQnResponseDto(), Comparator.comparing(CeTaCheckQnReponseDto::getOrdinal));
		// Check if TA is compliant or not, this is hard code logic as required by user if the questions order are changed, this need to be changed too
		if ((!dto.getCeTaCheckQnResponseGeneralDto().get(0).getIsYes() && !dto.getCeTaCheckQnResponseGeneralDto().get(1).getIsYes()) || !dto.getCeTaCheckQnResponseGeneralDto().get(0).getIsYes()) {
			// If question 1 is NO and question 1 and 2 is No. The result will be informed to HOD and the outcome is Not applicable.
			isCompliant = FLAGS.FLAG_NA;
		} else {
			if (dto.getCeTaCheckQnResponseDto().stream().anyMatch(row -> (row.getOrdinal() != 9 && row.getOrdinal() != 10) && !row.getIsYes())
					|| (dto.getCeTaCheckQnResponseGeneralDto().get(2).getIsYes() && dto.getCeTaCheckQnResponseDto().get(5).getIsYes() && !dto.getCeTaCheckQnResponseDto().get(6).getIsYes())) {
				isCompliant = FLAGS.FLAG_N;
			}
			if ((Strings.isNullOrEmpty(isCompliant) || isCompliant.equalsIgnoreCase(FLAGS.FLAG_Y)) && dto.getCeTaCheckDocumentDto().size() > 0) {
				if (dto.getCeTaCheckDocumentDto().stream().anyMatch(row -> row.getIsConsumerInformedCode().equals(FLAGS.FLAG_N))) {
					isCompliant = FLAGS.FLAG_N;
				} else {
					isCompliant = FLAGS.FLAG_Y;
				}
			}
		}
		return cache.getType(isCompliant);
	}

}
