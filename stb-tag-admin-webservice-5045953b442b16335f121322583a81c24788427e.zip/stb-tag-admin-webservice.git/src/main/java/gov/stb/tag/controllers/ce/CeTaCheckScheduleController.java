package gov.stb.tag.controllers.ce;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.ta.schedule.CeTaCheckScheduleDto;
import gov.stb.tag.dto.ce.ta.schedule.CeTaCheckScheduleItemDto;
import gov.stb.tag.dto.ce.ta.schedule.CeTaCheckScheduleSearchTaDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckSchedule;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.User;
import gov.stb.tag.model.ViewCeTaCheckSchedulableItem;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ce.CeTaCheckScheduleRepository;

@RestController
@RequestMapping(path = "/api/v1/ce/ta-check-schedules")
@Transactional
public class CeTaCheckScheduleController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTaCheckScheduleRepository ceTaCheckScheduleRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;

	// to search TA
	@RequestMapping(value = "/search-ta/{toPaginate}", method = RequestMethod.GET)
	public ResultDto<ViewCeTaCheckSchedulableItem> searchTas(CeTaCheckScheduleSearchTaDto searchDto, @PathVariable String toPaginate) {
		ResultDto<ViewCeTaCheckSchedulableItem> taResultDto = ceTaCheckScheduleRepository.getTaList(searchDto, "true".equalsIgnoreCase(toPaginate));

		Object[] finalRecords = new Object[taResultDto.getRecords().length];
		var i = 0;
		for (ViewCeTaCheckSchedulableItem schedulableItem : taResultDto.getModels()) {
			var dto = CeTaCheckScheduleItemDto.buildFromSchedulableItem(cache, schedulableItem);
			finalRecords[i] = dto;
			i++;
		}
		taResultDto.setRecords(finalRecords);
		return taResultDto;
	}

	@RequestMapping(path = { "/view/{year}/{month}", "/view" }, method = RequestMethod.GET)
	public CeTaCheckScheduleDto loadSchedule(@PathVariable(required = false) Integer year, @PathVariable(required = false) Integer month) {
		if (year == null && month == null) {
			LocalDate nextMonth = LocalDate.now().plusMonths(1);
			year = nextMonth.getYear();
			month = nextMonth.getMonthValue();
		}
		CeTaCheckSchedule schedule = ceTaCheckScheduleRepository.getTaCheckSchedule(year, month);
		if (schedule != null) {
			return CeTaCheckScheduleDto.buildFromCeTaCheckSchedule(cache, workflowHelper, schedule, userRepository.getUserByLoginId(schedule.getCreatedBy()));
		} else {
			LocalDate lastDayOfMonth = LocalDate.of(year, month, 1).plusMonths(1).minusDays(1);
			if (LocalDate.now().isAfter(lastDayOfMonth)) {
				throw new ValidationException("Please select a future month to create new schedule.");
			}
			return CeTaCheckScheduleDto.buildNewCeTaCheckSchedule(year, month);
		}
	}

	// to save schedule
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveSchedule(@RequestBody CeTaCheckScheduleDto dto) {

		if (dto.getId() == null) {
			CeTaCheckSchedule schedule = ceTaCheckScheduleRepository.getTaCheckSchedule(dto.getYear(), dto.getMonth());
			if (schedule == null) {
				// save new
				schedule = new CeTaCheckSchedule();
				schedule = saveSchedule(schedule, dto, false);
			} else {
				throw new ValidationException("Schedule already created. Please refresh the page and try again.");
			}

			ceTaskHelper.createOrUpdateCeTaskForCeCheckScheduleWorkflow(schedule, null);

		} else {
			// update
			CeTaCheckSchedule schedule = ceTaCheckScheduleRepository.get(CeTaCheckSchedule.class, dto.getId());
			schedule = ceTaCheckScheduleRepository.get(CeTaCheckSchedule.class, dto.getId());
			schedule = saveSchedule(schedule, dto, false);
			if (schedule.getWorkflow() != null) {
				Workflow workflow = schedule.getWorkflow();
				workflowHelper.edit(workflow, dto.getInternalRemarks());
			}

			ceTaskHelper.createOrUpdateCeTaskForCeCheckScheduleWorkflow(schedule, null);
		}
	}

	// to submit, approve, route-back
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody CeTaCheckScheduleDto dto, @PathVariable String action, @PathVariable Integer id) {
		CeTaCheckSchedule schedule = ceTaCheckScheduleRepository.get(CeTaCheckSchedule.class, dto.getId());

		saveSchedule(schedule, dto, ACTION_APPROVE.equals(action));

		switch (action) {
		case ACTION_SUBMIT: // submit for approval

			if (schedule.getWorkflow() == null) {
				// first submission, save new workflow
				Workflow workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.CE_WKFLW_TA_SCHEDULE, dto.getInternalRemarks(), null, null, true, null, dto.getSupporterId(), dto.getApproverId());
				schedule.setWorkflow(workflow);
			} else {
				// re-submission
				workflowHelper.forward(schedule.getWorkflow(), true, dto.getInternalRemarks(), dto.getSupporterId(), dto.getApproverId(), false, dto.getFiles());
			}

			ceTaskHelper.createOrUpdateCeTaskForCeCheckScheduleWorkflow(schedule, null);

			break;
		case ACTION_APPROVE:
			workflowHelper.forward(schedule.getWorkflow(), false, dto.getInternalRemarks(), null, null, false, dto.getFiles());

			// delete last approved, and snapshot a new set of approved schedule items
			List<CeTaCheckScheduleItem> lastApprovedItems = schedule.getCeTaCheckScheduleItems().stream().filter(item -> item.isApproved() && !item.isDeleted()).collect(Collectors.toList());
			for (CeTaCheckScheduleItem lastApprovedItem : lastApprovedItems) {
				if (lastApprovedItem.isEditable()) {
					logger.info("Set approved CeTaCheckScheduleItem(id={}, scheduledDate={}) as deleted", lastApprovedItem.getId(), lastApprovedItem.getScheduledDate());
					lastApprovedItem.setIsDeleted(true);
					ceTaCheckScheduleRepository.save(lastApprovedItem);
				}
			}

			List<CeTaCheckScheduleItem> confirmedItems = schedule.getCeTaCheckScheduleItems().stream().filter(item -> !item.isApproved() && !item.isDeleted()).collect(Collectors.toList());
			for (CeTaCheckScheduleItem confirmedItem : confirmedItems) {
				if (confirmedItem.isEditable()) {
					logger.info("Creating new CeTaCheckScheduleItem for approved, snaphot from confirmed CeTaCheckScheduleItem(id={}, scheduledDate={})", confirmedItem.getId(),
							confirmedItem.getScheduledDate());
					snapshotApprovedCeTaCheckScheduleItem(confirmedItem);
				}
			}

			ceTaskHelper.completeCeTaskByScheduleMonth(schedule.getYear(), schedule.getMonth());

			break;
		case ACTION_ROUTE:
			User oic = userRepository.getUserByLoginId(schedule.getCreatedBy());
			workflowHelper.rfa(schedule.getWorkflow(), Codes.Statuses.CE_WKFLW_ROUTED, dto.getInternalRemarks(), dto.getExternalRemarks(), dto.getRecommendationCode(), dto.getFiles(),
					dto.getFileDescription(), oic.getId());

			ceTaskHelper.createOrUpdateCeTaskForCeCheckScheduleWorkflow(schedule, null);

			break;
		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = ceTaCheckScheduleRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private CeTaCheckSchedule saveSchedule(CeTaCheckSchedule schedule, CeTaCheckScheduleDto dto, boolean isApproved) {

		List<CeTaCheckScheduleItem> scheduleItems = Lists.newArrayList();
		if (schedule.getId() == null) {
			logger.info("Creating new schedule for month: {}, year: {}", dto.getMonth(), dto.getYear());
			schedule = new CeTaCheckSchedule();
			schedule.setMonth(dto.getMonth());
			schedule.setYear(dto.getYear());
			ceTaCheckScheduleRepository.save(schedule);
		} else {
			scheduleItems = schedule.getCeTaCheckScheduleItems().stream().collect(Collectors.toList());
		}
		for (CeTaCheckScheduleItemDto scheduleItemDto : dto.getScheduleItems()) {
			if (scheduleItemDto.getId() != null) {
				logger.info("Updating existing CeTaCheckScheduleItem id={}", scheduleItemDto.getId());
				Optional<CeTaCheckScheduleItem> scheduleItemObj = scheduleItems.stream().filter(item -> scheduleItemDto.getId().equals(item.getId())).findFirst();
				CeTaCheckScheduleItem scheduleItem = scheduleItemObj.get();
				updateCeTaCheckScheduleItem(scheduleItem, scheduleItemDto);
				ceTaCheckScheduleRepository.save(scheduleItem);
			} else {
				logger.info("Creating new CeTaCheckScheduleItem");
				CeTaCheckScheduleItem scheduleItem = new CeTaCheckScheduleItem();
				scheduleItem.setCeTaCheckSchedule(schedule);
				setCeTaCheckScheduleItemFromDto(scheduleItem, scheduleItemDto);
				ceTaCheckScheduleRepository.save(scheduleItem);
				if (CollectionUtils.isEmpty(schedule.getCeTaCheckScheduleItems())) {
					schedule.setCeTaCheckScheduleItems(Sets.newHashSet());
				}
				schedule.getCeTaCheckScheduleItems().add(scheduleItem);
			}
		}
		for (Integer tobeDeletedId : dto.getScheduleItemsTobeDeleted()) {
			CeTaCheckScheduleItem tobeDeleted = ceTaCheckScheduleRepository.get(CeTaCheckScheduleItem.class, tobeDeletedId);
			tobeDeleted.setIsDeleted(true);// soft delete
			ceTaCheckScheduleRepository.save(tobeDeleted);
		}

		return schedule;
	}

	private void setCeTaCheckScheduleItemFromDto(CeTaCheckScheduleItem scheduleItem, CeTaCheckScheduleItemDto dto) {
		ViewCeTaCheckSchedulableItem schedulableItem = ceTaCheckScheduleRepository.getTaCheckSchedulableItem(dto.getAddressId());
		Address address = ceTaCheckScheduleRepository.get(Address.class, dto.getAddressId());
		scheduleItem.setAddress(address);
		if (scheduleItem.getId() == null) {
			scheduleItem.setAddressType(cache.getType(schedulableItem.getAddressTypeCode()));
			scheduleItem.setLastAaFilingFyEndDate(schedulableItem.getLastAaFilingFyEndDate());
			scheduleItem.setLastAaFilingStatus(cache.getStatus(schedulableItem.getLastAaFilingStatusCode()));
			scheduleItem.setLastTatiCheck(dto.getLastTatiCheckId() != null ? ceTaCheckScheduleRepository.get(CeTaCheck.class, dto.getLastTatiCheckId()) : null);
			scheduleItem.setLicence(ceTaCheckScheduleRepository.get(Licence.class, schedulableItem.getLicenceId()));
			scheduleItem.setTaBranch(schedulableItem.getTaBranchId() != null ? ceTaCheckScheduleRepository.get(TaBranch.class, schedulableItem.getTaBranchId()) : null);
			scheduleItem.setLicenceCeasedDate(schedulableItem.getLicenceCeasedDate());
			scheduleItem.setLicenceExpiryDate(schedulableItem.getLicenceExpiryDate());
			scheduleItem.setLicenceStatus(cache.getStatus(schedulableItem.getLicenceStatusCode()));
			scheduleItem.setNoOfReds(schedulableItem.getNoOfReds());
			scheduleItem.setTaName(schedulableItem.getTaName());
			scheduleItem.setBranchStatus(cache.getStatus(schedulableItem.getBranchStatusCode()));
			scheduleItem.setServiceType(cache.getType(schedulableItem.getServiceTypeCode()));
			scheduleItem.setIsApproved(Boolean.FALSE);
			scheduleItem.setIsDeleted(Boolean.FALSE);
		}
		updateCeTaCheckScheduleItem(scheduleItem, dto);
	}

	private void updateCeTaCheckScheduleItem(CeTaCheckScheduleItem scheduleItem, CeTaCheckScheduleItemDto dto) {
		scheduleItem.setCheckType(dto.getCheckType().getKey() != null ? cache.getType(dto.getCheckType().getKey().toString()) : null);
		scheduleItem.setAuxEoUser(dto.getAuxEo().getKey() != null ? cache.getType(dto.getAuxEo().getKey().toString()) : null);
		scheduleItem.setEoUser(dto.getEo().getKey() != null ? ceTaCheckScheduleRepository.get(User.class, dto.getEo().getKey()) : null);
		scheduleItem.setScheduledDate(dto.getScheduledDate());
	}

	private void snapshotApprovedCeTaCheckScheduleItem(CeTaCheckScheduleItem scheduleItem) {
		CeTaCheckScheduleItem approvedScheduleItem = new CeTaCheckScheduleItem();
		approvedScheduleItem.setCeTaCheckSchedule(scheduleItem.getCeTaCheckSchedule());
		approvedScheduleItem.setAddress(snapshotAsNewAddress(scheduleItem.getAddress()));
		approvedScheduleItem.setIsApproved(true);
		approvedScheduleItem.setAddressType(scheduleItem.getAddressType());
		approvedScheduleItem.setLastAaFilingFyEndDate(scheduleItem.getLastAaFilingFyEndDate());
		approvedScheduleItem.setLastAaFilingStatus(scheduleItem.getLastAaFilingStatus());
		approvedScheduleItem.setLastTatiCheck(scheduleItem.getLastTatiCheck());
		approvedScheduleItem.setLicence(scheduleItem.getLicence());
		approvedScheduleItem.setTaBranch(scheduleItem.getTaBranch());
		approvedScheduleItem.setLicenceCeasedDate(scheduleItem.getLicenceCeasedDate());
		approvedScheduleItem.setLicenceExpiryDate(scheduleItem.getLicenceExpiryDate());
		approvedScheduleItem.setLicenceStatus(scheduleItem.getLicenceStatus());
		approvedScheduleItem.setNoOfReds(scheduleItem.getNoOfReds());
		approvedScheduleItem.setTaName(scheduleItem.getTaName());
		approvedScheduleItem.setBranchStatus(scheduleItem.getBranchStatus());
		approvedScheduleItem.setServiceType(scheduleItem.getServiceType());
		approvedScheduleItem.setCheckType(scheduleItem.getCheckType());
		approvedScheduleItem.setAuxEoUser(scheduleItem.getAuxEoUser());
		approvedScheduleItem.setEoUser(scheduleItem.getEoUser());
		approvedScheduleItem.setScheduledDate(scheduleItem.getScheduledDate());
		ceTaCheckScheduleRepository.save(approvedScheduleItem);

		scheduleItem.setLastApprovedCeTaCheckScheduleItem(approvedScheduleItem);
		ceTaCheckScheduleRepository.save(scheduleItem);

	}

	private Address snapshotAsNewAddress(Address address) {
		Address checkedAddress = new Address();
		checkedAddress.setAddressType(address.getAddressType());
		checkedAddress.setBlock(address.getBlock());
		checkedAddress.setBuilding(address.getBuilding());
		checkedAddress.setFloor(address.getFloor());
		checkedAddress.setForeignLine1(address.getForeignLine1());
		checkedAddress.setForeignLine2(address.getForeignLine2());
		checkedAddress.setForeignLine3(address.getForeignLine3());
		checkedAddress.setPostal(address.getPostal());
		checkedAddress.setPremiseType(address.getPremiseType());
		checkedAddress.setStreet(address.getStreet());
		checkedAddress.setUnit(address.getUnit());
		ceTaCheckScheduleRepository.save(checkedAddress);
		return checkedAddress;
	}
}
