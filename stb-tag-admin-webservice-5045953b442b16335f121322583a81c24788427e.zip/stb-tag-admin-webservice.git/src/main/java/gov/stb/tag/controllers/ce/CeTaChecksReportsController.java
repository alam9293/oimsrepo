package gov.stb.tag.controllers.ce;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes.AddressType;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportItemDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportPersonDetailsDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportTaDetailsDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportsSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.TaCommonRepository;
import gov.stb.tag.repository.ce.CeTaChecksReportsRepository;

@RestController
@RequestMapping(path = "/api/v1/ce/ta-checks-reports")
@Transactional
public class CeTaChecksReportsController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTaChecksReportsRepository ceTaChecksReportsRepository;
	@Autowired
	TaCommonRepository taCommonRepository;

	// to retrieve all scheduled Tas
	@RequestMapping(method = RequestMethod.GET, value = "/list")
	public ResultDto<CeTaCheckReportItemDto> getList(CeTaCheckReportsSearchDto searchDto) {
		User currentUser = ceTaChecksReportsRepository.getLicenseeUserByUserId(getUser().getId());
		ResultDto<CeTaCheckScheduleItem> result = ceTaChecksReportsRepository.getCeTaScheduleChecks(searchDto, getUser().getId());

		ResultDto<CeTaCheckReportItemDto> resultDto = new ResultDto<CeTaCheckReportItemDto>();

		resultDto.setTotal(result.getTotal());
		resultDto.setResult(result.getResult());
		resultDto.setSuccessFlag(result.getSuccessFlag());
		Object[] records = new Object[result.getModels().size()];
		resultDto.setRecords(records);
		int i = 0;
		if (result.getModels().size() > 0) {
			for (CeTaCheckScheduleItem row : result.getModels()) {
				CeTaCheckReportItemDto dto = CeTaCheckReportItemDto.buildItemDto(cache, row, currentUser.getLoginId());
				records[i++] = dto;
			}
		}

		return resultDto;
	}

	// to search ta details by licence number
	@RequestMapping(path = { "/search/ta-details/{licenceNo}" }, method = RequestMethod.GET)
	public CeTaCheckReportTaDetailsDto getTaDetailsFromLicenceNo(@PathVariable String licenceNo) {

		CeTaCheckReportTaDetailsDto resultDto = new CeTaCheckReportTaDetailsDto();
		logger.info("Search data for licence no: {}", licenceNo);
		Licence licModel = ceTaChecksReportsRepository.getLicenceFromLicNo(licenceNo);

		if (licModel != null) {
			resultDto.setLicenceNo(licenceNo);
			if (licModel.getTravelAgent() != null) {
				resultDto.setUen(licModel.getTravelAgent().getUen());
				resultDto.setTaName(licModel.getTravelAgent().getName());
				resultDto.setTaContactNo(licModel.getTravelAgent().getContactNo());
				if (licModel.getTravelAgent().getOperatingAddress() != null) {
					resultDto.setAddressType(new ListableDto(cache.getType(AddressType.TA_ADDR_OP)));
					resultDto.setAddressDto(AddressDto.buildFromAddress(cache, licModel.getTravelAgent().getOperatingAddress()));
				} else if (licModel.getTravelAgent().getRegisteredAddress() != null) {
					resultDto.setAddressType(new ListableDto(cache.getType(AddressType.TA_ADDR_REG)));
					resultDto.setAddressDto(AddressDto.buildFromAddress(cache, licModel.getTravelAgent().getOperatingAddress()));
				}
				logger.info("Found TA details: {}", licModel.getTravelAgent().getUen());
			}
			Stakeholder keDetails = taCommonRepository.getExistingKe(licModel.getId());
			if (keDetails != null) {
				resultDto.setTaKeUin(keDetails.getUin());
				resultDto.setTaKeName(keDetails.getName());
				logger.info("Found KE details id: {}", keDetails.getId());
			}

		} else {
			throw new ValidationException("TA details not found in TRUST");
		}

		return resultDto;
	}

	// to search person details by uin
	@RequestMapping(path = { "/search/person-details/{uin}" }, method = RequestMethod.GET)
	public CeTaCheckReportPersonDetailsDto getPersonDetailsFromUin(@PathVariable String uin) {

		CeTaCheckReportPersonDetailsDto resultDto = new CeTaCheckReportPersonDetailsDto();
		logger.info("Search person for uin: {}", uin);
		Stakeholder shModel = ceTaChecksReportsRepository.getTastakeholderFromUin(uin);
		if (shModel != null) {
			logger.info("Found person stkh id: {}", shModel.getId());
			resultDto.setUinPassportNo(shModel.getUin());
			resultDto.setName(shModel.getName());
			resultDto.setPersonContactNo(shModel.getContactNo());
			// resultDto.setNationality(new ListableDto(shModel.getNationality()));
			List<ListableDto> roles = ceTaChecksReportsRepository.getPersonRoleFromUin(shModel.getUin());

			if (roles.size() > 0) {
				resultDto.setRole(String.join(", ", roles.parallelStream().map(ListableDto::getLabel).collect(Collectors.toList())));
			}

		} else {
			throw new ValidationException("Person details not found in TRUST");
		}

		return resultDto;
	}
}
