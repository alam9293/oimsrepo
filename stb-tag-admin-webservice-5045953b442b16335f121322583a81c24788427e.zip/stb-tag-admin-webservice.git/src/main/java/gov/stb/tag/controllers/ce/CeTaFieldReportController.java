package gov.stb.tag.controllers.ce;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.CeSubmissionStatus;
import gov.stb.tag.constant.Codes.SignDocResults;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ce.ta.tafieldreport.CeTaFieldReportDto;
import gov.stb.tag.dto.ce.ta.tafieldreport.CeTaFieldReportSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.signdoc.CeTaFieldReportPdfHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTaFieldReport;
import gov.stb.tag.model.File;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.CeCaseRepository;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.TaCommonRepository;
import gov.stb.tag.repository.ce.CeTaCheckRepository;
import gov.stb.tag.repository.ce.CeTaFieldReportRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ce/ta-field-report")
@Transactional
public class CeTaFieldReportController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTaCheckRepository ceTaCheckRepository;
	@Autowired
	TaCommonRepository taCommonRepository;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	CeCaseRepository ceCaseRepository;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	CeTaFieldReportRepository ceTaFieldReportRepository;

	@Autowired
	CeTaFieldReportPdfHelper ceTaFieldReportPdfHelper;

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public CeTaFieldReportDto loadTaFieldReport(CeTaFieldReportSearchDto searchDto) {
		CeTaFieldReportDto resultDto = new CeTaFieldReportDto();
		User currentUser = ceTaCheckRepository.getLicenseeUserByUserId(getUser().getId());
		if (searchDto.getCeTaFieldReportId() != null) {
			logger.info("Get ceTaFieldReport for id: {}", searchDto.getCeTaFieldReportId());
			resultDto = CeTaFieldReportDto.buildFieldReportDtoFromFieldReportModel(cache, ceTaCheckRepository.get(CeTaFieldReport.class, searchDto.getCeTaFieldReportId()), resultDto, userRepository);
		} else if (searchDto.getCeTaCheckScheduleItemId() != null) {
			logger.info("Get ceTaFieldReport for ceTaCheckScheduleId: {}", searchDto.getCeTaCheckScheduleItemId());
			CeTaFieldReport fieldReport = ceTaFieldReportRepository.getFieldReportFromScheduleItem(searchDto.getCeTaCheckScheduleItemId());
			if (fieldReport != null) {
				logger.info("Found existing ceTaFieldReport with id: {}", fieldReport.getId());
				resultDto = CeTaFieldReportDto.buildFieldReportDtoFromFieldReportModel(cache, fieldReport, resultDto, userRepository);
			} else {
				logger.info("No existing ceTaFieldReport, create new");
				resultDto = CeTaFieldReportDto.buildNewFieldReportDto(cache, ceTaCheckRepository.get(CeTaCheckScheduleItem.class, searchDto.getCeTaCheckScheduleItemId()), resultDto, currentUser);
			}
		} else if (searchDto.getCeCaseId() != null) {
			logger.info("Create new field report for case id : {}", searchDto.getCeCaseId());
			resultDto = CeTaFieldReportDto.buildNewFieldReportDto(cache, null, resultDto, currentUser);
			resultDto.setCeCaseId(ceTaCheckRepository.get(CeCase.class, searchDto.getCeCaseId()).getId());
			resultDto.setCaseNo(ceTaCheckRepository.get(CeCase.class, searchDto.getCeCaseId()).getCaseNo());
		}

		if (resultDto.getSubmissionStatus().getKey() != null && (resultDto.getSubmissionStatus().getKey().toString().equalsIgnoreCase(CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED)
				|| (!Strings.isNullOrEmpty(resultDto.getCreatedBy()) && !resultDto.getCreatedBy().equalsIgnoreCase(currentUser.getName())))) {
			resultDto.setDisableEdit(true);
			logger.info("Do not allow ceTaFieldReport to be edited");
		}
		return resultDto;
	}

	// to create/update ta check report
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public CeTaFieldReportSearchDto saveTaFieldReport(@RequestBody CeTaFieldReportDto dto) {
		CeTaFieldReport model = new CeTaFieldReport();
		CeTaCheckScheduleItem ceTaCheckScheduleItem = null;
		CeCase ceCaseModel = null;
		CeTaFieldReportSearchDto searchDto = new CeTaFieldReportSearchDto();
		if (dto.getCeTaFieldReportId() != null) { // Get current report for update
			logger.info("Update existing ceTaFieldReport with id: {}", dto.getCeTaFieldReportId());
			model = ceTaCheckRepository.get(CeTaFieldReport.class, dto.getCeTaFieldReportId());
		}
		if (dto.getCeTaCheckScheduleItemId() != null) { // Get schedule item to tie to
			logger.info("Create new ceTaCheck with scheduleId: {}", dto.getCeTaCheckScheduleItemId());
			ceTaCheckScheduleItem = ceTaCheckRepository.get(CeTaCheckScheduleItem.class, dto.getCeTaCheckScheduleItemId());
		}
		if (!Strings.isNullOrEmpty(dto.getCaseNo())) {
			logger.info("Map field report with caseNo: {}", dto.getCaseNo());
			ceCaseModel = ceCaseRepository.getCaseFromCaseNo(dto.getCaseNo());
			if (ceCaseModel == null) {
				throw new ValidationException("The case number entered is not found in TRUST");
			}
		}

		if (ceTaCheckScheduleItem == null) {
			if (dto.getCeCaseId() != null) {
				// means the report is added from a case
				logger.info("Field report created from case id : {}", dto.getCeCaseId());
				ceCaseModel = ceTaCheckRepository.get(CeCase.class, dto.getCeCaseId());
			}
		}

		model = updateCeFieldReportValues(model, dto, ceTaCheckScheduleItem);
		if (dto.getAttachments().size() > 0) {
			List<Integer> fileIds = dto.getAttachments().parallelStream().map(FileDto::getId).collect(Collectors.toList());
			if (fileIds.size() > 0) {
				List<File> files = fileRepository.getFiles(fileIds);
				model.setFiles(new HashSet<>(files));
			}
		}
		List<Integer> toDeleteList = dto.getDeletedAttachements();
		if (toDeleteList != null && !toDeleteList.isEmpty()) {
			for (Integer id : toDeleteList) {
				if (id != null) {
					File attachemnt = new File();
					attachemnt = fileHelper.getFile(id);
					if (attachemnt != null) {
						fileHelper.deleteFile(attachemnt);
					}
				}
			}
		}
		// Only update the description in the files
		updateFiles(dto.getAttachments());

		if (model.getCeTaCheckScheduleItem() != null) {
			ceTaCheckRepository.saveOrUpdate(model.getCeTaCheckScheduleItem());
		}
		ceTaCheckRepository.saveOrUpdate(model);
		logger.info("Field report saved");
		if (ceCaseModel != null) {
			ceCaseRepository.saveOrUpdate(ceCaseModel);
			searchDto.setCeCaseId(ceCaseModel.getId());
			logger.info("Case saved");
		}

		searchDto.setCeTaFieldReportId(model.getId());
		return searchDto;
	}

	// to submit ta field report with sign doc
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST }, value = "/submit/{ceFieldReportId}")
	public String updateSigndocPdf(@PathVariable Integer ceFieldReportId) {
		logger.info("Submit ta field report with id: {}", ceFieldReportId);
		CeTaFieldReport model = ceTaCheckRepository.get(CeTaFieldReport.class, ceFieldReportId);
		byte[] pdf = ceTaFieldReportPdfHelper.generatePdf(model);
		return ceTaFieldReportPdfHelper.preloadToSigndoc(pdf, properties.signdocCeTaFieldReportResultUrl + model.getId());
	}

	@RequestMapping(path = { "/submit/update-sign-doc-result" }, method = RequestMethod.POST)
	public void updateSignDocResult(@RequestBody CeTaFieldReportSearchDto searchDto) {
		CeTaFieldReport model = ceTaCheckRepository.get(CeTaFieldReport.class, searchDto.getCeTaFieldReportId());

		if (model.isDraft()) {
			logger.info("Status of sign doc submisison {}, ceTaFieldReportId: {}", searchDto.getSdweb_result(), model.getId());
			CeCase ceCaseModel = null;
			if (searchDto.getSdweb_result().equalsIgnoreCase(SignDocResults.SUCCESS)) {
				model.setSigndocId(searchDto.getSdweb_docid());
				model.setIsDraft(Boolean.FALSE);
				if (model.getCeTaCheckScheduleItem() != null) {
					// If field report is submitted via scheduled item, need to set the scheduled item last check done on which address type
					// and create ce case or link the field report into the reference case no
					ceCaseModel = model.getCeCase();
					if (ceCaseModel == null) {
						ceCaseModel = new CeCase();
						logger.info("Case not found.");
					} else {
						logger.info("Update case with caseId: ", ceCaseModel.getId());
					}
					CeTaCheckScheduleItem scheduleItem = model.getCeTaCheckScheduleItem();
					if (scheduleItem != null && !scheduleItem.toRevisit()) {
						if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_OP)) {
							scheduleItem.getLicence().getTravelAgent().setIsLastOpAddrCheckDone(Boolean.TRUE);
						} else if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_REG)) {
							scheduleItem.getLicence().getTravelAgent().setIsLastRegAddrCheckDone(Boolean.TRUE);
						} else if (Entities.equals(scheduleItem.getAddressType(), Codes.Types.TA_ADDR_BRANCH)) {
							if (scheduleItem.getTaBranch() != null) {
								scheduleItem.getTaBranch().setIsLastCheckDone(Boolean.TRUE);
							}
						}
						logger.info("Done snapshot the last check id : {}", model.getId());
					}
					model.setCeCase(ceCaseHelper.createNewCaseFromTaFieldReport(model, scheduleItem, ceCaseModel));
					logger.info("Update values for caseId : {}", model.getCeCase().getId());
				} else {
					// If report is submitted from case, update the report to tie to the case
					if (model.getCeCase() != null) {
						// means the report is added from a case
						ceCaseModel = ceTaCheckRepository.get(CeCase.class, model.getCeCase().getId());
						logger.info("Report added from caseId : {}", ceCaseModel.getId());
					}
					List<CeTaFieldReport> ceTaFieldReports = Arrays.asList(model);
					ceCaseModel.setCeTaFieldReports(new HashSet<>(ceTaFieldReports));
				}
			} else if (searchDto.getSdweb_result().equalsIgnoreCase(SignDocResults.CANCEL)) {
				logger.info("User cancel. Submission of sign doc not done for taCheckId: {}", model.getId());
			} else if (searchDto.getSdweb_result().equalsIgnoreCase(SignDocResults.ERROR)) {
				logger.error("ERROR Submission of sign doc for taCheckId: {}", model.getId());
				throw new ValidationException(DateUtil.format(LocalDateTime.now()) + " - Unable to archive signed document. Please contact administrator.");
			}
			if (ceCaseModel != null) {
				ceTaCheckRepository.saveOrUpdate(ceCaseModel);
			}
			ceTaCheckRepository.saveOrUpdate(model);
		}

	}

	private void updateFiles(List<FileDto> filesDto) {
		if (CollectionUtils.isNotEmpty(filesDto)) {
			List<File> files = fileRepository.getFiles(filesDto.stream().map(FileDto::getId).collect(Collectors.toList()));
			for (File file : files) {
				FileDto fDto = filesDto.stream().filter(u -> u.getId().equals(file.getId())).findFirst().get();
				file.setDescription(fDto.getDescription());
			}
		}
	}

	private CeTaFieldReport updateCeFieldReportValues(CeTaFieldReport model, CeTaFieldReportDto dto, CeTaCheckScheduleItem ceTaCheckScheduleItem) {
		if (ceTaCheckScheduleItem != null) {
			model.setCeTaCheckScheduleItem(ceTaCheckScheduleItem);
			if (dto.getToRevisit() != null) {
				model.getCeTaCheckScheduleItem().setToRevisit(dto.getToRevisit());
			}
		}

		model.setCrmRefNo(dto.getCrmRefNo());
		if (!Strings.isNullOrEmpty(dto.getCaseNo())) {
			model.setCeCase(ceCaseRepository.getCaseFromCaseNo(dto.getCaseNo()));
		}

		Address addModel = null;
		if (dto.getTaDetailsDto() != null) {
			if (dto.getTaDetailsDto().getAddressDto() != null && dto.getTaDetailsDto().getAddressDto().getAddressId() != null) {
				addModel = ceTaCheckRepository.get(Address.class, dto.getTaDetailsDto().getAddressDto().getAddressId());
				addModel = AddressDto.buildAddressDtoToModel(cache, dto.getTaDetailsDto().getAddressDto(), addModel);
			} else {
				addModel = AddressDto.buildAddressDtoToModel(cache, dto.getTaDetailsDto().getAddressDto(), new Address());
			}
			ceTaCheckRepository.saveOrUpdate(addModel);

			model.setAddress(addModel);
			if (dto.getTaDetailsDto().getAddressType() != null) {
				model.setAddressType(cache.getType(dto.getTaDetailsDto().getAddressType().getKey().toString()));
			}
			model.setLicenceNo(dto.getTaDetailsDto().getLicenceNo());
			model.setUen(dto.getTaDetailsDto().getUen());
			model.setTaName(dto.getTaDetailsDto().getTaName());
			model.setTaContactNo(dto.getTaDetailsDto().getTaContactNo());
		}

		if (dto.getPersonDetailsDto() != null) {
			model.setUinPassportNo(dto.getPersonDetailsDto().getUinPassportNo());
			model.setName(dto.getPersonDetailsDto().getName());
			model.setRole(dto.getPersonDetailsDto().getRole());
			model.setPersonContactNo(dto.getPersonDetailsDto().getPersonContactNo());
			// model.setNationality(cache.getType(dto.getPersonDetailsDto().getNationality().getKey().toString()));
		}

		model.setDetails(dto.getDetails());
		model.setWitness(cache.getType(dto.getAuxEo().getKey().toString()));
		model.setTaOfficerName(dto.getTravelAgentOfficerName());

		if (dto.getClassificationsSelected() != null && dto.getClassificationsSelected().length > 0) {
			model.setClassifications(new HashSet<>(ceTaCheckRepository.getTypes(dto.getClassificationsSelected(), Boolean.TRUE)));
		} else {
			model.setClassifications(null);
		}

		if (!Strings.isNullOrEmpty(dto.getOtherClassification())) {
			model.setOtherClassification(dto.getOtherClassification());
		} else {
			model.setOtherClassification(null);
		}

		if (dto.getToSubmit()) {
			model.setIsDraft(Boolean.FALSE);
		} else {
			model.setIsDraft(Boolean.TRUE);
		}

		return model;
	}

}
