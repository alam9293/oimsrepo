package gov.stb.tag.controllers.ce;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import gov.stb.tag.constant.Codes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.tg.checkreports.CeTgCheckReportItemDto;
import gov.stb.tag.dto.ce.tg.checkreports.CeTgCheckReportSearchDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeTgCheckSchedule;
import gov.stb.tag.model.CeTgCheckScheduleItemLocation;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ce.CeTgChecksReportsRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ce/tg-checks-reports")
@Transactional
public class CeTgCheckReportController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTgChecksReportsRepository ceTgChecksReportsRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;

	@RequestMapping(path = { "/list/get-years/" }, method = RequestMethod.GET)
	public List<ListableDto> getScheduledYears() {
		return ceTgChecksReportsRepository.getApprovedScheduledYears();
	}

	@RequestMapping(path = { "/list/get-weeks/{year}" }, method = RequestMethod.GET)
	public List<ListableDto> getScheduledWeeks(@PathVariable Integer year) {
		List<CeTgCheckSchedule> approvedSchedules = ceTgChecksReportsRepository.getApprovedScheduleByYear(year);
		List<ListableDto> scheduledWeeksList = new ArrayList<>();

		for (CeTgCheckSchedule schedule : approvedSchedules) {
			if (schedule.getFromDate() != null) {
				LocalDate fromDate = schedule.getFromDate();
				scheduledWeeksList.add(new ListableDto(fromDate, DateUtil.format(fromDate) + " to " + DateUtil.format(schedule.getToDate())));
			}
		}

		return scheduledWeeksList;
	}

	@RequestMapping(value = "/list/get-eos", method = RequestMethod.GET)
	public List<ListableDto> getEos() {
		return toListableDtos(userRepository.getActiveUsersByRole(Codes.Roles.TG_CNE_ENFORCEMENT_OFFICER));
	}

	// to retrieve all scheduled item locations
	@RequestMapping(method = RequestMethod.GET, value = "/list")
	public ResultDto<CeTgCheckReportItemDto> getList(CeTgCheckReportSearchDto searchDto) {
		ResultDto<CeTgCheckScheduleItemLocation> result = ceTgChecksReportsRepository.getCeTgScheduleItemLocations(searchDto);

		ResultDto<CeTgCheckReportItemDto> resultDto = new ResultDto<CeTgCheckReportItemDto>();
		resultDto.setTotal(result.getTotal());
		resultDto.setResult(result.getResult());
		resultDto.setSuccessFlag(result.getSuccessFlag());
		Object[] records = new Object[result.getModels().size()];
		resultDto.setRecords(records);
		int i = 0;
		if (result.getModels().size() > 0) {
			for (CeTgCheckScheduleItemLocation row : result.getModels()) {
				CeTgCheckReportItemDto dto = CeTgCheckReportItemDto.buildTgCheckReportItemDto(cache, row);
				records[i++] = dto;
			}
		}
		return resultDto;
	}

}
