package gov.stb.tag.controllers.ce;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import gov.stb.tag.model.*;
import gov.stb.tag.repository.ce.CeCaseInfringerRepository;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.CeSubmissionStatus;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.TravelAgentBasicDto;
import gov.stb.tag.dto.ce.cases.CeInfringementDto;
import gov.stb.tag.dto.ce.cases.CeRecommendationDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.dto.ce.tg.tgfieldreport.CeTgFieldReportDto;
import gov.stb.tag.dto.ce.tg.tgfieldreport.CeTgFieldReportTgDto;
import gov.stb.tag.dto.ce.tg.tgfieldreport.CeTgFieldReportTgInfringementDto;
import gov.stb.tag.dto.dashboard.UserProfileDto;
import gov.stb.tag.dto.workflow.WorkflowUserRoleDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.repository.CeCaseRepository;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ce.CeTgFieldReportRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.repository.tg.TgLicenceRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/ce/tg-field-report")
@Transactional
public class CeTgFieldReportController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CeTgFieldReportRepository ceTgFieldReportRepository;

	@Autowired
	CeCaseRepository ceCaseRepository;

	@Autowired
	CeCaseInfringerRepository ceCaseInfringerRepository;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	FileRepository fileRepository;

	@Autowired
	TgLicenceRepository tgLicenceRepository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	TravelAgentRepository travelAgentRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	TgHelper tgHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	WorkflowHelper workflowHelper;

	@RequestMapping(path = { "/view/new/{checkScheduleItemLocationId}" }, method = RequestMethod.GET)
	public CeTgFieldReportDto newTgFieldReport(@PathVariable Integer checkScheduleItemLocationId) {
		CeTgFieldReportDto resultDto = new CeTgFieldReportDto();
		Role selectedRole = userRepository.getRoleWithFunctions(getSelectedRoleCode());

		if (checkScheduleItemLocationId != null) {
			CeTgCheckScheduleItemLocation scheduleItemLocation = ceTgFieldReportRepository.get(CeTgCheckScheduleItemLocation.class, checkScheduleItemLocationId);

			if (!isEditable(scheduleItemLocation)) {
				logger.error("Unable to submit TG Field Report for ceTgCheckScheduleLocation.id={}. Schedule is pending approval.", checkScheduleItemLocationId);
				throw new ValidationException("Schedule is pending approval.");
			}
			if (scheduleItemLocation.getCeTgCheckScheduleItem().getScheduleDate().isAfter(LocalDate.now())) {
				logger.error("Unable to submit TG Field Report for ceTgCheckScheduleLocation.id={}. Schedule is in future date.", checkScheduleItemLocationId);
				throw new ValidationException("Schedule is in future date.");
			}

			resultDto = CeTgFieldReportDto.buildNewTgFieldReport(scheduleItemLocation);
			resultDto.setDisableEdit(!selectedRole.getFunctions().stream().filter(func -> func.getCode().equals(Codes.Permission.CE_TG_FIELD_REPORT_SAVE)).findFirst().isPresent());
		}
		return resultDto;
	}

	@RequestMapping(path = { "/view/{tgFieldReportId}" }, method = RequestMethod.GET)
	public CeTgFieldReportDto loadTgFieldReport(@PathVariable Integer tgFieldReportId) {
		CeTgFieldReportDto resultDto = new CeTgFieldReportDto();
		Role selectedRole = userRepository.getRoleWithFunctions(getSelectedRoleCode());
		Boolean hasSavePermission = selectedRole.getFunctions().stream().filter(func -> func.getCode().equals(Codes.Permission.CE_TG_FIELD_REPORT_SAVE)).findFirst().isPresent();

		if (tgFieldReportId != null) {
			CeTgFieldReport tgFieldReport = ceTgFieldReportRepository.get(CeTgFieldReport.class, tgFieldReportId);

			resultDto = CeTgFieldReportDto.buildDtoFromTgFieldReport(cache, tgFieldReport, resultDto, userRepository);
			if (resultDto.getStatus().getKey() != null && (resultDto.getStatus().getKey().toString().equalsIgnoreCase(CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED) || !hasSavePermission)) {
				resultDto.setDisableEdit(true);

				CeCase ceCase = ceCaseRepository.getCaseFromTgFieldReport(tgFieldReportId);
				if (ceCase != null) {
					resultDto.setCaseId(ceCase.getId());
					resultDto.setCaseNo(ceCase.getCaseNo());
				}
			}
		}

		return resultDto;
	}

	@RequestMapping(value = { "/view/past-infringements/{uin}" }, method = RequestMethod.GET)
	public List<CeInfringementDto> getPastInfringements(@PathVariable String uin) {
		List<CeInfringementDto> result = Lists.newArrayList();

		if (StringUtils.isNotBlank(uin)) {
			List<CeCaseInfringement> infringements = touristGuideRepository.getTgInfringements(uin);
			infringements.forEach(infringement -> {
				CeInfringementDto infringementDto = new CeInfringementDto(infringement.getCeCaseInfringer(), infringement, cache, true, ceCaseHelper);
				if (infringement.getLastRecommendation() != null) {
					infringementDto.setRecommendation(new CeRecommendationDto(infringement.getLastRecommendation(), cache, fileHelper, workflowHelper, null, false));
				}
				result.add(infringementDto);
			});
		}

		return result;
	}

	// to create/update tg field report
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveTgFieldReport(@RequestBody CeTgFieldReportDto dto) {
		CeTgFieldReport ceTgFieldReport = new CeTgFieldReport();
		CeTgCheckScheduleItemLocation scheduleItemLocation = new CeTgCheckScheduleItemLocation();
		Role selectedRole = userRepository.getRoleWithFunctions(getSelectedRoleCode());
		Boolean hasSavePermission = selectedRole.getFunctions().stream().filter(func -> func.getCode().equals(Codes.Permission.CE_TG_FIELD_REPORT_SAVE)).findFirst().isPresent();

		if (!hasSavePermission) {
			throw new ValidationException("You do not have permission to save/submit field report.");
		}

		if (dto.getCeTgFieldReportId() != null) {
			ceTgFieldReport = ceTgFieldReportRepository.get(CeTgFieldReport.class, dto.getCeTgFieldReportId());
		}

		if (dto.getCeTgCheckScheduleItemLocationId() != null) {
			scheduleItemLocation = ceTgFieldReportRepository.get(CeTgCheckScheduleItemLocation.class, dto.getCeTgCheckScheduleItemLocationId());
		}

		updateAttachments(dto.getFiles());
		updateTgFieldReportValues(ceTgFieldReport, dto, scheduleItemLocation);
		if (!ceTgFieldReport.isDraft()) {
			ceCaseHelper.createCaseForTgFieldReport(ceTgFieldReport);
		}

		return ceTgFieldReport.getId();
	}

	private CeTgFieldReport updateTgFieldReportValues(CeTgFieldReport ceTgFieldReport, CeTgFieldReportDto dto, CeTgCheckScheduleItemLocation scheduleItemLocation) {

		if (dto.getFiles().size() > 0) {
			List<Integer> fileIds = dto.getFiles().parallelStream().map(AttachmentDto::getId).collect(Collectors.toList());
			if (fileIds.size() > 0) {
				List<File> files = fileRepository.getFiles(fileIds);
				ceTgFieldReport.setFiles(new HashSet<>(files));
			}
		}

		if (dto.getToSubmit()) {
			ceTgFieldReport.setIsDraft(Boolean.FALSE);
		} else {
			ceTgFieldReport.setIsDraft(Boolean.TRUE);
		}

		if (dto.getInfringedTime() != null) {
			LocalDate infringedDate = scheduleItemLocation.getCeTgCheckScheduleItem().getScheduleDate();
			LocalTime infringedTime = LocalTime.parse(dto.getInfringedTime());
			ceTgFieldReport.setInfringedDate(LocalDateTime.of(infringedDate, infringedTime));
		}

		ceTgFieldReport.setDetails(dto.getDetails());
		ceTgFieldReport.setRemarks(dto.getRemarks());
		ceTgFieldReport.setEoUser(userRepository.getUserByLoginId(getUser().getLoginId()));
		ceTgFieldReport.setAoUser(dto.getApproverId() != null ? userRepository.get(User.class, dto.getApproverId()) : null);

		// ceTgFieldReportRepository.saveOrUpdate(ceTgFieldReport);

		// Save CeTgFieldReportTgs and infringement
		List<CeTgFieldReportTgInfringement> infringementList = new ArrayList<CeTgFieldReportTgInfringement>();
		List<CeTgFieldReportTg> tgList = new ArrayList<CeTgFieldReportTg>();

		for (CeTgFieldReportTgDto itemDto : dto.getTgDetailsDtos()) {
			CeTgFieldReportTg ceTgFieldReportTg = new CeTgFieldReportTg();
			Licence licence = null;
			if (itemDto.getCeTgFieldReportTgId() != null) {
				ceTgFieldReportTg = ceTgFieldReportRepository.get(CeTgFieldReportTg.class, itemDto.getCeTgFieldReportTgId());
			}

			if (itemDto.getLicenceId() != null) {
				licence = ceTgFieldReportRepository.load(Licence.class, itemDto.getLicenceId());
			}

			ceTgFieldReportTg = CeTgFieldReportTgDto.buildDtoToModel(cache, ceTgFieldReportTg, itemDto, ceTgFieldReport, licence);
			tgList.add(ceTgFieldReportTg);

			// save infringement
			for (CeTgFieldReportTgInfringementDto infringementDto : itemDto.getInfringements()) {
				CeTgFieldReportTgInfringement infringement = new CeTgFieldReportTgInfringement();
				if (infringementDto.getInfringementId() != null) {
					infringement = ceTgFieldReportRepository.get(CeTgFieldReportTgInfringement.class, infringementDto.getInfringementId());
				}

				infringement.setCeTgFieldReportTg(ceTgFieldReportTg);
				infringement
						.setCeProvision(infringementDto.getOffenceProvision().getId() != null ? ceTgFieldReportRepository.get(CeProvision.class, infringementDto.getOffenceProvision().getId()) : null);
				infringement
						.setReadWith(infringementDto.getReadWith() != null ? ceTgFieldReportRepository.get(CeProvision.class, infringementDto.getReadWith().getId()) : null);
				infringement.setRecommendedOutcome(
						infringementDto.getRecommendation() != null && infringementDto.getRecommendation().getKey() != null ? cache.getType(infringementDto.getRecommendation().getKey().toString())
								: null);

				infringementList.add(infringement);
			}
		}

		fileHelper.softDeleteFileList(dto.getFilesToDelete());

		for (Integer toDeleteId : dto.getDeletedTgDetailsDtos()) {
			CeTgFieldReportTg toDelete = ceTgFieldReportRepository.load(CeTgFieldReportTg.class, toDeleteId);
			if (toDelete.getCeTgFieldReportTgInfringements() != null) {
				for (CeTgFieldReportTgInfringement row : toDelete.getCeTgFieldReportTgInfringements()) {
					ceTgFieldReportRepository.delete(row);
				}
			}
			ceTgFieldReportRepository.delete(toDelete);
		}

		ceTgFieldReport.setCeTgCheckScheduleItemLocation(scheduleItemLocation);

		ceTgFieldReportRepository.saveOrUpdate(ceTgFieldReport);
		ceTgFieldReportRepository.saveOrUpdate(tgList);
		ceTgFieldReportRepository.saveOrUpdate(infringementList);
		logger.info("Saving TG Field Report - id: {}, isDraft: {}", ceTgFieldReport.getId(), ceTgFieldReport.isDraft());

		return ceTgFieldReport;
	}

	private void updateAttachments(List<AttachmentDto> filesDto) {
		if (CollectionUtils.isNotEmpty(filesDto)) {
			List<File> files = fileRepository.getFiles(filesDto.stream().map(AttachmentDto::getId).collect(Collectors.toList()));
			for (File file : files) {
				AttachmentDto fDto = filesDto.stream().filter(u -> u.getId().equals(file.getId())).findFirst().get();
				file.setDescription(fDto.getDescription());
			}
		}
	}

	// to search person details by uin
	@RequestMapping(path = { "/search/tg/{uin}" }, method = RequestMethod.GET)
	public CeTgFieldReportTgDto getTgDetailsFromUin(@PathVariable String uin) {
		CeTgFieldReportTgDto resultDto = new CeTgFieldReportTgDto();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(uin);
		CeCaseInfringer ceCaseInfringer = null;

		if (tg != null) {
			Type ageGroup = tgHelper.calculateAgeGroup(tg);
			resultDto = CeTgFieldReportTgDto.buildTgDetails(cache, tg, tg.getLicence(), ageGroup);
		} else if (tg == null) {
			ceCaseInfringer = ceCaseInfringerRepository.getCeCaseInfringerByUin(uin);
		}

		if (ceCaseInfringer != null) {
			resultDto = CeTgFieldReportTgDto.buildUtgDetails(cache, ceCaseInfringer);
		} else {
			throw new ValidationException("Tourist Guide not found in TRUST");
		}

		return resultDto;
	}

	// to search person details by uin
	@RequestMapping(path = { "/search/tg-licence/{licenceNo}" }, method = RequestMethod.GET)
	public CeTgFieldReportTgDto getLicenceDetailsFromLicenceNo(@PathVariable String licenceNo) {
		CeTgFieldReportTgDto resultDto = new CeTgFieldReportTgDto();
		Licence tgLicence = tgLicenceRepository.getLicenceByLicenceNo(licenceNo);
		if (tgLicence != null) {
			TouristGuide tg = tgLicence.getTouristGuide();
			Type ageGroup = tgHelper.calculateAgeGroup(tg);
			resultDto = CeTgFieldReportTgDto.buildTgDetails(cache, tg, tgLicence, ageGroup);
		} else {
			throw new ValidationException("Licence not found in TRUST");
		}
		return resultDto;
	}

	// to load active travel agents for 'Name of TA'
	@RequestMapping(value = "/search/travel-agents", method = RequestMethod.GET)
	public List<TravelAgentBasicDto> getTravelAgents() {
		return travelAgentRepository.getActiveTravelAgentsBasic();
	}

	@RequestMapping(value = { "/search/ao" }, method = RequestMethod.GET)
	public List<WorkflowUserRoleDto> getCaseApprovingOfficer() {

		List<WorkflowUserRoleDto> workflowUserRoleDtos = new ArrayList<>();

		List<String> roleCodeSet = new ArrayList<>(2);
		roleCodeSet.add(Codes.Roles.TA_HEAD_OF_DEPARTMENT);
		roleCodeSet.add(Codes.Roles.TG_HEAD_OF_DEPARTMENT);

		List<User> users = userRepository.getActiveUsersByRoles(roleCodeSet);
		User defaultAssignee = userRepository.getUserByLoginId(cache.getSystemParameter(Codes.SystemParameters.CE_DEFAULT_TG_FIELD_REPORT_AO).getValue());

		WorkflowUserRoleDto dto = new WorkflowUserRoleDto();
		dto.setStartStatusCode(Codes.Statuses.CE_WKFLW_PEND_APPR);
		dto.setDefaultAssignee(defaultAssignee.getId());

		if (CollectionUtils.isNotEmpty(users)) {
			List<UserProfileDto> userProfileDtos = new ArrayList<>();
			users.forEach(user -> userProfileDtos.add(UserProfileDto.buildFromUser(cache, user, null)));
			dto.setUsers(userProfileDtos);
		}

		workflowUserRoleDtos.add(dto);

		return workflowUserRoleDtos;
	}

	private Boolean isEditable(CeTgCheckScheduleItemLocation ceTgCheckScheduleItemLocation) {
		WorkflowAction lastAction = null;
		CeTgCheckScheduleItem ceTgCheckScheduleItem = ceTgCheckScheduleItemLocation.getCeTgCheckScheduleItem();

		if (!ceTgCheckScheduleItemLocation.getCreatedBy().equalsIgnoreCase("Data Migration")) {
			lastAction = ceTgCheckScheduleItem.getCeTgCheckSchedule().getWorkflow().getLastAction();
		}

		Boolean isPendingApproval = lastAction != null && Codes.Statuses.CE_WKFLW_APPR.equals(lastAction.getStatus().getCode()) ? false : true;

		if (isPendingApproval && ceTgCheckScheduleItem.isEditable()) {
			return false;
		}
		return true;
	}

}
