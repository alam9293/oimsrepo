package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.TravelAgentBasicDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.licenceAa.TaLicenceAaDto;
import gov.stb.tag.dto.ta.licenceAa.TaLicenceAaItemDto;
import gov.stb.tag.dto.ta.licenceAa.TaLicenceAaSearchDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.ta.TaAaSubmissionRepository;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaLicenceRepository;
import gov.stb.tag.repository.ta.TaNetValueRectificationRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.CsvUtil;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/audited-accounts")
@Transactional
public class TaAaSubmissionController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaAaSubmissionRepository taAaSubmissionRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TaNetValueRectificationRepository taNetValueRectificationRepository;
	@Autowired
	TaNetValueShortfallRepository taNetValueShortfallRepository;
	@Autowired
	CeTaskHelper ceTaskHelper;

	// CR1227
	@Autowired
	TaLicenceRepository taLicenceRepository;

	public static final Object[] docTypeList = { Codes.TaDocumentTypes.TA_DOC_AUDIT_REPORT };
	protected static final String[] contentHeaders = new String[] { "Name", "Licence No", "UEN", "Submission Ref", "Submission Date", "Status", "Submission", "Assigned Officer" };

	// to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceAaItemDto> getList(TaLicenceAaSearchDto searchDto) {
		ResultDto<TaLicenceAaItemDto> resultDTO = new ResultDto<TaLicenceAaItemDto>();
		resultDTO = taAaSubmissionRepository.getPendingList(searchDto, getUser().getId(), true);
		return resultDTO;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/export-list")
	public void exportAAList(@RequestBody TaLicenceAaSearchDto searchDto, HttpServletResponse response) throws IOException, ParseException {
		ResultDto<TaLicenceAaItemDto> searchResultDTOs = taAaSubmissionRepository.getPendingList(searchDto, getUser().getId(), true);
		List<TaLicenceAaItemDto> models = searchResultDTOs.getModels();
		CsvUtil.export(response, contentHeaders, models, dto -> new String[] { dto.getName(), dto.getLicenceNo(), dto.getUen(), dto.getApplicationNo(),
				dto.getSubmissionDate().format(DateUtil.DATETIME_FORMAT), dto.getStatus(), dto.isOfflineSubmission() ? "Offline" : "Online", dto.getAssignedOfficer() });
	}

	// to create new or get existing application details
	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaLicenceAaDto getNewApplication() {
		Licence licenceModel = new Licence();
		User currentUser = taAaSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		licenceModel = currentUser.getTravelAgent().getLicence();

		TaFilingCondition annualFiling = new TaFilingCondition();
		TaAnnualFilingDto annualFilingDto = new TaAnnualFilingDto();

		TaLicenceAaDto aaDto = new TaLicenceAaDto();

		List<FileDto> fileList = new ArrayList<FileDto>();

		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(licenceModel)) {
			// Check if TA has application pending approval, if yes, TA cannot submit another
			Application appModel = taAaSubmissionRepository.getPendingApplicationFromLicenceId(licenceModel.getId(), Codes.ApplicationTypes.TA_APP_AA_SUBMISSION);

			// Check annual filing for outstanding AA. If TA has pending submission/ overdue condition return oldest for TA to submit
			annualFiling = taAnnualFilingRepository.getTaAnnualFilingPendingTA(licenceModel.getId(), Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, Boolean.TRUE, Boolean.FALSE);

			if (appModel == null) {
				if (annualFiling == null) { // if Ta does not have application pending approval && does not have filing model pending submission / overdue
					// TA has submitted all required AA
					aaDto.setHasAaToSubmit(Boolean.FALSE);

				} else {
					aaDto.setApplicationStatus(
							new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));
					fileList = taAaSubmissionRepository.getSupportingDocList(docTypeList, fileHelper);
					aaDto.setFiles(fileList);
					aaDto.setAnnualFilingDto(TaAnnualFilingDto.build(annualFiling));
				}

			} else { // If there is pending application, retrieve the AA details with the AnnualFiling.
				aaDto = taAaSubmissionRepository.getAaSubmissionFromAppId(appModel.getId());
				aaDto = TaLicenceAaDto.buildApplication(cache, appHelper, appModel, aaDto);
				annualFilingDto = taAnnualFilingRepository.getTaAnnualFilingByAaSubmissionId(aaDto.getAaSubmissionId());
				aaDto.setAnnualFilingDto(annualFilingDto);
				// fileList = taAaSubmissionRepository.getFiles(aaDto.getApplicationId(), fileHelper);
				// if (fileList.isEmpty()) {
				// fileList = taAaSubmissionRepository.getSupportingDocList(docTypeList, fileHelper);
				// }
				// aaDto.setFiles(fileList);

				List<FileDto> reqFileList = new ArrayList<FileDto>();
				fileList = taAaSubmissionRepository.getFiles(aaDto.getApplicationId(), fileHelper);
				reqFileList = taAaSubmissionRepository.getSupportingDocList(docTypeList, fileHelper); /* to define which supporting Doc are required */

				aaDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));

			}

		}

		return aaDto;

	}

	// to load active travel agents for offline submission
	@RequestMapping(value = "/offline/new/travel-agents", method = RequestMethod.GET)
	public List<TravelAgentBasicDto> getTravelAgents() {
		return travelAgentRepository.getActiveTravelAgentsBasic();
	}

	// to load annual filing pending submission by travel agent's licence id
	@RequestMapping(value = "/offline/new/travel-agents/{licenceId}", method = RequestMethod.GET)
	public TaLicenceAaDto getTaAnnualFiling(@PathVariable Integer licenceId) {

		Licence licenceModel = new Licence();
		licenceModel = taAaSubmissionRepository.get(Licence.class, licenceId);

		TaFilingCondition annualFiling = new TaFilingCondition();
		TaAnnualFilingDto annualFilingDto = new TaAnnualFilingDto();

		TaLicenceAaDto aaDto = new TaLicenceAaDto();

		List<FileDto> fileList = new ArrayList<FileDto>();

		// Check if TA has application pending approval, if yes, TA cannot submit another
		Application appModel = taAaSubmissionRepository.getPendingApplicationFromLicenceId(licenceModel.getId(), Codes.ApplicationTypes.TA_APP_AA_SUBMISSION);

		// Check annual filing for outstanding AA. If TA has pending submission/ overdue condition return oldest for TA to submit
		annualFiling = taAnnualFilingRepository.getTaAnnualFilingPendingTA(licenceModel.getId(), Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, Boolean.TRUE, Boolean.FALSE);

		if (appModel == null) {

			if (annualFiling == null) { // if Ta does not have application pending approval && does not have filing model pending submission / overdue
				// TA has submitted all required AA
				aaDto.setHasAaToSubmit(Boolean.FALSE);

			} else {
				appModel = new Application();
				appModel.setLicence(licenceModel);
				aaDto = TaLicenceAaDto.buildApplication(cache, appHelper, appModel, aaDto);
				aaDto.setApplicationStatus(
						new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));
				fileList = taAaSubmissionRepository.getSupportingDocList(docTypeList, fileHelper);
				aaDto.setFiles(fileList);
				aaDto.setAnnualFilingDto(TaAnnualFilingDto.build(annualFiling));

			}

		} else { // If there is pending application, retrieve the AA details with the AnnualFiling.
			aaDto = taAaSubmissionRepository.getAaSubmissionFromAppId(appModel.getId());
			aaDto = TaLicenceAaDto.buildApplication(cache, appHelper, appModel, aaDto);
			annualFilingDto = taAnnualFilingRepository.getTaAnnualFilingByAaSubmissionId(aaDto.getAaSubmissionId());
			aaDto.setAnnualFilingDto(annualFilingDto);
			List<FileDto> reqFileList = new ArrayList<FileDto>();
			fileList = taAaSubmissionRepository.getFiles(aaDto.getApplicationId(), fileHelper);
			reqFileList = taAaSubmissionRepository.getSupportingDocList(docTypeList, fileHelper); /* to define which supporting Doc are required */

			aaDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
			if (appModel.getLastAction() != null && !appHelper.hasFinalApprovedOrRejected(appModel)) {
				aaDto.setHasAaToSubmit(Boolean.FALSE);
			}

		}
		aaDto.setOfflineSubmission(true);

		return aaDto;
	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taAaSubmissionRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	// to submit new application details
	@RequestMapping(path = { "/save", "/update", "offline/save", "offline/update", "/edit" }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaLicenceAaDto dto) throws IOException {
		Licence licenceModel = new Licence();
		Integer licenceId = null;
		if (dto.isOfflineSubmission() || dto.getIsEdit()) {
			licenceId = dto.getLicenceId();
			licenceModel = taAaSubmissionRepository.get(Licence.class, licenceId);
		} else {
			User currentUser = taAaSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
			licenceModel = currentUser.getTravelAgent().getLicence();
			licenceId = licenceModel.getId();

			if (dto.getApplicationId() != null) {
				if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
					appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
				}
			}
		}

		TaFilingCondition annualFilingModel = new TaFilingCondition();
		annualFilingModel = taAaSubmissionRepository.get(TaFilingCondition.class, dto.getAnnualFilingDto().getAnnualFilingId());

		TaAaSubmission aaModel = new TaAaSubmission();

		if (dto != null) {
			Application appModel;
			if (dto.getApplicationId() != null) { // Update existing
				aaModel = taAaSubmissionRepository.get(TaAaSubmission.class, dto.getAaSubmissionId());
				appModel = taAaSubmissionRepository.get(Application.class, dto.getApplicationId());

			} else { // save new
				appModel = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, licenceId, dto.isOfflineSubmission(), dto.isDraft());
			}

			if (!dto.isDraft() && !dto.getIsEdit()) {
				appModel.setIsDraft(Boolean.FALSE);
				if (appModel.getSubmissionDate() == null) {
					appModel.setSubmissionDate(LocalDateTime.now());
				}
				annualFilingModel.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_APPROVAL));
				annualFilingModel.setRectifiedApplication(appModel);
				taAaSubmissionRepository.saveOrUpdate(annualFilingModel);
				appHelper.forward(appModel, true);
				ceTaskHelper.completeCeTaskByTaFilingCondition(annualFilingModel);
			} else if (dto.getIsEdit()) {
				appHelper.edit(appModel, dto.getInternalRemarks());
			}
			taAaSubmissionRepository.saveOrUpdate(appModel);

			aaModel.setApplication(appModel);
			aaModel.setTaAnnualFiling(annualFilingModel);
			aaModel = taAaSubmissionRepository.updateAaDetails(dto, aaModel, cache);

			taAaSubmissionRepository.saveOrUpdate(aaModel);

			for (FileDto fileDto : dto.getFiles()) {
				if (dto.isOfflineSubmission() || dto.getIsEdit()) {
					File fileModel = taAaSubmissionRepository.get(File.class, fileDto.getId());
					ApplicationFile appFile = fileRepository.getAppFile(fileDto.getId());
					if (fileModel != null && appFile == null) {
						fileHelper.saveApplicationFile(appModel, fileModel, fileDto);
					}
				} else {
					if (fileDto.getPublicFileId() == null && !Strings.isNullOrEmpty(fileDto.getOriginalName())) {
						fileHelper.saveFile(appModel, fileDto);
					}
				}
			}

			List<Integer> toDeleteList = dto.getToDeleteFiles();
			if (toDeleteList != null && !toDeleteList.isEmpty()) {
				for (Integer id : toDeleteList) {
					if (id != null) {
						File attachemnt = new File();
						attachemnt = fileHelper.getFile(id);
						if (attachemnt != null) {
							fileHelper.deleteFile(attachemnt);
						}
					}
				}
			}
		}
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceAaDto getApplication(@PathVariable Integer id) {
		User currentUser = taAaSubmissionRepository.getLicenseeUserByUserId(getUser().getId());

		TaLicenceAaDto resultDto = new TaLicenceAaDto();
		TaAnnualFilingDto annualFilingDto = new TaAnnualFilingDto();
		List<FileDto> fileList = new ArrayList<FileDto>();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}

			resultDto = taAaSubmissionRepository.getAaSubmissionFromAppId(id);
			if (resultDto != null) {
				resultDto = TaLicenceAaDto.buildApplication(cache, appHelper, taAaSubmissionRepository.get(Application.class, id), resultDto);
				annualFilingDto = taAnnualFilingRepository.getTaAnnualFilingByAaSubmissionId(resultDto.getAaSubmissionId());
				resultDto.setAnnualFilingDto(annualFilingDto);

				// link the shortfall details if the AA has shortfall
				TaNetValueRectification rectification = null;
				if (resultDto.getShortfall() != null && resultDto.getShortfall().compareTo(BigDecimal.ZERO) > 0) {// AA has shortfall
					// find the shortfall record
					TaNetValueShortfall shortfall = taNetValueShortfallRepository.getShortfallByAaSubmissionId(resultDto.getAaSubmissionId());
					if (shortfall != null) {
						rectification = shortfall.getTaNetValueRectification();
						resultDto.setShortfallDto(TaNetValueShortfallDto.buildFromNetValueShortfall(cache, workflowHelper, fileHelper, appHelper, shortfall, rectification, Boolean.TRUE));
					}
				}

				List<FileDto> reqFileList = new ArrayList<FileDto>();
				fileList = taAaSubmissionRepository.getFiles(resultDto.getApplicationId(), fileHelper);
				reqFileList = taAaSubmissionRepository.getSupportingDocList(docTypeList, fileHelper); /* to define which supporting Doc are required */

				resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
			}
		}

		return resultDto;
	}

	// to approve, reject, RFA submission
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaAaSubmission aaModel = new TaAaSubmission();
		aaModel = taAaSubmissionRepository.get(TaAaSubmission.class, id);

		TaFilingCondition annualFilingModel = new TaFilingCondition();
		annualFilingModel = aaModel.getTaAnnualFiling();

		Application appModel = new Application();
		appModel = taAaSubmissionRepository.get(Application.class, aaModel.getApplication().getId());

		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		String taAnnualFilingType = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(appModel, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			aaModel = calculateRatios(aaModel);

			if (appHelper.hasFinalApproved(appModel)) {

				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taMsgType = Codes.EmailType.TA_UPON_APPROVAL;
				taAnnualFilingType = Codes.Statuses.TA_FILING_APPROVED;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				boolean newShortFall = false;
				if (aaModel.getShortfall().compareTo(BigDecimal.ZERO) > 0) {
					appHelper.createNetValueShortfall(aaModel, null);
					newShortFall = true;
				}

				if (!newShortFall) {
					// CR 1227
					// Check if anymore filing conditions
					SystemParameter sysParam = taLicenceRepository.getJobParameter(Codes.SystemParameters.TA_FILING_CONDITION_REMINDER_START_DATE);

					// List<TaFilingCondition> taFilingConditions = taLicenceRepository.getPendingTaAnnualFilingSubmissionsByLicenceId(sysParam.getValue(),
					// aaModel.getApplication().getLicence().getId());
					TaLicenceRenewalExerciseTa taFilingConditions = taLicenceRepository.getTaByLicenceId(aaModel.getApplication().getLicence().getId());
					logger.info("TaAaSubmissionController getExpiryDate - " + aaModel.getApplication().getLicence().getExpiryDate());
					boolean fulfilled = conditionsFulfilled(taFilingConditions, aaModel);
					if (fulfilled) {
						// Override the message
						// TA_UPON_APPROVAL with TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED
						taMsgType = Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED;
						logger.info("TaAaSubmissionController NewEmail - " + Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED);
					}
				}
			}

			break;

		case ACTION_REJECT:
			appHelper.reject(appModel, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;

			if (LocalDate.now().isAfter(annualFilingModel.getDueDate())) {
				taAnnualFilingType = Codes.Statuses.TA_FILING_LATE;
			} else {
				taAnnualFilingType = Codes.Statuses.TA_FILING_PEND_SUBMISSION;
			}
			annualFilingModel.setRectifiedApplication(null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:
			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
				taAnnualFilingType = Codes.Statuses.TA_FILING_RFA;
			}
			appHelper.rfa(appModel, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		// update filing status
		if (taAnnualFilingType != null) {
			annualFilingModel.setStatus(cache.getStatus(taAnnualFilingType));
		}
		taAaSubmissionRepository.update(aaModel);

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(appModel.getLicence().getTravelAgent(), appModel, taAlertMsg, Codes.Modules.MOD_TA, appModel.getType(), "../ta-aa-submission/" + appModel.getId(),
					cache.getStatus(statusCode));

			/* Send email to notify TA & KE */
			String url = String.format(properties.applicationUrl, "ta-aa-submission/" + appModel.getId());
			emailHelper.emailTaUponAction(appModel, taMsgType, url);
		}
	}

	private boolean conditionsFulfilled(TaLicenceRenewalExerciseTa taLicenceRenewalExerciseTa, TaAaSubmission aaModel) {

		try {
			if (null == taLicenceRenewalExerciseTa) {
				return false;
			}

			// Aa
			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition1().getId() == aaModel.getTaAnnualFiling().getId()) {
					// cont
				} else if (taLicenceRenewalExerciseTa.getTaAaFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition2().getId() == aaModel.getTaAnnualFiling().getId()) {
					// cont
				} else if (taLicenceRenewalExerciseTa.getTaAaFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// Abpr
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// NET val
			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1()) {
				if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2()) {
				if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			// MA
			if (null != taLicenceRenewalExerciseTa.getMaFilingCondition()) {
				if (taLicenceRenewalExerciseTa.getMaFilingCondition().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			return true;
		} catch (Exception e) {
			return false;
		}
		/*
		 * for (TaFilingCondition conditions : filteredTaFilingConditions) {
		 * 
		 * if (!conditions.getStatus().getCode().equals("TA_FILING_APPR")) { return false; }
		 * 
		 * } return true;
		 */

	}

	private TaAaSubmission calculateRatios(TaAaSubmission aa) {
		BigDecimal netProfitMargin = null;
		BigDecimal quickRatio = null;
		BigDecimal debtEquityRatio = null;
		BigDecimal profitScRatio = null;

		if (aa.getRevenue().compareTo(BigDecimal.ZERO) == 0 || (aa.getRevenue().add(aa.getOtherIncome()).compareTo(BigDecimal.ZERO) == 0)) {
			netProfitMargin = Codes.NumericalRepresent.NEG_INFINIY_BIG_DECIMAL;
		} else {
			netProfitMargin = aa.getNetProfitLoss().divide(aa.getRevenue().add(aa.getOtherIncome()), 2, RoundingMode.HALF_UP);
		}
		aa.setNetProfitMargin(netProfitMargin);
		aa.setIsNetProfitMarginRed(isRatioRed(Codes.SystemParameters.TA_NET_PROFIT_MARGIN_THRESHOLD, aa.getNetProfitMargin()));

		if (aa.getCurrentLiabilities().compareTo(BigDecimal.ZERO) == 0) {
			quickRatio = Codes.NumericalRepresent.NEG_INFINIY_BIG_DECIMAL;
		} else {
			quickRatio = (aa.getCashCashEquiv().add(aa.getTradeReceivables().add(aa.getTradeSecurities()))).divide(aa.getCurrentLiabilities(), 2, RoundingMode.HALF_UP);
		}
		aa.setQuickRatio(quickRatio);
		aa.setIsQuickRatioRed(isRatioRed(Codes.SystemParameters.TA_QUICK_RATIO_THRESHOLD, aa.getQuickRatio()));

		if (aa.getTotalEquity().compareTo(BigDecimal.ZERO) == 0) {
			debtEquityRatio = Codes.NumericalRepresent.NEG_INFINIY_BIG_DECIMAL;
		} else {
			debtEquityRatio = aa.getTotalLiabilities().divide(aa.getTotalEquity(), 2, RoundingMode.HALF_UP);
		}
		aa.setDebtEquityRatio(debtEquityRatio);
		aa.setIsDebtEquityRatioRed(isRatioRed(Codes.SystemParameters.TA_DEBT_EQUITY_THRESHOLD, aa.getDebtEquityRatio()));

		if (aa.getCapital().compareTo(BigDecimal.ZERO) == 0) {
			profitScRatio = Codes.NumericalRepresent.NEG_INFINIY_BIG_DECIMAL;
		} else {
			profitScRatio = aa.getAccProfitLoss().divide(aa.getCapital(), 2, RoundingMode.HALF_UP);
		}
		aa.setProfitScRatio(profitScRatio);
		aa.setIsProfitScRatioRed(isRatioRed(Codes.SystemParameters.TA_PROFIT_SC_THRESHOLD, aa.getProfitScRatio()));

		// set no. of red
		Integer noOfRed = 0;
		noOfRed = noOfRed + (aa.isNetProfitMarginRed() ? 1 : 0);
		noOfRed = noOfRed + (aa.isQuickRatioRed() ? 1 : 0);
		noOfRed = noOfRed + (aa.isDebtEquityRatioRed() ? 1 : 0);
		noOfRed = noOfRed + (aa.isProfitScRatioRed() ? 1 : 0);
		aa.setNoOfReds(noOfRed);

		// set net value
		aa.setNetValue((aa.getTotalAssets() != null && aa.getTotalLiabilities() != null) ? aa.getTotalAssets().subtract(aa.getTotalLiabilities()) : null);

		// set shortfall
		Licence licence = aa.getApplication().getLicence();
		Integer financialRequirement = (licence.getTier().getKey().equals(Codes.Types.TA_TIER_GENERAL)
				? Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_GENERAL_FINANICAL_REQUIREMENT).getValue())
				: Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_NICHE_FINANICAL_REQUIREMENT).getValue()));
		aa.setShortfall(aa.getNetValue() != null ? BigDecimal.valueOf(financialRequirement).subtract(aa.getNetValue()).compareTo(new BigDecimal(0)) < 0 ? new BigDecimal(0)
				: BigDecimal.valueOf(financialRequirement).subtract(aa.getNetValue()) : null);
		return aa;
	}

	private Boolean isRatioRed(String systemParam, BigDecimal ratio) {
		String thresholdVal = cache.getSystemParameter(systemParam).getValue();
		BigDecimal thresholdLower = null;
		BigDecimal thresholdUpper = null;
		if (thresholdVal != null) {
			if (thresholdVal.contains(",")) {
				thresholdLower = new BigDecimal(thresholdVal.split(",")[0]);
				thresholdUpper = new BigDecimal(thresholdVal.split(",")[1]);
			} else {
				thresholdLower = new BigDecimal(thresholdVal.split(",")[0]);
			}
			if (thresholdLower != null) {
				if (ratio.compareTo(thresholdLower) < 0) {
					return true;
				}
			}
			if (thresholdUpper != null) {
				if (ratio.compareTo(thresholdUpper) > 0) {
					return true;
				}
			}
		}
		return false;
	}
}
