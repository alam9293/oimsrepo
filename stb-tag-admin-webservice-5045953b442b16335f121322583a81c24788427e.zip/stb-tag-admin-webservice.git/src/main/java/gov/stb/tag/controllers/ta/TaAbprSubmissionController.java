package gov.stb.tag.controllers.ta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.TravelAgentBasicDto;
import gov.stb.tag.dto.ta.abpr.TaAbprSubmissionDto;
import gov.stb.tag.dto.ta.abpr.TaAbprSubmissionItemDto;
import gov.stb.tag.dto.ta.abpr.TaAbprSubmissionSearchDto;
import gov.stb.tag.dto.ta.abpr.TaAreaOfFocusDto;
import gov.stb.tag.dto.ta.abpr.TaBusinessOperationDto;
import gov.stb.tag.dto.ta.abpr.TaFunctionActivityDto;
import gov.stb.tag.dto.ta.abpr.TaMarketSpecializationDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaBusinessOperation;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFocusArea;
import gov.stb.tag.model.TaFunctionActivity;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaSpecializedMarket;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.ta.TaAbprSubmissionRepository;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaLicenceRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/abprs")
@Transactional
public class TaAbprSubmissionController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaAbprSubmissionRepository taAbprSubmissionRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	TaLicenceRepository taLicenceRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	CeTaskHelper ceTaskHelper;

	// to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaAbprSubmissionItemDto> getList(TaAbprSubmissionSearchDto searchDto) {
		ResultDto<TaAbprSubmissionItemDto> resultDTO = new ResultDto<TaAbprSubmissionItemDto>();
		resultDTO = taAbprSubmissionRepository.getPendingList(searchDto, getUser().getId());
		return resultDTO;
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TaAbprSubmissionDto getIntranetApplication(@PathVariable Integer id) {
		User currentUser = taAbprSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			appHelper.isAppBelongToTA(id, currentUser);
		}
		TaAbprSubmission taAbprSubmission = taAbprSubmissionRepository.getApplication(id, null, false);
		TaAbprSubmissionDto taAbprSubmissionDto = TaAbprSubmissionDto.buildFromApplication(cache, appHelper, taAbprSubmission, false);
		return taAbprSubmissionDto;
	}

	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaAbprSubmissionDto getInternetApplication() {
		User currentUser = taAbprSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		TaAbprSubmission taAbprSubmission = taAbprSubmissionRepository.getApplication(null, currentUser.getTravelAgent().getId(), true);

		if ((taAbprSubmission) != null) {
			return TaAbprSubmissionDto.buildFromApplication(cache, appHelper, taAbprSubmission, true);

		} else {
			return newAbprSubmission(currentUser.getTravelAgent().getLicence().getId());
		}
	}

	private TaAbprSubmissionDto newAbprSubmission(Integer licenceId) {

		TaAbprSubmissionDto taAbprSubmissionDto = new TaAbprSubmissionDto();
		taAbprSubmissionDto.setApplicationStatus(
				new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));

		TaFilingCondition filing = taAnnualFilingRepository.getTaAnnualFilingPendingTA(licenceId, Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION, true, false);

		if (filing == null) {
			taAbprSubmissionDto.setHasAbprToSubmit(false);
		} else {
			taAbprSubmissionDto.setHasAbprToSubmit(true);
			taAbprSubmissionDto.setTaLicenceAnnualFilingDto(TaAnnualFilingDto.build(filing));
			taAbprSubmissionDto.buildFromLicence(cache, filing.getLicence(), taAbprSubmissionDto);

			List<TaFunctionActivityDto> functionActivities = new ArrayList<TaFunctionActivityDto>();
			for (Type type : cache.getTaFunctionActivity()) {
				TaFunctionActivityDto a = new TaFunctionActivityDto();
				a.setQuestion(new ListableDto(type.getKey(), type.getLabel()));
				functionActivities.add(a);
			}
			taAbprSubmissionDto.setFunctionRows(functionActivities);
		}

		return taAbprSubmissionDto;
	}

	@RequestMapping(value = "/new/{id}", method = RequestMethod.GET)
	public TaAbprSubmissionDto getInternetApplication(@PathVariable Integer id) {
		User currentUser = taAbprSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			appHelper.isAppBelongToTA(id, currentUser);
		}
		TaAbprSubmission taAbprSubmission = taAbprSubmissionRepository.getApplication(id, currentUser.getTravelAgent().getId(), false);
		TaAbprSubmissionDto taAbprSubmissionDto = (taAbprSubmission) != null ? TaAbprSubmissionDto.buildFromApplication(cache, appHelper, taAbprSubmission, true) : new TaAbprSubmissionDto();
		return taAbprSubmissionDto;
	}

	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {

		TaAbprSubmission taAbprSubmission = taAbprSubmissionRepository.getApplication(id, null, false);
		Application application = taAbprSubmission.getApplication();

		TaFilingCondition taAnnualFiling = taAbprSubmission.getTaAnnualFiling();
		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(application, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			if (appHelper.hasFinalApproved(application)) {
				taAnnualFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_APPROVED));
				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taMsgType = Codes.EmailType.TA_UPON_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				// CR 1227
				// Check if anymore filing conditions
				SystemParameter sysParam = taLicenceRepository.getJobParameter(Codes.SystemParameters.TA_FILING_CONDITION_REMINDER_START_DATE);
				// List<TaFilingCondition> taFilingConditions = taLicenceRepository.getPendingTaAnnualFilingSubmissionsByLicenceId(sysParam.getValue(), application.getLicence().getId());
				TaLicenceRenewalExerciseTa taFilingConditions = taLicenceRepository.getTaByLicenceId(application.getLicence().getId());
				logger.info("TaAbprSubmissionController getExpiryDate - " + application.getLicence().getExpiryDate());

				boolean fulfilled = conditionsFulfilled(taFilingConditions, taAbprSubmission);
				if (fulfilled) {
					// Override the message
					// TA_UPON_APPROVAL with TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED
					taMsgType = Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED;
					logger.info("TaAbprSubmissionController NewEmail - " + Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED);
				}

			}
			break;

		case ACTION_REJECT:
			appHelper.reject(application, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;
			if (LocalDate.now().isAfter(taAnnualFiling.getDueDate())) {
				taAnnualFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_LATE));
			} else {
				taAnnualFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_SUBMISSION));
			}
			taAnnualFiling.setRectifiedApplication(null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:
			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
				taAnnualFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_RFA));
			}
			appHelper.rfa(application, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());

			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			alertHelper.createAlert(application.getLicence().getTravelAgent(), application, taAlertMsg, Codes.Modules.MOD_TA, application.getType(), "../ta-abpr-submission/" + application.getId(),
					cache.getStatus(statusCode));

			String url = String.format(properties.applicationUrl, "ta-abpr-submission/" + application.getId());
			emailHelper.emailTaUponAction(application, taMsgType, url);
		}
	}

	private boolean conditionsFulfilled(TaLicenceRenewalExerciseTa taLicenceRenewalExerciseTa, TaAbprSubmission taAbprSubmission) {

		try {
			if (null == taLicenceRenewalExerciseTa) {
				return false;
			}

			// Aa
			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// Abpr
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition1().getId() == taAbprSubmission.getTaAnnualFiling().getId()) {
					// cont
				} else if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition2().getId() == taAbprSubmission.getTaAnnualFiling().getId()) {
					// cont
				} else if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// NET val
			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1()) {
				if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2()) {
				if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			// MA
			if (null != taLicenceRenewalExerciseTa.getMaFilingCondition()) {
				if (taLicenceRenewalExerciseTa.getMaFilingCondition().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			return true;
		} catch (Exception e) {
			return false;
		}
		/*
		 * for (TaFilingCondition conditions : filteredTaFilingConditions) {
		 * 
		 * if (!conditions.getStatus().getCode().equals("TA_FILING_APPR")) { return false; }
		 * 
		 * } return true;
		 */

	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taAbprSubmissionRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	@RequestMapping(path = { "/save/nil-submission", "/offline/save/nil-submission" }, method = RequestMethod.POST)
	public void saveNilSubmissionn(@RequestBody TaAbprSubmissionDto taAbprSubmissionDto) {
		User currentUser = taAbprSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = null;
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			licence = currentUser.getTravelAgent().getLicence();
		} else {
			licence = taAbprSubmissionRepository.get(Licence.class, taAbprSubmissionDto.getLicenceId());
		}

		if (licence != null) {
			TaAbprSubmission taAbprSubmission = null;
			Application application = new Application();

			TaFilingCondition annualFilingModel = new TaFilingCondition();
			annualFilingModel = taAbprSubmissionRepository.get(TaFilingCondition.class, taAbprSubmissionDto.getTaLicenceAnnualFilingDto().getAnnualFilingId());

			if (taAbprSubmissionDto.getAbprSubmissionId() == null) {
				application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION, licence.getId(), taAbprSubmissionDto.isOfflineSubmission(), taAbprSubmissionDto.isDraft());

				taAbprSubmission = new TaAbprSubmission();
				taAbprSubmission.setApplication(application);
				taAbprSubmission.setTaAnnualFiling(annualFilingModel);
			} else {
				application = taAbprSubmissionRepository.get(Application.class, taAbprSubmissionDto.getApplicationId());
				taAbprSubmission = taAbprSubmissionRepository.get(TaAbprSubmission.class, taAbprSubmissionDto.getAbprSubmissionId());
			}
			application.setIsDraft(false);
			annualFilingModel.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_APPROVAL));
			annualFilingModel.setRectifiedApplication(application);
			taAbprSubmissionRepository.saveOrUpdate(annualFilingModel);
			appHelper.forward(application, true);
			taAbprSubmissionRepository.saveOrUpdate(application);
			ceTaskHelper.completeCeTaskByTaFilingCondition(annualFilingModel);

			// clear existing market specializations
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaSpecializedMarkets())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaSpecializedMarkets());
			}
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaBusinessOperations())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaBusinessOperations());
			}
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaFocusAreas())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaFocusAreas());
			}
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaFunctionActivities())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaFunctionActivities());
			}
			taAbprSubmission.setIsNilSubmission(true);

			taAbprSubmission.setInboundOp(new BigDecimal(0));
			taAbprSubmission.setOutboundOp(new BigDecimal(0));
			taAbprSubmission.setInboundOpPercent(new BigDecimal(0));
			taAbprSubmission.setOutboundOpPercent(new BigDecimal(0));
			taAbprSubmission.setInboundFitPax(0);
			taAbprSubmission.setOutboundFitPax(0);
			taAbprSubmission.setInboundGrpPax(0);
			taAbprSubmission.setOutboundGrpPax(0);
			taAbprSubmission.setInboundFitPaxPercent(new BigDecimal(0));
			taAbprSubmission.setOutboundFitPaxPercent(new BigDecimal(0));
			taAbprSubmission.setInboundGrpPaxPercent(new BigDecimal(0));
			taAbprSubmission.setOutboundGrpPaxPercent(new BigDecimal(0));

			taAbprSubmission.setDepreciation(taAbprSubmissionDto.getDepreciation());
			taAbprSubmission.setIndirectTax(taAbprSubmissionDto.getIndirectTax());
			taAbprSubmission.setNoOfEmployee(taAbprSubmissionDto.getNoOfEmployee());
			taAbprSubmission.setOperatingCost(taAbprSubmissionDto.getOperatingCost());
			taAbprSubmission.setRemuneration(taAbprSubmissionDto.getRemuneration());
			if (taAbprSubmissionDto.getHasOverseasBranch() != null) {
				taAbprSubmission.setHasOverseasBranch(Boolean.valueOf(taAbprSubmissionDto.getHasOverseasBranch()));
			}

			taAbprSubmissionRepository.save(taAbprSubmission);
		}
	}

	@RequestMapping(path = { "/save", "/offline/save" }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaAbprSubmissionDto taAbprSubmissionDto) {
		User currentUser = taAbprSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = null;
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			licence = currentUser.getTravelAgent().getLicence();
		} else {
			licence = taAbprSubmissionRepository.get(Licence.class, taAbprSubmissionDto.getLicenceId());
		}

		if (licence != null) {
			TaAbprSubmission taAbprSubmission = null;
			Application application;

			TaFilingCondition annualFilingModel = new TaFilingCondition();
			annualFilingModel = taAbprSubmissionRepository.get(TaFilingCondition.class, taAbprSubmissionDto.getTaLicenceAnnualFilingDto().getAnnualFilingId());

			if (taAbprSubmissionDto.getAbprSubmissionId() == null) {
				application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION, licence.getId(), taAbprSubmissionDto.isOfflineSubmission(), taAbprSubmissionDto.isDraft());
				taAbprSubmission = new TaAbprSubmission();
				taAbprSubmission.setApplication(application);
				taAbprSubmission.setTaAnnualFiling(annualFilingModel);
			} else {
				application = taAbprSubmissionRepository.get(Application.class, taAbprSubmissionDto.getApplicationId());
				taAbprSubmission = taAbprSubmissionRepository.get(TaAbprSubmission.class, taAbprSubmissionDto.getAbprSubmissionId());
			}

			if (!taAbprSubmissionDto.isDraft()) {
				application.setIsDraft(false);
				if (application.getSubmissionDate() == null) {
					application.setSubmissionDate(LocalDateTime.now());
				}
				annualFilingModel.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_APPROVAL));
				annualFilingModel.setRectifiedApplication(application);
				taAbprSubmissionRepository.saveOrUpdate(annualFilingModel);
				appHelper.forward(application, true);
				ceTaskHelper.completeCeTaskByTaFilingCondition(annualFilingModel);
			}
			taAbprSubmissionRepository.saveOrUpdate(application);

			// appHelper.saveAction(application, Codes.Statuses.TA_APP_PENDING_APPROVAL);

			// clear existing market specializations
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaSpecializedMarkets())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaSpecializedMarkets());
			}
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaBusinessOperations())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaBusinessOperations());
			}
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaFocusAreas())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaFocusAreas());
			}
			if (CollectionUtils.isNotEmpty(taAbprSubmission.getTaFunctionActivities())) {
				taAbprSubmissionRepository.delete(taAbprSubmission.getTaFunctionActivities());
			}
			taAbprSubmission.setIsNilSubmission(false);
			taAbprSubmission.setTaSpecializedMarkets(Sets.newHashSet());
			taAbprSubmission.setTaBusinessOperations(Sets.newHashSet());
			taAbprSubmission.setTaFocusAreas(Sets.newHashSet());
			taAbprSubmission.setTaFunctionActivities(Sets.newHashSet());

			taAbprSubmission.setInboundOp(taAbprSubmissionDto.getInboundOp());
			taAbprSubmission.setOutboundOp(taAbprSubmissionDto.getOutboundOp());
			taAbprSubmission.setInboundOpPercent(taAbprSubmissionDto.getInboundOpPercent());
			taAbprSubmission.setOutboundOpPercent(taAbprSubmissionDto.getOutboundOpPercent());

			// taAbprSubmission.setInboundOpPercent(taAbprSubmissionDto.getInboundValue());
			// taAbprSubmission.setOutboundOpPercent(taAbprSubmissionDto.getOutboundValue());
			taAbprSubmission.setInboundFitPax(taAbprSubmissionDto.getInboundFitPax());
			taAbprSubmission.setOutboundFitPax(taAbprSubmissionDto.getOutboundFitPax());
			taAbprSubmission.setInboundGrpPax(taAbprSubmissionDto.getInboundGrpPax());
			taAbprSubmission.setOutboundGrpPax(taAbprSubmissionDto.getOutboundGrpPax());

			taAbprSubmission.setInboundFitPaxPercent(taAbprSubmissionDto.getInboundFitPaxPercent());
			taAbprSubmission.setOutboundFitPaxPercent(taAbprSubmissionDto.getOutboundFitPaxPercent());
			taAbprSubmission.setInboundGrpPaxPercent(taAbprSubmissionDto.getInboundGrpPaxPercent());
			taAbprSubmission.setOutboundGrpPaxPercent(taAbprSubmissionDto.getOutboundGrpPaxPercent());

			taAbprSubmission.setDepreciation(taAbprSubmissionDto.getDepreciation());
			taAbprSubmission.setIndirectTax(taAbprSubmissionDto.getIndirectTax());
			taAbprSubmission.setNoOfEmployee(taAbprSubmissionDto.getNoOfEmployee());
			taAbprSubmission.setOperatingCost(taAbprSubmissionDto.getOperatingCost());
			taAbprSubmission.setRemuneration(taAbprSubmissionDto.getRemuneration());
			if (taAbprSubmissionDto.getHasOverseasBranch() != null) {
				taAbprSubmission.setHasOverseasBranch(Boolean.valueOf(taAbprSubmissionDto.getHasOverseasBranch()));
			}
			Set<TaSpecializedMarket> taMarketSpecializationSet = new HashSet<TaSpecializedMarket>();
			for (TaMarketSpecializationDto taMarketSpecializationDto : taAbprSubmissionDto.getInboundRows()) {
				if (taMarketSpecializationDto.getCountry() != null && taMarketSpecializationDto.getCountry().getKey() != null
						&& taMarketSpecializationDto.getPercentage().compareTo(new BigDecimal("0")) != 0) {
					TaSpecializedMarket taSpecializedMarket = new TaSpecializedMarket();
					taSpecializedMarket.setTaAbprSubmission(taAbprSubmission);
					taSpecializedMarket.setCountry(cache.getType(taMarketSpecializationDto.getCountry().getKey().toString()));
					taSpecializedMarket.setPercent(taMarketSpecializationDto.getPercentage());
					taSpecializedMarket.setIsInbound(true);
					taMarketSpecializationSet.add(taSpecializedMarket);
					taAbprSubmissionRepository.save(taSpecializedMarket);
				}

			}
			for (TaMarketSpecializationDto taMarketSpecializationDto : taAbprSubmissionDto.getOutboundRows()) {
				if (taMarketSpecializationDto.getCountry() != null && taMarketSpecializationDto.getCountry().getKey() != null
						&& taMarketSpecializationDto.getPercentage().compareTo(new BigDecimal("0")) != 0) {
					TaSpecializedMarket taSpecializedMarket = new TaSpecializedMarket();
					taSpecializedMarket.setTaAbprSubmission(taAbprSubmission);
					taSpecializedMarket.setCountry(cache.getType(taMarketSpecializationDto.getCountry().getKey().toString()));
					taSpecializedMarket.setPercent(taMarketSpecializationDto.getPercentage());
					taSpecializedMarket.setIsInbound(false);
					taMarketSpecializationSet.add(taSpecializedMarket);
					taAbprSubmissionRepository.save(taSpecializedMarket);
				}
			}
			taAbprSubmission.setTaSpecializedMarkets(taMarketSpecializationSet);

			Set<TaBusinessOperation> taBusinessOperationSet = new HashSet<TaBusinessOperation>();
			for (TaBusinessOperationDto taBusinessOperationDto : taAbprSubmissionDto.getBusinessRows()) {
				if (taBusinessOperationDto.getService() != null && taBusinessOperationDto.getService().getKey() != null) {
					TaBusinessOperation taBusinessOperation = new TaBusinessOperation();
					taBusinessOperation.setTaAbprSubmission(taAbprSubmission);
					taBusinessOperation.setService(cache.getType(taBusinessOperationDto.getService().getKey().toString()));
					taBusinessOperation.setInbound(taBusinessOperationDto.getInbound());
					taBusinessOperation.setOutbound(taBusinessOperationDto.getOutbound());
					taBusinessOperation.setIsInboundOwned(taBusinessOperationDto.getIsInboundOwned() == null ? Boolean.FALSE : taBusinessOperationDto.getIsInboundOwned());
					taBusinessOperation.setIsOutboundOwned(taBusinessOperationDto.getIsOutboundOwned() == null ? Boolean.FALSE : taBusinessOperationDto.getIsOutboundOwned());
					/// taBusinessOperation.setOutboundPercent(taBusinessOperationDto.getOutboundPercent());
					taBusinessOperationSet.add(taBusinessOperation);
					taAbprSubmissionRepository.save(taBusinessOperation);
				}
			}
			taAbprSubmission.setTaBusinessOperations(taBusinessOperationSet);

			Set<TaFocusArea> taAreaOfFocusSet = new HashSet<TaFocusArea>();
			for (TaAreaOfFocusDto taAreaOfFocusDto : taAbprSubmissionDto.getFocusRows()) {
				if (taAreaOfFocusDto.getFocusArea() != null && taAreaOfFocusDto.getFocusArea().getKey() != null) {
					TaFocusArea taFocusArea = new TaFocusArea();
					taFocusArea.setTaAbprSubmission(taAbprSubmission);
					taFocusArea.setFocusArea(cache.getType(taAreaOfFocusDto.getFocusArea().getKey().toString()));
					taFocusArea.setHasInboundOp(taAreaOfFocusDto.getHasInboundOp() == null ? Boolean.FALSE : taAreaOfFocusDto.getHasInboundOp());
					taFocusArea.setHasOutboundOp(taAreaOfFocusDto.getHasOutboundOp() == null ? Boolean.FALSE : taAreaOfFocusDto.getHasOutboundOp());
					taFocusArea.setRemarks(taAreaOfFocusDto.getRemarks());
					taAreaOfFocusSet.add(taFocusArea);
					taAbprSubmissionRepository.save(taFocusArea);
				}
			}
			taAbprSubmission.setTaFocusAreas(taAreaOfFocusSet);

			Set<TaFocusArea> taOtherAreaOfFocusSet = new HashSet<TaFocusArea>();
			for (TaAreaOfFocusDto taOtherAreaOfFocusDto : taAbprSubmissionDto.getOtherFocusRows()) {
				if (taOtherAreaOfFocusDto.getOtherFocusArea() != null) {
					TaFocusArea taOtherFocusArea = new TaFocusArea();
					taOtherFocusArea.setTaAbprSubmission(taAbprSubmission);
					taOtherFocusArea.setOtherFocusArea(taOtherAreaOfFocusDto.getOtherFocusArea());
					// taOtherFocusArea.setFocusArea(cache.getType(taOtherAreaOfFocusDto.getFocusArea().getKey().toString()));
					taOtherFocusArea.setHasInboundOp(taOtherAreaOfFocusDto.getHasInboundOp() == null ? Boolean.FALSE : taOtherAreaOfFocusDto.getHasInboundOp());
					taOtherFocusArea.setHasOutboundOp(taOtherAreaOfFocusDto.getHasOutboundOp() == null ? Boolean.FALSE : taOtherAreaOfFocusDto.getHasOutboundOp());
					taOtherFocusArea.setRemarks(taOtherAreaOfFocusDto.getRemarks());
					taOtherAreaOfFocusSet.add(taOtherFocusArea);
					taAbprSubmissionRepository.save(taOtherFocusArea);
				}
			}
			taAbprSubmission.setTaFocusAreas(taOtherAreaOfFocusSet);

			Set<TaFunctionActivity> taFunctionActivitySet = new HashSet<TaFunctionActivity>();
			for (TaFunctionActivityDto taFunctionActivityDto : taAbprSubmissionDto.getFunctionRows()) {
				if (taFunctionActivityDto.getQuestion() != null && taFunctionActivityDto.getQuestion().getKey() != null) {
					TaFunctionActivity taFunctionActivity = new TaFunctionActivity();
					taFunctionActivity.setTaAbprSubmission(taAbprSubmission);
					taFunctionActivity.setQuestion(cache.getType(taFunctionActivityDto.getQuestion().getKey().toString()));
					taFunctionActivity.setIsInbound(taFunctionActivityDto.getIsInbound() == null ? Boolean.FALSE : taFunctionActivityDto.getIsInbound());
					taFunctionActivity.setIsOutbound(taFunctionActivityDto.getIsOutbound() == null ? Boolean.FALSE : taFunctionActivityDto.getIsOutbound());
					taFunctionActivitySet.add(taFunctionActivity);
					taAbprSubmissionRepository.save(taFunctionActivity);
				}
			}
			taAbprSubmission.setTaFunctionActivities(taFunctionActivitySet);
			taAbprSubmissionRepository.save(taAbprSubmission);
		}
	}

	// to load active travel agents for offline submission
	@RequestMapping(value = "/offline/new/travel-agents", method = RequestMethod.GET)
	public List<TravelAgentBasicDto> getTravelAgents() {
		return travelAgentRepository.getActiveTravelAgentsBasic();
	}

	// to load annual filing pending submission by travel agent's licence id
	@RequestMapping(value = "/offline/new/travel-agents/{licenceId}", method = RequestMethod.GET)
	public TaAbprSubmissionDto getTaAbprAnnualFiling(@PathVariable Integer licenceId) {

		TaAbprSubmissionDto resultDto = new TaAbprSubmissionDto();

		// Check if TA has application pending approval, if yes, TA cannot submit another
		Application pendingApp = taAbprSubmissionRepository.getPendingApplicationFromLicenceId(licenceId, Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION);

		if (pendingApp == null) {
			resultDto = newAbprSubmission(licenceId);
		} else {
			TaAbprSubmission taAbprSubmission = taAbprSubmissionRepository.getApplication(pendingApp.getId(), null, false);
			resultDto = TaAbprSubmissionDto.buildFromApplication(cache, appHelper, taAbprSubmission, false);
			resultDto.setHasAbprToSubmit(Boolean.FALSE);
		}

		resultDto.setOfflineSubmission(Boolean.TRUE);
		return resultDto;
	}
}
