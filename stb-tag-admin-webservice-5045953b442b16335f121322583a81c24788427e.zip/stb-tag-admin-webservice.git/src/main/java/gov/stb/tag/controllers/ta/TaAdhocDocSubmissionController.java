package gov.stb.tag.controllers.ta;

import com.google.common.base.Strings;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.adhocdoc.ma.TaAdhocDocDto;
import gov.stb.tag.dto.ta.adhocdoc.ma.TaAdhocDocItemDto;
import gov.stb.tag.dto.ta.adhocdoc.ma.TaAdhocDocSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.*;
import gov.stb.tag.model.*;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaAdhocDocSubmissionRepository;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(path = "/api/v1/ta/adhoc-filing-doc")
@Transactional
public class TaAdhocDocSubmissionController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaAdhocDocSubmissionRepository taAdhocDocSubmissionRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;

	public static final Object[] docTypeList = { Codes.TaDocumentTypes.TA_DOC_MANAGEMENT_ACCOUNTS };

	// to create new or get existing application details
	@RequestMapping(value = "/load", method = RequestMethod.GET)
	public TaAdhocDocDto loadNewOrPending() {
		User currentUser = taAdhocDocSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = currentUser.getTravelAgent().getLicence();
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(licence)) {
			// Check if TA has application pending approval, if yes, TA cannot submit another
			Application application = taAdhocDocSubmissionRepository.getPendingApplicationFromLicenceId(licence.getId(), Codes.ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION);
			if (application == null) {
				TaAdhocDocDto dto = TaAdhocDocDto.buildFromNew(cache, taAnnualFilingRepository.getTaAnnualFilingPendingTA(licence.getId(), Codes.ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION, Boolean.TRUE, false),
						fileHelper);
				return dto;
			} else {
				return this.buildAdhocDocDto(application.getId());
			}
		}

		return null;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaAdhocDocDto dto) {

		Application application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION,
				(taAdhocDocSubmissionRepository.getLicenseeUserByUserId(getUser().getId()).getTravelAgent().getLicence().getId()), dto.isOfflineSubmission(), false);
		appHelper.forward(application, true);

		// 2. Save files uploaded by user
		for (FileDto doc : dto.getDocuments()) {
			fileHelper.saveFile(application, doc);
		}

		// 3. Save fields in form
		this.saveApplicationFields(dto, new TaAdhocDocSubmission(), application);

		// 4. Update filing status
		TaFilingCondition filing = taAdhocDocSubmissionRepository.get(TaFilingCondition.class, dto.getFilingDto().getAnnualFilingId());
		if (filing != null) {
			filing.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_APPROVAL));
			filing.setRectifiedApplication(application);
			taAdhocDocSubmissionRepository.save(filing);
		}
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateApplication(@RequestPart(name = "application") TaAdhocDocDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {
		// 1. Save application actions
		Application application = taAdhocDocSubmissionRepository.get(Application.class, dto.getApplicationId());
		appHelper.forward(application, true);

		// 2. Delete files deleted by user
		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}
		}

		// 3. Save additional files uploaded by user
		for (FileDto doc : dto.getDocuments()) {
			if (doc.getPublicFileId() == null) {
				fileHelper.saveFile(application, doc);
			}
		}

		// 4. Save changes made by user
		this.saveApplicationFields(dto, taAdhocDocSubmissionRepository.getApplication(application.getId()), application);

		// 5. Update filing status
		TaFilingCondition filing = taAdhocDocSubmissionRepository.get(TaFilingCondition.class, dto.getFilingDto().getAnnualFilingId());
		if (filing != null) {
			filing.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_APPROVAL));
			filing.setRectifiedApplication(application);
			taAdhocDocSubmissionRepository.save(filing);
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaAdhocDocItemDto> getList(TaAdhocDocSearchDto searchDto) {
		return taAdhocDocSubmissionRepository.getPendingList(searchDto, getUser().getId());
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaAdhocDocDto getApplication(@PathVariable Integer id) {
		User currentUser = taAdhocDocSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
			return buildAdhocDocDto(id);
		}
		return null;
	}

	// to approve, reject, rfa
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaAdhocDocSubmission doc = taAdhocDocSubmissionRepository.getApplication(id);
		Application app = doc.getApplication();

		TaFilingCondition docFiling = doc.getTaFilingCondition();

		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			if (appHelper.hasFinalApproved(app)) {
				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taMsgType = Codes.EmailType.TA_UPON_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;
				if (docFiling != null) {
					docFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_APPROVED));
				}
			}
			break;
		case ACTION_REJECT:
			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;
			if (docFiling != null) {
				if (LocalDate.now().isAfter(docFiling.getDueDate())) {
					docFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_LATE));
				} else {
					docFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_SUBMISSION));
				}
				docFiling.setRectifiedApplication(null);
			}
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
				statusCode = Codes.Statuses.TA_APP_RFA;
				if (docFiling != null) {
					docFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_RFA));
				}
			}

			appHelper.rfa(app, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());

			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(app.getLicence().getTravelAgent(), app, taAlertMsg, Codes.Modules.MOD_TA, app.getType(), "../ta-doc-submission/" + app.getId(), cache.getStatus(statusCode));

			/* Send email to notify TA */
			String url = String.format(properties.applicationUrl, "ta-doc-submission/" + app.getId());
			emailHelper.emailTaUponAction(app, taMsgType, url);
		}
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taAdhocDocSubmissionRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void saveApplicationFields(TaAdhocDocDto dto, TaAdhocDocSubmission submission, Application application) {
		if (submission == null) {
			submission = new TaAdhocDocSubmission();
		}
		submission.setApplication(application);
		submission.setTaFilingCondition(taAdhocDocSubmissionRepository.get(TaFilingCondition.class, dto.getFilingDto().getAnnualFilingId()));
		taAdhocDocSubmissionRepository.save(submission);
	}

	private TaAdhocDocDto buildAdhocDocDto(Integer applicationId) {
		TaAdhocDocSubmission doc = taAdhocDocSubmissionRepository.getApplication(applicationId);
		return TaAdhocDocDto.buildFromApplication(cache, appHelper, workflowHelper, doc, fileHelper);
	}

}
