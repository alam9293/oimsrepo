package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.filingrequest.TaAdhocFilingRequestItemDto;
import gov.stb.tag.dto.ta.filingrequest.TaAdhocFilingRequestSearchDto;
import gov.stb.tag.dto.ta.filingrequest.TaAdhocRequestDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAdhocFilingRequest;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.ta.TaAdhocFilingRequestRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/filing-request")
@Transactional
public class TaAdhocFilingRequestController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cacheHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	TaAdhocFilingRequestRepository taAdhocFilingRequestRepository;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	TaRenewalRepository taRenewalRepository;

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaAdhocFilingRequestItemDto> getTaFilingRequests(TaAdhocFilingRequestSearchDto searchDto) {
		ResultDto<TaAdhocFilingRequest> result = taAdhocFilingRequestRepository.getList(searchDto, getUser().getId());
		ResultDto<TaAdhocFilingRequestItemDto> resultDto = new ResultDto<TaAdhocFilingRequestItemDto>();

		resultDto.setTotal(result.getTotal());
		resultDto.setResult(result.getResult());
		resultDto.setSuccessFlag(result.getSuccessFlag());
		Object[] records = new Object[result.getModels().size()];
		resultDto.setRecords(records);
		int i = 0;
		if (result.getModels().size() > 0) {
			for (TaAdhocFilingRequest row : result.getModels()) {
				TaAdhocFilingRequestItemDto dto = TaAdhocFilingRequestItemDto.buildFilingRequestItemDto(row, workflowHelper);
				records[i++] = dto;
			}
		}
		return resultDto;
	}

	// to load filing details for travel agent's licence id
	@RequestMapping(value = "/view/travel-agents", method = RequestMethod.GET)
	public TaAdhocRequestDto getTaForAdhocFilingRequest(TaAdhocFilingRequestSearchDto searchDto) {
		TaAdhocRequestDto resultDto = TaAdhocRequestDto.buildAdhocFilingDto(cacheHelper, null, new TaAdhocRequestDto(), taAdhocFilingRequestRepository.get(Licence.class, searchDto.getLicenceId()),
				workflowHelper);
		resultDto.setReqType(new ListableDto(cache.getType(searchDto.getReqType())));
		resultDto.setWorkType(new ListableDto(cache.getType(Codes.TA_ADHOC_REQS.get(resultDto.getReqType().getKey().toString()).get(0))));
		resultDto.setFy(LocalDate.now().getYear());

		// Check if there is any pending request for TA
		List<TaAdhocFilingRequest> adHocFilingReqPendingList = taAdhocFilingRequestRepository.getAdhocRequestPendingTa(searchDto.getLicenceId(), searchDto.getReqType(), null);
		if (adHocFilingReqPendingList != null && adHocFilingReqPendingList.size() > 0) {
			// for (TaAdhocFilingRequest row : adHocFilingReqPendingList) {
			// resultDto.getPastRequests().add(TaAdhocRequestDto.buildAdhocFilingDto(cacheHelper, row, new TaAdhocRequestDto(), null, workflowHelper));
			//
			// }
			resultDto.setErrorMsg("Unable to create new request, the TA has " + cache.getType(searchDto.getReqType()).getLabel() + " pending approval.");
		}

		if (resultDto.getWorkflowId() == null) {
			resultDto = resultDto.buildNewWorkflowDto(cache, null, resultDto, workflowHelper, resultDto.getWorkType().getKey().toString());
		}

		return resultDto;
	}

	// to save/update request details
	@RequestMapping(path = { "/save", "/update", }, method = RequestMethod.POST)
	public Integer saveAdhocRequest(@RequestBody TaAdhocRequestDto dto) throws IOException {

		if (dto != null) {
			Licence licenceModel = taAdhocFilingRequestRepository.get(Licence.class, dto.getLicenceId());
			TaAdhocFilingRequest model;
			if (dto.getAdhocFilingRequestId() != null) {
				model = taAdhocFilingRequestRepository.get(TaAdhocFilingRequest.class, dto.getAdhocFilingRequestId());
				Workflow workflow = model.getWorkflow();
				workflow.setType(cacheHelper.getType(dto.getWorkType().getKey().toString()));
				taAdhocFilingRequestRepository.saveOrUpdate(workflow);
			} else {
				model = new TaAdhocFilingRequest();
				Workflow workflow = workflowHelper.saveNewWorkflow(dto.getWorkType().getKey().toString(), null, null, null, Boolean.FALSE, licenceModel);
				model.setWorkflow(workflow);
			}

			model = TaAdhocRequestDto.updateModelFromDto(cache, model, dto, licenceModel);
			taAdhocFilingRequestRepository.saveOrUpdate(model);

			return model.getId();
		}
		return null;
	}

	// to approve, reject, route
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaAdhocFilingRequest reqModel = taAdhocFilingRequestRepository.get(TaAdhocFilingRequest.class, id);
		Workflow workflow = reqModel.getWorkflow();
		switch (action) {
		case ACTION_APPROVE:
			if (workflow.getLastAction() == null) {
				workflowHelper.forward(workflow, Boolean.TRUE, dto.getInternalRemarks(), null, null, null);
			} else {
				workflowHelper.forward(workflow, Boolean.FALSE, dto.getInternalRemarks(), null, null, null);
				if (workflowHelper.hasFinalApproved(workflow)) {
					// create filing condition, send email
					TaFilingCondition filingModel = new TaFilingCondition();
					filingModel = setFilingCondtions(filingModel, reqModel);
					reqModel.setTaFiling(filingModel);
					taAdhocFilingRequestRepository.save(reqModel);

					String url = Codes.TA_APP_LINKS.get(filingModel.getApplicationType().getCode()).get(0);
					alertHelper.createAlertForFiling(filingModel.getLicence().getTravelAgent(), filingModel, Messages.Alerts.TA_ADHOC_FILING_SUBMISSION_NOTIFY, Codes.Modules.MOD_TA,
							filingModel.getApplicationType(), "../" + url, null);
					emailHelper.emailTaForFilingSubmission(filingModel, Codes.TA_APP_LINKS.get(filingModel.getApplicationType().getCode()).get(1), String.format(properties.applicationUrl, url));

					if (filingModel.getApplicationType().getCode().equalsIgnoreCase(ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION)) {
						// Check if TA is in renewal this year
						TaLicenceRenewalExerciseTa renewalTa = taRenewalRepository.getTaLicenceRenewalExerciseTaForYear(filingModel.getLicence().getId(), LocalDate.now());
						if (renewalTa != null && renewalTa.getMaFilingCondition() == null) {
							renewalTa.setMaFilingCondition(filingModel);
							taRenewalRepository.saveOrUpdate(filingModel);
						}
					}

				}

			}
			break;
		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
			if (workflowHelper.hasFinalApprovedOrRejected(workflow)) {
				throw new ValidationException("Routing can only be applied to pending requests.");
			}
			workflowHelper.rfa(workflow, dto.getRouteStatus(), dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;
		}
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TaAdhocRequestDto getDetails(@PathVariable Integer id) {
		TaAdhocFilingRequest extension = taAdhocFilingRequestRepository.get(TaAdhocFilingRequest.class, id);

		TaAdhocRequestDto resultDto = TaAdhocRequestDto.buildAdhocFilingDto(cacheHelper, extension, new TaAdhocRequestDto(), extension.getWorkflow().getLicence(), workflowHelper);

		return resultDto;
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = taAdhocFilingRequestRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private TaFilingCondition setFilingCondtions(TaFilingCondition filingModel, TaAdhocFilingRequest requestModel) {
		filingModel.setLicence(requestModel.getWorkflow().getLicence());
		filingModel.setApplicationType(cache.getType(Codes.TA_ADHOC_REQS.get(requestModel.getReqType().getCode()).get(1)));
		filingModel.setRequestedAsAtDate(requestModel.getRequestedAsAtDate());
		filingModel.setDueDate(requestModel.getDueDate());
		filingModel.setRemarks(requestModel.getRequestRemarks());
		filingModel.setStatus(cache.getStatus(Statuses.TA_FILING_PEND_SUBMISSION));
		filingModel.setFy(requestModel.getFy());
		taAdhocFilingRequestRepository.save(filingModel);
		return filingModel;
	}
}
