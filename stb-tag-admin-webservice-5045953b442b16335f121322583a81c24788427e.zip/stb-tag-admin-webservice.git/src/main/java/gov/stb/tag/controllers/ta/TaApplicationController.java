package gov.stb.tag.controllers.ta;

import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AssignDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.ta.application.TaApplicationBasicDto;
import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;
import gov.stb.tag.dto.ta.application.TaApplicationSearchItemDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.model.User;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ta.TaApplicationRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/applications")
@Transactional
public class TaApplicationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaApplicationRepository taApplicationRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	ApplicationHelper appHelper;

	// to retrieve all TA applications
	@RequestMapping(method = RequestMethod.GET, path = { "/view", "/history" })
	public ResultDto<TaApplicationSearchItemDto> getList(TaApplicationSearchDto searchDto) {
		User currentUser = taApplicationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			searchDto.setLicenceId(currentUser.getTravelAgent().getLicence().getId());
		}
		return taApplicationRepository.getList(searchDto, getUser().getId());
	}

	// to retrieve all TA applications
	@RequestMapping(method = RequestMethod.GET, path = { "/view/{id}", "/history/{id}" })
	public TaApplicationBasicDto getApplication(@PathVariable Integer id) {
		User currentUser = taApplicationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
		}
		return taApplicationRepository.getApplicationBasic(id);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view/{id}/workflow-actions")
	public ResultDto<WorkflowAction> getWorkflowActionsList(@PathVariable Integer id, WorkflowActionSearchDto searchDto) {
		ResultDto<WorkflowAction> results = taApplicationRepository.getWorkflowActionsList(id, searchDto);
		var models = results.getModels();
		models.stream().forEach(u -> {
			var dto = new WorkflowActionDto(cache, u);
			results.getRecords()[models.indexOf(u)] = dto;
		});
		return results;
	}

	@RequestMapping(value = "/re-assign", method = RequestMethod.POST)
	public void reAssignAppWorkflow(@RequestBody AssignDto dto) {
		if (dto.getWorkflowIds() != null && dto.getWorkflowIds().size() > 0) {
			reAssignWorkflow(dto);
		}
		if (dto.getApplicationIds() != null && dto.getApplicationIds().size() > 0) {
			reAssignApplication(dto);
		}
	}
}
