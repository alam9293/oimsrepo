package gov.stb.tag.controllers.ta;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.TaDocumentTypes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.branch.TaBranchDto;
import gov.stb.tag.dto.ta.branchapplication.TaBranchApplicationBatchDto;
import gov.stb.tag.dto.ta.branchapplication.TaBranchApplicationDto;
import gov.stb.tag.dto.ta.branchapplication.TaBranchApplicationItemDto;
import gov.stb.tag.dto.ta.branchapplication.TaBranchApplicationSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaBranchApplication;
import gov.stb.tag.model.TaBranchApplicationBatch;
import gov.stb.tag.model.TaELicenceRequest;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.BaseRepository;
import gov.stb.tag.repository.ta.TaBranchApplicationRepository;
import gov.stb.tag.repository.ta.TaBranchRepository;
import gov.stb.tag.repository.ta.TaELicenceRequestRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/branch-applications")
@Transactional
public class TaBranchApplicationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	BaseRepository baseRepository;
	@Autowired
	TaBranchApplicationRepository taBranchApplicationRepository;
	@Autowired
	TaBranchRepository taBranchRepository;
	@Autowired
	TaELicenceRequestRepository taELicenceRequestRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	LicenceHelper licenceHelper;

	// admin - ta-branch-list
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaBranchApplicationItemDto> getList(TaBranchApplicationSearchDto taBranchApplicationSearchDto) {
		return taBranchApplicationRepository.getPendingList(taBranchApplicationSearchDto, getUser().getId());
	}

	// admin - ta-branch-view
	@RequestMapping(value = "/view/details/{id}", method = RequestMethod.GET)
	public TaBranchApplicationBatchDto getApplication(@PathVariable Integer id) {
		List<TaBranchApplication> taBranchApplicationsPending = taBranchApplicationRepository.getApplications(id, null, null);
		TaBranchApplicationBatchDto taBranchApplicationBatchDto = TaBranchApplicationBatchDto.buildFromApplication(cache, appHelper, paymentHelper, taBranchApplicationsPending, fileHelper);
		return taBranchApplicationBatchDto;
	}

	// admin - ta-branch-view
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {

		List<TaBranchApplication> taBranchApplicationList = taBranchApplicationRepository.getApplications(id, null, null);
		Application application = taBranchApplicationList.get(0).getTaBranchApplicationBatch().getApplication();

		String taAlertMsg = null;
		String taEmailType = null;
		String status = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(application, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(application)) {
				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taEmailType = Codes.EmailType.TA_BRANCH_APPROVAL;
				status = Codes.Statuses.TA_APP_APPROVED;

				List<TaBranchApplication> newBranchApplicationList = taBranchApplicationList.stream().filter(u -> Codes.Types.TA_APP_BRANCH_NEW.equals(u.getType().getCode()))
						.collect(Collectors.toList());

				// if new branch application found, create payment only
				if (CollectionUtils.isNotEmpty(newBranchApplicationList)) {
					logger.info("new branch application found.");
					// Has payment
					int payAmount = newBranchApplicationList.size() * 40;
					PaymentRequest paymentRequest = paymentHelper.savePaymentRequest(application.getApplicationNo(), Codes.TaPaymentRequestTypes.PAYREQ_TA_BRANCH_A,
							application.getLicence().getTravelAgent().getUen(), application.getLicence().getTravelAgent().getName(), new BigDecimal(payAmount), "TA Branch Licence Application Fee",
							null, false, true, application.getLicence().getLicenceNo(), application.getLicence().getTravelAgent().getEmailAddress(), null);

					TaBranchApplicationBatch taBranchApplicationBatch = taBranchApplicationList.get(0).getTaBranchApplicationBatch();
					taBranchApplicationBatch.setAppFeeBillRefNo(paymentRequest.getBillRefNo());
					taBranchApplicationRepository.save(taBranchApplicationBatch);

				} else {
					logger.info("no new branch application found.");

					// check if there is pending e-licence request
					TaELicenceRequest taELicenceReqModel = taELicenceRequestRepository.getPendingApplication(application.getLicence().getId());

					// process branch UPDATE application
					List<TaBranchApplication> updateBranchAppList = taBranchApplicationList.stream().filter(u -> Codes.Types.TA_APP_BRANCH_UPDATE.equals(u.getType().getCode()))
							.collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(updateBranchAppList)) {
						updateBranchAppList.forEach(u -> {
							licenceHelper.ceaseBranchLicence(u);
							if (taELicenceReqModel == null) {
								logger.info("e-licence view flag (Branch approve action) : " + application.getLicence().getIsViewable());
								if (application.getLicence().getIsViewable() != null && application.getLicence().getIsViewable() == Codes.ELicenceView.VIEW) {
									// set e-licence download flag
									u.getTaBranch().setIsDownloadable(Codes.ELicenceDownloadRequest.RESET);
								}
							}
							licenceHelper.saveNewBranchLicence(u);
						});
					}

					// process branch CEASE application
					List<TaBranchApplication> ceaseBranchAppList = taBranchApplicationList.stream().filter(u -> Codes.Types.TA_APP_BRANCH_CEASE.equals(u.getType().getCode()))
							.collect(Collectors.toList());
					if (CollectionUtils.isNotEmpty(ceaseBranchAppList)) {
						ceaseBranchAppList.forEach(u -> {
							licenceHelper.ceaseBranchLicence(u);
						});
					}

					taBranchApplicationList.forEach(u -> u.setStatus(cache.getStatus(Codes.Statuses.TA_APP_APPROVED)));
					baseRepository.saveOrUpdate(taBranchApplicationList);

				}
			}
			break;

		case ACTION_REJECT:
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taEmailType = Codes.EmailType.TA_UPON_REJECTION;
			status = Codes.Statuses.TA_APP_REJECTED;

			taBranchApplicationList.forEach(u -> u.setStatus(cache.getStatus(Codes.Statuses.TA_APP_REJECTED)));
			baseRepository.saveOrUpdate(taBranchApplicationList);

			appHelper.reject(application, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			status = dto.getRouteStatus();
			if (StringUtils.equals(status, Codes.Statuses.TA_APP_RFA)) {
				taEmailType = Codes.EmailType.TA_UPON_RFA;
				taAlertMsg = Messages.Alerts.APP_RFA;

				taBranchApplicationList.forEach(u -> u.setStatus(cache.getStatus(Codes.Statuses.TA_APP_RFA)));
				baseRepository.saveOrUpdate(taBranchApplicationList);
			}

			appHelper.rfa(application, status, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			// send alert to notify TA
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}
			alertHelper.createAlert(application.getLicence().getTravelAgent(), application, taAlertMsg, Codes.Modules.MOD_TA, application.getType(),
					"../ta-application-branch-licence/" + application.getId(), cache.getStatus(status));

			// Send email to notify TA
			String url = String.format(properties.applicationUrl, "ta-application-branch-licence/" + application.getId());

			emailHelper.emailTaUponAction(application, taEmailType, url);
		}

	}

	@RequestMapping(value = { "/view/{id}", "/new/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaBranchApplicationBatchDto getApplicationById(@PathVariable Integer id) {
		User currentUser = taBranchApplicationRepository.getLicenseeUserByUserId(getUser().getId());
		Application application = new Application();
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			application = appHelper.isAppBelongToTA(id, currentUser);
		}
		List<TaBranchApplication> taBranchApplicationsPending = taBranchApplicationRepository.getApplications(application.getId(), currentUser.getTravelAgent().getId(), null);
		TaBranchApplicationBatchDto taBranchApplicationBatchDto = TaBranchApplicationBatchDto.buildFromApplication(cache, appHelper, paymentHelper, taBranchApplicationsPending, fileHelper);
		return taBranchApplicationBatchDto;
	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taBranchApplicationRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	// Portal
	@RequestMapping(value = { "/new", "/load" }, method = RequestMethod.GET)
	public TaBranchApplicationBatchDto loadNew() {
		TaBranchApplicationBatchDto taBranchApplicationBatchDto = new TaBranchApplicationBatchDto();
		List<TaBranchDto> taBranchDtoList = new ArrayList<TaBranchDto>();
		User currentUser = taBranchApplicationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			List<TaBranch> taActiveBranches = taBranchApplicationRepository.getBranchesByStatus(currentUser.getTravelAgent().getLicence().getId(),
					Arrays.asList(Codes.Statuses.TA_BRANCH_ACTIVE, Codes.Statuses.TA_BRANCH_M_PENDING_RENEWAL));
			taActiveBranches.forEach((temp) -> {
				TaBranchDto taBranchDto = TaBranchDto.buildFromTaBranch(cache, temp);
				taBranchDtoList.add(taBranchDto);
			});
			List<TaBranchApplication> taBranchApplicationsPending = taBranchApplicationRepository.getPendingBranches(currentUser.getTravelAgent().getLicence().getId());
			List<TaBranch> taCeasedBranches = taBranchApplicationRepository.getBranchesByStatus(currentUser.getTravelAgent().getLicence().getId(),
					Arrays.asList(Codes.Statuses.TA_BRANCH_CEASED, Codes.Statuses.TA_BRANCH_M_REVOKED, Codes.Statuses.TA_BRANCH_M_CEASED, Codes.Statuses.TA_BRANCH_M_SUSPEND));
			taCeasedBranches.forEach((temp) -> {
				TaBranchDto taBranchDto = TaBranchDto.buildFromTaBranch(cache, temp);
				taBranchDtoList.add(taBranchDto);
			});

			taBranchApplicationBatchDto = TaBranchApplicationBatchDto.buildFromApplication(cache, appHelper, paymentHelper, taBranchApplicationsPending, taActiveBranches, taCeasedBranches,
					fileHelper);
		}
		return taBranchApplicationBatchDto;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveApplication(@RequestBody List<TaBranchApplicationDto> taBranchApplicationDtoList) {
		User currentUser = taBranchApplicationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			Licence licence = currentUser.getTravelAgent().getLicence();
			Application application = new Application();
			TaBranchApplicationBatch taBranchApplicationBatch = new TaBranchApplicationBatch();
			for (TaBranchApplicationDto applicationDto : taBranchApplicationDtoList) {
				TaBranchApplication applicationBranch = new TaBranchApplication();
				if (!Strings.isNullOrEmpty(applicationDto.getApplicationBranchId())) {
					applicationBranch = taBranchApplicationRepository.get(TaBranchApplication.class, Integer.parseInt(applicationDto.getApplicationBranchId()));
					taBranchApplicationBatch = taBranchApplicationRepository.get(TaBranchApplicationBatch.class, applicationBranch.getTaBranchApplicationBatch().getId());
					application = taBranchApplicationBatch.getApplication();
				} else if (application.getId() == null) {
					application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_BRANCH, licence.getId(), false, false);
				}

				taBranchApplicationBatch.setApplication(application);
				baseRepository.save(taBranchApplicationBatch);

				applicationBranch.setTenancyStartDate(applicationDto.getTenancyStartDate() != null ? applicationDto.getTenancyStartDate() : null);
				applicationBranch.setTenancyEndDate(applicationDto.getTenancyEndDate() != null ? applicationDto.getTenancyEndDate() : null);

				if ("New".equalsIgnoreCase(applicationDto.getType())) {
					applicationBranch.setType(cache.getType(Codes.Types.TA_APP_BRANCH_NEW));
					Address branchAdd = new Address();
					TaBranch taBranch = new TaBranch();
					if (applicationDto.getBranchId() != null && !"".equals(applicationDto.getBranchId())) {
						taBranch = baseRepository.get(TaBranch.class, applicationDto.getBranchId());
						branchAdd = baseRepository.get(Address.class, taBranch.getAddress().getId());
					}
					branchAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
					branchAdd.setPostal(applicationDto.getPostalCode());
					branchAdd.setPremiseType(cache.getType(applicationDto.getPremisesType()));
					branchAdd.setStreet(applicationDto.getStreet());
					branchAdd.setBlock(applicationDto.getBlk());
					branchAdd.setBuilding(applicationDto.getBuildingName());
					if (applicationDto.getLevel() != null && !"".equals(applicationDto.getLevel())) {
						branchAdd.setFloor(applicationDto.getLevel());
					}
					if (applicationDto.getUnit() != null && !"".equals(applicationDto.getUnit())) {
						branchAdd.setUnit(applicationDto.getUnit());
					}

					if (applicationDto.getSelectedFile() != null) {

						if (applicationDto.getSelectedFile().getPublicFileId() == null) {

							File file = new File();
							file.setFilename(applicationDto.getSelectedFile().getProcessedName());
							file.setExtension(applicationDto.getSelectedFile().getExtension());
							file.setOriginalFilename(applicationDto.getSelectedFile().getOriginalName());
							file.setPath(applicationDto.getSelectedFile().getPath());

							file.setSize(applicationDto.getSelectedFile().getSize());
							file.setPublicFileId(applicationDto.getSelectedFile().getId()); // when passing in from internet, the public file id is the id
							file.setHash(applicationDto.getSelectedFile().getHash());
							file.setTransferStatus(cache.getStatus(Codes.Statuses.TXF_PENDING));

							file.setDescription(cache.getType(TaDocumentTypes.TA_DOC_TENANCY).getLabel());
							//
							ApplicationFile appFile = new ApplicationFile();
							appFile.setApplication(application);
							appFile.setDocumentType(cache.getType(TaDocumentTypes.TA_DOC_TENANCY));
							appFile.setFile(file);
							baseRepository.save(file);
							applicationBranch.setTenancyDoc(file);

							baseRepository.save(file);
							baseRepository.save(appFile);
						} else {
							File file = fileHelper.getFile(applicationDto.getSelectedFile().getId());
							applicationBranch.setTenancyDoc(file);
						}
					}
					applicationBranch.setAddress(branchAdd);
					applicationBranch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_PROCESSING_APPROVAL));
					applicationBranch.setTenancyStartDate(applicationDto.getTenancyStartDate());
					applicationBranch.setTenancyEndDate(applicationDto.getTenancyEndDate());
					baseRepository.save(branchAdd);
					applicationBranch.setTaBranchApplicationBatch(taBranchApplicationBatch);
					baseRepository.save(applicationBranch);
				} else if ("Update".equalsIgnoreCase(applicationDto.getType())) {
					applicationBranch.setType(cache.getType(Codes.Types.TA_APP_BRANCH_UPDATE));
					Address branchAdd = new Address();
					branchAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
					branchAdd.setPostal(applicationDto.getPostalCode());
					branchAdd.setPremiseType(cache.getType(applicationDto.getPremisesType()));
					branchAdd.setStreet(applicationDto.getStreet());
					branchAdd.setBlock(applicationDto.getBlk());
					branchAdd.setBuilding(applicationDto.getBuildingName());
					if (applicationDto.getLevel() != null && !applicationDto.getLevel().equals("")) {
						branchAdd.setFloor(applicationDto.getLevel());
					}
					if (applicationDto.getUnit() != null && !applicationDto.getUnit().equals("")) {
						branchAdd.setUnit(applicationDto.getUnit());
					}
					applicationBranch.setAddress(branchAdd);
					applicationBranch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_PROCESSING_UPDATE));
					if (applicationDto.getToReplace().getBranchId() != null && !applicationDto.getToReplace().getBranchId().equals("")) {
						TaBranch taBranchFormer = baseRepository.get(TaBranch.class, Integer.parseInt(applicationDto.getToReplace().getBranchId()));
						applicationBranch.setTaBranch(taBranchFormer);

					}
					if (applicationDto.getSelectedFile() != null) {
						if (applicationDto.getSelectedFile().getPublicFileId() == null) {

							File file = new File();
							file.setFilename(applicationDto.getSelectedFile().getProcessedName());
							file.setExtension(applicationDto.getSelectedFile().getExtension());
							file.setOriginalFilename(applicationDto.getSelectedFile().getOriginalName());
							file.setPath(applicationDto.getSelectedFile().getPath());
							file.setSize(applicationDto.getSelectedFile().getSize());
							file.setPublicFileId(applicationDto.getSelectedFile().getId()); // when passing in from internet, the public file id is the id
							file.setHash(applicationDto.getSelectedFile().getHash());
							file.setTransferStatus(cache.getStatus(Codes.Statuses.TXF_PENDING));

							file.setDescription(cache.getType(TaDocumentTypes.TA_DOC_TENANCY).getLabel());
							//
							ApplicationFile appFile = new ApplicationFile();
							appFile.setApplication(application);
							appFile.setDocumentType(cache.getType(TaDocumentTypes.TA_DOC_TENANCY));
							appFile.setFile(file);
							baseRepository.save(file);
							applicationBranch.setTenancyDoc(file);

							baseRepository.save(file);
							baseRepository.save(appFile);
						} else {
							File file = baseRepository.get(File.class, applicationDto.getSelectedFile().getId());
							applicationBranch.setTenancyDoc(file);
						}
					}
					applicationBranch.setTenancyStartDate(applicationDto.getTenancyStartDate());
					applicationBranch.setTenancyEndDate(applicationDto.getTenancyEndDate());
					baseRepository.save(branchAdd);
					applicationBranch.setTaBranchApplicationBatch(taBranchApplicationBatch);
					baseRepository.save(applicationBranch);

				} else if ("Cessation".equalsIgnoreCase(applicationDto.getType())) {
					applicationBranch.setType(cache.getType(Codes.Types.TA_APP_BRANCH_CEASE));
					TaBranch taBranch = baseRepository.get(TaBranch.class, Integer.parseInt(applicationDto.getBranchId()));
					applicationBranch.setAddress(taBranch.getAddress());
					applicationBranch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_PROCESSING_CESSATION));
					applicationBranch.setTaBranch(taBranch);
					applicationBranch.setTaBranchApplicationBatch(taBranchApplicationBatch);
					baseRepository.save(applicationBranch);
				}

				logger.info("applicationBranch " + applicationBranch.getId());
				logger.info("taBranchApplicationBatch " + taBranchApplicationBatch.getId());
				logger.info("application " + application.getId());

			}
			appHelper.forward(application, true);

		}
	}
}
