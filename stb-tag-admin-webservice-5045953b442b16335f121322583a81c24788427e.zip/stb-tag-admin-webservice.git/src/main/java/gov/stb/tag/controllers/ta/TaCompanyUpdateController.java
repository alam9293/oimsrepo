package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.TravelAgentBasicDto;
import gov.stb.tag.dto.ta.companyupdate.TaCompanyDetailsDto;
import gov.stb.tag.dto.ta.companyupdate.TaCompanyInboundOutboundDto;
import gov.stb.tag.dto.ta.companyupdate.TaCompanyUpdateSubmissionDto;
import gov.stb.tag.dto.ta.companyupdate.TaCompanyUpdateSubmissionItemDto;
import gov.stb.tag.dto.ta.companyupdate.TaCompanyUpdateSubmissionSearchDto;
import gov.stb.tag.dto.ta.licence.TaLicenceDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaCompanyUpdate;
import gov.stb.tag.model.TaELicenceRequest;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.ta.TaBranchRepository;
import gov.stb.tag.repository.ta.TaCompanyUpdateRepository;
import gov.stb.tag.repository.ta.TaELicenceRequestRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/company-updates")
@Transactional
public class TaCompanyUpdateController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	TaCompanyUpdateRepository taCompanyUpdateRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TaELicenceRequestRepository taELicenceRequestRepository;
	@Autowired
	TaBranchRepository taBranchRepository;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TaCompanyUpdateSubmissionDto getIntranetApplication(@PathVariable Integer id) {
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			appHelper.isAppBelongToTA(id, currentUser);
		}
		TaCompanyUpdate taCompanyUpdate = taCompanyUpdateRepository.getApplication(id, null, false);
		TaCompanyUpdateSubmissionDto taCompanyUpdateSubmissionDto = TaCompanyUpdateSubmissionDto.buildFromApplication(cache, appHelper, taCompanyUpdate, fileHelper);

		return taCompanyUpdateSubmissionDto;
	}

	@RequestMapping(path = { "/new/licence-details" }, method = RequestMethod.GET)
	public TaLicenceDto getCurrentLicenceDetails() {
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		TaLicenceDto resultDto = new TaLicenceDto();
		return resultDto.buildFromLicence(cache, currentUser.getTravelAgent().getLicence(), resultDto);
	}

	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {

		TaCompanyUpdate taCompanyUpdate = taCompanyUpdateRepository.getApplication(id, null, false);
		Application application = taCompanyUpdate.getApplication();

		String alertMsg = null;
		String emailType = null;
		String statusCode = null;
		boolean flag = true; // for operation address and licensee change flag

		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(application, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			if (appHelper.hasFinalApproved(application)) {
				alertMsg = Messages.Alerts.APP_APPROVE;
				emailType = Codes.EmailType.TA_COMP_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				Licence licenceModel = new Licence();
				licenceModel = application.getLicence();

				TravelAgent travelAgent = taCompanyUpdateRepository.get(TravelAgent.class, taCompanyUpdate.getApplication().getLicence().getTravelAgent().getId());

				String originalOpAddr = travelAgent.getOperatingAddress().getSingleLineAddressDisplay();
				String updatedOpAddr = taCompanyUpdate.getOperatingAddress().getSingleLineAddressDisplay();
				if (originalOpAddr != null && updatedOpAddr != null && !originalOpAddr.trim().equalsIgnoreCase(updatedOpAddr.trim())) {
					flag = false; // licensee change flag
				}

				if (!travelAgent.getName().equalsIgnoreCase(taCompanyUpdate.getCompanyName())) {
					travelAgent.setFormerName(travelAgent.getName());
					travelAgent.setName(taCompanyUpdate.getCompanyName());
					travelAgent.setDisplayName(null);
					flag = false; // operation address change flag
				}
				if (!Entities.equals(travelAgent.getFormOfBusiness(), taCompanyUpdate.getFormOfBusiness())) {
					travelAgent.setFormOfBusiness(taCompanyUpdate.getFormOfBusiness());
				}

				if (!Entities.equals(travelAgent.getBusinessConstitution(), taCompanyUpdate.getBusinessConstitution())) {
					travelAgent.setBusinessConstitution(taCompanyUpdate.getBusinessConstitution());
				}
				if (!Entities.equals(travelAgent.getPrincipleActivities(), taCompanyUpdate.getPrincipleActivities())) {
					travelAgent.setPrincipleActivities(taCompanyUpdate.getPrincipleActivities());
				}

				if (!Entities.equals(travelAgent.getSecondaryPrincipleActivities(), taCompanyUpdate.getSecondaryPrincipleActivities())) {
					travelAgent.setSecondaryPrincipleActivities(taCompanyUpdate.getSecondaryPrincipleActivities());
				}
				if (!Entities.equals(travelAgent.getIncorporatedPlace(), taCompanyUpdate.getPlaceIncorporated())) {
					travelAgent.setIncorporatedPlace(taCompanyUpdate.getPlaceIncorporated());
				}

				if (!Entities.equals(travelAgent.getEstablishmentStatus(), taCompanyUpdate.getEstablishmentStatus())) {
					travelAgent.setEstablishmentStatus(taCompanyUpdate.getEstablishmentStatus());
				}
				if (!Entities.equals(travelAgent.getTaSegmentation(), taCompanyUpdate.getTaSegmentation())) {
					travelAgent.setTaSegmentation(taCompanyUpdate.getTaSegmentation());
				}
				if ((travelAgent.getPaidUpCapital() != null && !travelAgent.getPaidUpCapital().equals(taCompanyUpdate.getPaidUpCapital())) || travelAgent.getPaidUpCapital() == null) {
					travelAgent.setPaidUpCapital(taCompanyUpdate.getPaidUpCapital());
				}
				if (!Objects.equals(taCompanyUpdate.getWebsiteUrl(), travelAgent.getWebsiteUrl())) {
					travelAgent.setWebsiteUrl(taCompanyUpdate.getWebsiteUrl());
				}
				if (!Objects.equals(travelAgent.getEmailAddress(), taCompanyUpdate.getEmailAddress())) {
					travelAgent.setEmailAddress(taCompanyUpdate.getEmailAddress());
				}
				if (!Objects.equals(travelAgent.getContactNo(), taCompanyUpdate.getContactNo())) {
					travelAgent.setContactNo(taCompanyUpdate.getContactNo());
				}
				if (!Objects.equals(travelAgent.getFaxNo(), taCompanyUpdate.getFaxNo())) {
					travelAgent.setFaxNo(taCompanyUpdate.getFaxNo());
				}
				if (!Objects.equals(travelAgent.getRegisteredAddress(), taCompanyUpdate.getRegisteredAddress())) {
					travelAgent.setRegisteredAddress(taCompanyUpdate.getRegisteredAddress());
				}
				if (!Objects.equals(travelAgent.getOperatingAddress(), taCompanyUpdate.getOperatingAddress())) {
					travelAgent.setOperatingAddress(taCompanyUpdate.getOperatingAddress());
					travelAgent.setDisplayAddress(null);
				}
				taCompanyUpdateRepository.save(travelAgent);

				// set licence printing
				appHelper.setTaApplicationPendingPrinting(application);

				if (!flag) {
					// update e-licence download flag
					logger.info("Licence Viewable flag (TA Company Update Approval) for Licence No " + licenceModel.getLicenceNo() + " : " + licenceModel.getIsViewable());
					if (licenceModel.getIsViewable() != null && licenceModel.getIsViewable() == Codes.ELicenceView.VIEW) {
						// check if there is pending e-licence request submission
						TaELicenceRequest taELicenceReqModel = taELicenceRequestRepository.getPendingApplication(licenceModel.getId());
						// If there is no pending submission, reset downloadflag to be able to re-download
						if (taELicenceReqModel == null) {
							taELicenceRequestRepository.resetELicenceRequest(licenceModel);
							List<TaBranch> branches = new ArrayList<TaBranch>();
							branches = travelAgentRepository.getActiveBranchesByLicenceId(travelAgent.getLicence().getId());
							for (TaBranch branch : branches) {
								taBranchRepository.resetBranchELicenceRequest(branch);
							}
						}
					} else {
						logger.info("(TACompanyUpdate Approve Action) - E-licence is not viewable for Licence No " + licenceModel.getLicenceNo());
					}
				}
			}
			break;

		case ACTION_REJECT:
			appHelper.reject(application, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			alertMsg = Messages.Alerts.APP_REJECT;
			emailType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				alertMsg = Messages.Alerts.APP_RFA;
				emailType = Codes.EmailType.TA_UPON_RFA;
			}

			appHelper.rfa(application, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);

		}

		if (alertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				alertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}
			alertHelper.createAlert(application.getLicence().getTravelAgent(), application, alertMsg, Codes.Modules.MOD_TA, application.getType(),
					"../ta-change-company-details/" + application.getId(), cache.getStatus(statusCode));

			String url = String.format(properties.applicationUrl, "ta-change-company-details/" + application.getId());
			emailHelper.emailTaUponAction(application, emailType, url);
		}

	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taCompanyUpdateRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	// to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaCompanyUpdateSubmissionItemDto> getList(TaCompanyUpdateSubmissionSearchDto searchDto) {
		ResultDto<TaCompanyUpdateSubmissionItemDto> resultDTO = new ResultDto<TaCompanyUpdateSubmissionItemDto>();
		resultDTO = taCompanyUpdateRepository.getPendingList(searchDto, getUser().getId());
		return resultDTO;
	}

	// Portal
	@RequestMapping(value = { "/new/business-entity", "/load/business-entity" }, method = RequestMethod.GET)
	public TaCompanyUpdateSubmissionDto loadBusinessEntity() {
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		TaCompanyUpdate taCompanyUpdate = taCompanyUpdateRepository.getApplication(null, currentUser.getTravelAgent().getId(), true);
		TaCompanyUpdateSubmissionDto taCompanyUpdateSubmissionDto = new TaCompanyUpdateSubmissionDto();
		Licence licence = currentUser.getTravelAgent().getLicence();
		taCompanyUpdateSubmissionDto.buildFromLicence(cache, licence, taCompanyUpdateSubmissionDto);

		// Licence licence = baseRepository.get(Licence.class, currentUser.getTravelAgent().getLicence().getId());
		if ((taCompanyUpdate) != null) {
			taCompanyUpdateSubmissionDto = TaCompanyUpdateSubmissionDto.buildFromApplication(cache, appHelper, taCompanyUpdate, fileHelper);
		} else {
			taCompanyUpdateSubmissionDto.setApplicationStatus(
					new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));

			// 2. Business Entity - New
			taCompanyUpdateSubmissionDto.setNewDetails(TaCompanyDetailsDto.buildFromApplication(cache, taCompanyUpdate));

			// 3. Business Entity - Current
			taCompanyUpdateSubmissionDto.setCurrentDetails(TaCompanyDetailsDto.buildFromLicence(cache, licence));

			// 4. Default to pull from EDH if new application
			taCompanyUpdateSubmissionDto.setIsEdhPopulated(true);

			// 5. Default Supporting Doc
			if (taCompanyUpdateSubmissionDto.getCompanyDetailsDocument() == null) {
				taCompanyUpdateSubmissionDto.setCompanyDetailsDocument(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_TENANCY), fileHelper));
			}
			if (taCompanyUpdateSubmissionDto.getAcra() == null) {
				taCompanyUpdateSubmissionDto.setAcra(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ), fileHelper));
			}
		}

		return taCompanyUpdateSubmissionDto;
	}

	// to submit new application details
	@RequestMapping(path = { "/save/business-entity", "/offline/save/business-entity" }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaCompanyUpdateSubmissionDto dto) throws IOException {
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = null;
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			licenceModel = currentUser.getTravelAgent().getLicence();
		} else {
			licenceModel = taCompanyUpdateRepository.get(Licence.class, dto.getLicenceId());
		}

		TaCompanyUpdate taCompanyUpdate = new TaCompanyUpdate();
		Application application = new Application();

		if (dto != null) {

			if (dto.getApplicationId() != null) { // Update existing
				application = taCompanyUpdateRepository.get(Application.class, dto.getApplicationId());
				appHelper.forward(application, true);

				taCompanyUpdate = taCompanyUpdateRepository.get(TaCompanyUpdate.class, dto.getId());
				taCompanyUpdate = updateTaCompanyUpdateDetails(dto, taCompanyUpdate);
				taCompanyUpdate.setApplication(application);
				taCompanyUpdate.setIsEdhPopulated(dto.getIsEdhPopulated());
				taCompanyUpdateRepository.update(taCompanyUpdate.getOperatingAddress());
				taCompanyUpdateRepository.update(taCompanyUpdate.getRegisteredAddress());

			} else { // save new
				application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_COMPANY_UPDATE, licenceModel.getId(), dto.isOfflineSubmission(), false);
				appHelper.forward(application, true);
				taCompanyUpdate = updateTaCompanyUpdateDetails(dto, taCompanyUpdate);
				taCompanyUpdate.setApplication(application);
				taCompanyUpdate.setIsEdhPopulated(dto.getIsEdhPopulated());
				taCompanyUpdateRepository.save(taCompanyUpdate.getOperatingAddress());
				taCompanyUpdateRepository.save(taCompanyUpdate.getRegisteredAddress());
			}

			TaCompanyUpdate snapshot = taCompanyUpdate.getPreviousValue() == null ? new TaCompanyUpdate() : taCompanyUpdate.getPreviousValue();
			snapshot = appHelper.snapshotCurrentCompanyDetails(snapshot, licenceModel);
			taCompanyUpdate.setPreviousValue(snapshot);
			taCompanyUpdateRepository.saveOrUpdate(snapshot);

			List<Integer> appFiles = new ArrayList<>();
			// 3. Save additional files uploaded by user
			if (dto.getCompanyDetailsDocument() != null) {
				if (dto.getCompanyDetailsDocument().getSize() != null && dto.getCompanyDetailsDocument().getPublicFileId() == null) {
					ApplicationFile appFile = fileHelper.saveFile(application, dto.getCompanyDetailsDocument());
					appFiles.add(appFile.getId());
				} else if (dto.getCompanyDetailsDocument().getId() != null) {
					ApplicationFile appFile = fileRepository.getAppFile(dto.getCompanyDetailsDocument().getId());
					appFiles.add(appFile.getId());
				}
			}
			if (dto.getAcra() != null) {
				if (dto.getAcra().getSize() != null && dto.getAcra().getPublicFileId() == null) {
					ApplicationFile appFile = fileHelper.saveFile(application, dto.getAcra());
					appFiles.add(appFile.getId());
				} else if (dto.getAcra().getId() != null) {
					ApplicationFile appFile = fileRepository.getAppFile(dto.getAcra().getId());
					appFiles.add(appFile.getId());
				}
			}

			if (dto.getOtherDocuments().size() > 0) {
				for (FileDto doc : dto.getOtherDocuments()) {
					if (doc.getPublicFileId() == null) {
						ApplicationFile appFile = fileHelper.saveFile(application, doc);
						appFiles.add(appFile.getId());
					} else {
						ApplicationFile appFile = fileRepository.getAppFile(doc.getId());
						appFiles.add(appFile.getId());
					}

				}
			}

			if (application.getApplicationFiles() != null) {
				for (ApplicationFile appFile : application.getApplicationFiles()) {
					if (!appFiles.contains(appFile.getId())) {
						fileHelper.deleteFile(appFile.getFile());
					}
				}
			}
			taCompanyUpdateRepository.saveOrUpdate(taCompanyUpdate);

		}

	}

	@RequestMapping(value = "/new/business-entity/{id}", method = RequestMethod.GET)
	public TaCompanyUpdateSubmissionDto getInternetApplication(@PathVariable Integer id) {
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			appHelper.isAppBelongToTA(id, currentUser);
		}
		TaCompanyUpdate taCompanyUpdate = taCompanyUpdateRepository.getApplication(id, null, false);
		TaCompanyUpdateSubmissionDto taCompanyUpdateSubmissionDto = TaCompanyUpdateSubmissionDto.buildFromApplication(cache, appHelper, taCompanyUpdate, fileHelper);
		return taCompanyUpdateSubmissionDto;
	}

	@RequestMapping(path = { "/update/business-entity" }, method = RequestMethod.POST)
	public void updateApplication(@RequestPart(name = "application") TaCompanyUpdateSubmissionDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) throws IOException {
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();
		if (dto.getApplicationId() != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
			}
		}

		TaCompanyUpdate taCompanyUpdate = new TaCompanyUpdate();
		Application application = new Application();

		if (dto != null) {

			if (dto.getApplicationId() != null) { // Update existing
				application = taCompanyUpdateRepository.get(Application.class, dto.getApplicationId());
				appHelper.forward(application, true);

				taCompanyUpdate = taCompanyUpdateRepository.get(TaCompanyUpdate.class, dto.getId());
				taCompanyUpdate = updateTaCompanyUpdateDetails(dto, taCompanyUpdate);
				taCompanyUpdate.setApplication(application);

				taCompanyUpdateRepository.update(taCompanyUpdate.getOperatingAddress());
				taCompanyUpdateRepository.update(taCompanyUpdate.getRegisteredAddress());
				// taCompanyUpdateRepository.update(taCompanyUpdate);

			} else { // save new
				application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_COMPANY_UPDATE, licenceModel.getId(), dto.isOfflineSubmission(), false);
				appHelper.forward(application, true);
				taCompanyUpdate = updateTaCompanyUpdateDetails(dto, taCompanyUpdate);
				taCompanyUpdate.setApplication(application);

				taCompanyUpdateRepository.save(taCompanyUpdate.getOperatingAddress());
				taCompanyUpdateRepository.save(taCompanyUpdate.getRegisteredAddress());

				// taCompanyUpdateRepository.save(taCompanyUpdate);
			}

			TaCompanyUpdate snapshot = taCompanyUpdate.getPreviousValue() == null ? new TaCompanyUpdate() : taCompanyUpdate.getPreviousValue();
			snapshot = appHelper.snapshotCurrentCompanyDetails(snapshot, currentUser.getTravelAgent().getLicence());
			taCompanyUpdate.setPreviousValue(snapshot);
			taCompanyUpdateRepository.saveOrUpdate(snapshot);

			List<ApplicationFile> appFiles = new ArrayList<>();
			// 3. Save additional files uploaded by user
			if (dto.getCompanyDetailsDocument() != null) {
				if (dto.getCompanyDetailsDocument().getSize() != null && dto.getCompanyDetailsDocument().getPublicFileId() == null) {
					appFiles.add(fileHelper.saveFile(application, dto.getCompanyDetailsDocument()));
				}
			}

			if (dto.getAcra() != null) {
				if (dto.getAcra().getSize() != null && dto.getAcra().getPublicFileId() == null) {
					appFiles.add(fileHelper.saveFile(application, dto.getAcra()));
				}
			}

			if (dto.getOtherDocuments().size() > 0) {
				for (FileDto doc : dto.getOtherDocuments()) {
					if (doc.getPublicFileId() == null) {
						appFiles.add(fileHelper.saveFile(application, doc));
					} else {
						appFiles.add(fileRepository.getAppFile(doc.getId()));
					}

				}
			}

			if (application.getApplicationFiles() != null) {
				for (ApplicationFile appFile : application.getApplicationFiles()) {
					if (!appFiles.contains(appFile)) {
						fileHelper.deleteFile(appFile.getFile());
					}
				}
			}
			taCompanyUpdateRepository.saveOrUpdate(taCompanyUpdate);

		}

	}

	@RequestMapping(value = { "/new/InboundOutboundServices", "/load/InboundOutboundServices" }, method = RequestMethod.GET)
	public List<TaCompanyInboundOutboundDto> loadInboundOutboundServices() {
		List<TaCompanyInboundOutboundDto> taCompanyInboundOutboundDtoList = new ArrayList<TaCompanyInboundOutboundDto>();
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {

			Set<Type> bothBoundServices = new HashSet<Type>();
			bothBoundServices.addAll(currentUser.getTravelAgent().getInboundServices());
			Set<Type> inboundServices = new HashSet<Type>();
			inboundServices.addAll(currentUser.getTravelAgent().getInboundServices());
			Set<Type> outboundServices = new HashSet<Type>();
			outboundServices.addAll(currentUser.getTravelAgent().getOutboundServices());
			bothBoundServices.retainAll(outboundServices);

			for (Type s : bothBoundServices) {
				TaCompanyInboundOutboundDto taCompanyInboundOutboundDto = new TaCompanyInboundOutboundDto();
				taCompanyInboundOutboundDto.setService((s != null) ? new ListableDto(s.getKey(), cache.getLabel(s, false)) : new ListableDto());
				taCompanyInboundOutboundDto.setInbound(true);
				taCompanyInboundOutboundDto.setOutbound(true);
				taCompanyInboundOutboundDtoList.add(taCompanyInboundOutboundDto);
			}

			inboundServices.removeAll(currentUser.getTravelAgent().getOutboundServices());
			for (Type s : inboundServices) {
				TaCompanyInboundOutboundDto taCompanyInboundOutboundDto = new TaCompanyInboundOutboundDto();
				taCompanyInboundOutboundDto.setService((s != null) ? new ListableDto(s.getKey(), cache.getLabel(s, false)) : new ListableDto());
				taCompanyInboundOutboundDto.setInbound(true);
				taCompanyInboundOutboundDto.setOutbound(false);
				taCompanyInboundOutboundDtoList.add(taCompanyInboundOutboundDto);
			}

			outboundServices.removeAll(currentUser.getTravelAgent().getInboundServices());
			for (Type s : outboundServices) {
				TaCompanyInboundOutboundDto taCompanyInboundOutboundDto = new TaCompanyInboundOutboundDto();
				taCompanyInboundOutboundDto.setService((s != null) ? new ListableDto(s.getKey(), cache.getLabel(s, false)) : new ListableDto());
				taCompanyInboundOutboundDto.setInbound(false);
				taCompanyInboundOutboundDto.setOutbound(true);
				taCompanyInboundOutboundDtoList.add(taCompanyInboundOutboundDto);
			}

		}
		return taCompanyInboundOutboundDtoList;
	}

	@RequestMapping(value = "/save/InboundOutboundServices", method = RequestMethod.POST)
	public void saveApplication(@RequestBody List<TaCompanyInboundOutboundDto> taCompanyInboundOutboundDtoList) {
		User currentUser = taCompanyUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			TravelAgent travelAgent = taCompanyUpdateRepository.get(TravelAgent.class, currentUser.getTravelAgent().getId());
			Set<Type> inboundServices = new HashSet<Type>();
			Set<Type> outboundServices = new HashSet<Type>();
			for (TaCompanyInboundOutboundDto item : taCompanyInboundOutboundDtoList) {
				Type type = new Type();
				type = cache.getType(item.getService().getKey().toString());
				if (item.isInbound()) {
					inboundServices.add(type);
				}
				if (item.isOutbound()) {
					outboundServices.add(type);
				}
			}

			travelAgent.setInboundServices(inboundServices);
			travelAgent.setOutboundServices(outboundServices);
			taCompanyUpdateRepository.saveOrUpdate(travelAgent);
		}
	}

	public TaCompanyUpdate updateTaCompanyUpdateDetails(TaCompanyUpdateSubmissionDto dto, TaCompanyUpdate taCompanyUpdate) {

		// Business Entity
		taCompanyUpdate.setCompanyName(dto.getNewDetails().getCompanyName());
		taCompanyUpdate.setContactNo(dto.getNewDetails().getContactNo());
		taCompanyUpdate.setFaxNo(dto.getNewDetails().getFaxNo());
		taCompanyUpdate.setEmailAddress(dto.getNewDetails().getEmailAddress());
		if (dto.getNewDetails().getEstablishmentStatus().getKey() != null) {
			taCompanyUpdate.setEstablishmentStatus(cache.getType(dto.getNewDetails().getEstablishmentStatus().getKey().toString()));
		}
		if (dto.getNewDetails().getFormOfBusiness().getKey() != null) {
			taCompanyUpdate.setFormOfBusiness(cache.getType(dto.getNewDetails().getFormOfBusiness().getKey().toString()));
		}
		if (dto.getNewDetails().getBusinessConstitution().getKey() != null) {
			taCompanyUpdate.setBusinessConstitution(cache.getType(dto.getNewDetails().getBusinessConstitution().getKey().toString()));
		}
		if (dto.getNewDetails().getTaSegmentation().getKey() != null) {
			taCompanyUpdate.setTaSegmentation(cache.getType(dto.getNewDetails().getTaSegmentation().getKey().toString()));
		}
		Address operatingAddress = new Address();
		if (taCompanyUpdate.getOperatingAddress() != null) {
			operatingAddress = taCompanyUpdate.getOperatingAddress();
		}
		operatingAddress.setBlock(dto.getNewDetails().getOperatingAddress().getBlock());
		operatingAddress.setBuilding(dto.getNewDetails().getOperatingAddress().getBuilding());
		operatingAddress.setFloor(dto.getNewDetails().getOperatingAddress().getFloor());
		operatingAddress.setPostal(dto.getNewDetails().getOperatingAddress().getPostal());
		operatingAddress.setPremiseType(cache.getType(dto.getNewDetails().getOperatingAddress().getPremisesType().getKey().toString()));
		operatingAddress.setStreet(dto.getNewDetails().getOperatingAddress().getStreet());
		operatingAddress.setUnit(dto.getNewDetails().getOperatingAddress().getUnit());
		operatingAddress.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		taCompanyUpdate.setOperatingAddress(operatingAddress);
		taCompanyUpdate.setPaidUpCapital(dto.getNewDetails().getPaidUpCapital());
		if (dto.getNewDetails().getPlaceIncorporated().getKey() != null) {
			taCompanyUpdate.setPlaceIncorporated(cache.getType(dto.getNewDetails().getPlaceIncorporated().getKey().toString()));
		}
		if (dto.getNewDetails().getPrincipleActivities().getKey() != null) {
			taCompanyUpdate.setPrincipleActivities(cache.getType(dto.getNewDetails().getPrincipleActivities().getKey().toString()));
		}
		if (dto.getNewDetails().getSecondaryPrincipleActivities().getKey() != null) {
			taCompanyUpdate.setSecondaryPrincipleActivities(cache.getType(dto.getNewDetails().getSecondaryPrincipleActivities().getKey().toString()));
		}
		Address registeredAddress = new Address();
		if (taCompanyUpdate.getRegisteredAddress() != null) {
			registeredAddress = taCompanyUpdate.getRegisteredAddress();
		}
		registeredAddress.setBlock(dto.getNewDetails().getRegisteredAddress().getBlock());
		registeredAddress.setBuilding(dto.getNewDetails().getRegisteredAddress().getBuilding());
		registeredAddress.setFloor(dto.getNewDetails().getRegisteredAddress().getFloor());
		registeredAddress.setPostal(dto.getNewDetails().getRegisteredAddress().getPostal());
		registeredAddress.setPremiseType(cache.getType(dto.getNewDetails().getRegisteredAddress().getPremisesType().getKey().toString()));
		registeredAddress.setStreet(dto.getNewDetails().getRegisteredAddress().getStreet());
		registeredAddress.setUnit(dto.getNewDetails().getRegisteredAddress().getUnit());
		registeredAddress.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		taCompanyUpdate.setRegisteredAddress(registeredAddress);
		taCompanyUpdate.setWebsiteUrl(dto.getNewDetails().getWebsiteUrl());
		taCompanyUpdate.setIsEdhPopulated(dto.getIsEdhPopulated());

		return taCompanyUpdate;
	}

	// to load active travel agents for offline submission
	@RequestMapping(value = "/offline/new/travel-agents", method = RequestMethod.GET)
	public List<TravelAgentBasicDto> getTravelAgents() {
		return travelAgentRepository.getActiveTravelAgentsBasic();
	}

	// to load new submission by travel agent's licence id
	@RequestMapping(value = "/offline/new/travel-agents/{licenceId}", method = RequestMethod.GET)
	public TaCompanyUpdateSubmissionDto loadOfflineTaCompanyUpdate(@PathVariable Integer licenceId) {

		TaCompanyUpdateSubmissionDto taCompanyUpdateSubmissionDto = null;

		// Check if TA has application pending approval, if yes, TA cannot submit another
		Application pendingApp = taCompanyUpdateRepository.getPendingApplicationFromLicenceId(licenceId, Codes.ApplicationTypes.TA_APP_COMPANY_UPDATE);

		if (pendingApp == null) {
			Licence licence = taCompanyUpdateRepository.get(Licence.class, licenceId);

			taCompanyUpdateSubmissionDto = new TaCompanyUpdateSubmissionDto();
			taCompanyUpdateSubmissionDto.buildFromLicence(cache, licence, taCompanyUpdateSubmissionDto);
			taCompanyUpdateSubmissionDto.setApplicationStatus(
					new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));

			taCompanyUpdateSubmissionDto.setCurrentDetails(TaCompanyDetailsDto.buildFromLicence(cache, licence));
			taCompanyUpdateSubmissionDto.setNewDetails(TaCompanyDetailsDto.buildFromLicence(cache, licence));
			taCompanyUpdateSubmissionDto.setIsEdhPopulated(false);
			taCompanyUpdateSubmissionDto.setCompanyDetailsDocument(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_TENANCY), fileHelper));
			taCompanyUpdateSubmissionDto.setAcra(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ), fileHelper));

		} else {
			TaCompanyUpdate taCompanyUpdateApp = taCompanyUpdateRepository.getApplication(pendingApp.getId(), null, false);
			taCompanyUpdateSubmissionDto = TaCompanyUpdateSubmissionDto.buildFromApplication(cache, appHelper, taCompanyUpdateApp, fileHelper);
		}

		taCompanyUpdateSubmissionDto.setOfflineSubmission(Boolean.TRUE);
		return taCompanyUpdateSubmissionDto;
	}

}
