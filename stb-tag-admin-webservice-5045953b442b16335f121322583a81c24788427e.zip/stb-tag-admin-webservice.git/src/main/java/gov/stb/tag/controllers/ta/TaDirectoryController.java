package gov.stb.tag.controllers.ta;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.travelagent.TravelAgentDto;
import gov.stb.tag.dto.ta.travelagent.TravelAgentItemDto;
import gov.stb.tag.dto.ta.travelagent.TravelAgentSearchDto;
import gov.stb.tag.helper.ExcelFileHelper;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.repository.ta.TaBranchRepository;
import gov.stb.tag.repository.ta.TaDirectoryRepository;
import gov.stb.tag.repository.ta.TaKeyExecutiveRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.ReportUtil;
import gov.stb.tag.util.ReportUtil.Reports;
import io.jsonwebtoken.lang.Collections;

@RestController
@RequestMapping(path = "/api/v1/directory/ta")
@Transactional
public class TaDirectoryController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private TaDirectoryRepository taDirectoryRepository;

	@Autowired
	private TaKeyExecutiveRepository taKeyExecutiveRepository;

	@Autowired
	private TaBranchRepository taBranchRepository;

	@Autowired
	ExcelFileHelper excelFileHelper;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public ResultDto<TravelAgentItemDto> getTaDirectory(TravelAgentSearchDto searchDto) {

		ResultDto<TravelAgentItemDto> taList = taDirectoryRepository.getTaListByFilters(searchDto);

		Object[] finalRecords = new Object[taList.getRecords().length];
		var i = 0;
		for (Object obj : taList.getRecords()) {
			TravelAgent ta = (TravelAgent) obj;
			var dto = TravelAgentItemDto.buildFromTravelAgent(cache, ta);

			finalRecords[i] = dto;
			i++;
		}

		taList.setRecords(finalRecords);

		return taList;
	}

	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public TravelAgentDto getTaDetails(@RequestParam(value = "licenceNo", required = false) String licenceNo) {

		TravelAgent ta = taDirectoryRepository.getTaDetailByLicenceNo(licenceNo);

		TravelAgentDto dto = new TravelAgentDto();

		dto.setName(ta.getName());
		dto.setUen(ta.getUen());
		dto.setWebsiteUrl(ta.getWebsiteUrl());
		dto.setContactNo(ta.getContactNo());
		dto.setEmailAddress(ta.getEmailAddress());
		dto.setOperatingAddress(ta.getOperatingAddress().getAddressDisplay());
		if (ta.getLicence().getCeasedDate() != null) {
			dto.setOperationYear(ta.getLicence().getCeasedDate().getYear() - ta.getLicence().getIssueDate().getYear());
		} else {
			dto.setOperationYear(LocalDate.now().getYear() - ta.getLicence().getIssueDate().getYear());
		}
		// TODO : fax No
		if (ta.getInboundServices() != null && ta.getInboundServices().size() > 0) {
			dto.setInboundServices(ta.getInboundServices().stream().map(u -> cache.getLabel(u, false)).collect(Collectors.toList()));
		}

		if (ta.getOutboundServices() != null && ta.getOutboundServices().size() > 0) {
			dto.setOutboundServices(ta.getOutboundServices().stream().map(u -> cache.getLabel(u, false)).collect(Collectors.toList()));
		}

		var licence = ta.getLicence();
		dto.setLicenceNo(licence.getLicenceNo());
		dto.setStatus(licence.getStatus().getCode());
		dto.setLicenceIssuedDate(licence.getIssueDate().format(DateUtil.DATE_FORMAT));

		TaStakeholder ke = taKeyExecutiveRepository.getKeyExecutiveByLicenceNo(licenceNo);
		if (ke != null) {
			var kePerson = ke.getStakeholder();
			dto.setKeName(kePerson.getName());
			dto.setKeDesignation(cache.getLabel(kePerson.getDesignation(), false));
		}

		List<TaBranch> branches = taBranchRepository.getBranchesByLicenceNo(licenceNo);

		List<String> branchList = new ArrayList<>();
		if (!Collections.isEmpty(branches)) {
			for (TaBranch tb : branches) {
				if (tb.getAddress() != null) {
					branchList.add(tb.getAddress().toFormattedAddress(true));
				}

			}
			dto.setBranches(branchList);
		}

		return dto;

	}

	@RequestMapping(value = "/generate-excel", method = RequestMethod.GET)
	public void generateTaDirectoryExcel(TravelAgentSearchDto searchDto, HttpServletResponse response) {
		Reports report = ReportUtil.Reports.valueOf("TA_REPORT_DIRECTORY");
		String OPTION_All = "ALL";
		Map<String, Object> filter = new HashMap<String, Object>();
		filter.put("service", new ArrayList<>(List.of(OPTION_All)));
		filter.put("licenceNo", null);
		filter.put("type", null);
		filter.put("status", new ArrayList<>(List.of(Codes.Statuses.TA_ACTIVE, Codes.Statuses.TA_PEND_REVOCATION, Codes.Statuses.TA_PEND_SUSPENSION)));
		filter.put("licenceNoName", null);

		if (!StringUtils.isBlank(searchDto.getType()) && !OPTION_All.equals(searchDto.getType())) {
			filter.put("type", searchDto.getType());
		}

		if (!CollectionUtils.isEmpty(searchDto.getService()) && !searchDto.getService().contains(OPTION_All)) {
			filter.put("service", searchDto.getService());
		}

		if (!CollectionUtils.isEmpty(searchDto.getStatus())) {

			if (!searchDto.getStatus().contains(OPTION_All)) {
				List<String> statuses = new ArrayList<>();

				for (String status : searchDto.getStatus()) {
					if (status.contains("|")) {
						String[] statusSplit = status.split("\\|");
						statuses.addAll(Arrays.asList(statusSplit));
					} else {
						statuses.add(status);
					}
				}

				filter.put("status", statuses);
			} else {
				filter.put("status", new ArrayList<>(List.of(OPTION_All)));
			}

		}

		if (!StringUtils.isBlank(searchDto.getName())) {
			filter.put("licenceNoName", searchDto.getName());
		}

		if (!StringUtils.isBlank(searchDto.getLicenceName())) {
			filter.put("licenceNoName", searchDto.getLicenceName());
		} else if (!StringUtils.isBlank(searchDto.getMobileName())) {
			filter.put("licenceNoName", searchDto.getMobileName());
		}

		if (!StringUtils.isBlank(searchDto.getLicenceNo())) {
			filter.put("licenceNo", searchDto.getLicenceNo());
		}

		List<Object[]> dataList = taDirectoryRepository.getResultSetFromNamedQuery(report.getNamedQuery(), filter);
		Workbook workbook = excelFileHelper.createExcelSheet("Ta Directory", report.getHeaderNames());

		Sheet sheet = workbook.getSheetAt(0);

		int rowNum = 1, recordCount = 1;
		for (Object[] obj : dataList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(Integer.toString(recordCount));

			int columnCount = obj.length;
			for (int i = 0; i < columnCount; i++) {
				row.createCell(i + 1).setCellValue(obj[i] != null ? obj[i].toString() : null);
			}

			recordCount++;
		}

		excelFileHelper.createExcelFile("ta-directory.xlsx", workbook, response);
	}

}
