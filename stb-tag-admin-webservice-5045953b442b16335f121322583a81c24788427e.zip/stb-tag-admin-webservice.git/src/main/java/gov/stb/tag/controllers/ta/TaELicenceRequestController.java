package gov.stb.tag.controllers.ta;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.zxing.WriterException;
import com.itextpdf.barcodes.BarcodeQRCode;
import com.itextpdf.io.font.FontProgram;
import com.itextpdf.io.font.FontProgramFactory;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.xobject.PdfFormXObject;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.dashboard.LicenceDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceRequestDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceRequestItemDto;
import gov.stb.tag.dto.ta.elicencerequest.TaELicenceRequestSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaELicenceRequest;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.ta.TaBranchRepository;
import gov.stb.tag.repository.ta.TaELicenceRequestRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.FileUtil;
import gov.stb.tag.util.QRCodeGenerator;

@RestController
@RequestMapping(path = "/api/v1/ta/elicence-request")
@Transactional
public class TaELicenceRequestController extends BaseController {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaELicenceRequestRepository taELicenceRequestRepository;
	@Autowired
	TaBranchRepository taBranchRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;

	// to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaELicenceRequestItemDto> getList(TaELicenceRequestSearchDto searchDto) {
		ResultDto<TaELicenceRequestItemDto> resultDTO = new ResultDto<TaELicenceRequestItemDto>();
		resultDTO = taELicenceRequestRepository.getPendingList(searchDto, getUser().getId());
		return resultDTO;
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaELicenceRequestDto getApplication(@PathVariable Integer id) {
		User currentUser = taELicenceRequestRepository.getLicenseeUserByUserId(getUser().getId());
		TaELicenceRequestDto resultDto = new TaELicenceRequestDto();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}

			resultDto = taELicenceRequestRepository.getELicenceRequestByAppId(id);
			if (resultDto != null) {
				resultDto = TaELicenceRequestDto.buildApplication(cache, appHelper, taELicenceRequestRepository.get(Application.class, id), resultDto);
			}
		}
		return resultDto;
	}

	// to create new or get existing application details
	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaELicenceRequestDto getNewApplication() {

		TaELicenceRequestDto resultDto = new TaELicenceRequestDto();
		TaELicenceRequest taELicenceReqModel = new TaELicenceRequest();

		User currentUser = taELicenceRequestRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();
		if (Codes.Roles.TA_PUBLIC.equals(getSelectedRoleCode()) && !Objects.isNull(currentUser.getTravelAgent())) {
			// Check if there is approved e-license request pending. Do not allow new submission if there is
			taELicenceReqModel = taELicenceRequestRepository.getPendingApplication(licenceModel.getId());
		}

		if (taELicenceReqModel == null) {
			resultDto.setIsDownloadable(licenceModel.getIsDownloadable());
			resultDto.setApplicationStatus(
					new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));
			resultDto.setLicenceNo(licenceModel.getLicenceNo());
			resultDto.setLicenceId(licenceModel.getId());

			resultDto = resultDto.buildFromLicence(cache, licenceModel, resultDto);
		} else {
			resultDto = getExistingAppId(resultDto, taELicenceReqModel.getApplication());
		}

		return resultDto;
	}

	// to submit new application details
	@RequestMapping(path = { "/save", "/update" }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaELicenceRequestDto dto) {
		User currentUser = taELicenceRequestRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();
		if (dto.getApplicationId() != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
			}
		}

		TaELicenceRequest taELicenceReqModel = new TaELicenceRequest();

		if (dto != null) {
			Application appModel;

			if (dto.getApplicationId() != null) { // Update existing
				appModel = taELicenceRequestRepository.get(Application.class, dto.getApplicationId());
				appHelper.forward(appModel, true);
				taELicenceReqModel = taELicenceRequestRepository.get(TaELicenceRequest.class, dto.getApplicationId());
			} else { // save new
				appModel = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_ELICENCE_REQUEST, licenceModel.getId(), dto.isOfflineSubmission(), false);
				appHelper.forward(appModel, true);
			}

			taELicenceReqModel = taELicenceRequestRepository.updateELicenceReqDetails(dto, taELicenceReqModel);
			taELicenceReqModel.setApplication(appModel);
			taELicenceRequestRepository.saveOrUpdate(taELicenceReqModel);
			licenceModel = taELicenceRequestRepository.updateELicenceFlag(dto, licenceModel);
			List<TaBranch> branches = new ArrayList<TaBranch>();
			branches = travelAgentRepository.getActiveBranchesByLicenceId(licenceModel.getId());
			for (TaBranch branch : branches) {
				taBranchRepository.updateBranchELicenceFlag(branch);
			}
		}
	}

	private TaELicenceRequestDto getExistingAppId(TaELicenceRequestDto resultDto, Application appModel) {
		resultDto = taELicenceRequestRepository.getELicenceRequestByAppId(appModel.getId());
		resultDto = TaELicenceRequestDto.buildApplication(cache, appHelper, appModel, resultDto);
		return resultDto;
	}

	// to approve, reject, revert e-licence request
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaELicenceRequest taELicenceReqModel = new TaELicenceRequest();
		Licence licenceModel = new Licence();
		taELicenceReqModel = taELicenceRequestRepository.get(TaELicenceRequest.class, id);

		Application appModel = taELicenceReqModel.getApplication();
		licenceModel = appModel.getLicence();

		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(appModel, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(appModel)) {
				taAlertMsg = Messages.Alerts.TA_APP_ELICENCE_APPROVE;
				taMsgType = Codes.EmailType.TA_ELICENCE_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				if (licenceModel.getIsViewable() != null && licenceModel.getIsViewable() == Codes.ELicenceView.VIEW) {
					licenceModel = taELicenceRequestRepository.approveELicenceRequest(licenceModel);
					List<TaBranch> branches = new ArrayList<TaBranch>();
					branches = travelAgentRepository.getActiveBranchesByLicenceId(licenceModel.getId());
					for (TaBranch branch : branches) {
						taBranchRepository.approveBranchELicenceRequest(branch);
					}
				} else {
					logger.info("(TAELicenceRequest Approve Action) - E-licence is not viewable for Licence No " + licenceModel.getLicenceNo());
				}

			}
			break;

		case ACTION_REJECT:
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;

			appHelper.reject(appModel, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			if (licenceModel.getIsViewable() != null && licenceModel.getIsViewable() == Codes.ELicenceView.VIEW) {
				licenceModel = taELicenceRequestRepository.updateELicToReqNeed(licenceModel);
				List<TaBranch> branches = new ArrayList<TaBranch>();
				branches = travelAgentRepository.getActiveBranchesByLicenceId(licenceModel.getId());
				for (TaBranch branch : branches) {
					taBranchRepository.updateBranchELicToReqNeed(branch);
				}
			}
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
			}

			appHelper.rfa(appModel, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(appModel.getLicence().getTravelAgent(), appModel, taAlertMsg, Codes.Modules.MOD_TA, appModel.getType(), "../ta-e-licence-request/" + appModel.getId(),
					cache.getStatus(statusCode));

			/* Send email to notify TA & KE */

			String url = String.format(properties.applicationUrl, "ta-e-licence-request/" + appModel.getId());
			logger.info("QR URL is " + url);
			emailHelper.emailTaUponAction(appModel, taMsgType, url);
		}

	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taELicenceRequestRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	// update isDownloadable flag and download files
	@RequestMapping(path = "/updateFlag", method = RequestMethod.POST)
	public void updateDownloadFlag(@RequestBody LicenceDto dto, HttpServletResponse response) throws Exception {
		Licence licenceModel = new Licence();
		List<TaBranch> branches = new ArrayList<TaBranch>();
		List<File> fileList = new ArrayList<File>();
		List<String> fileNameList = new ArrayList<String>();
		boolean isBranchDownloadable = false;
		String dest = "";

		String tempFileLocation = properties.baseDir + properties.downloadDir;
		Date now = new java.util.Date();
		Timestamp current = new java.sql.Timestamp(now.getTime());
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmssss").format(current);

		licenceModel = taELicenceRequestRepository.get(Licence.class, dto.getLicenceId());
		branches = travelAgentRepository.getActiveBranchesByLicenceId(dto.getLicenceId());
		TravelAgent ta = travelAgentRepository.getTravelAgentByLicenceId(dto.getLicenceId());

		String folderName = "TA-e-licence" + ta.getLicence().getLicenceNo() + "_" + DateUtil.format(LocalDate.now(), DateUtil.REPORT_DATE_FORMAT_PATTERN);
		tempFileLocation = tempFileLocation + timeStamp + "/";
		int i = 1;

		logger.info("E-licence view flag : " + licenceModel.getIsViewable());
		logger.info("E-licence download flag : " + licenceModel.getIsDownloadable());
		logger.info("check e-licence image is downloadable or not");
		if ((licenceModel.getIsViewable() != null && licenceModel.getIsViewable() == Codes.ELicenceView.VIEW) && (licenceModel.getIsDownloadable() == null
				|| licenceModel.getIsDownloadable() == Codes.ELicenceDownloadRequest.RESET || licenceModel.getIsDownloadable() == Codes.ELicenceDownloadRequest.APPROVE)) {
			logger.info("e-licence image is allowed to download");
			logger.info("update isDownloadable flag to NEED_TO_REQUEST");
			licenceModel = taELicenceRequestRepository.updateELicToReqNeed(licenceModel);
			// to write pdf file
			if (licenceModel.getIsDownloadable() != null && licenceModel.getIsDownloadable() == Codes.ELicenceDownloadRequest.NEED_TO_REQUEST) {
				// file path
				dest = tempFileLocation + ta.getLicence().getLicenceNo() + "_" + i + ".pdf";

				File file = new File(dest);
				file.getParentFile().mkdirs();
				// write Main address License PDF
				drawLicence(dest, ta, ta.getLicence());

				fileList.add(file);
				fileNameList.add(ta.getLicence().getLicenceNo() + "_" + i + ".pdf");
				i++;
			}
		} else {
			logger.info("e-licence image is not allowed to download");
		}

		if (licenceModel.getIsViewable() != null && licenceModel.getIsViewable() == Codes.ELicenceView.VIEW) {
			for (TaBranch branch : branches) {
				if (branch.getIsDownloadable() == null || branch.getIsDownloadable() == Codes.ELicenceDownloadRequest.RESET || branch.getIsDownloadable() == Codes.ELicenceDownloadRequest.APPROVE) {
					isBranchDownloadable = true; // check if branch e-licence existed or not
					logger.info("Branch e-licence image is able to download postal code - " + branch.getAddress().getPostal());
					// update branch download flag to NEED_TO_REQUEST status
					taBranchRepository.updateBranchELicToReqNeed(branch);

					AddressDto branchDto = new AddressDto();
					branchDto = AddressDto.buildFromAddress(cache, branch.getAddress(), branch.getIsDownloadable());
					// file path
					dest = tempFileLocation + ta.getLicence().getLicenceNo() + "_" + i + ".pdf";

					File file = new File(dest);
					file.getParentFile().mkdirs();
					// write Branch address License PDF
					drawBranchLicence(dest, ta, ta.getLicence(), branchDto);

					fileList.add(file);
					fileNameList.add(ta.getLicence().getLicenceNo() + "_" + i + ".pdf");
					i++;
				}

			}
		} else {
			logger.info("e-licence image is not viewable");
		}

		logger.info("files to be downloaded : " + i);

		if (fileList.size() == 1) {
			if (fileList.get(0).exists()) {
				FileUtil.downloadSingleFile(response, fileList.get(0), null);
			}
		} else {
			String zipFile = CreateZipFileFromMultipleFilesWithZipOutputStream(fileList, fileNameList, folderName, tempFileLocation);
			File zip = new File(zipFile);
			if (zip.exists()) {
				logger.info("zip file exists");
				FileUtil.downloadSingleFile(response, new File(zipFile), null);
			} else {
				logger.info("zip file does not exist");
			}
		}

		// delete folder
		deleteDir(tempFileLocation);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/getData")
	public TaELicenceDto getTaELicenceData() {
		String content = "";
		String qrcode = "";
		Boolean isDownloadButtonOn = false;
		byte[] image = new byte[0];
		List<TaBranch> branches = new ArrayList<TaBranch>();
		List<AddressDto> branchAddrDtoList = new ArrayList<AddressDto>();

		User user = userRepository.getLicenseeUserByUserId(getUser().getId());
		TaELicenceDto result = new TaELicenceDto();
		if (!Objects.isNull(user.getTravelAgent())) {
			TravelAgent ta = user.getTravelAgent();
			Licence licence = ta.getLicence();
			// get Branches
			branches = travelAgentRepository.getActiveBranchesByLicenceId(licence.getId());
			Address operatingAddr = ta.getOperatingAddress();
			Address displayAddr = ta.getDisplayAddress();

			content = properties.taELicenceQrUrl;
			logger.info("QR Code URL" + content);
			content = content + licence.getLicenceNo();
			// Generate and Return Qr Code in Byte Array
			try {
				if (licence.getTier().getCode() != null && licence.getTier().getCode().equalsIgnoreCase(Codes.Types.TA_TIER_GENERAL)) {
					image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0xFFc1dfdb); // general bg color
				} else if (licence.getTier().getCode() != null && licence.getTier().getCode().equalsIgnoreCase(Codes.Types.TA_TIER_NICHE)) {
					image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0xFFEAE5AD);// niche bg color
				} else {
					image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0);
				}
				// Convert Byte Array into Base64 Encode String
				qrcode = Base64.getEncoder().encodeToString(image);
			} catch (WriterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("WriterException : " + e.getMessage());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("IOException : " + e.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Exception : " + e.getMessage());
			}

			if (licence.getIsDownloadable() == null || (licence.getIsDownloadable() == Codes.ELicenceDownloadRequest.APPROVE || licence.getIsDownloadable() == Codes.ELicenceDownloadRequest.RESET)) {
				isDownloadButtonOn = true;
			}
			for (TaBranch branch : branches) {
				AddressDto branchAddrDto = new AddressDto();
				branchAddrDto = AddressDto.buildFromAddress(cache, branch.getAddress(), branch.getIsDownloadable());
				branchAddrDtoList.add(branchAddrDto);
				if (branch.getIsDownloadable() == null || branch.getIsDownloadable() == Codes.ELicenceDownloadRequest.APPROVE || branch.getIsDownloadable() == Codes.ELicenceDownloadRequest.RESET) {
					isDownloadButtonOn = true;
				}
			}
			logger.info("isDownloadButtonOn : " + isDownloadButtonOn);
			result.setQrCode(qrcode);
			result.setLicence(LicenceDto.buildFromLicence(cache, licence, isDownloadButtonOn));
			result.setBranchAddrList(branchAddrDtoList);
			if (displayAddr == null) {
				result.setDisplayAddr(AddressDto.buildFromAddress(cache, operatingAddr));
			} else {
				result.setDisplayAddr(AddressDto.buildFromAddress(cache, displayAddr));
			}
			if (ta.getDisplayName() != null && !ta.getDisplayName().isEmpty()) {
				result.setDisplayName(ta.getDisplayName());
			} else {
				result.setDisplayName(ta.getName());
			}
		}

		return result;
	}

	@RequestMapping(value = "/elicence/save/{id}", method = RequestMethod.POST)
	public void updateELicenceDetails(@RequestBody TaELicenceDto dto, @PathVariable Integer id) {
		Address displayAddress = new Address();
		Licence licenceModel = new Licence();
		TravelAgent ta = travelAgentRepository.getTravelAgentByLicenceId(id);

		if (ta != null) {

			TaELicenceRequest taELicenceReqModel = taELicenceRequestRepository.getPendingApplication(id);
			licenceModel = ta.getLicence();

			if (!Strings.isNullOrEmpty(dto.getDisplayName())) {
				ta.setDisplayName(dto.getDisplayName().toUpperCase().trim());
			} else {
				ta.setDisplayName(null);
			}

			if (dto.getDisplayAddr() != null) {

				displayAddress.setBlock(dto.getDisplayAddr().getBlock());
				displayAddress.setBuilding(dto.getDisplayAddr().getBuilding());
				displayAddress.setFloor(dto.getDisplayAddr().getFloor());
				displayAddress.setPostal(dto.getDisplayAddr().getPostal());
				displayAddress.setPremiseType(cache.getType(dto.getDisplayAddr().getPremisesType().getKey().toString()));
				displayAddress.setStreet(dto.getDisplayAddr().getStreet());
				displayAddress.setUnit(dto.getDisplayAddr().getUnit());
				displayAddress.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));

				ta.setDisplayAddress(displayAddress);
			} else {
				ta.setDisplayAddress(null);
			}

			travelAgentRepository.update(ta);
			if (taELicenceReqModel == null) {
				taELicenceRequestRepository.resetELicenceRequest(licenceModel);
				List<TaBranch> branches = new ArrayList<TaBranch>();
				branches = travelAgentRepository.getActiveBranchesByLicenceId(licenceModel.getId());
				for (TaBranch branch : branches) {
					taBranchRepository.resetBranchELicenceRequest(branch);
				}
			}
		}
	}

	@RequestMapping(value = "/download", method = RequestMethod.POST)
	public void downloadFiles(@RequestBody TaELicenceDto dto, HttpServletResponse response) throws Exception {

		List<File> fileList = new ArrayList<File>();
		List<String> fileNameList = new ArrayList<String>();
		TravelAgent ta = travelAgentRepository.getTravelAgentByLicenceId(dto.getLicence().getLicenceId());

		String tempFileLocation = properties.baseDir + properties.downloadDir;
		String dest = "";

		Date now = new java.util.Date();
		Timestamp current = new java.sql.Timestamp(now.getTime());
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmssss").format(current);
		String folderName = "TA-e-licence" + ta.getLicence().getLicenceNo() + "_" + DateUtil.format(LocalDate.now(), DateUtil.REPORT_DATE_FORMAT_PATTERN);

		tempFileLocation = tempFileLocation + timeStamp + "/";
		int i = 1;
		boolean branchflag = false;

		if (ta != null && ta.getLicence() != null) {
			dest = tempFileLocation + ta.getLicence().getLicenceNo() + "_" + i + ".pdf";

			File file = new File(dest);
			file.getParentFile().mkdirs();

			drawLicence(dest, ta, ta.getLicence());

			fileList.add(file);
			fileNameList.add(ta.getLicence().getLicenceNo() + "_" + i + ".pdf");
			i++;

			if (dto.getBranchAddrList() == null) {
				List<TaBranch> branches = new ArrayList<TaBranch>();

				// get Branches
				branches = travelAgentRepository.getActiveBranchesByLicenceId(dto.getLicence().getLicenceId());
				for (TaBranch branch : branches) {
					AddressDto branchAddrDto = new AddressDto();
					branchAddrDto = AddressDto.buildFromAddress(cache, branch.getAddress(), branch.getIsDownloadable());

					dest = tempFileLocation + ta.getLicence().getLicenceNo() + "_" + i + ".pdf";

					File branchfile = new File(dest);
					branchfile.getParentFile().mkdirs();
					drawBranchLicence(dest, ta, ta.getLicence(), branchAddrDto);

					fileList.add(branchfile);
					fileNameList.add(ta.getLicence().getLicenceNo() + "_" + i + ".pdf");
					i++;
					branchflag = true; // check if branch e-licence existed or not

				}
			}
		}

		if (fileList.size() == 1) {
			if (fileList.get(0).exists()) {
				FileUtil.downloadSingleFile(response, fileList.get(0), null);
			}
		} else {
			String zipFile = CreateZipFileFromMultipleFilesWithZipOutputStream(fileList, fileNameList, folderName, tempFileLocation);
			File zip = new File(zipFile);
			if (zip.exists()) {
				logger.info("zip file exists");
				FileUtil.downloadSingleFile(response, new File(zipFile), null);
			} else {
				logger.info("zip file does not exist");
			}
		}

		// delete folder
		deleteDir(tempFileLocation);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/getTaELicenceDetails")
	public TaELicenceDto getTaELicenceDetails(@RequestBody LicenceDto dto) {
		TaELicenceDto result = new TaELicenceDto();
		byte[] image = new byte[0];
		List<TaBranch> branches = new ArrayList<TaBranch>();
		List<AddressDto> branchAddrDtoList = new ArrayList<AddressDto>();
		String content = "";
		String qrcode = "";

		TravelAgent ta = travelAgentRepository.getTravelAgentByLicenceId(dto.getLicenceId());

		if (!Objects.isNull(ta)) {
			Licence licence = ta.getLicence();
			// get Branches
			branches = travelAgentRepository.getActiveBranchesByLicenceId(licence.getId());
			Address operatingAddr = ta.getOperatingAddress();
			Address displayAddr = ta.getDisplayAddress();

			content = properties.taELicenceQrUrl;
			logger.info("QR Code URL" + content);
			content = content + licence.getLicenceNo();
			// Generate and Return Qr Code in Byte Array
			try {
				if (licence.getTier().getCode() != null && licence.getTier().getCode().equalsIgnoreCase(Codes.Types.TA_TIER_GENERAL)) {
					image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0xFFc1dfdb); // general bg color
				} else if (licence.getTier().getCode() != null && licence.getTier().getCode().equalsIgnoreCase(Codes.Types.TA_TIER_NICHE)) {
					image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0xFFEAE5AD);// niche bg color
				} else {
					image = QRCodeGenerator.getQRCodeImage(content, 130, 130, 0);
				}
				// Convert Byte Array into Base64 Encode String
				qrcode = Base64.getEncoder().encodeToString(image);
			} catch (WriterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("WriterException : " + e.getMessage());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("IOException : " + e.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Exception : " + e.getMessage());
			}

			for (TaBranch branch : branches) {
				AddressDto branchAddrDto = new AddressDto();
				branchAddrDto = AddressDto.buildFromAddress(cache, branch.getAddress(), branch.getIsDownloadable());
				branchAddrDtoList.add(branchAddrDto);
			}
			result.setQrCode(qrcode);
			result.setLicence(LicenceDto.buildFromLicence(cache, licence, true));
			result.setBranchAddrList(branchAddrDtoList);
			if (displayAddr == null) {
				result.setDisplayAddr(AddressDto.buildFromAddress(cache, operatingAddr));
			} else {
				result.setDisplayAddr(AddressDto.buildFromAddress(cache, displayAddr));
			}
			if (ta.getDisplayName() != null && !ta.getDisplayName().isEmpty()) {
				result.setDisplayName(ta.getDisplayName());
			} else {
				result.setDisplayName(ta.getName());
			}
		}

		return result;
	}

	private String CreateZipFileFromMultipleFilesWithZipOutputStream(List<File> srcFiles, List<String> fileNameList, String zipFileName, String filePath) {
		String zipFile = String.format(filePath + zipFileName + ".zip");

		try {
			// create byte buffer
			byte[] buffer = new byte[4 * 1024];
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);

			int i = 0;
			for (File srcFile : srcFiles) {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(srcFile);
					// begin writing a new ZIP entry, positions the stream to the start of the entry data
					zos.putNextEntry(new ZipEntry(fileNameList.get(i)));
					int length;

					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}

					// close the InputStream
					fis.close();
				} catch (IOException ioe) {
					logger.error("Error getting file: " + ioe);
				}
				i++;
				zos.closeEntry();
			}

			// close the ZipOutputStream
			zos.close();
		} catch (IOException ioe) {
			logger.error("Error creating zip file: " + ioe);
		}

		return zipFile;
	}

	protected void drawLicence(String dest, TravelAgent ta, Licence licence) throws Exception {
		// background image file location
		String imgFileLocation = properties.baseDir + properties.imageDir;
		String fontFileLocation = properties.baseDir + properties.fontDir;
		String bgImage = "";
		String title = "";

		if (licence.getTier().getKey() != null && licence.getTier().getKey().equals(Codes.Types.TA_TIER_GENERAL)) {
			bgImage = imgFileLocation + Codes.Types.TA_TIER_GENERAL + ".png";
			title = "TRAVEL AGENT LICENCE (GENERAL)";
		} else if (licence.getTier().getKey() != null && licence.getTier().getKey().equals(Codes.Types.TA_TIER_NICHE)) {
			bgImage = imgFileLocation + Codes.Types.TA_TIER_NICHE + ".png";
			title = "TRAVEL AGENT LICENCE (NICHE)";
		}

		// open PDF document in writing mode.
		PdfDocument pdfDoc = new PdfDocument(new PdfWriter(dest));
		PageSize pageSize = PageSize.A4;
		// creates a document from a PdfDocument with a manually set PageSize.
		Document doc = new Document(pdfDoc, pageSize);
		// create an ImageData instance representing the image from the specified file
		ImageData image = ImageDataFactory.create(bgImage);
		PdfCanvas pdfCanvas = new PdfCanvas(pdfDoc.addNewPage());
		// creates PdfImageXObject from image and fitted into specific rectangle on
		// canvas. The created imageXObject will be fit inside on the specified
		// rectangle without preserving aspect ratio
		pdfCanvas.addImageFittedIntoRectangle(image, pageSize, false);

		String ARIAL_BLACK_BOLD_ITALIC = fontFileLocation + "Arial-Black-Italic.ttf";
		FontProgram fontProgramArialBlack = FontProgramFactory.createFont(ARIAL_BLACK_BOLD_ITALIC);

		PdfFont arialBlackBoldItalicFont = PdfFontFactory.createFont(fontProgramArialBlack, PdfEncodings.WINANSI);
		PdfFont timesBoldFont = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
		PdfFont timesFont = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);

		// Title
		pdfCanvas.beginText().setFontAndSize(arialBlackBoldItalicFont, 16).moveText(191, pageSize.getTop() - 105).showText(title).moveText(60, -pageSize.getTop() + 30).endText();

		String licenceLabel = "Licence Number";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 16).moveText(191, pageSize.getTop() - 126).showText(licenceLabel).moveText(60, -pageSize.getTop() + 30).endText();

		String licenceNumber = Codes.TaTgType.TA + licence.getLicenceNo();
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 26).moveText(191, pageSize.getTop() - 154).showText(licenceNumber).moveText(60, -pageSize.getTop() + 30).endText();

		String licenseeLabel = "Name of Licensee:";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, pageSize.getTop() - 220).showText(licenseeLabel).moveText(60, -pageSize.getTop() + 30).endText();

		int offset = 10;
		int licenseeMaxWidth = 315;
		int licensee_x = 200;
		float licenseeFontSize = 12;

		String licensee = ta.getName() != null ? ta.getName().trim().toUpperCase() : "";
		licenseeFontSize = countFontSizeByWidth(licensee, timesBoldFont, licenseeFontSize, licenseeMaxWidth);

		int licenseeTxtWidth = (int) timesBoldFont.getWidth(licensee, licenseeFontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, licenseeFontSize).moveText((licensee_x + offset), pageSize.getTop() - 220).showText(licensee).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(licensee_x, pageSize.getTop() - 224);
		// Drawing the line
		pdfCanvas.lineTo((licensee_x + licenseeMaxWidth), pageSize.getTop() - 224);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		String mainAddrLabel = "Main Address:";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, pageSize.getTop() - 266).showText(mainAddrLabel).moveText(60, -pageSize.getTop() + 30).endText();

		int mainAddrMaxWidth = 315;
		int mainAddr_x = 200;
		float mainAddr1FontSize = 12;
		float mainAddr2FontSize = 12;

		String mainAddr1 = getAddressLine1(ta.getOperatingAddress()).toUpperCase().trim();
		mainAddr1FontSize = countFontSizeByWidth(mainAddr1, timesBoldFont, mainAddr1FontSize, mainAddrMaxWidth);

		int mainAddr1TxtWidth = (int) timesBoldFont.getWidth(mainAddr1, mainAddr1FontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, mainAddr1FontSize).moveText((mainAddr_x + offset), pageSize.getTop() - 266).showText(mainAddr1).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(mainAddr_x, pageSize.getTop() - 270);
		// Drawing the line
		pdfCanvas.lineTo((mainAddr_x + mainAddrMaxWidth), pageSize.getTop() - 270);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		String mainAddr2 = getAddressLine2(ta.getOperatingAddress()).toUpperCase().trim();
		mainAddr2FontSize = countFontSizeByWidth(mainAddr2, timesBoldFont, mainAddr2FontSize, mainAddrMaxWidth);

		int mainAddr2TxtWidth = (int) timesBoldFont.getWidth(mainAddr2, mainAddr2FontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, mainAddr2FontSize).moveText((mainAddr_x + offset), pageSize.getTop() - 296).showText(mainAddr2).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(mainAddr_x, pageSize.getTop() - 300);
		// Drawing the line
		pdfCanvas.lineTo((mainAddr_x + mainAddrMaxWidth), pageSize.getTop() - 300);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		String periodLabel = "Period of Validity:";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, pageSize.getTop() - 344).showText(periodLabel).moveText(60, -pageSize.getTop() + 30).endText();

		int periodMaxWidth = 152;
		int startPeriod_x = 200;
		int endPeriod_x = (startPeriod_x + periodMaxWidth + 12);

		String startPeriod = DateUtil.format(licence.getStartDate(), DateUtil.DATE_FORMAT_PATTERN);
		startPeriod = (startPeriod == null) ? "" : startPeriod.toUpperCase();

		int startPeriodTxtWidth = (int) timesBoldFont.getWidth(startPeriod, 12);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 12).moveText((startPeriod_x + ((periodMaxWidth / 2) - (startPeriodTxtWidth / 2))), pageSize.getTop() - 344).showText(startPeriod)
				.moveText(60, -pageSize.getTop() + 30).endText();

		String toLabel = "to";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText((startPeriod_x + periodMaxWidth), pageSize.getTop() - 344).showText(toLabel).moveText(60, -pageSize.getTop() + 30).endText();

		String endPeriod = DateUtil.format(licence.getExpiryDate(), DateUtil.DATE_FORMAT_PATTERN);
		endPeriod = (endPeriod == null) ? "" : endPeriod.toUpperCase();

		int endPeriodTxtWidth = (int) timesBoldFont.getWidth(endPeriod, 12);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 12).moveText((endPeriod_x + ((periodMaxWidth / 2) - (endPeriodTxtWidth / 2))), pageSize.getTop() - 344).showText(endPeriod)
				.moveText(60, -pageSize.getTop() + 30).endText();

		// Initial point of the line
		pdfCanvas.moveTo(startPeriod_x, pageSize.getTop() - 348);
		// Drawing the line
		pdfCanvas.lineTo((startPeriod_x + periodMaxWidth), pageSize.getTop() - 348);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		// Initial point of the line
		pdfCanvas.moveTo(endPeriod_x, pageSize.getTop() - 348);
		// Drawing the line
		pdfCanvas.lineTo((endPeriod_x + periodMaxWidth), pageSize.getTop() - 348);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		// Initial point of the line
		pdfCanvas.moveTo(53, pageSize.getTop() - 388);
		// Drawing the line
		pdfCanvas.lineTo(540, pageSize.getTop() - 388);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		List<String> txtList = new ArrayList<>();
		txtList.add("is hereby licensed to carry on the business of a travel agent subject to the");
		txtList.add("provisions of the Travel Agents Act, the Regulations made thereunder and");
		txtList.add("the conditions stipulated by the Singapore Tourism Board.");

		int content_y = (int) (pageSize.getTop() - 436);
		for (String txt : txtList) {
			pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, content_y).showText(txt).moveText(60, -pageSize.getTop() + 30).endText();

			content_y = (content_y - 18);
		}

		txtList.clear();
		txtList.add("Unless revoked or surrendered prior to such date under the provisions of");
		txtList.add("the Travel Agents Act or any of the Regulations made thereunder.");

		content_y = (content_y - 32);
		for (String txt : txtList) {
			pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, content_y).showText(txt).moveText(60, -pageSize.getTop() + 30).endText();

			content_y = (content_y - 18);
		}

		String remark = "This is a computer-generated document, no signature is required. ";
		pdfCanvas.beginText().setFontAndSize(timesFont, 12).moveText(222, pageSize.getTop() - 763).showText(remark).moveText(60, -pageSize.getTop() + 763).endText();

		String qrInfo = "Scan QR code to check validity";
		pdfCanvas.beginText().setFontAndSize(timesFont, 10).moveText(85, pageSize.getTop() - 632).showText(qrInfo).moveText(60, -pageSize.getTop() + 632).endText();

		String qrUrl = "";
		qrUrl = properties.taELicenceQrUrl;
		qrUrl = qrUrl + licence.getLicenceNo();
		logger.info("QR Code URL" + qrUrl);

		BarcodeQRCode barcodeQRCode = new BarcodeQRCode(qrUrl);
		PdfFormXObject barcodeObject = barcodeQRCode.createFormXObject(null, pdfDoc);
		Image qrImg = new Image(barcodeObject);
		qrImg.setWidth(152);
		qrImg.setHeight(152);
		qrImg.setFixedPosition(72, 64);
		doc.add(qrImg);

		// close PDF document.
		doc.close();
	}

	protected void drawBranchLicence(String dest, TravelAgent ta, Licence licence, AddressDto branchAddress) throws Exception {

		// background image file location
		String imgFileLocation = properties.baseDir + properties.imageDir;
		String fontFileLocation = properties.baseDir + properties.fontDir;
		String bgImage = "";
		String title = "";

		if (licence.getTier().getKey() != null && licence.getTier().getKey().equals(Codes.Types.TA_TIER_GENERAL)) {
			bgImage = imgFileLocation + Codes.Types.TA_TIER_GENERAL + ".png";
			title = "TRAVEL AGENT LICENCE (GENERAL)";
		} else if (licence.getTier().getKey() != null && licence.getTier().getKey().equals(Codes.Types.TA_TIER_NICHE)) {
			bgImage = imgFileLocation + Codes.Types.TA_TIER_NICHE + ".png";
			title = "TRAVEL AGENT LICENCE (NICHE)";
		}

		// open PDF document in writing mode.
		PdfDocument pdfDoc = new PdfDocument(new PdfWriter(dest));
		PageSize pageSize = PageSize.A4;
		// creates a document from a PdfDocument with a manually set PageSize.
		Document doc = new Document(pdfDoc, pageSize);
		// create an ImageData instance representing the image from the specified file
		ImageData image = ImageDataFactory.create(bgImage);
		PdfCanvas pdfCanvas = new PdfCanvas(pdfDoc.addNewPage());
		// creates PdfImageXObject from image and fitted into specific rectangle on
		// canvas. The created imageXObject will be fit inside on the specified
		// rectangle without preserving aspect ratio
		pdfCanvas.addImageFittedIntoRectangle(image, pageSize, false);

		String ARIAL_BLACK_BOLD_ITALIC = fontFileLocation + "Arial-Black-Italic.ttf";
		FontProgram fontProgramArialBlack = FontProgramFactory.createFont(ARIAL_BLACK_BOLD_ITALIC);

		PdfFont arialBlackBoldItalicFont = PdfFontFactory.createFont(fontProgramArialBlack, PdfEncodings.WINANSI);
		PdfFont timesBoldFont = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
		PdfFont timesFont = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);

		// Title
		pdfCanvas.beginText().setFontAndSize(arialBlackBoldItalicFont, 16).moveText(191, pageSize.getTop() - 105).showText(title).moveText(60, -pageSize.getTop() + 30).endText();

		String licenceLabel = "Licence Number";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 16).moveText(191, pageSize.getTop() - 126).showText(licenceLabel).moveText(60, -pageSize.getTop() + 30).endText();

		String licenceNumber = Codes.TaTgType.TA + licence.getLicenceNo();
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 26).moveText(191, pageSize.getTop() - 154).showText(licenceNumber).moveText(60, -pageSize.getTop() + 30).endText();

		String licenseeLabel = "Name of Licensee:";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, pageSize.getTop() - 222).showText(licenseeLabel).moveText(60, -pageSize.getTop() + 30).endText();

		int offset = 10;
		int licenseeMaxWidth = 315;
		int licensee_x = 200;
		float licenseeFontSize = 12;

		String licensee = ta.getName() != null ? ta.getName().trim().toUpperCase() : "";
		licenseeFontSize = countFontSizeByWidth(licensee, timesBoldFont, licenseeFontSize, licenseeMaxWidth);

		int licenseeTxtWidth = (int) timesBoldFont.getWidth(licensee, licenseeFontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, licenseeFontSize).moveText((licensee_x + offset), pageSize.getTop() - 222).showText(licensee).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(licensee_x, pageSize.getTop() - 226);
		// Drawing the line
		pdfCanvas.lineTo((licensee_x + licenseeMaxWidth), pageSize.getTop() - 226);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		String mainAddrLabel = "Main Address:";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, pageSize.getTop() - 251).showText(mainAddrLabel).moveText(60, -pageSize.getTop() + 30).endText();

		int mainAddrMaxWidth = 315;
		int mainAddr_x = 200;
		float mainAddr1FontSize = 12;
		float mainAddr2FontSize = 12;

		String mainAddr1 = getAddressLine1(ta.getOperatingAddress()).toUpperCase().trim();
		mainAddr1FontSize = countFontSizeByWidth(mainAddr1, timesBoldFont, mainAddr1FontSize, mainAddrMaxWidth);

		int mainAddr1TxtWidth = (int) timesBoldFont.getWidth(mainAddr1, mainAddr1FontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, mainAddr1FontSize).moveText((mainAddr_x + offset), pageSize.getTop() - 251).showText(mainAddr1).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(mainAddr_x, pageSize.getTop() - 255);
		// Drawing the line
		pdfCanvas.lineTo((mainAddr_x + mainAddrMaxWidth), pageSize.getTop() - 255);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		String mainAddr2 = getAddressLine2(ta.getOperatingAddress()).toUpperCase().trim();
		mainAddr2FontSize = countFontSizeByWidth(mainAddr2, timesBoldFont, mainAddr2FontSize, mainAddrMaxWidth);

		int mainAddr2TxtWidth = (int) timesBoldFont.getWidth(mainAddr2, mainAddr2FontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, mainAddr2FontSize).moveText((mainAddr_x + offset), pageSize.getTop() - 276).showText(mainAddr2).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(mainAddr_x, pageSize.getTop() - 280);
		// Drawing the line
		pdfCanvas.lineTo((mainAddr_x + mainAddrMaxWidth), pageSize.getTop() - 280);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		String periodLabel = "Period of Validity:";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, pageSize.getTop() - 308).showText(periodLabel).moveText(60, -pageSize.getTop() + 30).endText();

		int periodMaxWidth = 152;
		int startPeriod_x = 200;
		int endPeriod_x = (startPeriod_x + periodMaxWidth + 12);

		String startPeriod = DateUtil.format(licence.getStartDate(), DateUtil.DATE_FORMAT_PATTERN);
		startPeriod = (startPeriod == null) ? "" : startPeriod.toUpperCase();
		int startPeriodTxtWidth = (int) timesBoldFont.getWidth(startPeriod, 12);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 12).moveText((startPeriod_x + ((periodMaxWidth / 2) - (startPeriodTxtWidth / 2))), pageSize.getTop() - 308).showText(startPeriod)
				.moveText(60, -pageSize.getTop() + 30).endText();

		String toLabel = "to";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText((startPeriod_x + periodMaxWidth), pageSize.getTop() - 308).showText(toLabel).moveText(60, -pageSize.getTop() + 30).endText();

		String endPeriod = DateUtil.format(licence.getExpiryDate(), DateUtil.DATE_FORMAT_PATTERN);
		endPeriod = (endPeriod == null) ? "" : endPeriod.toUpperCase();
		int endPeriodTxtWidth = (int) timesBoldFont.getWidth(endPeriod, 12);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 12).moveText((endPeriod_x + ((periodMaxWidth / 2) - (endPeriodTxtWidth / 2))), pageSize.getTop() - 308).showText(endPeriod)
				.moveText(60, -pageSize.getTop() + 30).endText();

		// Initial point of the line
		pdfCanvas.moveTo(startPeriod_x, pageSize.getTop() - 312);
		// Drawing the line
		pdfCanvas.lineTo((startPeriod_x + periodMaxWidth), pageSize.getTop() - 312);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		// Initial point of the line
		pdfCanvas.moveTo(endPeriod_x, pageSize.getTop() - 312);
		// Drawing the line
		pdfCanvas.lineTo((endPeriod_x + periodMaxWidth), pageSize.getTop() - 312);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		List<String> txtList = new ArrayList<>();
		txtList.add("is  hereby  licensed  to  carry  on  the  business  of  a  travel agent  at");
		int content_y = (int) (pageSize.getTop() - 350);
		for (String txt : txtList) {
			pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, content_y).showText(txt).moveText(60, -pageSize.getTop() + 30).endText();
		}

		String branchAddrLabel = "Branch Address:";
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, pageSize.getTop() - 396).showText(branchAddrLabel).moveText(60, -pageSize.getTop() + 30).endText();

		int branchAddrMaxWidth = 315;
		int branchAddr_x = 200;
		float branchAddr1FontSize = 12;
		float branchAddr2FontSize = 12;

		String branchAddr1 = getAddressDtoLine1(branchAddress).toUpperCase().trim();
		branchAddr1FontSize = countFontSizeByWidth(branchAddr1, timesBoldFont, branchAddr1FontSize, branchAddrMaxWidth);

		int branchAddr1TxtWidth = (int) timesBoldFont.getWidth(branchAddr1, branchAddr1FontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, branchAddr1FontSize).moveText((branchAddr_x + offset), pageSize.getTop() - 396).showText(branchAddr1).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(branchAddr_x, pageSize.getTop() - 400);
		// Drawing the line
		pdfCanvas.lineTo((branchAddr_x + branchAddrMaxWidth), pageSize.getTop() - 400);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		String branchAddr2 = getAddressDtoLine2(branchAddress).toUpperCase().trim();
		branchAddr2FontSize = countFontSizeByWidth(branchAddr2, timesBoldFont, branchAddr2FontSize, branchAddrMaxWidth);

		int branchAddr2TxtWidth = (int) timesBoldFont.getWidth(branchAddr2, branchAddr2FontSize);
		pdfCanvas.beginText().setFontAndSize(timesBoldFont, branchAddr2FontSize).moveText((branchAddr_x + offset), pageSize.getTop() - 422).showText(branchAddr2).moveText(60, -pageSize.getTop() + 30)
				.endText();

		// Initial point of the line
		pdfCanvas.moveTo(branchAddr_x, pageSize.getTop() - 426);
		// Drawing the line
		pdfCanvas.lineTo((branchAddr_x + branchAddrMaxWidth), pageSize.getTop() - 426);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		// Initial point of the line
		pdfCanvas.moveTo(53, pageSize.getTop() - 454);
		// Drawing the line
		pdfCanvas.lineTo(540, pageSize.getTop() - 454);
		// Closing the path stroke
		pdfCanvas.closePathStroke();

		txtList.clear();
		txtList.add("subject to the provisions of the Travel Agents Act, the Regulations made");
		txtList.add("thereunder and the conditions stipulated by the Singapore Tourism Board. ");

		content_y = (int) (pageSize.getTop() - 500);
		for (String txt : txtList) {
			pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, content_y).showText(txt).moveText(60, -pageSize.getTop() + 30).endText();

			content_y = (content_y - 18);
		}

		txtList.clear();
		txtList.add("Unless revoked or surrendered prior to such date under the provisions of");
		txtList.add("the Travel Agents Act or any of the Regulations made thereunder.");

		content_y = (content_y - 30);
		for (String txt : txtList) {
			pdfCanvas.beginText().setFontAndSize(timesBoldFont, 14).moveText(79, content_y).showText(txt).moveText(60, -pageSize.getTop() + 30).endText();

			content_y = (content_y - 18);
		}

		String remark = "This is a computer-generated document, no signature is required. ";
		pdfCanvas.beginText().setFontAndSize(timesFont, 12).moveText(222, pageSize.getTop() - 763).showText(remark).moveText(60, -pageSize.getTop() + 763).endText();

		String qrInfo = "Scan QR code to check validity";
		pdfCanvas.beginText().setFontAndSize(timesFont, 10).moveText(85, pageSize.getTop() - 624).showText(qrInfo).moveText(60, -pageSize.getTop() + 624).endText();

		String qrUrl = "";
		qrUrl = properties.taELicenceQrUrl;
		qrUrl = qrUrl + licence.getLicenceNo();
		logger.info("QR Code URL" + qrUrl);
		BarcodeQRCode barcodeQRCode = new BarcodeQRCode(qrUrl);
		PdfFormXObject barcodeObject = barcodeQRCode.createFormXObject(null, pdfDoc);
		Image qrImg = new Image(barcodeObject);
		qrImg.setWidth(152);
		qrImg.setHeight(152);
		qrImg.setFixedPosition(72, 67);
		doc.add(qrImg);

		// close PDF document.
		doc.close();
	}

	private float countFontSizeByWidth(String text, PdfFont font, float fontSize, double maxWidth) {
		// start with a large font size
		float font_size = fontSize;
		double txtWidth = 0.00;
		// lower the font size until the text fits the canvas
		do {
			font_size = (float) (font_size - 0.01);
			txtWidth = font.getWidth(text, font_size);
		} while (txtWidth > maxWidth);
		return font_size;
	}

	private void deleteDir(String folderPath) {
		logger.info("delete directory");
		try {
			File dirFile = new File(folderPath);

			if (dirFile.exists()) {
				logger.info("directory exists");
				logger.info("Number of files before calling FileUtils.cleanDirectory() method clean directory - " + dirFile.listFiles().length);
				FileUtils.deleteDirectory(dirFile);
			} else {
				logger.info("directory does not exist");
			}
			logger.info("Existence of the %s directory - %s", dirFile.getName(), dirFile.exists());
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}
	}

	private String getAddressLine1(Address addr) {
		if (addr.getAddressType() != null && Codes.Types.ADDR_LOCAL.equals(addr.getAddressType().getCode())) {
			return toFormattedAddressLine1(addr);
		} else {
			return toUnstructuredSingleLineAddress(addr);
		}
	}

	private String getAddressLine2(Address addr) {
		if (addr.getAddressType() != null && Codes.Types.ADDR_LOCAL.equals(addr.getAddressType().getCode())) {
			return toFormattedAddressLine2(addr);
		} else {
			return "";
		}
	}

	private String toUnstructuredSingleLineAddress(Address addr) {
		String address = addr.getForeignLine1();
		if (!StringUtils.isEmpty(addr.getForeignLine2())) {
			address += " " + addr.getForeignLine2();
		}
		if (!StringUtils.isEmpty(addr.getForeignLine3())) {
			address += " " + addr.getForeignLine3();
		}
		return address;
	}

	private String toFormattedAddressLine1(Address addr) {
		// populating block + street
		String address = addr.getStreet();
		if (!Strings.isNullOrEmpty(addr.getBlock())) {
			address = addr.getBlock() + " " + address;
		}

		// populating floor, unit and building
		if (!Strings.isNullOrEmpty(addr.getFloor()) || !Strings.isNullOrEmpty(addr.getUnit())) {
			address += " ";
		}
		if (!Strings.isNullOrEmpty(addr.getFloor())) {
			if (!Strings.isNullOrEmpty(addr.getUnit())) {
				address += "#" + addr.getFloor();
			} else {
				address += addr.getFloor();
			}
		}

		if (!Strings.isNullOrEmpty(addr.getUnit())) {
			if (!Strings.isNullOrEmpty(addr.getFloor()) && !Strings.isNullOrEmpty(addr.getUnit())) {
				address += "-" + addr.getUnit();
			} else {
				address += addr.getUnit();
			}
		}
		return address;
	}

	private String toFormattedAddressLine2(Address addr) {
		String address = "";
		if (!Strings.isNullOrEmpty(addr.getBuilding())) {
			address += addr.getBuilding() + " ";
		}

		// populating postal
		if (!Strings.isNullOrEmpty(addr.getPostal())) {
			address += "SINGAPORE " + addr.getPostal();
		}
		return address;
	}

	private String getAddressDtoLine1(AddressDto addr) {
		if (addr.getType() != null && Codes.Types.ADDR_LOCAL.equals(addr.getType().getKey())) {
			return toFormattedAddressDtoLine1(addr);
		} else {
			return toUnstructuredSingleLineAddressDto(addr);
		}
	}

	private String getAddressDtoLine2(AddressDto addr) {
		if (addr.getType() != null && Codes.Types.ADDR_LOCAL.equals(addr.getType().getKey())) {
			return toFormattedAddressDtoLine2(addr);
		} else {
			return "";
		}
	}

	private String toUnstructuredSingleLineAddressDto(AddressDto addr) {
		String address = addr.getForeignLine1();
		if (!StringUtils.isEmpty(addr.getForeignLine2())) {
			address += " " + addr.getForeignLine2();
		}
		if (!StringUtils.isEmpty(addr.getForeignLine3())) {
			address += " " + addr.getForeignLine3();
		}
		return address;
	}

	private String toFormattedAddressDtoLine1(AddressDto addr) {
		// populating block + street
		String address = addr.getStreet();
		if (!Strings.isNullOrEmpty(addr.getBlock())) {
			address = addr.getBlock() + " " + address;
		}

		// populating floor, unit and building
		if (!Strings.isNullOrEmpty(addr.getFloor()) || !Strings.isNullOrEmpty(addr.getUnit())) {
			address += " ";
		}
		if (!Strings.isNullOrEmpty(addr.getFloor())) {
			if (!Strings.isNullOrEmpty(addr.getUnit())) {
				address += "#" + addr.getFloor();
			} else {
				address += addr.getFloor();
			}
		}

		if (!Strings.isNullOrEmpty(addr.getUnit())) {
			if (!Strings.isNullOrEmpty(addr.getFloor()) && !Strings.isNullOrEmpty(addr.getUnit())) {
				address += "-" + addr.getUnit();
			} else {
				address += addr.getUnit();
			}
		}
		return address;
	}

	private String toFormattedAddressDtoLine2(AddressDto addr) {
		String address = "";
		if (!Strings.isNullOrEmpty(addr.getBuilding())) {
			address += addr.getBuilding() + " ";
		}

		// populating postal
		if (!Strings.isNullOrEmpty(addr.getPostal())) {
			address += "SINGAPORE " + addr.getPostal();
		}
		return address;
	}
}