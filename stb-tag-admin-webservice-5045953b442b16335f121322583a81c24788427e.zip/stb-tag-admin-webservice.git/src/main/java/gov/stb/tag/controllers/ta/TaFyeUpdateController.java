package gov.stb.tag.controllers.ta;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.fye.TaAnnualFilingSubmissionDto;
import gov.stb.tag.dto.ta.fye.TaChangeFyeItemDto;
import gov.stb.tag.dto.ta.fye.TaChangeFyeSearchDto;
import gov.stb.tag.dto.ta.fye.TaFyDto;
import gov.stb.tag.dto.ta.fye.TaFyUpdateDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFyUpdate;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaFyeUpdateRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/fye")
@Transactional
public class TaFyeUpdateController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaFyeUpdateRepository taFyeUpdateRepository;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;

	@RequestMapping(value = "/load/fys", method = RequestMethod.GET)
	public List<TaFyDto> getFyList() {
		User currentUser = taFyeUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		TravelAgent ta = currentUser.getTravelAgent();
		List<TaFyDto> fys = taFyeUpdateRepository.getFys(ta.getLicence().getId());

		if (CollectionUtils.isNotEmpty(fys)) {
			// derive the min and max fy end date to be changed
			fys.stream().forEach(fy -> {
				fy.setMinFyEndDate(fy.getFyStartDate().plusDays(1));
				fy.setMaxFyEndDate(fy.getFyStartDate().minusDays(1).plusMonths(24));
			});

			// add the upcoming fy into the list
			fys.add(new TaFyDto(fys.get(fys.size() - 1).getFyEndDate().plusDays(1), ta.getFyeDate()));
		} else {
			TaFilingCondition prevFiling = taAnnualFilingRepository.getPreviousTaAnnualFiling(ta.getLicence().getId());

			LocalDate fyStartDate = null;
			if (prevFiling == null) {
				// no filing generated yet, probably is new TA, start date take from licence start date
				fyStartDate = ta.getLicence().getStartDate();
			} else {
				fyStartDate = prevFiling.getFyEndDate().plusDays(1);
			}

			fys = Lists.newArrayList(new TaFyDto(fyStartDate, ta.getFyeDate()));
		}

		return fys;
	}

	@RequestMapping(value = "/load", method = RequestMethod.GET)
	public TaFyUpdateDto loadNewOrPending() {
		User currentUser = taFyeUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			Licence licence = currentUser.getTravelAgent().getLicence();
			TaFyUpdate fyUpdate = taFyeUpdateRepository.getPendingApplication(licence.getId());
			if (fyUpdate == null) {
				TaFyUpdateDto dto = TaFyUpdateDto.buildFromNew(cache, licence, fileHelper);
				return dto;
			} else {
				TaFyUpdateDto dto = TaFyUpdateDto.buildFromApplication(cache, appHelper, fyUpdate, fileHelper);
				return dto;
			}
		}
		return null;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaFyUpdateDto dto) {

		Application application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_FY_UPDATE,
				(taFyeUpdateRepository.getLicenseeUserByUserId(getUser().getId()).getTravelAgent().getLicence().getId()), dto.isOfflineSubmission(), false);
		appHelper.forward(application, true);

		// 2. Save files uploaded by user
		fileHelper.saveFile(application, dto.getDirectorResolution());
		for (FileDto doc : dto.getOtherDocuments()) {
			fileHelper.saveFile(application, doc);
		}

		// 3. Save fields in form
		this.saveApplicationFields(dto, new TaFyUpdate(), application);
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateApplication(@RequestPart(name = "application") TaFyUpdateDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {

		// 1. Save application actions
		Application application = taFyeUpdateRepository.get(Application.class, dto.getApplicationId());
		appHelper.forward(application, true);

		// 2. Delete files deleted by user
		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}

		}

		// 3. Save additional files uploaded by user
		if (dto.getDirectorResolution().getPublicFileId() == null) {
			fileHelper.saveFile(application, dto.getDirectorResolution());
		}
		for (FileDto doc : dto.getOtherDocuments()) {
			if (doc.getPublicFileId() == null) {
				fileHelper.saveFile(application, doc);
			}
		}

		// 4. Save changes made by user
		this.saveApplicationFields(dto, taFyeUpdateRepository.getApplication(application.getId()), application);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaChangeFyeItemDto> getList(TaChangeFyeSearchDto searchDto) {
		return taFyeUpdateRepository.getPendingList(searchDto, getUser().getId());
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaFyUpdateDto getApplication(@PathVariable Integer id) {
		User currentUser = taFyeUpdateRepository.getLicenseeUserByUserId(getUser().getId());
		TaFyUpdateDto resultDto = new TaFyUpdateDto();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
			resultDto = TaFyUpdateDto.buildFromApplication(cache, appHelper, taFyeUpdateRepository.getApplication(id), fileHelper);

			if (!Codes.Statuses.TA_APP_APPROVED.equals(resultDto.getApplicationStatus().getKey()) && !Codes.Statuses.TA_APP_REJECTED.equals(resultDto.getApplicationStatus().getKey())) {

				// set the affected filings
				List<TaFilingCondition> filings = taAnnualFilingRepository.getTaAnnualFilingByFye(resultDto.getLicenceId(), resultDto.getSelectedFyObj().getFyEndDate());
				if (CollectionUtils.isNotEmpty(filings)) {
					resultDto.setAffectedFilings(Lists.newArrayList());

					Map<String, List<TaFilingCondition>> filingsByAppType = Maps.newHashMap();
					sortAndconvertToMap(filingsByAppType, filings);

					for (String appType : filingsByAppType.keySet()) {
						TaAnnualFilingSubmissionDto previousFiling = null;
						for (TaFilingCondition filing : filingsByAppType.get(appType)) {
							LocalDate newfyEndDate = null;
							if (previousFiling == null) {
								newfyEndDate = resultDto.getNewFyEndDate();
							} else {
								newfyEndDate = appHelper.getNextFyEndDate(previousFiling.getFyeDateToBe());
							}

							TaAnnualFilingSubmissionDto filingDto = TaAnnualFilingSubmissionDto.buildFromAnnualFiling(cache, filing);
							filingDto.setFyeDateToBe(newfyEndDate);
							// check if the filing has application
							if (Codes.ApplicationTypes.TA_APP_AA_SUBMISSION.equals(filing.getApplicationType().getCode())) {
								TaAaSubmission aaSubmission = taFyeUpdateRepository.getTaAaSubmissionByFilingId(filing.getId());
								filingDto.setApplicationNo(aaSubmission == null ? "-" : aaSubmission.getApplication().getApplicationNo());
							} else if (Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION.equals(filing.getApplicationType().getCode())) {
								TaAbprSubmission abprSubmission = taFyeUpdateRepository.getTaAbprSubmissionByFilingId(filing.getId());
								filingDto.setApplicationNo(abprSubmission == null ? "-" : abprSubmission.getApplication().getApplicationNo());
							}
							resultDto.getAffectedFilings().add(filingDto);

							previousFiling = filingDto;
						}
					}
				}
			}
		}
		return resultDto;
	}

	// to approve, reject, revert change fye
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaFyUpdate fyAppl = taFyeUpdateRepository.getApplication(id);
		Application app = fyAppl.getApplication();

		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			if (appHelper.hasFinalApproved(app)) {
				statusCode = Codes.Statuses.TA_APP_APPROVED;
				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taMsgType = Codes.EmailType.TA_UPON_APPROVAL;
				changeFye(fyAppl);

				// create case if submission date is > 6 months from previous fye
				logger.info("Change of FYE(App id:{}) submission Date:{}, Current FYP:{} to {}, New FYP:{} to {}", fyAppl.getApplication().getId(),
						DateUtil.format(fyAppl.getApplication().getSubmissionDate()), DateUtil.format(fyAppl.getFyStartDate()), DateUtil.format(fyAppl.getOldFyeDate()),
						DateUtil.format(fyAppl.getFyStartDate()), DateUtil.format(fyAppl.getNewFyeDate()));

				Integer duration = cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_MONTHS_TO_INFORM_DUE_FYE_CHANGE);
				LocalDate thisFyStartDate = fyAppl.getFyStartDate();
				if (fyAppl.getApplication().getSubmissionDate().isAfter(thisFyStartDate.plusMonths(duration).atStartOfDay().minusNanos(1))) {
					logger.info("Change of fye submission is more than > {} months. Creating case...", duration);
					ceCaseHelper.createCaseForFyeInfringement(fyAppl);
				}
			}

			break;

		case ACTION_REJECT:
			statusCode = Codes.Statuses.TA_APP_REJECTED;
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;

			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taMsgType = Codes.EmailType.TA_UPON_RFA;
				taAlertMsg = Messages.Alerts.APP_RFA;
			}

			appHelper.rfa(app, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;
		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(app.getLicence().getTravelAgent(), app, taAlertMsg, Codes.Modules.MOD_TA, app.getType(), "../ta-change-fye/" + app.getId(), cache.getStatus(statusCode));

			/* Send email to notify TA */
			String url = String.format(properties.applicationUrl, "ta-change-fye/" + fyAppl.getApplication().getId());
			emailHelper.emailTaUponAction(app, taMsgType, url);
		}

	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taFyeUpdateRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void saveApplicationFields(TaFyUpdateDto dto, TaFyUpdate fyUpdateAppl, Application application) {
		if (fyUpdateAppl == null) {
			fyUpdateAppl = new TaFyUpdate();
		}
		fyUpdateAppl.setApplication(application);
		fyUpdateAppl.setFyStartDate(dto.getSelectedFyObj().getFyStartDate());
		fyUpdateAppl.setOldFyeDate(dto.getSelectedFyObj().getFyEndDate());
		fyUpdateAppl.setNewFyeDate(dto.getNewFyEndDate());
		fyUpdateAppl.setReason(dto.getReason());
		taFyeUpdateRepository.save(fyUpdateAppl);
	}

	private void changeFye(TaFyUpdate fyAppl) {

		// update the fyend date of the existing annual filing if any
		List<TaFilingCondition> filings = taAnnualFilingRepository.getTaAnnualFilingByFye(fyAppl.getApplication().getLicence().getId(), fyAppl.getOldFyeDate());
		Map<String, List<TaFilingCondition>> filingsByAppType = Maps.newHashMap();

		TravelAgent ta = fyAppl.getApplication().getLicence().getTravelAgent();
		LocalDate upcomingFyEndDate = ta.getFyeDate();

		if (CollectionUtils.isNotEmpty(filings)) { // existing filings should be empty if ta change the future fye date
			LocalDate lastFyeEndDate = fyAppl.getNewFyeDate();
			Boolean hasNewFilingCreated = false;

			sortAndconvertToMap(filingsByAppType, filings);

			for (String appType : filingsByAppType.keySet()) {
				TaFilingCondition previousFiling = null;

				for (TaFilingCondition oldFiling : filingsByAppType.get(appType)) {

					// void old filing
					oldFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_VOID));
					oldFiling.setRemarks("Change of fye, appl no:" + fyAppl.getApplication().getApplicationNo());
					taFyeUpdateRepository.update(oldFiling);

					// create new filing if new fyeDate had passed
					LocalDate fyStartDate = null;
					LocalDate fyEndDate = null;
					if (previousFiling == null) {
						fyStartDate = oldFiling.getFyStartDate();
						fyEndDate = fyAppl.getNewFyeDate();
					} else {
						fyStartDate = previousFiling.getFyEndDate().plusDays(1);
						fyEndDate = appHelper.getNextFyEndDate(previousFiling.getFyEndDate());
					}

					if (!fyEndDate.isAfter(fyStartDate)) {
						logger.error("FyEndDate (" + DateUtil.format(fyEndDate) + ") is not before fyStartDate (" + DateUtil.format(fyStartDate) + ")!");
						throw new ValidationException("FyEndDate (" + DateUtil.format(fyEndDate) + ") cannot be earlier than fyStartDate (" + DateUtil.format(fyStartDate) + ")!");
					}

					if (LocalDate.now().isAfter(fyEndDate)) {
						TaFilingCondition newFiling = appHelper.saveTaAnnualFiling(oldFiling.getLicence(), fyStartDate, fyEndDate, oldFiling.getApplicationType().getCode(),
								oldFiling.getTarR141Infringement());

						// link AA and ABPR submission to new filing if the application status is RFA or Pending Approval or in Draft mode
						TaAaSubmission aaSubmission = taFyeUpdateRepository.getTaAaSubmissionByFilingId(oldFiling.getId()) == null
								? taFyeUpdateRepository.getDraftTaAaSubmissionByFilingId(oldFiling.getId())
								: taFyeUpdateRepository.getTaAaSubmissionByFilingId(oldFiling.getId());
						if (aaSubmission != null) {
							aaSubmission.setTaAnnualFiling(newFiling);
							taFyeUpdateRepository.update(newFiling);
						}

						TaAbprSubmission abprSubmission = taFyeUpdateRepository.getTaAbprSubmissionByFilingId(oldFiling.getId()) == null
								? taFyeUpdateRepository.getDraftTaAbprSubmissionByFilingId(oldFiling.getId())
								: taFyeUpdateRepository.getTaAbprSubmissionByFilingId(oldFiling.getId());
						if (abprSubmission != null) {
							abprSubmission.setTaAnnualFiling(newFiling);
							taFyeUpdateRepository.update(newFiling);
						}

						hasNewFilingCreated = true;
						previousFiling = newFiling;
						lastFyeEndDate = fyEndDate.isAfter(lastFyeEndDate) ? fyEndDate : lastFyeEndDate;
					}
				}
			}

			if (hasNewFilingCreated) {
				upcomingFyEndDate = appHelper.getNextFyEndDate(lastFyeEndDate);
			} else {
				upcomingFyEndDate = lastFyeEndDate;
			}
		} else {
			upcomingFyEndDate = fyAppl.getNewFyeDate();
		}

		// update upcoming fye end date
		ta.setFyeDate(upcomingFyEndDate);
		taFyeUpdateRepository.update(ta);
	}

	private void sortAndconvertToMap(Map<String, List<TaFilingCondition>> filingsByAppType, List<TaFilingCondition> filings) {
		for (TaFilingCondition filing : filings) {
			String appCode = filing.getApplicationType().getCode();
			if (filingsByAppType.containsKey(appCode)) {
				filingsByAppType.get(appCode).add(filing);
			} else {
				filingsByAppType.put(appCode, Lists.newArrayList(filing));
			}
			Collections.sort(filingsByAppType.get(appCode), Comparator.comparing(TaFilingCondition::getFyEndDate));
		}
	}
}
