package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licencemanageke.TaLicenceKeCompareDetails;
import gov.stb.tag.dto.ta.licencemanageke.TaLicenceKeDetailsDto;
import gov.stb.tag.dto.ta.licencemanageke.TaLicenceKeItemDto;
import gov.stb.tag.dto.ta.licencemanageke.TaLicenceKeSearchDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.CeTaskRepository;
import gov.stb.tag.repository.TaCommonRepository;
import gov.stb.tag.repository.ta.TaKeApplicationRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/ke")
@Transactional
public class TaKeApplicationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaKeApplicationRepository repository;
	@Autowired
	protected CacheHelper cache;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	CeTaskHelper ceTaskHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	CeTaskRepository ceTaskRepository;
	@Autowired
	TaCommonRepository taCommonRepository;

	public static final Object[] keResigndocTypeList = { Codes.TaDocumentTypes.TA_DOC_KE_RESIGN_LETTER };
	public static final Object[] keUpdatedocTypeList = { Codes.TaDocumentTypes.TA_DOC_KE_NRIC };
	public static final Object[] keAssigndocTypeList = { Codes.TaDocumentTypes.TA_DOC_KE_DIR_RESOLUTION, Codes.TaDocumentTypes.TA_DOC_KE_RESUME, Codes.TaDocumentTypes.TA_DOC_KE_NRIC };
	private static final Object[] keAssignType = { Codes.ApplicationTypes.TA_APP_KE_ASSIGN, Codes.ApplicationTypes.TA_APP_KE_REASSIGN };

	// Intranet: to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceKeItemDto> getList(TaLicenceKeSearchDto searchDto) {
		ResultDto<TaLicenceKeItemDto> resultDTO = new ResultDto<TaLicenceKeItemDto>();
		resultDTO = repository.getPendingList(searchDto, getUser().getId());
		return resultDTO;
	}

	// Intranet: to retrieve application details
	@RequestMapping(value = { "/view/{id}" }, method = RequestMethod.GET)
	public TaLicenceKeDetailsDto getApplicationCompareChange(@PathVariable Integer id) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());
		TaLicenceKeDetailsDto resultDto = new TaLicenceKeDetailsDto();
		resultDto.setCompareDetailsDto(new ArrayList<TaLicenceKeCompareDetails>());
		List<TaLicenceKeCompareDetails> compareDtoList = resultDto.getCompareDetailsDto();
		resultDto.setTaKeStakeholder(new TaStakeholderDto());
		List<FileDto> fileList = new ArrayList<FileDto>();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}

			/* Get KE application details */
			TaStakeholderApplication keAppModel = new TaStakeholderApplication();
			keAppModel = repository.getKeAppFromAppId(id);
			List<FileDto> reqFileList = new ArrayList<FileDto>();
			if (Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(keAppModel.getApplication().getType().getCode())) {
				// Set current KE details and new ke details into DTO
				List<TaStakeholder> taStakeholders = new ArrayList<TaStakeholder>();
				taStakeholders = repository.getTaStakeholdersFromStakeholder(keAppModel.getTaStakeholder().getStakeholder().getId());
				// set current KE details
				resultDto.setStakeholderDto(new StakeholderDto(cache, keAppModel.getTaStakeholder().getStakeholder()));
				resultDto.setTaKeStakeholder(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, keAppModel.getTaStakeholder(), Boolean.TRUE, Boolean.TRUE));
				reqFileList = repository.getSupportingDocList(keResigndocTypeList, fileHelper); /* to define which supporting Doc are required */
				reqFileList.addAll(repository.getSupportingDocList(keAssigndocTypeList, fileHelper));
			}

			// Set new KE details
			TaStakeholder newTaKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
			resultDto = TaLicenceKeDetailsDto.buildAppDtoFromTaStakeholderAppModel(cache, appHelper, keAppModel, resultDto, null, newTaKe);

			// if (Codes.ApplicationTypes.TA_APP_KE_RESIGN.equalsIgnoreCase(keAppModel.getApplication().getType().getCode())
			// || Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(keAppModel.getApplication().getType().getCode())) {
			// if (resultDto.getTaKeStakeholder().getResignedDate() == null) {
			// resultDto.getTaKeStakeholder().setResignedDate(keAppModel.getResignedDate());
			// }
			// }

			if (Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS.equalsIgnoreCase(keAppModel.getApplication().getType().getCode())) {
				reqFileList = repository.getSupportingDocList(keUpdatedocTypeList, fileHelper); /* to define which supporting Doc are required */
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DateUtil.DATE_FORMAT_PATTERN);

				compareDtoList.add(new TaLicenceKeCompareDetails("NRIC/PASSPORT/FIN NO.", keAppModel.getUin(), keAppModel.getPreviousValue().getUin()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Name", keAppModel.getName(), keAppModel.getPreviousValue().getName()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Date of birth", keAppModel.getDob() != null ? keAppModel.getDob().format(formatter) : "",
						keAppModel.getPreviousValue().getDob() != null ? keAppModel.getPreviousValue().getDob().format(formatter) : ""));
				compareDtoList.add(new TaLicenceKeCompareDetails("Gender", keAppModel.getSex(), keAppModel.getPreviousValue().getSex()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Nationality", keAppModel.getNationality(), keAppModel.getPreviousValue().getNationality()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Mobile no.", keAppModel.getContactNo(), keAppModel.getPreviousValue().getContactNo()));

				compareDtoList.add(new TaLicenceKeCompareDetails("Office no.", keAppModel.getOfficeNo(), keAppModel.getPreviousValue().getOfficeNo()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Residential no.", keAppModel.getResidentialNo(), keAppModel.getPreviousValue().getResidentialNo()));

				compareDtoList.add(new TaLicenceKeCompareDetails("Email address", keAppModel.getEmail(), keAppModel.getPreviousValue().getEmail()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Highest Qualification Attained", keAppModel.getHighestEduLevel(), keAppModel.getPreviousValue().getHighestEduLevel()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Designation", keAppModel.getDesignation(), keAppModel.getPreviousValue().getDesignation()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Other Designation", keAppModel.getOtherDesignation(), keAppModel.getPreviousValue().getOtherDesignation()));

				// compareDtoList.add(new TaLicenceKeCompareDetails(resultDto.getNewStakeholderDto().isScpr() ? "Registered Address:" : " Mailing Address:", null, null));
				compareDtoList.add(new TaLicenceKeCompareDetails("Postal Code", keAppModel.getAddress().getPostal(), keAppModel.getPreviousValue().getAddress().getPostal()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Block/House No", keAppModel.getAddress().getBlock(), keAppModel.getPreviousValue().getAddress().getBlock()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Street Name", keAppModel.getAddress().getStreet(), keAppModel.getPreviousValue().getAddress().getStreet()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Building Name", keAppModel.getAddress().getBuilding(), keAppModel.getPreviousValue().getAddress().getBuilding()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Level", keAppModel.getAddress().getFloor(), keAppModel.getPreviousValue().getAddress().getFloor()));
				compareDtoList.add(new TaLicenceKeCompareDetails("Unit No", keAppModel.getAddress().getUnit(), keAppModel.getPreviousValue().getAddress().getUnit()));

			}

			if (Codes.ApplicationTypes.TA_APP_KE_RESIGN.equalsIgnoreCase(keAppModel.getApplication().getType().getCode())) {
				reqFileList = repository.getSupportingDocList(keResigndocTypeList, fileHelper); /* to define which supporting Doc are required */
			}

			if (Codes.ApplicationTypes.TA_APP_KE_ASSIGN.equalsIgnoreCase(keAppModel.getApplication().getType().getCode())) {
				reqFileList = repository.getSupportingDocList(keAssigndocTypeList, fileHelper); /* to define which supporting Doc are required */
			}

			fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
			resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));

		}

		return resultDto;
	}

	// Intranet: to approve, reject, revert KE update details or resign or assign or reassign
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {

		TaStakeholderApplication keAppModel = new TaStakeholderApplication();
		keAppModel = repository.getKeAppFromAppId(id);
		keAppModel.setIsCompany(Boolean.FALSE);

		Application appModel = repository.get(Application.class, keAppModel.getApplication().getId());

		String appType = appModel.getType().getCode();
		String appUrl = null;
		switch (appType) {
		case Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS:
			appUrl = "ta-manage-ke-update/";
			break;
		case Codes.ApplicationTypes.TA_APP_KE_RESIGN:
			appUrl = "ta-manage-ke-resign/";
			break;
		case Codes.ApplicationTypes.TA_APP_KE_REASSIGN:
		case Codes.ApplicationTypes.TA_APP_KE_ASSIGN:
			appUrl = "ta-manage-ke-assign/";
			break;

		}

		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(appModel, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(appModel)) {
				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taMsgType = Codes.EmailType.TA_UPON_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;
				Integer daysToInformKeResign = cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_DAYS_TO_INFORM_DUE_KE_RESIGN);

				TaStakeholder currentKe = new TaStakeholder();
				Long daysDiff = 0L;
				switch (appType) {
				case Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS:
					Stakeholder currentStakeholderModel = new Stakeholder();
					currentStakeholderModel = repository.get(Stakeholder.class, keAppModel.getTaStakeholder().getStakeholder().getId());
					currentStakeholderModel = repository.updateStakeholderModelFromStakeholderAppModel(currentStakeholderModel, keAppModel);
					repository.saveOrUpdate(currentStakeholderModel);
					break;

				case Codes.ApplicationTypes.TA_APP_KE_RESIGN:
					currentKe = repository.get(TaStakeholder.class, keAppModel.getTaStakeholder().getId());
					LocalDate resignDate = keAppModel.getResignedDate() == null ? appModel.getSubmissionDate().toLocalDate() : keAppModel.getResignedDate();
					currentKe.setResignedDate(resignDate);
					keAppModel.setResignedDate(resignDate);
					repository.saveOrUpdate(currentKe);

					daysDiff = ChronoUnit.DAYS.between(keAppModel.getResignedDate(), keAppModel.getApplication().getSubmissionDate());
					logger.info("Diffence in days: {}", daysDiff);
					if (daysDiff > daysToInformKeResign) {
						logger.info("KE Resignation submission is more than > {} days. Creating case...");
						ceCaseHelper.createCaseForKeInfringement(keAppModel, keAppModel.getResignedDate().plusDays(daysToInformKeResign).plusDays(1));
					}

					break;

				case Codes.ApplicationTypes.TA_APP_KE_REASSIGN:
				case Codes.ApplicationTypes.TA_APP_KE_ASSIGN:
					TaStakeholder newKe = new TaStakeholder();
					if (Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(keAppModel.getType().getCode())) {
						currentKe = repository.get(TaStakeholder.class, keAppModel.getTaStakeholder().getId());
						currentKe.setResignedDate(keAppModel.getResignedDate() == null ? appModel.getSubmissionDate().toLocalDate() : keAppModel.getResignedDate());
						repository.saveOrUpdate(currentKe);

						daysDiff = ChronoUnit.DAYS.between(keAppModel.getResignedDate(), keAppModel.getApplication().getSubmissionDate());
						logger.info("Diffence in days: {}", daysDiff);
						if (daysDiff > daysToInformKeResign) {
							TaStakeholder lastResignedKe = taCommonRepository.getTaLastResignedKe(appModel.getLicence().getId());
							CeCaseInfringement liveInfringement = ceTaskRepository.searchKeR153bInfringementLiveCase(appModel.getLicence().getId());
							if (lastResignedKe == null) {
								if (liveInfringement == null) {
									logger.info("KE Re-assignment submission is more than > {} days. Creating case...");
									ceCaseHelper.createCaseForKeInfringement(keAppModel, keAppModel.getResignedDate().plusDays(daysToInformKeResign).plusDays(1));
								}
							}
						}
					}
					// If the application Uin === current Ke Uin, it means that the application only submi declaration, there is no need to save details again
					Stakeholder lastAppointedKeDetails = travelAgentRepository.getTaLatestAppointedKe(appModel.getLicence().getId());
					if (lastAppointedKeDetails == null || (lastAppointedKeDetails != null && !lastAppointedKeDetails.getUin().equalsIgnoreCase(keAppModel.getUin()))) {
						// check if in DB there is already this personnel
						Stakeholder existingDetails = new Stakeholder();
						existingDetails = travelAgentRepository.getSameStakeholder(keAppModel.getUin());
						Stakeholder newKeDetails = new Stakeholder();
						if (existingDetails != null) {
							newKeDetails = repository.updateStakeholderModelFromStakeholderAppModel(existingDetails, keAppModel);
						} else {
							newKeDetails = repository.updateStakeholderModelFromStakeholderAppModel(newKeDetails, keAppModel);
						}
						repository.saveOrUpdate(newKeDetails);
						newKe.setAppointedDate(keAppModel.getAppointedDate() == null ? LocalDate.now() : keAppModel.getAppointedDate());
						newKe.setRole(keAppModel.getRole());
						newKe.setLicence(keAppModel.getApplication().getLicence());
						newKeDetails.setIsCompany(Boolean.FALSE);
						newKe.setStakeholder(newKeDetails);
					} else {
						newKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
					}

					Set<TaKeDeclaration> taKeDeclarations = keAppModel.getTaKeDeclarations();
					for (TaKeDeclaration row : taKeDeclarations) {
						row.setTaKeyExecutive(newKe);
					}
					repository.saveOrUpdate(newKe);
					break;

				}
			}
			break;

		case ACTION_REJECT:
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;

			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;

			switch (appType) {
			// Require to resign KE if this KE was approved, but submit declaration and it was rejected.
			case Codes.ApplicationTypes.TA_APP_KE_REASSIGN:
			case Codes.ApplicationTypes.TA_APP_KE_ASSIGN:
				Stakeholder curentKeDetails = new Stakeholder();
				curentKeDetails = travelAgentRepository.getExistingKe(keAppModel.getApplication().getLicence().getId());
				TaStakeholder thisTaKe = new TaStakeholder();
				if (curentKeDetails != null) {
					if (curentKeDetails.getUin().equalsIgnoreCase(keAppModel.getUin())) {
						thisTaKe = repository.getTaStakeholderFromStakeholder(keAppModel.getUin(), keAppModel.getName(), keAppModel.getApplication().getLicence().getId(), curentKeDetails.getId());
						thisTaKe.setResignedDate(LocalDate.now());
						repository.saveOrUpdate(thisTaKe);
					}
				}
			}

			appHelper.reject(appModel, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
			}

			appHelper.rfa(appModel, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(appModel.getLicence().getTravelAgent(), appModel, taAlertMsg, Codes.Modules.MOD_TA, appModel.getType(), "../" + appUrl + appModel.getId(),
					cache.getStatus(statusCode));

			/* Send email to notify TA */
			String url = String.format(properties.applicationUrl, appUrl + appModel.getId());
			emailHelper.emailTaUponAction(appModel, taMsgType, url);
		}

	}

	/***** Internet: UPDATE DETAILS OF KE *****/
	// Internet to retrieve application details
	@RequestMapping(value = { "/update-details/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceKeDetailsDto getApplication(@PathVariable Integer id) {
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());

		TaLicenceKeDetailsDto resultDto = new TaLicenceKeDetailsDto();
		List<FileDto> fileList = new ArrayList<FileDto>();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
			TaStakeholderApplication keAppModel = new TaStakeholderApplication();
			keAppModel = repository.getKeAppFromAppId(id);
			if (keAppModel != null) {
				List<TaStakeholder> taStakeholders = new ArrayList<TaStakeholder>();
				TaStakeholder newTaKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
				taStakeholders = repository.getTaStakeholdersFromStakeholder(keAppModel.getTaStakeholder().getStakeholder().getId());
				resultDto = TaLicenceKeDetailsDto.buildAppDtoFromTaStakeholderAppModel(cache, appHelper, keAppModel, resultDto, taStakeholders, newTaKe);

				fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
				if (fileList != null) {
					resultDto.setFiles(fileList);
				}
				resultDto = repository.compareUserUinAndKeUin(resultDto, currentUser.getLoginId(), keAppModel.getTaStakeholder().getStakeholder().getUin());
			}

			List<FileDto> reqFileList = new ArrayList<FileDto>();
			fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
			reqFileList = repository.getSupportingDocList(keUpdatedocTypeList, fileHelper); /* to define which supporting Doc are required */

			resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
		}

		return resultDto;
	}

	// Internet to create new or get existing update ke details application details
	@RequestMapping(value = "/update-details/new", method = RequestMethod.GET)
	public TaLicenceKeDetailsDto getNewApplication() {
		Licence licenceModel = new Licence();
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());
		licenceModel = currentUser.getTravelAgent().getLicence();
		String currentKeUin = null;

		TaLicenceKeDetailsDto resultDto = new TaLicenceKeDetailsDto();
		Application appModel = new Application();
		List<FileDto> fileList = new ArrayList<FileDto>();

		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(licenceModel)) {
			appModel = repository.getPendingApplicationFromLicenceId(licenceModel.getId(), Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS);
		}
		if (appModel == null) { // Create new application if no existing application

			Stakeholder stakeholderModel = new Stakeholder();
			stakeholderModel = travelAgentRepository.getExistingKe(licenceModel.getId());

			if (stakeholderModel == null) {
				resultDto.setHaveKe(Boolean.FALSE);
			} else {
				currentKeUin = stakeholderModel.getUin();
			}
			resultDto = TaLicenceKeDetailsDto.buildNewAppDtoFromCurrentStakeholderModel(cache, stakeholderModel, resultDto, Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS, Codes.Statuses.TA_APP_NEW);

		} else { // Retrieve existing aplication
			TaStakeholderApplication keAppModel = new TaStakeholderApplication();
			keAppModel = repository.getKeAppFromAppId(appModel.getId());
			List<TaStakeholder> taStakeholders = new ArrayList<TaStakeholder>();
			taStakeholders = repository.getTaStakeholdersFromStakeholder(keAppModel.getTaStakeholder().getStakeholder().getId());
			TaStakeholder newTaKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
			resultDto = TaLicenceKeDetailsDto.buildAppDtoFromTaStakeholderAppModel(cache, appHelper, keAppModel, resultDto, taStakeholders, newTaKe);
			currentKeUin = keAppModel.getTaStakeholder().getStakeholder().getUin();
			fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
		}

		resultDto = repository.compareUserUinAndKeUin(resultDto, currentUser.getLoginId(), currentKeUin);

		List<FileDto> reqFileList = new ArrayList<FileDto>();
		reqFileList = repository.getSupportingDocList(keUpdatedocTypeList, fileHelper); /* to define which supporting Doc are required */

		resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));

		return resultDto;
	}

	// Internet to submit new update ke details application details
	@RequestMapping(path = { "/update-details/save", "/update-details/update", }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaLicenceKeDetailsDto dto) throws IOException {
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();

		if (dto != null & dto.getApplicationId() != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
			}
		}

		Application appModel = new Application();
		TaStakeholderApplication keModel = new TaStakeholderApplication();

		if (dto != null) {
			if (dto.getApplicationId() != null) { // get existing application
				appModel = repository.get(Application.class, dto.getApplicationId());
				keModel = repository.get(TaStakeholderApplication.class, dto.getTaKeAppId());
			} else { // save new application details
				appModel = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS, licenceModel.getId(), dto.isOfflineSubmission(), false);
			}
		}
		appHelper.forward(appModel, true);

		TaStakeholder currentKeDetails = new TaStakeholder();
		currentKeDetails = repository.get(TaStakeholder.class, dto.getTaKeStakeholder().getTaStakeholderId());

		keModel = repository.updateTaStakeholderAppFromAppDto(dto, keModel, cache, appModel, currentKeDetails);
		TaStakeholderApplication currentKeDetailsRef = keModel.getPreviousValue() == null ? new TaStakeholderApplication() : keModel.getPreviousValue();
		currentKeDetailsRef = appHelper.snapshotCurrentStakeholder(currentKeDetailsRef, currentKeDetails);
		repository.saveOrUpdate(currentKeDetailsRef);
		keModel.setPreviousValue(currentKeDetailsRef);

		repository.saveOrUpdate(keModel);

		List<Integer> toDeleteList = dto.getToDeleteFiles();
		if (toDeleteList != null && !toDeleteList.isEmpty()) {
			for (Integer id : toDeleteList) {
				if (id != null) {
					File attachemnt = new File();
					attachemnt = repository.get(File.class, id);
					if (attachemnt != null) {
						fileHelper.deleteFile(attachemnt);
					}
				}
			}
		}
		for (FileDto doc : dto.getFiles()) {
			if (doc.getPublicFileId() == null && !Strings.isNullOrEmpty(doc.getOriginalName())) {
				fileHelper.saveFile(appModel, doc);
			}
		}

	}

	/***** END *****/

	/*** RESGIN KE API *****/
	// Internet to create new or get existing update ke details application details
	@RequestMapping(value = "/resign/new", method = RequestMethod.GET)
	public TaLicenceKeDetailsDto getNewApplicationResign() {
		Licence licenceModel = new Licence();
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());
		licenceModel = currentUser.getTravelAgent().getLicence();

		TaLicenceKeDetailsDto resultDto = new TaLicenceKeDetailsDto();
		List<FileDto> fileList = new ArrayList<FileDto>();

		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(licenceModel)) {
			Application appModel = repository.getPendingApplicationFromLicenceId(licenceModel.getId(), Codes.ApplicationTypes.TA_APP_KE_RESIGN);

			if (appModel == null) {// Create new application
				Stakeholder stakeholderModel = new Stakeholder();
				stakeholderModel = travelAgentRepository.getExistingKe(licenceModel.getId());
				if (stakeholderModel == null) {
					resultDto.setHaveKe(Boolean.FALSE);
				} else {
					resultDto = TaLicenceKeDetailsDto.buildNewAppDtoFromCurrentStakeholderModel(cache, stakeholderModel, resultDto, Codes.ApplicationTypes.TA_APP_KE_RESIGN, Codes.Statuses.TA_APP_NEW);
				}

			} else { // get existing application
				TaStakeholderApplication keAppModel = new TaStakeholderApplication();
				keAppModel = repository.getKeAppFromAppId(appModel.getId());
				List<TaStakeholder> taStakeholders = new ArrayList<TaStakeholder>();
				taStakeholders = repository.getTaStakeholdersFromStakeholder(keAppModel.getTaStakeholder().getStakeholder().getId());
				TaStakeholder newTaKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
				resultDto = TaLicenceKeDetailsDto.buildAppDtoFromTaStakeholderAppModel(cache, appHelper, keAppModel, resultDto, taStakeholders, newTaKe);
				fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
			}
			List<FileDto> reqFileList = new ArrayList<FileDto>();
			reqFileList = repository.getSupportingDocList(keResigndocTypeList, fileHelper); /* to define which supporting Doc are required */
			resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
		}
		return resultDto;
	}

	// Internet to submit new resign ke application details
	@RequestMapping(path = { "/resign/save", "/resign/update", }, method = RequestMethod.POST)
	public void saveApplicationResign(@RequestBody TaLicenceKeDetailsDto dto) throws IOException {
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();

		if (dto.getApplicationId() != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
			}
		}

		Application appModel = new Application();
		TaStakeholderApplication keModel = new TaStakeholderApplication();

		if (dto != null) {
			if (dto.getApplicationId() != null) { // retreive existing application
				appModel = repository.get(Application.class, dto.getApplicationId());
				keModel = repository.get(TaStakeholderApplication.class, dto.getTaKeAppId());

			} else { // save new application
				appModel = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_KE_RESIGN, licenceModel.getId(), dto.isOfflineSubmission(), false);
			}
		}
		appHelper.forward(appModel, true);
		keModel.setType(cache.getType(Codes.ApplicationTypes.TA_APP_KE_RESIGN));

		if (dto.getTaKeStakeholder().getTaStakeholderId() != null) {
			TaStakeholder keDetails = new TaStakeholder();
			keDetails = repository.get(TaStakeholder.class, dto.getTaKeStakeholder().getTaStakeholderId());
			keModel.setApplication(appModel);
			keModel.setTaStakeholder(keDetails); // Save current KE into application
		}

		keModel.setResignedDate(dto.getTaKeStakeholder().getResignedDate() == null ? LocalDate.now() : dto.getTaKeStakeholder().getResignedDate());
		repository.saveOrUpdate(keModel);

		for (FileDto fileDto : dto.getFiles()) {
			if (fileDto.getPublicFileId() == null && !Strings.isNullOrEmpty(fileDto.getOriginalName())) {
				fileHelper.saveFile(appModel, fileDto);
			}
		}

		List<Integer> toDeleteList = dto.getToDeleteFiles();
		if (toDeleteList != null && !toDeleteList.isEmpty()) {
			for (Integer id : toDeleteList) {
				if (id != null) {
					File attachemnt = new File();
					attachemnt = fileHelper.getFile(id);
					if (attachemnt != null) {
						fileHelper.deleteFile(attachemnt);
					}
				}
			}
		}

	}

	// Internet: to retrieve application details
	@RequestMapping(value = { "/resign/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceKeDetailsDto getApplicationResign(@PathVariable Integer id) {
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());

		TaLicenceKeDetailsDto resultDto = new TaLicenceKeDetailsDto();
		List<FileDto> fileList = new ArrayList<FileDto>();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
			TaStakeholderApplication keAppModel = new TaStakeholderApplication();
			keAppModel = repository.getKeAppFromAppId(id);
			if (resultDto != null) {
				List<TaStakeholder> taStakeholders = new ArrayList<TaStakeholder>();
				taStakeholders = repository.getTaStakeholdersFromStakeholder(keAppModel.getTaStakeholder().getStakeholder().getId());
				TaStakeholder newTaKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
				resultDto = TaLicenceKeDetailsDto.buildAppDtoFromTaStakeholderAppModel(cache, appHelper, keAppModel, resultDto, taStakeholders, newTaKe);

				fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
				List<FileDto> reqFileList = new ArrayList<FileDto>();
				reqFileList = repository.getSupportingDocList(keResigndocTypeList, fileHelper); /* to define which supporting Doc are required */
				resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
			}
		}
		return resultDto;
	}

	/***** END *****/

	/*** ASSGIN KE API *****/
	// Internet to create new or get existing update ke details application details
	@RequestMapping(value = "/assign/new", method = RequestMethod.GET)
	public TaLicenceKeDetailsDto getNewApplicationAssign() {
		Licence licenceModel = new Licence();
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());
		licenceModel = currentUser.getTravelAgent().getLicence();
		TaLicenceKeDetailsDto resultDto = new TaLicenceKeDetailsDto();
		List<FileDto> fileList = new ArrayList<FileDto>();
		List<TaKeDeclarationsDto> declareDtos = new ArrayList<>();
		Stakeholder existingKeShModel = travelAgentRepository.getExistingKeNotResigned(licenceModel.getId());
		TaStakeholder keToBe = travelAgentRepository.getKeToBe(licenceModel.getId());
		List<FileDto> reqFileList = new ArrayList<FileDto>();
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(licenceModel)) {
			Application appModel = repository.getPendingApplicationsFromLicenceId(licenceModel.getId(), keAssignType, Boolean.TRUE);
			if (appModel == null) { // Create new application for submission
				if (existingKeShModel != null) { // Determine if this is Assign or Reassign application. If no stakeholder model then it is assign
					resultDto = TaLicenceKeDetailsDto.buildNewAppDtoFromCurrentStakeholderModel(cache, existingKeShModel, resultDto, Codes.ApplicationTypes.TA_APP_KE_REASSIGN,
							Codes.Statuses.TA_APP_NEW);
					reqFileList.addAll(repository.getSupportingDocList(keResigndocTypeList, fileHelper));
				} else {
					TaStakeholder lastResignedKe = travelAgentRepository.getTaLastResignedKe(licenceModel.getId());
					resultDto = TaLicenceKeDetailsDto.buildNewAppDtoFromCurrentStakeholderModel(cache, existingKeShModel, resultDto, Codes.ApplicationTypes.TA_APP_KE_ASSIGN,
							Codes.Statuses.TA_APP_NEW);
					resultDto.setHaveKe(Boolean.FALSE);
					resultDto.setTaKeStakeholder(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, lastResignedKe, false, false));
				}

				if (keToBe != null) {
					resultDto.setNewTaStakeholderDto(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, keToBe, false, false));
					resultDto.setNewStakeholderDto(StakeholderDto.buildFromStakeholder(cache, keToBe.getStakeholder(), new StakeholderDto()));
				}
			} else { // Retrieve existing application
				TaStakeholderApplication keAppModel = new TaStakeholderApplication();
				List<TaStakeholder> taStakeholders = new ArrayList<TaStakeholder>();
				keAppModel = repository.getKeAppFromAppId(appModel.getId());

				// Get current KE details
				if (appModel.getType().getCode().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_KE_REASSIGN)) {
					taStakeholders = repository.getTaStakeholdersFromStakeholder(keAppModel.getTaStakeholder().getStakeholder().getId());
					reqFileList.addAll(repository.getSupportingDocList(keResigndocTypeList, fileHelper));
				} else {
					TaStakeholder lastResignedKe = travelAgentRepository.getTaLastResignedKe(licenceModel.getId());
					resultDto.setTaKeStakeholder(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, lastResignedKe, false, false));
				}

				// Get new KE details
				TaStakeholder newTaKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
				// Set current & new KE into DTO
				resultDto = TaLicenceKeDetailsDto.buildAppDtoFromTaStakeholderAppModel(cache, appHelper, keAppModel, resultDto, taStakeholders, newTaKe);
				resultDto = repository.compareUserUinAndKeUin(resultDto, currentUser.getLoginId(), keAppModel.getUin());
				resultDto.setIsMyInfoPopulated(Boolean.FALSE);
				fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
				if (resultDto.getTaKeDeclarations().isEmpty()) { // If existing application do no have declaration, it will show pending declaration
					if (!appModel.isDraft() && !(Codes.Statuses.TA_APP_NEW.equalsIgnoreCase(appModel.getLastAction().getStatus().getCode())
							|| Codes.Statuses.TA_APP_RFA.equalsIgnoreCase(appModel.getLastAction().getStatus().getCode()))) {
						resultDto.setNeedCompleteDeclaration(Boolean.TRUE);
					}
				}

			}

			if (resultDto.getTaKeDeclarations() == null || resultDto.getTaKeDeclarations().isEmpty()) {
				/* Set decalrations required for application */
				for (TaKeClause clause : cache.getTaKeClauses()) {
					declareDtos.add(TaKeDeclarationsDto.buildClauseOnly(cache, clause));
				}
				resultDto.setTaKeDeclarations(declareDtos);
			}

			reqFileList.addAll(repository.getSupportingDocList(keAssigndocTypeList, fileHelper)); /* to define which supporting Doc are required */
			resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));

			Collections.sort(resultDto.getFiles(), Comparator.comparing(FileDto::getDocumentTypeLabel));
		}
		return resultDto;
	}

	@RequestMapping(path = { "/assign/save", "/assign/update", }, method = RequestMethod.POST)
	public void saveApplicationAssign(@RequestBody TaLicenceKeDetailsDto dto) throws IOException {
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();

		if (dto.getApplicationId() != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
			}
		}

		TaStakeholderApplication stakeholderAppModel = new TaStakeholderApplication();

		if (dto != null) {
			Application appModel;
			if (dto.getApplicationId() != null) { // Update existing
				appModel = repository.get(Application.class, dto.getApplicationId());
				stakeholderAppModel = repository.get(TaStakeholderApplication.class, dto.getTaKeAppId());

				if (!stakeholderAppModel.getTaKeDeclarations().isEmpty() && (!stakeholderAppModel.getUin().equalsIgnoreCase(dto.getNewStakeholderDto().getUin())) && dto.getApplicantIsKe() != null
						&& !dto.getApplicantIsKe()) {
					for (TaKeDeclaration x : stakeholderAppModel.getTaKeDeclarations()) {
						repository.delete(x);
					}
				}

			} else { // save new
				appModel = appHelper.saveNewApplication(dto.getKeAppType(), licenceModel.getId(), dto.isOfflineSubmission(), false);
			}

			if (dto.getNeedCompleteDeclaration() != null && dto.getNeedCompleteDeclaration() && dto.getApplicationId() != null) {
				appHelper.resubmit(appModel, true);
			} else {
				appHelper.forward(appModel, true);
			}
			repository.saveOrUpdate(appModel);
			ceTaskHelper.completeCeTaskByLicence(licenceModel.getId(), Codes.CeTaskTypes.CE_TASK_TAR_R15_3B, Codes.CeTaskStatus.CE_TASK_FOR_INFO);

			TaStakeholder keDetails = new TaStakeholder();
			if (dto.getNeedCompleteDeclaration() == null || !dto.getNeedCompleteDeclaration()) {
				if (dto.getHaveKe() && Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(dto.getKeAppType())) {
					keDetails = repository.get(TaStakeholder.class, dto.getTaKeStakeholder().getTaStakeholderId());
				}
				stakeholderAppModel = repository.updateTaStakeholderAppFromAppDto(dto, stakeholderAppModel, cache, appModel, keDetails);
				repository.saveOrUpdate(stakeholderAppModel);
			}

			for (FileDto fileDto : dto.getFiles()) {
				if (fileDto.getPublicFileId() == null && !Strings.isNullOrEmpty(fileDto.getOriginalName())) {
					fileHelper.saveFile(appModel, fileDto);
				}
			}

			List<Integer> toDeleteList = dto.getToDeleteFiles();
			if (toDeleteList != null && !toDeleteList.isEmpty()) {
				for (Integer id : toDeleteList) {
					if (id != null) {
						File attachemnt = new File();
						attachemnt = fileHelper.getFile(id);
						if (attachemnt != null) {
							fileHelper.deleteFile(attachemnt);
						}
					}
				}
			}

			List<TaKeDeclaration> declarations = new ArrayList<>();
			if (dto.getApplicantIsKe() != null && dto.getApplicantIsKe()) {
				for (TaKeDeclarationsDto declarationDto : dto.getTaKeDeclarations()) {
					TaKeDeclaration declaration = new TaKeDeclaration();
					if (declarationDto.getId() == null) {
						declaration = new TaKeDeclaration();
						declaration.setOptionSelected(declarationDto.getSelectedOption());
						if (declarationDto.getSelectedOption().equalsIgnoreCase(declarationDto.getOptionsToPrompt())) {
							declaration.setRemarks(declarationDto.getRemarks());
						} else {
							declaration.setRemarks(null);
						}
						declaration.setTaKeClause(cache.getTaKeClause(Integer.parseInt(declarationDto.getClause().getKey().toString())));
						declaration.setTaKeyExecutiveApplication(stakeholderAppModel);
						declarations.add(declaration);
					} else {
						declaration = repository.get(TaKeDeclaration.class, declarationDto.getId());
						declaration.setOptionSelected(declarationDto.getSelectedOption());
						if (declarationDto.getSelectedOption().equalsIgnoreCase(declarationDto.getOptionsToPrompt())) {
							declaration.setRemarks(declarationDto.getRemarks());
						} else {
							declaration.setRemarks(null);
						}
					}
					repository.saveOrUpdate(declaration);
				}
			} else {
				if (stakeholderAppModel.getTaKeDeclarations().isEmpty() && !dto.isDraft()) {
					String url = String.format(properties.applicationUrl, "ta-manage-ke-assign/" + appModel.getId());
					emailHelper.emailNewKeForDeclaration(stakeholderAppModel, Codes.EmailType.TA_KE_DECLARATION, url, stakeholderAppModel.getEmail());
				}
			}
		}

	}

	// Internet to retrieve application details
	@RequestMapping(value = { "/assign/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceKeDetailsDto getApplicationAssign(@PathVariable Integer id) {
		User currentUser = repository.getLicenseeUserByUserId(getUser().getId());

		TaLicenceKeDetailsDto resultDto = new TaLicenceKeDetailsDto();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
			TaStakeholderApplication keAppModel = new TaStakeholderApplication();
			List<FileDto> fileList = new ArrayList<FileDto>();
			keAppModel = repository.getKeAppFromAppId(id);
			List<FileDto> reqFileList = new ArrayList<FileDto>();
			if (resultDto != null) {
				List<TaStakeholder> taStakeholders = new ArrayList<TaStakeholder>();
				if (Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(keAppModel.getApplication().getType().getCode())) {
					taStakeholders = repository.getTaStakeholdersFromStakeholder(keAppModel.getTaStakeholder().getStakeholder().getId());
					reqFileList.addAll(repository.getSupportingDocList(keResigndocTypeList, fileHelper));
				} else {
					TaStakeholder lastResignedKe = travelAgentRepository.getTaLastResignedKe(keAppModel.getApplication().getLicence().getId());
					resultDto.setTaKeStakeholder(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, lastResignedKe, false, false));
				}
				TaStakeholder newTaKe = repository.getTaStakeholderFromUin(keAppModel.getUin(), keAppModel.getName());
				resultDto = TaLicenceKeDetailsDto.buildAppDtoFromTaStakeholderAppModel(cache, appHelper, keAppModel, resultDto, taStakeholders, newTaKe);

				fileList = repository.getFiles(resultDto.getApplicationId(), fileHelper);
				reqFileList.addAll(repository.getSupportingDocList(keAssigndocTypeList, fileHelper)); /* to define which supporting Doc are required */
				resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
				Collections.sort(resultDto.getFiles(), Comparator.comparing(FileDto::getDocumentTypeLabel));
				resultDto = repository.compareUserUinAndKeUin(resultDto, currentUser.getLoginId(), keAppModel.getUin());

				List<TaKeDeclarationsDto> declareDtos = new ArrayList<>();
				if (resultDto.getTaKeDeclarations().isEmpty()) {
					if (!(Codes.Statuses.TA_APP_NEW.equalsIgnoreCase(keAppModel.getApplication().getLastAction().getStatus().getCode())
							|| Codes.Statuses.TA_APP_RFA.equalsIgnoreCase(keAppModel.getApplication().getLastAction().getStatus().getCode()))) {
						resultDto.setNeedCompleteDeclaration(Boolean.TRUE);
					}
					/* Set decalrations required for application */
					for (TaKeClause clause : cache.getTaKeClauses()) {
						declareDtos.add(TaKeDeclarationsDto.buildClauseOnly(cache, clause));
					}
					resultDto.setTaKeDeclarations(declareDtos);
				}
			}
		}

		return resultDto;
	}

	/***** END *****/

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = repository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

}
