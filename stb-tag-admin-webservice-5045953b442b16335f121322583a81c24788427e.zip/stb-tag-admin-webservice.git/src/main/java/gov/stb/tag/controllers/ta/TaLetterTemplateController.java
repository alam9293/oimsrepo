package gov.stb.tag.controllers.ta;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.lettertemplate.TaLetterTemplateItemDto;
import gov.stb.tag.dto.ta.stakeholder.*;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.model.*;
import gov.stb.tag.repository.ta.TaLetterTemplateRepository;
import gov.stb.tag.repository.ta.TaStakeholderRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(path = "/api/v1/ta/letter-template")
@Transactional
public class TaLetterTemplateController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaLetterTemplateRepository taLetterTemplateRepository;

	@RequestMapping(path = "/view/templates", method = RequestMethod.GET)
	public List<ListableDto> getLetterTemplates() throws IOException {
		List<LetterTemplate> letterTemplates = taLetterTemplateRepository.getLetterTemplates();
		List<ListableDto> results = new ArrayList<>();
		for (LetterTemplate letterTemplate : letterTemplates) {
			results.add(new ListableDto(letterTemplate.getCode(), letterTemplate.getName()));
		}
		return results;
	}

	@RequestMapping(path = "/view/{code}", method = RequestMethod.GET)
	public TaLetterTemplateItemDto getTemplateDetail(@PathVariable String code) {
		LetterTemplate template = taLetterTemplateRepository.getLetterTemplateDetail(code);
		return TaLetterTemplateItemDto.build(template);
	}

	@RequestMapping(path = "/save", method = RequestMethod.POST)
	public void saveLetterTemplate(@RequestBody TaLetterTemplateItemDto dto) {
		LetterTemplate template = taLetterTemplateRepository.getLetterTemplateDetail(dto.getCode());
		if (template == null) {
			logger.error("Letter template for code={} not found.", dto.getCode());
			throw new ValidationException("Letter template for code=" + dto.getCode() + " not found.");
		}
		template.setContent(dto.getContent());
		taLetterTemplateRepository.update(template);
	}
}
