package gov.stb.tag.controllers.ta;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import gov.stb.tag.dto.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ta.licencecessation.TaLicenceCessationDto;
import gov.stb.tag.dto.ta.licencecessation.TaLicenceCessationItemDto;
import gov.stb.tag.dto.ta.licencecessation.TaLicenceCessationSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.LicenceReturnHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.LicenceReturnBatch;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaLicenceCessation;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.LicenceReturnRepository;
import gov.stb.tag.repository.ta.TaLicenceCessationRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/cessations")
@Transactional
public class TaLicenceCessationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaLicenceCessationRepository taLicenceCessationRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	CommonRepository commonRepository;
	@Autowired
	LicenceReturnRepository licenceReturnRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	LicenceReturnHelper licenceReturnHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;

	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaLicenceCessationDto loadNew() {
		User currentUser = taLicenceCessationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			TaLicenceCessationDto dto = new TaLicenceCessationDto();
			Licence licence = currentUser.getTravelAgent().getLicence();
			if (licence.isPendingCessation()) {
				dto.setIsPendingCessation(true);
				return dto;
			} else {
				TaLicenceCessation cessation = taLicenceCessationRepository.getPendingApplication(licence.getId());
				if (cessation == null) {
					dto = TaLicenceCessationDto.buildFromNew(cache, licence, fileHelper);
					return dto;
				} else {
					dto = TaLicenceCessationDto.buildFromApplication(cache, appHelper, cessation, null, fileHelper);
					return dto;
				}
			}
		}

		return null;
	}

	@RequestMapping(path = { "/save", "offline/save" }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaLicenceCessationDto dto) {

		User currentUser = taLicenceCessationRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = null;
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			licence = currentUser.getTravelAgent().getLicence();
		} else {
			licence = taLicenceCessationRepository.get(Licence.class, dto.getLicenceId());
		}

		if (licence != null) {
			// 1. Create application and workflow action
			Application app = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_CESSATION, licence.getId(), dto.isOfflineSubmission(), false);
			appHelper.forward(app, true);

			// 2. Save files uploaded by user
			saveFile(dto, app);

			// 3. Save fields in form
			TaLicenceCessation cessation = new TaLicenceCessation();
			cessation.setApplication(app);
			cessation.setReason(cache.getType(dto.getReason().getKey().toString()));
			if (dto.getReason().getKey().equals(Codes.Types.TA_REASON_CEASE_OTHERS)) {
				cessation.setOtherReason(dto.getOtherReason());
			}
			cessation.setEffectiveDate(dto.getCessationDate() != null ? dto.getCessationDate() : LocalDate.now());

			taLicenceCessationRepository.save(cessation);

			// 4. Create Licence Return record
			LocalDate dueDate = cessation.getEffectiveDate().plusDays(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.LCRTN_DAYS_DUE_TA_CEASE).getValue()));
			licenceReturnHelper.createBatchRecord(cessation.getApplication().getLicence(), cessation.getApplication().getLicence(),
					travelAgentRepository.getBranchesByLicenceId(cessation.getApplication().getLicence().getId()), app.getType(), dueDate, cessation.getApplication());
		}

	}

	@RequestMapping(path = { "/update" }, method = RequestMethod.POST)
	public void updateApplication(@RequestPart(name = "application") TaLicenceCessationDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {

		// 1. Save application actions
		Application app = taLicenceCessationRepository.get(Application.class, dto.getApplicationId());
		appHelper.forward(app, true);

		// 2. Delete files deleted by user
		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}

		}

		// 3. Save additional files uploaded by user
		saveFile(dto, app);

		// 4. Save changes made by user
		TaLicenceCessation cessation = taLicenceCessationRepository.getApplication(app.getId());
		cessation.setReason(cache.getType(dto.getReason().getKey().toString()));
		if (dto.getReason().getKey().equals(Codes.Types.TA_REASON_CEASE_OTHERS)) {
			cessation.setOtherReason(dto.getOtherReason());
		}
		cessation.setEffectiveDate(dto.getCessationDate() != null ? dto.getCessationDate() : LocalDate.now());
		taLicenceCessationRepository.save(cessation);

		// 4. Update Licence Return batch due date
		LocalDate dueDate = cessation.getEffectiveDate().plusDays(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.LCRTN_DAYS_DUE_TA_CEASE).getValue()));
		LicenceReturnBatch batch = licenceReturnRepository.getBatchRecordByApp(cessation.getApplication().getId());
		if (batch != null) {
			batch.setDueDate(dueDate);
			taLicenceCessationRepository.save(batch);
		}
	}

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TaLicenceCessationItemDto> getList(TaLicenceCessationSearchDto searchDto) {

		return taLicenceCessationRepository.getPendingList(searchDto, getUser().getId());

	}

	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceCessationDto getApplication(@PathVariable Integer id) {
		User currentUser = taLicenceCessationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			appHelper.isAppBelongToTA(id, currentUser);
		}
		TaLicenceCessation tlc = taLicenceCessationRepository.getApplication(id);
		LicenceReturnBatch lrb = licenceReturnRepository.getBatchRecordByApp(id);
		TaLicenceCessationDto result = TaLicenceCessationDto.buildFromApplication(cache, appHelper, tlc, lrb, fileHelper);
		return result;
	}

	@RequestMapping(value = "/{action}/{id}/{licenceReturned}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id, @PathVariable Boolean licenceReturned) {

		// 1. Update Application Status
		TaLicenceCessation tlc = taLicenceCessationRepository.getApplication(id);
		Application app = tlc.getApplication();

		String url = String.format(properties.applicationUrl, "ta-cease-licence/" + app.getId());
		String alertMsg = null;
		String emailType = null;
		String statusCode = null;

		// 2. Update Licence Status / Schedule for Batch Job + Cascade cessation status to Branches
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(app)) {
				emailType = Codes.EmailType.TA_UPON_APPROVAL;
				alertMsg = Messages.Alerts.APP_APPROVE;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				if (tlc.getEffectiveDate().isAfter(LocalDate.now())) {
					tlc.getApplication().getLicence().setIsPendingCessation(true);
					tlc.setPendingBatchJob(true);
					taLicenceCessationRepository.save(tlc.getApplication().getLicence());
					taLicenceCessationRepository.save(tlc);
				} else {
					// update licence's status
					licenceHelper.updateLicenceStatus(tlc.getApplication().getLicence(), Codes.Statuses.TA_CEASED, null, tlc.getEffectiveDate().atStartOfDay());
					tlc.getApplication().getLicence().setCeasedDate(tlc.getEffectiveDate());
					tlc.setPendingBatchJob(false);
					taLicenceCessationRepository.update(tlc.getApplication().getLicence());
					taLicenceCessationRepository.save(tlc);

					// update branch's status
					List<TaBranch> branches = travelAgentRepository.getBranchesByLicenceId(tlc.getApplication().getLicence().getId());
					for (TaBranch branch : branches) {
						if (!branch.getStatus().getCode().equals(Codes.Statuses.TA_BRANCH_CEASED)) {
							branch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_M_CEASED));
							branch.setCeasedDate(LocalDate.now());
							taLicenceCessationRepository.save(branch);
						}
					}
				}

				Long daysDiff = ChronoUnit.DAYS.between(tlc.getEffectiveDate(), tlc.getApplication().getSubmissionDate());
				logger.info("Diffence in days: {}", daysDiff);
				Integer daysToInformBusinessCeased = cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_DAYS_TO_INFORM_DUE_TA_CEASE);
				if (daysDiff > daysToInformBusinessCeased) {
					logger.info("Licence cessation submission is more than > {} days. Creating case...");
					ceCaseHelper.createCaseForCeasedLicence(tlc, tlc.getEffectiveDate().plusDays(daysToInformBusinessCeased).plusDays(1));
				}
			}
			break;

		case ACTION_REJECT:
			emailType = Codes.EmailType.TA_UPON_REJECTION;
			alertMsg = Messages.Alerts.APP_REJECT;
			statusCode = Codes.Statuses.TA_APP_REJECTED;

			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			LicenceReturnBatch lrb = licenceReturnRepository.getBatchRecordByApp(app.getId());
			licenceReturnHelper.voidBatchRecord(lrb.getId());
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				emailType = Codes.EmailType.TA_UPON_RFA;
				alertMsg = Messages.Alerts.APP_RFA;
			}

			appHelper.rfa(app, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (alertMsg != null) {
			// 3. Generate alert to notify TA
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				alertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}
			alertHelper.createAlert(app.getLicence().getTravelAgent(), app, alertMsg, Codes.Modules.MOD_TA, app.getType(), "../ta-cease-licence/" + app.getId(), cache.getStatus(statusCode));

			// 4. Update return licence records
			if (licenceReturned) {
				LicenceReturnBatch lrb = licenceReturnRepository.getBatchRecordByApp(app.getId());
				licenceReturnHelper.markAsReturned(Arrays.asList(lrb.getLicences().stream().filter(o -> o.getBranch() == null).findFirst().get().getId()), lrb.getId());
			}

			// 5. Send email to notify TA
			emailHelper.emailTaUponAction(app, emailType, url);
		}

	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taLicenceCessationRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	// to load active travel agents for offline submission
	@RequestMapping(value = "/offline/new/travel-agents", method = RequestMethod.GET)
	public List<TravelAgentBasicDto> getTravelAgents() {
		return travelAgentRepository.getActiveTravelAgentsBasic();
	}

	// to load licence cessation pending submission by travel agent's licence id
	@RequestMapping(value = "/offline/new/travel-agents/{licenceId}", method = RequestMethod.GET)
	public TaLicenceCessationDto getTaLicenceCessation(@PathVariable Integer licenceId) {

		TaLicenceCessationDto resultDto = new TaLicenceCessationDto();

		// Check if TA has application pending approval or draft
		Application pendingApp = taLicenceCessationRepository.getPendingApplicationFromLicenceId(licenceId, Codes.ApplicationTypes.TA_APP_CESSATION);
		Licence licence = taLicenceCessationRepository.get(Licence.class, licenceId);

		if (licence.isPendingCessation()) {
			resultDto.setIsPendingCessation(true);
		} else {
			if (pendingApp == null) {
				resultDto = TaLicenceCessationDto.buildFromNew(cache, licence, fileHelper);
				resultDto.setApplicationStatus(
						new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));
				resultDto.buildFromLicence(cache, licence, resultDto);
			} else {
				TaLicenceCessation cessation = taLicenceCessationRepository.getApplication(pendingApp.getId());
				resultDto = TaLicenceCessationDto.buildFromApplication(cache, appHelper, cessation, null, fileHelper);
				resultDto.setHasSubmittedCessation(Boolean.TRUE);
			}
			resultDto.setIsPendingCessation(false);
		}

		resultDto.setOfflineSubmission(Boolean.TRUE);
		return resultDto;
	}

	private void saveFile(TaLicenceCessationDto dto, Application app) {
		if (dto.isOfflineSubmission()) {
			File fileModel = taLicenceCessationRepository.get(File.class, dto.getDirectorResolution().getId());
			if (fileModel != null) {
				fileHelper.saveApplicationFile(app, fileModel, dto.getDirectorResolution());
			}
		} else if (dto.getDirectorResolution().getPublicFileId() == null) {
			fileHelper.saveFile(app, dto.getDirectorResolution());
		}

		for (FileDto doc : dto.getOtherDocuments()) {
			if (dto.isOfflineSubmission()) {
				File fileModel = taLicenceCessationRepository.get(File.class, doc.getId());
				if (fileModel != null) {
					fileHelper.saveApplicationFile(app, fileModel, doc);
				}
			} else if (doc.getPublicFileId() == null) {
				fileHelper.saveFile(app, doc);
			}
		}
	}

}
