package gov.stb.tag.controllers.ta;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.LicenceStatusSpanDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.TravelAgentBasicDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.ce.cases.CeInfringementDto;
import gov.stb.tag.dto.ce.cases.CeRecommendationDto;
import gov.stb.tag.dto.ce.directory.CeInfringementForPublicDto;
import gov.stb.tag.dto.ta.abpr.TaAbprDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingSearchDto;
import gov.stb.tag.dto.ta.licence.TaCpfArrearDto;
import gov.stb.tag.dto.ta.licence.TaLicenceDetailsDto;
import gov.stb.tag.dto.ta.licence.TaLicenceDto;
import gov.stb.tag.dto.ta.licence.TaLicenceFinancialDto;
import gov.stb.tag.dto.ta.licence.TaLicenceFinancialMaDto;
import gov.stb.tag.dto.ta.licence.TaLicenceItemDto;
import gov.stb.tag.dto.ta.licence.TaLicencePastDto;
import gov.stb.tag.dto.ta.licence.TaLicencePersonnelItemDto;
import gov.stb.tag.dto.ta.licence.TaLicencePersonnelSearchDto;
import gov.stb.tag.dto.ta.licence.TaLicenceSearchDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderRecordsDto;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.LicenceReturnHelper;
import gov.stb.tag.helper.MessageHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.LicenceReturnBatch;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceCessation;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.CommonRepository;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.ce.CeCaseRecommendationRepository;
import gov.stb.tag.repository.ce.CeDirectoryRepository;
import gov.stb.tag.repository.ta.TaLicenceCessationRepository;
import gov.stb.tag.repository.ta.TaLicenceRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/licences/")
@Transactional
public class TaLicenceController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaLicenceRepository taLicenceRepository;
	@Autowired
	TaLicenceCessationRepository taLicenceCessationRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	CommonRepository commonRepository;
	@Autowired
	CeDirectoryRepository ceDirectoryRepository;
	@Autowired
	PaymentRepository paymentRepository;
	@Autowired
	CeCaseRecommendationRepository ceCaseRecommendationRepository;

	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	MessageHelper messageHelper;
	@Autowired
	LicenceReturnHelper licenceReturnHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	WorkflowHelper workflowHelper;

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TaLicenceItemDto> getList(TaLicenceSearchDto searchDto) {

		return taLicenceRepository.getTaLicences(searchDto);

	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TaLicenceDto getLicenceSummary(@PathVariable Integer id) {
		Licence licence = taLicenceRepository.getLicence(id, false, false);
		TaLicenceDto result = new TaLicenceDto();
		result = result.buildFromLicence(cache, licence, result);
		return result;
	}

	@RequestMapping(value = "/view/details/{id}", method = RequestMethod.GET)
	public TaLicenceDetailsDto getLicenceDetails(@PathVariable Integer id) {
		Licence licence = taLicenceRepository.getLicence(id, false, true);
		TaLicenceDetailsDto result = TaLicenceDetailsDto.build(cache, licence, travelAgentRepository.getBranchesByLicenceId(id));
		return result;
	}

	@RequestMapping(value = "/abpr/view/fys/{id}", method = RequestMethod.GET)
	public List<ListableDto> getLicenceAbprFys(@PathVariable Integer id) {
		List<TaFilingCondition> abprs = taLicenceRepository.getAbprFys(id);
		List<ListableDto> results = new ArrayList<>();
		for (TaFilingCondition filing : abprs) {
			results.add(new ListableDto(filing.getId(), DateUtil.format(filing.getFyStartDate()), DateUtil.format(filing.getFyEndDate())));
		}

		return results;
	}

	@RequestMapping(value = "/abpr/view/{id}", method = RequestMethod.GET)
	public TaAbprDto getLicenceAbpr(@PathVariable Integer id) {
		TaAbprSubmission abpr = taLicenceRepository.getAbpr(id);
		if (abpr != null) {
			TaAbprDto result = TaAbprDto.build(cache, abpr);
			return result;
		}
		return null;
	}

	@RequestMapping(value = "/financial/view/aa/{id}", method = RequestMethod.GET)
	public List<TaLicenceFinancialDto> getLicenceFinancial(@PathVariable Integer id) {
		List<TaAaSubmission> aas = taLicenceRepository.getFinancialAa(id);
		List<TaLicenceFinancialDto> result = new ArrayList<>();
		for (TaAaSubmission aa : aas) {
			result.add(TaLicenceFinancialDto.build(cache, aa));
		}
		return result;
	}

	@RequestMapping(value = "/financial/view/ma/{id}", method = RequestMethod.GET)
	public List<TaLicenceFinancialMaDto> getLicenceMaDetails(@PathVariable Integer id) {
		List<TaMaSubmission> mas = taLicenceRepository.getFinancialMa(id);
		List<TaLicenceFinancialMaDto> result = new ArrayList<>();
		for (TaMaSubmission ma : mas) {
			result.add(TaLicenceFinancialMaDto.build(cache, ma));
		}
		return result;
	}

	@RequestMapping(value = "/personnels/view/{id}", method = RequestMethod.GET)
	public ResultDto<TaLicencePersonnelItemDto> getLicencePersonnels(@PathVariable Integer id, TaLicencePersonnelSearchDto searchDto) {

		return taLicenceRepository.getPersonnels(searchDto, id);

	}

	@RequestMapping(value = "/personnels/view/personnel/{id}", method = RequestMethod.GET)
	public StakeholderRecordsDto getLicencePersonnel(@PathVariable Integer id) {
		TaStakeholder tsh = taLicenceRepository.getPersonnel(id);
		StakeholderRecordsDto result = StakeholderRecordsDto.build(cache, new ArrayList<>(Arrays.asList(tsh)), tsh.getStakeholder(), false, false);
		return result;

	}

	@RequestMapping(value = "/personnels/view/ke/{id}", method = RequestMethod.GET)
	public StakeholderRecordsDto getLicenceKe(@PathVariable Integer id) {

		TaStakeholder tsh = travelAgentRepository.getExistingKeTaStakeholder(id);
		if (tsh != null) {
			StakeholderRecordsDto result = StakeholderRecordsDto.build(cache, new ArrayList<>(Arrays.asList(tsh)), tsh.getStakeholder(), true, false);
			return result;
		}
		return null;
	}

	@RequestMapping(value = "/past-history/view/{id}", method = RequestMethod.GET)
	public TaLicencePastDto getLicencePast(@PathVariable Integer id) {
		TaLicencePastDto result = TaLicencePastDto.build(cache, taLicenceRepository.getLicence(id, true, false));
		return result;
	}

	@RequestMapping(value = "/past-history/view/status-span/{id}", method = RequestMethod.GET)
	public List<LicenceStatusSpanDto> getLicenceStatusSpan(@PathVariable Integer id) {
		List<LicenceStatusSpanDto> resultList = new ArrayList<>();
		taLicenceRepository.getStatusSpan(id).stream().forEach(ss -> {
			resultList.add(LicenceStatusSpanDto.buildFromStatusSpan(cache, ss));
		});
		return resultList;
	}

	@RequestMapping(value = "/past-infringements/view/{id}", method = RequestMethod.GET)
	public List<CeInfringementDto> getInfringement(@PathVariable Integer id) {
		Licence licence = taLicenceRepository.getLicence(id, false, false);
		List<CeCaseInfringement> infringements = travelAgentRepository.getTaInfringements(licence.getTravelAgent().getUen());
		List<CeInfringementDto> result = Lists.newArrayList();
		infringements.forEach(infringement -> {
			CeInfringementDto infringementDto = new CeInfringementDto(infringement.getCeCaseInfringer(), infringement, cache, true, ceCaseHelper);
			if (infringement.getLastRecommendation() != null) {
				CeCaseRecommendation recomm = ceCaseRecommendationRepository.getRecommendationById(infringement.getLastRecommendation().getId());
				infringementDto.setRecommendation(new CeRecommendationDto(recomm, cache, fileHelper, workflowHelper, null, false));
			}
			result.add(infringementDto);
		});
		return result;
	}

	@RequestMapping(value = "/cpf-arrears/view/{id}", method = RequestMethod.GET)
	public ResultDto<TaCpfArrearDto> getTaCpfArrears(@PathVariable Integer id, TaLicenceSearchDto searchDto) {
		Licence licence = taLicenceRepository.getLicence(id, false, false);
		searchDto.setUen(licence.getTravelAgent().getUen());
		return taLicenceRepository.getTaCpfArrears(searchDto);
	}

	/**
	 * to retrieve list of infringement by login user
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/past-infringements/view", method = RequestMethod.GET)
	public List<CeInfringementForPublicDto> getInfringementByCurrentTa(@PathVariable Integer id) {
		User currentUser = commonRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			Licence licence = currentUser.getTravelAgent().getLicence();
			List<CeInfringementForPublicDto> result = ceDirectoryRepository.getPast5YearsInfringements(licence.getTravelAgent().getUen());
			result.forEach(dto -> {
				if (!Strings.isNullOrEmpty(dto.getBillRefNo())) {
					PaymentRequest payReq = paymentRepository.getPaymentRequest(dto.getBillRefNo());
					dto.setPaymentRequestStatus(new ListableDto(payReq.getStatus(), true));
				}
			});
			return result;
		}
		return null;
	}

	@RequestMapping(value = "/update-status/{id}/{licenceReturned}", method = RequestMethod.POST)
	public void updateStatus(@RequestBody WorkflowActionDto dto, @PathVariable Integer id, @PathVariable Boolean licenceReturned) {

		// 1. Update Licence status
		Licence licence = taLicenceRepository.get(Licence.class, id);
		StatusSpan statusSpan = licenceHelper.updateLicenceStatus(licence, dto.getAction(), null, dto.getInternalRemarks(), dto.getExternalRemarks(), null);
		licence.setIsPendingCessation(false);
		List<TaLicenceCessation> tlcs = taLicenceCessationRepository.getPendingCessation(licence.getId());
		for (TaLicenceCessation tlc : tlcs) {
			tlc.setPendingBatchJob(false);
			taLicenceRepository.save(tlc);
		}
		if (dto.getAction().equals(Codes.Statuses.TA_CEASED) || dto.getAction().equals(Codes.Statuses.TA_REVOKED)) {
			licence.setCeasedDate(LocalDate.now());
		} else {
			licence.setCeasedDate(null);
		}
		taLicenceRepository.save(licence);

		// 2. Create Licence Return record
		if (dto.getAction().equals(Codes.Statuses.TA_REVOKED) || dto.getAction().equals(Codes.Statuses.TA_CEASED)) {
			LicenceReturnBatch lrb = licenceReturnHelper.createBatchRecord(licence, licence, travelAgentRepository.getBranchesByLicenceId(licence.getId()),
					(dto.getAction().equals(Codes.Statuses.TA_CEASED) ? cache.getType(Codes.Types.TA_LRTN_CEASED) : cache.getType(Codes.Types.TA_LRTN_REVOKED)),
					LocalDate.now().plusDays(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.LCRTN_DAYS_DUE_TA_CEASE).getValue())), null);
			if (licenceReturned) {
				licenceReturnHelper.markAsReturned(Arrays.asList(lrb.getLicences().stream().filter(o -> o.getBranch() == null).findFirst().get().getId()), lrb.getId());
			}
		}

		// 3. Cascade status update to branch

		Status branchStatus = new Status();
		if (dto.getAction().equals(Codes.Statuses.TA_ACTIVE)) {
			branchStatus = cache.getStatus(Codes.Statuses.TA_BRANCH_ACTIVE);
		} else if (dto.getAction().equals(Codes.Statuses.TA_CEASED)) {
			branchStatus = cache.getStatus(Codes.Statuses.TA_BRANCH_M_CEASED);
		} else if (dto.getAction().equals(Codes.Statuses.TA_REVOKED)) {
			branchStatus = cache.getStatus(Codes.Statuses.TA_BRANCH_M_REVOKED);
		} else if (dto.getAction().equals(Codes.Statuses.TA_SUSPENDED)) {
			branchStatus = cache.getStatus(Codes.Statuses.TA_BRANCH_M_SUSPEND);
		}

		if (branchStatus != null) {
			List<TaBranch> branches = travelAgentRepository.getBranchesByLicenceId(licence.getId());
			for (TaBranch branch : branches) {
				if (!branch.getStatus().getCode().equals(Codes.Statuses.TA_BRANCH_CEASED)) {
					branch.setStatus(branchStatus);
					if (dto.getAction().equals(Codes.Statuses.TA_ACTIVE)) {
						branch.setCeasedDate(null);
					} else {
						branch.setCeasedDate(LocalDate.now());
					}

					taLicenceRepository.save(branch);
				}
			}
		}

		// 4. Generate alert to notify TA
		alertHelper.createAlert(licence.getTravelAgent(), null,
				dto.getExternalRemarks() != null ? dto.getExternalRemarks() : messageHelper.formatTaLicenceStatusUpdatePlaceholders(Messages.Alerts.TA_LICENCE_STATUS_UPDATE, statusSpan),
				Codes.Modules.MOD_TA, null, null, cache.getStatus(dto.getAction()));

		// 5. Send email to notify TA
		emailHelper.emailUponTaLicenceStatusUpdate(licence, statusSpan, Codes.EmailType.TA_LICENCE_STATUS_UPDATE, dto.getAction(), licence.getTravelAgent().getEmailAddress());
	}

	// to load all travel agents
	@RequestMapping(value = "/travel-agents", method = RequestMethod.GET)
	public List<TravelAgentBasicDto> getTravelAgents() {
		return travelAgentRepository.getActiveTravelAgentsBasic();
	}

	// to load all filing conditions
	@RequestMapping(method = RequestMethod.GET, value = "/filing-conditions/view")
	public ResultDto<TaAnnualFilingDto> getLicenceFilingConditions(TaLicenceFilingSearchDto searchDto) {
		ResultDto<TaAnnualFilingDto> resultDto = taLicenceRepository.getAllTaFilingConditions(searchDto);
		return resultDto;
	}

}
