package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.cases.CeInfringementDto;
import gov.stb.tag.dto.ce.cases.CeRecommendationDto;
import gov.stb.tag.dto.myinfo.MyInfoPersonBasicDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.abpr.TaAreaOfFocusDto;
import gov.stb.tag.dto.ta.abpr.TaBusinessOperationDto;
import gov.stb.tag.dto.ta.abpr.TaMarketSpecializationDto;
import gov.stb.tag.dto.ta.licencecreation.TaLicenceCreationDto;
import gov.stb.tag.dto.ta.licencecreation.TaLicenceCreationItemDto;
import gov.stb.tag.dto.ta.licencecreation.TaLicenceCreationSearchDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderRecordDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.MyInfoHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaBusinessOperation;
import gov.stb.tag.model.TaFocusArea;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.TaSpecializedMarket;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.ta.TaLicenceCreationRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.CsvUtil;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/creations")
@Transactional
public class TaLicenceCreationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaLicenceCreationRepository taLicenceCreationRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	PaymentRepository paymentRepository;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	MyInfoHelper myInfoHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	Properties properties;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	WorkflowHelper workflowHelper;

	protected static final String[] contentHeaders = new String[] { "Name", "UEN", "Submission ID", "Tier", "Mode", "Submission Date", "Status", "Assigned Officer" };

	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaLicenceCreationDto loadNew() {
		User currentUser = taLicenceCreationRepository.get(User.class, getUser().getId());
		String uen = currentUser.getUen();
		TaLicenceCreationDto dto = new TaLicenceCreationDto();
		if (travelAgentRepository.isActiveTa(uen)) {
			logger.info("loadNew(): Skipping new-app-form as user is an active TA: {}", uen);
			dto.setIsActiveLicencee(true);
			return dto;
		} else {
			logger.info("loadNew(): retrieving app data (if any) for TA: {}", uen);
			TaLicenceCreation app = taLicenceCreationRepository.getPendingApplication(uen);
			if (app == null) {
				logger.info("loadNew(): No application found. Loading new application for TA: {}", uen);
				dto = TaLicenceCreationDto.buildNewForm(cache, currentUser, fileHelper);
				return dto;
			} else {
				logger.info("loadNew(): app found. id: {}, appNo: {}, loading app data for TA: {}", app.getApplication().getId(), app.getApplication().getApplicationNo(), uen);
				dto = TaLicenceCreationDto.buildFromApplication(cache, paymentHelper, app, currentUser, myInfoHelper, fileHelper);
				return dto;
			}
		}

	}

	@RequestMapping(value = "/save-payment-request", method = RequestMethod.POST)
	public String savePaymentRequest(@RequestBody PaymentRequestDto dto) {
		PaymentRequest req = paymentHelper.savePaymentRequest(dto.getRefNo(), dto.getTypeCode(), dto.getPayerUinUen(), dto.getPayerName(),
				new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TA_LIC_APPLICATION_FEE).getValue()), dto.getDescription(), dto.getRemarks(), true, dto.getIsPayerCompany(),
				dto.getUserField2());
		return req.getBillRefNo();
	}

	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public TaLicenceCreationDto submitApplication(@RequestBody TaLicenceCreationDto dto) {
		Application app = taLicenceCreationRepository.get(Application.class, dto.getId());
		TaLicenceCreation tlc = taLicenceCreationRepository.getApplication(dto.getId());
		PaymentRequest req = paymentHelper.getPaymentRequest(tlc.getAppFeeBillRefNo());
		if (req.getStatus().getCode().equals(Codes.Statuses.PAYREQ_PAID) || req.getStatus().getCode().equals(Codes.Statuses.PAYREQ_SETTLED)) {
			appHelper.forward(app, true);
		} else {
			throw new ValidationException("Payment not made yet");
		}
		app.setSubmissionDate(LocalDateTime.now());
		app.setIsDraft(false);
		taLicenceCreationRepository.save(app);

		String url = String.format(properties.applicationUrl, "ta-application-form/" + app.getId());
		String[] recipients = { tlc.getEmailAddress(), tlc.getAppEmailAddress(), tlc.getTaKeyExecutive() != null ? tlc.getTaKeyExecutive().getEmail() : null };

		emailHelper.emailUponTaLicenceCreationSubmission(tlc, Codes.EmailType.TA_LICENCE_CREATION_SUBMISSION, url, recipients);
		return TaLicenceCreationDto.buildFromApplication(cache, paymentHelper, tlc, taLicenceCreationRepository.getLicenseeUserByUserId(getUser().getId()), myInfoHelper, fileHelper);

	}

	@RequestMapping(value = "/save/{triggerKe}", method = RequestMethod.POST)
	public TaLicenceCreationDto saveApplication(@RequestBody TaLicenceCreationDto dto, @PathVariable Boolean triggerKe) {

		// 1. Create application and workflow action
		Application app;
		if (dto.getId() == null) {
			app = new Application();
			app.setTaTgType(Codes.TaTgType.TA);
			app.setType(cache.getType(Codes.ApplicationTypes.TA_APP_CREATION));
			app.setIsDeleted(false);

		} else {
			app = taLicenceCreationRepository.get(Application.class, dto.getId());
		}
		app.setIsDraft(dto.getIsDraft());
		taLicenceCreationRepository.save(app);

		// 2. Save fields in form
		TaLicenceCreation tlc;
		if (dto.getId() == null) {
			tlc = setTaLicenceCreation(new TaLicenceCreation(), dto, app);
		} else {
			tlc = setTaLicenceCreation(taLicenceCreationRepository.getApplication(dto.getId()), dto, app);
		}
		if (!dto.getIsDraft() && !triggerKe) {
			PaymentRequest req = paymentHelper.getPaymentRequest(tlc.getAppFeeBillRefNo());
			if (req.getStatus().getCode().equals(Codes.Statuses.PAYREQ_PAID) || req.getStatus().getCode().equals(Codes.Statuses.PAYREQ_SETTLED)) {
				appHelper.forward(app, true);
			} else {
				throw new ValidationException("Payment not made yet");
			}

		}

		// 3. Generate Email Link
		if (dto.getId() == null && dto.getIsDraft()) {
			String url = String.format(properties.applicationUrl, "ta-application-form/" + app.getId());
			String[] recipients = { tlc.getEmailAddress(), tlc.getAppEmailAddress(), tlc.getTaKeyExecutive() != null ? tlc.getTaKeyExecutive().getEmail() : null };
			emailHelper.emailUponTaLicenceCreationSubmission(tlc, Codes.EmailType.TA_LICENCE_CREATION_DRAFT, url, recipients);

		}
		if (triggerKe) {
			String url = String.format(properties.applicationUrl, "ta-application-form/" + app.getId() + "/5");
			emailHelper.emailKe(tlc.getTaKeyExecutive(), Codes.EmailType.TA_KE_DECLARATION, url, tlc, tlc.getTaKeyExecutive().getEmail());
		}
		return TaLicenceCreationDto.buildFromApplication(cache, paymentHelper, tlc, taLicenceCreationRepository.getLicenseeUserByUserId(getUser().getId()), myInfoHelper, fileHelper);
	}

	@RequestMapping(value = "/link-app-fee/{appId}/{billRefNo}", method = RequestMethod.POST)
	public void linkAppFee(@PathVariable Integer appId, @PathVariable String billRefNo) {
		TaLicenceCreation tlc = taLicenceCreationRepository.getApplication(appId);
		PaymentRequest pr = paymentRepository.getPaymentRequest(billRefNo);
		if (tlc == null) {
			throw new ValidationException("Ta Licence Creation Application does not exist.");
		}
		if (pr == null) {
			throw new ValidationException("Payment Request does not exist.");
		}
		tlc.setAppFeeBillRefNo(pr.getBillRefNo());
		taLicenceCreationRepository.save(tlc);

		// update application no in payment request
		pr.setRefNo(tlc.getApplication().getApplicationNo());
		pr.setPayerName(tlc.getCompanyName());
		taLicenceCreationRepository.save(pr);
	}

	@RequestMapping(value = "/get-same-stakeholder/{id}", method = RequestMethod.GET)
	public Integer getSameStakeholder(@PathVariable Integer id) {
		TaStakeholderApplication shApp = taLicenceCreationRepository.get(TaStakeholderApplication.class, id);
		Stakeholder sh = travelAgentRepository.getSameStakeholder(shApp.getIsCompany() ? shApp.getCompanyUen() : shApp.getUin());
		return (sh != null ? sh.getId() : null);

	}

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TaLicenceCreationItemDto> getList(TaLicenceCreationSearchDto searchDto) {
		return taLicenceCreationRepository.getPendingList(searchDto, getUser().getId(), true);

	}

	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceCreationDto getApplication(@PathVariable Integer id) {
		TaLicenceCreation tlc = taLicenceCreationRepository.getApplication(id);
		User currentUser = taLicenceCreationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			appHelper.isAppBelongToTA(tlc, currentUser);
		}

		TaLicenceCreationDto result = new TaLicenceCreationDto();
		if (tlc.getApplication().isDeleted()) {
			result.setIsDeleted(true);
			return result;
		} else {
			result = TaLicenceCreationDto.buildFromApplication(cache, paymentHelper, tlc, currentUser, myInfoHelper, fileHelper);
			result.setIsFinalApproval(appHelper.isFinalApproval(tlc.getApplication()));
			result.setIsInLowestStep(appHelper.isInLowestStep(null, tlc.getApplication()));
			return result;
		}

	}

	@RequestMapping(value = { "/view/past-infringements/{id}" }, method = RequestMethod.GET)
	public List<CeInfringementDto> getInfringement(@PathVariable Integer id) {
		TaLicenceCreation tlc = taLicenceCreationRepository.getApplication(id);
		List<CeCaseInfringement> infringements = travelAgentRepository.getTaInfringements(tlc.getUen());
		List<CeInfringementDto> result = Lists.newArrayList();
		infringements.forEach(infringement -> {
			CeInfringementDto infringementDto = new CeInfringementDto(infringement.getCeCaseInfringer(), infringement, cache, true, ceCaseHelper);
			if (infringement.getLastRecommendation() != null) {
				infringementDto.setRecommendation(new CeRecommendationDto(infringement.getLastRecommendation(), cache, fileHelper, workflowHelper, null, false));
			}
			result.add(infringementDto);
		});
		return result;
	}

	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {

		// Update Application Status
		TaLicenceCreation tlc = taLicenceCreationRepository.getApplication(id);
		Application app = tlc.getApplication();

		// approve / reject / rfa
		String url = String.format(properties.applicationUrl, "ta-application-form/" + app.getId());
		String emailType = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(app)) {
				emailType = Codes.EmailType.TA_UPON_APPROVAL;

				if (tlc.getApplicationMode().getCode().equals(Codes.Types.TA_APPR_FA)) {
					PaymentRequest pr = paymentHelper.savePaymentRequest(app.getApplicationNo(), Codes.TaPaymentRequestTypes.PAYREQ_TA_CREATION_L, tlc.getUen(), tlc.getCompanyName(),
							new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TA_LICENCE_FEE).getValue()), "TA Licence Creation Licence Fee", null, false, true, tlc.getEmailAddress());
					tlc.setLicenceFeeBillRefNo(pr.getBillRefNo());
					taLicenceCreationRepository.save(tlc);
				}

			}
			break;

		case ACTION_REJECT:
			emailType = Codes.EmailType.TA_UPON_REJECTION;

			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			tlc.setIsConcluded(true);
			taLicenceCreationRepository.save(tlc);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:
			if (StringUtils.equals(dto.getRouteStatus(), Codes.Statuses.TA_APP_RFA)) {
				emailType = Codes.EmailType.TA_UPON_RFA;
			}
			appHelper.rfa(app, dto.getRouteStatus(), dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		// Send email to notify TA
		if (emailType != null) {
			String[] recipients = { tlc.getEmailAddress(), tlc.getAppEmailAddress(), tlc.getTaKeyExecutive() != null ? tlc.getTaKeyExecutive().getEmail() : null };
			emailHelper.emailUponTaLicenceCreationSubmission(tlc, emailType, url, recipients);
		}

	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taLicenceCreationRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private TaLicenceCreation setTaLicenceCreation(TaLicenceCreation tlc, TaLicenceCreationDto dto, Application app) {
		tlc.setApplication(app);
		tlc.setIsConcluded(false);
		tlc.setApplicationMode(dto.getOperatingAddress().getPostal().isEmpty() ? cache.getType(Codes.Types.TA_APPR_IPA) : cache.getType(Codes.Types.TA_APPR_FA));
		tlc.setLicenceTier(cache.getType(dto.getLicenceTier().getKey().toString()));
		tlc.setEffectiveDate(dto.getEffectiveDate());
		// Applicant Particulars
		if (dto.getIsAppMyInfo() && dto.getIsAppMyInfoClicked() != null && dto.getIsAppMyInfoClicked()) {
			MyInfoPersonBasicDto myinfo = myInfoHelper.getMyInfoPersonByUin(dto.getAppUin());
			tlc.setAppDob(myinfo.getDob());
			tlc.setAppName(myinfo.getName());
			tlc.setAppNationality(cache.getType(myinfo.getNationality()));
			tlc.setAppSex(cache.getType(myinfo.getSex()));
			if (myInfoHelper.isOccupationEditable(dto.getAppUin())) {
				tlc.setAppDesignation(cache.getType(dto.getAppDesignation().getKey().toString()));
			} else {
				tlc.setAppDesignation(cache.getType(myinfo.getOccupation()));
			}
		} else {
			tlc.setAppDob(dto.getAppDob());
			tlc.setAppName(dto.getAppName());
			tlc.setAppNationality(cache.getType(dto.getAppNationality().getKey().toString()));
			tlc.setAppSex(cache.getType(dto.getAppSex().getKey().toString()));
			tlc.setAppDesignation(cache.getType(dto.getAppDesignation().getKey().toString()));
		}
		tlc.setAppUin(dto.getAppUin());
		tlc.setAppEmailAddress(dto.getAppEmailAddress());
		tlc.setAppFaxNo(dto.getAppFaxNo());
		tlc.setAppMobileNo(dto.getAppMobileNo());
		tlc.setAppOfficeNo(dto.getAppOfficeNo());
		tlc.setAppOtherDesignation(dto.getAppOtherDesignation());
		tlc.setAppResidentialNo(dto.getAppResidentialNo());
		tlc.setIsMyInfoPopulated(dto.getIsAppMyInfo());

		// Business Entity
		tlc.setIsEdhPopulated(dto.getIsEdhPopulated());
		tlc.setCompanyFormerName(dto.getCompanyFormerName());
		tlc.setCompanyName(dto.getCompanyName());
		tlc.setContactNo(dto.getContactNo());
		tlc.setFaxNo(dto.getFaxNo());
		tlc.setEmailAddress(dto.getEmailAddress());
		if (dto.getEstablishmentStatus().getKey() != null) {
			tlc.setEstablishmentStatus(cache.getType(dto.getEstablishmentStatus().getKey().toString()));
		}
		if (dto.getFormOfBusiness().getKey() != null) {
			tlc.setFormOfBusiness(cache.getType(dto.getFormOfBusiness().getKey().toString()));
		}
		if (dto.getBusinessConstitution().getKey() != null) {
			tlc.setBusinessConstitution(cache.getType(dto.getBusinessConstitution().getKey().toString()));
		}

		if (dto.getFyeDay() != null && dto.getFyeMonth() != null) {
			try {
				if (dto.getFyeDay() == 29 && dto.getFyeMonth() == 2) {
					if (LocalDate.now().isLeapYear() && LocalDate.of(LocalDate.now().getYear(), dto.getFyeMonth(), dto.getFyeDay()).isAfter(LocalDate.now())) {
						tlc.setFyeDate(LocalDate.of(LocalDate.now().getYear(), dto.getFyeMonth(), dto.getFyeDay()));
					} else if (LocalDate.now().plusYears(1).isLeapYear() && LocalDate.of(LocalDate.now().getYear(), dto.getFyeMonth(), 28).isBefore(LocalDate.now())) {
						tlc.setFyeDate(LocalDate.of(LocalDate.now().getYear() + 1, dto.getFyeMonth(), dto.getFyeDay()));
					} else {
						throw new ValidationException("Invalid Financial Year End Date");
					}
				} else {
					if (LocalDate.of(LocalDate.now().getYear(), dto.getFyeMonth(), dto.getFyeDay()).isAfter(LocalDate.now())) {
						tlc.setFyeDate(LocalDate.of(LocalDate.now().getYear(), dto.getFyeMonth(), dto.getFyeDay()));
					} else {
						tlc.setFyeDate(LocalDate.of(LocalDate.now().getYear() + 1, dto.getFyeMonth(), dto.getFyeDay()));
					}
				}

			} catch (Exception e) {
				throw new ValidationException("Invalid Financial Year End Date");
			}

		}

		Address opAdd;
		if (tlc.getOperatingAddress() != null) {
			opAdd = tlc.getOperatingAddress();
		} else {
			opAdd = new Address();
		}
		opAdd.setBlock(dto.getOperatingAddress().getBlock());
		opAdd.setBuilding(dto.getOperatingAddress().getBuilding());
		opAdd.setFloor(dto.getOperatingAddress().getFloor());
		opAdd.setPostal(dto.getOperatingAddress().getPostal());
		opAdd.setPremiseType(cache.getType(dto.getOperatingAddress().getPremisesType().getKey().toString()));
		opAdd.setStreet(dto.getOperatingAddress().getStreet());
		opAdd.setUnit(dto.getOperatingAddress().getUnit());
		opAdd.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		tlc.setOperatingAddress(opAdd);
		tlc.setPaidUpCapital(dto.getPaidUpCapital());
		if (dto.getPlaceIncorporated().getKey() != null) {
			tlc.setPlaceIncorporated(cache.getType(dto.getPlaceIncorporated().getKey().toString()));
		}
		if (dto.getPrincipleActivities().getKey() != null) {
			tlc.setPrincipleActivities(cache.getType(dto.getPrincipleActivities().getKey().toString()));
		}

		if (dto.getSecondaryPrincipleActivities().getKey() != null) {
			tlc.setSecondaryPrincipleActivities(cache.getType(dto.getSecondaryPrincipleActivities().getKey().toString()));
		}

		Address regAdd;
		if (tlc.getRegisteredAddress() != null) {
			regAdd = tlc.getRegisteredAddress();
		} else {
			regAdd = new Address();
		}
		regAdd.setBlock(dto.getRegisteredAddress().getBlock());
		regAdd.setBuilding(dto.getRegisteredAddress().getBuilding());
		regAdd.setFloor(dto.getRegisteredAddress().getFloor());
		regAdd.setPostal(dto.getRegisteredAddress().getPostal());
		regAdd.setPremiseType(cache.getType(dto.getRegisteredAddress().getPremisesType().getKey().toString()));
		regAdd.setStreet(dto.getRegisteredAddress().getStreet());
		regAdd.setUnit(dto.getRegisteredAddress().getUnit());
		regAdd.setForeignLine1(dto.getRegisteredAddress().getForeignLine1());
		regAdd.setForeignLine2(dto.getRegisteredAddress().getForeignLine2());
		regAdd.setForeignLine3(dto.getRegisteredAddress().getForeignLine3());
		regAdd.setAddressType(dto.getRegisteredAddress().getType() != null ? cache.getType(dto.getRegisteredAddress().getType().getKey().toString()) : null);
		tlc.setRegisteredAddress(regAdd);
		tlc.setRegistrationDate(dto.getRegistrationDate());
		tlc.setTaSegmentation(cache.getType(dto.getTaSegmentation().getKey().toString()));
		tlc.setUen(dto.getUen());
		tlc.setWebsiteUrl(dto.getWebsiteUrl());
		tlc.setIsOppAddSameAsRegAdd(dto.getIsOppAddSameAsRegAdd());

		// Market Specialization
		List<TaBusinessOperation> bos = new ArrayList<>();
		List<TaFocusArea> aofs = new ArrayList<>();
		List<TaSpecializedMarket> mss = new ArrayList<>();
		tlc.setCurrentBusinessWriteUp(dto.getCurrentBusinessWriteUp());
		tlc.setInboundOpPercent(dto.getInboundOpPercent());
		tlc.setOutboundOpPercent(dto.getOutboundOpPercent());
		tlc.setTaBusinessWriteUp(dto.getTaBusinessWriteUp());

		tlc.setBusinessIdea(dto.getBusinessIdea());
		tlc.setConsumerFacingBrand(dto.getConsumerFacingBrand());
		tlc.setMktgCommsPlan(dto.getMktgCommsPlan());

		if (dto.getSalesChannelSelected() != null && dto.getSalesChannelSelected().length > 0) {
			tlc.setSalesChannel(new HashSet<>(taLicenceCreationRepository.getAllTypes(dto.getSalesChannelSelected(), Boolean.TRUE)));
		} else {
			tlc.setSalesChannel(null);
		}

		if (!Strings.isNullOrEmpty(dto.getOtherSalesChannel())) {
			tlc.setOtherSalesChannel(dto.getOtherSalesChannel());
		} else {
			tlc.setOtherSalesChannel(null);
		}
		tlc.setFinancialStrategy(dto.getFinancialStrategy());
		tlc.setRevenueProj1(dto.getRevenueProj1());
		tlc.setRevenueProj2(dto.getRevenueProj2());
		tlc.setCostProj1(dto.getCostProj1());
		tlc.setCostProj2(dto.getCostProj2());
		tlc.setProfitLossProj1(dto.getProfitLossProj1());
		tlc.setProfitLossProj2(dto.getProfitLossProj2());

		tlc.setEstTimeToProfit(dto.getEstTimeToProfit());
		tlc.setCompetitiveEdge(dto.getCompetitiveEdge());
		tlc.setPartnerServideProviders(dto.getPartnerServideProviders());
		tlc.setHasOtherBizActivities(dto.getHasOtherBizActivities() != null ? dto.getHasOtherBizActivities() : Boolean.FALSE);
		tlc.setPercentFocusOnTaBiz(dto.getPercentFocusOnTaBiz());
		tlc.setHasTaLicBefore(dto.getHasTaLicBefore() != null ? dto.getHasTaLicBefore() : Boolean.FALSE);
		tlc.setDetailsRegardingPrevLic(dto.getDetailsRegardingPrevLic());
		tlc.setRelationsWithOtherTa(dto.getRelationsWithOtherTa());
		tlc.setOthers(dto.getOthers());

		for (TaBusinessOperationDto boDto : dto.getTaBusinessOperations()) {
			if (boDto.getId() == null) {
				TaBusinessOperation bo = new TaBusinessOperation();
				bo.setInboundPercent(boDto.getInboundPercent());
				bo.setOutboundPercent(boDto.getOutboundPercent());
				bo.setService(cache.getType(boDto.getService().getKey().toString()));
				bo.setTaLicenceCreation(tlc);
				bos.add(bo);
			} else {
				TaBusinessOperation bo = taLicenceCreationRepository.get(TaBusinessOperation.class, boDto.getId());
				bo.setInboundPercent(boDto.getInboundPercent());
				bo.setOutboundPercent(boDto.getOutboundPercent());
				bo.setService(cache.getType(boDto.getService().getKey().toString()));
				bos.add(bo);
			}

		}
		if (tlc.getTaBusinessOperations() != null) {
			for (TaBusinessOperation bo : tlc.getTaBusinessOperations()) {
				if (!bos.contains(bo)) {
					taLicenceCreationRepository.delete(bo);
				}
			}
		}
		for (TaAreaOfFocusDto aofDto : dto.getTaFocusAreas()) {
			if (aofDto.getId() == null) {
				TaFocusArea aof = new TaFocusArea();
				aof.setFocusArea(cache.getType(aofDto.getFocusArea().getKey().toString()));
				aof.setHasInboundOp(aofDto.getHasInboundOp());
				aof.setHasOutboundOp(aofDto.getHasOutboundOp());
				aof.setRemarks(aofDto.getRemarks());
				aof.setTaLicenceCreation(tlc);
				aofs.add(aof);
			} else {
				TaFocusArea aof = taLicenceCreationRepository.get(TaFocusArea.class, aofDto.getId());
				aof.setFocusArea(cache.getType(aofDto.getFocusArea().getKey().toString()));
				aof.setHasInboundOp(aofDto.getHasInboundOp());
				aof.setHasOutboundOp(aofDto.getHasOutboundOp());
				aof.setRemarks(aofDto.getRemarks());
				aofs.add(aof);
			}

		}
		if (tlc.getTaFocusAreas() != null) {
			for (TaFocusArea aof : tlc.getTaFocusAreas()) {
				if (!aofs.contains(aof)) {
					taLicenceCreationRepository.delete(aof);
				}
			}
		}
		for (TaMarketSpecializationDto msDto : dto.getTaInboundSpecializedMarkets()) {
			if (msDto.getId() == null) {
				TaSpecializedMarket ms = new TaSpecializedMarket();
				ms.setCountry(cache.getType(msDto.getCountry().getKey().toString()));
				ms.setPercent(msDto.getPercentage());
				ms.setIsInbound(true);
				ms.setTaLicenceCreation(tlc);
				mss.add(ms);
			} else {
				TaSpecializedMarket ms = taLicenceCreationRepository.get(TaSpecializedMarket.class, msDto.getId());
				ms.setCountry(cache.getType(msDto.getCountry().getKey().toString()));
				ms.setPercent(msDto.getPercentage());
				ms.setIsInbound(true);
				mss.add(ms);
			}

		}
		for (TaMarketSpecializationDto msDto : dto.getTaOutboundSpecializedMarkets()) {
			if (msDto.getId() == null) {
				TaSpecializedMarket ms = new TaSpecializedMarket();
				ms.setCountry(cache.getType(msDto.getCountry().getKey().toString()));
				ms.setPercent(msDto.getPercentage());
				ms.setIsInbound(false);
				ms.setTaLicenceCreation(tlc);
				mss.add(ms);
			} else {
				TaSpecializedMarket ms = taLicenceCreationRepository.get(TaSpecializedMarket.class, msDto.getId());
				ms.setCountry(cache.getType(msDto.getCountry().getKey().toString()));
				ms.setPercent(msDto.getPercentage());
				ms.setIsInbound(false);
				mss.add(ms);
			}

		}
		if (tlc.getTaSpecializedMarkets() != null) {
			for (TaSpecializedMarket ms : tlc.getTaSpecializedMarkets()) {
				if (!mss.contains(ms)) {
					taLicenceCreationRepository.delete(ms);
				}
			}
		}

		// KE
		MyInfoPersonBasicDto keMyInfo = new MyInfoPersonBasicDto();
		if (dto.getIsKeMyInfo() && dto.getIsKeMyInfoClicked() != null && dto.getIsKeMyInfoClicked()) {
			keMyInfo = myInfoHelper.getMyInfoPersonByUin(dto.getTaKeyExecutive().getParticulars().getUin());
		}
		List<TaKeDeclaration> declarations = new ArrayList<>();
		TaStakeholderApplication ke;
		if (dto.getTaKeyExecutive().getParticulars().getStakeholderId() != null) {
			ke = taLicenceCreationRepository.get(TaStakeholderApplication.class, dto.getTaKeyExecutive().getParticulars().getStakeholderId());
			if (dto.getIsKeMyInfo() && dto.getIsKeMyInfoClicked() != null && dto.getIsKeMyInfoClicked() && !myInfoHelper.isRegAddEditable(dto.getTaKeyExecutive().getParticulars().getUin())) {
				ke.getAddress().setBlock(keMyInfo.getRegAddBlock());
				ke.getAddress().setBuilding(keMyInfo.getRegAddBuilding());
				ke.getAddress().setFloor(keMyInfo.getRegAddFloor());
				ke.getAddress().setPostal(keMyInfo.getRegAddPostal());
				ke.getAddress().setStreet(keMyInfo.getRegAddStreet());
				ke.getAddress().setUnit(keMyInfo.getRegAddUnit());
			} else {
				ke.getAddress().setBlock(dto.getTaKeyExecutive().getParticulars().getAddress().getBlock());
				ke.getAddress().setBuilding(dto.getTaKeyExecutive().getParticulars().getAddress().getBuilding());
				ke.getAddress().setFloor(dto.getTaKeyExecutive().getParticulars().getAddress().getFloor());
				ke.getAddress().setPostal(dto.getTaKeyExecutive().getParticulars().getAddress().getPostal());
				ke.getAddress().setStreet(dto.getTaKeyExecutive().getParticulars().getAddress().getStreet());
				ke.getAddress().setUnit(dto.getTaKeyExecutive().getParticulars().getAddress().getUnit());
			}
			ke.getAddress()
					.setAddressType(dto.getTaKeyExecutive().getParticulars().getAddress().getType().getKey() != null
							? cache.getType(dto.getTaKeyExecutive().getParticulars().getAddress().getType().getKey().toString())
							: null);

		} else {
			ke = new TaStakeholderApplication();
			Address keAdd = new Address();
			if (dto.getIsKeMyInfo() && dto.getIsKeMyInfoClicked() != null && dto.getIsKeMyInfoClicked() && !myInfoHelper.isRegAddEditable(dto.getTaKeyExecutive().getParticulars().getUin())) {
				keAdd.setBlock(keMyInfo.getRegAddBlock());
				keAdd.setBuilding(keMyInfo.getRegAddBuilding());
				keAdd.setFloor(keMyInfo.getRegAddFloor());
				keAdd.setPostal(keMyInfo.getRegAddPostal());
				keAdd.setStreet(keMyInfo.getRegAddStreet());
				keAdd.setUnit(keMyInfo.getRegAddUnit());
			} else {
				keAdd.setBlock(dto.getTaKeyExecutive().getParticulars().getAddress().getBlock());
				keAdd.setBuilding(dto.getTaKeyExecutive().getParticulars().getAddress().getBuilding());
				keAdd.setFloor(dto.getTaKeyExecutive().getParticulars().getAddress().getFloor());
				keAdd.setPostal(dto.getTaKeyExecutive().getParticulars().getAddress().getPostal());
				keAdd.setStreet(dto.getTaKeyExecutive().getParticulars().getAddress().getStreet());
				keAdd.setUnit(dto.getTaKeyExecutive().getParticulars().getAddress().getUnit());

			}
			keAdd.setAddressType(dto.getTaKeyExecutive().getParticulars().getAddress().getType().getKey() != null
					? cache.getType(dto.getTaKeyExecutive().getParticulars().getAddress().getType().getKey().toString())
					: null);
			ke.setAddress(keAdd);

		}
		if (dto.getIsKeMyInfo() && dto.getIsKeMyInfoClicked() != null && dto.getIsKeMyInfoClicked()) {
			ke.setDob(keMyInfo.getDob());
			ke.setName(keMyInfo.getName());
			ke.setNationality(cache.getType(keMyInfo.getNationality()));
			ke.setSex(cache.getType(keMyInfo.getSex()));
			if (myInfoHelper.isOccupationEditable(dto.getTaKeyExecutive().getParticulars().getUin())) {
				ke.setDesignation(cache.getType(keMyInfo.getOccupation()));
			} else {
				ke.setDesignation(cache.getType(dto.getTaKeyExecutive().getParticulars().getDesignation().getKey().toString()));
			}
		} else {
			ke.setDob(dto.getTaKeyExecutive().getParticulars().getDob());
			ke.setName(dto.getTaKeyExecutive().getParticulars().getStakeholderName());
			ke.setNationality(cache.getType(dto.getTaKeyExecutive().getParticulars().getNationality().getKey().toString()));
			ke.setSex(cache.getType(dto.getTaKeyExecutive().getParticulars().getSex().getKey().toString()));
			ke.setDesignation(cache.getType(dto.getTaKeyExecutive().getParticulars().getDesignation().getKey().toString()));
		}

		ke.setEmail(dto.getTaKeyExecutive().getParticulars().getEmail());
		ke.setContactNo(dto.getTaKeyExecutive().getParticulars().getContactNo());
		ke.setResidentialNo(dto.getTaKeyExecutive().getParticulars().getResidentialNo());
		ke.setOfficeNo(dto.getTaKeyExecutive().getParticulars().getOfficeNo());
		ke.setHighestEduLevel(
				dto.getTaKeyExecutive().getParticulars().getHighestEduLevel().getKey() != null ? cache.getType(dto.getTaKeyExecutive().getParticulars().getHighestEduLevel().getKey().toString())
						: null);
		ke.setUin(dto.getTaKeyExecutive().getParticulars().getUin());
		ke.setOtherDesignation(dto.getTaKeyExecutive().getParticulars().getOtherDesignation());
		ke.setAppointedDate(dto.getTaKeyExecutive().getInvolvement().getAppointedDate());
		ke.setRole(cache.getType(Codes.TaStakeholderRoles.STKHLD_KE));
		ke.setIsMyInfoPopulated(dto.getIsKeMyInfo());

		for (TaKeDeclarationsDto declarationDto : dto.getTaKeyExecutive().getInvolvement().getTaKeDeclarations()) {
			if (declarationDto.getId() == null) {
				TaKeDeclaration declaration = new TaKeDeclaration();
				declaration.setOptionSelected(declarationDto.getSelectedOption());
				if (declarationDto.getSelectedOption().equalsIgnoreCase(declarationDto.getOptionsToPrompt())) {
					declaration.setRemarks(declarationDto.getRemarks());
				} else {
					declaration.setRemarks(null);
				}
				declaration.setTaKeClause(cache.getTaKeClause(Integer.parseInt(declarationDto.getClause().getKey().toString())));
				declaration.setTaKeyExecutiveApplication(ke);
				declarations.add(declaration);
			} else {
				TaKeDeclaration declaration = taLicenceCreationRepository.get(TaKeDeclaration.class, declarationDto.getId());
				declaration.setOptionSelected(declarationDto.getSelectedOption());
				if (declarationDto.getSelectedOption().equalsIgnoreCase(declarationDto.getOptionsToPrompt())) {
					declaration.setRemarks(declarationDto.getRemarks());
				} else {
					declaration.setRemarks(null);
				}
			}

		}

		// // Personnel
		List<TaStakeholderApplication> stakeholders = new ArrayList<>();
		for (StakeholderRecordDto tshDto : dto.getTaStakeholders()) {
			if (!tshDto.getInvolvement().getRole().getKey().toString().equals(Codes.TaStakeholderRoles.STKHLD_KE)) {
				TaStakeholderApplication tsa;
				if (tshDto.getParticulars().getStakeholderId() != null) {
					tsa = taLicenceCreationRepository.get(TaStakeholderApplication.class, tshDto.getParticulars().getStakeholderId());
					tsa.getAddress().setAddressType(tshDto.getParticulars().getAddress().getType() != null ? cache.getType(tshDto.getParticulars().getAddress().getType().getKey().toString()) : null);
					tsa.getAddress().setBlock(tshDto.getParticulars().getAddress().getBlock());
					tsa.getAddress().setBuilding(tshDto.getParticulars().getAddress().getBuilding());
					tsa.getAddress().setFloor(tshDto.getParticulars().getAddress().getFloor());
					tsa.getAddress().setPostal(tshDto.getParticulars().getAddress().getPostal());
					tsa.getAddress().setStreet(tshDto.getParticulars().getAddress().getStreet());
					tsa.getAddress().setUnit(tshDto.getParticulars().getAddress().getUnit());
					tsa.getAddress().setForeignLine1(tshDto.getParticulars().getAddress().getForeignLine1());
					tsa.getAddress().setForeignLine2(tshDto.getParticulars().getAddress().getForeignLine2());
					tsa.getAddress().setForeignLine3(tshDto.getParticulars().getAddress().getForeignLine3());
				} else {
					tsa = new TaStakeholderApplication();
					Address shAdd = new Address();
					shAdd.setBlock(tshDto.getParticulars().getAddress().getBlock());
					shAdd.setBuilding(tshDto.getParticulars().getAddress().getBuilding());
					shAdd.setFloor(tshDto.getParticulars().getAddress().getFloor());
					shAdd.setPostal(tshDto.getParticulars().getAddress().getPostal());
					shAdd.setStreet(tshDto.getParticulars().getAddress().getStreet());
					shAdd.setUnit(tshDto.getParticulars().getAddress().getUnit());
					shAdd.setAddressType(tshDto.getParticulars().getAddress().getType() != null ? cache.getType(tshDto.getParticulars().getAddress().getType().getKey().toString()) : null);
					shAdd.setForeignLine1(tshDto.getParticulars().getAddress().getForeignLine1());
					shAdd.setForeignLine2(tshDto.getParticulars().getAddress().getForeignLine2());
					shAdd.setForeignLine3(tshDto.getParticulars().getAddress().getForeignLine3());
					tsa.setAddress(shAdd);
				}

				tsa.setAppointedDate(tshDto.getInvolvement().getAppointedDate());
				tsa.setRole(cache.getType(tshDto.getInvolvement().getRole().getKey().toString()));
				tsa.setSharesHeld(tshDto.getInvolvement().getSharesHeld());
				tsa.setCompanyIncorporatedDate(tshDto.getParticulars().getCompanyIncorporatedDate());
				tsa.setCompanyUen(tshDto.getParticulars().getCompanyUen());
				tsa.setContactNo(tshDto.getParticulars().getContactNo());
				tsa.setEmail(tshDto.getParticulars().getEmail());
				tsa.setFormerUin(tshDto.getParticulars().getFormerUin());
				tsa.setIsCompany(tshDto.getParticulars().getIsCompany());
				tsa.setName(tshDto.getParticulars().getStakeholderName());
				tsa.setNationality(cache.getType(tshDto.getParticulars().getNationality().getKey().toString()));
				tsa.setSex(cache.getType(tshDto.getParticulars().getSex().getKey().toString()));
				tsa.setUin(tshDto.getParticulars().getUin());
				tsa.setTaLicenceCreation(tlc);
				tsa.setIsEdhPopulated(dto.getIsEdhPopulated());
				stakeholders.add(tsa);
			}

		}
		if (tlc.getTaStakeholders() != null) {
			for (TaStakeholderApplication tsa : tlc.getTaStakeholders()) {
				if (!tsa.getRole().getCode().equals(Codes.TaStakeholderRoles.STKHLD_KE)) {
					if (!stakeholders.contains(tsa)) {
						taLicenceCreationRepository.delete(tsa);
					}
				}

			}
		}

		// 7. Supporting Documents
		List<ApplicationFile> appFiles = new ArrayList<>();
		if (dto.getKeNric().getSize() != null) {
			if (dto.getKeNric().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getKeNric());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getKeNric().getId());
				appFiles.add(file);
			}
		}
		if (dto.getKeResolution().getSize() != null) {
			if (dto.getKeResolution().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getKeResolution());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getKeResolution().getId());
				appFiles.add(file);
			}
		}
		if (dto.getKeResume().getSize() != null) {
			if (dto.getKeResume().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getKeResume());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getKeResume().getId());
				appFiles.add(file);
			}
		}
		if (dto.getBeoc().getSize() != null) {
			if (dto.getBeoc().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getBeoc());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getBeoc().getId());
				appFiles.add(file);
			}
		}
		if (dto.getBankStatement().getSize() != null) {
			if (dto.getBankStatement().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getBankStatement());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getBankStatement().getId());
				appFiles.add(file);
			}
		}
		if (dto.getTenancyAgreement().getSize() != null) {
			if (dto.getTenancyAgreement().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getTenancyAgreement());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getTenancyAgreement().getId());
				appFiles.add(file);
			}
		}
		if (dto.getHosApproval().getSize() != null) {
			if (dto.getHosApproval().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getHosApproval());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getHosApproval().getId());
				appFiles.add(file);
			}
		}
		if (dto.getCbs().getSize() != null) {
			if (dto.getCbs().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getCbs());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getCbs().getId());
				appFiles.add(file);
			}
		}
		if (dto.getAfa().getSize() != null) {
			if (dto.getAfa().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getAfa());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getAfa().getId());
				appFiles.add(file);
			}
		}
		if (dto.getAcra().getSize() != null) {
			if (dto.getAcra().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getAcra());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getAcra().getId());
				appFiles.add(file);
			}
		}
		for (FileDto doc : dto.getOtherDocuments()) {
			if (doc.getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, doc);
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(doc.getId());
				appFiles.add(file);
			}

		}
		if (app.getApplicationFiles() != null) {
			for (ApplicationFile appFile : app.getApplicationFiles()) {
				if (!appFiles.contains(appFile)) {
					fileHelper.deleteFile(appFile.getFile());
				}
			}
		}

		taLicenceCreationRepository.save(tlc.getOperatingAddress());
		taLicenceCreationRepository.save(tlc.getRegisteredAddress());
		taLicenceCreationRepository.save(tlc);
		taLicenceCreationRepository.save(mss);
		taLicenceCreationRepository.save(bos);
		taLicenceCreationRepository.save(aofs);

		taLicenceCreationRepository.save(ke.getAddress());
		taLicenceCreationRepository.save(ke);
		taLicenceCreationRepository.save(declarations);
		tlc.setTaKeyExecutive(ke);
		taLicenceCreationRepository.save(tlc);

		stakeholders.stream().forEach(o -> {
			if (o.getRole() != null && !Codes.TaStakeholderRoles.STKHLD_KE.equals(o.getRole().getCode())) {
				o.setTaLicenceCreation(tlc);
				taLicenceCreationRepository.save(o.getAddress());
				taLicenceCreationRepository.save(o);
			}

		});
		return tlc;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/export-list")
	public void exportAAList(@RequestBody TaLicenceCreationSearchDto searchDto, HttpServletResponse response) throws IOException, ParseException {
		ResultDto<TaLicenceCreationItemDto> searchResultDTOs = taLicenceCreationRepository.getPendingList(searchDto, getUser().getId(), true);
		List<TaLicenceCreationItemDto> models = searchResultDTOs.getModels();
		CsvUtil.export(response, contentHeaders, models, dto -> new String[] { dto.getName(), dto.getUen(), dto.getApplicationNo(), dto.getTier(), dto.getMode(),
				dto.getSubmissionDate().format(DateUtil.DATETIME_FORMAT), dto.getStatus(), dto.getAssignedOfficer() });
	}

}
