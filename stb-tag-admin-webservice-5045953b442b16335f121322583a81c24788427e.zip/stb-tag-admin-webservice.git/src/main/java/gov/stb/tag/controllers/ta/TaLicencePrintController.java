package gov.stb.tag.controllers.ta;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licenceprint.TaLicencePrintDto;
import gov.stb.tag.dto.ta.licenceprint.TaLicencePrintItemDto;
import gov.stb.tag.dto.ta.licenceprint.TaLicencePrintSearchDto;
import gov.stb.tag.repository.ta.TaLicencePrintRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/licence-printing")
@Transactional
public class TaLicencePrintController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaLicencePrintRepository taLicencePrintRepository;

	@RequestMapping(method = RequestMethod.GET, path = { "/view" })
	public ResultDto<TaLicencePrintItemDto> getList(TaLicencePrintSearchDto searchDto) {
		return taLicencePrintRepository.getList(searchDto, getUser().getId());
	}

	@RequestMapping(method = RequestMethod.POST, path = { "/update" })
	public void updateLicencePrintStatus(@RequestBody TaLicencePrintDto dto) {
		taLicencePrintRepository.getApplicationByIds(dto.getApplicationIds()).forEach(application -> {
			application.setLicencePrintStatus(cache.getStatus(dto.getStatus().getKey().toString()));
			taLicencePrintRepository.save(application);
		});
	}
}
