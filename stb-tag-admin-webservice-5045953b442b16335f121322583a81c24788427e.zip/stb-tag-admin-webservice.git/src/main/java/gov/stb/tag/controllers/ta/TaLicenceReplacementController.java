package gov.stb.tag.controllers.ta;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.licencereplacement.TaLicenceReplacementDto;
import gov.stb.tag.dto.ta.licencereplacement.TaLicenceReplacementItemDto;
import gov.stb.tag.dto.ta.licencereplacement.TaLicenceReplacementSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TaLicenceReplacement;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.ta.TaLicenceReplacementRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/replacement")
@Transactional
public class TaLicenceReplacementController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaLicenceReplacementRepository taLicenceReplacementRepository;
	@Autowired
	TravelAgentRepository taRepository;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	PaymentRepository paymentRepository;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	FileHelper fileHelper;

	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaLicenceReplacementDto loadNew() {
		User currentUser = taLicenceReplacementRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			Licence licence = currentUser.getTravelAgent().getLicence();
			TaLicenceReplacement tlr = taLicenceReplacementRepository.getPendingApplication(licence.getId());
			if (tlr == null) {
				TaLicenceReplacementDto dto = TaLicenceReplacementDto.buildFromNew(cache, fileHelper);
				return dto;
			} else {
				TaLicenceReplacementDto dto = TaLicenceReplacementDto.buildFromApplication(cache, appHelper, paymentHelper, tlr, fileHelper);
				return dto;
			}
		}
		return null;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public TaLicenceReplacementDto saveApplication(@RequestBody TaLicenceReplacementDto dto) {

		// 1. Create application and workflow action
		Application app;
		TaLicenceReplacement tlr;
		if (dto.getApplicationId() == null) {
			app = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_REPLACEMENT,
					(taLicenceReplacementRepository.getLicenseeUserByUserId(getUser().getId()).getTravelAgent().getLicence().getId()), dto.isOfflineSubmission(), dto.isDraft());
			app.setSubmissionDate(LocalDateTime.now());
			tlr = new TaLicenceReplacement();
		} else {
			app = taLicenceReplacementRepository.get(Application.class, dto.getApplicationId());
			tlr = taLicenceReplacementRepository.getApplication(dto.getApplicationId());
		}
		if (!dto.isDraft()) {
			appHelper.forward(app, true);
		}
		app.setIsDraft(dto.isDraft());

		// 2. Save files uploaded by user
		List<ApplicationFile> appFiles = new ArrayList<>();
		if (dto.getPoliceReport() != null && dto.getPoliceReport().getSize() != null) {
			if (dto.getPoliceReport().getPublicFileId() == null) {
				ApplicationFile file = fileHelper.saveFile(app, dto.getPoliceReport());
				appFiles.add(file);
			} else {
				ApplicationFile file = fileRepository.getAppFile(dto.getPoliceReport().getId());
				appFiles.add(file);
			}
		}
		if (CollectionUtils.isNotEmpty(dto.getOtherDocuments())) {
			for (FileDto doc : dto.getOtherDocuments()) {
				if (doc.getPublicFileId() == null) {
					ApplicationFile file = fileHelper.saveFile(app, doc);
					appFiles.add(file);
				} else {
					ApplicationFile file = fileRepository.getAppFile(doc.getId());
					appFiles.add(file);
				}

			}
		}

		if (app.getApplicationFiles() != null) {
			for (ApplicationFile appFile : app.getApplicationFiles()) {
				if (!appFiles.contains(appFile)) {
					fileHelper.deleteFile(appFile.getFile());
				}
			}
		}

		// 3. Save fields in form
		tlr.setApplication(app);
		tlr.setReason(cache.getType(dto.getReason().getKey().toString()));
		if (dto.getReason().getKey().equals(Codes.Types.TA_REASON_REPLACE_OTHERS)) {
			tlr.setOtherReason(dto.getOtherReasons());
		}

		taLicenceReplacementRepository.save(tlr);
		tlr.getApplication().setApplicationFiles(new HashSet<>(appFiles));
		return TaLicenceReplacementDto.buildFromApplication(cache, appHelper, paymentHelper, tlr, fileHelper);

	}

	@RequestMapping(value = "/save-payment-request", method = RequestMethod.POST)
	public String savePaymentRequest(@RequestBody PaymentRequestDto dto) {
		TravelAgent ta = taRepository.getTaByUen(dto.getPayerUinUen());
		PaymentRequest req = paymentHelper.savePaymentRequest(dto.getRefNo(), dto.getTypeCode(), dto.getPayerUinUen(), dto.getPayerName(),
				new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TA_LIC_REPLACE_FEE).getValue()), dto.getDescription(), dto.getRemarks(), true, dto.getIsPayerCompany(),
				ta.getEmailAddress());
		return req.getBillRefNo();
	}

	@RequestMapping(value = "/link-pay-request/{appId}/{billRefNo}", method = RequestMethod.POST)
	public void linkAppFee(@PathVariable Integer appId, @PathVariable String billRefNo) {
		TaLicenceReplacement tlr = taLicenceReplacementRepository.getApplication(appId);
		PaymentRequest pr = paymentRepository.getPaymentRequest(billRefNo);
		if (tlr == null) {
			throw new ValidationException("Ta Licence Replacement Application does not exist.");
		}
		if (pr == null) {
			throw new ValidationException("Payment Request does not exist.");
		}
		tlr.setBillRefNo(pr.getBillRefNo());
		taLicenceReplacementRepository.save(tlr);

		// update application no in payment request
		pr.setRefNo(tlr.getApplication().getApplicationNo());
		pr.setPayerName(tlr.getApplication().getLicence().getTravelAgent().getName());
		pr.setUserField1(tlr.getApplication().getLicence().getLicenceNo());
		taLicenceReplacementRepository.save(pr);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceReplacementItemDto> getList(TaLicenceReplacementSearchDto searchDto) {
		return taLicenceReplacementRepository.getPendingList(searchDto, getUser().getId());
	}

	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceReplacementDto getApplication(@PathVariable Integer id) {
		User currentUser = taLicenceReplacementRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			appHelper.isAppBelongToTA(id, currentUser);
		}
		TaLicenceReplacement tlr = taLicenceReplacementRepository.getApplication(id);
		TaLicenceReplacementDto result = TaLicenceReplacementDto.buildFromApplication(cache, appHelper, paymentHelper, tlr, fileHelper);
		return result;
	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taLicenceReplacementRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {

		// Update Application Status
		TaLicenceReplacement tlr = taLicenceReplacementRepository.getApplication(id);
		Application app = tlr.getApplication();

		String alertMsg = null;
		String emailType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(app)) {
				alertMsg = Messages.Alerts.APP_APPROVE;
				emailType = Codes.EmailType.TA_UPON_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;
			}
			break;

		case ACTION_REJECT:
			alertMsg = Messages.Alerts.APP_REJECT;
			emailType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;

			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				alertMsg = Messages.Alerts.APP_RFA;
				emailType = Codes.EmailType.TA_UPON_RFA;
			}

			appHelper.rfa(app, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		// Send alert and email to notify TA
		if (alertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				alertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			alertHelper.createAlert(app.getLicence().getTravelAgent(), app, alertMsg, Codes.Modules.MOD_TA, app.getType(), "../ta-replace-licence/" + app.getId(), cache.getStatus(statusCode));

			String url = String.format(properties.applicationUrl, "ta-replace-licence/" + app.getId());
			emailHelper.emailTaUponAction(app, emailType, url);
		}

	}

}
