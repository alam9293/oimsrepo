package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licencetierswitch.TaLicenceTierSwitchDto;
import gov.stb.tag.dto.ta.licencetierswitch.TaLicenceTierSwitchItemDto;
import gov.stb.tag.dto.ta.licencetierswitch.TaLicenceTierSwitchSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaELicenceRequest;
import gov.stb.tag.model.TaLicenceTierSwitch;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.ta.TaBranchRepository;
import gov.stb.tag.repository.ta.TaELicenceRequestRepository;
import gov.stb.tag.repository.ta.TaLicenceTierSwitchRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/tier-switches")
@Transactional
public class TaLicenceTierSwitchController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaLicenceTierSwitchRepository taLicenceTierSwitchRepository;
	@Autowired
	TaELicenceRequestRepository taELicenceRequestRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TaBranchRepository taBranchRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	LicenceHelper licenceHelper;

	// to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceTierSwitchItemDto> getList(TaLicenceTierSwitchSearchDto searchDto) {
		ResultDto<TaLicenceTierSwitchItemDto> resultDTO = new ResultDto<TaLicenceTierSwitchItemDto>();
		resultDTO = taLicenceTierSwitchRepository.getPendingList(searchDto, getUser().getId());
		return resultDTO;
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceTierSwitchDto getApplication(@PathVariable Integer id) {
		User currentUser = taLicenceTierSwitchRepository.getLicenseeUserByUserId(getUser().getId());
		TaLicenceTierSwitchDto resultDto = new TaLicenceTierSwitchDto();
		List<FileDto> fileList = new ArrayList<FileDto>();
		Object[] docTypeList = { Codes.TaDocumentTypes.TA_DOC_BANK, Codes.TaDocumentTypes.TA_DOC_MGMT_ACC };
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}

			resultDto = taLicenceTierSwitchRepository.getTierSwitchByAppId(id);
			if (resultDto != null) {
				resultDto = TaLicenceTierSwitchDto.buildApplication(cache, appHelper, taLicenceTierSwitchRepository.get(Application.class, id), resultDto);
				resultDto = taLicenceTierSwitchRepository.buildBusinessOperationsIntoDto(resultDto);

				List<FileDto> reqFileList = new ArrayList<FileDto>();
				fileList = taLicenceTierSwitchRepository.getFiles(resultDto.getApplicationId(), fileHelper);
				reqFileList = taLicenceTierSwitchRepository.getSupportingDocList(docTypeList, fileHelper); /* to define which supporting Doc are required */

				resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
			}
		}
		return resultDto;
	}

	// to approve, reject, revert switch tier
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaLicenceTierSwitch tierSwitchModel = new TaLicenceTierSwitch();
		tierSwitchModel = taLicenceTierSwitchRepository.get(TaLicenceTierSwitch.class, id);

		Application appModel = tierSwitchModel.getApplication();

		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(appModel, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(appModel)) {
				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taMsgType = Codes.EmailType.TA_TS_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				Licence licenceModel = new Licence();
				licenceModel = appModel.getLicence();

				if (tierSwitchModel.getStartDate().isAfter(LocalDate.now())) {
					// Batch job to do the switch tier
					tierSwitchModel.setPendingSwitch(Boolean.TRUE);
					taLicenceTierSwitchRepository.saveOrUpdate(tierSwitchModel);
				} else {
					// Straight away update licence tier
					licenceHelper.updateLicenceTier(tierSwitchModel);

					// set licence printing
					appHelper.setTaApplicationPendingPrinting(appModel);
				}

				// update e-licence download flag
				logger.info("Licence Viewable flag (TA Licence Tier Switch Approval) for Licence No " + licenceModel.getLicenceNo() + " : " + licenceModel.getIsViewable());
				if (licenceModel.getIsViewable() != null && licenceModel.getIsViewable() == Codes.ELicenceView.VIEW) {
					logger.info("E-licence is viewable for Licence No " + licenceModel.getLicenceNo());
					// check if there is pending e-licence request submission
					TaELicenceRequest taELicenceReqModel = taELicenceRequestRepository.getPendingApplication(licenceModel.getId());
					// If there is no pending submission, reset downloadflag to be able to re-download
					if (taELicenceReqModel == null) {
						taELicenceRequestRepository.resetELicenceRequest(licenceModel);
						List<TaBranch> branches = new ArrayList<TaBranch>();
						branches = travelAgentRepository.getActiveBranchesByLicenceId(licenceModel.getId());
						for (TaBranch branch : branches) {
							taBranchRepository.resetBranchELicenceRequest(branch);
						}
					}
				} else {
					logger.info("E-licence is not viewable for Licence No " + licenceModel.getLicenceNo());
				}
			}
			break;

		case ACTION_REJECT:
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;

			appHelper.reject(appModel, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
			}

			appHelper.rfa(appModel, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(appModel.getLicence().getTravelAgent(), appModel, taAlertMsg, Codes.Modules.MOD_TA, appModel.getType(), "../ta-switch-tier/" + appModel.getId(),
					cache.getStatus(statusCode));

			/* Send email to notify TA & KE */

			String url = String.format(properties.applicationUrl, "ta-switch-tier/" + appModel.getId());
			emailHelper.emailTaUponAction(appModel, taMsgType, url);
		}

	}

	// to create new or get existing application details
	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaLicenceTierSwitchDto getNewApplication() {

		TaLicenceTierSwitchDto resultDto = new TaLicenceTierSwitchDto();
		List<FileDto> fileList = new ArrayList<FileDto>();
		Object[] docTypeList = { Codes.TaDocumentTypes.TA_DOC_BANK, Codes.TaDocumentTypes.TA_DOC_MGMT_ACC };
		TaLicenceTierSwitch switchTierModel = new TaLicenceTierSwitch();

		User currentUser = taLicenceTierSwitchRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();
		if (Codes.Roles.TA_PUBLIC.equals(getSelectedRoleCode()) && !Objects.isNull(currentUser.getTravelAgent())) {
			// Check if there is approved switch tier pending to switch/ Pending processing/ RFA. Do not allow new submission if there is
			switchTierModel = taLicenceTierSwitchRepository.getPendingTierSwitch(licenceModel.getId());
		}

		if (switchTierModel == null) {
			resultDto.setOldLicenceTier(licenceModel.getTier().getLabel());
			resultDto.setOldLicenceTierCode(licenceModel.getTier().getCode());
			resultDto.setApplicationStatus(
					new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));
			resultDto.setLicenceNo(licenceModel.getLicenceNo());
			resultDto.setLicenceId(licenceModel.getId());

			resultDto = resultDto.buildFromLicence(cache, licenceModel, resultDto);

			Type newTier = new Type();
			if (Codes.Types.TA_TIER_NICHE.equalsIgnoreCase(licenceModel.getTier().getCode())) {
				newTier = cache.getType(Codes.Types.TA_TIER_GENERAL);
				resultDto.setNewLicenceTier(newTier.getLabel());
				resultDto.setNewLicenceTierCode(newTier.getCode());
			} else {
				newTier = cache.getType(Codes.Types.TA_TIER_NICHE);
				resultDto.setNewLicenceTier(newTier.getLabel());
				resultDto.setNewLicenceTierCode(newTier.getCode());
			}
			fileList = taLicenceTierSwitchRepository.getSupportingDocList(docTypeList, fileHelper); /* to define which supporting Doc are required */
			resultDto.setFiles(fileList);

		} else {
			resultDto = getExistingAppId(resultDto, switchTierModel.getApplication());
			List<FileDto> reqFileList = new ArrayList<FileDto>();
			fileList = resultDto.getFiles();
			reqFileList = taLicenceTierSwitchRepository.getSupportingDocList(docTypeList, fileHelper); /* to define which supporting Doc are required */

			resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
		}

		return resultDto;
	}

	private TaLicenceTierSwitchDto getExistingAppId(TaLicenceTierSwitchDto resultDto, Application appModel) {
		resultDto = taLicenceTierSwitchRepository.getTierSwitchByAppId(appModel.getId());
		resultDto = TaLicenceTierSwitchDto.buildApplication(cache, appHelper, appModel, resultDto);
		resultDto = taLicenceTierSwitchRepository.buildBusinessOperationsIntoDto(resultDto);

		List<FileDto> fileList = new ArrayList<FileDto>();
		fileList = taLicenceTierSwitchRepository.getFiles(resultDto.getApplicationId(), fileHelper);
		resultDto.setFiles(fileList);
		return resultDto;
	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taLicenceTierSwitchRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	// to submit new application details
	@RequestMapping(path = { "/save", "/update" }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaLicenceTierSwitchDto dto) throws IOException {
		User currentUser = taLicenceTierSwitchRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licenceModel = new Licence();
		licenceModel = currentUser.getTravelAgent().getLicence();
		if (dto.getApplicationId() != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
			}
		}

		TaLicenceTierSwitch tierSwitcModel = new TaLicenceTierSwitch();

		if (dto != null) {
			Application appModel;

			if (dto.getApplicationId() != null) { // Update existing
				appModel = taLicenceTierSwitchRepository.get(Application.class, dto.getApplicationId());
				appHelper.forward(appModel, true);
				tierSwitcModel = taLicenceTierSwitchRepository.get(TaLicenceTierSwitch.class, dto.getId());
			} else { // save new
				appModel = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_TIER_SWITCH, licenceModel.getId(), dto.isOfflineSubmission(), false);
				appHelper.forward(appModel, true);
			}

			tierSwitcModel = taLicenceTierSwitchRepository.updateTierSwitchDetails(dto, tierSwitcModel);
			tierSwitcModel.setApplication(appModel);
			taLicenceTierSwitchRepository.saveOrUpdate(tierSwitcModel);
			tierSwitcModel = taLicenceTierSwitchRepository.updateBusinessOperations(dto, tierSwitcModel);
			/* TODO set TA licence to be pending return */

			for (FileDto doc : dto.getFiles()) {
				if (doc.getPublicFileId() == null && !Strings.isNullOrEmpty(doc.getOriginalName())) {
					fileHelper.saveFile(appModel, doc);
				}
			}

			List<Integer> toDeleteList = dto.getToDeleteFiles();
			if (toDeleteList != null && !toDeleteList.isEmpty()) {
				for (Integer id : toDeleteList) {
					if (id != null) {
						File attachemnt = new File();
						attachemnt = fileHelper.getFile(id);
						if (attachemnt != null) {
							fileHelper.deleteFile(attachemnt);
						}
					}
				}
			}
		}
	}
}
