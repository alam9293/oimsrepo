package gov.stb.tag.controllers.ta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.ma.TaMaDto;
import gov.stb.tag.dto.ta.ma.TaMaItemDto;
import gov.stb.tag.dto.ta.ma.TaMaSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaLicenceRepository;
import gov.stb.tag.repository.ta.TaMaSubmissionRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/management-accounts")
@Transactional
public class TaMaSubmissionController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaMaSubmissionRepository taMaSubmissionRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository fileRepository;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	TaNetValueShortfallRepository taNetValueShortfallRepository;

	// CR1227
	@Autowired
	TaLicenceRepository taLicenceRepository;

	public static final Object[] docTypeList = { Codes.TaDocumentTypes.TA_DOC_MANAGEMENT_ACCOUNTS };

	// to create new or get existing application details
	@RequestMapping(value = "/load", method = RequestMethod.GET)
	public TaMaDto loadNewOrPending() {
		User currentUser = taMaSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = currentUser.getTravelAgent().getLicence();
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(licence)) {
			// Check if TA has application pending approval, if yes, TA cannot submit another
			Application application = taMaSubmissionRepository.getPendingApplicationFromLicenceId(licence.getId(), Codes.ApplicationTypes.TA_MA_FILING_TYPES);
			if (application == null) {
				TaMaDto dto = TaMaDto.buildFromNew(cache, taAnnualFilingRepository.getTaAnnualFilingPendingTA(licence.getId(), Codes.ApplicationTypes.TA_MA_FILING_TYPES, Boolean.TRUE, false),
						fileHelper);
				return dto;
			} else {
				return this.buildMaDto(application.getId());
			}
		}

		return null;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaMaDto dto) {

		Application application = appHelper.saveNewApplication(dto.getFilingDto().getTypeCode(),
				(taMaSubmissionRepository.getLicenseeUserByUserId(getUser().getId()).getTravelAgent().getLicence().getId()), dto.isOfflineSubmission(), false);
		appHelper.forward(application, true);

		// 2. Save files uploaded by user
		fileHelper.saveFile(application, dto.getManagementAccounts());
		for (FileDto doc : dto.getOtherDocuments()) {
			fileHelper.saveFile(application, doc);
		}

		// 3. Save fields in form
		this.saveApplicationFields(dto, new TaMaSubmission(), application);

		// 4. Update filing status
		TaFilingCondition filing = taMaSubmissionRepository.get(TaFilingCondition.class, dto.getFilingDto().getAnnualFilingId());
		if (filing != null) {
			filing.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_APPROVAL));
			filing.setRectifiedApplication(application);
			taMaSubmissionRepository.save(filing);
		}
	}

	@RequestMapping(value = { "/update", "edit" }, method = RequestMethod.POST)
	public void updateApplication(@RequestPart(name = "application") TaMaDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {
		if (!dto.isOfflineSubmission() || !dto.getIsEdit()) {
			User currentUser = taMaSubmissionRepository.getLicenseeUserByUserId(getUser().getId());

			if (dto.getApplicationId() != null) {
				if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
					appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
				}
			}
		}

		// 1. Get application
		Application application = taMaSubmissionRepository.get(Application.class, dto.getApplicationId());

		// 2. Delete files deleted by user
		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}
		}

		// 3. Save additional files uploaded by user
		if (dto.getIsEdit()) {
			File maFileModel = taMaSubmissionRepository.get(File.class, dto.getManagementAccounts().getId());
			ApplicationFile maAppFileModel = fileRepository.getAppFile(dto.getManagementAccounts().getId());
			if (maFileModel != null && maAppFileModel == null) {
				fileHelper.saveApplicationFile(application, maFileModel, dto.getManagementAccounts());
			}
			for (FileDto doc : dto.getOtherDocuments()) {
				File otherFileModel = taMaSubmissionRepository.get(File.class, doc.getId());
				ApplicationFile otherAppFileModel = fileRepository.getAppFile(doc.getId());
				if (otherFileModel != null && otherAppFileModel == null) {
					fileHelper.saveApplicationFile(application, otherFileModel, doc);
				}
			}
		} else {
			if (dto.getManagementAccounts().getPublicFileId() == null && !Strings.isNullOrEmpty(dto.getManagementAccounts().getOriginalName())) {
				fileHelper.saveFile(application, dto.getManagementAccounts());
			}
			for (FileDto doc : dto.getOtherDocuments()) {
				if (doc.getPublicFileId() == null) {
					fileHelper.saveFile(application, doc);
				}
			}
		}

		// 4. Save changes made by user
		TaFilingCondition filing = taMaSubmissionRepository.get(TaFilingCondition.class, dto.getFilingDto().getAnnualFilingId());
		if (!dto.isDraft() && !dto.getIsEdit()) {
			appHelper.forward(application, true);

			// 5. Update filing status
			if (filing != null) {
				filing.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_APPROVAL));
				filing.setRectifiedApplication(application);
				taMaSubmissionRepository.save(filing);
			}
		} else if (dto.getIsEdit()) {
			appHelper.edit(application, dto.getInternalRemarks());
		}

		this.saveApplicationFields(dto, taMaSubmissionRepository.getApplication(application.getId()), application);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaMaItemDto> getList(TaMaSearchDto searchDto) {
		return taMaSubmissionRepository.getPendingList(searchDto, getUser().getId());
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaMaDto getApplication(@PathVariable Integer id) {
		User currentUser = taMaSubmissionRepository.getLicenseeUserByUserId(getUser().getId());
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
			return buildMaDto(id);
		}
		return null;
	}

	// to approve, reject, rfa
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaMaSubmission ma = taMaSubmissionRepository.getApplication(id);
		Application app = ma.getApplication();

		TaFilingCondition maFiling = ma.getTaFilingCondition();

		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			if (appHelper.hasFinalApproved(app)) {
				taAlertMsg = Messages.Alerts.APP_APPROVE;
				taMsgType = Codes.EmailType.TA_UPON_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				boolean newShortFall = false;
				if (maFiling != null) {
					maFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_APPROVED));
				}
				// create shortfall record if there is shortfall
				if (ma.getShortfall().compareTo(BigDecimal.ZERO) > 0) {
					appHelper.createNetValueShortfall(null, ma);
					newShortFall = true;
				}

				if (!newShortFall) {
					// CR 1227
					// Check if anymore filing conditions
					SystemParameter sysParam = taLicenceRepository.getJobParameter(Codes.SystemParameters.TA_FILING_CONDITION_REMINDER_START_DATE);
					// List<TaFilingCondition> taFilingConditions = taLicenceRepository.getPendingTaAnnualFilingSubmissionsByLicenceId(sysParam.getValue(), app.getLicence().getId());
					TaLicenceRenewalExerciseTa taFilingConditions = taLicenceRepository.getTaByLicenceId(app.getLicence().getId());
					logger.info("TaMaSubmissionController getExpiryDate - " + app.getLicence().getExpiryDate());
					boolean fulfilled = conditionsFulfilled(taFilingConditions, ma);
					if (fulfilled) {
						// Override the message
						// TA_UPON_APPROVAL with TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED
						taMsgType = Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED;
						logger.info("TaMaSubmissionController NewEmail - " + Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED);
					}
				}
			}
			break;
		case ACTION_REJECT:
			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;
			if (maFiling != null) {
				if (LocalDate.now().isAfter(maFiling.getDueDate())) {
					maFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_LATE));
				} else {
					maFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_PEND_SUBMISSION));
				}
				maFiling.setRectifiedApplication(null);
			}
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
				statusCode = Codes.Statuses.TA_APP_RFA;
				if (maFiling != null) {
					maFiling.setStatus(cache.getStatus(Codes.Statuses.TA_FILING_RFA));
				}
			}

			appHelper.rfa(app, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());

			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(app.getLicence().getTravelAgent(), app, taAlertMsg, Codes.Modules.MOD_TA, app.getType(), "../ta-ma-submission/" + app.getId(), cache.getStatus(statusCode));

			/* Send email to notify TA */
			String url = String.format(properties.applicationUrl, "ta-ma-submission/" + app.getId());
			emailHelper.emailTaUponAction(app, taMsgType, url);
		}
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taMaSubmissionRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void saveApplicationFields(TaMaDto dto, TaMaSubmission submission, Application application) {
		if (submission == null) {
			submission = new TaMaSubmission();
		}
		submission.setApplication(application);
		submission.setTotalAssets(dto.getTotalAssets());
		submission.setTotalLiabilities(dto.getTotalLiabilities());
		submission.setAsAtDate(dto.getAsatDate());
		submission.setPaidUpCapital(dto.getCapital());

		// set net value
		submission.setNetValue((submission.getTotalAssets() != null && submission.getTotalLiabilities() != null) ? submission.getTotalAssets().subtract(submission.getTotalLiabilities()) : null);

		// set shortfall
		Integer financialRequirement = (submission.getApplication().getLicence().getTier().getKey().equals(Codes.Types.TA_TIER_GENERAL)
				? Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_GENERAL_FINANICAL_REQUIREMENT).getValue())
				: Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_NICHE_FINANICAL_REQUIREMENT).getValue()));
		submission.setShortfall(submission.getNetValue() != null ? BigDecimal.valueOf(financialRequirement).subtract(submission.getNetValue()).compareTo(new BigDecimal(0)) < 0 ? new BigDecimal(0)
				: BigDecimal.valueOf(financialRequirement).subtract(submission.getNetValue()) : null);

		submission.setTaFilingCondition(taMaSubmissionRepository.get(TaFilingCondition.class, dto.getFilingDto().getAnnualFilingId()));
		taMaSubmissionRepository.save(submission);
	}

	private TaMaDto buildMaDto(Integer applicationId) {
		TaMaSubmission ma = taMaSubmissionRepository.getApplication(applicationId);
		TaNetValueShortfall shortfall = null;
		TaNetValueRectification rectification = null;
		if (ma.getShortfall().compareTo(BigDecimal.ZERO) > 0) {// MA has shortfall
			// find the shortfall record
			shortfall = taNetValueShortfallRepository.getShortfallByMaSubmissionId(ma.getId());
			if (shortfall != null) {
				rectification = shortfall.getTaNetValueRectification();
			}
		}
		return TaMaDto.buildFromApplication(cache, appHelper, workflowHelper, ma, shortfall, rectification, fileHelper);
	}

	private boolean conditionsFulfilled(TaLicenceRenewalExerciseTa taLicenceRenewalExerciseTa, TaMaSubmission ma) {

		try {
			if (null == taLicenceRenewalExerciseTa) {
				return false;
			}

			// Aa
			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// Abpr
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// NET val
			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1()) {
				if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2()) {
				if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			// MA
			if (null != taLicenceRenewalExerciseTa.getMaFilingCondition()) {
				if (taLicenceRenewalExerciseTa.getMaFilingCondition().getId() == ma.getTaFilingCondition().getId()) {
					// cont
				} else if (taLicenceRenewalExerciseTa.getMaFilingCondition().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			return true;
		} catch (Exception e) {
			return false;
		}
		/*
		 * for (TaFilingCondition conditions : filteredTaFilingConditions) {
		 * 
		 * if (!conditions.getStatus().getCode().equals("TA_FILING_APPR")) { return false; }
		 * 
		 * } return true;
		 */

	}

}
