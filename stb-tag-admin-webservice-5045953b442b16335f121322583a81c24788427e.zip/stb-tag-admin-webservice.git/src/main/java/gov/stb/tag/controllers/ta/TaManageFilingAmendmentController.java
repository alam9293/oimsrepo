package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.constant.Codes.EmailType;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingExtensionDateDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingItemDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingSearchDto;
import gov.stb.tag.dto.ta.filingamend.TaLicenceFilingAmendDto;
import gov.stb.tag.dto.ta.filingamend.TaLicenceFilingAmendSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFilingConditionAmendment;
import gov.stb.tag.model.TaFilingConditionExtension;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaFilingAmendmentRepository;
import gov.stb.tag.repository.ta.TaFilingExtensionsRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/manage-filing-amend")
@Transactional
public class TaManageFilingAmendmentController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cacheHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	TaFilingAmendmentRepository taFilingAmendmentRepository;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	TaFilingExtensionsRepository taFilingExtensionsRepository;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	TaRenewalRepository taRenewalRepository;

	public static final Object[] applicableTypes = { ApplicationTypes.TA_APP_MA_SUBMISSION, ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION, ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION };

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceFilingItemDto> getTaFilings(TaLicenceFilingSearchDto searchDto) {
		ResultDto<TaFilingConditionAmendment> result = taFilingAmendmentRepository.getList(searchDto, getUser().getId());
		ResultDto<TaLicenceFilingItemDto> resultDto = new ResultDto<TaLicenceFilingItemDto>();

		resultDto.setTotal(result.getTotal());
		resultDto.setResult(result.getResult());
		resultDto.setSuccessFlag(result.getSuccessFlag());
		Object[] records = new Object[result.getModels().size()];
		resultDto.setRecords(records);
		int i = 0;
		if (result.getModels().size() > 0) {
			for (TaFilingConditionAmendment row : result.getModels()) {
				TaLicenceFilingItemDto dto = TaLicenceFilingItemDto.buildFilingItemDto(row, workflowHelper);
				records[i++] = dto;
			}
		}
		return resultDto;
	}

	// to load filing details for travel agent's licence id
	@RequestMapping(value = "/view/travel-agents", method = RequestMethod.GET)
	public TaLicenceFilingAmendDto getTaDetails(TaLicenceFilingAmendSearchDto searchDto) {
		Licence licenceModel = taFilingAmendmentRepository.get(Licence.class, searchDto.getLicenceId());
		TaLicenceFilingAmendDto resultDto = TaLicenceFilingAmendDto.buildFromModel(cacheHelper, null, new TaLicenceFilingAmendDto(), licenceModel, workflowHelper);
		resultDto.setWorkType(new ListableDto(cache.getType(Codes.Workflow.TA_WKFLW_FILING_AMEND)));

		List<TaFilingCondition> annualFilingList = taAnnualFilingRepository.getTaFilingsPendingTa(searchDto.getLicenceId(), applicableTypes);

		if (annualFilingList != null && annualFilingList.size() > 0) {
			resultDto.setExtensionDates(new ArrayList<TaLicenceFilingExtensionDateDto>());
			for (TaFilingCondition row : annualFilingList) {
				TaFilingConditionAmendment extension = taFilingAmendmentRepository.getAmendments(searchDto.getLicenceId(), row.getId());
				if (extension == null) {
					resultDto.getExtensionDates().add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(row, new TaLicenceFilingExtensionDateDto()));
				}
			}
			if (resultDto.getExtensionDates() != null && resultDto.getExtensionDates().size() < 1) {
				resultDto.setErrorMsg("All MA/Document filing conditions amendment request for TA are pending approval.");
			}
		} else {
			resultDto.setErrorMsg("No pending MA/Document submission for TA.");
		}

		if (resultDto.getWorkflowId() == null) {
			resultDto = resultDto.buildNewWorkflowDto(cache, null, resultDto, workflowHelper, resultDto.getWorkType().getKey().toString());
		}

		return resultDto;
	}

	// to submit new application details
	@RequestMapping(path = { "/save", "/update", }, method = RequestMethod.POST)
	public Integer saveDto(@RequestBody TaLicenceFilingAmendDto dto) throws IOException {

		if (dto != null) {
			Licence licenceModel = taFilingAmendmentRepository.get(Licence.class, dto.getLicenceId());
			TaFilingConditionAmendment model;
			if (dto.getFilingAmendId() != null) {
				model = taFilingAmendmentRepository.get(TaFilingConditionAmendment.class, dto.getFilingAmendId());
				Workflow workflow = model.getWorkflow();
				workflow.setType(cacheHelper.getType(dto.getWorkType().getKey().toString()));
				taFilingAmendmentRepository.saveOrUpdate(workflow);
			} else {
				model = new TaFilingConditionAmendment();
				Workflow workflow = workflowHelper.saveNewWorkflow(dto.getWorkType().getKey().toString(), null, null, null, Boolean.FALSE, licenceModel);
				model.setWorkflow(workflow);
			}
			taFilingAmendmentRepository.saveOrUpdate(model);

			List<TaFilingConditionExtension> dates = new ArrayList<TaFilingConditionExtension>();
			dates = updateDateFromDto(model, dto.getExtensionDates());
			taFilingAmendmentRepository.saveOrUpdate(dates);

			return model.getId();
		}
		return null;
	}

	// to approve, reject, RFA
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaFilingConditionAmendment amend = taFilingAmendmentRepository.get(TaFilingConditionAmendment.class, id);
		Workflow workflow = amend.getWorkflow();
		switch (action) {
		case ACTION_APPROVE:
			if (workflow.getLastAction() == null) {
				workflowHelper.forward(workflow, Boolean.TRUE, dto.getInternalRemarks(), null, null, null);
			} else {
				workflowHelper.forward(workflow, Boolean.FALSE, dto.getInternalRemarks(), null, null, null);
				if (workflowHelper.hasFinalApproved(workflow)) {
					String emailBody = "";
					String alertText = "";
					int index = 1;
					for (TaFilingConditionExtension row : amend.getTaFilingConditionExtensions()) {
						String filingChanges = "";
						if (row.getToProceed()) {
							TaFilingCondition filing = row.getTaFilingCondition();
							filing.setLastExtension(row);
							if (row.getAmmendmentType().getCode().equalsIgnoreCase(Types.TA_FILING_AMEND_EXTEND_DUE_DATE)) {
								if (row.getExtendedDueDate().isAfter(LocalDate.now()) || row.getExtendedDueDate().equals(LocalDate.now())) {
									if (filing.getStatus().getCode().equalsIgnoreCase(Statuses.TA_FILING_LATE)) {
										filing.setStatus(cacheHelper.getStatus(Statuses.TA_FILING_PEND_SUBMISSION));
									}
								}
								filingChanges += (index++) + ". Due date for " + cache.getLabel(filing.getApplicationType(), true) + " submission is extended to "
										+ DateUtil.format(row.getExtendedDueDate()) + ". ";
								alertText += filingChanges;
								emailBody += "<p>" + filingChanges + "Please <a href=\""
										+ String.format(properties.applicationUrl, Codes.TA_APP_LINKS.get(filing.getApplicationType().getCode()).get(0))
										+ "\">login here</a> to make the submission by " + DateUtil.format(row.getExtendedDueDate() != null ? row.getExtendedDueDate() : filing.getDueDate()) + ".</p>";
							} else { // filling to rescind
								filing.setStatus(cacheHelper.getStatus(Statuses.TA_FILING_VOID));

								if (!filing.getApplicationType().getCode().equalsIgnoreCase(ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION)) {
									TaLicenceRenewalExerciseTa renewalTa = taRenewalRepository.getRenewalTaFromFiling(filing);
									if (renewalTa != null) {
										renewalTa.setMaFilingCondition(null);
										renewalTa.setIsMaRequired(Boolean.FALSE);
										renewalTa.setIsMaVoid(Boolean.TRUE);
										taFilingAmendmentRepository.saveOrUpdate(renewalTa);
									}
								}

								filingChanges += (index++) + ". " + cache.getLabel(filing.getApplicationType(), true) + " submission due on "
										+ DateUtil.format(row.getExtendedDueDate() != null ? row.getExtendedDueDate() : filing.getDueDate()) + " has been rescinded. ";
								alertText += filingChanges;
								emailBody += "<p> " + filingChanges + "</p>";
							}
							System.out.println(emailBody);

							taFilingAmendmentRepository.saveOrUpdate(filing);
						}
					}
					// send email
					alertHelper.createAlert(workflow.getLicence().getTravelAgent(), null, alertText, Codes.Modules.MOD_TA, null, null, null);
					emailHelper.emailTaForFilingConditionAmend(workflow.getLicence(), EmailType.TA_FILING_CONDITION_CHANGE_NOTIFY, emailBody);
				}
			}
			break;
		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
			if (workflowHelper.hasFinalApprovedOrRejected(workflow)) {
				throw new ValidationException("Routing can only be applied to open cases.");
			}
			workflowHelper.rfa(workflow, dto.getRouteStatus(), dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;
		}
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TaLicenceFilingAmendDto getDetails(@PathVariable Integer id) {
		TaFilingConditionAmendment amend = taFilingAmendmentRepository.get(TaFilingConditionAmendment.class, id);

		TaLicenceFilingAmendDto resultDto = TaLicenceFilingAmendDto.buildFromModel(cacheHelper, amend, new TaLicenceFilingAmendDto(), amend.getWorkflow().getLicence(), workflowHelper);

		// List<TaLicenceFilingExtensionDateDto> extendDtoList = new ArrayList<TaLicenceFilingExtensionDateDto>();
		//
		// for (TaFilingConditionExtension row : amend.getTaFilingConditionExtensions()) {
		// List<TaFilingConditionExtension> pastExtensions = taFilingAmendmentRepository.getExtensionDates(row.getTaFilingCondition().getId());
		// for (TaFilingConditionExtension pastExtension : pastExtensions) {
		// if (pastExtension.getTaFilingConditionExtensionAssessment() == null) {
		// extendDtoList.add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(pastExtension, new TaLicenceFilingExtensionDateDto()));
		// }
		// }
		// }
		//
		// resultDto.setExtensionDates(extendDtoList);
		return resultDto;
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = taFilingAmendmentRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private List<TaFilingConditionExtension> updateDateFromDto(TaFilingConditionAmendment amendmentModel, List<TaLicenceFilingExtensionDateDto> extensionDates) {
		List<TaFilingConditionExtension> dates = new ArrayList<TaFilingConditionExtension>();
		for (TaLicenceFilingExtensionDateDto row : extensionDates) {
			if (row.getAmmendType() != null && !Strings.isNullOrEmpty(row.getAmmendType().getKey().toString())) {
				TaFilingConditionExtension date;
				if (row.getExtensionDateId() != null) {
					date = taFilingExtensionsRepository.get(TaFilingConditionExtension.class, row.getExtensionDateId());
				} else {
					date = new TaFilingConditionExtension();
				}
				date.setAmmendmentType(cache.getType(row.getAmmendType().getKey().toString()));
				if (row.getAmmendType().getKey().toString().equalsIgnoreCase(Types.TA_FILING_AMEND_EXTEND_DUE_DATE)) {
					date.setExtendedDueDate(row.getExtendedDueDate());
				}
				date.setTaFilingCondition(taFilingExtensionsRepository.get(TaFilingCondition.class, row.getAnnualFilingId()));
				date.setToProceed(row.getToExtend());
				date.setTaFilingConditionAmendment(amendmentModel);
				dates.add(date);
			}
		}
		return dates;
	}

}
