package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.FLAGS;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingExtensionDateDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingExtensionDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingItemDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFilingConditionExtension;
import gov.stb.tag.model.TaFilingConditionExtensionAssessment;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.ta.TaAnnualFilingRepository;
import gov.stb.tag.repository.ta.TaFilingExtensionsRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/manage-filing")
@Transactional
public class TaManageFilingController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	FileHelper fileHelper;
	@Autowired
	CacheHelper cacheHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	TaNetValueShortfallRepository shortRepo;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TaFilingExtensionsRepository taFilingExtensionsRepository;
	@Autowired
	TaAnnualFilingRepository taAnnualFilingRepository;
	@Autowired
	CeTaskHelper ceTaskHelper;

	public static final Object[] docTypeList = { Codes.TaDocumentTypes.TA_DOC_EXTENSION_EMAIL_REQUEST };
	public static final Object[] applicableTypes = { Codes.ApplicationTypes.TA_APP_AA_SUBMISSION, Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION };

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceFilingItemDto> getTaFilings(TaLicenceFilingSearchDto searchDto) {
		ResultDto<TaFilingConditionExtensionAssessment> result = taFilingExtensionsRepository.getList(searchDto, getUser().getId());
		ResultDto<TaLicenceFilingItemDto> resultDto = new ResultDto<TaLicenceFilingItemDto>();

		resultDto.setTotal(result.getTotal());
		resultDto.setResult(result.getResult());
		resultDto.setSuccessFlag(result.getSuccessFlag());
		Object[] records = new Object[result.getModels().size()];
		resultDto.setRecords(records);
		int i = 0;
		if (result.getModels().size() > 0) {
			for (TaFilingConditionExtensionAssessment row : result.getModels()) {
				TaLicenceFilingItemDto dto = TaLicenceFilingItemDto.buildFilingItemDto(row, workflowHelper);
				records[i++] = dto;
			}
		}
		return resultDto;
	}

	@RequestMapping(path = "/view/ta-risk-assessment", method = RequestMethod.POST)
	public TaLicenceFilingExtensionDto getRiskAssessment(@RequestBody TaLicenceFilingExtensionDto dto) {
		DecimalFormat f = new DecimalFormat("###,###");
		Integer shortfallCriteria = null;

		Boolean isDetailed = Boolean.FALSE;

		Licence licence = taFilingExtensionsRepository.get(Licence.class, dto.getLicenceId());

		for (TaLicenceFilingExtensionDateDto row : dto.getExtensionDates()) {
			LocalDate dtAdd1Month = row.getDueDate().plusDays(1).plusMonths(1).minusDays(1);
			if (row.getExtendedDueDate() != null) {
				Boolean isBeforeExtendedDueDate = dtAdd1Month.isBefore(row.getExtendedDueDate());
				logger.info("getRiskAssessment() - dueDate={}, dtAdd1Month={}, isBeforeExtendedDueDate={}", row.getDueDate(), dtAdd1Month, isBeforeExtendedDueDate);

				if (isBeforeExtendedDueDate) {
					logger.info("getRiskAssessment() - Extended due date={} is more than 1 month, set risk assessment as detailed", row.getExtendedDueDate());
					isDetailed = Boolean.TRUE;
					break;
				} else {
					logger.info("getRiskAssessment() - Extended due date={} is less than/equal 1 month, set risk assessment as preliminary.", row.getExtendedDueDate());
				}
			} else {
				logger.info("getRiskAssessment() - Extended due date is null");
			}

		}

		/****************** Assess AA *****************/
		List<TaAaSubmission> aaList = taAnnualFilingRepository.getAaPreviousFiling(dto.getLicenceId(), 2);
		int loseCount = 0;
		dto.setConsecutiveLossesRemarks("");
		int index = 1;
		for (TaAaSubmission aa : aaList) {
			if (aa.getNetProfitLoss() != null) {
				dto.setConsecutiveLossesRemarks(dto.getConsecutiveLossesRemarks().concat(aa.getTaAnnualFiling().getFy() + " " + aa.getTaAnnualFiling().getApplicationType().getLabel()) + ": S$"
						+ f.format(aa.getNetProfitLoss()) + " \r\n");
				if (aa.getNetProfitLoss().signum() == -1) {
					loseCount++;
				}
			}

			if (index == 1) {
				dto.setAssessedAaId(aa.getId());
			} else {
				dto.setAssessedAa2Id(aa.getId());
			}
			index++;
		}

		if (aaList.size() < 2) {// Does not have 2 consecutive year of data to compute
			dto.setConsecutiveLossesRemarks("No pass 2 consecutive years of AA to compute.");
			dto.setHasConsecutiveLosses(new ListableDto(cacheHelper.getType(FLAGS.FLAG_NA).getCode(), cacheHelper.getType(FLAGS.FLAG_NA).getLabel()));
		}

		if (aaList.size() == 2) {// Have 2 consecutive year of data to compute
			if (loseCount > 1) {
				dto.setHasConsecutiveLosses(new ListableDto(cacheHelper.getType(FLAGS.FLAG_Y).getCode(), cacheHelper.getType(FLAGS.FLAG_Y).getLabel()));
			} else {
				dto.setHasConsecutiveLosses(new ListableDto(cacheHelper.getType(FLAGS.FLAG_N).getCode(), cacheHelper.getType(FLAGS.FLAG_N).getLabel()));
			}
		}

		if (aaList.size() > 0) {
			if (licence.getTier().getKey().toString().equalsIgnoreCase(Types.TA_TIER_NICHE)) {
				shortfallCriteria = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_EXTENSION_SHORTFALL_NICHE).getValue());
			} else {
				shortfallCriteria = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_EXTENSION_SHORTFALL_GENERAL).getValue());
			}
			if (aaList.get(0).getShortfall() != null) {
				dto.setShortfallExceededLossesRemarks(
						aaList.get(0).getTaAnnualFiling().getFy() + " " + aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ": S$" + f.format(aaList.get(0).getShortfall()));
				if (aaList.get(0).getShortfall().compareTo(new BigDecimal(shortfallCriteria)) == 1) {
					dto.setHasShortfallExceeded(new ListableDto(cacheHelper.getType(FLAGS.FLAG_Y).getCode(), cacheHelper.getType(FLAGS.FLAG_Y).getLabel()));
				} else {
					dto.setHasShortfallExceeded(new ListableDto(cacheHelper.getType(FLAGS.FLAG_N).getCode(), cacheHelper.getType(FLAGS.FLAG_N).getLabel()));
				}
			} else {
				dto.setHasShortfallExceeded(new ListableDto(cacheHelper.getType(FLAGS.FLAG_NA).getCode(), cacheHelper.getType(FLAGS.FLAG_NA).getLabel()));
				dto.setShortfallExceededLossesRemarks("Unable to determine due to incomplete information (based on " + aaList.get(0).getTaAnnualFiling().getFy() + " "
						+ aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ") ");
			}

			if (aaList.get(0).getCurrentAssets() != null && aaList.get(0).getCurrentLiabilities() != null) {
				if (aaList.get(0).getCurrentAssets().compareTo(BigDecimal.ZERO) != 0 && aaList.get(0).getCurrentLiabilities().compareTo(BigDecimal.ZERO) != 0) {
					if (aaList.get(0).getCurrentAssets().divide(aaList.get(0).getCurrentLiabilities(), 2, RoundingMode.HALF_UP).compareTo(new BigDecimal(1)) == -1) {
						dto.setIsCurrentRatioLessThanOne(new ListableDto(cacheHelper.getType(FLAGS.FLAG_Y).getCode(), cacheHelper.getType(FLAGS.FLAG_Y).getLabel()));
					} else {
						dto.setIsCurrentRatioLessThanOne(new ListableDto(cacheHelper.getType(FLAGS.FLAG_N).getCode(), cacheHelper.getType(FLAGS.FLAG_N).getLabel()));
					}
				} else {
					dto.setIsCurrentRatioLessThanOne(new ListableDto(cacheHelper.getType(FLAGS.FLAG_Y).getCode(), cacheHelper.getType(FLAGS.FLAG_Y).getLabel()));
				}
				if (aaList.get(0).getCurrentAssets().compareTo(BigDecimal.ZERO) == 0 || aaList.get(0).getCurrentLiabilities().compareTo(BigDecimal.ZERO) == 0) {
					dto.setIsCurrentRatioLessRemarks(aaList.get(0).getTaAnnualFiling().getFy() + " " + aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ": 0");
				} else {
					dto.setIsCurrentRatioLessRemarks(aaList.get(0).getTaAnnualFiling().getFy() + " " + aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ": "
							+ aaList.get(0).getCurrentAssets().divide(aaList.get(0).getCurrentLiabilities(), 2, RoundingMode.HALF_UP));
				}

			} else {
				dto.setIsCurrentRatioLessThanOne(new ListableDto(cacheHelper.getType(FLAGS.FLAG_NA).getCode(), cacheHelper.getType(FLAGS.FLAG_NA).getLabel()));
				dto.setIsCurrentRatioLessRemarks("Unable to determine due to incomplete information (based on " + aaList.get(0).getTaAnnualFiling().getFy() + " "
						+ aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ") ");
			}

			if (isDetailed) {
				if (aaList.get(0).getRevenue() != null) {
					if (aaList.get(0).getRevenue().compareTo(new BigDecimal(10000000)) == 0 || aaList.get(0).getRevenue().compareTo(new BigDecimal(10000000)) == 1) {
						dto.setSalesTurnoverRisk("High, ");
					} else {
						dto.setSalesTurnoverRisk("Low, ");
					}
					dto.setSalesTurnoverRisk(dto.getSalesTurnoverRisk().concat(" sales turnover S$" + f.format(aaList.get(0).getRevenue())));
				} else {
					dto.setSalesTurnoverRisk("Unable to determine due to incomplete information (based on " + aaList.get(0).getTaAnnualFiling().getFy() + " "
							+ aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ") ");
				}

				if (aaList.get(0).getAmtOwnByDir() != null && aaList.get(0).getCapital() != null) {
					if (aaList.get(0).getCapital().compareTo(new BigDecimal(0)) != 0) {
						if (aaList.get(0).getAmtOwnByDir().divide(aaList.get(0).getCapital(), 2, RoundingMode.HALF_UP).compareTo(new BigDecimal(0.1)) == 1) {
							dto.setAmtOwedByDirRisk("High, ");
						} else {
							dto.setAmtOwedByDirRisk("Low, ");
						}
					} else {
						dto.setAmtOwedByDirRisk("Low, ");
					}
					dto.setAmtOwedByDirRisk(dto.getAmtOwedByDirRisk().concat(" amount due from director is S$" + f.format(aaList.get(0).getAmtOwnByDir()) + " (based on "
							+ aaList.get(0).getTaAnnualFiling().getFy() + " " + aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ")"));
				} else {
					dto.setAmtOwedByDirRisk("Unable to determine due to incomplete information (based on " + aaList.get(0).getTaAnnualFiling().getFy() + " "
							+ aaList.get(0).getTaAnnualFiling().getApplicationType().getLabel() + ") ");
				}
			}

		} else {
			dto.setHasShortfallExceeded(new ListableDto(cacheHelper.getType(FLAGS.FLAG_NA).getCode(), cacheHelper.getType(FLAGS.FLAG_NA).getLabel()));
			dto.setIsCurrentRatioLessThanOne(new ListableDto(cacheHelper.getType(FLAGS.FLAG_NA).getCode(), cacheHelper.getType(FLAGS.FLAG_NA).getLabel()));
		}

		if (isDetailed) {
			dto.setType(new ListableDto(cacheHelper.getType(Codes.Workflow.TA_WKFLW_EXTENSION_DETL)));
			/****************** Assess ABPR *****************/
			TaAbprSubmission abpr = taAnnualFilingRepository.getAbprPreviousFiling(dto.getLicenceId());
			if (abpr != null) {
				if (abpr.getOutboundOpPercent().compareTo(new BigDecimal(60)) == 1) {
					dto.setInboundOutboundRisk("High, ");
				} else {
					dto.setInboundOutboundRisk("Low, ");
				}
				dto.setInboundOutboundRisk(dto.getInboundOutboundRisk()
						.concat(abpr.getOutboundOpPercent().toString() + "% (based on " + abpr.getTaAnnualFiling().getFy() + " " + abpr.getTaAnnualFiling().getApplicationType().getLabel() + ")"));
				dto.setAssessedAbprId(abpr.getId());
			} else {
				dto.setInboundOutboundRisk("No previous ABPR.");
			}

		} else {
			dto.setType(new ListableDto(cacheHelper.getType(Codes.Workflow.TA_WKFLW_EXTENSION_PREM)));
		}

		if (dto.getWorkflowId() == null) {
			dto = dto.buildNewWorkflowDto(cache, null, dto, workflowHelper, dto.getType().getKey().toString());
		}

		return dto;
	}

	// to load filing details for travel agent's licence id
	@RequestMapping(value = "/view/travel-agents/{licenceId}", method = RequestMethod.GET)
	public TaLicenceFilingExtensionDto getTaAnnualFilingExtension(@PathVariable Integer licenceId) {
		List<AttachmentDto> fileList = new ArrayList<AttachmentDto>();
		Licence licenceModel = taFilingExtensionsRepository.get(Licence.class, licenceId);
		TaLicenceFilingExtensionDto resultDto = TaLicenceFilingExtensionDto.buildFromExtension(cacheHelper, null, new TaLicenceFilingExtensionDto(), licenceModel, workflowHelper);

		List<TaFilingCondition> annualFilingList = taAnnualFilingRepository.getTaFilingsPendingTa(licenceId, applicableTypes);

		if (annualFilingList != null) {
			resultDto.setExtensionDates(new ArrayList<TaLicenceFilingExtensionDateDto>());
			List<TaLicenceFilingExtensionDateDto> pastExtensionsDto = new ArrayList<TaLicenceFilingExtensionDateDto>();
			for (TaFilingCondition row : annualFilingList) {
				TaFilingConditionExtensionAssessment extension = taFilingExtensionsRepository.getPendingExtension(licenceId, row.getId());
				if (extension == null) {
					resultDto.getExtensionDates().add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(row, new TaLicenceFilingExtensionDateDto()));

					List<TaFilingConditionExtension> pastExtensions = taFilingExtensionsRepository.getExtensionDates(row.getId());
					for (TaFilingConditionExtension pastExtension : pastExtensions) {
						if (pastExtension.getTaFilingConditionExtensionAssessment() == null) {
							pastExtensionsDto.add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(pastExtension, new TaLicenceFilingExtensionDateDto()));
						}
					}
				}
				resultDto.setPastExtensionDates(pastExtensionsDto);
			}
			fileList = taFilingExtensionsRepository.getSupportingDocList(docTypeList, fileHelper);
			resultDto.setFiles(fileList);
		}

		return resultDto;
	}

	// to submit new application details
	@RequestMapping(path = { "/save", "/update", }, method = RequestMethod.POST)
	public Integer saveFilingExtension(@RequestBody TaLicenceFilingExtensionDto dto) throws IOException {

		if (dto != null) {
			Licence licenceModel = taFilingExtensionsRepository.get(Licence.class, dto.getLicenceId());
			TaFilingConditionExtensionAssessment extensionModel;
			if (dto.getFilingExtensionId() != null) {
				extensionModel = taFilingExtensionsRepository.get(TaFilingConditionExtensionAssessment.class, dto.getFilingExtensionId());
				Workflow workflow = extensionModel.getWorkflow();
				workflow.setType(cacheHelper.getType(dto.getType().getKey().toString()));
				taFilingExtensionsRepository.saveOrUpdate(workflow);
			} else {
				extensionModel = new TaFilingConditionExtensionAssessment();
				Workflow workflow = workflowHelper.saveNewWorkflow(dto.getType().getKey().toString(), null, null, null, Boolean.FALSE, licenceModel);
				extensionModel.setWorkflow(workflow);
			}

			extensionModel = updateExtensionFromDto(extensionModel, dto);
			taFilingExtensionsRepository.saveOrUpdate(extensionModel);
			List<TaFilingConditionExtension> dates = new ArrayList<TaFilingConditionExtension>();
			dates = updateDateFromDto(extensionModel, dto.getExtensionDates());
			taFilingExtensionsRepository.saveOrUpdate(dates);

			for (AttachmentDto fileDto : dto.getFiles()) {
				File fileModel = taFilingExtensionsRepository.get(File.class, fileDto.getId());
				if (fileModel != null) {
					fileHelper.saveWorkflowFile(extensionModel.getWorkflow(), fileDto);
				}
			}

			List<Integer> toDeleteList = dto.getToDeleteFiles();
			if (toDeleteList != null && !toDeleteList.isEmpty()) {
				for (Integer id : toDeleteList) {
					if (id != null) {
						File attachemnt = new File();
						attachemnt = fileHelper.getFile(id);
						if (attachemnt != null) {
							fileHelper.deleteFile(attachemnt);
						}
					}
				}
			}
			return extensionModel.getId();
		}
		return null;
	}

	// to approve, reject, RFA
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaFilingConditionExtensionAssessment assessment = taFilingExtensionsRepository.get(TaFilingConditionExtensionAssessment.class, id);
		Workflow workflow = assessment.getWorkflow();
		switch (action) {
		case ACTION_APPROVE:
			if (workflow.getLastAction() == null) {
				workflowHelper.forward(workflow, Boolean.TRUE, dto.getInternalRemarks(), null, null, null);
			} else {
				workflowHelper.forward(workflow, Boolean.FALSE, dto.getInternalRemarks(), null, null, null);
				if (workflowHelper.hasFinalApproved(workflow)) {
					// TODO: send email
					for (TaFilingConditionExtension row : assessment.getTaFilingConditionExtensions()) {
						if (row.getToProceed()) {
							TaFilingCondition filing = row.getTaFilingCondition();
							filing.setLastExtension(row);
							taFilingExtensionsRepository.saveOrUpdate(filing);

							if (row.getExtendedDueDate().isAfter(LocalDate.now()) || row.getExtendedDueDate().equals(LocalDate.now())) {
								if (filing.getStatus().getCode().equalsIgnoreCase(Statuses.TA_FILING_LATE)) {
									filing.setStatus(cacheHelper.getStatus(Statuses.TA_FILING_PEND_SUBMISSION));
								}
							}

							if (CollectionUtils.isNotEmpty(ceTaskHelper.getCeTaskByTaFilingCondition(filing))) {
								// create For Info Task
								logger.info("TaFilingCondition(id: {}) due date extended. Creating For Info Task with new due date and SLA", filing.getId());
								ceTaskHelper.createCeTaskForAaOrAbpr(filing, Messages.CeTaskDetails.R141_FINANCIAL_REQUIREMENT_GG_LATE, Codes.CeTaskStatus.CE_TASK_FOR_INFO);
							}
						}
					}
				}
			}
			break;
		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
			if (workflowHelper.hasFinalApprovedOrRejected(workflow)) {
				throw new ValidationException("Routing can only be applied to open cases.");
			}
			workflowHelper.rfa(workflow, dto.getRouteStatus(), dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;
		}
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TaLicenceFilingExtensionDto getDetails(@PathVariable Integer id) {
		List<AttachmentDto> fileList = new ArrayList<AttachmentDto>();
		TaFilingConditionExtensionAssessment extension = taFilingExtensionsRepository.get(TaFilingConditionExtensionAssessment.class, id);

		TaLicenceFilingExtensionDto resultDto = TaLicenceFilingExtensionDto.buildFromExtension(cacheHelper, extension, new TaLicenceFilingExtensionDto(), extension.getWorkflow().getLicence(),
				workflowHelper);

		List<AttachmentDto> reqFileList = new ArrayList<AttachmentDto>();
		fileList = taFilingExtensionsRepository.getFiles(resultDto.getWorkflowId(), fileHelper);
		reqFileList = taFilingExtensionsRepository.getSupportingDocList(docTypeList, fileHelper); /* to define which supporting Doc are required */

		resultDto.setFiles(fileHelper.addFilesNotIncluded(fileList, reqFileList));
		List<TaLicenceFilingExtensionDateDto> pastExtensionsDto = new ArrayList<TaLicenceFilingExtensionDateDto>();
		for (TaFilingConditionExtension row : extension.getTaFilingConditionExtensions()) {
			List<TaFilingConditionExtension> pastExtensions = taFilingExtensionsRepository.getExtensionDates(row.getTaFilingCondition().getId());
			for (TaFilingConditionExtension pastExtension : pastExtensions) {
				if (pastExtension.getTaFilingConditionExtensionAssessment() == null) {
					pastExtensionsDto.add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(pastExtension, new TaLicenceFilingExtensionDateDto()));
				}
			}
		}
		resultDto.setPastExtensionDates(pastExtensionsDto);
		return resultDto;
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = taFilingExtensionsRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private List<TaFilingConditionExtension> updateDateFromDto(TaFilingConditionExtensionAssessment extensionModel, List<TaLicenceFilingExtensionDateDto> extensionDates) {
		List<TaFilingConditionExtension> dates = new ArrayList<TaFilingConditionExtension>();
		for (TaLicenceFilingExtensionDateDto row : extensionDates) {
			if (row.getExtendedDueDate() != null) {
				TaFilingConditionExtension date;
				if (row.getExtensionDateId() != null) {
					date = taFilingExtensionsRepository.get(TaFilingConditionExtension.class, row.getExtensionDateId());
				} else {
					date = new TaFilingConditionExtension();
				}
				date.setExtendedDueDate(row.getExtendedDueDate());
				date.setTaFilingCondition(taFilingExtensionsRepository.get(TaFilingCondition.class, row.getAnnualFilingId()));
				date.setToProceed(row.getToExtend());
				date.setTaFilingConditionExtensionAssessment(extensionModel);
				date.setToProceed(row.getToExtend());
				dates.add(date);
			}
		}
		return dates;
	}

	private TaFilingConditionExtensionAssessment updateExtensionFromDto(TaFilingConditionExtensionAssessment extensionModel, TaLicenceFilingExtensionDto dto) {
		extensionModel.setReason(dto.getReason());
		extensionModel.setRiskAssessment(dto.getRiskAssessment());
		if (dto.getAssessedAaId() != null) {
			extensionModel.setAssessedAa(taFilingExtensionsRepository.get(TaAaSubmission.class, dto.getAssessedAaId()));
		}
		if (dto.getAssessedAa2Id() != null) {
			extensionModel.setAssessedAa2(taFilingExtensionsRepository.get(TaAaSubmission.class, dto.getAssessedAa2Id()));
		}
		if (dto.getAssessedAbprId() != null) {
			extensionModel.setAssessedAbpr(taFilingExtensionsRepository.get(TaAbprSubmission.class, dto.getAssessedAbprId()));
		}
		extensionModel.setHasConsecutiveLosses(cache.getType(dto.getHasConsecutiveLosses().getKey().toString()));
		extensionModel.setConsecutiveLossesRemarks(dto.getConsecutiveLossesRemarks());
		extensionModel.setHasShortfallExceeded(cache.getType(dto.getHasShortfallExceeded().getKey().toString()));
		extensionModel.setShortfallExceededLossesRemarks(dto.getShortfallExceededLossesRemarks());
		extensionModel.setIsCurrentRatioLessThanOne(cache.getType(dto.getIsCurrentRatioLessThanOne().getKey().toString()));
		extensionModel.setIsCurrentRatioLessRemarks(dto.getIsCurrentRatioLessRemarks());
		extensionModel.setInboundOutboundRisk(dto.getInboundOutboundRisk());
		extensionModel.setSalesTurnoverRisk(dto.getSalesTurnoverRisk());
		extensionModel.setAmtOwedByDirRisk(dto.getAmtOwedByDirRisk());
		extensionModel.setLitigationSuitRisk(dto.getLitigationSuitRisk());
		extensionModel.setCpfArrearsRisk(dto.getLitigationSuitRisk());
		extensionModel.setNonDeliveryRisk(dto.getNonDeliveryRisk());
		extensionModel.setManagerAssessment(dto.getManagerAssessment());
		return extensionModel;
	}
}
