package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaLicenceMaRequestDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaLicenceRenewalExerciseGroupDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaLicenceRenewalExerciseParticipantDto;
import gov.stb.tag.dto.ta.licenceRenewalExercise.TaRenewalTaSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceRenewal;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaLicenceRenewalExerciseParam;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.CsvUtil;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/renewal-exercise")
@Transactional
public class TaManageRenewalExerciseController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	private static final Integer BATCH_COMMIT_INTERVAL = 100;

	@Autowired
	TaRenewalRepository taRenewalRepository;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	CacheHelper cacheHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	TaNetValueShortfallRepository shortRepo;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	protected Properties properties;

	protected static final String[] CONTENT_HEADERS = new String[] { "S/No.", "TA Number", "UEN ", "Licence Type", "TA Name", "License Status", "Gender", "KE Name", "Block No", "Street Name",
			"Level No", "Unit No", "Building Name", "Postal Code", "Tel", "Mobile", "KE Email", "Company Email", "Licence Issued Date", "FY End", "Audited accounts 1", "Netvalue 1",
			"Netvalue fulfilment 1", "Audited accounts 2", "Netvalue 2", "Netvalue fulfilment 2", "Management accounts", "MA Netvalue", "MA Netvalue fulfilment", "ABPR 1", "ABPR 2",
			"Outstanding Payments", "Renewal Type", "Renewal Status", "Baselined Name", "Baselined KE", "Baselined FYE", "Baselined Outstanding Payment" };

	@RequestMapping(method = RequestMethod.POST, value = "/export-list")
	public void exportRenewalExerciseList(@RequestBody TaRenewalTaSearchDto searchDto, HttpServletResponse response) throws IOException, ParseException {
		List<TaLicenceRenewalExerciseParticipantDto> recordList = new ArrayList<TaLicenceRenewalExerciseParticipantDto>();

		TaLicenceRenewalExercise renewalExercise = taRenewalRepository.get(TaLicenceRenewalExercise.class, searchDto.getRenewalExerciseId());

		if (renewalExercise != null) {
			ResultDto<TaLicenceRenewalExerciseTa> result = new ResultDto<TaLicenceRenewalExerciseTa>();
			result = taRenewalRepository.getTaLicenceRenewalExerciseTa(searchDto, false);

			Map<Integer, TaAaSubmission> aaSubmissionMap = Maps.newHashMap();
			Map<Integer, TaAbprSubmission> abprSubmissionMap = Maps.newHashMap();
			Map<Integer, TaMaSubmission> maSubmissionMap = Maps.newHashMap();
			Integer year = properties.year != null ? Integer.parseInt(properties.year) : 0;
			if (result.getModels().size() > 0) {
				// Map aa to annual filing
				for (TaAaSubmission aa : taRenewalRepository.getTaAaSubmissionModelByFyeDate(renewalExercise.getYear(), null)) {
					aaSubmissionMap.put(aa.getTaAnnualFiling().getId(), aa);
				}
				// Map abpr to annual filing
				for (TaAbprSubmission abpr : taRenewalRepository.getTaAbprSubmissionModelByFyeDate(renewalExercise.getYear(), null)) {
					abprSubmissionMap.put(abpr.getTaAnnualFiling().getId(), abpr);
				}
				// Map abpr to annual filing
				for (TaMaSubmission ma : taRenewalRepository.getTaMaSubmissionModelByFyeDate(renewalExercise.getYear(), null)) {
					maSubmissionMap.put(ma.getTaFilingCondition().getId(), ma);
				}
			}
			for (TaLicenceRenewalExerciseTa row : result.getModels()) {
				TaLicenceRenewalExerciseParticipantDto dto = new TaLicenceRenewalExerciseParticipantDto();

				TaLicenceRenewalExerciseParam exerciseParam = taRenewalRepository.getExerciseParam(renewalExercise.getId(), row.getLicence().getId());
				TaLicenceRenewal renewalSubmission = null;
				if (row.getTaLicenceRenewal() != null) {
					renewalSubmission = taRenewalRepository.get(TaLicenceRenewal.class, row.getTaLicenceRenewal().getId());
				}
				dto = TaLicenceRenewalExerciseParticipantDto.buildRenewalParticipantForDto(cacheHelper, row, dto, renewalExercise, aaSubmissionMap, abprSubmissionMap, exerciseParam, renewalSubmission,
						maSubmissionMap, true, year);
				recordList.add(dto);
			}
		}

		logger.info("Start generating csv for ta-renewal-exercise ");
		List<String[]> contents = new ArrayList<>();
		for (int i = 0, j = 0; i < recordList.size(); i++, j = 0) {
			TaLicenceRenewalExerciseParticipantDto dto = recordList.get(i);
			String[] content = new String[CONTENT_HEADERS.length];
			content[j++] = String.valueOf(i + 1);
			content[j++] = "TA" + dto.getLicenceNo();
			content[j++] = dto.getUen();
			content[j++] = dto.getLicenceStatus().getOtherLabel();
			content[j++] = dto.getName();
			content[j++] = dto.getLicenceStatus().getLabel();
			content[j++] = dto.getKeDetails() != null ? dto.getKeDetails().getSex().getLabel() : "";
			content[j++] = dto.getKeyExec() != null ? dto.getKeyExec().getLabel() : "";
			content[j++] = dto.getTaOperatingAddress() != null ? dto.getTaOperatingAddress().getBlock() : "";
			content[j++] = dto.getTaOperatingAddress() != null ? dto.getTaOperatingAddress().getStreet() : "";
			content[j++] = dto.getTaOperatingAddress() != null ? dto.getTaOperatingAddress().getFloor() : "";
			content[j++] = dto.getTaOperatingAddress() != null ? dto.getTaOperatingAddress().getUnit() : "";
			content[j++] = dto.getTaOperatingAddress() != null ? dto.getTaOperatingAddress().getBuilding() : "";
			content[j++] = dto.getTaOperatingAddress() != null ? dto.getTaOperatingAddress().getPostal() : "";
			content[j++] = dto.getKeDetails() != null ? dto.getKeDetails().getContactNo() : "";
			content[j++] = "";
			content[j++] = dto.getKeDetails() != null ? dto.getKeDetails().getEmail() : "";
			content[j++] = dto.getTaDto().getEmailAddress();
			content[j++] = dto.getTaDto().getLicenceIssuedDate();
			content[j++] = dto.getFye().format(DateUtil.DATE_FORMAT);

			content[j++] = dto.getAuditedAccounts(0);
			content[j++] = dto.getAaNetValue(0);
			content[j++] = dto.getAaNetValueFulfilment(0);
			content[j++] = dto.getAuditedAccounts(1);
			content[j++] = dto.getAaNetValue(1);
			content[j++] = dto.getAaNetValueFulfilment(1);
			content[j++] = dto.getMa(0);
			content[j++] = dto.getMaNetValue(0);
			content[j++] = dto.getMaNetValueFulfilment(0);
			content[j++] = dto.getAbpr(0);
			content[j++] = dto.getAbpr(1);
			content[j++] = dto.getOutstandingPayment() != null ? dto.getOutstandingPayment().toString() : "";
			content[j++] = dto.getRenewalType().getLabel();
			content[j++] = dto.getRenewalSubmission() != null ? dto.getRenewalSubmission().getLabel() : "";
			content[j++] = dto.getBaselinedName();
			content[j++] = dto.getBaselinedKe() != null ? dto.getBaselinedKe().getUin() : "";
			content[j++] = dto.getBaselinedFye() != null ? dto.getBaselinedFye().format(DateUtil.DATE_FORMAT) : "";
			content[j++] = dto.getBaselinedOutstandingPayment() != null ? dto.getBaselinedOutstandingPayment().toString() : "";
			contents.add(content);
		}
		logger.info("End generating csv for ta-renewal-exercise ");
		CsvUtil.export(response, CONTENT_HEADERS, contents);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceRenewalExerciseParticipantDto> getTaLicenceRenewalExerciseGroup(TaRenewalTaSearchDto searchDto) {
		// TaLicenceRenewalExerciseGroupDto groupDto = new TaLicenceRenewalExerciseGroupDto();
		ResultDto<TaLicenceRenewalExerciseParticipantDto> resultDto = new ResultDto<TaLicenceRenewalExerciseParticipantDto>();
		Integer year = properties.year != null ? Integer.parseInt(properties.year) : 0;

		TaLicenceRenewalExercise renewalExercise = taRenewalRepository.get(TaLicenceRenewalExercise.class, searchDto.getRenewalExerciseId());
		if (renewalExercise != null) {
			// TaLicenceRenewalExerciseGroupDto.mapModeltoRenewalExerciseGroupDto(cacheHelper, renewalExercise, groupDto, workflowHelper);

			ResultDto<TaLicenceRenewalExerciseTa> result = new ResultDto<TaLicenceRenewalExerciseTa>();
			result = taRenewalRepository.getTaLicenceRenewalExerciseTa(searchDto, true);

			resultDto.setTotal(result.getTotal());
			resultDto.setResult(result.getResult());
			resultDto.setSuccessFlag(result.getSuccessFlag());
			Object[] records = new Object[result.getModels().size()];
			resultDto.setRecords(records);
			int i = 0;

			Map<Integer, TaAaSubmission> aaSubmissionMap = Maps.newHashMap();
			Map<Integer, TaAbprSubmission> abprSubmissionMap = Maps.newHashMap();
			Map<Integer, TaMaSubmission> maSubmissionMap = Maps.newHashMap();
			if (result.getModels().size() > 0) {
				// Map aa to annual filing
				for (TaAaSubmission aa : taRenewalRepository.getTaAaSubmissionModelByFyeDate(renewalExercise.getYear(), null)) {
					aaSubmissionMap.put(aa.getTaAnnualFiling().getId(), aa);
				}
				// Map abpr to annual filing
				for (TaAbprSubmission abpr : taRenewalRepository.getTaAbprSubmissionModelByFyeDate(renewalExercise.getYear(), null)) {
					abprSubmissionMap.put(abpr.getTaAnnualFiling().getId(), abpr);
				}
				// Map ma to annual filing
				for (TaMaSubmission ma : taRenewalRepository.getTaMaSubmissionModelByFyeDate(renewalExercise.getYear(), null)) {
					maSubmissionMap.put(ma.getTaFilingCondition().getId(), ma);
				}
			}

			for (TaLicenceRenewalExerciseTa row : result.getModels()) {
				TaLicenceRenewalExerciseParticipantDto dto = new TaLicenceRenewalExerciseParticipantDto();

				TaLicenceRenewalExerciseParam exerciseParam = taRenewalRepository.getExerciseParam(renewalExercise.getId(), row.getLicence().getId());
				TaLicenceRenewal renewalSubmission = null;
				if (row.getTaLicenceRenewal() != null) {
					renewalSubmission = taRenewalRepository.get(TaLicenceRenewal.class, row.getTaLicenceRenewal().getId());
				}
				dto = TaLicenceRenewalExerciseParticipantDto.buildRenewalParticipantForDto(cacheHelper, row, dto, renewalExercise, aaSubmissionMap, abprSubmissionMap, exerciseParam, renewalSubmission,
						maSubmissionMap, false, year);
				records[i++] = dto;
			}
		}

		return resultDto;
	}

	@RequestMapping(value = "/view/year/dates/{renewalExerciseId}", method = RequestMethod.GET)
	public TaLicenceRenewalExerciseGroupDto getRenewalDatesFromRenewalExerciseId(@PathVariable Integer renewalExerciseId) {
		TaLicenceRenewalExercise renewalExercise = taRenewalRepository.get(TaLicenceRenewalExercise.class, renewalExerciseId);
		TaLicenceRenewalExerciseGroupDto resultDto = getRenewalStatsFromRenewalExerciseId(renewalExercise, new TaLicenceRenewalExerciseGroupDto());
		resultDto = TaLicenceRenewalExerciseGroupDto.mapModeltoRenewalExerciseGroupDto(cacheHelper, renewalExercise, resultDto, workflowHelper);

		return resultDto;
	}

	private TaLicenceRenewalExerciseGroupDto getRenewalStatsFromRenewalExerciseId(TaLicenceRenewalExercise renewalExercise, TaLicenceRenewalExerciseGroupDto resultDto) {

		resultDto.setSnapshotAsatDate(renewalExercise.getRefreshedDate());
		Long totalLicence = taRenewalRepository.getTaDueForRenewalCount(renewalExercise.getYear());
		resultDto.setTotalLicence(totalLicence == null ? null : Math.toIntExact(totalLicence));

		Long totalLicenceCust = taRenewalRepository.getTaLicenceRenewalTypeCount(Codes.TaRenewalTypes.TA_RENEW_CUSTOMISED, renewalExercise.getId());
		Long totalLicenceExpress = taRenewalRepository.getTaLicenceRenewalTypeCount(Codes.TaRenewalTypes.TA_RENEW_EXPRESS, renewalExercise.getId());

		Long totalRenewed = taRenewalRepository.getTaRenewalCount(Boolean.TRUE, renewalExercise.getId());
		Long totalNotRenewed = taRenewalRepository.getTaRenewalCount(Boolean.FALSE, renewalExercise.getId());

		resultDto.setTotalCustomised(totalLicenceCust == null ? null : Math.toIntExact(totalLicenceCust));
		resultDto.setTotalExpress(totalLicenceExpress == null ? null : Math.toIntExact(totalLicenceExpress));
		resultDto.setTotalRenewed(totalRenewed == null ? null : Math.toIntExact(totalRenewed));
		resultDto.setTotalNotRenewed(totalNotRenewed == null ? null : Math.toIntExact(totalNotRenewed));

		/*
		 * Map<String, Integer> liceneStatuses = Maps.newHashMap(); for (Object a : Codes.TaStatuses.RENEWAL_ACTIVE) { Long count = taRenewalRepository.getTaLicenceRenewalStatusCount(a.toString(),
		 * renewalExercise.getId()); liceneStatuses.put(a.toString(), count == null ? null : Math.toIntExact(count)); }
		 */
		List<ListableDto> totalLicenceByStatusList = taRenewalRepository.getTaLicenceRenewalStatusesCount(renewalExercise.getId());

		// for the requirement to be able to display count zero for Number of Ceased if there is no Ceased licence
		ListableDto totalLicenceByStatus = totalLicenceByStatusList.stream().filter(totLicByStatus -> Codes.Statuses.TA_CEASED.equals(totLicByStatus.getKey())).findAny().orElse(null);
		if (totalLicenceByStatus == null) {
			totalLicenceByStatusList.add(new ListableDto(Codes.Statuses.TA_CEASED, cache.getStatus(Codes.Statuses.TA_CEASED).getLabel(), null, 0, null));
		}
		//

		resultDto.setTotalLicenceByStatus(totalLicenceByStatusList);
		return resultDto;
	}

	@RequestMapping(value = "/view/years", method = RequestMethod.GET)
	public List<ListableDto> getRenewalYears() {
		List<TaLicenceRenewalExercise> renewalExercises = taRenewalRepository.getRenewalYears();
		List<ListableDto> results = new ArrayList<>();
		Integer currentYear = LocalDate.now().getYear();
		// currentYear = LocalDate.of(2021, 1, 10).getYear();

		if (renewalExercises.size() == 0 || (renewalExercises.size() > 0 && renewalExercises.get(0).getYear() < currentYear)) {
			TaLicenceRenewalExercise currentExercise = new TaLicenceRenewalExercise();
			currentExercise = taRenewalRepository.updateRenewalExercise(currentExercise, null, currentYear, cacheHelper, workflowHelper);
			taRenewalRepository.saveOrUpdate(currentExercise);
			renewalExercises.add(0, currentExercise);

		}

		if (renewalExercises != null) {
			for (TaLicenceRenewalExercise renewalExercise : renewalExercises) {
				results.add(new ListableDto(renewalExercise.getId(), renewalExercise.getYear().toString()));
				if (taRenewalRepository.getRenewalExerciseNotRejectedByYear(renewalExercise.getYear()).size() == 0) {
					if (taRenewalRepository.getRenewalExerciseFromYear(renewalExercise.getYear()) == null) {
						TaLicenceRenewalExercise currentExercise = new TaLicenceRenewalExercise();
						currentExercise = taRenewalRepository.updateRenewalExercise(currentExercise, null, currentYear, cacheHelper, workflowHelper);
						taRenewalRepository.saveOrUpdate(currentExercise);
						results.add(0, new ListableDto(currentExercise.getId(), currentExercise.getYear().toString()));
					}

				}

			}
		}
		return results;
	}

	@RequestMapping(path = { "/save/exercise-dates", }, method = RequestMethod.GET)
	public Boolean saveRenewalExercise(TaLicenceRenewalExerciseGroupDto dto) throws IOException {
		if (dto != null) {
			TaLicenceRenewalExercise currentExercise = taRenewalRepository.get(TaLicenceRenewalExercise.class, dto.getRenewalExerciseId());
			taRenewalRepository.updateRenewalExercise(currentExercise, dto, null, cacheHelper, workflowHelper);
			if (currentExercise.isRefreshing() && currentExercise.getUpdatedDate().plusMinutes(10).isAfter(LocalDateTime.now())) {
				return Boolean.FALSE; // Do not re-populate data if it is populating in progress comparing the updated time 10mins before
			} else {
				currentExercise.setIsRefreshing(Boolean.TRUE);
				taRenewalRepository.saveOrUpdate(currentExercise);
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}

	@RequestMapping(path = { "/view/ma-require", }, method = RequestMethod.GET)
	public TaLicenceMaRequestDto getMaRequire(TaRenewalTaSearchDto dto) throws IOException {
		TaLicenceMaRequestDto dtoResult = new TaLicenceMaRequestDto();
		if (dto != null) {
			TaLicenceRenewalExerciseParam exerciseParam = taRenewalRepository.getExerciseParam(dto.getRenewalExerciseId(), dto.getLicenceId());
			if (exerciseParam == null) {
				dtoResult = TaLicenceMaRequestDto.buildRequestMaDto(null, dtoResult, dto.getLicenceId(), dto.getRenewalExerciseId(), dto.getRenewalExerciseTaId(),
						taRenewalRepository.get(TaLicenceRenewalExercise.class, dto.getRenewalExerciseId()), taRenewalRepository.get(TaLicenceRenewalExerciseTa.class, dto.getRenewalExerciseTaId()));
			} else {
				dtoResult = TaLicenceMaRequestDto.buildRequestMaDto(exerciseParam, dtoResult, dto.getLicenceId(), dto.getRenewalExerciseId(), dto.getRenewalExerciseTaId(), null, null);
			}

		}
		return dtoResult;
	}

	@RequestMapping(path = { "/save/ma-require", }, method = RequestMethod.POST)
	public void saveMaRequire(@RequestBody TaLicenceMaRequestDto dto) throws IOException {
		if (dto != null) {
			TaLicenceRenewalExerciseParam exerciseParam = taRenewalRepository.getExerciseParam(dto.getRenewalExerciseId(), dto.getLicenceId());
			if (exerciseParam == null) {
				exerciseParam = new TaLicenceRenewalExerciseParam();
			}
			exerciseParam.setIsMaRequiredByUser(Boolean.valueOf(dto.getIsRequireMa()));
			if (exerciseParam.isMaRequiredByUser()) {
				exerciseParam.setRequestedMaAsAtDate(dto.getRequestedMaAsAtDate());
				if (dto.getMaSubmissionDueDate() != null) {
					exerciseParam.setMaSubmissionDueDate(dto.getMaSubmissionDueDate());
				} else {
					exerciseParam.setMaSubmissionDueDate(taRenewalRepository.get(Licence.class, dto.getLicenceId()).getExpiryDate());
				}

			}
			exerciseParam.setLicence(taRenewalRepository.get(Licence.class, dto.getLicenceId()));
			exerciseParam.setTaLicenceRenewalExercise(taRenewalRepository.get(TaLicenceRenewalExercise.class, dto.getRenewalExerciseId()));
			taRenewalRepository.save(exerciseParam);

			TaLicenceRenewalExerciseTa renewalTa = taRenewalRepository.getTaLicenceRenewalExerciseTa(dto.getRenewalExerciseId(), dto.getLicenceId(), null);
			renewalTa.setIsMaVoid(Boolean.FALSE);
			taRenewalRepository.save(renewalTa);
		}
	}

	@RequestMapping(path = { "/save/populate-exercise-tas/{renewalExerciseId}", }, method = RequestMethod.GET)
	public TaLicenceRenewalExerciseGroupDto saveRenewalExerciseTas(@PathVariable Integer renewalExerciseId) throws IOException {
		if (renewalExerciseId != null) {
			TaLicenceRenewalExercise renewalExercise = taRenewalRepository.get(TaLicenceRenewalExercise.class, renewalExerciseId);
			TaLicenceRenewalExerciseGroupDto resultDto = TaLicenceRenewalExerciseGroupDto.mapModeltoRenewalExerciseGroupDto(cacheHelper, renewalExercise, new TaLicenceRenewalExerciseGroupDto(),
					workflowHelper);
			populateTaLicenceRenewalExerciseTas(renewalExercise);
			renewalExercise.setIsRefreshing(Boolean.FALSE);
			renewalExercise.setRefreshedDate(LocalDateTime.now());
			taRenewalRepository.saveOrUpdate(renewalExercise);

			resultDto = getRenewalStatsFromRenewalExerciseId(renewalExercise, resultDto);
			return resultDto;
		}
		return null;
	}

	// to approve, reject, RFA
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaLicenceRenewalExercise renewalExercise = taRenewalRepository.get(TaLicenceRenewalExercise.class, id);
		if (renewalExercise.getWorkflow() == null) {
			renewalExercise.setWorkflow(workflowHelper.saveNewWorkflow(Codes.Workflow.TA_WKFLW_RENEW_EX, null, null, null, Boolean.FALSE, null));
		}
		Workflow workflow = renewalExercise.getWorkflow();
		switch (action) {
		case ACTION_APPROVE:
			if (workflow.getLastAction() == null) {
				workflowHelper.forward(workflow, Boolean.TRUE, dto.getInternalRemarks(), null, null, null);
			} else {
				workflowHelper.forward(workflow, Boolean.FALSE, dto.getInternalRemarks(), null, null, null);
				if (workflowHelper.hasFinalApproved(workflow)) {
					// set renewal exercie to baselined
					baselineRenewalExercise(renewalExercise);
				}
			}
			break;
		case ACTION_REJECT:
			workflowHelper.reject(workflow, dto.getInternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
			if (workflowHelper.hasFinalApprovedOrRejected(workflow)) {
				throw new ValidationException("Routing can only be applied to open cases.");
			}
			workflowHelper.rfa(workflow, dto.getRouteStatus(), dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;
		}
	}

	private void populateTaLicenceRenewalExerciseTas(TaLicenceRenewalExercise exerciseModel) {
		Integer yearOfRenewalExercise = exerciseModel.getYear();
		LocalDate fyeCutOffDate = exerciseModel.getFyeCutOffDate();

		Integer nicheCriteria = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_RENEWAL_SHORTFALL_NICHE).getValue());
		Integer generalCriteria = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_RENEWAL_SHORTFALL_GENERAL).getValue());

		// Map the KE
		Map<String, TaStakeholder> keNameByLicenceNo = Maps.newHashMap();
		for (TaStakeholder tas : taRenewalRepository.getKeyExecutivesForTaDueForRenewal(yearOfRenewalExercise)) {
			if (!keNameByLicenceNo.containsKey(tas.getLicence().getLicenceNo())) {
				keNameByLicenceNo.put(tas.getLicence().getLicenceNo(), tas);
			}
		}

		// Map the outstanding payment
		Map<String, BigDecimal> outstandingPaymentByUen = Maps.newHashMap();
		for (ListableDto paymentAmountDto : taRenewalRepository.getTaOutstandingPayments()) {
			if (!outstandingPaymentByUen.containsKey(paymentAmountDto.getKey())) {
				outstandingPaymentByUen.put(paymentAmountDto.getKey().toString(), (BigDecimal) paymentAmountDto.getData());
			}
		}

		// Map the AA Annual Filing
		Map<String, List<TaFilingCondition>> aaFilingByLicenceNo = Maps.newHashMap();
		for (TaFilingCondition aa : taRenewalRepository.getTaAaFilingByFyeDate(yearOfRenewalExercise)) {
			if (!aaFilingByLicenceNo.containsKey(aa.getLicence().getLicenceNo())) {
				aaFilingByLicenceNo.put(aa.getLicence().getLicenceNo(), Lists.newArrayList());
			}
			if (aaFilingByLicenceNo.get(aa.getLicence().getLicenceNo()).size() < 2) { // check past 2 only
				if (Objects.equals(aa.getStatus().getCode(), Codes.Statuses.TA_FILING_APPROVED)) {
					aaFilingByLicenceNo.get(aa.getLicence().getLicenceNo()).add(aa);
				} else if (!aa.getFyEndDate().isAfter(fyeCutOffDate)) {
					aaFilingByLicenceNo.get(aa.getLicence().getLicenceNo()).add(aa);
				} else {
					logger.info("Licence no: {} - Skip AA Filing for fye {}", aa.getLicence().getLicenceNo(), aa.getFyEndDate());
				}
			}
		}

		// Map the ABPR Annual Filing
		Map<String, List<TaFilingCondition>> abprFilingByLicenceNo = Maps.newHashMap();
		for (TaFilingCondition abpr : taRenewalRepository.getTaAbprFilingByFyeDate(yearOfRenewalExercise)) {
			if (!abprFilingByLicenceNo.containsKey(abpr.getLicence().getLicenceNo())) {
				abprFilingByLicenceNo.put(abpr.getLicence().getLicenceNo(), Lists.newArrayList());
			}
			if (abprFilingByLicenceNo.get(abpr.getLicence().getLicenceNo()).size() < 2) {
				if (Objects.equals(abpr.getStatus().getCode(), Codes.Statuses.TA_FILING_APPROVED)) {
					abprFilingByLicenceNo.get(abpr.getLicence().getLicenceNo()).add(abpr);
				} else if (!abpr.getFyEndDate().isAfter(fyeCutOffDate)) {
					abprFilingByLicenceNo.get(abpr.getLicence().getLicenceNo()).add(abpr);
				} else {
					logger.info("Licence no: {} - Skip ABPR Filing for fye {}", abpr.getLicence().getLicenceNo(), abpr.getFyEndDate());
				}
			}
		}

		// Map the Ad-hoc MA Filing
		Map<String, List<TaFilingCondition>> adhocMaFilingByLicenceNo = Maps.newHashMap();
		for (TaFilingCondition adhocMa : taRenewalRepository.getTaAdhocMaFilingByFyeDate(yearOfRenewalExercise, exerciseModel.getStartDate())) {
			if (!adhocMaFilingByLicenceNo.containsKey(adhocMa.getLicence().getLicenceNo())) {
				adhocMaFilingByLicenceNo.put(adhocMa.getLicence().getLicenceNo(), Lists.newArrayList());
			}
			if (adhocMaFilingByLicenceNo.get(adhocMa.getLicence().getLicenceNo()).size() < 1) {
				adhocMaFilingByLicenceNo.get(adhocMa.getLicence().getLicenceNo()).add(adhocMa);
			}
		}

		// Map the MA Filing
		Map<String, List<TaFilingCondition>> maFilingByLicenceNo = Maps.newHashMap();
		for (TaFilingCondition maFiing : taRenewalRepository.getTaMaFilingByFyeDate(yearOfRenewalExercise, exerciseModel.getStartDate())) {
			if (!maFilingByLicenceNo.containsKey(maFiing.getLicence().getLicenceNo())) {
				maFilingByLicenceNo.put(maFiing.getLicence().getLicenceNo(), Lists.newArrayList());
			}
			if (maFilingByLicenceNo.get(maFiing.getLicence().getLicenceNo()).size() < 1) {
				maFilingByLicenceNo.get(maFiing.getLicence().getLicenceNo()).add(maFiing);
			}
		}

		// Map the approved AA Submission
		Map<String, List<TaAaSubmission>> aaSubmissionByLicenceNo = Maps.newHashMap();
		for (TaAaSubmission aa : taRenewalRepository.getTaAaSubmissionModelByFyeDate(yearOfRenewalExercise, Statuses.TA_APP_APPROVED)) {
			if (!aaSubmissionByLicenceNo.containsKey(aa.getApplication().getLicence().getLicenceNo())) {
				aaSubmissionByLicenceNo.put(aa.getApplication().getLicence().getLicenceNo(), Lists.newArrayList(aa));
			} else {
				aaSubmissionByLicenceNo.get(aa.getApplication().getLicence().getLicenceNo()).add(aa);
			}
		}

		// Map the AA shortfalls
		Map<Integer, TaNetValueShortfall> shortfallByAaFilingId = Maps.newHashMap();
		for (TaNetValueShortfall shortfall : taRenewalRepository.getApprovedTaShortfallModelByFyeDate(yearOfRenewalExercise, Codes.ApplicationTypes.TA_APP_AA_SUBMISSION)) {
			shortfallByAaFilingId.put(shortfall.getTaAaSubmission().getTaAnnualFiling().getId(), shortfall);
		}

		// Map the MA shortfalls
		Map<Integer, TaNetValueShortfall> shortfallByMaFilingId = Maps.newHashMap();
		for (TaNetValueShortfall shortfall : taRenewalRepository.getApprovedTaShortfallModelByFyeDate(yearOfRenewalExercise, Codes.ApplicationTypes.TA_APP_MA_SUBMISSION)) {
			shortfallByMaFilingId.put(shortfall.getTaMaSubmission().getTaFilingCondition().getId(), shortfall);
		}
		for (TaNetValueShortfall shortfall : taRenewalRepository.getApprovedTaShortfallModelByFyeDate(yearOfRenewalExercise, Codes.ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION)) {
			shortfallByMaFilingId.put(shortfall.getTaMaSubmission().getTaFilingCondition().getId(), shortfall);
		}

		List<Licence> allTaDueForRenewal = taRenewalRepository.getTaLicencesDueForRenewal(yearOfRenewalExercise);

		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH);
		int date = Calendar.getInstance().get(Calendar.DATE);

		for (int i = 0; i < allTaDueForRenewal.size(); i++) {
			Licence taBasic = allTaDueForRenewal.get(i);

			if (taBasic.getLicenceNo().equals("03365N")) {
				String olala = "";
				olala = olala + "";
			}

			TaLicenceRenewalExerciseTa participant = taRenewalRepository.getTaLicenceRenewalExerciseTa(exerciseModel.getId(), taBasic.getId(), Boolean.FALSE);
			if (participant == null) {
				participant = new TaLicenceRenewalExerciseTa();
			} else {
				if (!exerciseModel.hasBaselined() && participant.getLicence().getStatus().getCode().equalsIgnoreCase(Statuses.TA_CEASED)) {
					taRenewalRepository.delete(participant);
					break;
				}
			}

			boolean isExpress = true;

			participant.setTaLicenceRenewalExercise(exerciseModel);
			participant.setLicence(taBasic);
			participant.setKe(keNameByLicenceNo.get(taBasic.getLicenceNo()));
			participant.setFye(taBasic.getTravelAgent().getFyeDate());
			participant.setOutstandingPayment(outstandingPaymentByUen.get(taBasic.getTravelAgent().getUen()));

			if (adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo()) != null && !adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo()).isEmpty()) {
				if (adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo()).size() > 0 && adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0) != null) {
					// participant.setMaFilingCondition(adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0)); //temp
				}
			} else {
				if (maFilingByLicenceNo.get(taBasic.getLicenceNo()) != null && !maFilingByLicenceNo.get(taBasic.getLicenceNo()).isEmpty()) {
					if (maFilingByLicenceNo.get(taBasic.getLicenceNo()).size() > 0 && maFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0) != null) {
						// participant.setMaFilingCondition(maFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0)); // temp
					}
				} else {
					// participant.setMaFilingCondition(null); // temp
				}
			}

			if (aaFilingByLicenceNo.get(taBasic.getLicenceNo()) != null && !aaFilingByLicenceNo.get(taBasic.getLicenceNo()).isEmpty()) {

				// if licence issue date before fy cr 1227
				LocalDate dt = taBasic.getIssueDate().plusYears(1);
				LocalDate dt2 = LocalDate.of(year, 3, 31);
				boolean tf = taBasic.getIssueDate().plusYears(1).isBefore(LocalDate.of(year, 3, 31));

				if (taBasic.getIssueDate().plusYears(1).isBefore(LocalDate.of(year, 3, 31)) == true) {
					if (aaFilingByLicenceNo.get(taBasic.getLicenceNo()).size() > 0 && aaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0) != null) {
						participant.setTaAaFilingCondition1(aaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0));
						if (shortfallByAaFilingId.get(aaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0).getId()) != null) {
							participant.setTaNetValueShortfallAa1(shortfallByAaFilingId.get(participant.getTaAaFilingCondition1().getId()));
						}
					} else {
						participant.setTaAaFilingCondition1(null);
					}
					if (aaFilingByLicenceNo.get(taBasic.getLicenceNo()).size() > 1 && aaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(1) != null) {
						participant.setTaAaFilingCondition2(aaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(1));
						if (shortfallByAaFilingId.get(aaFilingByLicenceNo.get(taBasic.getLicenceNo()).get(1).getId()) != null) {
							participant.setTaNetValueShortfallAa2(shortfallByAaFilingId.get(participant.getTaAaFilingCondition2().getId()));
						}
					} else {
						participant.setTaAaFilingCondition2(null);
					}
				}

			} else {
				participant.setTaAaFilingCondition1(null);
				participant.setTaAaFilingCondition2(null);
			}

			if (abprFilingByLicenceNo.get(taBasic.getLicenceNo()) != null && !abprFilingByLicenceNo.get(taBasic.getLicenceNo()).isEmpty()) {
				if (abprFilingByLicenceNo.get(taBasic.getLicenceNo()).size() > 0 && abprFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0) != null) {
					participant.setTaAbprFilingCondition1(abprFilingByLicenceNo.get(taBasic.getLicenceNo()).get(0));
				} else {
					participant.setTaAbprFilingCondition1(null);
				}
				if (abprFilingByLicenceNo.get(taBasic.getLicenceNo()).size() > 1 && abprFilingByLicenceNo.get(taBasic.getLicenceNo()).get(1) != null) {
					participant.setTaAbprFilingCondition2(abprFilingByLicenceNo.get(taBasic.getLicenceNo()).get(1));
				} else {
					participant.setTaAbprFilingCondition2(null);
				}
			} else {
				participant.setTaAbprFilingCondition1(null);
				participant.setTaAbprFilingCondition2(null);
			}
			// participant.setIsMaRequired(Boolean.FALSE);
			// Check if Ta has fulfilled all the AA submissions

			List<TaFilingCondition> aaFilingByLicenceNoList = aaFilingByLicenceNo.get(taBasic.getLicenceNo());
			if (CollectionUtils.isNotEmpty(aaFilingByLicenceNoList)) {

				for (TaFilingCondition aa : aaFilingByLicenceNoList) {
					if (!aa.getStatus().getCode().equals(Codes.Statuses.TA_FILING_APPROVED)) {
						isExpress = false;
					} else {
						// if one of the AA has shortfall, but not fulfil net value
						for (TaAaSubmission aaSubmission : aa.getTaAaSubmission()) {
							if (aaSubmission.getShortfall() != null && aaSubmission.getShortfall().compareTo(BigDecimal.ZERO) > 0) {
								if (shortfallByAaFilingId.get(aaSubmission.getTaAnnualFiling().getId()) != null) {

									int test = aaSubmission.getTaAnnualFiling().getId();
									TaNetValueRectification taNetValueRectification = shortfallByAaFilingId.get(aaSubmission.getTaAnnualFiling().getId()).getTaNetValueRectification();

									if (taNetValueRectification == null) {
										isExpress = false;
									}
								}
							}
						}
					}
				}
			} else {

				/*
				 * logger.info("AA filing for licence no: {} is empty", taBasic.getLicenceNo()); isExpress = false; if (CollectionUtils.isEmpty(adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo()))) {
				 * participant.setIsMaRequired(Boolean.TRUE); // No AA due, and no ad-hoc MA requested, require MA to be submitted }
				 */
			}

			// Check if Ta has fulfilled all the ABPR submissions

			if (CollectionUtils.isNotEmpty(abprFilingByLicenceNo.get(taBasic.getLicenceNo()))) {
				for (TaFilingCondition abpr : abprFilingByLicenceNo.get(taBasic.getLicenceNo())) {
					// if (abpr.getStatus().getCode().equals(Codes.Statuses.TA_FILING_PEND_SUBMISSION)) {
					if (abpr.getStatus().getCode().equals(Codes.Statuses.TA_FILING_PEND_SUBMISSION) || !abpr.getStatus().getCode().equals(Codes.Statuses.TA_FILING_APPROVED)) {
						isExpress = false;
					}
				}
			} else {
				logger.info("ABPR filing for licence no: {} is empty", taBasic.getLicenceNo());
				isExpress = false;
			}

			// Check if require MA
			/**
			 * if (!participant.isMaRequired() && CollectionUtils.isEmpty(adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo())) && (participant.getIsMaVoid() != null && !participant.getIsMaVoid())) {
			 * logger.info("Licence no: {} - Checking if require MA", taBasic.getLicenceNo());
			 * 
			 * int criteriaMetCount = 0; List<TaAaSubmission> aaSubmissions = aaSubmissionByLicenceNo.get(taBasic.getLicenceNo());
			 * 
			 * if (CollectionUtils.isNotEmpty(aaSubmissions)) {
			 * 
			 * // Criteria 1: TA has 2 years of netProfitLoss? int netProfitLossCount = 0; for (int index = 0; index < 2 && index < aaSubmissions.size(); index++) { if
			 * (aaSubmissions.get(index).getNetProfitLoss() != null && aaSubmissions.get(index).getNetProfitLoss().compareTo(BigDecimal.ZERO) < 0) { netProfitLossCount++; } }
			 * 
			 * if (netProfitLossCount >= 2) { logger.info("Licence no: {} - Has 2 years netProfitLossCount", taBasic.getLicenceNo()); criteriaMetCount += 1; }
			 * 
			 * // Criteria 2: Shortfall > 30K (general) 15K (niche)? if (aaSubmissions.get(0).getShortfall() != null && shortfallByAaFilingId.get(aaSubmissions.get(0).getTaAnnualFiling().getId()) !=
			 * null && shortfallByAaFilingId.get(aaSubmissions.get(0).getTaAnnualFiling().getId()).getTaNetValueRectification() != null && aaSubmissions.get(0).getShortfall().compareTo(new
			 * BigDecimal(taBasic.getTier().getCode().equalsIgnoreCase(Types.TA_TIER_NICHE) ? nicheCriteria : generalCriteria)) > 0) { logger.info("Licence no: {} - shortfall > {}",
			 * taBasic.getTier().getCode().equalsIgnoreCase(Types.TA_TIER_NICHE) ? nicheCriteria : generalCriteria, taBasic.getLicenceNo()); criteriaMetCount += 1; }
			 * 
			 * // Criteria 3: Current Ratio < 1? BigDecimal currentRatio = BigDecimal.ZERO; if (!Objects.isNull(aaSubmissions.get(0).getCurrentAssets()) &&
			 * !Objects.isNull(aaSubmissions.get(0).getCurrentLiabilities()) && aaSubmissions.get(0).getCurrentLiabilities().compareTo(BigDecimal.ZERO) != 0) { currentRatio =
			 * aaSubmissions.get(0).getCurrentAssets().divide(aaSubmissions.get(0).getCurrentLiabilities(), 2, RoundingMode.HALF_UP); if (currentRatio.compareTo(BigDecimal.ONE) < 0) {
			 * logger.info("Licence no: {} - Current Ratio < 1", taBasic.getLicenceNo()); criteriaMetCount += 1; } }
			 * 
			 * } else { logger.info("Licence no: {} - No AA submitted", taBasic.getLicenceNo()); }
			 * 
			 * if (criteriaMetCount >= 2) { participant.setIsMaRequired(Boolean.TRUE); } }
			 **/

			if (participant.isMaRequired() && CollectionUtils.isNotEmpty(adhocMaFilingByLicenceNo.get(taBasic.getLicenceNo())) && participant.getMaFilingCondition() == null) {
				// participant.setIsMaRequired(Boolean.FALSE); // temp
			}

			// CR1227
			if (participant != null && participant.getTaNetValueShortfallMa1() != null) {
				// participant.setIsMaRequired(Boolean.TRUE); // temp
			}

			if (participant.isMaRequired()) {
				isExpress = Boolean.FALSE;
			}

			if (!exerciseModel.hasBaselined()) {
				if (isExpress && Objects.isNull(outstandingPaymentByUen.get(taBasic.getTravelAgent().getUen())) && !Objects.isNull(keNameByLicenceNo.get(taBasic.getLicenceNo()))) {
					participant.setType(cacheHelper.getType(Codes.TaRenewalTypes.TA_RENEW_EXPRESS));
				} else {
					participant.setType(cacheHelper.getType(Codes.TaRenewalTypes.TA_RENEW_CUSTOMISED));
				}
			} else {

				if (participant.getMaFilingCondition() != null && participant.getMaFilingCondition().getTaMaSubmission() != null) {
					if (shortfallByMaFilingId.get(participant.getMaFilingCondition().getId()) != null) {
						participant.setTaNetValueShortfallMa1(shortfallByMaFilingId.get(participant.getMaFilingCondition().getId()));
					}

				}
				TaLicenceRenewalExerciseParam param = taRenewalRepository.getExerciseParam(exerciseModel.getId(), participant.getLicence().getId());
				if (((participant.isMaRequired() && param == null) || (param != null && param.isMaRequiredByUser())) && participant.getMaFilingCondition() == null) {
					// Add Ma filing
					TaFilingCondition ma = new TaFilingCondition();
					if (participant.getMaFilingCondition() != null) {
						ma = participant.getMaFilingCondition();
					}

					// ma = setMaCondtions(ma, exerciseModel, param, participant); //temp
					// taRenewalRepository.save(ma); //temp
					// participant.setMaFilingCondition(ma); //temp
				}

			}

			// if licence issue date before fy cr 1227
			// boolean issueDate = taBasic.getIssueDate().plusYears(1).isBefore(LocalDate.of(year, 3, 31));
			boolean isMaRequired = false;
			List<TaLicenceRenewalExerciseTa> noOfExercise = taRenewalRepository.getTaLicenceRenewalExerciseTaByLicenceId(participant.getLicence().getId());
			if (noOfExercise != null && noOfExercise.size() > 0) {
				if (noOfExercise.get(noOfExercise.size() - 1).getTaAaFilingCondition1() == null && noOfExercise.get(noOfExercise.size() - 1).getTaAaFilingCondition2() == null) {
					isMaRequired = true;
				}
			}

			if (taBasic.getLicenceNo().equals("03413")) {
				String olala = "";
				olala = olala + "";
			}

			if (isMaRequired == true) {
				if (participant.getMaFilingCondition() == null) {
					TaLicenceRenewalExerciseParam param = taRenewalRepository.getExerciseParam(exerciseModel.getId(), participant.getLicence().getId());
					TaFilingCondition ma = new TaFilingCondition();

					if (participant.getMaFilingCondition() != null) {
						ma = participant.getMaFilingCondition();
					}

					// ma = setMaCondtions(ma, exerciseModel, param, participant);//temp
					// ma.setRequestedAsAtDate(LocalDate.now());//temp
					// taRenewalRepository.save(ma);
					// participant.setMaFilingCondition(ma); //temp
					// participant.setIsMaRequired(true); //temp
					taRenewalRepository.saveOrUpdate(participant);

				}
			}

			taRenewalRepository.saveOrUpdate(participant);

			if (i % BATCH_COMMIT_INTERVAL == 0) {
				logger.info("Batch Committing records at " + i);
				taRenewalRepository.batchCommit(true);
			}
		}
		logger.info("Batch Committing remaining records.");
		taRenewalRepository.batchCommit(true); // open txn to let @Transactional AOP close its own block

	}

	private void baselineRenewalExercise(TaLicenceRenewalExercise renewalExercise) {
		renewalExercise.setBaselinedDate(LocalDateTime.now());
		renewalExercise.setHasBaselined(Boolean.TRUE);
		taRenewalRepository.saveOrUpdate(renewalExercise);

		for (TaLicenceRenewalExerciseTa ta : taRenewalRepository.getTaLicenceRenewalExerciseTas(renewalExercise.getId())) {
			ta.setBaselinedFye(ta.getFye());
			ta.setBaselinedKe(ta.getKe());
			if (ta.getKe() != null) {
				ta.setBaselinedKeName(ta.getKe().getStakeholder().getName());
			}
			ta.setBaselinedName(ta.getLicence().getTravelAgent().getName());
			ta.setBaselinedOutstandingPayment(travelAgentRepository.getTaOutstandingPaymentAmount(ta.getLicence().getTravelAgent().getUen()));

			TaLicenceRenewalExerciseParam param = taRenewalRepository.getExerciseParam(renewalExercise.getId(), ta.getLicence().getId());
			if ((ta.isMaRequired() && param == null) || (param != null && param.isMaRequiredByUser())) {
				// Add Ma filing
				TaFilingCondition ma = new TaFilingCondition();
				ma = setMaCondtions(ma, renewalExercise, param, ta);
				ta.setMaFilingCondition(ma);
			}
			taRenewalRepository.saveOrUpdate(ta);

		}
	}

	private TaFilingCondition setMaCondtions(TaFilingCondition ma, TaLicenceRenewalExercise renewalExercise, TaLicenceRenewalExerciseParam param, TaLicenceRenewalExerciseTa ta) {
		ma.setApplicationType(cache.getType(Codes.ApplicationTypes.TA_APP_MA_SUBMISSION));
		ma.setFy(renewalExercise.getYear());
		ma.setLicence(ta.getLicence());
		if (ma.getStatus() == null) {
			ma.setStatus(cache.getStatus(Statuses.TA_FILING_PEND_SUBMISSION));
		}
		if (param != null && param.getMaSubmissionDueDate() != null) {
			ma.setDueDate(param.getMaSubmissionDueDate());
		} else {
			LocalDate dueDate = ta.getLicence().getExpiryDate();
			ma.setDueDate(dueDate);
		}
		if (param != null && param.getRequestedMaAsAtDate() != null) {
			ma.setRequestedAsAtDate(param.getRequestedMaAsAtDate());
		} else {
			ma.setRequestedAsAtDate(renewalExercise.getDefaultRequestedMaAsAtDate());
		}
		taRenewalRepository.save(ma);
		return ma;
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = taRenewalRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

}
