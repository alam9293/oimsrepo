package gov.stb.tag.controllers.ta;

import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.EmailType;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallDto;
import gov.stb.tag.dto.ta.shortfallRectification.TaShortfallRectificationActionDto;
import gov.stb.tag.dto.ta.shortfallRectification.TaShortfallRectificationDto;
import gov.stb.tag.dto.ta.shortfallRectification.TaShortfallRectificationItemDto;
import gov.stb.tag.dto.ta.shortfallRectification.TaShortfallRectificationSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.ta.TaLicenceRepository;
import gov.stb.tag.repository.ta.TaNetValueRectificationRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/ta-shortfall-fulfillment")
@Transactional
public class TaNetValueRectificationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaNetValueRectificationRepository taNetValueRectificationRepository;
	@Autowired
	TaNetValueShortfallRepository taNetValueShortfallRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;

	// CR1227
	@Autowired
	TaLicenceRepository taLicenceRepository;

	@RequestMapping(value = "/load", method = RequestMethod.GET)
	public TaShortfallRectificationDto loadNewOrPending() {
		User currentUser = taNetValueRectificationRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
			Licence licence = currentUser.getTravelAgent().getLicence();
			TaNetValueRectification rectification = taNetValueRectificationRepository.getPendingApplication(licence.getId());
			if (rectification == null) {
				TaShortfallRectificationDto dto = TaShortfallRectificationDto.buildFromNew(cache, workflowHelper, appHelper, taNetValueShortfallRepository.getUnsubmittedShortfall(licence.getId()),
						fileHelper);
				return dto;
			} else {
				TaShortfallRectificationDto dto = TaShortfallRectificationDto.buildFromApplication(cache, appHelper, workflowHelper, rectification,
						travelAgentRepository.getExistingKeTaStakeholder(licence.getId()), fileHelper);
				return dto;
			}
		}
		return null;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaShortfallRectificationDto dto) {

		Application application = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION,
				(taNetValueRectificationRepository.getLicenseeUserByUserId(getUser().getId()).getTravelAgent().getLicence().getId()), dto.isOfflineSubmission(), false);
		appHelper.forward(application, true);

		// 2. Save files uploaded by user
		if (dto.getDirectorResolution() != null && !Strings.isNullOrEmpty(dto.getDirectorResolution().getOriginalName())) {
			fileHelper.saveFile(application, dto.getDirectorResolution());
		}
		if (dto.getBankStatement() != null && !Strings.isNullOrEmpty(dto.getBankStatement().getOriginalName())) {
			fileHelper.saveFile(application, dto.getBankStatement());
		}
		if (dto.getAcra() != null && !Strings.isNullOrEmpty(dto.getAcra().getOriginalName())) {
			fileHelper.saveFile(application, dto.getAcra());
		}
		for (FileDto doc : dto.getOtherDocuments()) {
			fileHelper.saveFile(application, doc);
		}

		// 3. Save fields in form
		this.saveApplicationFields(dto, new TaNetValueRectification(), application);
	}

	@RequestMapping(value = "/save/email-acknowledgement/{id}", method = RequestMethod.POST)
	public void sendEmailAcknowledgement(@PathVariable Integer id) {
		Application application = taNetValueRectificationRepository.get(Application.class, id);

		/* Send email to notify TA */
		String url = String.format(properties.applicationUrl, "ta-shortfall-fulfilment/" + application.getId());
		emailHelper.emailTaCneUponAction(application, application.getLicence(), EmailType.CNE_UPON_TA_SUBMISSION, url, application.getAssignee());
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateApplication(@RequestPart(name = "application") TaShortfallRectificationDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {
		// 1. Save application actions
		Application application = taNetValueRectificationRepository.get(Application.class, dto.getApplicationId());
		appHelper.forward(application, true);

		// 2. Delete files deleted by user
		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}
		}

		// 3. Save additional files uploaded by user
		if (dto.getDirectorResolution().getPublicFileId() == null && !Strings.isNullOrEmpty(dto.getDirectorResolution().getOriginalName())) {
			fileHelper.saveFile(application, dto.getDirectorResolution());
		}
		if (dto.getBankStatement().getPublicFileId() == null && !Strings.isNullOrEmpty(dto.getBankStatement().getOriginalName())) {
			fileHelper.saveFile(application, dto.getBankStatement());
		}
		if (dto.getAcra() != null && !Strings.isNullOrEmpty(dto.getAcra().getOriginalName())) {
			fileHelper.saveFile(application, dto.getAcra());
		}
		for (FileDto doc : dto.getOtherDocuments()) {
			if (doc.getPublicFileId() == null && !Strings.isNullOrEmpty(doc.getOriginalName())) {
				fileHelper.saveFile(application, doc);
			}
		}

		// 4. Save changes made by user
		this.saveApplicationFields(dto, taNetValueRectificationRepository.getApplication(application.getId()), application);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaShortfallRectificationItemDto> getList(TaShortfallRectificationSearchDto searchDto) {
		return taNetValueRectificationRepository.getPendingList(searchDto, getUser().getId());
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaShortfallRectificationDto getApplication(@PathVariable Integer id) {
		User currentUser = taNetValueRectificationRepository.getLicenseeUserByUserId(getUser().getId());
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
				appHelper.isAppBelongToTA(id, currentUser);
			}
			TaNetValueRectification rect = taNetValueRectificationRepository.getApplication(id);
			return TaShortfallRectificationDto.buildFromApplication(cache, appHelper, workflowHelper, rect,
					travelAgentRepository.getExistingKeTaStakeholder(rect.getApplication().getLicence().getId()), fileHelper);
		}
		return null;
	}

	// to approve, reject, rfa
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(TaShortfallRectificationActionDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaNetValueRectification rectification = taNetValueRectificationRepository.getApplication(id);
		Application app = rectification.getApplication();

		Set<TaNetValueShortfall> shortfallsRectified = rectification.getTaNetValueShortfalls();
		String taAlertMsg = null;
		String taMsgType = null;
		String statusCode = null;

		/* When at the final approval, the recommendation is reject, and action is approve */
		if (appHelper.isFinalApproval(app) && ACTION_APPROVE.equals(action) && Codes.Types.APP_RECOMMEND_REJ.equals(dto.getRecommendationCode())) {
			action = ACTION_REJECT;
		}

		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), dto.getRecommendationCode(), dto.getFiles(), dto.getFileDescription());
			// update rectified date, input by officers
			rectification.setRectifiedDate(dto.getRectifiedDate());
			if (appHelper.hasFinalApproved(app)) {
				taAlertMsg = Messages.Alerts.TA_SUBMISSION_APPROVE;
				taMsgType = Codes.EmailType.CNE_UPON_TA_SUBMISSION_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;

				// set the approved rectification to shortfall
				shortfallsRectified.forEach(shortfall -> {
					shortfall.setTaNetValueRectification(rectification);

					// create case if rectified date > due date
					if (rectification.getRectifiedDate().isAfter(DateUtil.getMaxDate(shortfall.getRectificationDueDate(), shortfall.getExtendedDueDate()))
							&& shortfall.getTarR9Infringement() == null) {
						ceCaseHelper.createCaseForNvMfrInfringement(shortfall);
					}
				});

				// set the TA paid up capital
				TravelAgent ta = app.getLicence().getTravelAgent();
				ta.setPaidUpCapital(rectification.getAmount());
				taNetValueRectificationRepository.save(ta);

				// CR 1227
				// Check if anymore filing conditions
				SystemParameter sysParam = taLicenceRepository.getJobParameter(Codes.SystemParameters.TA_FILING_CONDITION_REMINDER_START_DATE);
				// List<TaFilingCondition> taFilingConditions = taLicenceRepository.getPendingTaAnnualFilingSubmissionsByLicenceId(sysParam.getValue(), app.getLicence().getId());
				TaLicenceRenewalExerciseTa taFilingConditions = taLicenceRepository.getTaByLicenceId(app.getLicence().getId());

				boolean fulfilled = conditionsFulfilled(taFilingConditions, app);
				logger.info("NET VAL" + fulfilled);
				logger.info("TaNetValueRectificationController getExpiryDate - " + app.getLicence().getExpiryDate());
				if (fulfilled) {
					// Override the message
					// TA_UPON_APPROVAL with TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED
					taMsgType = Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED;
					logger.info("TaNetValueRectificationController NewEmail - " + Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED);
				}

			}
			break;

		case ACTION_REJECT:
			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), dto.getRecommendationCode(), dto.getFiles(), dto.getFileDescription());
			taAlertMsg = Messages.Alerts.TA_SUBMISSION_REJECT;
			taMsgType = Codes.EmailType.CNE_RECT_SHORTFALL_UPON_REJECT;
			statusCode = Codes.Statuses.TA_APP_REJECTED;

			// removed the rectification from netvalue shortfall record, so that it will be treated as not rectified
			shortfallsRectified.forEach(shortfall -> shortfall.setTaNetValueRectification(null));
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:
			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.TA_SUBMISSION_RFA;
				taMsgType = Codes.EmailType.CNE_UPON_TA_SUBMISSION_RFA;
			}

			appHelper.rfa(app, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), dto.getRecommendationCode(), dto.getFiles(), dto.getFileDescription(), dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(app.getLicence().getTravelAgent(), app, taAlertMsg, Codes.Modules.MOD_TA, app.getType(), "../ta-shortfall-fulfilment/" + app.getId(), cache.getStatus(statusCode));

			/* Send email to notify TA */
			logger.info("NET VAL " + taMsgType);
			if (taMsgType.equals(EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED)) {
				logger.info("NET VAL " + 1);
				String url = String.format(properties.applicationUrl, "ta-shortfall-fulfilment");

				emailHelper.emailTaUponAction(app, taMsgType, url);
			} else {
				logger.info("NET VAL " + 2);
				String url = String.format(properties.applicationUrl, "ta-shortfall-fulfilment/" + app.getId());
				emailHelper.emailTaCneUponAction(app, app.getLicence(), taMsgType, url, appHelper.getSigningOfficerForCE(app, getUser()));
			}

		}
	}

	private boolean conditionsFulfilled(TaLicenceRenewalExerciseTa taLicenceRenewalExerciseTa, Application app) {

		try {
			if (null == taLicenceRenewalExerciseTa) {
				return false;
			}

			// Aa
			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaAaFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAaFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// Abpr
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition1()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition1().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}
			if (null != taLicenceRenewalExerciseTa.getTaAbprFilingCondition2()) {
				if (taLicenceRenewalExerciseTa.getTaAbprFilingCondition2().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			// NET val
			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1()) {
				if (taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1().getId() == app.getId()) {
					// cont
				} else if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa1().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2()) {
				if (taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2().getId() == app.getId()) {
					// cont
				} else if (null != taLicenceRenewalExerciseTa.getTaNetValueShortfallMa2().getTaNetValueRectification()) {
					// cont
				} else {
					return false;
				}
			}

			// MA
			if (null != taLicenceRenewalExerciseTa.getMaFilingCondition()) {
				if (taLicenceRenewalExerciseTa.getMaFilingCondition().getStatus().getCode().equals("TA_FILING_APPR")) {
					// cont
				} else {
					return false;
				}
			}

			return true;
		} catch (Exception e) {
			return false;
		}
		/*
		 * for (TaFilingCondition conditions : filteredTaFilingConditions) {
		 * 
		 * if (!conditions.getStatus().getCode().equals("TA_FILING_APPR")) { return false; }
		 * 
		 * } return true;
		 */

	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taNetValueRectificationRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void saveApplicationFields(TaShortfallRectificationDto dto, TaNetValueRectification rectification, Application application) {
		if (rectification == null) {
			rectification = new TaNetValueRectification();
		}
		rectification.setApplication(application);
		rectification.setAmount(dto.getCapital());
		rectification.setIsEdhPopulated(dto.getIsEdhPopulated());
		taNetValueRectificationRepository.save(rectification);

		// set the shortfall records to the rectification
		rectification.setAllTaNetValueShortfalls(Sets.newHashSet());
		for (TaNetValueShortfallDto shortfallDto : dto.getNetvalueShortfalls()) {
			TaNetValueShortfall shortfall = taNetValueRectificationRepository.get(TaNetValueShortfall.class, shortfallDto.getId());
			shortfall.setTaNetValueRectification(rectification);
			taNetValueRectificationRepository.save(shortfall);
			rectification.getAllTaNetValueShortfalls().add(shortfall);

			// Complete Ce Task
			ceTaskHelper.completeCeTaskByWorkflow(shortfall.getWorkflow());
		}
	}
}
