package gov.stb.tag.controllers.ta;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Objects;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallApprovalDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallItemDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallLetterDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallSearchDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallUpdateDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeTaskHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.MessageHelper;
import gov.stb.tag.helper.TaShortfallLetterPdfHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.LetterTemplate;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.ta.TaNetValueRectificationRepository;
import gov.stb.tag.repository.ta.TaNetValueShortfallRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/ta-rectification-shortfall")
@Transactional
public class TaNetValueShortfallController extends BaseController {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaNetValueShortfallRepository taNetValueShortfallRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	TaNetValueRectificationRepository taNetValueRectificationRepository;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;
	@Autowired
	TaRenewalRepository taRenewalRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	MessageHelper messageHelper;
	@Autowired
	TaShortfallLetterPdfHelper taShortfallLetterPdfHelper;

	// to retrieve all Shortfall records
	@RequestMapping(method = RequestMethod.GET, path = { "/view" })
	public ResultDto<TaNetValueShortfall> getList(TaNetValueShortfallSearchDto searchDto) {

		ResultDto<TaNetValueShortfall> results = taNetValueShortfallRepository.getList(searchDto, getUser().getId());

		Object[] finalRecords = new Object[results.getRecords().length];
		var i = 0;
		for (TaNetValueShortfall shortfall : results.getModels()) {
			var dto = TaNetValueShortfallItemDto.buildFromNetValueShortfall(cache, workflowHelper, appHelper, shortfall, taRenewalRepository);
			finalRecords[i] = dto;
			i++;
		}
		results.setRecords(finalRecords);

		return results;
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TaNetValueShortfallUpdateDto getDetails(@PathVariable Integer id) {
		TaNetValueShortfall shortfall = taNetValueShortfallRepository.get(TaNetValueShortfall.class, id);
		TaNetValueShortfallUpdateDto dto = TaNetValueShortfallUpdateDto.buildFromNetValueShortfall(cache, workflowHelper, appHelper, shortfall, shortfall.getTaNetValueRectification(),
				taRenewalRepository);
		if (shortfall.getParentShortfall() != null) {
			dto.setIsParent(Boolean.FALSE);
			TaNetValueShortfallUpdateDto parentDto = TaNetValueShortfallUpdateDto.buildFromNetValueShortfall(cache, workflowHelper, appHelper, shortfall.getParentShortfall(),
					shortfall.getParentShortfall().getTaNetValueRectification(), taRenewalRepository);
			parentDto.setIsParent(Boolean.TRUE);
			dto.setLinkedNetValueShortfall(parentDto);
		}
		// check if the netvalue shortfall is parent of other
		TaNetValueShortfall childShortfall = taNetValueShortfallRepository.getShortfallByParentId(id);
		if (childShortfall != null) {
			dto.setIsParent(Boolean.TRUE);
			TaNetValueShortfallUpdateDto childDto = TaNetValueShortfallUpdateDto.buildFromNetValueShortfall(cache, workflowHelper, appHelper, childShortfall,
					childShortfall.getTaNetValueRectification(), taRenewalRepository);
			childDto.setIsParent(Boolean.FALSE);
			dto.setLinkedNetValueShortfall(childDto);
		}
		return dto;
	}

	@RequestMapping(value = "/update/due-dates", method = RequestMethod.POST)
	public void updateShortfallDueDates(@RequestBody List<TaNetValueShortfallApprovalDto> dtoList) {
		logger.info("Updating shortfall due dates");
		for (TaNetValueShortfallApprovalDto dto : dtoList) {
			TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.get(TaNetValueShortfall.class, dto.getId());
			if (workflowHelper.hasFinalApprovedOrRejected(taNetValueShortfall.getWorkflow())) {
				throw new ValidationException("Update of due date can only be applied to open cases.");
			}
			workflowHelper.edit(taNetValueShortfall.getWorkflow(), dto.getInternalRemarks());
			taNetValueShortfall.setRectificationDueDate(dto.getDueDate());
			taNetValueShortfallRepository.save(taNetValueShortfall);
		}
	}

	@RequestMapping(value = "/update/letter-isssued-dates", method = RequestMethod.POST)
	public void updateShortfallLetterIssuedDates(@RequestBody List<TaNetValueShortfallApprovalDto> dtoList) {
		logger.info("Updating shortfall letter issue dates");
		for (TaNetValueShortfallApprovalDto dto : dtoList) {
			TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.get(TaNetValueShortfall.class, dto.getId());
			if (StringUtils.isNotBlank(taNetValueShortfall.getLetterContent()) && taNetValueShortfall.getLetterIssuedDate() != null) {
				throw new ValidationException("Unable to overwrite letter issued date for letters sent by system.");
			}
			workflowHelper.edit(taNetValueShortfall.getWorkflow(), dto.getInternalRemarks());
			taNetValueShortfall.setLetterIssuedDate(dto.getLetterIssuedDate());
			taNetValueShortfallRepository.save(taNetValueShortfall);
		}
	}

	@RequestMapping(value = "/extend", method = RequestMethod.POST)
	public void extendShortfallRectificationDueDates(@RequestBody List<TaNetValueShortfallApprovalDto> dtoList) {
		logger.info("Extending shortfall rectification due date");

		String taAlertMsg = gov.stb.tag.constant.Messages.Alerts.CNE_EXTEND_SHORTFALL_APPROVE;

		for (TaNetValueShortfallApprovalDto dto : dtoList) {
			TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.get(TaNetValueShortfall.class, dto.getId());
			if (taNetValueShortfall.getRectificationDueDate() != null && dto.getExtendedDueDate() != null && !dto.getExtendedDueDate().isAfter(taNetValueShortfall.getRectificationDueDate())) {
				throw new ValidationException("Extended due date must be at least one day later than rectification due date");
			}
			workflowHelper.edit(taNetValueShortfall.getWorkflow(), dto.getInternalRemarks());
			taNetValueShortfall.setExtendedDueDate(dto.getExtendedDueDate());
			taNetValueShortfallRepository.save(taNetValueShortfall);

			if (dto.getExtendedDueDate() != null) {
				alertHelper.createAlert(taNetValueShortfall.getWorkflow().getLicence().getTravelAgent(), null, taAlertMsg, Codes.Modules.MOD_TA,
						cache.getType(Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION), "../ta-shortfall-fulfilment/", null);

				// STBPROD-1207 -Removed this email as not in work flow Seow Hwang
				// String url = String.format(properties.applicationUrl, "ta-shortfall-fulfilment/");
				// emailHelper.emailTaCneUponAction(null, taNetValueShortfall.getWorkflow().getLicence(), EmailType.CNE_UPON_SHORTFALL_EXTENSION_APPROVAL, url, getUser());

				// create For Info Task
				logger.info("Shortfall(id: {}) due date extended. Creating For Info Task with new due date and SLA", taNetValueShortfall.getId());
				ceTaskHelper.createCeTaskForShortfall(taNetValueShortfall, Messages.CeTaskDetails.R9_SHORTFALL_APPR, Codes.CeTaskStatus.CE_TASK_FOR_INFO);
			}
		}
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateShortfall(@RequestBody TaNetValueShortfallApprovalDto dto) {
		TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.getShortfallByShortfallId(dto.getId());
		WorkflowAction action = workflowHelper.edit(taNetValueShortfall.getWorkflow(), dto.getInternalRemarks());

		saveSubmissionFields(taNetValueShortfall, action, dto);
	}

	@RequestMapping(value = "/update/generated-letter", method = RequestMethod.POST)
	public void updateGeneratedShortfallLetter(@RequestBody TaNetValueShortfallApprovalDto dto) {
		logger.info("Updating generated shortfall letter");
		TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.getShortfallByShortfallId(dto.getId());
		WorkflowAction action = workflowHelper.edit(taNetValueShortfall.getWorkflow(), dto.getInternalRemarks());
		taNetValueRectificationRepository.save(action);
		if (dto.getRecommendationCode().equals(Codes.Types.RECOMMEND_IMPOSE)) {
			taNetValueShortfall.setLetterContent(dto.getLetterContent());
			taNetValueRectificationRepository.update(taNetValueShortfall);
		}
	}

	@RequestMapping(value = "/approve", method = RequestMethod.POST)
	public void approveShortfall(@RequestBody List<TaNetValueShortfallApprovalDto> dtoList) {
		for (TaNetValueShortfallApprovalDto dto : dtoList) {
			TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.getShortfallByShortfallId(dto.getId());
			Licence licence = taNetValueShortfall.getWorkflow().getLicence();
			if (workflowHelper.hasFinalApprovedOrRejected(taNetValueShortfall.getWorkflow())) {
				throw new ValidationException("Approve can only be applied to open cases.");
			}
			if (workflowHelper.isFinalApproval(taNetValueShortfall.getWorkflow())) {
				// check if parent is the same status or has final approved/rejected
				TaNetValueShortfall parentShortfall = taNetValueShortfall.getParentShortfall();
				if (parentShortfall != null) {
					if (!workflowHelper.hasFinalApprovedOrRejected(parentShortfall.getWorkflow())
							&& !Objects.equal(parentShortfall.getWorkflow().getLastAction().getStatus(), taNetValueShortfall.getWorkflow().getLastAction().getStatus())) {
						logger.info("Parent shortfall has not submitted for approval.");
						throw new ValidationException("You are not supposed to approve the shortfall until all linked shortfall has been submitted for approval.");
					}
				}
				// check if child is the same status or has final approved/rejected
				TaNetValueShortfall childShortfall = taNetValueShortfallRepository.getShortfallByParentId(taNetValueShortfall.getId());
				if (childShortfall != null) {
					if (!workflowHelper.hasFinalApprovedOrRejected(childShortfall.getWorkflow())
							&& !Objects.equal(childShortfall.getWorkflow().getLastAction().getStatus(), taNetValueShortfall.getWorkflow().getLastAction().getStatus())) {
						logger.info("Child shortfall has not submitted for approval.");
						throw new ValidationException("You are not supposed to approve the shortfall until all linked shortfall has been submitted for approval.");
					}
				}
			}

			WorkflowAction workflowAction = workflowHelper.forward(taNetValueShortfall.getWorkflow(), false, dto.getInternalRemarks(), dto.getRecommendationCode(), dto.getFiles(),
					dto.getFileDescription());

			// Generate Shortfall Letter in PDF, alert and email upon approval and recommendation is to impose
			if (Entities.equals(workflowAction.getStatus(), Codes.Statuses.TA_WKFLW_APPROVED) && Entities.equals(workflowAction.getRecommendation(), Codes.Types.RECOMMEND_IMPOSE)) {
				if (StringUtils.isBlank(taNetValueShortfall.getLetterContent())) {
					LetterTemplate template = taNetValueShortfallRepository.get(LetterTemplate.class, Codes.LetterType.TA_SHORTFALL_LETTER);
					String letterContent = template.getContent();
					TaStakeholder ke = travelAgentRepository.getExistingKeTaStakeholder(licence.getId());
					letterContent = messageHelper.formatTaNetValueShortfallLetterPlaceholders(letterContent, taNetValueShortfall, licence, licence.getTravelAgent(), ke.getStakeholder());
					taNetValueShortfall.setLetterContent(letterContent);
				}

				// Generate Shortfall Letter in PDF
				TaNetValueShortfallLetterDto shortfallLetterDto = taShortfallLetterPdfHelper.generatePdf(taNetValueShortfall.getWorkflow(), taNetValueShortfall.getLetterContent(),
						licence.getLicenceNo());
				File shortfallLetter = fileHelper.saveShortfallLetter(taNetValueShortfall.getWorkflow(), shortfallLetterDto.getFileName(), shortfallLetterDto.getShortfallLetterByteArray());

				// Generate alert to notify TA to submit Proof of Shortfall Rectification
				alertHelper.createAlertForShortfall(licence.getTravelAgent(), Messages.Alerts.TA_SHORTFALL_RECTIFICATION_NOTIFY, Codes.Modules.MOD_TA,
						cache.getType(Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION), "../ta-shortfall-fulfilment");

				// Send email to notify TA & KE to submit Proof of Shortfall Rectification
				String url = String.format(properties.applicationUrl, "ta-shortfall-fulfilment/");
				emailHelper.emailTaForShortfallRectificationSubmission(licence, taNetValueShortfall, fileHelper.getPhyiscalFile(shortfallLetter), url);
				taNetValueShortfall.setLetterIssuedDate(LocalDate.now());

				// Update letter content with letter date to NV shortfall
				taNetValueShortfall.setLetterContent(shortfallLetterDto.getLetterContent());
				taNetValueShortfallRepository.update(taNetValueShortfall);
			}

		}
	}

	@RequestMapping(value = "/route", method = RequestMethod.POST)
	public void rfaShortfall(@RequestBody List<TaNetValueShortfallApprovalDto> dtoList) {
		for (TaNetValueShortfallApprovalDto dto : dtoList) {
			TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.get(TaNetValueShortfall.class, dto.getId());
			if (workflowHelper.hasFinalApprovedOrRejected(taNetValueShortfall.getWorkflow())) {
				throw new ValidationException("Routing can only be applied to open cases.");
			}
			workflowHelper.rfa(taNetValueShortfall.getWorkflow(), dto.getRouteStatus(), dto.getInternalRemarks(), null, null, dto.getFiles(), dto.getFileDescription(), dto.getAssignee());
		}
	}

	@RequestMapping(value = "/rescind", method = RequestMethod.POST)
	public void rescindShortfall(@RequestBody List<TaNetValueShortfallApprovalDto> dtoList) {
		for (TaNetValueShortfallApprovalDto dto : dtoList) {
			TaNetValueShortfall taNetValueShortfall = taNetValueShortfallRepository.get(TaNetValueShortfall.class, dto.getId());
			if (!workflowHelper.hasFinalApproved(taNetValueShortfall.getWorkflow())) {
				throw new ValidationException("Rescind can only be applied to approved cases.");
			}
			// TODO : need to redo
			workflowHelper.rfa(taNetValueShortfall.getWorkflow(), dto.getRouteStatus(), dto.getInternalRemarks(), null, null, dto.getFiles(), dto.getFileDescription(), dto.getAssignee());
		}
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Workflow workflow = taNetValueRectificationRepository.get(Workflow.class, dto.getWorkflowId());
		workflowHelper.saveNote(workflow, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void saveSubmissionFields(TaNetValueShortfall taNetValueShortfall, WorkflowAction action, TaNetValueShortfallApprovalDto dto) {

		boolean hasApproved = workflowHelper.hasFinalApprovedOrRejected(taNetValueShortfall.getWorkflow());
		if (!hasApproved) {
			taNetValueShortfall.setType(cache.getType(dto.getShortfallTypeCode()));
			taNetValueShortfall.setAmount(dto.getAmount());
			taNetValueShortfall.setRectificationDueDate(dto.getDueDate());
			taNetValueShortfall.setRemarks(dto.getRemarks());
			action.setRecommendation(cache.getType(dto.getRecommendationCode()));

			String letterContent = "";
			if (dto.getRecommendationCode().equals(Codes.Types.RECOMMEND_IMPOSE)) {
				LetterTemplate template = taNetValueShortfallRepository.get(LetterTemplate.class, Codes.LetterType.TA_SHORTFALL_LETTER);
				letterContent = template.getContent();
				Licence licence = taNetValueShortfall.getWorkflow().getLicence();
				TaStakeholder ke = travelAgentRepository.getExistingKeTaStakeholder(licence.getId());
				letterContent = messageHelper.formatTaNetValueShortfallLetterPlaceholders(letterContent, taNetValueShortfall, licence, licence.getTravelAgent(), ke.getStakeholder());
			}
			taNetValueShortfall.setLetterContent(letterContent);

			taNetValueRectificationRepository.save(action);
		}

		// only allow update letter issued date when letter content is blank
		if (StringUtils.isBlank(taNetValueShortfall.getLetterContent())) {
			taNetValueShortfall.setLetterIssuedDate(dto.getLetterIssuedDate());
		}
		taNetValueRectificationRepository.save(taNetValueShortfall);

		for (Integer fileId : dto.getDeletedWorkflowFileIds()) {
			fileHelper.deleteWorkflowFileByWorkflowFileId(fileId);
		}
		for (AttachmentDto workflowFileDto : dto.getWorkflowFiles()) {
			fileHelper.saveWorkflowFile(taNetValueShortfall.getWorkflow(), workflowFileDto);
		}
	}
}
