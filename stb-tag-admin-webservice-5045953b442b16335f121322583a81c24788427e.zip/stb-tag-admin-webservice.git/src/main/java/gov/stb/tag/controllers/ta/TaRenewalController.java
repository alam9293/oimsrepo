package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.branch.TaBranchDto;
import gov.stb.tag.dto.ta.companyupdate.TaCompanyDetailsDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalChecklist;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalItemDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalSearchDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderRecordDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.TaHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.TaLicenceRenewal;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.ta.TaBranchApplicationRepository;
import gov.stb.tag.repository.ta.TaBranchRepository;
import gov.stb.tag.repository.ta.TaELicenceRequestRepository;
import gov.stb.tag.repository.ta.TaKeApplicationRepository;
import gov.stb.tag.repository.ta.TaRenewalRepository;
import gov.stb.tag.repository.ta.TaStakeholderRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/ta/renewals")
@Transactional
public class TaRenewalController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaRenewalRepository taRenewalRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	TaBranchApplicationRepository taBranchApplicationRepository;
	@Autowired
	TaBranchRepository taBranchRepository;
	@Autowired
	TaStakeholderRepository taStakeholderRepository;
	@Autowired
	TaKeApplicationRepository taKeApplicationRepository;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	PaymentRepository paymentRepository;
	@Autowired
	TaHelper taHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	TaELicenceRequestRepository taELicenceRequestRepository;

	// to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TaLicenceRenewalItemDto> getList(TaLicenceRenewalSearchDto searchDto) {
		return taRenewalRepository.getPendingList(searchDto, getUser().getId(), true);
	}

	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TaLicenceRenewalDto loadNew() {
		User currentUser = taRenewalRepository.get(User.class, getUser().getId());
		String uen = currentUser.getUen();
		Licence licenceModel = currentUser.getTravelAgent().getLicence();
		TaLicenceRenewalDto resultDto = new TaLicenceRenewalDto();
		LocalDate currentDate = LocalDate.now();
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(licenceModel)) {

			Application appModel = taRenewalRepository.getPendingApplicationFromLicenceId(licenceModel.getId(), Codes.ApplicationTypes.TA_APP_RENEWAL);
			List<FileDto> fileList = new ArrayList<FileDto>();
			logger.info("loadNew(): retrieving renewal app data (if any) for TA: {}", uen);
			// Check if there is any renewal pending processing

			if (appModel != null && appModel.getLastAction().getStatus().getCode().equalsIgnoreCase(Codes.Statuses.TA_APP_REJECTED)) {
				appModel = null;
			}

			if (appModel == null) {
				logger.info("loadNew(): No application found for this year. Loading new application for TA: {}", uen);
				resultDto.setApplicationStatus(
						new ListableDto(Codes.Statuses.TA_APP_NEW, cache.getStatus(Codes.Statuses.TA_APP_NEW).getLabel(), cache.getStatus(Codes.Statuses.TA_APP_NEW).getOtherLabel(), null, null));
				TaLicenceRenewalExerciseTa exerciseTa = taRenewalRepository.getTaLicenceRenewalExerciseTaForYear(licenceModel.getId(), currentDate);
				if (exerciseTa != null) {
					resultDto.setTaLicenceRenewalExerciseTaId(exerciseTa.getId());
				}
			} else {
				logger.info("loadNew(): app found. id: {}, appNo: {}, loading app data for TA: {}", appModel.getId(), appModel.getApplicationNo(), uen);
				TaLicenceRenewal renewalApp = taRenewalRepository.getRenewalSubmissionFromAppId(appModel.getId());
				resultDto = TaLicenceRenewalDto.buildApplication(cache, appHelper, paymentHelper, renewalApp, resultDto);

				List<FileDto> reqFileList = new ArrayList<FileDto>();
				fileList = taRenewalRepository.getFiles(resultDto.getApplicationId(), fileHelper);

				resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
			}

			resultDto = setLicenseeDetailForView(resultDto, licenceModel);
			// Check if logged in user is KE. Only KE can do declaration and submit renewal
			logger.info("loadNew(): getKeStakeholderDto 1111 :getLoginId {}, getUin {}", currentUser.getLoginId(), resultDto.getKeStakeholderDto().getUin());
			if (resultDto.getKeStakeholderDto() != null) {
				logger.info("loadNew(): getKeStakeholderDto 222 :getLoginId {}, getUin {}", currentUser.getLoginId(), resultDto.getKeStakeholderDto().getUin());
				resultDto.setIsKeUser(travelAgentRepository.compareUserUinAndKeUin(currentUser.getLoginId(), resultDto.getKeStakeholderDto().getUin()));
			}
			logger.info("loadNew(): getKeStakeholderDto 3333 :getLoginId {}, getUin {}", currentUser.getLoginId(), resultDto.getKeStakeholderDto().getUin());

			// Check for TaLicenceRenewalExercise and see if approved renewal period open
			TaLicenceRenewalExercise renewalExercise = taRenewalRepository.getApprovedRenewalExerciseFromYear(currentDate.getYear());
			if (renewalExercise != null) {
				if (renewalExercise.getStartDate().isEqual(currentDate) || currentDate.isAfter(renewalExercise.getStartDate())) {
					resultDto.setRenewalIsOpen(Boolean.TRUE);
				}
				if (currentDate.isAfter(renewalExercise.getEndDate())) {
					resultDto.setIsLate(Boolean.TRUE);
				}
				if (currentDate.isAfter(LocalDate.of(currentDate.getYear(), 12, 31))) {
					resultDto.setRenewalIsOpen(Boolean.FALSE);
				}

				if (resultDto.getRenewalIsOpen() || resultDto.getIsLate()) {

					/*
					 * // TODO: need to change the year, otherwise unable to retrieve the past renewal conditions renewalChecklist = taHelper.getTaRenewalChecklist(LocalDate.now().getYear(),
					 * licenceModel, renewalChecklist);
					 */
					TaLicenceRenewalChecklist renewalChecklist = new TaLicenceRenewalChecklist();
					renewalChecklist.setOutstandingPaymentAmount(travelAgentRepository.getTaOutstandingPaymentAmount(licenceModel.getTravelAgent().getUen()));
					renewalChecklist = taHelper.getTaRenewalChecklist(renewalExercise.getYear(), licenceModel, new TaLicenceRenewalChecklist(), renewalChecklist.getOutstandingPaymentAmount());
					resultDto.setRenewalChecklist(renewalChecklist);
				}
			} else {
				resultDto.setRenewalIsOpen(Boolean.FALSE);
			}
		}
		return resultDto;

	}

	private TaLicenceRenewalDto setLicenseeDetailForView(TaLicenceRenewalDto resultDto, Licence licenceModel) {

		if (licenceModel != null) {
			logger.info("loadNew(): setLicenseeDetailForView 1111 : licenceModel.getId() {}", licenceModel.getId());
			// 1. Get business entity details
			resultDto.setCurrentCompanyDetails(TaCompanyDetailsDto.buildFromLicence(cache, licenceModel));

			// 2. Get Active Branch list
			List<TaBranchDto> activeBranchDtoList = new ArrayList<TaBranchDto>();
			List<TaBranch> taActiveBranches = taBranchApplicationRepository.getBranchesByStatus(licenceModel.getId(), Arrays.asList(Codes.Statuses.TA_BRANCH_ACTIVE));
			taActiveBranches.forEach((temp) -> {
				TaBranchDto taBranchDto = TaBranchDto.buildFromTaBranch(cache, temp);
				activeBranchDtoList.add(taBranchDto);
			});
			resultDto.setActiveBranchList(activeBranchDtoList);

			// 3. Get current KE details
			Stakeholder stakeholderModel = new Stakeholder();
			stakeholderModel = travelAgentRepository.getExistingKe(licenceModel.getId());

			if (stakeholderModel == null) {
				resultDto.setHaveKe(Boolean.FALSE);
			} else {
				resultDto.setKeStakeholderDto(new StakeholderDto(cache, stakeholderModel));
				if (!stakeholderModel.getTaStakeholders().isEmpty()) {
					for (TaStakeholder row : stakeholderModel.getTaStakeholders()) {
						if (Codes.TaStakeholderRoles.STKHLD_KE.equalsIgnoreCase(row.getRole().getCode())) {
							logger.info("loadNew(): setLicenseeDetailForView 1111 : getUin {}", row.getStakeholder().getUin());
							logger.info("loadNew(): setLicenseeDetailForView 1111 : getAppointedDate {}", row.getAppointedDate());
							logger.info("loadNew(): setLicenseeDetailForView 1111 : getCompanyUen {}", row.getStakeholder().getCompanyUen());
							logger.info("loadNew(): setLicenseeDetailForView 1111 : getName {}", row.getStakeholder().getName());
							resultDto.setTaKeStakeholder(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, row, Boolean.TRUE, Boolean.TRUE));
						}
					}
				}
			}

			// 4. Get personnels
			List<StakeholderRecordDto> results = new ArrayList<>();
			List<TaStakeholder> stakeholderList = taStakeholderRepository.getFullPersonnelByLicenceId(licenceModel.getId());
			for (TaStakeholder tsh : stakeholderList) {
				results.add(StakeholderRecordDto.build(cache, tsh, tsh.getStakeholder(), Boolean.FALSE, Boolean.FALSE));
			}
			resultDto.setPersonnelList(results);
		}

		// 5.Get the declaration required for KE to complete during renewal
		List<TaKeDeclarationsDto> declareDtos = new ArrayList<>();
		if (resultDto.getTaKeDeclarationsForRenewal() == null || resultDto.getTaKeDeclarationsForRenewal().isEmpty()) {
			/* Set decalrations required for application */
			for (TaKeClause clause : cache.getTaKeClausesForRenewal()) {
				declareDtos.add(TaKeDeclarationsDto.buildClauseOnly(cache, clause));
			}
			resultDto.setTaKeDeclarationsForRenewal(declareDtos);
		}
		return resultDto;
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/load/{id}" }, method = RequestMethod.GET)
	public TaLicenceRenewalDto getApplication(@PathVariable Integer id) {
		User currentUser = taRenewalRepository.getLicenseeUserByUserId(getUser().getId());

		TaLicenceRenewalDto resultDto = new TaLicenceRenewalDto();
		TaLicenceRenewal renewalApp = new TaLicenceRenewal();
		List<FileDto> fileList = new ArrayList<FileDto>();
		TravelAgent ta = currentUser.getTravelAgent();
		Licence licenceModel = new Licence();
		if (id != null) {
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(ta)) {
				appHelper.isAppBelongToTA(id, currentUser);
				licenceModel = ta.getLicence();
			}

			renewalApp = taRenewalRepository.getRenewalSubmissionFromAppId(id);
			if (renewalApp != null) {
				resultDto = TaLicenceRenewalDto.buildApplication(cache, appHelper, paymentHelper, renewalApp, resultDto);

				List<FileDto> reqFileList = new ArrayList<FileDto>();
				fileList = taRenewalRepository.getFiles(resultDto.getApplicationId(), fileHelper);

				resultDto.setFiles(appHelper.addFilesNotIncluded(fileList, reqFileList));
			}
			if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
				// Check if logged in user is KE. Only KE can do declaration and submit renewal
				resultDto = setLicenseeDetailForView(resultDto, licenceModel);
				resultDto.setIsKeUser(travelAgentRepository.compareUserUinAndKeUin(currentUser.getLoginId(), resultDto.getKeStakeholderDto().getUin()));
			} else {
				licenceModel = renewalApp.getApplication().getLicence();
				TaLicenceRenewalChecklist renewalChecklist = new TaLicenceRenewalChecklist();

				renewalChecklist.setOutstandingPaymentAmount(travelAgentRepository.getTaOutstandingPaymentAmount(licenceModel.getTravelAgent().getUen()));
				renewalChecklist = taHelper.getTaRenewalChecklist(renewalApp.getTaLicenceRenewalExerciseTa().getTaLicenceRenewalExercise().getYear(), licenceModel, renewalChecklist,
						renewalChecklist.getOutstandingPaymentAmount());
				resultDto.setRenewalChecklist(renewalChecklist);

				// Get Ta past renewal cycle
				List<TaLicenceRenewalExerciseTa> taRenewalCycle = taRenewalRepository.getTaPastRenewalCycle(licenceModel.getId(), 3,
						renewalApp.getTaLicenceRenewalExerciseTa().getTaLicenceRenewalExercise().getYear());
				if (taRenewalCycle != null) {
					resultDto.setPastRenewalCycle(new ArrayList<ListableDto>());
					for (TaLicenceRenewalExerciseTa row : taRenewalCycle) {
						resultDto.getPastRenewalCycle().add(new ListableDto(
								row.getTaLicenceRenewalExercise().getStartDate().format(DateUtil.DATE_FORMAT).concat(" to ")
										.concat(row.getTaLicenceRenewalExercise().getEndDate().format(DateUtil.DATE_FORMAT)),
								row.getTaLicenceRenewal().getApplication().getSubmissionDate().format(DateUtil.DATE_FORMAT), row.getTaLicenceRenewal().getLateRemarks() == null ? "No" : "Yes"));
					}
				}

			}
		}

		return resultDto;
	}

	// to submit new application details
	@RequestMapping(path = { "/save", "/update", "offline/save", "offline/update" }, method = RequestMethod.POST)
	public void saveApplication(@RequestBody TaLicenceRenewalDto dto) throws IOException {
		Licence licenceModel = new Licence();
		Integer licenceId = null;
		if (dto.isOfflineSubmission()) {
			licenceId = dto.getLicenceId();
			licenceModel = taRenewalRepository.get(Licence.class, licenceId);
		} else {
			User currentUser = taRenewalRepository.getLicenseeUserByUserId(getUser().getId());
			licenceModel = currentUser.getTravelAgent().getLicence();
			licenceId = licenceModel.getId();

			if (dto != null && dto.getApplicationId() != null) {
				if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {
					appHelper.isAppBelongToTA(dto.getApplicationId(), currentUser);
				}
			}
		}

		TaLicenceRenewal renewalModel = null;

		if (dto != null) {
			Application appModel;

			if (dto.getApplicationId() != null) { // Update existing
				renewalModel = taRenewalRepository.get(TaLicenceRenewal.class, dto.getId());
				appModel = taRenewalRepository.get(Application.class, dto.getApplicationId());
			} else { // save new
				appModel = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_RENEWAL, licenceId, dto.isOfflineSubmission(), false);
			}

			appHelper.forward(appModel, true);

			renewalModel = taRenewalRepository.updateRenewalDetails(dto, renewalModel, cache, appModel);

			for (FileDto fileDto : dto.getFiles()) {
				if (fileDto.getPublicFileId() == null && !Strings.isNullOrEmpty(fileDto.getOriginalName())) {
					fileHelper.saveFile(appModel, fileDto);
				}
			}

			List<Integer> toDeleteList = dto.getToDeleteFiles();
			if (toDeleteList != null && !toDeleteList.isEmpty()) {
				for (Integer id : toDeleteList) {
					if (id != null) {
						File attachemnt = new File();
						attachemnt = fileHelper.getFile(id);
						if (attachemnt != null) {
							fileHelper.deleteFile(attachemnt);
						}
					}
				}
			}
		}
	}

	// to approve, reject, revert switch tier
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void submitAction(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TaLicenceRenewal renewalModel = new TaLicenceRenewal();
		renewalModel = taRenewalRepository.get(TaLicenceRenewal.class, id);

		Application appModel = taRenewalRepository.get(Application.class, renewalModel.getApplication().getId());
		Licence licenceModel = appModel.getLicence();
		TravelAgent taModel = licenceModel.getTravelAgent();

		String taAlertMsg = null;
		String taMsgType = null;
		BigDecimal appAmount = null;
		BigDecimal branchAppAmount = null;
		BigDecimal mainAppAmount = null;
		BigDecimal branchAmt = null;
		String statusCode = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(appModel, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			if (appHelper.hasFinalApproved(appModel)) {
				taAlertMsg = Messages.Alerts.TA_APP_RENEWAL_APPROVE;
				taMsgType = Codes.EmailType.TA_LICENCE_RENEWAL_APPROVAL;
				statusCode = Codes.Statuses.TA_APP_APPROVED;
				Long activeBranchCount = 0L;
				activeBranchCount = travelAgentRepository.getBranchCount(licenceModel.getId(), Codes.Statuses.TA_BRANCH_ACTIVE);
				branchAmt = new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TA_BRANCH_FEE).getValue());

				mainAppAmount = new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TA_LICENCE_RENEWAL_FEE).getValue());
				branchAppAmount = branchAmt.multiply(new BigDecimal(activeBranchCount));
				appAmount = mainAppAmount.add(branchAppAmount);
				PaymentRequest pr = paymentHelper.savePaymentRequest(appModel.getApplicationNo(), Codes.TaPaymentRequestTypes.PAYREQ_TA_RENEWAL, taModel.getUen(), taModel.getName(), appAmount,
						"TA Licence Renewal Fee", null, Boolean.FALSE, Boolean.TRUE, taModel.getEmailAddress());
				renewalModel.setAppFeeBillRefNo(pr.getBillRefNo());

				// to waive payment based on configuration
				List<String> paybills = paymentHelper.waivePayments(Lists.newArrayList(pr.getBillRefNo()));
				if (!paybills.contains(pr.getBillRefNo())) {
					taAlertMsg = Messages.Alerts.APP_APPROVE;
					taMsgType = Codes.EmailType.TA_LICENCE_RENEWAL_APPROVAL_WAIVED;
				}
			}

			break;
		case ACTION_REJECT:
			taAlertMsg = Messages.Alerts.APP_REJECT;
			taMsgType = Codes.EmailType.TA_UPON_REJECTION;
			statusCode = Codes.Statuses.TA_APP_REJECTED;
			appHelper.reject(appModel, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			// Check if licence is already expired, then immediately cease
			if (licenceModel.getExpiryDate().isBefore(LocalDate.now())) {
				licenceHelper.updateLicenceStatus(licenceModel, Codes.Statuses.TA_CEASED, null, licenceModel.getExpiryDate().plusDays(1).atStartOfDay());
				List<TaBranch> branches = travelAgentRepository.getBranchesByLicenceId(licenceModel.getId(), null);
				if (branches != null) {
					for (TaBranch branch : branches) {
						if (branch.getStatus().getCode().equals(Codes.Statuses.TA_BRANCH_ACTIVE) || branch.getStatus().getCode().equals(Codes.Statuses.TA_BRANCH_M_PENDING_RENEWAL)) {
							branch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_M_CEASED));
							branch.setCeasedDate(LocalDate.now());
							travelAgentRepository.save(branch);
						}
					}
				}
			}
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:
			statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TA_APP_RFA)) {
				taAlertMsg = Messages.Alerts.APP_RFA;
				taMsgType = Codes.EmailType.TA_UPON_RFA;
			}

			appHelper.rfa(appModel, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		taRenewalRepository.update(renewalModel);

		if (taAlertMsg != null) {
			if (!Strings.isNullOrEmpty(dto.getExternalRemarks())) {
				taAlertMsg += "Remarks:\n" + dto.getExternalRemarks();
			}

			/* Generate alert to notify TA */
			alertHelper.createAlert(taModel, appModel, taAlertMsg, Codes.Modules.MOD_TA, appModel.getType(), "../ta-renew-licence/" + appModel.getId(), cache.getStatus(statusCode), appAmount);

			/* Send email to notify TA & KE */
			String url = String.format(properties.applicationUrl, "ta-renew-licence/" + appModel.getId());
			emailHelper.emailTaRenewalUponAction(appModel, taMsgType, url, mainAppAmount, branchAmt);
		}

	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = taRenewalRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

}
