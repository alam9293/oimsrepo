package gov.stb.tag.controllers.ta;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.stakeholder.PersonnelDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderRecordDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderRecordsDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderItemDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.ta.TaStakeholderRepository;
import gov.stb.tag.repository.ta.TravelAgentRepository;

@RestController
@RequestMapping(path = "/api/v1/ta/personnel")
@Transactional
public class TaStakeholderController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaStakeholderRepository taStakeholderRepository;
	@Autowired
	TravelAgentRepository travelAgentRepository;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TaStakeholderItemDto> getPersonnels(TaStakeholderSearchDto searchDto) {

		return taStakeholderRepository.getPersonnels(searchDto);

	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public StakeholderRecordsDto getPersonnel(@PathVariable Integer id) {
		Stakeholder sh = taStakeholderRepository.getPersonnel(id);
		StakeholderRecordsDto dto = StakeholderRecordsDto.build(cache, new ArrayList<>(sh.getTaStakeholders()), sh, Boolean.FALSE, Boolean.TRUE);
		return dto;

	}

	/**
	 * For TA public users
	 * 
	 * @return
	 */
	@RequestMapping(value = "/load", method = RequestMethod.GET)
	public List<PersonnelDto> loadPersonnels() {
		User currentUser = taStakeholderRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = currentUser.getTravelAgent().getLicence();
		return taStakeholderRepository.getPersonnelByLicenceId(licence.getId());
	}

	@RequestMapping(value = "/load/full", method = RequestMethod.GET)
	public List<StakeholderRecordDto> loadFullPersonnels() {
		User currentUser = taStakeholderRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = currentUser.getTravelAgent().getLicence();
		List<StakeholderRecordDto> results = new ArrayList<>();
		for (TaStakeholder tsh : taStakeholderRepository.getFullPersonnelByLicenceId(licence.getId())) {
			results.add(StakeholderRecordDto.build(cache, tsh, tsh.getStakeholder(), Boolean.FALSE, Boolean.FALSE));
		}
		return results;
	}

	@RequestMapping(value = "/load/{id}", method = RequestMethod.GET)
	public StakeholderRecordDto loadPersonnelParticulars(@PathVariable Integer id) {
		User currentUser = taStakeholderRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = currentUser.getTravelAgent().getLicence();

		TaStakeholder tas = taStakeholderRepository.getPersonnelParticulars(id, true);
		if (tas != null && licence.getId().equals(tas.getLicence().getId())) {
			StakeholderRecordDto dto = StakeholderRecordDto.build(cache, tas, tas.getStakeholder(), Boolean.FALSE, Boolean.FALSE);
			return dto;
		}

		return null;
	}

	@RequestMapping(value = "/load/get-application-no/{appId}", method = RequestMethod.GET)
	public List<String> getAppNo(@PathVariable Integer appId) {
		return Arrays.asList(taStakeholderRepository.get(Application.class, appId).getApplicationNo());
	}

	@RequestMapping(path = { "/save/{isEdhPopulated}" }, method = RequestMethod.POST)
	public Integer saveApplication(@RequestBody List<StakeholderRecordDto> stakeholders, @PathVariable Boolean isEdhPopulated) throws IOException {

		User currentUser = taStakeholderRepository.getLicenseeUserByUserId(getUser().getId());
		Licence licence = currentUser.getTravelAgent().getLicence();

		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC) && !Objects.isNull(currentUser.getTravelAgent())) {

			// 1. Create Passive Application
			Application app = appHelper.saveNewApplication(Codes.ApplicationTypes.TA_APP_PERSONNEL, licence.getId(), false, false);
			appHelper.autoApprove(app, true);

			for (StakeholderRecordDto stakeholder : stakeholders) {
				if (!stakeholder.getInvolvement().getRole().getKey().toString().equals(Codes.TaStakeholderRoles.STKHLD_KE)) {
					// 2. Create TaStakeholderApplication
					TaStakeholderApplication newValue = new TaStakeholderApplication();
					newValue.setApplication(app);
					Address newAddress = new Address();
					newAddress.setAddressType(cache.getType(stakeholder.getParticulars().getAddress().getType().getKey().toString()));
					if (stakeholder.getParticulars().getAddress().getType().getKey().toString().equals(Codes.Types.ADDR_FOREIGN)) {
						newAddress.setForeignLine1(stakeholder.getParticulars().getAddress().getForeignLine1());
						newAddress.setForeignLine2(stakeholder.getParticulars().getAddress().getForeignLine2());
						newAddress.setForeignLine3(stakeholder.getParticulars().getAddress().getForeignLine3());
					} else {
						newAddress.setBlock(stakeholder.getParticulars().getAddress().getBlock());
						newAddress.setBuilding(stakeholder.getParticulars().getAddress().getBuilding());
						newAddress.setFloor(stakeholder.getParticulars().getAddress().getFloor());
						newAddress.setPostal(stakeholder.getParticulars().getAddress().getPostal());
						newAddress.setStreet(stakeholder.getParticulars().getAddress().getStreet());
						newAddress.setUnit(stakeholder.getParticulars().getAddress().getUnit());
					}
					newValue.setAddress(newAddress);
					newValue.setAppointedDate(stakeholder.getInvolvement().getAppointedDate());
					newValue.setCompanyIncorporatedDate(stakeholder.getParticulars().getCompanyIncorporatedDate());
					newValue.setCompanyUen(stakeholder.getParticulars().getCompanyUen());
					newValue.setContactNo(stakeholder.getParticulars().getContactNo());
					newValue.setEmail(stakeholder.getParticulars().getEmail());
					newValue.setIsCompany(stakeholder.getParticulars().getIsCompany());
					newValue.setName(stakeholder.getParticulars().getStakeholderName());
					newValue.setNationality(cache.getType(stakeholder.getParticulars().getNationality().getKey().toString()));
					newValue.setResignedDate(stakeholder.getInvolvement().getResignedDate());
					newValue.setRole(cache.getType(stakeholder.getInvolvement().getRole().getKey().toString()));
					newValue.setSex(cache.getType(stakeholder.getParticulars().getSex().getKey().toString()));
					newValue.setSharesHeld(stakeholder.getInvolvement().getSharesHeld());
					newValue.setUin(stakeholder.getParticulars().getUin());
					newValue.setIsEdhPopulated(isEdhPopulated);

					TaStakeholder tsh = new TaStakeholder();
					if (stakeholder.getInvolvement().getTaStakeholderId() != null) {
						tsh = taStakeholderRepository.getPersonnelParticulars(stakeholder.getInvolvement().getTaStakeholderId(), Boolean.FALSE);
						TaStakeholderApplication oldValue = new TaStakeholderApplication();
						oldValue = appHelper.snapshotCurrentStakeholder(oldValue, tsh);
						newValue.setPreviousValue(oldValue);
						taStakeholderRepository.save(oldValue);
					}
					taStakeholderRepository.save(newAddress);
					taStakeholderRepository.save(newValue);

					// 3. Update/Create Stakeholder/TaStakeholder
					tsh.setAppointedDate(stakeholder.getInvolvement().getAppointedDate());
					tsh.setLicence(licence);
					tsh.setResignedDate(stakeholder.getInvolvement().getResignedDate());
					tsh.setRole(cache.getType(stakeholder.getInvolvement().getRole().getKey().toString()));
					tsh.setSharesHeld(stakeholder.getInvolvement().getSharesHeld());

					if (stakeholder.getParticulars().getIsCompany() == null) {
						stakeholder.getParticulars().setIsCompany(false);
					}

					Stakeholder sh;
					if (stakeholder.getParticulars().getStakeholderId() != null) {
						sh = tsh.getStakeholder();
					} else {
						sh = travelAgentRepository
								.getSameStakeholder(stakeholder.getParticulars().getIsCompany() ? stakeholder.getParticulars().getCompanyUen() : stakeholder.getParticulars().getUin());
						if (sh == null) {
							sh = new Stakeholder();
						}
						tsh.setStakeholder(sh);
					}
					sh.setAddress(newAddress);
					sh.setCompanyIncorporatedDate(stakeholder.getParticulars().getCompanyIncorporatedDate());
					sh.setCompanyUen(stakeholder.getParticulars().getCompanyUen());
					sh.setContactNo(stakeholder.getParticulars().getContactNo());
					sh.setEmail(stakeholder.getParticulars().getEmail());
					sh.setIsCompany(stakeholder.getParticulars().getIsCompany());
					sh.setName(stakeholder.getParticulars().getStakeholderName());
					sh.setNationality(cache.getType(stakeholder.getParticulars().getNationality().getKey().toString()));
					sh.setSex(cache.getType(stakeholder.getParticulars().getSex().getKey().toString()));
					sh.setUin(stakeholder.getParticulars().getUin());
					taStakeholderRepository.save(sh);
					taStakeholderRepository.save(tsh);
				}

			}
			return app.getId();
		} else {
			throw new ValidationException("User not a valid TA");
		}

	}

}
