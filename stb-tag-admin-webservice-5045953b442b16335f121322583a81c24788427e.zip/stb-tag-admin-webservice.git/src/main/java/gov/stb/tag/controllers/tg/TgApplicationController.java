package gov.stb.tag.controllers.tg;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AssignDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.WorkflowActionSearchDto;
import gov.stb.tag.dto.tg.application.TgApplicationSearchDto;
import gov.stb.tag.dto.tg.application.TgApplicationSearchItemDto;
import gov.stb.tag.dto.tg.application.TgCourseApplicationSearchItemDto;
import gov.stb.tag.dto.tg.licenceprinting.TgLicencePrintingDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.tg.TgApplicationRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/applications")
@Transactional
public class TgApplicationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	// to retrieve all TG applications
	@RequestMapping(method = RequestMethod.GET, path = { "/view" })
	public ResultDto<TgApplicationSearchItemDto> getList(TgApplicationSearchDto searchDto) {
		return tgApplicationRepository.getTgApplicationsList(searchDto);
	}

	// to retrieve all TG course applications
	@RequestMapping(method = RequestMethod.GET, path = { "/view/courses" })
	public ResultDto<TgCourseApplicationSearchItemDto> getTgCourseApplications(TgApplicationSearchDto searchDto) {
		return tgApplicationRepository.getTgCourseApplicationsList(searchDto);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/view/{id}/workflow-actions")
	public ResultDto<WorkflowAction> getWorkflowActionsList(@PathVariable Integer id, WorkflowActionSearchDto searchDto) {
		ResultDto<WorkflowAction> results = tgApplicationRepository.getWorkflowActionsList(id, searchDto);
		var models = results.getModels();
		models.stream().forEach(u -> {
			var dto = new WorkflowActionDto(cache, u);
			results.getRecords()[models.indexOf(u)] = dto;
		});
		return results;
	}

	// to view licence print details
	@RequestMapping(value = "/view/licence-print-details/{applicationId}", method = RequestMethod.GET)
	public TgLicencePrintingDto getLicencePrintDetails(@PathVariable Integer applicationId) {
		Application application = tgApplicationRepository.getSingleApplicationById(applicationId);
		if (application == null) {
			throw new ValidationException("Application is null");
		}
		return TgLicencePrintingDto.buildLicencePrintingDetails(cache, application);
	}

	@RequestMapping(value = "/re-assign", method = RequestMethod.POST)
	public void reAssignAppWorkflow(@RequestBody AssignDto dto) {
		reAssignApplication(dto);
	}
}
