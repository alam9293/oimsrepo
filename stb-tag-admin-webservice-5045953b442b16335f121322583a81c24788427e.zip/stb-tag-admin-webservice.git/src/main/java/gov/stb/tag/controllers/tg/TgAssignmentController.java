package gov.stb.tag.controllers.tg;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentDateDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentItemDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentResultDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgAssignment;
import gov.stb.tag.model.TgAssignmentDate;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.LicenceStatusRepository;
import gov.stb.tag.repository.tg.TgAssignmentRepository;
import gov.stb.tag.repository.tg.TgLicenceRenewalRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/tg/assignments")
@Transactional
public class TgAssignmentController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgAssignmentRepository tgAssignmentRepository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	LicenceStatusRepository licenceRepository;

	@Autowired
	TgLicenceRenewalRepository tgLicenceRenewalRepository;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	EmailHelper emailHelper;

	@Autowired
	AlertHelper alertHelper;

	@Autowired
	LicenceHelper licenceHelper;

	/*
	 * to retrieve past 3 years based on licence'expiry year, from Public
	 */
	@RequestMapping(path = "/view/past-years/{number}", method = RequestMethod.GET)
	public List<ListableDto> getPastYears(@PathVariable Integer number) {
		Licence licence = touristGuideRepository.getTouristGuideByUserId(getUser().getId()).getLicence();
		return licenceHelper.getTgLicencePastYears(licence, number);
	}

	// to retrieve all submitted assignments
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgAssignmentItemDto> getAllList(TgAssignmentSearchDto searchDto) {
		return tgAssignmentRepository.getAssignments(searchDto, getUser().getTouristGuide().getId());
	}

	// to retrieve all submitted assignments by licence id
	@RequestMapping(value = "/view/licence/{licenceId}", method = RequestMethod.GET)
	public ResultDto<TgAssignmentItemDto> getAllListByLicence(TgAssignmentSearchDto searchDto, @PathVariable Integer licenceId) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(licenceId);
		return tgAssignmentRepository.getAssignments(searchDto, tg.getId());
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TgAssignmentResultDto getSingleRecord(@PathVariable Integer id) {
		TgAssignment ta = tgAssignmentRepository.getSingleAssignment(id);
		// validate that the id pass from front end belongs to log in user
		if (!ta.getTouristGuide().getId().equals(getUser().getTouristGuide().getId())) {
			throw new ValidationException("This assignment does not belong to the logged in user");
		}
		Licence l = licenceRepository.getLicenceDetailsByTgId(getUser().getTouristGuide().getId());
		TgAssignmentResultDto tarDto = TgAssignmentResultDto.buildSingleAssignment(cache, ta, l.getStartDate());
		return tarDto;
	}

	@RequestMapping(path = "/view/language-types", method = RequestMethod.GET)
	public List<ListableDto> getTgLanguageTypes() {
		TouristGuide tg = touristGuideRepository.getTouristGuideByUserId(getUser().getId());
		return toListableDtos(tg.getGuidingLanguages());
	}

	// to retrieve all submitted assignments for current cycle
	@RequestMapping(value = "/view/current", method = RequestMethod.GET)
	public ResultDto<TgAssignmentItemDto> getCurrentList(TgAssignmentSearchDto searchDto) {
		searchDto.setIsCurrentCycle(true);
		return tgAssignmentRepository.getAssignments(searchDto, getUser().getTouristGuide().getId());
	}

	@RequestMapping(value = "/view/current/{renewalId}", method = RequestMethod.GET)
	public ResultDto<TgAssignmentItemDto> getCurrentListWithId(TgAssignmentSearchDto searchDto, @PathVariable Integer renewalId) {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(renewalId);
		searchDto.setIsCurrentCycle(false);
		searchDto.setStartDate(renewal.getPreviousLicenceStartDate());
		searchDto.setEndDate(renewal.getPreviousLicenceExpiryDate());
		return tgAssignmentRepository.getAssignments(searchDto, renewal.getApplication().getLicence().getTouristGuide().getId());
	}

	// to save submitted assignment
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveAssignment(@RequestBody TgAssignmentDto dto) {
		TgAssignment ta = new TgAssignment();
		setAssignment(ta, dto);
		tgAssignmentRepository.save(ta);
	}

	// to update submitted assignment
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateAssignment(@RequestBody TgAssignmentDto dto) {
		TgAssignment ta = tgAssignmentRepository.getSingleAssignment(dto.getTgAssignmentId());
		tgAssignmentRepository.delete(ta.getTgAssignmentDates());
		setAssignment(ta, dto);
		tgAssignmentRepository.update(ta);
	}

	// to update assignment to delete
	@RequestMapping(value = "/update/delete", method = RequestMethod.POST)
	public void deleteAssignment(@RequestBody TgAssignmentDto dto) {
		TgAssignment ta = tgAssignmentRepository.getSingleAssignment(dto.getTgAssignmentId());
		// validate that the id pass from front end belongs to log in user
		if (!ta.getTouristGuide().getId().equals(getUser().getTouristGuide().getId())) {
			throw new ValidationException("This assignment does not belong to the logged in user");
		}
		ta.setIsDeleted(dto.isDeleted());
		tgAssignmentRepository.update(ta);
	}

	private void setAssignment(TgAssignment ta, TgAssignmentDto dto) {
		ta.setTouristGuide(getUser().getTouristGuide());
		ta.setType(cache.getType(dto.getTourType().getKey().toString()));
		if (dto.getTourType().getKey().toString().equals(Codes.Types.TG_ASN_TOUR_OTH)) {
			ta.setTourTypeOther(dto.getTourTypeOther());
		}
		ta.setStartDate(dto.getStartDate());
		ta.setEndDate(dto.getEndDate());
		ta.setEmploymentSource(cache.getType(dto.getEmploymentSourceType().getKey().toString()));
		if (dto.getEmploymentSourceType().getKey().toString().equals(Codes.Types.TG_ASN_EMP_SRC_OTH)) {
			ta.setEmploymentSourceTypeOther(dto.getEmploymentSourceTypeOther());
		}
		ta.setCompanyName(dto.getCompanyName());
		ta.setLanguage(cache.getType(dto.getLanguage()));
		ta.setFeeReceived(dto.getFeeReceived());
		ta.setIsDeleted(false);

		Set<TgAssignmentDate> tadSet = new HashSet<>();
		for (TgAssignmentDateDto td : dto.getTgAssignmentDates()) {
			TgAssignmentDate tad = new TgAssignmentDate();
			tad.setDate(DateUtil.parseDate(td.getDate()));
			tad.setNoOfHours(td.getNoOfHours());
			tad.setTgAssignment(ta);
			tadSet.add(tad);
		}
		tgAssignmentRepository.save(tadSet);
	}

}
