package gov.stb.tag.controllers.tg;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.candidate.TgCandidateDto;
import gov.stb.tag.dto.tg.candidate.TgCandidateItemDto;
import gov.stb.tag.dto.tg.candidate.TgCandidateSearchDto;
import gov.stb.tag.dto.tg.licencetierswitch.TgLicenceTierSwitchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PasswordHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TgLicenceTierSwitch;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.tg.TgCandidateRepository;
import gov.stb.tag.repository.tg.TgLicenceTierSwitchRepository;
import gov.stb.tag.repository.tg.TgTrainingProviderRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.EncryptionUtil;

@RestController
@RequestMapping(path = "/api/v1/tg/candidates")
@Transactional
public class TgCandidateController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgCandidateRepository repository;

	@Autowired
	TgTrainingProviderRepository tpRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	TgLicenceTierSwitchRepository tgLicenceTierSwitchRepository;

	@Autowired
	private PaymentRepository paymentRepository;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	EmailHelper emailHelper;

	@Autowired
	LicenceHelper licenceHelper;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	PasswordHelper passwordHelper;

	@Autowired
	PaymentHelper paymentHelper;

	@Autowired
	AlertHelper alertHelper;

	// to retrieve all TG Candidate
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgCandidate> getAllList(TgCandidateSearchDto searchDto) {
		ResultDto<TgCandidate> resultDto = repository.getTgCandidates(searchDto);

		Object[] finalRecords = new Object[resultDto.getRecords().length];
		var i = 0;
		for (TgCandidate tc : resultDto.getModels()) {
			var dto = new TgCandidateItemDto(cache, tc);
			finalRecords[i] = dto;
			i++;
		}
		resultDto.setRecords(finalRecords);
		return resultDto;
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TgCandidateDto getSingleCandidate(@PathVariable Integer id) {
		TgCandidate tc = repository.getTgCandidateById(id);
		User user = userRepository.getUserByTgCandidateId(id);
		TgCandidateDto resultDto = new TgCandidateDto(cache, tc, tc.getLastCandidateResult(), paymentHelper, user, true, repository);
		return resultDto;
	}

	@RequestMapping(value = "/view/result/{tgCandidateResultId}", method = RequestMethod.GET)
	public TgCandidateDto getSingleResult(@PathVariable Integer tgCandidateResultId) {
		TgCandidateResult tgCandidateResult = repository.getTgCandidateResultById(tgCandidateResultId);
		TgCandidate tgCandidate = tgCandidateResult.getTgCandidate();
		User user = userRepository.getUserByTgCandidateId(tgCandidate.getId());
		TgCandidateDto resultDto = new TgCandidateDto(cache, tgCandidate, tgCandidateResult, paymentHelper, user, true, repository);
		return resultDto;
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public TgCandidateDto getSingleCandidateByUin(@RequestParam String uin) {
		String requestedBy = getUser().getLoginId();
		String cddUin = StringUtils.trim(uin);

		logger.info("[{}] getSingleCandidateByUin() - Attempt to search tgCandidate by uin.", requestedBy);
		TgCandidate tc = repository.getTgCandidateByUin(cddUin);
		TgCandidateDto resultDto = new TgCandidateDto();
		if (tc != null) {
			logger.info("[{}] getSingleCandidateByUin() - tgCandidate.id={} is found.", requestedBy, tc.getId());
			User user = userRepository.getUserByTgCandidateId(tc.getId());
			resultDto = new TgCandidateDto(cache, tc, null, paymentHelper, user, false, repository);

			if (tc.getLicence() != null) {
				resultDto.setName(tc.getLicence().getTouristGuide() != null ? tc.getLicence().getTouristGuide().getName() : "");
			}
		} else if (tc == null) {
			logger.info("[{}] getSingleCandidateByUin() - Attempt to search touristGuide by uin.", requestedBy);
			TouristGuide touristGuide = touristGuideRepository.getTouristGuideByUin(cddUin);

			if (touristGuide != null) {
				logger.info("[{}] getSingleCandidateByUin() - Attempt to save tgCandidate with touristGuideId={} details.", requestedBy, touristGuide.getId());
				TgCandidate candidate = new TgCandidate();
				candidate.setUin(touristGuide.getUin());
				candidate.setFormerUin(touristGuide.getFormerUin());
				candidate.setLicence(touristGuide.getLicence());
				repository.save(candidate);
				tc = candidate;
				resultDto = TgCandidateDto.buildFromTouristGuide(cache, touristGuide, tc);
			}
		}

		if (tc == null) {
			logger.info("[{}] getSingleCandidateByUin() - tgCandidate with uin \"{}\" does not exist.", requestedBy, cddUin);
			resultDto.setUin(cddUin);
		}

		return resultDto;
	}

	// to save new candidate result
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveTgCandidate(@RequestPart(name = "dto") TgCandidateDto dto) {
		var user = getUser();

		// create candidate
		TgCandidate tgCandidate = new TgCandidate();
		logger.info("[{}] saveTgCandidate() - Attempt to get TgCandidate with id={}", user.getLoginId(), dto.getCandidateId());
		if (dto.getCandidateId() != null) {
			tgCandidate = repository.getTgCandidateById(dto.getCandidateId());
		} else {
			logger.info("[{}] saveTgCandidate() - TgCandidate with id={} does not exist. Creating new candidate.", user.getLoginId(), dto.getCandidateId());
			tgCandidate.setUin(StringUtils.trim(dto.getUin()));
			repository.save(tgCandidate);
		}

		// create candidate result
		logger.info("[{}] saveTgCandidate() - Saving new tgCandidateResult for candidate.id={}.", user.getLoginId(), tgCandidate.getId());
		TgCandidateResult tgCandidateResult = new TgCandidateResult();
		tgCandidateResult = saveTgCandidateResult(dto, tgCandidateResult, null, false);
		tgCandidateResult.setTgCandidate(tgCandidate);
		repository.save(tgCandidateResult);

		logger.info("[{}] saveTgCandidate - Set lastCandidateResult for candidate.id={} to lastCandidateResultId={}.", user.getLoginId(), tgCandidate.getId(), tgCandidateResult.getId());
		tgCandidate.setLastCandidateResult(tgCandidateResult);
		repository.update(tgCandidate);

		// create payment request for ATG - Assessment Path - ATO is STB
		createPayReqForATGExam(tgCandidate, tgCandidateResult);

		// waive payment if ATG exam fee is configured to be waived
		if (tgCandidateResult.getBillRefNo() != null) {
			List<String> payBill = paymentHelper.waivePayments(Arrays.asList(tgCandidateResult.getBillRefNo()));
			if (!payBill.isEmpty()) {// send email for TG Practical Assessment Fee
				User user1 = userRepository.getUserByLoginId(tgCandidate.getUin());
				if (user1 != null) {
					TouristGuide tg = user1.getTouristGuide();
					if (tg != null) {
						String url = String.format(properties.applicationUrl, "payment-list");
						emailHelper.emailTGOnPracticalAsessmentFee(tg, payBill, Codes.EmailType.ATG_PRACTICAL_ASSESSMENT_FEE);
						alertHelper.createAlert(tg, null, Messages.Alerts.ATG_PRACTICAL_ASSESSMENT_FEE, Codes.Modules.MOD_TG, cache.getType(Codes.TgPaymentRequestTypes.PAYREQ_TG_ATG_EXAM), url,
								payBill, null);
					}
				}
			}
		}

		// create candidate user if the result is last result
		if (tgCandidate.getLastCandidateResult() != null && tgCandidate.getLastCandidateResult().getId().equals(tgCandidateResult.getId())) {
			createUser(tgCandidate, tgCandidateResult);
		}

		return tgCandidate.getId();
	}

	// to update assessment
	@RequestMapping(value = "/save/result/{tgCandidateResultId}", method = RequestMethod.POST)
	public Integer updateAssessment(@RequestPart(name = "dto") TgCandidateDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles, @PathVariable Integer tgCandidateResultId) {
		var user = getUser();
		TgCandidateResult tgCandidateResult = repository.getTgCandidateResultById(tgCandidateResultId);

		logger.info("[{}] updateAssessment() - Updating tgCandidateResult.id={} for candidate.id={}", user.getLoginId(), tgCandidateResult.getId(), tgCandidateResult.getTgCandidate().getId());

		if (tgCandidateResult != null) {
			TgCandidate tgCandidate = tgCandidateResult.getTgCandidate();
			tgCandidateResult = saveTgCandidateResult(dto, tgCandidateResult, deletedFiles, false);
			repository.update(tgCandidateResult);
			createPayReqForATGExam(tgCandidateResult.getTgCandidate(), tgCandidateResult);

			// create candidate user and payment if the result is last result
			if (tgCandidate.getLastCandidateResult() != null && tgCandidate.getLastCandidateResult().getId().equals(tgCandidateResult.getId())) {
				createUser(tgCandidate, tgCandidateResult);
			}
		} else {
			String errorMsg = "TgCandidateResult with id=" + tgCandidateResultId + " does not exist.";
			logger.error("[{}] Unable to updateAssessment() -> e={}", user.getLoginId(), errorMsg);
			throw new ValidationException(errorMsg);
		}

		return tgCandidateResultId;
	}

	public Integer switchTgTier(TgCandidateResult tgCandidateResult, TgCandidate tgCandidate) {
		String requestedBy = getUser().getLoginId();

		// switch tier when result competent
		logger.info("[{}] switchTgTier() - Attempt to get TouristGuide with tgCandidateId={}", requestedBy, tgCandidate.getId());

		TouristGuide touristGuide = touristGuideRepository.getTouristGuideByLicenceId(tgCandidate.getLicence().getId());
		LocalDate examDate = tgCandidateResult.getExamDate();
		LocalDate licenceStartDate = touristGuide.getLicence().getStartDate();
		LocalDate licenceExpiryDate = touristGuide.getLicence().getExpiryDate();
		if (!tgCandidateResult.isDirectIssuance() && examDate.isBefore(licenceStartDate) && examDate.isAfter(licenceExpiryDate)) {
			String errorMsg = "Exam date not within current licence cycle.";
			logger.error("[{}] Unable to switchTgTier() -> e={}", requestedBy, errorMsg);
			throw new ValidationException(errorMsg);
		}

		saveSwitchTierApplication(touristGuide, tgCandidateResult, requestedBy);

		return tgCandidate.getId();
	}

	// to update assessment for switch tier
	@RequestMapping(value = "/save/switch-tier/{tgCandidateResultId}", method = RequestMethod.POST)
	public Integer updateSwitchTgTier(@RequestPart(name = "dto") TgCandidateDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles, @PathVariable Integer tgCandidateResultId) {
		var user = getUser();
		TgCandidateResult tgCandidateResult = repository.getTgCandidateResultById(tgCandidateResultId);

		logger.info("[{}] updateSwitchTgTier() - Updating tgCandidateResult.id={} for candidate.id={}", user.getLoginId(), tgCandidateResult.getId(), tgCandidateResult.getTgCandidate().getId());

		Licence licence = tgCandidateResult.getTgCandidate() != null ? tgCandidateResult.getTgCandidate().getLicence() : null;
		if (licence == null) {
			String errorMsg = "Licence for candidateId=" + dto.getCandidateId() + " does not exist.";
			logger.error("[{}] Unable to updateSwitchTgTier() -> e={}", user.getLoginId(), errorMsg);
			throw new ValidationException(errorMsg);
		}

		TouristGuide touristGuide = licence.getTouristGuide();
		if (touristGuide == null) {
			String errorMsg = "Tourist Guide for licenceNo=" + licence.getLicenceNo() + " does not exist.";
			logger.error("[{}] Unable to updateSwitchTgTier() -> e={}", user.getLoginId(), errorMsg);
			throw new ValidationException(errorMsg);
		}

		if (tgCandidateResult != null) {
			tgCandidateResult = saveTgCandidateResult(dto, tgCandidateResult, deletedFiles, false);
			repository.update(tgCandidateResult);

			TgLicenceTierSwitch tts = tgLicenceTierSwitchRepository.getTgLicenceTierSwitchByResultId(tgCandidateResult.getId());

			if (Boolean.FALSE.equals(tts.getPendingSwitch())) {
				String errorMsg = "Licence type has been switched to this result.";
				logger.error("[{}] Unable to updateSwitchTgTier() -> e={}", user.getLoginId(), errorMsg);
				throw new ValidationException(errorMsg);
			}

			if (tgCandidateResult.getSpecializedArea() != null) {
				tts.setSpecializedArea(tgCandidateResult.getSpecializedArea());
			}

			if (tgCandidateResult.getTier() != null && !licence.getTier().equals(tgCandidateResult.getTier())) {
				tts.setNewLicenceTier(tgCandidateResult.getTier());
			}

		} else {
			String errorMsg = "TgCandidateResult with id=" + tgCandidateResultId + " does not exist.";
			logger.error("[{}] Unable to updateAssessment() -> e={}", user.getLoginId(), errorMsg);
			throw new ValidationException(errorMsg);
		}

		return tgCandidateResultId;
	}

	// to enable/disabled portal id
	@RequestMapping(value = "/update/portal-id/{id}/{isPortalId}", method = RequestMethod.GET)
	public void updatePortalId(@PathVariable Integer id, @PathVariable Boolean isPortalId, @RequestParam String email) {
		TgCandidate tgCandidate = repository.get(TgCandidate.class, id);
		User user = userRepository.getUserByTgCandidateId(id);
		TgCandidateResult lastCandidateResult = tgCandidate.getLastCandidateResult();

		var userId = user.getId();
		var tgCandidateId = tgCandidate.getId();
		var loginId = getUser().getLoginId();

		if (isPortalId) {
			if (!Strings.isNullOrEmpty(email)) {
				lastCandidateResult.setEmail(email);
				user.setEmailAddress(email);
				repository.update(lastCandidateResult);
				logger.info("[{}] updatePortalId(). email for candidate.id={} is updated to tgCandidateResult.id={}", getUser().getLoginId(), lastCandidateResult.getTgCandidate().getId(),
						lastCandidateResult.getId());
			}

			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC_PORTAL));

			String NumericChars = "1234567890";
			String SpecialChars = "#$_&!";

			// random password
			String randPassword = PasswordHelper.GenerateRandomPassword(12, 12, 6, 2, 2, 2);

			// generate salt and hashed password
			String salt = EncryptionUtil.generateSalt();
			String hashedPassword = PasswordHelper.encode(randPassword, salt);

			// update user password
			user.setSalt(salt);
			user.setPassword(hashedPassword);
			userRepository.update(user);

			var emailAdd = lastCandidateResult.getEmail();

			// email user
			logger.info("[{}] updatePortalId() - Updated password for user.id:{}, tgCandidate.id={}.", loginId, userId, tgCandidateId);

			if (!Strings.isNullOrEmpty(emailAdd)) {
				emailHelper.emailUserLoginDetails(user, randPassword, Codes.EmailType.USER_LOGIN_DETAILS, emailAdd);
				logger.info("[{}] updatePortalId() - Login information for user.id:{}, tgCandidate.id={} sent to:{}.", loginId, userId, tgCandidateId, emailAdd);
			} else {
				throw new ValidationException("Email address is required.");
			}
		} else {
			if (Codes.UserTypes.USER_PUBLIC_PORTAL.equals(user.getType().getCode())) {
				user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
				// save current password to password history before setting password to null
				passwordHelper.moveCurrentPasswordToHistory(user);
				// set password to null (all singpass holder users account password is null)
				user.setPassword(null);
				user.setSalt(null);
				userRepository.update(user);
				logger.info("[{}] updatePortalId() - Portal ID is disabled for user.id:{}, tgCandidate.id={}.", loginId, userId, tgCandidateId);
			} else {
				logger.info("[{}] updatePortalId() - user.id:{}, tgCandidate.id={} login type is not portal ID.", loginId, userId, tgCandidateId);
			}
		}
	}

	// reset portal id password
	@RequestMapping(value = "/update/portal-id-password/{id}", method = RequestMethod.GET)
	public void updatePortalIdPassword(@PathVariable Integer id) {
		TgCandidate tgCandidate = repository.get(TgCandidate.class, id);
		User user = userRepository.getUserByTgCandidateId(id);
		TgCandidateResult lastCandidateResult = tgCandidate.getLastCandidateResult();

		// validate valid portal id
		if (!user.getType().getCode().equals(Codes.UserTypes.USER_PUBLIC_PORTAL)) {
			throw new ValidationException("Candidate does not have portal id enabled");
		}

		// save current password to password history before setting new password
		passwordHelper.moveCurrentPasswordToHistory(user);

		// random password
		String randPassword = PasswordHelper.GenerateRandomPassword(12, 12, 6, 2, 2, 2);

		// generate salt and hashed password
		String salt = EncryptionUtil.generateSalt();
		String hashedPassword = PasswordHelper.encode(randPassword, salt);

		// update user password
		user.setSalt(salt);
		user.setPassword(hashedPassword);
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setLoginCount(0);

		var emailAdd = lastCandidateResult.getEmail();
		var userId = user.getId();
		var tgCandidateId = tgCandidate.getId();
		var loginId = getUser().getLoginId();

		logger.info("[{}] updatePortalIdPassword() - Updated password for user.id:{}, tgCandidate.id={}.", loginId, userId, tgCandidateId);

		// email user
		if (!Strings.isNullOrEmpty(emailAdd)) {
			emailHelper.emailUserLoginDetails(user, randPassword, Codes.EmailType.USER_LOGIN_DETAILS, emailAdd);
			logger.info("[{}] updatePortalIdPassword() - Login information for user.id:{}, tgCandidate.id={} sent to:{}.", loginId, userId, tgCandidateId, emailAdd);
		}
	}

	/************* Switch Tier (TG) ****************/
	// view pending switch tier
	@RequestMapping(value = "/switch-tier/view", method = RequestMethod.GET)
	public TgLicenceTierSwitchDto getPendingLicenceTierSwitch() {
		var user = getUser();
		TgLicenceTierSwitch tts = tgLicenceTierSwitchRepository.getPendingTierSwitchByUin(user.getLoginId());
		TgLicenceTierSwitchDto resultDto = new TgLicenceTierSwitchDto();

		if (tts != null) {
			appHelper.isAppBelongToTG(tts, user, Codes.ApplicationTypes.TG_APP_SWITCH_TIER);
			resultDto = resultDto.buildFromTgLicenceTierSwitch(cache, tts, paymentHelper);
		}

		return resultDto;
	}

	// load switch tier upon officer switch tier

	@RequestMapping(value = { "/switch-tier/load/{id}", "/switch-tier/view/{id}" }, method = RequestMethod.GET)
	public TgLicenceTierSwitchDto getLicenceTierSwitchById(@PathVariable Integer id) {
		TgLicenceTierSwitch tts = tgLicenceTierSwitchRepository.getLicenceTierSwitchById(id);
		TgLicenceTierSwitchDto resultDto = new TgLicenceTierSwitchDto();
		return resultDto.buildFromTgLicenceTierSwitch(cache, tts, paymentHelper);
	}

	@RequestMapping(value = "/save/payment", method = RequestMethod.POST)
	public TgLicenceTierSwitchDto switchTierPayment(@RequestPart(name = "dto") TgLicenceTierSwitchDto itemDto) {

		User user = getUser();
		TgLicenceTierSwitch tts = tgLicenceTierSwitchRepository.getLicenceTierSwitchById(itemDto.getId());
		if (tts != null) {
			itemDto.setId(tts.getId());

			var application = tts.getApplication();
			if (application != null) {
				PaymentRequest pr = paymentHelper.savePaymentRequest(application.getApplicationNo(), Codes.TgPaymentRequestTypes.PAYREQ_TG_SWITCH_TIER, user.getLoginId(), user.getName(),
						new BigDecimal(itemDto.getPaymentFee()), "TG Switch Tier Fee", null, true, false);
				tts.setAppFeeBillRefNo(pr.getBillRefNo());
				itemDto.setAppFeeBillRefNo(pr.getBillRefNo());
				itemDto.setApplicationNo(application.getApplicationNo());
			}
		}

		return itemDto;
	}

	// switch tier after TG card payment made
	@RequestMapping(value = "/switch-tier/save/{id}", method = RequestMethod.GET)
	public TgLicenceTierSwitchDto switchTierAfterCardPayment(@PathVariable Integer id) {
		var user = getUser();
		var requestedBy = user.getLoginId();
		TgLicenceTierSwitchDto dto = new TgLicenceTierSwitchDto();

		// error checking
		TouristGuide touristGuide = touristGuideRepository.getTouristGuideByUserId(user.getId());
		if (touristGuide == null) {
			String errorMsg = "Tourist Guide does not exist.";
			logger.error("[{}] Unable to switchTierAfterCardPayment() -> e={}", requestedBy, errorMsg);
			throw new ValidationException(errorMsg);
		}

		Licence licence = touristGuide.getLicence();
		if (licence == null) {
			String errorMsg = "Licence for touristGuideId=" + touristGuide.getId() + " does not exist.";
			logger.error("[{}] Unable to switchTierAfterCardPayment() -> e={}", requestedBy, errorMsg);
			throw new ValidationException(errorMsg);
		}

		TgLicenceTierSwitch tts = tgLicenceTierSwitchRepository.getLicenceTierSwitchById(id);

		if (tts == null) {
			String errorMsg = "TG Licence Tier Switch application does not exist.";
			logger.error("[{}] Unable to switchTierAfterCardPayment() -> e={}", requestedBy, errorMsg);
			throw new ValidationException(errorMsg);
		} else if (tts.getAppFeeBillRefNo() == null) {
			String errorMsg = "Bill ref no does not exist.";
			logger.error("[{}] Unable to switchTierAfterCardPayment() -> e={}", requestedBy, errorMsg);
			throw new ValidationException(errorMsg);
		}

		PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(tts.getAppFeeBillRefNo());

		if (paymentRequest.getStatus().equals(cache.getStatus(Codes.Statuses.PAYREQ_PAID)) || paymentRequest.getStatus().equals(cache.getStatus(Codes.Statuses.PAYREQ_WAIVED))) {
			Application application = tts.getApplication();
			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));

			logger.info("[{}] switchTierAfterCardPayment() - Attempt to update tier and/or specialized area for touristGuideId={}", requestedBy, touristGuide.getId());
			saveSwitchTgTier(tts, licence, touristGuide, requestedBy);
		}

		dto = dto.buildFromTgLicenceTierSwitch(cache, tts, paymentHelper);

		return dto;
	}

	private void saveSwitchTgTier(TgLicenceTierSwitch tts, Licence licence, TouristGuide touristGuide, String requestedBy) {
		if (tts.getNewLicenceTier() != null) {
			// update status span
			Type prevTier = licence.getTier();
			Type nextTier = tts.getNewLicenceTier();
			TgCandidateResult result = tts.getTgCandidateResult();
			logger.info("[{}] switchTierAfterCardPayment() - Attempt to create status span for tg={}, prevTier={}, nextTier={}, statusCode={}", requestedBy, touristGuide.getId(), prevTier.getCode(),
					nextTier.getCode(), licence.getStatus().getCode());

			licence.setTier(nextTier);
			tts.setStartDate(LocalDate.now());
			licenceHelper.updateLicenceStatus(licence, licence.getStatus().getCode(), licence.getTier(), tts.getStartDate().atStartOfDay());
		}

		if (tts.getSpecializedArea() != null) {
			touristGuide.getSpecializedAreas().add(tts.getSpecializedArea());
		}

		tts.setPendingSwitch(false);
	}

	private TgCandidateResult saveTgCandidateResult(TgCandidateDto dto, TgCandidateResult tgCandidateResult, List<Integer> deletedFiles, Boolean isForSwitchTier) {
		tgCandidateResult.setName(dto.getName());
		tgCandidateResult.setEmail(Strings.isNullOrEmpty(dto.getEmail()) ? null : dto.getEmail());
		tgCandidateResult.setSpecializedArea(dto.getSpecializedArea() != null ? cache.getType(dto.getSpecializedArea()) : null);
		tgCandidateResult.setGuidingLanguage(dto.getGuidingLanguage() != null && Boolean.FALSE.equals(isForSwitchTier) ? cache.getType(dto.getGuidingLanguage()) : null);
		tgCandidateResult.setSelectedItinerary(dto.getSelectedItinerary() != null ? cache.getType(dto.getSelectedItinerary()) : null);
		tgCandidateResult.setExamDate(dto.getExamDate() != null ? dto.getExamDate() : null);
		tgCandidateResult.setIsDirectIssuance(dto.getIsDirectIssuance() != null ? Boolean.valueOf(dto.getIsDirectIssuance()) : Boolean.FALSE);
		tgCandidateResult.setDirectIssuanceDate(dto.getDirectIssuanceDate() != null ? dto.getDirectIssuanceDate() : null);
		tgCandidateResult.setTier(dto.getTier() != null ? cache.getType(dto.getTier()) : null);
		tgCandidateResult.setResult(dto.getResult() != null ? cache.getStatus(dto.getResult()) : null);
		tgCandidateResult.setChiefAssessor(Strings.isNullOrEmpty(dto.getChiefAssessor()) ? null : dto.getChiefAssessor());
		tgCandidateResult.setDeputyChiefAssessor(Strings.isNullOrEmpty(dto.getDeputyChiefAssessor()) ? null : dto.getDeputyChiefAssessor());
		tgCandidateResult.setAssessor(Strings.isNullOrEmpty(dto.getLanguageAssessor()) ? null : dto.getLanguageAssessor());
		tgCandidateResult.setRemarks(Strings.isNullOrEmpty(dto.getRemarks()) ? null : dto.getRemarks());

		if (dto.getDiGuidingLanguages() != null && Boolean.FALSE.equals(isForSwitchTier)) {
			Set<Type> guidingLanguages = new HashSet<>();
			for (String language : dto.getDiGuidingLanguages()) {
				guidingLanguages.add(cache.getType(language));
			}
			tgCandidateResult.setDiGuidingLanguages(guidingLanguages);
		}

		TgTrainingProvider tp = tpRepository.get(TgTrainingProvider.class, dto.getTgTrainingProvider());
		if (tp != null) {
			tgCandidateResult.setTgTrainingProvider(tp);
		}

		Set<File> files = new HashSet<>();
		// save file
		for (FileDto doc : dto.getSupportingDocs()) {
			File file = new File();
			if (doc.getId() == null) {
				file = fileHelper.saveFile(doc, false);
			} else {
				file = fileHelper.getFile(doc.getId());
			}
			files.add(file);
		}
		if (deletedFiles != null) {
			for (Integer fileId : deletedFiles) {
				File file = fileHelper.getFile(fileId);
				if (file != null) {
					fileHelper.deleteFile(file);
					logger.info("[{}] saveTgCandidateResult(), file.id={} deleted", getUser().getLoginId(), tgCandidateResult.getId(), fileId);
				}
			}
		}

		if (files.size() > 0) {
			tgCandidateResult.setFiles(files);
		}

		return tgCandidateResult;
	}

	private void createUser(TgCandidate tgCandidate, TgCandidateResult tgCandidateResult) {
		String requestedBy = getUser().getLoginId();
		// create user if result competent or direct issuance
		Boolean hasResult = false;

		if (tgCandidateResult.getResult() != null && tgCandidateResult.getExamDate() != null) {
			hasResult = Codes.Statuses.TG_CANDIDATE_RESULT_COMPETENT.equals(tgCandidateResult.getResult().getCode());
		}

		User user = userRepository.getUserByLoginId(tgCandidate.getUin());

		logger.info("[{}] createUser() - Attempt to create or update user for tgCandidate.id=[{}]", requestedBy, tgCandidate.getId());
		if ((hasResult || tgCandidateResult.isDirectIssuance()) && user != null) {
			// check role
			TouristGuide tg = user.getTouristGuide();
			if (tg != null) {
				// check licence status code and delicensed more than 6 years
				Licence licence = tg.getLicence();
				if (licence != null && Codes.Statuses.TG_INACTIVE.equals(licence.getStatus().getCode())) {
					int yearsBetween = Period.between(licence.getExpiryDate(), LocalDate.now()).getYears();
					if (yearsBetween > 6) {
						logger.info("[{}] createUser() - YearsBetween expiry date={}. Updating TouristGuide to TgCandidateId=[{}].", requestedBy, yearsBetween, tgCandidate.getId());
						user.getRoles().remove(cache.getRole(Codes.Roles.TG_PUBLIC));
						user.getRoles().add(cache.getRole(Codes.Roles.TG_CANDIDATE));
						user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
						user.setTouristGuide(null);
						user.setTgCandidate(tgCandidate);
						repository.update(user);
					}
				}

				// Create switch tier payment request if DirectIssuance or hasResult, Skip if payment request created
				TgLicenceTierSwitch licenceTierSwitch = repository.getTgLicenceTierSwitchById(tgCandidateResult.getId());
				if (licenceTierSwitch == null) {
					switchTgTier(tgCandidateResult, tgCandidate);
				}
			} else if (Codes.Statuses.USER_INACTIVE.equals(user.getStatus().getCode())) {
				logger.info("[{}] createUser() - Updating tgCandidate.user.status=[{}] to active.", getUser().getLoginId(), tgCandidate.getId());
				user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			}
		} else if ((!hasResult || !tgCandidateResult.isDirectIssuance()) && user != null) {
			// check role
			TouristGuide tg = user.getTouristGuide();
			if (tg != null) {
				// check licence status code and delicensed more than 6 years
				Licence licence = tg.getLicence();
				if (licence != null && Codes.Statuses.TG_INACTIVE.equals(licence.getStatus().getCode())) {
					int yearsBetween = Period.between(licence.getExpiryDate(), LocalDate.now()).getYears();
					if (yearsBetween > 6) {
						logger.info("[{}] createUser() -> YearsBetween expiry date=[{}]. Updating TouristGuide to TgCandidateId=[{}], user.status=[{}].", requestedBy, yearsBetween,
								tgCandidate.getId(), Codes.Statuses.USER_INACTIVE);
						user.getRoles().remove(cache.getRole(Codes.Roles.TG_PUBLIC));
						user.getRoles().add(cache.getRole(Codes.Roles.TG_CANDIDATE));
						user.setStatus(cache.getStatus(Codes.Statuses.USER_INACTIVE));
						user.setTouristGuide(null);
						user.setTgCandidate(tgCandidate);
						repository.update(user);
					}
				}
			} else {
				logger.info("[{}] createUser() - Updating tgCandidate.user.status=[{}] to inactive.", getUser().getLoginId(), tgCandidate.getId());
				user.setStatus(cache.getStatus(Codes.Statuses.USER_INACTIVE));
			}
		} else if ((hasResult || tgCandidateResult.isDirectIssuance()) && user == null) {
			logger.info("[{}] createUser() - Attempt to create user for tgCandidate.id=[{}].", getUser().getLoginId(), tgCandidate.getId());
			user = new User();
			user.setTgCandidate(tgCandidate);
			user.setLoginId(tgCandidate.getUin());
			user.setEmailAddress(tgCandidateResult.getEmail());
			user.setName(tgCandidateResult.getName());
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
			user.getRoles().add(cache.getRole(Codes.Roles.TG_CANDIDATE));
			repository.save(user);
		}
	}

	private void createPayReqForATGExam(TgCandidate tgCandidate, TgCandidateResult tgCandidateResult) {
		// create payment request for ATG - Assessment Path - ATO is STB, if no payReq created before
		if (StringUtils.isBlank(tgCandidateResult.getBillRefNo())) {
			if (Codes.Types.TG_TIER_AREA.equals(tgCandidateResult.getTier().getCode()) && Boolean.FALSE.equals(tgCandidateResult.isDirectIssuance())
					&& StringUtils.equals("Singapore Tourism Board", tgCandidateResult.getTgTrainingProvider().getName())) {
				String createdDt = DateUtil.format(LocalDate.now(), DateUtil.REPORT_DATE_FORMAT_PATTERN);
				String refNo = "TG_ATG_".concat(tgCandidateResult.getId().toString()).concat("_").concat(createdDt);
				logger.info("createPayReqForATGExam() - Creating payment request refNo=[{}] for tgCandidateResult.id=[{}]", refNo, tgCandidateResult.getId());
				PaymentRequest atgPayReq = paymentHelper.savePaymentRequest(refNo, Codes.TgPaymentRequestTypes.PAYREQ_TG_ATG_EXAM, tgCandidate.getUin(), tgCandidateResult.getName(),
						new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TG_ATG_EXAM_FEE).getValue()), "ATG Practical Assessment Fee", null, Boolean.FALSE, Boolean.FALSE);
				tgCandidateResult.setBillRefNo(atgPayReq.getBillRefNo());
			}
		}
	}

	private void saveSwitchTierApplication(TouristGuide touristGuide, TgCandidateResult tgCandidateResult, String requestedBy) {

		logger.info("[{}] saveSwitchTierApplication() - Attempt to create switch tier application for tg={}", requestedBy, touristGuide.getId());
		Licence licence = touristGuide.getLicence();
		Boolean sameTier = false;
		Boolean areaExists = false;
		Type newLicenceTier = tgCandidateResult.getTier();

		if (licence.getTier().equals(tgCandidateResult.getTier()) || Codes.Types.TG_TIER_GENERAL_AREA.equals(licence.getTier().getCode())) {
			sameTier = true;
			newLicenceTier = cache.getType(licence.getTier().getCode());
		} else {
			if ((Codes.Types.TG_TIER_GENERAL.equals(licence.getTier().getCode()) && Codes.Types.TG_TIER_AREA.equals(tgCandidateResult.getTier().getCode()))
					|| (Codes.Types.TG_TIER_AREA.equals(licence.getTier().getCode()) && Codes.Types.TG_TIER_GENERAL.equals(tgCandidateResult.getTier().getCode()))) {
				newLicenceTier = cache.getType(Codes.Types.TG_TIER_GENERAL_AREA);
			}
		}

		for (Type area : touristGuide.getSpecializedAreas()) {
			if (tgCandidateResult.getSpecializedArea() != null && area.equals(tgCandidateResult.getSpecializedArea())) {
				areaExists = true;
			}
		}

		if ((tgCandidateResult.getSpecializedArea() != null && sameTier && areaExists) || (tgCandidateResult.getSpecializedArea() == null && sameTier)) {
			String errorMsg = "Unable to switch tier. Tier is same as previous tier and/or no addition in specialized area.";
			logger.error("[{}] Unable to saveSwitchTierApplication() -> e={}", requestedBy, errorMsg);
		} else {
			// create TG Licence Tier Switch
			logger.info("[{}] saveSwitchTierApplication() - Attempt to create TG switch tier application.", requestedBy);
			TgLicenceTierSwitch tts = new TgLicenceTierSwitch();
			tts.setPendingSwitch(Boolean.TRUE);
			tts.setTgCandidateResult(tgCandidateResult);

			LocalDate startDt = tgCandidateResult.getExamDate() != null ? tgCandidateResult.getExamDate() : tgCandidateResult.getDirectIssuanceDate();
			tts.setStartDate(startDt);
			if (tgCandidateResult.getTier() != null) {
				tts.setOldLicenceTier(licence.getTier());
				tts.setNewLicenceTier(newLicenceTier);
			}
			if (tgCandidateResult.getSpecializedArea() != null) {
				tts.setSpecializedArea(tgCandidateResult.getSpecializedArea());
			}
			repository.save(tts);

			Application application = appHelper.saveNewApplication(Codes.ApplicationTypes.TG_APP_SWITCH_TIER, touristGuide.getLicence().getId(), false, true);
			application.setIsDraft(false);

			if (application != null) {
				logger.info("[{}] saveSwitchTierApplication() - Saving TG switch tier payment request for applicationId={}", requestedBy, application.getId());
				String createdDt = DateUtil.format(LocalDate.now(), DateUtil.REPORT_DATE_FORMAT_PATTERN);
				String refNo = "TG-".concat(createdDt).concat("-").concat(tgCandidateResult.getId().toString());
				PaymentRequest pr = paymentHelper.savePaymentRequest(refNo, Codes.TgPaymentRequestTypes.PAYREQ_TG_SWITCH_TIER, touristGuide.getUin(), touristGuide.getName(),
						new BigDecimal(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue())), "Change of Guiding Category", null, true, false,
						touristGuide.getEmailAddress());
				application.setApplicationNo(refNo);
				application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PAYMENT));
				application.setSubmissionDate(LocalDateTime.now());
				tts.setApplication(application);
				tts.setAppFeeBillRefNo(pr.getBillRefNo());
				appHelper.forward(application, true);
			}

			// waive payment if TG licence switch Tier fee is configured to be waived
			if (tts.getAppFeeBillRefNo() != null) {
				List<String> payBills = paymentHelper.waivePayments(Arrays.asList(tts.getAppFeeBillRefNo()));
				if (CollectionUtils.isEmpty(payBills)) {// If payment is waived, directly update TG licence tier code
					application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));
					saveSwitchTgTier(tts, licence, touristGuide, requestedBy);
				} else {
					String url = String.format(properties.applicationUrl, "tg/switch-tier");
					String specialisedArea = null;
					if (tgCandidateResult != null && tgCandidateResult.getSpecializedArea() != null) {
						specialisedArea = tgCandidateResult.getSpecializedArea().getLabel();
					}
					emailHelper.emailTGOnSwitchTierFee(touristGuide, payBills, application, Codes.EmailType.TG_LICENCE_SWITCH_TIER_FEE, url, specialisedArea);
					alertHelper.createAlert(touristGuide, application, Messages.Alerts.TG_LICENCE_SWITCH_TIER_FEE, Codes.Modules.MOD_TG, cache.getType(Codes.ApplicationTypes.TG_APP_SWITCH_TIER),
							"tg/switch-tier", payBills, specialisedArea);
				}
			}

			tgCandidateResult.setIsForSwitchTier(true);
		}
	}

}
