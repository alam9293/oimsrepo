package gov.stb.tag.controllers.tg;

import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.TgCourseSubsidyDto;
import gov.stb.tag.dto.tg.course.TgCourseAttendanceDetailDto;
import gov.stb.tag.dto.tg.course.TgCourseAttendanceDto;
import gov.stb.tag.dto.tg.course.TgCourseAttendanceNewDto;
import gov.stb.tag.dto.tg.course.TgCourseAttendanceSearchDto;
import gov.stb.tag.dto.tg.course.TgCourseDto;
import gov.stb.tag.dto.tg.course.TgCourseItemDto;
import gov.stb.tag.dto.tg.course.TgCourseResultDto;
import gov.stb.tag.dto.tg.course.TgCourseSearchDto;
import gov.stb.tag.dto.tg.trainingprovider.TgTrainingProviderItemDto;
import gov.stb.tag.dto.tg.trainingprovider.TgTrainingProviderSearchDto;
import gov.stb.tag.dto.tg.trainingprovider.TrainingProviderDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.TgCourseHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgCourseAttendanceDetail;
import gov.stb.tag.model.TgCourseSubsidy;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.LicenceStatusRepository;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgCourseAttendanceDetailRepository;
import gov.stb.tag.repository.tg.TgCourseAttendanceRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgLicenceRenewalRepository;
import gov.stb.tag.repository.tg.TgTrainingProviderRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/")
@Transactional
public class TgCourseController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	TgCourseRepository tgCourseRepository;

	@Autowired
	TgTrainingProviderRepository tgTrainingProviderRepository;

	@Autowired
	TgCourseAttendanceRepository tgCourseAttendanceRepository;

	@Autowired
	TgCourseAttendanceDetailRepository tgCourseAttendanceDetailRepository;

	@Autowired
	LicenceStatusRepository licenceRepository;

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	@Autowired
	TgLicenceRenewalRepository tgLicenceRenewalRepository;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	LicenceHelper licenceHelper;

	@Autowired
	TgCourseHelper tgCourseHelper;

	/*
	 * Admin
	 */
	@RequestMapping(value = "tg/courses/view", method = RequestMethod.GET)
	public ResultDto<TgCourseItemDto> getCourses(TgCourseSearchDto searchDto) throws UnsupportedEncodingException {

		return tgCourseRepository.getTgCourses(searchDto);
	}

	@RequestMapping(path = { "tg/courses/view/{code}", "tp/pdc/courses/view/{code}" }, method = RequestMethod.GET)
	public TgCourseDto getTgCourses(@PathVariable String code) {

		TgCourseDto dto = tgCourseHelper.getTgCourseByCode(code);
		if (getSelectedRoleCode().equals(Codes.Roles.TP_PUBLIC)) {
			tgCourseHelper.isTgCourseBelongToTp(getUser().getTgTrainingProvider(), tgCourseRepository.getTgCourseWithTpByCode(code), null);
			dto.setCanBeRenewed(tgCourseHelper.checkIsCourseEligibleToRenew(tgCourseRepository.get(TgCourse.class, code)));
		}
		return dto;
	}

	@RequestMapping(value = "tg/courses/view/{code}/all-cycles", method = RequestMethod.GET)
	public List<TgCourseItemDto> getCourseCycles(@PathVariable String code) {
		return tgCourseRepository.getTgCourseCycles(code);
	}

	@RequestMapping(path = { "tg/courses/save", "tp/pdc/courses/save" }, method = RequestMethod.POST)
	public String saveCourse(@RequestBody TgCourseDto dto) {

		TgTrainingProvider tp = null;

		if (getSelectedRoleCode().equals(Codes.Roles.TP_PUBLIC)) {
			tp = getUser().getTgTrainingProvider();
			dto.setTgTrainingProviderId(tp.getId());
		} else {
			tp = tgCourseRepository.get(TgTrainingProvider.class, dto.getTgTrainingProviderId());
		}

		TgCourse course = new TgCourse();
		course.setCode(tgCourseHelper.generateCourseCode(tp));
		setCourse(course, dto);

		tgCourseRepository.save(course);

		return course.getCode();
	}

	@RequestMapping(path = { "tg/courses/update", "tp/pdc/courses/update" }, method = RequestMethod.POST)
	public String updateCourse(@RequestBody TgCourseDto dto) {

		TgCourse course = tgCourseRepository.get(TgCourse.class, dto.getCode());
		if (getSelectedRoleCode().equals(Codes.Roles.TP_PUBLIC)) {
			tgCourseHelper.isTgCourseBelongToTp(getUser().getTgTrainingProvider(), course, null);
			dto.setTgTrainingProviderId(getUser().getTgTrainingProvider().getId());
		}

		setCourse(course, dto);

		return course.getCode();
	}

	@RequestMapping(value = "tg/courses/update/delete/{code}", method = RequestMethod.GET)
	public void updateCourse(@PathVariable String code) {
		TgCourse course = tgCourseRepository.get(TgCourse.class, code);
		course.setIsDeleted(true);
		tgCourseRepository.update(course);

		for (TgCourseAttendance tgCourseAttendance : course.getTgCourseAttendances()) {
			deleteCourseAttendance(tgCourseAttendance.getId());
		}
	}

	// TODO: Move to TP module
	@RequestMapping(value = "tg/courses/view/tp", method = RequestMethod.GET)
	public List<ListableDto> getTps() {
		return toListableDtos(tgTrainingProviderRepository.getTrainingProviders());
	}

	@RequestMapping(value = "tg/courses/view/tp/{tgCourseTypeCode}", method = RequestMethod.GET)
	public List<ListableDto> getTps(@PathVariable String tgCourseTypeCode) {
		return toListableDtos(tgTrainingProviderRepository.getTrainingProviders(tgCourseTypeCode));
	}

	/*
	 * TG
	 */

	/*
	 * Call from public user
	 */
	@RequestMapping(path = "tg/course/view/past-years/{number}", method = RequestMethod.GET)
	public List<ListableDto> getPastYears(@PathVariable Integer number) {
		Licence licence = touristGuideRepository.getTouristGuideByUserId(getUser().getId()).getLicence();
		return licenceHelper.getTgLicencePastYears(licence, number);
	}

	// to retrieve all courses belonging to TG
	@RequestMapping(value = "tg/course/view", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getListOfCourseByTgId(TgCourseAttendanceSearchDto searchDto) {
		ResultDto<TgCourseResultDto> tc = tgCourseRepository.getAllListOfCourseByTgId(searchDto, getUser().getTouristGuide().getId());

		Object[] finalRecords = new Object[tc.getRecords().length];
		var i = 0;
		for (Object obj : tc.getRecords()) {
			TgCourseAttendance tca = (TgCourseAttendance) obj;
			var dto = TgCourseResultDto.setListOfTgCourse(cache, tca);
			finalRecords[i] = dto;
			i++;
		}

		tc.setRecords(finalRecords);
		return tc;
	}

	// to retrieve all courses belonging to TG by Licence ID
	@RequestMapping(value = "tg/course/view/{licenceId}", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getListOfCourseByLicenceId(TgCourseAttendanceSearchDto searchDto, @PathVariable Integer licenceId) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(licenceId);
		ResultDto<TgCourseResultDto> tc = tgCourseRepository.getAllListOfCourseByTgId(searchDto, tg.getId());

		Object[] finalRecords = new Object[tc.getRecords().length];
		var i = 0;
		for (Object obj : tc.getRecords()) {
			TgCourseAttendance tca = (TgCourseAttendance) obj;
			var dto = TgCourseResultDto.setListOfTgCourse(cache, tca);
			finalRecords[i] = dto;
			i++;
		}

		tc.setRecords(finalRecords);
		return tc;
	}

	// to retrieve current courses belonging to TG
	@RequestMapping(value = "tg/course/view/current", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getCurrentListOfCourseByTgId(TgCourseAttendanceSearchDto searchDto) {

		return getCurrentListOfCourseByTgId(searchDto, getUser().getTouristGuide().getId());

	}

	// to retrieve all courses
	@RequestMapping(value = "tg/course/view/calendar", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getListOfCalendarCourses(TgCourseAttendanceSearchDto searchDto) {

		ResultDto<TgCourseResultDto> tc = tgCourseRepository.getAllListOfCourse(searchDto);

		Object[] finalRecords = new Object[tc.getRecords().length];
		var i = 0;
		for (Object obj : tc.getRecords()) {
			TgCourseAttendance tca = (TgCourseAttendance) obj;
			var dto = TgCourseResultDto.setListOfTgCourse(cache, tca);
			finalRecords[i] = dto;
			i++;
		}

		tc.setRecords(finalRecords);
		return tc;

	}

	@RequestMapping(value = "tg/course/view/calendar/{code}", method = RequestMethod.GET)
	public TgCourseDto getTgCalendarCourse(@PathVariable String code) {

		return tgCourseHelper.getTgCourseByCode(code);

	}

	// to retrieve all tps
	@RequestMapping(value = "tg/course/view/calendar/tp", method = RequestMethod.GET)
	public ResultDto<TgTrainingProviderItemDto> getListOfCalendarTp(TgTrainingProviderSearchDto searchDto) {
		searchDto.setTpTypes(new String[] { "pdc" });
		searchDto.setStatus(Codes.Statuses.USER_ACTIVE);
		return tgTrainingProviderRepository.getList(searchDto);
	}

	@RequestMapping(value = "tg/course/view/calendar/tp/{id}", method = RequestMethod.GET)
	public TrainingProviderDto getTgCalendarCourse(@PathVariable Integer id) {
		TgTrainingProvider tgTrainingProvider = tgTrainingProviderRepository.getTgTrainingProviderById(id);
		return new TrainingProviderDto(cache, tgTrainingProvider);
	}

	@RequestMapping(value = "tg/course/view/current/{renewalId}", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getCurrentListOfCourseByRenewalId(TgCourseAttendanceSearchDto searchDto, @PathVariable Integer renewalId) {

		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(renewalId);
		return getRenewalCycleCourseList(searchDto, renewal);

	}

	/*
	 * PDC
	 */

	// to retrieve courses belong to TP
	@RequestMapping(value = "tp/pdc/view/listOfCourse/{attendedDate}", method = RequestMethod.GET)
	public List<TgCourseResultDto> getListOfCourse(@PathVariable String attendedDate) {
		List<TgCourseResultDto> listTgCourse = new ArrayList<TgCourseResultDto>();
		List<TgCourse> tc = tgCourseRepository.getListOfCourseByTpId(attendedDate, getUser().getTgTrainingProvider().getId());
		for (int i = 0; i < tc.size(); i++) {
			TgCourseResultDto dto = TgCourseResultDto.buildFromAssignment(cache, tc.get(i));
			listTgCourse.add(dto);
		}
		return listTgCourse;
	}

	// to retrieve list of selected course details belong to TP
	@RequestMapping(value = "tp/pdc/view", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getListOfCourseDetails(TgCourseAttendanceSearchDto searchDto) {
		return getListOfCourseDetailsSearch(searchDto, Codes.Types.TP_COURSE_PDC);
	}

	// to retrieve name from licenceNo.
	@RequestMapping(value = "tp/pdc/view/name/{licenceNo}", method = RequestMethod.GET)
	public String getPdcName(@PathVariable String licenceNo) {
		return tgCourseRepository.getTgName(licenceNo);
	}

	// to save submitted course attendance
	@RequestMapping(value = "tp/pdc/save", method = RequestMethod.POST)
	public void saveCourseAttendance(@RequestPart(name = "dto") TgCourseAttendanceNewDto dto) {
		// validate no duplicated course
		checkForDuplicatedCourse(dto.getCourseCode(), dto.getAttendedDate());

		// validate licence no
		Set<TgCourseAttendanceDetailDto> attendeeRows = dto.getTgCourseAttendanceDetails();
		checkForDuplicatedLicensee(attendeeRows, null);
		checkLicenceValid(attendeeRows);

		// create application
		Application application = new Application();
		application.setIsDraft(false);
		application.setSubmissionDate(LocalDateTime.now());
		application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
		application.setTaTgType(Codes.TaTgType.TG);
		application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_PDC_SUBMISSION));
		tgApplicationRepository.save(application);

		appHelper.forward(application, true);

		// create course attendance
		TgCourseAttendance tca = new TgCourseAttendance();
		tca.setAttendedDate(dto.getAttendedDate());
		tca.setAttendedEndDate(dto.getAttendedEndDate());
		tca.setApplication(application);
		tca.setTgCourse(tgCourseRepository.load(TgCourse.class, dto.getCourseCode()));
		tgCourseAttendanceRepository.save(tca);

		// save file
		saveFile(application, dto);

		// create course attendance detail
		addUpdateCourseAttendanceDetail(attendeeRows, tca);
	}

	@RequestMapping(value = "tp/pdc/view/{attendanceId}", method = RequestMethod.GET)
	public TgCourseAttendanceDto getCourseAttendanceDetails(@PathVariable Integer attendanceId) {
		TgCourseAttendance tca = tgCourseRepository.getCourseAttendanceById(attendanceId, getTpId());
		TgCourseAttendanceDto dto = TgCourseAttendanceDto.buildFromCourseAttendance(cache, tca);
		return dto;
	}

	@RequestMapping(value = "tp/pdc/update", method = RequestMethod.POST)
	public TgCourseAttendanceDto savePDCAttendanceDetails(@RequestPart(name = "dto") TgCourseAttendanceDto dto) {
		TgCourseAttendance tca = tgCourseAttendanceRepository.get(TgCourseAttendance.class, dto.getAttendanceId());

		// validate licence no
		Set<TgCourseAttendanceDetailDto> attendeeRows = dto.getAttendeeRows();
		checkForDuplicatedLicensee(attendeeRows, dto.getAttendanceId());
		checkLicenceValid(attendeeRows);

		// update course code
		if (!tca.getTgCourse().getCode().equals(dto.getCourseCode())) {
			tca.setTgCourse(tgCourseRepository.load(TgCourse.class, dto.getCourseCode()));
		}

		// update course conducted date
		tca.setAttendedDate(dto.getCourseDate());
		tca.setAttendedEndDate(dto.getCourseEndDate());

		// save file
		updateFile(tca.getApplication(), dto);

		// add and update
		addUpdateCourseAttendanceDetail(attendeeRows, tca);

		// delete
		removeCourseAttendanceDetail(dto.getRemoveAttendeeRows());
		return dto;
	}

	@RequestMapping(value = "tp/pdc/update/delete/{attendanceId}", method = RequestMethod.GET)
	public void deletePDCAttendance(@PathVariable Integer attendanceId) {
		deleteCourseAttendance(attendanceId);
	}

	// to retrieve approved courses belong to TP
	@RequestMapping(value = "tp/pdc/courses/view", method = RequestMethod.GET)
	public ResultDto<TgCourseItemDto> getTpCourses(TgCourseSearchDto searchDto) {
		searchDto.setTrainingProviderId(getUser().getTgTrainingProvider().getId());
		return tgCourseRepository.getTpCourses(searchDto);
	}

	/*
	 * MRC
	 */

	@RequestMapping(value = "tp/mrc/view", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getMRCList(TgCourseAttendanceSearchDto searchDto) {
		return getListOfCourseDetailsSearch(searchDto, Codes.Types.TP_COURSE_MRC);
	}

	@RequestMapping(value = "tp/mrc/view/{attendanceId}", method = RequestMethod.GET)
	public TgCourseAttendanceDto getMRCAttendanceDetails(@PathVariable Integer attendanceId) {
		TgCourseAttendance tca = tgCourseRepository.getCourseAttendanceById(attendanceId, getTpId());
		TgCourseAttendanceDto dto = TgCourseAttendanceDto.buildFromCourseAttendance(cache, tca);
		return dto;
	}

	// to retrieve name from licenceNo.
	@RequestMapping(value = "tp/mrc/view/name/{licenceNo}", method = RequestMethod.GET)
	public String getMrcName(@PathVariable String licenceNo) {
		return tgCourseRepository.getTgName(licenceNo);
	}

	@RequestMapping(value = "tp/mrc/save", method = RequestMethod.POST)
	public void newMrcAttendance(@RequestPart(name = "dto") TgCourseAttendanceNewDto dto) {

		// validate licence no
		Set<TgCourseAttendanceDetailDto> attendeeRows = dto.getTgCourseAttendanceDetails();
		checkLicenceValid(attendeeRows);

		// create application
		Application application = new Application();
		application.setIsDraft(false);
		application.setSubmissionDate(LocalDateTime.now());
		application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
		application.setTaTgType(Codes.TaTgType.TG);
		application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_MRC_SUBMISSION));
		tgApplicationRepository.save(application);

		appHelper.forward(application, true);

		// create course attendance
		TgCourseAttendance tca = new TgCourseAttendance();
		tca.setAttendedDate(dto.getAttendedDate());
		tca.setApplication(application);
		if (dto.getCourseCode() != null) {
			tca.setTgCourse(tgCourseRepository.load(TgCourse.class, dto.getCourseCode()));
		} else {
			tca.setTgCourse(tgCourseRepository.getTgCourseByTypeAndTpId(Codes.Types.TP_COURSE_MRC, getUser().getTgTrainingProvider().getId()));
		}
		tgCourseAttendanceRepository.save(tca);

		// save file
		saveFile(application, dto);

		// create course attendance detail
		addUpdateCourseAttendanceDetail(attendeeRows, tca);
	}

	private void checkForDuplicatedCourse(String courseCode, LocalDate startDate) {
		if (tgCourseAttendanceRepository.hasExistingAttendanceForCourse(courseCode, startDate)) {
			throw new ValidationException("TP has already submitted an attendance for this course");
		}
	}

	private void checkForDuplicatedLicensee(Set<TgCourseAttendanceDetailDto> attendeeRows, Integer attendanceId) {
		if (attendeeRows != null && attendeeRows.size() > 0) {
			List<String> duplicatedLicenceNo = new ArrayList<>();
			List<String> licenceNo = new ArrayList<>();
			attendeeRows.stream().forEach(o -> licenceNo.add(o.getLicenceNo()));
			licenceNo.stream().filter(i -> Collections.frequency(licenceNo, i) > 1).collect(Collectors.toSet()).forEach(o -> duplicatedLicenceNo.add(o));
			if (!duplicatedLicenceNo.isEmpty()) {
				String toPrint = "";
				for (String aString : duplicatedLicenceNo) {
					toPrint = toPrint + " " + aString;
				}
				throw new ValidationException("Duplicated Licence No found: " + toPrint);
			}

			// To cater concurrent duplicate licence no in DB
			if (attendanceId != null) {
				String toPrintConcurrent = "";
				for (TgCourseAttendanceDetailDto dto : attendeeRows) {
					if (dto.getAttendanceDetailId() == null) {
						Integer licenceId = tgCourseRepository.getTouristGuideIdByLicenceNo(dto.getLicenceNo());
						Integer size = tgCourseAttendanceDetailRepository.checkDuplicateLicenceNo(licenceId, attendanceId);
						if (size > 0) {
							toPrintConcurrent = toPrintConcurrent + " " + dto.getLicenceNo();
						}
					}
				}

				if (!Strings.isNullOrEmpty(toPrintConcurrent)) {
					throw new ValidationException("Duplicated Licence No found in Database: " + toPrintConcurrent);
				}
			}

		}

	}

	private void checkLicenceValid(Set<TgCourseAttendanceDetailDto> attendeeRows) {
		if (attendeeRows != null && attendeeRows.size() > 0) {
			// List<String> licenceNoList = attendeeRows.stream().map(u -> u.getLicenceNo()).collect(Collectors.toList());
			//
			// List<Licence> licenceList = licenceRepository.getLicenceListByLicenceNo(licenceNoList);
			// List<String> existLicenceNos = licenceList.stream().map(u -> u.getLicenceNo()).collect(Collectors.toList());
			//
			// List<String> invalidLicNos = licenceNoList.stream().filter(u -> !existLicenceNos.contains(u)).collect(Collectors.toList());
			//
			// if (invalidLicNos != null && invalidLicNos.size() > 0) {
			// throw new ValidationException("Invalid licence number found : " + StringUtils.join(invalidLicNos, ", "));
			// }

			List<String> receivedLicenceNoLists = new ArrayList<String>();
			List<String> receivedLicenceNameLists = new ArrayList<String>();
			for (TgCourseAttendanceDetailDto tcaDto : attendeeRows) {
				receivedLicenceNoLists.add((tcaDto.getLicenceNo()));
				receivedLicenceNameLists.add((tcaDto.getName()));
			}
			List<Licence> licenceLists = licenceRepository.getLicenceListByLicenceNo(receivedLicenceNoLists, Codes.TaTgType.TG);
			// store list of licence no pulled from licence repo
			List<String> licenceNoThatExistList = licenceLists.stream().map(u -> u.getLicenceNo()).collect(Collectors.toList());
			// check for licence no that is not return from licence repo
			List<String> invalidLicenceList = receivedLicenceNoLists.stream().filter(u -> !licenceNoThatExistList.contains(u)).collect(Collectors.toList());

			// check if TG name is tally with the valid licence no
			for (Licence l : licenceLists) {
				int index = receivedLicenceNoLists.indexOf(l.getLicenceNo());
				// check if the user input name is the same as the name stored in DB, paired with the licence no
				if (!receivedLicenceNameLists.get(index).equalsIgnoreCase(l.getTouristGuide().getName())) {
					invalidLicenceList.add(l.getLicenceNo());
				}
			}

			if (invalidLicenceList != null && invalidLicenceList.size() > 0) {
				throw new ValidationException("Invalid licence number found : " + StringUtils.join(invalidLicenceList, ", "));
			}
		}
	}

	@RequestMapping(value = "tp/mrc/update", method = RequestMethod.POST)
	public TgCourseAttendanceDto saveMRCAttendanceDetails(@RequestPart(name = "dto") TgCourseAttendanceDto dto) {
		TgCourseAttendance tca = tgCourseAttendanceRepository.get(TgCourseAttendance.class, dto.getAttendanceId());

		// validate licence no
		Set<TgCourseAttendanceDetailDto> attendeeRows = dto.getAttendeeRows();
		checkLicenceValid(attendeeRows);

		// update course conducted date
		if (!tca.getAttendedDate().equals(dto.getCourseDate())) {
			tca.setAttendedDate(dto.getCourseDate());
		}

		// save file
		updateFile(tca.getApplication(), dto);

		// add and update
		addUpdateCourseAttendanceDetail(attendeeRows, tca);

		// delete
		removeCourseAttendanceDetail(dto.getRemoveAttendeeRows());
		return dto;
	}

	@RequestMapping(value = "tp/mrc/update/delete/{attendanceId}", method = RequestMethod.GET)
	public void deleteMRCAttendance(@PathVariable Integer attendanceId) {
		deleteCourseAttendance(attendanceId);
	}

	private ResultDto<TgCourseResultDto> getCurrentListOfCourseByTgId(TgCourseAttendanceSearchDto searchDto, Integer touristGuideId) {
		ResultDto<TgCourseResultDto> tc = tgCourseRepository.getCurrentListOfCourseByTgId(searchDto, touristGuideId);

		Object[] finalRecords = new Object[tc.getRecords().length];
		var i = 0;
		for (Object obj : tc.getRecords()) {
			TgCourseAttendance tca = (TgCourseAttendance) obj;
			var dto = TgCourseResultDto.setListOfTgCourse(cache, tca);
			finalRecords[i] = dto;
			i++;
		}

		tc.setRecords(finalRecords);
		return tc;
	}

	private ResultDto<TgCourseResultDto> getRenewalCycleCourseList(TgCourseAttendanceSearchDto searchDto, TgLicenceRenewal renewal) {
		Application app = renewal.getApplication();

		searchDto.setStartDate(renewal.getPreviousLicenceStartDate());
		if (Codes.Statuses.PRINT_LICENCE_COLLECTED.equals(app.getLicencePrintStatus().getCode())) {
			searchDto.setEndDate(renewal.getPreviousLicenceExpiryDate());
		}
		ResultDto<TgCourseResultDto> tc = tgCourseRepository.getAllListOfCourseByTgId(searchDto, renewal.getApplication().getLicence().getTouristGuide().getId());

		Object[] finalRecords = new Object[tc.getRecords().length];
		var i = 0;
		for (Object obj : tc.getRecords()) {
			TgCourseAttendance tca = (TgCourseAttendance) obj;
			var dto = TgCourseResultDto.setListOfTgCourse(cache, tca);
			finalRecords[i] = dto;
			i++;
		}

		tc.setRecords(finalRecords);
		return tc;
	}

	private void setCourse(TgCourse course, TgCourseDto dto) {
		course.setName(dto.getName());
		course.setApprovedStartDate(dto.getApprovedStartDate());
		course.setApprovedEndDate(dto.getApprovedEndDate());
		course.setLanguage(cache.getType(dto.getLanguageCode()));
		course.setType(cache.getType(dto.getTypeCode()));
		course.setTgTrainingProvider(tgCourseRepository.load(TgTrainingProvider.class, dto.getTgTrainingProviderId()));

		if (Codes.Types.TP_COURSE_PDC.equals(dto.getTypeCode())) {
			course.setNoOfHours(dto.getNoOfHours());
			course.setCategory(cache.getType(dto.getCategoryCode()));
			course.setSsgCourseCode(dto.getSsgCourseCode());
			course.setObjective(dto.getObjective());
			course.setOutline(dto.getOutline());
			course.setClassroomHrs(dto.getClassroomHrs());
			course.setOutOfClassroomHrs(dto.getOutOfClassroomHrs());
			course.setCourseFee(dto.getCourseFee());
			course.setCourseFeeNote(dto.getCourseFeeNote());

			Set<TgCourseSubsidy> subsidies = course.getTgCourseSubsidies();
			if (subsidies == null || subsidies.size() == 0) {
				for (TgCourseSubsidyDto subsidyDto : dto.getSubsidies()) {
					TgCourseSubsidy subsidy = new TgCourseSubsidy();
					subsidy.setTgCourse(course);
					subsidy.setType(cache.getType(subsidyDto.getTypeCode()));
					subsidy.setFee(subsidyDto.getFee());
					tgCourseRepository.save(subsidy);
				}
			} else {
				for (TgCourseSubsidy subsidy : subsidies) {
					for (TgCourseSubsidyDto subsidyDto : dto.getSubsidies()) {
						if (subsidy.getId().equals(subsidyDto.getId())) {
							subsidy.setFee(subsidyDto.getFee());
						}
					}
					tgCourseRepository.update(subsidies);
				}
			}
		}

	}

	private List<TgCourseAttendanceDetail> addUpdateCourseAttendanceDetail(Set<TgCourseAttendanceDetailDto> attendeeRows, TgCourseAttendance tca) {
		List<TgCourseAttendanceDetail> tcadList = new ArrayList<>();

		if (attendeeRows != null && attendeeRows.size() > 0) {
			for (TgCourseAttendanceDetailDto dto : attendeeRows) {
				if (dto.getAttendanceDetailId() != null) {
					TgCourseAttendanceDetail tcad = tgCourseAttendanceDetailRepository.get(TgCourseAttendanceDetail.class, dto.getAttendanceDetailId());
					tcad.setScore(dto.getScore());
					tcad.setMaxScore(dto.getMaxScore());
					tcad.setResult(getCourseResult(dto.getScore(), dto.getMaxScore()));
					tcad.setAttendance(cache.getType(dto.getAttendance()));
					tcad.setDeleted(false);

				} else {

					var licence = licenceRepository.getLicenceDetailByLicenceNo(dto.getLicenceNo(), Codes.TaTgType.TG);
					var tg = licence.getTouristGuide();

					TgCourseAttendanceDetail tcad = new TgCourseAttendanceDetail();
					tcad.setTouristGuide(tg);
					tcad.setAttendance(cache.getType(dto.getAttendance()));
					tcad.setDeleted(false);

					if (dto.getScore() != null) {
						tcad.setScore(dto.getScore());
						tcad.setResult(getCourseResult(dto.getScore(), dto.getMaxScore()));
					}

					if (dto.getMaxScore() != null) {
						tcad.setMaxScore(dto.getMaxScore());
					}

					tcad.setTgCourseAttendance(tca);
					tcadList.add(tcad);
				}
			}

			if (tcadList.size() > 0) {
				tgCourseAttendanceDetailRepository.save(tcadList);
			}
		}

		return tcadList;
	}

	private void removeCourseAttendanceDetail(List<Integer> removeAttendeeRows) {
		if (removeAttendeeRows != null && removeAttendeeRows.size() > 0) {
			List<TgCourseAttendanceDetail> attendanceDetails = tgCourseAttendanceDetailRepository.getTgCourseAttendanceDetailsByIds(removeAttendeeRows);
			attendanceDetails.forEach(u -> u.setDeleted(true));

			tgCourseAttendanceDetailRepository.save(attendanceDetails);
		}
	}

	// return null if not TP
	private Integer getTpId() {
		Integer tpId = null;

		if (!Codes.UserTypes.USER_STB.equals(getUser().getType().getCode())) {
			tpId = getUser().getTgTrainingProvider().getId();
		}

		return tpId;
	}

	private ResultDto<TgCourseResultDto> getListOfCourseDetailsSearch(TgCourseAttendanceSearchDto searchDto, String type) {

		ResultDto<TgCourseResultDto> tc = tgCourseRepository.getListOfCourseDetails(searchDto, getTpId(), type);

		Object[] finalRecords = new Object[tc.getRecords().length];
		var i = 0;
		for (Object obj : tc.getRecords()) {
			TgCourseAttendance tca = (TgCourseAttendance) obj;
			var dto = TgCourseResultDto.setListOfCourseDetails(cache, tca);
			finalRecords[i] = dto;
			i++;
		}

		tc.setRecords(finalRecords);
		return tc;
	}

	private void deleteCourseAttendance(Integer attendanceId) {
		TgCourseAttendance tca = tgCourseRepository.getCourseAttendanceById(attendanceId, getTpId());
		tca.setIsDeleted(true);
		tgCourseRepository.update(tca);

		Set<TgCourseAttendanceDetail> attendanceDetails = tca.getTgCourseAttendanceDetails();
		for (TgCourseAttendanceDetail attendanceDetail : attendanceDetails) {
			attendanceDetail.setDeleted(true);
		}
		tgCourseRepository.update(attendanceDetails);
	}

	private void saveFile(Application app, TgCourseAttendanceNewDto dto) {
		if (Codes.UserTypes.USER_STB.equals(getUser().getType().getCode())) {
			for (FileDto fileDto : dto.getSupportingDocs()) {
				File fileModel = tgCourseRepository.get(File.class, fileDto.getId());
				if (fileModel != null) {
					fileHelper.saveApplicationFile(app, fileModel, fileDto);
				}
			}
		} else {
			for (FileDto fileDto : dto.getSupportingDocs()) {
				fileHelper.saveFile(app, fileDto);
			}
		}
	}

	private void updateFile(Application app, TgCourseAttendanceDto dto) {
		if (Codes.UserTypes.USER_STB.equals(getUser().getType().getCode())) {
			for (ApplicationFile appFile : app.getApplicationFiles()) {
				if (appFile.getDocumentType().getCode().equals(Codes.TgDocumentTypes.TG_DOC_OTHERS)) {
					if (!isInFiles(dto.getSupportingDocs(), appFile.getFile())) {
						fileHelper.deleteFile(appFile.getFile());
					}
				}
			}

			for (FileDto file : dto.getSupportingDocs()) {
				if (!isInApp(app.getApplicationFiles(), file)) {
					fileHelper.saveFile(app, file);
				}
			}
		} else {
			fileHelper.updateFiles(app, dto.getSupportingDocs(), Codes.TgDocumentTypes.TG_DOC_OTHERS);
		}
	}

	private boolean isInFiles(List<FileDto> files, File currFile) {
		boolean isIn = false;

		for (FileDto file : files) {
			if (currFile.getId() == file.getId()) {
				isIn = true;
				break;
			}
		}

		return isIn;
	}

	private boolean isInApp(Set<ApplicationFile> files, FileDto currFile) {
		boolean isIn = false;

		for (ApplicationFile file : files) {
			if (currFile.getId() == file.getFile().getId()) {
				isIn = true;
				break;
			}
		}

		return isIn;
	}

	private Type getCourseResult(Integer score, Integer maxScore) {

		if (score == null || maxScore == null) {
			return null;
		}

		Integer percentage = score * 100 / maxScore;
		Integer passingRate = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_COURSE_RESULT_PASSING_RATE).getValue());

		return percentage >= passingRate ? cache.getType(Codes.Types.TG_RESULT_PASS) : cache.getType(Codes.Types.TG_RESULT_FAIL);
	}

}
