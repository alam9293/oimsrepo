package gov.stb.tag.controllers.tg;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.TgCourseSubsidyDto;
import gov.stb.tag.dto.tg.course.TgCourseDto;
import gov.stb.tag.dto.tg.coursecreation.TgCourseCreationDto;
import gov.stb.tag.dto.tg.coursecreation.TgCourseCreationItemDto;
import gov.stb.tag.dto.tg.coursecreation.TgCourseCreationSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.TgCourseHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseCreation;
import gov.stb.tag.model.TgCourseSubsidy;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.repository.tg.TgCourseCreationRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/course-creation")
@Transactional
public class TgCourseCreationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgCourseCreationRepository tgCourseCreationRepository;
	@Autowired
	TgCourseHelper tgCourseHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer submitNewCourseCreation(@RequestPart(name = "dto") TgCourseCreationDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {

		TgCourseCreation tcc = new TgCourseCreation();
		Application application;
		if (dto.getId() == null) {
			application = appHelper.saveNewCourseApplication(Codes.ApplicationTypes.TG_APP_COURSE_CREATION, null, false, false);
			tcc.setApplication(application);
		} else {
			tcc = tgCourseCreationRepository.getTgCourseCreationById(dto.getId());
			application = tcc.getApplication();
		}
		saveTgCourseCreation(tcc, dto);
		tgCourseCreationRepository.saveOrUpdate(tcc);

		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}
		}

		// Save files uploaded by user
		for (FileDto doc : dto.getDocs()) {
			if (doc.getPublicFileId() == null) {
				fileHelper.saveFile(application, doc);
			}
		}

		appHelper.forward(application, true);
		return application.getId();
	}

	// create alert
	@RequestMapping(path = "/save/create-alert/{id}", method = RequestMethod.POST)
	public Integer createCreationAlert(@PathVariable Integer id) {
		TgCourseCreation tgCourseCreation = tgCourseCreationRepository.getTgCourseCreationByAppId(id);
		Application application = tgCourseCreation.getApplication();
		alertHelper.createAlert(tgCourseCreation.getTgTrainingProvider(), application, Messages.Alerts.APP_SUBMISSION, Codes.Modules.MOD_TP, application.getType(),
				"tp-pdc-courses/new/".concat(application.getId().toString()));
		return id;
	}

	@RequestMapping(method = RequestMethod.GET, path = { "/view" })
	public ResultDto<TgCourseCreationItemDto> getPendingList(TgCourseCreationSearchDto searchDto) {
		return tgCourseCreationRepository.getPendingList(searchDto);
	}

	@RequestMapping(path = "/view/{id}", method = RequestMethod.GET)
	public TgCourseCreationDto getApplication(@PathVariable Integer id) {

		TgCourseCreation tgCourseCreation = tgCourseCreationRepository.getTgCourseCreationByAppId(id);
		if (getSelectedRoleCode().equals(Codes.Roles.TP_PUBLIC)) {
			tgCourseHelper.isTgCourseBelongToTp(getUser().getTgTrainingProvider(), null, tgCourseCreation);
		}

		TgCourseCreationDto resultDto = new TgCourseCreationDto();
		TgCourseCreationDto.buildFromTgCourseCreation(tgCourseCreation, resultDto, cache, appHelper, tgCourseHelper, fileHelper);
		return resultDto;
	}

	// approve, reject, rfa
	@RequestMapping(value = "/{action}", method = RequestMethod.POST)
	public void process(@PathVariable String action, @RequestPart(name = "tgCourseCreationDto") TgCourseCreationDto tgCourseCreationDto, @RequestPart(name = "approvalDto") ApprovalDto approvalDto) {
		TgCourseCreation tcc = tgCourseCreationRepository.getTgCourseCreationByAppId(tgCourseCreationDto.getApplicationId());
		Application app = tcc.getApplication();
		TgTrainingProvider tp = tcc.getTgTrainingProvider();

		String url = String.format(properties.applicationUrl, "tp-pdc-courses/new/" + app.getId());
		String alertMsg = null;
		String emailType = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, approvalDto.getInternalRemarks(), approvalDto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(app)) {
				createTgCourse(tcc);
				emailType = Codes.EmailType.TG_COURSE_UPON_APPROVAL;
				alertMsg = Messages.Alerts.APP_APPROVE;
			} else {
				tcc.setNoOfHours(tgCourseCreationDto.getTgCourse().getNoOfHours());
			}
			break;

		case ACTION_REJECT:
			emailType = Codes.EmailType.TG_COURSE_UPON_REJECTION;
			alertMsg = Messages.Alerts.APP_REJECT;

			appHelper.reject(app, approvalDto.getInternalRemarks(), approvalDto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			String status = approvalDto.getRouteStatus();
			if (StringUtils.equals(status, Codes.Statuses.TG_APP_RFA)) {
				emailType = Codes.EmailType.TG_COURSE_UPON_RFA;
				alertMsg = Messages.Alerts.APP_RFA;
			}

			appHelper.rfa(app, status, approvalDto.getInternalRemarks(), approvalDto.getExternalRemarks(), null, null, null, approvalDto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (emailType != null) {
			emailHelper.emailUponTgCourseAction(app, tp.getName(), tcc.getName(), emailType, url, tp.getEmail());
		}

		if (alertMsg != null) {
			alertHelper.createAlert(tp, app, alertMsg, Codes.Modules.MOD_TP, app.getType(), "tp-pdc-courses/new/" + app.getId());
		}

	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = tgCourseCreationRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void saveTgCourseCreation(TgCourseCreation tcc, TgCourseCreationDto dto) {
		tcc.setTrainers(dto.getTrainers());
		// tcc.setAppropriateLevel(dto.getAppropriateLevel());
		tcc.setAssessment(dto.getAssessment());
		tcc.setSynopsis(dto.getSynopsis());

		TgCourseDto course = dto.getTgCourse();
		tcc.setName(course.getName());
		tcc.setCategory(cache.getType(course.getCategoryCode()));
		tcc.setLanguage(cache.getType(course.getLanguageCode()));
		tcc.setNoOfHours(course.getNoOfHours());
		tcc.setSsgCourseCode(course.getSsgCourseCode());
		tcc.setObjective(course.getObjective());
		tcc.setOutline(course.getOutline());
		tcc.setClassroomHrs(course.getClassroomHrs());
		tcc.setOutOfClassroomHrs(course.getOutOfClassroomHrs());
		tcc.setCourseFee(course.getCourseFee());
		tcc.setCourseFeeNote(course.getCourseFeeNote());
		tcc.setTgTrainingProvider(getUser().getTgTrainingProvider());

		for (TgCourseSubsidyDto subsidyDto : course.getSubsidies()) {
			TgCourseSubsidy subsidy = new TgCourseSubsidy();
			if (subsidyDto.getId() != null) {
				subsidy = tgCourseCreationRepository.get(TgCourseSubsidy.class, subsidyDto.getId());
			} else {
				subsidy.setTgCourseCreation(tcc);
				subsidy.setType(cache.getType(subsidyDto.getTypeCode()));
			}
			subsidy.setFee(subsidyDto.getFee());
			tgCourseCreationRepository.saveOrUpdate(subsidy);
		}
	}

	private TgCourse createTgCourse(TgCourseCreation tcc) {
		String paramCourseNewEndDate = cache.getSystemParameterAsString(Codes.SystemParameters.TG_COURSE_RENEWED_END_DATE);

		TgCourse newTgCourse = new TgCourse();
		newTgCourse.setCode(tgCourseHelper.generateCourseCode(tcc.getTgTrainingProvider()));
		newTgCourse.setName(tcc.getName());
		newTgCourse.setApprovedStartDate(LocalDate.now());

		LocalDate courseEndDate = LocalDate.of(newTgCourse.getApprovedStartDate().getYear(), Integer.valueOf(paramCourseNewEndDate.split("-")[1]),
				Integer.valueOf(paramCourseNewEndDate.split("-")[0]));
		if (courseEndDate.isBefore(newTgCourse.getApprovedStartDate())) {
			// if end date falls before start date, plus another year
			courseEndDate = courseEndDate.plusYears(1);
		}
		newTgCourse.setApprovedEndDate(courseEndDate);
		newTgCourse.setCategory(tcc.getCategory());
		newTgCourse.setClassroomHrs(tcc.getClassroomHrs());
		newTgCourse.setCourseFee(tcc.getCourseFee());
		newTgCourse.setCourseFeeNote(tcc.getCourseFeeNote());
		newTgCourse.setLanguage(tcc.getLanguage());
		newTgCourse.setNoOfHours(tcc.getNoOfHours());
		newTgCourse.setObjective(tcc.getObjective());
		newTgCourse.setOutline(tcc.getOutline());
		newTgCourse.setOutOfClassroomHrs(tcc.getOutOfClassroomHrs());
		newTgCourse.setSsgCourseCode(tcc.getSsgCourseCode());
		newTgCourse.setTgTrainingProvider(tcc.getTgTrainingProvider());
		newTgCourse.setType(cache.getType(Codes.Types.TP_COURSE_PDC));
		tgCourseRepository.save(newTgCourse);

		newTgCourse.setTgCourseSubsidies(Sets.newHashSet());
		tcc.getTgCourseSubsidies().forEach(s -> {
			TgCourseSubsidy subsidy = new TgCourseSubsidy();
			subsidy.setFee(s.getFee());
			subsidy.setTgCourse(newTgCourse);
			subsidy.setType(s.getType());
			tgCourseRepository.save(subsidy);

			newTgCourse.getTgCourseSubsidies().add(subsidy);
		});

		return newTgCourse;
	}

}
