package gov.stb.tag.controllers.tg;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.tg.coursecriteria.TgCourseCriteriaDto;
import gov.stb.tag.model.TgCourseCriteria;
import gov.stb.tag.repository.tg.TgCourseCriteriaRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/course-criteria")
@Transactional
public class TgCourseCriteriaController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgCourseCriteriaRepository tgCourseCriteriaRepository;

	@RequestMapping(path = "/view", method = RequestMethod.GET)
	public List<TgCourseCriteriaDto> getTgCourseCriteria() {
		return tgCourseCriteriaRepository.getAllCourseCriteria();
	}

	@RequestMapping(path = "/update", method = RequestMethod.POST)
	public void updateTgCourseCriteria(@RequestBody List<TgCourseCriteriaDto> list) {
		for (int index = 0; index < list.size(); index++) {
			TgCourseCriteriaDto dto = list.get(index);
			dto.setOrdinal(index + 1);
			saveTgCourseCriteria(dto);
		}
	}

	private void saveTgCourseCriteria(TgCourseCriteriaDto dto) {
		TgCourseCriteria tgCourseCriteria = null;
		if (dto.getId() == null) {
			tgCourseCriteria = new TgCourseCriteria();
		} else {
			tgCourseCriteria = tgCourseCriteriaRepository.get(TgCourseCriteria.class, dto.getId());
		}
		tgCourseCriteria.setCriteria(dto.getCriteria());
		tgCourseCriteria.setWeightage1(dto.getWeightage1());
		tgCourseCriteria.setWeightage2(dto.getWeightage2());
		tgCourseCriteria.setWeightage3(dto.getWeightage3());
		tgCourseCriteria.setWeightage4(dto.getWeightage4());
		tgCourseCriteria.setWeightage5(dto.getWeightage5());
		tgCourseCriteria.setIsActive(dto.getIsActive());
		tgCourseCriteria.setOrdinal(dto.getOrdinal());

		tgCourseCriteriaRepository.save(tgCourseCriteria);
	}
}
