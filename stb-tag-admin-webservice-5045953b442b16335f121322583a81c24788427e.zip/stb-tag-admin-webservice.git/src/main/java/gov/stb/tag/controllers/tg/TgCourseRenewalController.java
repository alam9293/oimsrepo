package gov.stb.tag.controllers.tg;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.tg.courserenewal.TgCourseEvaluationDto;
import gov.stb.tag.dto.tg.courserenewal.TgCourseRenewalDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.TgCourseHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseCriteria;
import gov.stb.tag.model.TgCourseEvaluation;
import gov.stb.tag.model.TgCourseRenewal;
import gov.stb.tag.model.TgCourseSubsidy;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.repository.tg.TgCourseCriteriaRepository;
import gov.stb.tag.repository.tg.TgCourseRenewalRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/course-renewal")
@Transactional
public class TgCourseRenewalController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgCourseRenewalRepository tgCourseRenewalRepository;
	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgCourseCriteriaRepository tgCourseCriteriaRepository;
	@Autowired
	TgCourseHelper tgCourseHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;

	@RequestMapping(path = "/load/{code}", method = RequestMethod.GET)
	public TgCourseRenewalDto getTgCourseRenewal(@PathVariable String code) {
		if (getSelectedRoleCode().equals(Codes.Roles.TP_PUBLIC)) {
			tgCourseHelper.isTgCourseBelongToTp(getUser().getTgTrainingProvider(), tgCourseRepository.getTgCourseWithTpByCode(code), null);
		}
		TgCourse tgCourseToRenew = tgCourseRenewalRepository.get(TgCourse.class, code);
		Boolean canRenew = tgCourseHelper.checkIsCourseEligibleToRenew(tgCourseToRenew);
		if (!canRenew) {
			throw new ValidationException("The selected course cannot be renewed right now.");
		}

		TgCourseRenewalDto resultDto = new TgCourseRenewalDto();
		resultDto.setTgCourse(tgCourseHelper.getTgCourseByCode(code));
		resultDto.setEvaluations(Lists.newArrayList());
		List<TgCourseCriteria> courseCriteriaList = tgCourseCriteriaRepository.getActiveCourseCriteria();
		courseCriteriaList.forEach(tgCourseCriteria -> {
			resultDto.getEvaluations().add(TgCourseEvaluationDto.buildFromTgCourseCriteria(tgCourseCriteria));
		});
		return resultDto;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveTgCourseRenewal(@RequestBody TgCourseRenewalDto dto) {

		TgCourse tgCourse = tgCourseRenewalRepository.get(TgCourse.class, dto.getTgCourse().getCode());
		TgTrainingProvider tp = tgCourse.getTgTrainingProvider();

		Application application = appHelper.saveNewCourseApplication(Codes.ApplicationTypes.TG_APP_COURSE_RENEWAL, tgCourse.getCode(), false, false);
		TgCourseRenewal tgCourseRenewal = new TgCourseRenewal();
		tgCourseRenewal.setApplication(application);
		tgCourseRenewal.setRemarks(dto.getRemarks());
		tgCourseRenewal.setTgCourse(tgCourse);
		tgCourseRenewalRepository.save(tgCourseRenewal);
		BigDecimal totalPoints = setEvaluations(tgCourseRenewal, dto.getEvaluations());
		for (FileDto doc : dto.getDocs()) {
			fileHelper.saveFile(application, doc);
		}

		String emailType = null;
		BigDecimal minPtsToRenew = new BigDecimal(cache.getSystemParameterAsString(Codes.SystemParameters.TG_COURSE_MIN_POINTS_TO_RENEW));
		if (totalPoints.compareTo(minPtsToRenew) >= 0) {
			// auto approve
			logger.info("Auto approve course code {}, score points={}, required points={}.", dto.getTgCourse().getCode(), totalPoints, minPtsToRenew);
			appHelper.autoApprove(application, false);

			// create new course with new period
			duplicateCourse(tgCourse);

			emailType = Codes.EmailType.TG_COURSE_UPON_APPROVAL;

		} else {
			// auto reject
			logger.info("Auto reject course code {}, score points={}, required points={}", dto.getTgCourse().getCode(), totalPoints, minPtsToRenew);
			appHelper.autoReject(application, false, null, "Submitted course does not meet renewal requirement.");

			emailType = Codes.EmailType.TG_COURSE_UPON_REJECTION;
		}

		if (emailType != null) {
			String url = String.format(properties.applicationUrl, "tp-pdc-courses/renew/app/".concat(application.getId().toString()));
			emailHelper.emailUponTgAction(application, tp.getName(), emailType, url, tp.getEmail());
		}

		return application.getId();
	}

	@RequestMapping(path = "/view/{id}", method = RequestMethod.GET)
	public TgCourseRenewalDto getApplication(@PathVariable Integer id) {

		TgCourseRenewal tgCourseRenewal = tgCourseRenewalRepository.getTgCourseRenewalByAppId(id);
		TgCourse tgCourse = tgCourseRenewal.getTgCourse();

		if (getSelectedRoleCode().equals(Codes.Roles.TP_PUBLIC)) {
			tgCourseHelper.isTgCourseBelongToTp(getUser().getTgTrainingProvider(), tgCourse, null);
		}

		TgCourseRenewalDto resultDto = new TgCourseRenewalDto();
		TgCourseRenewalDto.buildFromTgCourseRenewal(tgCourseRenewal, resultDto, cache, appHelper, tgCourseHelper, fileHelper);
		return resultDto;
	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		Application application = tgCourseRenewalRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(application, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	// create alert
	@RequestMapping(path = "/save/create-alert/{id}", method = RequestMethod.POST)
	public Integer createRenewalAlert(@PathVariable Integer id) {
		TgCourseRenewal tgCourseRenewal = tgCourseRenewalRepository.getTgCourseRenewalByAppId(id);
		Application application = tgCourseRenewal.getApplication();

		String alertMsg = null;
		if (Entities.equals(application.getLastAction().getStatus(), Codes.Statuses.TG_APP_APPROVED)) {
			alertMsg = Messages.Alerts.APP_APPROVE;
		} else {
			alertMsg = Messages.Alerts.APP_REJECT;
		}

		if (alertMsg != null) {
			alertHelper.createAlert(tgCourseRenewal.getTgCourse().getTgTrainingProvider(), application, alertMsg, Codes.Modules.MOD_TP, application.getType(),
					"tp-pdc-courses/renew/app/".concat(application.getId().toString()));
		}

		return id;
	}

	private BigDecimal setEvaluations(TgCourseRenewal tgCourseRenewal, List<TgCourseEvaluationDto> evaluationlist) {

		BigDecimal totalPoints = BigDecimal.ZERO;
		for (TgCourseEvaluationDto evaluationDto : evaluationlist) {
			TgCourseCriteria tgCourseCriteria = tgCourseRenewalRepository.get(TgCourseCriteria.class, evaluationDto.getTgCourseCriteriaId());
			List<BigDecimal> weigthtageByPoint = Lists.newArrayList();
			weigthtageByPoint.add(tgCourseCriteria.getWeightage1());
			weigthtageByPoint.add(tgCourseCriteria.getWeightage2());
			weigthtageByPoint.add(tgCourseCriteria.getWeightage3());
			weigthtageByPoint.add(tgCourseCriteria.getWeightage4());
			weigthtageByPoint.add(tgCourseCriteria.getWeightage5());

			TgCourseEvaluation evaluation = new TgCourseEvaluation();
			evaluation.setTgCourseCriteria(tgCourseCriteria);
			evaluation.setRating(evaluationDto.getRating());
			evaluation.setWeightage(weigthtageByPoint.get(evaluationDto.getRating() - 1));
			evaluation.setTgCourseRenewal(tgCourseRenewal);
			tgCourseRenewalRepository.save(evaluation);

			logger.info("{}, no. of points={}", tgCourseCriteria.getCriteria(), evaluation.getWeightage());
			totalPoints = totalPoints.add(evaluation.getWeightage());
		}

		return totalPoints;
	}

	private TgCourse duplicateCourse(TgCourse tgCourse) {
		String paramCourseNewEndDate = cache.getSystemParameterAsString(Codes.SystemParameters.TG_COURSE_RENEWED_END_DATE);

		TgCourse newTgCourse = new TgCourse();
		newTgCourse.setCode(tgCourseHelper.generateCourseCode(tgCourse.getTgTrainingProvider()));
		newTgCourse.setName(tgCourse.getName());
		newTgCourse.setApprovedStartDate(LocalDate.now().isAfter(tgCourse.getApprovedEndDate()) ? LocalDate.now() : tgCourse.getApprovedEndDate().plusDays(1));

		LocalDate courseEndDate = LocalDate.of(newTgCourse.getApprovedStartDate().getYear(), Integer.valueOf(paramCourseNewEndDate.split("-")[1]),
				Integer.valueOf(paramCourseNewEndDate.split("-")[0]));
		if (courseEndDate.isBefore(newTgCourse.getApprovedStartDate())) {
			// if end date falls before start date, plus another year
			courseEndDate = courseEndDate.plusYears(1);
		}
		newTgCourse.setApprovedEndDate(courseEndDate);
		newTgCourse.setCategory(tgCourse.getCategory());
		newTgCourse.setClassroomHrs(tgCourse.getClassroomHrs());
		newTgCourse.setCourseFee(tgCourse.getCourseFee());
		newTgCourse.setCourseFeeNote(tgCourse.getCourseFeeNote());
		newTgCourse.setLanguage(tgCourse.getLanguage());
		newTgCourse.setNoOfHours(tgCourse.getNoOfHours());
		newTgCourse.setObjective(tgCourse.getObjective());
		newTgCourse.setOutline(tgCourse.getOutline());
		newTgCourse.setOutOfClassroomHrs(tgCourse.getOutOfClassroomHrs());
		newTgCourse.setSsgCourseCode(tgCourse.getSsgCourseCode());
		newTgCourse.setTgTrainingProvider(tgCourse.getTgTrainingProvider());
		newTgCourse.setType(tgCourse.getType());
		newTgCourse.setParentTgCourse(tgCourse);
		tgCourseRenewalRepository.save(newTgCourse);

		newTgCourse.setTgCourseSubsidies(Sets.newHashSet());
		tgCourse.getTgCourseSubsidies().forEach(s -> {
			TgCourseSubsidy subsidy = new TgCourseSubsidy();
			subsidy.setFee(s.getFee());
			subsidy.setTgCourse(newTgCourse);
			subsidy.setType(s.getType());
			tgCourseRenewalRepository.save(subsidy);

			newTgCourse.getTgCourseSubsidies().add(subsidy);
		});

		return newTgCourse;
	}

}
