package gov.stb.tag.controllers.tg;

import java.io.IOException;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.touristguide.TouristGuideItemDto;
import gov.stb.tag.dto.tg.touristguide.TouristGuideSearchDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.tg.TgDirectoryRepository;

@RestController
@RequestMapping(path = "/api/v1/directory/tg")
@Transactional
public class TgDirectoryController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private TgDirectoryRepository tgDirectoryRepository;

	@Autowired
	private FileHelper fileHelper;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public ResultDto<TouristGuideItemDto> getTgDirectory(TouristGuideSearchDto searchDto) throws IOException {

		ResultDto<TouristGuideItemDto> tgList = tgDirectoryRepository.getTgListByFilter(searchDto);

		Object[] finalRecords = new Object[tgList.getRecords().length];
		var i = 0;
		for (Object obj : tgList.getRecords()) {
			TouristGuide tg = (TouristGuide) obj;
			var dto = TouristGuideItemDto.buildFromTouristGuide(cache, tg);

			finalRecords[i] = dto;
			i++;
		}

		tgList.setRecords(finalRecords);

		return tgList;

	}

}
