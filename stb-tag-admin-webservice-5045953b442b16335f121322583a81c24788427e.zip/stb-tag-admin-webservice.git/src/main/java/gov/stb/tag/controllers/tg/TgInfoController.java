package gov.stb.tag.controllers.tg;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.tgInfo.TgInfoResultDto;
import gov.stb.tag.dto.tg.tgInfo.TgInfoSearchDto;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgInfo;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgLicenceRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/info")
@Transactional
public class TgInfoController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	@Autowired
	TgLicenceRepository tgLicenceRepository;

	@Autowired
	FileHelper fileHelper;

	@RequestMapping(value = "/view/{licenceId}", method = RequestMethod.GET)
	public ResultDto<TgInfoResultDto> getListOfCourseDetails(TgInfoSearchDto searchDto, @PathVariable Integer licenceId) {
		Licence lic = tgLicenceRepository.get(Licence.class, licenceId);
		ResultDto<TgInfoResultDto> tgInfo = tgLicenceRepository.getTgInfoDetails(searchDto, lic.getTouristGuide().getId());

		Object[] finalRecords = new Object[tgInfo.getRecords().length];
		var i = 0;
		for (Object obj : tgInfo.getRecords()) {
			TgInfo info = (TgInfo) obj;
			var dto = TgInfoResultDto.buildDtoFromModel(cache, info, fileHelper);
			finalRecords[i] = dto;
			i++;
		}

		tgInfo.setRecords(finalRecords);
		return tgInfo;
	}

	@RequestMapping(value = "/delete/{tgInfoId}", method = RequestMethod.GET)
	public void deleteTgInfo(@PathVariable Integer tgInfoId) {
		TgInfo info = tgLicenceRepository.get(TgInfo.class, tgInfoId);
		info.setIsDeleted(Boolean.TRUE);
		tgLicenceRepository.update(info);

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveTgInfo(@RequestPart(name = "dto") TgInfoResultDto dto) {
		TgInfo info = new TgInfo();
		Licence licence = tgLicenceRepository.get(Licence.class, dto.getLicenceId());
		if (dto.getId() != null) {// update existing
			info = tgLicenceRepository.get(TgInfo.class, dto.getId());
		}
		info = dto.buildModelFromDto(dto, info, cache, fileHelper, licence.getTouristGuide());
		tgLicenceRepository.saveOrUpdate(info);
	}
}
