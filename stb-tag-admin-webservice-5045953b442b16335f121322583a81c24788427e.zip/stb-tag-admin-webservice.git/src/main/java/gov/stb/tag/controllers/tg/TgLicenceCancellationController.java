package gov.stb.tag.controllers.tg;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.tg.licencecancellation.TgLicenceCancellationDto;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.TgLicenceCancellation;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgLicenceCancellationRepository;
import gov.stb.tag.repository.tg.TgLicenceRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/cancel")
@Transactional
public class TgLicenceCancellationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicenceCancellationRepository tgLicenceCancellationRepository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	@Autowired
	TgLicenceRepository tgLicenceRepository;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	EmailHelper emailHelper;

	@Autowired
	AlertHelper alertHelper;

	@Autowired
	UserHelper userHelper;

	/*
	 * Internet
	 */
	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TgLicenceCancellationDto checkLicence() {

		var itemDto = new TgLicenceCancellationDto();

		var user = getUser();
		var tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		var licence = tg.getLicence();
		if (licence != null && !Codes.Statuses.TG_ACTIVE.equals(licence.getStatus().getCode())) {
			itemDto.setAllowCancel(false);
		}
		return itemDto;
	}

	// save new application (no approval workflow)
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveApplication(@RequestPart(name = "dto") TgLicenceCancellationDto itemDto) {

		var user = getUser();
		var tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		tg.setHasPersonUpdateAccess(false);
		touristGuideRepository.update(tg);

		var licence = tg.getLicence();
		licence.setCeasedDate(LocalDate.now());
		licence.setStatus(cache.getStatus(Codes.Statuses.TG_CANCELLED));
		licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_CANCELLED);
		tgLicenceRepository.update(licence);

		Application application = new Application();
		application.setIsDraft(false);
		application.setIsDeleted(false);
		application.setSubmissionDate(LocalDateTime.now());
		application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
		application.setTaTgType(Codes.TaTgType.TG);
		application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_CANCELLATION));
		application.setLicence(licence);
		tgApplicationRepository.save(application);

		appHelper.forward(application, true);

		TgLicenceCancellation tlc = new TgLicenceCancellation();
		tlc.setReason(itemDto.getReason());
		tlc.setApplication(application);
		tgLicenceCancellationRepository.save(tlc);

		String url = String.format(properties.applicationUrl, "login");
		emailHelper.emailUponTgAction(application, tg.getName(), Codes.EmailType.TG_LICENCE_CANCELLATION, url, tg.getEmailAddress());
		alertHelper.createAlert(tg, application, Messages.Alerts.TG_LIC_CANCELLED_SUCCESS, Codes.Modules.MOD_TG, application.getType(), null);
	}

	// get application no
	@RequestMapping(value = "/new/application-no", method = RequestMethod.GET)
	public TgLicenceCancellationDto getApplicationNo() {

		var itemDto = new TgLicenceCancellationDto();

		var user = getUser();
		var tlc = tgLicenceCancellationRepository.getApplication(user.getLoginId());
		if (tlc != null) {
			itemDto.setId(tlc.getId());

			var application = tlc.getApplication();
			itemDto = itemDto.populateAppStatus(cache, application, itemDto);
		}

		return itemDto;
	}

	// edit application
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public TgLicenceCancellationDto editApplication(@PathVariable Integer id) {

		var tlc = tgLicenceCancellationRepository.getApplicationById(id);
		var user = getUser();
		appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_CANCELLATION);

		TgLicenceCancellationDto itemDto = new TgLicenceCancellationDto();
		if (tlc != null) {
			itemDto.setId(tlc.getId());
			itemDto.setReason(tlc.getReason());

			var application = tlc.getApplication();
			itemDto = itemDto.populateAppStatus(cache, application, itemDto);
		}

		return itemDto;
	}

	/*
	 * Intranet
	 */

	// to retrieve submitted application details
	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TgLicenceCancellationDto getLicenceCancellationDetail(@PathVariable Integer id) {
		var tlc = tgLicenceCancellationRepository.getApplicationById(id);
		var itemDto = new TgLicenceCancellationDto();
		itemDto = itemDto.buildFromTgLicenceCancellation(cache, tlc, appHelper, fileHelper);
		itemDto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(itemDto.getNric()));
		return itemDto;
	}

	// to retrieve submitted application details by application id
	@RequestMapping(value = "/view/app/{id}", method = RequestMethod.GET)
	public TgLicenceCancellationDto getLicenceCancellationDetailByApplication(@PathVariable Integer id) {
		var tlc = tgLicenceCancellationRepository.getTgLicenceCancellationByApplicationId(id);
		var itemDto = new TgLicenceCancellationDto();
		itemDto = itemDto.buildFromTgLicenceCancellation(cache, tlc, appHelper, fileHelper);
		itemDto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(itemDto.getNric()));
		return itemDto;
	}

}
