package gov.stb.tag.controllers.tg;

import static gov.stb.tag.util.DateUtil.REPORT_DATE_FORMAT_PATTERN;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPageMar;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTPageSz;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTSectPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblWidth;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.LicenceStatusSpanDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ce.cases.CeInfringementDto;
import gov.stb.tag.dto.ce.cases.CeRecommendationDto;
import gov.stb.tag.dto.ce.directory.CeInfringementForPublicDto;
import gov.stb.tag.dto.iams.IamsCreatePortalUserValueResponseDto;
import gov.stb.tag.dto.iams.IamsPortalAllUserInfoResponseDto;
import gov.stb.tag.dto.iams.IamsPortalLoginRequestDto;
import gov.stb.tag.dto.iams.IamsPortalUserRequestDto;
import gov.stb.tag.dto.iams.IamsPortalUserValueRequestDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentItemDto;
import gov.stb.tag.dto.tg.assignment.TgAssignmentSearchDto;
import gov.stb.tag.dto.tg.course.TgCourseAttendanceSearchDto;
import gov.stb.tag.dto.tg.course.TgCourseResultDto;
import gov.stb.tag.dto.tg.licence.TgLicenceDto;
import gov.stb.tag.dto.tg.licence.TgLicenceResultDto;
import gov.stb.tag.dto.tg.licence.TgLicenceSearchDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalConditionDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.CpfHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.MessageHelper;
import gov.stb.tag.helper.PasswordHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.ce.CeCaseRecommendationRepository;
import gov.stb.tag.repository.ce.CeDirectoryRepository;
import gov.stb.tag.repository.tg.TgAssignmentRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgLicenceRenewalRepository;
import gov.stb.tag.repository.tg.TgLicenceRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.FileUtil;

@RestController
@RequestMapping(path = "/api/v1/tg/licences")
@Transactional
public class TgLicenceController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicenceRepository licenceRepository;
	@Autowired
	TouristGuideRepository touristGuideRepository;
	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgAssignmentRepository tgAssignmentRepository;
	@Autowired
	TgLicenceRenewalRepository tgLicenceRenewalRepository;
	@Autowired
	CeDirectoryRepository ceDirectoryRepository;
	@Autowired
	PaymentRepository paymentRepository;
	@Autowired
	CeCaseRecommendationRepository ceCaseRecommendationRepository;

	@Autowired
	UserHelper userHelper;
	@Autowired
	PasswordHelper passwordHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	MessageHelper messageHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	CpfHelper cpfHelper;
	@Autowired
	TgHelper tgHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	Properties properties;
	@Autowired
	ObjectMapper objectMapper;

	// to retrieve all TG licence
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<Licence> getAllList(TgLicenceSearchDto searchDto) {
		ResultDto<Licence> licenceResultDto = licenceRepository.getListOfTgLicence(searchDto);

		Object[] finalRecords = new Object[licenceResultDto.getRecords().length];
		var i = 0;
		for (Licence l : licenceResultDto.getModels()) {
			var dto = TgLicenceResultDto.buildListAllPage(cache, l);
			finalRecords[i] = dto;
			i++;
		}
		licenceResultDto.setRecords(finalRecords);
		return licenceResultDto;
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TgLicenceResultDto getSingleLicence(@PathVariable Integer id) {
		Licence licence = licenceRepository.getSingleLicence(id);
		TgLicenceResultDto tlDto = TgLicenceResultDto.buildSinglePage(cache, licence, userHelper, licenceHelper);
		return tlDto;
	}

	@RequestMapping(value = "/view/current-cycle-attendance/{id}/{type}", method = RequestMethod.GET)
	public ResultDto<TgCourseResultDto> getCurrentCycleMrc(TgCourseAttendanceSearchDto searchDto, @PathVariable Integer id, @PathVariable String type) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(id);
		if (tg == null) {
			throw new ValidationException("No tourist guide record found");
		}
		if (type.equals("mrc")) {
			searchDto.setType(Codes.Types.TP_COURSE_MRC);
		} else if (type.equals("pdc")) {
			searchDto.setType(Codes.Types.TP_COURSE_PDC);
		} else {
			throw new ValidationException("Invalid type");
		}

		ResultDto<TgCourseResultDto> tc = tgCourseRepository.getCurrentListOfCourseByTgId(searchDto, tg.getId());
		Object[] finalRecords = new Object[tc.getRecords().length];
		var i = 0;
		for (Object obj : tc.getRecords()) {
			TgCourseAttendance tca = (TgCourseAttendance) obj;
			var dto = TgCourseResultDto.setListOfTgCourse(cache, tca);
			finalRecords[i] = dto;
			i++;
		}

		tc.setRecords(finalRecords);
		return tc;
	}

	@RequestMapping(value = "/view/current-cycle-assignments/{id}", method = RequestMethod.GET)
	public ResultDto<TgAssignmentItemDto> getCurrentCycleAssignments(TgAssignmentSearchDto searchDto, @PathVariable Integer id) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(id);
		if (tg == null) {
			throw new ValidationException("No tourist guide record found");
		}
		searchDto.setIsCurrentCycle(true);
		return tgAssignmentRepository.getAssignments(searchDto, tg.getId());
	}

	@RequestMapping(value = "/view/current-cycle-others/{id}", method = RequestMethod.GET)
	public TgLicenceRenewalDto getCurrentCycleOthers(@PathVariable Integer id) {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewalByLicenceId(id);
		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(id);
		return new TgLicenceRenewalDto(cache, renewal, tg, fileHelper, appHelper, paymentHelper, userHelper, cpfHelper, false);

	}

	@RequestMapping(value = "/view/current-cycle-conditions/{id}", method = RequestMethod.GET)
	public TgLicenceRenewalConditionDto getCurrentCycleConditions(@PathVariable Integer id) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(id);
		return tgHelper.setLicenceRenewalCondition(tg);
	}

	@RequestMapping(value = "/status-span/view/{id}", method = RequestMethod.GET)
	public List<LicenceStatusSpanDto> getLicenceStatusSpan(@PathVariable Integer id) {
		List<LicenceStatusSpanDto> resultList = new ArrayList<>();
		touristGuideRepository.getStatusSpan(id).stream().forEach(ss -> {
			resultList.add(LicenceStatusSpanDto.buildFromStatusSpan(cache, ss));
		});
		return resultList;
	}

	@RequestMapping(path = "/view/{licenceId}/past-years/{number}", method = RequestMethod.GET)
	public List<ListableDto> getPastYearsByLicenceId(@PathVariable Integer licenceId, @PathVariable Integer number) {
		Licence licence = touristGuideRepository.get(Licence.class, licenceId);
		return licenceHelper.getTgLicencePastYears(licence, number);
	}

	@RequestMapping(value = "/past-infringements/view/{id}", method = RequestMethod.GET)
	public List<CeInfringementDto> getInfringement(@PathVariable Integer id) {
		Licence licence = touristGuideRepository.get(Licence.class, id);
		List<CeCaseInfringement> infringements = touristGuideRepository.getTgInfringements(licence.getTouristGuide().getUin());
		List<CeInfringementDto> result = Lists.newArrayList();
		infringements.forEach(infringement -> {
			CeInfringementDto infringementDto = new CeInfringementDto(infringement.getCeCaseInfringer(), infringement, cache, true, ceCaseHelper);
			if (infringement.getLastRecommendation() != null) {
				CeCaseRecommendation recomm = ceCaseRecommendationRepository.getRecommendationById(infringement.getLastRecommendation().getId());
				infringementDto.setRecommendation(new CeRecommendationDto(recomm, cache, fileHelper, workflowHelper, null, false));
			}
			result.add(infringementDto);
		});
		return result;
	}

	/**
	 * to retrieve list of infringement by login user
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/past-infringements/view", method = RequestMethod.GET)
	public List<CeInfringementForPublicDto> getInfringementByCurrentTg(@PathVariable Integer id) {
		User currentUser = commonRepository.getLicenseeUserByUserId(getUser().getId());
		if (getSelectedRoleCode().equals(Codes.Roles.TA_PUBLIC)) {
			Licence licence = currentUser.getTouristGuide().getLicence();

			List<CeInfringementForPublicDto> results = ceDirectoryRepository.getPast5YearsInfringements(licence.getTouristGuide().getUin());
			results.forEach(dto -> {
				if (!Strings.isNullOrEmpty(dto.getBillRefNo())) {
					PaymentRequest payReq = paymentRepository.getPaymentRequest(dto.getBillRefNo());
					dto.setPaymentRequestStatus(new ListableDto(payReq.getStatus(), true));
				}
			});
			return results;
		}
		return null;
	}

	// to update licence status
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateLicence(@RequestBody TgLicenceDto dto) {

		Licence licence = licenceRepository.get(Licence.class, dto.getLicenceId());
		TouristGuide tg = licence.getTouristGuide();

		// Update Licence status
		if (dto.getIsStatusUpdate()) {
			logger.info("Update Licence Status of TG {} from {} to {}", dto.getLicenceId(), licence.getStatus().getCode(), dto.getLicenceStatusCode());
			// check if TG licence has expired when STB officer is updating TG licence status to active
			if (licence.getExpiryDate().isBefore(LocalDate.now()) && Codes.Statuses.TG_ACTIVE.equals(dto.getLicenceStatusCode())) {
				// if previous TG licence status is not delicence, set TG new licence status to delicence and throw exception
				if (!Codes.Statuses.TG_INACTIVE.equals(licence.getStatus().getCode())) {
					StatusSpan statusSpan = licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_INACTIVE, null, dto.getInternalRemarks(), null, null);

					// 2. Generate alert to notify TG
					alertHelper.createAlert(tg, null, messageHelper.formatLicenceStatusUpdatePlaceholders(Messages.Alerts.LICENCE_STATUS_UPDATE, statusSpan), Codes.Modules.MOD_TG, null, null);

					// 3. Send email to notify TG
					emailHelper.emailUponLicenceStatusUpdate(tg.getName(), statusSpan, Codes.EmailType.TG_LICENCE_STATUS_UPDATE, tg.getEmailAddress());
				}
				throw new ValidationException("Licence has expired. Please advice TG to go through renewal / reinstatement");
			} else {
				if (Codes.Statuses.TG_ACTIVE.equals(dto.getLicenceStatusCode())) {
					tg.setHasPersonUpdateAccess(true);
				} else {
					tg.setHasPersonUpdateAccess(false);
				}
				StatusSpan statusSpan = licenceHelper.updateLicenceStatus(licence, dto.getLicenceStatusCode(), null, dto.getInternalRemarks(), null, null);

				// 2. Generate alert to notify TG
				alertHelper.createAlert(tg, null, messageHelper.formatLicenceStatusUpdatePlaceholders(Messages.Alerts.LICENCE_STATUS_UPDATE, statusSpan), Codes.Modules.MOD_TG, null, null);

				// 3. Send email to notify TG
				emailHelper.emailUponLicenceStatusUpdate(tg.getName(), statusSpan, Codes.EmailType.TG_LICENCE_STATUS_UPDATE, tg.getEmailAddress());
			}
		} else {

			// Update "person update" access
			logger.info("Update Person Update Access of TG {}", dto.getLicenceId());
			tg.setHasPersonUpdateAccess(dto.getHasPersonUpdateAccess());
			touristGuideRepository.update(tg);
		}

	}

	// to enable/disabled portal id
	@RequestMapping(value = "/update/portal-id/{id}/{isPortalId}", method = RequestMethod.GET)
	public void updatePortalId(@PathVariable Integer id, @PathVariable Boolean isPortalId) {
		Licence l = licenceRepository.get(Licence.class, id);
		User user = l.getTouristGuide().getUser();
		logger.info("updatePortalId User: {}, Enable Portal Login : {}", user.getLoginId(), isPortalId);
		if (isPortalId) {
			connectToIams(user, isPortalId);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC_PORTAL));

			// email iams password manager link to user to reset their password before login to TRUST
			emailHelper.emailUponPortalIdEnabled(l.getTouristGuide(), Codes.EmailType.TG_PORTAL_ID_ENABLED, properties.iamsPasswordManagerUrl, "stb.testuser@wizvision.com");
		} else {
			connectToIams(user, isPortalId);
			user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
			// save current password to password history before setting password to null
			passwordHelper.moveCurrentPasswordToHistory(user);
			// set password to null (all singpass holder users account password is null)
			user.setPassword(null);
			user.setSalt(null);
		}
	}

	private void connectToIams(User user, Boolean isPortalId) {
		Boolean isUserExists = false;
		String iamsId = null;
		try {
			// 1. Iams login
			String headerApiUrl = properties.iamsApexEgL1BaseApiUrl + properties.iamsApiLogin;
			String apiUrl = properties.iamsApexIgL0BaseApiUrl + properties.iamsApiLogin;
			HttpHeaders headers = new HttpHeaders();
			String header = "";
			headers.add(Codes.Headers.CONTENT_TYPE, Codes.Headers.Values.APPLICATION_JSON); // must include for APEX API as they enforce content-type else will have 404
			if (properties.iamsApexEnabled) {
				header = generateIamsApexSignature(headerApiUrl, HttpMethod.POST.toString());
				headers.add(Codes.Headers.APEX_AUTH, header);
			}
			String loginPayload = loginIams();
			logger.info("IAMS-LOGIN-ApiUrl: {}, Payload: {}", apiUrl, loginPayload);
			ResponseEntity<String> resp = getRestTemplate().exchange(apiUrl, HttpMethod.POST, new HttpEntity<>(loginPayload, headers), String.class);
			logger.info("IAMS-LOGIN-RESP STATUS: {}, RESP BODY: {}", resp.getStatusCodeValue(), resp.getBody());
			Preconditions.checkState((resp.getStatusCode() == HttpStatus.OK), "Response status not 200: %s", resp.getStatusCodeValue());
			String cookie = resp.getHeaders().getFirst(HttpHeaders.SET_COOKIE);

			// 2. Get All user
			IamsPortalAllUserInfoResponseDto[] allUserObject = getIamsAllUser(cookie);

			// 3. To check if user exists
			for (IamsPortalAllUserInfoResponseDto dto : allUserObject) {
				if (dto.getValues().getCentralAccount() != null && dto.getValues().getCentralAccount().equals(user.getLoginId())) {
					isUserExists = true;
					iamsId = dto.getValues().getUidPerson();
					logger.info("iamsPortal-User Exists: {}", user.getLoginId());
					break;
				}
			}

			if (isPortalId) {// Enable Portal Login
				if (isUserExists) {// If user exists then call to iams-Enable user
					enablePortalUser(user, cookie, iamsId, Boolean.FALSE);
				} else {// If user does not exist then call to iams-Create user
					createPortalUser(user, cookie);
				}
			} else {// Disable Portal Login
				if (isUserExists) {// If user exists then call to iams-disable user
					enablePortalUser(user, cookie, iamsId, Boolean.TRUE);
				}
			}

		} catch (HttpStatusCodeException e) {
			logger.info("RESP STATUS: {}, RESP BODY: {}", e.getRawStatusCode(), e.getResponseBodyAsString());
			logger.error(e.getMessage(), e);
			throw new ValidationException("Unable to connect to IAMS");
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new ValidationException("Unable to connect to IAMS");
		}
	}

	private IamsPortalAllUserInfoResponseDto[] getIamsAllUser(String cookie) throws JsonParseException, JsonMappingException, IOException, ApiUtilException {
		String headerApiUrl = properties.iamsApexEgL1BaseApiUrl + properties.iamsApiAllUser;
		String apiUrl = properties.iamsApexIgL0BaseApiUrl + properties.iamsApiAllUser;
		HttpHeaders headers = new HttpHeaders();
		String header = "";
		headers.add(Codes.Headers.CONTENT_TYPE, Codes.Headers.Values.APPLICATION_JSON); // must include for APEX API as they enforce content-type else will have 404
		headers.add("Cookie", cookie);
		if (properties.iamsApexEnabled) {
			header = generateIamsApexSignature(headerApiUrl, HttpMethod.GET.toString());
			headers.add(Codes.Headers.APEX_AUTH, header);
		}

		logger.info("IAMS-GETALLUSER-ApiUrl: {}", apiUrl);
		ResponseEntity<String> resp = getRestTemplate().exchange(apiUrl, HttpMethod.GET, new HttpEntity<>(headers), String.class);
		logger.info("IAMS-GETALLUSER-RESP STATUS: {}, RESP BODY: {}", resp.getStatusCodeValue(), resp.getBody());
		Preconditions.checkState((resp.getStatusCode() == HttpStatus.OK), "Response status not 200: %s", resp.getStatusCodeValue());
		return objectMapper.readValue(resp.getBody(), IamsPortalAllUserInfoResponseDto[].class);
	}

	private void createPortalUser(User user, String cookie) throws ApiUtilException, IOException {
		String headerApiUrl = properties.iamsApexEgL1BaseApiUrl + properties.iamsApiUser;
		String apiUrl = properties.iamsApexIgL0BaseApiUrl + properties.iamsApiUser;
		HttpHeaders headers = new HttpHeaders();
		String header = "";
		headers.add(Codes.Headers.CONTENT_TYPE, Codes.Headers.Values.APPLICATION_JSON); // must include for APEX API as they enforce content-type else will have 404
		headers.add("Cookie", cookie);
		if (properties.iamsApexEnabled) {
			header = generateIamsApexSignature(headerApiUrl, HttpMethod.POST.toString());
			headers.add(Codes.Headers.APEX_AUTH, header);
		}

		IamsPortalUserValueRequestDto valueDto = new IamsPortalUserValueRequestDto();
		IamsPortalUserRequestDto dto = new IamsPortalUserRequestDto();
		dto.setFirstName(user.getTouristGuide().getName());
		dto.setLastName(user.getTouristGuide().getName());
		dto.setCentralAccount(user.getLoginId());
		dto.setDefaultEmailAddress(user.getTouristGuide().getEmailAddress());
		dto.setContactEmail(user.getTouristGuide().getEmailAddress());
		dto.setPhone(user.getTouristGuide().getMobileNo());
		dto.setIsExternal(Boolean.TRUE);
		dto.setIsInActive(Boolean.FALSE);
		valueDto.setValues(dto);
		String dtoMapper = objectMapper.writeValueAsString(valueDto);

		logger.info("IAMS-createPortalUser-ApiUrl:{}, REQ BODY: {}", apiUrl, dtoMapper);
		ResponseEntity<String> resp = getRestTemplate().exchange(apiUrl, HttpMethod.POST, new HttpEntity<>(dtoMapper, headers), String.class);
		logger.info("IAMS-createPortalUser-RESP STATUS: {}, RESP BODY: {}", resp.getStatusCodeValue(), resp.getBody());
		Preconditions.checkState((resp.getStatusCode() == HttpStatus.OK), "Response status not 200: %s", resp.getStatusCodeValue());
		IamsCreatePortalUserValueResponseDto responseDto = objectMapper.readValue(resp.getBody(), IamsCreatePortalUserValueResponseDto.class);
	}

	private void enablePortalUser(User user, String cookie, String iamsId, Boolean status) throws ApiUtilException, JsonProcessingException {
		String headerApiUrl = properties.iamsApexEgL1BaseApiUrl + properties.iamsApiUser + "/" + iamsId;
		String apiUrl = properties.iamsApexIgL0BaseApiUrl + properties.iamsApiUser + "/" + iamsId;
		HttpHeaders headers = new HttpHeaders();
		String header = "";
		headers.add(Codes.Headers.CONTENT_TYPE, Codes.Headers.Values.APPLICATION_JSON); // must include for APEX API as they enforce content-type else will have 404
		headers.add("Cookie", cookie);
		if (properties.iamsApexEnabled) {
			header = generateIamsApexSignature(headerApiUrl, HttpMethod.PUT.toString());
			headers.add(Codes.Headers.APEX_AUTH, header);
		}

		IamsPortalUserValueRequestDto valueDto = new IamsPortalUserValueRequestDto();
		IamsPortalUserRequestDto dto = new IamsPortalUserRequestDto();
		dto.setFirstName(user.getTouristGuide().getName());
		dto.setLastName(user.getTouristGuide().getName());
		dto.setCentralAccount(user.getLoginId());
		dto.setDefaultEmailAddress(user.getTouristGuide().getEmailAddress());
		dto.setContactEmail(user.getTouristGuide().getEmailAddress());
		dto.setPhone(user.getTouristGuide().getMobileNo());
		dto.setIsExternal(Boolean.TRUE);
		dto.setIsInActive(status);
		valueDto.setValues(dto);
		String dtoMapper = objectMapper.writeValueAsString(valueDto);

		logger.info("IAMS-enablePortalUser-ApiUrl: {},User isInactive Status: {}", apiUrl, status);
		logger.info("IAMS-enablePortalUser- REQ BODY: {}", dtoMapper);
		ResponseEntity<String> resp = getRestTemplate().exchange(apiUrl, HttpMethod.PUT, new HttpEntity<>(dtoMapper, headers), String.class);
		logger.info("IAMS-enablePortalUser-RESP STATUS: {}, RESP BODY: {}", resp.getStatusCodeValue(), resp.getBody());
		Preconditions.checkState((resp.getStatusCode() == HttpStatus.OK), "Response status not 200: %s", resp.getStatusCodeValue());
	}

	private String loginIams() throws JsonProcessingException {
		IamsPortalLoginRequestDto iamsPortalLoginDto = new IamsPortalLoginRequestDto();
		iamsPortalLoginDto.setAuthString(properties.iamsApiLoginInfo);
		return objectMapper.writeValueAsString(iamsPortalLoginDto);
	}

	// reset portal id password
	@RequestMapping(value = "/update/portal-id-password/{id}", method = RequestMethod.GET)
	public void updatePortalIdPassword(@PathVariable Integer id) {
		Licence l = licenceRepository.get(Licence.class, id);
		User user = l.getTouristGuide().getUser();

		// validate valid portal id
		if (!user.getType().getCode().equals(Codes.UserTypes.USER_PUBLIC_PORTAL)) {
			throw new ValidationException("Licensee does not have portal id enabled");
		}

		logger.info("updatePortalIdPassword User: {}, Enable Portal Login : {}", user.getLoginId(), "True");

		connectToIams(user, Boolean.TRUE);

		// email iams password manager link to user to reset their password before login to TRUST
		emailHelper.emailUponPortalIdEnabled(l.getTouristGuide(), Codes.EmailType.TG_PORTAL_ID_ENABLED, properties.iamsPasswordManagerUrl, l.getTouristGuide().getEmailAddress());
	}

	// to print TG licence mailing label
	@RequestMapping(value = "/print/mailing-label", method = RequestMethod.POST)
	public void printMailingLabels(@RequestBody TgLicenceSearchDto searchDto, HttpServletResponse response) throws IOException {
		logger.info(
				"Download records for TG Mailing Labels. [searchDto: name: {}, licenceNo: {}, language: {}, licenceType: {}, expiryDate: {}, "
						+ "licenceStatus: {}, workPassExpiryDateFrom: {}, workPassExpiryDateTo: {}]",
				searchDto.getName(), searchDto.getLicenceNo(), searchDto.getLanguage(), searchDto.getLicenceType(), searchDto.getExpiryDate(), searchDto.getLicenceStatus(),
				searchDto.getWorkPassExpiryDateFrom(), searchDto.getWorkPassExpiryDateTo());
		List<Licence> licences = licenceRepository.getListOfTgLicenceForMailingLabels(searchDto);
		logger.info("TG Mailing Labels total records={}", licences.size());
		generateExcelMailingLabel(licences, response);
	}

	public void generateExcelMailingLabel(List<Licence> licences, HttpServletResponse response) throws IOException {
		String tempFileLocation = properties.baseDir + properties.downloadDir;
		String fileName = "TG_mailing_labels_" + DateUtil.format(LocalDate.now(), REPORT_DATE_FORMAT_PATTERN);
		logger.info("Creating new file for TG Mailing Labels [fileName: {}]", fileName);

		// create document
		XWPFDocument doc = new XWPFDocument();

		// set margin
		double twipsPerCentimeters = 566.93;
		long marginTopBottom = (long) (0.38 * twipsPerCentimeters);
		CTSectPr sectPr = doc.getDocument().getBody().addNewSectPr();
		CTPageMar pageMar = sectPr.addNewPgMar();
		pageMar.setLeft(BigInteger.ZERO);
		pageMar.setTop(BigInteger.valueOf(marginTopBottom));
		pageMar.setRight(BigInteger.ZERO);
		pageMar.setBottom(BigInteger.valueOf(marginTopBottom));

		// set page size
		if (!sectPr.isSetPgSz()) {
			sectPr.addNewPgSz();
		}

		CTPageSz pageSz = sectPr.getPgSz();
		// A4 size in points is 595x842. 1 point is 20 twips
		pageSz.setW(BigInteger.valueOf(595 * 20));
		pageSz.setH(BigInteger.valueOf(842 * 20));

		// create table
		XWPFTable table = doc.createTable(1, 2);

		int i = 0;
		int index = 0;
		for (Licence licence : licences) {

			TouristGuide tg = licence.getTouristGuide();
			long tableWidth = (long) (10.5 * twipsPerCentimeters); // 10.5 cm is 4.133858 inch
			XWPFTableRow row = table.getRow(i);

			if (index == 0 || index % 2 == 0) {
				if (row == null) {
					// add row
					row = table.createRow();
				}
				XWPFTableCell cell = row.getCell(0);
				toFormattedCell(cell, tg, tableWidth);
				// setHeight in twips (Twentieth of an Inch Point).
				row.setHeight((int) (4.8 * twipsPerCentimeters));
			} else {
				XWPFTableCell cell = row.getCell(1);
				toFormattedCell(cell, tg, tableWidth);
				i++;
			}

			index++;
		}

		String outputFilePath = tempFileLocation + "/" + fileName + ".docx";
		// create physical excel in specified outputFilePath
		FileOutputStream fileOutput = new FileOutputStream(outputFilePath);
		doc.write(fileOutput);
		fileOutput.close();
		FileUtil.downloadSingleFile(response, new File(outputFilePath), null);

	}

	private void toFormattedCell(XWPFTableCell cell, TouristGuide tg, long tableWidth) {
		cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);

		XWPFParagraph paragraph = cell.addParagraph();
		paragraph.setIndentationLeft(1800);
		toFormattedMailingLabel(paragraph, tg);

		CTTblWidth cellWidth = cell.getCTTc().addNewTcPr().addNewTcW();
		cellWidth.setW(BigInteger.valueOf(tableWidth));
	}

	private void toFormattedMailingLabel(XWPFParagraph paragraph, TouristGuide tg) {
		XWPFRun run = paragraph.createRun();
		run.setFontFamily("Calibri");
		run.setFontSize(11);
		run.setText(tg.getName());
		run.addBreak();

		Address address = tg.getMailingAddress() != null ? tg.getMailingAddress() : tg.getRegisteredAddress();

		Type addressType = address != null ? address.getAddressType() : null;

		if (addressType != null && Codes.Types.ADDR_LOCAL.equals(addressType.getCode())) {
			// populating block + street
			String street = address.getStreet();
			String block = address.getBlock();

			if (!StringUtils.isBlank(block)) {
				run.setText(block + " " + street);
			} else {
				run.setText(street);
			}

			// populating floor, unit and building
			String floor = address.getFloor();
			String unit = address.getUnit();
			String building = address.getBuilding();
			String floorUnitBuilding = "";
			if (!StringUtils.isBlank(floor) || !StringUtils.isBlank(unit) || !StringUtils.isBlank(building)) {
				run.addBreak();
			}
			if (!StringUtils.isBlank(floor)) {
				if (!StringUtils.isBlank(unit)) {
					floorUnitBuilding += "#" + floor;
				} else {
					floorUnitBuilding += floor;
				}
			}
			if (!StringUtils.isBlank(floor) && !StringUtils.isBlank(unit)) {
				floorUnitBuilding += "-" + unit;
			} else {
				if (!StringUtils.isBlank(unit)) {
					floorUnitBuilding += unit;
				}
			}
			if (!StringUtils.isBlank(building)) {
				if (!StringUtils.isBlank(floor) || !StringUtils.isBlank(unit)) {
					floorUnitBuilding += " " + building;
				} else {
					floorUnitBuilding += building;
				}
			}

			run.setText(floorUnitBuilding);

			// populating postal
			String postal = address.getPostal();
			if (!StringUtils.isBlank(postal)) {
				run.addBreak();
				run.setText("SINGAPORE " + postal);
			}
		} else {

			if (address != null) {
				run.setText(address.getForeignLine1());
				if (!StringUtils.isEmpty(address.getForeignLine2())) {
					run.addBreak();
					run.setText(address.getForeignLine2());
				}
				if (!StringUtils.isEmpty(address.getForeignLine3())) {
					run.addBreak();
					run.setText(address.getForeignLine3());
				}
			}
		}
	}

	// to update hasPassedon status and licence status
	@RequestMapping(value = "/update/haspassedon", method = RequestMethod.POST)
	public void updateHasPassedOn(@RequestBody TgLicenceDto dto) {
		Licence licence = licenceRepository.get(Licence.class, dto.getLicenceId());
		TouristGuide tg = licence.getTouristGuide();

		if (dto.getHasPassedOn()) {
			logger.info("Update Licence status to delicensed and hasPassedOn status to Yes {}", dto.getLicenceId());
			tg.setHasPassedOn(dto.getHasPassedOn());
			touristGuideRepository.update(tg);

			StatusSpan statusSpan = licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_INACTIVE, null, dto.getInternalRemarks(), null, LocalDateTime.now());

		} else {
			logger.info("Update Licence status to licensed and hasPassedOn status to No {}", dto.getLicenceId());
			tg.setHasPassedOn(dto.getHasPassedOn());
			touristGuideRepository.update(tg);

			StatusSpan statusSpan = licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE, null, dto.getInternalRemarks(), null, LocalDateTime.now());
		}
	}

	@RequestMapping(value = "/elicence/save/{id}", method = RequestMethod.POST)
	public void updateELicenceDetails(@RequestBody TgLicenceDto dto, @PathVariable Integer id) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(id);

		if (tg != null) {
			if (!Strings.isNullOrEmpty(dto.getDisplayName())) {
				tg.setDisplayName(dto.getDisplayName().toUpperCase().trim());
			} else {
				tg.setDisplayName(null);
			}
			if (!Strings.isNullOrEmpty(dto.getDisplaySecondName())) {
				tg.setDisplaySecondName(dto.getDisplaySecondName().toUpperCase().trim());
			} else {
				tg.setDisplaySecondName(null);
			}
			if (!Strings.isNullOrEmpty(dto.getDisplayEmployerName())) {
				tg.setDisplayEmployerName(dto.getDisplayEmployerName().toUpperCase().trim());
			} else {
				tg.setDisplayEmployerName(null);
			}
			if (!Strings.isNullOrEmpty(dto.getDisplaySecondEmployerName())) {
				tg.setDisplaySecondEmployerName(dto.getDisplaySecondEmployerName().toUpperCase().trim());
			} else {
				tg.setDisplaySecondEmployerName(null);
			}
			touristGuideRepository.update(tg);
		}
	}

	public String generateIamsApexSignature(String egL2ApiUrl, String reqMethod) throws ApiUtilException {
		String egL1Signature = ApiSigning.getSignatureToken(properties.iamsApexEgL1Realm, Codes.Apex.INTERNET_L1, reqMethod, egL2ApiUrl, properties.iamsApexEgL1AppId, properties.iamsApexEgL1Secret,
				null, null, null, null, null, null);
		logger.info("APEX egL1EndPoint: {}, Header-egL1Signature: {}", egL2ApiUrl, egL1Signature);
		return egL1Signature;
	}

	private RestTemplate getRestTemplate() {
		CloseableHttpClient httpClient;
		if (properties.tagProxyEnabled || properties.appEnv.equals(Codes.Environments.SIT)) {
			HttpHost proxyHost = new HttpHost(properties.tagProxyHost, properties.tagProxyPort);
			httpClient = HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).setProxy(proxyHost).build();
		} else {
			httpClient = HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).build();
		}
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		return new RestTemplate(requestFactory);
	}
}
