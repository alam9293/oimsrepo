package gov.stb.tag.controllers.tg;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Objects;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licencecreation.TgLicenceCreationDto;
import gov.stb.tag.dto.tg.licencecreation.TgLicenceCreationItemDto;
import gov.stb.tag.dto.tg.licencecreation.TgLicenceCreationSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.CpfHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgLicenceCreation;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgCandidateRepository;
import gov.stb.tag.repository.tg.TgLicenceCreationRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/creations")
@Transactional
public class TgLicenceCreationController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicenceCreationRepository tgLicenceCreationRepository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	TgCandidateRepository tgCandidateRepository;

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	FileRepository fileRepository;

	@Autowired
	LicenceHelper licenceHelper;

	@Autowired
	EmailHelper emailHelper;

	@Autowired
	AlertHelper alertHelper;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	UserHelper userHelper;

	@Autowired
	PaymentHelper paymentHelper;

	@Autowired
	CpfHelper cpfHelper;

	/*
	 * Internet
	 */
	// get application no
	@RequestMapping(value = "/new/application-no", method = RequestMethod.GET)
	public TgLicenceCreationDto getApplicationNo() {
		Integer tgCandidateId = getUser().getTgCandidate().getId();
		TgCandidate tc = tgCandidateRepository.getTgCandidateById(tgCandidateId);
		TgLicenceCreation tlc = tgLicenceCreationRepository.getApplication(tc.getUin());
		return new TgLicenceCreationDto(cache, tlc, tc, appHelper, paymentHelper, fileHelper, userHelper, licenceHelper, cpfHelper, true);
	}

	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TgLicenceCreationDto newApplication() {
		Integer tgCandidateId = getUser().getTgCandidate().getId();
		TgCandidate tc = tgCandidateRepository.getTgCandidateById(tgCandidateId);
		TgLicenceCreation tlc = tgLicenceCreationRepository.getApplication(tc.getUin());
		return new TgLicenceCreationDto(cache, tlc, tc, appHelper, paymentHelper, fileHelper, userHelper, licenceHelper, cpfHelper, true);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public TgLicenceCreationDto saveBeforePayment(@RequestPart(name = "dto") TgLicenceCreationDto itemDto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {

		var user = getUser();
		TgLicenceCreation tlc;
		Application application;
		if (itemDto.getId() != null) {
			tlc = tgLicenceCreationRepository.get(TgLicenceCreation.class, itemDto.getId());
			appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_CREATION);

			application = tlc.getApplication();

		} else {
			tlc = new TgLicenceCreation();
			tgLicenceCreationRepository.save(tlc);
			application = appHelper.saveNewApplication(Codes.ApplicationTypes.TG_APP_CREATION, null, false, true);
		}

		updateTgLicenceCreation(tlc, itemDto, application, deletedFiles, user);
		tgLicenceCreationRepository.save(tlc);

		return TgLicenceCreationDto.buildSubmissionDetails(cache, paymentHelper, tlc);
	}

	@RequestMapping(value = "/save/payment", method = RequestMethod.POST)
	public TgLicenceCreationDto newApplicationPayment(@RequestPart(name = "dto") TgLicenceCreationDto itemDto) {
		Integer tgCandidateId = getUser().getTgCandidate().getId();
		TgCandidate tc = tgCandidateRepository.getTgCandidateById(tgCandidateId);
		String tgCandidateNric = tc.getUin();

		var tlc = tgLicenceCreationRepository.getApplication(tgCandidateNric);
		if (tlc != null) {
			itemDto.setId(tlc.getId());

			var application = tlc.getApplication();
			if (application != null) {
				PaymentRequest pr = paymentHelper.savePaymentRequest(application.getApplicationNo(), Codes.TgPaymentRequestTypes.PAYREQ_TG_CREATION, tlc.getUin(), tlc.getName(),
						new BigDecimal(itemDto.getPaymentFee()), "TG Licence Creation Licence Fee", null, true, false, tlc.getEmailAddress());
				tlc.setAppFeeBillRefNo(pr.getBillRefNo());
				itemDto.setBillRefNo(pr.getBillRefNo());
			}
		}

		return itemDto;
	}

	@RequestMapping(value = "/save/{id}", method = RequestMethod.GET)
	public TgLicenceCreationDto saveAfterPayment(@PathVariable Integer id) {
		TgLicenceCreationDto dto = new TgLicenceCreationDto();

		var user = getUser();

		TgLicenceCreation tlc = tgLicenceCreationRepository.getLicenceCreationById(id);
		appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_CREATION);

		var application = tlc.getApplication();
		var lastAction = application.getLastAction();

		PaymentRequest payReq = paymentHelper.getPaymentRequest(tlc.getAppFeeBillRefNo());
		PaymentTxn paymentTxn = payReq.getLastTxn();

		if (Entities.equals(payReq.getStatus(), Codes.Statuses.PAYREQ_WAIVED) || paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL))) {

			if (lastAction == null || Entities.anyEquals(application.getLicencePrintStatus(), null, Codes.Statuses.PRINT_PENDING_APPROVAL)) {
				application.setIsDraft(false);
				application.setSubmissionDate(LocalDateTime.now());
				application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_APPROVAL));

				approveApplication(application, tlc);
			}

			dto.setApplicationNo(application.getApplicationNo());
			dto.setIsDraft(false);
			dto.setId(tlc.getId());
			dto.setPaymentSuccess(true);
		} else {
			dto.setPaymentSuccess(false);
		}

		return dto;
	}

	@RequestMapping(value = "/draft", method = RequestMethod.POST)
	public void draftApplication(@RequestPart(name = "dto") TgLicenceCreationDto itemDto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {
		var user = getUser();
		Integer tgCandidateId = getUser().getTgCandidate().getId();
		TgCandidate tc = tgCandidateRepository.getTgCandidateById(tgCandidateId);

		TgLicenceCreation tlc;
		Application application;

		// to check whether user save application as draft before
		if (itemDto.getId() != null) {
			tlc = tgLicenceCreationRepository.getLicenceCreationById(itemDto.getId());
			appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_CREATION);

			application = tlc.getApplication();

		} else {
			tlc = new TgLicenceCreation();
			tgLicenceCreationRepository.save(tlc);
			application = appHelper.saveNewApplication(Codes.ApplicationTypes.TG_APP_CREATION, null, false, true);
		}

		updateTgLicenceCreation(tlc, itemDto, application, deletedFiles, user);

		if (itemDto.getId() == null) {
			String url = String.format(properties.applicationUrl, "tg/application-form/" + tlc.getId());

			String userEmail = null;
			if (StringUtils.isBlank(itemDto.getEmailAddress())) {
				var lastCandidateResult = tc.getLastCandidateResult();
				userEmail = lastCandidateResult.getEmail();
			} else {
				userEmail = itemDto.getEmailAddress();
			}

			emailHelper.emailUponTgAction(application, user.getName(), Codes.EmailType.TG_APP_DRAFT, url, userEmail);
		}
	}

	@RequestMapping(value = "/load/{id}", method = RequestMethod.GET)
	public TgLicenceCreationDto getApplication(@PathVariable Integer id) {
		var tlc = tgLicenceCreationRepository.getLicenceCreationById(id);
		var user = getUser();
		appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_CREATION);

		return TgLicenceCreationDto.buildSubmissionDetails(cache, paymentHelper, tlc);
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public TgLicenceCreationDto retrieveApplication(@PathVariable Integer id) {

		var tlc = tgLicenceCreationRepository.getLicenceCreationById(id);
		var user = getUser();
		Integer tgCandidateId = getUser().getTgCandidate().getId();
		TgCandidate tc = tgCandidateRepository.getTgCandidateById(tgCandidateId);
		appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_CREATION);
		return new TgLicenceCreationDto(cache, tlc, tc, appHelper, paymentHelper, fileHelper, userHelper, licenceHelper, cpfHelper, true);
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateApplication(@RequestPart(name = "dto") TgLicenceCreationDto itemDto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {

		var user = getUser();
		var tlc = tgLicenceCreationRepository.getLicenceCreationById(itemDto.getId());
		appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_CREATION);

		Application application = tlc.getApplication();

		updateTgLicenceCreation(tlc, itemDto, application, deletedFiles, user);
		approveRfaApplication(application, tlc, user.getTouristGuide());
	}

	private void updateTgLicenceCreation(TgLicenceCreation tlc, TgLicenceCreationDto itemDto, Application application, List<Integer> deletedFiles, User user) {
		tlc.setUin(itemDto.getNric());
		tlc.setUser(user);
		tlc.setSalutation(itemDto.getSalutation() != null ? cache.getType(itemDto.getSalutation()) : null);
		tlc.setName(itemDto.getName());
		tlc.setDob(itemDto.getDob());
		tlc.setSex(itemDto.getSex() != null ? cache.getType(itemDto.getSex()) : null);
		tlc.setMaritalStatus(itemDto.getMaritalStatus() != null ? cache.getType(itemDto.getMaritalStatus()) : null);
		tlc.setRace(itemDto.getRace() != null ? cache.getType(itemDto.getRace()) : null);
		tlc.setNationality(itemDto.getNationality() != null ? cache.getType(itemDto.getNationality()) : null);
		tlc.setBirthCountry(itemDto.getBirthCountry() != null ? cache.getType(itemDto.getBirthCountry()) : null);
		tlc.setResidentialStatus(itemDto.getResidentialStatus() != null ? cache.getType(itemDto.getResidentialStatus()) : null);
		tlc.setHighestEduLevel(itemDto.getHighestEduLevel() != null ? cache.getType(itemDto.getHighestEduLevel()) : null);
		tlc.setMobileNo(itemDto.getMobileNo());
		tlc.setEmailAddress(itemDto.getEmailAddress());
		tlc.setEmployerName(itemDto.getEmployerName());
		tlc.setOccupation(itemDto.getOccupation() != null ? cache.getType(itemDto.getOccupation()) : null);
		tlc.setOccupationOther(itemDto.getOccupationOther());
		tlc.setWorkPassType(itemDto.getWorkPassType() != null ? cache.getType(itemDto.getWorkPassType()) : null);
		tlc.setWorkpassExpiryDate(itemDto.getWorkpassExpiryDate() != null ? itemDto.getWorkpassExpiryDate() : null);
		tlc.setAliasName(itemDto.getAliasName());
		tlc.setHasConsentEmailAddress(itemDto.getHasConsentEmailAddress());
		tlc.setHasConsentMobileNo(itemDto.getHasConsentMobileNo());
		tlc.setIsMyInfoPopulated(itemDto.isMyInfoPopulated());
		tlc.setApplication(application);

		Address regAddr = null;
		if (itemDto.getRegPostal() != null) {
			regAddr = tlc.getRegisteredAddress();

			if (regAddr == null) {
				regAddr = new Address();
				tgLicenceCreationRepository.save(regAddr);
			}

			String addressType = itemDto.getRegType().getKey().toString();
			if (addressType.equals(Codes.Types.ADDR_LOCAL)) {
				regAddr = AddressDto.buildAddressFromDto(regAddr, cache.getType(addressType), itemDto.getRegStreet(), itemDto.getRegBuilding(), itemDto.getRegBlock(), itemDto.getRegFloor(),
						itemDto.getRegUnit(), itemDto.getRegPostal(), null, null, null);
			} else if (addressType.equals(Codes.Types.ADDR_FOREIGN)) {
				regAddr = AddressDto.buildAddressFromDto(regAddr, cache.getType(addressType), null, null, null, null, null, null, itemDto.getRegForeignLine1(), itemDto.getRegForeignLine2(),
						itemDto.getRegForeignLine3());
			}
			tlc.setRegisteredAddress(regAddr);
		}

		Address opAddr = null;
		if (itemDto.getIsAddrSame()) {
			tlc.setOperatingAddress(tlc.getRegisteredAddress());
		} else {
			if (itemDto.getOptPostal() != null) {
				opAddr = tlc.getOperatingAddress();

				if (opAddr == null || Objects.equal(opAddr, regAddr)) {
					opAddr = new Address();
					tgLicenceCreationRepository.save(opAddr);
				}

				String addressType = itemDto.getOptType().getKey().toString();
				if (addressType.equals(Codes.Types.ADDR_LOCAL)) {
					opAddr = AddressDto.buildAddressFromDto(opAddr, cache.getType(addressType), itemDto.getOptStreet(), itemDto.getOptBuilding(), itemDto.getOptBlock(), itemDto.getOptFloor(),
							itemDto.getOptUnit(), itemDto.getOptPostal(), null, null, null);
				} else if (addressType.equals(Codes.Types.ADDR_FOREIGN)) {
					opAddr = AddressDto.buildAddressFromDto(opAddr, cache.getType(addressType), null, null, null, null, null, null, itemDto.getOptForeignLine1(), itemDto.getOptForeignLine2(),
							itemDto.getOptForeignLine3());
				}

				tlc.setOperatingAddress(opAddr);
			}
		}

		if (itemDto.isConvictChecked()) {
			tlc.setOffenceDate(itemDto.getOffenceDate());
			tlc.setOffenceDeclaredDate(LocalDateTime.now());
			tlc.setOffenceType(itemDto.getOffenceType());
			tlc.setEnforcementOutcome(itemDto.getEnforcementOutcome());
		} else {
			tlc.setOffenceDate(null);
			tlc.setOffenceDeclaredDate(null);
			tlc.setOffenceType(null);
			tlc.setEnforcementOutcome(null);
		}

		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}
		}

		if (itemDto.getPhoto() != null && itemDto.getPhoto().getPublicFileId() == null) {

			Set<ApplicationFile> applicationFileSet = application.getApplicationFiles();
			if (CollectionUtils.isNotEmpty(applicationFileSet)) {
				for (ApplicationFile af : applicationFileSet) {
					if (Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equalsIgnoreCase(af.getDocumentType().getCode())) {
						fileHelper.deleteFile(af.getFile());
					}
				}
			}

			ApplicationFile file = fileHelper.saveFile(application, itemDto.getPhoto());
			if (application.getApplicationFiles() != null) {
				application.getApplicationFiles().add(file);
			}
		}

		if (itemDto.getOtherSupportDocs() != null) {
			for (FileDto doc : itemDto.getOtherSupportDocs()) {
				if (doc.getPublicFileId() == null) {
					fileHelper.saveFile(application, doc);
				}
			}
		}
		tgLicenceCreationRepository.saveOrUpdate(tlc);
	}

	/*
	 * Intranet
	 */

	// to retrieve all pending new applications
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgLicenceCreationItemDto> getPendingList(TgLicenceCreationSearchDto searchDto) {
		return tgLicenceCreationRepository.getPendingList(searchDto);
	}

	// to retrieve submitted application details by application id
	@RequestMapping(value = "/view/app/{id}", method = RequestMethod.GET)
	public ResponseEntity<TgLicenceCreationDto> getLicenceCreationDetailByApplication(@PathVariable Integer id) {
		var tlc = tgLicenceCreationRepository.getLicenceCreationByApplicationId(id);
		var tgCandidate = tgCandidateRepository.getTgCandidateByUin(tlc.getUin());
		var itemDto = new TgLicenceCreationDto(cache, tlc, tgCandidate, appHelper, paymentHelper, fileHelper, userHelper, licenceHelper, cpfHelper, false);

		return addVersionCheck(itemDto, tlc.getApplication());
	}

	// to retrieve submitted application details
	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public ResponseEntity<TgLicenceCreationDto> getLicenceCreationDetail(@PathVariable Integer id) {
		var tlc = tgLicenceCreationRepository.getLicenceCreationById(id);
		var tgCandidate = tgCandidateRepository.getTgCandidateByUin(tlc.getUin());
		var itemDto = new TgLicenceCreationDto(cache, tlc, tgCandidate, appHelper, paymentHelper, fileHelper, userHelper, licenceHelper, cpfHelper, false);

		return addVersionCheck(itemDto, tlc.getApplication());
	}

	// approve, reject, rfa
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void process(@RequestHeader(Codes.Headers.VERSION_CHECK) String vc, @RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		runVersionCheck(vc);
		TgLicenceCreation tlc = tgLicenceCreationRepository.getLicenceCreationById(id);
		Application app = tlc.getApplication();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(tlc.getUin());

		String alertMsg = null;
		String emailType = null;
		String url = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(app)) {
				url = String.format(properties.applicationUrl, "dashboard-tg");
				emailType = Codes.EmailType.TG_UPON_APPROVAL;
				alertMsg = Messages.Alerts.TG_APP_APPROVE;

				updateMedisavePaymentStatus(tlc);

				app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));

				Licence licence = (tg == null ? null : tg.getLicence());
				tg = saveUpdateTgLicence(tlc, app, licence);

				// update licence to candidate
				var tgCandidate = tgCandidateRepository.getTgCandidateByUin(tlc.getUin());
				if (tgCandidate != null) {
					tgCandidate.setLicence(tg.getLicence());
					logger.info("[{}] approveLicenceCreation() update licence.id={} to tgCandidate.id={}", getUser().getLoginId(), tg.getLicence().getId(), tgCandidate.getId());
				}
			}
			break;

		case ACTION_REJECT:
			url = String.format(properties.applicationUrl, "tg/application-form/" + tlc.getId());
			emailType = Codes.EmailType.TG_UPON_REJECTION;

			app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			String status = dto.getRouteStatus();
			if (StringUtils.equals(status, Codes.Statuses.TG_APP_RFA)) {
				url = String.format(properties.applicationUrl, "tg/application-form/" + tlc.getId());
				emailType = Codes.EmailType.TG_UPON_RFA;
			}

			User user = userRepository.getUserByLoginId(tlc.getUin());
			user.setTouristGuide(tg);
			user.getRoles().remove(cache.getRole(Codes.Roles.TG_PUBLIC));
			user.getRoles().add(cache.getRole(Codes.Roles.TG_CANDIDATE));

			app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_APPROVAL));
			appHelper.rfaAfterApproved(app, status, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (emailType != null) {
			emailHelper.emailUponTgAction(app, tlc.getName(), emailType, url, tlc.getEmailAddress());
		}

		if (alertMsg != null) {
			alertHelper.createAlert(tg, app, alertMsg, Codes.Modules.MOD_TG, app.getType(), "tg/application-form/" + tlc.getId());
		}
	}

	private TouristGuide saveUpdateTgLicence(TgLicenceCreation newTlc, Application newApplication, Licence oldTgLicence) {

		var tgCandidate = tgCandidateRepository.getTgCandidateByUin(newTlc.getUin());
		var lastCandidateResult = tgCandidate.getLastCandidateResult();

		var examDt = lastCandidateResult.getExamDate();
		var directIssuanceDt = lastCandidateResult.getDirectIssuanceDate();
		// var expiryDt = examDt != null ? licenceHelper.calculateExpiryDate(examDt) : licenceHelper.calculateExpiryDate(directIssuanceDt);
		// var startDt = examDt != null ? examDt : directIssuanceDt;
		var startDt = LocalDate.now();
		Integer validMonth = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_VALID_MONTHS).getValue());
		var expiryDt = startDt.plusMonths(validMonth).minusDays(1);

		Set<Type> guidingLanguages = new HashSet<>();
		Set<Type> specializedAreas = new HashSet<>();

		var tg = new TouristGuide();
		if (oldTgLicence != null) {
			tg = oldTgLicence.getTouristGuide();

			oldTgLicence.setStartDate(startDt);
			oldTgLicence.setExpiryDate(expiryDt);
			oldTgLicence.setTier(lastCandidateResult.getTier());
			licenceHelper.updateLicenceStatus(oldTgLicence, Codes.Statuses.TG_ACTIVE, null, startDt.atStartOfDay());
			newApplication.setLicence(oldTgLicence);

		} else {
			tg.setDob(newTlc.getDob());
			tg.setSex(newTlc.getSex());
			tg.setUser(newTlc.getUser());
			tg.setUin(newTlc.getUin());
			touristGuideRepository.save(tg);

			var licence = new Licence();
			licence.setTaTgType(Codes.TaTgType.TG);
			licence.setExpiryDate(expiryDt);
			licence.setTouristGuide(tg);
			licence.setStatus(cache.getStatus(Codes.Statuses.TG_ACTIVE));
			licence.setTier(lastCandidateResult.getTier());
			licence.setIsPendingCessation(false);
			licence.setIssueDate(startDt);
			licence.setStartDate(startDt);

			licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE, null, startDt.atStartOfDay());
			touristGuideRepository.save(licence);

			newApplication.setLicence(licence);
			tg.setLicence(licence);
		}

		tg.setAliasName(newTlc.getAliasName());
		tg.setName(newTlc.getName());
		tg.setMaritalStatus(newTlc.getMaritalStatus());
		tg.setRace(newTlc.getRace());
		tg.setNationality(newTlc.getNationality());
		tg.setBirthCountry(newTlc.getBirthCountry());
		tg.setResidentialStatus(newTlc.getResidentialStatus());
		tg.setHighestEduLevel(newTlc.getHighestEduLevel());
		tg.setMobileNo(newTlc.getMobileNo());
		tg.setSalutation(newTlc.getSalutation());
		tg.setEmailAddress(newTlc.getEmailAddress());
		tg.setEmployerName(newTlc.getEmployerName());
		tg.setOccupation(newTlc.getOccupation());
		tg.setOccupationOther(newTlc.getOccupationOther());
		tg.setWorkPassType(newTlc.getWorkPassType());
		tg.setWorkPassExpiryDate(newTlc.getWorkpassExpiryDate());
		tg.setRegisteredAddress(newTlc.getRegisteredAddress());
		tg.setMailingAddress(newTlc.getOperatingAddress());
		tg.setOffenceDeclaredDate(newTlc.getOffenceDeclaredDate());
		tg.setOffenceDate(newTlc.getOffenceDate());
		tg.setOffenceType(newTlc.getOffenceType());
		tg.setEnforcementOutcome(newTlc.getEnforcementOutcome());
		tg.setHasConsentMobileNo(newTlc.hasConsentMobileNo());
		tg.setHasConsentEmailAddress(newTlc.hasConsentEmailAddress());
		tg.setIsMyInfoPopulated(newTlc.isMyInfoPopulated());
		tg.setHasPersonUpdateAccess(true);

		Optional<ApplicationFile> photoOptional = newApplication.getApplicationFiles().stream().filter(u -> Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(u.getDocumentType().getCode()))
				.findFirst();
		if (photoOptional.isPresent()) {
			var photo = photoOptional.get();
			tg.setPhoto(photo.getFile());
		}

		if (lastCandidateResult.isDirectIssuance() != null && lastCandidateResult.isDirectIssuance()) {
			guidingLanguages.addAll(tgCandidate.getLastCandidateResult().getDiGuidingLanguages());
			tg.setGuidingLanguages(guidingLanguages);
		} else {
			guidingLanguages.add(lastCandidateResult.getGuidingLanguage());
			tg.setGuidingLanguages(guidingLanguages);
		}

		if (lastCandidateResult.getSpecializedArea() != null) {
			specializedAreas.add(lastCandidateResult.getSpecializedArea());
			tg.setSpecializedAreas(specializedAreas);
		}

		User user = userRepository.getUserByLoginId(newTlc.getUin());
		user.setTouristGuide(tg);
		user.getRoles().remove(cache.getRole(Codes.Roles.TG_CANDIDATE));
		user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));

		return tg;

	}

	private void updateMedisavePaymentStatus(TgLicenceCreation tlc) {
		tlc.setMedisavePaymentStatus(cpfHelper.checkMedisavePaymentStatus(tlc.getUin()));
		tgLicenceCreationRepository.saveOrUpdate(tlc);
	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		var tgLicenceCreation = tgLicenceCreationRepository.get(TgLicenceCreation.class, dto.getApplicationId());
		appHelper.saveNote(tgLicenceCreation.getApplication(), dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private void approveRfaApplication(Application app, TgLicenceCreation tlc, TouristGuide tg) {
		Licence lic = new Licence();
		var workflowAction = appHelper.autoApprove(app, true);
		app.setLastAction(workflowAction);

		if (appHelper.hasFinalApproved(app)) {

			updateMedisavePaymentStatus(tlc);

			app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));

			if (app.getLicence() != null) {
				lic = touristGuideRepository.get(Licence.class, app.getLicence().getId());
			}
			tg = saveRfaApplication(tlc, app, lic, tg);
		}
	}

	private void approveApplication(Application app, TgLicenceCreation tlc) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(tlc.getUin());
		var workflowAction = appHelper.autoApprove(app, true);
		app.setLastAction(workflowAction);

		if (appHelper.hasFinalApproved(app)) {

			updateMedisavePaymentStatus(tlc);

			app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));

			Licence licence = (tg == null ? null : tg.getLicence());
			tg = saveUpdateTgLicence(tlc, app, licence);

			// update licence to candidate
			var tgCandidate = tgCandidateRepository.getTgCandidateByUin(tlc.getUin());
			if (tgCandidate != null) {
				tgCandidate.setLicence(tg.getLicence());
				logger.info("[{}] approveLicenceCreation() update licence.id={} to tgCandidate.id={}", getUser().getLoginId(), tg.getLicence().getId(), tgCandidate.getId());
			}

		}

		emailHelper.emailUponTgAction(app, tlc.getName(), Codes.EmailType.TG_RENEWAL_SUBMISSION, String.format(properties.applicationUrl, "dashboard-tg"), tlc.getEmailAddress());
		alertHelper.createAlert(tg, app, Messages.Alerts.TG_RENEWAL_SUBMISSION, Codes.Modules.MOD_TG, app.getType(), "tg/application-form/" + tlc.getId());
	}

	private TouristGuide saveRfaApplication(TgLicenceCreation tlc, Application app, Licence licence, TouristGuide tg) {
		tg.setDob(tlc.getDob());
		tg.setSex(tlc.getSex());
		tg.setUser(tlc.getUser());
		tg.setUin(tlc.getUin());

		app.setLicence(licence);
		tg.setLicence(licence);

		tg.setAliasName(tlc.getAliasName());
		tg.setName(tlc.getName());
		tg.setMaritalStatus(tlc.getMaritalStatus());
		tg.setRace(tlc.getRace());
		tg.setNationality(tlc.getNationality());
		tg.setBirthCountry(tlc.getBirthCountry());
		tg.setResidentialStatus(tlc.getResidentialStatus());
		tg.setHighestEduLevel(tlc.getHighestEduLevel());
		tg.setMobileNo(tlc.getMobileNo());
		tg.setSalutation(tlc.getSalutation());
		tg.setEmailAddress(tlc.getEmailAddress());
		tg.setEmployerName(tlc.getEmployerName());
		tg.setOccupation(tlc.getOccupation());
		tg.setOccupationOther(tlc.getOccupationOther());
		tg.setWorkPassType(tlc.getWorkPassType());
		tg.setWorkPassExpiryDate(tlc.getWorkpassExpiryDate());
		tg.setRegisteredAddress(tlc.getRegisteredAddress());
		tg.setMailingAddress(tlc.getOperatingAddress());
		tg.setOffenceDeclaredDate(tlc.getOffenceDeclaredDate());
		tg.setOffenceDate(tlc.getOffenceDate());
		tg.setOffenceType(tlc.getOffenceType());
		tg.setEnforcementOutcome(tlc.getEnforcementOutcome());
		tg.setHasConsentMobileNo(tlc.hasConsentMobileNo());
		tg.setHasConsentEmailAddress(tlc.hasConsentEmailAddress());
		tg.setIsMyInfoPopulated(tlc.isMyInfoPopulated());
		tg.setHasPersonUpdateAccess(true);

		Optional<ApplicationFile> photoOptional = app.getApplicationFiles().stream()
				.filter(u -> Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(u.getDocumentType().getCode()) && (u.getIsDeleted() == null || u.getIsDeleted() == false)).findFirst();
		if (photoOptional.isPresent()) {
			var photo = photoOptional.get();
			tg.setPhoto(photo.getFile());
		}

		User user = userRepository.getUserByLoginId(tlc.getUin());
		user.setTouristGuide(tg);
		user.getRoles().remove(cache.getRole(Codes.Roles.TG_CANDIDATE));
		user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));

		touristGuideRepository.update(tg);

		touristGuideRepository.update(licence);

		emailHelper.emailUponTgAction(app, tlc.getName(), Codes.EmailType.TG_RENEWAL_SUBMISSION, String.format(properties.applicationUrl, "dashboard-tg"), tlc.getEmailAddress());
		alertHelper.createAlert(tg, app, Messages.Alerts.TG_RENEWAL_SUBMISSION, Codes.Modules.MOD_TG, app.getType(), "tg/application-form/" + tlc.getId());

		return tg;
	}

	@RequestMapping(value = "/view/declaration/{licenceCreationId}", method = RequestMethod.GET)
	public TgLicenceCreationDto getLicenceCreationDeclaration(@PathVariable Integer licenceCreationId) throws Exception {
		TgLicenceCreationDto dto = new TgLicenceCreationDto();
		TgLicenceCreation creation = tgLicenceCreationRepository.getCreation(licenceCreationId);
		dto = TgLicenceCreationDto.buildCreationDeclationDto(cache, creation);
		return dto;
	}
}