package gov.stb.tag.controllers.tg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licenceprint.TgLicencePrintSearchDto;
import gov.stb.tag.dto.tg.licenceprinting.TgLicencePrintingDto;
import gov.stb.tag.dto.tg.licenceprinting.TgLicencePrintingItemDto;
import gov.stb.tag.dto.tg.licenceprinting.TgLicencePrintingResultDto;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.LicenceStatusRepository;
import gov.stb.tag.repository.tg.TgLicencePrintRepository;
import gov.stb.tag.repository.tg.TgLicenceRenewalRepository;
import gov.stb.tag.repository.tg.TgMlptRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.ExcelUtil;
import gov.stb.tag.util.FileUtil;

@RestController
@RequestMapping(path = "/api/v1/tg/licence-printing")
@Transactional
public class TgLicencePrintController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicencePrintRepository tgLicencePrintRepository;

	@Autowired
	LicenceStatusRepository licenceRepository;

	@Autowired
	TgLicencePrintRepository tgPrintColourRepository;

	@Autowired
	TgLicenceRenewalRepository tgLicenceRenewalRepository;

	@Autowired
	TgMlptRepository tgMlptRepository;

	@Autowired
	EmailHelper emailHelper;

	@Autowired
	AlertHelper alertHelper;

	@Autowired
	UserHelper userHelper;

	@Autowired
	LicenceHelper licenceHelper;

	// to retrieve all application
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgLicencePrintingItemDto> getAllList(TgLicencePrintSearchDto searchDto) {
		return tgLicencePrintRepository.getAllListByLicencePrintStatus(searchDto);
	}

	// to download records for send to vendor
	@RequestMapping(value = "/view/selected", method = RequestMethod.POST)
	public void getSelectedList(@RequestBody TgLicencePrintingDto dto, HttpServletResponse response) throws IOException {
		logger.info("Download records for licence printing [count: {}]", dto.getApplicationNos().size());
		List<File> fileList = new ArrayList<File>();
		List<String> fileNameList = new ArrayList<String>();
		List<TgLicencePrintingResultDto> printResultDto = new ArrayList<TgLicencePrintingResultDto>();
		for (String applicationNo : dto.getApplicationNos()) {
			Application application = tgLicencePrintRepository.getSingleApplication(applicationNo);

			Licence licence = application.getLicence();
			TouristGuide tg = licence.getTouristGuide();

			gov.stb.tag.model.File tgPhoto = tg.getPhoto();

			var appFiles = application.getApplicationFiles();
			if (CollectionUtils.isNotEmpty(appFiles)) {
				for (ApplicationFile applicationFile : appFiles) {
					if (Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(applicationFile.getDocumentType().getCode())) {
						tgPhoto = applicationFile.getFile();
					}
				}
			}

			// split to get file format
			String[] splitedFileName = tgPhoto.getFilename().split("\\.");

			// attach file format with licence no_name as file name
			fileNameList.add(licence.getLicenceNo() + "_" + tg.getName() + "." + splitedFileName[splitedFileName.length - 1]);

			// photos physical location
			fileList.add(new File(properties.baseDir + tgPhoto.getPath(), FilenameUtils.getName(tgPhoto.getFilename())));

			// retrieve expiry of physical licence
			LocalDate expiryDate = licence.getExpiryDate();

			printResultDto.add(TgLicencePrintingResultDto.buildFromAssignment(cache, licence, expiryDate, userHelper.checkWorkPassHolder(tg.getUin())));
		}
		generateExcelAndZipPhoto(fileList, fileNameList, printResultDto, response);
	}

	// to update licence print status to send to vendor
	@RequestMapping(value = "/update/sp", method = RequestMethod.POST)
	public void udpateLicencePrintStatusSP(@RequestBody TgLicencePrintingDto dto) {
		logger.info("Update licence print status = Send To Vendor [count: {}; Date: {}]", dto.getApplicationNos().size(), dto.getSendToVendorDate());
		for (String applicationNo : dto.getApplicationNos()) {
			Application application = tgLicencePrintRepository.getSingleApplication(applicationNo);
			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_SUBMIT_PRINT));
			application.setSendToVendorDate(dto.getSendToVendorDate());
			tgLicencePrintRepository.update(application);
		}
	}

	// to update licence print status to pending collection
	@RequestMapping(value = "/update/pc", method = RequestMethod.POST)
	public void udpateLicencePrintStatusPC(@RequestBody TgLicencePrintingDto dto) {
		logger.info("Update licence print status = Pending Collection [count: {}]", dto.getApplicationNos().size());
		for (String applicationNo : dto.getApplicationNos()) {
			Application application = tgLicencePrintRepository.getSingleApplication(applicationNo);

			String workPassType = "";
			TouristGuide tg = application.getLicence().getTouristGuide();

			if (tg.getWorkPassType() != null) {
				workPassType = "WorkPass";
			} else {
				workPassType = "NRIC";
			}
			// emailHelper.emailUponUdpateLicencePrintStatusPC(application, tg.getName(), Codes.EmailType.TG_LICENCE_COLLECT, workPassType, dto.getPendingCollectionStartDate(),
			// dto.getPendingCollectionEndDate(), tg.getUser().getEmailAddress());
			alertHelper.createAlert(tg, application, Messages.Alerts.LICENCE_COLLECT, Codes.Modules.MOD_TG, application.getType(), null);
			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_COLLECTION));
			application.setPendingCollectionStartDate(dto.getPendingCollectionStartDate());
			application.setPendingCollectionEndDate(dto.getPendingCollectionEndDate());
			tgLicencePrintRepository.update(application);
		}
	}

	// to licence print status to licence collected
	@RequestMapping(value = "/update/lc", method = RequestMethod.POST)
	public void udpateLicencePrintStatus(@RequestBody TgLicencePrintingDto dto) {
		logger.info("Update licence print status = Licence Collected [count: {}; Date: {}]", dto.getApplicationNos().size(), dto.getCollectedDate());
		for (String applicationNo : dto.getApplicationNos()) {
			Application application = tgLicencePrintRepository.getSingleApplication(applicationNo);
			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_LICENCE_COLLECTED));
			application.setLicenceCollectedDate(dto.getCollectedDate());
			tgLicencePrintRepository.update(application);
		}
	}

	public void generateExcelAndZipPhoto(List<File> fileList, List<String> fileNameList, List<TgLicencePrintingResultDto> taiDto, HttpServletResponse response) throws IOException {
		String tempFileLocation = properties.baseDir + properties.downloadDir;
		File originalExcelFile = new File(tempFileLocation + "/TG_licence_print_template.xlsx");
		FileInputStream fileInput = new FileInputStream(originalExcelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(fileInput);
		XSSFSheet sheet = workbook.getSheet("Printing template");
		ExcelUtil.createHeaderRow(sheet, Codes.FileHeader.TG_LICENCE_PRINT);

		int i = 1;
		for (TgLicencePrintingResultDto dto : taiDto) {
			XSSFRow row = sheet.createRow(i++);
			int j = 0;

			row.createCell(j++, CellType.STRING).setCellValue(dto.getLicenceType().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLicenceNo());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getName1().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getColumn());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getName2().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getCal2());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage1().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage2().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage3().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage4().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage5().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage6().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage7().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage8().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getLanguage9().toUpperCase());
			row.createCell(j++, CellType.STRING).setCellValue(DateUtil.format(dto.getExpiryDate(), DateUtil.DATE_FORMAT_PATTERN_2).toUpperCase());
		}
		String excelFileName = "print_template_" + DateUtil.format(LocalDate.now());
		String outputFilePath = tempFileLocation + "/" + excelFileName + ".xlsx";
		// create physical excel in specified outputFilePath
		FileOutputStream fileOutput = new FileOutputStream(outputFilePath);
		workbook.write(fileOutput);
		workbook.close();
		fileList.add(new File(outputFilePath));
		// add excel file name to list
		fileNameList.add(excelFileName + ".xlsx");
		String zipFile = CreateZipFileFromMultipleFilesWithZipOutputStream(fileList, fileNameList, excelFileName);
		FileUtil.downloadSingleFile(response, new File(zipFile), null);
	}

	private String CreateZipFileFromMultipleFilesWithZipOutputStream(List<File> srcFiles, List<String> fileNameList, String excelFileName) {
		String zipFile = String.format(properties.baseDir + properties.downloadDir + excelFileName + ".zip");

		try {
			// create byte buffer
			byte[] buffer = new byte[4 * 1024];
			FileOutputStream fos = new FileOutputStream(zipFile);
			ZipOutputStream zos = new ZipOutputStream(fos);

			int i = 0;
			for (File srcFile : srcFiles) {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(srcFile);
					// begin writing a new ZIP entry, positions the stream to the start of the entry data
					zos.putNextEntry(new ZipEntry(fileNameList.get(i)));
					int length;

					while ((length = fis.read(buffer)) > 0) {
						zos.write(buffer, 0, length);
					}

					// close the InputStream
					fis.close();
				} catch (IOException ioe) {
					logger.error("Error getting file: " + ioe);
				}
				i++;
				zos.closeEntry();
			}

			// close the ZipOutputStream
			zos.close();
		} catch (IOException ioe) {
			logger.error("Error creating zip file: " + ioe);
		}

		return zipFile;
	}
}
