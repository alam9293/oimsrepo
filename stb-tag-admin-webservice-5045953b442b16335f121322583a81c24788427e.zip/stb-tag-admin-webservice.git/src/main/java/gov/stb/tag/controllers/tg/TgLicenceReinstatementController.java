package gov.stb.tag.controllers.tg;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.repository.tg.TgLicenceReinstatementRepository;

@RestController
@RequestMapping(path = "/api/v1/tg")
@Transactional
public class TgLicenceReinstatementController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicenceReinstatementRepository repository;

}
