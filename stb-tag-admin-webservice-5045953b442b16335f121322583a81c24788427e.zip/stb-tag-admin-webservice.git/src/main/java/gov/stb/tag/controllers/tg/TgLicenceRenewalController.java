package gov.stb.tag.controllers.tg;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.application.TgApplicationDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalConditionDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalItemDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalRfaDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalSearchDto;
import gov.stb.tag.dto.tg.licencerenewal.TgLicenceRenewalSubmitDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CpfHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.tg.TgAssignmentRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgLicenceRenewalRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/licence-renewals")
@Transactional
public class TgLicenceRenewalController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicenceRenewalRepository tgLicenceRenewalRepository;
	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgAssignmentRepository tgAssignmentRepository;
	@Autowired
	TouristGuideRepository touristGuideRepository;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	UserHelper userHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	ApplicationHelper appHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	CpfHelper cpfHelper;
	@Autowired
	TgHelper tgHelper;

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgLicenceRenewalItemDto> getRenewalPendingListByFilter(TgLicenceRenewalSearchDto searchDto) throws Exception {
		searchDto.setApplicationType(Codes.ApplicationTypes.TG_APP_RENEWAL);
		return tgLicenceRenewalRepository.getPendingListByFilter(searchDto);
	}

	@RequestMapping(method = RequestMethod.GET, path = { "/view/reinstate" })
	public ResultDto<TgLicenceRenewalItemDto> getReinstatePendingListByFilter(TgLicenceRenewalSearchDto searchDto) throws Exception {
		searchDto.setApplicationType(Codes.ApplicationTypes.TG_APP_REINSTATEMENT);
		return tgLicenceRenewalRepository.getPendingListByFilter(searchDto);
	}

	@RequestMapping(value = "/view/{licenceRenewalId}", method = RequestMethod.GET)
	public TgLicenceRenewalDto getLicenceRenewal(@PathVariable Integer licenceRenewalId) throws Exception {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(licenceRenewalId);
		return new TgLicenceRenewalDto(cache, renewal, null, fileHelper, appHelper, paymentHelper, userHelper, cpfHelper, false);
	}

	@RequestMapping(value = "/view/app/{appId}", method = RequestMethod.GET)
	public TgLicenceRenewalDto getLicenceRenewalByApplication(@PathVariable Integer appId) throws Exception {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getTgLicenceRenewalByApplicationId(appId);
		return new TgLicenceRenewalDto(cache, renewal, null, fileHelper, appHelper, paymentHelper, userHelper, cpfHelper, false);
	}

	@RequestMapping(value = "/view/declaration/{licenceRenewalId}", method = RequestMethod.GET)
	public TgLicenceRenewalSubmitDto getLicenceRenewalDeclaration(@PathVariable Integer licenceRenewalId) throws Exception {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(licenceRenewalId);
		return new TgLicenceRenewalSubmitDto(cache, renewal);
	}

	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TgLicenceRenewalDto getNewLicenceRenewal() {

		Integer userId = getUser().getId();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUserId(userId);
		TgLicenceRenewal rfaLicenceRenewal = tgLicenceRenewalRepository.getRfaRenewal(userId, tg.getLicence().getExpiryDate());
		TgLicenceRenewal licenceRenewal = rfaLicenceRenewal != null ? rfaLicenceRenewal : tgLicenceRenewalRepository.getDraftRenewal(userId);

		if (licenceRenewal == null) {
			String licenceTypeCode = licenceHelper.getLicenceRenewalType(getUser());
			Application renewalApplication = new Application();
			renewalApplication.setTaTgType(Codes.TaTgType.TG);
			if (Codes.LicenceRenewalType.REINSTATE.equals(licenceTypeCode)) {
				renewalApplication.setType(cache.getType(Codes.ApplicationTypes.TG_APP_REINSTATEMENT));
			} else {
				renewalApplication.setType(cache.getType(Codes.ApplicationTypes.TG_APP_RENEWAL));
			}
			renewalApplication.setIsDraft(true);
			renewalApplication.setIsDeleted(false);
			Licence licence = tgLicenceRenewalRepository.getLicence(getUser().getId());
			renewalApplication.setLicence(licence);
			tgLicenceRenewalRepository.save(renewalApplication);

			licenceRenewal = new TgLicenceRenewal();
			licenceRenewal.setApplication(renewalApplication);
			licenceRenewal.setPreviousLicenceStartDate(licence.getStartDate());
			licenceRenewal.setPreviousLicenceExpiryDate(licence.getExpiryDate());
			licenceRenewal.setType(cache.getType(licenceTypeCode));
			tgLicenceRenewalRepository.save(licenceRenewal);
		}

		return new TgLicenceRenewalDto(cache, licenceRenewal, getRequiredMedStartDate(licenceRenewal), getPaymentStatus(licenceRenewal), appHelper, fileHelper, licenceHelper, userHelper, cpfHelper,
				paymentHelper);
	}

	@RequestMapping(value = "/new/condition", method = RequestMethod.GET)
	public TgLicenceRenewalConditionDto getLicenceRenewalConditionsById() {

		return tgHelper.setLicenceRenewalCondition(touristGuideRepository.getTouristGuideByUserId(getUser().getId()));

	}

	@RequestMapping(value = "/new/condition/{licenceRenewalId}", method = RequestMethod.GET)
	public TgLicenceRenewalConditionDto getLicenceRenewalConditionsByUser(@PathVariable Integer licenceRenewalId) {

		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(licenceRenewalId);
		return tgHelper.setLicenceRenewalCondition(renewal.getApplication().getLicence().getTouristGuide());

	}

	@RequestMapping(value = "/new/declaration", method = RequestMethod.GET)
	public TgLicenceRenewalSubmitDto getLicenceRenewalDeclaration() {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getDraftRenewal(getUser().getId());
		return new TgLicenceRenewalSubmitDto(cache, renewal);
	}

	@RequestMapping(value = "/update/{renewalConditions}/{currentTgPhotoId}", method = RequestMethod.POST)
	public void updateApplication(@PathVariable String renewalConditions, @RequestPart(name = "dto") TgLicenceRenewalDto renewalDto, @PathVariable Integer currentTgPhotoId) {

		TouristGuide tg = touristGuideRepository.getTouristGuideByUserId(getUser().getId());
		TgLicenceRenewal rfaRenewal = tgLicenceRenewalRepository.getRfaRenewal(getUser().getId(), tg.getLicence().getExpiryDate());
		TgLicenceRenewal licenceRenewal = rfaRenewal != null ? rfaRenewal : tgLicenceRenewalRepository.getDraftRenewal(getUser().getId());
		Application renewalApplication = licenceRenewal.getApplication();

		switch (renewalConditions) {
		case Codes.renewalConditions.RENEWAL_ASSIGNMENTS:
			licenceRenewal.setHasNoAssignment(renewalDto.getHasNoAssignment());
			tgLicenceRenewalRepository.update(licenceRenewal);
			break;
		case Codes.renewalConditions.RENEWAL_CPF:
			licenceRenewal.setCpfDeclared(renewalDto.getCpfDeclared());
			tgLicenceRenewalRepository.update(licenceRenewal);
			break;
		case Codes.renewalConditions.RENEWAL_NEW_PHOTO:
			fileHelper.updateRenewalFiles(renewalApplication, Arrays.asList(renewalDto.getPhoto()), Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO);
			updateCurrentTGPhoto(currentTgPhotoId);
			break;
		case Codes.renewalConditions.RENEWAL_MEDICAL_REPORT:
			if (renewalDto.getMedDate() != null) {
				LocalDate medDate = renewalDto.getMedDate();
				if (getRequiredMedStartDate(licenceRenewal).minusDays(1).isBefore(medDate) && (LocalDate.now().isAfter(medDate) || LocalDate.now().equals(medDate))) {
					licenceRenewal.setMedicalDate(renewalDto.getMedDate());
					tgLicenceRenewalRepository.update(licenceRenewal);
				} else {
					throw new ValidationException("Incorrect Medical Date");
				}
			}
			if (renewalDto.getMedFiles() != null) {
				fileHelper.updateFiles(renewalApplication, renewalDto.getMedFiles(), Codes.TgDocumentTypes.TG_DOC_MEDICAL_65);
			}
			break;
		case Codes.renewalConditions.RENEWAL_WORK_PASS:
			fileHelper.updateFiles(renewalApplication, renewalDto.getWorkPassFiles(), Codes.TgDocumentTypes.TG_DOC_WORK_PASS);
			break;
		default:
			break;
		}

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public TgApplicationDto saveNewApplication(@RequestPart(name = "dto") TgLicenceRenewalSubmitDto itemDto) {

		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getDraftRenewal(getUser().getId());
		Application renewalApplication = renewal.getApplication();
		WorkflowAction lastAction = renewalApplication.getLastAction();

		if (lastAction == null) {
			if (itemDto.isConvictChecked()) {
				renewal.setOffenceDeclaredDate(LocalDateTime.now());

				renewal.setOffenceDate(itemDto.getOffenceDate());
				renewal.setOffenceType(itemDto.getOffenceType());
				renewal.setEnforcementOutcome(itemDto.getEnforcementOutcome());
			} else {
				renewal.setOffenceDeclaredDate(null);
				renewal.setOffenceDate(null);
				renewal.setOffenceType(null);
				renewal.setEnforcementOutcome(null);
			}
			renewal.setHasConsentEmailAddress(itemDto.isHasConsentEmailAddress());
			renewal.setHasConsentMobileNo(itemDto.isHasConsentMobileNo());

			TouristGuide tg = renewalApplication.getLicence().getTouristGuide();
			String licenceTypeCode = licenceHelper.getLicenceRenewalType(getUser());
			String paymentReqType = "";
			if (Codes.LicenceRenewalType.REINSTATE.equals(licenceTypeCode)) {
				paymentReqType = Codes.TgPaymentRequestTypes.PAYREQ_TG_REINSTATEMENT;
			} else {
				paymentReqType = Codes.TgPaymentRequestTypes.PAYREQ_TG_RENEWAL;
			}
			PaymentRequest pr = paymentHelper.savePaymentRequest(renewalApplication.getApplicationNo(), paymentReqType, tg.getUin(), tg.getName(),
					new BigDecimal(cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_RENEWAL_FEE).getValue()), "TG Licence Renewal Fee", null, true, false, tg.getEmailAddress());
			renewal.setAppFeeBillRefNo(pr.getBillRefNo());

		}

		return new TgApplicationDto(cache, renewalApplication, renewal.getAppFeeBillRefNo(), renewal.getId());

	}

	@RequestMapping(value = "/save/{licenceRenewalId}", method = RequestMethod.GET)
	public TgApplicationDto saveAfterPayment(@PathVariable Integer licenceRenewalId) {

		TgApplicationDto dto = new TgApplicationDto();

		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(licenceRenewalId);
		appHelper.isAppBelongToTG(renewal, getUser(), Codes.ApplicationTypes.TG_APP_RENEWAL);

		var application = renewal.getApplication();
		var lastAction = application.getLastAction();

		Licence licence = application.getLicence();
		TouristGuide tg = licence.getTouristGuide();

		PaymentRequest payReq = paymentHelper.getPaymentRequest(renewal.getAppFeeBillRefNo());
		PaymentTxn paymentTxn = payReq.getLastTxn();

		if (Entities.equals(payReq.getStatus(), Codes.Statuses.PAYREQ_WAIVED) || paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL))) {

			if (lastAction == null || Entities.anyEquals(application.getLicencePrintStatus(), null, Codes.Statuses.PRINT_PENDING_APPROVAL)) {
				application.setIsDraft(false);
				application.setSubmissionDate(LocalDateTime.now());

				String licenceTypeCode = licenceHelper.getLicenceRenewalType(getUser());
				if (Codes.LicenceRenewalType.REINSTATE.equals(licenceTypeCode)) {
					application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_REINSTATEMENT));
				} else {
					application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_RENEWAL));
				}

				approveApplication(application, licence, renewal, tg, false);
			}

			dto = new TgApplicationDto(cache, application, renewal.getAppFeeBillRefNo(), renewal.getId());
			dto.setPaymentSuccess(true);
		} else {
			dto.setPaymentSuccess(false);
		}

		return dto;
	}

	@RequestMapping(value = "/save", method = RequestMethod.GET)
	public TgApplicationDto saveRfaApplication() {

		TouristGuide tg = touristGuideRepository.getTouristGuideByUserId(getUser().getId());
		Licence licence = tg.getLicence();
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRfaRenewal(getUser().getId(), licence.getExpiryDate());
		Application renewalApplication = renewal.getApplication();
		WorkflowAction lastAction = renewalApplication.getLastAction();

		if (lastAction.getStatus().getCode().equals(Codes.Statuses.TG_APP_RFA)) {
			renewalApplication.setIsDraft(false);
			approveApplication(renewalApplication, licence, renewal, tg, true);
		}

		return new TgApplicationDto(cache, renewalApplication, null, renewal.getId());
	}

	@RequestMapping(value = "/load/{id}", method = RequestMethod.GET)
	public TgLicenceRenewalDto getApplication(@PathVariable Integer id) {
		var tlc = tgLicenceRenewalRepository.getRenewal(id);
		var user = getUser();
		appHelper.isAppBelongToTG(tlc, user, Codes.ApplicationTypes.TG_APP_RENEWAL);
		return TgLicenceRenewalDto.buildSubmissionDetails(cache, paymentHelper, tlc);
	}

	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void process(@RequestBody TgLicenceRenewalRfaDto dto, @PathVariable Integer id, @PathVariable String action) {

		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(id);
		Application renewalApplication = renewal.getApplication();
		Licence licence = renewalApplication.getLicence();
		TouristGuide tg = licence.getTouristGuide();

		String alertMsg = null;
		String emailType = null;
		switch (action) {
		case ACTION_APPROVE:
			// appHelper.forward(renewalApplication, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			// emailType = Codes.EmailType.TG_UPON_APPROVAL;
			// alertMsg = Messages.Alerts.TG_APP_APPROVE;
			// approveApplication(renewalApplication, licence, renewal, tg, false);
			appHelper.forward(renewalApplication, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(renewalApplication)) {
				emailType = Codes.EmailType.TG_UPON_APPROVAL;
				alertMsg = Messages.Alerts.TG_APP_APPROVE;

				renewal = tgLicenceRenewalRepository.getRenewal(id);
				Application app = renewal.getApplication();
				licence = app.getLicence();
				tg = licence.getTouristGuide();
				tg.setHasPersonUpdateAccess(true);
				touristGuideRepository.update(tg);

				updateMedisavePaymentStatus(renewal, tg.getUin());
				app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));

				if (LocalDate.now().isBefore(licence.getExpiryDate()) || LocalDate.now().equals(licence.getExpiryDate())) {
					licenceHelper.renewLicence(renewal, true);
				} else {
					licenceHelper.renewLicence(renewal, false);
				}
			}
			break;

		case ACTION_REJECT:
			emailType = Codes.EmailType.TG_UPON_REJECTION;
			alertMsg = Messages.Alerts.APP_REJECT;

			updateMedisavePaymentStatus(renewal, tg.getUin());
			renewalApplication.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
			appHelper.reject(renewalApplication, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:
			String statusCode = dto.getRouteStatus();
			if (StringUtils.equals(statusCode, Codes.Statuses.TG_APP_RFA)) {
				emailType = Codes.EmailType.TG_UPON_RFA;
				alertMsg = Messages.Alerts.APP_RFA;
			}

			renewal.setHasRfaNewPhoto(dto.getHasRfaNewPhoto());
			renewal.setHasRfaMedicalReport(dto.getHasRfaMedicalReport());
			renewal.setHasRfaWorkPass(dto.getHasRfaWorkPass());
			tgLicenceRenewalRepository.flush(); // for renewal updated date to be before action updated date

			renewalApplication.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_APPROVAL));
			appHelper.rfaAfterApproved(renewalApplication, statusCode, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (alertMsg != null) {
			String url = String.format(properties.applicationUrl, "tg/renewal-form");
			emailHelper.emailUponTgAction(renewalApplication, tg.getName(), emailType, url, tg.getEmailAddress());
			alertHelper.createAlert(tg, renewalApplication, alertMsg, Codes.Modules.MOD_TG, renewalApplication.getType(), "tg/renewal-form");
		}

	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(dto.getApplicationId());
		appHelper.saveNote(renewal.getApplication(), dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	public LocalDate getRequiredMedStartDate(TgLicenceRenewal renewal) {
		LocalDate now = LocalDate.now();
		if (renewal.getApplication().getLastAction() != null && Entities.equals(renewal.getApplication().getLastAction().getStatus(), Codes.Statuses.TG_APP_RFA)) {
			LocalDate renewalStartDateFromNow = now.minusMonths(6).plusDays(1);

			Licence licence = renewal.getApplication().getLicence();
			LocalDate licenceExpiryDate = renewal.getPreviousLicenceExpiryDate();
			LocalDate renewalStartDateFromLicenceExpiryDate = licenceExpiryDate.minusMonths(6).plusDays(1);
			return renewalStartDateFromNow;
			// return renewalStartDateFromNow.isAfter(renewalStartDateFromLicenceExpiryDate) ? renewalStartDateFromNow : renewalStartDateFromLicenceExpiryDate;
		} else {
			LocalDate renewalStartDateFromNow = now.minusMonths(6).plusDays(1);

			Licence licence = renewal.getApplication().getLicence();
			LocalDate licenceExpiryDate = licence.getExpiryDate();
			LocalDate renewalStartDateFromLicenceExpiryDate = licenceExpiryDate.minusMonths(6).plusDays(1);
			return renewalStartDateFromNow;
			// return renewalStartDateFromNow.isAfter(renewalStartDateFromLicenceExpiryDate) ? renewalStartDateFromNow : renewalStartDateFromLicenceExpiryDate;
		}
	}

	// check whether payment is made successfully
	private boolean getPaymentStatus(TgLicenceRenewal licenceRenewal) {

		PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(licenceRenewal.getAppFeeBillRefNo());
		if (paymentRequest != null) {
			PaymentTxn paymentTxn = paymentRequest.getLastTxn();

			if (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL))) {
				return true;
			}
		}

		return false;
	}

	private void updateMedisavePaymentStatus(TgLicenceRenewal renewal, String uin) {
		renewal.setMedisavePaymentStatus(cpfHelper.checkMedisavePaymentStatus(uin));
		tgLicenceRenewalRepository.saveOrUpdate(renewal);
	}

	private void approveApplication(Application renewalApplication, Licence licence, TgLicenceRenewal renewal, TouristGuide tg, Boolean isRfaApp) {
		var workflowAction = appHelper.autoApprove(renewalApplication, true);
		renewalApplication.setLastAction(workflowAction);
		Application app = renewal.getApplication();

		if (appHelper.hasFinalApproved(renewalApplication)) {
			tg.setHasPersonUpdateAccess(true);
			touristGuideRepository.update(tg);

			updateMedisavePaymentStatus(renewal, tg.getUin());
			renewalApplication.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));

			if (!isRfaApp) {
				if (LocalDate.now().isBefore(licence.getExpiryDate()) || LocalDate.now().equals(licence.getExpiryDate())) {
					licenceHelper.renewLicence(renewal, true);
				} else {
					licenceHelper.renewLicence(renewal, false);
				}
			}

			// update TG photo on RFA application submission
			if (isRfaApp) {
				Boolean setBackTgPhoto = true;
				for (ApplicationFile appFile : renewalApplication.getApplicationFiles()) {
					if (appFile.getDocumentType().getCode().equals(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO)) {
						tg.setPhoto(appFile.getFile());
						setBackTgPhoto = false;
						break;
					}
				}
				// TG use back current photo and tied back to application
				if (setBackTgPhoto) {
					FileDto dto = new FileDto();
					dto.setDocType(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO);
					File file = fileHelper.getFile(tg.getPhoto().getId());
					fileHelper.saveApplicationFile(app, file, dto);
				}

			}
		}

		String emailType = Codes.EmailType.TG_RENEWAL_SUBMISSION;
		String alertMsg = Messages.Alerts.TG_RENEWAL_SUBMISSION;
		if (alertMsg != null) {
			String url = String.format(properties.applicationUrl, "tg/renewal-form");
			emailHelper.emailUponTgAction(renewalApplication, tg.getName(), emailType, url, tg.getEmailAddress());
			alertHelper.createAlert(tg, renewalApplication, alertMsg, Codes.Modules.MOD_TG, renewalApplication.getType(), "tg/renewal-form");
		}
	}

	@RequestMapping(value = "/update/setCurrentTgPhoto/{licenceRenewalId}/{currentTgPhotoId}", method = RequestMethod.GET)
	public void setCurrentTGPhoto(@PathVariable Integer licenceRenewalId, @PathVariable Integer currentTgPhotoId) {
		TgLicenceRenewal renewal = tgLicenceRenewalRepository.getRenewal(licenceRenewalId);
		Application application = renewal.getApplication();

		if (application.getApplicationFiles() != null) {
			for (ApplicationFile appFile : application.getApplicationFiles()) {
				File file = fileHelper.getFile(appFile.getFile().getId());
				if (Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(appFile.getDocumentType().getCode())) {
					fileHelper.deleteFile(file);
				}
				updateCurrentTGPhoto(currentTgPhotoId);
			}
		}
	}

	public void updateCurrentTGPhoto(Integer currentTgPhotoId) {
		if (currentTgPhotoId != null) {
			File currentTgFile = touristGuideRepository.get(File.class, currentTgPhotoId);
			if (currentTgFile != null) {
				currentTgFile.setIsDeleted(false);
				touristGuideRepository.save(currentTgFile);
			}
		}
	}
}
