package gov.stb.tag.controllers.tg;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licencereplacement.TgLicenceReplacementDto;
import gov.stb.tag.dto.tg.licencereplacement.TgLicenceReplacementItemDto;
import gov.stb.tag.dto.tg.licencereplacement.TgLicenceReplacementSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgLicenceReplacement;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgLicenceReplacementRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/replace")
@Transactional
public class TgLicenceReplacementController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgLicenceReplacementRepository tgLicenceReplacementRepository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	@Autowired
	FileRepository fileRepository;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	LicenceHelper licenceHelper;

	@Autowired
	EmailHelper emailHelper;

	@Autowired
	AlertHelper alertHelper;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	UserHelper userHelper;

	@Autowired
	PaymentHelper paymentHelper;

	/*
	 * Internet
	 */
	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public TgLicenceReplacementDto checkLicence() {

		var itemDto = new TgLicenceReplacementDto();

		var user = getUser();
		var tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		var licence = tg.getLicence();
		if (licence != null && !Codes.Statuses.TG_ACTIVE.equals(licence.getStatus().getCode())) {
			itemDto.setAllowReplace(false);
		}

		var tlr = tgLicenceReplacementRepository.getApplication(user.getLoginId());
		if (tlr != null) {
			// check whether payment is made successfully
			PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(tlr.getAppFeeBillRefNo());
			Boolean paymentSuccess = false;
			Boolean paymentTxnSuccess = false;

			if (paymentRequest != null) {
				PaymentTxn paymentTxn = paymentRequest.getLastTxn();
				paymentTxnSuccess = paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL));

				if (paymentTxnSuccess) {
					paymentSuccess = true;
				}
			}

			// if application submitted or payment success but application submission failed
			if (!tlr.getApplication().getIsDraft() || (tlr.getApplication().getIsDraft() && paymentSuccess == true)) {
				// only for RFA as this application type don't allow user to save draft
				itemDto.setId(tlr.getId());
				var application = tlr.getApplication();
				itemDto.setIsDraft(application.getIsDraft());
				itemDto = itemDto.populateAppStatus(cache, application, itemDto);

				if (paymentRequest != null) {
					if (paymentTxnSuccess) {
						itemDto.setPaymentSuccess(true);
					} else {
						itemDto.setPaymentSuccess(false);
					}

					itemDto = itemDto.buildFromApplication(cache, application, itemDto, appHelper, fileHelper);
				}
			}
		}

		itemDto.setPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_REPLACEMENT_FEE).getValue()));

		return itemDto;
	}

	// save new application
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public TgLicenceReplacementDto saveApplication(@RequestPart(name = "dto") TgLicenceReplacementDto itemDto) {

		var user = getUser();
		var tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());

		Application application = new Application();
		application.setIsDraft(true);
		application.setIsDeleted(false);
		application.setTaTgType(Codes.TaTgType.TG);
		application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_REPLACEMENT));
		application.setLicence(tg.getLicence());
		application.setOfflineSubmission(false);
		tgApplicationRepository.save(application);

		if (CollectionUtils.isNotEmpty(itemDto.getOtherSupportDocs())) {
			for (FileDto doc : itemDto.getOtherSupportDocs()) {
				fileHelper.saveFile(application, doc);
			}
		}

		TgLicenceReplacement tlr = new TgLicenceReplacement();
		tlr.setApplication(application);
		tgLicenceReplacementRepository.save(tlr);

		return TgLicenceReplacementDto.buildSubmissionDetails(cache, paymentHelper, tlr);
	}

	@RequestMapping(value = "/save/payment", method = RequestMethod.POST)
	public TgLicenceReplacementDto replacementPayment(@RequestPart(name = "dto") TgLicenceReplacementDto itemDto) {

		var user = getUser();
		var tlr = tgLicenceReplacementRepository.getApplication(user.getLoginId());
		if (tlr != null) {
			itemDto.setId(tlr.getId());

			var application = tlr.getApplication();
			if (application != null) {
				PaymentRequest pr = paymentHelper.savePaymentRequest(application.getApplicationNo(), Codes.TgPaymentRequestTypes.PAYREQ_TG_APP_REPLACEMENT, user.getLoginId(), user.getName(),
						new BigDecimal(itemDto.getPaymentFee()), "TG Licence Replacement Fee", null, true, false, application.getLicence().getTouristGuide().getEmailAddress());
				tlr.setAppFeeBillRefNo(pr.getBillRefNo());
				itemDto.setBillRefNo(pr.getBillRefNo());
				itemDto.setApplicationNo(application.getApplicationNo());
			}
		}

		return itemDto;
	}

	@RequestMapping(value = "/save/{id}", method = RequestMethod.GET)
	public TgLicenceReplacementDto saveAfterPayment(@PathVariable Integer id) {

		var user = getUser();
		var tlr = tgLicenceReplacementRepository.getApplicationById(id);
		appHelper.isAppBelongToTG(tlr, user, Codes.ApplicationTypes.TG_APP_REPLACEMENT);

		TgLicenceReplacementDto dto = new TgLicenceReplacementDto();
		dto.setId(tlr.getId());

		var application = tlr.getApplication();
		var lastAction = application.getLastAction();

		PaymentRequest payReq = paymentHelper.getPaymentRequest(tlr.getAppFeeBillRefNo());
		PaymentTxn paymentTxn = payReq.getLastTxn();

		if (Entities.equals(payReq.getStatus(), Codes.Statuses.PAYREQ_WAIVED) || paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL))) {

			if (lastAction == null || !(Entities.allEquals(lastAction.getStatus(), Codes.Statuses.TG_APP_PENDING_PO, Codes.Statuses.TG_APP_PENDING_AO, Codes.Statuses.TG_APP_PENDING_HODIV))) {
				application.setIsDraft(false);
				application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_APPROVAL));
				application.setSubmissionDate(LocalDateTime.now());

				appHelper.forward(application, true);

				dto.setApplicationNo(application.getApplicationNo());
				dto.setPaymentSuccess(true);
			}
		} else {
			dto.setPaymentSuccess(false);
		}

		dto.setIsDraft(false);

		return dto;
	}

	// get application no
	@RequestMapping(value = "/new/application-no", method = RequestMethod.GET)
	public TgLicenceReplacementDto getApplicationNo() {

		var itemDto = new TgLicenceReplacementDto();

		var user = getUser();
		var tlr = tgLicenceReplacementRepository.getApplication(user.getLoginId());
		if (tlr != null) {
			itemDto.setId(tlr.getId());

			var application = tlr.getApplication();
			itemDto = itemDto.populateAppStatus(cache, application, itemDto);
		}

		return itemDto;
	}

	// edit application
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public TgLicenceReplacementDto editApplication(@PathVariable Integer id) {

		var tlr = tgLicenceReplacementRepository.getApplicationById(id);
		var user = getUser();
		appHelper.isAppBelongToTG(tlr, user, Codes.ApplicationTypes.TG_APP_REPLACEMENT);

		TgLicenceReplacementDto itemDto = new TgLicenceReplacementDto();
		if (tlr != null) {
			itemDto.setId(tlr.getId());

			var application = tlr.getApplication();
			itemDto.setIsDraft(application.getIsDraft());
			itemDto = itemDto.buildFromApplication(cache, application, itemDto, appHelper, fileHelper);
			itemDto = itemDto.populateAppStatus(cache, application, itemDto);
			itemDto.setPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_REPLACEMENT_FEE).getValue()));

			// check whether payment is made successfully
			PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(tlr.getAppFeeBillRefNo());
			if (paymentRequest != null) {
				PaymentTxn paymentTxn = paymentRequest.getLastTxn();

				if (paymentTxn != null) {
					itemDto.setPaymentSuccess(paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)));
				}

			}
		}

		return itemDto;
	}

	// update application
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public TgLicenceReplacementDto updateApplication(@RequestPart(name = "dto") TgLicenceReplacementDto itemDto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {

		var tlr = tgLicenceReplacementRepository.getApplicationById(itemDto.getId());

		Application application = tlr.getApplication();

		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}

		}

		List<FileDto> newFiles = itemDto.getOtherSupportDocs().stream().filter(u -> u.getPublicFileId() == null).collect(Collectors.toList());
		if (CollectionUtils.isNotEmpty(newFiles)) {
			for (FileDto doc : newFiles) {
				fileHelper.saveFile(application, doc);
			}
		}

		appHelper.forward(application, true);

		return itemDto;
	}

	@RequestMapping(value = "/load/{id}", method = RequestMethod.GET)
	public TgLicenceReplacementDto getApplication(@PathVariable Integer id) {
		var tlr = tgLicenceReplacementRepository.getApplicationById(id);
		var user = getUser();
		appHelper.isAppBelongToTG(tlr, user, Codes.ApplicationTypes.TG_APP_REPLACEMENT);
		return TgLicenceReplacementDto.buildSubmissionDetails(cache, paymentHelper, tlr);
	}

	/*
	 * Intranet
	 */
	// to retrieve all pending applications
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgLicenceReplacementItemDto> getPendingList(TgLicenceReplacementSearchDto searchDto) {
		return tgLicenceReplacementRepository.getPendingList(searchDto);
	}

	// to retrieve submitted application details
	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TgLicenceReplacementDto getLicenceReplacementDetail(@PathVariable Integer id) {
		var tlr = tgLicenceReplacementRepository.getApplicationById(id);
		var itemDto = new TgLicenceReplacementDto();
		itemDto = itemDto.buildFromTgLicenceReplacement(cache, tlr, appHelper, fileHelper, paymentHelper);
		itemDto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(itemDto.getNric()));
		return itemDto;
	}

	// approve, reject and rfa
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void process(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {

		TgLicenceReplacement tlr = tgLicenceReplacementRepository.getApplicationById(id);
		Application application = tlr.getApplication();
		Licence licence = application.getLicence();
		TouristGuide tg = licence.getTouristGuide();

		String url = null;
		String alertMsg = null;
		String emailType = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(application, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(application)) {
				url = String.format(properties.applicationUrl, "dashboard-tg");
				emailType = Codes.EmailType.TG_UPON_APPROVAL;
				alertMsg = Messages.Alerts.TG_APP_APPROVE;

				application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));
			}
			break;

		case ACTION_REJECT:
			url = String.format(properties.applicationUrl, "dashboard-tg");
			emailType = Codes.EmailType.TG_UPON_REJECTION;
			alertMsg = Messages.Alerts.APP_REJECT;

			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
			appHelper.reject(application, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			String status = dto.getRouteStatus();
			if (StringUtils.equals(status, Codes.Statuses.TG_APP_RFA)) {
				url = String.format(properties.applicationUrl, "tg/lost-licence-form/" + tlr.getId());
				emailType = Codes.EmailType.TG_UPON_RFA;
				alertMsg = Messages.Alerts.APP_RFA;
			}

			appHelper.rfa(application, status, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (alertMsg != null) {
			emailHelper.emailUponTgAction(application, tg.getName(), emailType, url, tg.getEmailAddress());
			alertHelper.createAlert(tg, application, alertMsg, Codes.Modules.MOD_TG, application.getType(), "tg/lost-licence-form/" + tlr.getId());
		}
	}

	// to retrieve submitted application details by application id
	@RequestMapping(value = "/view/app/{id}", method = RequestMethod.GET)
	public TgLicenceReplacementDto getLicenceReplacementDetailByApplication(@PathVariable Integer id) {
		var tlr = tgLicenceReplacementRepository.getTgLicenceReplacementByApplicationId(id);
		var itemDto = new TgLicenceReplacementDto();
		itemDto = itemDto.buildFromTgLicenceReplacement(cache, tlr, appHelper, fileHelper, paymentHelper);
		itemDto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(itemDto.getNric()));
		return itemDto;
	}

	// save note
	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		var tgLicenceReplacement = tgLicenceReplacementRepository.getApplicationById(dto.getApplicationId());
		appHelper.saveNote(tgLicenceReplacement.getApplication(), dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}
}
