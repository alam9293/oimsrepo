package gov.stb.tag.controllers.tg;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptApplicationDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptItemDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptRegistrationDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSearchDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotAllocationDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotItemDto;
import gov.stb.tag.dto.tg.mlpt.TgMlptSlotLanguageCountDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgMlptSlot;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.tg.TgMlptRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/tg/mlpt")
@Transactional
public class TgMlptController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgMlptRepository repository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	PaymentHelper paymentHelper;

	@Autowired
	AlertHelper alertHelper;

	@Autowired
	EmailHelper emailHelper;

	@Autowired
	LicenceHelper licenceHelper;

	@Autowired
	FileHelper fileHelper;

	/* MLPT Schedule */

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgMlptItemDto> viewMlpts(TgMlptSearchDto searchDto) {
		return repository.getMlpts(searchDto);
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TgMlptDto viewMlpt(@PathVariable Integer id) {
		return repository.getMlpt(id);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public void saveMlpt(@RequestBody TgMlptDto dto) {
		validateHasExistingMlpt(dto.getRegStartDate(), dto.getMlptEndDate(), null);

		TgMlpt mlpt = new TgMlpt();
		setMlpt(mlpt, dto);
		repository.save(mlpt);
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public void updateMlpt(@RequestBody TgMlptDto dto) {
		validateHasExistingMlpt(dto.getRegStartDate(), dto.getMlptEndDate(), dto.getId());

		TgMlpt mlpt = repository.get(TgMlpt.class, dto.getId());
		setMlpt(mlpt, dto);
		repository.update(mlpt);
	}

	/* MLPT Registration (public) */
	@RequestMapping(value = "/registration/view", method = RequestMethod.GET)
	public TgMlptRegistrationDto viewMlptRegistration() {
		var user = getUser();
		var tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		var registration = repository.getLatestTgMlptRegistrationByUin(user.getLoginId());
		var tgMlpt = registration != null ? registration.getTgMlpt() : null;
		Boolean newLicenceCollected = false;
		Boolean openForRegistration = false;

		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();
		List<TgLicenceMlptRegistration> registrations = new ArrayList<>();

		// check whether licence sent to printing
		if (registration != null) {
			appHelper.isAppBelongToTG(registration, user, Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION);
			registrations = repository.getMlptRegistrationsByTgAndTgMlpt(tg.getId(), tgMlpt.getId());
			TgLicenceMlptRegistration confirmedRegistration = repository.getConfirmedMlptRegistration(tg.getId(), tgMlpt.getId());
			if (confirmedRegistration != null && confirmedRegistration.getApplication() != null) {
				Status licencePrintStatus = confirmedRegistration.getApplication().getLicencePrintStatus();
				newLicenceCollected = licencePrintStatus != null && !Codes.Statuses.PRINT_NOT_REQUIRED.equals(licencePrintStatus.getCode())
						&& Codes.Statuses.PRINT_LICENCE_COLLECTED.equals(licencePrintStatus.getCode());
			}

			// Open for mlpt if within the registration period no matter previous cycle result is Not yet competent/absent/not taking mlpt
			var latestTgMlpt = repository.getNearestOpenMlpt();
			var localDateNow = LocalDate.now();
			if (latestTgMlpt != null && ((localDateNow.isAfter(latestTgMlpt.getRegStartDate()) && localDateNow.isBefore(latestTgMlpt.getRegEndDate()))
					|| localDateNow.isEqual(latestTgMlpt.getRegStartDate()) || localDateNow.isEqual(latestTgMlpt.getRegEndDate()))) {
				openForRegistration = true;
			}
		}

		if (registration != null && !newLicenceCollected && !openForRegistration) {
			for (TgLicenceMlptRegistration reg : registrations) {
				// check whether payment is made successfully
				PaymentRequest req = paymentHelper.getPaymentRequest(reg.getAppFeeBillRefNo());
				PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
				Boolean paymentSuccess = paymentTxn != null ? paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)) : false;

				if (reg.getApplication() != null && reg.getApplication().getIsDraft() == true && paymentSuccess) {
					// return current MLPT schedule and draft application if payment successful
					return TgMlptRegistrationDto.buildTgMlptAndDraftRegistration(cache, tgMlpt, reg, appHelper, paymentHelper);
				} else {
					dto = TgMlptRegistrationDto.buildTgMlptAndDraftRegistration(cache, tgMlpt, null, null, paymentHelper);
				}
			}
		} else if (registration == null || newLicenceCollected || openForRegistration) {
			if (registration != null) {
				for (TgLicenceMlptRegistration reg : registrations) {
					// check whether payment is made successfully
					PaymentRequest req = paymentHelper.getPaymentRequest(reg.getAppFeeBillRefNo());
					PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
					Boolean paymentSuccess = paymentTxn != null ? paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)) : false;
					if (reg.getApplication() != null && reg.getApplication().getIsDraft() == true && paymentSuccess) {
						// return current MLPT schedule and draft application if payment successful
						return TgMlptRegistrationDto.buildTgMlptAndDraftRegistration(cache, tgMlpt, reg, appHelper, paymentHelper);
					}
				}
			}
			tgMlpt = repository.getNearestOpenMlpt();
			dto = TgMlptRegistrationDto.buildTgMlptAndDraftRegistration(cache, tgMlpt, null, null, paymentHelper);
		}

		return dto;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/registration/view/tg-guiding-languages")
	public List<ListableDto> getTgGuidingLanguage() {
		User user = userRepository.getUserByLoginId(getUser().getLoginId());
		TouristGuide tg = user.getTouristGuide();
		return toListableDtos(tg.getGuidingLanguages());
	}

	@RequestMapping(value = "/registration/view/{mlptId}", method = RequestMethod.GET)
	public TgMlptRegistrationDto viewMlptRegistration(@PathVariable Integer mlptId) {
		var user = getUser();
		var tg = user.getTouristGuide();
		var tgMlpt = repository.get(TgMlpt.class, mlptId);

		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();

		if (tgMlpt != null) {
			List<TgLicenceMlptRegistration> registrations = repository.getMlptRegistrationsByTgAndTgMlpt(tg.getId(), tgMlpt.getId());
			if (!registrations.isEmpty()) {
				appHelper.isAppBelongToTG(registrations.get(0), user, Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION);

				for (TgLicenceMlptRegistration reg : registrations) {
					// check whether payment is made successfully
					PaymentRequest req = paymentHelper.getPaymentRequest(reg.getAppFeeBillRefNo());
					PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
					Boolean paymentSuccess = paymentTxn != null ? paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)) : false;

					if (reg.getApplication() != null && reg.getApplication().getIsDraft() == true && paymentSuccess) {
						// return current MLPT schedule and draft application
						return TgMlptRegistrationDto.buildTgMlptAndDraftRegistration(cache, tgMlpt, reg, appHelper, paymentHelper);
					} else {
						dto = TgMlptRegistrationDto.buildTgMlptAndDraftRegistration(cache, tgMlpt, null, null, paymentHelper);
					}
				}
			}

		} else {
			String errorMsg = "MLPT with id=" + mlptId + " does not exist.";
			logger.error("[{}] Unable to viewMlptRegistration() -> e={}", user.getLoginId(), errorMsg);
			throw new ValidationException(errorMsg);
		}

		return dto;
	}

	@RequestMapping(value = "/registration/view/submitted/{mlptId}", method = RequestMethod.GET)
	public TgMlptRegistrationDto viewSubmittedMlptRegistration(@PathVariable Integer mlptId) {
		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();
		var user = getUser();
		var tg = user.getTouristGuide();
		var tgMlpt = repository.getMlpt(mlptId);
		var licence = repository.getLicenceByTgId(tg.getId());

		if (tgMlpt != null) {
			List<TgLicenceMlptRegistration> registrations = repository.getMlptRegistrationsByTgAndTgMlpt(tg.getId(), tgMlpt.getId());

			if (!registrations.isEmpty()) {
				appHelper.isAppBelongToTG(registrations.get(0), user, Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION);
				TgMlpt nextTgMlpt = repository.getNearestOpenMlpt();
				TgLicenceMlptRegistration confirmedRegistration = repository.getConfirmedMlptRegistration(tg.getId(), tgMlpt.getId());
				dto = TgMlptRegistrationDto.buildSubmittedTgMlptRegistration(cache, registrations, confirmedRegistration, nextTgMlpt, appHelper, paymentHelper, licence.getStatus().getCode());
			} else {

				// if registrations is empty, system need to check whether the MLPT registration fee is waived
				dto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION));
				// Do not wave the bill if delicensed TG for MLPT
				if (Codes.Statuses.TG_INACTIVE.equals(licence.getStatus().getCode())) {
					dto.setIsWaived(false);
				}
			}
		}

		return dto;
	}

	@RequestMapping(value = "/registration/view/details/{mlptId}", method = RequestMethod.GET)
	public List<TgMlptSlotItemDto> viewMlptRegistrationDetails(@PathVariable Integer mlptId) {
		List<TgMlptSlotItemDto> resultDto = new ArrayList<>();
		var user = getUser();
		var tg = user.getTouristGuide();
		var tgMlpt = repository.getMlpt(mlptId);

		if (tgMlpt != null) {
			List<TgLicenceMlptRegistration> registrations = repository.getMlptRegistrationsByTgAndTgMlpt(tg.getId(), tgMlpt.getId());
			if (!registrations.isEmpty()) {
				appHelper.isAppBelongToTG(registrations.get(0), user, Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION);
				for (TgLicenceMlptRegistration registration : registrations) {
					// check whether payment is made successfully
					PaymentRequest req = paymentHelper.getPaymentRequest(registration.getAppFeeBillRefNo());
					PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
					Boolean paymentSuccess = paymentTxn != null ? paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)) : false;

					if (!registration.getTgMlptSlots().isEmpty() && paymentSuccess) {
						for (TgMlptSlot slot : registration.getTgMlptSlots()) {
							TgMlptSlotItemDto dto = TgMlptSlotDto.buildTgMlptDetails(cache, slot);
							resultDto.add(dto);
						}
					}
				}
			}
		}

		return resultDto;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/registration/view/reinstatement")
	public List<TgMlptSlotItemDto> viewMlptAssessment() {
		User user = userRepository.getUserByLoginId(getUser().getLoginId());
		Licence licence = user.getTouristGuide().getLicence();
		return repository.getCurrentMlptSlotForReinstatement(licence.getId(), licence.getExpiryDate().plusYears(3).atStartOfDay(), licence.getExpiryDate().plusYears(6).atStartOfDay());
	}

	// save new application (no approval workflow)
	@RequestMapping(value = "/registration/save/mlpt/{mlptId}", method = RequestMethod.POST)
	public TgMlptApplicationDto saveMlptRegistrationBeforePayment(@RequestBody TgMlptApplicationDto dto, @PathVariable Integer mlptId) {
		User user = getUser();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());

		TgMlpt tgMlpt = repository.get(TgMlpt.class, mlptId);
		if (Objects.isNull(tgMlpt)) {
			String errorMsg = "MLPT with id=" + mlptId + " does not exist.";
			logger.error("[{}] Unable to saveMlptRegistrationBeforePayment() -> e={}", user.getLoginId(), errorMsg);
			throw new ValidationException(errorMsg);
		}

		// check new or draft application
		logger.info("[{}] saveMlptRegistrationBeforePayment() - Attempt to get draft application", user.getLoginId());
		TgLicenceMlptRegistration registration = dto.getRegistrationId() != null ? repository.getTgMlptRegistrationById(dto.getRegistrationId()) : new TgLicenceMlptRegistration();
		Application application = registration != null && registration.getApplication() != null ? registration.getApplication() : null;

		// create application
		if (application == null) {
			logger.info("[{}] saveMlptRegistrationBeforePayment() - Saving new application for appType={}, licenceId={}", user.getLoginId(), Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION,
					tg.getLicence().getId());
			application = appHelper.saveNewApplication(Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION, tg.getLicence().getId(), false, true);
			registration.setTgMlpt(tgMlpt);
			registration.setApplication(application);
			String licenceTypeCode = licenceHelper.getLicenceRenewalStatus(user);
			registration.setIsForReinstatement(Codes.LicenceRenewalStatus.REINSTATE_AF_3YR.equals(licenceTypeCode));
			repository.save(registration);

			// create slot
			logger.info("[{}] saveMlptRegistrationBeforePayment() - Saving new slot(s) for tgLicenceMlptRegistrationId={}", user.getLoginId(), registration.getId());
			Set<TgMlptSlot> slots = new HashSet<>();
			if (dto.getTestLanguages() != null) {
				for (ListableDto language : dto.getTestLanguages()) {
					TgMlptSlot slot = new TgMlptSlot();
					slot.setGuidingLanguage(cache.getType(language.getKey().toString()));
					slot.setTgLicenceMlptRegistration(registration);
					repository.save(slot);
					slots.add(slot);
				}
				registration.setTgMlptSlots(slots);
			}
		} else {
			// update slot
			logger.info("[{}] saveMlptRegistrationBeforePayment() - Replace slot(s) with new test languages for tgLicenceMlptRegistrationId={}", user.getLoginId(), registration.getId());
			if (dto.getTestLanguages() != null) {
				repository.delete(registration.getTgMlptSlots());
				Set<TgMlptSlot> slots = new HashSet<>();
				for (ListableDto language : dto.getTestLanguages()) {
					TgMlptSlot newSlot = new TgMlptSlot();
					newSlot.setGuidingLanguage(cache.getType(language.getKey().toString()));
					newSlot.setTgLicenceMlptRegistration(registration);
					repository.save(newSlot);
					slots.add(newSlot);
				}
				registration.setTgMlptSlots(slots);
			}
		}
		repository.update(registration);
		return TgMlptApplicationDto.buildFromTgMlptApplication(cache, registration, appHelper, paymentHelper, tg.getLicence().getStatus().getCode());

	}

	// save payment
	@RequestMapping(value = "/registration/save/payment/{registrationId}", method = RequestMethod.POST)
	public TgMlptApplicationDto saveMlptPayment(@RequestBody TgMlptRegistrationDto dto, @PathVariable Integer registrationId) {

		var user = getUser();
		logger.info("[{}] saveMlptPayment() - Saving payment request for registrationId={}", user.getLoginId(), registrationId);
		TgLicenceMlptRegistration registration = repository.getTgMlptRegistrationById(registrationId);

		if (registration != null) {
			var application = registration.getApplication();
			if (application != null) {
				TouristGuide tg = application.getLicence().getTouristGuide();
				PaymentRequest pr = paymentHelper.savePaymentRequest(application.getApplicationNo(), Codes.TgPaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION, tg.getUin(), tg.getName(),
						new BigDecimal(dto.getPaymentFee()), "TG MLPT Registration Fee", null, true, false, application.getLicence().getTouristGuide().getEmailAddress());
				registration.setAppFeeBillRefNo(pr.getBillRefNo());
				application.setSubmissionDate(LocalDateTime.now());
				repository.update(registration);
				repository.update(application);
			}
		} else {
			String errorMsg = "MLPT Registration with id=" + registrationId + " does not exist.";
			logger.error("[{}] Unable to saveMlptPayment() -> e={}", user.getLoginId(), errorMsg);
			throw new ValidationException(errorMsg);
		}

		return TgMlptApplicationDto.buildFromTgMlptApplication(cache, registration, appHelper, paymentHelper, null);
	}

	// save card payment
	@RequestMapping(value = "/registration/save/card-payment/{tgMlptId}", method = RequestMethod.POST)
	public TgMlptRegistrationDto saveMlptCardPayment(@RequestBody TgMlptRegistrationDto dto, @PathVariable Integer tgMlptId) {

		var tg = touristGuideRepository.getTouristGuideByUserId(getUser().getId());
		TgMlpt tgMlpt = repository.get(TgMlpt.class, tgMlptId);
		List<TgLicenceMlptRegistration> registrations = repository.getMlptRegistrationsByTgAndTgMlpt(tg.getId(), tgMlptId);
		if (tgMlpt != null) {
			String licenceNo = tg.getLicence().getLicenceNo();
			String regStartDate = DateUtil.format(tgMlpt.getRegStartDate(), DateUtil.REPORT_DATE_FORMAT_PATTERN);
			String refNo = "TG_MLPT_".concat(licenceNo).concat("_").concat(regStartDate);

			logger.info("saveMlptCardPayment(), attempting to save payment request for refNo = {}", refNo);
			PaymentRequest pr = paymentHelper.savePaymentRequest(refNo, Codes.TgPaymentRequestTypes.PAYREQ_TG_MLPT, tg.getUin(), tg.getName(), new BigDecimal(dto.getCardPaymentFee()),
					"TG MLPT Badge Amendment Fee", null, true, false, tg.getEmailAddress());

			// save print fee bill ref no
			for (TgLicenceMlptRegistration registration : registrations) {
				registration.setPrintFeeBillRefNo(pr.getBillRefNo());
				repository.update(registration);
			}

			logger.info("saveMlptCardPayment(), paymentRequest.id={} is saved to printFeeBillRefNo={}", pr.getId(), pr.getBillRefNo());
		}

		return TgMlptRegistrationDto.buildTgMlptCardPayment(cache, tgMlpt, registrations, paymentHelper);
	}

	// load registration details after payment
	@RequestMapping(value = "/registration/load/{registrationId}", method = RequestMethod.GET)
	public TgMlptApplicationDto getRegistration(@PathVariable Integer registrationId) {
		TgLicenceMlptRegistration registration = repository.getTgMlptRegistrationById(registrationId);
		var user = getUser();
		appHelper.isAppBelongToTG(registration, user, Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION);

		var dto = new TgMlptApplicationDto();
		dto = dto.buildFromTgMlptApplication(cache, registration, appHelper, paymentHelper, null);
		dto.setMlptId(registration.getTgMlpt().getId());

		// Payment
		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(registration.getAppFeeBillRefNo()), false));
		return dto;
	}

	// load mlpt details after card payment
	@RequestMapping(value = "/registration/load/mlpt/{tgMlptId}", method = RequestMethod.GET)
	public TgMlptApplicationDto getMlptDetails(@PathVariable Integer tgMlptId) {
		var user = getUser();
		var tg = user.getTouristGuide();
		var dto = new TgMlptRegistrationDto();

		TgMlpt tgMlpt = repository.get(TgMlpt.class, tgMlptId);
		List<TgLicenceMlptRegistration> registrations = repository.getMlptRegistrationsByTgAndTgMlpt(tg.getId(), tgMlpt.getId());
		TgLicenceMlptRegistration firstRegistration = registrations.get(0);
		appHelper.isAppBelongToTG(firstRegistration, user, Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION);

		if (firstRegistration != null && firstRegistration.getApplication() != null) {
			dto.setLicencePrintStatus(firstRegistration.getApplication().getLicencePrintStatus() != null ? firstRegistration.getApplication().getLicencePrintStatus().getCode() : "");
		}

		// Payment
		dto.setCardFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(firstRegistration.getPrintFeeBillRefNo()), false));
		return dto;
	}

	// update application after payment made
	@RequestMapping(value = "/registration/save/{registrationId}", method = RequestMethod.GET)
	public TgMlptApplicationDto saveAfterPayment(@PathVariable Integer registrationId) {

		var user = getUser();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		TgLicenceMlptRegistration registration = repository.getTgMlptRegistrationById(registrationId);
		appHelper.isAppBelongToTG(registration, user, Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION);

		TgMlptApplicationDto dto = new TgMlptApplicationDto();
		dto.setRegistrationId(registration.getId());

		var application = registration.getApplication();

		PaymentRequest payReq = paymentHelper.getPaymentRequest(registration.getAppFeeBillRefNo());
		PaymentTxn paymentTxn = payReq.getLastTxn();

		if ((payReq != null && Entities.equals(payReq.getStatus(), Codes.Statuses.PAYREQ_WAIVED))
				|| (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
			application.setIsDraft(false);
			application.setSubmissionDate(LocalDateTime.now());
			repository.update(application);

			if (application.getLastAction() == null) {
				appHelper.forward(application, true);
			}

			dto.setApplicationNo(application.getApplicationNo());
			dto.setPaymentSuccess(true);

		} else {
			dto.setPaymentSuccess(false);
		}

		dto.setIsDraft(application.getIsDraft());

		// add email
		String userEmail = null;
		if (!StringUtils.isBlank(tg.getEmailAddress())) {
			userEmail = tg.getEmailAddress();
			emailHelper.emailUponTgMlptRegistration(registration, tg.getName(), Codes.EmailType.TG_APPLY_MLPT, null, userEmail);
		}

		return dto;
	}

	// update application after card payment made
	@RequestMapping(value = "/registration/save/licence-print/{tgMlptId}", method = RequestMethod.GET)
	public TgMlptRegistrationDto saveAfterCardPayment(@PathVariable Integer tgMlptId) {
		var user = getUser();

		TouristGuide touristGuide = touristGuideRepository.getTouristGuideByUserId(user.getId());
		TgMlpt tgMlpt = repository.get(TgMlpt.class, tgMlptId);
		List<TgLicenceMlptRegistration> registrations = repository.getMlptRegistrationsByTgAndTgMlpt(touristGuide.getId(), tgMlpt.getId());
		TgLicenceMlptRegistration printPendPayRegistration = repository.getPrintPendPayMlptRegistration(touristGuide.getId(), tgMlpt.getId());

		if (printPendPayRegistration != null) {
			PaymentRequest payReq = paymentHelper.getPaymentRequest(printPendPayRegistration.getAppFeeBillRefNo());
			PaymentTxn paymentTxn = payReq.getLastTxn();

			if (payReq != null && (Entities.equals(payReq.getStatus(), Codes.Statuses.PAYREQ_WAIVED))
					|| (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
				printPendPayRegistration.getApplication().setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));
				for (TgLicenceMlptRegistration registration : registrations) {
					for (TgMlptSlot slot : registration.getTgMlptSlots()) {
						if (slot.getResultStatus() != null && Codes.Statuses.TG_MLPT_COMPETENT.equals(slot.getResultStatus().getCode())) {
							logger.info("saveAfterCardPayment(), adding guiding language={} to tg.licenceNo={}.", slot.getGuidingLanguage().getLabel(), touristGuide.getLicence().getLicenceNo());
							touristGuide.getGuidingLanguages().add(slot.getGuidingLanguage());
						}
					}
				}

				repository.update(touristGuide);
				logger.info("saveAfterCardPayment(), updated licence print status to = {} and added guiding languages = {} to tg.licenceNo = {}.", Codes.Statuses.PRINT_PENDING_PRINTING,
						touristGuide.getGuidingLanguagesWithComma(cache), touristGuide.getLicence().getLicenceNo());

			}
		}

		return TgMlptRegistrationDto.buildConfirmedRegistration(cache, printPendPayRegistration, appHelper, paymentHelper);
	}

	/* MLPT Slot */

	@RequestMapping(value = "/slots/view/{id}", method = RequestMethod.GET)
	public List<TgMlptSlotAllocationDto> viewMlptSlots(@PathVariable Integer id) {

		// create List<TgMlptSlotAllocationDto> where each TgMlptSlotAllocationDto is one day
		TgMlpt mlpt = repository.get(TgMlpt.class, id);

		// Add empty unassigned TgMlptSlotAllocationDto with no date
		List<TgMlptSlotAllocationDto> allocations = new ArrayList<TgMlptSlotAllocationDto>();
		TgMlptSlotAllocationDto unassigned = new TgMlptSlotAllocationDto();
		allocations.add(unassigned);

		// Add one TgMlptSlotAllocationDto for each mlpt date
		List<LocalDate> availDates = mlpt.getMlptStartDate().datesUntil(mlpt.getMlptEndDate()).collect(Collectors.toList());
		for (LocalDate availDate : availDates) {
			allocations.add(new TgMlptSlotAllocationDto(availDate));
		}
		allocations.add(new TgMlptSlotAllocationDto(mlpt.getMlptEndDate()));

		// Assign slots to TgMlptSlotAllocationDto
		List<TgMlptSlotItemDto> slots = repository.getMlptSlots(id);
		Integer allocationNumber = 1; // track which allocation it is on
		TgMlptSlotAllocationDto currentAllocation = allocations.get(allocationNumber);

		LocalTime startingTime = LocalTime.of(8, 0);
		for (TgMlptSlotItemDto slot : slots) {
			if (slot.getResultFileId() != null) {
				slot.setResultFile(FileDto.buildFromFile(fileHelper.getFile(slot.getResultFileId())));
			}

			if (slot.getStartTime() == null) {
				unassigned.getSlots().add(slot);
			} else {
				LocalDate slotDate = slot.getStartTime().toLocalDate();
				LocalTime slotTime = slot.getStartTime().toLocalTime();
				LocalTime endTime = LocalTime.of(19, 0);

				// Find the allocation with the same start date
				while (!currentAllocation.getStartDate().equals(slotDate)) {
					currentAllocation = allocations.get(++allocationNumber);
					startingTime = LocalTime.of(8, 0); // reset startingTime
				}

				// Allocate empty slot if !startTime.equals(endTime)
				while (!startingTime.equals(endTime)) {
					if (slotTime.equals(startingTime)) {
						currentAllocation.getSlots().add(slot);
						startingTime = startingTime.plusMinutes(30);
						break;
					} else {
						currentAllocation.getSlots().add(new TgMlptSlotItemDto(LocalDateTime.of(currentAllocation.getStartDate(), startingTime)));
						startingTime = startingTime.plusMinutes(30);
					}
				}

			}
		}

		return allocations;
	}

	@RequestMapping(value = "/slots/view/details/{slotId}", method = RequestMethod.GET)
	public TgMlptSlotDto viewMlptSlot(@PathVariable Integer slotId) {
		return repository.getMlptSlot(slotId);
	}

	@RequestMapping(value = "/slots/view/allocate/{id}", method = RequestMethod.GET)
	public List<TgMlptSlotAllocationDto> allocateMlptSlot(@PathVariable Integer id) {

		// create List<TgMlptSlotAllocationDto> where each TgMlptSlotAllocationDto is one day
		TgMlpt mlpt = repository.get(TgMlpt.class, id);

		// Add empty unassigned TgMlptSlotAllocationDto with no date
		List<TgMlptSlotAllocationDto> allocations = new ArrayList<TgMlptSlotAllocationDto>();
		TgMlptSlotAllocationDto unassigned = new TgMlptSlotAllocationDto();
		allocations.add(unassigned);

		// Add one TgMlptSlotAllocationDto for each mlpt date
		List<LocalDate> availDates = mlpt.getMlptStartDate().datesUntil(mlpt.getMlptEndDate()).collect(Collectors.toList());
		for (LocalDate availDate : availDates) {
			allocations.add(new TgMlptSlotAllocationDto(availDate));
		}
		allocations.add(new TgMlptSlotAllocationDto(mlpt.getMlptEndDate()));

		// Sort slots
		List<TgMlptSlotItemDto> rawSlots = repository.getMlptSlots(id, "guidingLanguage.code");
		List<TgMlptSlotLanguageCountDto> languageGroups = repository.getLanguageGroupByMlptSlot(id);

		List<TgMlptSlotItemDto> slots = new ArrayList<TgMlptSlotItemDto>();
		for (TgMlptSlotLanguageCountDto languageGroup : languageGroups) {
			for (TgMlptSlotItemDto slot : rawSlots) {
				if (slot.getGuidingLanguageCode().equals(languageGroup.getGuidingLanguageCode())) {
					slots.add(slot);
				}
			}
		}

		// Assign slots to TgMlptSlotAllocationDto
		Integer allocationNumber = 1; // track which allocation it is on
		Integer timeSlotCounter = 0;
		TgMlptSlotAllocationDto currentAllocation = allocations.get(allocationNumber);

		for (TgMlptSlotItemDto slot : slots) {
			// If previous allocate is full, start new allocation
			if (timeSlotCounter == 14) {
				// If last allocation is full, put in unassigned
				if (allocationNumber.equals(allocations.size() - 1)) {
					currentAllocation = allocations.get(0);
				} else {
					currentAllocation = allocations.get(++allocationNumber);
					timeSlotCounter = 0;
				}
			}

			// Add break
			if (timeSlotCounter == 0 || timeSlotCounter == 6) {
				currentAllocation.getSlots().add(new TgMlptSlotItemDto());
				currentAllocation.getSlots().add(new TgMlptSlotItemDto());
				currentAllocation.getSlots().add(new TgMlptSlotItemDto());
			}

			// Add slot
			currentAllocation.getSlots().add(slot);
			timeSlotCounter++;
		}

		return allocations;
	}

	@RequestMapping(value = "/slots/save/draft/{id}", method = RequestMethod.POST)
	public void saveMlptSlots(@RequestBody List<TgMlptSlotAllocationDto> allocations, @PathVariable Integer id) {
		saveMlptSlots(allocations, id, Codes.Statuses.TG_MLPT_ALLOC_DRAFT);
	}

	@RequestMapping(value = "/slots/save/submit/{id}/{sendSceduleToTg}", method = RequestMethod.POST)
	public void submitMlptSlots(@RequestBody List<TgMlptSlotAllocationDto> allocations, @PathVariable Integer id, @PathVariable Boolean sendSceduleToTg) {
		TgMlpt mlpt = repository.get(TgMlpt.class, id);

		if (mlpt.getRegEndDate().plusDays(1).isAfter(LocalDate.now())) {
			throw new ValidationException("Cannot send Schedule before Registration End Date");
		}

		saveMlptSlots(allocations, id, Codes.Statuses.TG_MLPT_ALLOC_PUB);

		if (sendSceduleToTg) {
			for (TgLicenceMlptRegistration registration : mlpt.getTgLicenceMlptRegistrations()) {
				if (!registration.getApplication().getIsDraft() && !registration.getApplication().isDeleted()) {
					sendAllocationNotification(registration, id, Messages.Alerts.TG_MLPT_SLOT_ALLOCATED);
				}
			}
		}
	}

	@RequestMapping(value = "/slots/save/swap/{id}", method = RequestMethod.POST)
	public void swapMlptSlots(@RequestBody List<TgMlptSlotItemDto> swapSlots, @PathVariable Integer id) {
		TgMlpt mlpt = repository.get(TgMlpt.class, id);

		if (LocalDate.now().isAfter(mlpt.getMlptStartDate())) {
			throw new ValidationException("Cannot Swap Slot after MLPT Start Date");
		}

		TgMlptSlotItemDto slotOneDto = swapSlots.get(0);
		TgMlptSlotItemDto slotTwoDto = swapSlots.get(1);

		TgMlptSlot slotOne = updateAndGetMlptSlot(slotOneDto.getId(), slotTwoDto.getStartTime());
		TgMlptSlot slotTwo = updateAndGetMlptSlot(slotTwoDto.getId(), slotOneDto.getStartTime());

		TgLicenceMlptRegistration registrationOne = null;
		if (slotOne != null) {
			registrationOne = slotOne.getTgLicenceMlptRegistration();
			sendAllocationNotification(registrationOne, id, Messages.Alerts.TG_MLPT_SLOT_SWAP);
		}
		if (slotTwo != null) {
			TgLicenceMlptRegistration registrationTwo = slotTwo.getTgLicenceMlptRegistration();
			if (registrationOne != null && !registrationOne.getId().equals(registrationTwo.getId())) {
				sendAllocationNotification(registrationTwo, id, Messages.Alerts.TG_MLPT_SLOT_SWAP);
			}
		}

	}

	@RequestMapping(value = "/slots/save/update/{id}", method = RequestMethod.POST)
	public void updateMlptSlots(@RequestBody List<TgMlptSlotAllocationDto> allocations, @PathVariable Integer id) {

		for (TgMlptSlotAllocationDto allocation : allocations) {
			updateMlptSlots(allocation);
		}
	}

	@RequestMapping(value = "/slots/submit/{id}", method = RequestMethod.POST)
	public void resultMlptSlots(@RequestBody TgMlptSlotAllocationDto allocation, @PathVariable Integer id) {
		TgMlpt mlpt = repository.get(TgMlpt.class, id);

		if (mlpt.getMlptStartDate().isAfter(LocalDate.now())) {
			throw new ValidationException("Cannot Send Email to TG before MLPT Start Date");
		}

		updateMlptSlots(allocation);

		for (TgMlptSlotItemDto slot : allocation.getSlots()) {
			List<TgMlptSlotItemDto> relatedSlots = getRelatedSlots(slot.getLicenceNo(), id);

			if (hasSubmittedResult(relatedSlots) && !hasEmailSent(relatedSlots)) {
				setEmailSent(relatedSlots);

				TgMlptSlot tgMlptSlot = repository.get(TgMlptSlot.class, slot.getId());
				TgLicenceMlptRegistration registration = tgMlptSlot.getTgLicenceMlptRegistration();
				Application app = registration.getApplication();
				TouristGuide tg = app.getLicence().getTouristGuide();
				String url = String.format(properties.applicationUrl, "tg/apply-mlpt/" + id);
				alertHelper.createAlert(tg, app, Messages.Alerts.TG_MLPT_SLOT_RESULT, Codes.Modules.MOD_TG, app.getType(), "tg/apply-mlpt/" + id);
				if (hasResultPass(relatedSlots) && !slot.getIsForReinstatement()) {
					app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PAYMENT));
					repository.update(app);
				}
				emailHelper.emailUponTgMlptRegistration(registration, tg.getName(), Codes.EmailType.TG_MLPT_SLOT_RESULT, url, tg.getEmailAddress());

				tgMlptSlot.setResultSentDate(LocalDateTime.now());
				repository.update(tgMlptSlot);
			}
		}

	}

	/* Private Method */

	private void validateHasExistingMlpt(LocalDate regStartDate, LocalDate mlptEndDate, Integer idToExclude) {
		if (repository.hasExistingMlptDates(regStartDate, mlptEndDate, idToExclude)) {
			throw new ValidationException("Dates already exist");
		}
	}

	private void setMlpt(TgMlpt mlpt, TgMlptDto dto) {
		mlpt.setName(dto.getName());
		mlpt.setRegStartDate(dto.getRegStartDate());
		mlpt.setRegEndDate(dto.getRegEndDate());
		mlpt.setMlptStartDate(dto.getMlptStartDate());
		mlpt.setMlptEndDate(dto.getMlptEndDate());
		mlpt.setRemarks(dto.getRemarks());
		if (mlpt.getAllocationStatus() == null) {
			mlpt.setAllocationStatus(cache.getStatus(Codes.Statuses.TG_MLPT_ALLOC_DRAFT));
		}
	}

	private void updateMlptSlot(Integer id, LocalDateTime startTime) {
		if (id != null) {
			TgMlptSlot slot = repository.load(TgMlptSlot.class, id);
			slot.setStartTime(startTime);
			repository.update(slot);
		}
	}

	private TgMlptSlot updateAndGetMlptSlot(Integer id, LocalDateTime startTime) {
		TgMlptSlot slot = null;

		if (id != null) {
			slot = repository.get(TgMlptSlot.class, id);
			slot.setStartTime(startTime);
			repository.update(slot);
		}

		return slot;
	}

	private void saveMlptSlots(List<TgMlptSlotAllocationDto> allocations, Integer id, String allocationStatus) {
		// set allocation status
		TgMlpt mlpt = repository.get(TgMlpt.class, id);
		mlpt.setAllocationStatus(cache.getStatus(allocationStatus));
		repository.save(mlpt);

		// Set unassigned
		for (TgMlptSlotItemDto slotDto : allocations.get(0).getSlots()) {
			updateMlptSlot(slotDto.getId(), null);
		}
		// Set allocation
		for (int i = 1; i < allocations.size(); i++) {
			TgMlptSlotAllocationDto allocationDto = allocations.get(i);
			LocalTime startingTime = LocalTime.of(8, 0);

			for (TgMlptSlotItemDto slotDto : allocationDto.getSlots()) {
				updateMlptSlot(slotDto.getId(), LocalDateTime.of(allocationDto.getStartDate(), startingTime));
				startingTime = startingTime.plusMinutes(30);
			}
		}
	}

	private void updateMlptSlots(TgMlptSlotAllocationDto allocation) {
		LocalTime startingTime = LocalTime.of(8, 0);

		for (TgMlptSlotItemDto slotDto : allocation.getSlots()) {
			if (slotDto.getId() != null) {
				TgMlptSlot slot = repository.load(TgMlptSlot.class, slotDto.getId());
				slot.setStartTime(LocalDateTime.of(allocation.getStartDate(), startingTime));
				slot.setChiefAssessor(slotDto.getChiefAssessor());
				slot.setAssessor(slotDto.getAssessor());
				slot.setResultStatus(cache.getStatus(slotDto.getResultStatusCode()));
				if (slotDto.getResultFile().getId() != null) {
					slot.setResultFile(repository.load(File.class, slotDto.getResultFile().getId()));
				}
				repository.saveOrUpdate(slot);
			}
			startingTime = startingTime.plusMinutes(30);
		}
	}

	private void sendAllocationNotification(TgLicenceMlptRegistration registration, Integer mlptId, String alertMessage) {
		Application app = registration.getApplication();
		TouristGuide tg = app.getLicence().getTouristGuide();
		String url = String.format(properties.applicationUrl, "tg/apply-mlpt/" + mlptId);
		emailHelper.emailUponTgMlptRegistration(registration, tg.getName(), Codes.EmailType.TG_MLPT_SLOT_ALLOCATED, url, tg.getEmailAddress());
		alertHelper.createAlert(tg, app, alertMessage, Codes.Modules.MOD_TG, app.getType(), "tg/apply-mlpt/" + mlptId);
	}

	private List<TgMlptSlotItemDto> getRelatedSlots(String licenceNo, Integer mlptId) {
		List<TgMlptSlotItemDto> newSlots = new ArrayList<TgMlptSlotItemDto>();
		List<TgMlptSlotItemDto> slots = repository.getMlptSlots(mlptId);

		for (TgMlptSlotItemDto slot : slots) {
			if (slot.getLicenceNo().equals(licenceNo)) {
				newSlots.add(slot);
			}
		}

		return newSlots;
	}

	private Boolean hasSubmittedResult(List<TgMlptSlotItemDto> slots) {
		Boolean hasSubmittedResult = true;

		for (TgMlptSlotItemDto slot : slots) {
			if (slot.getResultStatusCode() == null) {
				hasSubmittedResult = false;
			}
		}

		return hasSubmittedResult;
	}

	private Boolean hasEmailSent(List<TgMlptSlotItemDto> slots) {
		Boolean hasEmailSent = true;

		for (TgMlptSlotItemDto slot : slots) {
			if (slot.getResultSentDate() == null) {
				hasEmailSent = false;
			}
		}

		return hasEmailSent;
	}

	private Boolean hasResultPass(List<TgMlptSlotItemDto> slots) {
		Boolean hasResultPass = false;

		for (TgMlptSlotItemDto slot : slots) {
			if (Codes.Statuses.TG_MLPT_COMPETENT.equals(slot.getResultStatusCode())) {
				hasResultPass = true;
			}
		}

		return hasResultPass;
	}

	private void setEmailSent(List<TgMlptSlotItemDto> slots) {

		for (TgMlptSlotItemDto slot : slots) {
			TgMlptSlot tgMlptSlot = repository.load(TgMlptSlot.class, slot.getId());
			tgMlptSlot.setResultSentDate(LocalDateTime.now());
			repository.update(tgMlptSlot);
		}

	}

}
