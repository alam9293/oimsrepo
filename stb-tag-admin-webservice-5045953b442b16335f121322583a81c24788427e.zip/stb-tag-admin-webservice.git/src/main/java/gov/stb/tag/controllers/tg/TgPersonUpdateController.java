package gov.stb.tag.controllers.tg;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Objects;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.particularUpdate.ParticularUpdateCompareDetails;
import gov.stb.tag.dto.tg.particularUpdate.ParticularUpdateDto;
import gov.stb.tag.dto.tg.particularUpdate.ParticularUpdateItemDto;
import gov.stb.tag.dto.tg.particularUpdate.ParticularUpdateSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgPersonUpdate;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.repository.tg.TgApplicationRepository;
import gov.stb.tag.repository.tg.TgCandidateRepository;
import gov.stb.tag.repository.tg.TgPersonUpdateRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;

@RestController
@RequestMapping(path = "/api/v1/tg/particulars")
@Transactional
public class TgPersonUpdateController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgPersonUpdateRepository tgPersonUpdateRepository;

	@Autowired
	TgCandidateRepository tgCandidateRepository;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	TgApplicationRepository tgApplicationRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	FileRepository fileRepository;

	@Autowired
	ApplicationHelper appHelper;

	@Autowired
	LicenceHelper licenceHelper;

	@Autowired
	EmailHelper emailHelper;

	@Autowired
	AlertHelper alertHelper;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	UserHelper userHelper;

	@Autowired
	PaymentHelper paymentHelper;

	/*
	 * Internet
	 */
	// get particular info
	@RequestMapping(value = "/new", method = RequestMethod.GET)
	public ParticularUpdateDto getParticularInfo() {
		var user = getUser();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		return ParticularUpdateDto.populateDto(cache, null, new ParticularUpdateDto(), tg, paymentHelper, fileHelper, userHelper, user.getLoginId());
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ParticularUpdateDto editParticularInfo() {
		var user = getUser();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		TgPersonUpdate tpu = tgPersonUpdateRepository.getTgPersonUpdateDetails(user.getLoginId());
		return ParticularUpdateDto.populateDto(cache, tpu, new ParticularUpdateDto(), tg, paymentHelper, fileHelper, userHelper, user.getLoginId());
	}

	// get application no
	@RequestMapping(value = "/new/application-no", method = RequestMethod.GET)
	public ParticularUpdateDto getApplicationNo() {

		var user = getUser();
		var tpu = tgPersonUpdateRepository.getTgPersonUpdateDetails(user.getLoginId());
		var app = tpu.getApplication();

		var itemDto = new ParticularUpdateDto();
		if (app != null) {
			itemDto.setApplicationNo(app.getApplicationNo());
		}

		itemDto.setIsDraft(app.getIsDraft());

		itemDto.setLicenceStatusCode(app.getLicence().getStatus().getCode());
		return itemDto;
	}

	// save particulars application
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ParticularUpdateDto saveBeforePayment(@RequestPart(name = "dto") ParticularUpdateDto itemDto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {

		var user = getUser();
		var tg = touristGuideRepository.getTouristGuideByUin(user.getLoginId());
		itemDto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(user.getLoginId()));

		// If name, payment and approval from officer is required
		var approvalRequired = false;
		if (!tg.getName().equalsIgnoreCase(itemDto.getName())) {
			approvalRequired = true;
		}

		// for workpass holder, company name, changed to PR or change of workpass time, payment and approval from officer is required
		if (!approvalRequired && itemDto.getIsWorkPassHolder()) {
			if ((StringUtils.isBlank(tg.getEmployerName()) && !StringUtils.isBlank(itemDto.getEmployerName()))
					|| (!StringUtils.isBlank(tg.getEmployerName()) && !tg.getEmployerName().equals(itemDto.getEmployerName()))
					|| (!Codes.Types.RESIDENTIAL_PR.equals(tg.getResidentialStatus().getCode()) && !Codes.Types.RESIDENTIAL_CITIZEN.equals(tg.getResidentialStatus().getCode())
							&& Codes.Types.RESIDENTIAL_PR.equals(itemDto.getResidentialStatus()))) {
				approvalRequired = true;
			}
		}

		if (approvalRequired) {
			itemDto.setPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue()));
			createTgPersonUpdate(tg, itemDto, false, deletedFiles);
		} else {
			updateTGWithoutApproval(tg, itemDto, deletedFiles);
		}

		return itemDto;
	}

	@RequestMapping(value = "/save/payment", method = RequestMethod.POST)
	public ParticularUpdateDto personUpdatePayment(@RequestPart(name = "dto") ParticularUpdateDto itemDto) {

		var user = getUser();
		var tpu = tgPersonUpdateRepository.getTgPersonUpdateDetails(user.getLoginId());
		if (tpu != null) {
			itemDto.setId(tpu.getId());
			PaymentRequest pr = savePayment(tpu.getApplication(), tpu, itemDto.getPaymentFee());
			itemDto.setBillRefNo(pr != null ? pr.getBillRefNo() : null);
		}

		return itemDto;
	}

	@RequestMapping(value = "/save/{id}", method = RequestMethod.GET)
	public ParticularUpdateDto saveAfterPayment(@PathVariable Integer id) {

		var user = getUser();
		var tpu = tgPersonUpdateRepository.getTgPersonUpdate(id);
		appHelper.isAppBelongToTG(tpu, user, Codes.ApplicationTypes.TG_APP_PERSON_UPDATE);

		ParticularUpdateDto dto = new ParticularUpdateDto();
		dto.setId(tpu.getId());

		var application = tpu.getApplication();
		var lastAction = application.getLastAction();

		PaymentRequest payReq = paymentHelper.getPaymentRequest(tpu.getAppFeeBillRefNo());
		PaymentTxn paymentTxn = payReq.getLastTxn();

		if (Entities.equals(payReq.getStatus(), Codes.Statuses.PAYREQ_WAIVED) || paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL))) {

			if (lastAction == null || !(Entities.allEquals(lastAction.getStatus(), Codes.Statuses.TG_APP_PENDING_PO, Codes.Statuses.TG_APP_PENDING_AO, Codes.Statuses.TG_APP_PENDING_HODIV))) {
				application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_APPROVAL));
				var workflowAction = appHelper.forward(application, true);
				application.setLastAction(workflowAction);
				application.setIsDraft(false);
				application.setSubmissionDate(LocalDateTime.now());
				tgApplicationRepository.update(application);

				dto.setApplicationNo(application.getApplicationNo());
			}

			dto.setPaymentSuccess(true);
		} else {
			dto.setPaymentSuccess(false);
		}

		dto.setIsDraft(application.getIsDraft());

		return dto;
	}

	private TgPersonUpdate createTgPersonUpdate(TouristGuide tg, ParticularUpdateDto itemDto, boolean isAutoApproved, List<Integer> deletedFiles) {

		User user = getUser();
		TgPersonUpdate tpu = tgPersonUpdateRepository.getTgPersonUpdateDetails(user.getLoginId());
		Application application = new Application();
		if (tpu != null) {
			application = tpu.getApplication();
		} else {
			tpu = new TgPersonUpdate();
			tgPersonUpdateRepository.save(tpu);

			application = appHelper.saveNewApplication(Codes.ApplicationTypes.TG_APP_PERSON_UPDATE, tg.getLicence().getId(), false, false);

			// save snapshot
			TgPersonUpdate snapshot = tpu.getPreviousValue() == null ? new TgPersonUpdate() : tpu.getPreviousValue();
			snapshot = appHelper.snapshotCurrentTgDetails(snapshot, tg);
			tpu.setPreviousValue(snapshot);
			tgPersonUpdateRepository.saveOrUpdate(snapshot);
		}

		if (isAutoApproved) {
			application.setSubmissionDate(LocalDateTime.now());
			application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
			var workflowAction = appHelper.autoApprove(application, true);
			application.setLastAction(workflowAction);
		} else {
			application.setIsDraft(true);
		}

		tpu.setUser(tg.getUser());
		tpu.setApplication(application);
		updateTgPersonUpdateFromDto(tpu, itemDto, deletedFiles);
		itemDto.setBillRefNo(tpu.getAppFeeBillRefNo());

		return tpu;
	}

	private void updateTGWithoutApproval(TouristGuide tg, ParticularUpdateDto itemDto, List<Integer> deletedFiles) {
		var tpu = createTgPersonUpdate(tg, itemDto, true, deletedFiles);
		updateTgFromTgPersonUpdate(tpu, tg);
	}

	// retrieve rfa application
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public ParticularUpdateDto retrieveRfaApplication(@PathVariable Integer id) {

		TgPersonUpdate tpu = tgPersonUpdateRepository.getTgPersonUpdate(id);
		User user = getUser();
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(tpu.getUin());
		appHelper.isAppBelongToTG(tpu, user, Codes.ApplicationTypes.TG_APP_PERSON_UPDATE);
		return ParticularUpdateDto.populateDto(cache, tpu, new ParticularUpdateDto(), tg, paymentHelper, fileHelper, userHelper, user.getLoginId());
	}

	@RequestMapping(value = "/load/{id}", method = RequestMethod.GET)
	public ParticularUpdateDto getApplication(@PathVariable Integer id) {
		TgPersonUpdate tpu = tgPersonUpdateRepository.getTgPersonUpdate(id);
		var user = getUser();
		appHelper.isAppBelongToTG(tpu, user, Codes.ApplicationTypes.TG_APP_PERSON_UPDATE);

		var itemDto = new ParticularUpdateDto();
		itemDto = itemDto.buildSubmissionDetails(cache, paymentHelper, tpu);
		return itemDto;
	}

	// update particulars application
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ParticularUpdateDto updateApplication(@RequestPart(name = "dto") ParticularUpdateDto itemDto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {
		TgPersonUpdate tpu = tgPersonUpdateRepository.get(TgPersonUpdate.class, itemDto.getId());
		updateTgPersonUpdateFromDto(tpu, itemDto, deletedFiles);
		appHelper.forward(tpu.getApplication(), true);
		return itemDto;
	}

	private void updateTgPersonUpdateFromDto(TgPersonUpdate tpu, ParticularUpdateDto itemDto, List<Integer> deletedFiles) {
		tpu.setUin(itemDto.getNric());
		tpu.setSalutation(itemDto.getSalutation() != null ? cache.getType(itemDto.getSalutation()) : null);
		tpu.setName(itemDto.getName());
		tpu.setDob(itemDto.getDob());
		tpu.setSex(itemDto.getSex() != null ? cache.getType(itemDto.getSex()) : null);
		tpu.setMaritalStatus(itemDto.getMaritalStatus() != null ? cache.getType(itemDto.getMaritalStatus()) : null);
		tpu.setRace(itemDto.getRace() != null ? cache.getType(itemDto.getRace()) : null);
		tpu.setNationality(itemDto.getNationality() != null ? cache.getType(itemDto.getNationality()) : null);
		tpu.setBirthCountry(itemDto.getBirthCountry() != null ? cache.getType(itemDto.getBirthCountry()) : null);
		tpu.setResidentialStatus(itemDto.getResidentialStatus() != null ? cache.getType(itemDto.getResidentialStatus()) : null);
		tpu.setHighestEduLevel(itemDto.getHighestEduLevel() != null ? cache.getType(itemDto.getHighestEduLevel()) : null);
		tpu.setMobileNo(itemDto.getMobileNo());
		tpu.setEmailAddress(itemDto.getEmailAddress());
		tpu.setEmployerName(itemDto.getEmployerName());
		tpu.setOccupation(itemDto.getOccupation() != null ? cache.getType(itemDto.getOccupation()) : null);
		tpu.setOccupationOther(itemDto.getOccupationOther());
		tpu.setWorkPassType(itemDto.getWorkPassType() != null ? cache.getType(itemDto.getWorkPassType()) : null);
		tpu.setWorkpassExpiryDate(itemDto.getWorkpassExpiryDate() != null ? itemDto.getWorkpassExpiryDate() : null);
		tpu.setAliasName(itemDto.getAliasName());
		tpu.setIsMyInfoPopulated(itemDto.isMyInfoPopulated());

		tpu.setHasConsentEmailAddress(itemDto.getHasConsentEmailAddress());
		tpu.setHasConsentMobileNo(itemDto.getHasConsentMobileNo());

		Address regAddr = null;
		Address opAddr = null;
		if (StringUtils.isNotBlank(itemDto.getRegPostal())) {
			regAddr = tpu.getRegisteredAddress();
			if (regAddr == null) {
				regAddr = new Address();
				touristGuideRepository.save(regAddr);
			}

			String addressType = itemDto.getRegType().getKey().toString();
			if (addressType.equals(Codes.Types.ADDR_LOCAL)) {
				regAddr = AddressDto.buildAddressFromDto(regAddr, cache.getType(addressType), itemDto.getRegStreet(), itemDto.getRegBuilding(), itemDto.getRegBlock(), itemDto.getRegFloor(),
						itemDto.getRegUnit(), itemDto.getRegPostal(), null, null, null);
			} else if (addressType.equals(Codes.Types.ADDR_FOREIGN)) {
				regAddr = AddressDto.buildAddressFromDto(regAddr, cache.getType(addressType), null, null, null, null, null, null, itemDto.getRegForeignLine1(), itemDto.getRegForeignLine2(),
						itemDto.getRegForeignLine3());
			}

		}

		if (itemDto.getIsAddrSame()) {
			opAddr = regAddr;
		} else {
			if (StringUtils.isNotBlank(itemDto.getOptPostal())) {
				opAddr = tpu.getOperatingAddress();

				if (opAddr == null || Objects.equal(opAddr, regAddr)) {
					opAddr = new Address();
					touristGuideRepository.save(opAddr);
				}

				String addressType = itemDto.getOptType().getKey().toString();
				if (addressType.equals(Codes.Types.ADDR_LOCAL)) {
					opAddr = AddressDto.buildAddressFromDto(opAddr, cache.getType(addressType), itemDto.getOptStreet(), itemDto.getOptBuilding(), itemDto.getOptBlock(), itemDto.getOptFloor(),
							itemDto.getOptUnit(), itemDto.getOptPostal(), null, null, null);
				} else if (addressType.equals(Codes.Types.ADDR_FOREIGN)) {
					opAddr = AddressDto.buildAddressFromDto(opAddr, cache.getType(addressType), null, null, null, null, null, null, itemDto.getOptForeignLine1(), itemDto.getOptForeignLine2(),
							itemDto.getOptForeignLine3());
				}

			}
		}

		tpu.setRegisteredAddress(regAddr);
		tpu.setOperatingAddress(opAddr);

		if (itemDto.isConvictChecked()) {
			tpu.setOffenceDate(itemDto.getOffenceDate());
			tpu.setOffenceDeclaredDate(LocalDateTime.now());
			tpu.setOffenceType(itemDto.getOffenceType());
			tpu.setEnforcementOutcome(itemDto.getEnforcementOutcome());
		} else {
			tpu.setOffenceDate(null);
			tpu.setOffenceDeclaredDate(null);
			tpu.setOffenceType(null);
			tpu.setEnforcementOutcome(null);
		}

		for (Integer fileId : deletedFiles) {
			File file = fileHelper.getFile(fileId);
			if (file != null) {
				fileHelper.deleteFile(file);
			}
		}

		fileHelper.updateFiles(tpu.getApplication(), itemDto.getOtherSupportDocs(), Codes.TgDocumentTypes.TG_DOC_WORK_PASS);

	}

	/*
	 * Intranet
	 */

	// to retrieve all pending applications
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<ParticularUpdateItemDto> getPendingList(ParticularUpdateSearchDto searchDto) {
		return tgPersonUpdateRepository.getPendingListByFilter(searchDto);
	}

	// to retrieve update particulars application details
	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public ParticularUpdateDto getParticularsUpdateDetail(@PathVariable Integer id) {
		TgPersonUpdate tpu = tgPersonUpdateRepository.get(TgPersonUpdate.class, id);
		return viewParticularUpdate(tpu);
	}

	// to retrieve update particulars application details by application id
	@RequestMapping(value = "/view/app/{id}", method = RequestMethod.GET)
	public ParticularUpdateDto getParticularsUpdateDetailByApplication(@PathVariable Integer id) {
		var tpu = tgPersonUpdateRepository.getTgPersonUpdateDetailsByApplicationId(id);
		return viewParticularUpdate(tpu);
	}

	// approve, reject, rfa
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void process(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TgPersonUpdate tpu = tgPersonUpdateRepository.getTgPersonUpdate(id);
		Application app = tpu.getApplication();
		TouristGuide tg = app.getLicence().getTouristGuide();

		String url = null;
		String alertMsg = null;
		String emailType = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(app, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(app)) {
				app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_PRINTING));
				updateTgFromTgPersonUpdate(tpu, tg);
				app.setLicence(tg.getLicence());

				url = String.format(properties.applicationUrl, "dashboard-tg");
				emailType = Codes.EmailType.TG_UPON_APPROVAL;
				alertMsg = Messages.Alerts.TG_APP_APPROVE;
			}
			break;

		case ACTION_REJECT:
			url = String.format(properties.applicationUrl, "tg/particulars/view/" + tpu.getId());
			emailType = Codes.EmailType.TG_UPON_REJECTION;
			alertMsg = Messages.Alerts.APP_REJECT;

			app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
			appHelper.reject(app, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			String status = dto.getRouteStatus();
			if (StringUtils.equals(status, Codes.Statuses.TG_APP_RFA)) {
				url = String.format(properties.applicationUrl, "tg/particulars/view/" + tpu.getId());
				emailType = Codes.EmailType.TG_UPON_RFA;
				alertMsg = Messages.Alerts.APP_RFA;
			}

			appHelper.rfa(app, status, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (url != null) {
			emailHelper.emailUponTgAction(app, tpu.getName(), emailType, url, tpu.getEmailAddress());
			alertHelper.createAlert(tg, app, alertMsg, Codes.Modules.MOD_TG, app.getType(), "tg/particulars/view/" + tpu.getId());
		}

	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		var tpu = tgPersonUpdateRepository.get(TgPersonUpdate.class, dto.getApplicationId());
		appHelper.saveNote(tpu.getApplication(), dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	private ParticularUpdateDto viewParticularUpdate(TgPersonUpdate tpu) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DateUtil.DATE_FORMAT_PATTERN);
		var tg = tpu.getApplication().getLicence().getTouristGuide();
		var isAppPersonUpdate = Codes.ApplicationTypes.TG_APP_PERSON_UPDATE.equalsIgnoreCase(tpu.getApplication().getType().getCode());

		ParticularUpdateDto itemDto = new ParticularUpdateDto(cache, tpu, tg, appHelper, fileHelper, paymentHelper);

		itemDto.setCompareDetailsDto(new ArrayList<ParticularUpdateCompareDetails>());
		List<ParticularUpdateCompareDetails> compareDtoList = itemDto.getCompareDetailsDto();
		itemDto.setCompareWorkPassDetailsDto(new ArrayList<ParticularUpdateCompareDetails>());
		List<ParticularUpdateCompareDetails> compareWorkPassDtoList = itemDto.getCompareWorkPassDetailsDto();

		itemDto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(tpu.getUin()));

		Boolean hasPreviousValue = tpu.getPreviousValue() != null;

		if (isAppPersonUpdate) {

			compareDtoList.add(new ParticularUpdateCompareDetails("Salutation", tpu.getSalutation(), hasPreviousValue ? tpu.getPreviousValue().getSalutation() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Full Name(As per NRIC/Passport)", tpu.getName(), hasPreviousValue ? tpu.getPreviousValue().getName() : "-"));
			compareDtoList.add(new ParticularUpdateCompareDetails("Alias Name", tpu.getAliasName(), hasPreviousValue ? tpu.getPreviousValue().getAliasName() : "-"));
			compareDtoList.add(new ParticularUpdateCompareDetails("NRIC/FIN", tpu.getUin(), hasPreviousValue ? tpu.getPreviousValue().getUin() : "-"));
			compareDtoList.add(new ParticularUpdateCompareDetails("Date of Birth", tpu.getDob() != null ? tpu.getDob().format(formatter) : "-",
					hasPreviousValue && tpu.getPreviousValue().getDob() != null ? tpu.getPreviousValue().getDob().format(formatter) : "-"));
			compareDtoList.add(new ParticularUpdateCompareDetails("Country of Birth", tpu.getBirthCountry(), hasPreviousValue ? tpu.getPreviousValue().getBirthCountry() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Nationality", tpu.getNationality(), hasPreviousValue ? tpu.getPreviousValue().getNationality() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Gender", tpu.getSex(), hasPreviousValue ? tpu.getPreviousValue().getSex() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Race", tpu.getRace(), hasPreviousValue ? tpu.getPreviousValue().getRace() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Marital Status", tpu.getMaritalStatus(), hasPreviousValue ? tpu.getPreviousValue().getMaritalStatus() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Highest Education Level", tpu.getHighestEduLevel(), hasPreviousValue ? tpu.getPreviousValue().getHighestEduLevel() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Mobile Number", tpu.getMobileNo(), hasPreviousValue ? tpu.getPreviousValue().getMobileNo() : "-"));
			compareDtoList.add(new ParticularUpdateCompareDetails("Email Address", tpu.getEmailAddress(), hasPreviousValue ? tpu.getPreviousValue().getEmailAddress() : "-"));
			compareDtoList.add(new ParticularUpdateCompareDetails("Residential Status", tpu.getResidentialStatus(), hasPreviousValue ? tpu.getPreviousValue().getResidentialStatus() : null));
			compareDtoList.add(new ParticularUpdateCompareDetails("Registered Address", tpu.getRegisteredAddress() != null ? tpu.getRegisteredAddress().getAddressDisplay() : "-",
					hasPreviousValue && tpu.getPreviousValue().getRegisteredAddress() != null ? tpu.getPreviousValue().getRegisteredAddress().getAddressDisplay() : "-"));
			compareDtoList.add(new ParticularUpdateCompareDetails("Mailing Address",
					tpu.getOperatingAddress() != null
							? (Objects.equal(tpu.getRegisteredAddress(), tpu.getOperatingAddress()) ? "Same as Registered Address" : tpu.getOperatingAddress().getAddressDisplay())
							: "-",
					hasPreviousValue && tpu.getPreviousValue().getOperatingAddress() != null
							? (Objects.equal(tpu.getPreviousValue().getRegisteredAddress(), tpu.getPreviousValue().getOperatingAddress()) ? "Same as Registered Address"
									: tpu.getPreviousValue().getOperatingAddress().getAddressDisplay())
							: "-"));

			itemDto.setPhoto(tpu.getPhoto() != null ? FileDto.buildFromFile(tpu.getPhoto(), null, fileHelper) : null);
			itemDto.setPrevPhoto(hasPreviousValue && tpu.getPreviousValue().getPhoto() != null ? FileDto.buildFromFile(tpu.getPreviousValue().getPhoto(), null, fileHelper) : null);
		}

		if (isAppPersonUpdate && itemDto.getIsWorkPassHolder()) {
			compareWorkPassDtoList.add(new ParticularUpdateCompareDetails("Name of Employer", tpu.getEmployerName(), hasPreviousValue ? tpu.getPreviousValue().getEmployerName() : "-"));
			compareWorkPassDtoList.add(new ParticularUpdateCompareDetails("Occupation", tpu.getOccupation(), hasPreviousValue ? tpu.getPreviousValue().getOccupation() : null));
			compareWorkPassDtoList.add(new ParticularUpdateCompareDetails("Other Occupation", tpu.getOccupationOther(), hasPreviousValue ? tpu.getPreviousValue().getOccupationOther() : "-"));
			compareWorkPassDtoList.add(new ParticularUpdateCompareDetails("Type of Work Pass", tpu.getWorkPassType(), hasPreviousValue ? tpu.getPreviousValue().getWorkPassType() : null));
			compareWorkPassDtoList.add(new ParticularUpdateCompareDetails("Work Pass Expiry", tpu.getWorkpassExpiryDate() != null ? tpu.getWorkpassExpiryDate().format(formatter) : "-",
					hasPreviousValue && tpu.getPreviousValue().getWorkpassExpiryDate() != null ? tpu.getPreviousValue().getWorkpassExpiryDate().format(formatter) : ""));
		}
		return itemDto;
	}

	private void updateTgFromTgPersonUpdate(TgPersonUpdate tpu, TouristGuide tg) {

		Application app = tpu.getApplication();
		boolean isNewExisting = false;

		if (!app.isOfflineSubmission()) {
			tg.setSalutation(tpu.getSalutation());
			tg.setDob(tpu.getDob());
			tg.setSex(tpu.getSex());
			tg.setAliasName(tpu.getAliasName());
			tg.setMaritalStatus(tpu.getMaritalStatus());
			tg.setRace(tpu.getRace());
			tg.setNationality(tpu.getNationality());
			tg.setBirthCountry(tpu.getBirthCountry());
			tg.setHighestEduLevel(tpu.getHighestEduLevel());
			tg.setMobileNo(tpu.getMobileNo());
			tg.setEmailAddress(tpu.getEmailAddress());
			tg.setRegisteredAddress(tpu.getRegisteredAddress());
			tg.setMailingAddress(tpu.getOperatingAddress());
			tg.setOffenceDeclaredDate(tpu.getOffenceDeclaredDate());
			tg.setOffenceDate(tpu.getOffenceDate());
			tg.setOffenceType(tpu.getOffenceType());
			tg.setEnforcementOutcome(tpu.getEnforcementOutcome());
			tg.setHasConsentMobileNo(tpu.hasConsentMobileNo());
			tg.setHasConsentEmailAddress(tpu.hasConsentEmailAddress());
			tg.setHasPersonUpdateAccess(true);
			tg.setIsMyInfoPopulated(tpu.isMyInfoPopulated());
		} else {
			if (tpu.getPhoto() != null) {
				tg.setPhoto(tpu.getPhoto());
			}
			// tg.setUin(tpu.getUin());
			User user = new User();
			TgCandidate tgCandidate = new TgCandidate();
			if (tg.getUser() != null) {
				logger.info("user with touristguideId is existed");
				user = tg.getUser();
				user.setLoginId(tpu.getUin());
			} else {
				logger.info("user with touristguideId is not existed");
				// To cater where user no tied with tg
				user = userRepository.getUserByLoginId(tpu.getUin());
				if (user != null) {
					logger.info("the updated NRIC/FIN user is existed");
					isNewExisting = true;
					user.setLoginId(tpu.getUin());
					touristGuideRepository.update(user);
				}
				if (!isNewExisting) {
					logger.info("the updated NRIC/FIN user is not existed");
					logger.info("find user by old UIN");
					user = userRepository.getUserByLoginId(tg.getUin());
					if (user != null) {
						logger.info("the old UIN is existed");
						user.setLoginId(tpu.getUin());
						touristGuideRepository.update(user);
					} else {
						logger.info("the old UIN is not existed");
					}
				}
			}

			if (user != null) {
				tgCandidate = user.getTgCandidate();
				if (tgCandidate != null) {
					logger.info("TG Candidate is existed");
					tgCandidate.setUin(tpu.getUin());
				} else {
					logger.info("TG Candidate is not existed");
				}
			} else {
				tgCandidate = tgCandidateRepository.getTgCandidateByUin(tg.getUin());
				if (tgCandidate != null) {
					logger.info("TG Candidate is existed");
					tgCandidate.setUin(tpu.getUin());
				} else {
					logger.info("TG Candidate is not existed");
				}
			}
			tg.setUin(tpu.getUin());

		}

		tg.setName(tpu.getName());
		tg.setResidentialStatus(tpu.getResidentialStatus());

		if (userHelper.checkWorkPassHolder(tpu.getUin())) {
			tg.setEmployerName(tpu.getEmployerName());
			tg.setOccupation(tpu.getOccupation());
			tg.setOccupationOther(tpu.getOccupationOther());
			tg.setWorkPassType(tpu.getWorkPassType());
			tg.setWorkPassExpiryDate(tpu.getWorkpassExpiryDate());
		}

		// Update elicence name and company name to null
		tg.setDisplayName(null);
		tg.setDisplaySecondName(null);
		tg.setDisplayEmployerName(null);
		tg.setDisplaySecondEmployerName(null);

		touristGuideRepository.saveOrUpdate(tg);

	}

	// offline submission

	@RequestMapping(value = "/offline/save/{id}", method = RequestMethod.POST)
	public String updateResidentialStatus(@RequestBody ParticularUpdateDto dto, @PathVariable Integer id) {

		String tpuId = null;

		validatePendingApproval(id);

		TouristGuide tg = touristGuideRepository.getTouristGuideByLicenceId(id);

		if (tg != null) {
			Licence licence = tg.getLicence();
			Application application = new Application();
			application = appHelper.saveNewApplication(Codes.ApplicationTypes.TG_APP_PERSON_UPDATE, licence.getId(), true, false);

			// 1. Save Current Data
			TgPersonUpdate tpu = new TgPersonUpdate();
			tpu.setIsMyInfoPopulated(tg.isMyInfoPopulated());
			tpu.setName(tg.getName());
			tpu.setUin(tg.getUin());
			tpu.setResidentialStatus(tg.getResidentialStatus());
			if (userHelper.checkWorkPassHolder(tg.getUin())) {
				tpu.setEmployerName(tg.getEmployerName());
				tpu.setOccupation(tg.getOccupation());
				tpu.setOccupationOther(tg.getOccupationOther());
				tpu.setWorkPassType(tg.getWorkPassType());
				tpu.setWorkpassExpiryDate(tg.getWorkPassExpiryDate());
			}
			tpu.setPhoto(tg.getPhoto());
			touristGuideRepository.save(tpu);

			// 2. save snapshot
			TgPersonUpdate snapshot = new TgPersonUpdate();
			snapshot.setPreviousValue(tpu);
			offlineUpdateTgPersonUpdateFromDto(snapshot, dto);
			snapshot.setApplication(application);
			touristGuideRepository.save(snapshot);
			tpuId = snapshot.getId().toString();

			if (dto.getIsPaymentRequired() != null && dto.getIsPaymentRequired()) {
				// Require Approval
				var lastAction = application.getLastAction();
				if (lastAction == null || !(Entities.allEquals(lastAction.getStatus(), Codes.Statuses.TG_APP_PENDING_PO, Codes.Statuses.TG_APP_PENDING_AO, Codes.Statuses.TG_APP_PENDING_HODIV))) {
					application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_PENDING_APPROVAL));
					var workflowAction = appHelper.forward(application, true);
					application.setLastAction(workflowAction);
					application.setIsDraft(false);
					application.setSubmissionDate(LocalDateTime.now());
					touristGuideRepository.update(application);
				}
				touristGuideRepository.update(snapshot);
			} else {
				// Without Approval
				application.setSubmissionDate(LocalDateTime.now());
				application.setLicencePrintStatus(cache.getStatus(Codes.Statuses.PRINT_NOT_REQUIRED));
				var workflowAction = appHelper.autoApprove(application, true);
				application.setLastAction(workflowAction);
				touristGuideRepository.update(application);

				updateTgFromTgPersonUpdate(snapshot, tg);
			}
		}
		return tpuId;
	}

	@RequestMapping(value = "/offline/save/payment/{id}", method = RequestMethod.GET)
	public void offlinePersonUpdatePayment(@PathVariable Integer id) {

		TgPersonUpdate tpu = touristGuideRepository.get(TgPersonUpdate.class, id);

		if (tpu != null) {
			PaymentRequest pr = savePayment(tpu.getApplication(), tpu, Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue()));
			paymentHelper.waivePayments(Arrays.asList(pr.getBillRefNo()));
		}
	}

	// update particulars application
	@RequestMapping(value = "/offline/save/update", method = RequestMethod.POST)
	public void offlineUpdateApplication(@RequestBody ParticularUpdateDto dto) {
		TgPersonUpdate tpu = tgPersonUpdateRepository.get(TgPersonUpdate.class, dto.getId());
		offlineUpdateTgPersonUpdateFromDto(tpu, dto);
	}

	private PaymentRequest savePayment(Application application, TgPersonUpdate tpu, Integer paymentFee) {
		PaymentRequest pr = null;
		if (application != null) {
			pr = paymentHelper.savePaymentRequest(application.getApplicationNo(), Codes.TgPaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE, tpu.getUin(), tpu.getName(), new BigDecimal(paymentFee),
					"TG Particular Update Fee", null, true, false, tpu.getEmailAddress());
			tpu.setAppFeeBillRefNo(pr.getBillRefNo());
		}
		return pr;
	}

	private void validatePendingApproval(Integer id) {
		TgPersonUpdate tpu = tgPersonUpdateRepository.getTgPersonUpdateDetails(id);

		if (tpu != null) {
			var app = tpu.getApplication();
			var lastAction = app.getLastAction();
			if (lastAction != null) {
				throw new ValidationException("There is a pending approval with application no " + app.getApplicationNo() + ".");
			}
		}
	}

	private void offlineUpdateTgPersonUpdateFromDto(TgPersonUpdate tpu, ParticularUpdateDto dto) {
		tpu.setIsMyInfoPopulated(false);
		tpu.setName(dto.getName());
		tpu.setUin(dto.getNric());
		tpu.setResidentialStatus(cache.getType(dto.getResidentialStatus()));
		if (userHelper.checkWorkPassHolder(dto.getNric())) {
			tpu.setEmployerName(dto.getEmployerName());
			tpu.setOccupation(dto.getOccupation() != null ? cache.getType(dto.getOccupation()) : null);
			tpu.setOccupationOther(dto.getOccupationOther());
			tpu.setWorkPassType(dto.getWorkPassType() != null ? cache.getType(dto.getWorkPassType()) : null);
			tpu.setWorkpassExpiryDate(dto.getWorkpassExpiryDate() != null ? dto.getWorkpassExpiryDate() : null);
		}
		if (dto.getPhoto() != null) {
			tpu.setPhoto(touristGuideRepository.load(File.class, dto.getPhoto().getId()));
		}
	}
}