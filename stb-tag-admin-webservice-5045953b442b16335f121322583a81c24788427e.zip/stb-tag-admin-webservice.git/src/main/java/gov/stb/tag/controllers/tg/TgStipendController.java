package gov.stb.tag.controllers.tg;

import static gov.stb.tag.util.DateUtil.REPORT_DATE_FORMAT_PATTERN;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.CaseNoteDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.licence.TgLicenceDto;
import gov.stb.tag.dto.tg.licence.TgLicenceSearchDto;
import gov.stb.tag.dto.tg.stipend.TgStipendConfigDto;
import gov.stb.tag.dto.tg.stipend.TgStipendConfigSearchDto;
import gov.stb.tag.dto.tg.stipend.TgStipendDto;
import gov.stb.tag.dto.tg.stipend.TgStipendItemDto;
import gov.stb.tag.dto.tg.stipend.TgStipendSearchDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.AlertHelper;
import gov.stb.tag.helper.EmailHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.helper.TgStipendPdfHelper;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentStatusSpan;
import gov.stb.tag.model.TgStipend;
import gov.stb.tag.model.TgStipendConfig;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.PaymentRepository;
import gov.stb.tag.repository.tg.TgLicenceRepository;
import gov.stb.tag.repository.tg.TgStipendRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.ExcelUtil;
import gov.stb.tag.util.FileUtil;
import gov.stb.tag.util.NumeralUtil;

@RestController
@RequestMapping(path = "/api/v1/tg/stipend")
@Transactional
public class TgStipendController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgStipendRepository tgStipendRepository;
	@Autowired
	TouristGuideRepository touristGuideRepository;
	@Autowired
	AlertHelper alertHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	PaymentHelper paymentHelper;
	@Autowired
	TgHelper tgHelper;
	@Autowired
	TgLicenceRepository tgLicenceRepository;
	@Autowired
	PaymentRepository paymentRepository;
	@Autowired
	TgStipendPdfHelper tgStipendPdfHelper;

	protected static final String[] CONTENT_HEADERS = new String[] { "S/No.", "Reference No.", "TG Name", "TG NRIC", "Name as per bank account", "Bank Name", "Bank Code", "Bank Branch Code",
			"Bank Account No", "Amount", "Bill Reference No.", "Payment Status", "Application Status", "Approver", "Approved Date" };

	/*
	 * Stipend System Config
	 */
	@RequestMapping(value = "/config/view", method = RequestMethod.GET)
	public TgStipendConfigDto getConfig(TgStipendConfigSearchDto searchDto) throws Exception {
		TgStipendConfigDto dto = new TgStipendConfigDto();
		TgStipendConfig model = tgStipendRepository.getStipendConfig(searchDto);
		if (model != null) {
			dto = TgStipendConfigDto.buildFromModel(model, false, userRepository);
			if (LocalDate.now().isAfter(dto.getPeriodStartDate()) || LocalDate.now().isEqual(dto.getPeriodStartDate())) {
				dto.setEditable(false);
			}
		}

		return dto;
	}

	@RequestMapping(value = "/config/save", method = RequestMethod.POST)
	public Integer saveConfig(@RequestBody TgStipendConfigDto dto) {
		TgStipendConfig model = null;
		if (dto.getId() != null) {
			model = tgStipendRepository.get(TgStipendConfig.class, dto.getId());
		} else {
			model = new TgStipendConfig();
		}

		model = updateConfigModelFromDto(model, dto);
		tgStipendRepository.saveOrUpdate(model);

		return model.getId();

	}

	// to retrieve all Active TG licences who are PR or Singaporeans
	@RequestMapping(path = { "/config/view/search-tg/{configId}", "/config/view/search-tg" }, method = RequestMethod.GET)
	public List<TgLicenceDto> getAllList(@PathVariable Optional<Integer> configId) {
		TgLicenceSearchDto searchDto = new TgLicenceSearchDto();
		searchDto.setWorkPassHolder(false);
		searchDto.setLicenceStatus(Statuses.TG_ACTIVE);
		searchDto.setResidentialStatuses(new String[] { Types.RESIDENTIAL_CITIZEN, Types.RESIDENTIAL_PR });
		List<Licence> licences = tgLicenceRepository.getTgLicences(searchDto);
		List<TgLicenceDto> dtoList = new ArrayList<TgLicenceDto>();
		for (Licence l : licences) {
			dtoList.add(TgLicenceDto.buildFromLicence(cache, l, new TgLicenceDto()));
		}

		if (configId.isPresent()) {
			TgStipendConfig configModel = tgStipendRepository.get(TgStipendConfig.class, configId.get());
			Set<TouristGuide> tgsSelected = configModel.getAppealTgs();
			if (tgsSelected != null) {
				List<Licence> selectedLicencesWhereNotActive = tgStipendRepository.getTgs(tgsSelected.stream().map(TouristGuide::getId).collect(Collectors.toList()));
				for (Licence l : selectedLicencesWhereNotActive) {
					dtoList.add(TgLicenceDto.buildFromLicence(cache, l, new TgLicenceDto()));
				}
			}

			List<TgStipend> stipedList = tgStipendRepository.getTgStipendByConfig(configId.get());
			for (TgStipend stipend : stipedList) {
				Integer licId = stipend.getApplication().getLicence().getId();
				TgLicenceDto licDto = dtoList.stream().filter(lic -> licId.equals(lic.getLicenceId())).findAny().orElse(null);

				if (dtoList.indexOf(licDto) != -1) {
					dtoList.get(dtoList.indexOf(licDto)).setData(true);
				}
			}

		}

		return dtoList;
	}

	private TgStipendConfig updateConfigModelFromDto(TgStipendConfig model, TgStipendConfigDto dto) {
		model.setForAppeal(dto.getForAppeal());
		model.setAmount(dto.getAmount());
		model.setPreamble(dto.getPreamble());
		model.setSupportingDocText(dto.getSupportingDocText());
		model.setDeclaration(dto.getDeclaration());
		if (dto.getPeriodStartDate() != null) {
			model.setPeriodStartDate(dto.getPeriodStartDate());
		}
		model.setPeriodEndDate(dto.getPeriodEndDate());
		model.setLicenceStartBefore(dto.getLicenceStartBefore());
		if (!dto.getForAppeal()) {
			if (dto.getGuidingLanguages() != null) {
				model.setGuidingLanguages(String.join(",", dto.getGuidingLanguages()));
			}
		}
		if (dto.getForAppeal()) {
			// model.setAppealTgLicIds(String.join(",", dto.getTgMultiCtrl()));

			if (dto.getTgMultiCtrl() != null && dto.getTgMultiCtrl().length > 0) {
				Integer[] integerArra = NumeralUtil.convertArray(dto.getTgMultiCtrl(), Integer::parseInt, Integer[]::new);
				Integer[] integerArrb = NumeralUtil.convertArray(dto.getAppealedTGId(), Integer::parseInt, Integer[]::new);
				int aLen = dto.getTgMultiCtrl().length;
				int bLen = dto.getAppealedTGId().length;
				Integer[] result = new Integer[aLen + bLen];

				System.arraycopy(integerArra, 0, result, 0, aLen);
				System.arraycopy(integerArrb, 0, result, aLen, bLen);

				System.out.println(touristGuideRepository.getTouristGuidesByLicenceId(result).toString());
				model.setAppealTgs(new HashSet<>(touristGuideRepository.getTouristGuidesByLicenceId(result)));
			}
		}
		return model;
	}

	/*
	 * Internet
	 */
	@RequestMapping(value = "/new/{configId}", method = RequestMethod.GET)
	public TgStipendDto getStipendInfo(@PathVariable Integer configId) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(getUser().getLoginId());
		TgStipendConfig config = tgStipendRepository.get(TgStipendConfig.class, configId);
		Boolean isEligible = config != null ? true : false;
		// TgStipendConfig config = tgStipendRepository.getLatestStipendConfig(false);

		// if (!isEligible) {
		// // check if TG is one of the appeal successful TG
		// config = tgStipendRepository.getLatestStipendConfig(true);
		// isEligible = config != null ? tgHelper.getStipendEligibility(tg, config) : false;
		// }

		TgStipendDto dto = new TgStipendDto();
		TgStipend appliedStipend = tgStipendRepository.getTgStipendByTgAndPeriod(tg.getId(), config.getId());

		if (appliedStipend != null) {
			TgStipendDto.buildSubmissionFromModel(cache, appHelper, appliedStipend, config, dto, paymentHelper, fileHelper);
		} else {
			dto = TgStipendDto.buildNewSubmission(cache, tg, config);
			dto.setIsEligible(isEligible);
		}

		return dto;
	}

	// save new application
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveApplication(@RequestPart(name = "dto") TgStipendDto dto) {
		TouristGuide tg = touristGuideRepository.getTouristGuideByUin(getUser().getLoginId());
		TgStipendConfig config = tgStipendRepository.get(TgStipendConfig.class, dto.getConfigDto().getId());
		TgStipend appliedStipend = tgStipendRepository.getTgStipendByTgAndPeriod(tg.getId(), config.getId());

		if (appliedStipend != null) {
			logger.error("tg.id={} have applied for the stipend. stipendConfig.id={}", tg.getId(), config.getId());
			throw new ValidationException("You have applied for the stipend.");
		}

		Application application = new Application();
		application.setIsDraft(false);
		application.setTaTgType(Codes.TaTgType.TG);
		application.setType(cache.getType(Codes.ApplicationTypes.TG_APP_STIPEND));
		application.setLicence(tg.getLicence());
		application.setOfflineSubmission(false);
		application.setSubmissionDate(LocalDateTime.now());
		tgStipendRepository.save(application);

		appHelper.forward(application, true);

		TgStipend ts = new TgStipend();
		ts.setApplication(application);
		ts.setTgStipendConfig(config);
		updateTgStipend(ts, dto, application, tg, null);
		tgStipendRepository.save(ts);

		return ts.getId();
	}

	@RequestMapping(value = "/load/{id}", method = RequestMethod.GET)
	public TgStipendDto getApplication(@PathVariable Integer id) {
		TgStipend model = tgStipendRepository.getTgStipend(id);
		var user = getUser();
		appHelper.isAppBelongToTG(model, user, Codes.ApplicationTypes.TG_APP_STIPEND);
		TgStipendDto dto = new TgStipendDto();
		TgStipendConfig config = model.getTgStipendConfig();
		dto = TgStipendDto.buildSubmissionFromModel(cache, appHelper, model, config, dto, paymentHelper, fileHelper);

		return dto;
	}

	@RequestMapping(value = "/load/app/{appId}", method = RequestMethod.GET)
	public TgStipendDto getApplicationByAppId(@PathVariable Integer appId) {
		TgStipend model = tgStipendRepository.getTgStipendByApplication(appId);
		var user = getUser();
		appHelper.isAppBelongToTG(model, user, Codes.ApplicationTypes.TG_APP_STIPEND);
		TgStipendDto dto = new TgStipendDto();
		TgStipendConfig config = model.getTgStipendConfig();
		dto = TgStipendDto.buildSubmissionFromModel(cache, appHelper, model, config, dto, paymentHelper, fileHelper);

		return dto;
	}

	// update application
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public Integer updateApplication(@RequestPart(name = "dto") TgStipendDto dto, @RequestPart(name = "deletedFiles") List<Integer> deletedFiles) {
		TgStipend ts = tgStipendRepository.getTgStipend(dto.getId());
		Application application = ts.getApplication();
		updateTgStipend(ts, dto, application, application.getLicence().getTouristGuide(), deletedFiles);
		appHelper.forward(application, true);
		return ts.getId();
	}

	// update application
	@RequestMapping(value = "/update/follow-up", method = RequestMethod.POST)
	public Integer updateApplicationAfterFollowUp(@RequestBody TgStipendDto dto) {
		TgStipend ts = tgStipendRepository.getTgStipend(dto.getId());
		Application application = ts.getApplication();
		updateTgStipend(ts, dto, application, application.getLicence().getTouristGuide(), null);
		ts.setIsPendingFollowUp(false);
		ts.setHasFollowUpRequiredByFinance(false);
		PaymentRequest payReq = paymentRepository.getPaymentRequest(ts.getAppBillRefNo());
		payReq.setStatus(cache.getStatus(Statuses.PAYREQ_PENDING_DISBURSEMENT));
		paymentHelper.createPaymentStatusSpan(payReq, cache.getStatus(Codes.Statuses.PAYREQ_PENDING_DISBURSEMENT));
		appHelper.resubmitAfterFollowUp(application, true);
		return ts.getId();
	}

	private void updateTgStipend(TgStipend ts, TgStipendDto dto, Application application, TouristGuide tg, List<Integer> deletedFiles) {
		ts.setGuidingLanguages(tg.getGuidingLanguagesWithComma(cache));
		ts.setResidentialStatus(tg.getResidentialStatus());
		ts.setNameAsPerBank(dto.getNameAsPerBank().toUpperCase());
		ts.setBankName(dto.getBankName().toUpperCase());
		ts.setBankCode(dto.getBankCode());
		ts.setBankBranchCode(dto.getBankBranchCode());
		ts.setBankAccountNo(dto.getBankAccountNo());
		ts.setAmount(dto.getAmount() != null ? dto.getAmount() : dto.getConfigDto().getAmount());

		List<FileDto> newFiles = dto.getSupportingDocs().stream().filter(u -> u.getPublicFileId() == null).collect(Collectors.toList());
		if (CollectionUtils.isNotEmpty(newFiles)) {
			for (FileDto doc : newFiles) {
				fileHelper.saveFile(application, doc);
			}
		}

		if (CollectionUtils.isNotEmpty(deletedFiles)) {
			for (Integer fileId : deletedFiles) {
				File file = fileHelper.getFile(fileId);
				if (file != null) {
					fileHelper.deleteFile(file);
				}
			}
		}

	}

	/*
	 * Intranet
	 */
	// to retrieve all pending new applications
	@RequestMapping(method = RequestMethod.GET, value = "/view")
	public ResultDto<TgStipendItemDto> getList(TgStipendSearchDto searchDto) {
		return tgStipendRepository.getPendingList(searchDto, getUser().getId());
	}

	// to retrieve application details
	@RequestMapping(value = { "/view/{id}", "/view/app/{id}" }, method = RequestMethod.GET)
	public TgStipendDto getDetail(@PathVariable Integer id) {
		TgStipend model = tgStipendRepository.getTgStipendByApplication(id);
		TgStipendDto dto = new TgStipendDto();
		dto = TgStipendDto.buildSubmissionFromModel(cache, appHelper, model, model.getTgStipendConfig(), dto, paymentHelper, fileHelper);

		return dto;
	}

	// to retrieve application details by billRefNo
	@RequestMapping(value = "/view/billRefNo/{billRefNo}", method = RequestMethod.GET)
	public TgStipendDto getDetailsByBillRefNo(@PathVariable String billRefNo) {
		TgStipend model = tgStipendRepository.getTgStipendByBillRefNo(billRefNo);
		TgStipendDto dto = new TgStipendDto();
		dto = dto.buildSubmissionFromModel(cache, appHelper, model, model.getTgStipendConfig(), dto, paymentHelper, fileHelper);

		return dto;
	}

	// to retrieve all approved stipend applications
	@RequestMapping(method = RequestMethod.GET, value = "/view/finance/app/approved")
	public ResultDto<TgStipendItemDto> getApprovedList(TgStipendSearchDto searchDto) {
		return tgStipendRepository.getApprovedList(searchDto, true);
	}

	@RequestMapping(path = "/notes/save", method = RequestMethod.POST)
	public void saveCaseNote(CaseNoteDto dto) {
		var model = tgStipendRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(model, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
	}

	@RequestMapping(path = "/notes/save/finance", method = RequestMethod.POST)
	public void saveFinanceCaseNote(CaseNoteDto dto) {
		var model = tgStipendRepository.get(Application.class, dto.getApplicationId());
		appHelper.saveNote(model, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());

		var stipend = tgStipendRepository.getTgStipendByApplication(dto.getApplicationId());
		PaymentRequest payReq = paymentRepository.getPaymentRequest(stipend.getAppBillRefNo());

		if (!stipend.getHasFollowUpRequiredByFinance()) {
			stipend.setHasFollowUpRequiredByFinance(true);
			payReq.setStatus(cache.getStatus(Statuses.PAYREQ_PENDING_FOLLOW_UP));
			paymentHelper.createPaymentStatusSpan(payReq, cache.getStatus(Codes.Statuses.PAYREQ_PENDING_FOLLOW_UP), dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
		} else {
			paymentHelper.createPaymentStatusSpan(payReq, payReq.getStatus(), dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
		}

	}

	// approve, reject, rfa, followup
	@RequestMapping(value = "/{action}/{id}", method = RequestMethod.POST)
	public void process(@RequestBody ApprovalDto dto, @PathVariable String action, @PathVariable Integer id) {
		TgStipend stipendModel = tgStipendRepository.getTgStipendByApplication(id);
		Application appModel = stipendModel.getApplication();
		TouristGuide tgModel = appModel.getLicence().getTouristGuide();
		Licence licence = appModel.getLicence();
		TouristGuide tg = licence.getTouristGuide();

		String url = null;
		String alertMsg = null;
		String emailType = null;
		switch (action) {
		case ACTION_APPROVE:
			appHelper.forward(appModel, false, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);

			if (appHelper.hasFinalApproved(appModel)) {
				// Create payment request Pending Disbursement
				PaymentRequest pr = paymentHelper.savePaymentRequestCustomiseStatus(appModel.getApplicationNo(), Codes.TgPaymentRequestTypes.PAYREQ_TG_STIPEND, tgModel.getUin(), tgModel.getName(),
						stipendModel.getAmount(), "TG Wage Support", null, Boolean.FALSE, Boolean.FALSE, tgModel.getEmailAddress(), Codes.Statuses.PAYREQ_PENDING_DISBURSEMENT);
				stipendModel.setAppBillRefNo(pr.getBillRefNo());
			}
			break;

		case ACTION_REJECT:

			url = String.format(properties.applicationUrl, "tg/stipend-form/" + stipendModel.getId());
			alertMsg = Messages.Alerts.APP_REJECT;

			appHelper.reject(appModel, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null);
			break;

		case ACTION_ROUTE:
		case ACTION_RFA:

			String status = dto.getRouteStatus();
			if (StringUtils.equals(status, Codes.Statuses.TG_APP_RFA)) {
				url = String.format(properties.applicationUrl, "tg/stipend-form/" + stipendModel.getId());
				alertMsg = Messages.Alerts.APP_RFA;
				emailType = Codes.EmailType.TG_UPON_RFA;
			}

			appHelper.rfa(appModel, status, dto.getInternalRemarks(), dto.getExternalRemarks(), null, null, null, dto.getAssignee());
			break;

		case ACTION_FOLLOW_UP:

			if (stipendModel.isPendingFollowUp()) {
				throw new ValidationException("Application is pending TG input.");
			}
			stipendModel.setIsPendingFollowUp(true);
			PaymentRequest payReq = paymentHelper.getPaymentRequest(stipendModel.getAppBillRefNo());
			payReq.setStatus(cache.getStatus(Statuses.PAYREQ_PENDING_TG));
			paymentHelper.createPaymentStatusSpan(payReq, cache.getStatus(Codes.Statuses.PAYREQ_PENDING_TG), dto.getInternalRemarks(), null, null);
			url = String.format(properties.applicationUrl, "tg/stipend-form/" + stipendModel.getId());
			alertMsg = Messages.Alerts.APP_RFA;
			emailType = Codes.EmailType.TG_UPON_RFA;
			appHelper.followUp(appModel, dto.getInternalRemarks(), dto.getExternalRemarks());
			break;

		default:
			throw new ValidationException("Action received is invalid: " + action);
		}

		if (alertMsg != null) {
			alertHelper.createAlert(tgModel, appModel, alertMsg, Codes.Modules.MOD_TG, appModel.getType(), "tg/stipend-form/" + stipendModel.getId());
		}

		if (emailType != null) {
			emailHelper.emailUponTgAction(appModel, tg.getName(), emailType, url, tg.getEmailAddress());
		}

	}

	@RequestMapping(method = RequestMethod.POST, value = "/export-list")
	public void exportApprovedStipendList(@RequestBody TgStipendSearchDto searchDto, HttpServletResponse response) throws IOException {
		List<TgStipendDto> recordList = new ArrayList<TgStipendDto>();
		ResultDto<TgStipendItemDto> result = tgStipendRepository.getApprovedList(searchDto, false);
		List<TgStipendItemDto> models = result.getModels();

		if (!models.isEmpty()) {
			for (TgStipendItemDto itemDto : result.getModels()) {
				TgStipendDto dto = new TgStipendDto();
				TgStipend model = tgStipendRepository.get(TgStipend.class, itemDto.getStipendId());
				dto = TgStipendDto.buildSubmissionFromModel(cache, appHelper, model, model.getTgStipendConfig(), dto, paymentHelper, fileHelper);
				recordList.add(dto);
			}
		}

		generateExcel(recordList, response);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/export-list/pdf")
	public void exportStipendPdf(@RequestBody TgStipendSearchDto searchDto, HttpServletResponse response) throws IOException {
		if (searchDto.getAppIds() != null) {
			List<TgStipend> tgStipends = tgStipendRepository.getTgStipendByApplications(searchDto.getAppIds(), searchDto);
			List<TgStipendDto> dtos = new ArrayList<TgStipendDto>();

			for (TgStipend model : tgStipends) {
				TgStipendDto dto = new TgStipendDto();
				PaymentRequest payReq = paymentHelper.getPaymentRequest(model.getAppBillRefNo());
				dto = dto.buildSubmissionFromModel(cache, appHelper, model, model.getTgStipendConfig(), dto, paymentHelper, fileHelper);
				List<PaymentStatusSpan> results = paymentRepository.getPaymentStatusSpans(payReq.getId());
				dto.setAppPayout(dto.getAppPayout().buildPaymentStatusSpan(cache, dto.getAppPayout(), results));
				dtos.add(dto);
			}

			String outputFilePath = properties.baseDir + properties.downloadDir + "/" + "tg_stipend_application_" + DateUtil.format(LocalDate.now(), REPORT_DATE_FORMAT_PATTERN) + ".pdf";
			byte[] byteArray = tgStipendPdfHelper.generatePdf(dtos, outputFilePath);

			FileUtil.downloadSingleFile(response, new java.io.File(outputFilePath), null);

		}
	}

	public void generateExcel(List<TgStipendDto> recordList, HttpServletResponse response) throws IOException {
		logger.info("Start generating excel for tg-stipend-application ");
		String tempFileLocation = properties.baseDir + properties.downloadDir;
		String fileName = "tg_stipend_application_" + DateUtil.format(LocalDate.now(), REPORT_DATE_FORMAT_PATTERN);

		// create excel workbook
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("TG Stipend Application");
		ExcelUtil.createHeaderRow(sheet, CONTENT_HEADERS);

		int i = 1;
		for (TgStipendDto dto : recordList) {
			XSSFRow row = sheet.createRow(i++);
			int j = 0;

			row.createCell(j++, CellType.STRING).setCellValue(String.valueOf(i - 1));
			row.createCell(j++, CellType.STRING).setCellValue(dto.getApplicationNo());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getName());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getUin());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getNameAsPerBank());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getBankName());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getBankCode());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getBankBranchCode());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getBankAccountNo());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getAmount() != null ? dto.getAmount().toString() : "0");
			row.createCell(j++, CellType.STRING).setCellValue(dto.getBillRefNo());
			row.createCell(j++, CellType.STRING).setCellValue(dto.getAppPayout() != null ? dto.getAppPayout().getStatus() : "");
			row.createCell(j++, CellType.STRING).setCellValue(dto.getApplicationStatus().getLabel());
			row.createCell(j++, CellType.STRING).setCellValue(!Strings.isNullOrEmpty(dto.getApprover()) ? dto.getApprover() : "");
			row.createCell(j++, CellType.STRING).setCellValue(dto.getApprovedDate() != null ? dto.getApprovedDate().format(DateUtil.DATETIME_FORMAT) : "");
		}

		logger.info("End generating excel for tg-stipend-application");

		String outputFilePath = tempFileLocation + "/" + fileName + ".xlsx";
		// create physical excel in specified outputFilePath
		FileOutputStream fileOutput = new FileOutputStream(outputFilePath);
		workbook.write(fileOutput);
		fileOutput.close();
		workbook.close();
		FileUtil.downloadSingleFile(response, new java.io.File(outputFilePath), null);
	}

}