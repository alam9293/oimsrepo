package gov.stb.tag.controllers.tg;

import java.util.HashSet;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.controllers.BaseController;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.tg.trainingprovider.TgTrainingProviderItemDto;
import gov.stb.tag.dto.tg.trainingprovider.TgTrainingProviderSearchDto;
import gov.stb.tag.dto.tg.trainingprovider.TrainingProviderDto;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgCourseAttendance;
import gov.stb.tag.model.TgCourseAttendanceDetail;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.repository.tg.TgCourseAttendanceDetailRepository;
import gov.stb.tag.repository.tg.TgCourseAttendanceRepository;
import gov.stb.tag.repository.tg.TgCourseRepository;
import gov.stb.tag.repository.tg.TgTrainingProviderRepository;

@RestController
@RequestMapping(path = "/api/v1/tg/training-provider")
@Transactional
public class TgTrainingProviderController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TgTrainingProviderRepository tgTrainingProviderRepository;
	@Autowired
	TgCourseRepository tgCourseRepository;
	@Autowired
	TgCourseAttendanceRepository tgCourseAttendanceRepository;
	@Autowired
	TgCourseAttendanceDetailRepository tgCourseAttendanceDetailRepository;

	/*
	 * Admin
	 */
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public ResultDto<TgTrainingProviderItemDto> getTrainingProviders(TgTrainingProviderSearchDto searchDto) {
		return tgTrainingProviderRepository.getList(searchDto);
	}

	@RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
	public TrainingProviderDto getTgTrainingProviders(@PathVariable Integer id) {
		TgTrainingProvider tgTrainingProvider = tgTrainingProviderRepository.getTgTrainingProviderById(id);
		return new TrainingProviderDto(cache, tgTrainingProvider);
	}

	@RequestMapping(value = "/profile/load", method = RequestMethod.GET)
	public TrainingProviderDto getTgTrainingProviderProfile() {
		TgTrainingProvider tgTrainingProvider = tgTrainingProviderRepository.get(TgTrainingProvider.class, getUser().getTgTrainingProvider().getId());
		return new TrainingProviderDto(cache, tgTrainingProvider);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer saveTrainingProvider(@RequestBody TrainingProviderDto dto) {
		TgTrainingProvider tgTrainingProvider = new TgTrainingProvider();

		saveOrUpdateTrainingProvider(tgTrainingProvider, dto);
		tgTrainingProviderRepository.save(tgTrainingProvider);
		return tgTrainingProvider.getId();
	}

	@RequestMapping(path = { "/update", "/profile/update" }, method = RequestMethod.POST)
	public Integer updateTrainingProvider(@RequestBody TrainingProviderDto dto) {
		TgTrainingProvider tgTrainingProvider = null;

		if (getSelectedRoleCode().equals(Codes.Roles.TP_PUBLIC)) {
			tgTrainingProvider = tgTrainingProviderRepository.getTgTrainingProviderById(getUser().getTgTrainingProvider().getId());
			dto.setId(tgTrainingProvider.getId());
		} else {
			tgTrainingProvider = tgTrainingProviderRepository.getTgTrainingProviderById(dto.getId());
		}
		saveOrUpdateTrainingProvider(tgTrainingProvider, dto);
		return tgTrainingProvider.getId();
	}

	@RequestMapping(value = "/update/delete/{id}", method = RequestMethod.GET)
	public void updateTrainingProvider(@PathVariable Integer id) {
		TgTrainingProvider tgTrainingProvider = tgTrainingProviderRepository.getTgTrainingProviderById(id);

		Set<TgCourse> tgCourseList = tgTrainingProvider.getTgCourses();
		Set<TgCourseAttendance> tgCourseAttendanceList = new HashSet<>();
		Set<TgCourseAttendanceDetail> tgCourseAttendanceDetailList = new HashSet<>();

		if (CollectionUtils.isNotEmpty(tgCourseList)) {
			tgCourseList.forEach(u -> {
				Set<TgCourseAttendance> tcaSet = u.getTgCourseAttendances();
				if (CollectionUtils.isNotEmpty(tcaSet)) {

					tcaSet.forEach(tca -> {
						tgCourseAttendanceDetailList.addAll(tca.getTgCourseAttendanceDetails());

						tca.setIsDeleted(true);
					});

					tgCourseAttendanceList.addAll(tcaSet);
				}

				u.setIsDeleted(true);
			});
		}

		if (CollectionUtils.isNotEmpty(tgCourseAttendanceDetailList)) {
			tgCourseAttendanceDetailList.forEach(u -> u.setDeleted(true));
		}

		tgCourseAttendanceDetailRepository.update(tgCourseAttendanceDetailList);
		tgCourseAttendanceRepository.update(tgCourseAttendanceList);
		tgCourseRepository.update(tgCourseAttendanceList);

		tgTrainingProvider.setIsDeleted(true);
		tgTrainingProviderRepository.save(tgTrainingProvider);

	}

	private void saveOrUpdateTrainingProvider(TgTrainingProvider tgTrainingProvider, TrainingProviderDto dto) {

		tgTrainingProvider.setName(dto.getName());
		tgTrainingProvider.setUen(dto.getUen());
		tgTrainingProvider.setIsPdc(dto.getIsPdc());
		tgTrainingProvider.setIsMrc(dto.getIsMrc());
		tgTrainingProvider.setIsAto(dto.getIsAto());
		tgTrainingProvider.setContactPerson(dto.getContactPerson());
		tgTrainingProvider.setEmail(dto.getEmail());
		tgTrainingProvider.setContactNo(dto.getContactNo());
		tgTrainingProvider.setContactPerson1(dto.getContactPerson1());
		tgTrainingProvider.setEmail1(dto.getEmail1());
		tgTrainingProvider.setContactNo1(dto.getContactNo1());
		tgTrainingProvider.setProfileSummary(dto.getProfileSummary());
		tgTrainingProvider.setWebLink(dto.getWebLink());
		tgTrainingProvider.setSignUpLink(dto.getSignUpLink());
		tgTrainingProvider.setStatus(dto.getStatus() == null ? cache.getStatus(Codes.Statuses.USER_ACTIVE) : cache.getStatus(dto.getStatus().getKey().toString()));

		Address address = tgTrainingProvider.getAddress();
		if (address == null) {
			address = new Address();
			tgTrainingProviderRepository.save(address);
		}
		AddressDto addrDto = dto.getAddress();

		String addressType = addrDto.getType().getKey().toString();
		if (Codes.Types.ADDR_FOREIGN.equals(addressType)) {
			address.setAddressType(cache.getType(Codes.Types.ADDR_FOREIGN));
			address.setStreet(null);
			address.setBuilding(null);
			address.setBlock(null);
			address.setFloor(null);
			address.setUnit(null);
			address.setPostal(null);
			address.setForeignLine1(addrDto.getForeignLine1());
			address.setForeignLine2(addrDto.getForeignLine2());
			address.setForeignLine3(addrDto.getForeignLine3());
		} else {
			address.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			address.setStreet(addrDto.getStreet());
			address.setBuilding(addrDto.getBuilding());
			address.setBlock(addrDto.getBlock());
			address.setFloor(addrDto.getFloor());
			address.setUnit(addrDto.getUnit());
			address.setPostal(addrDto.getPostal());
			address.setForeignLine1(null);
			address.setForeignLine2(null);
			address.setForeignLine3(null);
		}
		tgTrainingProvider.setAddress(address);

	}
}
