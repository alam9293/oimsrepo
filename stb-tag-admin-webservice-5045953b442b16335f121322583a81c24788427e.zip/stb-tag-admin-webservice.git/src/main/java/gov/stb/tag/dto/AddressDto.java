package gov.stb.tag.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Type;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddressDto {

	private String street;

	private String building;

	private String block;

	private String floor;

	private String unit;

	private String postal;

	private ListableDto premisesType;

	private ListableDto type;

	private String singleLineAddress;

	private String formatted;

	private String singleLined;

	private Integer addressId;

	private String foreignLine1;

	private String foreignLine2;

	private String foreignLine3;

	private Integer downloadFlag;

	public static AddressDto buildFromAddress(Cache cache, Address address) {
		AddressDto dto = new AddressDto();
		if (address != null) {
			dto.setStreet(address.getStreet());
			dto.setBlock(address.getBlock());
			dto.setBuilding(address.getBuilding());
			dto.setFloor(address.getFloor());
			dto.setPostal(address.getPostal());
			dto.setUnit(address.getUnit());
			dto.setPremisesType((address.getPremiseType() != null) ? new ListableDto(address.getPremiseType().getKey(), cache.getLabel(address.getPremiseType(), false)) : new ListableDto());
			dto.setSingleLineAddress(address.getSingleLineAddressDisplay());
			dto.setFormatted(address.getFormattedAddressDisplay());
			dto.setSingleLined(address.getSingleLineAddressDisplay());
			dto.setAddressId(address.getId());
			dto.setForeignLine1(address.getForeignLine1());
			dto.setForeignLine2(address.getForeignLine2());
			dto.setForeignLine3(address.getForeignLine3());
			dto.setType(address.getAddressType() != null ? new ListableDto(address.getAddressType().getKey(), cache.getLabel(address.getAddressType(), false)) : new ListableDto());
		}
		return dto;
	}

	public static AddressDto buildFromAddress(Cache cache, Address address, Integer downloadFlag) {
		AddressDto dto = new AddressDto();
		if (address != null) {
			dto.setStreet(address.getStreet());
			dto.setBlock(address.getBlock());
			dto.setBuilding(address.getBuilding());
			dto.setFloor(address.getFloor());
			dto.setPostal(address.getPostal());
			dto.setUnit(address.getUnit());
			dto.setPremisesType((address.getPremiseType() != null) ? new ListableDto(address.getPremiseType().getKey(), cache.getLabel(address.getPremiseType(), false)) : new ListableDto());
			dto.setSingleLineAddress(address.getSingleLineAddressDisplay());
			dto.setFormatted(address.getFormattedAddressDisplay());
			dto.setSingleLined(address.getSingleLineAddressDisplay());
			dto.setAddressId(address.getId());
			dto.setForeignLine1(address.getForeignLine1());
			dto.setForeignLine2(address.getForeignLine2());
			dto.setForeignLine3(address.getForeignLine3());
			dto.setType(address.getAddressType() != null ? new ListableDto(address.getAddressType().getKey(), cache.getLabel(address.getAddressType(), false)) : new ListableDto());
			dto.setDownloadFlag(downloadFlag);
		}
		return dto;
	}

	public static Address buildAddressFromDto(Address addr, Type addrType, String street, String building, String block, String floor, String unit, String postal, String foreignLine1,
			String foreignLine2, String foreignLine3) {
		addr.setAddressType(addrType);
		addr.setStreet(street);
		addr.setBuilding(building);
		addr.setBlock(block);
		addr.setFloor(floor);
		addr.setUnit(unit);
		addr.setPostal(postal);
		addr.setForeignLine1(foreignLine1);
		addr.setForeignLine2(foreignLine2);
		addr.setForeignLine3(foreignLine3);

		return addr;
	}

	public static Address buildAddressDtoToModel(CacheHelper cache, AddressDto addDto, Address addmodel) {
		if (addDto != null) {
			addmodel.setPostal(addDto.getPostal());
			addmodel.setStreet(addDto.getStreet());
			addmodel.setBuilding(addDto.getBuilding());
			addmodel.setBlock(addDto.getBlock());
			addmodel.setFloor(addDto.getFloor());
			addmodel.setUnit(addDto.getUnit());
			addmodel.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
			if (addDto.getPremisesType().getKey() != null) {
				addmodel.setPremiseType(cache.getType(addDto.getPremisesType().getKey().toString()));
			}
		}
		return addmodel;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public ListableDto getPremisesType() {
		return premisesType;
	}

	public void setPremisesType(ListableDto premisesType) {
		this.premisesType = premisesType;
	}

	public String getSingleLineAddress() {
		return singleLineAddress;
	}

	public void setSingleLineAddress(String singleLineAddress) {
		this.singleLineAddress = singleLineAddress;
	}

	public String getFormatted() {
		return formatted;
	}

	public void setFormatted(String formatted) {
		this.formatted = formatted;
	}

	public String getSingleLined() {
		return singleLined;
	}

	public void setSingleLined(String singleLined) {
		this.singleLined = singleLined;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getForeignLine1() {
		return foreignLine1;
	}

	public void setForeignLine1(String foreignLine1) {
		this.foreignLine1 = foreignLine1;
	}

	public String getForeignLine2() {
		return foreignLine2;
	}

	public void setForeignLine2(String foreignLine2) {
		this.foreignLine2 = foreignLine2;
	}

	public String getForeignLine3() {
		return foreignLine3;
	}

	public void setForeignLine3(String foreignLine3) {
		this.foreignLine3 = foreignLine3;
	}

	public ListableDto getType() {
		return type;
	}

	public void setType(ListableDto type) {
		this.type = type;
	}

	public Integer getDownloadFlag() {
		return downloadFlag;
	}

	public void setDownloadFlag(Integer downloadFlag) {
		this.downloadFlag = downloadFlag;
	}
}
