package gov.stb.tag.dto;

import java.util.List;

public class AssignDto {

	private List<Integer> applicationIds;
	private Integer workflowId; // for C&E
	private Integer reAssignedOfficerId;
	private String internalRemarks;
	private List<Integer> workflowIds;

	public List<Integer> getApplicationIds() {
		return applicationIds;
	}

	public void setApplicationIds(List<Integer> applicationIds) {
		this.applicationIds = applicationIds;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public Integer getReAssignedOfficerId() {
		return reAssignedOfficerId;
	}

	public void setReAssignedOfficerId(Integer reAssignedOfficerId) {
		this.reAssignedOfficerId = reAssignedOfficerId;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public List<Integer> getWorkflowIds() {
		return workflowIds;
	}

	public void setWorkflowIds(List<Integer> workflowIds) {
		this.workflowIds = workflowIds;
	}
}
