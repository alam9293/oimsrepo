package gov.stb.tag.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.wiz.model.api.AuditableEntity;

import gov.stb.tag.model.User;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.util.DateUtil;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuditableEntityDto {

	private String createdBy;
	private LocalDateTime createdDate;

	private String updatedBy;
	private LocalDateTime updatedDate;

	public <T extends AuditableEntityDto> T buildEditorDetailsFromModel(AuditableEntity entity, T dto, UserRepository userRepository) {
		User createdBy = userRepository.getUserByLoginId(entity.getCreatedBy());
		User updatedBy = userRepository.getUserByLoginId(entity.getUpdatedBy());

		dto.setCreatedBy(createdBy == null ? entity.getCreatedBy() : createdBy.getName());
		dto.setCreatedDate(entity.getCreatedDate());
		if (!DateUtil.isEqualDateTimeUpToSec(entity.getCreatedDate(), entity.getUpdatedDate())) {
			dto.setUpdatedBy(updatedBy == null ? entity.getUpdatedBy() : updatedBy.getName());
			dto.setUpdatedDate(entity.getUpdatedDate());
		}

		return dto;

	}

	public <T extends AuditableEntityDto> T buildEditorDetails(String createdBy, LocalDateTime createdDate, String updatedBy, LocalDateTime updatedDate, T dto) {
		dto.setCreatedBy(createdBy);
		dto.setCreatedDate(createdDate);
		dto.setUpdatedBy(updatedBy);
		dto.setUpdatedDate(updatedDate);
		return dto;

	}

	public String getCreatedBy() {
		return createdBy;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

}
