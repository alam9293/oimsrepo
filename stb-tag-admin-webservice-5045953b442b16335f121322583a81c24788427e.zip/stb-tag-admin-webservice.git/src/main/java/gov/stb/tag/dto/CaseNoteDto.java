package gov.stb.tag.dto;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class CaseNoteDto {
	private Integer applicationId;
	private Integer workflowId;
	private Integer payReqId;
	private String internalRemarks;
	private List<MultipartFile> files;
	private List<String> fileDescription;

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public Integer getPayReqId() {
		return payReqId;
	}

	public void setPayReqId(Integer payReqId) {
		this.payReqId = payReqId;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public List<MultipartFile> getFiles() {
		return files;
	}

	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}

	public List<String> getFileDescription() {
		return fileDescription;
	}

	public void setFileDescription(List<String> fileDescription) {
		this.fileDescription = fileDescription;
	}
}
