package gov.stb.tag.dto;

import gov.stb.tag.annotation.MapProjection;

public class TravelAgentBasicDto {

	@MapProjection(path = "travelAgent.id")
	private Integer id;

	@MapProjection(path = "travelAgent.name")
	private String name;

	@MapProjection(path = "travelAgent.uen")
	private String uen;

	@MapProjection(path = "id")
	private Integer licenceId;

	@MapProjection(path = "licenceNo")
	private String licenceNo;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}


}
