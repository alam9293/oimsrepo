package gov.stb.tag.dto.auth;

public class AuthPubRequestDto {

	private String authSecret;

	private String iamsIdToken;

	private String spIdToken;

	public String getAuthSecret() {
		return authSecret;
	}

	public void setAuthSecret(String authSecret) {
		this.authSecret = authSecret;
	}

	public String getIamsIdToken() {
		return iamsIdToken;
	}

	public void setIamsIdToken(String iamsIdToken) {
		this.iamsIdToken = iamsIdToken;
	}

	public String getSpIdToken() {
		return spIdToken;
	}

	public void setSpIdToken(String spIdToken) {
		this.spIdToken = spIdToken;
	}

}