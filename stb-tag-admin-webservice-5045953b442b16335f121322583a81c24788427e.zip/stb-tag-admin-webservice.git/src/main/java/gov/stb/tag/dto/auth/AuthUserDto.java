package gov.stb.tag.dto.auth;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.dashboard.LicenseeDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;

public class AuthUserDto {

	private Integer id;

	private String loginId;

	private String name;

	private String uen;

	private ListableDto userType;

	private LicenseeDto licensee;

	private ListableDto status;

	private ListableDto selectedRole;

	private List<ListableDto> roles;

	private Set<ListableDto> permissions;

	private LocalDateTime lastLoginDate;

	private boolean isTpPdc;

	private boolean isTpMrc;

	private boolean isToChangePassword;

	private ListableDto department;

	public AuthUserDto() {

	}

	public static AuthUserDto buildFromUser(Cache cache, User user, Role selectedRole) {
		AuthUserDto dto = new AuthUserDto();
		dto.setIsToChangePassword(user.isToChangePassword());
		dto.setId(user.getId());
		dto.setLoginId(user.getLoginId());
		dto.setName(user.getName());
		dto.setUen(user.getUen());
		dto.setUserType(new ListableDto(user.getType().getCode(), cache.getLabel(user.getType(), false)));
		dto.setStatus(new ListableDto(user.getStatus().getCode(), cache.getLabel(user.getStatus(), false)));
		dto.setLastLoginDate(user.getLastLoginDate());
		if (!Objects.isNull(user.getType())) {
			LicenseeDto licensee = new LicenseeDto();
			if (Codes.UserTypes.USER_PUBLIC.equals(user.getType().getCode()) && user.getTravelAgent() != null) {
				TravelAgent ta = user.getTravelAgent();
				licensee.setName(ta.getName());
				licensee.setLicenceNumber(ta.getLicence().getLicenceNo());
				licensee.setStatus(new ListableDto(ta.getLicence().getStatus().getCode(), cache.getLabel(ta.getLicence().getStatus(), false)));
				dto.setLicensee(licensee);
			} else if (Codes.UserTypes.USER_PUBLIC.equals(user.getType().getCode()) || Codes.UserTypes.USER_PUBLIC_PORTAL.equals(user.getType().getCode())) {
				if (user.getTouristGuide() != null) {
					TouristGuide tg = user.getTouristGuide();
					licensee.setName(tg.getName());
					licensee.setLicenceNumber(tg.getLicence().getLicenceNo());
					licensee.setStatus(new ListableDto(tg.getLicence().getStatus().getCode(), cache.getLabel(tg.getLicence().getStatus(), false)));
				}
				dto.setLicensee(licensee);
			}

			if (Codes.UserTypes.USER_PUBLIC.equals(user.getType().getCode()) && user.getTgTrainingProvider() != null) {
				TgTrainingProvider ttp = user.getTgTrainingProvider();
				dto.setIsTpPdc(ttp.isPdc());
				dto.setIsTpMrc(ttp.isMrc());
			}
		}

		// set selected role
		Role currentRole = Objects.isNull(selectedRole) ? user.getDefaultRole() : selectedRole;
		dto.setSelectedRole(new ListableDto(currentRole.getCode(), cache.getLabel(cache.getRole(currentRole.getCode()), false)));

		// set permission based on this user and current selected role
		if (!Objects.isNull(currentRole)) {
			dto.setPermissions(Sets.newHashSet());
			currentRole.getFunctions().forEach(f -> dto.getPermissions().add(new ListableDto(f.getCode(), f.getLabel())));
		}

		// set all roles that are assigned to this user
		dto.setRoles(Lists.newArrayList());
		if (user.getDepartment() != null) {
			dto.setDepartment(new ListableDto(user.getDepartment().getCode(), cache.getLabel(user.getDepartment(), false)));
		}
		user.getRoles().forEach(r -> dto.getRoles().add(new ListableDto(r.getCode(), r.getLabel(), null, null, getRoleType(r.getCode()))));
		Collections.sort(dto.getRoles(), Comparator.comparing(ListableDto::getLabel));
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public ListableDto getUserType() {
		return userType;
	}

	public void setUserType(ListableDto userType) {
		this.userType = userType;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public ListableDto getSelectedRole() {
		return selectedRole;
	}

	public void setSelectedRole(ListableDto selectedRole) {
		this.selectedRole = selectedRole;
	}

	public List<ListableDto> getRoles() {
		return roles;
	}

	public void setRoles(List<ListableDto> roles) {
		this.roles = roles;
	}

	public Set<ListableDto> getPermissions() {
		return permissions;
	}

	public void setPermissions(Set<ListableDto> permissions) {
		this.permissions = permissions;
	}

	public LocalDateTime getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(LocalDateTime lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public LicenseeDto getLicensee() {
		return licensee;
	}

	public void setLicensee(LicenseeDto licensee) {
		this.licensee = licensee;
	}

	public boolean isTpPdc() {
		return isTpPdc;
	}

	public void setIsTpPdc(boolean isTpPdc) {
		this.isTpPdc = isTpPdc;
	}

	public boolean isTpMrc() {
		return isTpMrc;
	}

	public void setIsTpMrc(boolean isTpMrc) {
		this.isTpMrc = isTpMrc;
	}

	public boolean isToChangePassword() {
		return isToChangePassword;
	}

	public void setIsToChangePassword(boolean isToChangePassword) {
		this.isToChangePassword = isToChangePassword;
	}

	private static String getRoleType(String roleCode) {
		if (roleCode.startsWith("TA_")) {
			return "TA";
		} else if (roleCode.startsWith("TG_")) {
			return "TG";
		} else if (roleCode.startsWith("CNE_")) {
			return "CNE";
		} else if (roleCode.startsWith("FIN")) {
			return "FIN";
		} else if (roleCode.startsWith("SYS")) {
			return "SYS";
		} else {
			return "OTH";
		}
	}

	public ListableDto getDepartment() {
		return department;
	}

	public void setDepartment(ListableDto department) {
		this.department = department;
	}
}
