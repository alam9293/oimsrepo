package gov.stb.tag.dto.bulletin;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Bulletin;
import gov.stb.tag.model.CategoryListing;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BulletinCatgoryListingDto {

	private Integer id;

	private Boolean isPrivate;

	private LocalDate effectiveDate;

	private LocalDate expiryDate;

	private String content;

	private String title;

	private String categoryTitle;

	private String typeCode;

	private List<FileDto> files = new ArrayList<>();

	private String updatedBy;

	private LocalDateTime updatedDate;

	private Boolean isDelisted;

	private Boolean isCurrentlyDisplay;

	private Integer fileId;

	private String hash;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategoryTitle() {
		return categoryTitle;
	}

	public void setCategoryTitle(String categoryTitle) {
		this.categoryTitle = categoryTitle;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Boolean getIsPrivate() {
		return isPrivate;
	}

	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public Boolean getIsDelisted() {
		return isDelisted;
	}

	public void setIsDelisted(Boolean isDelisted) {
		this.isDelisted = isDelisted;
	}

	public Boolean getIsCurrentlyDisplay() {
		return isCurrentlyDisplay;
	}

	public void setIsCurrentlyDisplay(Boolean isCurrentlyDisplay) {
		this.isCurrentlyDisplay = isCurrentlyDisplay;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public static BulletinCatgoryListingDto buildFromBulletin(Cache cache, Bulletin bulletin) {

		if (bulletin != null) {
			BulletinCatgoryListingDto dto = new BulletinCatgoryListingDto();

			dto.setId(bulletin.getId());
			dto.setContent(bulletin.getContent());
			dto.setEffectiveDate(bulletin.getEffectiveDate());
			dto.setTitle(bulletin.getTitle());
			dto.setTypeCode(bulletin.getType().getCode());
			dto.setUpdatedBy(bulletin.getUpdatedBy());
			dto.setUpdatedDate(bulletin.getUpdatedDate());
			dto.setExpiryDate(bulletin.getExpiryDate());
			dto.setIsPrivate(bulletin.isPrivate());
			dto.setCategoryTitle(Codes.InfohubLabel.INFOHUB_BULLETIN_LABEL);
			// for file (set as empty
			dto.setFileId(0);
			dto.setHash("");

			return dto;
		}

		return null;
	}

	// REUSE FOR INFOHUB
	public static BulletinCatgoryListingDto buildFromBulletin(Cache cache, CategoryListing listing) {

		if (listing != null) {
			BulletinCatgoryListingDto dto = new BulletinCatgoryListingDto();

			dto.setId(listing.getId());
			// dto.setContent(listing.getContent());
			dto.setEffectiveDate(listing.getEffectiveDate());
			dto.setTitle(listing.getTitle());
			dto.setTypeCode(listing.getType().getCode());
			dto.setUpdatedBy(listing.getUpdatedBy());
			dto.setUpdatedDate(listing.getUpdatedDate());
			dto.setExpiryDate(listing.getExpiryDate());
			dto.setCategoryTitle(listing.getCategories().getTitle());

			// for file
			dto.setFileId(listing.getFileId());
			dto.setHash(listing.getHash());
			// dto.setIsPrivate(listing.isPrivate());

			return dto;
		}

		return null;
	}
}
