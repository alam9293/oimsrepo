package gov.stb.tag.dto.bulletin;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BulletinSearchDto extends SearchDto {

	private String type;

	private String title;

	private String isPrivate;

	private String isDelisted;

	private String isCurrentlyDisplay;

	private LocalDate effectiveDateFrom;

	private LocalDate effectiveDateTo;

	private LocalDate expiryDateFrom;

	private LocalDate expiryDateTo;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIsPrivate() {
		return isPrivate;
	}

	public void setIsPrivate(String isPrivate) {
		this.isPrivate = isPrivate;
	}

	public String getIsDelisted() {
		return isDelisted;
	}

	public void setIsDelisted(String isDelisted) {
		this.isDelisted = isDelisted;
	}

	public String getIsCurrentlyDisplay() {
		return isCurrentlyDisplay;
	}

	public void setIsCurrentlyDisplay(String isCurrentlyDisplay) {
		this.isCurrentlyDisplay = isCurrentlyDisplay;
	}

	public LocalDate getEffectiveDateFrom() {
		return effectiveDateFrom;
	}

	public void setEffectiveDateFrom(LocalDate effectiveDateFrom) {
		this.effectiveDateFrom = effectiveDateFrom;
	}

	public LocalDate getEffectiveDateTo() {
		return effectiveDateTo;
	}

	public void setEffectiveDateTo(LocalDate effectiveDateTo) {
		this.effectiveDateTo = effectiveDateTo;
	}

	public LocalDate getExpiryDateFrom() {
		return expiryDateFrom;
	}

	public void setExpiryDateFrom(LocalDate expiryDateFrom) {
		this.expiryDateFrom = expiryDateFrom;
	}

	public LocalDate getExpiryDateTo() {
		return expiryDateTo;
	}

	public void setExpiryDateTo(LocalDate expiryDateTo) {
		this.expiryDateTo = expiryDateTo;
	}
}
