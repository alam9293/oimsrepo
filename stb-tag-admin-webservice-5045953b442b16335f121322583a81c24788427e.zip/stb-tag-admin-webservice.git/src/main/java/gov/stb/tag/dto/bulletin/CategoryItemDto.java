package gov.stb.tag.dto.bulletin;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Category;
import gov.stb.tag.model.CategoryListing;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CategoryItemDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "isPrivate")
	private Boolean isPrivate;

	@MapProjection(path = "effectiveDate")
	private LocalDate effectiveDate;

	@MapProjection(path = "expiryDate")
	private LocalDate expiryDate;

	// @MapProjection(path = "content")
	// private String content;

	@MapProjection(path = "title")
	private String title;

	@MapProjection(path = "type.code")
	private String typeCode;

	private List<FileDto> files = new ArrayList<>();

	@MapProjection(path = "updatedBy")
	private String updatedBy;

	@MapProjection(path = "updatedDate")
	private LocalDateTime updatedDate;

	@MapProjection(path = "isDelisted")
	private Boolean isDelisted;

	private Boolean isCurrentlyDisplay;

	private Integer fileId;

	private String originalFilename;

	private String hash;

	private List<CategoryListDto> categoryList = new ArrayList<CategoryListDto>();

	public static CategoryItemDto buildFromCategory(Cache cache, Category category, List<CategoryListing> categoryListing) {

		if (category != null) {
			CategoryItemDto dto = new CategoryItemDto();

			dto.setId(category.getId());
			// dto.setContent(bulletin.getContent());
			dto.setEffectiveDate(category.getEffectiveDate());
			dto.setTitle(category.getTitle());
			// dto.setTypeCode(category.getType().getCode());
			dto.setUpdatedBy(category.getUpdatedBy());
			dto.setUpdatedDate(category.getUpdatedDate());
			dto.setExpiryDate(category.getExpiryDate());
			dto.setIsPrivate(category.isPrivate());

			dto.setFileId(category.getFileId());
			dto.setHash(category.getHash());
			dto.setOriginalFilename(category.getOriginalFilename());
			for (CategoryListing items : categoryListing) {
				CategoryListDto i = CategoryListDto.buildFromCategoryListing(items);
				dto.categoryList.add(i);
			}
			return dto;
		}

		return null;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/*
	 * public String getContent() { return content; }
	 * 
	 * public void setContent(String content) { this.content = content; }
	 */

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public List<CategoryListDto> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<CategoryListDto> categoryListDtoList) {
		this.categoryList = categoryListDtoList;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Boolean getIsPrivate() {
		return isPrivate;
	}

	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public Boolean getIsDelisted() {
		return isDelisted;
	}

	public void setIsDelisted(Boolean isDelisted) {
		this.isDelisted = isDelisted;
	}

	public Boolean getIsCurrentlyDisplay() {
		return isCurrentlyDisplay;
	}

	public void setIsCurrentlyDisplay(Boolean isCurrentlyDisplay) {
		this.isCurrentlyDisplay = isCurrentlyDisplay;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public String getOriginalFilename() {
		return originalFilename;
	}

	public void setOriginalFilename(String originalFilename) {
		this.originalFilename = originalFilename;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}
}
