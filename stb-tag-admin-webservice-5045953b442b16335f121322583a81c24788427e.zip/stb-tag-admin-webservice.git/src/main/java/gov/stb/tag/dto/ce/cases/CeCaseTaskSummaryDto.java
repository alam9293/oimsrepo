package gov.stb.tag.dto.ce.cases;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.CeCaseDecision;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.CeCaseRescind;
import gov.stb.tag.model.PaymentRequest;

public class CeCaseTaskSummaryDto {

	private String offenderName;
	private String offenderUenUin;
	private String offenderLicenceNo;
	private List<CeProvisionDto> offenceProvisions;
	private List<String> taskDetails;
	private Set<FileDto> letterIssuances;

	// for case task logs
	private LocalDateTime approvedDate;
	private ListableDto caseTaskType;
	private ListableDto caseTaskStatus;
	private Integer workflowId;

	public CeCaseTaskSummaryDto() {

	}

	public static List<CeCaseTaskSummaryDto> populateRecommendationCaseTaskSummaryDetails(List<CeCaseRecommendation> recommendations, CeCasesDto ceCasesDto, CeCaseHelper ceCaseHelper) {

		List<CeCaseInfringer> ceCaseInfringers = new ArrayList<>();
		Set<String> infringerUenUins = new HashSet<>();
		for (CeCaseRecommendation recomm : recommendations) {
			CeCaseInfringer infringer = recomm.getCeCaseInfringement().getCeCaseInfringer();
			infringerUenUins.add(infringer.getUenUin());
			ceCaseInfringers.add(infringer);
		}

		List<CeCaseTaskSummaryDto> dtoList = new ArrayList<>();

		for (String uenUin : infringerUenUins) {
			CeCaseInfringer ceCaseInfringer = ceCaseInfringers.stream().filter(u -> u.getUenUin().equals(uenUin)).findAny().get();

			CeCaseTaskSummaryDto dto = new CeCaseTaskSummaryDto();
			dto.setOffenderUenUin(ceCaseInfringer.getUenUin());
			dto.setOffenderName(ceCaseInfringer.getName());
			dto.setOffenderLicenceNo(ceCaseInfringer.getLicence() != null ? ceCaseInfringer.getLicence().getLicenceNo() : null);

			List<CeProvisionDto> offenceProvisions = new ArrayList<>();
			List<String> taskDetails = new ArrayList<>();
			Set<FileDto> letterIssuances = new HashSet<>();

			List<CeInfringementDto> infringements = ceCasesDto.getInfringements().stream().filter(infringement -> infringement.getOffenderUenUin().equals(ceCaseInfringer.getUenUin()))
					.collect(Collectors.toList());
			for (CeInfringementDto ceInfringementDto : infringements) {
				if (!ceInfringementDto.getIsCompleted()) {
					Optional<CeCaseRecommendation> recommOptional = recommendations.stream().filter(u -> u.getCeCaseInfringement().getId().equals(ceInfringementDto.getInfringementId())).findAny();
					if (recommOptional.isPresent()) {
						CeCaseRecommendation recommendation = recommOptional.get();

						CeProvisionDto ceProvisionDto = ceInfringementDto.getOffenceProvision();
						offenceProvisions.add(ceProvisionDto);

						ListableDto chapter = ceProvisionDto.getChapter();
						String taskDetail = ceCaseHelper.populateInfringementTaskDetails(chapter.getKeyString(), ceProvisionDto.getSection(), recommendation.getOutcome(),
								recommendation.getPenaltyAmount(), recommendation.getPenaltyStatusStartDate(), recommendation.getPenaltyStatusEndDate(), null, null, null);
						taskDetails.add(taskDetail);

						FileDto letter = ceInfringementDto.getRecommendation().getLetterIssuance();
						if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
							letterIssuances.add(letter);
						}
					}
				}
			}

			dto.setOffenceProvisions(offenceProvisions);
			dto.setTaskDetails(taskDetails);
			dto.setLetterIssuances(letterIssuances);
			dtoList.add(dto);
		}

		return dtoList;
	}

	public static List<CeCaseTaskSummaryDto> populateDecisionCaseTaskSummaryDetails(List<CeCaseDecision> decisions, CeCasesDto ceCasesDto, CeCaseHelper ceCaseHelper) {

		Set<CeCaseInfringer> ceCaseInfringers = new HashSet<>();
		for (CeCaseDecision decision : decisions) {
			ceCaseInfringers.add(decision.getCeCaseInfringement().getCeCaseInfringer());
		}

		List<CeCaseTaskSummaryDto> dtoList = new ArrayList<>();

		for (CeCaseInfringer ceCaseInfringer : ceCaseInfringers) {
			CeCaseTaskSummaryDto dto = new CeCaseTaskSummaryDto();
			dto.setOffenderUenUin(ceCaseInfringer.getUenUin());
			dto.setOffenderName(ceCaseInfringer.getName());

			List<CeProvisionDto> offenceProvisions = new ArrayList<>();
			List<String> taskDetails = new ArrayList<>();
			Set<FileDto> letterIssuances = new HashSet<>();

			List<CeInfringementDto> infringements = ceCasesDto.getInfringements().stream().filter(infringement -> infringement.getOffenderUenUin().equals(ceCaseInfringer.getUenUin()))
					.collect(Collectors.toList());
			for (CeInfringementDto ceInfringementDto : infringements) {
				Optional<CeCaseDecision> decOptional = decisions.stream().filter(u -> u.getCeCaseInfringement().getId().equals(ceInfringementDto.getInfringementId())).findAny();
				if (decOptional.isPresent()) {
					CeCaseDecision decision = decOptional.get();

					CeProvisionDto ceProvisionDto = ceInfringementDto.getOffenceProvision();
					offenceProvisions.add(ceProvisionDto);

					ListableDto chapter = ceProvisionDto.getChapter();
					String taskDetail = ceCaseHelper.populateInfringementTaskDetails(chapter.getKeyString(), ceProvisionDto.getSection(), decision.getOutcome(), decision.getPenaltyAmount(),
							decision.getPenaltyStatusStartDate(), decision.getPenaltyStatusEndDate(), null, null, null);
					taskDetails.add(taskDetail);

					if (ceInfringementDto.getDecision() != null) {
						FileDto letter = ceInfringementDto.getDecision().getLetterIssuance();
						if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
							letterIssuances.add(letter);
						}
					}

				}
			}

			dto.setOffenceProvisions(offenceProvisions);
			dto.setTaskDetails(taskDetails);
			dto.setLetterIssuances(letterIssuances);
			dtoList.add(dto);
		}

		return dtoList;
	}

	public static List<CeCaseTaskSummaryDto> populateAppealCaseTaskSummaryDetails(List<CeCaseAppeal> appeals, CeCasesDto ceCasesDto, CeCaseHelper ceCaseHelper) {

		Set<CeCaseInfringer> ceCaseInfringers = new HashSet<>();
		for (CeCaseAppeal appeal : appeals) {
			ceCaseInfringers.add(appeal.getCeCaseInfringement().getCeCaseInfringer());
		}

		List<CeCaseTaskSummaryDto> dtoList = new ArrayList<>();

		for (CeCaseInfringer ceCaseInfringer : ceCaseInfringers) {
			CeCaseTaskSummaryDto dto = new CeCaseTaskSummaryDto();
			dto.setOffenderUenUin(ceCaseInfringer.getUenUin());
			dto.setOffenderName(ceCaseInfringer.getName());

			List<CeProvisionDto> offenceProvisions = new ArrayList<>();
			List<String> taskDetails = new ArrayList<>();
			Set<FileDto> letterIssuances = new HashSet<>();

			List<CeInfringementDto> infringements = ceCasesDto.getInfringements().stream().filter(infringement -> infringement.getOffenderUenUin().equals(ceCaseInfringer.getUenUin()))
					.collect(Collectors.toList());
			for (CeInfringementDto ceInfringementDto : infringements) {
				Optional<CeCaseAppeal> appealOptional = appeals.stream().filter(u -> u.getCeCaseInfringement().getId().equals(ceInfringementDto.getInfringementId())).findAny();
				if (appealOptional.isPresent()) {
					CeCaseAppeal appeal = appealOptional.get();

					CeProvisionDto ceProvisionDto = ceInfringementDto.getOffenceProvision();
					offenceProvisions.add(ceProvisionDto);

					ListableDto chapter = ceProvisionDto.getChapter();
					String taskDetail = null;
					if (appeal.getResult() != null) {
						taskDetail = "MTI Appeal Result: ".concat(appeal.getResult().getLabel()).concat("; ");
						taskDetail = taskDetail.concat(System.lineSeparator());
						taskDetail = taskDetail.concat(ceCaseHelper.populateInfringementTaskDetails(chapter.getKeyString(), ceProvisionDto.getSection(), appeal.getOutcome(), appeal.getPenaltyAmount(),
								appeal.getPenaltyStatusStartDate(), appeal.getPenaltyStatusEndDate(), null, null, null));

						// populate any payment refund/waive details
						CeCaseDecision lastDecision = appeal.getCeCaseInfringement().getLastDecision();
						if (lastDecision.getBillRefNo() != null && !lastDecision.hasInProgressAppeal()) {
							// get payment status
							PaymentRequest payReq = ceCaseHelper.getNodPaymentDetails(lastDecision.getBillRefNo());
							if (payReq != null) {

								BigDecimal amountDiff = null;
								if (Entities.equals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_AFP) && appeal.getPenaltyAmount().compareTo(payReq.getPayableAmount()) < 0) {
									// Amount reduced
									amountDiff = payReq.getPayableAmount().subtract(appeal.getPenaltyAmount());
								} else {
									// Penalty cancelled
									amountDiff = payReq.getPayableAmount();
								}

								taskDetail = taskDetail.concat(System.lineSeparator());
								taskDetail = taskDetail.concat(ceCaseHelper.populatePaymentRefundOrWaiveTaskDetails(amountDiff, payReq.getPayableAmount(), payReq.getStatus(), payReq.getBillRefNo()));
							}
						}

					} else {
						taskDetail = ceCaseHelper.populateInfringementTaskDetails(chapter.getKeyString(), ceProvisionDto.getSection(), appeal.getOutcome(), appeal.getPenaltyAmount(),
								appeal.getPenaltyStatusStartDate(), appeal.getPenaltyStatusEndDate(), null, null, null);
					}
					taskDetails.add(taskDetail);

					if (ceInfringementDto.getResult() != null) {
						FileDto letter = ceInfringementDto.getResult().getLetterIssuance();
						if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
							letterIssuances.add(letter);
						}
					}

				}
			}

			dto.setOffenceProvisions(offenceProvisions);
			dto.setTaskDetails(taskDetails);
			dto.setLetterIssuances(letterIssuances);
			dtoList.add(dto);
		}

		return dtoList;
	}

	public static List<CeCaseTaskSummaryDto> populateRescindCaseTaskSummaryDetails(List<CeCaseRescind> rescinds, CeCasesDto ceCasesDto, CeCaseHelper ceCaseHelper) {

		Set<CeCaseInfringer> ceCaseInfringers = new HashSet<>();
		for (CeCaseRescind rescind : rescinds) {
			ceCaseInfringers.add(rescind.getCeCaseInfringement().getCeCaseInfringer());
		}

		List<CeCaseTaskSummaryDto> dtoList = new ArrayList<>();

		for (CeCaseInfringer ceCaseInfringer : ceCaseInfringers) {
			CeCaseTaskSummaryDto dto = new CeCaseTaskSummaryDto();
			dto.setOffenderUenUin(ceCaseInfringer.getUenUin());
			dto.setOffenderName(ceCaseInfringer.getName());

			List<CeProvisionDto> offenceProvisions = new ArrayList<>();
			List<String> taskDetails = new ArrayList<>();
			Set<FileDto> letterIssuances = new HashSet<>();

			List<CeInfringementDto> infringements = ceCasesDto.getInfringements().stream().filter(infringement -> infringement.getOffenderUenUin().equals(ceCaseInfringer.getUenUin()))
					.collect(Collectors.toList());
			for (CeInfringementDto ceInfringementDto : infringements) {
				Optional<CeCaseRescind> rescindOptional = rescinds.stream().filter(u -> u.getCeCaseInfringement().getId().equals(ceInfringementDto.getInfringementId())).findAny();
				if (rescindOptional.isPresent()) {
					CeProvisionDto ceProvisionDto = ceInfringementDto.getOffenceProvision();
					offenceProvisions.add(ceProvisionDto);

					ListableDto chapter = ceProvisionDto.getChapter();
					String taskDetail = ceCaseHelper.populateInfringementTaskDetails(chapter.getKeyString(), ceProvisionDto.getSection(), null, null, null, null, null, null, null);
					taskDetails.add(taskDetail);

					if (ceInfringementDto.getRescind() != null) {
						FileDto letter = ceInfringementDto.getRescind().getLetterIssuance();
						if (letter != null && (CollectionUtils.isEmpty(letterIssuances) || letterIssuances.stream().filter(u -> u.getId().equals(letter.getId())).findAny().isEmpty())) {
							letterIssuances.add(letter);
						}
					}

				}

			}

			dto.setOffenceProvisions(offenceProvisions);
			dto.setTaskDetails(taskDetails);
			dto.setLetterIssuances(letterIssuances);
			dtoList.add(dto);
		}

		return dtoList;
	}

	public String getOffenderName() {
		return offenderName;
	}

	public void setOffenderName(String offenderName) {
		this.offenderName = offenderName;
	}

	public String getOffenderUenUin() {
		return offenderUenUin;
	}

	public void setOffenderUenUin(String offenderUenUin) {
		this.offenderUenUin = offenderUenUin;
	}

	public String getOffenderLicenceNo() {
		return offenderLicenceNo;
	}

	public void setOffenderLicenceNo(String offenderLicenceNo) {
		this.offenderLicenceNo = offenderLicenceNo;
	}

	public List<CeProvisionDto> getOffenceProvisions() {
		return offenceProvisions;
	}

	public void setOffenceProvisions(List<CeProvisionDto> offenceProvisions) {
		this.offenceProvisions = offenceProvisions;
	}

	public List<String> getTaskDetails() {
		return taskDetails;
	}

	public void setTaskDetails(List<String> taskDetails) {
		this.taskDetails = taskDetails;
	}

	public Set<FileDto> getLetterIssuances() {
		return letterIssuances;
	}

	public void setLetterIssuances(Set<FileDto> letterIssuances) {
		this.letterIssuances = letterIssuances;
	}

	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

	public ListableDto getCaseTaskType() {
		return caseTaskType;
	}

	public void setCaseTaskType(ListableDto caseTaskType) {
		this.caseTaskType = caseTaskType;
	}

	public ListableDto getCaseTaskStatus() {
		return caseTaskStatus;
	}

	public void setCaseTaskStatus(ListableDto caseTaskStatus) {
		this.caseTaskStatus = caseTaskStatus;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

}
