package gov.stb.tag.dto.ce.cases;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowFile;
import gov.stb.tag.model.WorkflowStepAssignment;

public class CeCaseTaskWorkflowDto {

	private Integer workflowId;
	private ListableDto caseTaskStatus = new ListableDto();
	private String workflowAssessment;
	private String internalRemarks;
	private String lastActionBy;

	private Integer assigneeId;
	private String assigneeName;
	private Long sla;
	private ListableDto appOrWkflwType;
	private String appOrWkflwTypeCode;

	private Integer approverId;
	private Integer supporterId;
	private List<FileDto> workflowFiles;
	private List<FileDto> deletedWorkflowFiles;

	private Boolean isAssignee = false; // to indicate whether current user is assignee
	private Boolean isFinalApproval = false; // to indicate whether current status is in final approval stage
	private Boolean isInGroup = false; // to indicate whether current user is in support / approval group
	private Boolean isFromCreateCaseTask = false; // used this to check the save action is from case task dialog

	// to display case summary
	private List<CeCaseTaskSummaryDto> caseTaskSummary;

	public CeCaseTaskWorkflowDto() {
	}

	public CeCaseTaskWorkflowDto(Workflow workflow, FileHelper fileHelper, CacheHelper cache, WorkflowHelper workflowHelper, User currentUser) {
		if (workflow != null) {
			this.appOrWkflwTypeCode = workflow.getType().getCode();
			this.appOrWkflwType = new ListableDto(workflow.getType().getCode(), cache.getLabel(workflow.getType(), false));
			this.workflowId = workflow.getId();
			this.workflowAssessment = workflow.getDescription();
			this.sla = workflow.getSlaExpiryDate() != null ? ChronoUnit.DAYS.between(LocalDate.now(), workflow.getSlaExpiryDate()) : null;
			this.isAssignee = workflow.getAssignee() != null && workflow.getAssignee().getId().equals(currentUser.getId()) ? true : false;
			this.isFinalApproval = workflowHelper.isFinalApproval(workflow);

			User assignee = workflow.getAssignee();
			if (assignee != null) {
				this.assigneeId = assignee.getId();
				this.assigneeName = assignee.getName();
			}

			WorkflowAction lastAction = workflow.getLastAction();
			if (lastAction != null) {
				this.caseTaskStatus = new ListableDto(lastAction.getStatus().getCode(), cache.getLabel(lastAction.getStatus(), false));

				if (!workflowHelper.isFirstStep(workflow)) {
					this.internalRemarks = lastAction.getInternalRemarks();
					this.lastActionBy = lastAction.getCreatedBy();
				}

				// overwrite SLA by if current workflow status is routed back
				if (Entities.equals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_ROUTED)) {
					Optional<CeTask> ceTaskOptional = workflow.getCeTasks().stream().filter(wk -> !Entities.equals(wk.getStatus(), Codes.CeTaskStatus.CE_TASK_COMPLETED)).findFirst();
					if (ceTaskOptional.isPresent()) {
						CeTask ceTask = ceTaskOptional.get();
						this.sla = ChronoUnit.DAYS.between(LocalDate.now(), ceTask.getSlaExpiryDate());
					}
				}
			}

			List<WorkflowStepAssignment> workflowStepAssignments = workflow.getWorkflowStepAssignments();
			if (CollectionUtils.isNotEmpty(workflowStepAssignments)) {
				Optional<WorkflowStepAssignment> supporterOptional = workflowStepAssignments.stream()
						.filter(u -> u.getWorkflowStep().getStartStatus().getCode().equals(Codes.Statuses.CE_WKFLW_PEND_SUPP)).findAny();
				if (supporterOptional.isPresent()) {
					this.supporterId = supporterOptional.get().getUser().getId();
				}

				Optional<WorkflowStepAssignment> approverOptional = workflowStepAssignments.stream()
						.filter(u -> u.getWorkflowStep().getStartStatus().getCode().equals(Codes.Statuses.CE_WKFLW_PEND_APPR)).findAny();
				if (approverOptional.isPresent()) {
					this.approverId = approverOptional.get().getUser().getId();
				}
			}

			Set<WorkflowFile> workflowFiles = workflow.getWorkflowFiles();
			if (!workflowFiles.isEmpty()) {
				List<FileDto> files = new ArrayList<>();
				workflowFiles.forEach(u -> {
					FileDto fileDto = FileDto.buildFromFile(u.getFile(), null, fileHelper);
					if (u.getDocumentType() != null) {
						fileDto.setDocType(u.getDocumentType().getCode());
						fileDto.setDocumentTypeLabel(u.getDocumentType().getLabel());
					}
					files.add(fileDto);
				});

				this.workflowFiles = files;
			}
		}
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public ListableDto getCaseTaskStatus() {
		return caseTaskStatus;
	}

	public void setCaseTaskStatus(ListableDto caseTaskStatus) {
		this.caseTaskStatus = caseTaskStatus;
	}

	public String getWorkflowAssessment() {
		return workflowAssessment;
	}

	public void setWorkflowAssessment(String workflowAssessment) {
		this.workflowAssessment = workflowAssessment;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public Integer getAssigneeId() {
		return assigneeId;
	}

	public void setAssigneeId(Integer assigneeId) {
		this.assigneeId = assigneeId;
	}

	public String getAssigneeName() {
		return assigneeName;
	}

	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	public Long getSla() {
		return sla;
	}

	public void setSla(Long sla) {
		this.sla = sla;
	}

	public ListableDto getAppOrWkflwType() {
		return appOrWkflwType;
	}

	public void setAppOrWkflwType(ListableDto appOrWkflwType) {
		this.appOrWkflwType = appOrWkflwType;
	}

	public String getAppOrWkflwTypeCode() {
		return appOrWkflwTypeCode;
	}

	public void setAppOrWkflwTypeCode(String appOrWkflwTypeCode) {
		this.appOrWkflwTypeCode = appOrWkflwTypeCode;
	}

	public Integer getApproverId() {
		return approverId;
	}

	public void setApproverId(Integer approverId) {
		this.approverId = approverId;
	}

	public Integer getSupporterId() {
		return supporterId;
	}

	public void setSupporterId(Integer supporterId) {
		this.supporterId = supporterId;
	}

	public List<FileDto> getWorkflowFiles() {
		return workflowFiles;
	}

	public void setWorkflowFiles(List<FileDto> workflowFiles) {
		this.workflowFiles = workflowFiles;
	}

	public List<FileDto> getDeletedWorkflowFiles() {
		return deletedWorkflowFiles;
	}

	public void setDeletedWorkflowFiles(List<FileDto> deletedWorkflowFiles) {
		this.deletedWorkflowFiles = deletedWorkflowFiles;
	}

	public Boolean getIsAssignee() {
		return isAssignee;
	}

	public void setIsAssignee(Boolean isAssignee) {
		this.isAssignee = isAssignee;
	}

	public Boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	public void setIsFinalApproval(Boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public List<CeCaseTaskSummaryDto> getCaseTaskSummary() {
		return caseTaskSummary;
	}

	public void setCaseTaskSummary(List<CeCaseTaskSummaryDto> caseTaskSummary) {
		this.caseTaskSummary = caseTaskSummary;
	}

	public Boolean getIsInGroup() {
		return isInGroup;
	}

	public void setIsInGroup(Boolean isInGroup) {
		this.isInGroup = isInGroup;
	}

	public String getLastActionBy() {
		return lastActionBy;
	}

	public void setLastActionBy(String lastActionBy) {
		this.lastActionBy = lastActionBy;
	}

	public Boolean getIsFromCreateCaseTask() {
		return isFromCreateCaseTask;
	}

	public void setIsFromCreateCaseTask(Boolean isFromCreateCaseTask) {
		this.isFromCreateCaseTask = isFromCreateCaseTask;
	}

}