package gov.stb.tag.dto.ce.cases;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTaFieldReport;
import gov.stb.tag.model.CeTgFieldReport;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TravelAgent;

public class CeComplianceCheckDto {

	private final static String COMPLIANCE_CHECK = "TA Check (TATI) ID: ";
	private final static String TA_FIELD_REPORT = "TA Field Report No: ";
	private final static String TG_FIELD_REPORT = "TG Field Report No: ";

	private Integer id;
	private LocalDateTime conductedDate;
	private String uin;
	private String uen;
	private String licenceNo;
	private String name;
	private String companyName;
	private String conductedBy;
	private String remarks;
	private Integer ceCaseId;
	private String type; // compliance check, ta field report. tg field report
	private String nameForDisplay;
	private Boolean toRevisit;

	public CeComplianceCheckDto() {

	}

	public CeComplianceCheckDto(CeTgFieldReport ceTgFieldReport, Integer ceCaseId) {
		this.id = ceTgFieldReport.getId();
		this.conductedDate = ceTgFieldReport.getCreatedDate();
		this.conductedBy = ceTgFieldReport.getEoUser().getName();
		this.remarks = ceTgFieldReport.getRemarks();
		this.type = Codes.ComplianceCheckFieldReportType.TG_FIELD_REPORT;
		this.ceCaseId = ceCaseId;
		this.nameForDisplay = TG_FIELD_REPORT + ceTgFieldReport.getReportNo();

		// TODO: change to multiple licences
		/*
		 * Licence licence = ceTgFieldReport.getCeTgFieldReportTgs().getLicence(); if (licence != null) { this.licenceNo = licence.getLicenceNo();
		 * 
		 * TouristGuide tg = licence.getTouristGuide(); if (tg != null) { this.uin = tg.getUin(); this.name = tg.getName(); } }
		 */

	}

	public CeComplianceCheckDto(CeTaFieldReport ceTaFieldReport, Integer ceCaseId) {
		this.id = ceTaFieldReport.getId();
		this.conductedDate = ceTaFieldReport.getCreatedDate();
		this.uin = ceTaFieldReport.getUinPassportNo();
		this.name = ceTaFieldReport.getName();
		this.remarks = ceTaFieldReport.getDetails();
		this.type = Codes.ComplianceCheckFieldReportType.TA_FIELD_REPORT;
		this.ceCaseId = ceCaseId;
		this.nameForDisplay = (TA_FIELD_REPORT + ceTaFieldReport.getReportNo()).concat(ceTaFieldReport.isDraft() ? " (Draft) " : "");

		CeTaCheckScheduleItem ceTaCheckScheduleItem = ceTaFieldReport.getCeTaCheckScheduleItem();
		if (ceTaCheckScheduleItem != null) {
			this.conductedBy = ceTaCheckScheduleItem.getEoUser().getName();

			Licence licence = ceTaCheckScheduleItem.getLicence();
			if (licence != null) {
				this.licenceNo = licence.getLicenceNo();

				TravelAgent ta = licence.getTravelAgent();
				if (ta != null) {
					this.uen = ta.getUen();
					this.companyName = ta.getName();
				}
			}

		} else {
			this.conductedBy = ceTaFieldReport.getCreatedBy();
		}

	}

	public CeComplianceCheckDto(CeTaCheck ceTaCheck, Integer ceCaseId) {
		this.id = ceTaCheck.getId();
		this.conductedDate = ceTaCheck.getCreatedDate();
		this.conductedBy = ceTaCheck.getEoUser().getName();
		this.remarks = ceTaCheck.getRemarks();
		this.type = Codes.ComplianceCheckFieldReportType.COMPLIANCE_CHECKS;
		this.licenceNo = ceTaCheck.getLicenceNo();
		this.uin = ceTaCheck.getTaKeUin();
		this.name = ceTaCheck.getTaKeName();
		this.uen = ceTaCheck.getUen();
		this.companyName = ceTaCheck.getTaName();
		this.ceCaseId = ceCaseId;

		if (ceTaCheck.getCeTaCheckScheduleItem() != null) {
			this.toRevisit = ceTaCheck.getCeTaCheckScheduleItem().toRevisit();
			this.nameForDisplay = (ceTaCheck.getCeTaCheckScheduleItem().getCheckType().getLabel() + " (")
					.concat(this.toRevisit ? "To Revisit" : "Is TA Compliant:" + ceTaCheck.getIsCompliant().getLabel()).concat(")");
		}

	}

	public static <M> ResultDto<CeComplianceCheckDto> buildFromModels(ResultDto<M> results) {

		ResultDto<CeComplianceCheckDto> resultDtos = new ResultDto<CeComplianceCheckDto>();
		resultDtos.setTotal(results.getTotal());
		resultDtos.setNoOfPages(results.getNoOfPages());
		resultDtos.setSuccessFlag(results.getSuccessFlag());

		var models = results.getModels();

		List<Object> objs = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(models)) {
			if (models.get(0).getClass().equals(CeTgFieldReport.class)) {
				models.stream().forEach(u -> {
					CeTgFieldReport ceTgFieldReport = (CeTgFieldReport) u;
					var dto = new CeComplianceCheckDto(ceTgFieldReport, null);
					objs.add(dto);
				});
			} else {
				models.stream().forEach(u -> {
					CeTaFieldReport ceTaFieldReport = (CeTaFieldReport) u;
					var dto = new CeComplianceCheckDto(ceTaFieldReport, null);
					objs.add(dto);
				});
			}
		}
		resultDtos.setRecords(objs.toArray());
		return resultDtos;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getConductedDate() {
		return conductedDate;
	}

	public void setConductedDate(LocalDateTime conductedDate) {
		this.conductedDate = conductedDate;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getConductedBy() {
		return conductedBy;
	}

	public void setConductedBy(String conductedBy) {
		this.conductedBy = conductedBy;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getCeCaseId() {
		return ceCaseId;
	}

	public void setCeCaseId(Integer ceCaseId) {
		this.ceCaseId = ceCaseId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getNameForDisplay() {
		return nameForDisplay;
	}

	public void setNameForDisplay(String nameForDisplay) {
		this.nameForDisplay = nameForDisplay;
	}

	public Boolean getToRevisit() {
		return toRevisit;
	}

	public void setToRevisit(Boolean toRevisit) {
		this.toRevisit = toRevisit;
	}

}
