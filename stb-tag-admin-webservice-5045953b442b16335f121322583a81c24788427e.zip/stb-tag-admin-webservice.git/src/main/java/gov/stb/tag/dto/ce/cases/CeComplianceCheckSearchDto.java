package gov.stb.tag.dto.ce.cases;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeComplianceCheckSearchDto extends SearchDto {

	private String type;
	private String name;
	private String uin;
	private String uen;
	private String companyName;
	private String licenceNo;
	private LocalDateTime conductedDateFrom;
	private LocalDateTime conductedDateTo;
	private String conductedBy;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public LocalDateTime getConductedDateFrom() {
		return conductedDateFrom;
	}

	public void setConductedDateFrom(LocalDateTime conductedDateFrom) {
		this.conductedDateFrom = conductedDateFrom;
	}

	public LocalDateTime getConductedDateTo() {
		return conductedDateTo;
	}

	public void setConductedDateTo(LocalDateTime conductedDateTo) {
		this.conductedDateTo = conductedDateTo;
	}

	public String getConductedBy() {
		return conductedBy;
	}

	public void setConductedBy(String conductedBy) {
		this.conductedBy = conductedBy;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

}
