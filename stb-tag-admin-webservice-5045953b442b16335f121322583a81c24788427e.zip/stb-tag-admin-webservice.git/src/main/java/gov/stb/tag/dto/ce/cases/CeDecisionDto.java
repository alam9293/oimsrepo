package gov.stb.tag.dto.ce.cases;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeCaseDecision;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;

public class CeDecisionDto {

	private Integer decisionId;
	private Boolean showCause;
	private LocalDate showCauseDate;
	private String taggedIpCaseNo;
	private ListableDto decision;
	private BigDecimal penaltyAmount;
	private LocalDate penaltyStartDate;
	private LocalDate penaltyEndDate;

	private Boolean toEmailLetter;
	private FileDto letterIssuance;
	private LocalDate letterIssuanceDate;
	private List<FileDto> deletedLetterIssuance;

	private Integer workflowId;
	private ListableDto workflowStatus;
	private LocalDateTime approvedDate;

	@JsonIgnore
	private CeCaseDecision ceCaseDecision;

	public CeDecisionDto() {

	}

	public CeDecisionDto(CeCaseDecision ceCaseDecision, CacheHelper cache, FileHelper fileHelper, WorkflowHelper workflowHelper, User oic, boolean isForCaseTaskLogDetails) {
		if (ceCaseDecision != null) {
			this.decisionId = ceCaseDecision.getId();
			if (ceCaseDecision.getOutcome() != null) {
				this.decision = new ListableDto(ceCaseDecision.getOutcome().getCode(), cache.getLabel(ceCaseDecision.getOutcome(), false));
			}

			this.toEmailLetter = ceCaseDecision.getToEmailLetter();
			this.taggedIpCaseNo = ceCaseDecision.getTaggedIpCaseNo();
			this.penaltyAmount = ceCaseDecision.getPenaltyAmount();
			this.penaltyStartDate = ceCaseDecision.getPenaltyStatusStartDate();
			this.penaltyEndDate = ceCaseDecision.getPenaltyStatusEndDate();
			this.showCause = ceCaseDecision.hasShowCause();
			this.letterIssuanceDate = ceCaseDecision.getLetterIssuanceDate();
			this.showCauseDate = ceCaseDecision.getShowCauseDate();

			Workflow workflow = ceCaseDecision.getWorkflow();
			if (workflow != null) {
				WorkflowAction lastAction = workflow.getLastAction();

				if (lastAction != null) {
					if (workflowHelper.isPendingApproval(lastAction.getStatus())) {
						this.workflowId = workflow.getId();
						this.workflowStatus = new ListableDto(lastAction.getStatus().getCode(), cache.getLabel(lastAction.getStatus(), false));
					}

					if (Entities.equals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_APPR)) {
						this.approvedDate = lastAction.getCreatedDate();
					}
				}
			}

			if (ceCaseDecision.getLetter() != null) {
				this.letterIssuance = FileDto.buildFromFile(ceCaseDecision.getLetter(), null, fileHelper);
			}

		}
	}

	public Integer getDecisionId() {
		return decisionId;
	}

	public void setDecisionId(Integer decisionId) {
		this.decisionId = decisionId;
	}

	public Boolean getShowCause() {
		return showCause;
	}

	public void setShowCause(Boolean showCause) {
		this.showCause = showCause;
	}

	public ListableDto getDecision() {
		return decision;
	}

	public void setDecision(ListableDto decision) {
		this.decision = decision;
	}

	public BigDecimal getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(BigDecimal penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public LocalDate getPenaltyStartDate() {
		return penaltyStartDate;
	}

	public void setPenaltyStartDate(LocalDate penaltyStartDate) {
		this.penaltyStartDate = penaltyStartDate;
	}

	public LocalDate getPenaltyEndDate() {
		return penaltyEndDate;
	}

	public void setPenaltyEndDate(LocalDate penaltyEndDate) {
		this.penaltyEndDate = penaltyEndDate;
	}

	public Boolean getToEmailLetter() {
		return toEmailLetter;
	}

	public void setToEmailLetter(Boolean toEmailLetter) {
		this.toEmailLetter = toEmailLetter;
	}

	public FileDto getLetterIssuance() {
		return letterIssuance;
	}

	public void setLetterIssuance(FileDto letterIssuance) {
		this.letterIssuance = letterIssuance;
	}

	public List<FileDto> getDeletedLetterIssuance() {
		return deletedLetterIssuance;
	}

	public void setDeletedLetterIssuance(List<FileDto> deletedLetterIssuance) {
		this.deletedLetterIssuance = deletedLetterIssuance;
	}

	public ListableDto getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(ListableDto workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public String getTaggedIpCaseNo() {
		return taggedIpCaseNo;
	}

	public void setTaggedIpCaseNo(String taggedIpCaseNo) {
		this.taggedIpCaseNo = taggedIpCaseNo;
	}

	public CeCaseDecision getCeCaseDecision() {
		return ceCaseDecision;
	}

	public void setCeCaseDecision(CeCaseDecision ceCaseDecision) {
		this.ceCaseDecision = ceCaseDecision;
	}

	public LocalDate getShowCauseDate() {
		return showCauseDate;
	}

	public void setShowCauseDate(LocalDate showCauseDate) {
		this.showCauseDate = showCauseDate;
	}

	public LocalDate getLetterIssuanceDate() {
		return letterIssuanceDate;
	}

	public void setLetterIssuanceDate(LocalDate letterIssuanceDate) {
		this.letterIssuanceDate = letterIssuanceDate;
	}

	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

}
