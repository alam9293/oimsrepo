package gov.stb.tag.dto.ce.cases;

import java.time.LocalDateTime;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CeCaseHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.CeCaseDecision;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.Type;

public class CeInfringementDto {

	private Integer offenderId;
	private String offenderName;
	private String offenderUenUin;
	private Integer licenceId;

	private Integer infringementId;
	private LocalDateTime offenceDate;
	private CeProvisionDto offenceProvision;

	private CeRecommendationDto recommendation;
	private CeDecisionDto decision;
	private CeResultDto result;
	private CeRescindDto rescind;

	private ListableDto workflowStatus;
	private Boolean hasApprovedPastRecommendation = false;
	private Boolean isPendingApproval = false;
	private Boolean isCompleted = false; // true if outcome of infringement is NOD/NFA/Caution/Circular/Counsel/Open IP/Tag IP
	private Boolean isConcluded = false; // true if infringement is concluded
	private String taggedCaseNo;
	private Integer taggedCaseId;
	private String taggedCaseType;

	private ListableDto outcome;
	private LocalDateTime outcomeDate;
	private String finalOutcomeDetails;
	private Integer ipCaseId;

	// only for relevant offences
	private Integer caseId;
	private String caseNo;
	private String ipCaseNo;
	private String taTgType;
	private ListableDto status;

	public CeInfringementDto() {

	}

	public CeInfringementDto(CeCaseInfringer ceCaseInfringer, CeCaseInfringement ceCaseInfringement, Cache cache, boolean isForRelevant, CeCaseHelper caseHelper) {
		this.offenderId = ceCaseInfringer.getId();
		this.offenderUenUin = ceCaseInfringer.getUenUin();
		this.offenderName = ceCaseInfringer.getName();

		if (ceCaseInfringer.getLicence() != null) {
			this.licenceId = ceCaseInfringer.getLicence().getId();
		}

		if (ceCaseInfringement != null) {
			this.infringementId = ceCaseInfringement.getId();
			this.offenceDate = ceCaseInfringement.getInfringedDate();
			if (ceCaseInfringement.getCeProvision() != null) {
				this.offenceProvision = CeProvisionDto.buildFromProvisions(cache, ceCaseInfringement.getCeProvision());
			}

			CeCase oriCase = ceCaseInfringement.getCeOriginatingCase();
			if (oriCase != null && ceCaseInfringement.getCeCase() != oriCase) {
				this.taggedCaseNo = oriCase.getCaseNo();
				this.taggedCaseId = oriCase.getId();
				this.taggedCaseType = oriCase.getTaTgType().toLowerCase();
			}
			if (ceCaseInfringement.getOutcome() != null) {
				Type infringementOutcome = ceCaseInfringement.getOutcome();
				this.outcome = new ListableDto(infringementOutcome.getCode(), cache.getLabel(infringementOutcome, false));
				this.isCompleted = Entities.anyEquals(infringementOutcome, Codes.CeRecommendation.COMPLETED_OUTCOME);
				this.isConcluded = ceCaseInfringement.getIsConcluded();
				this.outcomeDate = ceCaseInfringement.getOutcomeDate();
				this.finalOutcomeDetails = ceCaseInfringement.getOutcome().getLabel();

				if (Entities.equals(ceCaseInfringement.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_OPEN_IP)) {
					CeCase ipCase = ceCaseInfringement.getCeCase();
					this.ipCaseId = ipCase.getId();
					this.ipCaseNo = ipCase.getCaseNo();
					this.caseNo = ipCase.getCaseNo();
				} else {
					CeCaseRecommendation lastRecomm = ceCaseInfringement.getLastRecommendation();

					if (ceCaseInfringement.getLastDecision() != null) {
						CeCaseDecision lastDecision = caseHelper.getDecisionById(ceCaseInfringement.getLastDecision().getId());
						CeCaseAppeal lastAppeal = lastDecision.getCeCaseAppeal();
						if (lastAppeal != null) {
							this.finalOutcomeDetails = caseHelper.populateInfringementTaskDetails(null, null, lastAppeal.getOutcome(), lastAppeal.getPenaltyAmount(),
									lastAppeal.getPenaltyStatusStartDate(), lastAppeal.getPenaltyStatusEndDate(), null, null, null);
						} else {
							this.finalOutcomeDetails = caseHelper.populateInfringementTaskDetails(null, null, lastDecision.getOutcome(), lastDecision.getPenaltyAmount(),
									lastDecision.getPenaltyStatusStartDate(), lastDecision.getPenaltyStatusEndDate(), null, null, null);
						}
					} else if (lastRecomm != null) {
						this.finalOutcomeDetails = caseHelper.populateInfringementTaskDetails(null, null, lastRecomm.getOutcome(), lastRecomm.getPenaltyAmount(),
								lastRecomm.getPenaltyStatusStartDate(), lastRecomm.getPenaltyStatusEndDate(), null, null, null);
					}
				}

			}

			if (isForRelevant) {
				CeCase ceCase = ceCaseInfringement.getCeCase();
				this.caseId = ceCase.getId();
				this.caseNo = ceCase.getCaseNo();
				this.taTgType = ceCase.getTaTgType();
				this.status = new ListableDto(ceCase.getStatus().getCode(), cache.getLabel(ceCase.getStatus(), false));
				if (ceCase.isIp()) {
					CeCase ipCase = ceCaseInfringement.getCeCase();
					this.ipCaseId = ipCase.getId();
					this.ipCaseNo = ipCase.getCaseNo();
					if (ceCaseInfringement.getCeOriginatingCase() != null) {
						this.caseNo = ceCaseInfringement.getCeOriginatingCase().getCaseNo();
						this.caseId = ceCaseInfringement.getCeOriginatingCase().getId();
					} else {
						this.caseNo = null;
						this.caseId = null;
					}
				}
			}
		}

	}

	public Integer getOffenderId() {
		return offenderId;
	}

	public void setOffenderId(Integer offenderId) {
		this.offenderId = offenderId;
	}

	public Integer getInfringementId() {
		return infringementId;
	}

	public void setInfringementId(Integer infringementId) {
		this.infringementId = infringementId;
	}

	public String getOffenderName() {
		return offenderName;
	}

	public void setOffenderName(String offenderName) {
		this.offenderName = offenderName;
	}

	public String getOffenderUenUin() {
		return offenderUenUin;
	}

	public void setOffenderUenUin(String offenderUenUin) {
		this.offenderUenUin = offenderUenUin;
	}

	public LocalDateTime getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDateTime offenceDate) {
		this.offenceDate = offenceDate;
	}

	public CeProvisionDto getOffenceProvision() {
		return offenceProvision;
	}

	public void setOffenceProvision(CeProvisionDto offenceProvision) {
		this.offenceProvision = offenceProvision;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public ListableDto getOutcome() {
		return outcome;
	}

	public void setOutcome(ListableDto outcome) {
		this.outcome = outcome;
	}

	public ListableDto getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(ListableDto workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public CeRecommendationDto getRecommendation() {
		return recommendation;
	}

	public void setRecommendation(CeRecommendationDto recommendation) {
		this.recommendation = recommendation;
	}

	public CeDecisionDto getDecision() {
		return decision;
	}

	public void setDecision(CeDecisionDto decision) {
		this.decision = decision;
	}

	public CeResultDto getResult() {
		return result;
	}

	public void setResult(CeResultDto result) {
		this.result = result;
	}

	public Boolean getHasApprovedPastRecommendation() {
		return hasApprovedPastRecommendation;
	}

	public void setHasApprovedPastRecommendation(Boolean hasApprovedPastRecommendation) {
		this.hasApprovedPastRecommendation = hasApprovedPastRecommendation;
	}

	public Boolean getIsPendingApproval() {
		return isPendingApproval;
	}

	public void setIsPendingApproval(Boolean isPendingApproval) {
		this.isPendingApproval = isPendingApproval;
	}

	public String getFinalOutcomeDetails() {
		return finalOutcomeDetails;
	}

	public void setFinalOutcomeDetails(String finalOutcomeDetails) {
		this.finalOutcomeDetails = finalOutcomeDetails;
	}

	public CeRescindDto getRescind() {
		return rescind;
	}

	public void setRescind(CeRescindDto rescind) {
		this.rescind = rescind;
	}

	public Integer getIpCaseId() {
		return ipCaseId;
	}

	public void setIpCaseId(Integer ipCaseId) {
		this.ipCaseId = ipCaseId;
	}

	public String getTaggedCaseNo() {
		return taggedCaseNo;
	}

	public void setTaggedCaseNo(String taggedCaseNo) {
		this.taggedCaseNo = taggedCaseNo;
	}

	public Boolean getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(Boolean isCompleted) {
		this.isCompleted = isCompleted;
	}

	public LocalDateTime getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(LocalDateTime outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public Integer getCaseId() {
		return caseId;
	}

	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}

	public String getIpCaseNo() {
		return ipCaseNo;
	}

	public void setIpCaseNo(String ipCaseNo) {
		this.ipCaseNo = ipCaseNo;
	}

	public Boolean getIsConcluded() {
		return isConcluded;
	}

	public void setIsConcluded(Boolean isConcluded) {
		this.isConcluded = isConcluded;
	}

	public Integer getTaggedCaseId() {
		return taggedCaseId;
	}

	public void setTaggedCaseId(Integer taggedCaseId) {
		this.taggedCaseId = taggedCaseId;
	}

	public String getTaggedCaseType() {
		return taggedCaseType;
	}

	public void setTaggedCaseType(String taggedCaseType) {
		this.taggedCaseType = taggedCaseType;
	}

}
