package gov.stb.tag.dto.ce.cases;

import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;

public class CeInfringerDto {

	private String name;
	private Integer licenceId;

	public CeInfringerDto() {

	}

	public CeInfringerDto(TravelAgent ta) {
		if (ta != null) {
			this.name = ta.getName();
			this.licenceId = ta.getLicence().getId();
		}
	}

	public CeInfringerDto(TouristGuide tg) {
		if (tg != null) {
			this.name = tg.getName();
			this.licenceId = tg.getLicence().getId();
		}
	}

	public CeInfringerDto(Stakeholder stakeholder) {
		if (stakeholder != null) {
			this.name = stakeholder.getName();
		}
	}

	public CeInfringerDto(CeCaseInfringer ceCaseInfringer) {
		if (ceCaseInfringer != null) {
			this.name = ceCaseInfringer.getName();
			this.licenceId = ceCaseInfringer.getLicence() != null ? ceCaseInfringer.getLicence().getId() : null;
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}
}