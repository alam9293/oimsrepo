package gov.stb.tag.dto.ce.cases;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;

public class CeResultDto {

	private Integer resultId;
	private ListableDto result;
	private ListableDto newDecision;
	private LocalDate appealDate;
	private LocalDate appealRespondByDate;
	private LocalDate respondedDate;

	private BigDecimal penaltyAmount;
	private LocalDate penaltyStartDate;
	private LocalDate penaltyEndDate;

	private Boolean toEmailLetter;
	private FileDto letterIssuance;
	private LocalDate letterIssuanceDate;
	private List<FileDto> deletedLetterIssuance;

	private Integer workflowId;
	private ListableDto workflowStatus;
	private LocalDateTime approvedDate;

	@JsonIgnore
	private CeCaseAppeal ceCaseAppeal;

	public CeResultDto() {

	}

	public CeResultDto(CeCaseAppeal ceCaseAppeal, CacheHelper cache, FileHelper fileHelper, WorkflowHelper workflowHelper, User oic) {
		if (ceCaseAppeal != null) {
			this.resultId = ceCaseAppeal.getId();
			if (ceCaseAppeal.getResult() != null) {
				this.result = new ListableDto(ceCaseAppeal.getResult().getCode(), cache.getLabel(ceCaseAppeal.getResult(), false));
			}
			if (ceCaseAppeal.getOutcome() != null) {
				this.newDecision = new ListableDto(ceCaseAppeal.getOutcome().getCode(), cache.getLabel(ceCaseAppeal.getOutcome(), false));
			}

			this.toEmailLetter = ceCaseAppeal.getToEmailLetter();
			this.penaltyAmount = ceCaseAppeal.getPenaltyAmount();
			this.penaltyStartDate = ceCaseAppeal.getPenaltyStatusStartDate();
			this.penaltyEndDate = ceCaseAppeal.getPenaltyStatusEndDate();
			this.letterIssuanceDate = ceCaseAppeal.getLetterIssuanceDate();
			this.appealDate = ceCaseAppeal.getAppealDate();
			this.appealRespondByDate = ceCaseAppeal.getAppealRespondByDate();
			this.respondedDate = ceCaseAppeal.getRespondedDate();

			Workflow workflow = ceCaseAppeal.getWorkflow();
			if (workflow != null) {
				WorkflowAction lastAction = workflow.getLastAction();

				if (lastAction != null) {
					if (workflowHelper.isPendingApproval(lastAction.getStatus())) {
						this.workflowId = workflow.getId();
						this.workflowStatus = new ListableDto(lastAction.getStatus().getCode(), cache.getLabel(lastAction.getStatus(), false));
					}

					if (Entities.equals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_APPR)) {
						this.approvedDate = lastAction.getCreatedDate();
					}
				}
			}

			if (ceCaseAppeal.getLetter() != null) {
				this.letterIssuance = FileDto.buildFromFile(ceCaseAppeal.getLetter(), null, fileHelper);
			}

		}
	}

	public Integer getResultId() {
		return resultId;
	}

	public void setResultId(Integer resultId) {
		this.resultId = resultId;
	}

	public ListableDto getResult() {
		return result;
	}

	public void setResult(ListableDto result) {
		this.result = result;
	}

	public BigDecimal getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(BigDecimal penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public Boolean getToEmailLetter() {
		return toEmailLetter;
	}

	public void setToEmailLetter(Boolean toEmailLetter) {
		this.toEmailLetter = toEmailLetter;
	}

	public FileDto getLetterIssuance() {
		return letterIssuance;
	}

	public void setLetterIssuance(FileDto letterIssuance) {
		this.letterIssuance = letterIssuance;
	}

	public List<FileDto> getDeletedLetterIssuance() {
		return deletedLetterIssuance;
	}

	public void setDeletedLetterIssuance(List<FileDto> deletedLetterIssuance) {
		this.deletedLetterIssuance = deletedLetterIssuance;
	}

	public ListableDto getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(ListableDto workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public LocalDate getPenaltyStartDate() {
		return penaltyStartDate;
	}

	public void setPenaltyStartDate(LocalDate penaltyStartDate) {
		this.penaltyStartDate = penaltyStartDate;
	}

	public LocalDate getPenaltyEndDate() {
		return penaltyEndDate;
	}

	public void setPenaltyEndDate(LocalDate penaltyEndDate) {
		this.penaltyEndDate = penaltyEndDate;
	}

	public ListableDto getNewDecision() {
		return newDecision;
	}

	public void setNewDecision(ListableDto newDecision) {
		this.newDecision = newDecision;
	}

	public CeCaseAppeal getCeCaseAppeal() {
		return ceCaseAppeal;
	}

	public void setCeCaseAppeal(CeCaseAppeal ceCaseAppeal) {
		this.ceCaseAppeal = ceCaseAppeal;
	}

	public LocalDate getLetterIssuanceDate() {
		return letterIssuanceDate;
	}

	public void setLetterIssuanceDate(LocalDate letterIssuanceDate) {
		this.letterIssuanceDate = letterIssuanceDate;
	}

	public LocalDate getAppealDate() {
		return appealDate;
	}

	public void setAppealDate(LocalDate appealDate) {
		this.appealDate = appealDate;
	}

	public LocalDate getAppealRespondByDate() {
		return appealRespondByDate;
	}

	public void setAppealRespondByDate(LocalDate appealRespondByDate) {
		this.appealRespondByDate = appealRespondByDate;
	}

	public LocalDate getRespondedDate() {
		return respondedDate;
	}

	public void setRespondedDate(LocalDate respondedDate) {
		this.respondedDate = respondedDate;
	}

	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

}
