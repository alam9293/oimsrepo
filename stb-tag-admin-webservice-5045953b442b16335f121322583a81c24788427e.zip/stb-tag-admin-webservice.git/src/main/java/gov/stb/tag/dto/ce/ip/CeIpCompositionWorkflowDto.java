package gov.stb.tag.dto.ce.ip;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.cases.CeCaseTaskWorkflowDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseComposition;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowStep;
import gov.stb.tag.model.WorkflowStepAssignment;

public class CeIpCompositionWorkflowDto extends ApprovalDto {

	private Integer id;

	private String taTgType;

	private List<CeIpCompositionDto> compositions = Lists.newArrayList();

	private CeCaseTaskWorkflowDto workflow;

	public CeIpCompositionWorkflowDto() {
		this.workflow = new CeCaseTaskWorkflowDto();
		this.workflow.setCaseTaskStatus(new ListableDto(Codes.Statuses.CE_WKFLW_NEW, Codes.Statuses.CE_WKFLW_NEW));
	}

	private CeIpCompositionWorkflowDto(CeCase ip) {
		this.id = ip.getId();
		this.taTgType = ip.getTaTgType();
	}

	public CeIpCompositionWorkflowDto(CeCase ip, List<CeCaseComposition> compos, FileHelper fileHelper, CacheHelper cache, WorkflowHelper workflowHelper, User user, PaymentHelper paymentHelper) {
		this(ip);

		this.setWorkflow(compos, fileHelper, cache, workflowHelper, user);

		for (CeCaseComposition compo : compos) {
			compositions.add(new CeIpCompositionDto(compo, paymentHelper, this.workflow, fileHelper));
		}
	}

	public CeIpCompositionWorkflowDto(CeCase ip, List<CeCaseInfringement> infringements, List<CeCaseComposition> compos, FileHelper fileHelper, CacheHelper cache, WorkflowHelper workflowHelper,
			User user, PaymentHelper paymentHelper) {
		this(ip);

		this.setWorkflow(compos, fileHelper, cache, workflowHelper, user);

		for (CeCaseInfringement infringement : infringements) {
			if (Codes.CeOutcomeIp.CE_OUTCOME_IP_COMPO.equals(infringement.getOutcome() != null ? infringement.getOutcome().getCode() : null)) {
				CeCaseInfringer infringer = infringement.getCeCaseInfringer();
				if (compositions.size() == 0 || !infringer.getUenUin().equals(compositions.get(compositions.size() - 1).getUenUin())) {
					Optional<CeCaseComposition> compo = compos.stream().filter(x -> x.getCeCaseInfringer().getId().equals(infringer.getId())).findFirst();
					if (compo.isPresent()) {
						compositions.add(new CeIpCompositionDto(compo.get(), paymentHelper, this.workflow, fileHelper));
					} else {
						compositions.add(new CeIpCompositionDto(infringer, this.workflow));
					}
				}
			}
		}
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public List<CeIpCompositionDto> getCompositions() {
		return compositions;
	}

	public void setCompositions(List<CeIpCompositionDto> compositions) {
		this.compositions = compositions;
	}

	public CeCaseTaskWorkflowDto getWorkflow() {
		return workflow;
	}

	public void setWorkflow(CeCaseTaskWorkflowDto workflow) {
		this.workflow = workflow;
	}

	private void setWorkflow(List<CeCaseComposition> compos, FileHelper fileHelper, CacheHelper cache, WorkflowHelper workflowHelper, User user) {
		if (compos.size() != 0) {
			Workflow currWorkflow = null;
			for (CeCaseComposition compo : compos) {
				Workflow workflow = compo.getWorkflow();
				// Workflow waiveWorkflow = compo.getWaiveWorkflow();
				if (workflow != null) {
					/*
					 * if (waiveWorkflow != null) { workflow = waiveWorkflow; }
					 */
					String workflowActionType = workflow.getLastAction().getType().getCode();
					if (Codes.WorkflowActionTypes.ROUTE.equals(workflowActionType) || Codes.WorkflowActionTypes.SUBMIT.equals(workflowActionType)) {
						currWorkflow = workflow;
						break;
					} else if (Codes.WorkflowActionTypes.APPROVE.equals(workflowActionType)) {
						currWorkflow = workflow;
					}
				}
			}
			if (currWorkflow != null) {
				this.workflow = new CeCaseTaskWorkflowDto(currWorkflow, fileHelper, cache, workflowHelper, user);
				this.workflow.setInternalRemarks(currWorkflow.getLastAction().getInternalRemarks());
				this.workflow.setLastActionBy(currWorkflow.getLastAction().getCreatedBy());
				List<WorkflowStepAssignment> workflowStepAssignments = currWorkflow.getWorkflowStepAssignments();
				workflowStepAssignments.forEach(u -> {
					WorkflowStep ws = u.getWorkflowStep();
					if (ws != null) {
						Set<Role> roles = ws.getRoles();
						if (roles.contains(user.getDefaultRole())) {
							this.workflow.setIsInGroup(true);
						}
					}
				});
			} else {
				setEmptyWorkflow();
			}
		} else {
			setEmptyWorkflow();
		}
	}

	private void setEmptyWorkflow() {
		this.workflow = new CeCaseTaskWorkflowDto();
		this.workflow.setCaseTaskStatus(new ListableDto(Codes.Statuses.CE_WKFLW_NEW, Codes.Statuses.CE_WKFLW_NEW));
	}

}
