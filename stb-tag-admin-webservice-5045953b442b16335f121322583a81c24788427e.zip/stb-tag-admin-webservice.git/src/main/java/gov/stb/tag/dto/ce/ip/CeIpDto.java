package gov.stb.tag.dto.ce.ip;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseInfringement;

public class CeIpDto {

	private Integer id;

	private String caseNo;

	private String taTgType;

	private Boolean isComplex;

	private ListableDto status;

	private ListableDto oic;

	private LocalDateTime createdDate;

	private List<CeIpComplainantDto> complainants = Lists.newArrayList();
	private List<Integer> deletedComplainants = Lists.newArrayList();

	private List<CeIpInfringementDto> infringements = Lists.newArrayList();
	private List<Integer> deletedInfringements = Lists.newArrayList();

	private List<CeIpRevIpDto> revIps = Lists.newArrayList();
	private List<Integer> deletedRevIps = Lists.newArrayList();

	private List<CeIpCompositionDto> compositions = Lists.newArrayList();

	private List<FileDto> othAttachments;
	private List<FileDto> othDeletedAttachments;

	// used for display case details info
	private Integer caseId;

	public CeIpDto() {
	}

	public CeIpDto(CeCase ceCase, List<CeCaseInfringement> infringements, FileHelper fileHelper, Cache cache) {
		this.id = ceCase.getId();
		this.caseNo = ceCase.getCaseNo();
		this.taTgType = ceCase.getTaTgType();
		this.status = new ListableDto(ceCase.getStatus());
		this.oic = new ListableDto(ceCase.getOic());
		this.createdDate = ceCase.getCreatedDate();
		this.caseId = ceCase.getTaggedCase() != null ? ceCase.getTaggedCase().getId() : null;
		this.isComplex = ceCase.isComplex();

		this.complainants = ceCase.getCeCaseComplainants().stream().map(x -> {
			return new CeIpComplainantDto(x);
		}).collect(Collectors.toList());

		if (infringements != null) {
			this.infringements = infringements.stream().map(x -> {
				return new CeIpInfringementDto(x, cache);
			}).collect(Collectors.toList());
		}

		this.revIps = ceCase.getCeCaseInternalIps().stream().map(x -> {
			return new CeIpRevIpDto(x);
		}).collect(Collectors.toList());
		this.revIps.addAll(ceCase.getCeCaseExternalIps().stream().map(x -> {
			return new CeIpRevIpDto(x);
		}).collect(Collectors.toList()));

		this.othAttachments = ceCase.getFiles().stream().filter(x -> !x.getIsDeleted()).map(x -> {
			return FileDto.buildFromFile(x, null, fileHelper);
		}).collect(Collectors.toList());

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public ListableDto getOic() {
		return oic;
	}

	public void setOic(ListableDto oic) {
		this.oic = oic;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public List<CeIpComplainantDto> getComplainants() {
		return complainants;
	}

	public void setComplainants(List<CeIpComplainantDto> complainants) {
		this.complainants = complainants;
	}

	public List<CeIpInfringementDto> getInfringements() {
		return infringements;
	}

	public void setInfringements(List<CeIpInfringementDto> infringements) {
		this.infringements = infringements;
	}

	public List<CeIpRevIpDto> getRevIps() {
		return revIps;
	}

	public void setRevIps(List<CeIpRevIpDto> revIps) {
		this.revIps = revIps;
	}

	public List<FileDto> getOthAttachments() {
		return othAttachments;
	}

	public void setOthAttachments(List<FileDto> othAttachments) {
		this.othAttachments = othAttachments;
	}

	public List<FileDto> getOthDeletedAttachments() {
		return othDeletedAttachments;
	}

	public void setOthDeletedAttachments(List<FileDto> othDeletedAttachments) {
		this.othDeletedAttachments = othDeletedAttachments;
	}

	public List<Integer> getDeletedComplainants() {
		return deletedComplainants;
	}

	public void setDeletedComplainants(List<Integer> deletedComplainants) {
		this.deletedComplainants = deletedComplainants;
	}

	public List<Integer> getDeletedInfringements() {
		return deletedInfringements;
	}

	public void setDeletedInfringements(List<Integer> deletedInfringements) {
		this.deletedInfringements = deletedInfringements;
	}

	public List<Integer> getDeletedRevIps() {
		return deletedRevIps;
	}

	public void setDeletedRevIps(List<Integer> deletedRevIps) {
		this.deletedRevIps = deletedRevIps;
	}

	public List<CeIpCompositionDto> getCompositions() {
		return compositions;
	}

	public void setCompositions(List<CeIpCompositionDto> compositions) {
		this.compositions = compositions;
	}

	public Integer getCaseId() {
		return caseId;
	}

	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}

	public Boolean getIsComplex() {
		return isComplex;
	}

	public void setIsComplex(Boolean isComplex) {
		this.isComplex = isComplex;
	}

}
