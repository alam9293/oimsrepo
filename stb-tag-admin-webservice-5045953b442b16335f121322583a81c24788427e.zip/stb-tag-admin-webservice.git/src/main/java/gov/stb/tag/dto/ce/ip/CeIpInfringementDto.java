package gov.stb.tag.dto.ce.ip;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.model.Licence;

public class CeIpInfringementDto {

	private Integer id;

	private Integer infringerId;

	private ListableDto idType;

	private String name;

	private String uenUin;

	private String licenceNo;

	private String category;

	private ListableDto nationality;

	private ListableDto ageGroup;

	private ListableDto guidingLanguageProvided;

	private Integer ipOffenceCount;

	private LocalDate offenceDate;

	private String ceOriginatingCaseNo;

	private CeProvisionDto provision;

	private List<CeProvisionDto> provisionsReadWith = Lists.newArrayList();

	private ListableDto outcome;

	private String ipSentencingDetails;

	private String ipCourtCaseNo;

	private LocalDate outcomeDate;

	private String location;

	public CeIpInfringementDto() {
	}

	public CeIpInfringementDto(CeCaseInfringement ceCaseInfringement, Cache cache) {
		CeCaseInfringer ceCaseInfringer = ceCaseInfringement.getCeCaseInfringer();
		CeProvision provision = ceCaseInfringement.getCeProvision();
		CeCase ceCase = ceCaseInfringement.getCeCase();

		if (ceCaseInfringer != null) {
			Licence licence = ceCaseInfringer.getLicence();
			this.infringerId = ceCaseInfringer.getId();
			this.idType = new ListableDto(ceCaseInfringer.getIdType());
			this.name = ceCaseInfringer.getName();
			this.uenUin = ceCaseInfringer.getUenUin();
			this.licenceNo = licence != null ? licence.getLicenceNo() : null;
			this.category = ceCaseInfringer.getCategory();
			this.nationality = new ListableDto(ceCaseInfringer.getNationality());
			this.ageGroup = new ListableDto(ceCaseInfringer.getAgeGroup());
			this.guidingLanguageProvided = new ListableDto(ceCaseInfringer.getGuidingLanguageProvided());
		}
		this.id = ceCaseInfringement.getId();
		this.ipOffenceCount = ceCaseInfringement.getIpOffenceCount();
		this.offenceDate = ceCaseInfringement.getInfringedDate() != null ? ceCaseInfringement.getInfringedDate().toLocalDate() : null;
		if (ceCaseInfringement.getCeOriginatingCase() != null) {
			this.ceOriginatingCaseNo = ceCaseInfringement.getCeOriginatingCase().getCaseNo();
			if (ceCaseInfringement.getCeOriginatingCase().getId().equals(ceCase.getId())) {
				this.ceOriginatingCaseNo = null;
			}
		}
		if (provision != null) {
			this.provision = new CeProvisionDto(cache, provision);
		} else {
			this.provision = new CeProvisionDto();
		}
		this.provisionsReadWith = ceCaseInfringement.getReadWiths().stream().map(x -> {
			return new CeProvisionDto(cache, x);
		}).collect(Collectors.toList());
		this.outcome = new ListableDto(ceCaseInfringement.getOutcome());
		this.ipSentencingDetails = ceCaseInfringement.getIpSentencingDetails();
		this.ipCourtCaseNo = ceCaseInfringement.getIpCourtCaseNo();
		this.outcomeDate = ceCaseInfringement.getOutcomeDate() != null ? ceCaseInfringement.getOutcomeDate().toLocalDate() : null;
		this.location = ceCaseInfringement.getLocation();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getInfringerId() {
		return infringerId;
	}

	public void setInfringerId(Integer infringerId) {
		this.infringerId = infringerId;
	}

	public ListableDto getIdType() {
		return idType;
	}

	public void setIdType(ListableDto idType) {
		this.idType = idType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public ListableDto getNationality() {
		return nationality;
	}

	public void setNationality(ListableDto nationality) {
		this.nationality = nationality;
	}

	public ListableDto getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(ListableDto ageGroup) {
		this.ageGroup = ageGroup;
	}

	public ListableDto getGuidingLanguageProvided() {
		return guidingLanguageProvided;
	}

	public void setGuidingLanguageProvided(ListableDto guidingLanguageProvided) {
		this.guidingLanguageProvided = guidingLanguageProvided;
	}

	public Integer getIpOffenceCount() {
		return ipOffenceCount;
	}

	public void setIpOffenceCount(Integer ipOffenceCount) {
		this.ipOffenceCount = ipOffenceCount;
	}

	public LocalDate getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDate offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getCeOriginatingCaseNo() {
		return ceOriginatingCaseNo;
	}

	public void setCeOriginatingCaseNo(String ceOriginatingCaseNo) {
		this.ceOriginatingCaseNo = ceOriginatingCaseNo;
	}

	public CeProvisionDto getProvision() {
		return provision;
	}

	public void setProvision(CeProvisionDto provision) {
		this.provision = provision;
	}

	public List<CeProvisionDto> getProvisionsReadWith() {
		return provisionsReadWith;
	}

	public void setProvisionsReadWith(List<CeProvisionDto> provisionsReadWith) {
		this.provisionsReadWith = provisionsReadWith;
	}

	public ListableDto getOutcome() {
		return outcome;
	}

	public void setOutcome(ListableDto outcome) {
		this.outcome = outcome;
	}

	public String getIpSentencingDetails() {
		return ipSentencingDetails;
	}

	public void setIpSentencingDetails(String ipSentencingDetails) {
		this.ipSentencingDetails = ipSentencingDetails;
	}

	public String getIpCourtCaseNo() {
		return ipCourtCaseNo;
	}

	public void setIpCourtCaseNo(String ipCourtCaseNo) {
		this.ipCourtCaseNo = ipCourtCaseNo;
	}

	public LocalDate getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(LocalDate outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
