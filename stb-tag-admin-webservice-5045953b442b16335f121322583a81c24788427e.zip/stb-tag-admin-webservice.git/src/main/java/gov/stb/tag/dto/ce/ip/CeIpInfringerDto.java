package gov.stb.tag.dto.ce.ip;

import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeIpInfringerDto {

	private List<String> licenceNos = Lists.newArrayList();

	private String licenceNo;

	private String name;

	private ListableDto nationality;

	private ListableDto ageGroup;

	public CeIpInfringerDto() {
	}

	public CeIpInfringerDto(TouristGuide tg, TgHelper tgHelper) {
		this.name = tg.getName();
		this.licenceNo = tg.getLicence().getLicenceNo();
		this.licenceNos.add(this.licenceNo);
		this.nationality = new ListableDto(tg.getNationality());
		this.ageGroup = new ListableDto(tgHelper.calculateAgeGroup(tg));
	}

	public CeIpInfringerDto(TravelAgent ta) {
		this.name = ta.getName();
		this.licenceNos = ta.getLicences().stream().map(x -> x.getLicenceNo()).collect(Collectors.toList());
		if (this.licenceNos.size() == 1) {
			this.licenceNo = this.licenceNos.get(0);
		}
	}

	public CeIpInfringerDto(CeCaseInfringer infringer) {
		this.name = infringer.getName();
		if (infringer.getLicence() != null) {
			this.licenceNo = infringer.getLicence().getLicenceNo();
			this.licenceNos.add(this.licenceNo);
		}
		this.nationality = new ListableDto(infringer.getNationality());
		this.ageGroup = new ListableDto(infringer.getAgeGroup());
	}

	public List<String> getLicenceNos() {
		return licenceNos;
	}

	public void setLicenceNos(List<String> licenceNos) {
		this.licenceNos = licenceNos;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ListableDto getNationality() {
		return nationality;
	}

	public void setNationality(ListableDto nationality) {
		this.nationality = nationality;
	}

	public ListableDto getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(ListableDto ageGroup) {
		this.ageGroup = ageGroup;
	}

}
