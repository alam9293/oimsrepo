package gov.stb.tag.dto.ce.provision;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.CeProvision;

public class CeProvisionDto {

	private Integer id;
	private ListableDto chapter;
	private String section;
	private String label;
	private String description;
	private List<CeProvisionDto> readWiths = Lists.newArrayList();

	private Boolean isOffence;
	private Boolean isReadWithOnly;
	private String chapterCode;

	private LocalDate effectiveDate;
	private LocalDate ineffectiveDate;

	public CeProvisionDto() {

	}

	public CeProvisionDto(Cache cache, CeProvision ceProvision) {
		this(cache, ceProvision, false);
	}

	public CeProvisionDto(Cache cache, CeProvision ceProvision, Boolean requireReadWith) {
		this.id = ceProvision.getId();
		this.chapter = new ListableDto(ceProvision.getChapter());
		this.section = ceProvision.getSection();
		this.label = ceProvision.getLabel();
		this.description = ceProvision.getDescription();
		this.effectiveDate = ceProvision.getEffectiveDate();
		this.ineffectiveDate = ceProvision.getIneffectiveDate();
		if (requireReadWith) {
			this.readWiths = ceProvision.getReadWiths().stream()
					.filter(u -> u.getIneffectiveDate() == null || u.getIneffectiveDate().isAfter(LocalDate.now()))
					.map(x -> new CeProvisionDto(cache, x))
					.collect(Collectors.toList());
		}
		this.isOffence = ceProvision.isOffence();
		this.isReadWithOnly = ceProvision.isReadWithOnly();
	}

	public static CeProvisionDto buildFromProvisions(Cache cache, CeProvision ceProvision) {
		CeProvisionDto dto = new CeProvisionDto();

		dto.setId(ceProvision.getId());
		dto.setChapter(new ListableDto(ceProvision.getChapter().getCode(), cache.getLabel(ceProvision.getChapter(), true)));
		dto.setChapterCode(ceProvision.getChapter().getCode());
		dto.setSection(ceProvision.getSection());
		dto.setLabel(ceProvision.getLabel());
		dto.setDescription(ceProvision.getDescription());
		dto.setIsOffence(ceProvision.isOffence());
		dto.setEffectiveDate(ceProvision.getEffectiveDate());
		dto.setIneffectiveDate(ceProvision.getIneffectiveDate());
		dto.setIsReadWithOnly(ceProvision.isReadWithOnly());

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ListableDto getChapter() {
		return chapter;
	}

	public void setChapter(ListableDto chapter) {
		this.chapter = chapter;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getOffence() {
		return isOffence;
	}

	public Boolean getIsOffence() {
		return isOffence;
	}

	public void setIsOffence(Boolean isOffence) {
		this.isOffence = isOffence;
	}

	public Boolean getIsReadWithOnly() {
		return isReadWithOnly;
	}

	public void setIsReadWithOnly(Boolean isReadWithOnly) {
		this.isReadWithOnly = isReadWithOnly;
	}

	public String getChapterCode() {
		return chapterCode;
	}

	public void setChapterCode(String chapterCode) {
		this.chapterCode = chapterCode;
	}

	public List<CeProvisionDto> getReadWiths() {
		return readWiths;
	}

	public void setReadWiths(List<CeProvisionDto> readWiths) {
		this.readWiths = readWiths;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public LocalDate getIneffectiveDate() {
		return ineffectiveDate;
	}

	public void setIneffectiveDate(LocalDate ineffectiveDate) {
		this.ineffectiveDate = ineffectiveDate;
	}

}
