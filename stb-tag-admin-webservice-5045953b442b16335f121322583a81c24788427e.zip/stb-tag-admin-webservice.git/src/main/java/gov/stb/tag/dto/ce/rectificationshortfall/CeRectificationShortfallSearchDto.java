package gov.stb.tag.dto.ce.rectificationshortfall;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeRectificationShortfallSearchDto extends TaApplicationSearchDto {

	private String aaRefNo;
	private LocalDateTime aaApprovedDate;
	private double shortfallAmount;
	private String triggerStatus;
	private String submissionStatus;

	public String getAaRefNo() {
		return aaRefNo;
	}

	public void setAaRefNo(String aaRefNo) {
		this.aaRefNo = aaRefNo;
	}

	public LocalDateTime getAaApprovedDate() {
		return aaApprovedDate;
	}

	public void setAaApprovedDate(LocalDateTime aaApprovedDate) {
		this.aaApprovedDate = aaApprovedDate;
	}

	public double getShortfallAmount() {
		return shortfallAmount;
	}

	public void setShortfallAmount(double shortfallAmount) {
		this.shortfallAmount = shortfallAmount;
	}

	public String getTriggerStatus() {
		return triggerStatus;
	}

	public void setTriggerStatus(String triggerStatus) {
		this.triggerStatus = triggerStatus;
	}

	public String getSubmissionStatus() {
		return submissionStatus;
	}

	public void setSubmissionStatus(String submissionStatus) {
		this.submissionStatus = submissionStatus;
	}
}
