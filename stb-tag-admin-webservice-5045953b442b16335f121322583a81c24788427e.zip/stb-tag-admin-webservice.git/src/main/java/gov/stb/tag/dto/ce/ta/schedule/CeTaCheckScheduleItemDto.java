package gov.stb.tag.dto.ce.ta.schedule;

import java.time.LocalDate;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.ViewCeTaCheckSchedulableItem;

public class CeTaCheckScheduleItemDto {

	private Integer id;
	private Integer addressId;
	private Integer lastTatiCheckId;
	private String taName;
	private String licenceNo;
	private String uen;
	private String block;
	private String floorUnit;
	private String building;
	private String street;
	private String postal;
	private String premisesType;
	private String addressType;
	private Integer noOfReds;
	private LocalDate lastAaFilingFyEndDate;
	private String lastAaFilingStatus;
	private String lastTatiCheckIsCompliant;
	private LocalDate lastTatiCheckDate;
	private Boolean lastCheckDone;
	private LocalDate licenceCeasedDate;
	private LocalDate licenceExpiryDate;
	private String licenceStatus;
	private String branchStatus;
	private String serviceType;
	private ListableDto checkType;
	private ListableDto eo;
	private ListableDto auxEo;
	private LocalDate scheduledDate;
	private Boolean isApproved = false;
	private Boolean isEditable = true;

	public static CeTaCheckScheduleItemDto buildFromSchedulableItem(Cache cache, ViewCeTaCheckSchedulableItem schedulableItem) {
		CeTaCheckScheduleItemDto dto = new CeTaCheckScheduleItemDto();

		dto.setAddressId(schedulableItem.getAddressId());
		dto.setTaName(schedulableItem.getTaName());
		dto.setUen(schedulableItem.getUen());
		dto.setLicenceNo(schedulableItem.getLicenceNo());
		dto.setBlock(schedulableItem.getBlock());
		dto.setFloorUnit(schedulableItem.getFloorUnit());
		dto.setBuilding(schedulableItem.getBuilding());
		dto.setStreet(schedulableItem.getStreet());
		dto.setPostal(schedulableItem.getPostal());
		dto.setPremisesType(schedulableItem.getPremiseTypeCode() != null ? cache.getType(schedulableItem.getPremiseTypeCode()).getLabel() : null);
		dto.setAddressType(schedulableItem.getAddressTypeCode() != null ? cache.getType(schedulableItem.getAddressTypeCode()).getLabel() : null);
		dto.setNoOfReds(schedulableItem.getNoOfReds());
		dto.setLastAaFilingFyEndDate(schedulableItem.getLastAaFilingFyEndDate());
		dto.setLastAaFilingStatus(schedulableItem.getLastAaFilingStatusCode() != null ? cache.getStatus(schedulableItem.getLastAaFilingStatusCode()).getLabel() : null);
		dto.setLicenceCeasedDate(schedulableItem.getLicenceCeasedDate());
		dto.setLicenceExpiryDate(schedulableItem.getLicenceExpiryDate());
		dto.setLicenceStatus(cache.getStatus(schedulableItem.getLicenceStatusCode()).getLabel());
		dto.setBranchStatus(schedulableItem.getBranchStatusCode() != null ? cache.getStatus(schedulableItem.getBranchStatusCode()).getLabel() : null);
		dto.setServiceType(schedulableItem.getServiceTypeCode() != null ? cache.getType(schedulableItem.getServiceTypeCode()).getLabel() : null);
		dto.setLastCheckDone(schedulableItem.getLastCheckDone());
		dto.setLastTatiCheckId(schedulableItem.getLastTatiCheckId());
		dto.setLastTatiCheckIsCompliant(schedulableItem.getLastTatiCheckIsCompliantCode() != null ? cache.getType(schedulableItem.getLastTatiCheckIsCompliantCode()).getLabel() : null);
		dto.setLastTatiCheckDate(schedulableItem.getLastTatiCheckDate());
		return dto;
	}

	public static CeTaCheckScheduleItemDto buildFromScheduleItem(Cache cache, CeTaCheckScheduleItem scheduleItem) {
		CeTaCheckScheduleItemDto dto = new CeTaCheckScheduleItemDto();
		dto.setId(scheduleItem.getId());
		dto.setAddressId(scheduleItem.getAddress().getId());
		dto.setTaName(scheduleItem.getTaName());
		dto.setUen(scheduleItem.getLicence().getTravelAgent().getUen());
		dto.setLicenceNo(scheduleItem.getLicence().getLicenceNo());
		dto.setBlock(scheduleItem.getAddress().getBlock());
		dto.setFloorUnit(scheduleItem.getAddress().toFloorUnit());
		dto.setBuilding(scheduleItem.getAddress().getBuilding());
		dto.setStreet(scheduleItem.getAddress().getStreet());
		dto.setPostal(scheduleItem.getAddress().getPostal());
		dto.setPremisesType(cache.getLabel(scheduleItem.getAddress().getPremiseType(), false));
		dto.setAddressType(cache.getLabel(scheduleItem.getAddressType(), false));
		dto.setNoOfReds(scheduleItem.getNoOfReds());
		dto.setLastAaFilingFyEndDate(scheduleItem.getLastAaFilingFyEndDate());
		dto.setLastAaFilingStatus(cache.getLabel(scheduleItem.getLastAaFilingStatus(), false));
		dto.setLicenceCeasedDate(scheduleItem.getLicenceCeasedDate());
		dto.setLicenceExpiryDate(scheduleItem.getLicenceExpiryDate());
		dto.setLicenceStatus(cache.getLabel(scheduleItem.getLicence().getStatus(), false));
		dto.setBranchStatus(cache.getLabel(scheduleItem.getBranchStatus(), false));
		dto.setServiceType(cache.getLabel(scheduleItem.getServiceType(), false));
		CeTaCheck lastTatiCheck = scheduleItem.getLastTatiCheck();
		if (lastTatiCheck != null) {
			dto.setLastTatiCheckIsCompliant(cache.getLabel(lastTatiCheck.getIsCompliant(), false));
			dto.setLastTatiCheckDate(lastTatiCheck.getCheckedDate().toLocalDate());
		}
		dto.setLastCheckDone(scheduleItem.getIsLastCheckDone());
		dto.setCheckType(new ListableDto(scheduleItem.getCheckType()));
		dto.setEo(new ListableDto(scheduleItem.getEoUser()));
		dto.setAuxEo(new ListableDto(scheduleItem.getAuxEoUser()));
		dto.setScheduledDate(scheduleItem.getScheduledDate());
		dto.setIsApproved(scheduleItem.isApproved());
		dto.setIsEditable(scheduleItem.isEditable());
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public Integer getLastTatiCheckId() {
		return lastTatiCheckId;
	}

	public void setLastTatiCheckId(Integer lastTatiCheckId) {
		this.lastTatiCheckId = lastTatiCheckId;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getFloorUnit() {
		return floorUnit;
	}

	public void setFloorUnit(String floorUnit) {
		this.floorUnit = floorUnit;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public String getPremisesType() {
		return premisesType;
	}

	public void setPremisesType(String premisesType) {
		this.premisesType = premisesType;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public Integer getNoOfReds() {
		return noOfReds;
	}

	public void setNoOfReds(Integer noOfReds) {
		this.noOfReds = noOfReds;
	}

	public LocalDate getLastAaFilingFyEndDate() {
		return lastAaFilingFyEndDate;
	}

	public void setLastAaFilingFyEndDate(LocalDate lastAaFilingFyEndDate) {
		this.lastAaFilingFyEndDate = lastAaFilingFyEndDate;
	}

	public String getLastAaFilingStatus() {
		return lastAaFilingStatus;
	}

	public void setLastAaFilingStatus(String lastAaFilingStatus) {
		this.lastAaFilingStatus = lastAaFilingStatus;
	}

	public String getLastTatiCheckIsCompliant() {
		return lastTatiCheckIsCompliant;
	}

	public void setLastTatiCheckIsCompliant(String lastTatiCheckIsCompliant) {
		this.lastTatiCheckIsCompliant = lastTatiCheckIsCompliant;
	}

	public Boolean getLastCheckDone() {
		return lastCheckDone;
	}

	public void setLastCheckDone(Boolean lastCheckDone) {
		this.lastCheckDone = lastCheckDone;
	}

	public LocalDate getLastTatiCheckDate() {
		return lastTatiCheckDate;
	}

	public void setLastTatiCheckDate(LocalDate lastTatiCheckDate) {
		this.lastTatiCheckDate = lastTatiCheckDate;
	}

	public LocalDate getLicenceCeasedDate() {
		return licenceCeasedDate;
	}

	public void setLicenceCeasedDate(LocalDate licenceCeasedDate) {
		this.licenceCeasedDate = licenceCeasedDate;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public String getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(String licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public String getBranchStatus() {
		return branchStatus;
	}

	public void setBranchStatus(String branchStatus) {
		this.branchStatus = branchStatus;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public ListableDto getCheckType() {
		return checkType;
	}

	public void setCheckType(ListableDto checkType) {
		this.checkType = checkType;
	}

	public ListableDto getEo() {
		return eo;
	}

	public void setEo(ListableDto eo) {
		this.eo = eo;
	}

	public ListableDto getAuxEo() {
		return auxEo;
	}

	public void setAuxEo(ListableDto auxEo) {
		this.auxEo = auxEo;
	}

	public LocalDate getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(LocalDate scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public Boolean getIsEditable() {
		return isEditable;
	}

	public void setIsEditable(Boolean isEditable) {
		this.isEditable = isEditable;
	}

}
