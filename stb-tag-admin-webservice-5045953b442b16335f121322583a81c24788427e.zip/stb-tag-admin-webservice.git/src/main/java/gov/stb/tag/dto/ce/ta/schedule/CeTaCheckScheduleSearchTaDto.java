package gov.stb.tag.dto.ce.ta.schedule;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeTaCheckScheduleSearchTaDto extends SearchDto {

	private String taName;

	private String licenceNo;

	private String uen;

	private String building;

	private String street;

	private String postal;

	private String[] premisesType;

	private String addressType;

	private Integer[] noOfReds;

	private String lastAaFilingStatus;

	private String[] lastTatiCheckIsCompliant; // Yes, No, NA

	private String lastTatiCheckDone; // Yes or No

	private String lastCheckDone; // Yes or No

	private LocalDate licenceCeasedDate;

	private LocalDate licenceExpiryDate;

	private String licenceStatus;

	private String branchStatus;

	private String[] serviceType;

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public String[] getPremisesType() {
		return premisesType;
	}

	public void setPremisesType(String[] premisesType) {
		this.premisesType = premisesType;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public Integer[] getNoOfReds() {
		return noOfReds;
	}

	public void setNoOfReds(Integer[] noOfReds) {
		this.noOfReds = noOfReds;
	}

	public String getLastAaFilingStatus() {
		return lastAaFilingStatus;
	}

	public void setLastAaFilingStatus(String lastAaFilingStatus) {
		this.lastAaFilingStatus = lastAaFilingStatus;
	}

	public String[] getLastTatiCheckIsCompliant() {
		return lastTatiCheckIsCompliant;
	}

	public void setLastTatiCheckIsCompliant(String[] lastTatiCheckIsCompliant) {
		this.lastTatiCheckIsCompliant = lastTatiCheckIsCompliant;
	}

	public String getLastTatiCheckDone() {
		return lastTatiCheckDone;
	}

	public void setLastTatiCheckDone(String lastTatiCheckDone) {
		this.lastTatiCheckDone = lastTatiCheckDone;
	}

	public String getLastCheckDone() {
		return lastCheckDone;
	}

	public void setLastCheckDone(String lastCheckDone) {
		this.lastCheckDone = lastCheckDone;
	}

	public LocalDate getLicenceCeasedDate() {
		return licenceCeasedDate;
	}

	public void setLicenceCeasedDate(LocalDate licenceCeasedDate) {
		this.licenceCeasedDate = licenceCeasedDate;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public String getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(String licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public String getBranchStatus() {
		return branchStatus;
	}

	public void setBranchStatus(String branchStatus) {
		this.branchStatus = branchStatus;
	}

	public String[] getServiceType() {
		return serviceType;
	}

	public void setServiceType(String[] serviceType) {
		this.serviceType = serviceType;
	}

}
