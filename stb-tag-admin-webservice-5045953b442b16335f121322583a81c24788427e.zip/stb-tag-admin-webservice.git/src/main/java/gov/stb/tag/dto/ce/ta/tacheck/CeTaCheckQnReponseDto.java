package gov.stb.tag.dto.ce.ta.tacheck;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckQn;
import gov.stb.tag.model.CeTaCheckQnResponse;

public class CeTaCheckQnReponseDto extends EntityDto {

	private Integer ceTaCheckQnId;

	private String title;

	private String question;

	private Boolean isGeneral;

	private Boolean isActive;

	private Integer ceTaCheckResponseId;

	private Boolean isYes;

	private String remarks;

	private Integer ordinal;

	public static CeTaCheckQnReponseDto buildQnOnly(Cache cache, CeTaCheckQn model, CeTaCheckQnReponseDto dto) {
		dto.setCeTaCheckQnId(model.getId());
		dto.setTitle(model.getTitle());
		dto.setQuestion(model.getQuestion());
		dto.setIsGeneral(model.isGeneral());
		dto.setIsActive(model.getIsActive());
		dto.setIsYes(Boolean.FALSE);
		dto.setOrdinal(model.getOrdinal());
		return dto;
	}

	public static CeTaCheckQnReponseDto buildQnAndReponse(Cache cache, CeTaCheckQnResponse model, CeTaCheckQnReponseDto dto) {
		dto = buildQnOnly(cache, model.getCeTaCheckQn(), dto);
		dto.setCeTaCheckResponseId(model.getId());
		dto.setIsYes(model.isYes());
		dto.setRemarks(model.getRemarks());
		return dto;
	}

	public static CeTaCheckQnResponse buildReponseDtoToModel(CeTaCheckQnResponse model, CeTaCheckQnReponseDto dto, CeTaCheckQn qnModel, CeTaCheck ceTaCheck) {
		model.setCeTaCheckQn(qnModel);
		model.setIsYes(dto.getIsYes());
		model.setRemarks(dto.getRemarks().trim());
		model.setCeTaCheck(ceTaCheck);
		return model;
	}

	public Integer getCeTaCheckQnId() {
		return ceTaCheckQnId;
	}

	public void setCeTaCheckQnId(Integer ceTaCheckQnId) {
		this.ceTaCheckQnId = ceTaCheckQnId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Boolean getIsGeneral() {
		return isGeneral;
	}

	public void setIsGeneral(Boolean isGeneral) {
		this.isGeneral = isGeneral;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getCeTaCheckResponseId() {
		return ceTaCheckResponseId;
	}

	public void setCeTaCheckResponseId(Integer ceTaCheckResponseId) {
		this.ceTaCheckResponseId = ceTaCheckResponseId;
	}

	public Boolean getIsYes() {
		return isYes;
	}

	public void setIsYes(Boolean isYes) {
		this.isYes = isYes;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

}
