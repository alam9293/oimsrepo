package gov.stb.tag.dto.ce.ta.tacheckreport;

import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ListableDto;

public class CeTaCheckReportTaDetailsDto {

	private String licenceNo;
	private String uen;
	private String taName;
	private String taContactNo;
	private AddressDto addressDto = new AddressDto();
	private ListableDto addressType = new ListableDto();

	private String taKeUin;
	private String taKeName;

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public String getTaContactNo() {
		return taContactNo;
	}

	public void setTaContactNo(String taContactNo) {
		this.taContactNo = taContactNo;
	}

	public AddressDto getAddressDto() {
		return addressDto;
	}

	public void setAddressDto(AddressDto addressDto) {
		this.addressDto = addressDto;
	}

	public ListableDto getAddressType() {
		return addressType;
	}

	public void setAddressType(ListableDto addressType) {
		this.addressType = addressType;
	}

	public String getTaKeUin() {
		return taKeUin;
	}

	public void setTaKeUin(String taKeUin) {
		this.taKeUin = taKeUin;
	}

	public String getTaKeName() {
		return taKeName;
	}

	public void setTaKeName(String taKeName) {
		this.taKeName = taKeName;
	}

}
