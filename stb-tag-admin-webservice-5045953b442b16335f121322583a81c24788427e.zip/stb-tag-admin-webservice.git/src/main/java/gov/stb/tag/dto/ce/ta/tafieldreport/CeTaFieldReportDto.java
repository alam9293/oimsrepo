package gov.stb.tag.dto.ce.ta.tafieldreport;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes.CE_TA_FIELD_REPORT_CLASS;
import gov.stb.tag.constant.Codes.CeSubmissionStatus;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.AuditableEntityDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.SignDocDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportPersonDetailsDto;
import gov.stb.tag.dto.ce.ta.tacheckreport.CeTaCheckReportTaDetailsDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTaFieldReport;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.UserRepository;

public class CeTaFieldReportDto extends AuditableEntityDto {
	private Integer ceTaCheckScheduleItemId;
	private Integer ceTaFieldReportId;
	private Integer ceCaseId;
	private String reportNo;
	private Boolean toSubmit = false;
	private String toRevisit;
	private String crmRefNo;
	private String caseNo;

	// TA Details
	private CeTaCheckReportTaDetailsDto taDetailsDto = new CeTaCheckReportTaDetailsDto();

	// Person Details
	private CeTaCheckReportPersonDetailsDto personDetailsDto = new CeTaCheckReportPersonDetailsDto();

	private String details;
	private ListableDto auxEo = new ListableDto();
	private String travelAgentOfficerName;
	String[] classificationsSelected;
	private List<String> classificationsSelectedLabels;
	private String otherClassification;
	private boolean disableEdit = Boolean.FALSE;
	private ListableDto submissionStatus = new ListableDto();

	private List<FileDto> attachments = new ArrayList<FileDto>();
	private List<Integer> deletedAttachements = new ArrayList<Integer>();

	// For Sign Doc
	private SignDocDto signDocDto;

	public static CeTaFieldReportDto buildFieldReportDtoFromFieldReportModel(Cache cache, CeTaFieldReport model, CeTaFieldReportDto dto, UserRepository userRepo) {
		if (model.getCeTaCheckScheduleItem() != null) {
			dto.setCeTaCheckScheduleItemId(model.getCeTaCheckScheduleItem().getId());
			dto.setToRevisit(model.getCeTaCheckScheduleItem().toRevisit());
		}
		dto.setCeTaFieldReportId(model.getId());
		dto.setReportNo(model.getReportNo());
		dto.setDetails(model.getDetails());

		dto.setCrmRefNo(model.getCrmRefNo());

		// TA details
		CeTaCheckReportTaDetailsDto taDetails = new CeTaCheckReportTaDetailsDto();
		taDetails.setLicenceNo(model.getLicenceNo());
		taDetails.setUen(model.getUen());
		taDetails.setTaName(model.getTaName());
		taDetails.setTaContactNo(model.getTaContactNo());
		taDetails.setAddressDto(AddressDto.buildFromAddress(cache, model.getAddress()));
		if (model.getAddressType() != null) {
			taDetails.setAddressType(new ListableDto(model.getAddressType()));
		}
		dto.setTaDetailsDto(taDetails);

		// Person details
		CeTaCheckReportPersonDetailsDto personDetails = new CeTaCheckReportPersonDetailsDto();
		personDetails.setUinPassportNo(model.getUinPassportNo());
		personDetails.setName(model.getName());
		personDetails.setRole(model.getRole());
		personDetails.setPersonContactNo(model.getPersonContactNo());
		// personDetails.setNationality(new ListableDto(model.getNationality()));
		dto.setPersonDetailsDto(personDetails);

		dto.setAuxEo(new ListableDto(model.getWitness()));
		dto.setTravelAgentOfficerName(model.getTaOfficerName());

		if (model.getClassifications() != null && model.getClassifications().size() > 0) {
			dto.setClassificationsSelected((model.getClassifications().parallelStream().map(Type::getCode).collect(Collectors.toList())).toArray(new String[model.getClassifications().size()]));
			if (!model.isDraft()) {
				dto.setClassificationsSelectedLabels(new ArrayList<String>());
				dto.getClassificationsSelectedLabels().addAll(
						model.getClassifications().parallelStream().filter(o -> !o.getCode().equalsIgnoreCase(CE_TA_FIELD_REPORT_CLASS.OTHERS)).map(Type::getLabel).collect(Collectors.toList()));
				if (model.getClassifications().contains(cache.getType(CE_TA_FIELD_REPORT_CLASS.OTHERS))) {
					dto.getClassificationsSelectedLabels().add(cache.getType(CE_TA_FIELD_REPORT_CLASS.OTHERS).getLabel().concat(": ").concat(model.getOtherClassification()));
				}
			}

		}
		dto.setOtherClassification(model.getOtherClassification());
		dto.setSubmissionStatus(new ListableDto(cache.getStatus(model.isDraft() ? CeSubmissionStatus.STAT_CE_SUBMISSION_DRAFT : CeSubmissionStatus.STAT_CE_SUBMISSION_SUBMITTED)));
		if (model.getFiles() != null && model.getFiles().size() > 0) {
			for (File row : model.getFiles()) {
				dto.getAttachments().add(FileDto.buildFromFile(row));
			}
		}

		if (model.getCeCase() != null) {
			dto.setCaseNo(model.getCeCase().getCaseNo());
			dto.setCeCaseId(model.getCeCase().getId());
		}

		dto.buildEditorDetailsFromModel(model, dto, userRepo);

		if (!Strings.isNullOrEmpty(model.getSigndocId())) {
			dto.setSignDocDto(new SignDocDto());
			dto.getSignDocDto().setSdweb_docid(model.getSigndocId());
		}

		return dto;

	}

	public static CeTaFieldReportDto buildNewFieldReportDto(Cache cache, CeTaCheckScheduleItem model, CeTaFieldReportDto dto, User currentUser) {
		if (model != null) {
			dto.setCeTaCheckScheduleItemId(model.getId());
			if (model.getAuxEoUser() != null) {
				dto.setAuxEo(new ListableDto(cache.getType(model.getAuxEoUser().getCode())));
			}
			CeTaCheckReportTaDetailsDto taDetails = new CeTaCheckReportTaDetailsDto();
			taDetails.setAddressDto(AddressDto.buildFromAddress(cache, model.getAddress()));
			taDetails.setAddressType(new ListableDto(model.getAddressType()));
			taDetails.setLicenceNo(model.getLicence().getLicenceNo());
			taDetails.setUen(model.getLicence().getTravelAgent().getUen());
			taDetails.setTaName(model.getTaName());
			dto.setTaDetailsDto(taDetails);
		}

		dto.setSubmissionStatus(new ListableDto(CeSubmissionStatus.STAT_CE_NEW, "New"));
		dto.buildEditorDetails(currentUser.getName(), LocalDateTime.now(), null, null, dto);

		return dto;
	}

	public Integer getCeTaCheckScheduleItemId() {
		return ceTaCheckScheduleItemId;
	}

	public void setCeTaCheckScheduleItemId(Integer ceTaCheckScheduleItemId) {
		this.ceTaCheckScheduleItemId = ceTaCheckScheduleItemId;
	}

	public Integer getCeTaFieldReportId() {
		return ceTaFieldReportId;
	}

	public void setCeTaFieldReportId(Integer ceTaFieldReportId) {
		this.ceTaFieldReportId = ceTaFieldReportId;
	}

	public Boolean getToSubmit() {
		return toSubmit;
	}

	public void setToSubmit(Boolean toSubmit) {
		this.toSubmit = toSubmit;
	}

	public ListableDto getAuxEo() {
		return auxEo;
	}

	public void setAuxEo(ListableDto auxEo) {
		this.auxEo = auxEo;
	}

	public String getTravelAgentOfficerName() {
		return travelAgentOfficerName;
	}

	public void setTravelAgentOfficerName(String travelAgentOfficerName) {
		this.travelAgentOfficerName = travelAgentOfficerName;
	}

	public CeTaCheckReportPersonDetailsDto getPersonDetailsDto() {
		return personDetailsDto;
	}

	public void setPersonDetailsDto(CeTaCheckReportPersonDetailsDto personDetailsDto) {
		this.personDetailsDto = personDetailsDto;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getReportNo() {
		return reportNo;
	}

	public void setReportNo(String reportNo) {
		this.reportNo = reportNo;
	}

	public String getOtherClassification() {
		return otherClassification;
	}

	public void setOtherClassification(String otherClassification) {
		this.otherClassification = otherClassification;
	}

	public String[] getClassificationsSelected() {
		return classificationsSelected;
	}

	public void setClassificationsSelected(String[] classificationsSelected) {
		this.classificationsSelected = classificationsSelected;
	}

	public boolean isDisableEdit() {
		return disableEdit;
	}

	public void setDisableEdit(boolean disableEdit) {
		this.disableEdit = disableEdit;
	}

	public ListableDto getSubmissionStatus() {
		return submissionStatus;
	}

	public void setSubmissionStatus(ListableDto submissionStatus) {
		this.submissionStatus = submissionStatus;
	}

	public CeTaCheckReportTaDetailsDto getTaDetailsDto() {
		return taDetailsDto;
	}

	public void setTaDetailsDto(CeTaCheckReportTaDetailsDto taDetailsDto) {
		this.taDetailsDto = taDetailsDto;
	}

	public List<Integer> getDeletedAttachements() {
		return deletedAttachements;
	}

	public void setDeletedAttachements(List<Integer> deletedAttachements) {
		this.deletedAttachements = deletedAttachements;
	}

	public List<FileDto> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<FileDto> attachments) {
		this.attachments = attachments;
	}

	public Boolean getToRevisit() {
		return Boolean.valueOf(toRevisit);
	}

	public void setToRevisit(Boolean toRevisit) {
		this.toRevisit = String.valueOf(toRevisit);
	}

	public String getCrmRefNo() {
		return crmRefNo;
	}

	public void setCrmRefNo(String crmRefNo) {
		this.crmRefNo = crmRefNo;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public Integer getCeCaseId() {
		return ceCaseId;
	}

	public void setCeCaseId(Integer ceCaseId) {
		this.ceCaseId = ceCaseId;
	}

	public SignDocDto getSignDocDto() {
		return signDocDto;
	}

	public void setSignDocDto(SignDocDto signDocDto) {
		this.signDocDto = signDocDto;
	}

	public List<String> getClassificationsSelectedLabels() {
		return classificationsSelectedLabels;
	}

	public void setClassificationsSelectedLabels(List<String> classificationsSelectedLabels) {
		this.classificationsSelectedLabels = classificationsSelectedLabels;
	}

	public void setToRevisit(String toRevisit) {
		this.toRevisit = toRevisit;
	}

}
