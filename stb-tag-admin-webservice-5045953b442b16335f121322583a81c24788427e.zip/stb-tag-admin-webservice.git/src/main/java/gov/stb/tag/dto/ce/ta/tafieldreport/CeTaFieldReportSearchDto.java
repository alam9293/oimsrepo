package gov.stb.tag.dto.ce.ta.tafieldreport;

import gov.stb.tag.dto.SignDocDto;

public class CeTaFieldReportSearchDto extends SignDocDto {
	private Integer ceTaCheckScheduleItemId;
	private Integer ceTaFieldReportId;
	private Integer ceCaseId;

	public Integer getCeTaCheckScheduleItemId() {
		return ceTaCheckScheduleItemId;
	}

	public void setCeTaCheckScheduleItemId(Integer ceTaCheckScheduleItemId) {
		this.ceTaCheckScheduleItemId = ceTaCheckScheduleItemId;
	}

	public Integer getCeTaFieldReportId() {
		return ceTaFieldReportId;
	}

	public void setCeTaFieldReportId(Integer ceTaFieldReportId) {
		this.ceTaFieldReportId = ceTaFieldReportId;
	}

	public Integer getCeCaseId() {
		return ceCaseId;
	}

	public void setCeCaseId(Integer ceCaseId) {
		this.ceCaseId = ceCaseId;
	}

}
