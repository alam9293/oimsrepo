package gov.stb.tag.dto.ce.tg.checkreports;

import com.fasterxml.jackson.annotation.JsonInclude;
import gov.stb.tag.dto.SearchDto;

import java.time.LocalDate;
import java.time.LocalDateTime;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeTgCheckReportSearchDto extends SearchDto {

    private Object[] meridiemTypes;
    private Object[] locationTypes;
    private Integer[] eoUsers;
    private LocalDate scheduleDateFrom;
    private LocalDate scheduleDateTo;

    public Object[] getMeridiemTypes() { return meridiemTypes; }

    public void setMeridiemTypes(Object[] meridiemTypes) { this.meridiemTypes = meridiemTypes; }

    public Object[] getLocationTypes() { return locationTypes; }

    public void setLocationTypes(Object[] locationTypes) { this.locationTypes = locationTypes; }

     public Integer[] getEoUsers() { return eoUsers; }

     public void setEoUsers(Integer[] eoUsers) { this.eoUsers = eoUsers; }

    public LocalDate getScheduleDateFrom() { return scheduleDateFrom; }

    public void setScheduleDateFrom(LocalDate scheduleDateFrom) { this.scheduleDateFrom = scheduleDateFrom; }

    public LocalDate getScheduleDateTo() { return scheduleDateTo; }

    public void setScheduleDateTo(LocalDate scheduleDateTo) { this.scheduleDateTo = scheduleDateTo; }
}
