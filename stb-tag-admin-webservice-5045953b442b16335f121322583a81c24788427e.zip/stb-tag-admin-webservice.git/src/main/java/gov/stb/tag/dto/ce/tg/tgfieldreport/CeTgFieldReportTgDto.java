package gov.stb.tag.dto.ce.tg.tgfieldreport;

import com.google.common.collect.Lists;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.TgHelper;
import gov.stb.tag.model.*;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CeTgFieldReportTgDto {

	// Person Details
	private Integer ceTgFieldReportTgId;
	private String uin;
	private String name;
	private String contactNo;
	private ListableDto nationality = new ListableDto();
	private Integer licenceId;
	private String licenceNo;
	private ListableDto licenceStatus = new ListableDto();
	private LocalDate licenceExpiryDate;
	private String approvedLanguages;
	private ListableDto ageGroup = new ListableDto();

	private String passportNo;
	private String role;
	private String taName;
	private String vehicleNo;
	private Integer noOfTourists;
	private ListableDto touristNationality = new ListableDto();
	private String hasValidLicence;
	private String isLicenceDisplayed;
	private String isPictureTallied;
	private String isLanguageApproved;
	private ListableDto guidingLanguageProvided = new ListableDto();
	private Integer noOfAntecedentRecords;

	private List<CeTgFieldReportTgInfringementDto> infringements = Lists.newArrayList();

	public static CeTgFieldReportTgDto buildTgDetails(Cache cache, TouristGuide touristGuide, Licence licence, Type ageGroup) {
		CeTgFieldReportTgDto resultDto = new CeTgFieldReportTgDto();

		if (touristGuide != null) {
			resultDto.setUin(touristGuide.getUin());
			resultDto.setName(touristGuide.getName());
			resultDto.setContactNo(touristGuide.getMobileNo());
			resultDto.setNationality(new ListableDto(touristGuide.getNationality()));
			resultDto.setAgeGroup(ageGroup != null ? new ListableDto(ageGroup) : new ListableDto());
		}

		if (licence != null) {
			resultDto.setLicenceId(licence.getId());
			resultDto.setLicenceNo(licence.getLicenceNo());
			resultDto.setLicenceStatus(new ListableDto(licence.getStatus()));
			resultDto.setApprovedLanguages(touristGuide.getGuidingLanguagesWithComma(cache));
			resultDto.setLicenceExpiryDate(licence.getExpiryDate());
		}

		return resultDto;
	}

	public static CeTgFieldReportTgDto buildUtgDetails(Cache cache, CeCaseInfringer ceCaseInfringer) {
		CeTgFieldReportTgDto resultDto = new CeTgFieldReportTgDto();
		resultDto.setUin(ceCaseInfringer.getUenUin());
		resultDto.setName(ceCaseInfringer.getName());
		resultDto.setNationality(new ListableDto(ceCaseInfringer.getNationality()));
		resultDto.setAgeGroup(new ListableDto(ceCaseInfringer.getAgeGroup()));
		return resultDto;
	}

	public static CeTgFieldReportTgDto buildFromCeTgFieldReportTg(Cache cache, CeTgFieldReportTg ceTgFieldReportTg) {
		CeTgFieldReportTgDto dto = new CeTgFieldReportTgDto();

		dto.setCeTgFieldReportTgId(ceTgFieldReportTg.getId());
		dto.setUin(ceTgFieldReportTg.getUin());
		dto.setPassportNo(ceTgFieldReportTg.getPassportNo());
		dto.setName(ceTgFieldReportTg.getName());
		dto.setContactNo(ceTgFieldReportTg.getContactNo());
		dto.setRole(ceTgFieldReportTg.getRole());
		dto.setTaName(ceTgFieldReportTg.getTaName());
		dto.setNationality(new ListableDto(ceTgFieldReportTg.getNationality()));
		dto.setVehicleNo(ceTgFieldReportTg.getVehicleNo());
		dto.setNoOfTourists(ceTgFieldReportTg.getNoOfTourists());
		dto.setTouristNationality(new ListableDto(ceTgFieldReportTg.getTouristNationality()));
		dto.setAgeGroup(new ListableDto(ceTgFieldReportTg.getAgeGroup()));
		dto.setGuidingLanguageProvided(new ListableDto(ceTgFieldReportTg.getGuidingLanguageProvided()));
		dto.setNoOfAntecedentRecords(ceTgFieldReportTg.getNoOfAntecedentRecords());

		// licence details
		if (ceTgFieldReportTg.getLicence() != null) {
			Licence licence = ceTgFieldReportTg.getLicence();
			dto.setLicenceId(licence.getId());
			dto.setLicenceNo(licence.getLicenceNo());
			dto.setLicenceStatus(new ListableDto(licence.getStatus()));
			dto.setApprovedLanguages(licence.getTouristGuide().getGuidingLanguagesWithComma(cache));
			dto.setLicenceExpiryDate(licence.getExpiryDate());
		}

		dto.setHasValidLicence(ceTgFieldReportTg.getHasValidLicence() != null ? ceTgFieldReportTg.getHasValidLicence().toString() : "na");
		dto.setIsLicenceDisplayed(ceTgFieldReportTg.isLicenceDisplayed() != null ? ceTgFieldReportTg.isLicenceDisplayed().toString() : "na");
		dto.setIsPictureTallied(ceTgFieldReportTg.isPictureTallied() != null ? ceTgFieldReportTg.isPictureTallied().toString() : "na");
		dto.setIsLanguageApproved(ceTgFieldReportTg.isLanguageApproved() != null ? ceTgFieldReportTg.isLanguageApproved().toString() : "na");

		// infringement details
		List<CeTgFieldReportTgInfringementDto> infringements = new ArrayList<>();
		Set<CeTgFieldReportTgInfringement> ceTgFieldReportTgInfringements = ceTgFieldReportTg.getCeTgFieldReportTgInfringements();
		for (CeTgFieldReportTgInfringement i : ceTgFieldReportTgInfringements) {
			infringements.add(CeTgFieldReportTgInfringementDto.buildFromCeTgFieldReportTgInfringement(cache, i));
		}
		dto.setInfringements(infringements);

		return dto;
	}

	public static CeTgFieldReportTg buildDtoToModel(Cache cache, CeTgFieldReportTg model, CeTgFieldReportTgDto dto, CeTgFieldReport ceTgFieldReport, Licence licence) {
		model.setCeTgFieldReport(ceTgFieldReport);

		model.setUin(StringUtils.isNotBlank(dto.getUin()) ? dto.getUin() : null);
		model.setPassportNo(dto.getPassportNo());
		model.setName(dto.getName());
		model.setContactNo(dto.getContactNo());
		model.setRole(dto.getRole());
		model.setTaName(dto.getTaName());
		model.setNationality(dto.getNationality().getKey() != null ? cache.getType(dto.getNationality().getKey().toString()) : null);
		model.setVehicleNo(dto.getVehicleNo());
		model.setNoOfTourists(dto.getNoOfTourists());
		model.setTouristNationality(dto.getTouristNationality().getKey() != null ? cache.getType(dto.getTouristNationality().getKey().toString()) : null);
		model.setAgeGroup(dto.getAgeGroup().getKey() != null ? cache.getType(dto.getAgeGroup().getKey().toString()) : null);
		model.setGuidingLanguageProvided(dto.getGuidingLanguageProvided().getKey() != null ? cache.getType(dto.getGuidingLanguageProvided().getKey().toString()) : null);
		model.setNoOfAntecedentRecords(dto.getNoOfAntecedentRecords());

		if (licence != null) {
			model.setLicence(licence);
			model.setLicenceStatus(cache.getStatus(dto.getLicenceStatus().getKey().toString()));
			model.setLicenceExpiryDate(licence.getExpiryDate());
			model.setApprovedLanguages(dto.getApprovedLanguages());
			model.setHasValidLicence(dto.getHasValidLicence() != null && !dto.getHasValidLicence().equalsIgnoreCase("na") ? Boolean.parseBoolean(dto.getHasValidLicence()) : null);
			model.setIsLicenceDisplayed(dto.getIsLicenceDisplayed() != null && !dto.getIsLicenceDisplayed().equalsIgnoreCase("na") ? Boolean.parseBoolean(dto.getIsLicenceDisplayed()) : null);
			model.setIsPictureTallied(dto.getIsPictureTallied() != null && !dto.getIsPictureTallied().equalsIgnoreCase("na") ? Boolean.parseBoolean(dto.getIsPictureTallied()) : null);
			model.setIsLanguageApproved(dto.getIsLanguageApproved() != null && !dto.getIsLanguageApproved().equalsIgnoreCase("na") ? Boolean.parseBoolean(dto.getIsLanguageApproved()) : null);
		}

		return model;
	}

	public Integer getCeTgFieldReportTgId() { return ceTgFieldReportTgId; }

	public void setCeTgFieldReportTgId(Integer ceTgFieldReportTgId) { this.ceTgFieldReportTgId = ceTgFieldReportTgId; }

	public String getUin() { return uin; }

	public void setUin(String uin) { this.uin = uin; }

	public String getName() { return name; }

	public void setName(String name) { this.name = name; }

	public String getContactNo() { return contactNo; }

	public void setContactNo(String contactNo) { this.contactNo = contactNo; }

	public ListableDto getNationality() { return nationality; }

	public void setNationality(ListableDto nationality) { this.nationality = nationality; }

	public Integer getLicenceId() { return licenceId; }

	public void setLicenceId(Integer licenceId) { this.licenceId = licenceId; }

	public String getLicenceNo() { return licenceNo; }

	public void setLicenceNo(String licenceNo) { this.licenceNo = licenceNo; }

	public ListableDto getLicenceStatus() { return licenceStatus; }

	public void setLicenceStatus(ListableDto licenceStatus) { this.licenceStatus = licenceStatus; }

	public LocalDate getLicenceExpiryDate() { return licenceExpiryDate; }

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) { this.licenceExpiryDate = licenceExpiryDate; }

	public String getApprovedLanguages() { return approvedLanguages; }

	public void setApprovedLanguages(String approvedLanguages) { this.approvedLanguages = approvedLanguages; }

	public ListableDto getAgeGroup() { return ageGroup; }

	public void setAgeGroup(ListableDto ageGroup) { this.ageGroup = ageGroup; }

	public String getPassportNo() { return passportNo; }

	public void setPassportNo(String passportNo) { this.passportNo = passportNo; }

	public String getRole() { return role; }

	public void setRole(String role) { this.role = role; }

	public String getTaName() { return taName; }

	public void setTaName(String taName) { this.taName = taName; }

	public String getVehicleNo() { return vehicleNo; }

	public void setVehicleNo(String vehicleNo) { this.vehicleNo = vehicleNo; }

	public Integer getNoOfTourists() { return noOfTourists; }

	public void setNoOfTourists(Integer noOfTourists) { this.noOfTourists = noOfTourists; }

	public ListableDto getTouristNationality() { return touristNationality; }

	public void setTouristNationality(ListableDto touristNationality) { this.touristNationality = touristNationality; }

	public String getHasValidLicence() { return hasValidLicence; }

	public void setHasValidLicence(String hasValidLicence) { this.hasValidLicence = hasValidLicence; }

	public String getIsLicenceDisplayed() { return isLicenceDisplayed; }

	public void setIsLicenceDisplayed(String isLicenceDisplayed) { this.isLicenceDisplayed = isLicenceDisplayed; }

	public String getIsPictureTallied() { return isPictureTallied; }

	public void setIsPictureTallied(String isPictureTallied) { this.isPictureTallied = isPictureTallied; }

	public String getIsLanguageApproved() { return isLanguageApproved; }

	public void setIsLanguageApproved(String isLanguageApproved) { this.isLanguageApproved = isLanguageApproved; }

	public List<CeTgFieldReportTgInfringementDto> getInfringements() { return infringements; }

	public void setInfringements(List<CeTgFieldReportTgInfringementDto> infringements) { this.infringements = infringements; }

	public ListableDto getGuidingLanguageProvided() { return guidingLanguageProvided; }

	public void setGuidingLanguageProvided(ListableDto guidingLanguageProvided) { this.guidingLanguageProvided = guidingLanguageProvided; }

	public Integer getNoOfAntecedentRecords() { return noOfAntecedentRecords; }

	public void setNoOfAntecedentRecords(Integer noOfAntecedentRecords) { this.noOfAntecedentRecords = noOfAntecedentRecords; }
}
