package gov.stb.tag.dto.ce.tg.tgfieldreport;

import com.google.common.collect.Lists;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ce.provision.CeProvisionDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CeTgFieldReportTgInfringementDto {

	private Integer infringementId;
	private CeProvisionDto offenceProvision;
	private CeProvisionDto readWith;
	private ListableDto recommendation;

	public static CeTgFieldReportTgInfringementDto buildFromCeTgFieldReportTgInfringement(Cache cache, CeTgFieldReportTgInfringement infringement) {
		CeTgFieldReportTgInfringementDto dto = new CeTgFieldReportTgInfringementDto();

		dto.setInfringementId(infringement.getId() != null ? infringement.getId() : null);
		dto.setOffenceProvision(infringement.getCeProvision() != null ? new CeProvisionDto(cache, infringement.getCeProvision(), false) : null);
		dto.setReadWith(infringement.getReadWith() != null ? new CeProvisionDto(cache, infringement.getReadWith(), false) : null);
		dto.setRecommendation(infringement.getRecommendedOutcome() != null ? new ListableDto(infringement.getRecommendedOutcome()) : null);

		return dto;
	}

	public Integer getInfringementId() {
		return infringementId;
	}

	public void setInfringementId(Integer infringementId) {
		this.infringementId = infringementId;
	}

	public CeProvisionDto getOffenceProvision() {
		return offenceProvision;
	}

	public void setOffenceProvision(CeProvisionDto offenceProvision) {
		this.offenceProvision = offenceProvision;
	}

	public CeProvisionDto getReadWith() { return readWith; }

	public void setReadWith(CeProvisionDto readWith) { this.readWith = readWith; }

	public ListableDto getRecommendation() {
		return recommendation;
	}

	public void setRecommendation(ListableDto recommendation) {
		this.recommendation = recommendation;
	}
}
