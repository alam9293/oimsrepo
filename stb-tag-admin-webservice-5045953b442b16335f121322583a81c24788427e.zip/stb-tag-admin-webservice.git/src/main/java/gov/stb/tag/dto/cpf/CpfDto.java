package gov.stb.tag.dto.cpf;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CpfDto {

	private CpfRDXSEMPSOperationDto RDXSEMPSOperation;

	private CpfRDXSEMPSOperationResponseDto RDXSEMPSOperationResponse;

	@JsonProperty("RDXSEMPSOperation")
	public CpfRDXSEMPSOperationDto getRDXSEMPSOperation() {
		return RDXSEMPSOperation;
	}

	@JsonProperty("RDXSEMPSOperation")
	public void setRDXSEMPSOperation(CpfRDXSEMPSOperationDto rDXSEMPSOperation) {
		RDXSEMPSOperation = rDXSEMPSOperation;
	}

	@JsonProperty("RDXSEMPSOperationResponse")
	public CpfRDXSEMPSOperationResponseDto getRDXSEMPSOperationResponse() {
		return RDXSEMPSOperationResponse;
	}

	@JsonProperty("RDXSEMPSOperationResponse")
	public void setRDXSEMPSOperationResponse(CpfRDXSEMPSOperationResponseDto rDXSEMPSOperationResponse) {
		RDXSEMPSOperationResponse = rDXSEMPSOperationResponse;
	}

}
