package gov.stb.tag.dto.cpf;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CpfRDXSEMPSOperationResponseDto {

	private CpfOutputDataDto output_data;

	public CpfOutputDataDto getOutput_data() {
		return output_data;
	}

	public void setOutput_data(CpfOutputDataDto output_data) {
		this.output_data = output_data;
	}

}
