package gov.stb.tag.dto.dashboard;

import java.time.LocalDate;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Licence;

public class LicenceDto {

	private Integer licenceId;

	private String licenceNumber;

	private ListableDto status;

	private LocalDate issueDate; // licence first issue date

	private LocalDate startDate; // latest renewed cycle start date

	private LocalDate expiryDate; // latest renewed cycle expiry date

	private ListableDto licenceTier;

	private Integer downloadFlag;

	private Boolean isDownloadButtonOn;

	private Integer viewFlag;

	public static LicenceDto buildFromLicence(Cache cache, Licence licence) {
		LicenceDto dto = new LicenceDto();
		dto.setStartDate(licence.getStartDate());
		dto.setExpiryDate(licence.getExpiryDate());
		dto.setIssueDate(licence.getIssueDate());
		dto.setLicenceNumber(licence.getLicenceNo());
		dto.setLicenceTier(new ListableDto(licence.getTier().getCode(), cache.getLabel(licence.getTier(), false)));
		dto.setLicenceId(licence.getId());
		String statusColor = "grey";
		switch (licence.getStatus().getCode()) {
		case Codes.Statuses.TG_ACTIVE:
			statusColor = "green";
			break;
		case Codes.Statuses.TG_INACTIVE:
			statusColor = "grey";
			break;
		case Codes.Statuses.TG_CANCELLED:
			statusColor = "grey";
			break;
		case Codes.Statuses.TG_REVOKED:
			statusColor = "red";
			break;
		case Codes.Statuses.TG_SUSPENDED:
			statusColor = "red";
			break;
		}
		dto.setStatus(new ListableDto(licence.getStatus().getCode(), cache.getLabel(licence.getStatus(), true), statusColor));
		dto.setDownloadFlag(licence.getIsDownloadable());
		dto.setIsDownloadButtonOn(false);
		dto.setViewFlag(licence.getIsViewable());
		return dto;
	}

	public static LicenceDto buildFromLicence(Cache cache, Licence licence, Boolean isDownloadButtonOn) {
		LicenceDto dto = new LicenceDto();
		dto.setStartDate(licence.getStartDate());
		dto.setExpiryDate(licence.getExpiryDate());
		dto.setIssueDate(licence.getIssueDate());
		dto.setLicenceNumber(licence.getLicenceNo());
		dto.setLicenceTier(new ListableDto(licence.getTier().getCode(), cache.getLabel(licence.getTier(), false)));
		dto.setLicenceId(licence.getId());
		String statusColor = "grey";
		switch (licence.getStatus().getCode()) {
		case Codes.Statuses.TG_ACTIVE:
			statusColor = "green";
			break;
		case Codes.Statuses.TG_INACTIVE:
			statusColor = "grey";
			break;
		case Codes.Statuses.TG_CANCELLED:
			statusColor = "grey";
			break;
		case Codes.Statuses.TG_REVOKED:
			statusColor = "red";
			break;
		case Codes.Statuses.TG_SUSPENDED:
			statusColor = "red";
			break;
		}
		dto.setStatus(new ListableDto(licence.getStatus().getCode(), cache.getLabel(licence.getStatus(), true), statusColor));
		dto.setDownloadFlag(licence.getIsDownloadable());
		dto.setIsDownloadButtonOn(isDownloadButtonOn);
		dto.setViewFlag(licence.getIsViewable());
		return dto;
	}

	public String getLicenceNumber() {
		return licenceNumber;
	}

	public void setLicenceNumber(String licenceNumber) {
		this.licenceNumber = licenceNumber;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public ListableDto getLicenceTier() {
		return licenceTier;
	}

	public void setLicenceTier(ListableDto licenceTier) {
		this.licenceTier = licenceTier;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public Integer getDownloadFlag() {
		return downloadFlag;
	}

	public void setDownloadFlag(Integer downloadFlag) {
		this.downloadFlag = downloadFlag;
	}

	public Boolean getIsDownloadButtonOn() {
		return isDownloadButtonOn;
	}

	public void setIsDownloadButtonOn(Boolean isDownloadButtonOn) {
		this.isDownloadButtonOn = isDownloadButtonOn;
	}

	public Integer getViewFlag() {
		return viewFlag;
	}

	public void setViewFlag(Integer viewFlag) {
		this.viewFlag = viewFlag;
	}
}
