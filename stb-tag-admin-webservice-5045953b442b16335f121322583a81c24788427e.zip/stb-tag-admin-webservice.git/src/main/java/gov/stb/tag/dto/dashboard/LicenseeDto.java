package gov.stb.tag.dto.dashboard;

import gov.stb.tag.dto.ListableDto;

public class LicenseeDto {

	private String name;

	private String licenceNumber;

	private ListableDto status;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNumber() {
		return licenceNumber;
	}

	public void setLicenceNumber(String licenceNumber) {
		this.licenceNumber = licenceNumber;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

}
