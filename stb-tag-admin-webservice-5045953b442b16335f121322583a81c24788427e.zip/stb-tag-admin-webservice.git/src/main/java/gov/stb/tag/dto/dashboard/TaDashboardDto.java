package gov.stb.tag.dto.dashboard;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.licenceRenewal.TaLicenceRenewalChecklist;

public class TaDashboardDto {

	private LicenceDto licence;

	private Long pendingActionsCount;

	private Long pendingApprovalCount;

	private BigDecimal outstandingPaymentAmount;

	private List<ListableDto> submissionDue;

	private TaLicenceRenewalChecklist renewalChecklist;

	private LocalDate renewalStart;
	private LocalDate renewalEnd;
	private boolean isRenewalPeriod = Boolean.FALSE;

	public LicenceDto getLicence() {
		return licence;
	}

	public void setLicence(LicenceDto licence) {
		this.licence = licence;
	}

	public Long getPendingActionsCount() {
		return pendingActionsCount;
	}

	public void setPendingActionsCount(Long pendingActionsCount) {
		this.pendingActionsCount = pendingActionsCount;
	}

	public Long getPendingApprovalCount() {
		return pendingApprovalCount;
	}

	public void setPendingApprovalCount(Long pendingApprovalCount) {
		this.pendingApprovalCount = pendingApprovalCount;
	}

	public BigDecimal getOutstandingPaymentAmount() {
		return outstandingPaymentAmount;
	}

	public void setOutstandingPaymentAmount(BigDecimal outstandingPaymentAmount) {
		this.outstandingPaymentAmount = outstandingPaymentAmount;
	}

	public List<ListableDto> getSubmissionDue() {
		return submissionDue;
	}

	public void setSubmissionDue(List<ListableDto> submissionDue) {
		this.submissionDue = submissionDue;
	}

	public TaLicenceRenewalChecklist getRenewalChecklist() {
		return renewalChecklist;
	}

	public void setRenewalChecklist(TaLicenceRenewalChecklist renewalChecklist) {
		this.renewalChecklist = renewalChecklist;
	}

	public LocalDate getRenewalStart() {
		return renewalStart;
	}

	public void setRenewalStart(LocalDate renewalStart) {
		this.renewalStart = renewalStart;
	}

	public LocalDate getRenewalEnd() {
		return renewalEnd;
	}

	public void setRenewalEnd(LocalDate renewalEnd) {
		this.renewalEnd = renewalEnd;
	}

	public boolean isRenewalPeriod() {
		return isRenewalPeriod;
	}

	public void setRenewalPeriod(boolean isRenewalPeriod) {
		this.isRenewalPeriod = isRenewalPeriod;
	}

}
