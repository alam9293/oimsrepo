package gov.stb.tag.dto.dashboard;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.User;

public class TgDashboardDto {

	private ListableDto licenceStatus;
	private ListableDto printStatus;

	private Integer daysLeftToExpire;

	private Integer pendingApplicationCount;

	private BigDecimal assignmentCount;

	private BigDecimal pdcHoursCount;

	public TgDashboardDto(Cache cache, User user, TgLicenceRenewal licenceRenewal, LocalDate licenceExpiryDate, Integer pendingApplicationCount, BigDecimal assignmentCount, BigDecimal pdcHoursCount) {
		this.licenceStatus = new ListableDto(cache.getStatus(user.getTouristGuide().getLicence().getStatus().getCode()));
		this.printStatus = new ListableDto();
		if (licenceRenewal != null) {
			Status printStatus = licenceRenewal.getApplication().getLicencePrintStatus();
			if (printStatus != null) {
				this.printStatus = new ListableDto(cache.getStatus(printStatus.getCode()));
			}
		}
		this.daysLeftToExpire = (int) ChronoUnit.DAYS.between(LocalDate.now(), licenceExpiryDate);
		this.pendingApplicationCount = pendingApplicationCount;
		this.assignmentCount = assignmentCount;
		this.pdcHoursCount = pdcHoursCount;
	}

	public ListableDto getPrintStatus() {
		return printStatus;
	}

	public void setPrintStatus(ListableDto printStatus) {
		this.printStatus = printStatus;
	}

	public Integer getDaysLeftToExpire() {
		return daysLeftToExpire;
	}

	public void setDaysLeftToExpire(Integer daysLeftToExpire) {
		this.daysLeftToExpire = daysLeftToExpire;
	}

	public Integer getPendingApplicationCount() {
		return pendingApplicationCount;
	}

	public void setPendingApplicationCount(Integer pendingApplicationCount) {
		this.pendingApplicationCount = pendingApplicationCount;
	}

	public BigDecimal getAssignmentCount() {
		return assignmentCount;
	}

	public void setAssignmentCount(BigDecimal assignmentCount) {
		this.assignmentCount = assignmentCount;
	}

	public BigDecimal getPdcHoursCount() {
		return pdcHoursCount;
	}

	public void setPdcHoursCount(BigDecimal pdcHoursCount) {
		this.pdcHoursCount = pdcHoursCount;
	}

	public ListableDto getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(ListableDto licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

}
