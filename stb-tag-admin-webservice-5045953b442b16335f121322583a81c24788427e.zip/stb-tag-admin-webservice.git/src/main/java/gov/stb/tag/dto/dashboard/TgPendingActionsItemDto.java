package gov.stb.tag.dto.dashboard;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgPendingActionsItemDto {

	@MapProjection(path = "id")
	private Integer applicationId;

	@MapProjection(path = "applicationNo")
	private String applicationNo;

	@MapProjection(path = "submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "isOfflineSubmission")
	private boolean isOfflineSubmission;

	@MapProjection(path = "licence.id")
	private Integer licenceId;

	@MapProjection(path = "licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "licence.touristGuide.name")
	private String name;

	@MapProjection(path = "licence.touristGuide.uin")
	private String uin;

	@MapProjection(path = "lastAction.status.label")
	private String status;

	@MapProjection(path = "lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "licencePrintStatus.label")
	private String licencePrintStatus;

	@MapProjection(path = "type.code")
	private String type;

	@MapProjection(path = "type.label")
	private String typeLabel;

	@MapProjection(path = "assignee.name")
	private String assignedOfficer;

	@MapProjection(path = "lastAction.externalRemarks")
	private String remarks;

	public TgPendingActionsItemDto() {

	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isOfflineSubmission() {
		return isOfflineSubmission;
	}

	public void setOfflineSubmission(boolean isOfflineSubmission) {
		this.isOfflineSubmission = isOfflineSubmission;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(String licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
