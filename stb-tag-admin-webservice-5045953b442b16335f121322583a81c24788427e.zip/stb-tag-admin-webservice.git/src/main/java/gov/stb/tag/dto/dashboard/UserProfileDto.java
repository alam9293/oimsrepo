package gov.stb.tag.dto.dashboard;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Set;

import com.google.common.collect.Sets;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;

public class UserProfileDto {

	private Integer id;

	private String loginId;

	private String name;

	private ListableDto status;

	private ListableDto role;

	private Set<ListableDto> assignedRoles;

	private LicenseeDto licensee;

	private LocalDateTime lastLoginDate;

	public UserProfileDto() {

	}

	public static UserProfileDto buildFromUser(Cache cache, User user, String defaultRole) {
		UserProfileDto dto = new UserProfileDto();
		dto.setId(user.getId());
		dto.setLoginId(user.getLoginId());
		dto.setName(user.getName());
		dto.setStatus(new ListableDto(user.getStatus().getCode(), cache.getLabel(user.getStatus(), false)));
		if (defaultRole != null) {
			dto.setRole(new ListableDto(defaultRole, cache.getLabel(cache.getRole(defaultRole), false)));
		}
		dto.setAssignedRoles(Sets.newHashSet());
		user.getRoles().forEach(r -> dto.getAssignedRoles().add(new ListableDto(r.getCode(), r.getLabel())));
		dto.setLastLoginDate(user.getLastLoginDate());
		if (!Objects.isNull(user.getType())) {
			LicenseeDto licensee = new LicenseeDto();
			if (user.getTravelAgent() != null) {
				TravelAgent ta = user.getTravelAgent();
				licensee.setName(ta.getName());
				licensee.setLicenceNumber(ta.getLicence().getLicenceNo());
				dto.setLicensee(licensee);
			} else if (user.getTouristGuide() != null) {
				TouristGuide tg = user.getTouristGuide();
				licensee.setName(tg.getName());
				licensee.setLicenceNumber(tg.getLicence().getLicenceNo());
				dto.setLicensee(licensee);
			}
		}
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public ListableDto getRole() {
		return role;
	}

	public void setRole(ListableDto role) {
		this.role = role;
	}

	public Set<ListableDto> getAssignedRoles() {
		return assignedRoles;
	}

	public void setAssignedRoles(Set<ListableDto> assignedRoles) {
		this.assignedRoles = assignedRoles;
	}

	public LicenseeDto getLicensee() {
		return licensee;
	}

	public void setLicensee(LicenseeDto licensee) {
		this.licensee = licensee;
	}

	public LocalDateTime getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(LocalDateTime lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

}
