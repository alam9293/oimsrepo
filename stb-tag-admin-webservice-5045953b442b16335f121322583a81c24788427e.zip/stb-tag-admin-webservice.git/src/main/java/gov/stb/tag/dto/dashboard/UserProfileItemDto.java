package gov.stb.tag.dto.dashboard;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.User;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserProfileItemDto extends EntityDto {

	@MapProjection(path = "id")
	protected Integer id;

	@MapProjection(path = "loginId")
	private String loginId;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "emailAddress")
	private String emailAddress;

	@MapProjection(path = "taAssigneeChars")
	private String taAssigneeChars;

	@MapProjection(path = "status.label")
	private String status;

	@MapProjection(path = "department.label")
	private String department;

	@MapProjection(path = "role")
	private String role;

	private List<String> userRoles;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getTaAssigneeChars() {
		return taAssigneeChars;
	}

	public void setTaAssigneeChars(String taAssigneeChars) {
		this.taAssigneeChars = taAssigneeChars;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<String> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<String> userRoles) {
		this.userRoles = userRoles;
	}

	public static UserProfileItemDto setListOfUser(Cache cache, User usr) {
		UserProfileItemDto userDto = new UserProfileItemDto();
		List<String> myRoles = new ArrayList<String>();

		if (usr.getId() != null) {
			userDto.setId(usr.getId());
		}
		if (!Strings.isNullOrEmpty(usr.getEmailAddress())) {
			userDto.setEmailAddress(usr.getEmailAddress());
		}
		if (!Strings.isNullOrEmpty(usr.getLoginId())) {
			userDto.setLoginId(usr.getLoginId());
		}
		if (!Strings.isNullOrEmpty(usr.getName())) {
			userDto.setName(usr.getName());
		}
		if (!Strings.isNullOrEmpty(usr.getTaAssigneeChars())) {
			userDto.setTaAssigneeChars(usr.getTaAssigneeChars());
		}
		if (usr.getStatus() != null) {
			userDto.setStatus(usr.getStatus().getLabel());
		}
		if (usr.getDepartment() != null) {
			userDto.setDepartment(usr.getDepartment().getLabel());
		}

		if (usr.getRoles() != null) {
			String roleStr = "";

			for (Role role : usr.getRoles()) {
				myRoles.add(role.getCode());
				if (Strings.isNullOrEmpty(roleStr)) {
					roleStr = role.getLabel();
				} else {
					roleStr = roleStr + ", " + role.getLabel();
				}
				userDto.setRole(roleStr);
			}
			userDto.setUserRoles(myRoles);
		}

		return userDto;
	}
}
