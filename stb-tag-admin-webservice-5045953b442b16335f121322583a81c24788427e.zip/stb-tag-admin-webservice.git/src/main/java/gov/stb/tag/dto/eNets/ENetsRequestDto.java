package gov.stb.tag.dto.eNets;

public class ENetsRequestDto {

	private String ss;

	private ENetsRequestMessageDto msg;

	public ENetsRequestDto() {
	}

	public String getSs() {
		return ss;
	}

	public void setSs(String ss) {
		this.ss = ss;
	}

	public ENetsRequestMessageDto getMsg() {
		return msg;
	}

	public void setMsg(ENetsRequestMessageDto msg) {
		this.msg = msg;
	}
}
