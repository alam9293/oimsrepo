package gov.stb.tag.dto.eNets;

public class ENetsTxnDto {

	private String keyId;

	private String hmac;

	private String payload;

	private Boolean isAllWaived = false;

	private String txnId;

	private ENetsRequestDto requestDto;

	public ENetsTxnDto() {
	}

	public ENetsRequestDto getRequestDto() {
		return requestDto;
	}

	public void setRequestDto(ENetsRequestDto requestDto) {
		this.requestDto = requestDto;
	}

	public String getKeyId() {
		return keyId;
	}

	public String getHmac() {
		return hmac;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	public void setHmac(String hmac) {
		this.hmac = hmac;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public Boolean getIsAllWaived() {
		return isAllWaived;
	}

	public void setIsAllWaived(Boolean isAllWaived) {
		this.isAllWaived = isAllWaived;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
}
