package gov.stb.tag.dto.emailing;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes.EmailBroadcastType;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.UserRepository;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailingDto extends EmailingItemDto {

	private String senderEmail; // To show in front end which email is used to send

	Integer[] licenceIds;

	private Boolean toSend;

	private ListableDto frequency;

	private List<FileDto> files = new ArrayList<FileDto>();
	private List<Integer> deletedFiles = new ArrayList<Integer>();

	private ListableDto emailType;

	private String[] tiers;
	private String[] licenceStatuses;
	private String[] guidingLanguages;

	private String snackbarMessage;
	private LocalDate minStartDate;

	public static EmailingDto buildEmailingDtoFromModel(Cache cache, EmailBroadcast model, EmailingDto dto, UserRepository userRepo) {
		dto.buildItemDtoFromEmailBroadcastModel(cache, model, dto, userRepo);
		dto.setFrequency(new ListableDto(model.getFrquency()));
		dto.setEmailType(new ListableDto(model.getType()));
		dto.setMinStartDate(model.getStartDate());

		// dto.setLicenceIds(model.getL);

		if (model.getFiles() != null && model.getFiles().size() > 0) {
			for (File row : model.getFiles()) {
				dto.getFiles().add(FileDto.buildFromFile(row));
			}
		}

		if (model.getType().getCode().equalsIgnoreCase(EmailBroadcastType.TG)) {
			if (model.getLicenceStatuses() != null) {
				List<String> licStatuses = model.getLicenceStatuses().stream().map(Status::getCode).collect(Collectors.toList());
				dto.setLicenceStatuses(licStatuses.toArray(new String[licStatuses.size()]));
			}

			if (model.getTiers() != null) {
				List<String> tiers = model.getTiers().stream().map(Type::getCode).collect(Collectors.toList());
				dto.setTiers(tiers.toArray(new String[tiers.size()]));
			}

			if (model.getGuidingLanguages() != null) {
				List<String> guidingLanguages = model.getGuidingLanguages().stream().map(Type::getCode).collect(Collectors.toList());
				dto.setGuidingLanguages(guidingLanguages.toArray(new String[guidingLanguages.size()]));
			}

		}

		return dto;

	}

	public Integer[] getLicenceIds() {
		return licenceIds;
	}

	public void setLicenceIds(Integer[] licenceIds) {
		this.licenceIds = licenceIds;
	}

	public ListableDto getFrequency() {
		return frequency;
	}

	public void setFrequency(ListableDto frequency) {
		this.frequency = frequency;
	}

	public List<Integer> getDeletedFiles() {
		return deletedFiles;
	}

	public void setDeletedFiles(List<Integer> deletedFiles) {
		this.deletedFiles = deletedFiles;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public ListableDto getEmailType() {
		return emailType;
	}

	public void setEmailType(ListableDto emailType) {
		this.emailType = emailType;
	}

	public Boolean toSend() {
		return toSend;
	}

	public void setToSend(Boolean toSend) {
		this.toSend = toSend;
	}

	public String getSenderEmail() {
		return senderEmail;
	}

	public void setSenderEmail(String senderEmail) {
		this.senderEmail = senderEmail;
	}

	public Boolean getToSend() {
		return toSend;
	}

	public String[] getLicenceStatuses() {
		return licenceStatuses;
	}

	public void setLicenceStatuses(String[] licenceStatuses) {
		this.licenceStatuses = licenceStatuses;
	}

	public String[] getTiers() {
		return tiers;
	}

	public void setTiers(String[] tiers) {
		this.tiers = tiers;
	}

	public String[] getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(String[] guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public String getSnackbarMessage() {
		return snackbarMessage;
	}

	public void setSnackbarMessage(String snackbarMessage) {
		this.snackbarMessage = snackbarMessage;
	}

	public LocalDate getMinStartDate() {
		return minStartDate;
	}

	public void setMinStartDate(LocalDate minStartDate) {
		this.minStartDate = minStartDate;
	}

}
