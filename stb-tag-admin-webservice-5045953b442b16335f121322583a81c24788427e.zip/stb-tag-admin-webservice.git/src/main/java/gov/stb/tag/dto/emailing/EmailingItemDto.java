package gov.stb.tag.dto.emailing;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.AuditableEntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.repository.UserRepository;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailingItemDto extends AuditableEntityDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "isActive")
	private Boolean isActive;

	@MapProjection(path = "content")
	private String content;

	@MapProjection(path = "subject")
	private String subject;

	@MapProjection(path = "lastSentDateTime")
	private LocalDateTime lastSentDateTime;

	@MapProjection(path = "isRecurring")
	private Boolean isRecurring;

	@MapProjection(path = "startDate")
	private LocalDate startDate;

	@MapProjection(path = "endDate")
	private LocalDate endDate;

	@MapProjection(path = "nextEmailDate")
	private LocalDate nextEmailDate;

	@MapProjection(path = "isSending")
	private Boolean isSending;

	public EmailingItemDto buildItemDtoFromEmailBroadcastModel(Cache cache, EmailBroadcast model, EmailingItemDto dto, UserRepository userRepo) {
		dto.buildEditorDetailsFromModel(model, dto, userRepo);
		dto.setId(model.getId());
		dto.setIsActive(model.isActive());
		dto.setContent(model.getContent());
		dto.setSubject(model.getSubject());
		dto.setLastSentDateTime(model.getLastSentDateTime());
		dto.setIsRecurring(model.isRecurring());
		dto.setStartDate(model.getStartDate());
		dto.setEndDate(model.getEndDate());
		dto.setNextEmailDate(model.getNextEmailDate());
		dto.setIsSending(model.isSending());
		return dto;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public LocalDateTime getLastSentDateTime() {
		return lastSentDateTime;
	}

	public void setLastSentDateTime(LocalDateTime lastSentDateTime) {
		this.lastSentDateTime = lastSentDateTime;
	}

	public Boolean getIsRecurring() {
		return isRecurring;
	}

	public void setIsRecurring(Boolean isRecurring) {
		this.isRecurring = isRecurring;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getNextEmailDate() {
		return nextEmailDate;
	}

	public void setNextEmailDate(LocalDate nextEmailDate) {
		this.nextEmailDate = nextEmailDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Boolean getIsSending() {
		return isSending;
	}

	public void setIsSending(Boolean isSending) {
		this.isSending = isSending;
	}

}
