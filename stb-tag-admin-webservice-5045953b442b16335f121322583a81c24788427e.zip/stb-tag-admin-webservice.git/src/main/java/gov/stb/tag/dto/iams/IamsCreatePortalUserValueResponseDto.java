package gov.stb.tag.dto.iams;

public class IamsCreatePortalUserValueResponseDto {

	private String uid;

	private String uri;

	public IamsCreatePortalUserValueResponseDto() {
	}

	public String getUid() {
		return uid;
	}

	public String getUri() {
		return uri;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

}
