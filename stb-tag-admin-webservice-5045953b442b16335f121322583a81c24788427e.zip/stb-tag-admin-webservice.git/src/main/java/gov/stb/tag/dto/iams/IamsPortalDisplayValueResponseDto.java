package gov.stb.tag.dto.iams;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IamsPortalDisplayValueResponseDto {

	private String xMarkedForDeletion;

	public IamsPortalDisplayValueResponseDto() {
	}

	@JsonProperty("XMarkedForDeletion")
	public String getxMarkedForDeletion() {
		return xMarkedForDeletion;
	}

	@JsonProperty("XMarkedForDeletion")
	public void setxMarkedForDeletion(String xMarkedForDeletion) {
		this.xMarkedForDeletion = xMarkedForDeletion;
	}
}
