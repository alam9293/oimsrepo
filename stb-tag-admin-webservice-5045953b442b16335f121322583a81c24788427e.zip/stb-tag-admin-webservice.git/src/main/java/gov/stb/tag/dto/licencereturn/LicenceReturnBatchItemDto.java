package gov.stb.tag.dto.licencereturn;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LicenceReturnBatchItemDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "dueDate")
	private LocalDate dueDate;

	@MapProjection(path = "licence.id")
	private Integer licenceId;

	@MapProjection(path = "licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "licence.travelAgent.name")
	private String name;

	@MapProjection(path = "licence.travelAgent.uen")
	private String uen;

	@MapProjection(path = "status.label")
	private String status;

	@MapProjection(path = "type.label")
	private String type;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
