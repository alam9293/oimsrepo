package gov.stb.tag.dto.payment;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.model.PaymentRequest;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentRequestItemDto extends EntityDto {

	@MapProjection(path = "id")
	protected Integer id;

	@MapProjection(path = "version")
	protected Integer version;

	@MapProjection(path = "billRefNo")
	private String billRefNo;

	@MapProjection(path = "refNo")
	private String refNo;

	@MapProjection(path = "payerUinUen")
	private String payerUinUen;

	@MapProjection(path = "payerName")
	private String payerName;

	@MapProjection(path = "payableAmount")
	private BigDecimal payableAmount;

	@MapProjection(path = "type.label")
	private String type;

	@MapProjection(path = "status.label")
	private String status;

	@MapProjection(path = "status.code")
	private String statusCode;

	@MapProjection(path = "lastTxn.status.label")
	private String lastTxnStatus;

	@MapProjection(path = "lastTxn.status.code")
	private String lastTxnStatusCode;

	@MapProjection(path = "lastTxn.txnDate")
	private LocalDateTime lastTxnDate;

	@MapProjection(path = "lastTxn.id")
	protected Integer lastTxnId;

	@MapProjection(path = "lastTxn.paymentType.label")
	private String lastTxnPaymentTypeLabel;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getPayerUinUen() {
		return payerUinUen;
	}

	public void setPayerUinUen(String payerUinUen) {
		this.payerUinUen = payerUinUen;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public BigDecimal getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(BigDecimal payableAmount) {
		this.payableAmount = payableAmount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getLastTxnStatus() {
		return lastTxnStatus;
	}

	public void setLastTxnStatus(String lastTxnStatus) {
		this.lastTxnStatus = lastTxnStatus;
	}

	public String getLastTxnStatusCode() {
		return lastTxnStatusCode;
	}

	public void setLastTxnStatusCode(String lastTxnStatusCode) {
		this.lastTxnStatusCode = lastTxnStatusCode;
	}

	public LocalDateTime getLastTxnDate() {
		return lastTxnDate;
	}

	public void setLastTxnDate(LocalDateTime lastTxnDate) {
		this.lastTxnDate = lastTxnDate;
	}

	@Override
	public String getEntityName() {
		return PaymentRequest.class.getSimpleName();
	}

	@Override
	public String getEntityId() {
		return id != null ? id.toString() : null;
	}

	public Integer getLastTxnId() {
		return lastTxnId;
	}

	public String getLastTxnPaymentTypeLabel() {
		return lastTxnPaymentTypeLabel;
	}

	public void setLastTxnId(Integer lastTxnId) {
		this.lastTxnId = lastTxnId;
	}

	public void setLastTxnPaymentTypeLabel(String lastTxnPaymentTypeLabel) {
		this.lastTxnPaymentTypeLabel = lastTxnPaymentTypeLabel;
	}

}
