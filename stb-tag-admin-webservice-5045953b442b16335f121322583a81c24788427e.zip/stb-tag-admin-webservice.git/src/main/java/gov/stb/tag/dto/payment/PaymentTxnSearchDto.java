package gov.stb.tag.dto.payment;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentTxnSearchDto extends SearchDto {

	private Integer id;
	private String status;
	private LocalDateTime txnDateFrom;
	private LocalDateTime txnDateTo;
	private String billRefNo;

	public PaymentTxnSearchDto() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getTxnDateFrom() {
		return txnDateFrom;
	}

	public void setTxnDateFrom(LocalDateTime txnDateFrom) {
		this.txnDateFrom = txnDateFrom;
	}

	public LocalDateTime getTxnDateTo() {
		return txnDateTo;
	}

	public void setTxnDateTo(LocalDateTime txnDateTo) {
		this.txnDateTo = txnDateTo;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

}
