package gov.stb.tag.dto.paynow;

public class AmtDtlsDto {

	private String txnCcy;

	private String txnAmt;

	public AmtDtlsDto() {
	}

	public String getTxnCcy() {
		return txnCcy;
	}

	public void setTxnCcy(String txnCcy) {
		this.txnCcy = txnCcy;
	}

	public String getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(String txnAmt) {
		this.txnAmt = txnAmt;
	}

}
