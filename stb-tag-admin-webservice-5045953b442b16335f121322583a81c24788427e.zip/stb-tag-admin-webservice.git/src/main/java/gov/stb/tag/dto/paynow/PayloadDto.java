package gov.stb.tag.dto.paynow;

public class PayloadDto {

	private HeaderDto header;

	private TxnInfoDto txnInfo;

	public PayloadDto() {
	}

	public TxnInfoDto getTxnInfo() {
		return txnInfo;
	}

	public void setTxnInfo(TxnInfoDto txnInfo) {
		this.txnInfo = txnInfo;
	}

	public HeaderDto getHeader() {
		return header;
	}

	public void setHeader(HeaderDto header) {
		this.header = header;
	}
}
