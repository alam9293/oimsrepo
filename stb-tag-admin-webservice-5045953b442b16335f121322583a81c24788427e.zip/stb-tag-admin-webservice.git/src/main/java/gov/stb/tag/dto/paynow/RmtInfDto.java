package gov.stb.tag.dto.paynow;

public class RmtInfDto {

	private String paymentDetails;

	private String purposeCode;

	public RmtInfDto() {
	}

	public String getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(String paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	public String getPurposeCode() {
		return purposeCode;
	}

	public void setPurposeCode(String purposeCode) {
		this.purposeCode = purposeCode;
	}

}
