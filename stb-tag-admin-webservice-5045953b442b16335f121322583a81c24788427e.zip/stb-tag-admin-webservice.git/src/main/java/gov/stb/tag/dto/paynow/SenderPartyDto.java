package gov.stb.tag.dto.paynow;

public class SenderPartyDto {

	private String name;

	private String senderBankId;

	public SenderPartyDto() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSenderBankId() {
		return senderBankId;
	}

	public void setSenderBankId(String senderBankId) {
		this.senderBankId = senderBankId;
	}

}
