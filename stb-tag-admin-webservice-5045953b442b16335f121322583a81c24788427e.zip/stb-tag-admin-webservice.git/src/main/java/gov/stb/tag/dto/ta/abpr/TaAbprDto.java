package gov.stb.tag.dto.ta.abpr;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ta.annualfiling.TaAnnualFilingDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaBusinessOperation;
import gov.stb.tag.model.TaFocusArea;
import gov.stb.tag.model.TaFunctionActivity;
import gov.stb.tag.model.TaSpecializedMarket;

public class TaAbprDto extends EntityDto {

	private BigDecimal inboundOp;
	private BigDecimal inboundOpPercent;
	private BigDecimal outboundOp;
	private BigDecimal outboundOpPercent;
	private Integer inboundGrpPax;
	private BigDecimal inboundGrpPaxPercent;
	private Integer outboundGrpPax;
	private BigDecimal outboundGrpPaxPercent;
	private Integer inboundFitPax;
	private BigDecimal inboundFitPaxPercent;
	private Integer outboundFitPax;
	private BigDecimal outboundFitPaxPercent;
	private Integer noOfEmployee;
	private BigDecimal operatingCost;
	private BigDecimal depreciation;
	private BigDecimal remuneration;
	private BigDecimal indirectTax;
	private Boolean hasOverseasBranch;
	private List<TaMarketSpecializationDto> inboundms = new ArrayList<>();
	private List<TaMarketSpecializationDto> outboundms = new ArrayList<>();
	private List<TaBusinessOperationDto> bo = new ArrayList<>();
	private List<TaAreaOfFocusDto> aof = new ArrayList<>();
	private List<TaFunctionActivityDto> fa = new ArrayList<>();
	private TaAnnualFilingDto annualFiling;

	public static TaAbprDto build(Cache cahce, TaAbprSubmission abpr) {
		TaAbprDto dto = new TaAbprDto();
		dto.setInboundOp(abpr.getInboundOp());
		dto.setInboundOpPercent(abpr.getInboundOpPercent());
		dto.setOutboundOp(abpr.getOutboundOp());
		dto.setOutboundOpPercent(abpr.getOutboundOpPercent());
		dto.setInboundGrpPax(abpr.getInboundGrpPax());
		dto.setInboundGrpPaxPercent(abpr.getInboundGrpPaxPercent());
		dto.setInboundFitPax(abpr.getInboundFitPax());
		dto.setInboundFitPaxPercent(abpr.getInboundFitPaxPercent());
		dto.setOutboundFitPax(abpr.getOutboundFitPax());
		dto.setOutboundFitPaxPercent(abpr.getOutboundFitPaxPercent());
		dto.setOutboundGrpPax(abpr.getOutboundGrpPax());
		dto.setOutboundGrpPaxPercent(abpr.getOutboundGrpPaxPercent());
		dto.setNoOfEmployee(abpr.getNoOfEmployee());
		dto.setOperatingCost(abpr.getOperatingCost());
		dto.setDepreciation(abpr.getDepreciation());
		dto.setRemuneration(abpr.getRemuneration());
		dto.setIndirectTax(abpr.getIndirectTax());
		dto.setHasOverseasBranch(abpr.hasOverseasBranch());

		Set<TaSpecializedMarket> mss = abpr.getTaSpecializedMarkets();
		if (CollectionUtils.isNotEmpty(mss)) {
			for (TaSpecializedMarket ms : abpr.getTaSpecializedMarkets()) {
				if (ms.getIsInbound()) {
					dto.getInboundms().add(TaMarketSpecializationDto.buildFromMS(cahce, ms));
				} else {
					dto.getOutboundms().add(TaMarketSpecializationDto.buildFromMS(cahce, ms));
				}
			}
		}

		Set<TaBusinessOperation> bos = abpr.getTaBusinessOperations();
		if (CollectionUtils.isNotEmpty(bos)) {
			for (TaBusinessOperation bo : abpr.getTaBusinessOperations()) {
				dto.getBo().add(TaBusinessOperationDto.buildFromBO(cahce, bo));

			}
		}

		Set<TaFocusArea> aofs = abpr.getTaFocusAreas();
		if (CollectionUtils.isNotEmpty(aofs)) {
			for (TaFocusArea aof : abpr.getTaFocusAreas()) {
				dto.getAof().add(TaAreaOfFocusDto.buildFromFA(cahce, aof));
			}
		}

		Set<TaFunctionActivity> fas = abpr.getTaFunctionActivities();
		if (CollectionUtils.isNotEmpty(fas)) {
			for (TaFunctionActivity fa : abpr.getTaFunctionActivities()) {
				dto.getFa().add(TaFunctionActivityDto.buildFromFA(cahce, fa));
			}
		}

		dto.setAnnualFiling(TaAnnualFilingDto.build(abpr.getTaAnnualFiling()));

		return dto;

	}

	public List<TaMarketSpecializationDto> getInboundms() {
		return inboundms;
	}

	public BigDecimal getInboundOpPercent() {
		return inboundOpPercent;
	}

	public void setInboundOpPercent(BigDecimal inboundOpPercent) {
		this.inboundOpPercent = inboundOpPercent;
	}

	public BigDecimal getOutboundOpPercent() {
		return outboundOpPercent;
	}

	public void setOutboundOpPercent(BigDecimal outboundOpPercent) {
		this.outboundOpPercent = outboundOpPercent;
	}

	public void setInboundms(List<TaMarketSpecializationDto> inboundms) {
		this.inboundms = inboundms;
	}

	public List<TaMarketSpecializationDto> getOutboundms() {
		return outboundms;
	}

	public void setOutboundms(List<TaMarketSpecializationDto> outboundms) {
		this.outboundms = outboundms;
	}

	public List<TaBusinessOperationDto> getBo() {
		return bo;
	}

	public void setBo(List<TaBusinessOperationDto> bo) {
		this.bo = bo;
	}

	public List<TaAreaOfFocusDto> getAof() {
		return aof;
	}

	public void setAof(List<TaAreaOfFocusDto> aof) {
		this.aof = aof;
	}

	public TaAnnualFilingDto getAnnualFiling() {
		return annualFiling;
	}

	public void setAnnualFiling(TaAnnualFilingDto annualFiling) {
		this.annualFiling = annualFiling;
	}

	public BigDecimal getInboundOp() {
		return inboundOp;
	}

	public void setInboundOp(BigDecimal inboundOp) {
		this.inboundOp = inboundOp;
	}

	public BigDecimal getOutboundOp() {
		return outboundOp;
	}

	public void setOutboundOp(BigDecimal outboundOp) {
		this.outboundOp = outboundOp;
	}

	public Integer getInboundGrpPax() {
		return inboundGrpPax;
	}

	public void setInboundGrpPax(Integer inboundGrpPax) {
		this.inboundGrpPax = inboundGrpPax;
	}

	public BigDecimal getInboundGrpPaxPercent() {
		return inboundGrpPaxPercent;
	}

	public void setInboundGrpPaxPercent(BigDecimal inboundGrpPaxPercent) {
		this.inboundGrpPaxPercent = inboundGrpPaxPercent;
	}

	public Integer getOutboundGrpPax() {
		return outboundGrpPax;
	}

	public void setOutboundGrpPax(Integer outboundGrpPax) {
		this.outboundGrpPax = outboundGrpPax;
	}

	public BigDecimal getOutboundGrpPaxPercent() {
		return outboundGrpPaxPercent;
	}

	public void setOutboundGrpPaxPercent(BigDecimal outboundGrpPaxPercent) {
		this.outboundGrpPaxPercent = outboundGrpPaxPercent;
	}

	public Integer getInboundFitPax() {
		return inboundFitPax;
	}

	public void setInboundFitPax(Integer inboundFitPax) {
		this.inboundFitPax = inboundFitPax;
	}

	public BigDecimal getInboundFitPaxPercent() {
		return inboundFitPaxPercent;
	}

	public void setInboundFitPaxPercent(BigDecimal inboundFitPaxPercent) {
		this.inboundFitPaxPercent = inboundFitPaxPercent;
	}

	public Integer getOutboundFitPax() {
		return outboundFitPax;
	}

	public void setOutboundFitPax(Integer outboundFitPax) {
		this.outboundFitPax = outboundFitPax;
	}

	public BigDecimal getOutboundFitPaxPercent() {
		return outboundFitPaxPercent;
	}

	public void setOutboundFitPaxPercent(BigDecimal outboundFitPaxPercent) {
		this.outboundFitPaxPercent = outboundFitPaxPercent;
	}

	public Integer getNoOfEmployee() {
		return noOfEmployee;
	}

	public void setNoOfEmployee(Integer noOfEmployee) {
		this.noOfEmployee = noOfEmployee;
	}

	public BigDecimal getOperatingCost() {
		return operatingCost;
	}

	public void setOperatingCost(BigDecimal operatingCost) {
		this.operatingCost = operatingCost;
	}

	public BigDecimal getDepreciation() {
		return depreciation;
	}

	public void setDepreciation(BigDecimal depreciation) {
		this.depreciation = depreciation;
	}

	public BigDecimal getRemuneration() {
		return remuneration;
	}

	public void setRemuneration(BigDecimal remuneration) {
		this.remuneration = remuneration;
	}

	public BigDecimal getIndirectTax() {
		return indirectTax;
	}

	public void setIndirectTax(BigDecimal indirectTax) {
		this.indirectTax = indirectTax;
	}

	public Boolean getHasOverseasBranch() {
		return hasOverseasBranch;
	}

	public void setHasOverseasBranch(Boolean hasOverseasBranch) {
		this.hasOverseasBranch = hasOverseasBranch;
	}

	public List<TaFunctionActivityDto> getFa() {
		return fa;
	}

	public void setFa(List<TaFunctionActivityDto> fa) {
		this.fa = fa;
	}

}
