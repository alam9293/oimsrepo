package gov.stb.tag.dto.ta.abpr;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaFunctionActivity;

public class TaFunctionActivityDto extends EntityDto {

	private Integer id;

	private ListableDto question;

	private Boolean isInbound;

	private Boolean isOutbound;

	public static TaFunctionActivityDto buildFromFA(Cache cache, TaFunctionActivity fa) {
		TaFunctionActivityDto dto = new TaFunctionActivityDto();
		dto.setId(fa.getId());
		dto.setQuestion(fa.getQuestion() != null ? new ListableDto(fa.getQuestion().getCode(), cache.getLabel(fa.getQuestion(), false)) : new ListableDto());
		dto.setIsInbound(fa.getIsInbound());
		dto.setIsOutbound(fa.getIsOutbound());
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ListableDto getQuestion() {
		return question;
	}

	public void setQuestion(ListableDto question) {
		this.question = question;
	}

	public Boolean getIsInbound() {
		return isInbound;
	}

	public void setIsInbound(Boolean isInbound) {
		this.isInbound = isInbound;
	}

	public Boolean getIsOutbound() {
		return isOutbound;
	}

	public void setIsOutbound(Boolean isOutbound) {
		this.isOutbound = isOutbound;
	}

}
