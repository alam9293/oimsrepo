package gov.stb.tag.dto.ta.abpr;

import java.math.BigDecimal;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaSpecializedMarket;

public class TaMarketSpecializationDto extends EntityDto {

	private Integer id;
	private ListableDto country;
	private BigDecimal percentage;
	private Boolean isInbound;

	public static TaMarketSpecializationDto buildFromMS(Cache cache, TaSpecializedMarket ms) {
		TaMarketSpecializationDto dto = new TaMarketSpecializationDto();
		dto.setId(ms.getId());
		dto.setCountry((ms.getCountry() != null) ? new ListableDto(ms.getCountry().getKey(), cache.getLabel(ms.getCountry(), false)) : new ListableDto());
		dto.setPercentage(ms.getPercent());
		dto.setIsInbound(ms.getIsInbound());
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ListableDto getCountry() {
		return country;
	}

	public void setCountry(ListableDto country) {
		this.country = country;
	}

	public BigDecimal getPercentage() {
		return percentage;
	}

	public void setPercentage(BigDecimal percentage) {
		this.percentage = percentage;
	}

	public Boolean getIsInbound() {
		return isInbound;
	}

	public void setIsInbound(Boolean isInbound) {
		this.isInbound = isInbound;
	}

}
