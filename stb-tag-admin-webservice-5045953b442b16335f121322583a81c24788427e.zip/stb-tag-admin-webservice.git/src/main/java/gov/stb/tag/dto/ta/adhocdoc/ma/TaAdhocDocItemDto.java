package gov.stb.tag.dto.ta.adhocdoc.ma;

import com.fasterxml.jackson.annotation.JsonInclude;
import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaAdhocDocItemDto extends TaApplicationItemDto {

	public TaAdhocDocItemDto() {

	}

}
