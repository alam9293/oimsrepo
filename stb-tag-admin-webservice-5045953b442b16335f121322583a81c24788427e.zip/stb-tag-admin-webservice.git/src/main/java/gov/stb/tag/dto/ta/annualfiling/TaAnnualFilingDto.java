package gov.stb.tag.dto.ta.annualfiling;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.model.TaFilingCondition;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaAnnualFilingDto extends EntityDto {

	@MapProjection(path = "taAnnualFiling.id")
	private Integer annualFilingId;

	// From TaAnnualFiling, Upon creation, this is the previous fy TaAnnualFiling's fyEndDate.
	@MapProjection(path = "taAnnualFiling.fyStartDate")
	private LocalDate fyStartDate;

	// From TaAnnualFiling, Upon creation, this is the current FYE. It can result to >12 mths (FYE update to future date) or <12 mths (FYE update to past date; system need
	// to find/update this)
	@MapProjection(path = "taAnnualFiling.fyEndDate")
	private LocalDate fyEndDate;

	// From TaAnnualFiling
	@MapProjection(path = "taAnnualFiling.dueDate")
	private LocalDate dueDate;

	@MapProjection(path = "taAnnualFiling.fy")
	private Integer annualFilingFy;

	// From TaAnnualFiling
	@MapProjection(path = "taAnnualFiling.requestedAsAtDate")
	private LocalDate requestedAsAtDate;

	@MapProjection(path = "taAnnualFiling.lastExtension.extendedDueDate")
	private LocalDate extendedDueDate;

	@MapProjection(path = "taAnnualFiling.lastExtension.toProceed")
	private Boolean toExtend;

	@MapProjection(path = "taAnnualFiling.lastExtension.remarks")
	private String extensionRemarks;

	@MapProjection(path = "taAnnualFiling.applicationType.code")
	private String typeCode;

	private String typeLabel;

	private String filingStatusLabel;

	@MapProjection(path = "taAnnualFiling.remarks")
	private String remarks;

	public static TaAnnualFilingDto build(TaFilingCondition annualFiling) {
		TaAnnualFilingDto dto = new TaAnnualFilingDto();
		dto.setAnnualFilingId(annualFiling.getId());
		dto.setFyStartDate(annualFiling.getFyStartDate());
		dto.setFyEndDate(annualFiling.getFyEndDate());
		dto.setDueDate(annualFiling.getDueDate());
		dto.setAnnualFilingFy(annualFiling.getFy());
		dto.setRequestedAsAtDate(annualFiling.getRequestedAsAtDate());
		dto.setTypeCode(annualFiling.getApplicationType().getCode());
		dto.setTypeLabel(annualFiling.getApplicationType().getLabel());
		dto.setFilingStatusLabel(annualFiling.getStatus().getLabel());
		if (annualFiling.getLastExtension() != null && annualFiling.getLastExtension().getToProceed()) {
			dto.setToExtend(annualFiling.getLastExtension().getToProceed());
			dto.setExtendedDueDate(annualFiling.getLastExtension().getExtendedDueDate());
			dto.setExtensionRemarks(annualFiling.getLastExtension().getRemarks());
		} else {
			dto.setToExtend(Boolean.FALSE);
		}
		dto.setRemarks(annualFiling.getRemarks());
		return dto;
	}

	public <T extends TaAnnualFilingDto> T buildFromModel(TaFilingCondition annualFiling, T dto) {
		dto.setAnnualFilingId(annualFiling.getId());
		dto.setFyStartDate(annualFiling.getFyStartDate());
		dto.setFyEndDate(annualFiling.getFyEndDate());
		dto.setDueDate(annualFiling.getDueDate());
		dto.setAnnualFilingFy(annualFiling.getFy());
		dto.setRequestedAsAtDate(annualFiling.getRequestedAsAtDate());
		dto.setTypeLabel(annualFiling.getApplicationType().getLabel());
		dto.setFilingStatusLabel(annualFiling.getStatus().getLabel());
		return dto;
	}

	public Integer getAnnualFilingId() {
		return annualFilingId;
	}

	public void setAnnualFilingId(Integer annualFilingId) {
		this.annualFilingId = annualFilingId;
	}

	public LocalDate getFyStartDate() {
		return fyStartDate;
	}

	public void setFyStartDate(LocalDate fyStartDate) {
		this.fyStartDate = fyStartDate;
	}

	public LocalDate getFyEndDate() {
		return fyEndDate;
	}

	public void setFyEndDate(LocalDate fyEndDate) {
		this.fyEndDate = fyEndDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public Integer getAnnualFilingFy() {
		return annualFilingFy;
	}

	public void setAnnualFilingFy(Integer annualFilingFy) {
		this.annualFilingFy = annualFilingFy;
	}

	public LocalDate getRequestedAsAtDate() {
		return requestedAsAtDate;
	}

	public void setRequestedAsAtDate(LocalDate requestedAsAtDate) {
		this.requestedAsAtDate = requestedAsAtDate;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

	public Boolean getToExtend() {
		return toExtend;
	}

	public void setToExtend(Boolean toExtend) {
		this.toExtend = toExtend;
	}

	public String getExtensionRemarks() {
		return extensionRemarks;
	}

	public void setExtensionRemarks(String extensionRemarks) {
		this.extensionRemarks = extensionRemarks;
	}

	public String getFilingStatusLabel() {
		return filingStatusLabel;
	}

	public void setFilingStatusLabel(String filingStatusLabel) {
		this.filingStatusLabel = filingStatusLabel;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
