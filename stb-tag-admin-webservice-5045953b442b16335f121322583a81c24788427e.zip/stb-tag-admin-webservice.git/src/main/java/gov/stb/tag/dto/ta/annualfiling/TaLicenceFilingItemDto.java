package gov.stb.tag.dto.ta.annualfiling;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.workflow.WorkflowItemDto;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.TaFilingConditionAmendment;
import gov.stb.tag.model.TaFilingConditionExtension;
import gov.stb.tag.model.TaFilingConditionExtensionAssessment;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceFilingItemDto extends WorkflowItemDto {

	private List<TaLicenceFilingExtensionDateDto> extensionDates;

	private Integer extensionAssessId;

	private LocalDateTime createdDate;

	public static TaLicenceFilingItemDto buildFilingItemDto(TaFilingConditionExtensionAssessment model, WorkflowHelper workflowHelper) {
		if (model.getTaFilingConditionExtensions() != null) {
			TaLicenceFilingItemDto dto = new TaLicenceFilingItemDto();
			dto.setExtensionAssessId(model.getId());
			dto.setCreatedDate(model.getCreatedDate());
			dto.setExtensionDates(new ArrayList<TaLicenceFilingExtensionDateDto>());
			for (TaFilingConditionExtension row : model.getTaFilingConditionExtensions()) {
				dto.getExtensionDates().add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(row, new TaLicenceFilingExtensionDateDto()));
			}
			dto.buildWorkflowDto(workflowHelper, model.getWorkflow(), dto);
			return dto;
		}

		return null;
	}

	public static TaLicenceFilingItemDto buildFilingItemDto(TaFilingConditionAmendment model, WorkflowHelper workflowHelper) {
		if (model.getTaFilingConditionExtensions() != null) {
			TaLicenceFilingItemDto dto = new TaLicenceFilingItemDto();
			dto.setExtensionAssessId(model.getId());
			dto.setCreatedDate(model.getCreatedDate());
			dto.setExtensionDates(new ArrayList<TaLicenceFilingExtensionDateDto>());
			for (TaFilingConditionExtension row : model.getTaFilingConditionExtensions()) {
				dto.getExtensionDates().add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(row, new TaLicenceFilingExtensionDateDto()));
			}
			dto.buildWorkflowDto(workflowHelper, model.getWorkflow(), dto);
			return dto;
		}

		return null;
	}

	public List<TaLicenceFilingExtensionDateDto> getExtensionDates() {
		return extensionDates;
	}

	public void setExtensionDates(List<TaLicenceFilingExtensionDateDto> extensionDates) {
		this.extensionDates = extensionDates;
	}

	public Integer getExtensionAssessId() {
		return extensionAssessId;
	}

	public void setExtensionAssessId(Integer extensionAssessId) {
		this.extensionAssessId = extensionAssessId;
	}

	@Override
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	@Override
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

}
