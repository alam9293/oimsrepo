package gov.stb.tag.dto.ta.annualfiling;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.workflow.TaWorkflowSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceFilingSearchDto extends TaWorkflowSearchDto {
	private Integer licenceId;
	private Integer excludeAssessmentId;
	private Object[] filingTypes;

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public Integer getExcludeAssessmentId() {
		return excludeAssessmentId;
	}

	public void setExcludeAssessmentId(Integer excludeAssessmentId) {
		this.excludeAssessmentId = excludeAssessmentId;
	}

	public Object[] getFilingTypes() {
		return filingTypes;
	}

	public void setFilingTypes(Object[] filingTypes) {
		this.filingTypes = filingTypes;
	}

}
