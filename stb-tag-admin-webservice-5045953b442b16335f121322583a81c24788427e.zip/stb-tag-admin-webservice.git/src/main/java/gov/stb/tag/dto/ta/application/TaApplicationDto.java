package gov.stb.tag.dto.ta.application;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.licence.TaLicenceDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaApplicationDto extends TaLicenceDto {

	private ListableDto applicationStatus;

	private Integer applicationId;

	private String applicationNo;

	private LocalDateTime submissionDate;

	private String externalRemarks;

	private String internalRemarks;

	private boolean offlineSubmission;

	private boolean draft;

	private boolean isFinalApproval;

	private ListableDto applicationType;

	private boolean isInLowestStep;

	public TaApplicationDto() {

	}

	public <T extends TaApplicationDto> T buildFromApplication(Cache cache, ApplicationHelper appHelper, Application app, T dto) {
		dto = dto.buildFromLicence(cache, app.getLicence(), dto);
		if (app.getId() != null) {
			dto.setApplicationId(app.getId());
			dto.setApplicationNo(app.getApplicationNo());
			dto.setOfflineSubmission(app.isOfflineSubmission());
			dto.setIsFinalApproval(appHelper.isFinalApproval(app));
			dto.setIsInLowestStep(appHelper.isInLowestStep(null, app));
			if (app.getLastAction() != null) {
				dto.setApplicationStatus(new ListableDto(app.getLastAction().getStatus().getCode(), cache.getLabel(app.getLastAction().getStatus(), false),
						cache.getLabel(app.getLastAction().getStatus(), true), null, null));
				dto.setSubmissionDate(app.getSubmissionDate() != null ? app.getSubmissionDate() : app.getCreatedDate());
				dto.setExternalRemarks(app.getLastAction().getExternalRemarks());
				dto.setInternalRemarks(app.getLastAction().getInternalRemarks());
			}
			if (app.getIsDraft() != null) {
				dto.setDraft(app.getIsDraft());
				if (app.isDraft()) {
					dto.setApplicationStatus(new ListableDto(Codes.Statuses.TA_APP_DRAFT, cache.getStatus(Codes.Statuses.TA_APP_DRAFT).getCode(),
							cache.getStatus(Codes.Statuses.TA_APP_DRAFT).getOtherLabel(), null, null));
				}

			}
			dto.setApplicationType(new ListableDto(app.getType().getCode(), app.getType().getLabel(), app.getType().getOtherLabel(), null, null));

		}
		return dto;

	}

	public ListableDto getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(ListableDto applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public boolean isOfflineSubmission() {
		return offlineSubmission;
	}

	public void setOfflineSubmission(boolean offlineSubmission) {
		this.offlineSubmission = offlineSubmission;
	}

	public boolean isDraft() {
		return draft;
	}

	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	public boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	public void setIsFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public ListableDto getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(ListableDto applicationType) {
		this.applicationType = applicationType;
	}

	public boolean getIsInLowestStep() {
		return isInLowestStep;
	}

	public void setIsInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}
}
