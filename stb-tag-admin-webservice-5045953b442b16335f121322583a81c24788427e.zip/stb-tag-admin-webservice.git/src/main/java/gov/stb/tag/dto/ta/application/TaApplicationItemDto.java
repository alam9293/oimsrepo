package gov.stb.tag.dto.ta.application;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaApplicationItemDto {

	@MapProjection(path = "id")
	private Integer applicationId;

	@MapProjection(path = "applicationNo")
	private String applicationNo;

	@MapProjection(path = "submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "isOfflineSubmission")
	private boolean isOfflineSubmission;

	@MapProjection(path = "licence.id")
	private Integer licenceId;

	@MapProjection(path = "licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "licence.travelAgent.name")
	private String name;

	@MapProjection(path = "licence.travelAgent.uen")
	private String uen;

	@MapProjection(path = "licence.expiryDate")
	private LocalDate licenceExpiryDate;

	@MapProjection(path = "lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "lastAction.status.label")
	private String status;

	@MapProjection(path = "lastAction.status.otherLabel")
	private String externalStatus;

	@MapProjection(path = "type.code")
	private String type;

	@MapProjection(path = "type.label")
	private String typeLabel;

	@MapProjection(path = "assignee.name")
	private String assignedOfficer;

	@MapProjection(path = "lastAction.externalRemarks")
	private String remarks;

	public TaApplicationItemDto() {

	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isOfflineSubmission() {
		return isOfflineSubmission;
	}

	public void setOfflineSubmission(boolean isOfflineSubmission) {
		this.isOfflineSubmission = isOfflineSubmission;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getExternalStatus() {
		return externalStatus;
	}

	public void setExternalStatus(String externalStatus) {
		this.externalStatus = externalStatus;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

}
