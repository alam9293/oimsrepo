package gov.stb.tag.dto.ta.application;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaApplicationSearchItemDto {

	@MapProjection(path = "application.id")
	private Integer applicationId;

	@MapProjection(path = "application.applicationNo")
	private String applicationNo;

	@MapProjection(path = "application.submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "application.isOfflineSubmission")
	private boolean isOfflineSubmission;

	@MapProjection(path = "application.licence.id")
	private Integer licenceId;

	@MapProjection(path = "application.licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "application.licence.travelAgent.name")
	private String name;

	@MapProjection(path = "companyName")
	private String nameCreation;

	@MapProjection(path = "uen")
	private String uenCreation;

	@MapProjection(path = "application.licence.travelAgent.uen")
	private String uen;

	@MapProjection(path = "application.lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "application.lastAction.status.label")
	private String status;

	@MapProjection(path = "application.lastAction.status.otherLabel")
	private String externalStatus;

	@MapProjection(path = "application.type.code")
	private String type;

	@MapProjection(path = "application.type.label")
	private String typeLabel;

	@MapProjection(path = "application.assignee.name")
	private String assignedOfficer;

	@MapProjection(path = "application.lastAction.externalRemarks")
	private String remarks;

	public TaApplicationSearchItemDto() {

	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isOfflineSubmission() {
		return isOfflineSubmission;
	}

	public void setOfflineSubmission(boolean isOfflineSubmission) {
		this.isOfflineSubmission = isOfflineSubmission;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getExternalStatus() {
		return externalStatus;
	}

	public void setExternalStatus(String externalStatus) {
		this.externalStatus = externalStatus;
	}

	public String getNameCreation() {
		return nameCreation;
	}

	public void setNameCreation(String nameCreation) {
		this.nameCreation = nameCreation;
	}

	public String getUenCreation() {
		return uenCreation;
	}

	public void setUenCreation(String uenCreation) {
		this.uenCreation = uenCreation;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
