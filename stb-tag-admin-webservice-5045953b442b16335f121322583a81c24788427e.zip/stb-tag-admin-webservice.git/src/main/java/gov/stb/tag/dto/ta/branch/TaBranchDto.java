package gov.stb.tag.dto.ta.branch;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaBranch;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaBranchDto extends EntityDto {

	@MapProjection(path = "address.id")
	private String branchId;

	@MapProjection(path = "address")
	private String address;

	@MapProjection(path = "status.code")
	private String status;

	@MapProjection(path = "status.label")
	private String statusLabel;

	@MapProjection(path = "type.label")
	private String type;

	@MapProjection(path = "ceasedDate")
	private LocalDate ceasedDate;

	@MapProjection(path = "ceasedReason")
	private String ceasedReason;

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusLabel() {
		return statusLabel;
	}

	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	public String getCeasedReason() {
		return ceasedReason;
	}

	public void setCeasedReason(String ceasedReason) {
		this.ceasedReason = ceasedReason;
	}

	public static TaBranchDto buildFromTaBranch(Cache cache, TaBranch taBranch) {
		TaBranchDto taBranchDto = new TaBranchDto();
		taBranchDto.setBranchId(taBranch.getId().toString());
		taBranchDto.setAddress(taBranch.getAddress().getFormattedAddressDisplay());
		taBranchDto.setStatus(taBranch.getStatus().getCode());
		taBranchDto.setStatusLabel(taBranch.getStatus().getLabel());
		taBranchDto.setCeasedDate(taBranch.getCeasedDate());
		taBranchDto.setCeasedReason(taBranch.getCeasedReason());
		return taBranchDto;

	}

}
