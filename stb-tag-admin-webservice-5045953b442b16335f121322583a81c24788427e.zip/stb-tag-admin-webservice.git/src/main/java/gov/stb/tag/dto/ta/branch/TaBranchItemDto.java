package gov.stb.tag.dto.ta.branch;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaBranchItemDto {

	@MapProjection(path = "id")
	private Integer applicationId;

	@MapProjection(path = "submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "licence.id")
	private Integer licenceNo;

	@MapProjection(path = "licence.travelAgent.name")
	private String name;

	@MapProjection(path = "licence.travelAgent.uen")
	private String uen;

	@MapProjection(path = "lastAction.status.label")
	private String status;

	// private String assignedOfficer;

	public TaBranchItemDto() {

	}

	public Integer getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(Integer licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
