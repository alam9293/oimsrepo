package gov.stb.tag.dto.ta.branchapplication;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaBranchApplication;
import gov.stb.tag.repository.BaseRepository;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaBranchApplicationBatchDto extends TaApplicationDto {
	@Autowired
	BaseRepository baseRepository;
	@Autowired
	protected CacheHelper cacheHelper;

	private List<TaBranchApplicationDto> taBranchApplicationDtoList;
	private String paymentStatus;
	private String billRefNo;
	private Boolean isConcluded;
	private PaymentRequestDto paymentRequestDto;
	private String paymentStatusLabel;

	private static boolean containsBranchApplicationId(List<TaBranchApplication> taBranchApplicationList, int id) {
		for (TaBranchApplication taBranchApplication : taBranchApplicationList) {
			if (taBranchApplication.getTaBranch() != null && taBranchApplication.getTaBranch().getId() == id) { // I used getId(), replace that by the accessor you actually need
				return true;
			}
		}
		return false;
	}

	public static TaBranchApplicationBatchDto buildFromApplication(CacheHelper cache, ApplicationHelper appHelper, PaymentHelper paymentHelper, List<TaBranchApplication> taBranchApplicationBatch,
			FileHelper fileHelper) {
		List<TaBranch> taActiveBranches = new ArrayList<TaBranch>();
		List<TaBranch> taCeasedBranches = new ArrayList<TaBranch>();
		return buildFromApplication(cache, appHelper, paymentHelper, taBranchApplicationBatch, taActiveBranches, taCeasedBranches, fileHelper);
	}

	public static TaBranchApplicationBatchDto buildFromApplication(CacheHelper cache, ApplicationHelper appHelper, PaymentHelper paymentHelper, List<TaBranchApplication> taBranchApplicationBatch,
			List<TaBranch> taActiveBranches, List<TaBranch> taCeasedBranches, FileHelper fileHelper) {
		TaBranchApplicationBatchDto dto = new TaBranchApplicationBatchDto();
		if (taBranchApplicationBatch.size() > 0) {
			dto = dto.buildFromApplication(cache, appHelper, taBranchApplicationBatch.get(0).getTaBranchApplicationBatch().getApplication(), dto);
		}
		List<TaBranchApplicationDto> ltaBranchApplicationDtoList = new ArrayList<TaBranchApplicationDto>();
		taActiveBranches.forEach((temp) -> {
			if (!containsBranchApplicationId(taBranchApplicationBatch, temp.getId())) {
				TaBranchApplicationDto taBranchApplicationDto = new TaBranchApplicationDto();
				taBranchApplicationDto.setFormatAddress(temp.getAddress().getFormattedAddressDisplay());
				taBranchApplicationDto.setSingleLineAddress(temp.getAddress().getSingleLineAddressDisplay());
				taBranchApplicationDto.setBranchId(temp.getId().toString());
				taBranchApplicationDto.setBlk(temp.getAddress().getBlock());
				taBranchApplicationDto.setStreet(temp.getAddress().getStreet());
				taBranchApplicationDto.setBuildingName(temp.getAddress().getBuilding());
				taBranchApplicationDto.setLevel(temp.getAddress().getFloor());
				taBranchApplicationDto.setUnit(temp.getAddress().getUnit());
				taBranchApplicationDto.setPostalCode(temp.getAddress().getPostal());
				taBranchApplicationDto.setPremisesType((temp.getAddress().getPremiseType() == null) ? "" : temp.getAddress().getPremiseType().getCode());
				taBranchApplicationDto.setSupportingDocument((temp.getTenancyDoc() == null) ? "" : temp.getTenancyDoc().getOriginalFilename());
				taBranchApplicationDto.setStatus(temp.getStatus().getCode());
				taBranchApplicationDto.setStatusLabel(temp.getStatus().getLabel());
				taBranchApplicationDto.setType(temp.getStatus().getLabel());
				ltaBranchApplicationDtoList.add(taBranchApplicationDto);
			}
		});
		taBranchApplicationBatch.forEach((temp) -> {
			TaBranchApplicationDto taBranchApplicationDto = new TaBranchApplicationDto();
			taBranchApplicationDto.setSingleLineAddress((temp.getAddress() == null) ? "" : temp.getAddress().getSingleLineAddressDisplay());
			taBranchApplicationDto.setFormatAddress((temp.getAddress() == null) ? "" : temp.getAddress().getFormattedAddressDisplay());
			taBranchApplicationDto.setApplicationBranchId(temp.getId().toString());
			taBranchApplicationDto.setTenancyStartDate(temp.getTenancyStartDate());
			taBranchApplicationDto.setTenancyEndDate(temp.getTenancyEndDate());
			taBranchApplicationDto.setSupportingDocument((temp.getTenancyDoc() == null) ? "" : temp.getTenancyDoc().getOriginalFilename());
			taBranchApplicationDto.setBranchId((temp.getTaBranch() == null) ? "" : temp.getTaBranch().getId().toString());
			TaBranchApplicationDto ltaBranchApplicationDto = new TaBranchApplicationDto();
			if (temp.getTaBranch() != null) {
				ltaBranchApplicationDto.setBranchId(temp.getTaBranch().getId().toString());
				ltaBranchApplicationDto.setFormatAddress(temp.getTaBranch().getAddress().getFormattedAddressDisplay());
				ltaBranchApplicationDto.setSingleLineAddress(temp.getTaBranch().getAddress().getSingleLineAddressDisplay());
				ltaBranchApplicationDto.setBlk(temp.getTaBranch().getAddress().getBlock());
				ltaBranchApplicationDto.setStreet(temp.getTaBranch().getAddress().getStreet());
				ltaBranchApplicationDto.setBuildingName(temp.getTaBranch().getAddress().getBuilding());
				ltaBranchApplicationDto.setLevel(temp.getTaBranch().getAddress().getFloor());
				ltaBranchApplicationDto.setUnit(temp.getTaBranch().getAddress().getUnit());
				ltaBranchApplicationDto.setPostalCode(temp.getTaBranch().getAddress().getPostal());
				ltaBranchApplicationDto.setPremisesType((temp.getTaBranch().getAddress().getPremiseType() == null) ? "" : temp.getTaBranch().getAddress().getPremiseType().getCode());
				ltaBranchApplicationDto.setStatus(temp.getTaBranch().getStatus().getCode());
				ltaBranchApplicationDto.setStatusLabel(temp.getTaBranch().getStatus().getLabel());
			}
			taBranchApplicationDto.setBlk(temp.getAddress().getBlock());
			taBranchApplicationDto.setStreet(temp.getAddress().getStreet());
			taBranchApplicationDto.setBuildingName(temp.getAddress().getBuilding());
			taBranchApplicationDto.setLevel(temp.getAddress().getFloor());
			taBranchApplicationDto.setUnit(temp.getAddress().getUnit());
			taBranchApplicationDto.setPostalCode(temp.getAddress().getPostal());
			taBranchApplicationDto.setPremisesType((temp.getAddress().getPremiseType() == null) ? "" : temp.getAddress().getPremiseType().getCode());
			taBranchApplicationDto.setStatus(temp.getStatus().getCode());
			taBranchApplicationDto.setStatusLabel(temp.getStatus().getLabel());
			taBranchApplicationDto.setToReplace(ltaBranchApplicationDto);
			taBranchApplicationDto.setPreviousBranches((temp.getTaBranch() == null) ? "" : temp.getTaBranch().getAddress().getAddressDisplay());
			taBranchApplicationDto.setType(temp.getType().getLabel());
			taBranchApplicationDto.setSelectedFile(FileDto.buildFromFile(temp.getTenancyDoc(), null, fileHelper));
			ltaBranchApplicationDtoList.add(taBranchApplicationDto);

		});
		taCeasedBranches.forEach((temp) -> {
			TaBranchApplicationDto taBranchApplicationDto = new TaBranchApplicationDto();
			taBranchApplicationDto.setFormatAddress(temp.getAddress().getFormattedAddressDisplay());
			taBranchApplicationDto.setSingleLineAddress(temp.getAddress().getSingleLineAddressDisplay());
			taBranchApplicationDto.setBranchId(temp.getId().toString());
			taBranchApplicationDto.setBlk(temp.getAddress().getBlock());
			taBranchApplicationDto.setStreet(temp.getAddress().getStreet());
			taBranchApplicationDto.setBuildingName(temp.getAddress().getBuilding());
			taBranchApplicationDto.setLevel(temp.getAddress().getFloor());
			taBranchApplicationDto.setUnit(temp.getAddress().getUnit());
			taBranchApplicationDto.setPostalCode(temp.getAddress().getPostal());
			taBranchApplicationDto.setPremisesType((temp.getAddress().getPremiseType() == null) ? "" : temp.getAddress().getPremiseType().getCode());
			// taBranchApplicationDto.setSupportingDocument((temp.getTenancyDoc() == null) ? "" : temp.getTenancyDoc().getOriginalFilename());
			taBranchApplicationDto.setStatus(temp.getStatus().getCode());
			taBranchApplicationDto.setStatusLabel(temp.getStatus().getLabel());
			taBranchApplicationDto.setType(temp.getStatus().getLabel());
			taBranchApplicationDto.setCeasedDate(temp.getCeasedDate());
			ltaBranchApplicationDtoList.add(taBranchApplicationDto);

		});
		if (taBranchApplicationBatch.size() > 0) {
			PaymentRequest req = paymentHelper.getPaymentRequest(taBranchApplicationBatch.get(0).getTaBranchApplicationBatch().getAppFeeBillRefNo());

			if (req != null) {
				dto.setIsConcluded(taBranchApplicationBatch.get(0).getTaBranchApplicationBatch().getIsConcluded());
				dto.setPaymentStatus(req.getStatus().getCode());
				dto.setPaymentStatusLabel(req.getStatus().getLabel());
				dto.setBillRefNo(req.getBillRefNo());
				dto.setPaymentRequestDto(new PaymentRequestDto(cache, req, false));

			}

		}
		dto.setTaBranchApplicationDtoList(ltaBranchApplicationDtoList);
		return dto;
	}

	public List<TaBranchApplicationDto> getTaBranchApplicationDtoList() {
		return taBranchApplicationDtoList;
	}

	public void setTaBranchApplicationDtoList(List<TaBranchApplicationDto> taBranchApplicationDtoList) {
		this.taBranchApplicationDtoList = taBranchApplicationDtoList;
	}

	public Boolean getIsConcluded() {
		return isConcluded;
	}

	public void setIsConcluded(Boolean isConcluded) {
		this.isConcluded = isConcluded;
	}

	public PaymentRequestDto getPaymentRequestDto() {
		return paymentRequestDto;
	}

	public void setPaymentRequestDto(PaymentRequestDto paymentRequestDto) {
		this.paymentRequestDto = paymentRequestDto;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getPaymentStatusLabel() {
		return paymentStatusLabel;
	}

	public void setPaymentStatusLabel(String paymentStatusLabel) {
		this.paymentStatusLabel = paymentStatusLabel;
	}

}
