package gov.stb.tag.dto.ta.branchapplication;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaBranchApplicationBatchItemDto {

	@MapProjection(path = "id")
	private Integer applicationId;

	@MapProjection(path = "address")
	private String address;

	@MapProjection(path = "status.label")
	private String status;

	@MapProjection(path = "type.label")
	private String type;

	@MapProjection(path = "tenancyDoc.publicFileId")
	private Integer publicFileId;

	@MapProjection(path = "tenancyDoc.filename")
	private String filename;

	@MapProjection(path = "tenancyDoc.originalFilename")
	private String originalFilename;

	@MapProjection(path = "tenancyDoc.path")
	private String path;

	public Integer getPublicFileId() {
		return publicFileId;
	}

	public void setPublicFileId(Integer publicFileId) {
		this.publicFileId = publicFileId;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getOriginalFilename() {
		return originalFilename;
	}

	public void setOriginalFilename(String originalFilename) {
		this.originalFilename = originalFilename;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public TaBranchApplicationBatchItemDto() {

	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
