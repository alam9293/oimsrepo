package gov.stb.tag.dto.ta.branchapplication;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.dto.ta.branch.TaBranchDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaBranchApplication;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaBranchApplicationDto extends TaApplicationDto {
	private String applicationBranchId;
	private String branchFormerId;
	private String branchId;
	private String singleLineAddress;
	private String formatAddress;
	private String formattedAddress;
	private String blk;
	private String street;
	private String buildingName;
	private String level;
	private String unit;
	private String postalCode;
	private String premisesType;
	private LocalDate tenancyStartDate;
	private LocalDate tenancyEndDate;
	private String supportingDocument;
	private String status;
	private String statusLabel;
	// private String applicationType;
	private TaBranchApplicationDto toReplace;
	private String previousBranches;
	private String fileName;
	private FileDto selectedFile;
	private String type;
	private List<TaBranchDto> taBranchDtoList;
	private TaBranchDto taBranchDto;
	private LocalDate ceasedDate;

	private List<TaBranchApplication> taBranchApplicationList;
	// List<TaBranchApplicationBatchItemDto> taBranchApplicationBatchItemDto;
	ResultDto<TaBranchApplicationBatchItemDto> taBranchApplicationBatchItemDto;

	public ResultDto<TaBranchApplicationBatchItemDto> getTaBranchApplicationBatchItemDto() {
		return taBranchApplicationBatchItemDto;
	}

	public void setTaBranchApplicationBatchItemDto(ResultDto<TaBranchApplicationBatchItemDto> taBranchApplicationBatchItemDto) {
		this.taBranchApplicationBatchItemDto = taBranchApplicationBatchItemDto;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPremisesType() {
		return premisesType;
	}

	public void setPremisesType(String premisesType) {
		this.premisesType = premisesType;
	}

	public LocalDate getTenancyStartDate() {
		return tenancyStartDate;
	}

	public void setTenancyStartDate(LocalDate tenancyStartDate) {
		this.tenancyStartDate = tenancyStartDate;
	}

	public LocalDate getTenancyEndDate() {
		return tenancyEndDate;
	}

	public void setTenancyEndDate(LocalDate tenancyEndDate) {
		this.tenancyEndDate = tenancyEndDate;
	}

	public String getSupportingDocument() {
		return supportingDocument;
	}

	public void setSupportingDocument(String supportingDocument) {
		this.supportingDocument = supportingDocument;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	// public String getApplicationType() {
	// return applicationType;
	// }
	//
	// public void setApplicationType(String applicationType) {
	// this.applicationType = applicationType;
	// }

	// public TaBranchApplicationDto getToReplace() {
	// return toReplace;
	// }
	//
	// public void setToReplace(TaBranchApplicationDto toReplace) {
	// this.toReplace = toReplace;
	// }

	public String getPreviousBranches() {
		return previousBranches;
	}

	public void setPreviousBranches(String previousBranches) {
		this.previousBranches = previousBranches;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getBlk() {
		return blk;
	}

	public void setBlk(String blk) {
		this.blk = blk;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public TaBranchApplicationDto() {

	}

	public String getBranchFormerId() {
		return branchFormerId;
	}

	public void setBranchFormerId(String branchFormerId) {
		this.branchFormerId = branchFormerId;
	}

	public static TaBranchApplicationDto buildFromApplication(Cache cache, ApplicationHelper appHelper, List<TaBranchApplication> taBranchApplicationList, List<TaBranchDto> ltaBranch) {
		TaBranchApplicationDto dto = new TaBranchApplicationDto();
		dto = dto.buildFromApplication(cache, appHelper, taBranchApplicationList.get(0).getTaBranchApplicationBatch().getApplication(), dto);
		dto.setTaBranchDtoList(ltaBranch);
		// dto.setTaBranchApplicationList(taBranchApplicationList);

		// TODO - ADD Suppporting DOC
		// dto.setTaBranchApplications(taBranchApplication.getTaBranchApplicationBatch().getTaBranchApplications());
		// List<ListableDto> otherDocuments = new ArrayList<ListableDto>();
		// dto.setOtherDocuments(otherDocuments);
		return dto;
	}

	public static TaBranchApplicationDto buildFromApplication(Cache cache, ApplicationHelper appHelper, TaBranchApplication taBranchApplication) {
		TaBranchApplicationDto dto = new TaBranchApplicationDto();
		dto = dto.buildFromApplication(cache, appHelper, taBranchApplication.getTaBranchApplicationBatch().getApplication(), dto);

		// TODO - ADD Suppporting DOC
		// dto.setTaBranchApplications(taBranchApplication.getTaBranchApplicationBatch().getTaBranchApplications());
		// List<ListableDto> otherDocuments = new ArrayList<ListableDto>();
		// dto.setOtherDocuments(otherDocuments);
		return dto;
	}

	public static TaBranchApplicationDto buildFromApplication(Cache cache, ApplicationHelper appHelper, TaBranchApplication taBranchApplication,
			ResultDto<TaBranchApplicationBatchItemDto> taBranchApplicationBatchItemDto) {
		TaBranchApplicationDto dto = new TaBranchApplicationDto();
		dto = dto.buildFromApplication(cache, appHelper, taBranchApplication.getTaBranchApplicationBatch().getApplication(), dto);
		dto.setTaBranchApplicationBatchItemDto(taBranchApplicationBatchItemDto);
		// TODO - ADD Suppporting DOC
		// dto.setTaBranchApplications(taBranchApplication.getTaBranchApplicationBatch().getTaBranchApplications());
		// List<ListableDto> otherDocuments = new ArrayList<ListableDto>();
		// dto.setOtherDocuments(otherDocuments);
		return dto;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public FileDto getSelectedFile() {
		return selectedFile;
	}

	public void setSelectedFile(FileDto selectedFile) {
		this.selectedFile = selectedFile;
	}

	public List<TaBranchDto> getTaBranchDtoList() {
		return taBranchDtoList;
	}

	public void setTaBranchDtoList(List<TaBranchDto> taBranchDtoList) {
		this.taBranchDtoList = taBranchDtoList;
	}

	public List<TaBranchApplication> getTaBranchApplicationList() {
		return taBranchApplicationList;
	}

	public void setTaBranchApplicationList(List<TaBranchApplication> taBranchApplicationList) {
		this.taBranchApplicationList = taBranchApplicationList;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getApplicationBranchId() {
		return applicationBranchId;
	}

	public void setApplicationBranchId(String applicationBranchId) {
		this.applicationBranchId = applicationBranchId;
	}

	public String getStatusLabel() {
		return statusLabel;
	}

	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	public TaBranchDto getTaBranchDto() {
		return taBranchDto;
	}

	public void setTaBranchDto(TaBranchDto taBranchDto) {
		this.taBranchDto = taBranchDto;
	}

	public TaBranchApplicationDto getToReplace() {
		return toReplace;
	}

	public void setToReplace(TaBranchApplicationDto toReplace) {
		this.toReplace = toReplace;
	}

	public String getSingleLineAddress() {
		return singleLineAddress;
	}

	public void setSingleLineAddress(String singleLineAddress) {
		this.singleLineAddress = singleLineAddress;
	}

	public String getFormatAddress() {
		return formatAddress;
	}

	public void setFormatAddress(String formatAddress) {
		this.formatAddress = formatAddress;
	}

	public String getFormattedAddress() {
		return formattedAddress;
	}

	@Override
	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setFormattedAddress(String formattedAddress) {
		this.formattedAddress = formattedAddress;
	}

	@Override
	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

}
