package gov.stb.tag.dto.ta.companyupdate;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.jackson.BigDecimalToMoneyThousandSeparatorConverter;
import gov.stb.tag.jackson.MoneyThousandSeparatorToBigDecimalConverter;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaCompanyUpdate;
import gov.stb.tag.model.TravelAgent;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaCompanyDetailsDto {

	private LocalDate effectiveDate;

	private ListableDto applicationMode;

	private ListableDto licenceTier;

	private String companyName;

	private String companyFormerName;

	private ListableDto formOfBusiness;

	private ListableDto businessConstitution;

	private String uen;

	private LocalDate registrationDate;

	private ListableDto principleActivities;

	private ListableDto secondaryPrincipleActivities;

	private ListableDto placeIncorporated;

	private ListableDto establishmentStatus;

	private ListableDto taSegmentation;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal paidUpCapital;

	private String websiteUrl;

	private String emailAddress;

	private String contactNo;

	private String faxNo;

	private LocalDate fye;

	private AddressDto registeredAddress;

	private AddressDto operatingAddress;

	public static TaCompanyDetailsDto buildFromApplication(Cache cache, TaCompanyUpdate taCompanyUpdate) {

		TaCompanyDetailsDto result = new TaCompanyDetailsDto();
		if (taCompanyUpdate != null) {
			// 2. Business Entity -
			result.setCompanyName(taCompanyUpdate.getCompanyName());
			result.setFormOfBusiness(
					(taCompanyUpdate.getFormOfBusiness() != null) ? new ListableDto(taCompanyUpdate.getFormOfBusiness().getKey(), cache.getLabel(taCompanyUpdate.getFormOfBusiness(), false))
							: new ListableDto());
			result.setBusinessConstitution((taCompanyUpdate.getBusinessConstitution() != null)
					? new ListableDto(taCompanyUpdate.getBusinessConstitution().getKey(), cache.getLabel(taCompanyUpdate.getBusinessConstitution(), false))
					: new ListableDto());

			result.setPrincipleActivities((taCompanyUpdate.getPrincipleActivities() != null)
					? new ListableDto(taCompanyUpdate.getPrincipleActivities().getKey(), cache.getLabel(taCompanyUpdate.getPrincipleActivities(), false))
					: new ListableDto());
			result.setSecondaryPrincipleActivities((taCompanyUpdate.getSecondaryPrincipleActivities() != null)
					? new ListableDto(taCompanyUpdate.getSecondaryPrincipleActivities().getKey(), cache.getLabel(taCompanyUpdate.getSecondaryPrincipleActivities(), false))
					: new ListableDto());
			result.setPlaceIncorporated(
					(taCompanyUpdate.getPlaceIncorporated() != null) ? new ListableDto(taCompanyUpdate.getPlaceIncorporated().getKey(), cache.getLabel(taCompanyUpdate.getPlaceIncorporated(), false))
							: new ListableDto());
			result.setEstablishmentStatus((taCompanyUpdate.getEstablishmentStatus() != null)
					? new ListableDto(taCompanyUpdate.getEstablishmentStatus().getKey(), cache.getLabel(taCompanyUpdate.getEstablishmentStatus(), false))
					: new ListableDto());
			result.setTaSegmentation(
					(taCompanyUpdate.getTaSegmentation() != null) ? new ListableDto(taCompanyUpdate.getTaSegmentation().getKey(), cache.getLabel(taCompanyUpdate.getTaSegmentation(), false))
							: new ListableDto());
			result.setPaidUpCapital(taCompanyUpdate.getPaidUpCapital());
			result.setWebsiteUrl(taCompanyUpdate.getWebsiteUrl());
			result.setEmailAddress(taCompanyUpdate.getEmailAddress());
			result.setContactNo(taCompanyUpdate.getContactNo());
			result.setFaxNo(taCompanyUpdate.getFaxNo());
			result.setRegisteredAddress(AddressDto.buildFromAddress(cache, taCompanyUpdate.getRegisteredAddress()));
			result.setOperatingAddress(AddressDto.buildFromAddress(cache, taCompanyUpdate.getOperatingAddress()));
		}
		return result;
	}

	public static TaCompanyDetailsDto buildFromLicence(Cache cache, Licence licence) {

		TaCompanyDetailsDto result = new TaCompanyDetailsDto();
		if (licence != null && licence.getTravelAgent() != null) {
			TravelAgent travelAgent = licence.getTravelAgent();
			result.setCompanyName(travelAgent.getName());
			result.setFormOfBusiness(
					(travelAgent.getFormOfBusiness() != null) ? new ListableDto(travelAgent.getFormOfBusiness().getKey(), cache.getLabel(travelAgent.getFormOfBusiness(), false)) : new ListableDto());
			result.setBusinessConstitution(
					(travelAgent.getBusinessConstitution() != null) ? new ListableDto(travelAgent.getBusinessConstitution().getKey(), cache.getLabel(travelAgent.getBusinessConstitution(), false))
							: new ListableDto());
			result.setPrincipleActivities(
					(travelAgent.getPrincipleActivities() != null) ? new ListableDto(travelAgent.getPrincipleActivities().getKey(), cache.getLabel(travelAgent.getPrincipleActivities(), false))
							: new ListableDto());
			result.setSecondaryPrincipleActivities((travelAgent.getSecondaryPrincipleActivities() != null)
					? new ListableDto(travelAgent.getSecondaryPrincipleActivities().getKey(), cache.getLabel(travelAgent.getSecondaryPrincipleActivities(), false))
					: new ListableDto());
			result.setPlaceIncorporated(
					(travelAgent.getIncorporatedPlace() != null) ? new ListableDto(travelAgent.getIncorporatedPlace().getKey(), cache.getLabel(travelAgent.getIncorporatedPlace(), false))
							: new ListableDto());
			result.setEstablishmentStatus(
					(travelAgent.getEstablishmentStatus() != null) ? new ListableDto(travelAgent.getEstablishmentStatus().getKey(), cache.getLabel(travelAgent.getEstablishmentStatus(), false))
							: new ListableDto());
			result.setTaSegmentation(
					(travelAgent.getTaSegmentation() != null) ? new ListableDto(travelAgent.getTaSegmentation().getKey(), cache.getLabel(travelAgent.getTaSegmentation(), false)) : new ListableDto());
			result.setPaidUpCapital(travelAgent.getPaidUpCapital());
			result.setWebsiteUrl(travelAgent.getWebsiteUrl());
			result.setEmailAddress(travelAgent.getEmailAddress());
			result.setContactNo(travelAgent.getContactNo());
			result.setFaxNo(travelAgent.getFaxNo());
			result.setFye(travelAgent.getFyeDate());
			result.setUen(travelAgent.getUen());
			result.setRegisteredAddress(AddressDto.buildFromAddress(cache, travelAgent.getRegisteredAddress()));
			result.setOperatingAddress(AddressDto.buildFromAddress(cache, travelAgent.getOperatingAddress()));
			result.setLicenceTier(new ListableDto(licence.getTier().getKey(), cache.getLabel(licence.getTier(), false)));
		}
		return result;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public ListableDto getApplicationMode() {
		return applicationMode;
	}

	public void setApplicationMode(ListableDto applicationMode) {
		this.applicationMode = applicationMode;
	}

	public ListableDto getLicenceTier() {
		return licenceTier;
	}

	public void setLicenceTier(ListableDto licenceTier) {
		this.licenceTier = licenceTier;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyFormerName() {
		return companyFormerName;
	}

	public void setCompanyFormerName(String companyFormerName) {
		this.companyFormerName = companyFormerName;
	}

	public ListableDto getFormOfBusiness() {
		return formOfBusiness;
	}

	public void setFormOfBusiness(ListableDto formOfBusiness) {
		this.formOfBusiness = formOfBusiness;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public ListableDto getPrincipleActivities() {
		return principleActivities;
	}

	public void setPrincipleActivities(ListableDto principleActivities) {
		this.principleActivities = principleActivities;
	}

	public ListableDto getSecondaryPrincipleActivities() {
		return secondaryPrincipleActivities;
	}

	public void setSecondaryPrincipleActivities(ListableDto secondaryPrincipleActivities) {
		this.secondaryPrincipleActivities = secondaryPrincipleActivities;
	}

	public ListableDto getPlaceIncorporated() {
		return placeIncorporated;
	}

	public void setPlaceIncorporated(ListableDto placeIncorporated) {
		this.placeIncorporated = placeIncorporated;
	}

	public ListableDto getEstablishmentStatus() {
		return establishmentStatus;
	}

	public void setEstablishmentStatus(ListableDto establishmentStatus) {
		this.establishmentStatus = establishmentStatus;
	}

	public ListableDto getTaSegmentation() {
		return taSegmentation;
	}

	public void setTaSegmentation(ListableDto taSegmentation) {
		this.taSegmentation = taSegmentation;
	}

	public BigDecimal getPaidUpCapital() {
		return paidUpCapital;
	}

	public void setPaidUpCapital(BigDecimal paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public LocalDate getFye() {
		return fye;
	}

	public void setFye(LocalDate fye) {
		this.fye = fye;
	}

	public AddressDto getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(AddressDto registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public AddressDto getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(AddressDto operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public ListableDto getBusinessConstitution() {
		return businessConstitution;
	}

	public void setBusinessConstitution(ListableDto businessConstitution) {
		this.businessConstitution = businessConstitution;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

}
