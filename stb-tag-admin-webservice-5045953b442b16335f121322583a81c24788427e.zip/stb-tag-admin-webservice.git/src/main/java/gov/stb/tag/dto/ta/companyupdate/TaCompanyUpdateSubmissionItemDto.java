package gov.stb.tag.dto.ta.companyupdate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaCompanyUpdateSubmissionItemDto extends TaApplicationItemDto {

	public TaCompanyUpdateSubmissionItemDto() {

	}

}
