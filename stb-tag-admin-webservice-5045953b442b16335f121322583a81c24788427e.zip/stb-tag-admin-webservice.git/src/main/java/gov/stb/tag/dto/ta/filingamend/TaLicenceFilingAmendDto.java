package gov.stb.tag.dto.ta.filingamend;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingExtensionDateDto;
import gov.stb.tag.dto.workflow.WorkflowDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaFilingConditionAmendment;
import gov.stb.tag.model.TaFilingConditionExtension;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceFilingAmendDto extends WorkflowDto {

	private Integer filingAmendId;
	private LocalDateTime createdDate;

	private String externalRemarks;
	private String internalRemarks;
	private String errorMsg;

	private List<TaLicenceFilingExtensionDateDto> extensionDates;

	public static TaLicenceFilingAmendDto buildFromModel(CacheHelper cacheHelper, TaFilingConditionAmendment model, TaLicenceFilingAmendDto dto, Licence licence, WorkflowHelper workflowHelper) {

		if (model != null) {
			dto.setFilingAmendId(model.getId());
			dto.setCreatedDate(model.getCreatedDate());
			dto = dto.buildFromWorkflow(cacheHelper, model.getWorkflow(), dto, workflowHelper);

			if (model.getTaFilingConditionExtensions() != null) {
				dto.setExtensionDates(new ArrayList<TaLicenceFilingExtensionDateDto>());
				for (TaFilingConditionExtension row : model.getTaFilingConditionExtensions()) {
					dto.getExtensionDates().add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(row, new TaLicenceFilingExtensionDateDto()));
				}
			}
		} else {
			dto = dto.buildFromWorkflow(cacheHelper, null, dto, workflowHelper);
		}
		dto = dto.buildFromLicence(cacheHelper, licence, dto);
		return dto;
	}

	public static TaFilingConditionAmendment updateModelFromDto(Cache cache, TaFilingConditionAmendment model, TaLicenceFilingAmendDto dto, Licence licenceModel) {

		return model;
	}

	public Integer getFilingAmendId() {
		return filingAmendId;
	}

	public void setFilingAmendId(Integer filingAmendId) {
		this.filingAmendId = filingAmendId;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public List<TaLicenceFilingExtensionDateDto> getExtensionDates() {
		return extensionDates;
	}

	public void setExtensionDates(List<TaLicenceFilingExtensionDateDto> extensionDates) {
		this.extensionDates = extensionDates;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}
