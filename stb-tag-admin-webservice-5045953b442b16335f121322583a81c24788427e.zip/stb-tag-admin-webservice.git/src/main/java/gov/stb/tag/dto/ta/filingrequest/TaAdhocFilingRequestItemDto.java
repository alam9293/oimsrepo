package gov.stb.tag.dto.ta.filingrequest;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.workflow.WorkflowItemDto;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.TaAdhocFilingRequest;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaAdhocFilingRequestItemDto extends WorkflowItemDto {

	private LocalDateTime createdDate;

	private String reqTypeLabel;

	private String reqTypeCode;

	private Integer filingReqId;

	private LocalDate dueDate;

	private Integer fy;

	public static TaAdhocFilingRequestItemDto buildFilingRequestItemDto(TaAdhocFilingRequest model, WorkflowHelper workflowHelper) {
		TaAdhocFilingRequestItemDto dto = new TaAdhocFilingRequestItemDto();
		dto.setCreatedDate(model.getCreatedDate());
		dto.setReqTypeLabel(model.getReqType().getLabel());
		dto.setReqTypeCode(model.getReqType().getCode());
		dto.setFilingReqId(model.getId());
		dto.setDueDate(model.getDueDate());
		dto.setFy(model.getFy());
		dto.buildWorkflowDto(workflowHelper, model.getWorkflow(), dto);
		return dto;
	}

	@Override
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	@Override
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getReqTypeLabel() {
		return reqTypeLabel;
	}

	public void setReqTypeLabel(String reqTypeLabel) {
		this.reqTypeLabel = reqTypeLabel;
	}

	public Integer getFilingReqId() {
		return filingReqId;
	}

	public void setFilingReqId(Integer filingReqId) {
		this.filingReqId = filingReqId;
	}

	public String getReqTypeCode() {
		return reqTypeCode;
	}

	public void setReqTypeCode(String reqTypeCode) {
		this.reqTypeCode = reqTypeCode;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

}
