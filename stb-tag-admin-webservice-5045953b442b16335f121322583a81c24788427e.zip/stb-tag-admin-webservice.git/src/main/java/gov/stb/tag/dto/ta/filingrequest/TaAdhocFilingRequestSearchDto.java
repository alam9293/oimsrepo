package gov.stb.tag.dto.ta.filingrequest;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.workflow.TaWorkflowSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaAdhocFilingRequestSearchDto extends TaWorkflowSearchDto {
	private Integer licenceId;
	private String reqType;
	private Integer excludeRequestId;

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public Integer getExcludeRequestId() {
		return excludeRequestId;
	}

	public void setExcludeRequestId(Integer excludeRequestId) {
		this.excludeRequestId = excludeRequestId;
	}
}
