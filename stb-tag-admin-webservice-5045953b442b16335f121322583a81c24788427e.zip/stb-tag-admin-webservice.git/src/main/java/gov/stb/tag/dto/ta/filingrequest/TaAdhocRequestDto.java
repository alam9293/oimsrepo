package gov.stb.tag.dto.ta.filingrequest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes.TaAdhocReqTypes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.annualfiling.TaLicenceFilingExtensionDateDto;
import gov.stb.tag.dto.workflow.WorkflowDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAdhocFilingRequest;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaAdhocRequestDto extends WorkflowDto {

	private Integer adhocFilingRequestId;
	private LocalDateTime createdDate;
	private ListableDto reqType; // TA_REQ_ADHOC_DOCS, TA_REQ_ADHOC_MA
	private String requestRemarks;
	private LocalDate dueDate;
	private String errorMsg;
	private LocalDate requestedAsAtDate;
	private Integer fy;

	private List<TaAdhocRequestDto> pastRequests;
	private List<TaLicenceFilingExtensionDateDto> pastExtensionDates;

	public static TaAdhocRequestDto buildAdhocFilingDto(Cache cache, TaAdhocFilingRequest model, TaAdhocRequestDto dto, Licence licence, WorkflowHelper workflowHelper) {

		if (model != null) {
			dto.setAdhocFilingRequestId(model.getId());
			dto.setCreatedDate(model.getCreatedDate());
			dto.setReqType(new ListableDto(model.getReqType()));
			dto.setRequestRemarks(model.getRequestRemarks());
			dto.setDueDate(model.getDueDate());
			dto.setRequestedAsAtDate(model.getRequestedAsAtDate());
			dto.setFy(model.getFy());
			// if (model.getTaFilingConditionExtensions() != null) {
			// dto.setExtensionDates(new ArrayList<TaLicenceFilingExtensionDateDto>());
			// for (TaFilingConditionExtension row : model.getTaFilingConditionExtensions()) {
			// dto.getExtensionDates().add(TaLicenceFilingExtensionDateDto.buildFilingExtensionDto(row, new TaLicenceFilingExtensionDateDto()));
			// }
			// }
			dto = dto.buildFromWorkflow(cache, model.getWorkflow(), dto, workflowHelper);
		} else {
			dto = dto.buildFromWorkflow(cache, null, dto, workflowHelper);
		}
		dto = dto.buildFromLicence(cache, licence, dto);
		return dto;
	}

	public static TaAdhocFilingRequest updateModelFromDto(Cache cache, TaAdhocFilingRequest model, TaAdhocRequestDto dto, Licence licenceModel) {
		model.setReqType(cache.getType(dto.getReqType().getKey().toString()));
		model.setDueDate(dto.getDueDate());
		if (dto.getReqType().getKey().toString().equalsIgnoreCase(TaAdhocReqTypes.TA_REQ_ADHOC_MA)) {
			model.setRequestedAsAtDate(dto.getRequestedAsAtDate());
		}
		if (dto.getReqType().getKey().toString().equalsIgnoreCase(TaAdhocReqTypes.TA_REQ_ADHOC_DOCS)) {
			model.setRequestRemarks(dto.getRequestRemarks());
		}
		model.setFy(dto.getFy());
		return model;
	}

	public Integer getAdhocFilingRequestId() {
		return adhocFilingRequestId;
	}

	public void setAdhocFilingRequestId(Integer adhocFilingRequestId) {
		this.adhocFilingRequestId = adhocFilingRequestId;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public ListableDto getReqType() {
		return reqType;
	}

	public void setReqType(ListableDto reqType) {
		this.reqType = reqType;
	}

	public String getRequestRemarks() {
		return requestRemarks;
	}

	public void setRequestRemarks(String requestRemarks) {
		this.requestRemarks = requestRemarks;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public List<TaLicenceFilingExtensionDateDto> getPastExtensionDates() {
		return pastExtensionDates;
	}

	public void setPastExtensionDates(List<TaLicenceFilingExtensionDateDto> pastExtensionDates) {
		this.pastExtensionDates = pastExtensionDates;
	}

	public List<TaAdhocRequestDto> getPastRequests() {
		return pastRequests;
	}

	public void setPastRequests(List<TaAdhocRequestDto> pastRequests) {
		this.pastRequests = pastRequests;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public LocalDate getRequestedAsAtDate() {
		return requestedAsAtDate;
	}

	public void setRequestedAsAtDate(LocalDate requestedAsAtDate) {
		this.requestedAsAtDate = requestedAsAtDate;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

}
