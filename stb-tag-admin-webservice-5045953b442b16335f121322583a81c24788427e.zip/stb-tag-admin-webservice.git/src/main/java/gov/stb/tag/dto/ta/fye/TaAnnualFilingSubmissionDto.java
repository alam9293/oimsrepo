package gov.stb.tag.dto.ta.fye;

import java.time.LocalDate;

import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaFilingCondition;

public class TaAnnualFilingSubmissionDto {

	private String applicationNo;

	private ListableDto type;

	private Integer fy;

	private LocalDate fyeDate;

	private LocalDate dueDate;

	private ListableDto status;

	private LocalDate fyeDateToBe;

	public TaAnnualFilingSubmissionDto() {

	}

	public static TaAnnualFilingSubmissionDto buildFromAnnualFiling(Cache cache, TaFilingCondition filing) {
		if (filing != null) {
			TaAnnualFilingSubmissionDto dto = new TaAnnualFilingSubmissionDto();
			dto.setType(new ListableDto(filing.getApplicationType().getCode(), cache.getLabel(filing.getApplicationType(), true)));
			dto.setDueDate(filing.getDueDate());
			dto.setFyeDate(filing.getFyEndDate());
			dto.setFy(filing.getFy());
			dto.setStatus(new ListableDto(filing.getStatus().getCode(), cache.getLabel(filing.getStatus(), true)));
			return dto;
		}
		return null;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public ListableDto getType() {
		return type;
	}

	public void setType(ListableDto type) {
		this.type = type;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

	public LocalDate getFyeDate() {
		return fyeDate;
	}

	public void setFyeDate(LocalDate fyeDate) {
		this.fyeDate = fyeDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public LocalDate getFyeDateToBe() {
		return fyeDateToBe;
	}

	public void setFyeDateToBe(LocalDate fyeDateToBe) {
		this.fyeDateToBe = fyeDateToBe;
	}

}
