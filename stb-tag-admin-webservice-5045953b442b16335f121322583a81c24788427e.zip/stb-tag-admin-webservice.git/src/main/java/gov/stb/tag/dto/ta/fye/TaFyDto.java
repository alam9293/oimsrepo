package gov.stb.tag.dto.ta.fye;

import java.time.LocalDate;

import gov.stb.tag.annotation.MapProjection;

/**
 * The dto used for drop-down selection of list of fyes on change of fye screen
 * 
 * @author yvonne.yap
 *
 */
public class TaFyDto {

	@MapProjection(path = "fyStartDate")
	private LocalDate fyStartDate;

	@MapProjection(path = "fyEndDate")
	private LocalDate fyEndDate;

	private LocalDate minFyEndDate;

	private LocalDate maxFyEndDate;

	public TaFyDto() {

	}

	public TaFyDto(LocalDate fyStartDate, LocalDate fyEndDate) {
		super();
		this.fyStartDate = fyStartDate;
		this.fyEndDate = fyEndDate;
		this.minFyEndDate = this.fyStartDate.plusDays(1);
		this.maxFyEndDate = this.fyStartDate.minusDays(1).plusMonths(24);
	}

	public LocalDate getFyStartDate() {
		return fyStartDate;
	}

	public void setFyStartDate(LocalDate fyStartDate) {
		this.fyStartDate = fyStartDate;
	}

	public LocalDate getFyEndDate() {
		return fyEndDate;
	}

	public void setFyEndDate(LocalDate fyEndDate) {
		this.fyEndDate = fyEndDate;
	}

	public LocalDate getMinFyEndDate() {
		return minFyEndDate;
	}

	public void setMinFyEndDate(LocalDate minFyEndDate) {
		this.minFyEndDate = minFyEndDate;
	}

	public LocalDate getMaxFyEndDate() {
		return maxFyEndDate;
	}

	public void setMaxFyEndDate(LocalDate maxFyEndDate) {
		this.maxFyEndDate = maxFyEndDate;
	}

}
