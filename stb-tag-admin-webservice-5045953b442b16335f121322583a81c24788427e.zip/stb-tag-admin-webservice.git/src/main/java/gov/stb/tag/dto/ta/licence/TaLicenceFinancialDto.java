package gov.stb.tag.dto.ta.licence;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.jackson.BigDecimalToMoneyThousandSeparatorConverter;
import gov.stb.tag.model.TaAaSubmission;

public class TaLicenceFinancialDto extends EntityDto {

	private Integer appId;

	private Integer fy;

	private LocalDate fyStartDate;

	private LocalDate fyEndDate;

	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal capital;

	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal netValue; // TA - TL

	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal revenue;

	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal shortfall;

	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal netProfitLoss;

	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal accProfitLoss;

	public static TaLicenceFinancialDto build(Cache cache, TaAaSubmission aa) {
		TaLicenceFinancialDto dto = new TaLicenceFinancialDto();
		dto.setAppId(aa.getApplication().getId());
		dto.setFy(aa.getTaAnnualFiling().getFy());
		dto.setFyStartDate(aa.getTaAnnualFiling().getFyStartDate());
		dto.setFyEndDate(aa.getTaAnnualFiling().getFyEndDate());
		dto.setCapital(aa.getCapital());
		dto.setRevenue(aa.getRevenue());
		dto.setNetValue(aa.getNetValue());
		dto.setShortfall(aa.getShortfall());
		dto.setNetProfitLoss(aa.getNetProfitLoss());
		dto.setAccProfitLoss(aa.getAccProfitLoss());
		return dto;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

	public LocalDate getFyStartDate() {
		return fyStartDate;
	}

	public void setFyStartDate(LocalDate fyStartDate) {
		this.fyStartDate = fyStartDate;
	}

	public LocalDate getFyEndDate() {
		return fyEndDate;
	}

	public void setFyEndDate(LocalDate fyEndDate) {
		this.fyEndDate = fyEndDate;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getNetValue() {
		return netValue;
	}

	public void setNetValue(BigDecimal netValue) {
		this.netValue = netValue;
	}

	public BigDecimal getRevenue() {
		return revenue;
	}

	public void setRevenue(BigDecimal revenue) {
		this.revenue = revenue;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public BigDecimal getNetProfitLoss() {
		return netProfitLoss;
	}

	public void setNetProfitLoss(BigDecimal netProfitLoss) {
		this.netProfitLoss = netProfitLoss;
	}

	public BigDecimal getAccProfitLoss() {
		return accProfitLoss;
	}

	public void setAccProfitLoss(BigDecimal accProfitLoss) {
		this.accProfitLoss = accProfitLoss;
	}

}
