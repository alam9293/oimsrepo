package gov.stb.tag.dto.ta.licence;

import java.math.BigDecimal;
import java.time.LocalDate;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaMaSubmission;

public class TaLicenceFinancialMaDto extends EntityDto {

	private Integer appId;

	private Integer fy;

	private LocalDate asAtDate;

	private BigDecimal capital;

	private BigDecimal netValue; // TA - TL

	private BigDecimal totalAssets;

	private BigDecimal totalLiabilities;

	private BigDecimal shortfall;

	public static TaLicenceFinancialMaDto build(Cache cache, TaMaSubmission ma) {
		TaLicenceFinancialMaDto dto = new TaLicenceFinancialMaDto();
		dto.setAppId(ma.getApplication().getId());
		dto.setFy(ma.getTaFilingCondition().getFy());
		dto.setAsAtDate(ma.getAsAtDate());
		dto.setCapital(ma.getPaidUpCapital());
		dto.setNetValue(ma.getNetValue());
		dto.setShortfall(ma.getShortfall());
		dto.setTotalAssets(ma.getTotalAssets());
		dto.setTotalLiabilities(ma.getTotalLiabilities());
		return dto;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

	public LocalDate getAsAtDate() {
		return asAtDate;
	}

	public void setAsAtDate(LocalDate asAtDate) {
		this.asAtDate = asAtDate;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getNetValue() {
		return netValue;
	}

	public void setNetValue(BigDecimal netValue) {
		this.netValue = netValue;
	}

	public BigDecimal getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(BigDecimal totalAssets) {
		this.totalAssets = totalAssets;
	}

	public BigDecimal getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(BigDecimal totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

}
