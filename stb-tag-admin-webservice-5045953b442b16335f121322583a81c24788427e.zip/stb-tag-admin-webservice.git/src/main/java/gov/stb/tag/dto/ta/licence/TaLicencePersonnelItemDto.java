package gov.stb.tag.dto.ta.licence;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicencePersonnelItemDto extends SearchDto {

	@MapProjection(path = "id")
	private Integer taStakeholderId;

	@MapProjection(path = "stakeholder.id")
	private Integer stakeholderId;

	@MapProjection(path = "stakeholder.name")
	private String name;

	@MapProjection(path = "stakeholder.companyUen")
	private String uen;

	@MapProjection(path = "stakeholder.uin")
	private String uin;

	@MapProjection(path = "appointedDate")
	private LocalDate appointedDate;

	@MapProjection(path = "resignedDate")
	private LocalDate resignedDate;

	@MapProjection(path = "role.label")
	private String role;

	@MapProjection(path = "stakeholder.isCompany")
	private Boolean isCompany;

	public Integer getTaStakeholderId() {
		return taStakeholderId;
	}

	public void setTaStakeholderId(Integer taStakeholderId) {
		this.taStakeholderId = taStakeholderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public LocalDate getAppointedDate() {
		return appointedDate;
	}

	public void setAppointedDate(LocalDate appointedDate) {
		this.appointedDate = appointedDate;
	}

	public LocalDate getResignedDate() {
		return resignedDate;
	}

	public void setResignedDate(LocalDate resignedDate) {
		this.resignedDate = resignedDate;
	}

	public Integer getStakeholderId() {
		return stakeholderId;
	}

	public void setStakeholderId(Integer stakeholderId) {
		this.stakeholderId = stakeholderId;
	}

	public Boolean getIsCompany() {
		return isCompany;
	}

	public void setIsCompany(Boolean isCompany) {
		this.isCompany = isCompany;
	}

}
