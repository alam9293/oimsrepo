package gov.stb.tag.dto.ta.licenceAa;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;

public class TaLicenceAaFileDto extends EntityDto {

	@MapProjection(path = "applicationFiles.file.id")
	private Integer fileId;

	@MapProjection(path = "applicationFiles.file.filename")
	private String filename;

	@MapProjection(path = "applicationFiles.file.originalFilename")
	private String originalFilename;

	@MapProjection(path = "applicationFiles.file.path")
	private String path;

	@MapProjection(path = "applicationFiles.file.size")
	private Long size;

	@MapProjection(path = "applicationFiles.file.description")
	private String description;

	@MapProjection(path = "applicationFiles.documentType.code")
	private String documentTypeCode;

	@MapProjection(path = "applicationFiles.documentType.label")
	private String documentType;

	@MapProjection(path = "applicationFiles.documentType.otherLabel")
	private String documentInstructions;

	private String readableFileSize;

	public Integer getFileId() {
		return fileId;
	}

	public String getReadableFileSize() {
		return readableFileSize;
	}

	public void setReadableFileSize(String readableFileSize) {
		this.readableFileSize = readableFileSize;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDocumentTypeCode() {
		return documentTypeCode;
	}

	public void setDocumentTypeCode(String documentTypeCode) {
		this.documentTypeCode = documentTypeCode;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentInstructions() {
		return documentInstructions;
	}

	public void setDocumentInstructions(String documentInstructions) {
		this.documentInstructions = documentInstructions;
	}

	public String getOriginalFilename() {
		return originalFilename;
	}

	public void setOriginalFilename(String originalFilename) {
		this.originalFilename = originalFilename;
	}

}
