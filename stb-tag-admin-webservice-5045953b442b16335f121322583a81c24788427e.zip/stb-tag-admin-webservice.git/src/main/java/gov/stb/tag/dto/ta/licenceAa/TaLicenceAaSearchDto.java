package gov.stb.tag.dto.ta.licenceAa;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceAaSearchDto extends TaApplicationSearchDto {

}
