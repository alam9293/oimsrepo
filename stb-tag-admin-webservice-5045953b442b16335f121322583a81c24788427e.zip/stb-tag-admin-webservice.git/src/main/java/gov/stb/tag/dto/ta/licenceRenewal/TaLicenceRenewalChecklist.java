package gov.stb.tag.dto.ta.licenceRenewal;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.dashboard.TaSubmissionDueDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TaLicenceRenewal;

public class TaLicenceRenewalChecklist extends TaApplicationDto {
	private List<TaSubmissionDueDto> annualFilings = new ArrayList<TaSubmissionDueDto>();

	private Integer renewalSubmissionId;

	private BigDecimal outstandingPaymentAmount; // For admin renewal view

	// Payment
	private PaymentRequestDto renewalFee;

	private boolean hasKe = Boolean.TRUE;

	private boolean metRenewalCriteria = Boolean.TRUE;

	private boolean renewalIsCompleted;

	public static TaLicenceRenewalChecklist buildApplication(CacheHelper cache, ApplicationHelper appHelper, PaymentHelper paymentHelper, TaLicenceRenewal renewalApp, TaLicenceRenewalChecklist dto) {
		dto = dto.buildFromApplication(cache, appHelper, renewalApp.getApplication(), dto);
		dto.setRenewalSubmissionId(renewalApp.getId());
		PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(renewalApp.getAppFeeBillRefNo());
		dto.setRenewalFee(new PaymentRequestDto(cache, paymentRequest, Boolean.FALSE));
		if (paymentRequest != null) {
			dto.setRenewalIsCompleted(Entities.anyEquals(paymentRequest.getStatus(), Codes.Statuses.PAYREQ_SETTLED, Codes.Statuses.PAYREQ_WAIVED));
		}

		return dto;
	}

	public List<TaSubmissionDueDto> getAnnualFilings() {
		return annualFilings;
	}

	public void setAnnualFilings(List<TaSubmissionDueDto> annualFilings) {
		this.annualFilings = annualFilings;
	}

	public boolean isMetRenewalCriteria() {
		return metRenewalCriteria;
	}

	public void setMetRenewalCriteria(boolean metRenewalCriteria) {
		this.metRenewalCriteria = metRenewalCriteria;
	}

	public BigDecimal getOutstandingPaymentAmount() {
		return outstandingPaymentAmount;
	}

	public void setOutstandingPaymentAmount(BigDecimal outstandingPaymentAmount) {
		this.outstandingPaymentAmount = outstandingPaymentAmount;
	}

	public Integer getRenewalSubmissionId() {
		return renewalSubmissionId;
	}

	public void setRenewalSubmissionId(Integer renewalSubmissionId) {
		this.renewalSubmissionId = renewalSubmissionId;
	}

	public PaymentRequestDto getRenewalFee() {
		return renewalFee;
	}

	public void setRenewalFee(PaymentRequestDto renewalFee) {
		this.renewalFee = renewalFee;
	}

	public boolean isHasKe() {
		return hasKe;
	}

	public void setHasKe(boolean hasKe) {
		this.hasKe = hasKe;
	}

	public boolean isRenewalIsCompleted() {
		return renewalIsCompleted;
	}

	public void setRenewalIsCompleted(boolean renewalIsCompleted) {
		this.renewalIsCompleted = renewalIsCompleted;
	}

}
