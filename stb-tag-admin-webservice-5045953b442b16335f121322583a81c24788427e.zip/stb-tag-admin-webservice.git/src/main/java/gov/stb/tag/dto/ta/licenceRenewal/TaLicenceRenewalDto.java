package gov.stb.tag.dto.ta.licenceRenewal;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.dto.ta.branch.TaBranchDto;
import gov.stb.tag.dto.ta.companyupdate.TaCompanyDetailsDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderRecordDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaLicenceRenewal;

public class TaLicenceRenewalDto extends TaApplicationDto {

	private Integer id;

	private Integer taLicenceRenewalExerciseTaId;

	private List<FileDto> files = new ArrayList<FileDto>(); // require optional: other doc

	private List<Integer> toDeleteFiles = new ArrayList<Integer>();

	private Boolean isLate = Boolean.FALSE;

	private String lateRemarks;

	private Boolean isKeUser = Boolean.FALSE;

	private Boolean renewalIsOpen = Boolean.FALSE;

	// Payment
	private PaymentRequestDto renewalFee;

	// KE only
	private List<TaKeDeclarationsDto> taKeDeclarationsForRenewal;

	// Current Business Entity Details
	private TaCompanyDetailsDto currentCompanyDetails;

	// Current active branches
	private List<TaBranchDto> activeBranchList;

	/* TA have KE now? */
	private Boolean haveKe = Boolean.TRUE;

	// Current KE personal details
	private StakeholderDto keStakeholderDto;

	// Current KE Ta stakeholder details + declaration
	private TaStakeholderDto taKeStakeholder;

	// List of personnels
	private List<StakeholderRecordDto> personnelList;

	private TaLicenceRenewalChecklist renewalChecklist;

	private List<ListableDto> pastRenewalCycle;

	public static TaLicenceRenewalDto buildApplication(CacheHelper cache, ApplicationHelper appHelper, PaymentHelper paymentHelper, TaLicenceRenewal renewalApp, TaLicenceRenewalDto dto) {
		dto = dto.buildFromApplication(cache, appHelper, renewalApp.getApplication(), dto);
		dto.setLateRemarks(renewalApp.getLateRemarks());
		if (renewalApp.getTaLicenceRenewalExerciseTa() != null) {
			dto.setTaLicenceRenewalExerciseTaId(renewalApp.getTaLicenceRenewalExerciseTa().getId());
		}
		dto.setId(renewalApp.getId());
		List<TaKeDeclarationsDto> declarations = new ArrayList<>();
		for (TaKeDeclaration x : renewalApp.getTaKeDeclarations()) {
			declarations.add(TaKeDeclarationsDto.build(cache, x));
		}
		declarations.sort(Comparator.comparingInt(TaKeDeclarationsDto::getOrdinal));
		dto.setTaKeDeclarationsForRenewal(declarations);

		dto.setRenewalFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(renewalApp.getAppFeeBillRefNo()), Boolean.FALSE));

		return dto;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public List<Integer> getToDeleteFiles() {
		return toDeleteFiles;
	}

	public void setToDeleteFiles(List<Integer> toDeleteFiles) {
		this.toDeleteFiles = toDeleteFiles;
	}

	public TaCompanyDetailsDto getCurrentCompanyDetails() {
		return currentCompanyDetails;
	}

	public void setCurrentCompanyDetails(TaCompanyDetailsDto currentCompanyDetails) {
		this.currentCompanyDetails = currentCompanyDetails;
	}

	public List<TaBranchDto> getActiveBranchList() {
		return activeBranchList;
	}

	public void setActiveBranchList(List<TaBranchDto> activeBranchList) {
		this.activeBranchList = activeBranchList;
	}

	public TaStakeholderDto getTaKeStakeholder() {
		return taKeStakeholder;
	}

	public void setTaKeStakeholder(TaStakeholderDto taKeStakeholder) {
		this.taKeStakeholder = taKeStakeholder;
	}

	public StakeholderDto getKeStakeholderDto() {
		return keStakeholderDto;
	}

	public void setKeStakeholderDto(StakeholderDto keStakeholderDto) {
		this.keStakeholderDto = keStakeholderDto;
	}

	public Boolean getHaveKe() {
		return haveKe;
	}

	public void setHaveKe(Boolean haveKe) {
		this.haveKe = haveKe;
	}

	public List<StakeholderRecordDto> getPersonnelList() {
		return personnelList;
	}

	public void setPersonnelList(List<StakeholderRecordDto> personnelList) {
		this.personnelList = personnelList;
	}

	public Boolean getIsLate() {
		return isLate;
	}

	public void setIsLate(Boolean isLate) {
		this.isLate = isLate;
	}

	public String getLateRemarks() {
		return lateRemarks;
	}

	public void setLateRemarks(String lateRemarks) {
		this.lateRemarks = lateRemarks;
	}

	public List<TaKeDeclarationsDto> getTaKeDeclarationsForRenewal() {
		return taKeDeclarationsForRenewal;
	}

	public void setTaKeDeclarationsForRenewal(List<TaKeDeclarationsDto> taKeDeclarationsForRenewal) {
		this.taKeDeclarationsForRenewal = taKeDeclarationsForRenewal;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getIsKeUser() {
		return isKeUser;
	}

	public void setIsKeUser(Boolean isKeUser) {
		this.isKeUser = isKeUser;
	}

	public PaymentRequestDto getRenewalFee() {
		return renewalFee;
	}

	public void setRenewalFee(PaymentRequestDto renewalFee) {
		this.renewalFee = renewalFee;
	}

	public TaLicenceRenewalChecklist getRenewalChecklist() {
		return renewalChecklist;
	}

	public void setRenewalChecklist(TaLicenceRenewalChecklist renewalChecklist) {
		this.renewalChecklist = renewalChecklist;
	}

	public Integer getTaLicenceRenewalExerciseTaId() {
		return taLicenceRenewalExerciseTaId;
	}

	public void setTaLicenceRenewalExerciseTaId(Integer taLicenceRenewalExerciseTaId) {
		this.taLicenceRenewalExerciseTaId = taLicenceRenewalExerciseTaId;
	}

	public Boolean getRenewalIsOpen() {
		return renewalIsOpen;
	}

	public void setRenewalIsOpen(Boolean renewalIsOpen) {
		this.renewalIsOpen = renewalIsOpen;
	}

	public List<ListableDto> getPastRenewalCycle() {
		return pastRenewalCycle;
	}

	public void setPastRenewalCycle(List<ListableDto> pastRenewalCycle) {
		this.pastRenewalCycle = pastRenewalCycle;
	}

}
