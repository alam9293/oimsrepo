package gov.stb.tag.dto.ta.licenceRenewal;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceRenewalItemDto extends TaApplicationItemDto {

	public TaLicenceRenewalItemDto() {

	}

}
