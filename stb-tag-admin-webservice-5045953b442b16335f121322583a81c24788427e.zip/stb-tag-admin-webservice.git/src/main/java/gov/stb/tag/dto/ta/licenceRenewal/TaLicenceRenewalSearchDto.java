package gov.stb.tag.dto.ta.licenceRenewal;

import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;

public class TaLicenceRenewalSearchDto extends TaApplicationSearchDto {

}
