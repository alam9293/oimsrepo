package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.math.BigDecimal;
import java.time.LocalDate;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaNetValueShortfall;

public class AaFilingForRenewalDto extends TaFilingForRenewalDto {

	@MapProjection(path = "taAaSubmission.id")
	private Integer taAaSubmissionId;

	@MapProjection(path = "fyEndDate")
	private LocalDate fyEndDate;

	@MapProjection(path = "taAaSubmission.shortfall")
	private BigDecimal shortfall;

	private shortfallRectificationForRenewalDto rectification;

	public static AaFilingForRenewalDto buildAaFillingForRenewalDto(TaNetValueShortfall shortfallModel, TaFilingCondition filingModel, AaFilingForRenewalDto dto, TaAaSubmission aa) {
		if (filingModel != null) {
			dto = dto.buildFromFiling(filingModel, dto,
					aa != null && aa.getApplication() != null && !aa.getApplication().isDraft() && !aa.getApplication().isDeleted() ? aa.getApplication().getId() : null,
					aa != null && aa.getApplication() != null && !aa.getApplication().isDraft() && !aa.getApplication().isDeleted() ? aa.getApplication().getApplicationNo() : null);
			dto.setFyEndDate(filingModel.getFyEndDate());
		} else {
			dto.setFilingSubmissionStatus("Not required");
		}
		if (aa != null && !aa.getApplication().isDraft() && !aa.getApplication().isDeleted()) {
			dto.setTaAaSubmissionId(aa.getId());
		}

		if (shortfallModel != null) {
			if (aa != null && shortfallModel.getWorkflow().getLastAction().getStatus().getKey().toString().equalsIgnoreCase(Statuses.TA_WKFLW_APPROVED)
					&& shortfallModel.getWorkflow().getLastAction().getRecommendation().getCode().equalsIgnoreCase(Types.RECOMMEND_IMPOSE)) {
				dto.setShortfall(aa.getShortfall());
			}
			dto.setRectification(shortfallRectificationForRenewalDto.buildShortFallForRenewalDto(shortfallModel, new shortfallRectificationForRenewalDto()));
		}
		return dto;
	}

	public LocalDate getFyEndDate() {
		return fyEndDate;
	}

	public void setFyEndDate(LocalDate fyEndDate) {
		this.fyEndDate = fyEndDate;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public Integer getTaAaSubmissionId() {
		return taAaSubmissionId;
	}

	public void setTaAaSubmissionId(Integer taAaSubmissionId) {
		this.taAaSubmissionId = taAaSubmissionId;
	}

	public shortfallRectificationForRenewalDto getRectification() {
		return rectification;
	}

	public void setRectification(shortfallRectificationForRenewalDto rectification) {
		this.rectification = rectification;
	}

}
