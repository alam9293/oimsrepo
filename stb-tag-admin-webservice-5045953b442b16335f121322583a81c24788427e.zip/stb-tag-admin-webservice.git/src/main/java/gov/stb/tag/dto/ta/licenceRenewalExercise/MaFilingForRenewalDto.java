package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.math.BigDecimal;

import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueShortfall;

public class MaFilingForRenewalDto extends TaFilingForRenewalDto {

	private Integer taMaSubmissionId;

	private BigDecimal shortfall;

	private shortfallRectificationForRenewalDto rectification;

	public static MaFilingForRenewalDto buildMaFillingForRenewalDto(TaNetValueShortfall shortfallModel, TaFilingCondition filingModel, MaFilingForRenewalDto dto, TaMaSubmission ma) {
		if (filingModel != null) {
			dto = dto.buildFromFiling(filingModel, dto,
					ma != null && ma.getApplication() != null && !ma.getApplication().isDraft() && !ma.getApplication().isDeleted() ? ma.getApplication().getId() : null,
					ma != null && ma.getApplication() != null && !ma.getApplication().isDraft() && !ma.getApplication().isDeleted() ? ma.getApplication().getApplicationNo() : null);
		} else {
			dto.setFilingSubmissionStatus("Not required");
		}

		if (ma != null) {
			dto.setTaMaSubmissionId(ma.getId());
		}
		if (shortfallModel != null) {
			dto.setRectification(shortfallRectificationForRenewalDto.buildShortFallForRenewalDto(shortfallModel, new shortfallRectificationForRenewalDto()));
			if (ma != null && shortfallModel.getWorkflow().getLastAction().getStatus().getKey().toString().equalsIgnoreCase(Statuses.TA_WKFLW_APPROVED)
					&& shortfallModel.getWorkflow().getLastAction().getRecommendation().getCode().equalsIgnoreCase(Types.RECOMMEND_IMPOSE)) {
				dto.setShortfall(ma.getShortfall());
			}
		}
		return dto;
	}

	public Integer getTaMaSubmissionId() {
		return taMaSubmissionId;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setTaMaSubmissionId(Integer taMaSubmissionId) {
		this.taMaSubmissionId = taMaSubmissionId;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public shortfallRectificationForRenewalDto getRectification() {
		return rectification;
	}

	public void setRectification(shortfallRectificationForRenewalDto rectification) {
		this.rectification = rectification;
	}

}
