package gov.stb.tag.dto.ta.licenceRenewalExercise;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.ApplicationTypes;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderDto;
import gov.stb.tag.dto.ta.travelagent.TravelAgentDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaAbprSubmission;
import gov.stb.tag.model.TaLicenceRenewal;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaLicenceRenewalExerciseParam;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaStakeholder;

public class TaLicenceRenewalExerciseParticipantDto {

	private Integer renewalExerciseTaId;
	private Integer licenceId;
	private String name;
	private String licenceNo;
	private ListableDto licenceStatus;
	private String uen;
	private ListableDto renewalType;
	private ListableDto keyExec;
	private LocalDate fye;
	private BigDecimal outstandingPayment;
	private List<AaFilingForRenewalDto> aa = new ArrayList<AaFilingForRenewalDto>();
	private List<AbprFilingForRenewalDto> abpr = new ArrayList<AbprFilingForRenewalDto>();
	private List<MaFilingForRenewalDto> ma = new ArrayList<MaFilingForRenewalDto>();

	private String isRequireMa;
	private boolean hasAdhocMa;
	private boolean isMaVoid;
	private Integer renewalExerciseId;
	private ListableDto renewalSubmission;
	private TaLicenceMaRequestDto maRequest;

	private ListableDto renewalStatus;
	private StakeholderDto keDetails;
	private TravelAgentDto taDto;

	private String baselinedName;
	private StakeholderDto baselinedKe;
	private LocalDate baselinedFye;
	private BigDecimal baselinedOutstandingPayment;

	public static TaLicenceRenewalExerciseParticipantDto buildRenewalParticipantForDto(CacheHelper cacheHelper, TaLicenceRenewalExerciseTa model, TaLicenceRenewalExerciseParticipantDto dto,
			TaLicenceRenewalExercise renewalExercise, Map<Integer, TaAaSubmission> aaSubmissionMap, Map<Integer, TaAbprSubmission> abprSubmissionMap, TaLicenceRenewalExerciseParam exerciseParam,
			TaLicenceRenewal renewalSubmission, Map<Integer, TaMaSubmission> maSubmissionMap, Boolean detailsForExport, Integer year) {
		Licence licenceModel = model.getLicence();

		dto.setRenewalExerciseId(renewalExercise.getId());
		dto.setRenewalExerciseTaId(model.getId());
		dto.setLicenceId(licenceModel.getId());
		dto.setLicenceStatus(new ListableDto(licenceModel.getStatus().getKey(), licenceModel.getStatus().getLabel(), licenceModel.getTier().getLabel()));
		if (model.getType().getKey() != null && model.getType().getKey().equals(Codes.TaRenewalTypes.TA_RENEW_CUSTOMISED) && renewalExercise.getYear() != null && renewalExercise.getYear() >= year) {
			dto.setRenewalType(new ListableDto(model.getType().getKey(), Codes.TaRenewalTypesLabel.TA_RENEW_CUSTOMISED_NEW_LABEL));
		} else if (model.getType().getKey() != null && model.getType().getKey().equals(Codes.TaRenewalTypes.TA_RENEW_CUSTOMISED) && renewalExercise.getYear() != null
				&& renewalExercise.getYear() < year) {
			dto.setRenewalType(new ListableDto(model.getType().getKey(), model.getType().getLabel()));
		} else {
			dto.setRenewalType(new ListableDto(model.getType().getKey(), model.getType().getLabel()));
		}
		dto.setUen(licenceModel.getTravelAgent().getUen());
		dto.setLicenceNo(licenceModel.getLicenceNo());
		TaStakeholder confirmKe = null;
		if (renewalExercise.hasBaselined()) {
			dto.setBaselinedFye(model.getBaselinedFye());
			dto.setBaselinedName(model.getBaselinedName());
			dto.setBaselinedOutstandingPayment(model.getBaselinedOutstandingPayment());
			if (model.getBaselinedKe() != null) {
				if (detailsForExport) {
					dto.setBaselinedKe(new StakeholderDto(cacheHelper, model.getBaselinedKe().getStakeholder()));
				}
			}
		}
		dto.setName(model.getLicence().getTravelAgent().getName());
		if (model.getKe() != null) {
			confirmKe = model.getKe();
		}
		dto.setFye(model.getFye());
		dto.setOutstandingPayment(model.getOutstandingPayment());

		if (confirmKe != null) {
			dto.setKeyExec(new ListableDto(confirmKe.getId(), confirmKe.getStakeholder().getName()));
			if (detailsForExport) {
				dto.setKeDetails(new StakeholderDto(cacheHelper, confirmKe.getStakeholder()));
			}
		}

		if (detailsForExport) {
			dto.setTaDto(TravelAgentDto.buildTravelAgentDto(cacheHelper, model.getLicence().getTravelAgent()));
		}

		if (model.getTaAaFilingCondition1() != null) {
			dto.getAa().add(AaFilingForRenewalDto.buildAaFillingForRenewalDto(model.getTaNetValueShortfallAa1(), model.getTaAaFilingCondition1(), new AaFilingForRenewalDto(),
					aaSubmissionMap.get(model.getTaAaFilingCondition1().getId())));
		}
		if (model.getTaAaFilingCondition2() != null) {
			dto.getAa().add(AaFilingForRenewalDto.buildAaFillingForRenewalDto(model.getTaNetValueShortfallAa2(), model.getTaAaFilingCondition2(), new AaFilingForRenewalDto(),
					aaSubmissionMap.get(model.getTaAaFilingCondition2().getId())));
		}
		if (model.getTaAbprFilingCondition1() != null) {
			dto.getAbpr().add(AbprFilingForRenewalDto.buildAbprFillingForRenewalDto(model.getTaAbprFilingCondition1(), new AbprFilingForRenewalDto(),
					abprSubmissionMap.get(model.getTaAbprFilingCondition1().getId())));
		}
		if (model.getTaAbprFilingCondition2() != null) {
			dto.getAbpr().add(AbprFilingForRenewalDto.buildAbprFillingForRenewalDto(model.getTaAbprFilingCondition2(), new AbprFilingForRenewalDto(),
					abprSubmissionMap.get(model.getTaAbprFilingCondition2().getId())));
		}

		if (model.getTaLicenceRenewal() != null) {
			dto.setRenewalSubmission(new ListableDto(model.getTaLicenceRenewal().getApplication().getId(), model.getTaLicenceRenewal().getApplication().getLastAction().getStatus().getLabel()));
		}

		if (exerciseParam == null) {
			dto.setIsRequireMa(model.isMaRequired() == null ? null : model.isMaRequired().toString());
			if (!renewalExercise.hasBaselined() && Boolean.valueOf(dto.isRequireMa)) {
				dto.setMaRequest(TaLicenceMaRequestDto.buildRequestMaDto(null, new TaLicenceMaRequestDto(), licenceModel.getId(), renewalExercise.getId(), model.getId(), renewalExercise, model));
			}
		} else {
			if (!model.getIsMaVoid()) {
				dto.setIsRequireMa(exerciseParam.isMaRequiredByUser() == null ? null : exerciseParam.isMaRequiredByUser().toString());
			} else {

			}
			if (!renewalExercise.hasBaselined() && Boolean.valueOf(dto.isRequireMa)) {
				dto.setMaRequest(
						TaLicenceMaRequestDto.buildRequestMaDto(exerciseParam, new TaLicenceMaRequestDto(), licenceModel.getId(), renewalExercise.getId(), model.getId(), renewalExercise, model));
			}
		}

		if (renewalSubmission != null) {
			dto.setRenewalStatus(new ListableDto(renewalSubmission.getApplication().getLastAction().getStatus().getCode(), renewalSubmission.getApplication().getLastAction().getStatus().getLabel()));
		}

		if (renewalExercise.hasBaselined() && Boolean.valueOf(dto.isRequireMa)) {
			if (model.getMaFilingCondition() != null) {
				dto.setMaRequest(TaLicenceMaRequestDto.buildRequestMaDto(model.getMaFilingCondition(), new TaLicenceMaRequestDto()));
			}
		}

		if (model.getMaFilingCondition() != null) {
			if (model.getMaFilingCondition().getApplicationType().getCode().equalsIgnoreCase(ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION)) {
				dto.setHasAdhocMa(Boolean.TRUE);
			}
			dto.getMa().add(MaFilingForRenewalDto.buildMaFillingForRenewalDto(model.getTaNetValueShortfallMa1(), model.getMaFilingCondition(), new MaFilingForRenewalDto(),
					maSubmissionMap.get(model.getMaFilingCondition().getId())));
		}

		dto.setMaVoid(model.getIsMaVoid());

		return dto;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public ListableDto getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(ListableDto licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public ListableDto getKeyExec() {
		return keyExec;
	}

	public void setKeyExec(ListableDto keyExec) {
		this.keyExec = keyExec;
	}

	public LocalDate getFye() {
		return fye;
	}

	public void setFye(LocalDate fye) {
		this.fye = fye;
	}

	public List<AaFilingForRenewalDto> getAa() {
		return aa;
	}

	public void setAa(List<AaFilingForRenewalDto> aa) {
		this.aa = aa;
	}

	public List<AbprFilingForRenewalDto> getAbpr() {
		return abpr;
	}

	public void setAbpr(List<AbprFilingForRenewalDto> abpr) {
		this.abpr = abpr;
	}

	public BigDecimal getOutstandingPayment() {
		return outstandingPayment;
	}

	public void setOutstandingPayment(BigDecimal outstandingPayment) {
		this.outstandingPayment = outstandingPayment;
	}

	public Integer getRenewalExerciseTaId() {
		return renewalExerciseTaId;
	}

	public void setRenewalExerciseTaId(Integer renewalExerciseTaId) {
		this.renewalExerciseTaId = renewalExerciseTaId;
	}

	public ListableDto getRenewalType() {
		return renewalType;
	}

	public void setRenewalType(ListableDto renewalType) {
		this.renewalType = renewalType;
	}

	public ListableDto getRenewalSubmission() {
		return renewalSubmission;
	}

	public void setRenewalSubmission(ListableDto renewalSubmission) {
		this.renewalSubmission = renewalSubmission;
	}

	public Integer getRenewalExerciseId() {
		return renewalExerciseId;
	}

	public void setRenewalExerciseId(Integer renewalExerciseId) {
		this.renewalExerciseId = renewalExerciseId;
	}

	public String getIsRequireMa() {
		return isRequireMa;
	}

	public void setIsRequireMa(String isRequireMa) {
		this.isRequireMa = isRequireMa;
	}

	public TaLicenceMaRequestDto getMaRequest() {
		return maRequest;
	}

	public void setMaRequest(TaLicenceMaRequestDto maRequest) {
		this.maRequest = maRequest;
	}

	public ListableDto getRenewalStatus() {
		return renewalStatus;
	}

	public void setRenewalStatus(ListableDto renewalStatus) {
		this.renewalStatus = renewalStatus;
	}

	public List<MaFilingForRenewalDto> getMa() {
		return ma;
	}

	public void setMa(List<MaFilingForRenewalDto> ma) {
		this.ma = ma;
	}

	public StakeholderDto getKeDetails() {
		return keDetails;
	}

	public void setKeDetails(StakeholderDto keDetails) {
		this.keDetails = keDetails;
	}

	public TravelAgentDto getTaDto() {
		return taDto;
	}

	public void setTaDto(TravelAgentDto taDto) {
		this.taDto = taDto;
	}

	// convenient methods for TaManageRenewalExerciseController export function

	public String getAuditedAccounts(Integer index) {
		return getAa().size() > index ? getAa().get(index).getFy().toString().concat(" - ").concat(getAa().get(index).getFilingSubmissionStatus()) : "";
	}

	public String getAaNetValue(Integer index) {
		return getAa().size() > index && getAa().get(index).getShortfall() != null ? getAa().get(index).getShortfall().toString() : "";
	}

	public String getAaNetValueFulfilment(Integer index) {
		return getAa().size() > index && getAa().get(index).getRectification() != null ? getAa().get(index).getRectification().getRectificationStatus() : "";
	}

	public String getAbpr(Integer index) {
		return getAbpr().size() > index ? getAbpr().get(index).getFy().toString().concat(" - ").concat(getAbpr().get(index).getFilingSubmissionStatus()) : "";
	}

	public String getMa(Integer index) {
		return getMa().size() > index ? getMa().get(index).getFy().toString().concat(" - ").concat(getMa().get(index).getFilingSubmissionStatus()) : "";
	}

	public String getMaNetValue(Integer index) {
		return getMa().size() > index && getMa().get(index).getShortfall() != null ? getMa().get(index).getShortfall().toString() : "";
	}

	public String getMaNetValueFulfilment(Integer index) {
		return getMa().size() > index && getMa().get(index).getRectification() != null ? getMa().get(index).getRectification().getRectificationStatus() : "";
	}

	public AddressDto getTaOperatingAddress() {
		return getTaDto() != null && getTaDto().getOperatingAddressDto() != null ? getTaDto().getOperatingAddressDto() : null;
	}

	public String getBaselinedName() {
		return baselinedName;
	}

	public void setBaselinedName(String baselinedName) {
		this.baselinedName = baselinedName;
	}

	public StakeholderDto getBaselinedKe() {
		return baselinedKe;
	}

	public void setBaselinedKe(StakeholderDto baselinedKe) {
		this.baselinedKe = baselinedKe;
	}

	public LocalDate getBaselinedFye() {
		return baselinedFye;
	}

	public void setBaselinedFye(LocalDate baselinedFye) {
		this.baselinedFye = baselinedFye;
	}

	public BigDecimal getBaselinedOutstandingPayment() {
		return baselinedOutstandingPayment;
	}

	public void setBaselinedOutstandingPayment(BigDecimal baselinedOutstandingPayment) {
		this.baselinedOutstandingPayment = baselinedOutstandingPayment;
	}

	public boolean isHasAdhocMa() {
		return hasAdhocMa;
	}

	public void setHasAdhocMa(boolean hasAdhocMa) {
		this.hasAdhocMa = hasAdhocMa;
	}

	public boolean isMaVoid() {
		return isMaVoid;
	}

	public void setMaVoid(boolean isMaVoid) {
		this.isMaVoid = isMaVoid;
	}

}
