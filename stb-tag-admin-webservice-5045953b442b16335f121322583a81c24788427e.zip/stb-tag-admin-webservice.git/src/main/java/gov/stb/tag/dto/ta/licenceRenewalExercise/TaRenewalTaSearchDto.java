package gov.stb.tag.dto.ta.licenceRenewalExercise;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaRenewalTaSearchDto extends SearchDto {
	private String name;
	private String licenceNo;
	private String uen;
	private String applicationType;
	private String keName;
	private String fye;
	private Integer renewalExerciseId;
	private String renewalTypeLabel;
	private String renewalTypeCode;

	private Integer licenceId;
	private Integer renewalExerciseTaId;

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public Integer getRenewalExerciseTaId() {
		return renewalExerciseTaId;
	}

	public void setRenewalExerciseTaId(Integer renewalExerciseTaId) {
		this.renewalExerciseTaId = renewalExerciseTaId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getKeName() {
		return keName;
	}

	public void setKeName(String keName) {
		this.keName = keName;
	}

	public String getFye() {
		return fye;
	}

	public void setFye(String fye) {
		this.fye = fye;
	}

	public Integer getRenewalExerciseId() {
		return renewalExerciseId;
	}

	public void setRenewalExerciseId(Integer renewalExerciseId) {
		this.renewalExerciseId = renewalExerciseId;
	}

	public String getRenewalTypeLabel() {
		return renewalTypeLabel;
	}

	public void setRenewalTypeLabel(String renewalTypeLabel) {
		this.renewalTypeLabel = renewalTypeLabel;
	}

	public String getRenewalTypeCode() {
		return renewalTypeCode;
	}

	public void setRenewalTypeCode(String renewalTypeCode) {
		this.renewalTypeCode = renewalTypeCode;
	}

}
