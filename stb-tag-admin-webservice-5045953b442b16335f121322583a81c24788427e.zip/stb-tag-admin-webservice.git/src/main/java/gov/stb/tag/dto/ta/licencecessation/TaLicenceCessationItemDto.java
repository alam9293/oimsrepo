package gov.stb.tag.dto.ta.licencecessation;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceCessationItemDto extends TaApplicationItemDto {

	public TaLicenceCessationItemDto() {

	}

}
