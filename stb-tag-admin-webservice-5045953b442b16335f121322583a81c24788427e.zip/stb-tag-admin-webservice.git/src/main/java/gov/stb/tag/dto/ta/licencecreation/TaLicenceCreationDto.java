package gov.stb.tag.dto.ta.licencecreation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.ta.abpr.TaAreaOfFocusDto;
import gov.stb.tag.dto.ta.abpr.TaBusinessOperationDto;
import gov.stb.tag.dto.ta.abpr.TaMarketSpecializationDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderRecordDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.MyInfoHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.jackson.BigDecimalToMoneyThousandSeparatorConverter;
import gov.stb.tag.jackson.MoneyThousandSeparatorToBigDecimalConverter;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TaBusinessOperation;
import gov.stb.tag.model.TaFocusArea;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.TaSpecializedMarket;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceCreationDto extends EntityDto {

	// Application Details
	private Boolean isActiveLicencee;

	private Integer id;

	private String applicationNo;

	private Boolean isDraft;

	private LocalDate draftExpiryDate;

	private Boolean isDeleted;

	private ListableDto status;

	private String externalRemarks;

	private LocalDateTime submissionDate;

	private String loggedInUin;

	private LocalDateTime lastUpdated;

	// Applicant Details

	private Boolean isAppMyInfo;

	private Boolean isAppMyInfoClicked;

	private String appName;

	private String appUin;

	private LocalDate appDob;

	private ListableDto appSex;

	private ListableDto appNationality;

	private ListableDto appDesignation;

	private String appOtherDesignation;

	private String appOfficeNo;

	private String appResidentialNo;

	private String appMobileNo;

	private String appFaxNo;

	private String appEmailAddress;

	private String[] appEditableFields;

	// Business Entity Details
	private Boolean isEdhPopulated;

	private LocalDate effectiveDate;

	private ListableDto applicationMode;

	private ListableDto licenceTier;

	private String companyName;

	private String companyFormerName;

	private ListableDto formOfBusiness;

	private ListableDto businessConstitution;

	private String uen;

	private LocalDate registrationDate;

	private ListableDto principleActivities;

	private ListableDto secondaryPrincipleActivities;

	private ListableDto placeIncorporated;

	private ListableDto establishmentStatus;

	private ListableDto taSegmentation;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal paidUpCapital;

	private String websiteUrl;

	private String emailAddress;

	private String contactNo;

	private String faxNo;

	private Integer fyeDay;

	private Integer fyeMonth;

	private AddressDto registeredAddress;

	private AddressDto operatingAddress;

	private Boolean isOppAddSameAsRegAdd;

	// KE
	private Boolean isKeMyInfo;

	private Boolean isKeMyInfoClicked;

	private StakeholderRecordDto taKeyExecutive;

	private String[] keEditableFields;

	// Market Specialization
	private BigDecimal inboundOpPercent;

	private BigDecimal outboundOpPercent;

	private String taBusinessWriteUp;

	private String currentBusinessWriteUp;

	private String businessIdea;

	private String consumerFacingBrand;

	private String mktgCommsPlan;

	private String[] salesChannelSelected;
	private List<String> salesChannelSelectedLabels;

	private String otherSalesChannel;

	private String financialStrategy;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal revenueProj1;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal revenueProj2;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal costProj1;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal costProj2;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal profitLossProj1;

	@JsonDeserialize(converter = MoneyThousandSeparatorToBigDecimalConverter.class)
	@JsonSerialize(converter = BigDecimalToMoneyThousandSeparatorConverter.class)
	private BigDecimal profitLossProj2;

	private String estTimeToProfit;

	private String competitiveEdge;

	private String partnerServideProviders;

	private Boolean hasOtherBizActivities;

	private BigDecimal percentFocusOnTaBiz;

	private Boolean hasTaLicBefore;

	private String detailsRegardingPrevLic;

	private String relationsWithOtherTa;

	private String others;

	private List<TaMarketSpecializationDto> taInboundSpecializedMarkets = new ArrayList<>();
	private List<TaMarketSpecializationDto> taOutboundSpecializedMarkets = new ArrayList<>();

	private List<TaBusinessOperationDto> taBusinessOperations = new ArrayList<>();

	private List<TaAreaOfFocusDto> taFocusAreas = new ArrayList<>();

	// Personnels
	private List<StakeholderRecordDto> taStakeholders = new ArrayList<>();

	// Supporting Documents
	private FileDto keNric;
	private FileDto keResume;
	private FileDto keResolution;
	private FileDto beoc;
	private FileDto bankStatement;
	private FileDto tenancyAgreement;
	private FileDto hosApproval;
	private FileDto cbs;
	private FileDto afa;
	private FileDto acra;
	private List<FileDto> otherDocuments;

	// Payment
	private PaymentRequestDto appFee;
	private PaymentRequestDto licenceFee;

	private boolean isFinalApproval;
	private boolean isInLowestStep;

	public static TaLicenceCreationDto buildFromApplication(CacheHelper cache, PaymentHelper paymentHelper, TaLicenceCreation tlc, User user, MyInfoHelper myInfoHelper, FileHelper fileHelper) {
		TaLicenceCreationDto dto = new TaLicenceCreationDto();

		// 1. Application
		dto.setId(tlc.getApplication().getId());
		dto.setApplicationNo(tlc.getApplication().getApplicationNo());
		dto.setIsDraft(tlc.getApplication().getIsDraft());
		if (tlc.getApplication().getIsDraft()) {
			dto.setDraftExpiryDate(tlc.getCreatedDate().plusDays(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.APP_DRAFT_VALIDITY).getValue())).toLocalDate());
		}
		dto.setStatus(tlc.getApplication().getLastAction() != null ? new ListableDto(tlc.getApplication().getLastAction().getStatus().getKey(),
				cache.getLabel(tlc.getApplication().getLastAction().getStatus(), false), cache.getLabel(tlc.getApplication().getLastAction().getStatus(), true)) : new ListableDto());
		dto.setExternalRemarks(tlc.getApplication().getLastAction() != null ? tlc.getApplication().getLastAction().getExternalRemarks() : null);

		dto.setSubmissionDate(tlc.getApplication().getSubmissionDate());
		dto.setLoggedInUin(user.getLoginId());
		dto.setLastUpdated(tlc.getUpdatedDate());

		// 2. Application Particulars
		dto.setIsAppMyInfo(tlc.isMyInfoPopulated());
		dto.setAppName(tlc.getAppName());
		dto.setAppUin(tlc.getAppUin());
		dto.setAppDob(tlc.getAppDob());
		dto.setAppSex(tlc.getAppSex() != null ? new ListableDto(tlc.getAppSex().getKey(), cache.getLabel(tlc.getAppSex(), false)) : new ListableDto());
		dto.setAppNationality(tlc.getAppNationality() != null ? new ListableDto(tlc.getAppNationality().getKey(), cache.getLabel(tlc.getAppNationality(), false)) : new ListableDto());
		dto.setAppDesignation(tlc.getAppDesignation() != null ? new ListableDto(tlc.getAppDesignation().getKey(), cache.getLabel(tlc.getAppDesignation(), false)) : new ListableDto());
		dto.setAppOtherDesignation(tlc.getAppOtherDesignation());
		dto.setAppOfficeNo(tlc.getAppOfficeNo());
		dto.setAppResidentialNo(tlc.getAppResidentialNo());
		dto.setAppMobileNo(tlc.getAppMobileNo());
		dto.setAppFaxNo(tlc.getAppFaxNo());
		dto.setAppEmailAddress(tlc.getAppEmailAddress());
		if (tlc.isMyInfoPopulated()) {
			dto.setAppEditableFields(myInfoHelper.getNonEditableFields(tlc.getAppUin()));
		}

		// 3. Business Entity
		dto.setIsEdhPopulated(tlc.isEdhPopulated());
		dto.setEffectiveDate(tlc.getEffectiveDate());
		dto.setApplicationMode(tlc.getApplicationMode() != null ? new ListableDto(tlc.getApplicationMode().getKey(), cache.getLabel(tlc.getApplicationMode(), false)) : new ListableDto());
		dto.setLicenceTier(tlc.getLicenceTier() != null ? new ListableDto(tlc.getLicenceTier().getKey(), cache.getLabel(tlc.getLicenceTier(), false)) : new ListableDto());
		dto.setCompanyName(tlc.getCompanyName());
		dto.setCompanyFormerName(tlc.getCompanyFormerName());
		dto.setFormOfBusiness(tlc.getFormOfBusiness() != null ? new ListableDto(tlc.getFormOfBusiness().getKey(), cache.getLabel(tlc.getFormOfBusiness(), false)) : new ListableDto());
		dto.setBusinessConstitution(
				tlc.getBusinessConstitution() != null ? new ListableDto(tlc.getBusinessConstitution().getKey(), cache.getLabel(tlc.getBusinessConstitution(), false)) : new ListableDto());
		dto.setUen(tlc.getUen());
		dto.setRegistrationDate(tlc.getRegistrationDate());
		dto.setPrincipleActivities(
				tlc.getPrincipleActivities() != null ? new ListableDto(tlc.getPrincipleActivities().getKey(), cache.getLabel(tlc.getPrincipleActivities(), false)) : new ListableDto());
		dto.setSecondaryPrincipleActivities(
				tlc.getSecondaryPrincipleActivities() != null ? new ListableDto(tlc.getSecondaryPrincipleActivities().getKey(), cache.getLabel(tlc.getSecondaryPrincipleActivities(), false))
						: new ListableDto());
		dto.setPlaceIncorporated(tlc.getPlaceIncorporated() != null ? new ListableDto(tlc.getPlaceIncorporated().getKey(), cache.getLabel(tlc.getPlaceIncorporated(), false)) : new ListableDto());
		dto.setEstablishmentStatus(
				tlc.getEstablishmentStatus() != null ? new ListableDto(tlc.getEstablishmentStatus().getKey(), cache.getLabel(tlc.getEstablishmentStatus(), false)) : new ListableDto());
		dto.setTaSegmentation(tlc.getTaSegmentation() != null ? new ListableDto(tlc.getTaSegmentation().getKey(), cache.getLabel(tlc.getTaSegmentation(), false)) : new ListableDto());
		dto.setPaidUpCapital(tlc.getPaidUpCapital());
		dto.setWebsiteUrl(tlc.getWebsiteUrl());
		dto.setEmailAddress(tlc.getEmailAddress());
		dto.setContactNo(tlc.getContactNo());
		dto.setFaxNo(tlc.getFaxNo());
		if (tlc.getFyeDate() != null) {
			dto.setFyeDay(tlc.getFyeDate().getDayOfMonth());
			dto.setFyeMonth(tlc.getFyeDate().getMonthValue());
		}

		dto.setRegisteredAddress(AddressDto.buildFromAddress(cache, tlc.getRegisteredAddress()));
		dto.setOperatingAddress(AddressDto.buildFromAddress(cache, tlc.getOperatingAddress()));
		dto.setIsOppAddSameAsRegAdd(tlc.getIsOppAddSameAsRegAdd());

		// 4. Market Specialization
		dto.setInboundOpPercent(tlc.getInboundOpPercent());
		dto.setOutboundOpPercent(tlc.getOutboundOpPercent());

		if (!Strings.isNullOrEmpty(tlc.getTaBusinessWriteUp()) && !tlc.getApplication().getIsDraft()) {
			dto.setCurrentBusinessWriteUp(tlc.getCurrentBusinessWriteUp());
			dto.setTaBusinessWriteUp(tlc.getTaBusinessWriteUp());
		} else {
			dto.setBusinessIdea(tlc.getBusinessIdea());
			dto.setConsumerFacingBrand(tlc.getConsumerFacingBrand());
			dto.setMktgCommsPlan(tlc.getMktgCommsPlan());

			if (tlc.getSalesChannel() != null && tlc.getSalesChannel().size() > 0) {
				dto.setSalesChannelSelected((tlc.getSalesChannel().parallelStream().map(Type::getCode).collect(Collectors.toList())).toArray(new String[tlc.getSalesChannel().size()]));
				if (!tlc.getApplication().getIsDraft()) {
					dto.setSalesChannelSelectedLabels(new ArrayList<String>());
					dto.getSalesChannelSelectedLabels()
							.addAll(tlc.getSalesChannel().parallelStream().filter(o -> !o.getCode().equalsIgnoreCase(Types.TA_SALES_CHANNEL_OTHERS)).map(Type::getLabel).collect(Collectors.toList()));
					if (tlc.getSalesChannel().contains(cache.getType(Types.TA_SALES_CHANNEL_OTHERS))) {
						dto.getSalesChannelSelectedLabels().add(cache.getType(Types.TA_SALES_CHANNEL_OTHERS).getLabel().concat(": ").concat(tlc.getOtherSalesChannel()));
					}
				}
			}
			dto.setOtherSalesChannel(tlc.getOtherSalesChannel());

			dto.setFinancialStrategy(tlc.getFinancialStrategy());

			dto.setRevenueProj1(tlc.getRevenueProj1());
			dto.setRevenueProj2(tlc.getRevenueProj2());
			dto.setCostProj1(tlc.getCostProj1());
			dto.setCostProj2(tlc.getCostProj2());
			dto.setProfitLossProj1(tlc.getProfitLossProj1());
			dto.setProfitLossProj2(tlc.getProfitLossProj2());

			dto.setEstTimeToProfit(tlc.getEstTimeToProfit());
			dto.setCompetitiveEdge(tlc.getCompetitiveEdge());
			dto.setPartnerServideProviders(tlc.getPartnerServideProviders());
			dto.setHasOtherBizActivities(tlc.getHasOtherBizActivities());
			dto.setPercentFocusOnTaBiz(tlc.getPercentFocusOnTaBiz());
			dto.setHasTaLicBefore(tlc.getHasTaLicBefore());
			dto.setDetailsRegardingPrevLic(tlc.getDetailsRegardingPrevLic());
			dto.setRelationsWithOtherTa(tlc.getRelationsWithOtherTa());
			dto.setOthers(tlc.getOthers());
		}

		List<TaMarketSpecializationDto> ims = new ArrayList<>();
		List<TaMarketSpecializationDto> oms = new ArrayList<>();
		if (tlc.getTaSpecializedMarkets() != null) {
			for (TaSpecializedMarket aMS : tlc.getTaSpecializedMarkets()) {
				if (aMS.getIsInbound() == true) {
					ims.add(TaMarketSpecializationDto.buildFromMS(cache, aMS));
				} else {
					oms.add(TaMarketSpecializationDto.buildFromMS(cache, aMS));
				}

			}
		}

		dto.setTaInboundSpecializedMarkets(ims);
		dto.setTaOutboundSpecializedMarkets(oms);

		List<TaBusinessOperationDto> bo = new ArrayList<>();
		if (tlc.getTaBusinessOperations() != null) {
			for (TaBusinessOperation aBO : tlc.getTaBusinessOperations()) {
				bo.add(TaBusinessOperationDto.buildFromBO(cache, aBO));
			}
		}
		dto.setTaBusinessOperations(bo);

		List<TaAreaOfFocusDto> aof = new ArrayList<>();
		if (tlc.getTaFocusAreas() != null) {
			for (TaFocusArea aAOF : tlc.getTaFocusAreas()) {
				aof.add(TaAreaOfFocusDto.buildFromFA(cache, aAOF));
			}
		}
		dto.setTaFocusAreas(aof);

		// 5. Personnel
		List<StakeholderRecordDto> personnels = new ArrayList<>();
		if (tlc.getTaStakeholders() != null) {
			for (TaStakeholderApplication tsh : tlc.getTaStakeholders()) {
				if (!tsh.getRole().getCode().equals(Codes.TaStakeholderRoles.STKHLD_KE)) {
					personnels.add(StakeholderRecordDto.build(cache, tsh, false));
				}

			}
		}
		dto.setTaStakeholders(personnels);

		// 6. KE
		dto.setTaKeyExecutive(StakeholderRecordDto.build(cache, tlc.getTaKeyExecutive(), true));
		dto.setIsKeMyInfo(tlc.getTaKeyExecutive().isMyInfoPopulated());
		if (tlc.getTaKeyExecutive().isMyInfoPopulated()) {
			dto.setKeEditableFields(myInfoHelper.getNonEditableFields(tlc.getTaKeyExecutive().getUin()));
		}

		// 7. Supporting Documents
		if (tlc.getApplication().getApplicationFiles() != null) {
			List<ApplicationFile> appFiles = new ArrayList<>(tlc.getApplication().getApplicationFiles());
			List<FileDto> otherDocuments = new ArrayList<FileDto>();
			if (appFiles.size() > 0) {
				for (ApplicationFile appFile : appFiles) {
					if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_KE_NRIC)) {
						dto.setKeNric(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_KE_RESUME)) {
						dto.setKeResume(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_KE_DIR_RESOLUTION)) {
						dto.setKeResolution(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_BEOC)) {
						dto.setBeoc(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_BANK)) {
						dto.setBankStatement(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_TENANCY)) {
						dto.setTenancyAgreement(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_HOS_APPROVAL)) {
						dto.setHosApproval(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_CBS)) {
						dto.setCbs(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_MGMT_ACC)) {
						dto.setAfa(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ)) {
						dto.setAcra(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					} else {
						otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					}

				}
				dto.setOtherDocuments(otherDocuments);
			}
			if (dto.getKeNric() == null) {
				dto.setKeNric(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_KE_NRIC), fileHelper));
			}
			if (dto.getKeResume() == null) {
				dto.setKeResume(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_KE_RESUME), fileHelper));
			}
			if (dto.getKeResolution() == null) {
				dto.setKeResolution(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_KE_DIR_RESOLUTION), fileHelper));
			}
			if (dto.getBeoc() == null) {
				dto.setBeoc(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_BEOC), fileHelper));
			}
			if (dto.getBankStatement() == null) {
				dto.setBankStatement(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_BANK), fileHelper));
			}
			if (dto.getTenancyAgreement() == null) {
				dto.setTenancyAgreement(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_TENANCY), fileHelper));
			}
			if (dto.getHosApproval() == null) {
				dto.setHosApproval(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_HOS_APPROVAL), fileHelper));
			}
			if (dto.getCbs() == null) {
				dto.setCbs(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_CBS), fileHelper));
			}
			if (dto.getAfa() == null) {
				dto.setAfa(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_MGMT_ACC), fileHelper));
			}
			if (dto.getAcra() == null) {
				dto.setAcra(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ), fileHelper));
			}
		}

		// 8. Payment
		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tlc.getAppFeeBillRefNo()), false));
		dto.setLicenceFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tlc.getLicenceFeeBillRefNo()), false));
		return dto;

	}

	public static TaLicenceCreationDto buildNewForm(Cache cache, User user, FileHelper fileHelper) {
		TaLicenceCreationDto dto = new TaLicenceCreationDto();

		// 1. Setting KE Declaration Clauses into DTO
		StakeholderRecordDto shrDto = new StakeholderRecordDto();
		TaStakeholderDto tshDto = new TaStakeholderDto();
		List<TaKeDeclarationsDto> clauses = new ArrayList<>();
		for (TaKeClause clause : cache.getTaKeClauses()) {
			clauses.add(TaKeDeclarationsDto.buildClauseOnly(cache, clause));
		}
		tshDto.setTaKeDeclarations(clauses);
		shrDto.setInvolvement(tshDto);
		dto.setTaKeyExecutive(shrDto);

		// 2. Setting UEN from corppass / logged in uin
		dto.setUen(user.getUen());
		dto.setLoggedInUin(user.getLoginId());

		// 3. Setting status
		dto.setStatus(new ListableDto());

		// 4. Setting logged in user as Applicant
		dto.setAppUin(user.getLoginId());

		// 5. Setting documents
		dto.setKeNric(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_KE_NRIC), fileHelper));
		dto.setKeResume(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_KE_RESUME), fileHelper));
		dto.setKeResolution(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_KE_DIR_RESOLUTION), fileHelper));
		dto.setBeoc(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_BEOC), fileHelper));
		dto.setBankStatement(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_BANK), fileHelper));
		dto.setTenancyAgreement(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_TENANCY), fileHelper));
		dto.setHosApproval(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_HOS_APPROVAL), fileHelper));
		dto.setCbs(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_CBS), fileHelper));
		dto.setAfa(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_MGMT_ACC), fileHelper));
		dto.setAcra(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ), fileHelper));

		return dto;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public LocalDate getDraftExpiryDate() {
		return draftExpiryDate;
	}

	public void setDraftExpiryDate(LocalDate draftExpiryDate) {
		this.draftExpiryDate = draftExpiryDate;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppUin() {
		return appUin;
	}

	public void setAppUin(String appUin) {
		this.appUin = appUin;
	}

	public LocalDate getAppDob() {
		return appDob;
	}

	public void setAppDob(LocalDate appDob) {
		this.appDob = appDob;
	}

	public ListableDto getAppSex() {
		return appSex;
	}

	public void setAppSex(ListableDto appSex) {
		this.appSex = appSex;
	}

	public ListableDto getAppNationality() {
		return appNationality;
	}

	public void setAppNationality(ListableDto appNationality) {
		this.appNationality = appNationality;
	}

	public ListableDto getAppDesignation() {
		return appDesignation;
	}

	public void setAppDesignation(ListableDto appDesignation) {
		this.appDesignation = appDesignation;
	}

	public String getAppOtherDesignation() {
		return appOtherDesignation;
	}

	public void setAppOtherDesignation(String appOtherDesignation) {
		this.appOtherDesignation = appOtherDesignation;
	}

	public String getAppOfficeNo() {
		return appOfficeNo;
	}

	public void setAppOfficeNo(String appOfficeNo) {
		this.appOfficeNo = appOfficeNo;
	}

	public String getAppResidentialNo() {
		return appResidentialNo;
	}

	public void setAppResidentialNo(String appResidentialNo) {
		this.appResidentialNo = appResidentialNo;
	}

	public String getAppMobileNo() {
		return appMobileNo;
	}

	public void setAppMobileNo(String appMobileNo) {
		this.appMobileNo = appMobileNo;
	}

	public String getAppFaxNo() {
		return appFaxNo;
	}

	public void setAppFaxNo(String appFaxNo) {
		this.appFaxNo = appFaxNo;
	}

	public String getAppEmailAddress() {
		return appEmailAddress;
	}

	public void setAppEmailAddress(String appEmailAddress) {
		this.appEmailAddress = appEmailAddress;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public ListableDto getApplicationMode() {
		return applicationMode;
	}

	public void setApplicationMode(ListableDto applicationMode) {
		this.applicationMode = applicationMode;
	}

	public ListableDto getLicenceTier() {
		return licenceTier;
	}

	public void setLicenceTier(ListableDto licenceTier) {
		this.licenceTier = licenceTier;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyFormerName() {
		return companyFormerName;
	}

	public void setCompanyFormerName(String companyFormerName) {
		this.companyFormerName = companyFormerName;
	}

	public ListableDto getFormOfBusiness() {
		return formOfBusiness;
	}

	public void setFormOfBusiness(ListableDto formOfBusiness) {
		this.formOfBusiness = formOfBusiness;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public ListableDto getPrincipleActivities() {
		return principleActivities;
	}

	public void setPrincipleActivities(ListableDto principleActivities) {
		this.principleActivities = principleActivities;
	}

	public ListableDto getSecondaryPrincipleActivities() {
		return secondaryPrincipleActivities;
	}

	public void setSecondaryPrincipleActivities(ListableDto secondaryPrincipleActivities) {
		this.secondaryPrincipleActivities = secondaryPrincipleActivities;
	}

	public ListableDto getBusinessConstitution() {
		return businessConstitution;
	}

	public void setBusinessConstitution(ListableDto businessConstitution) {
		this.businessConstitution = businessConstitution;
	}

	public ListableDto getPlaceIncorporated() {
		return placeIncorporated;
	}

	public void setPlaceIncorporated(ListableDto placeIncorporated) {
		this.placeIncorporated = placeIncorporated;
	}

	public ListableDto getEstablishmentStatus() {
		return establishmentStatus;
	}

	public void setEstablishmentStatus(ListableDto establishmentStatus) {
		this.establishmentStatus = establishmentStatus;
	}

	public ListableDto getTaSegmentation() {
		return taSegmentation;
	}

	public void setTaSegmentation(ListableDto taSegmentation) {
		this.taSegmentation = taSegmentation;
	}

	public BigDecimal getPaidUpCapital() {
		return paidUpCapital;
	}

	public void setPaidUpCapital(BigDecimal paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Integer getFyeDay() {
		return fyeDay;
	}

	public void setFyeDay(Integer fyeDay) {
		this.fyeDay = fyeDay;
	}

	public Integer getFyeMonth() {
		return fyeMonth;
	}

	public void setFyeMonth(Integer fyeMonth) {
		this.fyeMonth = fyeMonth;
	}

	public AddressDto getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(AddressDto registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public AddressDto getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(AddressDto operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public BigDecimal getInboundOpPercent() {
		return inboundOpPercent;
	}

	public void setInboundOpPercent(BigDecimal inboundOpPercent) {
		this.inboundOpPercent = inboundOpPercent;
	}

	public BigDecimal getOutboundOpPercent() {
		return outboundOpPercent;
	}

	public void setOutboundOpPercent(BigDecimal outboundOpPercent) {
		this.outboundOpPercent = outboundOpPercent;
	}

	public String getTaBusinessWriteUp() {
		return taBusinessWriteUp;
	}

	public void setTaBusinessWriteUp(String taBusinessWriteUp) {
		this.taBusinessWriteUp = taBusinessWriteUp;
	}

	public String getCurrentBusinessWriteUp() {
		return currentBusinessWriteUp;
	}

	public void setCurrentBusinessWriteUp(String currentBusinessWriteUp) {
		this.currentBusinessWriteUp = currentBusinessWriteUp;
	}

	public StakeholderRecordDto getTaKeyExecutive() {
		return taKeyExecutive;
	}

	public void setTaKeyExecutive(StakeholderRecordDto taKeyExecutive) {
		this.taKeyExecutive = taKeyExecutive;
	}

	public List<TaMarketSpecializationDto> getTaInboundSpecializedMarkets() {
		return taInboundSpecializedMarkets;
	}

	public void setTaInboundSpecializedMarkets(List<TaMarketSpecializationDto> taInboundSpecializedMarkets) {
		this.taInboundSpecializedMarkets = taInboundSpecializedMarkets;
	}

	public List<TaMarketSpecializationDto> getTaOutboundSpecializedMarkets() {
		return taOutboundSpecializedMarkets;
	}

	public void setTaOutboundSpecializedMarkets(List<TaMarketSpecializationDto> taOutboundSpecializedMarkets) {
		this.taOutboundSpecializedMarkets = taOutboundSpecializedMarkets;
	}

	public List<TaBusinessOperationDto> getTaBusinessOperations() {
		return taBusinessOperations;
	}

	public void setTaBusinessOperations(List<TaBusinessOperationDto> taBusinessOperations) {
		this.taBusinessOperations = taBusinessOperations;
	}

	public List<TaAreaOfFocusDto> getTaFocusAreas() {
		return taFocusAreas;
	}

	public void setTaFocusAreas(List<TaAreaOfFocusDto> taFocusAreas) {
		this.taFocusAreas = taFocusAreas;
	}

	public List<StakeholderRecordDto> getTaStakeholders() {
		return taStakeholders;
	}

	public void setTaStakeholders(List<StakeholderRecordDto> taStakeholders) {
		this.taStakeholders = taStakeholders;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getLoggedInUin() {
		return loggedInUin;
	}

	public void setLoggedInUin(String loggedInUin) {
		this.loggedInUin = loggedInUin;
	}

	public Boolean getIsOppAddSameAsRegAdd() {
		return isOppAddSameAsRegAdd;
	}

	public void setIsOppAddSameAsRegAdd(Boolean isOppAddSameAsRegAdd) {
		this.isOppAddSameAsRegAdd = isOppAddSameAsRegAdd;
	}

	public FileDto getKeNric() {
		return keNric;
	}

	public void setKeNric(FileDto keNric) {
		this.keNric = keNric;
	}

	public FileDto getKeResume() {
		return keResume;
	}

	public void setKeResume(FileDto keResume) {
		this.keResume = keResume;
	}

	public FileDto getKeResolution() {
		return keResolution;
	}

	public void setKeResolution(FileDto keResolution) {
		this.keResolution = keResolution;
	}

	public FileDto getBeoc() {
		return beoc;
	}

	public void setBeoc(FileDto beoc) {
		this.beoc = beoc;
	}

	public FileDto getBankStatement() {
		return bankStatement;
	}

	public void setBankStatement(FileDto bankStatement) {
		this.bankStatement = bankStatement;
	}

	public FileDto getTenancyAgreement() {
		return tenancyAgreement;
	}

	public void setTenancyAgreement(FileDto tenancyAgreement) {
		this.tenancyAgreement = tenancyAgreement;
	}

	public FileDto getHosApproval() {
		return hosApproval;
	}

	public void setHosApproval(FileDto hosApproval) {
		this.hosApproval = hosApproval;
	}

	public FileDto getCbs() {
		return cbs;
	}

	public void setCbs(FileDto cbs) {
		this.cbs = cbs;
	}

	public FileDto getAcra() {
		return acra;
	}

	public void setAcra(FileDto acra) {
		this.acra = acra;
	}

	public FileDto getAfa() {
		return afa;
	}

	public void setAfa(FileDto afa) {
		this.afa = afa;
	}

	public List<FileDto> getOtherDocuments() {
		return otherDocuments;
	}

	public void setOtherDocuments(List<FileDto> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

	public LocalDateTime getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(LocalDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String[] getAppEditableFields() {
		return appEditableFields;
	}

	public void setAppEditableFields(String[] appEditableFields) {
		this.appEditableFields = appEditableFields;
	}

	public Boolean getIsAppMyInfo() {
		return isAppMyInfo;
	}

	public void setIsAppMyInfo(Boolean isAppMyInfo) {
		this.isAppMyInfo = isAppMyInfo;
	}

	public Boolean getIsKeMyInfo() {
		return isKeMyInfo;
	}

	public void setIsKeMyInfo(Boolean isKeMyInfo) {
		this.isKeMyInfo = isKeMyInfo;
	}

	public String[] getKeEditableFields() {
		return keEditableFields;
	}

	public void setKeEditableFields(String[] keEditableFields) {
		this.keEditableFields = keEditableFields;
	}

	public Boolean getIsAppMyInfoClicked() {
		return isAppMyInfoClicked;
	}

	public void setIsAppMyInfoClicked(Boolean isAppMyInfoClicked) {
		this.isAppMyInfoClicked = isAppMyInfoClicked;
	}

	public Boolean getIsKeMyInfoClicked() {
		return isKeMyInfoClicked;
	}

	public void setIsKeMyInfoClicked(Boolean isKeMyInfoClicked) {
		this.isKeMyInfoClicked = isKeMyInfoClicked;
	}

	public PaymentRequestDto getAppFee() {
		return appFee;
	}

	public void setAppFee(PaymentRequestDto appFee) {
		this.appFee = appFee;
	}

	public PaymentRequestDto getLicenceFee() {
		return licenceFee;
	}

	public void setLicenceFee(PaymentRequestDto licenceFee) {
		this.licenceFee = licenceFee;
	}

	public Boolean getIsEdhPopulated() {
		return isEdhPopulated;
	}

	public void setIsEdhPopulated(Boolean isEdhPopulated) {
		this.isEdhPopulated = isEdhPopulated;
	}

	public Boolean getIsActiveLicencee() {
		return isActiveLicencee;
	}

	public void setIsActiveLicencee(Boolean isActiveLicencee) {
		this.isActiveLicencee = isActiveLicencee;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	public void setIsFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public boolean getIsInLowestStep() {
		return isInLowestStep;
	}

	public void setIsInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getBusinessIdea() {
		return businessIdea;
	}

	public void setBusinessIdea(String businessIdea) {
		this.businessIdea = businessIdea;
	}

	public String getConsumerFacingBrand() {
		return consumerFacingBrand;
	}

	public void setConsumerFacingBrand(String consumerFacingBrand) {
		this.consumerFacingBrand = consumerFacingBrand;
	}

	public String getMktgCommsPlan() {
		return mktgCommsPlan;
	}

	public void setMktgCommsPlan(String mktgCommsPlan) {
		this.mktgCommsPlan = mktgCommsPlan;
	}

	public String getOtherSalesChannel() {
		return otherSalesChannel;
	}

	public void setOtherSalesChannel(String otherSalesChannel) {
		this.otherSalesChannel = otherSalesChannel;
	}

	public String getFinancialStrategy() {
		return financialStrategy;
	}

	public void setFinancialStrategy(String financialStrategy) {
		this.financialStrategy = financialStrategy;
	}

	public BigDecimal getRevenueProj1() {
		return revenueProj1;
	}

	public void setRevenueProj1(BigDecimal revenueProj1) {
		this.revenueProj1 = revenueProj1;
	}

	public BigDecimal getRevenueProj2() {
		return revenueProj2;
	}

	public void setRevenueProj2(BigDecimal revenueProj2) {
		this.revenueProj2 = revenueProj2;
	}

	public BigDecimal getCostProj1() {
		return costProj1;
	}

	public void setCostProj1(BigDecimal costProj1) {
		this.costProj1 = costProj1;
	}

	public BigDecimal getCostProj2() {
		return costProj2;
	}

	public void setCostProj2(BigDecimal costProj2) {
		this.costProj2 = costProj2;
	}

	public BigDecimal getProfitLossProj1() {
		return profitLossProj1;
	}

	public void setProfitLossProj1(BigDecimal profitLossProj1) {
		this.profitLossProj1 = profitLossProj1;
	}

	public BigDecimal getProfitLossProj2() {
		return profitLossProj2;
	}

	public void setProfitLossProj2(BigDecimal profitLossProj2) {
		this.profitLossProj2 = profitLossProj2;
	}

	public String getEstTimeToProfit() {
		return estTimeToProfit;
	}

	public void setEstTimeToProfit(String estTimeToProfit) {
		this.estTimeToProfit = estTimeToProfit;
	}

	public String getCompetitiveEdge() {
		return competitiveEdge;
	}

	public void setCompetitiveEdge(String competitiveEdge) {
		this.competitiveEdge = competitiveEdge;
	}

	public String getPartnerServideProviders() {
		return partnerServideProviders;
	}

	public void setPartnerServideProviders(String partnerServideProviders) {
		this.partnerServideProviders = partnerServideProviders;
	}

	public Boolean getHasOtherBizActivities() {
		return hasOtherBizActivities;
	}

	public void setHasOtherBizActivities(Boolean hasOtherBizActivities) {
		this.hasOtherBizActivities = hasOtherBizActivities;
	}

	public BigDecimal getPercentFocusOnTaBiz() {
		return percentFocusOnTaBiz;
	}

	public void setPercentFocusOnTaBiz(BigDecimal percentFocusOnTaBiz) {
		this.percentFocusOnTaBiz = percentFocusOnTaBiz;
	}

	public Boolean getHasTaLicBefore() {
		return hasTaLicBefore;
	}

	public void setHasTaLicBefore(Boolean hasTaLicBefore) {
		this.hasTaLicBefore = hasTaLicBefore;
	}

	public String getDetailsRegardingPrevLic() {
		return detailsRegardingPrevLic;
	}

	public void setDetailsRegardingPrevLic(String detailsRegardingPrevLic) {
		this.detailsRegardingPrevLic = detailsRegardingPrevLic;
	}

	public String getRelationsWithOtherTa() {
		return relationsWithOtherTa;
	}

	public void setRelationsWithOtherTa(String relationsWithOtherTa) {
		this.relationsWithOtherTa = relationsWithOtherTa;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public void setFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public void setInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

	public String[] getSalesChannelSelected() {
		return salesChannelSelected;
	}

	public void setSalesChannelSelected(String[] salesChannelSelected) {
		this.salesChannelSelected = salesChannelSelected;
	}

	public List<String> getSalesChannelSelectedLabels() {
		return salesChannelSelectedLabels;
	}

	public void setSalesChannelSelectedLabels(List<String> salesChannelSelectedLabels) {
		this.salesChannelSelectedLabels = salesChannelSelectedLabels;
	}

}
