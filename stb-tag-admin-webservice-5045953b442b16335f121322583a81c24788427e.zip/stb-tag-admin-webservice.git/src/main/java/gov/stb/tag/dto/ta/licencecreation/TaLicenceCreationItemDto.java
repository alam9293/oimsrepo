package gov.stb.tag.dto.ta.licencecreation;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaLicenceCreation;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceCreationItemDto {

	@MapProjection(path = "application.id")
	private Integer applicationId;

	@MapProjection(path = "application.applicationNo")
	private String applicationNo;

	@MapProjection(path = "application.submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "companyName")
	private String name;

	@MapProjection(path = "uen")
	private String uen;

	@MapProjection(path = "application.lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "application.lastAction.status.label")
	private String status;

	@MapProjection(path = "application.assignee.name")
	private String assignedOfficer;

	@MapProjection(path = "applicationMode.label")
	private String mode;

	@MapProjection(path = "licenceTier.label")
	private String tier;

	public static TaLicenceCreationItemDto buildFromApplication(Cache cache, TaLicenceCreation tlc) {
		TaLicenceCreationItemDto dto = new TaLicenceCreationItemDto();
		dto.setApplicationId(tlc.getApplication().getId());
		dto.setApplicationNo(tlc.getApplication().getApplicationNo());
		dto.setSubmissionDate(tlc.getApplication().getSubmissionDate());
		dto.setName(tlc.getCompanyName());
		dto.setUen(tlc.getUen());
		dto.setStatus(tlc.getApplication().getLastAction().getStatus().getCode());
		dto.setMode(cache.getLabel(tlc.getApplicationMode(), false));
		dto.setTier(cache.getLabel(tlc.getLicenceTier(), false));

		return dto;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
