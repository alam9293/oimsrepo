package gov.stb.tag.dto.ta.licencemanageke;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;

import gov.stb.tag.model.Type;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceKeCompareDetails {

	private String fieldCode;

	private String fieldName;

	private String newValue;

	private String currentValue;

	private String className;

	public TaLicenceKeCompareDetails(String fieldName, Type newValue, Type currentValue) {
		this.fieldName = fieldName;
		this.newValue = newValue == null ? "" : newValue.getLabel();
		this.currentValue = currentValue == null ? "" : currentValue.getLabel();
		setRowClass();
	}

	public TaLicenceKeCompareDetails(String fieldName, String newValue, String currentValue) {
		this.fieldName = fieldName;
		this.newValue = newValue;
		this.currentValue = currentValue;
		if (Strings.isNullOrEmpty(newValue)) {
			this.newValue = "";
		}
		if (Strings.isNullOrEmpty(currentValue)) {
			this.currentValue = "";
		}
		setRowClass();

	}

	private void setRowClass() {
		if (this.newValue.equalsIgnoreCase(this.currentValue)) {
			this.className = "";
		} else {
			this.className = "blue";
		}
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public String getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(String currentValue) {
		this.currentValue = currentValue;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

}
