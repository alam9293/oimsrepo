package gov.stb.tag.dto.ta.licencemanageke;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.dto.ta.stakeholder.StakeholderDto;
import gov.stb.tag.dto.ta.stakeholder.TaKeDeclarationsDto;
import gov.stb.tag.dto.ta.stakeholder.TaStakeholderDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaKeDeclaration;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceKeDetailsDto extends TaApplicationDto {

	@MapProjection(path = "id")
	private Integer taKeAppId;

	@MapProjection(path = "application.type.code")
	private String keAppType;

	@MapProjection(path = "application.type.label")
	private String keAppTypeLabel; // assign, update, resign (for resign, no need fill the below)

	/* TA have KE now? */
	private Boolean haveKe = Boolean.TRUE;

	/* Applicant is KE? */
	private Boolean applicantIsKe;

	/* KE declaration need to be completed? */
	private Boolean needCompleteDeclaration;

	/* Applicant data from myInfo Yes = true */
	private Boolean isMyInfoPopulated;

	/* Require NRIC doc? Mainly for update KE check if Name/ DOB/ Address/ Gender change */
	private Boolean nricRequired = false;

	// For current KE personel details
	private StakeholderDto stakeholderDto;

	// For current KE Ta stakeholder details + declaration
	private TaStakeholderDto taKeStakeholder;

	// For other roles of current KE
	private List<TaStakeholderDto> taStakeholders = new ArrayList<TaStakeholderDto>();

	// For intranet application view to compare before & after values
	private List<TaLicenceKeCompareDetails> compareDetailsDto;

	private List<FileDto> files = new ArrayList<FileDto>(); // required doc or optional: other doc

	private List<Integer> toDeleteFiles = new ArrayList<Integer>();

	// previous value
	private StakeholderDto prevValueStakeholderDto;

	/***** Mainly For assign KE application *****/
	// New KE to be assign
	private StakeholderDto newStakeholderDto;

	private TaStakeholderDto newTaStakeholderDto = new TaStakeholderDto();

	// New KE's ta stakeholder + declare
	private List<TaKeDeclarationsDto> taKeDeclarations;

	/**************** END *****************/

	public static TaLicenceKeDetailsDto buildAppDtoFromTaStakeholderAppModel(Cache cache, ApplicationHelper appHelper, TaStakeholderApplication app, TaLicenceKeDetailsDto dto,
			List<TaStakeholder> taStakeholders, TaStakeholder newTake) {
		if (app.getId() != null) {
			dto.setTaKeAppId(app.getId());
			dto.setKeAppType(app.getApplication().getType().getCode());
			dto.setKeAppTypeLabel(app.getApplication().getType().getLabel());
			dto.setIsMyInfoPopulated(app.isMyInfoPopulated());
		}

		if (app.getApplication() != null) {
			dto = dto.buildFromApplication(cache, appHelper, app.getApplication(), dto);
		}

		Stakeholder currentKe = new Stakeholder();

		if (app.getTaStakeholder() != null) {
			currentKe = app.getTaStakeholder().getStakeholder();
			StakeholderDto stakeholderDto = new StakeholderDto();
			stakeholderDto.setStakeholderId(currentKe.getId());
			stakeholderDto.setAddress(AddressDto.buildFromAddress(cache, currentKe.getAddress()));
			stakeholderDto.setContactNo(currentKe.getContactNo());

			stakeholderDto.setOfficeNo(currentKe.getOfficeNo());
			stakeholderDto.setResidentialNo(currentKe.getResidentialNo());

			stakeholderDto.setDob(currentKe.getDob());
			stakeholderDto.setEmail(currentKe.getEmail());
			stakeholderDto
					.setHighestEduLevel(currentKe.getHighestEduLevel() != null ? new ListableDto(currentKe.getHighestEduLevel().getKey(), cache.getLabel(currentKe.getHighestEduLevel(), Boolean.FALSE))
							: new ListableDto());
			stakeholderDto.setStakeholderName(currentKe.getName());
			stakeholderDto.setNationality(
					currentKe.getNationality() != null ? new ListableDto(currentKe.getNationality().getKey(), cache.getLabel(currentKe.getNationality(), Boolean.FALSE)) : new ListableDto());
			stakeholderDto.setSex(currentKe.getSex() != null ? new ListableDto(currentKe.getSex().getKey(), cache.getLabel(currentKe.getSex(), Boolean.FALSE)) : new ListableDto());
			stakeholderDto.setUin(currentKe.getUin());
			stakeholderDto.setDesignation(
					currentKe.getDesignation() != null ? new ListableDto(currentKe.getDesignation().getKey(), cache.getLabel(currentKe.getDesignation(), Boolean.FALSE)) : new ListableDto());
			stakeholderDto.setOtherDesignation(currentKe.getOtherDesignation());
			stakeholderDto.setScpr();

			dto.setStakeholderDto(stakeholderDto);
			dto.setTaKeStakeholder(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, app.getTaStakeholder(), Boolean.FALSE, Boolean.FALSE));
		} else {
			dto.setHaveKe(Boolean.FALSE);
		}

		if (taStakeholders != null) {
			for (TaStakeholder row : taStakeholders) {
				if (!Codes.TaStakeholderRoles.STKHLD_KE.equalsIgnoreCase(row.getRole().getCode())) {
					dto.getTaStakeholders().add(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, row, Boolean.FALSE, Boolean.FALSE));
				}
			}
		}

		if (!Codes.ApplicationTypes.TA_APP_KE_RESIGN.equalsIgnoreCase(app.getType().getCode())) {
			StakeholderDto newKe = new StakeholderDto();
			newKe.setAddress(AddressDto.buildFromAddress(cache, app.getAddress()));
			newKe.setContactNo(app.getContactNo());

			newKe.setOfficeNo(app.getOfficeNo());
			newKe.setResidentialNo(app.getResidentialNo());

			newKe.setDob(app.getDob());
			newKe.setEmail(app.getEmail());
			if (app.getHighestEduLevel() != null) {
				newKe.setHighestEduLevel(new ListableDto(app.getHighestEduLevel().getKey(), cache.getLabel(app.getHighestEduLevel(), Boolean.FALSE)));
			}
			newKe.setStakeholderName(app.getName());
			if (app.getNationality() != null) {
				newKe.setNationality(new ListableDto(app.getNationality().getKey(), cache.getLabel(app.getNationality(), Boolean.FALSE)));
			}
			if (app.getSex() != null) {
				newKe.setSex(new ListableDto(app.getSex().getKey(), cache.getLabel(app.getSex(), Boolean.FALSE)));
			}
			newKe.setUin(app.getUin());
			if (app.getDesignation() != null) {
				newKe.setDesignation(new ListableDto(app.getDesignation().getKey(), cache.getLabel(app.getDesignation(), Boolean.FALSE)));
			}
			newKe.setOtherDesignation(app.getOtherDesignation());
			newKe.setScpr();

			dto.setNewStakeholderDto(newKe);
			dto.setNewTaStakeholderDto(new TaStakeholderDto());
			dto.getNewTaStakeholderDto().setAppointedDate(app.getAppointedDate());

			if (Codes.ApplicationTypes.TA_APP_KE_ASSIGN.equalsIgnoreCase(app.getType().getCode()) || Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(app.getType().getCode())) {
				List<TaKeDeclarationsDto> declarations = new ArrayList<>();
				for (TaKeDeclaration x : app.getTaKeDeclarations()) {
					declarations.add(TaKeDeclarationsDto.build(cache, x));
				}
				declarations.sort(Comparator.comparingInt(TaKeDeclarationsDto::getOrdinal));
				dto.setTaKeDeclarations(declarations);
			}

		}

		// if (newTake != null) {
		// dto.getNewTaStakeholderDto().setResignedDate(newTake.getResignedDate());
		// dto.getNewTaStakeholderDto().setAppointedDate(newTake.getAppointedDate());
		// }

		if (Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS.equalsIgnoreCase(app.getType().getCode()) && !Codes.Statuses.TA_APP_NEW.equalsIgnoreCase(dto.getApplicationStatus().getKey().toString())
				&& app.getPreviousValue() != null) {
			dto.setPrevValueStakeholderDto(retrieveSnapshotIntoDto(app.getPreviousValue(), cache, new StakeholderDto()));
			if (!(app.getName().toUpperCase().equalsIgnoreCase(app.getPreviousValue().getName().toUpperCase()) || app.getSex().equals(app.getPreviousValue().getSex())
					|| app.getAddress().getPostal().equalsIgnoreCase(app.getPreviousValue().getAddress().getPostal())
					|| app.getAddress().getBlock().equalsIgnoreCase(app.getPreviousValue().getAddress().getBlock())
					|| app.getAddress().getStreet().equalsIgnoreCase(app.getPreviousValue().getAddress().getStreet())
					|| app.getAddress().getBuilding().equalsIgnoreCase(app.getPreviousValue().getAddress().getStreet())
					|| app.getAddress().getFloor().equalsIgnoreCase(app.getPreviousValue().getAddress().getFloor())
					|| app.getAddress().getUnit().equalsIgnoreCase(app.getPreviousValue().getAddress().getUnit()))) {

			} else {
				dto.setNricRequired(Boolean.TRUE);
			}
		}

		if (Codes.ApplicationTypes.TA_APP_KE_RESIGN.equalsIgnoreCase(app.getType().getCode()) || Codes.ApplicationTypes.TA_APP_KE_REASSIGN.equalsIgnoreCase(app.getType().getCode())) {
			if (app.getResignedDate() == null) {
				dto.getTaKeStakeholder().setResignedDate(LocalDate.now());
			} else {
				dto.getTaKeStakeholder().setResignedDate(app.getResignedDate());
			}

		}

		return dto;
	}

	public static StakeholderDto retrieveSnapshotIntoDto(TaStakeholderApplication prevValue, Cache cache, StakeholderDto shDto) {
		shDto = new StakeholderDto(cache, prevValue);
		shDto.setAddress(AddressDto.buildFromAddress(cache, prevValue.getAddress()));
		return shDto;
	}

	public static TaLicenceKeDetailsDto buildNewAppDtoFromCurrentStakeholderModel(Cache cache, Stakeholder stakeholder, TaLicenceKeDetailsDto dto, String appType, String appStatus) {
		dto.setKeAppType(cache.getType(appType).getCode());
		dto.setKeAppTypeLabel(cache.getType(appType).getLabel());
		dto.setApplicationStatus(new ListableDto(appStatus, cache.getStatus(appStatus).getLabel(), cache.getStatus(appStatus).getOtherLabel(), null, null));

		if (stakeholder != null) {
			if (dto.getKeAppType().equalsIgnoreCase(Codes.ApplicationTypes.TA_APP_KE_UPD_DETAILS)) {
				// Set into new stakeholder so user can edit stake holder detail in newStakeholderDTO
				dto.setNewStakeholderDto(new StakeholderDto(cache, stakeholder));
			}
			// Set into current stakeholder details to show user the current stakeholder details to user. This stakholder DTO will not be edited in front end
			dto.setStakeholderDto(new StakeholderDto(cache, stakeholder));

			if (!stakeholder.getTaStakeholders().isEmpty()) {
				for (TaStakeholder row : stakeholder.getTaStakeholders()) {
					if (Codes.TaStakeholderRoles.STKHLD_KE.equalsIgnoreCase(row.getRole().getCode())) {
						dto.setTaKeStakeholder(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, row, Boolean.TRUE, Boolean.TRUE));
					} else {
						dto.taStakeholders.add(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, row, Boolean.FALSE, Boolean.FALSE));
					}

				}
			}
		}

		return dto;
	}

	public Integer getTaKeAppId() {
		return taKeAppId;
	}

	public void setTaKeAppId(Integer taKeAppId) {
		this.taKeAppId = taKeAppId;
	}

	public String getKeAppType() {
		return keAppType;
	}

	public void setKeAppType(String keAppType) {
		this.keAppType = keAppType;
	}

	public String getKeAppTypeLabel() {
		return keAppTypeLabel;
	}

	public void setKeAppTypeLabel(String keAppTypeLabel) {
		this.keAppTypeLabel = keAppTypeLabel;
	}

	public StakeholderDto getStakeholderDto() {
		return stakeholderDto;
	}

	public void setStakeholderDto(StakeholderDto stakeholderDto) {
		this.stakeholderDto = stakeholderDto;
	}

	public List<TaStakeholderDto> getTaStakeholders() {
		return taStakeholders;
	}

	public void setTaStakeholders(List<TaStakeholderDto> taStakeholders) {
		this.taStakeholders = taStakeholders;
	}

	public TaStakeholderDto getTaKeStakeholder() {
		return taKeStakeholder;
	}

	public void setTaKeStakeholder(TaStakeholderDto taKeStakeholder) {
		this.taKeStakeholder = taKeStakeholder;
	}

	public List<TaLicenceKeCompareDetails> getCompareDetailsDto() {
		return compareDetailsDto;
	}

	public void setCompareDetailsDto(List<TaLicenceKeCompareDetails> compareDetailsDto) {
		this.compareDetailsDto = compareDetailsDto;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public List<Integer> getToDeleteFiles() {
		return toDeleteFiles;
	}

	public void setToDeleteFiles(List<Integer> toDeleteFiles) {
		this.toDeleteFiles = toDeleteFiles;
	}

	public StakeholderDto getNewStakeholderDto() {
		return newStakeholderDto;
	}

	public void setNewStakeholderDto(StakeholderDto newStakeholderDto) {
		this.newStakeholderDto = newStakeholderDto;
	}

	public Boolean getHaveKe() {
		return haveKe;
	}

	public void setHaveKe(Boolean haveKe) {
		this.haveKe = haveKe;
	}

	public List<TaKeDeclarationsDto> getTaKeDeclarations() {
		return taKeDeclarations;
	}

	public void setTaKeDeclarations(List<TaKeDeclarationsDto> taKeDeclarations) {
		this.taKeDeclarations = taKeDeclarations;
	}

	public Boolean getApplicantIsKe() {
		return applicantIsKe;
	}

	public void setApplicantIsKe(Boolean applicantIsKe) {
		this.applicantIsKe = applicantIsKe;
	}

	public Boolean getIsMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	public Boolean getNeedCompleteDeclaration() {
		return needCompleteDeclaration;
	}

	public void setNeedCompleteDeclaration(Boolean needCompleteDeclaration) {
		this.needCompleteDeclaration = needCompleteDeclaration;
	}

	public TaStakeholderDto getNewTaStakeholderDto() {
		return newTaStakeholderDto;
	}

	public void setNewTaStakeholderDto(TaStakeholderDto newTaStakeholderDto) {
		this.newTaStakeholderDto = newTaStakeholderDto;
	}

	public Boolean getNricRequired() {
		return nricRequired;
	}

	public void setNricRequired(Boolean nricRequired) {
		this.nricRequired = nricRequired;
	}

	public StakeholderDto getPrevValueStakeholderDto() {
		return prevValueStakeholderDto;
	}

	public void setPrevValueStakeholderDto(StakeholderDto prevValueStakeholderDto) {
		this.prevValueStakeholderDto = prevValueStakeholderDto;
	}

}
