package gov.stb.tag.dto.ta.licencemanageke;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceKeSearchDto extends TaApplicationSearchDto {

	private String appType;

	public String getAppType() {
		return appType;
	}

	public void setAppType(String appType) {
		this.appType = appType;
	}

}
