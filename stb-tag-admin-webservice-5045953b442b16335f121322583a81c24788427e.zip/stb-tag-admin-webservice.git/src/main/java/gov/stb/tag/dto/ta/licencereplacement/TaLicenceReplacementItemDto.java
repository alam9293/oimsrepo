package gov.stb.tag.dto.ta.licencereplacement;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ta.application.TaApplicationItemDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaLicenceReplacementItemDto extends TaApplicationItemDto {

	public TaLicenceReplacementItemDto() {

	}

}
