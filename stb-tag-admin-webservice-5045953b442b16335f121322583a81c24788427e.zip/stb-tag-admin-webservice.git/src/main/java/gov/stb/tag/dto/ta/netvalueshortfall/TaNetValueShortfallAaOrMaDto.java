package gov.stb.tag.dto.ta.netvalueshortfall;

import java.math.BigDecimal;
import java.time.LocalDate;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaMaSubmission;

public class TaNetValueShortfallAaOrMaDto {

	private Integer applicationId;
	private String applicationNo;
	private BigDecimal totalAssets;
	private BigDecimal totalLiabilities;
	private BigDecimal capital;
	private BigDecimal netvalue;
	private BigDecimal shortfall;
	private ListableDto type;
	private LocalDate fyEndDate;
	private Integer fy;

	public static TaNetValueShortfallAaOrMaDto buildFromAaOrMa(Cache cache, TaAaSubmission aa, TaMaSubmission ma) {
		if (aa != null) {
			TaNetValueShortfallAaOrMaDto dto = new TaNetValueShortfallAaOrMaDto();
			dto.setApplicationId(aa.getApplication().getId());
			dto.setApplicationNo(aa.getApplication().getApplicationNo());
			dto.setTotalAssets(aa.getTotalAssets());
			dto.setTotalLiabilities(aa.getTotalLiabilities());
			dto.setCapital(aa.getCapital());
			dto.setNetvalue(aa.getNetValue());
			dto.setShortfall(aa.getShortfall());
			dto.setType(new ListableDto(cache.getType(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION)));
			dto.setFyEndDate(aa.getTaAnnualFiling().getFyEndDate());
			dto.setFy(aa.getTaAnnualFiling().getFy());
			return dto;
		} else if (ma != null) {
			TaNetValueShortfallAaOrMaDto dto = new TaNetValueShortfallAaOrMaDto();
			dto.setApplicationId(ma.getApplication().getId());
			dto.setApplicationNo(ma.getApplication().getApplicationNo());
			dto.setTotalAssets(ma.getTotalAssets());
			dto.setTotalLiabilities(ma.getTotalLiabilities());
			dto.setCapital(ma.getPaidUpCapital());
			dto.setNetvalue(ma.getNetValue());
			dto.setShortfall(ma.getShortfall());
			dto.setType(new ListableDto(cache.getType(Codes.ApplicationTypes.TA_APP_MA_SUBMISSION)));
			dto.setFyEndDate(ma.getAsAtDate());
			dto.setFy(ma.getTaFilingCondition().getFy());
			return dto;
		} else {
			return null;
		}
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public BigDecimal getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(BigDecimal totalAssets) {
		this.totalAssets = totalAssets;
	}

	public BigDecimal getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(BigDecimal totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getNetvalue() {
		return netvalue;
	}

	public void setNetvalue(BigDecimal netvalue) {
		this.netvalue = netvalue;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public ListableDto getType() {
		return type;
	}

	public void setType(ListableDto type) {
		this.type = type;
	}

	public LocalDate getFyEndDate() {
		return fyEndDate;
	}

	public void setFyEndDate(LocalDate fyEndDate) {
		this.fyEndDate = fyEndDate;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

}
