package gov.stb.tag.dto.ta.netvalueshortfall;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.AttachmentDto;

public class TaNetValueShortfallApprovalDto extends ApprovalDto {

	private Integer id;
	private LocalDate dueDate;
	private BigDecimal amount;
	private String shortfallTypeCode;
	private String remarks;
	private String recommendationCode;
	private LocalDate letterIssuedDate;
	private LocalDate extendedDueDate;
	private List<AttachmentDto> workflowFiles;
	private List<Integer> deletedWorkflowFileIds;
	private String letterContent;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public String getShortfallTypeCode() {
		return shortfallTypeCode;
	}

	public void setShortfallTypeCode(String shortfallTypeCode) {
		this.shortfallTypeCode = shortfallTypeCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String getRecommendationCode() {
		return recommendationCode;
	}

	@Override
	public void setRecommendationCode(String recommendationCode) {
		this.recommendationCode = recommendationCode;
	}

	public LocalDate getLetterIssuedDate() {
		return letterIssuedDate;
	}

	public void setLetterIssuedDate(LocalDate letterIssuedDate) {
		this.letterIssuedDate = letterIssuedDate;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

	public List<AttachmentDto> getWorkflowFiles() {
		return workflowFiles;
	}

	public void setWorkflowFiles(List<AttachmentDto> workflowFiles) {
		this.workflowFiles = workflowFiles;
	}

	public List<Integer> getDeletedWorkflowFileIds() {
		return deletedWorkflowFileIds;
	}

	public void setDeletedWorkflowFileIds(List<Integer> deletedWorkflowFileIds) {
		this.deletedWorkflowFileIds = deletedWorkflowFileIds;
	}

	public String getLetterContent() { return letterContent; }

	public void setLetterContent(String letterContent) { this.letterContent = letterContent; }
}
