package gov.stb.tag.dto.ta.netvalueshortfall;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.workflow.WorkflowDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.ta.TaRenewalRepository;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaNetValueShortfallItemDto extends WorkflowDto {

	private Integer id;
	private String shortfallFor;
	private BigDecimal amount;
	private LocalDateTime createdDate;
	private LocalDate dueDate;
	private LocalDate extendedDueDate;
	private String statusCode;
	private String statusLabel;
	private LocalDateTime approvedDate;
	private LocalDate letterIssuedDate;
	private String shortfallTypeCode;
	private String shortfallTypeLabel;
	private String remarks;

	private Integer rectificationAppId;
	private String rectificationStatus;
	private LocalDate rectifiedDate;

	private Boolean disabledEdit;
	private Boolean isDueDateDerived;
	private Boolean enableExtension;

	public static TaNetValueShortfallItemDto buildFromNetValueShortfall(Cache cache, WorkflowHelper workflowHelper, ApplicationHelper appHelper, TaNetValueShortfall shortfall,
			TaRenewalRepository taRenewalRepository) {
		TaNetValueShortfallItemDto dto = new TaNetValueShortfallItemDto();
		dto = dto.buildFromWorkflow(cache, shortfall.getWorkflow(), dto, workflowHelper);
		dto.setId(shortfall.getId());
		dto.setAmount(shortfall.getAmount());
		dto.setDueDate(calculateShortfallProjectedDuedate(cache, shortfall.getRectificationDueDate(), dto.getLicenceId(), taRenewalRepository));
		dto.setExtendedDueDate(shortfall.getExtendedDueDate());
		dto.setIsDueDateDerived(shortfall.getRectificationDueDate() == null);
		dto.setShortfallFor(cache.getType(shortfall.determineShortfallFor()).getLabel());
		dto.setStatusCode(shortfall.getWorkflow().getLastAction().getStatus().getCode());
		dto.setStatusLabel(cache.getLabel(shortfall.getWorkflow().getLastAction().getStatus(), Boolean.FALSE));
		dto.setCreatedDate(shortfall.getCreatedDate());
		dto.setLetterIssuedDate(shortfall.getLetterIssuedDate());
		dto.setShortfallTypeCode(shortfall.getType().getCode());
		dto.setShortfallTypeLabel(cache.getLabel(shortfall.getType(), false));
		dto.setRemarks(shortfall.getRemarks());

		if (workflowHelper.hasFinalApproved(shortfall.getWorkflow())) {
			for (WorkflowAction action : shortfall.getWorkflow().getWorkflowActions()) {
				if (action.getType().getCode().equals(Codes.WorkflowActionTypes.APPROVE)) {
					// get latest approved date
					dto.setApprovedDate(
							dto.getApprovedDate() == null ? action.getCreatedDate() : (action.getCreatedDate().isAfter(dto.getApprovedDate()) ? action.getCreatedDate() : dto.getApprovedDate()));
				}
			}
		}

		TaNetValueRectification rect = shortfall.getTaNetValueRectification();
		dto.setRectificationStatus(shortfall.deriveRectificationStatus());
		if (rect != null) {
			dto.setRectificationAppId(rect.getApplication().getId());
			if (appHelper.hasFinalApproved(rect.getApplication())) {
				dto.setRectifiedDate(rect.getRectifiedDate());
			}
		}
		if (workflowHelper.hasFinalApprovedOrRejected(shortfall.getWorkflow())) {
			dto.setDisabledEdit(Boolean.TRUE);
			dto.setEnableExtension(Boolean.TRUE);
		} else {
			dto.setDisabledEdit(Boolean.FALSE);
			dto.setEnableExtension(Boolean.FALSE);
		}

		// disable extension if shortfall is fulfiled
		if (dto.getRectificationStatus().equalsIgnoreCase(Codes.Constants.YES)) {
			dto.setEnableExtension(Boolean.FALSE);
		}
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getShortfallFor() {
		return shortfallFor;
	}

	public void setShortfallFor(String shortfallFor) {
		this.shortfallFor = shortfallFor;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusLabel() {
		return statusLabel;
	}

	public void setStatusLabel(String statusLabel) {
		this.statusLabel = statusLabel;
	}

	@Override
	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	@Override
	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

	public LocalDate getLetterIssuedDate() {
		return letterIssuedDate;
	}

	public void setLetterIssuedDate(LocalDate letterIssuedDate) {
		this.letterIssuedDate = letterIssuedDate;
	}

	public String getShortfallTypeCode() {
		return shortfallTypeCode;
	}

	public void setShortfallTypeCode(String shortfallTypeCode) {
		this.shortfallTypeCode = shortfallTypeCode;
	}

	public String getShortfallTypeLabel() {
		return shortfallTypeLabel;
	}

	public void setShortfallTypeLabel(String shortfallTypeLabel) {
		this.shortfallTypeLabel = shortfallTypeLabel;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getRectificationAppId() {
		return rectificationAppId;
	}

	public void setRectificationAppId(Integer rectificationAppId) {
		this.rectificationAppId = rectificationAppId;
	}

	public String getRectificationStatus() {
		return rectificationStatus;
	}

	public void setRectificationStatus(String rectificationStatus) {
		this.rectificationStatus = rectificationStatus;
	}

	public LocalDate getRectifiedDate() {
		return rectifiedDate;
	}

	public void setRectifiedDate(LocalDate rectifiedDate) {
		this.rectifiedDate = rectifiedDate;
	}

	public Boolean getDisabledEdit() {
		return disabledEdit;
	}

	public void setDisabledEdit(Boolean disabledEdit) {
		this.disabledEdit = disabledEdit;
	}

	public Boolean getIsDueDateDerived() {
		return isDueDateDerived;
	}

	public void setIsDueDateDerived(Boolean isDueDateDerived) {
		this.isDueDateDerived = isDueDateDerived;
	}

	public Boolean getEnableExtension() {
		return enableExtension;
	}

	public void setEnableExtension(Boolean enableExtension) {
		this.enableExtension = enableExtension;
	}

	public static LocalDate calculateShortfallProjectedDuedate(Cache cache, LocalDate dueDate, Integer licId, TaRenewalRepository taRenewalRepository) {

		LocalDate output = null;
		LocalDate defaultDate = LocalDate.now().plusDays(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_SHORTFALL_DEFAULT_NO_OF_DAYS).getValue()));
		String monthDay = cache.getSystemParameter(Codes.SystemParameters.TA_SHORTFALL_MAX_SUBMISSION_DATE_MONTH_DAY).getValue();
		String[] monthDayArray = monthDay.split(",");
		Integer month = Integer.parseInt(monthDayArray[0]);
		Integer day = Integer.parseInt(monthDayArray[1]);
		LocalDate maxDate = LocalDate.of(Calendar.getInstance().get(Calendar.YEAR), month, day);
		Integer daysDiffer = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_SHORTFALL_SUBMISSION_DATE_DIFFER).getValue());

		if (dueDate == null) {

			if (taRenewalRepository.getTaLicenceRenewalExerciseTaForYear(licId, LocalDate.now()) != null) {
				if (defaultDate.isAfter(maxDate)) {
					output = maxDate;
				}
				if (ChronoUnit.DAYS.between(defaultDate, maxDate) >= daysDiffer) {
					output = defaultDate;
				}
			} else {
				output = defaultDate;
			}

		} else {
			output = dueDate;
		}

		return output;
	}
}
