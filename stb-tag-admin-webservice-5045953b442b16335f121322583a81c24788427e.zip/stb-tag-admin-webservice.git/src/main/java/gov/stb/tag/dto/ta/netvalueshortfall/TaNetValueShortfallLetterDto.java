package gov.stb.tag.dto.ta.netvalueshortfall;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.*;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.WorkflowFile;
import org.apache.commons.collections.CollectionUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TaNetValueShortfallLetterDto {

	private String fileName;
	private byte[] shortfallLetterByteArray;
	private String letterContent;

	public String getFileName() { return fileName; }

	public void setFileName(String fileName) { this.fileName = fileName; }

	public byte[] getShortfallLetterByteArray() { return shortfallLetterByteArray; }

	public void setShortfallLetterByteArray(byte[] shortfallLetterByteArray) { this.shortfallLetterByteArray = shortfallLetterByteArray; }

	public String getLetterContent() { return letterContent; }

	public void setLetterContent(String letterContent) { this.letterContent = letterContent; }
}
