package gov.stb.tag.dto.ta.shortfallRectification;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.ta.application.TaApplicationDto;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.util.DateUtil;

public class TaShortfallRectificationDto extends TaApplicationDto {

	private Boolean hasShortfallToRectify = Boolean.FALSE;
	private BigDecimal capital;
	private LocalDate rectifiedDate;
	private FileDto bankStatement;
	private FileDto directorResolution;
	private FileDto acra;
	private List<FileDto> otherDocuments;
	private List<TaNetValueShortfallDto> netvalueShortfalls;

	private BigDecimal rectificationAmount = BigDecimal.ZERO;
	private LocalDate rectificationDueDate;
	private LocalDate rectificationExtendedDueDate;

	// to validate the min rectified date allowed
	private LocalDate minRectifiedDate;

	// officer inputs
	private WorkflowActionDto officerLastActionDto;

	private Boolean isEdhPopulated;

	public static TaShortfallRectificationDto buildFromApplication(Cache cache, ApplicationHelper appHelper, WorkflowHelper workflowHelper, TaNetValueRectification rect, TaStakeholder ke,
			FileHelper fileHelper) {
		TaShortfallRectificationDto dto = new TaShortfallRectificationDto();
		dto = dto.buildFromApplication(cache, appHelper, rect.getApplication(), dto);
		dto = dto.setKeDetails(cache, ke, dto);
		dto.setCapital(rect.getAmount());
		dto.setIsEdhPopulated(rect.getIsEdhPopulated());
		dto.setRectifiedDate(rect.getRectifiedDate());
		dto.setNetvalueShortfalls(Lists.newArrayList());
		for (TaNetValueShortfall shortfall : rect.getAllTaNetValueShortfalls()) {
			TaNetValueShortfallDto shortfallDto = TaNetValueShortfallDto.buildFromNetValueShortfall(cache, workflowHelper, fileHelper, appHelper, shortfall, null, Boolean.FALSE);
			dto.getNetvalueShortfalls().add(shortfallDto);
			dto.setRectificationAmount(dto.getRectificationAmount().add(shortfallDto.getShortfallAmount()));
			dto.setRectificationDueDate(DateUtil.getMinDate(dto.getRectificationDueDate(), shortfallDto.getDueDate()));
			dto.setRectificationExtendedDueDate(DateUtil.getMinDate(dto.getRectificationExtendedDueDate(), shortfallDto.getExtendedDueDate()));
		}
		// setting director's resolution, bank statement, and other documents
		List<ApplicationFile> appFiles = new ArrayList<>(rect.getApplication().getApplicationFiles());
		List<FileDto> otherDocuments = new ArrayList<FileDto>();

		for (ApplicationFile appFile : appFiles) {
			if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_REC_DIRECTOR_RESOLUTION)) {
				dto.setDirectorResolution(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_REC_BANK_STATEMENT)) {
				dto.setBankStatement(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			} else if (appFile.getDocumentType().getCode().equals(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ)) {
				dto.setAcra(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			} else {
				otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
			}
		}
		dto.setOtherDocuments(otherDocuments);

		if (dto.getBankStatement() == null) {
			dto.setBankStatement(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_REC_BANK_STATEMENT), fileHelper));
		}
		if (dto.getDirectorResolution() == null) {
			dto.setDirectorResolution(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_REC_DIRECTOR_RESOLUTION), fileHelper));
		}
		if (dto.getAcra() == null) {
			dto.setAcra(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ), fileHelper));
		}
		dto.setHasShortfallToRectify(Boolean.TRUE);
		dto.setMinRectifiedDate(deriveMinRectifiedDateAllowed(rect.getAllTaNetValueShortfalls()));

		// set officer last action dto
		dto.setOfficerLastActionDto(new WorkflowActionDto(cache, rect.getApplication().getLastAction()));
		return dto;
	}

	public static TaShortfallRectificationDto buildFromNew(Cache cache, WorkflowHelper workflowHelper, ApplicationHelper appHelper, List<TaNetValueShortfall> unfulfilledShortfalls,
			FileHelper fileHelper) {

		TaShortfallRectificationDto dto = new TaShortfallRectificationDto();
		dto.setDirectorResolution(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_REC_DIRECTOR_RESOLUTION), fileHelper));
		dto.setBankStatement(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_REC_BANK_STATEMENT), fileHelper));
		dto.setAcra(FileDto.buildFromFile(null, cache.getType(Codes.TaDocumentTypes.TA_DOC_ACRA_BIZ), fileHelper));

		if (CollectionUtils.isNotEmpty(unfulfilledShortfalls)) {
			dto.setHasShortfallToRectify(Boolean.TRUE);
			dto.setNetvalueShortfalls(Lists.newArrayList());
			unfulfilledShortfalls.forEach(shortfall -> {
				TaNetValueShortfallDto shortfallDto = TaNetValueShortfallDto.buildFromNetValueShortfall(cache, workflowHelper, fileHelper, appHelper, shortfall, null, Boolean.FALSE);
				dto.getNetvalueShortfalls().add(shortfallDto);
				dto.setRectificationAmount(dto.getRectificationAmount().add(shortfallDto.getShortfallAmount()));
				dto.setRectificationDueDate(DateUtil.getMinDate(dto.getRectificationDueDate(), shortfallDto.getDueDate()));
				dto.setRectificationExtendedDueDate(DateUtil.getMinDate(dto.getRectificationExtendedDueDate(), shortfallDto.getExtendedDueDate()));
			});
		} else {
			dto.setHasShortfallToRectify(Boolean.FALSE);
		}

		return dto;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public LocalDate getRectifiedDate() {
		return rectifiedDate;
	}

	public void setRectifiedDate(LocalDate rectifiedDate) {
		this.rectifiedDate = rectifiedDate;
	}

	public BigDecimal getRectificationAmount() {
		return rectificationAmount;
	}

	public void setRectificationAmount(BigDecimal rectificationAmount) {
		this.rectificationAmount = rectificationAmount;
	}

	public LocalDate getRectificationDueDate() {
		return rectificationDueDate;
	}

	public void setRectificationDueDate(LocalDate rectificationDueDate) {
		this.rectificationDueDate = rectificationDueDate;
	}

	public LocalDate getRectificationExtendedDueDate() {
		return rectificationExtendedDueDate;
	}

	public void setRectificationExtendedDueDate(LocalDate rectificationExtendedDueDate) {
		this.rectificationExtendedDueDate = rectificationExtendedDueDate;
	}

	public FileDto getBankStatement() {
		return bankStatement;
	}

	public void setBankStatement(FileDto bankStatement) {
		this.bankStatement = bankStatement;
	}

	public FileDto getAcra() {
		return acra;
	}

	public void setAcra(FileDto acra) {
		this.acra = acra;
	}

	public FileDto getDirectorResolution() {
		return directorResolution;
	}

	public void setDirectorResolution(FileDto directorResolution) {
		this.directorResolution = directorResolution;
	}

	public List<FileDto> getOtherDocuments() {
		return otherDocuments;
	}

	public void setOtherDocuments(List<FileDto> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

	public List<TaNetValueShortfallDto> getNetvalueShortfalls() {
		return netvalueShortfalls;
	}

	public void setNetvalueShortfalls(List<TaNetValueShortfallDto> netvalueShortfalls) {
		this.netvalueShortfalls = netvalueShortfalls;
	}

	public Boolean getHasShortfallToRectify() {
		return hasShortfallToRectify;
	}

	public void setHasShortfallToRectify(Boolean hasShortfallToRectify) {
		this.hasShortfallToRectify = hasShortfallToRectify;
	}

	public LocalDate getMinRectifiedDate() {
		return minRectifiedDate;
	}

	public void setMinRectifiedDate(LocalDate minRectifiedDate) {
		this.minRectifiedDate = minRectifiedDate;
	}

	public WorkflowActionDto getOfficerLastActionDto() {
		return officerLastActionDto;
	}

	public void setOfficerLastActionDto(WorkflowActionDto officerLastActionDto) {
		this.officerLastActionDto = officerLastActionDto;
	}

	public Boolean getIsEdhPopulated() {
		return isEdhPopulated;
	}

	public void setIsEdhPopulated(Boolean isEdhPopulated) {
		this.isEdhPopulated = isEdhPopulated;
	}

	private static LocalDate deriveMinRectifiedDateAllowed(Collection<TaNetValueShortfall> shortfalls) {
		LocalDate minRectifiedDate = null;
		for (TaNetValueShortfall shortfall : shortfalls) {
			if (shortfall.getTaAaSubmission() != null) {
				LocalDate fyEndDate = shortfall.getTaAaSubmission().getTaAnnualFiling().getFyEndDate().plusDays(1);
				if (minRectifiedDate == null || fyEndDate.isAfter(minRectifiedDate)) {
					minRectifiedDate = fyEndDate;
				}
			} else if (shortfall.getTaMaSubmission() != null) {
				LocalDate asAtDate = shortfall.getTaMaSubmission().getAsAtDate().plusDays(1);
				if (minRectifiedDate == null || asAtDate.isAfter(minRectifiedDate)) {
					minRectifiedDate = asAtDate;
				}
			}
		}
		return minRectifiedDate;
	}
}
