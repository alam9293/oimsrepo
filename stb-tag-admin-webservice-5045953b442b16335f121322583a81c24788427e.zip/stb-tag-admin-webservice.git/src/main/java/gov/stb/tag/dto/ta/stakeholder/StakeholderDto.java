package gov.stb.tag.dto.ta.stakeholder;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;

import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaStakeholderApplication;

public class StakeholderDto {
	@Autowired
	UserHelper userHelper;

	private Integer stakeholderId;

	private Boolean isCompany;

	private String companyUen;

	private LocalDate companyIncorporatedDate;

	private String stakeholderName;

	private String uin;

	private String formerUin;

	private ListableDto sex = new ListableDto();

	private ListableDto nationality = new ListableDto();

	private AddressDto address;

	private LocalDate dob; // KE only

	private String contactNo; // mobile

	private String officeNo;
	private String residentialNo;

	private String email;

	private ListableDto highestEduLevel = new ListableDto(); // KE only

	private ListableDto designation = new ListableDto();

	private String otherDesignation;

	private boolean isScpr;

	public StakeholderDto() {

	}

	public StakeholderDto(Cache cache, Stakeholder stakeholder) {
		this.stakeholderId = stakeholder.getId();
		this.address = AddressDto.buildFromAddress(cache, stakeholder.getAddress());
		this.companyIncorporatedDate = stakeholder.getCompanyIncorporatedDate();
		this.companyUen = stakeholder.getCompanyUen();
		this.contactNo = stakeholder.getContactNo();
		this.officeNo = stakeholder.getOfficeNo();
		this.residentialNo = stakeholder.getResidentialNo();
		this.dob = stakeholder.getDob();
		this.email = stakeholder.getEmail();
		this.formerUin = stakeholder.getFormerUin();
		this.highestEduLevel = (stakeholder.getHighestEduLevel() != null ? new ListableDto(stakeholder.getHighestEduLevel().getKey(), cache.getLabel(stakeholder.getHighestEduLevel(), false))
				: new ListableDto());
		this.isCompany = stakeholder.isCompany();
		this.stakeholderName = stakeholder.getName();
		this.nationality = stakeholder.getNationality() != null ? new ListableDto(stakeholder.getNationality().getKey(), cache.getLabel(stakeholder.getNationality(), false)) : new ListableDto();
		this.sex = stakeholder.getSex() != null ? new ListableDto(stakeholder.getSex().getKey(), cache.getLabel(stakeholder.getSex(), false)) : new ListableDto();
		this.uin = stakeholder.getUin();
		this.designation = stakeholder.getDesignation() != null ? new ListableDto(stakeholder.getDesignation().getKey(), cache.getLabel(stakeholder.getDesignation(), false)) : new ListableDto();
		this.otherDesignation = stakeholder.getOtherDesignation();
		this.setScpr();

	}

	public StakeholderDto(Cache cache, TaStakeholderApplication stakeholder) {
		this.stakeholderId = stakeholder.getId();
		this.address = AddressDto.buildFromAddress(cache, stakeholder.getAddress());
		this.companyIncorporatedDate = stakeholder.getCompanyIncorporatedDate();
		this.companyUen = stakeholder.getCompanyUen();
		this.contactNo = stakeholder.getContactNo();
		this.officeNo = stakeholder.getOfficeNo();
		this.residentialNo = stakeholder.getResidentialNo();
		this.dob = stakeholder.getDob();
		this.email = stakeholder.getEmail();
		this.formerUin = stakeholder.getFormerUin();
		this.highestEduLevel = (stakeholder.getHighestEduLevel() != null ? new ListableDto(stakeholder.getHighestEduLevel().getKey(), cache.getLabel(stakeholder.getHighestEduLevel(), false))
				: new ListableDto());
		this.stakeholderName = stakeholder.getName();
		this.nationality = stakeholder.getNationality() != null ? new ListableDto(stakeholder.getNationality().getKey(), cache.getLabel(stakeholder.getNationality(), false)) : new ListableDto();
		this.sex = stakeholder.getSex() != null ? new ListableDto(stakeholder.getSex().getKey(), cache.getLabel(stakeholder.getSex(), false)) : new ListableDto();
		this.uin = stakeholder.getUin();
		this.designation = stakeholder.getDesignation() != null ? new ListableDto(stakeholder.getDesignation().getKey(), cache.getLabel(stakeholder.getDesignation(), false)) : new ListableDto();
		this.otherDesignation = stakeholder.getOtherDesignation();
		this.isCompany = stakeholder.getIsCompany();
		this.setScpr();
	}

	public static <T extends StakeholderDto> T buildFromStakeholder(Cache cache, Stakeholder stakeholder, T dto) {
		dto.setStakeholderId(stakeholder.getId());
		dto.setAddress(AddressDto.buildFromAddress(cache, stakeholder.getAddress()));
		dto.setCompanyIncorporatedDate(stakeholder.getCompanyIncorporatedDate());
		dto.setCompanyUen(stakeholder.getCompanyUen());
		dto.setContactNo(stakeholder.getContactNo());
		dto.setOfficeNo(stakeholder.getOfficeNo());
		dto.setResidentialNo(stakeholder.getResidentialNo());
		dto.setDob(stakeholder.getDob());
		dto.setEmail(stakeholder.getEmail());
		dto.setFormerUin(stakeholder.getFormerUin());
		dto.setHighestEduLevel(
				stakeholder.getHighestEduLevel() != null ? new ListableDto(stakeholder.getHighestEduLevel().getKey(), cache.getLabel(stakeholder.getHighestEduLevel(), false)) : new ListableDto());
		dto.setIsCompany(stakeholder.isCompany());
		dto.setStakeholderName(stakeholder.getName());
		dto.setNationality(stakeholder.getNationality() != null ? new ListableDto(stakeholder.getNationality().getKey(), cache.getLabel(stakeholder.getNationality(), false)) : new ListableDto());
		dto.setSex(stakeholder.getSex() != null ? new ListableDto(stakeholder.getSex().getKey(), cache.getLabel(stakeholder.getSex(), false)) : null);
		dto.setUin(stakeholder.getUin());
		dto.setDesignation(stakeholder.getDesignation() != null ? new ListableDto(stakeholder.getDesignation().getKey(), cache.getLabel(stakeholder.getDesignation(), false)) : new ListableDto());
		dto.setOtherDesignation(stakeholder.getOtherDesignation());
		return dto;
	}

	public Integer getStakeholderId() {
		return stakeholderId;
	}

	public void setStakeholderId(Integer stakeholderId) {
		this.stakeholderId = stakeholderId;
	}

	public Boolean getIsCompany() {
		return isCompany;
	}

	public void setIsCompany(Boolean isCompany) {
		this.isCompany = isCompany;
	}

	public String getCompanyUen() {
		return companyUen;
	}

	public void setCompanyUen(String companyUen) {
		this.companyUen = companyUen;
	}

	public LocalDate getCompanyIncorporatedDate() {
		return companyIncorporatedDate;
	}

	public void setCompanyIncorporatedDate(LocalDate companyIncorporatedDate) {
		this.companyIncorporatedDate = companyIncorporatedDate;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
		this.setScpr();
	}

	public String getFormerUin() {
		return formerUin;
	}

	public void setFormerUin(String formerUin) {
		this.formerUin = formerUin;
	}

	public ListableDto getSex() {
		return sex;
	}

	public void setSex(ListableDto sex) {
		this.sex = sex;
	}

	public ListableDto getNationality() {
		return nationality;
	}

	public void setNationality(ListableDto nationality) {
		this.nationality = nationality;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public ListableDto getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(ListableDto highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public String getStakeholderName() {
		return stakeholderName;
	}

	public void setStakeholderName(String stakeholderName) {
		this.stakeholderName = stakeholderName;
	}

	public String getOtherDesignation() {
		return otherDesignation;
	}

	public void setOtherDesignation(String otherDesignation) {
		this.otherDesignation = otherDesignation;
	}

	public ListableDto getDesignation() {
		return designation;
	}

	public void setDesignation(ListableDto designation) {
		this.designation = designation;
	}

	public boolean isScpr() {
		return isScpr;
	}

	public void setScpr() {
		if (isCompany != null && !isCompany) {
			this.isScpr = getUin().toUpperCase().startsWith("S") || getUin().toUpperCase().startsWith("T");
		} else {
			this.isScpr = false;
		}
	}

	public String getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public String getResidentialNo() {
		return residentialNo;
	}

	public void setResidentialNo(String residentialNo) {
		this.residentialNo = residentialNo;
	}
}
