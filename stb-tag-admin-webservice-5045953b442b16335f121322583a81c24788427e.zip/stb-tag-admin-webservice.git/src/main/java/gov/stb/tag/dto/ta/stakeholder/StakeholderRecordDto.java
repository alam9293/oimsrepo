package gov.stb.tag.dto.ta.stakeholder;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StakeholderRecordDto extends EntityDto {

	private StakeholderDto particulars;

	private TaStakeholderDto involvement;

	public static StakeholderRecordDto build(Cache cache, TaStakeholderApplication sh, Boolean loadDeclarations) {
		StakeholderRecordDto dto = new StakeholderRecordDto();
		dto.setInvolvement(TaStakeholderDto.buildFromTaStakeholder(cache, sh, loadDeclarations));
		dto.setParticulars(new StakeholderDto(cache, sh));
		return dto;
	}

	public static StakeholderRecordDto build(Cache cache, TaStakeholder involvement, Stakeholder particulars, Boolean loadDeclarations, Boolean loadLicence) {
		StakeholderRecordDto dto = new StakeholderRecordDto();
		dto.setInvolvement(TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, involvement, loadDeclarations, loadLicence));
		dto.setParticulars(new StakeholderDto(cache, particulars));
		return dto;
	}

	public StakeholderDto getParticulars() {
		return particulars;
	}

	public void setParticulars(StakeholderDto particulars) {
		this.particulars = particulars;
	}

	public TaStakeholderDto getInvolvement() {
		return involvement;
	}

	public void setInvolvement(TaStakeholderDto involvement) {
		this.involvement = involvement;
	}

}
