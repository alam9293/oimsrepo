package gov.stb.tag.dto.ta.stakeholder;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class StakeholderRecordsDto extends EntityDto {

	private StakeholderDto particulars;

	private List<TaStakeholderDto> involvements = new ArrayList<>();

	public static StakeholderRecordsDto build(Cache cache, List<TaStakeholder> involvements, Stakeholder particulars, Boolean loadDeclarations, Boolean loadLicence) {
		StakeholderRecordsDto dto = new StakeholderRecordsDto();
		List<TaStakeholderDto> involvementDto = new ArrayList<>();
		for (TaStakeholder x : involvements) {
			TaStakeholderDto xDto = TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, x, loadDeclarations, loadLicence);
			involvementDto.add(xDto);
		}
		dto.setInvolvements(involvementDto);
		dto.setParticulars(new StakeholderDto(cache, particulars));
		return dto;
	}

	public static StakeholderRecordsDto build(Cache cache, List<TaStakeholder> involvements, TaStakeholderApplication particulars, Boolean loadDeclarations, Boolean loadLicence) {
		StakeholderRecordsDto dto = new StakeholderRecordsDto();
		List<TaStakeholderDto> involvementDto = new ArrayList<>();
		for (TaStakeholder x : involvements) {
			TaStakeholderDto xDto = TaStakeholderDto.buildTaStakeholderDtoFromTaStakeholderModel(cache, x, loadDeclarations, loadLicence);
			involvementDto.add(xDto);
		}
		dto.setInvolvements(involvementDto);
		dto.setParticulars(new StakeholderDto(cache, particulars));
		return dto;
	}

	public StakeholderDto getParticulars() {
		return particulars;
	}

	public void setParticulars(StakeholderDto particulars) {
		this.particulars = particulars;
	}

	public List<TaStakeholderDto> getInvolvements() {
		return involvements;
	}

	public void setInvolvements(List<TaStakeholderDto> involvements) {
		this.involvements = involvements;
	}

}
