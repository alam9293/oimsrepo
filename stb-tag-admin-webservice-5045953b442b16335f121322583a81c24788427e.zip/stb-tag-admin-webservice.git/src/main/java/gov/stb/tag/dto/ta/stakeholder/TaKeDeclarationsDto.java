package gov.stb.tag.dto.ta.stakeholder;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.TaKeDeclaration;

public class TaKeDeclarationsDto extends EntityDto {

	private Integer id;

	private String prefix;

	private String selectedOption;

	private String options;

	private String optionsToPrompt;

	private String prompt;

	private ListableDto clause;

	private String remarks;

	private Boolean isOptionRequired;

	private Boolean isRadioButton;

	private Integer ordinal;

	private String subscript;

	public static TaKeDeclarationsDto build(Cache cache, TaKeDeclaration declaration) {
		TaKeDeclarationsDto dto = new TaKeDeclarationsDto();
		dto.setId(declaration.getId());
		dto.setPrefix(cache.getTaKeClause(declaration.getTaKeClause().getId()).getPrefix());
		dto.setSelectedOption(declaration.getOptionSelected());
		dto.setOptions(declaration.getTaKeClause().getOptions());
		dto.setClause(new ListableDto(declaration.getTaKeClause().getId(), cache.getTaKeClause(declaration.getTaKeClause().getId()).getClause()));
		dto.setSubscript(cache.getTaKeClause(declaration.getTaKeClause().getId()).getSubscript());
		dto.setRemarks(declaration.getRemarks());
		dto.setIsOptionRequired(cache.getTaKeClause(declaration.getTaKeClause().getId()).isOptionsRequired());
		dto.setIsRadioButton(cache.getTaKeClause(declaration.getTaKeClause().getId()).isRadioBtn());
		dto.setOptionsToPrompt(declaration.getTaKeClause().getOptionsToPrompt());
		dto.setPrompt(declaration.getTaKeClause().getPrompt());
		dto.setOrdinal(cache.getTaKeClause(declaration.getTaKeClause().getId()).getOrdinal());
		return dto;
	}

	public static TaKeDeclarationsDto buildClauseOnly(Cache cache, TaKeClause clause) {
		TaKeDeclarationsDto dto = new TaKeDeclarationsDto();
		dto.setPrefix(clause.getPrefix());
		dto.setOptions(clause.getOptions());
		dto.setClause(new ListableDto(clause.getId(), clause.getClause()));
		dto.setIsOptionRequired(clause.isOptionsRequired());
		dto.setIsRadioButton(clause.isRadioBtn());
		dto.setOptionsToPrompt(clause.getOptionsToPrompt());
		dto.setPrompt(clause.getPrompt());
		dto.setSubscript(clause.getSubscript());
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getSelectedOption() {
		return selectedOption;
	}

	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public ListableDto getClause() {
		return clause;
	}

	public void setClause(ListableDto clause) {
		this.clause = clause;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Boolean getIsOptionRequired() {
		return isOptionRequired;
	}

	public void setIsOptionRequired(Boolean isOptionRequired) {
		this.isOptionRequired = isOptionRequired;
	}

	public Boolean getIsRadioButton() {
		return isRadioButton;
	}

	public void setIsRadioButton(Boolean isRadioButton) {
		this.isRadioButton = isRadioButton;
	}

	public String getOptionsToPrompt() {
		return optionsToPrompt;
	}

	public void setOptionsToPrompt(String optionsToPrompt) {
		this.optionsToPrompt = optionsToPrompt;
	}

	public String getPrompt() {
		return prompt;
	}

	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public String getSubscript() {
		return subscript;
	}

	public void setSubscript(String subscript) {
		this.subscript = subscript;
	}

}
