package gov.stb.tag.dto.ta.stakeholder;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaStakeholderItemDto {

	@MapProjection(path = "id")
	private Integer stakeholderId;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "companyUen")
	private String uen;

	@MapProjection(path = "uin")
	private String uin;

	@MapProjection(path = "dob")
	private LocalDate dob;

	@MapProjection(path = "companyIncorporatedDate")
	private LocalDate companyIncorporatedDate;

	public Integer getStakeholderId() {
		return stakeholderId;
	}

	public void setStakeholderId(Integer stakeholderId) {
		this.stakeholderId = stakeholderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public LocalDate getCompanyIncorporatedDate() {
		return companyIncorporatedDate;
	}

	public void setCompanyIncorporatedDate(LocalDate companyIncorporatedDate) {
		this.companyIncorporatedDate = companyIncorporatedDate;
	}

}
