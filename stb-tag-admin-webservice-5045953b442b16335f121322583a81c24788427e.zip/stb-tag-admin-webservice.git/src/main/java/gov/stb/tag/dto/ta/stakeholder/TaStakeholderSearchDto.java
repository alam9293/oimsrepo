package gov.stb.tag.dto.ta.stakeholder;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaStakeholderSearchDto extends SearchDto {

	private String name;

	private String uin;

	private String uen;

	private LocalDate dobFrom;

	private LocalDate dobTo;

	private LocalDate companyIncorporatedDateFrom;

	private LocalDate companyIncorporatedDateTo;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public LocalDate getDobFrom() {
		return dobFrom;
	}

	public void setDobFrom(LocalDate dobFrom) {
		this.dobFrom = dobFrom;
	}

	public LocalDate getDobTo() {
		return dobTo;
	}

	public void setDobTo(LocalDate dobTo) {
		this.dobTo = dobTo;
	}

	public LocalDate getCompanyIncorporatedDateFrom() {
		return companyIncorporatedDateFrom;
	}

	public void setCompanyIncorporatedDateFrom(LocalDate companyIncorporatedDateFrom) {
		this.companyIncorporatedDateFrom = companyIncorporatedDateFrom;
	}

	public LocalDate getCompanyIncorporatedDateTo() {
		return companyIncorporatedDateTo;
	}

	public void setCompanyIncorporatedDateTo(LocalDate companyIncorporatedDateTo) {
		this.companyIncorporatedDateTo = companyIncorporatedDateTo;
	}

}
