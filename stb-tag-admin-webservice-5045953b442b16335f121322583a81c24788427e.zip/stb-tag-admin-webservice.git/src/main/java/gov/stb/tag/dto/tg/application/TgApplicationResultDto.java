package gov.stb.tag.dto.tg.application;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.helper.Cache;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgApplicationResultDto {

	private String applicationNo;

	public TgApplicationResultDto() {

	}

	public static TgApplicationResultDto setAllListByLicencePrintStatus(Cache cache, TgApplicationItemDto taItem) {
		TgApplicationResultDto taDto = new TgApplicationResultDto();
		taDto.setApplicationNo(taItem.getApplicationNo());
		return taDto;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

}
