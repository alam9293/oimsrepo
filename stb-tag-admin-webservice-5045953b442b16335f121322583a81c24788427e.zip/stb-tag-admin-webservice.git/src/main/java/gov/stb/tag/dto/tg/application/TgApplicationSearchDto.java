package gov.stb.tag.dto.tg.application;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgApplicationSearchDto extends SearchDto {

	private String name;
	private String nricFin;
	private String licenceNo;
	private String status;
	private String[] statuses;
	private String applicationNo;
	private String applicationType;
	private String applicationStatus;
	private String licenceType;
	private LocalDate dateSendVendor;
	private LocalDate pendingCollectionStartDate;
	private LocalDate pendingCollectionEndDate;
	private LocalDateTime submissionDateFrom;
	private LocalDateTime submissionDateTo;
	private String assignedOfficer;
	private String tgTrainingProviderName;
	private Boolean isPendingFollowUp;
	private Boolean hasFollowUpRequiredByFinance;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNricFin() {
		return nricFin;
	}

	public void setNricFin(String nricFin) {
		this.nricFin = nricFin;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String[] getStatuses() {
		return statuses;
	}

	public void setStatuses(String[] statuses) {
		this.statuses = statuses;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public LocalDate getDateSendVendor() {
		return dateSendVendor;
	}

	public void setDateSendVendor(LocalDate dateSendVendor) {
		this.dateSendVendor = dateSendVendor;
	}

	public LocalDate getPendingCollectionStartDate() {
		return pendingCollectionStartDate;
	}

	public void setPendingCollectionStartDate(LocalDate pendingCollectionStartDate) {
		this.pendingCollectionStartDate = pendingCollectionStartDate;
	}

	public LocalDate getPendingCollectionEndDate() {
		return pendingCollectionEndDate;
	}

	public void setPendingCollectionEndDate(LocalDate pendingCollectionEndDate) {
		this.pendingCollectionEndDate = pendingCollectionEndDate;
	}

	public LocalDateTime getSubmissionDateFrom() {
		return submissionDateFrom;
	}

	public void setSubmissionDateFrom(LocalDateTime submissionDateFrom) {
		this.submissionDateFrom = submissionDateFrom;
	}

	public LocalDateTime getSubmissionDateTo() {
		return submissionDateTo;
	}

	public void setSubmissionDateTo(LocalDateTime submissionDateTo) {
		this.submissionDateTo = submissionDateTo;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getTgTrainingProviderName() {
		return tgTrainingProviderName;
	}

	public void setTgTrainingProviderName(String tgTrainingProviderName) {
		this.tgTrainingProviderName = tgTrainingProviderName;
	}

	public Boolean isPendingFollowUp() { return isPendingFollowUp; }

	public void setIsPendingFollowUp(Boolean isPendingFollowUp) { this.isPendingFollowUp = isPendingFollowUp; }

	public Boolean getHasFollowUpRequiredByFinance() { return hasFollowUpRequiredByFinance; }

	public void setHasFollowUpRequiredByFinance(Boolean hasFollowUpRequiredByFinance) { this.hasFollowUpRequiredByFinance = hasFollowUpRequiredByFinance; }
}
