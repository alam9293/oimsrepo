package gov.stb.tag.dto.tg.assignment;

import java.math.BigDecimal;

public class TgAssignmentDateDto {

	private String date;
	private BigDecimal noOfHours;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}
}
