package gov.stb.tag.dto.tg.assignment;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgAssignmentItemDto {

	private Integer assignmentId;
	private LocalDate startDate;
	private LocalDate endDate;
	private String assignmentType;
	private String assignmentTypeOther;
	private String employmentSource;
	private String employmentSourceOther;
	private String companyName;
	private BigDecimal totalHours;
	private BigDecimal feeReceived;
	private LocalDateTime submissionDate;

	public Integer getAssignmentId() {
		return assignmentId;
	}

	public void setAssignmentId(Integer assignmentId) {
		this.assignmentId = assignmentId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getAssignmentType() {
		return assignmentType;
	}

	public void setAssignmentType(String assignmentType) {
		this.assignmentType = assignmentType;
	}

	public String getAssignmentTypeOther() {
		return assignmentTypeOther;
	}

	public void setAssignmentTypeOther(String assignmentTypeOther) {
		this.assignmentTypeOther = assignmentTypeOther;
	}

	public String getEmploymentSource() {
		return employmentSource;
	}

	public void setEmploymentSource(String employmentSource) {
		this.employmentSource = employmentSource;
	}

	public String getEmploymentSourceOther() {
		return employmentSourceOther;
	}

	public void setEmploymentSourceOther(String employmentSourceOther) {
		this.employmentSourceOther = employmentSourceOther;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public BigDecimal getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(BigDecimal totalHours) {
		this.totalHours = totalHours;
	}

	public BigDecimal getFeeReceived() {
		return feeReceived;
	}

	public void setFeeReceived(BigDecimal feeReceived) {
		this.feeReceived = feeReceived;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

}
