package gov.stb.tag.dto.tg.assignment;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgAssignment;
import gov.stb.tag.model.TgAssignmentDate;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgAssignmentResultDto {

	private Integer assignmentId;
	private LocalDate licenceStartDate;
	private LocalDate startDate;
	private LocalDate endDate;
	private ListableDto tourType;
	private String tourTypeOther;
	private BigDecimal totalHours;
	private ListableDto employmentSourceType;
	private String employmentSourceTypeOther;
	private String companyName;
	private String language;
	private BigDecimal feeReceived;
	private LocalDate submissionDate;
	private boolean isDeleted;
	private Set<TgAssignmentDate> tgAssignmentDates;

	public TgAssignmentResultDto() {

	}

	public static TgAssignmentResultDto buildFromAssignment(Cache cache, TgAssignment ta, LocalDate licenceStartDate) {
		TgAssignmentResultDto taDto = new TgAssignmentResultDto();
		taDto.setAssignmentId(ta.getId());
		taDto.setLicenceStartDate(licenceStartDate);
		taDto.setStartDate(ta.getStartDate());
		taDto.setEndDate(ta.getEndDate());
		taDto.setTourType(new ListableDto(ta.getType().getKey(), cache.getLabel(ta.getType(), false)));
		taDto.setEmploymentSourceType(new ListableDto(ta.getEmploymentSource().getKey(), cache.getLabel(ta.getEmploymentSource(), false)));
		taDto.setCompanyName(ta.getCompanyName());

		taDto.setFeeReceived(ta.getFeeReceived());
		taDto.setSubmissionDate(ta.getCreatedDate().toLocalDate());

		BigDecimal totalNoOfHours = new BigDecimal(0);
		for (TgAssignmentDate tad : ta.getTgAssignmentDates()) {
			totalNoOfHours = totalNoOfHours.add(tad.getNoOfHours());
		}
		taDto.setTotalHours(totalNoOfHours);
		taDto.setIsDeleted(ta.isDeleted());
		return taDto;
	}

	public static TgAssignmentResultDto buildSingleAssignment(Cache cache, TgAssignment ta, LocalDate licenceStartDate) {
		TgAssignmentResultDto taDto = new TgAssignmentResultDto();
		taDto.setAssignmentId(ta.getId());
		taDto.setLicenceStartDate(licenceStartDate);
		taDto.setTourType(new ListableDto(ta.getType().getKey(), cache.getLabel(ta.getType(), false)));
		if (ta.getType().getKey().toString().equals(Codes.Types.TG_ASN_TOUR_OTH)) {
			taDto.setTourTypeOther(ta.getTourTypeOther());
		}
		taDto.setStartDate(ta.getStartDate());
		taDto.setEndDate(ta.getEndDate());
		taDto.setEmploymentSourceType(new ListableDto(ta.getEmploymentSource().getKey(), cache.getLabel(ta.getEmploymentSource(), false)));
		if (ta.getEmploymentSource().getKey().toString().equals(Codes.Types.TG_ASN_EMP_SRC_OTH)) {
			taDto.setEmploymentSourceTypeOther(ta.getEmploymentSourceTypeOther());
		}
		taDto.setCompanyName(ta.getCompanyName());
		taDto.setLanguage((ta.getLanguage() != null) ? ta.getLanguage().getKey().toString() : "");
		taDto.setFeeReceived(ta.getFeeReceived());

		BigDecimal totalNoOfHours = new BigDecimal(0);
		for (TgAssignmentDate tad : ta.getTgAssignmentDates()) {
			totalNoOfHours = totalNoOfHours.add(tad.getNoOfHours());
		}
		taDto.setTotalHours(totalNoOfHours);

		SortedSet<TgAssignmentDate> tadSet = new TreeSet<>(Comparator.comparing(TgAssignmentDate::getDate));
		for (TgAssignmentDate td : ta.getTgAssignmentDates()) {
			TgAssignmentDate tad = new TgAssignmentDate();
			tad.setDate(td.getDate());
			tad.setNoOfHours(td.getNoOfHours());
			tadSet.add(tad);
		}
		taDto.setTgAssignmentDates(tadSet);
		return taDto;
	}

	public Integer getAssignmentId() {
		return assignmentId;
	}

	public void setAssignmentId(Integer assignmentId) {
		this.assignmentId = assignmentId;
	}

	public LocalDate getLicenceStartDate() {
		return licenceStartDate;
	}

	public void setLicenceStartDate(LocalDate licenceStartDate) {
		this.licenceStartDate = licenceStartDate;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public ListableDto getTourType() {
		return tourType;
	}

	public void setTourType(ListableDto tourType) {
		this.tourType = tourType;
	}

	public String getTourTypeOther() {
		return tourTypeOther;
	}

	public void setTourTypeOther(String tourTypeOther) {
		this.tourTypeOther = tourTypeOther;
	}

	public BigDecimal getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(BigDecimal totalHours) {
		this.totalHours = totalHours;
	}

	public ListableDto getEmploymentSourceType() {
		return employmentSourceType;
	}

	public void setEmploymentSourceType(ListableDto employmentSourceType) {
		this.employmentSourceType = employmentSourceType;
	}

	public String getEmploymentSourceTypeOther() {
		return employmentSourceTypeOther;
	}

	public void setEmploymentSourceTypeOther(String employmentSourceTypeOther) {
		this.employmentSourceTypeOther = employmentSourceTypeOther;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public BigDecimal getFeeReceived() {
		return feeReceived;
	}

	public void setFeeReceived(BigDecimal feeReceived) {
		this.feeReceived = feeReceived;
	}

	public LocalDate getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDate submissionDate) {
		this.submissionDate = submissionDate;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Set<TgAssignmentDate> getTgAssignmentDates() {
		return tgAssignmentDates;
	}

	public void setTgAssignmentDates(Set<TgAssignmentDate> tgAssignmentDates) {
		this.tgAssignmentDates = tgAssignmentDates;
	}
}
