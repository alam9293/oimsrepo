package gov.stb.tag.dto.tg.candidate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.tg.TgCandidateRepository;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCandidateDto extends TgCandidateExamDto {

	// candidate
	private Integer candidateId;
	private String uin;
	private String formerUin;
	private Integer licenceId;
	private String licenceNo;
	private Boolean isPortalId;

	// last exam details
	private List<TgCandidateExamDto> tgCandidateResults;

	// licence details
	private String licenceTier;
	private String licenceTierLabel;
	private String licenceSpecializedAreaLabel;
	private String licenceGuidingLanguage;
	private LocalDate licenceStartDate; // latest renewed cycle start date
	private String licenceStatusCode;
	private String tgName;

	public TgCandidateDto() {

	}

	public TgCandidateDto(CacheHelper cache, TgCandidate tc, TgCandidateResult tgCandidateResult, PaymentHelper paymentHelper, User user, Boolean buildResult, TgCandidateRepository repository) {
		super(cache, tgCandidateResult, paymentHelper, buildResult, repository);

		Licence licence = tc.getLicence();

		this.candidateId = tc.getId();
		this.uin = tc.getUin().toUpperCase();
		this.formerUin = tc.getFormerUin();
		this.isPortalId = user != null ? Codes.UserTypes.USER_PUBLIC_PORTAL.equals(user.getType().getKey()) : null;

		if (licence != null) {
			TouristGuide tg = licence.getTouristGuide();
			this.licenceId = licence.getId();
			this.licenceNo = licence.getLicenceNo();
			this.licenceTier = licence.getTier().getCode();
			this.licenceTierLabel = licence.getTier().getLabel();
			this.licenceSpecializedAreaLabel = tg.getSpecializedAreasWithComma(cache);
			this.licenceGuidingLanguage = tg.getGuidingLanguagesWithComma(cache);
			this.licenceStartDate = licence.getStartDate();
			this.tgName = tg.getName();
			this.licenceStatusCode = licence.getStatus().getCode();
		}

		if (buildResult) {
			var results = tc.getTgCandidateResults();
			List<TgCandidateExamDto> tgCandidateResults = new ArrayList<TgCandidateExamDto>();
			for (TgCandidateResult result : results) {
				tgCandidateResults.add(new TgCandidateExamDto(cache, result, paymentHelper, true, repository));
			}
			this.tgCandidateResults = tgCandidateResults;
		}
	}

	public static TgCandidateDto buildFromTouristGuide(Cache cache, TouristGuide tg, TgCandidate tc) {
		TgCandidateDto dto = new TgCandidateDto();
		dto.setUin(tg.getUin().toUpperCase());
		dto.setFormerUin(tg.getFormerUin() != null ? tg.getFormerUin().toUpperCase() : "");
		dto.setName(tg.getName());
		dto.setCandidateId(tc.getId());

		Licence licence = tg.getLicence();

		if (licence != null) {
			dto.setLicenceId(licence.getId());
			dto.setLicenceNo(licence.getLicenceNo());
			dto.setLicenceTier(licence.getTier().getCode());
			dto.setLicenceTierLabel(licence.getTier().getLabel());
			dto.setLicenceSpecializedAreaLabel(tg.getSpecializedAreasWithComma(cache));
			dto.setLicenceGuidingLanguage(tg.getGuidingLanguagesWithComma(cache));
			dto.setLicenceStartDate(licence.getStartDate());
			dto.setTgName(tg.getName());
			dto.setLicenceStatusCode(licence.getStatus().getCode());
		}

		return dto;
	}

	public Integer getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(Integer candidateId) {
		this.candidateId = candidateId;
	}

	public void setId(Integer candidateId) {
		this.candidateId = candidateId;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getFormerUin() {
		return formerUin;
	}

	public void setFormerUin(String formerUin) {
		this.formerUin = formerUin;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public List<TgCandidateExamDto> getTgCandidateResults() {
		return tgCandidateResults;
	}

	public void setTgCandidateResults(List<TgCandidateExamDto> tgCandidateResults) {
		this.tgCandidateResults = tgCandidateResults;
	}

	public Boolean getIsPortalId() {
		return isPortalId;
	}

	public void setIsPortalId(Boolean portalId) {
		isPortalId = portalId;
	}

	public String getLicenceGuidingLanguage() {
		return licenceGuidingLanguage;
	}

	public void setLicenceGuidingLanguage(String licenceGuidingLanguage) {
		this.licenceGuidingLanguage = licenceGuidingLanguage;
	}

	public String getLicenceTier() {
		return licenceTier;
	}

	public void setLicenceTier(String licenceTier) {
		this.licenceTier = licenceTier;
	}

	public String getLicenceTierLabel() {
		return licenceTierLabel;
	}

	public void setLicenceTierLabel(String licenceTierLabel) {
		this.licenceTierLabel = licenceTierLabel;
	}

	public String getLicenceSpecializedAreaLabel() {
		return licenceSpecializedAreaLabel;
	}

	public void setLicenceSpecializedAreaLabel(String licenceSpecializedAreaLabel) {
		this.licenceSpecializedAreaLabel = licenceSpecializedAreaLabel;
	}

	public LocalDate getLicenceStartDate() {
		return licenceStartDate;
	}

	public void setLicenceStartDate(LocalDate licenceStartDate) {
		this.licenceStartDate = licenceStartDate;
	}

	public String getTgName() {
		return tgName;
	}

	public void setTgName(String tgName) {
		this.tgName = tgName;
	}

	public String getLicenceStatusCode() {
		return licenceStatusCode;
	}

	public void setLicenceStatusCode(String licenceStatusCode) {
		this.licenceStatusCode = licenceStatusCode;
	}
}
