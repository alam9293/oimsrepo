package gov.stb.tag.dto.tg.candidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.User;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCandidateItemDto extends SearchDto {

	private Integer id;

	private String uin;

	private String name;

	private String licenceNo;

	private Boolean isDirectIssuance;

	private String testLanguage;

	private String tierCode;

	private String tier;

	private String specializedArea;

	private LocalDate examDate;

	private String result;

	private String trainingProviderName;

	private Boolean isForSwitchTier;

	public TgCandidateItemDto() {

	}

	public TgCandidateItemDto(CacheHelper cache, TgCandidate tc) {

		Licence licence = tc.getLicence();
		TgCandidateResult lastResult = tc.getLastCandidateResult();

		this.id = tc.getId();
		this.uin = tc.getUin().toUpperCase();

		if (licence != null) {
			this.licenceNo = licence.getLicenceNo();
		}

		if (lastResult != null) {
			this.name = lastResult.getName();
			this.isDirectIssuance = lastResult.isDirectIssuance();
			if (lastResult.isDirectIssuance()) {
				this.testLanguage = lastResult.getDiGuidingLanguagesWithComma(cache);
			} else {
				this.testLanguage = lastResult.getGuidingLanguage() != null ? lastResult.getGuidingLanguage().getLabel() : "";
			}

			this.tierCode = lastResult.getTier() != null ? lastResult.getTier().getCode() : "";
			this.tier = lastResult.getTier() != null ? lastResult.getTier().getLabel() : "";
			this.specializedArea = lastResult.getSpecializedArea() != null ? lastResult.getSpecializedArea().getLabel() : "";
			this.examDate = lastResult.getExamDate();
			this.result = lastResult.getResult() != null ? lastResult.getResult().getLabel() : "";
			this.trainingProviderName = lastResult.getTgTrainingProvider() != null ? lastResult.getTgTrainingProvider().getName() : "";
			this.isForSwitchTier = lastResult.isForSwitchTier();
		}

	}

	public Integer getId() { return id; }

	public void setId(Integer id) { this.id = id; }

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public Boolean getIsDirectIssuance() {
		return isDirectIssuance;
	}

	public void setIsDirectIssuance(Boolean directIssuance) {
		isDirectIssuance = directIssuance;
	}

	public String getTestLanguage() {
		return testLanguage;
	}

	public void setTestLanguage(String testLanguage) {
		this.testLanguage = testLanguage;
	}

	public String getTierCode() { return tierCode; }

	public void setTierCode(String tierCode) { this.tierCode = tierCode; }

	public String getTier() {
		return tier;
	}

	public void setTier(String tier) {
		this.tier = tier;
	}

	public String getSpecializedArea() {
		return specializedArea;
	}

	public void setSpecializedArea(String specializedArea) {
		if(Codes.Types.TG_TIER_GENERAL.equals(this.getTierCode())) {
			this.specializedArea = "-";
		} else {
			this.specializedArea = specializedArea;
		}
	}

	public LocalDate getExamDate() { return examDate; }

	public void setExamDate(LocalDate examDate) { this.examDate = examDate; }

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getTrainingProviderName() {
		return trainingProviderName;
	}

	public void setTrainingProviderName(String trainingProviderName) {
		this.trainingProviderName = trainingProviderName;
	}

	public Boolean getForSwitchTier() { return isForSwitchTier; }

	public void setForSwitchTier(Boolean forSwitchTier) { isForSwitchTier = forSwitchTier; }
}
