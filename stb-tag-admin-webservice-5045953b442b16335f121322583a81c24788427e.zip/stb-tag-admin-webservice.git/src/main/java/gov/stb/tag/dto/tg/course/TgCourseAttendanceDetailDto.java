package gov.stb.tag.dto.tg.course;

import java.util.Set;
import java.util.TreeSet;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgCourseAttendanceDetail;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseAttendanceDetailDto extends EntityDto implements Comparable<TgCourseAttendanceDetailDto> {

	private Integer attendanceDetailId;
	private String licenceNo;
	private String name;
	private Integer score;
	private Integer maxScore;
	private String attendance;

	public TgCourseAttendanceDetailDto() {

	}

	public static Set<TgCourseAttendanceDetailDto> buildFromCourseAttendanceDetailList(Cache cache, Set<TgCourseAttendanceDetail> details) {
		Set<TgCourseAttendanceDetailDto> dto = new TreeSet<TgCourseAttendanceDetailDto>();

		for (TgCourseAttendanceDetail detail : details) {
			if (!detail.isDeleted()) {
				var tg = detail.getTouristGuide();
				var licence = tg.getLicence();

				TgCourseAttendanceDetailDto detailDto = new TgCourseAttendanceDetailDto();
				detailDto.setAttendanceDetailId(detail.getId());
				detailDto.setLicenceNo(licence.getLicenceNo());
				detailDto.setName(tg.getName());
				detailDto.setScore(detail.getScore());
				detailDto.setMaxScore(detail.getMaxScore());
				detailDto.setAttendance(detail.getAttendance().getCode());

				dto.add(detailDto);
			}
		}

		return dto;
	}

	public Integer getAttendanceDetailId() {
		return attendanceDetailId;
	}

	public void setAttendanceDetailId(Integer attendanceDetailId) {
		this.attendanceDetailId = attendanceDetailId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(Integer maxScore) {
		this.maxScore = maxScore;
	}

	public String getAttendance() {
		return attendance;
	}

	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}

	@Override
	public int compareTo(TgCourseAttendanceDetailDto o) {
		return this.getLicenceNo().compareTo(o.getLicenceNo());
	}

}
