package gov.stb.tag.dto.tg.course;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TgCourseAttendance;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseAttendanceDto extends EntityDto {

	private Integer attendanceId;
	private String courseCode;
	private String courseName;
	private LocalDate courseDate; // attendedDate
	private LocalDate courseEndDate; // attendedEndDate
	private LocalDate approvedStartDate;
	private LocalDate approvedEndDate;

	private Set<TgCourseAttendanceDetailDto> attendeeRows;
	private List<Integer> removeAttendeeRows;

	private List<FileDto> supportingDocs;
	private List<Integer> toDeleteSupportingDocs;

	public TgCourseAttendanceDto() {

	}

	public static TgCourseAttendanceDto buildFromCourseAttendance(Cache cache, TgCourseAttendance tca) {
		TgCourseAttendanceDto dto = new TgCourseAttendanceDto();
		var tc = tca.getTgCourse();
		Application application = tca.getApplication();
		dto.setAttendanceId(tca.getId());
		dto.setCourseDate(tca.getAttendedDate());
		dto.setCourseEndDate(tca.getAttendedEndDate());
		dto.setApprovedStartDate(tc.getApprovedStartDate());
		dto.setApprovedEndDate(tc.getApprovedEndDate());
		dto.setCourseCode(tc.getCode());
		dto.setCourseName(tc.getName());
		List<FileDto> otherDocuments = new ArrayList<FileDto>();
		if (application != null && application.getApplicationFiles() != null) {
			for (ApplicationFile appFile : application.getApplicationFiles()) {
				if (Codes.TgDocumentTypes.TG_DOC_OTHERS.equals(appFile.getDocumentType().getCode())) {
					otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), null));
				}
			}
		}
		dto.setSupportingDocs(otherDocuments);
		dto.setAttendeeRows(TgCourseAttendanceDetailDto.buildFromCourseAttendanceDetailList(cache, tca.getTgCourseAttendanceDetails()));
		return dto;
	}

	public Integer getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(Integer attendanceId) {
		this.attendanceId = attendanceId;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Set<TgCourseAttendanceDetailDto> getAttendeeRows() {
		return attendeeRows;
	}

	public void setAttendeeRows(Set<TgCourseAttendanceDetailDto> attendeeRows) {
		this.attendeeRows = attendeeRows;
	}

	public LocalDate getCourseDate() {
		return courseDate;
	}

	public void setCourseDate(LocalDate courseDate) {
		this.courseDate = courseDate;
	}

	public LocalDate getCourseEndDate() {
		return courseEndDate;
	}

	public void setCourseEndDate(LocalDate courseEndDate) {
		this.courseEndDate = courseEndDate;
	}

	public LocalDate getApprovedStartDate() {
		return approvedStartDate;
	}

	public void setApprovedStartDate(LocalDate approvedStartDate) {
		this.approvedStartDate = approvedStartDate;
	}

	public LocalDate getApprovedEndDate() {
		return approvedEndDate;
	}

	public void setApprovedEndDate(LocalDate approvedEndDate) {
		this.approvedEndDate = approvedEndDate;
	}

	public List<Integer> getRemoveAttendeeRows() {
		return removeAttendeeRows;
	}

	public void setRemoveAttendeeRows(List<Integer> removeAttendeeRows) {
		this.removeAttendeeRows = removeAttendeeRows;
	}

	public List<FileDto> getSupportingDocs() {
		return supportingDocs;
	}

	public void setSupportingDocs(List<FileDto> supportingDocs) {
		this.supportingDocs = supportingDocs;
	}

	public List<Integer> getToDeleteSupportingDocs() {
		return toDeleteSupportingDocs;
	}

	public void setToDeleteSupportingDocs(List<Integer> toDeleteSupportingDocs) {
		this.toDeleteSupportingDocs = toDeleteSupportingDocs;
	}

}
