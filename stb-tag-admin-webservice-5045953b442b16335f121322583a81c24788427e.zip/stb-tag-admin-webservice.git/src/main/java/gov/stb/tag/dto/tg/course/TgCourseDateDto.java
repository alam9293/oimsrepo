package gov.stb.tag.dto.tg.course;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseDateDto extends EntityDto {

	@MapProjection(path = "attendedDate")
	private LocalDate attendedDate;

	@MapProjection(path = "attendedEndDate")
	private LocalDate attendedEndDate;

	public TgCourseDateDto() {

	}

	public LocalDate getAttendedDate() {
		return attendedDate;
	}

	public void setAttendedDate(LocalDate attendedDate) {
		this.attendedDate = attendedDate;
	}

	public LocalDate getAttendedEndDate() {
		return attendedEndDate;
	}

	public void setAttendedEndDate(LocalDate attendedEndDate) {
		this.attendedEndDate = attendedEndDate;
	}

}
