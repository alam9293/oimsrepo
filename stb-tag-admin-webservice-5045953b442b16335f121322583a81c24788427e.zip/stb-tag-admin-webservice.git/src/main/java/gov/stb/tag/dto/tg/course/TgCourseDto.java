package gov.stb.tag.dto.tg.course;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.TgCourseSubsidyDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgCourseCreation;
import gov.stb.tag.model.TgCourseSubsidy;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseDto extends EntityDto {

	@MapProjection(path = "code")
	private String code;

	@MapProjection(path = "type.code")
	private String typeCode;

	@MapProjection(path = "type.label")
	private String typeLabel;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "approvedStartDate")
	private LocalDate approvedStartDate;

	@MapProjection(path = "approvedEndDate")
	private LocalDate approvedEndDate;

	@MapProjection(path = "Category.code")
	private String categoryCode;

	@MapProjection(path = "Category.label")
	private String categoryLabel;

	@MapProjection(path = "language.code")
	private String languageCode;

	@MapProjection(path = "language.label")
	private String languageLabel;

	@MapProjection(path = "noOfHours")
	private BigDecimal noOfHours;

	@MapProjection(path = "tgTrainingProvider.id")
	private Integer tgTrainingProviderId;

	@MapProjection(path = "tgTrainingProvider.name")
	private String tgTrainingProviderName;

	@MapProjection(path = "tgTrainingProvider.contactNo")
	private String contactNo;

	@MapProjection(path = "tgTrainingProvider.email")
	private String email;

	@MapProjection(path = "tgTrainingProvider.signUpLink")
	private String signUpLink;

	@MapProjection(path = "ssgCourseCode")
	private String ssgCourseCode;

	@MapProjection(path = "objective")
	private String objective;

	@MapProjection(path = "outline")
	private String outline;

	@MapProjection(path = "classroomHrs")
	private BigDecimal classroomHrs;

	@MapProjection(path = "outOfClassroomHrs")
	private BigDecimal outOfClassroomHrs;

	@MapProjection(path = "courseFee")
	private BigDecimal courseFee;

	@MapProjection(path = "courseFeeNote")
	private String courseFeeNote;

	@MapProjection(path = "parentTgCourse.code")
	private String parentCourseCode;

	private List<TgCourseSubsidyDto> subsidies;

	private List<TgCourseDateDto> courseDates;

	private Boolean canBeRenewed;

	public TgCourseDto() {

	}

	public static void buildFromTgCourseCreation(TgCourseCreation tgCourseCreation, TgCourseDto dto, Cache cache) {
		dto.setName(tgCourseCreation.getName());
		dto.setCategoryCode(tgCourseCreation.getCategory().getCode());
		dto.setCategoryLabel(cache.getLabel(tgCourseCreation.getCategory(), false));
		dto.setClassroomHrs(tgCourseCreation.getClassroomHrs());
		dto.setLanguageCode(tgCourseCreation.getLanguage().getCode());
		dto.setLanguageLabel(cache.getLabel(tgCourseCreation.getLanguage(), false));
		dto.setNoOfHours(tgCourseCreation.getNoOfHours());
		dto.setObjective(tgCourseCreation.getObjective());
		dto.setOutline(tgCourseCreation.getOutline());
		dto.setOutOfClassroomHrs(tgCourseCreation.getOutOfClassroomHrs());
		dto.setSsgCourseCode(tgCourseCreation.getSsgCourseCode());
		dto.setTgTrainingProviderId(tgCourseCreation.getTgTrainingProvider().getId());
		dto.setTgTrainingProviderName(tgCourseCreation.getTgTrainingProvider().getName());
		dto.setCourseFee(tgCourseCreation.getCourseFee());
		dto.setCourseFeeNote(tgCourseCreation.getCourseFeeNote());

		List<TgCourseSubsidyDto> subsidyDtoList = new LinkedList<TgCourseSubsidyDto>();
		if (tgCourseCreation.getTgCourseSubsidies() != null && !tgCourseCreation.getTgCourseSubsidies().isEmpty()) {
			for (TgCourseSubsidy subsidy : tgCourseCreation.getTgCourseSubsidies()) {
				subsidyDtoList.add(new TgCourseSubsidyDto(subsidy));
			}
		}
		dto.setSubsidies(subsidyDtoList);

	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getApprovedStartDate() {
		return approvedStartDate;
	}

	public void setApprovedStartDate(LocalDate approvedStartDate) {
		this.approvedStartDate = approvedStartDate;
	}

	public LocalDate getApprovedEndDate() {
		return approvedEndDate;
	}

	public void setApprovedEndDate(LocalDate approvedEndDate) {
		this.approvedEndDate = approvedEndDate;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCategoryLabel() {
		return categoryLabel;
	}

	public void setCategoryLabel(String categoryLabel) {
		this.categoryLabel = categoryLabel;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public Integer getTgTrainingProviderId() {
		return tgTrainingProviderId;
	}

	public void setTgTrainingProviderId(Integer tgTrainingProviderId) {
		this.tgTrainingProviderId = tgTrainingProviderId;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLanguageLabel() {
		return languageLabel;
	}

	public void setLanguageLabel(String languageLabel) {
		this.languageLabel = languageLabel;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public String getTgTrainingProviderName() {
		return tgTrainingProviderName;
	}

	public void setTgTrainingProviderName(String tgTrainingProviderName) {
		this.tgTrainingProviderName = tgTrainingProviderName;
	}

	public String getSsgCourseCode() {
		return ssgCourseCode;
	}

	public void setSsgCourseCode(String ssgCourseCode) {
		this.ssgCourseCode = ssgCourseCode;
	}

	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public String getOutline() {
		return outline;
	}

	public void setOutline(String outline) {
		this.outline = outline;
	}

	public BigDecimal getClassroomHrs() {
		return classroomHrs;
	}

	public void setClassroomHrs(BigDecimal classroomHrs) {
		this.classroomHrs = classroomHrs;
	}

	public BigDecimal getOutOfClassroomHrs() {
		return outOfClassroomHrs;
	}

	public void setOutOfClassroomHrs(BigDecimal outOfClassroomHrs) {
		this.outOfClassroomHrs = outOfClassroomHrs;
	}

	public BigDecimal getCourseFee() {
		return courseFee;
	}

	public void setCourseFee(BigDecimal courseFee) {
		this.courseFee = courseFee;
	}

	public String getCourseFeeNote() {
		return courseFeeNote;
	}

	public void setCourseFeeNote(String courseFeeNote) {
		this.courseFeeNote = courseFeeNote;
	}

	public List<TgCourseSubsidyDto> getSubsidies() {
		return subsidies;
	}

	public void setSubsidies(List<TgCourseSubsidyDto> subsidies) {
		this.subsidies = subsidies;
	}

	public List<TgCourseDateDto> getCourseDates() {
		return courseDates;
	}

	public void setCourseDates(List<TgCourseDateDto> courseDates) {
		this.courseDates = courseDates;
	}

	public Boolean getCanBeRenewed() {
		return canBeRenewed;
	}

	public void setCanBeRenewed(Boolean canBeRenewed) {
		this.canBeRenewed = canBeRenewed;
	}

	public String getSignUpLink() {
		return signUpLink;
	}

	public void setSignUpLink(String signUpLink) {
		this.signUpLink = signUpLink;
	}

	public String getParentCourseCode() {
		return parentCourseCode;
	}

	public void setParentCourseCode(String parentCourseCode) {
		this.parentCourseCode = parentCourseCode;
	}

}
