package gov.stb.tag.dto.tg.course;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseItemDto {

	@MapProjection(path = "code")
	private String code;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "approvedStartDate")
	private LocalDate approvedStartDate;

	@MapProjection(path = "approvedEndDate")
	private LocalDate approvedEndDate;

	@MapProjection(path = "Category.label")
	private String category;

	@MapProjection(path = "language.label")
	private String language;

	@MapProjection(path = "noOfHours")
	private BigDecimal noOfHours;

	@MapProjection(path = "type.label")
	private String type;

	@MapProjection(path = "tgTrainingProvider.id")
	private Integer trainingProviderId;

	@MapProjection(path = "tgTrainingProvider.name")
	private String trainingProviderName;

	public TgCourseItemDto() {

	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getApprovedStartDate() {
		return approvedStartDate;
	}

	public void setApprovedStartDate(LocalDate approvedStartDate) {
		this.approvedStartDate = approvedStartDate;
	}

	public LocalDate getApprovedEndDate() {
		return approvedEndDate;
	}

	public void setApprovedEndDate(LocalDate approvedEndDate) {
		this.approvedEndDate = approvedEndDate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getTrainingProviderId() {
		return trainingProviderId;
	}

	public void setTrainingProviderId(Integer trainingProviderId) {
		this.trainingProviderId = trainingProviderId;
	}

	public String getTrainingProviderName() {
		return trainingProviderName;
	}

	public void setTrainingProviderName(String trainingProviderName) {
		this.trainingProviderName = trainingProviderName;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

}
