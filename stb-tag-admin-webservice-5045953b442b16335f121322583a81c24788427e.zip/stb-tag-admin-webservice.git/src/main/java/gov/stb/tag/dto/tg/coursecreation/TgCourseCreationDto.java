package gov.stb.tag.dto.tg.coursecreation;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;

import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.tg.application.TgApplicationDto;
import gov.stb.tag.dto.tg.course.TgCourseDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.TgCourseHelper;
import gov.stb.tag.model.TgCourseCreation;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseCreationDto extends TgApplicationDto {

	private Integer id;
	private TgCourseDto tgCourse;
	private String trainers;
	// private String appropriateLevel;
	private String assessment;
	private String synopsis;
	private List<FileDto> docs;

	public TgCourseCreationDto() {

	}

	public static void buildFromTgCourseCreation(TgCourseCreation tgCourseCreation, TgCourseCreationDto dto, Cache cache, ApplicationHelper appHelper, TgCourseHelper tgCourseHelper,
			FileHelper fileHelper) {
		dto.buildFromApplication(cache, appHelper, tgCourseCreation.getApplication(), dto);
		dto.setId(tgCourseCreation.getId());
		// dto.setAppropriateLevel(tgCourseCreation.getAppropriateLevel());
		dto.setAssessment(tgCourseCreation.getAssessment());
		dto.setSynopsis(tgCourseCreation.getSynopsis());
		dto.setTrainers(tgCourseCreation.getTrainers());
		TgCourseDto tgCourseDto = new TgCourseDto();
		TgCourseDto.buildFromTgCourseCreation(tgCourseCreation, tgCourseDto, cache);
		dto.setTgCourse(tgCourseDto);
		dto.setDocs(Lists.newArrayList());
		tgCourseCreation.getApplication().getApplicationFiles().forEach(appFile -> {
			dto.getDocs().add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
		});
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TgCourseDto getTgCourse() {
		return tgCourse;
	}

	public void setTgCourse(TgCourseDto tgCourse) {
		this.tgCourse = tgCourse;
	}

	public List<FileDto> getDocs() {
		return docs;
	}

	public void setDocs(List<FileDto> docs) {
		this.docs = docs;
	}

	// public String getAppropriateLevel() {
	// return appropriateLevel;
	// }
	//
	// public void setAppropriateLevel(String appropriateLevel) {
	// this.appropriateLevel = appropriateLevel;
	// }

	public String getAssessment() {
		return assessment;
	}

	public void setAssessment(String assessment) {
		this.assessment = assessment;
	}

	public String getSynopsis() {
		return synopsis;
	}

	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	public String getTrainers() {
		return trainers;
	}

	public void setTrainers(String trainers) {
		this.trainers = trainers;
	}

}
