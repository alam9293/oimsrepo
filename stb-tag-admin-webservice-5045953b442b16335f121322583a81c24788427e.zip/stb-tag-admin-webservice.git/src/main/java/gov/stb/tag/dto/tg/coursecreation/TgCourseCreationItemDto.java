package gov.stb.tag.dto.tg.coursecreation;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgCourseCreation;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseCreationItemDto extends SearchDto {

	@MapProjection(path = "id")
	private Integer courseCreationId;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "application.submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "application.lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "application.lastAction.status.label")
	private String status;

	@MapProjection(path = "application.id")
	private Integer applicationId;

	@MapProjection(path = "application.applicationNo")
	private String applicationNo;

	@MapProjection(path = "application.assignee.name")
	private String assignedOfficer;

	@MapProjection(path = "tgTrainingProvider.name")
	private String tgTrainingProviderName;

	public TgCourseCreationItemDto() {

	}

	public static TgCourseCreationItemDto buildFromLicenceCreation(Cache cache, TgCourseCreation tcc) {
		var tccDto = new TgCourseCreationItemDto();

		tccDto.setCourseCreationId(tcc.getId());
		tccDto.setName(tcc.getName());
		tccDto.setTgTrainingProviderName(tcc.getTgTrainingProvider().getName());

		var application = tcc.getApplication();
		tccDto.setStatus(cache.getLabel(application.getLastAction().getStatus(), true));
		tccDto.setSubmissionDate(application.getSubmissionDate());
		tccDto.setApplicationNo(application.getApplicationNo());

		return tccDto;

	}

	public Integer getCourseCreationId() {
		return courseCreationId;
	}

	public void setCourseCreationId(Integer courseCreationId) {
		this.courseCreationId = courseCreationId;
	}

	public String getTgTrainingProviderName() {
		return tgTrainingProviderName;
	}

	public void setTgTrainingProviderName(String tgTrainingProviderName) {
		this.tgTrainingProviderName = tgTrainingProviderName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

}
