package gov.stb.tag.dto.tg.coursecriteria;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.EntityDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseCriteriaDto extends EntityDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "criteria")
	private String criteria;

	@MapProjection(path = "isActive")
	private Boolean isActive;

	@MapProjection(path = "ordinal")
	protected Integer ordinal;

	@MapProjection(path = "weightage1")
	private BigDecimal weightage1;

	@MapProjection(path = "weightage2")
	private BigDecimal weightage2;

	@MapProjection(path = "weightage3")
	private BigDecimal weightage3;

	@MapProjection(path = "weightage4")
	private BigDecimal weightage4;

	@MapProjection(path = "weightage5")
	private BigDecimal weightage5;

	public TgCourseCriteriaDto() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public BigDecimal getWeightage1() {
		return weightage1;
	}

	public void setWeightage1(BigDecimal weightage1) {
		this.weightage1 = weightage1;
	}

	public BigDecimal getWeightage2() {
		return weightage2;
	}

	public void setWeightage2(BigDecimal weightage2) {
		this.weightage2 = weightage2;
	}

	public BigDecimal getWeightage3() {
		return weightage3;
	}

	public void setWeightage3(BigDecimal weightage3) {
		this.weightage3 = weightage3;
	}

	public BigDecimal getWeightage4() {
		return weightage4;
	}

	public void setWeightage4(BigDecimal weightage4) {
		this.weightage4 = weightage4;
	}

	public BigDecimal getWeightage5() {
		return weightage5;
	}

	public void setWeightage5(BigDecimal weightage5) {
		this.weightage5 = weightage5;
	}
}
