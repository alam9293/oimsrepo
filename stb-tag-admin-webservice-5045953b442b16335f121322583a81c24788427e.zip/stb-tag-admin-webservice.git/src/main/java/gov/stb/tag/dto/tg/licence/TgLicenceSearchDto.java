package gov.stb.tag.dto.tg.licence;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceSearchDto extends SearchDto {

	private String licenceNo;
	private String name;
	private String language;
	private String licenceType;
	private LocalDate expiryDate;
	private String licenceStatus;
	private LocalDate workPassExpiryDateFrom;
	private LocalDate workPassExpiryDateTo;
	private Boolean workPassHolder;
	private String[] residentialStatuses;

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(String licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public LocalDate getWorkPassExpiryDateFrom() {
		return workPassExpiryDateFrom;
	}

	public void setWorkPassExpiryDateFrom(LocalDate workPassExpiryDateFrom) {
		this.workPassExpiryDateFrom = workPassExpiryDateFrom;
	}

	public LocalDate getWorkPassExpiryDateTo() {
		return workPassExpiryDateTo;
	}

	public void setWorkPassExpiryDateTo(LocalDate workPassExpiryDateTo) {
		this.workPassExpiryDateTo = workPassExpiryDateTo;
	}

	public Boolean getWorkPassHolder() {
		return workPassHolder;
	}

	public void setWorkPassHolder(Boolean workPassHolder) {
		this.workPassHolder = workPassHolder;
	}

	public String[] getResidentialStatuses() {
		return residentialStatuses;
	}

	public void setResidentialStatuses(String[] residentialStatuses) {
		this.residentialStatuses = residentialStatuses;
	}
}
