package gov.stb.tag.dto.tg.licencecancellation;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.tg.application.TgApplicationItemDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.TgLicenceCancellation;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceCancellationDto extends TgApplicationItemDto {

	private Integer id; // tgLicenceCancellationId
	private String reason;
	private boolean allowCancel = true;

	public TgLicenceCancellationDto() {

	}

	public TgLicenceCancellationDto buildFromTgLicenceCancellation(Cache cache, TgLicenceCancellation tlc, ApplicationHelper appHelper, FileHelper fileHelper) {

		TgLicenceCancellationDto dto = new TgLicenceCancellationDto();
		var application = tlc.getApplication();
		dto = dto.buildFromApplication(cache, application, dto, appHelper, fileHelper);
		dto.setId(tlc.getId());
		dto.setReason(tlc.getReason());

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public boolean getAllowCancel() {
		return allowCancel;
	}

	public void setAllowCancel(boolean allowCancel) {
		this.allowCancel = allowCancel;
	}

}
