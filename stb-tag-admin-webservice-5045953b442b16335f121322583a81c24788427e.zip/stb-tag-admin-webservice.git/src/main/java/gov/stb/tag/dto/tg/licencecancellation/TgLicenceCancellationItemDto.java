package gov.stb.tag.dto.tg.licencecancellation;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgLicenceCancellation;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceCancellationItemDto extends SearchDto {

	private Integer licenceCancellationId;
	private String nric;
	private String name;
	private String licenceNo;
	private LocalDate expiryDate;
	private LocalDateTime submissionDate;

	public TgLicenceCancellationItemDto() {

	}

	public static TgLicenceCancellationItemDto buildFromLicenceCancellation(Cache cache, TgLicenceCancellation tlc) {
		var dto = new TgLicenceCancellationItemDto();
		dto.setLicenceCancellationId(tlc.getId());

		var application = tlc.getApplication();
		var licence = application.getLicence();
		var tg = licence.getTouristGuide();
		dto.setNric(tg.getUin());
		dto.setName(tg.getName());
		dto.setLicenceNo(licence.getLicenceNo());
		dto.setExpiryDate(licence.getExpiryDate());
		dto.setSubmissionDate(application.getSubmissionDate());

		return dto;
	}

	public Integer getLicenceCancellationId() {
		return licenceCancellationId;
	}

	public void setLicenceCancellationId(Integer licenceCancellationId) {
		this.licenceCancellationId = licenceCancellationId;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

}
