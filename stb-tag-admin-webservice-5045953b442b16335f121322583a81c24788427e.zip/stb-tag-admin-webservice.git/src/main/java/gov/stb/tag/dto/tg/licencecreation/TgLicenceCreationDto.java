package gov.stb.tag.dto.tg.licencecreation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Objects;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.tg.application.TgApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.CpfHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TgLicenceCreation;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.util.DateUtil;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceCreationDto extends TgApplicationDto {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private boolean isWorkPassHolder;

	private String name;
	private String aliasName;
	private LocalDate dob;
	private String nric;
	private String nationality;
	private String salutation;
	private String sex;
	private String maritalStatus;
	private String race;
	private String birthCountry;
	private String residentialStatus;
	private String highestEduLevel;
	private String mobileNo;
	private String emailAddress;
	private String employerName;
	private String occupation;
	private String occupationOther;
	private String workPassType;
	private LocalDate workpassExpiryDate;

	private boolean isSameAddress;
	private ListableDto regType;
	private ListableDto optType;

	private String regStreet;
	private String regBuilding;
	private String regBlock;
	private String regFloor;
	private String regUnit;
	private String regPostal;
	private String registeredAddress;

	private String optStreet;
	private String optBuilding;
	private String optBlock;
	private String optFloor;
	private String optUnit;
	private String optPostal;
	private String operatingAddress;

	private String regForeignLine1;
	private String regForeignLine2;
	private String regForeignLine3;

	private String optForeignLine1;
	private String optForeignLine2;
	private String optForeignLine3;

	private ListableDto status;
	private String statusRemark;
	private String guidingLanguage;
	private String areaSpecification;
	private String licenceType;
	private Integer id; // licenceCreationId
	private FileDto photo;
	private List<FileDto> otherSupportDocs;
	private List<WorkflowActionDto> workflowActions;

	private boolean convictChecked;
	// private LocalDateTime offenceDeclaredDate;
	private LocalDate offenceDate;
	private String offenceType;
	private String enforcementOutcome;

	private boolean hasConsentMobileNo;
	private boolean hasConsentEmailAddress;

	private Integer paymentFee;
	private String billRefNo;
	private Boolean isPaymentSuccess;
	private Boolean isWaived = false;

	private boolean isDraft;

	private boolean isAddrSame;

	private Boolean isMyInfoPopulated;

	// initial values for comparision
	private String initialNric;
	private String initialName;

	// Payment
	private PaymentRequestDto appFee;

	private Integer applicationId;
	private String applicationNo;
	private String applicationType;
	private LocalDateTime submissionDate;

	private boolean isFinalApproval;
	private boolean isInLowestStep;
	private ListableDto cpfStatus;

	private String tierCode;

	public TgLicenceCreationDto() {

	}

	public static TgLicenceCreationDto buildSubmissionDetails(CacheHelper cache, PaymentHelper paymentHelper, TgLicenceCreation tlc) {
		TgLicenceCreationDto dto = new TgLicenceCreationDto();
		dto.setId(tlc.getId());

		var application = tlc.getApplication();
		dto.setApplicationId(application.getId());
		dto.setApplicationNo(application.getApplicationNo());
		dto.setIsDraft(application.getIsDraft());

		// Payment
		dto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_CREATION));
		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tlc.getAppFeeBillRefNo()), false));

		return dto;
	}

	public TgLicenceCreationDto(CacheHelper cache, TgLicenceCreation tlc, TgCandidate tc, ApplicationHelper appHelper, PaymentHelper paymentHelper, FileHelper fileHelper, UserHelper userHelper,
			LicenceHelper licenceHelper, CpfHelper cpfHelper, boolean displayForInternet) {

		TgCandidateResult lastCandidateResult = tc.getLastCandidateResult();
		if (tlc == null) {
			this.isWorkPassHolder = userHelper.checkWorkPassHolder(tc.getUin());
			this.nric = tc.getUin();

			if (lastCandidateResult != null) {
				this.name = lastCandidateResult.getName();
				this.emailAddress = lastCandidateResult.getEmail();
			}
		} else {
			this.name = tlc.getName();
			this.dob = tlc.getDob();
			this.nric = tlc.getUin();
			this.mobileNo = tlc.getMobileNo();
			this.emailAddress = tlc.getEmailAddress();
			this.employerName = tlc.getEmployerName();
			this.occupationOther = tlc.getOccupationOther();
			this.workpassExpiryDate = tlc.getWorkpassExpiryDate();
			this.aliasName = tlc.getAliasName();
			this.isSameAddress = Objects.equal(tlc.getRegisteredAddress(), tlc.getOperatingAddress());
			this.registeredAddress = tlc.getRegisteredAddress() != null ? tlc.getRegisteredAddress().getAddressDisplay() : null;
			this.operatingAddress = tlc.getOperatingAddress() != null ? tlc.getOperatingAddress().getAddressDisplay() : null;
			this.id = tlc.getId();
			this.isMyInfoPopulated = tlc.isMyInfoPopulated();
			this.offenceDate = tlc.getOffenceDate();
			this.offenceType = tlc.getOffenceType();
			this.enforcementOutcome = tlc.getEnforcementOutcome();
			this.hasConsentEmailAddress = tlc.hasConsentEmailAddress();
			this.hasConsentMobileNo = tlc.hasConsentMobileNo();
			this.isWorkPassHolder = userHelper.checkWorkPassHolder(tlc.getUin());

			// if displayForInternet is TRUE, get code instead of label
			if (displayForInternet) {
				this.nationality = tlc.getNationality() != null ? tlc.getNationality().getCode() : null;
				this.salutation = tlc.getSalutation() != null ? tlc.getSalutation().getCode() : null;
				this.sex = tlc.getSex() != null ? tlc.getSex().getCode() : null;
				this.maritalStatus = tlc.getMaritalStatus() != null ? tlc.getMaritalStatus().getCode() : null;
				this.race = tlc.getRace() != null ? tlc.getRace().getCode() : null;
				this.birthCountry = tlc.getBirthCountry() != null ? tlc.getBirthCountry().getCode() : null;
				this.residentialStatus = tlc.getResidentialStatus() != null ? tlc.getResidentialStatus().getCode() : null;
				this.highestEduLevel = tlc.getHighestEduLevel() != null ? tlc.getHighestEduLevel().getCode() : null;
				this.occupation = tlc.getOccupation() != null ? tlc.getOccupation().getCode() : null;
				this.workPassType = tlc.getWorkPassType() != null ? tlc.getWorkPassType().getCode() : null;
			} else {
				this.nationality = cache.getLabel(tlc.getNationality(), true);
				this.salutation = cache.getLabel(tlc.getSalutation(), true);
				this.sex = cache.getLabel(tlc.getSex(), true);
				this.maritalStatus = tlc.getMaritalStatus() != null ? cache.getLabel(tlc.getMaritalStatus(), true) : null;
				this.race = tlc.getRace() != null ? cache.getLabel(tlc.getRace(), true) : null;
				this.birthCountry = cache.getLabel(tlc.getBirthCountry(), true);
				this.residentialStatus = cache.getLabel(tlc.getResidentialStatus(), true);
				this.highestEduLevel = cache.getLabel(tlc.getHighestEduLevel(), true);
				this.occupation = cache.getLabel(tlc.getOccupation(), true);
				this.workPassType = tlc.getWorkPassType() != null ? cache.getLabel(tlc.getWorkPassType(), true) : null;
			}

			var regAddr = tlc.getRegisteredAddress();
			var optAddr = tlc.getOperatingAddress();

			if (regAddr != null) {
				this.regType = new ListableDto(regAddr.getAddressType());
				this.regStreet = regAddr.getStreet();
				this.regBuilding = regAddr.getBuilding();
				this.regBlock = regAddr.getBlock();
				this.regFloor = regAddr.getFloor();
				this.regUnit = regAddr.getUnit();
				this.regPostal = regAddr.getPostal();
				this.regForeignLine1 = regAddr.getForeignLine1();
				this.regForeignLine2 = regAddr.getForeignLine2();
				this.regForeignLine3 = regAddr.getForeignLine3();
			}

			if (optAddr != null) {
				if (regAddr != null && regAddr.equals(optAddr)) {
					this.isAddrSame = true;
				} else {
					this.optType = new ListableDto(optAddr.getAddressType());
					this.optStreet = optAddr.getStreet();
					this.optBuilding = optAddr.getBuilding();
					this.optBlock = optAddr.getBlock();
					this.optFloor = optAddr.getFloor();
					this.optUnit = optAddr.getUnit();
					this.optPostal = optAddr.getPostal();
					this.optForeignLine1 = optAddr.getForeignLine1();
					this.optForeignLine2 = optAddr.getForeignLine2();
					this.optForeignLine3 = optAddr.getForeignLine3();
				}
			}

			var tlcApp = tlc.getApplication();
			this.buildFromApplication(cache, appHelper, tlcApp, this);
			this.isDraft = tlcApp.getIsDraft();
			this.applicationId = tlcApp.getId();
			this.applicationNo = tlcApp.getApplicationNo();
			this.applicationType = tlcApp.getType().getCode();
			this.submissionDate = tlcApp.getSubmissionDate();
			this.isFinalApproval = appHelper.isFinalApproval(tlcApp);
			this.isInLowestStep = appHelper.isInLowestStep(null, tlcApp);
			this.applicationNo = tlcApp.getApplicationNo();
			this.submissionDate = tlcApp.getSubmissionDate();
			var lastAction = tlcApp.getLastAction();
			if (lastAction != null) {
				var lastStatus = lastAction.getStatus();
				this.status = new ListableDto(lastStatus.getCode(), cache.getLabel(lastStatus, displayForInternet));
				this.statusRemark = lastAction.getExternalRemarks();
			}

			var appFiles = tlcApp.getApplicationFiles();
			List<FileDto> otherDocuments = new ArrayList<FileDto>();
			for (ApplicationFile appFile : appFiles) {
				if (!appFile.getIsDeleted()) {
					if (appFile.getDocumentType().getCode().equals(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO)) {
						this.photo = FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper);
					} else {
						otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
					}
				}
			}

			this.otherSupportDocs = otherDocuments;

			// check whether payment is made successfully
			PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(tlc.getAppFeeBillRefNo());
			this.isPaymentSuccess = false;
			if (paymentRequest != null) {
				this.appFee = new PaymentRequestDto(cache, paymentRequest, false);

				PaymentTxn paymentTxn = paymentRequest.getLastTxn();
				if ((paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))
						|| paymentRequest.getStatus().equals(cache.getStatus(Codes.Statuses.PAYREQ_WAIVED))) {
					this.isPaymentSuccess = true;
				}
			}

		}

		if (lastCandidateResult.isDirectIssuance() != null && lastCandidateResult.isDirectIssuance()) {
			this.guidingLanguage = lastCandidateResult.getDiGuidingLanguagesWithComma(cache);
		} else {
			this.guidingLanguage = lastCandidateResult.getGuidingLanguage() != null ? lastCandidateResult.getGuidingLanguage().getLabel() : "";
		}

		this.paymentFee = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_RENEWAL_FEE).getValue());

		this.areaSpecification = lastCandidateResult.getSpecializedArea() != null ? lastCandidateResult.getSpecializedArea().getLabel() : "";
		this.licenceType = lastCandidateResult.getTier() != null ? lastCandidateResult.getTier().getLabel() : "";
		this.initialName = lastCandidateResult.getName();
		this.initialNric = lastCandidateResult.getTgCandidate().getUin();

		if (!this.isWorkPassHolder) {
			Status cpfStatus = cpfHelper.checkMedisavePaymentStatus(this.nric);
			this.cpfStatus = new ListableDto(cpfStatus.getCode(), cache.getLabel(cpfStatus, false));
		}

		this.isWaived = paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_CREATION);
		this.tierCode = lastCandidateResult.getTier().getCode();
		if (lastCandidateResult.getTier() != null && lastCandidateResult.getTier().getCode().equals(Codes.Types.TG_TIER_AREA)) {
			this.isWaived = false;
		}
	}

	public boolean getIsWorkPassHolder() {
		return isWorkPassHolder;
	}

	public void setIsWorkPassHolder(boolean isWorkPassHolder) {
		this.isWorkPassHolder = isWorkPassHolder;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getApplicationNo() {
		return applicationNo;
	}

	@Override
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	@Override
	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	@Override
	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(String birthCountry) {
		this.birthCountry = birthCountry;
	}

	public String getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public String getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(String highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOccupationOther() {
		return occupationOther;
	}

	public void setOccupationOther(String occupationOther) {
		this.occupationOther = occupationOther;
	}

	public String getWorkPassType() {
		return workPassType;
	}

	public void setWorkPassType(String workPassType) {
		this.workPassType = workPassType;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getRegStreet() {
		return regStreet;
	}

	public void setRegStreet(String regStreet) {
		this.regStreet = regStreet;
	}

	public String getRegBuilding() {
		return regBuilding;
	}

	public void setRegBuilding(String regBuilding) {
		this.regBuilding = regBuilding;
	}

	public String getRegBlock() {
		return regBlock;
	}

	public void setRegBlock(String regBlock) {
		this.regBlock = regBlock;
	}

	public String getRegFloor() {
		return regFloor;
	}

	public void setRegFloor(String regFloor) {
		this.regFloor = regFloor;
	}

	public String getRegUnit() {
		return regUnit;
	}

	public void setRegUnit(String regUnit) {
		this.regUnit = regUnit;
	}

	public String getRegPostal() {
		return regPostal;
	}

	public void setRegPostal(String regPostal) {
		this.regPostal = regPostal;
	}

	public String getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(String registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public String getOptStreet() {
		return optStreet;
	}

	public void setOptStreet(String optStreet) {
		this.optStreet = optStreet;
	}

	public String getOptBuilding() {
		return optBuilding;
	}

	public void setOptBuilding(String optBuilding) {
		this.optBuilding = optBuilding;
	}

	public String getOptBlock() {
		return optBlock;
	}

	public void setOptBlock(String optBlock) {
		this.optBlock = optBlock;
	}

	public String getOptFloor() {
		return optFloor;
	}

	public void setOptFloor(String optFloor) {
		this.optFloor = optFloor;
	}

	public String getOptUnit() {
		return optUnit;
	}

	public void setOptUnit(String optUnit) {
		this.optUnit = optUnit;
	}

	public String getOptPostal() {
		return optPostal;
	}

	public void setOptPostal(String optPostal) {
		this.optPostal = optPostal;
	}

	public String getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(String operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public String getRegForeignLine1() {
		return regForeignLine1;
	}

	public void setRegForeignLine1(String regForeignLine1) {
		this.regForeignLine1 = regForeignLine1;
	}

	public String getRegForeignLine2() {
		return regForeignLine2;
	}

	public void setRegForeignLine2(String regForeignLine2) {
		this.regForeignLine2 = regForeignLine2;
	}

	public String getRegForeignLine3() {
		return regForeignLine3;
	}

	public void setRegForeignLine3(String regForeignLine3) {
		this.regForeignLine3 = regForeignLine3;
	}

	public String getOptForeignLine1() {
		return optForeignLine1;
	}

	public void setOptForeignLine1(String optForeignLine1) {
		this.optForeignLine1 = optForeignLine1;
	}

	public String getOptForeignLine2() {
		return optForeignLine2;
	}

	public void setOptForeignLine2(String optForeignLine2) {
		this.optForeignLine2 = optForeignLine2;
	}

	public String getOptForeignLine3() {
		return optForeignLine3;
	}

	public void setOptForeignLine3(String optForeignLine3) {
		this.optForeignLine3 = optForeignLine3;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(String guidingLanguage) {
		this.guidingLanguage = guidingLanguage;
	}

	@Override
	public String getAreaSpecification() {
		return areaSpecification;
	}

	@Override
	public void setAreaSpecification(String areaSpecification) {
		this.areaSpecification = areaSpecification;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public FileDto getPhoto() {
		return photo;
	}

	public void setPhoto(FileDto photo) {
		this.photo = photo;
	}

	public List<FileDto> getOtherSupportDocs() {
		return otherSupportDocs;
	}

	public void setOtherSupportDocs(List<FileDto> otherSupportDocs) {
		this.otherSupportDocs = otherSupportDocs;
	}

	public List<WorkflowActionDto> getWorkflowActions() {
		return workflowActions;
	}

	public void setWorkflowActions(List<WorkflowActionDto> workflowActions) {
		this.workflowActions = workflowActions;
	}

	public boolean isConvictChecked() {
		return convictChecked;
	}

	public void setConvictChecked(boolean convictChecked) {
		this.convictChecked = convictChecked;
	}

	public LocalDate getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDate offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public String getEnforcementOutcome() {
		return enforcementOutcome;
	}

	public void setEnforcementOutcome(String enforcementOutcome) {
		this.enforcementOutcome = enforcementOutcome;
	}

	public boolean getHasConsentMobileNo() {
		return hasConsentMobileNo;
	}

	public void setHasConsentMobileNo(boolean hasConsentMobileNo) {
		this.hasConsentMobileNo = hasConsentMobileNo;
	}

	public boolean getHasConsentEmailAddress() {
		return hasConsentEmailAddress;
	}

	public void setHasConsentEmailAddress(boolean hasConsentEmailAddress) {
		this.hasConsentEmailAddress = hasConsentEmailAddress;
	}

	public Integer getPaymentFee() {
		return paymentFee;
	}

	public void setPaymentFee(Integer paymentFee) {
		this.paymentFee = paymentFee;
	}

	@Override
	public String getBillRefNo() {
		return billRefNo;
	}

	@Override
	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(boolean isDraft) {
		this.isDraft = isDraft;
	}

	public boolean getIsAddrSame() {
		return isAddrSame;
	}

	public void setIsAddrSame(boolean isAddrSame) {
		this.isAddrSame = isAddrSame;
	}

	public String getStatusRemark() {
		return statusRemark;
	}

	public void setStatusRemark(String statusRemark) {
		this.statusRemark = statusRemark;
	}

	public LocalDate getWorkpassExpiryDate() {
		return workpassExpiryDate;
	}

	public void setWorkpassExpiryDate(LocalDate workpassExpiryDate) {
		this.workpassExpiryDate = workpassExpiryDate;
	}

	public Boolean isMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	@Override
	public Boolean isPaymentSuccess() {
		return isPaymentSuccess;
	}

	@Override
	public void setPaymentSuccess(Boolean isPaymentSuccess) {
		this.isPaymentSuccess = isPaymentSuccess;
	}

	public ListableDto getRegType() {
		return regType;
	}

	public void setRegType(ListableDto regType) {
		this.regType = regType;
	}

	public ListableDto getOptType() {
		return optType;
	}

	public void setOptType(ListableDto optType) {
		this.optType = optType;
	}

	public Boolean getIsPaymentSuccess() {
		return isPaymentSuccess;
	}

	public void setIsPaymentSuccess(Boolean isPaymentSuccess) {
		this.isPaymentSuccess = isPaymentSuccess;
	}

	public Boolean getIsMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setWorkPassHolder(boolean isWorkPassHolder) {
		this.isWorkPassHolder = isWorkPassHolder;
	}

	@Override
	public void setDraft(boolean isDraft) {
		this.isDraft = isDraft;
	}

	public void setAddrSame(boolean isAddrSame) {
		this.isAddrSame = isAddrSame;
	}

	public PaymentRequestDto getAppFee() {
		return appFee;
	}

	public void setAppFee(PaymentRequestDto appFee) {
		this.appFee = appFee;
	}

	@Override
	public Integer getApplicationId() {
		return applicationId;
	}

	@Override
	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	@Override
	public boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	@Override
	public void setIsFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	@Override
	public boolean getIsInLowestStep() {
		return isInLowestStep;
	}

	@Override
	public void setIsInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

	@Override
	public String getApplicationType() {
		return applicationType;
	}

	@Override
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getInitialNric() {
		return initialNric;
	}

	public void setInitialNric(String initialNric) {
		this.initialNric = initialNric;
	}

	public String getInitialName() {
		return initialName;
	}

	public void setInitialName(String initialName) {
		this.initialName = initialName;
	}

	public ListableDto getCpfStatus() {
		return cpfStatus;
	}

	public void setCpfStatus(ListableDto cpfStatus) {
		this.cpfStatus = cpfStatus;
	}

	public boolean isSameAddress() {
		return isSameAddress;
	}

	public void setSameAddress(boolean isSameAddress) {
		this.isSameAddress = isSameAddress;
	}

	public Boolean getIsWaived() {
		return isWaived;
	}

	public void setIsWaived(Boolean isWaived) {
		this.isWaived = isWaived;
	}

	public String getTierCode() {
		return tierCode;
	}

	public void setTierCode(String tierCode) {
		this.tierCode = tierCode;
	}

	/*
	 * Licence creation payment fee will be calculated based on formula below : Months between expiry date and exam date * prorated fee Day of the month will not affect the computation STB only look
	 * at the month (regardless it's first/mid/last of the month) eg, 15-may-2019 to 28-feb-2022, the total months to be considered will be may-2019 to feb-2022, which is 34 months
	 */
	private Integer calculatePaymentFee(CacheHelper cache, LicenceHelper licenceHelper, LocalDate examDt) {
		var expiryDt = licenceHelper.calculateExpiryDate(examDt);
		YearMonth startMonth = YearMonth.from(examDt);
		YearMonth endMonth = YearMonth.from(expiryDt);
		int totalMonths = (int) ChronoUnit.MONTHS.between(startMonth, endMonth) + 1;
		Integer proratedFeePerMonth = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_NEW_LICENCE_PRORATED_FEE).getValue());
		Integer computedFee = proratedFeePerMonth * totalMonths;

		logger.info("calculatePaymentFee(): proratedFeePerMonth: {},examDate: {}, expiryDate: {}, total-months: {}, computedFee: {}", proratedFeePerMonth, DateUtil.format(examDt),
				DateUtil.format(expiryDt), totalMonths, computedFee);
		return computedFee;
	}

	public static TgLicenceCreationDto buildCreationDeclationDto(CacheHelper cache, TgLicenceCreation licenceCreation) {
		TgLicenceCreationDto dto = new TgLicenceCreationDto();
		if (licenceCreation != null) {
			dto.setConvictChecked(licenceCreation.getOffenceDate() != null);

			dto.setOffenceDate(licenceCreation.getOffenceDate());
			dto.setOffenceType(licenceCreation.getOffenceType());
			dto.setEnforcementOutcome(licenceCreation.getEnforcementOutcome());

			TouristGuide tg = licenceCreation.getApplication().getLicence().getTouristGuide();

			dto.setHasConsentEmailAddress(licenceCreation.hasConsentEmailAddress() != null ? licenceCreation.hasConsentEmailAddress() : tg.hasConsentEmailAddress());
			dto.setHasConsentMobileNo(licenceCreation.hasConsentMobileNo() != null ? licenceCreation.hasConsentMobileNo() : tg.hasConsentMobileNo());
		}
		return dto;
	}
}
