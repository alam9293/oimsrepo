package gov.stb.tag.dto.tg.licenceprint;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicencePrintSearchDto extends SearchDto {

	private String licencePrintStatus;
	private boolean licenceSelected;
	private String applicationNo;
	private String applicationType;
	private String licenceNo;
	private String licenceType;
	private String name;
	private LocalDate dateSendVendor;
	private LocalDate pendingCollectionStartDate;
	private LocalDate pendingCollectionEndDate;

	public String getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(String licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}

	public boolean isLicenceSelected() {
		return licenceSelected;
	}

	public void setLicenceSelected(boolean licenceSelected) {
		this.licenceSelected = licenceSelected;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDateSendVendor() {
		return dateSendVendor;
	}

	public void setDateSendVendor(LocalDate dateSendVendor) {
		this.dateSendVendor = dateSendVendor;
	}

	public LocalDate getPendingCollectionStartDate() {
		return pendingCollectionStartDate;
	}

	public void setPendingCollectionStartDate(LocalDate pendingCollectionStartDate) {
		this.pendingCollectionStartDate = pendingCollectionStartDate;
	}

	public LocalDate getPendingCollectionEndDate() {
		return pendingCollectionEndDate;
	}

	public void setPendingCollectionEndDate(LocalDate pendingCollectionEndDate) {
		this.pendingCollectionEndDate = pendingCollectionEndDate;
	}

}
