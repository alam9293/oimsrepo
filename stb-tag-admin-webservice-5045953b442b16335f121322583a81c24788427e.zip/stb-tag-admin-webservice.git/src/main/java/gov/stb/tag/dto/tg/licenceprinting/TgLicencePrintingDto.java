package gov.stb.tag.dto.tg.licenceprinting;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Application;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicencePrintingDto extends EntityDto {

	private List<String> applicationNos;
	private ListableDto status;
	private LocalDate collectedDate;
	private LocalDate sendToVendorDate;
	private LocalDate pendingCollectionStartDate;
	private LocalDate pendingCollectionEndDate;

	public TgLicencePrintingDto() {

	}

	public static TgLicencePrintingDto buildLicencePrintingDetails(Cache cache, Application application) {
		TgLicencePrintingDto dto = new TgLicencePrintingDto();
		dto.setStatus(new ListableDto(application.getLicencePrintStatus().getCode(), cache.getLabel(application.getLicencePrintStatus(), true)));
		dto.setCollectedDate(application.getLicenceCollectedDate());
		dto.setSendToVendorDate(application.getSendToVendorDate());
		dto.setPendingCollectionStartDate(application.getPendingCollectionStartDate());
		dto.setPendingCollectionEndDate(application.getPendingCollectionEndDate());
		return dto;
	}

	public List<String> getApplicationNos() {
		return applicationNos;
	}

	public void setApplicationNos(List<String> applicationNos) {
		this.applicationNos = applicationNos;
	}

	public ListableDto getStatus() { return status; }

	public void setStatus(ListableDto status) { this.status = status; }

	public LocalDate getCollectedDate() {
		return collectedDate;
	}

	public void setCollectedDate(LocalDate collectedDate) {
		this.collectedDate = collectedDate;
	}

	public LocalDate getSendToVendorDate() {
		return sendToVendorDate;
	}

	public void setSendToVendorDate(LocalDate sendToVendorDate) {
		this.sendToVendorDate = sendToVendorDate;
	}

	public LocalDate getPendingCollectionStartDate() {
		return pendingCollectionStartDate;
	}

	public void setPendingCollectionStartDate(LocalDate pendingCollectionStartDate) {
		this.pendingCollectionStartDate = pendingCollectionStartDate;
	}

	public LocalDate getPendingCollectionEndDate() {
		return pendingCollectionEndDate;
	}

	public void setPendingCollectionEndDate(LocalDate pendingCollectionEndDate) {
		this.pendingCollectionEndDate = pendingCollectionEndDate;
	}

}
