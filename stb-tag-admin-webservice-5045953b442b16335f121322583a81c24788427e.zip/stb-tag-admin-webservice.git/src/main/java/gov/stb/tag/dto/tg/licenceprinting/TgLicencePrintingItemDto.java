package gov.stb.tag.dto.tg.licenceprinting;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicencePrintingItemDto extends SearchDto {

	private boolean licenceSelected;

	@MapProjection(path = "id")
	private Integer applicationId;

	@MapProjection(path = "applicationNo")
	private String applicationNo;

	@MapProjection(path = "type.label")
	private String applicationType;

	@MapProjection(path = "type.code")
	private String applicationTypeCode;

	@MapProjection(path = "licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "licence.tier.label")
	private String licenceType;

	@MapProjection(path = "licence.touristGuide.name")
	private String name;

	@MapProjection(path = "licencePrintStatus.code")
	private String printingStatusCode;

	@MapProjection(path = "licencePrintStatus.otherLabel")
	private String printingStatus;

	@MapProjection(path = "sendToVendorDate")
	private LocalDate dateSendVendor;

	@MapProjection(path = "pendingCollectionStartDate")
	private LocalDate pendingCollectionStartDate;

	@MapProjection(path = "pendingCollectionEndDate")
	private LocalDate pendingCollectionEndDate;

	public TgLicencePrintingItemDto() {

	}

	public boolean isLicenceSelected() {
		return licenceSelected;
	}

	public void setLicenceSelected(boolean licenceSelected) {
		this.licenceSelected = licenceSelected;
	}

	public Integer getApplicationId() { return applicationId; }

	public void setApplicationId(Integer applicationId) { this.applicationId = applicationId; }

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getApplicationTypeCode() { return applicationTypeCode; }

	public void setApplicationTypeCode(String applicationTypeCode) { this.applicationTypeCode = applicationTypeCode; }

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrintingStatusCode() {
		return printingStatusCode;
	}

	public void setPrintingStatusCode(String printingStatusCode) {
		this.printingStatusCode = printingStatusCode;
	}

	public String getPrintingStatus() {
		return printingStatus;
	}

	public void setPrintingStatus(String printingStatus) {
		this.printingStatus = printingStatus;
	}

	public LocalDate getDateSendVendor() {
		return dateSendVendor;
	}

	public void setDateSendVendor(LocalDate dateSendVendor) {
		this.dateSendVendor = dateSendVendor;
	}

	public LocalDate getPendingCollectionStartDate() {
		return pendingCollectionStartDate;
	}

	public void setPendingCollectionStartDate(LocalDate pendingCollectionStartDate) {
		this.pendingCollectionStartDate = pendingCollectionStartDate;
	}

	public LocalDate getPendingCollectionEndDate() {
		return pendingCollectionEndDate;
	}

	public void setPendingCollectionEndDate(LocalDate pendingCollectionEndDate) {
		this.pendingCollectionEndDate = pendingCollectionEndDate;
	}

}
