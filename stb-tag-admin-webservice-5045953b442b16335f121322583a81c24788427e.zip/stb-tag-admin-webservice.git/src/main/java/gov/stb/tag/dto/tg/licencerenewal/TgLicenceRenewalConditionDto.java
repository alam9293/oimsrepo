package gov.stb.tag.dto.tg.licencerenewal;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceRenewalConditionDto extends EntityDto {

	private String mrc;
	private String pdc;
	private String assignments;
	private String cpf;
	private String newPhoto;
	private String medicalReport;
	private String workPass;
	private String assessment;
	private Boolean isOpenForRenewal;

	public TgLicenceRenewalConditionDto() {

	}

	public String getMrc() {
		return mrc;
	}

	public void setMrc(String mrc) {
		this.mrc = mrc;
	}

	public String getPdc() {
		return pdc;
	}

	public void setPdc(String pdc) {
		this.pdc = pdc;
	}

	public String getAssignments() {
		return assignments;
	}

	public void setAssignments(String assignments) {
		this.assignments = assignments;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNewPhoto() {
		return newPhoto;
	}

	public void setNewPhoto(String newPhoto) {
		this.newPhoto = newPhoto;
	}

	public String getMedicalReport() {
		return medicalReport;
	}

	public void setMedicalReport(String medicalReport) {
		this.medicalReport = medicalReport;
	}

	public String getWorkPass() {
		return workPass;
	}

	public void setWorkPass(String workPass) {
		this.workPass = workPass;
	}

	public String getAssessment() {
		return assessment;
	}

	public void setAssessment(String assessment) {
		this.assessment = assessment;
	}

	public Boolean getIsOpenForRenewal() {
		return isOpenForRenewal;
	}

	public void setIsOpenForRenewal(Boolean isOpenForRenewal) {
		this.isOpenForRenewal = isOpenForRenewal;
	}

}
