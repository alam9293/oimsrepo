package gov.stb.tag.dto.tg.licencerenewal;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.ApprovalDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceRenewalRfaDto extends ApprovalDto {

	private Boolean hasRfaCpf;

	private Boolean hasRfaNewPhoto;

	private Boolean hasRfaMedicalReport;

	private Boolean hasRfaWorkPass;

	public TgLicenceRenewalRfaDto() {

	}

	public Boolean getHasRfaCpf() {
		return hasRfaCpf;
	}

	public void setHasRfaCpf(Boolean hasRfaCpf) {
		this.hasRfaCpf = hasRfaCpf;
	}

	public Boolean getHasRfaNewPhoto() {
		return hasRfaNewPhoto;
	}

	public void setHasRfaNewPhoto(Boolean hasRfaNewPhoto) {
		this.hasRfaNewPhoto = hasRfaNewPhoto;
	}

	public Boolean getHasRfaMedicalReport() {
		return hasRfaMedicalReport;
	}

	public void setHasRfaMedicalReport(Boolean hasRfaMedicalReport) {
		this.hasRfaMedicalReport = hasRfaMedicalReport;
	}

	public Boolean getHasRfaWorkPass() {
		return hasRfaWorkPass;
	}

	public void setHasRfaWorkPass(Boolean hasRfaWorkPass) {
		this.hasRfaWorkPass = hasRfaWorkPass;
	}

}
