package gov.stb.tag.dto.tg.licencerenewal;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.tg.application.TgApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceRenewalSearchDto extends TgApplicationSearchDto {

}
