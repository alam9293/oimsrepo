package gov.stb.tag.dto.tg.licencerenewal;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TouristGuide;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceRenewalSubmitDto extends EntityDto {

	private boolean convictChecked;
	// private LocalDateTime offenceDeclaredDate;
	private LocalDate offenceDate;
	private String offenceType;
	private String enforcementOutcome;

	private boolean hasConsentMobileNo;
	private boolean hasConsentEmailAddress;

	public TgLicenceRenewalSubmitDto() {

	}

	public TgLicenceRenewalSubmitDto(Cache cache, TgLicenceRenewal licenceRenewal) {

		this.setConvictChecked(licenceRenewal.getOffenceDate() != null);

		this.setOffenceDate(licenceRenewal.getOffenceDate());
		// this.setOffenceDeclaredDate(licenceRenewal.getOffenceDeclaredDate());
		this.setOffenceType(licenceRenewal.getOffenceType());
		this.setEnforcementOutcome(licenceRenewal.getEnforcementOutcome());

		TouristGuide tg = licenceRenewal.getApplication().getLicence().getTouristGuide();

		this.setHasConsentEmailAddress(licenceRenewal.getHasConsentEmailAddress() != null ? licenceRenewal.getHasConsentEmailAddress() : tg.hasConsentEmailAddress());
		this.setHasConsentMobileNo(licenceRenewal.getHasConsentMobileNo() != null ? licenceRenewal.getHasConsentMobileNo() : tg.hasConsentMobileNo());

	}

	public boolean isConvictChecked() {
		return convictChecked;
	}

	public void setConvictChecked(boolean convictChecked) {
		this.convictChecked = convictChecked;
	}

	// public LocalDateTime getOffenceDeclaredDate() {
	// return offenceDeclaredDate;
	// }
	//
	// public void setOffenceDeclaredDate(LocalDateTime offenceDeclaredDate) {
	// this.offenceDeclaredDate = offenceDeclaredDate;
	// }

	public LocalDate getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDate offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public String getEnforcementOutcome() {
		return enforcementOutcome;
	}

	public void setEnforcementOutcome(String enforcementOutcome) {
		this.enforcementOutcome = enforcementOutcome;
	}

	public boolean isHasConsentMobileNo() {
		return hasConsentMobileNo;
	}

	public void setHasConsentMobileNo(boolean hasConsentMobileNo) {
		this.hasConsentMobileNo = hasConsentMobileNo;
	}

	public boolean isHasConsentEmailAddress() {
		return hasConsentEmailAddress;
	}

	public void setHasConsentEmailAddress(boolean hasConsentEmailAddress) {
		this.hasConsentEmailAddress = hasConsentEmailAddress;
	}

}
