package gov.stb.tag.dto.tg.licencereplacement;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.tg.application.TgApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceReplacementSearchDto extends TgApplicationSearchDto {

	private LocalDateTime submissionDate;
	private String licenceRenewalType;

	public String getLicenceRenewalType() {
		return licenceRenewalType;
	}

	public void setLicenceRenewalType(String licenceRenewalType) {
		this.licenceRenewalType = licenceRenewalType;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

}
