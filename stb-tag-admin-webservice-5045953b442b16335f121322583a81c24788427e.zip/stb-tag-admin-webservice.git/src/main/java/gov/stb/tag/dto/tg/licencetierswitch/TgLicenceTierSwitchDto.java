package gov.stb.tag.dto.tg.licencetierswitch;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.tg.application.TgApplicationItemDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgLicenceTierSwitch;
import gov.stb.tag.model.Type;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgLicenceTierSwitchDto extends TgApplicationItemDto {

	private Integer id; // tgLicenceSwitchTierId
	private String oldLicenceTier;
	private String newLicenceTier;
	private String oldSpecializedArea;
	private String newSpecializedArea;
	private String appFeeBillRefNo;
	private Boolean pendingSwitch;
	private Boolean isPaymentSuccess;
	private Integer paymentFee;

	// Payment
	private PaymentRequestDto appFee;

	public TgLicenceTierSwitchDto() {

	}

	public TgLicenceTierSwitchDto buildFromTgLicenceTierSwitch(CacheHelper cache, TgLicenceTierSwitch tts, PaymentHelper paymentHelper) {

		TgLicenceTierSwitchDto dto = new TgLicenceTierSwitchDto();
		dto.setId(tts.getId());
		String currentSpecializedArea = "";
		String newSpecializedArea = tts.getSpecializedArea() != null ? tts.getSpecializedArea().getLabel() : "";
		if (tts.getApplication().getLicence().getTouristGuide().getSpecializedAreas() != null) {
			Set<Type> currentSpecializedAreaList = tts.getApplication().getLicence().getTouristGuide().getSpecializedAreas();
			for (Type type : currentSpecializedAreaList) {
				if (currentSpecializedArea != "") {
					currentSpecializedArea = currentSpecializedArea + " & " + type.getLabel();
				} else {
					currentSpecializedArea = type.getLabel();
				}
			}
		}
		if (currentSpecializedArea != "") {
			if (newSpecializedArea != "") {
				newSpecializedArea = currentSpecializedArea + " & " + newSpecializedArea;
			} else {
				newSpecializedArea = currentSpecializedArea;
			}
		}

		dto.setOldLicenceTier(tts.getOldLicenceTier().getLabel());
		dto.setNewLicenceTier(tts.getNewLicenceTier().getLabel());
		dto.setOldSpecializedArea(currentSpecializedArea);
		dto.setNewSpecializedArea(newSpecializedArea);
		dto.setAppFeeBillRefNo(tts.getAppFeeBillRefNo());
		dto.setPendingSwitch(tts.getPendingSwitch());
		dto.setPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue()));

		// check whether payment is made successfully
		PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(tts.getAppFeeBillRefNo());
		dto.setPaymentSuccess(false);
		if (paymentRequest != null) {
			PaymentTxn paymentTxn = paymentRequest.getLastTxn();

			if (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL))) {
				dto.setPaymentSuccess(true);
			}
		}

		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tts.getAppFeeBillRefNo()), false));

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setOldLicenceTier(String oldLicenceTier) {
		this.oldLicenceTier = oldLicenceTier;
	}

	public String getOldLicenceTier() {
		return oldLicenceTier;
	}

	public String getNewLicenceTier() {
		return newLicenceTier;
	}

	public void setNewLicenceTier(String newLicenceTier) {
		this.newLicenceTier = newLicenceTier;
	}

	public String getOldSpecializedArea() {
		return oldSpecializedArea;
	}

	public String getNewSpecializedArea() {
		return newSpecializedArea;
	}

	public void setOldSpecializedArea(String oldSpecializedArea) {
		this.oldSpecializedArea = oldSpecializedArea;
	}

	public void setNewSpecializedArea(String newSpecializedArea) {
		this.newSpecializedArea = newSpecializedArea;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public Boolean getPendingSwitch() {
		return pendingSwitch;
	}

	public void setPendingSwitch(Boolean pendingSwitch) {
		this.pendingSwitch = pendingSwitch;
	}

	public Boolean getPaymentSuccess() {
		return isPaymentSuccess;
	}

	public void setPaymentSuccess(Boolean paymentSuccess) {
		isPaymentSuccess = paymentSuccess;
	}

	public Integer getPaymentFee() {
		return paymentFee;
	}

	public void setPaymentFee(Integer paymentFee) {
		this.paymentFee = paymentFee;
	}

	public PaymentRequestDto getAppFee() {
		return appFee;
	}

	public void setAppFee(PaymentRequestDto appFee) {
		this.appFee = appFee;
	}
}
