package gov.stb.tag.dto.tg.mlpt;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgMlptSlot;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptApplicationDto {

	private Integer registrationId;
	private Integer mlptId;
	private List<ListableDto> testLanguages;
	private Integer paymentFee;
	private String appFeeBillRefNo;
	private String printFeeBillRefNo;
	private String applicationNo;
	private LocalDateTime submissionDate;
	private Boolean isPaymentSuccess;
	private Boolean isDraft;
	private Boolean waiveForInactiveLic;

	// slot
	private List<TgMlptSlotItemDto> tgMlptSlots;

	// Payment
	private PaymentRequestDto appFee;
	private PaymentRequestDto cardFee;

	public TgMlptApplicationDto() {

	}

	public static TgMlptApplicationDto buildFromTgMlptApplication(CacheHelper cache, TgLicenceMlptRegistration registration, ApplicationHelper appHelper, PaymentHelper paymentHelper,
			String licenceStatus) {
		TgMlptApplicationDto dto = new TgMlptApplicationDto();

		var application = registration != null ? registration.getApplication() : null;
		if (application != null) {
			dto.setApplicationNo(application.getApplicationNo());
			dto.setSubmissionDate(application.getSubmissionDate());
			dto.setIsDraft(application.getIsDraft());

			// Do not wave the bill if delicensed TG for MLPT
			dto.setWaiveForInactiveLic(true);
			if (!Strings.isNullOrEmpty(licenceStatus)) {
				if (Codes.Statuses.TG_INACTIVE.equals(licenceStatus)) {
					dto.setWaiveForInactiveLic(false);
				}
			}

			PaymentRequest req = paymentHelper.getPaymentRequest(registration.getAppFeeBillRefNo());
			if (req != null) {
				dto.setPaymentFee(req.getPayableAmount().intValue());
				PaymentTxn paymentTxn = req.getLastTxn();

				if (Entities.equals(req.getStatus(), Codes.Statuses.PAYREQ_WAIVED) || (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
					dto.setPaymentSuccess(Boolean.TRUE);
				} else {
					dto.setPaymentSuccess(Boolean.FALSE);
				}
			}
		}

		if (registration != null) {
			dto.setRegistrationId(registration.getId());
			dto.setAppFeeBillRefNo(registration.getAppFeeBillRefNo());
			dto.setPrintFeeBillRefNo(registration.getPrintFeeBillRefNo());

			List<TgMlptSlotItemDto> mlptSlots = new ArrayList<>();
			Set<TgMlptSlot> slots = registration.getTgMlptSlots();
			for (TgMlptSlot slot : slots) {
				mlptSlots.add(TgMlptSlotItemDto.buildFromTgMlptSlot(cache, slot));
			}
			dto.setTgMlptSlots(mlptSlots);
		}

		return dto;
	}

	public Integer getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(Integer registrationId) {
		this.registrationId = registrationId;
	}

	public List<ListableDto> getTestLanguages() {
		return testLanguages;
	}

	public void setTestLanguages(List<ListableDto> testLanguages) {
		this.testLanguages = testLanguages;
	}

	public Integer getPaymentFee() {
		return paymentFee;
	}

	public void setPaymentFee(Integer paymentFee) {
		this.paymentFee = paymentFee;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public String getPrintFeeBillRefNo() {
		return printFeeBillRefNo;
	}

	public void setPrintFeeBillRefNo(String printFeeBillRefNo) {
		this.printFeeBillRefNo = printFeeBillRefNo;
	}

	public List<TgMlptSlotItemDto> getTgMlptSlots() {
		return tgMlptSlots;
	}

	public void setTgMlptSlots(List<TgMlptSlotItemDto> tgMlptSlots) {
		this.tgMlptSlots = tgMlptSlots;
	}

	public Boolean getPaymentSuccess() {
		return isPaymentSuccess;
	}

	public void setPaymentSuccess(Boolean paymentSuccess) {
		isPaymentSuccess = paymentSuccess;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean draft) {
		isDraft = draft;
	}

	public PaymentRequestDto getAppFee() {
		return appFee;
	}

	public void setAppFee(PaymentRequestDto appFee) {
		this.appFee = appFee;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public PaymentRequestDto getCardFee() {
		return cardFee;
	}

	public void setCardFee(PaymentRequestDto cardFee) {
		this.cardFee = cardFee;
	}

	public Integer getMlptId() {
		return mlptId;
	}

	public void setMlptId(Integer mlptId) {
		this.mlptId = mlptId;
	}

	public Boolean getWaiveForInactiveLic() {
		return waiveForInactiveLic;
	}

	public void setWaiveForInactiveLic(Boolean waiveForInactiveLic) {
		this.waiveForInactiveLic = waiveForInactiveLic;
	}
}
