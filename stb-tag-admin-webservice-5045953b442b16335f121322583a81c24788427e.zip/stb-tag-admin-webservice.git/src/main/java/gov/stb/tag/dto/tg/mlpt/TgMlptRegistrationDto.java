package gov.stb.tag.dto.tg.mlpt;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgMlptSlot;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptRegistrationDto extends TgMlptApplicationDto {

	private Integer mlptId;
	private String mlptName;
	private LocalDate regStartDate;
	private LocalDate regEndDate;
	private LocalDate mlptStartDate;
	private LocalDate mlptEndDate;
	private Boolean isFutureMlpt;
	private Boolean isRegistrationClosed;
	private ListableDto allocationStatus;

	private Integer mlptFee;
	private Integer cardPaymentFee;
	private Boolean isWaived = false;
	private String appFeeBillRefNo;
	private String printFeeBillRefNo;
	private Boolean hasResult;
	private Boolean isAllResultUpdated;
	private Boolean isCardPaymentSuccess;
	private Boolean hasNewBadge;
	private String licencePrintStatus;
	private TgMlptApplicationDto mlptDraftApplication;
	private List<TgMlptApplicationDto> mlptSubmittedApplications;

	private List<String> guidingLanguages;

	// next mlpt date
	private Boolean hasNextMlpt;
	private String nextMlptName;
	private LocalDate nextRegStartDate;
	private LocalDate nextRegEndDate;
	private LocalDate nextMlptStartDate;
	private LocalDate nextMlptEndDate;

	public TgMlptRegistrationDto() {

	}

	public static TgMlptRegistrationDto buildTgMlptAndDraftRegistration(CacheHelper cache, TgMlpt tgMlpt, TgLicenceMlptRegistration registration, ApplicationHelper appHelper,
			PaymentHelper paymentHelper) {
		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();

		if (tgMlpt != null) {
			dto.setMlptId(tgMlpt.getId());
			dto.setMlptName(tgMlpt.getName());
			dto.setRegStartDate(tgMlpt.getRegStartDate());
			dto.setRegEndDate(tgMlpt.getRegEndDate());
			dto.setMlptStartDate(tgMlpt.getMlptStartDate());
			dto.setMlptEndDate(tgMlpt.getMlptEndDate());

			var regStartDate = tgMlpt.getRegStartDate();
			var regEndDate = tgMlpt.getRegEndDate();
			var localDateNow = LocalDate.now();
			var isFutureMlpt = regStartDate.isAfter(localDateNow);
			var isRegistrationClosed = regEndDate.isBefore(localDateNow);
			dto.setIsFutureMlpt(isFutureMlpt);
			dto.setIsRegistrationClosed(isRegistrationClosed);
			dto.setAllocationStatus(
					tgMlpt.getAllocationStatus() != null ? new ListableDto(tgMlpt.getAllocationStatus().getKey(), cache.getLabel(tgMlpt.getAllocationStatus(), false)) : new ListableDto());
		}

		if (registration != null) {
			dto.setMlptDraftApplication(TgMlptApplicationDto.buildFromTgMlptApplication(cache, registration, appHelper, paymentHelper, null));
		}

		dto.setMlptFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_MLPT_FEE).getValue()));
		dto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION));

		return dto;
	}

	public static TgMlptRegistrationDto buildSubmittedTgMlptRegistration(CacheHelper cache, List<TgLicenceMlptRegistration> registrations, TgLicenceMlptRegistration confirmedRegistration,
			TgMlpt nextTgMlpt, ApplicationHelper appHelper, PaymentHelper paymentHelper, String licenceStatus) {
		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();
		Boolean hasCompetentResult = false;

		dto.setAllResultUpdated(true);
		dto.setHasNewBadge(false);

		List<TgMlptApplicationDto> mlptSubmittedApplications = new ArrayList<>();
		if (registrations != null && registrations.size() > 0) {
			for (TgLicenceMlptRegistration registration : registrations) {
				// check whether payment is made successfully
				PaymentRequest req = paymentHelper.getPaymentRequest(registration.getAppFeeBillRefNo());
				PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
				Boolean paymentSuccess = Boolean.FALSE;
				if ((req != null && Entities.equals(req.getStatus(), Codes.Statuses.PAYREQ_WAIVED))
						|| (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
					paymentSuccess = Boolean.TRUE;
				}

				if (registration.getApplication().getIsDraft() == false) {
					mlptSubmittedApplications.add(TgMlptApplicationDto.buildFromTgMlptApplication(cache, registration, appHelper, paymentHelper, null));
				} else if (registration.getApplication().getIsDraft() == true && paymentSuccess) {
					dto.setMlptDraftApplication(TgMlptApplicationDto.buildFromTgMlptApplication(cache, registration, appHelper, paymentHelper, null));
				}

				// exclude payment fail registration
				if (LocalDate.now().isAfter(registration.getTgMlpt().getMlptStartDate()) && paymentSuccess) {
					for (TgMlptSlot slot : registration.getTgMlptSlots()) {
						if (slot.getResultStatus() != null && Codes.Statuses.TG_MLPT_COMPETENT.equals(slot.getResultStatus().getCode()) && hasCompetentResult == false) {
							hasCompetentResult = true;
						}

						if (slot.getResultStatus() == null) {
							dto.setAllResultUpdated(false);
						}
					}
				}
			}
			dto.setMlptSubmittedApplications(mlptSubmittedApplications);

			// licence print status
			if (confirmedRegistration != null) {
				dto.setLicencePrintStatus(confirmedRegistration.getApplication().getLicencePrintStatus() != null ? confirmedRegistration.getApplication().getLicencePrintStatus().getLabel() : "");
			}
		}

		// incur card payment
		if (hasCompetentResult && dto.getAllResultUpdated() == true) {
			dto.setHasNewBadge(true);
			dto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_MLPT));
			// Do not wave the bill if delicensed TG for MLPT
			if (Codes.Statuses.TG_INACTIVE.equals(licenceStatus)) {
				dto.setIsWaived(false);
			}
			dto.setCardPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue()));
		}

		// check whether TG has new badge and made payment
		if (dto.getAllResultUpdated() == true && dto.getHasNewBadge() == true) {
			TgLicenceMlptRegistration registration = registrations.get(0);
			PaymentRequest req = paymentHelper.getPaymentRequest(registration.getPrintFeeBillRefNo());
			PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
			dto.setPrintFeeBillRefNo(registration.getPrintFeeBillRefNo() != null ? registration.getPrintFeeBillRefNo() : "");
			if ((req != null && Entities.equals(req.getStatus(), Codes.Statuses.PAYREQ_WAIVED))
					|| (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
				dto.setIsCardPaymentSuccess(Boolean.TRUE);
			} else {
				dto.setIsCardPaymentSuccess(Boolean.FALSE);
			}
		}

		// pass next open tg mlpt schedule when all result updated
		dto.setHasNextMlpt(false);
		if (Boolean.TRUE.equals(dto.getAllResultUpdated()) && nextTgMlpt != null) {
			dto.setNextMlptName(nextTgMlpt.getName());
			dto.setNextRegStartDate(nextTgMlpt.getRegStartDate());
			dto.setNextRegEndDate(nextTgMlpt.getRegEndDate());
			dto.setNextMlptStartDate(nextTgMlpt.getMlptStartDate());
			dto.setNextMlptEndDate(nextTgMlpt.getMlptEndDate());
			dto.setHasNextMlpt(true);
		}

		return dto;
	}

	public static TgMlptRegistrationDto buildTgMlptCardPayment(CacheHelper cache, TgMlpt tgMlpt, List<TgLicenceMlptRegistration> registrations, PaymentHelper paymentHelper) {
		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();

		if (tgMlpt != null) {
			dto.setMlptId(tgMlpt.getId());
			dto.setMlptName(tgMlpt.getName());
			dto.setRegStartDate(tgMlpt.getRegStartDate());
			dto.setRegEndDate(tgMlpt.getRegEndDate());
		}

		dto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_MLPT));
		dto.setCardPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue()));
		dto.setPrintFeeBillRefNo(registrations.get(0) != null ? registrations.get(0).getPrintFeeBillRefNo() : "");

		// check whether TG has new badge and made payment
		for (TgLicenceMlptRegistration reg : registrations) {
			PaymentRequest req = paymentHelper.getPaymentRequest(reg.getPrintFeeBillRefNo());
			PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
			if ((req != null && Entities.equals(req.getStatus(), Codes.Statuses.PAYREQ_WAIVED))
					|| (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
				dto.setIsCardPaymentSuccess(Boolean.TRUE);
			} else {
				dto.setIsCardPaymentSuccess(Boolean.FALSE);
			}
		}

		return dto;
	}

	public static TgMlptRegistrationDto buildConfirmedRegistration(CacheHelper cache, TgLicenceMlptRegistration firstRegistration, ApplicationHelper appHelper, PaymentHelper paymentHelper) {
		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();

		// licence print status
		if (firstRegistration != null) {
			dto.setLicencePrintStatus(firstRegistration.getApplication().getLicencePrintStatus() != null ? firstRegistration.getApplication().getLicencePrintStatus().getLabel() : "");

			// payment status
			dto.setPrintFeeBillRefNo(firstRegistration.getPrintFeeBillRefNo());
			PaymentRequest req = paymentHelper.getPaymentRequest(firstRegistration.getPrintFeeBillRefNo());
			PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
			if ((req != null && Entities.equals(req.getStatus(), Codes.Statuses.PAYREQ_WAIVED))
					|| (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
				dto.setIsCardPaymentSuccess(Boolean.TRUE);
			} else {
				dto.setIsCardPaymentSuccess(Boolean.FALSE);
			}
		} else {
			dto.setIsCardPaymentSuccess(Boolean.FALSE);
		}

		return dto;
	}

	public static TgMlptRegistrationDto buildDashboardNotification(CacheHelper cache, TgMlpt tgMlpt, List<TgLicenceMlptRegistration> registrations, PaymentHelper paymentHelper) {
		TgMlptRegistrationDto dto = new TgMlptRegistrationDto();

		if (tgMlpt != null) {
			dto.setMlptId(tgMlpt.getId());
			dto.setMlptName(tgMlpt.getName());
			dto.setRegStartDate(tgMlpt.getRegStartDate());
			dto.setRegEndDate(tgMlpt.getRegEndDate());
			dto.setAllocationStatus(
					tgMlpt.getAllocationStatus() != null ? new ListableDto(tgMlpt.getAllocationStatus().getKey(), cache.getLabel(tgMlpt.getAllocationStatus(), false)) : new ListableDto());
		}

		if (registrations != null && registrations.size() > 0) {
			List<TgMlptSlotItemDto> mlptSlots = new ArrayList<>();
			String printFeeBillRefNo = new String();
			for (TgLicenceMlptRegistration registration : registrations) {
				if (registration.getApplication() != null && registration.getApplication().getIsDraft() == false) {
					// slot
					Set<TgMlptSlot> slots = registration.getTgMlptSlots();
					for (TgMlptSlot slot : slots) {
						mlptSlots.add(TgMlptSlotItemDto.buildTgMlptDetails(cache, slot));
					}

					printFeeBillRefNo = !printFeeBillRefNo.isBlank() ? registration.getPrintFeeBillRefNo() : "";
				}
			}

			// card payment
			PaymentRequest req = paymentHelper.getPaymentRequest(printFeeBillRefNo);
			PaymentTxn paymentTxn = req != null ? req.getLastTxn() : null;
			if ((req != null && Entities.equals(req.getStatus(), Codes.Statuses.PAYREQ_WAIVED))
					|| (paymentTxn != null && paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)))) {
				dto.setIsCardPaymentSuccess(Boolean.TRUE);
			} else {
				dto.setIsCardPaymentSuccess(Boolean.FALSE);
			}

			dto.setTgMlptSlots(mlptSlots);
		}

		return dto;
	}

	@Override
	public Integer getMlptId() {
		return mlptId;
	}

	@Override
	public void setMlptId(Integer mlptId) {
		this.mlptId = mlptId;
	}

	public String getMlptName() {
		return mlptName;
	}

	public void setMlptName(String mlptName) {
		this.mlptName = mlptName;
	}

	public LocalDate getRegStartDate() {
		return regStartDate;
	}

	public void setRegStartDate(LocalDate regStartDate) {
		this.regStartDate = regStartDate;
	}

	public LocalDate getRegEndDate() {
		return regEndDate;
	}

	public void setRegEndDate(LocalDate regEndDate) {
		this.regEndDate = regEndDate;
	}

	public LocalDate getMlptStartDate() {
		return mlptStartDate;
	}

	public void setMlptStartDate(LocalDate mlptStartDate) {
		this.mlptStartDate = mlptStartDate;
	}

	public LocalDate getMlptEndDate() {
		return mlptEndDate;
	}

	public void setMlptEndDate(LocalDate mlptEndDate) {
		this.mlptEndDate = mlptEndDate;
	}

	public Boolean getIsFutureMlpt() {
		return isFutureMlpt;
	}

	public void setIsFutureMlpt(Boolean isFutureMlpt) {
		this.isFutureMlpt = isFutureMlpt;
	}

	public Boolean getIsRegistrationClosed() {
		return isRegistrationClosed;
	}

	public void setIsRegistrationClosed(Boolean registrationClosed) {
		isRegistrationClosed = registrationClosed;
	}

	public Integer getMlptFee() {
		return mlptFee;
	}

	public void setMlptFee(Integer mlptFee) {
		this.mlptFee = mlptFee;
	}

	@Override
	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	@Override
	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	@Override
	public String getPrintFeeBillRefNo() {
		return printFeeBillRefNo;
	}

	@Override
	public void setPrintFeeBillRefNo(String printFeeBillRefNo) {
		this.printFeeBillRefNo = printFeeBillRefNo;
	}

	public TgMlptApplicationDto getMlptDraftApplication() {
		return mlptDraftApplication;
	}

	public void setMlptDraftApplication(TgMlptApplicationDto mlptDraftApplication) {
		this.mlptDraftApplication = mlptDraftApplication;
	}

	public List<TgMlptApplicationDto> getMlptSubmittedApplications() {
		return mlptSubmittedApplications;
	}

	public void setMlptSubmittedApplications(List<TgMlptApplicationDto> mlptSubmittedApplications) {
		this.mlptSubmittedApplications = mlptSubmittedApplications;
	}

	public Boolean getHasResult() {
		return hasResult;
	}

	public void setHasResult(Boolean hasResult) {
		this.hasResult = hasResult;
	}

	public Boolean getAllResultUpdated() {
		return isAllResultUpdated;
	}

	public void setAllResultUpdated(Boolean allResultUpdated) {
		isAllResultUpdated = allResultUpdated;
	}

	public Boolean getHasNewBadge() {
		return hasNewBadge;
	}

	public void setHasNewBadge(Boolean hasNewBadge) {
		this.hasNewBadge = hasNewBadge;
	}

	public Boolean getIsCardPaymentSuccess() {
		return isCardPaymentSuccess;
	}

	public void setIsCardPaymentSuccess(Boolean cardPaymentSuccess) {
		isCardPaymentSuccess = cardPaymentSuccess;
	}

	public Integer getCardPaymentFee() {
		return cardPaymentFee;
	}

	public void setCardPaymentFee(Integer cardPaymentFee) {
		this.cardPaymentFee = cardPaymentFee;
	}

	public String getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(String licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}

	public List<String> getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(List<String> guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public ListableDto getAllocationStatus() {
		return allocationStatus;
	}

	public void setAllocationStatus(ListableDto allocationStatus) {
		this.allocationStatus = allocationStatus;
	}

	public String getNextMlptName() {
		return nextMlptName;
	}

	public void setNextMlptName(String nextMlptName) {
		this.nextMlptName = nextMlptName;
	}

	public LocalDate getNextRegStartDate() {
		return nextRegStartDate;
	}

	public void setNextRegStartDate(LocalDate nextRegStartDate) {
		this.nextRegStartDate = nextRegStartDate;
	}

	public LocalDate getNextRegEndDate() {
		return nextRegEndDate;
	}

	public void setNextRegEndDate(LocalDate nextRegEndDate) {
		this.nextRegEndDate = nextRegEndDate;
	}

	public LocalDate getNextMlptStartDate() {
		return nextMlptStartDate;
	}

	public void setNextMlptStartDate(LocalDate nextMlptStartDate) {
		this.nextMlptStartDate = nextMlptStartDate;
	}

	public LocalDate getNextMlptEndDate() {
		return nextMlptEndDate;
	}

	public void setNextMlptEndDate(LocalDate nextMlptEndDate) {
		this.nextMlptEndDate = nextMlptEndDate;
	}

	public Boolean getHasNextMlpt() {
		return hasNextMlpt;
	}

	public void setHasNextMlpt(Boolean hasNextMlpt) {
		this.hasNextMlpt = hasNextMlpt;
	}

	public Boolean getIsWaived() {
		return isWaived;
	}

	public void setIsWaived(Boolean isWaived) {
		this.isWaived = isWaived;
	}

}
