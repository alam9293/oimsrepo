package gov.stb.tag.dto.tg.mlpt;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptSlotAllocationDto {

	LocalDate startDate;

	List<TgMlptSlotItemDto> slots;

	public TgMlptSlotAllocationDto() {
		this.slots = new ArrayList<TgMlptSlotItemDto>();
	}

	public TgMlptSlotAllocationDto(LocalDate startDate) {
		this.startDate = startDate;
		this.slots = new ArrayList<TgMlptSlotItemDto>();
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public List<TgMlptSlotItemDto> getSlots() {
		return slots;
	}

	public void setSlots(List<TgMlptSlotItemDto> slots) {
		this.slots = slots;
	}

}
