package gov.stb.tag.dto.tg.mlpt;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgMlptSlot;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptSlotItemDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "startTime")
	private LocalDateTime startTime;

	@MapProjection(path = "licence.licenceNo", doNotCreateAlias = true)
	private String licenceNo;

	@MapProjection(path = "touristGuide.name", doNotCreateAlias = true)
	private String name;

	@MapProjection(path = "tier.code", doNotCreateAlias = true)
	private String tierCode;

	@MapProjection(path = "tier.label", doNotCreateAlias = true)
	private String tierLabel;

	@MapProjection(path = "guidingLanguage.code")
	private String guidingLanguageCode;

	@MapProjection(path = "guidingLanguage.label")
	private String guidingLanguageLabel;

	@MapProjection(path = "assessor")
	private String assessor;

	@MapProjection(path = "chiefAssessor")
	private String chiefAssessor;

	@MapProjection(path = "resultStatus.code")
	private String resultStatusCode;

	@MapProjection(path = "resultStatus.label")
	private String resultStatusLabel;

	@MapProjection(path = "resultSentDate")
	private LocalDateTime resultSentDate;

	@MapProjection(path = "tgLicenceMlptRegistration.isForReinstatement")
	private Boolean isForReinstatement;

	private ListableDto resultStatus;

	private ListableDto testLanguages;

	private LocalDate startDate;

	@MapProjection(path = "resultFile.id")
	private Integer resultFileId;

	private FileDto resultFile = new FileDto();

	public TgMlptSlotItemDto() {
	}

	public TgMlptSlotItemDto(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public static TgMlptSlotItemDto buildFromTgMlptSlot(CacheHelper cache, TgMlptSlot slot) {
		TgMlptSlotItemDto dto = new TgMlptSlotItemDto();

		if (slot != null) {
			dto.setId(slot.getId());
			dto.setTestLanguages((slot.getGuidingLanguage() != null) ? new ListableDto(slot.getGuidingLanguage().getKey(), cache.getLabel(slot.getGuidingLanguage(), false)) : new ListableDto());
		}

		return dto;
	}

	public static TgMlptSlotItemDto buildTgMlptDetails(CacheHelper cache, TgMlptSlot slot) {
		TgMlptSlotItemDto dto = new TgMlptSlotItemDto();
		TgMlpt tgMlpt = slot.getTgLicenceMlptRegistration().getTgMlpt();

		dto.setId(slot.getId());
		dto.setTestLanguages((slot.getGuidingLanguage() != null) ? new ListableDto(slot.getGuidingLanguage().getKey(), cache.getLabel(slot.getGuidingLanguage(), false)) : new ListableDto());

		if (slot != null && tgMlpt.getAllocationStatus() != null && Codes.Statuses.TG_MLPT_ALLOC_PUB.equals(tgMlpt.getAllocationStatus().getCode())) {
			dto.setStartTime(slot.getStartTime());
			dto.setStartDate(slot.getStartTime() != null ? slot.getStartTime().toLocalDate() : null);
			dto.setResultStatus((slot.getResultStatus() != null) ? new ListableDto(slot.getResultStatus().getKey(), cache.getLabel(slot.getResultStatus(), false)) : new ListableDto());
		}

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGuidingLanguageCode() {
		return guidingLanguageCode;
	}

	public void setGuidingLanguageCode(String guidingLanguageCode) {
		this.guidingLanguageCode = guidingLanguageCode;
	}

	public String getTierCode() {
		return tierCode;
	}

	public void setTierCode(String tierCode) {
		this.tierCode = tierCode;
	}

	public String getTierLabel() {
		return tierLabel;
	}

	public void setTierLabel(String tierLabel) {
		this.tierLabel = tierLabel;
	}

	public String getGuidingLanguageLabel() {
		return guidingLanguageLabel;
	}

	public void setGuidingLanguageLabel(String guidingLanguageLabel) {
		this.guidingLanguageLabel = guidingLanguageLabel;
	}

	public String getAssessor() {
		return assessor;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public String getChiefAssessor() {
		return chiefAssessor;
	}

	public void setChiefAssessor(String chiefAssessor) {
		this.chiefAssessor = chiefAssessor;
	}

	public String getResultStatusCode() {
		return resultStatusCode;
	}

	public void setResultStatusCode(String resultStatusCode) {
		this.resultStatusCode = resultStatusCode;
	}

	public ListableDto getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(ListableDto resultStatus) {
		this.resultStatus = resultStatus;
	}

	public ListableDto getTestLanguages() {
		return testLanguages;
	}

	public void setTestLanguages(ListableDto testLanguages) {
		this.testLanguages = testLanguages;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getResultSentDate() {
		return resultSentDate;
	}

	public void setResultSentDate(LocalDateTime resultSentDate) {
		this.resultSentDate = resultSentDate;
	}

	public String getResultStatusLabel() {
		return resultStatusLabel;
	}

	public void setResultStatusLabel(String resultStatusLabel) {
		this.resultStatusLabel = resultStatusLabel;
	}

	public Boolean getIsForReinstatement() {
		return isForReinstatement;
	}

	public void setIsForReinstatement(Boolean isForReinstatement) {
		this.isForReinstatement = isForReinstatement;
	}

	public Integer getResultFileId() {
		return resultFileId;
	}

	public void setResultFileId(Integer resultFileId) {
		this.resultFileId = resultFileId;
	}

	public FileDto getResultFile() {
		return resultFile;
	}

	public void setResultFile(FileDto resultFile) {
		this.resultFile = resultFile;
	}

}
