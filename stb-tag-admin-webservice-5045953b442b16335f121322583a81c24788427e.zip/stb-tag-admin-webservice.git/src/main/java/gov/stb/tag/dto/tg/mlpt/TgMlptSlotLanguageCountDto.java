package gov.stb.tag.dto.tg.mlpt;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgMlptSlotLanguageCountDto {

	private String guidingLanguageCode;

	private Long count;

	public TgMlptSlotLanguageCountDto() {

	}

	public String getGuidingLanguageCode() {
		return guidingLanguageCode;
	}

	public void setGuidingLanguageCode(String guidingLanguageCode) {
		this.guidingLanguageCode = guidingLanguageCode;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

}
