package gov.stb.tag.dto.tg.particularUpdate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.WorkflowActionDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.tg.application.TgApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.TgPersonUpdate;
import gov.stb.tag.model.TouristGuide;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParticularUpdateDto extends TgApplicationDto {

	private Boolean isWorkPassHolder;
	private Boolean allowToEdit;
	private Boolean isPaymentRequired; // admin only

	private String aliasName;
	private LocalDate dob;
	private String nric;
	private String nationality;
	private String salutation;
	private String sex;
	private String maritalStatus;
	private String race;
	private String birthCountry;
	private String residentialStatus;
	private String highestEduLevel;
	private String mobileNo;
	private String emailAddress;
	private String employerName;
	private String occupation;
	private String occupationOther;
	private String workPassType;
	private LocalDate workpassExpiryDate;

	private ListableDto regType;
	private ListableDto optType;

	private String regStreet;
	private String regBuilding;
	private String regBlock;
	private String regFloor;
	private String regUnit;
	private String regPostal;
	private String registeredAddress;

	private String optStreet;
	private String optBuilding;
	private String optBlock;
	private String optFloor;
	private String optUnit;
	private String optPostal;
	private String operatingAddress;

	private String regForeignLine1;
	private String regForeignLine2;
	private String regForeignLine3;

	private String optForeignLine1;
	private String optForeignLine2;
	private String optForeignLine3;

	private ListableDto status;
	private String statusRemark;
	private String guidingLanguage;
	private String areaSpecification;
	private String licenceType;
	private Integer id; // particularUpdateId
	private FileDto photo;
	private FileDto prevPhoto;
	private List<FileDto> otherSupportDocs;
	private List<WorkflowActionDto> workflowActions;

	private Boolean convictChecked;
	// private LocalDateTime offenceDeclaredDate;
	private LocalDate offenceDate;
	private String offenceType;
	private String enforcementOutcome;

	private Boolean hasConsentMobileNo;
	private Boolean hasConsentEmailAddress;

	private Integer paymentFee;
	private Boolean isPaymentSuccess;
	private String paymentStatus;
	private Boolean isWaived = false;

	private Boolean isAddrSame;

	private Boolean isMyInfoPopulated;
	private Boolean isSnapshotMyInfoPopulated;

	private Boolean isDraft;

	// For intranet application view to compare before & after values
	private List<ParticularUpdateCompareDetails> compareDetailsDto;

	// For intranet application view to compare before & after values related to work pass
	private List<ParticularUpdateCompareDetails> compareWorkPassDetailsDto;

	// Payment
	private PaymentRequestDto appFee;

	public ParticularUpdateDto() {

	}

	public ParticularUpdateDto buildSubmissionDetails(CacheHelper cache, PaymentHelper paymentHelper, TgPersonUpdate tpu) {
		ParticularUpdateDto dto = new ParticularUpdateDto();
		var application = tpu.getApplication();
		dto.setApplicationId(application.getId());
		dto.setApplicationNo(application.getApplicationNo());
		dto.setIsDraft(application.getIsDraft());

		// Payment
		dto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE));
		dto.setAppFee(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(tpu.getAppFeeBillRefNo()), false));

		return dto;
	}

	public ParticularUpdateDto(Cache cache, TgPersonUpdate tpu, TouristGuide tg, ApplicationHelper appHelper, FileHelper fileHelper, PaymentHelper paymentHelper) {

		var application = tpu.getApplication();
		if (tpu.getApplication() != null) {
			this.buildFromApplication(cache, appHelper, tpu.getApplication(), this);
		}

		this.isMyInfoPopulated = tpu.isMyInfoPopulated();
		this.guidingLanguage = tg.getGuidingLanguagesWithComma(cache);
		this.isSnapshotMyInfoPopulated = tg.isMyInfoPopulated();

		this.setId(tpu.getId());
		this.setNric(tpu.getUin());
		this.setName(tpu.getName());
		this.setResidentialStatus(tpu.getResidentialStatus() != null ? tpu.getResidentialStatus().getCode() : null);
		this.setEmployerName(tpu.getEmployerName());
		this.setOccupation(tpu.getOccupation() != null ? tpu.getOccupation().getCode() : null);
		this.setOccupationOther(tpu.getOccupationOther());
		this.setWorkPassType(tpu.getWorkPassType() != null ? tpu.getWorkPassType().getCode() : null);
		this.setWorkpassExpiryDate(tpu.getWorkpassExpiryDate());

		if (Codes.Types.TG_TIER_AREA.equals(tg.getLicence().getTier().getCode()) || Codes.Types.TG_TIER_GENERAL_AREA.equals(tg.getLicence().getTier().getCode())) {
			Set<String> specializedAreaSet = new HashSet<>();
			if (tg.getSpecializedAreas() != null) {
				specializedAreaSet.addAll(tg.getSpecializedAreas().stream().map(u -> cache.getLabel(u, true)).collect(Collectors.toSet()));
			}
			this.areaSpecification = StringUtils.join(specializedAreaSet, " / ");
		}

		var appFiles = application.getApplicationFiles();
		List<FileDto> otherDocuments = new ArrayList<FileDto>();
		for (ApplicationFile appFile : appFiles) {
			if (!appFile.getIsDeleted()) {
				if (appFile.getDocumentType().getCode().equals(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO)) {
					this.photo = FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper);
				} else {
					otherDocuments.add(FileDto.buildFromFile(appFile.getFile(), appFile.getDocumentType(), fileHelper));
				}
			}
		}

		// check whether payment is made successfully
		PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(tpu.getAppFeeBillRefNo());
		if (paymentRequest != null) {
			this.setPaymentStatus(paymentRequest.getStatus().getLabel());
			this.setBillRefNo(paymentRequest.getBillRefNo());
		}

		this.otherSupportDocs = otherDocuments;

	}

	public static ParticularUpdateDto buildFromParticularUpdate(CacheHelper cache, TgPersonUpdate tpu, PaymentHelper paymentHelper, FileHelper fileHelper, UserHelper userHelper,
			ParticularUpdateDto itemDto, boolean hasPersonUpdateAccess, String loginUserId) {

		var app = tpu.getApplication();
		var lastAction = app.getLastAction();
		if (lastAction != null) {
			var lastStatus = lastAction.getStatus();
			itemDto.setStatus(new ListableDto(lastStatus.getCode(), cache.getLabel(lastStatus, true)));
			itemDto.setStatusRemark(lastAction.getExternalRemarks());
		}
		itemDto.setId(tpu.getId());
		itemDto.setIsDraft(app.getIsDraft());
		itemDto.setApplicationId(app.getId());
		itemDto.setApplicationNo(app.getApplicationNo());
		itemDto.setNric(tpu.getUin());
		itemDto.setSalutation(tpu.getSalutation() != null ? tpu.getSalutation().getCode() : null);
		itemDto.setName(tpu.getName());
		itemDto.setDob(tpu.getDob());
		itemDto.setSex(tpu.getSex() != null ? tpu.getSex().getCode() : null);
		itemDto.setMaritalStatus(tpu.getMaritalStatus() != null ? tpu.getMaritalStatus().getCode() : null);
		itemDto.setRace(tpu.getRace() != null ? tpu.getRace().getCode() : null);
		itemDto.setNationality(tpu.getNationality() != null ? tpu.getNationality().getCode() : null);
		itemDto.setBirthCountry(tpu.getBirthCountry() != null ? tpu.getBirthCountry().getCode() : null);
		itemDto.setResidentialStatus(tpu.getResidentialStatus() != null ? tpu.getResidentialStatus().getCode() : null);
		itemDto.setHighestEduLevel(tpu.getHighestEduLevel() != null ? tpu.getHighestEduLevel().getCode() : null);
		itemDto.setMobileNo(tpu.getMobileNo());
		itemDto.setEmailAddress(tpu.getEmailAddress());
		itemDto.setEmployerName(tpu.getEmployerName());
		itemDto.setOccupation(tpu.getOccupation() != null ? tpu.getOccupation().getCode() : null);
		itemDto.setOccupationOther(tpu.getOccupationOther());
		itemDto.setWorkPassType(tpu.getWorkPassType() != null ? tpu.getWorkPassType().getCode() : null);
		itemDto.setWorkpassExpiryDate(tpu.getWorkpassExpiryDate());
		itemDto.setAliasName(tpu.getAliasName());
		itemDto.setOffenceDate(tpu.getOffenceDate());
		itemDto.setOffenceType(tpu.getOffenceType());
		itemDto.setEnforcementOutcome(tpu.getEnforcementOutcome());
		itemDto.setHasConsentEmailAddress(tpu.hasConsentEmailAddress());
		itemDto.setHasConsentMobileNo(tpu.hasConsentMobileNo());
		itemDto.setIsMyInfoPopulated(tpu.isMyInfoPopulated());
		itemDto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(loginUserId));

		var appFiles = app.getApplicationFiles();
		if (CollectionUtils.isNotEmpty(appFiles)) {
			List<FileDto> otherDocuments = new ArrayList<FileDto>();
			for (ApplicationFile applicationFile : appFiles) {
				if (!Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO.equals(applicationFile.getDocumentType().getCode())) {
					otherDocuments.add(FileDto.buildFromFile(applicationFile.getFile(), applicationFile.getDocumentType(), fileHelper));
				}
			}

			if (otherDocuments != null && otherDocuments.size() > 0) {
				itemDto.setOtherSupportDocs(otherDocuments);
			}
		}

		// registered and operating address
		var regAddr = tpu.getRegisteredAddress();
		var optAddr = tpu.getOperatingAddress();

		if (regAddr != null) {
			itemDto.setRegType(new ListableDto(regAddr.getAddressType()));
			itemDto.setRegStreet(regAddr.getStreet());
			itemDto.setRegBuilding(regAddr.getBuilding());
			itemDto.setRegBlock(regAddr.getBlock());
			itemDto.setRegFloor(regAddr.getFloor());
			itemDto.setRegUnit(regAddr.getUnit());
			itemDto.setRegPostal(regAddr.getPostal());
			itemDto.setRegForeignLine1(regAddr.getForeignLine1());
			itemDto.setRegForeignLine2(regAddr.getForeignLine2());
			itemDto.setRegForeignLine3(regAddr.getForeignLine3());
		}

		if (optAddr != null) {
			if (regAddr != null && regAddr.equals(optAddr)) {
				itemDto.setIsAddrSame(true);
			} else {
				itemDto.setIsAddrSame(false);
			}
			itemDto.setOptType(new ListableDto(optAddr.getAddressType()));
			itemDto.setOptStreet(optAddr.getStreet());
			itemDto.setOptBuilding(optAddr.getBuilding());
			itemDto.setOptBlock(optAddr.getBlock());
			itemDto.setOptFloor(optAddr.getFloor());
			itemDto.setOptUnit(optAddr.getUnit());
			itemDto.setOptPostal(optAddr.getPostal());
			itemDto.setOptForeignLine1(optAddr.getForeignLine1());
			itemDto.setOptForeignLine2(optAddr.getForeignLine2());
			itemDto.setOptForeignLine3(optAddr.getForeignLine3());
		}

		// check whether payment is made successfully
		PaymentRequest paymentRequest = paymentHelper.getPaymentRequest(tpu.getAppFeeBillRefNo());
		if (paymentRequest != null) {
			PaymentTxn paymentTxn = paymentRequest.getLastTxn();
			itemDto.setBillRefNo(paymentRequest.getBillRefNo());

			if (paymentTxn != null) {
				itemDto.setPaymentSuccess(paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL)));
			}

		}

		itemDto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE));
		itemDto.setPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue()));

		itemDto.setBillRefNo(tpu.getAppFeeBillRefNo());

		if (Codes.Statuses.TG_ACTIVE.equalsIgnoreCase(tpu.getApplication().getLicence().getStatus().getCode()) || hasPersonUpdateAccess) {
			itemDto.setAllowToEdit(true);
		} else {
			itemDto.setAllowToEdit(false);
		}

		return itemDto;
	}

	public static ParticularUpdateDto buildFromTouristGuide(Cache cache, ParticularUpdateDto itemDto, TouristGuide tg, PaymentHelper paymentHelper) {

		itemDto.setNric(tg.getUin());
		itemDto.setSalutation(tg.getSalutation() != null ? tg.getSalutation().getCode() : null);
		itemDto.setName(tg.getName());
		itemDto.setDob(tg.getDob());
		itemDto.setSex(tg.getSex() != null ? tg.getSex().getCode() : null);
		itemDto.setMaritalStatus(tg.getMaritalStatus() != null ? tg.getMaritalStatus().getCode() : null);
		itemDto.setRace(tg.getRace() != null ? tg.getRace().getCode() : null);
		itemDto.setNationality(tg.getNationality() != null ? tg.getNationality().getCode() : null);
		itemDto.setBirthCountry(tg.getBirthCountry() != null ? tg.getBirthCountry().getCode() : null);
		itemDto.setResidentialStatus(tg.getResidentialStatus() != null ? tg.getResidentialStatus().getCode() : null);
		itemDto.setHighestEduLevel(tg.getHighestEduLevel() != null ? tg.getHighestEduLevel().getCode() : null);
		itemDto.setMobileNo(tg.getMobileNo());
		itemDto.setEmailAddress(tg.getEmailAddress());
		itemDto.setEmployerName(tg.getEmployerName());
		itemDto.setOccupation(tg.getOccupation() != null ? tg.getOccupation().getCode() : null);
		itemDto.setOccupationOther(tg.getOccupationOther());
		itemDto.setWorkPassType(tg.getWorkPassType() != null ? tg.getWorkPassType().getCode() : null);
		itemDto.setWorkpassExpiryDate(tg.getWorkPassExpiryDate());
		itemDto.setAliasName(tg.getAliasName());
		itemDto.setHasConsentEmailAddress(tg.hasConsentEmailAddress());
		itemDto.setHasConsentMobileNo(tg.hasConsentMobileNo());

		// registered and operating address
		var regAddr = tg.getRegisteredAddress();
		var optAddr = tg.getMailingAddress();

		if (regAddr != null) {
			itemDto.setRegType(new ListableDto(regAddr.getAddressType()));
			itemDto.setRegStreet(regAddr.getStreet());
			itemDto.setRegBuilding(regAddr.getBuilding());
			itemDto.setRegBlock(regAddr.getBlock());
			itemDto.setRegFloor(regAddr.getFloor());
			itemDto.setRegUnit(regAddr.getUnit());
			itemDto.setRegPostal(regAddr.getPostal());
			itemDto.setRegForeignLine1(regAddr.getForeignLine1());
			itemDto.setRegForeignLine2(regAddr.getForeignLine2());
			itemDto.setRegForeignLine3(regAddr.getForeignLine3());
		}

		if (optAddr != null) {
			if (regAddr != null && regAddr.equals(optAddr)) {
				itemDto.setIsAddrSame(true);
			} else {
				itemDto.setIsAddrSame(false);
			}
			itemDto.setOptType(new ListableDto(optAddr.getAddressType()));
			itemDto.setOptStreet(optAddr.getStreet());
			itemDto.setOptBuilding(optAddr.getBuilding());
			itemDto.setOptBlock(optAddr.getBlock());
			itemDto.setOptFloor(optAddr.getFloor());
			itemDto.setOptUnit(optAddr.getUnit());
			itemDto.setOptPostal(optAddr.getPostal());
			itemDto.setOptForeignLine1(optAddr.getForeignLine1());
			itemDto.setOptForeignLine2(optAddr.getForeignLine2());
			itemDto.setOptForeignLine3(optAddr.getForeignLine3());
		}

		itemDto.setLicenceStatusCode(tg.getLicence().getStatus().getCode());
		itemDto.setIsWaived(paymentHelper.checkPaymentIsWaived(Codes.TgPaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE));
		itemDto.setPaymentFee(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_PERSON_UPDATE_FEE).getValue()));

		if (Codes.Statuses.TG_ACTIVE.equalsIgnoreCase(tg.getLicence().getStatus().getCode()) || tg.getHasPersonUpdateAccess()) {
			itemDto.setAllowToEdit(true);
		} else {
			itemDto.setAllowToEdit(false);
		}

		return itemDto;
	}

	public static ParticularUpdateDto populateDto(CacheHelper cache, TgPersonUpdate tpu, ParticularUpdateDto dto, TouristGuide tg, PaymentHelper paymentHelper, FileHelper fileHelper,
			UserHelper userHelper, String userLoginId) {

		dto.setIsWorkPassHolder(userHelper.checkWorkPassHolder(userLoginId));
		if (tpu == null) {
			return buildFromTouristGuide(cache, dto, tg, paymentHelper);
		} else {
			return buildFromParticularUpdate(cache, tpu, paymentHelper, fileHelper, userHelper, dto, tg.getHasPersonUpdateAccess(), userLoginId);
		}
	}

	public Boolean getIsWorkPassHolder() {
		return isWorkPassHolder;
	}

	public void setIsWorkPassHolder(Boolean isWorkPassHolder) {
		this.isWorkPassHolder = isWorkPassHolder;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(String birthCountry) {
		this.birthCountry = birthCountry;
	}

	public String getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public String getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(String highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOccupationOther() {
		return occupationOther;
	}

	public void setOccupationOther(String occupationOther) {
		this.occupationOther = occupationOther;
	}

	public String getWorkPassType() {
		return workPassType;
	}

	public void setWorkPassType(String workPassType) {
		this.workPassType = workPassType;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getRegStreet() {
		return regStreet;
	}

	public void setRegStreet(String regStreet) {
		this.regStreet = regStreet;
	}

	public String getRegBuilding() {
		return regBuilding;
	}

	public void setRegBuilding(String regBuilding) {
		this.regBuilding = regBuilding;
	}

	public String getRegBlock() {
		return regBlock;
	}

	public void setRegBlock(String regBlock) {
		this.regBlock = regBlock;
	}

	public String getRegFloor() {
		return regFloor;
	}

	public void setRegFloor(String regFloor) {
		this.regFloor = regFloor;
	}

	public String getRegUnit() {
		return regUnit;
	}

	public void setRegUnit(String regUnit) {
		this.regUnit = regUnit;
	}

	public String getRegPostal() {
		return regPostal;
	}

	public void setRegPostal(String regPostal) {
		this.regPostal = regPostal;
	}

	public String getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(String registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public String getOptStreet() {
		return optStreet;
	}

	public void setOptStreet(String optStreet) {
		this.optStreet = optStreet;
	}

	public String getOptBuilding() {
		return optBuilding;
	}

	public void setOptBuilding(String optBuilding) {
		this.optBuilding = optBuilding;
	}

	public String getOptBlock() {
		return optBlock;
	}

	public void setOptBlock(String optBlock) {
		this.optBlock = optBlock;
	}

	public String getOptFloor() {
		return optFloor;
	}

	public void setOptFloor(String optFloor) {
		this.optFloor = optFloor;
	}

	public String getOptUnit() {
		return optUnit;
	}

	public void setOptUnit(String optUnit) {
		this.optUnit = optUnit;
	}

	public String getOptPostal() {
		return optPostal;
	}

	public void setOptPostal(String optPostal) {
		this.optPostal = optPostal;
	}

	public String getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(String operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public String getRegForeignLine1() {
		return regForeignLine1;
	}

	public void setRegForeignLine1(String regForeignLine1) {
		this.regForeignLine1 = regForeignLine1;
	}

	public String getRegForeignLine2() {
		return regForeignLine2;
	}

	public void setRegForeignLine2(String regForeignLine2) {
		this.regForeignLine2 = regForeignLine2;
	}

	public String getRegForeignLine3() {
		return regForeignLine3;
	}

	public void setRegForeignLine3(String regForeignLine3) {
		this.regForeignLine3 = regForeignLine3;
	}

	public String getOptForeignLine1() {
		return optForeignLine1;
	}

	public void setOptForeignLine1(String optForeignLine1) {
		this.optForeignLine1 = optForeignLine1;
	}

	public String getOptForeignLine2() {
		return optForeignLine2;
	}

	public void setOptForeignLine2(String optForeignLine2) {
		this.optForeignLine2 = optForeignLine2;
	}

	public String getOptForeignLine3() {
		return optForeignLine3;
	}

	public void setOptForeignLine3(String optForeignLine3) {
		this.optForeignLine3 = optForeignLine3;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public String getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(String guidingLanguage) {
		this.guidingLanguage = guidingLanguage;
	}

	public String getAreaSpecification() {
		return areaSpecification;
	}

	public void setAreaSpecification(String areaSpecification) {
		this.areaSpecification = areaSpecification;
	}

	public String getLicenceType() {
		return licenceType;
	}

	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}

	public FileDto getPhoto() {
		return photo;
	}

	public void setPhoto(FileDto photo) {
		this.photo = photo;
	}

	public FileDto getPrevPhoto() {
		return prevPhoto;
	}

	public void setPrevPhoto(FileDto prevPhoto) {
		this.prevPhoto = prevPhoto;
	}

	public List<FileDto> getOtherSupportDocs() {
		return otherSupportDocs;
	}

	public void setOtherSupportDocs(List<FileDto> otherSupportDocs) {
		this.otherSupportDocs = otherSupportDocs;
	}

	public List<WorkflowActionDto> getWorkflowActions() {
		return workflowActions;
	}

	public void setWorkflowActions(List<WorkflowActionDto> workflowActions) {
		this.workflowActions = workflowActions;
	}

	public Boolean isConvictChecked() {
		return convictChecked;
	}

	public void setConvictChecked(Boolean convictChecked) {
		this.convictChecked = convictChecked;
	}

	public LocalDate getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDate offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public String getEnforcementOutcome() {
		return enforcementOutcome;
	}

	public void setEnforcementOutcome(String enforcementOutcome) {
		this.enforcementOutcome = enforcementOutcome;
	}

	public Boolean getHasConsentMobileNo() {
		return hasConsentMobileNo;
	}

	public void setHasConsentMobileNo(Boolean hasConsentMobileNo) {
		this.hasConsentMobileNo = hasConsentMobileNo;
	}

	public Boolean getHasConsentEmailAddress() {
		return hasConsentEmailAddress;
	}

	public void setHasConsentEmailAddress(Boolean hasConsentEmailAddress) {
		this.hasConsentEmailAddress = hasConsentEmailAddress;
	}

	public Integer getPaymentFee() {
		return paymentFee;
	}

	public void setPaymentFee(Integer paymentFee) {
		this.paymentFee = paymentFee;
	}

	public Boolean getIsAddrSame() {
		return isAddrSame;
	}

	public void setIsAddrSame(Boolean isAddrSame) {
		this.isAddrSame = isAddrSame;
	}

	public String getStatusRemark() {
		return statusRemark;
	}

	public void setStatusRemark(String statusRemark) {
		this.statusRemark = statusRemark;
	}

	public LocalDate getWorkpassExpiryDate() {
		return workpassExpiryDate;
	}

	public void setWorkpassExpiryDate(LocalDate workpassExpiryDate) {
		this.workpassExpiryDate = workpassExpiryDate;
	}

	public Boolean isMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public ListableDto getRegType() {
		return regType;
	}

	public void setRegType(ListableDto regType) {
		this.regType = regType;
	}

	public ListableDto getOptType() {
		return optType;
	}

	public void setOptType(ListableDto optType) {
		this.optType = optType;
	}

	public Boolean getIsPaymentSuccess() {
		return isPaymentSuccess;
	}

	public void setIsPaymentSuccess(Boolean isPaymentSuccess) {
		this.isPaymentSuccess = isPaymentSuccess;
	}

	public Boolean getConvictChecked() {
		return convictChecked;
	}

	public Boolean getAllowToEdit() {
		return allowToEdit;
	}

	public void setAllowToEdit(Boolean allowToEdit) {
		this.allowToEdit = allowToEdit;
	}

	public Boolean getIsPaymentRequired() {
		return isPaymentRequired;
	}

	public void setIsPaymentRequired(Boolean isPaymentRequired) {
		this.isPaymentRequired = isPaymentRequired;
	}

	public List<ParticularUpdateCompareDetails> getCompareDetailsDto() {
		return compareDetailsDto;
	}

	public void setCompareDetailsDto(List<ParticularUpdateCompareDetails> compareDetailsDto) {
		this.compareDetailsDto = compareDetailsDto;
	}

	public void setCompareWorkPassDetailsDto(List<ParticularUpdateCompareDetails> compareWorkPassDetailsDto) {
		this.compareWorkPassDetailsDto = compareWorkPassDetailsDto;
	}

	public List<ParticularUpdateCompareDetails> getCompareWorkPassDetailsDto() {
		return compareWorkPassDetailsDto;
	}

	public PaymentRequestDto getAppFee() {
		return appFee;
	}

	public void setAppFee(PaymentRequestDto appFee) {
		this.appFee = appFee;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getSnapshotMyInfoPopulated() {
		return isSnapshotMyInfoPopulated;
	}

	public void setIsSnapshotMyInfoPopulated(Boolean isSnapshotMyInfoPopulated) {
		this.isSnapshotMyInfoPopulated = isSnapshotMyInfoPopulated;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Boolean getIsWaived() {
		return isWaived;
	}

	public void setIsWaived(Boolean isWaived) {
		this.isWaived = isWaived;
	}

}
