package gov.stb.tag.dto.tg.particularUpdate;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgPersonUpdate;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParticularUpdateItemDto extends SearchDto {

	@MapProjection(path = "id")
	private Integer particularUpdateId;

	@MapProjection(path = "application.licence.touristGuide.name")
	private String name;

	@MapProjection(path = "application.licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "application.submissionDate")
	private LocalDateTime submissionDate;

	@MapProjection(path = "application.applicationNo")
	private String applicationNo;

	@MapProjection(path = "application.id")
	private Integer applicationId;

	@MapProjection(path = "application.lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "application.lastAction.status.label")
	private String status;

	@MapProjection(path = "application.assignee.name")
	private String assignedOfficer;

	@MapProjection(path = "application.licence.touristGuide.uin")
	private String nricFin;

	@MapProjection(path = "application.licence.expiryDate")
	private LocalDate licenceExpiryDate;

	public ParticularUpdateItemDto() {

	}

	public static ParticularUpdateItemDto buildFromParticularUpdate(Cache cache, TgPersonUpdate tpu) {
		var puResultDto = new ParticularUpdateItemDto();

		puResultDto.setParticularUpdateId(tpu.getId());
		puResultDto.setName(tpu.getName());

		var application = tpu.getApplication();
		puResultDto.setStatus(cache.getLabel(application.getLastAction().getStatus(), true));
		puResultDto.setSubmissionDate(application.getSubmissionDate());

		return puResultDto;

	}

	public Integer getParticularUpdateId() {
		return particularUpdateId;
	}

	public void setParticularUpdateId(Integer particularUpdateId) {
		this.particularUpdateId = particularUpdateId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public String getNricFin() {
		return nricFin;
	}

	public void setNricFin(String nricFin) {
		this.nricFin = nricFin;
	}

	public Integer getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Integer applicationId) {
		this.applicationId = applicationId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
