package gov.stb.tag.dto.tg.stipend;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;

import gov.stb.tag.dto.AuditableEntityDto;
import gov.stb.tag.model.TgStipendConfig;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.util.NumeralUtil;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgStipendConfigDto extends AuditableEntityDto {

	private Integer id;

	private LocalDate periodStartDate;

	private LocalDate periodEndDate;

	private LocalDate licenceStartBefore;

	private String[] guidingLanguages;

	private BigDecimal amount;

	private Boolean forAppeal;

	private String[] tgMultiCtrl;

	private String preamble;

	private String supportingDocText;

	private String declaration;

	private boolean isEditable = true;

	private String[] appealedTGId;

	public static TgStipendConfigDto buildFromModel(TgStipendConfig model, Boolean forInternet, UserRepository userRepo) {
		TgStipendConfigDto dto = new TgStipendConfigDto();

		dto.setId(model.getId());
		dto.setAmount(model.getAmount());
		dto.setForAppeal(model.getForAppeal());
		dto.setPreamble(model.getPreamble());
		dto.setSupportingDocText(model.getSupportingDocText());
		dto.setDeclaration(model.getDeclaration());

		if (!forInternet) {
			dto.setPeriodStartDate(model.getPeriodStartDate());
			dto.setPeriodEndDate(model.getPeriodEndDate());
			dto.setLicenceStartBefore(model.getLicenceStartBefore());
			if (!Strings.isNullOrEmpty(model.getGuidingLanguages())) {
				dto.setGuidingLanguages(model.getGuidingLanguages().split(","));
			}
			// if (!Strings.isNullOrEmpty(model.getAppealTgLicIds())) {
			// dto.setTgMultiCtrl(model.getAppealTgLicIds().split(","));
			// }
			if (model.getAppealTgs() != null) {
				List<Integer> tgs = model.getAppealTgs().stream().map(TouristGuide::getId).collect(Collectors.toList());
				try {
					dto.setTgMultiCtrl(NumeralUtil.parseStringArray(tgs));
				} catch (Exception e) {
				}
			}

			dto.buildEditorDetailsFromModel(model, dto, userRepo);
		}

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getPeriodStartDate() {
		return periodStartDate;
	}

	public void setPeriodStartDate(LocalDate periodStartDate) {
		this.periodStartDate = periodStartDate;
	}

	public LocalDate getPeriodEndDate() {
		return periodEndDate;
	}

	public void setPeriodEndDate(LocalDate periodEndDate) {
		this.periodEndDate = periodEndDate;
	}

	public LocalDate getLicenceStartBefore() {
		return licenceStartBefore;
	}

	public void setLicenceStartBefore(LocalDate licenceStartBefore) {
		this.licenceStartBefore = licenceStartBefore;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Boolean getForAppeal() {
		return forAppeal;
	}

	public void setForAppeal(Boolean forAppeal) {
		this.forAppeal = forAppeal;
	}

	public String getPreamble() {
		return preamble;
	}

	public void setPreamble(String preamble) {
		this.preamble = preamble;
	}

	public String getSupportingDocText() {
		return supportingDocText;
	}

	public void setSupportingDocText(String supportingDocText) {
		this.supportingDocText = supportingDocText;
	}

	public String getDeclaration() {
		return declaration;
	}

	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}

	public String[] getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(String[] guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public boolean isEditable() {
		return isEditable;
	}

	public void setEditable(boolean isEditable) {
		this.isEditable = isEditable;
	}

	public String[] getTgMultiCtrl() {
		return tgMultiCtrl;
	}

	public void setTgMultiCtrl(String[] tgMultiCtrl) {
		this.tgMultiCtrl = tgMultiCtrl;
	}

	public String[] getAppealedTGId() {
		return appealedTGId;
	}

	public void setAppealedTGId(String[] appealedTGId) {
		this.appealedTGId = appealedTGId;
	}
}
