package gov.stb.tag.dto.tg.stipend;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.payment.PaymentRequestDto;
import gov.stb.tag.dto.tg.application.TgApplicationDto;
import gov.stb.tag.helper.ApplicationHelper;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.PaymentHelper;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.TgStipend;
import gov.stb.tag.model.TgStipendConfig;
import gov.stb.tag.model.TouristGuide;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgStipendDto extends TgApplicationDto {

	private Integer id;
	private String guidingLanguage;
	private ListableDto nationality;
	private ListableDto residentialStatus;
	private String nameAsPerBank;
	private String bankName;
	private String bankCode;
	private String bankBranchCode;
	private String bankAccountNo;
	private BigDecimal amount;
	private Boolean isDraft;
	private Boolean isEligible;
	private List<FileDto> supportingDocs;
	private Boolean hasFollowUpRequiredByFinance;
	private Boolean isPendingFollowUp;

	// config
	private TgStipendConfigDto configDto;

	// Payment
	private PaymentRequestDto appPayout;

	public static TgStipendDto buildNewSubmission(Cache cache, TouristGuide tg, TgStipendConfig config) {
		TgStipendDto dto = new TgStipendDto();
		dto = dto.buildFromLicence(cache, tg.getLicence(), dto);
		dto.setGuidingLanguage(tg.getGuidingLanguagesWithComma(cache));
		dto.setNationality(new ListableDto(tg.getNationality()));
		dto.setResidentialStatus(new ListableDto(tg.getResidentialStatus()));

		// config
		dto.setConfigDto(TgStipendConfigDto.buildFromModel(config, true, null));
		return dto;
	}

	public static TgStipendDto buildSubmissionFromModel(CacheHelper cache, ApplicationHelper appHelper, TgStipend model, TgStipendConfig config, TgStipendDto dto, PaymentHelper paymentHelper,
			FileHelper fileHelper) {
		var app = model.getApplication();
		if (app != null) {
			dto = dto.buildFromApplication(cache, appHelper, model.getApplication(), dto);
		}

		// config
		dto.setConfigDto(TgStipendConfigDto.buildFromModel(config, true, null));

		dto.setGuidingLanguage(model.getGuidingLanguages());
		dto.setResidentialStatus(new ListableDto(model.getResidentialStatus()));

		dto.setId(model.getId());
		dto.setNameAsPerBank(model.getNameAsPerBank());
		dto.setBankName(model.getBankName());
		dto.setBankCode(model.getBankCode());
		dto.setBankBranchCode(model.getBankBranchCode());
		dto.setBankAccountNo(model.getBankAccountNo());
		dto.setBillRefNo(model.getAppBillRefNo());
		dto.setAmount(model.getAmount());

		dto.setIsDraft(app.getIsDraft());
		dto.setHasFollowUpRequiredByFinance(model.getHasFollowUpRequiredByFinance());
		dto.setIsPendingFollowUp(model.isPendingFollowUp());

		var appFiles = app.getApplicationFiles();
		if (CollectionUtils.isNotEmpty(appFiles)) {
			List<FileDto> supportingDocuments = new ArrayList<FileDto>();
			for (ApplicationFile applicationFile : appFiles) {
				if (Codes.TgDocumentTypes.TG_DOC_STIPEND.equals(applicationFile.getDocumentType().getCode())) {
					supportingDocuments.add(FileDto.buildFromFile(applicationFile.getFile(), applicationFile.getDocumentType(), fileHelper));
				}
			}

			if (supportingDocuments != null && supportingDocuments.size() > 0) {
				dto.setSupportingDocs(supportingDocuments);
			}
		}

		if (!Strings.isNullOrEmpty(model.getAppBillRefNo())) {
			dto.setAppPayout(new PaymentRequestDto(cache, paymentHelper.getPaymentRequest(model.getAppBillRefNo()), Boolean.FALSE));
		}

		return dto;
	}

	public static TgStipendDto buildDashboardNotification(CacheHelper cache, ApplicationHelper appHelper, TgStipend model, Boolean eligible, TgStipendConfig config) {
		TgStipendDto dto = new TgStipendDto();
		dto.setConfigDto(new TgStipendConfigDto());
		TgStipendConfig finalConfig = model == null ? config : model.getTgStipendConfig();

		if (model != null) {
			dto.setId(model.getId());
			var app = model.getApplication();
			if (app != null) {
				dto = dto.buildFromApplication(cache, appHelper, model.getApplication(), dto);
				dto.setIsPendingFollowUp(model.isPendingFollowUp());
			}
		}

		if (finalConfig != null) {
			dto.getConfigDto().setId(finalConfig.getId());
			dto.getConfigDto().setPeriodStartDate(finalConfig.getPeriodStartDate());
			dto.getConfigDto().setPeriodEndDate(finalConfig.getPeriodEndDate());
		}
		dto.setIsEligible(eligible);

		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(String guidingLanguage) {
		this.guidingLanguage = guidingLanguage;
	}

	public ListableDto getNationality() {
		return nationality;
	}

	public void setNationality(ListableDto nationality) {
		this.nationality = nationality;
	}

	public ListableDto getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(ListableDto residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public String getNameAsPerBank() {
		return nameAsPerBank;
	}

	public void setNameAsPerBank(String nameAsPerBank) {
		this.nameAsPerBank = nameAsPerBank;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankBranchCode() {
		return bankBranchCode;
	}

	public void setBankBranchCode(String bankBranchCode) {
		this.bankBranchCode = bankBranchCode;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public PaymentRequestDto getAppPayout() {
		return appPayout;
	}

	public void setAppPayout(PaymentRequestDto appPayout) {
		this.appPayout = appPayout;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public Boolean getIsEligible() {
		return isEligible;
	}

	public void setIsEligible(Boolean eligible) {
		isEligible = eligible;
	}

	public List<FileDto> getSupportingDocs() {
		return supportingDocs;
	}

	public void setSupportingDocs(List<FileDto> supportingDocs) {
		this.supportingDocs = supportingDocs;
	}

	public TgStipendConfigDto getConfigDto() {
		return configDto;
	}

	public void setConfigDto(TgStipendConfigDto configDto) {
		this.configDto = configDto;
	}

	public Boolean getHasFollowUpRequiredByFinance() { return hasFollowUpRequiredByFinance; }

	public void setHasFollowUpRequiredByFinance(Boolean hasFollowUpRequiredByFinance) { this.hasFollowUpRequiredByFinance = hasFollowUpRequiredByFinance; }

	public Boolean getIsPendingFollowUp() { return isPendingFollowUp; }

	public void setIsPendingFollowUp(Boolean isPendingFollowUp) { this.isPendingFollowUp = isPendingFollowUp; }
}
