package gov.stb.tag.dto.tg.stipend;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.tg.application.TgApplicationSearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgStipendSearchDto extends TgApplicationSearchDto {

	private LocalDateTime approveDateFrom;
	private LocalDateTime approveDateTo;
	private List<Integer> appIds;

	public LocalDateTime getApproveDateFrom() {
		return approveDateFrom;
	}

	public void setApproveDateFrom(LocalDateTime approveDateFrom) {
		this.approveDateFrom = approveDateFrom;
	}

	public LocalDateTime getApproveDateTo() {
		return approveDateTo;
	}

	public void setApproveDateTo(LocalDateTime approveDateTo) {
		this.approveDateTo = approveDateTo;
	}

	public List<Integer> getAppIds() {
		return appIds;
	}

	public void setAppIds(List<Integer> appIds) {
		this.appIds = appIds;
	}

}
