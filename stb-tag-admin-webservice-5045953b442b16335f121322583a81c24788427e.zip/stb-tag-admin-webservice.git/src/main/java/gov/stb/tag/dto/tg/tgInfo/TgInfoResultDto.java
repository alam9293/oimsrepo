package gov.stb.tag.dto.tg.tgInfo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.TgInfo;
import gov.stb.tag.model.TouristGuide;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgInfoResultDto extends EntityDto {

	private Integer touristGuideId;

	private Integer licenceId;

	private Integer id;

	private String personName;

	private String companyName;

	private String typeCode;

	private String typeLabel;

	private String typeOther;

	private String details;

	private List<FileDto> files = new ArrayList<FileDto>();

	public List<Integer> deletedFileIds = new ArrayList<>();

	private Boolean isDeleted;

	private String updatedBy;

	private LocalDateTime updatedDate;

	public static Object buildDtoFromModel(CacheHelper cache, TgInfo model, FileHelper fileHelper) {
		TgInfoResultDto dto = new TgInfoResultDto();
		dto.setTouristGuideId(model.getTouristGuide().getId());
		dto.setId(model.getId());
		dto.setPersonName(model.getPersonName());
		dto.setCompanyName(model.getCompanyName() != null ? model.getCompanyName() : "");
		dto.setTypeCode(model.getType() != null ? model.getType().getCode() : null);
		dto.setTypeLabel(model.getType() != null ? model.getType().getLabel() : null);
		dto.setTypeOther(model.getTypeOther());
		dto.setDetails(model.getDetails());
		dto.setIsDeleted(model.getIsDeleted());
		dto.setUpdatedBy(model.getUpdatedBy());
		dto.setUpdatedDate(model.getUpdatedDate());

		if (model.getFiles() != null && model.getFiles().size() > 0) {
			for (File row : model.getFiles()) {
				dto.getFiles().add(FileDto.buildFromFile(row));
			}
		}
		return dto;
	}

	public TgInfo buildModelFromDto(TgInfoResultDto dto, TgInfo model, CacheHelper cache, FileHelper fileHelper, TouristGuide tg) {
		model.setTouristGuide(tg);
		model.setPersonName(dto.getPersonName());
		model.setCompanyName(dto.getCompanyName());
		model.setType(cache.getType(dto.getTypeCode()));
		model.setTypeOther(dto.getTypeOther());
		model.setDetails(dto.getDetails());

		// save file
		Set<File> files = new HashSet<>();
		if (dto.getFiles() != null) {
			for (FileDto doc : dto.getFiles()) {
				File file = new File();
				if (doc.getId() == null) {
					file = fileHelper.saveFile(doc, false);
				} else {
					file = fileHelper.getFile(doc.getId());
				}
				files.add(file);
			}
		}

		if (dto.getDeletedFileIds() != null) {
			for (Integer fileId : dto.getDeletedFileIds()) {
				File file = fileHelper.getFile(fileId);
				if (file != null) {
					fileHelper.deleteFile(file);
				}
			}
		}

		if (files.size() > 0) {
			model.setFiles(files);
		}
		return model;
	}

	public Integer getTouristGuideId() {
		return touristGuideId;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public Integer getId() {
		return id;
	}

	public String getPersonName() {
		return personName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public String getTypeOther() {
		return typeOther;
	}

	public String getDetails() {
		return details;
	}

	public List<FileDto> getFiles() {
		return files;
	}

	public List<Integer> getDeletedFileIds() {
		return deletedFileIds;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setTouristGuideId(Integer touristGuideId) {
		this.touristGuideId = touristGuideId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public void setTypeOther(String typeOther) {
		this.typeOther = typeOther;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public void setFiles(List<FileDto> files) {
		this.files = files;
	}

	public void setDeletedFileIds(List<Integer> deletedFileIds) {
		this.deletedFileIds = deletedFileIds;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}
}
