package gov.stb.tag.dto.tg.tgInfo;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgInfoSearchDto extends SearchDto {

}
