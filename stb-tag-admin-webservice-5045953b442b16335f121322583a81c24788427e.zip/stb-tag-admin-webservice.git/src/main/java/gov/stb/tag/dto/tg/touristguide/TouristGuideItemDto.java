package gov.stb.tag.dto.tg.touristguide;

import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TouristGuide;
import io.jsonwebtoken.lang.Collections;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TouristGuideItemDto {

	protected transient static Logger logger = LoggerFactory.getLogger(TouristGuideItemDto.class);

	private String licenceNo;
	private String name;
	private String aliasName;
	private String status;
	private String emailAddress;
	private String phoneNo;
	private String touristType;
	private Set<String> guidingLanguages;
	private Set<String> areaSpecialisations;
	private String languagesWithComma;
	private String areaSpecialisationsWithComma;
	private String photo;
	private String photoExtension;
	private Integer publicFileId;
	private Boolean displayPhoto;
	private String hash;

	public TouristGuideItemDto() {

	}

	public static TouristGuideItemDto buildFromTouristGuide(Cache cache, TouristGuide tg) {
		TouristGuideItemDto dto = new TouristGuideItemDto();

		dto.setName(tg.getName());
		dto.setAliasName(tg.getAliasName());
		if (tg.getHasConsentEmailAddress() != null && Boolean.TRUE.equals(tg.getHasConsentEmailAddress()) && !tg.getLicence().getStatus().getCode().equals(Codes.Statuses.TG_INACTIVE)
				&& !tg.getLicence().getStatus().getCode().equals(Codes.Statuses.TG_CANCELLED)) {
			dto.setEmailAddress(tg.getEmailAddress());
		}
		if (tg.getHasConsentMobileNo() != null && Boolean.TRUE.equals(tg.getHasConsentMobileNo()) && !tg.getLicence().getStatus().getCode().equals(Codes.Statuses.TG_INACTIVE)
				&& !tg.getLicence().getStatus().getCode().equals(Codes.Statuses.TG_CANCELLED)) {
			dto.setPhoneNo(tg.getMobileNo());
		}

		dto.setGuidingLanguages(tg.getGuidingLanguages().stream().map(u -> cache.getLabel(u, false)).collect(Collectors.toSet()));
		dto.setLanguagesWithComma(StringUtils.join(dto.getGuidingLanguages(), ", "));
		if (!Collections.isEmpty(tg.getSpecializedAreas())) {
			dto.setAreaSpecialisations(tg.getSpecializedAreas().stream().map(u -> cache.getLabel(u, false)).collect(Collectors.toSet()));
			dto.setAreaSpecialisationsWithComma(StringUtils.join(dto.getAreaSpecialisations(), ", "));
		}

		if (tg.getPhoto() != null && !tg.getLicence().getStatus().getCode().equals(Codes.Statuses.TG_INACTIVE) && !tg.getLicence().getStatus().getCode().equals(Codes.Statuses.TG_CANCELLED)) {
			dto.setPublicFileId(tg.getPhoto().getPublicFileId());
			dto.setDisplayPhoto(Boolean.TRUE);
			dto.setHash(tg.getPhoto().getHash());
		} else {
			dto.setDisplayPhoto(Boolean.FALSE);
		}

		var licence = tg.getLicence();
		dto.setLicenceNo(licence.getLicenceNo());
		dto.setTouristType(cache.getLabel(licence.getTier(), false));
		dto.setStatus(licence.getStatus().getCode());

		return dto;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getTouristType() {
		return touristType;
	}

	public void setTouristType(String touristType) {
		this.touristType = touristType;
	}

	public Set<String> getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(Set<String> guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public String getLanguagesWithComma() {
		return languagesWithComma;
	}

	public void setLanguagesWithComma(String languagesWithComma) {
		this.languagesWithComma = languagesWithComma;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getPhotoExtension() {
		return photoExtension;
	}

	public void setPhotoExtension(String photoExtension) {
		this.photoExtension = photoExtension;
	}

	public Set<String> getAreaSpecialisations() {
		return areaSpecialisations;
	}

	public void setAreaSpecialisations(Set<String> areaSpecialisations) {
		this.areaSpecialisations = areaSpecialisations;
	}

	public String getAreaSpecialisationsWithComma() {
		return areaSpecialisationsWithComma;
	}

	public void setAreaSpecialisationsWithComma(String areaSpecialisationsWithComma) {
		this.areaSpecialisationsWithComma = areaSpecialisationsWithComma;
	}

	public Integer getPublicFileId() {
		return publicFileId;
	}

	public void setPublicFileId(Integer publicFileId) {
		this.publicFileId = publicFileId;
	}

	public Boolean getDisplayPhoto() {
		return displayPhoto;
	}

	public void setDisplayPhoto(Boolean displayPhoto) {
		this.displayPhoto = displayPhoto;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}
}
