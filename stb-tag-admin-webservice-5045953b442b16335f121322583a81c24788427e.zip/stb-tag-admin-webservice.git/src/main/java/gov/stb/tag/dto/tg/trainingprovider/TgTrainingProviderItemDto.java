package gov.stb.tag.dto.tg.trainingprovider;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgTrainingProviderItemDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "uen")
	private String uen;

	@MapProjection(path = "name")
	private String name;

	@MapProjection(path = "contactPerson")
	private String contactPerson;

	@MapProjection(path = "status.label")
	private String status;

	@MapProjection(path = "isPdc")
	private Boolean isPdc;

	@MapProjection(path = "isMrc")
	private Boolean isMrc;

	@MapProjection(path = "isAto")
	private Boolean isAto;

	public TgTrainingProviderItemDto() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getIsPdc() {
		return isPdc;
	}

	public void setIsPdc(Boolean isPdc) {
		this.isPdc = isPdc;
	}

	public Boolean getIsMrc() {
		return isMrc;
	}

	public void setIsMrc(Boolean isMrc) {
		this.isMrc = isMrc;
	}

	public Boolean getIsAto() {
		return isAto;
	}

	public void setIsAto(Boolean isAto) {
		this.isAto = isAto;
	}

}
