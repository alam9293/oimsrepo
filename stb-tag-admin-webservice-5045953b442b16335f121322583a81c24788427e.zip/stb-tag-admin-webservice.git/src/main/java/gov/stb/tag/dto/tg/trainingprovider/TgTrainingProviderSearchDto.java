package gov.stb.tag.dto.tg.trainingprovider;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.SearchDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgTrainingProviderSearchDto extends SearchDto {

	private String uen;
	private String name;
	private String contactPerson;
	private String status;
	private String[] tpTypes;

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String[] getTpTypes() {
		return tpTypes;
	}

	public void setTpTypes(String[] tpTypes) {
		this.tpTypes = tpTypes;
	}

}
