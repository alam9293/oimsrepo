package gov.stb.tag.dto.tg.trainingprovider;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.AddressDto;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.TgTrainingProvider;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TrainingProviderDto extends EntityDto {

	private Integer id;
	private String name;
	private String uen;
	private String contactPerson;
	private ListableDto status;
	private Boolean isPdc;
	private Boolean isMrc;
	private Boolean isAto;
	private AddressDto address;
	private String email;
	private String contactNo;
	private String contactPerson1;
	private String email1;
	private String contactNo1;
	private String profileSummary;
	private String webLink;
	private String signUpLink;

	public TrainingProviderDto(Cache cache, TgTrainingProvider tp) {
		this.id = tp.getId();
		this.name = tp.getName();
		this.uen = tp.getUen();
		this.contactPerson = tp.getContactPerson();
		this.status = new ListableDto(cache.getStatus(tp.getStatus().getCode()));
		this.isPdc = tp.isPdc();
		this.isMrc = tp.isMrc();
		this.isAto = tp.isAto();
		this.address = AddressDto.buildFromAddress(cache, tp.getAddress());
		this.email = tp.getEmail();
		this.contactNo = tp.getContactNo();
		this.contactPerson1 = tp.getContactPerson1();
		this.email1 = tp.getEmail1();
		this.contactNo1 = tp.getContactNo1();
		this.profileSummary = tp.getProfileSummary();
		this.webLink = tp.getWebLink();
		this.signUpLink = tp.getSignUpLink();
	}

	public TrainingProviderDto() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public ListableDto getStatus() {
		return status;
	}

	public void setStatus(ListableDto status) {
		this.status = status;
	}

	public Boolean getIsPdc() {
		return isPdc;
	}

	public void setIsPdc(Boolean isPdc) {
		this.isPdc = isPdc;
	}

	public Boolean getIsMrc() {
		return isMrc;
	}

	public void setIsMrc(Boolean isMrc) {
		this.isMrc = isMrc;
	}

	public Boolean getIsAto() {
		return isAto;
	}

	public void setIsAto(Boolean isAto) {
		this.isAto = isAto;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getContactPerson1() {
		return contactPerson1;
	}

	public void setContactPerson1(String contactPerson1) {
		this.contactPerson1 = contactPerson1;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getContactNo1() {
		return contactNo1;
	}

	public void setContactNo1(String contactNo1) {
		this.contactNo1 = contactNo1;
	}

	public String getProfileSummary() {
		return profileSummary;
	}

	public void setProfileSummary(String profileSummary) {
		this.profileSummary = profileSummary;
	}

	public String getWebLink() {
		return webLink;
	}

	public void setWebLink(String webLink) {
		this.webLink = webLink;
	}

	public String getSignUpLink() {
		return signUpLink;
	}

	public void setSignUpLink(String signUpLink) {
		this.signUpLink = signUpLink;
	}

}
