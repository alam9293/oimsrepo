package gov.stb.tag.dto.workflow;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Roles;
import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.dashboard.UserProfileDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.WorkflowConfig;
import gov.stb.tag.model.WorkflowStep;
import gov.stb.tag.model.WorkflowStepAssignment;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowConfigItemDto extends EntityDto {

	private List<WorkflowUserRoleDto> roles;

	private List<String> levels;

	private List<WorkflowStepDto> workflowSteps;

	private String[] stringOfRoles;

	public static WorkflowConfigItemDto buildFromWorkflowConfigs(Cache cache, List<WorkflowStep> workflowSteps, List<WorkflowConfig> workflowConfigs, List<User> users, String workflowStepType) {

		WorkflowConfigItemDto workflowItemDto = new WorkflowConfigItemDto();

		if (users != null) {
			List<WorkflowUserRoleDto> roleDtos = new ArrayList<>();
			workflowSteps.forEach(ws -> {
				WorkflowUserRoleDto wurDto = new WorkflowUserRoleDto();
				Role role = ws.getRole();
				wurDto.setRole(role.getLabel());

				if (Codes.WorkflowStep.WKFLW_STEP_TG_APPLICATION.equalsIgnoreCase(workflowStepType) || Codes.WorkflowStep.WKFLW_STEP_TG.equalsIgnoreCase(workflowStepType)
						|| (Codes.WorkflowStep.WKFLW_STEP_TA.equalsIgnoreCase(workflowStepType) && Roles.TA_HEAD_OF_DEPARTMENT.equalsIgnoreCase(role.getCode()))) {
					List<UserProfileDto> userProfileDtos = new ArrayList<>();
					users.forEach(user -> {
						if (user.getRoles().contains(role) && !userProfileDtos.stream().anyMatch(u -> u.getId().equals(user.getId()))) {
							userProfileDtos.add(UserProfileDto.buildFromUser(cache, user, null));
						}
					});
					wurDto.setUsers(userProfileDtos);
				}
				roleDtos.add(wurDto);
			});

			workflowItemDto.setRoles(roleDtos);
		}

		List<String> levels = new ArrayList<>();
		for (int stepIndex = 1; stepIndex <= workflowSteps.size(); stepIndex++) {
			String levelLabel = "level".concat(Integer.toString(stepIndex));
			levels.add(levelLabel);
		}
		workflowItemDto.setLevels(levels);

		List<WorkflowStepDto> workflowStepDtos = new ArrayList<>();
		workflowConfigs.forEach(u -> {
			WorkflowStepDto dto = new WorkflowStepDto();
			Type appOrWkflwType = u.getAppOrWkflwType();
			dto.setApplicationTypeCode(appOrWkflwType.getCode());
			dto.setApplicationTypeLabel(appOrWkflwType.getLabel());

			int i = 1;
			TreeMap<String, Object> steps = new TreeMap<>();
			for (WorkflowStep ws : workflowSteps) {
				String levelLabel = "level".concat(Integer.toString(i));

				Optional<WorkflowStepAssignment> wsaOptional = u.getWorkflowStepAssignments().stream().filter(a -> a.getWorkflowStep().getId().equals(ws.getId())).findAny();

				Boolean isChecked = false;
				Integer assigneeId = null;
				if (wsaOptional.isPresent()) {
					isChecked = true;

					if (Codes.WorkflowStep.WKFLW_STEP_TG_APPLICATION.equalsIgnoreCase(workflowStepType) || Codes.WorkflowStep.WKFLW_STEP_TG.equalsIgnoreCase(workflowStepType)
							|| (Codes.WorkflowStep.WKFLW_STEP_TA.equalsIgnoreCase(workflowStepType) && Roles.TA_HEAD_OF_DEPARTMENT.equalsIgnoreCase(ws.getRole().getCode()))) {
						User user = wsaOptional.get().getUser();
						if (user != null) {
							assigneeId = user.getId();
						}
					}
				}

				steps.put(levelLabel, isChecked);
				steps.put(levelLabel.concat("Assignee"), assigneeId);
				dto.setSteps(steps);
				i++;
			}

			workflowStepDtos.add(dto);
		});
		workflowItemDto.setWorkflowSteps(workflowStepDtos);

		return workflowItemDto;
	}

	public List<WorkflowUserRoleDto> getRoles() {
		return roles;
	}

	public void setRoles(List<WorkflowUserRoleDto> roles) {
		this.roles = roles;
	}

	public List<WorkflowStepDto> getWorkflowSteps() {
		return workflowSteps;
	}

	public void setWorkflowSteps(List<WorkflowStepDto> workflowSteps) {
		this.workflowSteps = workflowSteps;
	}

	public List<String> getLevels() {
		return levels;
	}

	public void setLevels(List<String> levels) {
		this.levels = levels;
	}

	public String[] getStringOfRoles() {
		return stringOfRoles;
	}

	public void setStringOfRoles(String[] stringOfRoles) {
		this.stringOfRoles = stringOfRoles;
	}

}
