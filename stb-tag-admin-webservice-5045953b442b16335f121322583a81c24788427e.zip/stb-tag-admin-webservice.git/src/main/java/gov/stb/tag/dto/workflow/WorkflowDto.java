package gov.stb.tag.dto.workflow;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Codes.WorkflowActionTypes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.dto.ta.licence.TaLicenceDto;
import gov.stb.tag.helper.Cache;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowDto extends TaLicenceDto {

	private boolean isFinalApproval;

	private ListableDto lastAction;

	private ListableDto recommendation;

	private Integer workflowId;

	private boolean isInLowestStep;

	private ListableDto workType;

	private String assignedOfficer;

	private LocalDateTime approvedDate;

	private Integer assigneeId;

	private boolean isAllowedRoleInFirstStep;

	public <T extends WorkflowDto> T buildFromWorkflow(Cache cache, Workflow workflow, T dto, WorkflowHelper workflowHelper) {
		if (workflow != null) {
			if (workflow.getLicence() != null) {
				dto = dto.buildFromLicence(cache, workflow.getLicence(), dto);
			}
			if (workflow.getLastAction() == null) {
				dto.setLastAction(new ListableDto(Statuses.TA_WKFLW_NEW, cache.getStatus(Statuses.TA_WKFLW_NEW).getLabel(), cache.getStatus(Statuses.TA_WKFLW_NEW).getOtherLabel(), null, null));
			} else {
				dto.setLastAction(new ListableDto(workflow.getLastAction().getStatus().getCode(), cache.getLabel(workflow.getLastAction().getStatus(), false),
						cache.getLabel(workflow.getLastAction().getStatus(), true), null, null));

				if (workflow.getLastAction().getRecommendation() != null) {
					dto.setRecommendation(new ListableDto(workflow.getLastAction().getRecommendation()));
				}

			}

			dto.setIsFinalApproval(workflowHelper.isFinalApproval(workflow));
			dto.setWorkflowId(workflow.getId());
			dto.setIsInLowestStep(workflowHelper.isInLowestStep(workflow, null));
			dto.setWorkType(new ListableDto(workflow.getType()));
			dto.setAssignedOfficer(workflow.getAssignee() != null ? workflow.getAssignee().getName() : null);
			dto.setAssigneeId(workflow.getAssignee() != null ? workflow.getAssignee().getId() : null);

			for (WorkflowAction action : workflow.getWorkflowActions()) {
				if (action.getType().getCode().equals(WorkflowActionTypes.APPROVE)) {
					// get latest approved date
					dto.setApprovedDate(
							dto.getApprovedDate() == null ? action.getCreatedDate() : (action.getCreatedDate().isAfter(dto.getApprovedDate()) ? action.getCreatedDate() : dto.getApprovedDate()));
				}
			}

		} else {
			dto.setLastAction(new ListableDto(Codes.Statuses.TA_WKFLW_NEW, cache.getStatus(Statuses.TA_WKFLW_NEW).getLabel(), cache.getStatus(Statuses.TA_WKFLW_NEW).getOtherLabel(), null, null));
			dto.setIsFinalApproval(Boolean.FALSE);
			dto.setIsInLowestStep(Boolean.TRUE);
		}

		return dto;
	}

	public <T extends WorkflowDto> T buildNewWorkflowDto(Cache cache, Workflow workflow, T dto, WorkflowHelper workflowHelper, String workFlowConfigType) {
		dto = buildFromWorkflow(cache, workflow, dto, workflowHelper);
		if (dto.getIsInLowestStep()) {
			dto.setAllowedRoleInFirstStep(workflowHelper.isAllowedRoleInFirstStep(workFlowConfigType));
		}
		if (workflow == null) {
			dto.setWorkType(new ListableDto(cache.getType(workFlowConfigType)));
			// workflow.setLicence(licence);
		}
		return dto;
	}

	public boolean getIsFinalApproval() {
		return isFinalApproval;
	}

	public void setIsFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public ListableDto getLastAction() {
		return lastAction;
	}

	public void setLastAction(ListableDto lastAction) {
		this.lastAction = lastAction;
	}

	public ListableDto getRecommendation() {
		return recommendation;
	}

	public void setRecommendation(ListableDto recommendation) {
		this.recommendation = recommendation;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public boolean getIsInLowestStep() {
		return isInLowestStep;
	}

	public void setIsInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

	public ListableDto getWorkType() {
		return workType;
	}

	public void setWorkType(ListableDto workType) {
		this.workType = workType;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Integer getAssigneeId() {
		return assigneeId;
	}

	public void setAssigneeId(Integer assigneeId) {
		this.assigneeId = assigneeId;
	}

	public boolean isAllowedRoleInFirstStep() {
		return isAllowedRoleInFirstStep;
	}

	public void setAllowedRoleInFirstStep(boolean isAllowedRoleInFirstStep) {
		this.isAllowedRoleInFirstStep = isAllowedRoleInFirstStep;
	}

	public void setFinalApproval(boolean isFinalApproval) {
		this.isFinalApproval = isFinalApproval;
	}

	public void setInLowestStep(boolean isInLowestStep) {
		this.isInLowestStep = isInLowestStep;
	}

}
