package gov.stb.tag.dto.workflow;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.constant.Codes.WorkflowActionTypes;
import gov.stb.tag.helper.WorkflowHelper;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowItemDto {

	@MapProjection(path = "id")
	private Integer workflowId;

	@MapProjection(path = "type.code")
	private String type;

	@MapProjection(path = "type.label")
	private String typeLabel;

	@MapProjection(path = "createdDate")
	private LocalDateTime createdDate;

	@MapProjection(path = "workflow.licence.id")
	private Integer licenceId;

	@MapProjection(path = "workflow.licence.licenceNo")
	private String licenceNo;

	@MapProjection(path = "workflow.licence.travelAgent.name")
	private String name;

	@MapProjection(path = "workflow.licence.travelAgent.uen")
	private String uen;

	@MapProjection(path = "workflow.lastAction.status.code")
	private String statusCode;

	@MapProjection(path = "workflow.lastAction.status.label")
	private String status;

	@MapProjection(path = "workflow.lastAction.status.otherLabel")
	private String externalStatus;

	@MapProjection(path = "workflow.assignee.name")
	private String assignedOfficer;

	private LocalDateTime approvedDate;

	public WorkflowItemDto() {
	}

	public WorkflowItemDto buildWorkflowDto(WorkflowHelper workflowHelper, Workflow model, WorkflowItemDto dto) {
		dto.setWorkflowId(model.getId());
		dto.setType(model.getType().getCode());
		dto.setTypeLabel(model.getType().getLabel());
		dto.setCreatedDate(model.getCreatedDate());
		dto.setLicenceId(model.getLicence().getId());
		dto.setLicenceNo(model.getLicence().getLicenceNo());
		dto.setName(model.getLicence().getTravelAgent().getName());
		dto.setUen(model.getLicence().getTravelAgent().getUen());
		dto.setStatusCode(model.getLastAction().getStatus().getCode());
		dto.setStatus(model.getLastAction().getStatus().getLabel());
		dto.setExternalStatus(model.getLastAction().getStatus().getOtherLabel());
		dto.setAssignedOfficer(model.getAssignee() != null ? model.getAssignee().getName() : null);

		if (workflowHelper.hasFinalApproved(model)) {
			for (WorkflowAction action : model.getWorkflowActions()) {
				if (action.getType().getCode().equals(WorkflowActionTypes.APPROVE)) {
					// get latest approved date
					dto.setApprovedDate(
							dto.getApprovedDate() == null ? action.getCreatedDate() : (action.getCreatedDate().isAfter(dto.getApprovedDate()) ? action.getCreatedDate() : dto.getApprovedDate()));
				}
			}
		}

		return dto;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflow) {
		this.workflowId = workflow;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getExternalStatus() {
		return externalStatus;
	}

	public void setExternalStatus(String externalStatus) {
		this.externalStatus = externalStatus;
	}

	public String getAssignedOfficer() {
		return assignedOfficer;
	}

	public void setAssignedOfficer(String assignedOfficer) {
		this.assignedOfficer = assignedOfficer;
	}

	public LocalDateTime getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDateTime approvedDate) {
		this.approvedDate = approvedDate;
	}

}
