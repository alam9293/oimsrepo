package gov.stb.tag.dto.workflow;

import java.util.TreeMap;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowStepDto extends EntityDto {

	private String applicationTypeCode;
	private String applicationTypeLabel;

	private TreeMap<String, Object> steps;

	public String getApplicationTypeCode() {
		return applicationTypeCode;
	}

	public void setApplicationTypeCode(String applicationTypeCode) {
		this.applicationTypeCode = applicationTypeCode;
	}

	public String getApplicationTypeLabel() {
		return applicationTypeLabel;
	}

	public void setApplicationTypeLabel(String applicationTypeLabel) {
		this.applicationTypeLabel = applicationTypeLabel;
	}

	public TreeMap<String, Object> getSteps() {
		return steps;
	}

	public void setSteps(TreeMap<String, Object> steps) {
		this.steps = steps;
	}

}
