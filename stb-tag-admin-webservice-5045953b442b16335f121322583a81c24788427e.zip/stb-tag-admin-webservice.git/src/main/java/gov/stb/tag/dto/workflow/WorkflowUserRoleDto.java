package gov.stb.tag.dto.workflow;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.dto.EntityDto;
import gov.stb.tag.dto.dashboard.UserProfileDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkflowUserRoleDto extends EntityDto {

	private String role;

	private String roleCode;

	private String startStatusCode;

	private Integer defaultAssignee;

	private List<UserProfileDto> users;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public List<UserProfileDto> getUsers() {
		return users;
	}

	public void setUsers(List<UserProfileDto> users) {
		this.users = users;
	}

	public String getStartStatusCode() {
		return startStatusCode;
	}

	public void setStartStatusCode(String startStatusCode) {
		this.startStatusCode = startStatusCode;
	}

	public Integer getDefaultAssignee() {
		return defaultAssignee;
	}

	public void setDefaultAssignee(Integer defaultAssignee) {
		this.defaultAssignee = defaultAssignee;
	}

}
