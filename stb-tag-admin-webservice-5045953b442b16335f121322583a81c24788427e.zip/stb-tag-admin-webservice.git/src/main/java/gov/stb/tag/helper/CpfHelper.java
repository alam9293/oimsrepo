package gov.stb.tag.helper;

import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Preconditions;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.cpf.CpfDto;
import gov.stb.tag.dto.cpf.CpfInputDto;
import gov.stb.tag.dto.cpf.CpfOutputDataDto;
import gov.stb.tag.dto.cpf.CpfRDXSEMPSOperationDto;
import gov.stb.tag.model.Status;

@Component
public class CpfHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	protected static final String CONSUMER_ID = "STB";
	protected static final String SUCCESSFUL = "0000";
	protected static final String INVALID_ACCOUNT = "1001";
	protected static final String YES = "Y";
	protected ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	Properties properties;
	@Autowired
	CacheHelper cache;

	public Status checkMedisavePaymentStatus(String uinfin) {
		String apiUrl = properties.cpfApexIgL2BaseApiUrl + properties.cpfApiMedisavePaymentStatus;
		HttpHeaders headers = new HttpHeaders();
		String header = "";
		try {
			headers.add(Codes.Headers.CONTENT_TYPE, Codes.Headers.Values.APPLICATION_JSON); // must include for CPFB APEX API as they enforce content-type else will have 404
			if (properties.cpfApexEnabled) {
				header = generateCpfApexSignature(apiUrl);
				headers.add(Codes.Headers.APEX_AUTH, header);
			}
			String payload = generatePayload(uinfin);
			logger.info("REQ URL: {},  REQ BODY: {}, REQ HEADER: {}", apiUrl, payload, header);
			ResponseEntity<String> resp = getRestTemplate().exchange(apiUrl, HttpMethod.POST, new HttpEntity<>(payload, headers), String.class);
			logger.info("RESP STATUS: {}, RESP BODY: {}", resp.getStatusCodeValue(), resp.getBody());

			// validate the API response from external system and logs any pre-processing errors
			Preconditions.checkState((resp.getStatusCode() == HttpStatus.OK), "Response status not 200: %s", resp.getStatusCodeValue());
			CpfDto respDto = objectMapper.readValue(resp.getBody(), CpfDto.class);
			Preconditions.checkState(respDto.getRDXSEMPSOperationResponse() != null, "Response body missing RDXSEMPSOperationResponse");
			CpfOutputDataDto dto = respDto.getRDXSEMPSOperationResponse().getOutput_data();
			Preconditions.checkState(dto != null, "Response body missing output_data");

			// process the API response
			if (SUCCESSFUL.equals(dto.getSempswo_return_code())) {
				return cache.getStatus(YES.equals(dto.getSempswo_pmt_sts()) ? Codes.Statuses.CPF_MEDISAVE_Y : Codes.Statuses.CPF_MEDISAVE_N);
			} else if (INVALID_ACCOUNT.equals(dto.getSempswo_return_code())) {
				return cache.getStatus(Codes.Statuses.CPF_MEDISAVE_INVALID);
			} else {
				logger.error("Invalid sempswo_return_code received: {}", dto.getSempswo_return_code());
				return cache.getStatus(Codes.Statuses.CPF_MEDISAVE_ERROR);
			}
		} catch (HttpStatusCodeException e) {
			logger.info("RESP STATUS: {}, RESP BODY: {}", e.getRawStatusCode(), e.getResponseBodyAsString());
			logger.error(e.getMessage(), e);
			return cache.getStatus(Codes.Statuses.CPF_MEDISAVE_ERROR);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return cache.getStatus(Codes.Statuses.CPF_MEDISAVE_ERROR);
		}
	}

	public String generateCpfApexSignature(String apiUrl) throws ApiUtilException {
		apiUrl = apiUrl.replaceFirst("api.gov.sg", "i.api.gov.sg");
		String timestamp = String.valueOf(System.currentTimeMillis() + (properties.cpfApexTimestampOffsetSecs * 1000L));
		String signature = ApiSigning.getSignatureToken(properties.cpfApexIgL2Realm, Codes.Apex.INTRANET_L2, HttpMethod.POST.name(), apiUrl, properties.cpfApexIgL2AppId, null, null,
				properties.cpfApexIgL2Password, properties.cpfApexIgL2Alias, properties.cpfApexIgL2KeyStoreFilename, null, timestamp);
		return signature;
	}

	private String generatePayload(String uinfin) throws JsonProcessingException {
		CpfDto dto = new CpfDto();
		CpfRDXSEMPSOperationDto operationDto = new CpfRDXSEMPSOperationDto();
		CpfInputDto inputDto = new CpfInputDto();
		inputDto.setSempswi_con_id(CONSUMER_ID);
		inputDto.setSempswi_eeacn_c(uinfin);
		operationDto.setInput_data(inputDto);
		dto.setRDXSEMPSOperation(operationDto);
		return objectMapper.writeValueAsString(dto);
	}

	private RestTemplate getRestTemplate() {
		CloseableHttpClient httpClient;
		if (properties.tagProxyEnabled) {
			HttpHost proxyHost = new HttpHost(properties.tagProxyHost, properties.tagProxyPort);
			httpClient = HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).setProxy(proxyHost).build();
		} else {
			httpClient = HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).build();
		}
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		return new RestTemplate(requestFactory);
	}
}
