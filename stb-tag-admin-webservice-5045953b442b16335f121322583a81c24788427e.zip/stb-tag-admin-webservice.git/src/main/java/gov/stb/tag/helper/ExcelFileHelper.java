package gov.stb.tag.helper;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.constant.Properties;
import gov.stb.tag.util.FileUtil;

@Component
@Transactional
public class ExcelFileHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	Properties properties;

	public Workbook createExcelSheet(String sheetName, String[] columns) {

		Workbook workbook = new XSSFWorkbook();

		Sheet sheet = workbook.createSheet(sheetName);

		Row headerRow = sheet.createRow(0);

		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columns[i]);
		}

		return workbook;
	}

	public void createExcelFile(String fileName, Workbook workbook, HttpServletResponse response) {
		try {
			File file = new File(properties.baseDir + properties.downloadDir, FilenameUtils.getName(fileName));
			FileOutputStream fileOut = new FileOutputStream(file);
			workbook.write(fileOut);
			fileOut.close();
			workbook.close();

			FileUtil.downloadSingleFile(response, file, null);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}

	}

	public void createCell(Sheet sheet, List<Object[]> dataList) {
		int rowNum = 1, recordCount = 1;
		for (Object[] obj : dataList) {
			Row row = sheet.createRow(rowNum++);
			row.createCell(0).setCellValue(Integer.toString(recordCount));

			int columnCount = obj.length;
			for (int i = 0; i < columnCount; i++) {
				row.createCell(i + 1).setCellValue(obj[i] != null ? obj[i].toString() : null);
			}

			recordCount++;
		}
	}

}