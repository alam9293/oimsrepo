package gov.stb.tag.helper;

import java.io.IOException;
import java.math.BigDecimal;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.EncryptedJWT;
import com.nimbusds.jwt.SignedJWT;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.ApprovalDto;
import gov.stb.tag.dto.eNets.ENetsRequestDto;
import gov.stb.tag.dto.eNets.ENetsRequestMessageDto;
import gov.stb.tag.dto.eNets.ENetsResponseDto;
import gov.stb.tag.dto.eNets.ENetsTxnDto;
import gov.stb.tag.dto.paynow.PayloadDto;
import gov.stb.tag.exception.UnavailableException;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.File;
import gov.stb.tag.model.PaymentRefund;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentStatusSpan;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.WaiveType;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.CeTaskRepository;
import gov.stb.tag.repository.PaymentHelperRepository;
import gov.stb.tag.repository.tg.TouristGuideRepository;
import gov.stb.tag.util.wirecard.WirecardUtil;

@Component
@Transactional
public class PaymentHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	private static final SecureRandom SECURE_RANDOM = new SecureRandom();
	private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyMM-ddHH");
	private static final DateTimeFormatter DTF_1 = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss.SSS");
	private static final Integer VALIDITY_MINS = 2; // TODO: system parameter
	private static final String USER_FIELD_DELIMITER = ",";
	private static final Integer VALIDITY_MINS_PAYNOW = 5;

	@Autowired
	CacheHelper cache;
	@Autowired
	PaymentHelperRepository repository;
	@Autowired
	CeTaskRepository ceTaskRepository;
	@Autowired
	Properties properties;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	CeTaskHelper ceTaskHelper;

	@Autowired
	TouristGuideRepository touristGuideRepository;

	@Autowired
	ObjectMapper objectMapper;

	/**
	 * Return the payment request with the specified billRefNo.
	 */
	public PaymentRequest getPaymentRequest(String billRefNo) {
		return repository.getPaymentRequest(billRefNo);
	}

	/**
	 * Saves a new payment request with PAYREQ_NOT_PAID as the initial status.
	 */
	public PaymentRequest savePaymentRequest(String refNo, String typeCode, String payerUinUen, String payerName, BigDecimal amount, String desc, String remarks, Boolean isPrePayment,
			Boolean isPayerCompany) {
		var req = newPaymentRequest(refNo, typeCode, payerUinUen, payerName, amount, desc, remarks, isPrePayment, isPayerCompany, null, null, null, null);
		return req;
	}

	/**
	 * Saves a new payment request with PAYREQ_NOT_PAID as the initial status.
	 */
	public PaymentRequest savePaymentRequest(String refNo, String typeCode, String payerUinUen, String payerName, BigDecimal amount, String desc, String remarks, Boolean isPrePayment,
			Boolean isPayerCompany, String userField2) {
		var req = newPaymentRequest(refNo, typeCode, payerUinUen, payerName, amount, desc, remarks, isPrePayment, isPayerCompany, null, null, null, null);
		return req;
	}

	/**
	 * Saves a new payment request with PAYREQ_NOT_PAID as the initial status.
	 */
	public PaymentRequest savePaymentRequest(String refNo, String typeCode, String payerUinUen, String payerName, BigDecimal amount, String desc, String remarks, Boolean isPrePayment,
			Boolean isPayerCompany, String userField1, String userField2, String userField3) {
		var req = newPaymentRequest(refNo, typeCode, payerUinUen, payerName, amount, desc, remarks, isPrePayment, isPayerCompany, userField1, userField2, userField3, null);
		return req;
	}

	/**
	 * Saves a new payment request with PAYREQ_NOT_PAID as the initial status for C&E.
	 */
	public PaymentRequest savePaymentRequest(String refNo, String typeCode, String payerUinUen, String payerName, BigDecimal amount, String desc, String remarks, Boolean isPrePayment,
			Boolean isPayerCompany, LocalDate paymentDueDate) {
		var req = newPaymentRequest(refNo, typeCode, payerUinUen, payerName, amount, desc, remarks, isPrePayment, isPayerCompany, null, null, null, paymentDueDate);
		return req;
	}

	/**
	 * Saves a new payment request with defined payment request as the initial status.
	 */
	public PaymentRequest savePaymentRequestCustomiseStatus(String refNo, String typeCode, String payerUinUen, String payerName, BigDecimal amount, String desc, String remarks, Boolean isPrePayment,
			Boolean isPayerCompany, String userField2, String paymentRequestStatusCode) {
		var req = newPaymentRequest(refNo, typeCode, payerUinUen, payerName, amount, desc, remarks, isPrePayment, isPayerCompany, null, null, null, null, paymentRequestStatusCode);
		return req;
	}

	private PaymentRequest newPaymentRequest(String refNo, String typeCode, String payerUinUen, String payerName, BigDecimal amount, String desc, String remarks, Boolean isPrePayment,
			Boolean isPayerCompany, String userField1, String userField2, String userField3, LocalDate paymentDueDate) {
		var req = new PaymentRequest();
		req = newPaymentRequest(refNo, typeCode, payerUinUen, payerName, amount, desc, remarks, isPrePayment, isPayerCompany, userField1, userField2, userField3, paymentDueDate,
				Codes.Statuses.PAYREQ_NOT_PAID);
		createPaymentStatusSpan(req, cache.getStatus(Codes.Statuses.PAYREQ_NOT_PAID));
		return req;
	}

	private PaymentRequest newPaymentRequest(String refNo, String typeCode, String payerUinUen, String payerName, BigDecimal amount, String desc, String remarks, Boolean isPrePayment,
			Boolean isPayerCompany, String userField1, String userField2, String userField3, LocalDate paymentDueDate, String paymentRequestStatusCode) {
		var req = new PaymentRequest();
		req.setRefNo(refNo);
		req.setBillRefNo(generateBillRefNo());
		req.setType(cache.getType(typeCode));
		req.setPayerUinUen(payerUinUen);
		req.setPayerName(payerName);
		req.setPayableAmount(amount);
		req.setDescription(desc);
		req.setIsPayerCompany(isPayerCompany);
		req.setIsPrePayment(isPrePayment);
		req.setStatus(cache.getStatus(paymentRequestStatusCode));
		req.setRemarks(remarks);
		req.setUserField1(userField1);
		req.setUserField2(userField2);
		req.setUserField3(userField3);
		req.setDueDate(paymentDueDate);
		repository.save(req);
		createPaymentStatusSpan(req, cache.getStatus(paymentRequestStatusCode));
		return req;
	}

	private String generateBillRefNo() {
		StringBuilder sb;
		do {
			sb = new StringBuilder();
			sb.append(LocalDateTime.now().format(DTF));
			sb.append("-");
			sb.append(Strings.padStart(String.valueOf(SECURE_RANDOM.nextInt(9999)), 4, '0'));
			sb.append("-");
			sb.append(Strings.padStart(String.valueOf(SECURE_RANDOM.nextInt(9999)), 4, '0'));
		} while (repository.isBillRefNoExist(sb.toString()));
		return sb.toString();
	}

	/**
	 * Updates the payment request status (get in one pull but update one by one, so that updatedBy, updatedDate and version can be updated)
	 */
	public void updatePaymentRequestStatuses(List<Integer> ids, String statusCode) {
		updatePaymentRequestStatuses(ids, statusCode, null, null);
	}

	public void updatePaymentRequestStatuses(List<Integer> ids, String statusCode, ApprovalDto dto, String internalRemarks) {
		var reqs = repository.getPaymentRequests(ids);
		Status status = cache.getStatus(statusCode);
		reqs.stream().forEach(req -> {
			req.setStatus(status);
			if (dto != null) {
				createPaymentStatusSpan(req, status, dto.getInternalRemarks(), dto.getFiles(), dto.getFileDescription());
			} else {
				createPaymentStatusSpan(req, status, internalRemarks, null, null);
			}
			updatePaymentCeTask(req);
		});
	}

	/**
	 * Initiate the payment process when user clicks on the "Pay" button. This function saves a paymentTxn with initial status as Pending, and return the necessary eNets information so that the
	 * browser can route to eNets payment page.
	 */
	public ENetsTxnDto initPaymentProcess(String paymentTypeCode, List<String> billRefNos, BigDecimal amount, String statusUrl, String returnUrl, String continueUrl) throws NoSuchAlgorithmException {
		PaymentTxn txn = savePaymentTxn(paymentTypeCode, billRefNos, amount, null, false);
		txn.setContinueUrl(continueUrl);
		return createENetsRequestTxnDto(txn, null, statusUrl, returnUrl);
	}

	/**
	 * Get the payment requests by its latest payment txn. If any of them is still pending completion, this function throw UnavailableException for the frontend to block until its txn timeout. The
	 * anyBillRefNo can be any one of the billRefNo this txn is tied to. It is to minimize unsolicited api call to see payment request details.
	 */
	public List<PaymentRequest> getPaymentProcessResult(String anyBillRefNo, Integer txnId) throws InterruptedException {
		List<PaymentRequest> reqs = repository.getPaymentRequestByLastTxnId(txnId);
		PaymentTxn txn = reqs.get(0).getLastTxn();
		if (!Codes.PaymentTypes.PAYNOW.equals(txn.getPaymentType().getCode())) {
			if (reqs.isEmpty() || reqs.stream().noneMatch(req -> req.getBillRefNo().equals(anyBillRefNo))) {
				throw new ValidationException("Transaction ID " + txnId + " cannot be found, or is no longer the latest, for Bill Reference No. " + anyBillRefNo);
			}
			if (Entities.equals(txn.getStatus(), Codes.Statuses.PAYTXN_PENDING)) {
				if (!LocalDateTime.now().isAfter(txn.getValidityDate())) {
					if (properties.appEnv.equals(Codes.Environments.DEV) || properties.appEnv.equals(Codes.Environments.SIT)) {
						// Only for local testing since eNets Statusurl cannot be specified as "http://localhost..."
						logger.warn("ONLY FOR LOCAL/SIT TESTING (SIT SSL cert not recognized by eNets). PaymentTxn {} and its corresponding PaymentRequest set to successful.", txn.getId());
						txn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL));
						reqs.forEach(req -> {
							req.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_PAID));
							createPaymentStatusSpan(req, cache.getStatus(Codes.Statuses.PAYREQ_PAID));
							updatePaymentCeTask(req);
						});
						if (txn.getPaymentRequests().stream().findFirst().get().getUserField2() != null) {
							emailHelper.emailUponPayment(txn, Codes.EmailType.PAYMENT_RECEIPT);
						}

					} else {
						throw new UnavailableException("Transaction ID " + txnId + " is still pending completion. Please retry the service at a later time.");
					}
				} else {
					timeoutPaymentTxn(txn);
				}
			}
		}
		return reqs;
	}

	/**
	 * Complete the payment process when eNets fire a server-to-server request callback to us.
	 */
	public PaymentTxn completePaymentProcess(String json, HttpServletRequest request) throws NoSuchAlgorithmException {
		logger.info("eNets receive response: {} ", json);
		PaymentTxn paymentTxn = null;
		try {
			ENetsResponseDto dto = objectMapper.readValue(json, ENetsResponseDto.class);
			String generatedHmac = generateSignature(json, properties.eNetsSecretKey);// generate mac
			String hmacFromGW = request.getHeader("hmac");
			logger.info("Header hmac received :" + hmacFromGW);
			logger.info("Json hmac generated :" + generatedHmac);

			String txnId = dto.getMsg().getMerchantTxnRef();
			paymentTxn = repository.get(PaymentTxn.class, Integer.valueOf(txnId));

			if (paymentTxn == null) {
				logger.error("PaymentTxn ID {} cannot be found!", txnId);

			} else if (!Entities.equals(paymentTxn.getStatus(), Codes.Statuses.PAYTXN_PENDING) && !Entities.equals(paymentTxn.getStatus(), Codes.Statuses.PAYTXN_TIMEOUT)) {
				logger.warn("Ignoring all other request callback to complete transaction because the transaction is already completed.");

			} else {
				paymentTxn.setTxnDate(LocalDateTime.now());
				if (generatedHmac.equalsIgnoreCase(hmacFromGW)) {
					logger.info("eNets receiveS2STxnEnd :" + json);
					if ("0".equals(dto.getMsg().getNetsTxnStatus())) {
						paymentTxn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL));
						paymentTxn.getPaymentRequests().forEach(req -> {
							req.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_PAID));
							createPaymentStatusSpan(req, cache.getStatus(Codes.Statuses.PAYREQ_PAID));
							updatePaymentCeTask(req);
						});
						if (paymentTxn.getPaymentRequests().stream().findFirst().get().getUserField2() != null) {
							logger.info("[Payment Receipt]: sending email to: {} for TXN ID: {}", paymentTxn.getPaymentRequests().stream().findFirst().get().getUserField2(), paymentTxn.getId());
							emailHelper.emailUponPayment(paymentTxn, Codes.EmailType.PAYMENT_RECEIPT);
						} else {
							logger.info("No email found for TXN ID: {}", paymentTxn.getId());
						}

					} else {
						paymentTxn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_FAIL));
						paymentTxn.setErrorMsg(dto.getMsg().getStageRespCode() + ": " + dto.getMsg().getNetsTxnMsg());
					}
				} else {
					paymentTxn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_FAIL));
					paymentTxn.setErrorMsg("Return signature is invalid: " + hmacFromGW);
				}
			}
		} catch (NumberFormatException e) {
			// do nothing and let paymentTxn remains as null
		} catch (Exception ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

		return paymentTxn;

		// TODO: ACK must be done in public...
		// try {
		// String urlParameters = "mid=" + Properties.WIRECARD_MID + "&ref=" + txnId + "&ack=YES";
		// response.getOutputStream().print(ESAPI.encoder().canonicalize(urlParameters));
		// } catch (Exception e) {
		// log.error(e.getMessage(), e);
		// }
	}

	/**
	 * Save a payment txn to the payment request, and then set it as the request's last txn. If last txn is still pending, checks validity to decide to throw error or create a new one. Amount will be
	 * auto-calculated if txn is online (i.e. credit cards).
	 */
	public PaymentTxn savePaymentTxn(String paymentTypeCode, List<String> billRefNos, BigDecimal amount, String remarks, boolean isOffline) {
		List<PaymentRequest> reqs = getPaymentRequests(billRefNos);
		BigDecimal total = isOffline ? amount : BigDecimal.ZERO;
		remarks = (!isOffline && reqs.size() > 1) ? "Linked to Multiple Payment Requests" : remarks;

		// validate payment requests to check if it has been paid/void or its last txn is still in progress, as well as calculating the total payable for online txn
		for (PaymentRequest req : reqs) {
			if (!Entities.anyEquals(req.getStatus(), Codes.Statuses.PAYREQ_NOT_PAID, Codes.Statuses.PAYREQ_PENDING_REFUND, Codes.Statuses.PAYREQ_PENDING_DISBURSEMENT)) {
				throw new ValidationException(String.format(Messages.Errors.PAYMENT_NO_LONGER_PENDING, req.getBillRefNo()));
			}
			PaymentTxn lastTxn = req.getLastTxn();
			if (lastTxn != null && Entities.equals(lastTxn.getStatus(), Codes.Statuses.PAYTXN_PENDING)) {
				if (!LocalDateTime.now().isAfter(lastTxn.getValidityDate())) {
					throw new ValidationException(String.format(Messages.Errors.PAYMENT_IN_PROGRESS, lastTxn, req.getBillRefNo()));
				} else {
					// TODO: need a batch job to timeout all paymentTxns as well for users who did not retry payment anymore
					timeoutPaymentTxn(lastTxn);
				}
			}
			if (!isOffline) {
				total = total.add(req.getPayableAmount());
			}
			if (Entities.anyEquals(req.getStatus(), Codes.Statuses.PAYREQ_PENDING_REFUND, Codes.Statuses.PAYREQ_PENDING_DISBURSEMENT)) {
				total = total.negate();
			}
		}

		// create the payment txn to be tied to all payment requests
		PaymentTxn txn = new PaymentTxn();
		txn.setAmount(total);
		txn.setStatus(cache.getStatus(isOffline ? Codes.Statuses.PAYTXN_SUCCESSFUL : Codes.Statuses.PAYTXN_PENDING));
		txn.setTxnDate(LocalDateTime.now());
		txn.setPaymentType(cache.getType(paymentTypeCode));
		if (cache.getType(paymentTypeCode).getCode().equals(Codes.PaymentTypes.PAYNOW)) {
			txn.setValidityDate(LocalDateTime.now().plusMinutes(VALIDITY_MINS_PAYNOW.longValue()));
		} else {
			txn.setValidityDate(LocalDateTime.now().plusMinutes(VALIDITY_MINS.longValue()));
		}
		txn.setRemarks(remarks);
		repository.saveOrUpdate(txn);

		for (PaymentRequest req : reqs) {
			req.setLastTxn(txn);
			req.getPaymentTxns().add(txn);
			txn.getPaymentRequests().add(req);
			repository.update(req);
		}
		return txn;
	}

	/**
	 * Mark the specified payment txn as timeout.
	 */
	private void timeoutPaymentTxn(PaymentTxn paymentTxn) {
		paymentTxn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_TIMEOUT));
		paymentTxn.setErrorMsg("Transaction timeout.");
		repository.update(paymentTxn);
	}

	private String mergeStringsIfSimilar(String unmergedStrings) {
		String string = null;
		for (String s : unmergedStrings.split(USER_FIELD_DELIMITER)) {
			if (string == null) {
				string = s;
			}
			if (!string.equals(s)) {
				return unmergedStrings;
			}
		}
		return string;
	}

	// Only for performance test
	public PaymentTxn autoCompletePaymentProcess(HttpServletRequest request) throws NoSuchAlgorithmException {
		String txnId = WirecardUtil.getReturnTxnId(request);
		PaymentTxn paymentTxn = null;
		try {
			paymentTxn = repository.get(PaymentTxn.class, Integer.valueOf(txnId));
		} catch (NumberFormatException e) {
			// do nothing and let paymentTxn remains as null
		}
		if (paymentTxn == null) {
			logger.error("PaymentTxn ID {} cannot be found!", txnId);

		} else if (!Entities.equals(paymentTxn.getStatus(), Codes.Statuses.PAYTXN_PENDING) && !Entities.equals(paymentTxn.getStatus(), Codes.Statuses.PAYTXN_TIMEOUT)) {
			logger.warn("Ignoring all other request callback to complete transaction because the transaction is already completed.");

		} else {
			paymentTxn.setTxnDate(LocalDateTime.now());
			paymentTxn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL));
			paymentTxn.getPaymentRequests().forEach(req -> req.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_PAID)));
		}
		return paymentTxn;

	}

	public void waiveOrRefundPayment(String billRefNo, String taTgType, CeCaseAppeal appeal) {
		PaymentRequest payReq = repository.getPaymentRequest(billRefNo);
		if (payReq != null) {
			if (Entities.equals(payReq.getStatus(), Codes.Statuses.PAYREQ_SETTLED)) {
				autoApproveForPaymentRefund(payReq.getPayableAmount(), payReq, taTgType);
				appeal.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_PENDING_REFUND));
				updatePaymentRequestStatuses(Arrays.asList(payReq.getId()), Codes.Statuses.PAYREQ_PENDING_REFUND);
				if (CollectionUtils.isEmpty(ceTaskRepository.getOpenCeTasksByBillRefNo(billRefNo))) {
					// create pending refund task
					// ceTaskHelper.createCeTaskForAFPPayment(billRefNo, payReq.getStatus(), appeal.getCeCaseInfringement().getCeCase().getOic(), appeal.getCeCaseInfringement().getCeCase().getOic(),
					// payReq.getPayableAmount(), appeal.getCeCaseInfringement().getCeCaseInfringer().getLicence(), appeal.getCeCaseInfringement().getCeCaseInfringer(), payReq.getDueDate(),
					// appeal.getCeCaseInfringement().getCeCase());
				}
			} else {
				appeal.setPaymentStatus(cache.getStatus(Codes.Statuses.PAYREQ_WAIVED));
				updatePaymentRequestStatuses(Arrays.asList(payReq.getId()), Codes.Statuses.PAYREQ_WAIVED);
			}

			repository.update(appeal);
		}
	}

	public void autoApproveForPaymentRefund(BigDecimal payableAmount, PaymentRequest payReq, String taTgType) {
		PaymentRefund refund = new PaymentRefund();
		refund.setBillRefNo(payReq.getBillRefNo());
		refund.setPayerName(payReq.getPayerName());
		refund.setRefundAmount(payableAmount);

		Workflow workflow = workflowHelper.saveNewWorkflow(Codes.TaTgType.TA.equals(taTgType) ? Codes.Workflow.PAY_WKFLW_REFUND_TA : Codes.Workflow.PAY_WKFLW_REFUND_TG, null, null, null, false, null,
				null, null);
		refund.setWorkflow(workflow);
		repository.save(refund);

		workflowHelper.autoApprove(workflow, false, "MTI Appeal Result");

	}

	public PaymentStatusSpan createPaymentStatusSpan(PaymentRequest pr, Status status) {
		return createPaymentStatusSpan(pr, status, null, null, null);
	}

	public PaymentStatusSpan createPaymentStatusSpan(PaymentRequest pr, Status status, String internalRemarks, List<MultipartFile> files, List<String> fileDescs) {
		PaymentStatusSpan span = new PaymentStatusSpan();
		span.setPaymentRequest(pr);
		span.setStatus(status);
		span.setInternalRemarks(internalRemarks);
		repository.save(span);
		if (files != null && !files.isEmpty()) {
			Set<File> savedFiles = new HashSet<>();
			for (MultipartFile file : files) {
				if (fileDescs != null && !fileDescs.isEmpty()) {
					savedFiles.add(fileHelper.saveFile(span, fileDescs.get(files.indexOf(file)), file));
				} else {
					savedFiles.add(fileHelper.saveFile(span, null, file));
				}
			}
			span.setFiles(savedFiles);
			repository.save(span);
		}
		return span;
	}

	public void updatePaymentCeTask(PaymentRequest payReq) {
		ceTaskRepository.getOpenCeTasksByBillRefNo(payReq.getBillRefNo()).forEach(ceTask -> {
			switch (payReq.getStatus().getCode()) {
			case Codes.Statuses.PAYREQ_PAID:
				ceTask.setStatus(cache.getStatus(Codes.CeTaskStatus.CE_TASK_PAID));
				break;
			case Codes.Statuses.PAYREQ_PENDING_REFUND:
				// ceTask.setStatus(cache.getStatus(Codes.CeTaskStatus.CE_TASK_PEND_REFUND));
				// break;
			case Codes.Statuses.PAYREQ_SETTLED:
			case Codes.Statuses.PAYREQ_REFUNDED:
			case Codes.Statuses.PAYREQ_WAIVED:
				ceTaskHelper.completeCeTaskByBill(payReq.getBillRefNo());
				break;
			}
			repository.save(ceTask);
		});
	}

	// used for check whether payment request type is configured to waived
	public Boolean checkPaymentIsWaived(String paymentReqType) {
		WaiveType waiveType = repository.getWaiveTypeByPaymentRequestType(paymentReqType);
		return waiveType != null;
	}

	// used for check whether each payment request type is configured to waived and waive payment if yes
	public List<String> waivePayments(List<String> billRefNos) {
		List<String> payBills = new ArrayList<>();
		Boolean waiveForInactiveLic = true;

		List<WaiveType> waiveTypes = repository.getAllWaiveTypes();
		List<PaymentRequest> payReqs = getPaymentRequests(billRefNos);

		for (PaymentRequest payReq : payReqs) {
			Optional<WaiveType> waiveTypeOptional = waiveTypes.stream().filter(waive -> Entities.equals(waive.getType(), payReq.getType())).findFirst();
			TouristGuide touristGuide = touristGuideRepository.getTouristGuideByUin(payReq.getPayerUinUen());
			var isATG = repository.getIsAtg(payReq.getPayerUinUen());
			// Do not wave the bill if delicensed TG for MLPT and ATG exam
			if (Codes.TgPaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION.equals(payReq.getType().getCode()) || Codes.TgPaymentRequestTypes.PAYREQ_TG_ATG_EXAM.equals(payReq.getType().getCode())) {
				var tg = repository.getTouristGuideByUin(payReq.getPayerUinUen());
				if (tg != null) {
					if (Codes.Statuses.TG_INACTIVE.equals(tg.getLicence().getStatus().getCode())) {
						waiveForInactiveLic = false;
					}
				}
			}
			// Do not wave the bill if ATG for new applicants/non-TG
			if (Codes.TgPaymentRequestTypes.PAYREQ_TG_CREATION.equals(payReq.getType().getCode()) || Codes.TgPaymentRequestTypes.PAYREQ_TG_ATG_EXAM.equals(payReq.getType().getCode())) {
				if (touristGuide == null && isATG) {
					waiveForInactiveLic = false;
				}
			}
			if (waiveTypeOptional.isPresent() && waiveForInactiveLic) {
				updatePaymentRequestStatuses(Arrays.asList(payReq.getId()), Codes.Statuses.PAYREQ_WAIVED, null,
						cache.getSystemParameter(Codes.SystemParameters.PAYMENT_WAIVE_INTERNAL_REMARKS).getValue());
			} else {
				payBills.add(payReq.getBillRefNo());
			}
		}

		return payBills;
	}

	public List<PaymentRequest> getPaymentRequests(List<String> billRefNos) {
		List<PaymentRequest> reqs = repository.getPaymentRequestsByBillRefNo(billRefNos);
		if (reqs.isEmpty() || reqs.size() != billRefNos.size()) {
			throw new ValidationException(Messages.Errors.PAYMENT_REQ_MISSING);
		}

		return reqs;
	}

	/**
	 * Complete the payment process when PayNow fire a request callback to us.
	 */
	public PaymentTxn completePaymentProcessPayNow(String json) throws NoSuchAlgorithmException {
		PaymentTxn paymentTxn = new PaymentTxn();
		try {
			logger.info("DBSICN encrypt response: {} ", json);
			json = decryptJwe(json);
			PayloadDto dto = objectMapper.readValue(json, PayloadDto.class);

			String bankTxnRefText = "Bank Transaction Reference: " + dto.getTxnInfo().getTxnRefId();
			String customerReference = dto.getTxnInfo().getCustomerReference().trim();

			paymentTxn = repository.get(PaymentTxn.class, Integer.valueOf(customerReference));
			if (paymentTxn != null) {
				if (paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_PENDING)) || paymentTxn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_TIMEOUT))) {
					paymentTxn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL));
					paymentTxn.setTxnDate(LocalDateTime.now());
					paymentTxn.setErrorMsg("");

					if (paymentTxn.getRemarks() != null) {
						paymentTxn.setRemarks(paymentTxn.getRemarks() + "; " + bankTxnRefText);
					} else {
						paymentTxn.setRemarks(bankTxnRefText);
					}

					paymentTxn.getPaymentRequests().forEach(req -> {
						req.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_PAID));
						createPaymentStatusSpan(req, cache.getStatus(Codes.Statuses.PAYREQ_PAID));
						updatePaymentCeTask(req);
					});

					if (paymentTxn.getPaymentRequests().stream().findFirst().get().getUserField2() != null) {
						logger.info("[Payment Receipt]: sending email to: {} for TXN ID: {}", paymentTxn.getPaymentRequests().stream().findFirst().get().getUserField2(), paymentTxn.getId());
						emailHelper.emailUponPayment(paymentTxn, Codes.EmailType.PAYMENT_RECEIPT);
					} else {
						logger.info("No email found for TXN ID: {}", paymentTxn.getId());
					}
				} else {
					// If the txn status is successful,
					// 1. Ignore the Duplicate ICN return for the same txnId and same bank txn ref
					// 2. To handle Duplicate Scan and Pay by Consumer- same txnId but different bank txn ref
					if (paymentTxn.getRemarks() != null) {
						if (!paymentTxn.getRemarks().contains(dto.getTxnInfo().getTxnRefId())) {
							paymentTxn.setRemarks(paymentTxn.getRemarks() + "; " + bankTxnRefText);
						}
					} else {
						paymentTxn.setRemarks(bankTxnRefText);
					}
				}
				logger.info("PaymentTxnID: {} ; Status: {} ; Remark: {}", customerReference, paymentTxn.getStatus().getLabel(), paymentTxn.getRemarks());
				repository.update(paymentTxn);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return paymentTxn;
	}

	public Integer getPaymentTxnForICNResult(Integer txnId) {
		PaymentTxn txn = repository.get(PaymentTxn.class, txnId);
		if (txn != null) {
			if (properties.paynowByPassEnabled) {
				// For Local testing only: Bypass paynow to direct process the submission
				List<PaymentRequest> reqs = repository.getPaymentRequestByLastTxnId(txnId);
				txn.setStatus(cache.getStatus(Codes.Statuses.PAYTXN_SUCCESSFUL));
				txn.setTxnDate(LocalDateTime.now());
				reqs.forEach(req -> {
					req.setStatus(cache.getStatus(Codes.Statuses.PAYREQ_PAID));
					createPaymentStatusSpan(req, cache.getStatus(Codes.Statuses.PAYREQ_PAID));
					updatePaymentCeTask(req);
				});
				return 1;
			} else {
				if (!LocalDateTime.now().isAfter(txn.getValidityDate())) {
					if (!txn.getStatus().equals(cache.getStatus(Codes.Statuses.PAYTXN_PENDING))) {
						logger.info("Status for PayNow TxnId-{} is {}.", txnId, txn.getStatus().getLabel());
						return 1;
					}
				} else {
					timeoutPaymentTxn(txn);
					logger.info("PayNow Transaction ID {} has been timeout.", txnId);
					return 3;
				}
			}
		}
		return 2;
	}

	private String decryptJwe(String jwe) throws ApiUtilException, ParseException, JOSEException, IOException, GeneralSecurityException {
		// 1. Decrypt the json
		PrivateKey privateKey = ApiSigning.getPrivateKeyPEM(properties.paynowJwtPrivatePem, "");
		EncryptedJWT encryptedJWT = EncryptedJWT.parse(jwe);
		RSADecrypter decrypter = new RSADecrypter(privateKey);
		encryptedJWT.decrypt(decrypter);

		// 2.Verify the DBS signature
		Payload payload = encryptedJWT.getPayload();
		JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) ApiSigning.getPublicKeyPEM(properties.paynowVerifyJwsSignPublicPem));
		SignedJWT jwt = payload.toSignedJWT();
		logger.info("JWT: " + jwt);
		if (jwt.verify(verifier)) {
			logger.info("Decrypt response after sign verified: {} ", jwt.getJWTClaimsSet().getClaim("Payload").toString());
			return jwt.getJWTClaimsSet().getClaim("Payload").toString();
		} else {
			throw new ValidationException("decryptJwe(): Failed to validate signature with DBS RSA Public Key");
		}

		// Skip DBS signature verification
		// logger.info("DBSICN decrypt response: {} ", encryptedJWT.getPayload().toSignedJWT().getJWTClaimsSet().getClaim("Payload").toString());
		// return encryptedJWT.getPayload().toSignedJWT().getJWTClaimsSet().getClaim("Payload").toString();
	}

	private ENetsTxnDto createENetsRequestTxnDto(PaymentTxn txn, Object object, String statusUrl, String returnUrl) {
		ENetsTxnDto dto = new ENetsTxnDto();
		ENetsRequestDto requestDto = new ENetsRequestDto();
		ENetsRequestMessageDto msgDto = new ENetsRequestMessageDto();

		try {
			requestDto.setSs("1");
			msgDto.setNetsMid(properties.eNetsMid);
			msgDto.setSubmissionMode("B");// B-Browser Submission
			msgDto.setTxnAmount((txn.getAmount() == null ? "0" : txn.getAmount().multiply(new BigDecimal(100)).setScale(0).toPlainString()));// Transaction amount in cents for all currencies
			msgDto.setMerchantTxnRef(String.valueOf(txn.getId()));
			msgDto.setMerchantTxnDtm(LocalDateTime.now().format(DTF_1));
			msgDto.setPaymentType("SALE");// SALE-This is where the money is deducted from the cardholder’s credit account immediately.
			msgDto.setCurrencyCode(properties.eNetsCurrency);
			msgDto.setPaymentMode("CC");
			msgDto.setMerchantTimeZone("+8:00");
			msgDto.setB2sTxnEndURL(returnUrl.replace("txnId", txn.getId().toString()));// eNets return to TRUST Page, maxlength =80
			msgDto.setS2sTxnEndURL(statusUrl);// eNets call back service to update payment status, maxlength =80
			msgDto.setClientType("W");// W-WEB
			msgDto.setNetsMidIndicator("U");
			msgDto.setTid("");
			msgDto.setSupMsg("");
			msgDto.setIpAddress("");
			msgDto.setLanguage("en");
			requestDto.setMsg(msgDto);
			dto.setRequestDto(requestDto);
			dto.setKeyId(properties.eNetsKeyId);
			dto.setTxnId(String.valueOf(txn.getId()));

			String payload = objectMapper.writeValueAsString(dto.getRequestDto());
			dto.setHmac(generateSignature(payload, properties.eNetsSecretKey));
			dto.setPayload(payload);
			logger.info("payload :: " + payload);
			logger.info("hmac :: " + dto.getHmac());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dto;
	}

	/**
	 * Generate eNets signature based on txn request info and secret key.
	 */
	public String generateSignature(String txnReq, String secretKey) throws Exception {
		String concatPayloadAndSecretKey = txnReq + secretKey;
		String hmac = encodeBase64(hashSHA256ToBytes(concatPayloadAndSecretKey.getBytes()));
		return hmac;
	}

	public static byte[] hashSHA256ToBytes(byte[] input) throws Exception {
		byte[] byteData = null;
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		md.update(input);
		byteData = md.digest();
		return byteData;
	}

	public static String encodeBase64(byte[] data) throws Exception {
		return DatatypeConverter.printBase64Binary(data);
	}
}
