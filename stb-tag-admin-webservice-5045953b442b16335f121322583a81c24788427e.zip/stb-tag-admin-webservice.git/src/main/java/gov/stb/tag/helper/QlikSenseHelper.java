package gov.stb.tag.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.security.KeyStore;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.stb.tag.constant.Properties;

@Component
public class QlikSenseHelper {

	// STEPS TO INTEGRATE QLIKSENSE TO YOUR APP SERVER
	//
	// 1. Create or use existing Virtual Proxy
	// 1a. Prefix = qliksense
	// 1b. Session Cookie Header Name = <must be unique if u have more than 1 vProxies>
	// 1c. Load Balancing = Central
	// 1d. Windows Authentication Pattern = Forms (so you still can login as admin directly instead of via your app)
	//
	// 2. Export Certificates
	// 2a. Machine Name = tag-qlik
	// 2b. Export both Windows Format and PEM Format
	// 2c. Copy & transfer client.pfx and root.cer from QlikSense Server to your App Server
	//
	// 3. Jave Key Store
	// 3a. "C:\Program Files\Java\jdk-11.0.1\bin\keytool.exe" -importkeystore -srckeystore "client.pfx" -srcstoretype pkcs12 -destkeystore "client.jks" -deststoretype JKS -srcstorepass P@ssw0rd12345
	// -deststorepass P@ssw0rd12345 -noprompt
	// 3b. "C:\Program Files\Java\jdk-11.0.1\bin\keytool.exe" -import -alias QlikCA -keystore "root.jks" -file "root.cer" -storepass P@ssw0rd12345 -noprompt
	//
	// * Please open firewall in QlikSense Server Inbound Rule for Port 4243
	// * https://tag-qlik/qliksense/hub?qlikTicket=(generatedticket)

	@Autowired
	Properties properties;

	public String getQlikTicketedUrl(String userId) throws IOException {
		String xrfkey = "7rBHABt65vFflaZ7"; // Xrfkey to prevent cross-site issues
		OutputStreamWriter wr = null;
		BufferedReader in = null;
		try {

			/************** BEGIN Certificate Acquisition **************/
			String certFolder = properties.qsJksFolder; // This is a folder reference to the location of the jks files used for securing ReST communication
			String proxyCert = certFolder + "client.jks"; // Reference to the client jks file which includes the client certificate with private key
			String proxyCertPass = properties.qsJksPassword; // This is the password to access the Java Key Store information
			String rootCert = certFolder + "root.jks"; // Reference to the root certificate for the client cert. Required in this example because Qlik Sense certs are used.
			String rootCertPass = properties.qsJksPassword; // This is the password to access the Java Key Store information
			/************** END Certificate Acquisition **************/

			/************** BEGIN Certificate configuration for use in connection **************/
			KeyStore ks = KeyStore.getInstance("JKS");
			ks.load(new FileInputStream(new File(proxyCert)), proxyCertPass.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(ks, proxyCertPass.toCharArray());
			SSLContext context = SSLContext.getInstance("SSL");
			KeyStore ksTrust = KeyStore.getInstance("JKS");
			ksTrust.load(new FileInputStream(rootCert), rootCertPass.toCharArray());
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(ksTrust);
			context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
			SSLSocketFactory sslSocketFactory = context.getSocketFactory();
			/************** END Certificate configuration for use in connection **************/

			/************** BEGIN HTTPS Connection **************/
			// System.out.println("Browsing to: " + "https://" + host + ":4243/qps/" + vproxy + "/ticket?xrfkey=" + xrfkey);
			URL url = new URL("https://" + properties.qsHost + ":4243/qps/" + properties.qsVirtualProxy + "/ticket?xrfkey=" + xrfkey);
			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			connection.setSSLSocketFactory(sslSocketFactory);
			connection.setRequestProperty("x-qlik-xrfkey", xrfkey);
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestMethod("POST");
			/************** BEGIN JSON Message to Qlik Sense Proxy API **************/

			String body = "{ 'UserId':'" + userId + "','UserDirectory':'" + properties.qsUserDirectory + "',";
			body += "'Attributes': [],";
			body += "}";
			// System.out.println("Payload: " + body);
			/************** END JSON Message to Qlik Sense Proxy API **************/

			wr = new OutputStreamWriter(connection.getOutputStream());
			wr.write(body);
			wr.flush(); // Get the response from the QPS BufferedReader
			in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			StringBuilder builder = new StringBuilder();
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				builder.append(inputLine);
			}
			in.close();
			wr.close();

			JsonNode jsonNode = (new ObjectMapper()).readTree(builder.toString());
			String ticket = jsonNode.get("Ticket").asText();
			return properties.qsUrl + "?qlikTicket=" + ticket;

			// System.out.println("The response from the server is: " + data);
			/************** END HTTPS Connection **************/
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				in.close();
			}
			if (wr != null) {
				wr.close();
			}
		}
		return properties.qsUrl;
	}
}
