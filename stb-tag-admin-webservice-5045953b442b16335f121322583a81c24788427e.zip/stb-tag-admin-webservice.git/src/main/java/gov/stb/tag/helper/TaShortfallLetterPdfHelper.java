package gov.stb.tag.helper;

import com.lowagie.text.Document;
import com.lowagie.text.html.simpleparser.HTMLWorker;
import com.lowagie.text.pdf.PdfWriter;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.ta.netvalueshortfall.TaNetValueShortfallLetterDto;
import gov.stb.tag.helper.signdoc.PdfHelper;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.HeaderFooterPageEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.StringReader;
import java.time.LocalDate;

import static gov.stb.tag.util.DateUtil.REPORT_DATE_FORMAT_PATTERN;

@Component
public class TaShortfallLetterPdfHelper extends PdfHelper {
	@Autowired
	protected CacheHelper cacheHelper;

	@Autowired
	protected FileHelper fileHelper;

	@Autowired
	Properties properties;

	public TaNetValueShortfallLetterDto generatePdf(Workflow workflow, String letterContent, String licenceNo) {
		Document document = createDefaultDocument();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = null;
		String fileName = "ta_shortfall_letter_" + DateUtil.format(LocalDate.now(), REPORT_DATE_FORMAT_PATTERN) + "_TA" + licenceNo + ".pdf";
		try {
			logger.info("Start TaShortfallLetter create PDF ");
			java.io.File folder = new java.io.File(properties.baseDir + String.format(properties.workflowUploadDir, workflow.getId()));
			if (!folder.exists()) {
				folder.mkdirs();
			}

			String outputFilePath = properties.baseDir + String.format(properties.workflowUploadDir, workflow.getId()) + "/" + fileName;
			writer = PdfWriter.getInstance(document, new FileOutputStream(outputFilePath));
			HeaderFooterPageEvent event = new HeaderFooterPageEvent(properties.baseDir + "/stb_logo.jpg");
			writer.setPageEvent(event);
			document.open();

			letterContent = String.format("<p>Date: %s</p><p><br></p>", DateUtil.format(LocalDate.now(), DateUtil.DATE_FORMAT_PATTERN_2)).concat(letterContent);

			HTMLWorker htmlWorker = new HTMLWorker(document);
			htmlWorker.parse(new StringReader(letterContent));
			logger.info("End TaShortfallLetter PDF ");

		} catch (

		Exception e) {
			e.printStackTrace();
		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}

		TaNetValueShortfallLetterDto dto = new TaNetValueShortfallLetterDto();
		dto.setFileName(fileName);
		dto.setShortfallLetterByteArray(out.toByteArray());
		dto.setLetterContent(letterContent);
		return dto;

	}

}