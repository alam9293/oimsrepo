package gov.stb.tag.helper.signdoc;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.google.common.base.Strings;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import gov.stb.tag.constant.Codes.CE_TA_FIELD_REPORT_CLASS;
import gov.stb.tag.constant.Codes.SystemParameters;
import gov.stb.tag.dto.AuditableEntityDto;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.CeTaFieldReport;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.UserRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.HeaderFooterPageEvent;

@Component
public class CeTaFieldReportPdfHelper extends SigndocPdfHelper {
	@Autowired
	protected CacheHelper cacheHelper;

	@Autowired
	protected UserRepository userRepository;

	@Autowired
	protected FileHelper fileHelper;

	private static final String SIGNATURE_PLACEHOLDER = "<Signature>";

	@Override
	protected String getResultUrl() {
		return properties.signdocCeTaFieldReportResultUrl;
	}

	@Override
	protected void addCommands(MultiValueMap<String, Object> body) {
		// add a search-&-replace mandatory, lock_after_signed signature field command
		body.add("cmd_1", "name=Signature|searchtext=" + SIGNATURE_PLACEHOLDER + "|width=140|height=50|offsetx=0|offsety=0|type=formfield|subtype=signature|lock_after_sign=self|required=false");
	}

	public byte[] generatePdf(CeTaFieldReport resultDto) {
		Document document = createDefaultDocument();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = null;
		try {
			logger.info("Start ceTaFieldReport create PDF ");
			writer = PdfWriter.getInstance(document, out);
			HeaderFooterPageEvent event = new HeaderFooterPageEvent(properties.baseDir + "/stb_logo.jpg");
			writer.setPageEvent(event);
			document.open();

			Font headerFont = new Font(Font.HELVETICA, 16, Font.BOLD, Color.BLACK);
			Font cellHeaderFont = new Font(Font.HELVETICA, 12, Font.BOLD, Color.BLACK);

			document.add(createParaWithSpacing("TRAVEL AGENT COMPLIANCE FIELD REPORT", headerFont, 7f));
			PdfPTable table = createNewTable(2, 100, new float[] { 1f, 2f });

			AuditableEntityDto auditEntityDto = new AuditableEntityDto();
			auditEntityDto.buildEditorDetailsFromModel(resultDto, auditEntityDto, userRepository);

			table.addCell(createCellNoBorder("Created By"));
			table.addCell(createCellNoBorder(auditEntityDto.getCreatedBy() + " on " + DateUtil.format(auditEntityDto.getCreatedDate())));

			if (!Strings.isNullOrEmpty(auditEntityDto.getUpdatedBy())) {
				table.addCell(createCellNoBorder("Updated By"));
				table.addCell(createCellNoBorder(auditEntityDto.getUpdatedBy() + " on " + DateUtil.format(auditEntityDto.getUpdatedDate())));
			}

			table.addCell(createCellNoBorder("Report No"));
			table.addCell(createCellNoBorder(resultDto.getReportNo()));

			document.add(table);
			document.add(Chunk.NEWLINE);
			document.add(createParaWithSpacing("Travel Agent Details", headerFont, 7f));

			table.flushContent();
			table.addCell(createCellWithBorder("Licence No"));
			table.addCell(createCellWithBorder(resultDto.getLicenceNo()));

			table.addCell(createCellWithBorder("UEN"));
			table.addCell(createCellWithBorder(resultDto.getUen()));

			table.addCell(createCellWithBorder("Name of Travel Agent"));
			table.addCell(createCellWithBorder(resultDto.getTaName()));

			table.addCell(createCellWithBorder("Contact No"));
			table.addCell(createCellWithBorder(resultDto.getTaContactNo()));

			table.addCell(createCellWithBorder("Postal Code"));
			table.addCell(createCellWithBorder(resultDto.getAddress() != null ? resultDto.getAddress().getPostal() : null));

			table.addCell(createCellWithBorder("Address Type"));
			table.addCell(createCellWithBorder(resultDto.getAddressType() != null ? resultDto.getAddressType().getLabel() : null));

			table.addCell(createCellWithBorder("Block/House No"));
			table.addCell(createCellWithBorder(resultDto.getAddress() != null ? resultDto.getAddress().getBlock() : null));

			table.addCell(createCellWithBorder("Street Name"));
			table.addCell(createCellWithBorder(resultDto.getAddress() != null ? resultDto.getAddress().getStreet() : null));

			table.addCell(createCellWithBorder("Building Name"));
			table.addCell(createCellWithBorder(resultDto.getAddress() != null ? resultDto.getAddress().getBuilding() : null));

			table.addCell(createCellWithBorder("Premises Type"));
			table.addCell(createCellWithBorder(resultDto.getAddress() != null && resultDto.getAddress().getPremiseType() != null ? resultDto.getAddress().getPremiseType().getLabel() : null));

			table.addCell(createCellWithBorder("Level No"));
			table.addCell(createCellWithBorder(resultDto.getAddress() != null ? resultDto.getAddress().getFloor() : null));

			table.addCell(createCellWithBorder("Unit No"));
			table.addCell(createCellWithBorder(resultDto.getAddress() != null ? resultDto.getAddress().getUnit() : null));

			document.add(table);

			document.add(Chunk.NEWLINE);
			document.add(createParaWithSpacing("Person Details", headerFont, 7f));

			table.flushContent();
			table.addCell(createCellWithBorder("NRIC/FIN/Passport No."));
			table.addCell(createCellWithBorder(resultDto.getUinPassportNo()));

			table.addCell(createCellWithBorder("Name"));
			table.addCell(createCellWithBorder(resultDto.getName()));

			table.addCell(createCellWithBorder("Contact No"));
			table.addCell(createCellWithBorder(resultDto.getPersonContactNo()));

			table.addCell(createCellWithBorder("Designation"));
			table.addCell(createCellWithBorder(resultDto.getRole()));

			// table.addCell(createCellWithBorder("Nationality"));
			// table.addCell(createCellWithBorder(resultDto.getNationality() != null ? resultDto.getNationality().getLabel() : ""));

			document.add(table);
			document.add(Chunk.NEWLINE);

			table.flushContent();
			table.addCell(createCellWithBorder("Classification/nature of case or compliance issues:"));
			List<Type> list = new ArrayList<>(resultDto.getClassifications().stream().filter(o -> !o.getCode().equalsIgnoreCase(CE_TA_FIELD_REPORT_CLASS.OTHERS)).collect(Collectors.toList()));
			Collections.sort(list, Comparator.comparing(Type::getLabel));
			String classifications = list.stream().map(o -> String.valueOf(o.getLabel())).collect(Collectors.joining("\n"));

			if (resultDto.getClassifications().contains(cacheHelper.getType(CE_TA_FIELD_REPORT_CLASS.OTHERS))) {
				classifications = classifications.concat("\n").concat(cacheHelper.getType(CE_TA_FIELD_REPORT_CLASS.OTHERS).getLabel()).concat(": ").concat(resultDto.getOtherClassification());
			}
			table.addCell(createCellWithBorder(classifications));

			table.addCell(createCellWithBorder("Brief details of the case (if any)"));
			table.addCell(createCellWithBorder(resultDto.getDetails()));

			// table.addCell(createCellWithBorder("Witness Officer's Name"));
			// table.addCell(createCellWithBorder(resultDto.getWitness().getLabel()));
			document.add(table);

			table = createNewTable(3, 100, new float[] { 1f, 1f, 1f });

			table.addCell(createCellWithBorderRowSpan("STB Officer", 2));
			table.addCell(createCellWithBorderRowSpan(resultDto.getWitness() != null ? resultDto.getWitness().getLabel() : null, 2));
			table.addCell(createCellWithBorder("Signature: "));
			table.addCell(createCellForSignature("<Signature>"));

			table.addCell(createCellWithBorderRowSpan("Travel Agent Representative", 2));
			table.addCell(createCellWithBorderRowSpan(resultDto.getTaOfficerName(), 2));
			table.addCell(createCellWithBorder("Signature: "));
			table.addCell(createCellForSignature("<Signature>"));

			document.add(table);
			document.add(Chunk.NEWLINE);

			document.add(createParaWithSpacing(cacheHelper.getSystemParameter(SystemParameters.CE_TA_CHECKS_DECLARATION).getValue(), cellHeaderFont, 7f));

			document.add(Chunk.NEWLINE);

			for (File row : resultDto.getFiles()) {
				if (fileHelper.isImage(row.getExtension())) {
					attachImage(document, writer, fileHelper.getFullFilePath(properties.baseDir, row.getPath(), row.getFilename()));
				}
				if (row.getExtension().equalsIgnoreCase("pdf")) {
					attachPdf(document, writer, fileHelper.getFullFilePath(properties.baseDir, row.getPath(), row.getFilename()));
				}
			}
			logger.info("End ceTaFieldReport PDF ");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}
		return out.toByteArray();
	}

	// for local testing
	public static void main(String[] args) throws Exception {
		CeTaFieldReportPdfHelper helper = new CeTaFieldReportPdfHelper();
		helper.generatePdf(null);
	}
}