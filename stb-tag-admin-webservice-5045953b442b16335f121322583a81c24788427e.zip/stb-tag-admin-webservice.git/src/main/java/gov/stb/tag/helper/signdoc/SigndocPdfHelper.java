package gov.stb.tag.helper.signdoc;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.google.common.base.Strings;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import gov.stb.tag.constant.Properties;

@Component
public abstract class SigndocPdfHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private static final Integer DEFAULT_MARGIN_X = 30;
	private static final Integer DEFAULT_MARGIN_Y = 60;
	private static final Integer DEFAULT_IMG_MARGIN_X = 60;
	private static final Integer DEFAULT_IMG_MARGIN_Y = 60;

	@Autowired
	Properties properties;

	public String preloadToSigndoc(byte[] byteArray, String resultUrl) {
		MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("docdata", byteArray);
		body.add("dmsid", "de.softpro.sdweb.plugins.impl.FileDms");
		body.add("docid", RandomStringUtils.randomAlphanumeric(30).toUpperCase());
		// body.add("resulturl", getResultUrl());
		body.add("resulturl", resultUrl);
		addCommands(body);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "multipart/form-data");
		HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(body, headers);

		logger.info("PDF file created in-memory. Preloading it into Signdoc URL: {}", properties.signdocPreloadUrl);
		ResponseEntity<SigndocResp> resp = getRestTemplate().exchange(properties.signdocPreloadUrl, HttpMethod.POST, entity, SigndocResp.class);
		return resp.getBody().getRestLoadId().getValue(); // return refId to client browser to redirect & activate a session with SigndocWeb & load in the PDF for signing
	}

	private RestTemplate getRestTemplate() {
		CloseableHttpClient httpClient = HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		return new RestTemplate(requestFactory);
	}

	protected void attachImage(Document doc, PdfWriter writer, String filePath) {
		if (!Strings.isNullOrEmpty(filePath)) {
			doc.add(Chunk.NEXTPAGE);
			PdfContentByte canvas = writer.getDirectContentUnder();
			canvas.saveState();

			int resizedWidth = Float.valueOf(getAttachedImageWidth(doc)).intValue();
			int resizedHeight = Float.valueOf(getAttachedImageHeight(doc)).intValue();
			Image image;
			try {
				image = Image.getInstance(resizeImage(filePath, doc, resizedWidth, resizedHeight), null);
				image.setAbsolutePosition(DEFAULT_IMG_MARGIN_X, DEFAULT_IMG_MARGIN_Y); // 0, 0 = bottom left corner
				// image.setAbsolutePosition(DEFAULT_IMG_MARGIN_X, doc.getPageSize().getHeight() - image.getScaledHeight() - DEFAULT_IMG_MARGIN_Y); // 0, 0 = bottom left corner
				image.scaleToFit(resizedWidth, resizedHeight);
				canvas.addImage(image);

			} catch (BadElementException | IOException e) {
				e.printStackTrace();
			}
			canvas.restoreState();
		}
	}

	/**
	 * we want the x and o to be resized when the JFrame is resized
	 *
	 * @param originalImage
	 *            an x or an o. Use cross or oh fields.
	 *
	 * @param biggerWidth
	 * @param biggerHeight
	 * @throws IOException
	 */
	private BufferedImage resizeToBig(String filePath, int biggerWidth, int biggerHeight) throws IOException {
		BufferedImage image = ImageIO.read(new File(filePath));
		int type = image.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : image.getType();
		int fHeight = biggerHeight;
		int fWidth = biggerWidth;
		// Work out the resized width/height
		if (image.getHeight() > biggerHeight || image.getWidth() > biggerWidth) {
			fHeight = biggerHeight;
			int wid = biggerWidth;
			float sum = (float) image.getWidth() / (float) image.getHeight();
			fWidth = Math.round(fHeight * sum);

			if (fWidth > wid) {
				// rezise again for the width this time
				fHeight = Math.round(wid / sum);
				fWidth = wid;
			}
		}

		BufferedImage resizedImage = new BufferedImage(fWidth, fHeight, type);
		Graphics2D g = resizedImage.createGraphics();

		g.setComposite(AlphaComposite.Src);
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		g.drawImage(image, 0, 0, fWidth, fHeight, null);
		g.dispose();

		return resizedImage;
	}

	// this method will stretch the image to fill the whole document
	private BufferedImage resizeImage(String filePath, Document doc, Integer width, Integer height) throws IOException {
		BufferedImage image = ImageIO.read(new File(filePath));
		int type = image.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : image.getType();
		BufferedImage resizedImage = new BufferedImage(width, height, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(image, 0, 0, width, height, null);
		g.dispose();
		return resizedImage;
	}

	protected void attachPdf(Document doc, PdfWriter writer, String filePath) {
		if (!Strings.isNullOrEmpty(filePath)) {
			try {
				PdfContentByte cb = writer.getDirectContent();
				PdfReader reader = new PdfReader(filePath);
				for (int i = 1; i <= reader.getNumberOfPages(); i++) {
					doc.newPage();
					// import the page from source pdf
					PdfImportedPage page = writer.getImportedPage(reader, i);
					// add the page to the destination pdf
					cb.addTemplate(page, 0, 0);
				}
			} catch (BadElementException | IOException e) {
				e.printStackTrace();
			}
		}
	}

	protected Document createDefaultDocument() {
		return new Document(PageSize.A4, DEFAULT_MARGIN_X, DEFAULT_MARGIN_X, DEFAULT_MARGIN_Y, DEFAULT_MARGIN_Y);
	}

	protected float getWidth(Document doc) {
		return doc.getPageSize().getWidth() - doc.leftMargin() - doc.rightMargin();
	}

	protected float getHeight(Document doc) {
		return doc.getPageSize().getHeight() - doc.topMargin() - doc.bottomMargin();
	}

	protected float getAttachedImageWidth(Document doc) {
		return doc.getPageSize().getWidth() - DEFAULT_IMG_MARGIN_X - DEFAULT_IMG_MARGIN_X;
	}

	protected float getAttachedImageHeight(Document doc) {
		return doc.getPageSize().getHeight() - DEFAULT_IMG_MARGIN_Y - DEFAULT_IMG_MARGIN_Y;
	}

	protected PdfPCell createCellNoBorder(String text) {
		PdfPCell cell = new PdfPCell(new Paragraph(!Strings.isNullOrEmpty(text) ? text : ""));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPadding(5);
		return cell;
	}

	protected PdfPCell createCellWithBorder(String text) {
		PdfPCell cell = new PdfPCell(new Paragraph(!Strings.isNullOrEmpty(text) ? text : ""));
		cell.setPadding(5);
		return cell;
	}

	protected PdfPCell createCellForSignature(String text) {
		Paragraph p = new Paragraph(!Strings.isNullOrEmpty(text) ? text : "", new Font(Font.HELVETICA, 1, Font.NORMAL, Color.WHITE));
		PdfPCell cell = new PdfPCell(p);
		cell.setPadding(5);
		cell.setFixedHeight(60);
		cell.setBorderColorTop(Color.white);
		cell.setHorizontalAlignment(Element.ALIGN_BOTTOM);
		cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
		// cell.setBackgroundColor(Color.WHITE);
		return cell;
	}

	protected PdfPCell createStyledCellWithBorder(String text, Font headerFont) {
		PdfPCell cell = new PdfPCell(new Paragraph(!Strings.isNullOrEmpty(text) ? text : "", headerFont));
		cell.setPadding(5);
		return cell;
	}

	protected PdfPCell createCellWithBorderColSpan(String text, int colspan, Font headerFont) {
		PdfPCell cell = new PdfPCell(new Paragraph(!Strings.isNullOrEmpty(text) ? text : "", headerFont));
		cell.setColspan(colspan);
		cell.setPadding(5);
		return cell;
	}

	protected PdfPCell createCellWithBorderRowSpan(String text, int rowspan) {
		PdfPCell cellWithRowspan = new PdfPCell();
		cellWithRowspan.setRowspan(rowspan);
		cellWithRowspan.addElement(new Phrase(text));
		cellWithRowspan.setPadding(5);
		return cellWithRowspan;
	}

	protected PdfPCell createCellWithBorderAlignCenter(String text) {
		PdfPCell cell = new PdfPCell(new Paragraph(!Strings.isNullOrEmpty(text) ? text : ""));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setPadding(5);
		return cell;
	}

	protected PdfPTable createNewTable(int noOfCols, float widthPercent, float[] colWidths) {
		PdfPTable table = new PdfPTable(noOfCols);
		table.setWidthPercentage(widthPercent); // Width 100%
		table.setWidths(colWidths);// Set Column widths
		return table;
	}

	protected Paragraph createParaWithSpacing(String text, Font font, float spacingAfter) {
		Paragraph para = new Paragraph(!Strings.isNullOrEmpty(text) ? text : "", font);
		para.setSpacingAfter(spacingAfter);
		return para;
	}

	protected abstract String getResultUrl();

	protected abstract void addCommands(MultiValueMap<String, Object> body);
}