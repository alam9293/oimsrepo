# TAKE NOTE during deployment:

1. With reference to `tag.dir.base` configured in application.properties
	it should be pointing to path: /home/stbapp/stb_app_files/app_files_admin/download
	
2. COPY "TG_licence_print_template.xlsx" from \stb-tag-common\excel template into appserver's upload folder (refer to step #1 above for the path)


Note: Purpose of TG_licence_print_template.xlsx is for system to duplicate and modify the content for STB officer to send it to printing vendor.
