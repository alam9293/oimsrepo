-- mysql -uroot -p
CREATE USER 'tag_user'@'%' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON *.* TO 'tag_user'@'%' WITH GRANT OPTION;

-- if DB created under root, can grant using the following line
-- GRANT ALL PRIVILEGES ON stb_tag_admin_dev.* TO 'tag_user'@'%' WITH GRANT OPTION;


-- for STB DC, have to login as root
-- for AWS, have to request NCS assistance
SET GLOBAL log_bin_trust_function_creators = 1;


-- create DB with proper character set
CREATE DATABASE stb_tag_admin_dev CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE stb_tag_public_dev CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- enable slow query logging in STBDC DB
-- to ensure the path is created with mysql as owner /var/log/mysql/slow-query.log
SET GLOBAL slow_query_log_file ='/var/log/mysql/slow-query.log';
SET GLOBAL slow_query_log = 'ON';
SET GLOBAL long_query_time = 20;
SET GLOBAL log_queries_not_using_indexes = 'ON'
show variables LIKE '%slow%';
show variables LIKE 'long_query_time';
