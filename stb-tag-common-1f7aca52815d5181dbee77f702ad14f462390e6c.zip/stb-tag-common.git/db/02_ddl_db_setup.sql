-- AWS only accepts timezone string, configured at AWS web console 
-- SET GLOBAL time_zone = 'Asia/Singapore';
-- SET GLOBAL time_zone = '+8:00'; --for local

-- trigger for generate type code and running code
DELIMITER //
DROP TRIGGER IF EXISTS types_before_insert;
CREATE TRIGGER types_before_insert
BEFORE INSERT
   ON types FOR EACH ROW
BEGIN
	DECLARE vMax INTEGER;
    SELECT MAX(runningCode) FROM types INTO vMax;
	SET NEW.runningCode = IFNULL(vMax, 0) + 1;
    
	IF (ISNULL(NEW.code)) THEN
   		SET NEW.code = CONCAT(IFNULL(NEW.categoryCode,''), '_', NEW.runningCode);
   	END IF;
END; //
DELIMITER ;

-- trigger for generate TA and TG licence no
DELIMITER //
DROP TRIGGER IF EXISTS lic_no_before_insert;
CREATE TRIGGER lic_no_before_insert
BEFORE INSERT
   ON licences FOR EACH ROW
BEGIN
	DECLARE vMax INTEGER;
	DECLARE licNo VARCHAR(255);
	
	IF (NEW.taTgType LIKE "TA") THEN
		SELECT value FROM system_parameters WHERE code LIKE "TA_LICENCE_NO" INTO vMax;

		IF (vMax > 99999) THEN 
			SET licNo = vMax; 
		ELSE
			SET licNo = LPAD( vMax, 5, '0' );
		END IF;
		
		IF (NEW.tierCode LIKE 'TA_TIER_N') THEN
			SET licNo = CONCAT(licNo, 'N');
		END IF;
		
		SET NEW.licenceNo = licNo;
		UPDATE system_parameters SET value = (vMax+1) WHERE code LIKE "TA_LICENCE_NO";
	ELSE
		SELECT value FROM system_parameters WHERE code LIKE "TG_LICENCE_NO" INTO vMax;

		IF (vMax > 9999) THEN 
			SET licNo = vMax; 
		ELSE
			SET licNo = LPAD( vMax, 4, '0' );
		END IF;
		
		SET NEW.licenceNo = licNo;
		UPDATE system_parameters SET value = (vMax+1) WHERE code LIKE "TG_LICENCE_NO";
	END IF;
    
END; //
DELIMITER ;

-- trigger for generate TA and TG application no
DELIMITER //
DROP TRIGGER IF EXISTS app_no_before_insert;
CREATE TRIGGER app_no_before_insert
BEFORE INSERT
   ON applications FOR EACH ROW
BEGIN
	DECLARE vMax INTEGER;
	
	IF (NEW.taTgType LIKE "TA") THEN
		SELECT value FROM system_parameters WHERE code LIKE "TA_APPLICATION_NO" INTO vMax;
		SET NEW.applicationNo = CONCAT('TA-', YEAR(CURDATE()),LPAD( MONTH(CURDATE()), 2, '0' ),'-', LPAD( vMax, 6, '0' ));
		
        IF (vMax = 999999) THEN
			UPDATE system_parameters SET value = 1 WHERE code LIKE "TA_APPLICATION_NO";
		ELSE
        	UPDATE system_parameters SET value = (vMax+1) WHERE code LIKE "TA_APPLICATION_NO";
        END IF;
	ELSE
		SELECT value FROM system_parameters WHERE code LIKE "TG_APPLICATION_NO" INTO vMax;
		SET NEW.applicationNo = CONCAT('TG-', YEAR(CURDATE()),LPAD( MONTH(CURDATE()), 2, '0' ),'-', LPAD( vMax, 6, '0' ));
        
		IF (vMax = 999999) THEN
			UPDATE system_parameters SET value = 1 WHERE code LIKE "TG_APPLICATION_NO";
		ELSE
        	UPDATE system_parameters SET value = (vMax+1) WHERE code LIKE "TG_APPLICATION_NO";
        END IF;
	END IF;

    
END; //
DELIMITER ;