-- master data specific for public only

-- JOBS (PUBLIC) --

INSERT INTO jobs (createdBy, createdDate, updatedBy, updatedDate, version, isActive, cronExpression, scheduleDescription, className, description) VALUES ('SYSTEM', NOW(), 'SYSTEM', NOW(), 0, 1, '0 0 0/1 * * ?', 'Every hour at :00 minute', 'gov.stb.tag.job.ApplicationFileTxfPublicJob', 'For putting file transfer between Internet to Intranet.');
