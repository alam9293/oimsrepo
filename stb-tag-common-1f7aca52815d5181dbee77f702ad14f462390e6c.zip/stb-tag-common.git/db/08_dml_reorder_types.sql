
update types set ordinal = 999 where label like 'Other%'; 

update types as t1 
	inner join (SELECT 
    code, label, otherLabel, ordinal,
    ROW_NUMBER() OVER (PARTITION BY categoryCode ORDER BY label asc) AS rownum
FROM types
where categoryCode is not null and label not like 'other%') as t2 on t1.code = t2.code 
Set t1.ordinal = t2.rownum;


UPDATE types SET otherLabel= null WHERE (code = 'TA_DOC_BANK');

UPDATE types SET ordinal = '1' WHERE (categoryCode  = 'TA_AUDITOR_OPINION' and code = 'TA_AUDITOR_OPINION_UNQ');
UPDATE types SET ordinal = '2' WHERE (categoryCode  = 'TA_AUDITOR_OPINION' and code = 'TA_AUDITOR_OPINION_QLFY');
UPDATE types SET ordinal = '3' WHERE (categoryCode  = 'TA_AUDITOR_OPINION' and code = 'TA_AUDITOR_OPINION_DISC');
UPDATE types SET ordinal = '4' WHERE (categoryCode  = 'TA_AUDITOR_OPINION' and code = 'TA_AUDITOR_OPINION_ADV');

update types set ordinal = 1 where code = 'STKHLD_KE';
update types set ordinal = 2 where code = 'STKHLD_DI';
update types set ordinal = 3 where code = 'STKHLD_KE';
update types set ordinal = 4 where code = 'STKHLD_SPP';
update types set ordinal = 5 where code = 'STKHLD_PT';
update types set ordinal = 6 where code = 'STKHLD_MD';
update types set ordinal = 7 where code = 'STKHLD_DI';
update types set ordinal = 8 where code = 'STKHLD_MG';
update types set ordinal = 9 where code = 'STKHLD_SH';
update types set ordinal = 10 where code = 'STKHLD_ADM';
update types set ordinal = 11 where code = 'STKHLD_AG';
update types set ordinal = 12 where code = 'STKHLD_AGF';
update types set ordinal = 13 where code = 'STKHLD_AUD';
update types set ordinal = 14 where code = 'STKHLD_AR';
update types set ordinal = 15 where code = 'STKHLD_CEO';
update types set ordinal = 16 where code = 'STKHLD_DIA';
update types set ordinal = 17 where code = 'STKHLD_EO';
update types set ordinal = 18 where code = 'STKHLD_EXE';
update types set ordinal = 19 where code = 'STKHLD_FC';
update types set ordinal = 20 where code = 'STKHLD_GP';
update types set ordinal = 21 where code = 'STKHLD_GPF';
update types set ordinal = 22 where code = 'STKHLD_GPN';
update types set ordinal = 23 where code = 'STKHLD_ID';
update types set ordinal = 24 where code = 'STKHLD_LLP';
update types set ordinal = 25 where code = 'STKHLD_LP';
update types set ordinal = 26 where code = 'STKHLD_LC';
update types set ordinal = 27 where code = 'STKHLD_MEM';
update types set ordinal = 28 where code = 'STKHLD_NOK';
update types set ordinal = 29 where code = 'STKHLD_NOM';
update types set ordinal = 30 where code = 'STKHLD_NT';
update types set ordinal = 31 where code = 'STKHLD_OFC';
update types set ordinal = 32 where code = 'STKHLD_OWN';
update types set ordinal = 33 where code = 'STKHLD_PTA';
update types set ordinal = 34 where code = 'STKHLD_PTL';
update types set ordinal = 35 where code = 'STKHLD_PA';
update types set ordinal = 36 where code = 'STKHLD_PAL';
update types set ordinal = 37 where code = 'STKHLD_SEC';
update types set ordinal = 38 where code = 'STKHLD_TRU';
update types set ordinal = 39 where code = 'STKHLD_UF';
update types set ordinal = 40 where code = 'STKHLD_UL';

update types set ordinal = 1 where code = 'NAT_SG';
update types set ordinal = ordinal +1 where code != 'NAT_SG' AND categoryCode = 'NAT';

update statuses set ordinal = 999 where label like 'other%'; 

update statuses as t1 
	inner join (SELECT 
    code, label, otherLabel, ordinal,
    ROW_NUMBER() OVER (PARTITION BY categoryCode ORDER BY label asc) AS rownum
FROM statuses
where categoryCode is not null and label not like 'other%') as t2 on t1.code = t2.code 
Set t1.ordinal = t2.rownum;

