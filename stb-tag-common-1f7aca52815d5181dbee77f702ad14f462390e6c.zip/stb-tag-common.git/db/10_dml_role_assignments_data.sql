-- pls maintain at google sheet
-- this is manually maintained by sswong for DB re-setup

INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TA Processing Officer', 'TA_PO', 0, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TA Processing Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TA Verifying Officer', 'TA_VO', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TA Verifying Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TA Approving Officer', 'TA_AO', 2, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TA Approving Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TA Head of Division', 'TA_HODIV', 3, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TA Head of Division' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TA C&E Enforcement Officer', 'TA_CNE_EO', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TA C&E Enforcement Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TA Viewer', 'TA_VIEWER', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TA Viewer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TG Processing Officer', 'TG_PO', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TG Processing Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TG Approving Officer', 'TG_AO', 2, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TG Approving Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TG C&E Enforcement Officer', 'TG_CNE_EO', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TG C&E Enforcement Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'TG Viewer', 'TG_VIEWER', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'TG Viewer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'C&E Investigation Officer', 'CNE_IO', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'C&E Investigation Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'C&E Compliance Officer', 'CNE_CO', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'C&E Compliance Officer' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'System Administrator', 'SYSADM', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'System Administrator' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'Finance', 'FINANCE', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'Finance' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'Super Role', 'SUPER', 1, 1, 1, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'Super Role' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'Travel Agent Licensee', 'TA_PUB', 1, 0, 0, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'Travel Agent Licensee' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'Travel Agent Candidates', 'TA_CDD', 1, 0, 0, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'Travel Agent Candidates' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'Tourist Guide Licensee', 'TG_PUB', 1, 0, 0, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'Tourist Guide Licensee' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'Training Provider', 'TP_PUB', 1, 0, 0, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'Training Provider' WHERE r.code IS NULL);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) (SELECT 'Tourist Guide Candidate', 'TG_CDD', 1, 0, 0, 0 FROM (SELECT 1 dummy) x LEFT JOIN roles r ON label = 'Tourist Guide Candidate' WHERE r.code IS NULL);



INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search and View TA Licences', '/ta/licences/view', 'MOD_TA', 'TA_LC_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/licences/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/licences/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Licence Statuses', '/ta/licences/update-status', 'MOD_TA', 'TA_LC_UPD_STATUS', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/licences/update-status' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/licences/update-status');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/licences/update-status');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/licences/update-status');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search and View TA Return of Licences', '/ta/licences/return/view', 'MOD_TA', 'TA_LC_R_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/licences/return/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/licences/return/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/licences/return/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Mark Licences as Returned', '/ta/licences/return/update', 'MOD_TA', 'TA_LC_R_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/licences/return/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/licences/return/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/licences/return/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/licences/return/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/licences/return/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Applications / Submissions', '/ta/applications/view', 'MOD_TA', 'TA_APP_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/applications/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/applications/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search and View TA Personnels', '/ta/personnel/view', 'MOD_TA', 'TA_SH', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/personnel/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/personnel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/personnel/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Applications / Submissions', '/ta/applications/history', 'MOD_TA', 'TA_APP_HIS', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/applications/history' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/applications/history');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Licence Creation Applications', '/ta/creations/view', 'MOD_TA', 'TA_CRE_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA Licence Creation Applications', '/ta/creations/approve', 'MOD_TA', 'TA_CRE_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/creations/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/creations/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA Licence Creation Applications', '/ta/creations/rfa', 'MOD_TA', 'TA_CRE_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/creations/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/creations/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA Licence Creation Applications', '/ta/creations/reject', 'MOD_TA', 'TA_CRE_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/creations/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/creations/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/creations/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA Licence Creation Applications', '/ta/creations/notes/save', 'MOD_TA', 'TA_CRE_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/creations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/creations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/creations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/creations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Look for similar stakeholder', '/ta/creations/get-same-stakeholder', 'MOD_TA', 'TA_CRE_SAME_STKHLD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/get-same-stakeholder' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/creations/get-same-stakeholder');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/creations/get-same-stakeholder');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/creations/get-same-stakeholder');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/creations/get-same-stakeholder');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/get-same-stakeholder');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Licence Creation', '/ta/creations/new', 'MOD_TA', 'TA_CRE_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Licence Creation', '/ta/creations/save', 'MOD_TA', 'TA_CRE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Licence Creation', '/ta/creations/update', 'MOD_TA', 'TA_CRE_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Email TA Licence Creation KE', '/ta/creations/email-ke', 'MOD_TA', 'TA_CRE_EML_KE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/email-ke' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/email-ke');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/email-ke');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/email-ke');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA Licence Creation', '/ta/creations/load', 'MOD_TA', 'TA_CRE_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/load');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/load');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Link App Fee', '/ta/creations/link-app-fee', 'MOD_TA', 'TA_CRE_LAF', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/link-app-fee' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/link-app-fee');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/link-app-fee');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/link-app-fee');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Submit TA Licence Creation', '/ta/creations/submit', 'MOD_TA', 'TA_CRE_SUBMIT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/submit' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/submit');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/creations/submit');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/submit');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save Payment Request', '/ta/creations/save-payment-request', 'MOD_TA', 'TA_CRE_PAY_REQ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/creations/save-payment-request' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/creations/save-payment-request');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/ta/creations/save-payment-request');



INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Licence Cessation Applications', '/ta/cessations/view', 'MOD_TA', 'TA_CES_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/cessations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/cessations/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA Licence Cessation Applications', '/ta/cessations/approve', 'MOD_TA', 'TA_CES_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/cessations/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/cessations/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/cessations/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA Licence Cessation Applications', '/ta/cessations/rfa', 'MOD_TA', 'TA_CES_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/cessations/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/cessations/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/cessations/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA Licence Cessation Applications', '/ta/cessations/reject', 'MOD_TA', 'TA_CES_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/cessations/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/cessations/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/cessations/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/cessations/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA Licence Cessation Applications', '/ta/cessations/notes/save', 'MOD_TA', 'TA_CES_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/cessations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/cessations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/cessations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/cessations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/cessations/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Licence Cessation', '/ta/cessations/new', 'MOD_TA', 'TA_CES_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/cessations/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Licence Cessation', '/ta/cessations/save', 'MOD_TA', 'TA_CES_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/cessations/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Licence Cessation', '/ta/cessations/update', 'MOD_TA', 'TA_CES_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/cessations/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA Licence Cessation', '/ta/cessations/load', 'MOD_TA', 'TA_CES_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/cessations/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/cessations/load');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA ABPR Submissions', '/ta/abprs/view', 'MOD_TA', 'TA_ABPR_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/abprs/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/abprs/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA ABPR Submissions', '/ta/abprs/approve', 'MOD_TA', 'TA_ABPR_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/abprs/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/abprs/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/abprs/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/abprs/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA ABPR Submissions', '/ta/abprs/rfa', 'MOD_TA', 'TA_ABPR_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/abprs/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/abprs/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/abprs/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/abprs/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA ABPR Submissions', '/ta/abprs/reject', 'MOD_TA', 'TA_ABPR_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/abprs/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/abprs/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/abprs/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/abprs/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA ABPR Submissions', '/ta/abprs/notes/save', 'MOD_TA', 'TA_ABPR_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/abprs/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/abprs/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/abprs/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/abprs/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/abprs/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA ABPR Submission', '/ta/abprs/new', 'MOD_TA', 'TA_ABPR_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/abprs/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA ABPR Submission', '/ta/abprs/save', 'MOD_TA', 'TA_ABPR_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/abprs/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA ABPR Submission', '/ta/abprs/update', 'MOD_TA', 'TA_ABPR_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/abprs/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/abprs/update');



INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Licence Tier Switch Applications', '/ta/tier-switches/view', 'MOD_TA', 'TA_TS_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/tier-switches/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/tier-switches/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA Licence Tier Switch Applications', '/ta/tier-switches/approve', 'MOD_TA', 'TA_TS_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/tier-switches/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/tier-switches/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/tier-switches/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA Licence Tier Switch Applications', '/ta/tier-switches/rfa', 'MOD_TA', 'TA_TS_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/tier-switches/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/tier-switches/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/tier-switches/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/tier-switches/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA Licence Tier Switch Applications', '/ta/tier-switches/reject', 'MOD_TA', 'TA_TS_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/tier-switches/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/tier-switches/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/tier-switches/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/tier-switches/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA Licence Tier Switch Applications', '/ta/tier-switches/notes/save', 'MOD_TA', 'TA_TS_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/tier-switches/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/tier-switches/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/tier-switches/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/tier-switches/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/tier-switches/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Licence Tier Switch', '/ta/tier-switches/new', 'MOD_TA', 'TA_TS_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/tier-switches/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Licence Tier Switch', '/ta/tier-switches/save', 'MOD_TA', 'TA_TS_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/tier-switches/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Licence Tier Switch', '/ta/tier-switches/update', 'MOD_TA', 'TA_TS_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/tier-switches/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA Licence Tier Switch Application', '/ta/tier-switches/load', 'MOD_TA', 'TA_TS_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/tier-switches/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/tier-switches/load');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Licence Branch Applications', '/ta/branch-applications/view', 'MOD_TA', 'TA_BA_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/branch-applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/branch-applications/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA Licence Branch Applications', '/ta/branch-applications/approve', 'MOD_TA', 'TA_BA_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/branch-applications/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/branch-applications/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/branch-applications/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA Licence Branch Applications', '/ta/branch-applications/rfa', 'MOD_TA', 'TA_BA_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/branch-applications/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/branch-applications/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/branch-applications/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA Licence Branch Applications', '/ta/branch-applications/reject', 'MOD_TA', 'TA_BA_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/branch-applications/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/branch-applications/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/branch-applications/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/branch-applications/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA Licence Branch Applications', '/ta/branch-applications/notes/save', 'MOD_TA', 'TA_BA_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/branch-applications/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/branch-applications/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/branch-applications/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/branch-applications/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/branch-applications/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Branch Applications', '/ta/branch-applications/new', 'MOD_TA', 'TA_BA_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/branch-applications/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Branch Applications', '/ta/branch-applications/save', 'MOD_TA', 'TA_BA_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/branch-applications/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Branch Applications', '/ta/branch-applications/update', 'MOD_TA', 'TA_BA_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/branch-applications/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/branch-applications/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Licence Replacement Applications', '/ta/replacement/view', 'MOD_TA', 'TA_REP_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/replacement/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/replacement/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA Licence Replacement Applications', '/ta/replacement/approve', 'MOD_TA', 'TA_REP_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/replacement/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/replacement/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/replacement/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA Licence Replacement Applications', '/ta/replacement/rfa', 'MOD_TA', 'TA_REP_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/replacement/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/replacement/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/replacement/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA Licence Replacement Applications', '/ta/replacement/reject', 'MOD_TA', 'TA_REP_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/replacement/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/replacement/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/replacement/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/replacement/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA Licence Replacement Applications', '/ta/replacement/notes/save', 'MOD_TA', 'TA_REP_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/replacement/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/replacement/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/replacement/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/replacement/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/replacement/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Licence Replacement ', '/ta/replacement/new', 'MOD_TA', 'TA_REP_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/replacement/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Licence Replacement ', '/ta/replacement/save', 'MOD_TA', 'TA_REP_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/replacement/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA Licence Replacement ', '/ta/replacement/load', 'MOD_TA', 'TA_REP_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/replacement/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Link TA Licence Replacement to Payment Request', '/ta/replacement/link-pay-request', 'MOD_TA', 'TA_REP_LINK_PR', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/link-pay-request' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/replacement/link-pay-request');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save Payment Request', '/ta/replacement/save-payment-request', 'MOD_TA', 'TA_REP_PAY_REQ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/replacement/save-payment-request' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/replacement/save-payment-request');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/replacement/save-payment-request');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA AA Submissions', '/ta/audited-accounts/view', 'MOD_TA', 'TA_AA_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/audited-accounts/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA AA Submissions', '/ta/audited-accounts/approve', 'MOD_TA', 'TA_AA_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/audited-accounts/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/audited-accounts/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA AA Submissions', '/ta/audited-accounts/rfa', 'MOD_TA', 'TA_AA_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/audited-accounts/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/audited-accounts/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA AA Submissions', '/ta/audited-accounts/reject', 'MOD_TA', 'TA_AA_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/audited-accounts/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/audited-accounts/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA AA Submissions', '/ta/audited-accounts/notes/save', 'MOD_TA', 'TA_AA_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/audited-accounts/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/audited-accounts/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/audited-accounts/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA AA Submission', '/ta/audited-accounts/new', 'MOD_TA', 'TA_AA_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/audited-accounts/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA AA Submission', '/ta/audited-accounts/save', 'MOD_TA', 'TA_AA_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/audited-accounts/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA AA Submission', '/ta/audited-accounts/update', 'MOD_TA', 'TA_AA_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/audited-accounts/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA AA Application', '/ta/audited-accounts/load', 'MOD_TA', 'TA_AA_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/audited-accounts/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Offline AA Submission', '/ta/audited-accounts/offline/new', 'MOD_TA', 'TA_AA_OFF_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/offline/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/audited-accounts/offline/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/offline/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/audited-accounts/offline/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/audited-accounts/offline/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/offline/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Offline AA Submission', '/ta/audited-accounts/offline/save', 'MOD_TA', 'TA_AA_OFF_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/offline/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/audited-accounts/offline/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/offline/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/audited-accounts/offline/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/audited-accounts/offline/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/offline/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Offline AA Submission', '/ta/audited-accounts/offline/update', 'MOD_TA', 'TA_AA_OFF_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/audited-accounts/offline/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/audited-accounts/offline/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/audited-accounts/offline/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/audited-accounts/offline/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/audited-accounts/offline/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/audited-accounts/offline/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Licence Company Update Applications', '/ta/company-updates/view', 'MOD_TA', 'TA_COMP_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/company-updates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/company-updates/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA Licence Company Update Applications', '/ta/company-updates/approve', 'MOD_TA', 'TA_COMP_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/company-updates/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/company-updates/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/company-updates/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA Licence Company Update Applications', '/ta/company-updates/rfa', 'MOD_TA', 'TA_COMP_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/company-updates/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/company-updates/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/company-updates/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA Licence Company Update Applications', '/ta/company-updates/reject', 'MOD_TA', 'TA_COMP_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/company-updates/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/company-updates/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/company-updates/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/company-updates/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA Licence Company Update Applications', '/ta/company-updates/notes/save', 'MOD_TA', 'TA_COMP_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/company-updates/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/company-updates/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/company-updates/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/company-updates/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/company-updates/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Company Update Applications', '/ta/company-updates/new', 'MOD_TA', 'TA_COMP_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/company-updates/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Company Update Applications', '/ta/company-updates/save', 'MOD_TA', 'TA_COMP_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/company-updates/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Company Update Applications', '/ta/company-updates/update', 'MOD_TA', 'TA_COMP_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/company-updates/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/company-updates/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Change of Financial Year End Applications', '/ta/fye/view', 'MOD_TA', 'TA_FYE_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/fye/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/fye/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA Change of Financial Year End Applications', '/ta/fye/approve', 'MOD_TA', 'TA_FYE_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/fye/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/fye/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/fye/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA Change of Financial Year End Applications', '/ta/fye/rfa', 'MOD_TA', 'TA_FYE_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/fye/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/fye/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/fye/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA Change of Financial Year End Applications', '/ta/fye/reject', 'MOD_TA', 'TA_FYE_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/fye/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/fye/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/fye/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/fye/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA Change of Financial Year End Applications', '/ta/fye/notes/save', 'MOD_TA', 'TA_FYE_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/fye/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/fye/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/fye/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/fye/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/fye/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA Change of Financial Year End', '/ta/fye/load', 'MOD_TA', 'TA_FYE_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/fye/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA Licence Change of Financial Year End', '/ta/fye/save', 'MOD_TA', 'TA_FYE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/fye/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA Licence Change of Financial Year End', '/ta/fye/update', 'MOD_TA', 'TA_FYE_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/fye/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/fye/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA Manage KE', '/ta/ke/view', 'MOD_TA', 'TA_KE_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/ke/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/ke/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA KE ', '/ta/ke/approve', 'MOD_TA', 'TA_KE_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/ke/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/ke/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/ke/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TA KE ', '/ta/ke/rfa', 'MOD_TA', 'TA_KE_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/ke/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/ke/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/ke/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA KE ', '/ta/ke/reject', 'MOD_TA', 'TA_KE_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/ke/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/ke/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/ke/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/ke/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA KE ', '/ta/ke/notes/save', 'MOD_TA', 'TA_KE_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/ke/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/ke/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/ke/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/ta/ke/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/ta/ke/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA KE update details Submission', '/ta/ke/update-details/load', 'MOD_TA', 'TA_KE_UPD_DETAILS_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/update-details/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/update-details/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA KE update details Submission', '/ta/ke/update-details/save', 'MOD_TA', 'TA_KE_UPD_DETAILS_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/update-details/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/update-details/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA KE update details Submission', '/ta/ke/update-details/update', 'MOD_TA', 'TA_KE_UPD_DETAILS_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/update-details/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/update-details/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA KE Update details Submission', '/ta/ke/update-details/new', 'MOD_TA', 'TA_KE_UPD_DETAILS_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/update-details/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/update-details/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA KE Resign Submission', '/ta/ke/resign/load', 'MOD_TA', 'TA_KE_UPD_RESIGN_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/resign/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/resign/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA KE Resign Submission', '/ta/ke/resign/save', 'MOD_TA', 'TA_KE_UPD_RESIGN_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/resign/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/resign/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA KE Resign Submission', '/ta/ke/resign/update', 'MOD_TA', 'TA_KE_UPD_RESIGN_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/resign/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/resign/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA KE Resign Submission', '/ta/ke/resign/new', 'MOD_TA', 'TA_KE_UPD_RESIGN_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/resign/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/resign/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA KE Assign Submission', '/ta/ke/assign/load', 'MOD_TA', 'TA_KE_UPD_ASSIGN_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/assign/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/assign/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA KE Assign Submission', '/ta/ke/assign/save', 'MOD_TA', 'TA_KE_UPD_ASSIGN_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/assign/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/assign/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA KE Assign Submission', '/ta/ke/assign/update', 'MOD_TA', 'TA_KE_UPD_ASSIGN_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/assign/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/assign/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA KE Assign Submission', '/ta/ke/assign/new', 'MOD_TA', 'TA_KE_UPD_ASSIGN_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/ke/assign/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/ke/assign/new');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load Personnel', '/ta/personnel/load', 'MOD_TA', 'TA_PSN_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/personnel/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/personnel/load');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save Personnel', '/ta/personnel/save', 'MOD_TA', 'TA_PSN_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/personnel/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/personnel/save');




INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Courses', '/tg/courses/view', 'MOD_TG', 'TG_CSE_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/courses/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/courses/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/courses/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/tg/courses/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/courses/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/courses/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Candidates', '/tg/candidates/view', 'MOD_TG', 'TG_CDD_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/candidates/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/candidates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/candidates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/tg/candidates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/candidates/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/candidates/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Upload TG Candidates', '/tg/candidates/save', 'MOD_TG', 'TG_CDD_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/candidates/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/candidates/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/candidates/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Licences', '/tg/licences/view', 'MOD_TG', 'TG_LC_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licences/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/tg/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG C&E Enforcement Officer' AND functions.uri='/tg/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/tg/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/licences/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licences/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Suspend TG Licences', '/tg/licences/suspend', 'MOD_TG', 'TG_LC_SUS', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licences/suspend' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licences/suspend');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/licences/suspend');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licences/suspend');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Revoke TG Licences', '/tg/licences/revoke', 'MOD_TG', 'TG_LC_REV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licences/revoke' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licences/revoke');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/licences/revoke');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licences/revoke');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG Licences', '/tg/licences/update', 'MOD_TG', 'TG_LC_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licences/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licences/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licences/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Applications / Submissions', '/tg/applications/view', 'MOD_TG', 'TG_APP_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/applications/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/tg/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/applications/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/applications/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Licence Printing / Collection', '/tg/licence-printing/view', 'MOD_TG', 'TG_LP_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-printing/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-printing/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-printing/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/licence-printing/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-printing/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Licence Printing / Collection', '/tg/licence-printing/update', 'MOD_TG', 'TG_LP_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-printing/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-printing/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-printing/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/licence-printing/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-printing/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Licence Creation Applications', '/tg/creations/view', 'MOD_TG', 'TG_CRE_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/creations/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/creations/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TG Licence Creation Applications', '/tg/creations/approve', 'MOD_TG', 'TG_CRE_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/creations/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/creations/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TG Licence Creation Applications', '/tg/creations/rfa', 'MOD_TG', 'TG_CRE_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/creations/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/creations/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TG Licence Creation Applications', '/tg/creations/reject', 'MOD_TG', 'TG_CRE_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/creations/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/creations/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TG Licence Creation Applications', '/tg/creations/notes/save', 'MOD_TG', 'TG_CRE_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/creations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/creations/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/creations/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TG Licence Creation', '/tg/creations/new', 'MOD_TG', 'TG_CRE_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/tg/creations/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG Licence Creation', '/tg/creations/save', 'MOD_TG', 'TG_CRE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/tg/creations/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Draft TG Licence Creation', '/tg/creations/draft', 'MOD_TG', 'TG_CRE_DRAFT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/draft' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/tg/creations/draft');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load Edit TG Licence Creation', '/tg/creations/edit', 'MOD_TG', 'TG_CRE_EDIT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/edit' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/tg/creations/edit');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG Licence Creation', '/tg/creations/update', 'MOD_TG', 'TG_CRE_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/creations/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/tg/creations/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Assignment Submission', '/tg/assignments/view', 'MOD_TG', 'TG_ASG_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/assignments/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/assignments/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/assignments/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/assignments/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View Current Cycle TG Assignment Submission', '/tg/assignments/current/view', 'MOD_TG', 'TG_ASG_CUR_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/assignments/current/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/assignments/current/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG Assignment Submission', '/tg/assignments/save', 'MOD_TG', 'TG_ASG_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/assignments/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/assignments/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG Assignment Submission', '/tg/assignments/update', 'MOD_TG', 'TG_ASG_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/assignments/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/assignments/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Update Particulars Applications', '/tg/particulars/view', 'MOD_TG', 'TG_PAR_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/particulars/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/particulars/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/particulars/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/particulars/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TG Update Particulars Applications', '/tg/particulars/approve', 'MOD_TG', 'TG_PAR_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/particulars/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/particulars/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TG Update Particulars Applications', '/tg/particulars/rfa', 'MOD_TG', 'TG_PAR_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/particulars/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/particulars/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TG Update Particulars Applications', '/tg/particulars/reject', 'MOD_TG', 'TG_PAR_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/particulars/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/particulars/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TG Update Particulars Applications', '/tg/particulars/notes/save', 'MOD_TG', 'TG_PAR_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/particulars/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/particulars/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/particulars/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Particulars', '/tg/particulars/new', 'MOD_TG', 'TG_PAR_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/particulars/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG particulars', '/tg/particulars/save', 'MOD_TG', 'TG_PAR_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/particulars/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Edit TG particulars', '/tg/particulars/edit', 'MOD_TG', 'TG_PAR_EDIT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/edit' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/particulars/edit');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG particulars', '/tg/particulars/update', 'MOD_TG', 'TG_PAR_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/particulars/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/particulars/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View Course', '/tg/course/view', 'MOD_TG', 'TG_CRSE_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/course/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/course/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/course/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/course/view');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View MRC', '/tp/mrc/view', 'MOD_TG', 'TP_MRC_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tp/mrc/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/tp/mrc/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add TP MRC', '/tp/mrc/save', 'MOD_TG', 'TP_MRC_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tp/mrc/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/tp/mrc/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TP MRC', '/tp/mrc/update', 'MOD_TG', 'TP_MRC_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tp/mrc/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/tp/mrc/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View PDC', '/tp/pdc/view', 'MOD_TG', 'TP_PDC_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tp/pdc/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/tp/pdc/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add TP PDC', '/tp/pdc/save', 'MOD_TG', 'TP_PDC_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tp/pdc/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/tp/pdc/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TP MRC', '/tp/pdc/update', 'MOD_TG', 'TP_PDC_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tp/pdc/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/tp/pdc/update');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Licence Cancellation', '/tg/cancel/new', 'MOD_TG', 'TG_CAN_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/cancel/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/cancel/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG Licence Cancellation', '/tg/cancel/save', 'MOD_TG', 'TG_CAN_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/cancel/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/cancel/save');


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Licence Replacement Applications', '/tg/replace/view', 'MOD_TG', 'TG_REP_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/replace/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/replace/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/replace/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/replace/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TG Licence Replacement Applications', '/tg/replace/approve', 'MOD_TG', 'TG_REP_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/replace/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/replace/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TG Licence Replacement Applications', '/tg/replace/rfa', 'MOD_TG', 'TG_REP_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/replace/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/replace/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TG Licence Replacement Applications', '/tg/replace/reject', 'MOD_TG', 'TG_REP_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/replace/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/replace/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TG Licence Replacement Applications', '/tg/replace/notes/save', 'MOD_TG', 'TG_REP_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/replace/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/replace/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/replace/notes/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TG Licence Replacement', '/tg/replace/new', 'MOD_TG', 'TG_REP_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/replace/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG Licence Replacement', '/tg/replace/save', 'MOD_TG', 'TG_REP_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/replace/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Edit TG Licence Replacement', '/tg/replace/edit', 'MOD_TG', 'TG_REP_EDIT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/edit' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/replace/edit');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG Licence Replacement', '/tg/replace/update', 'MOD_TG', 'TG_REP_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/replace/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/replace/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View TG Licence Renewal Application', '/tg/licence-renewals/view', 'MOD_TG', 'TG_LR_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-renewals/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-renewals/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/licence-renewals/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/licence-renewals/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View TG Licence Renewal Application', '/tg/licence-renewals/new', 'MOD_TG', 'TG_LR_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-renewals/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-renewals/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/licence-renewals/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/new');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/licence-renewals/new');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG Licence Renewal', '/tg/licence-renewals/save', 'MOD_TG', 'TG_LR_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-renewals/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-renewals/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/licence-renewals/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/licence-renewals/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG Licence Renewal', '/tg/licence-renewals/update', 'MOD_TG', 'TG_LR_UPDATE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/update' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-renewals/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-renewals/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/licence-renewals/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/licence-renewals/update');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TG Licence Renewal', '/tg/licence-renewals/approve', 'MOD_TG', 'TG_LR_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-renewals/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/approve');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'RFA TG Licence Renewal', '/tg/licence-renewals/rfa', 'MOD_TG', 'TG_LR_RFA', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/rfa' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-renewals/rfa');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/rfa');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TG Licence Renewal', '/tg/licence-renewals/reject', 'MOD_TG', 'TG_LR_REJ', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-renewals/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/reject');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TG Licence Renewal Applications', '/tg/licence-renewals/notes/save', 'MOD_TG', 'TG_LR_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licence-renewals/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licence-renewals/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licence-renewals/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licence-renewals/notes/save');





INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Dashboard', '/dashboard', 'MOD_USR', 'USR_DASHBOARD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/dashboard' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/dashboard');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/dashboard');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Retrieve current login ID from Intranet', '/users/retrieve-current-login-userid', 'MOD_USR', 'USR_CUR_LOGINID', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/users/retrieve-current-login-userid' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/users/retrieve-current-login-userid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/users/retrieve-current-login-userid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/users/retrieve-current-login-userid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/users/retrieve-current-login-userid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/users/retrieve-current-login-userid');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save myinfo snapshot', '/my-info/snapshot', 'MOD_USR', 'USR_MYINFO_SNAPSHOT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/my-info/snapshot' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/my-info/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/my-info/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/my-info/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/my-info/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/my-info/snapshot');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save edh snapshot', '/edh/snapshot', 'MOD_USR', 'USR_EDH_SNAPSHOT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/edh/snapshot' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/edh/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/edh/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/edh/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/edh/snapshot');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/edh/snapshot');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Get current user details', '/users/current', 'MOD_USR', 'USR_CUR_DETAILS', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/users/current' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/users/current');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/users/current');



INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View Payment Requests', '/payment/requests/view', 'MOD_PAY', 'PAY_REQ_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/requests/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/payment/requests/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/requests/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save Payment Request', '/payment/requests/save', 'MOD_PAY', 'PAY_REQ_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/requests/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/payment/requests/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/payment/requests/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/requests/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/payment/requests/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/requests/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/payment/requests/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/payment/requests/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update Payment Request Status to Not Paid', '/payment/requests/update-status/not-paid', 'MOD_PAY', 'PAY_REQ_UPD_NP', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/requests/update-status/not-paid' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/payment/requests/update-status/not-paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/payment/requests/update-status/not-paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/requests/update-status/not-paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/requests/update-status/not-paid');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update Payment Request Status to Paid', '/payment/requests/update-status/paid', 'MOD_PAY', 'PAY_REQ_UPD_P', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/requests/update-status/paid' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/payment/requests/update-status/paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/payment/requests/update-status/paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/requests/update-status/paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/payment/requests/update-status/paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/payment/requests/update-status/paid');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/requests/update-status/paid');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update Payment Request Status to Settled', '/payment/requests/update-status/settled', 'MOD_PAY', 'PAY_REQ_UPD_S', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/requests/update-status/settled' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/payment/requests/update-status/settled');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/requests/update-status/settled');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update Payment Request Status to Void', '/payment/requests/update-status/void', 'MOD_PAY', 'PAY_REQ_UPD_V', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/requests/update-status/void' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/payment/requests/update-status/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/payment/requests/update-status/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/requests/update-status/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/requests/update-status/void');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View Payment Transactions', '/payment/txns/view', 'MOD_PAY', 'PAY_TXN_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/txns/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/payment/txns/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/txns/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save Payment Transaction', '/payment/txns/save', 'MOD_PAY', 'PAY_TXN_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/txns/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/payment/txns/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/txns/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/payment/txns/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/payment/txns/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/payment/txns/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/txns/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Delete Payment Transaction', '/payment/txns/delete', 'MOD_PAY', 'PAY_TXN_DEL', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/txns/delete' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/payment/txns/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/payment/txns/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/payment/txns/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/txns/delete');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View Payment Request', '/payment/portal/get-payment-request', 'MOD_PAY', 'PAY_REQ_VW_PORTAL', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/portal/get-payment-request' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/payment/portal/get-payment-request');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/payment/portal/get-payment-request');




INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'File Upload', '/file/upload', 'MOD_FILE', 'FILE_UPLOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/file/upload' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/file/upload');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/file/upload');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'File Download', '/file/download', 'MOD_FILE', 'FILE_DOWNLOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/file/download' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/file/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/file/download');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'File Delete', '/file/delete', 'MOD_FILE', 'FILE_DELETE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/file/delete' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Viewer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Finance' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/file/delete');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/file/delete');




INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search and View TA Licence Return records', '/licence-return/ta/view', 'MOD_RETURN', 'LCRTN_TA_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/licence-return/ta/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/licence-return/ta/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/licence-return/ta/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/licence-return/ta/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/licence-return/ta/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Licence Return Submission', '/licence-return/return', 'MOD_RETURN', 'LCRTN_SUBMIT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/licence-return/return' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/licence-return/return');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/licence-return/return');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/licence-return/return');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/licence-return/return');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/licence-return/return');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/licence-return/return');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Licence Return Void', '/licence-return/void', 'MOD_RETURN', 'LCRTN_VOID', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/licence-return/void' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/licence-return/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/licence-return/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/licence-return/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/licence-return/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/licence-return/void');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/licence-return/void');




INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Retrieve Bulletin list', '/bulletin/list', 'MOD_BULLETIN', 'BULLETIN_LIST', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/bulletin/list' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/bulletin/list');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/bulletin/list');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/bulletin/list');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/bulletin/list');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/bulletin/list');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Retrieve Bulletin Detail', '/bulletin/view', 'MOD_BULLETIN', 'BULLETIN_VIEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/bulletin/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/bulletin/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/bulletin/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/bulletin/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Training Provider' AND functions.uri='/bulletin/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/bulletin/view');



INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View TA Report List', '/reports/ta/view', 'MOD_RPT', 'REPORT_VIEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/reports/ta/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/reports/ta/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/reports/ta/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/reports/ta/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/reports/ta/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/reports/ta/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Download TA Report', '/reports/ta/download', 'MOD_RPT', 'REPORT_DWNL', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/reports/ta/download' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/reports/ta/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/reports/ta/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/reports/ta/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Division' AND functions.uri='/reports/ta/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/reports/ta/download');
