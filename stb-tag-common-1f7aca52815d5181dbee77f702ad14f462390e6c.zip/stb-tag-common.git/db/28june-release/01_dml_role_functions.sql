INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View TG Licence Cancellation Applications', '/tg/cancel/view', 'MOD_TG', 'TG_CAN_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/cancel/view' WHERE f.code IS NULL);

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/cancel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/cancel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/tg/cancel/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/cancel/view');

/*/tp/pdc*/
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tp/pdc/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tp/pdc/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tp/pdc/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tp/pdc/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tp/pdc/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tp/pdc/update');

/*/tp/mrc*/
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tp/mrc/view');	
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tp/mrc/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tp/mrc/save');	
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tp/mrc/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tp/mrc/update');	
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tp/mrc/update');

/*/tg/courses/view*/
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/courses/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/courses/view');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG Courses', '/tg/courses/save', 'MOD_TG', 'TG_CSE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/courses/save' WHERE f.code IS NULL);

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/courses/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/courses/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/courses/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG Courses', '/tg/courses/update', 'MOD_TG', 'TG_CSE_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/courses/update' WHERE f.code IS NULL);

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/courses/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/courses/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/tg/courses/update');

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/candidates/save');

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TG Candidate Portal ID', '/tg/candidates/update', 'MOD_TG', 'TG_CDD_UPD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/candidates/update' WHERE f.code IS NULL);

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/candidates/update');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/candidates/update');