UPDATE `statuses` SET `label` = 'Not Yet Competent' WHERE (`code` = 'TG_CANDIDATE_RESULT_INCOMPETENT');

INSERT INTO statuses (isActive, isEditable,ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 3, 'TG_CANDIDATE_RESULT_ABS', 'Absent',null, 'STAT_TG_CANDIDATE_RESULT');


INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 0, 'TG_ITINERARY', '', null, null, null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 1, 'TG_ITINERARY_A', 'A', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 2, 'TG_ITINERARY_B', 'B', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 3, 'TG_ITINERARY_C', 'C', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 4, 'TG_ITINERARY_D', 'D', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 5, 'TG_ITINERARY_E', 'E', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 6, 'TG_ITINERARY_F', 'F', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 7, 'TG_ITINERARY_G', 'G', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 8, 'TG_ITINERARY_H', 'H', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 9, 'TG_ITINERARY_I', 'I', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 10, 'TG_ITINERARY_J', 'J', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 11, 'TG_ITINERARY_K', 'K', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 12, 'TG_ITINERARY_L', 'L', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 13, 'TG_ITINERARY_M', 'M', null, 'TG_ITINERARY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 14, 'TG_ITINERARY_N', 'N', null, 'TG_ITINERARY', null);

update types set label = 'Professional Development Course' where code = 'TP_CSE_P';
update types set label = 'Mandatory Refresher Course' where code = 'TP_CSE_M';

INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 1, 'STAT_CPF_MEDI', 'CPF Medisave Status', null, 'STAT', null);
INSERT INTO statuses (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 1, 'CPF_MEDI_Y', 'Has no outstanding MediSave liabilities',null, 'STAT_CPF_MEDI');
INSERT INTO statuses (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 2, 'CPF_MEDI_N', 'Has outstanding MediSave liabilities',null, 'STAT_CPF_MEDI');
INSERT INTO statuses (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 3, 'CPF_MEDI_I', 'Invalid CPF account',null, 'STAT_CPF_MEDI');
INSERT INTO statuses (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 4, 'CPF_MEDI_E', 'Error',null, 'STAT_CPF_MEDI');
