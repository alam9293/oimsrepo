-- default TP for ad-hoc course

-- TP 
INSERT INTO tg_training_providers (createdBy, createdDate, updatedBy, updatedDate, version, contactNo, contactPerson, email, isMrc, isPdc, legacyId, name, uen, addressId, statusCode, isAto) VALUES ('system', sysdate(), 'system', sysdate(), '0', '', '', '', FALSE, TRUE, NULL, 'Singapore Tourism Board', '', NULL, 'USER_A', TRUE);
UPDATE `tg_training_providers` SET `isAto` = TRUE WHERE (`id` = '36');
UPDATE `tg_training_providers` SET `isAto` = TRUE WHERE (`id` = '58');
UPDATE `tg_training_providers` SET `isAto` = TRUE WHERE (`id` = '70');
UPDATE `tg_training_providers` SET `name` = 'Singapore Chinese Chamber Institute of Business' WHERE (`id` = '36');
