alter table ta_company_updates add column faxNo varchar(255);
alter table ta_licence_creations add column faxNo varchar(255);
alter table travel_agents add column faxNo varchar(255);

alter table stakeholders add column officeNo varchar(255);
alter table stakeholders add column residentialNo varchar(255);
alter table ta_licence_creations add column officeNo varchar(255);
alter table ta_licence_creations add column residentialNo varchar(255);
alter table ta_stakeholder_applications add column officeNo varchar(255);
alter table ta_stakeholder_applications add column residentialNo varchar(255);

-- For email template
alter table email_templates add column emailCountdownBaseDate varchar(255);
alter table email_templates add column emailCountdownUnits integer;
alter table email_templates add column isActive BIT(1) default 0 not null;
alter table email_templates add column attachmentId integer;
alter table email_templates add column emailCountdownPrepositionCode varchar(255);
alter table email_templates add column emailCountdownUnitTypeCode varchar(255);
alter table email_templates add column emailFrequencyCode varchar(255);
alter table email_templates add constraint FKmy4d7jskr5ambbp8x2xb3qh31 foreign key (attachmentId) references files (id);
alter table email_templates add constraint FKm3od2fmj4xdwtka2ax8dbkprq foreign key (emailCountdownPrepositionCode) references types (code);
alter table email_templates add constraint FK1llerbcsa00kfami1qwa8sn3l foreign key (emailCountdownUnitTypeCode) references types (code);
alter table email_templates add constraint FKnu8r11jdqp2cnke6arx4en6rj foreign key (emailFrequencyCode) references types (code);

create table ta_filing_condition_email_logs (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, forMonth integer, forYear integer, sendDate datetime(6), emailLogId integer, emailTemplateCode varchar(255), statusCode varchar(255), taFilingConditionId integer, primary key (id)) engine=InnoDB;
create table ta_licence_renewal_exercise_ta_email_logs (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, forMonth integer, forYear integer, sendDate datetime(6), emailLogId integer, emailTemplateCode varchar(255), statusCode varchar(255), taLicenceRenewalExerciseTaId integer, primary key (id)) engine=InnoDB;
alter table ta_filing_condition_email_logs add constraint FKgo52303dsdak9y82uxplh7uxy foreign key (emailLogId) references email_logs (id);
alter table ta_filing_condition_email_logs add constraint FK64u6mffxr8wkdydwcdc2bscgd foreign key (emailTemplateCode) references email_templates (code);
alter table ta_filing_condition_email_logs add constraint FKbr57iui8cu2x2jft9uv76uvdi foreign key (statusCode) references statuses (code);
alter table ta_filing_condition_email_logs add constraint FK9gsjjk93hohcrksgkr9eogo25 foreign key (taFilingConditionId) references ta_filing_conditions (id);
alter table ta_licence_renewal_exercise_ta_email_logs add constraint FKbk8uv48bp676sxoyb4vpdgcu8 foreign key (emailLogId) references email_logs (id);
alter table ta_licence_renewal_exercise_ta_email_logs add constraint FK4eayv9mn5gixj0c9tdmyejyvy foreign key (emailTemplateCode) references email_templates (code);
alter table ta_licence_renewal_exercise_ta_email_logs add constraint FK70v76h37f24tt4bxucrhukn9s foreign key (statusCode) references statuses (code);
alter table ta_licence_renewal_exercise_ta_email_logs add constraint FKt7s30mh07lq7tvdtlmd4wt8ls foreign key (taLicenceRenewalExerciseTaId) references ta_licence_renewal_exercise_tas (id);

