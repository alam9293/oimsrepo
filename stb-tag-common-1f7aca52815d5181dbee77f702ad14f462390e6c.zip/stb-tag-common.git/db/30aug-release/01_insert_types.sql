INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 0, 'EMAIL_COUNTDOWN_UNIT', '', null, null, null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 1, 'UNIT_DAY', 'Day', null, 'EMAIL_COUNTDOWN_UNIT', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 2, 'UNIT_MONTH', 'Month', null, 'EMAIL_COUNTDOWN_UNIT', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 0, 'EMAIL_COUNTDOWN_PREPOSITION', '', null, null, null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 1, 'PREPOSITION_BEFORE', 'Before', null, 'EMAIL_COUNTDOWN_PREPOSITION', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 2, 'PREPOSITION_AFTER', 'After', null, 'EMAIL_COUNTDOWN_PREPOSITION', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 3, 'PREPOSITION_ON', 'ON', null, 'EMAIL_COUNTDOWN_PREPOSITION', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 0, 'EMAIL_FREQUENCY', '', null, null, null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 1, 'FREQUENCY_ONCE', 'Once', null, 'EMAIL_FREQUENCY', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 2, 'FREQUENCY_MONTHLY', 'Monthly', null, 'EMAIL_FREQUENCY', null);

update email_templates set isActive = true;