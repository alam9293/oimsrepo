DELETE FROM email_templates WHERE code = 'TA_LICENCE_RENEWAL_REMINDER_START';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_LICENCE_RENEWAL_REMINDER_START', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear travel agent,</p>
<p><strong>NOTICE TO RENEW TRAVEL AGENT LICENCE BY ${renewal_exercise_end_date}</strong></p>
<ol>
<li>It is time to renew your TA licence expiring on ${licence_expiry_date}.</li>
<li>To renew your TA licence, please log on to <a href="https://trust.stb.gov.sg" target="_blank" rel="noopener">TRUST</a>&nbsp;with your CorpPass to submit the renewal application. Do note that your licence can only be renewed after all licensing requirements are fulfilled. Please refer to your renewal checklist on your dashboard in TRUST.</li>
<li>For CorpPass login issues, do contact the CorpPass helpdesk at <a href="mailto:support@corppass.gov.sg">support@corppass.gov.sg</a> or call 6643 0577 for assistance.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
<li>Please contact us at <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> if you have any further enquiries.</li>
<li>You may disregard this email if you have completed your renewal application.</li>
</ol>
<p style="text-align: left;">&nbsp;</p>
<p>Thank you.</p>
<p>Travel Agent Licensing &amp; Regulatory Review Department</p>
<p>Singapore Tourism Board</p>
<p>*Please do not reply to this computer generated email.*</p>', 'TA''s Reminder Email 1 for TA Licence Renewal', 'FIRST RENEWAL REMINDER - NOTICE TO RENEW TRAVEL AGENT LICENCE BY ${renewal_exercise_end_date}', 'Renewal Start Date', '0', false, 'PREPOSITION_ON', null, 'FREQUENCY_ONCE');


DELETE FROM email_templates WHERE code = 'TA_LICENCE_RENEWAL_REMINDER_MONTHLY';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_LICENCE_RENEWAL_REMINDER_MONTHLY', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear travel agent,</p>
<p>&nbsp;</p>
<p><strong>NOTICE TO RENEW TRAVEL AGENT LICENCE BY ${renewal_exercise_end_date}</strong></p>
<ol>
<li>Our records show that you have not renewed your travel agent licence expiring on ${licence_expiry_date}. You are required to renew your licence before the deadline of ${renewal_exercise_end_date} to ensure that your licence is renewed in time for your company to carry on the business of a travel agent.</li>
<li>To renew your TA licence, please log on to <a title="TRUST" href="https://trust.stb.gov.sg">TRUST&nbsp;</a>with your CorpPass to submit the renewal application. Do note that your licence can only be renewed after all licensing requirements are fulfilled. Please refer to your renewal checklist on your dashboard in TRUST.</li>
<li>For CorpPass login issues, do contact the CorpPass helpdesk at <a href="mailto:support@corppass.gov.sg">support@corppass.gov.sg</a> or call 6643 0577 for assistance.</li>
<li>Please contact us at <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> if you have any further enquiries.</li>
<li>You may disregard this email if you have completed your renewal application.</li>
</ol>
<p>&nbsp;</p>
<p>Thank you.</p>
<p>&nbsp;</p>
<p>Travel Agent Licensing &amp; Regulatory Review Department</p>
<p>Singapore Tourism Board</p>
<p>&nbsp;</p>
<p>* Please do not reply to this computer generated email.*</p>', 'TA\'\'s Reminder Email for TA Licence Renewal', 'RENEWAL REMINDER - NOTICE TO RENEW TRAVEL AGENT LICENCE BY ${renewal_exercise_end_date}', 'Renewal Start Date', '1', true, 'PREPOSITION_AFTER', 'UNIT_MONTH', 'FREQUENCY_MONTHLY');


DELETE FROM email_templates WHERE code = 'TA_LICENCE_RENEWAL_REMINDER_DEADLINE';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_LICENCE_RENEWAL_REMINDER_DEADLINE', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear travel agent,</p>
<p>&nbsp;</p>
<p><strong>YOUR LICENCE IS NOT RENEWED</strong></p>
<p>&nbsp;</p>
<p>Our records show that you have missed the deadline for renewing your travel agent licence expiring on ${licence_expiry_date}.&nbsp;</p>
<p>If you still intend to renew your licence, please submit a late renewal request, specifying the reason(s) for late renewal, via email to <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> by ${renewal_exercise_late_date}. Please be reminded that all licensing requirements must be fulfilled for the request to be considered.</p>
<p>&nbsp;</p>
<p>You may refer to our renewal notification letter dated ${renewal_exercise_start_date} for a step-by-step guide on the renewal process.&nbsp;</p>
<p>&nbsp;</p>
<p>Please note that you may not be able to renew your licence if you do not submit a request by the deadline specified above, and you will not be able to continue with your travel agent business from ${licence_expiry_date_after}. If you do not intend to renew your licence, we appreciate if you could also inform us via email.</p>
<p>&nbsp;</p>
<p>Kindly contact us at 6736-6622 or email <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> if you have any enquiries.</p>
<p>&nbsp;</p>
<p>Please disregard this email if you have already completed your licence renewal application.</p>
<p>&nbsp;</p>
<p>Thank you.</p>
<p>&nbsp;</p>
<p>Travel Agent Licensing &amp; Regulatory Review Department</p>
<p>Singapore Tourism Board</p>
<p>&nbsp;</p>
<p>* Please do not reply to this computer generated email. *&nbsp;</p>', 'TA''s Reminder Email 4 for TA Licence Renewal', 'FINAL REMINDER – RENEWAL  ${renewal_exercise_year}', 'Renewal Start Date', '3', true, 'PREPOSITION_AFTER', null, 'FREQUENCY_ONCE');




DELETE FROM email_templates WHERE code = 'TA_LICENCE_EXPIRY_NOTICE';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_LICENCE_EXPIRY_NOTICE', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear travel agent,</p>
<p><strong>YOU DO NOT HAVE A LICENCE TO OPERATE YOUR TRAVEL AGENCY FROM ${licence_expiry_date_after}</strong></p>
<p>Your travel agent licence has expired on ${licence_expiry_date_after}.</p>
<p>Please be informed that you may be liable for prosecution should you continue the business of a travel agent without a valid licence from ${licence_expiry_date_after}. Please apply for a new licence if you intend to conduct any travel agent business.</p>
<p>Kindly contact us at 6736-6622 or email <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> if you have any queries.</p>
<p>Thank you.</p>
<p>Travel Agent Licensing &amp; Regulatory Review Department</p>
<p>Singapore Tourism Board</p>
<p>* Please do not reply to this computer generated email. *</p>', 'TA''s notice of licence expiry', 'NOTICE OF LICENCE EXPIRY', 'Licence Expiry Date', '0', true, 'PREPOSITION_ON', null, 'FREQUENCY_ONCE');