INSERT INTO jobs (createdBy, createdDate, updatedBy, updatedDate, version, isActive, cronExpression, scheduleDescription, className, description) 
VALUES ('SYSTEM', NOW(), 'SYSTEM', NOW(), 0, 1, '0 0 8 * * ?', 'Everyday 08:00', 'gov.stb.tag.job.EmailNotificationJob', 'For email reminders');

INSERT INTO jobs (createdBy, createdDate, updatedBy, updatedDate, version, isActive, cronExpression, scheduleDescription, className, description) 
VALUES ('SYSTEM', NOW(), 'SYSTEM', NOW(), 0, 1, '0 0 6 * * ?', 'Everyday 06:00', 'gov.stb.tag.job.TaFilingEmailNotificationJob', 'Email reminder for TA filing submission');