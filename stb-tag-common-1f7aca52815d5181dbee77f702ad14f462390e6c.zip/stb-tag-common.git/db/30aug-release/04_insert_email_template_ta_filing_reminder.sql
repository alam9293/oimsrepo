DELETE FROM email_templates WHERE code = 'TA_FILING_REMINDER_1';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_FILING_REMINDER_1', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear Sir/Madam</p>
<p>&nbsp;</p>
<p><u>Submission of Annual Business Profile Returns and Audited Statement of Accounts - ${company_name}</u></p>
<p>&nbsp;</p>
<p>We note that your last financial year has ended.</p>
<p>&nbsp;</p>
<p>In accordance to Regulation 14 Subsection (1) (a) and (b) of the Travel Agents Regulations 2017, every licensee shall submit the following to the Board, within 6 months after the close of the financial year:</p>
<p>&nbsp;</p>
<p><ol><li>Annual Business Profile Returns</li><li>Audited Statement of Accounts</li></ol></p>
<p>&nbsp;</p>
<p>You may wish to note that administrative action such as financial penalty, suspension or revocation of travel agent licence may be imposed for late submissions. </p>
<p>&nbsp;</p>
<p>Please <a title="TRUST" href="https://trust.stb.gov.sg">login here</a> to submit your Annual Business Profile Returns and Audited Statement of Accounts.</p>
<p>&nbsp;</p>
<p>Thank you.</p>
<p>&nbsp;</p>
<p>Yours faithfully</p>
<p>${officer_name}</p>
<p>Travel Agent Licensing and Regulatory Review</p>
<p>Singapore Tourism Board</p>
<p>&nbsp;</p>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> for any queries.***</p>', 'TA FILING REMINDER 1', 'Submission of Annual Business Profile Returns and Audited Statement of Accounts - ${company_name}', 'Financial Year End Date', '1', true, 'PREPOSITION_AFTER', 'UNIT_DAY', 'FREQUENCY_ONCE');



DELETE FROM email_templates WHERE code = 'TA_FILING_REMINDER_2';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_FILING_REMINDER_2', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear Sir/Madam</p>
<p>&nbsp;</p>
<p><u>Submission of ${outstanding_submission} - ${company_name}</u></p>
<p>&nbsp;</p>
<p>We note that your last financial year has ended.</p>
<p>&nbsp;</p>
<p>In accordance to Regulation 14 Subsection (1) (a) and (b) of the Travel Agents Regulations 2017, every licensee shall submit the following to the Board, within 6 months after the close of the financial year:</p>
<p>&nbsp;</p>
<p><ol>${outstanding_submission_list}</ol></p>
<p>&nbsp;</p>
<p>You may wish to note that administrative action such as financial penalty, suspension or revocation of travel agent licence may be imposed for late submissions. </p>
<p>&nbsp;</p>
<p>Please <a title="TRUST" href="https://trust.stb.gov.sg">login here</a> to submit your ${outstanding_submission}.</p>
<p>&nbsp;</p>
<p>Thank you.</p>
<p>&nbsp;</p>
<p>Yours faithfully</p>
<p>${officer_name}</p>
<p>Travel Agent Licensing and Regulatory Review</p>
<p>Singapore Tourism Board</p>
<p>&nbsp;</p>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> for any queries.***</p>', 'TA FILING REMINDER 2', 'Submission of ${outstanding_submission} - ${company_name}', 'Financial Year End Date', '3', true, 'PREPOSITION_AFTER', 'UNIT_MONTH', 'FREQUENCY_ONCE');



DELETE FROM email_templates WHERE code = 'TA_FILING_REMINDER_3';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_FILING_REMINDER_3', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear Sir/Madam</p>
<p>&nbsp;</p>
<p><u><strong>Final Reminder</strong> - Submission of ${outstanding_submission} - ${company_name}</u></p>
<p>&nbsp;</p>
<p>We note that you have not submitted your ${outstanding_submission_with_date}.</p>
<p>&nbsp;</p>
<p>In accordance to Regulation 14 Subsection (1) (a) and (b) of the Travel Agents Regulations 2017, every licensee shall submit to the Board the Annual Business Profile Returns and a copy of the Audited Statement of Accounts within 6 months after the close of the financial year.</p>
<p>&nbsp;</p>
<p>Please ensure that the above mentioned submission is made before the due date. Administrative action such as financial penalty, suspension or revocation of travel agent licence may be imposed for late submissions.</p>
<p>&nbsp;</p>
<p>Please <a title="TRUST" href="https://trust.stb.gov.sg">login here</a> to submit your ${outstanding_submission}.</p>
<p>&nbsp;</p>
<p>Thank you.</p>
<p>&nbsp;</p>
<p>Yours faithfully</p>
<p>${officer_name}</p>
<p>Travel Agent Licensing and Regulatory Review</p>
<p>Singapore Tourism Board</p>
<p>&nbsp;</p>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> for any queries.***</p>', 'TA FILING REMINDER 3', '[Final Reminder] Submission of ${outstanding_submission} - ${company_name}', 'Financial Year End Date', '5', true, 'PREPOSITION_AFTER', 'UNIT_MONTH', 'FREQUENCY_ONCE');



DELETE FROM email_templates WHERE code = 'TA_FILING_REMINDER_4';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_FILING_REMINDER_4', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear Sir/Madam</p>
<p>&nbsp;</p>
<p><u><strong>For Immediate Attention</strong> - Submission of ${outstanding_submission} Due Today - ${company_name}</u></p>
<p>&nbsp;</p>
<p>We note that you have not submitted your ${outstanding_submission_with_date}.</p>
<p>&nbsp;</p>
<p>In accordance to Regulation 14 Subsection (1) (a) and (b) of the Travel Agents Regulations 2017, every licensee shall submit to the Board the Annual Business Profile Returns and a copy of the Audited Statement of Accounts within 6 months after the close of the financial year.</p>
<p>&nbsp;</p>
<p>Please ensure that the above mentioned submission is made before the due date. Administrative action such as financial penalty, suspension or revocation of travel agent licence may be imposed for late submissions.</p>
<p>&nbsp;</p>
<p>Please <a title="TRUST" href="https://trust.stb.gov.sg">login here</a> to submit your ${outstanding_submission}.</p>
<p>&nbsp;</p>
<p>Thank you.</p>
<p>&nbsp;</p>
<p>Yours faithfully</p>
<p>${officer_name}</p>
<p>Travel Agent Licensing and Regulatory Review</p>
<p>Singapore Tourism Board</p>
<p>&nbsp;</p>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> for any queries.***</p>', 'TA FILING REMINDER 4', '[For Immediate Attention] Submission of ${outstanding_submission} Due Today - ${company_name}', 'Stipulated/Extended Submission Due Date', '0', true, 'PREPOSITION_ON', 'UNIT_DAY', 'FREQUENCY_ONCE');




DELETE FROM email_templates WHERE code = 'TA_FILING_REMINDER_5';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TA_FILING_REMINDER_5', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear Sir/Madam</p>
<p>&nbsp;</p>
<p><u>Failure to Comply with Licensing Requirements - ${company_name}</u></p>
<p>&nbsp;</p>
<p>You have failed to submit your ${outstanding_submission_with_date}, and have therefore contravened the Travel Agents Regulations 2017.</p>
<p>&nbsp;</p>
<p>Please ensure that the above mentioned submission is made immediately. The administrative action imposed for breaches of the Travel Agents Regulations 2017 may increase with further delay.</p>
<p>&nbsp;</p>
<p>Please <a title="TRUST" href="https://trust.stb.gov.sg">login here</a> to submit your ${outstanding_submission}.</p>
<p>&nbsp;</p>
<p>Thank you.</p>
<p>&nbsp;</p>
<p>Yours faithfully</p>
<p>${officer_name}</p>
<p>Travel Agent Licensing and Regulatory Review</p>
<p>Singapore Tourism Board</p>
<p>&nbsp;</p>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:stb_ta@stb.gov.sg">stb_ta@stb.gov.sg</a> for any queries.***</p>', 'TA FILING REMINDER 5', 'Failure to Comply with Licensing Requirements - ${company_name}', 'Stipulated/Extended Submission Due Date', '1', true, 'PREPOSITION_AFTER', 'UNIT_DAY', 'FREQUENCY_MONTHLY');