-- ALERTS --

INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_TA', 'TA_APP_CREATION', '/ta-licence-view/1', 'ABC Travels has not submitted since 7 days after Returned for action.');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_TA', 'TA_APP_TIER_SWITCH', '#', 'JapanGo Pte Ltd has paid Licence fee of $400. You may proceed to print the licence.');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_TA', 'TA_APP_BRANCH', '#', 'Sisters Travel Pte Ltd has not paid Licence Fee of $400 since 7 days after approval.');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_TG', 'TA_APP_CREATION', '#', 'Chan Brothers Travel Pte Ltd has paid Licence Fee of $400. You may proceed to print the licence.');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_TG', 'TA_APP_CREATION', '#', 'Alert Message 5');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_TG', 'TA_APP_CREATION', '#', 'Alert Message 6');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_SYS', NULL, '#', 'Some message from a system trigger job that does not have a particular Reference ID.');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_SYS', NULL, '#', 'Alert Message 8');
INSERT INTO alerts (version, createdDate, createdBy, moduleCode, typeCode, url, message) VALUES (0, NOW(), 'TEST', 'MOD_SYS', NULL, '#', 'Alert Message 9');
