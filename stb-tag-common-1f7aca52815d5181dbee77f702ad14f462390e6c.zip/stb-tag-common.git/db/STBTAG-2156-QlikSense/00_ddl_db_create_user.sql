CREATE USER 'tag_qlik_user'@'%' IDENTIFIED BY '+zB_Z63g';

GRANT SELECT ON audit_logs TO 'tag_qlik_user'@'%';
GRANT SELECT ON email_logs TO 'tag_qlik_user'@'%';
GRANT SELECT ON types TO 'tag_qlik_user'@'%';
GRANT SELECT ON statuses TO 'tag_qlik_user'@'%';
GRANT SELECT ON email_templates TO 'tag_qlik_user'@'%';