alter table statuses add column footNote varchar(5000);
alter table types add column footNote varchar(5000);

INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 0, 'TA_SALES_CHANNEL', 'TA Sales Channel', null, null, null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version, footNote) VALUES (1, 1, 1, 'TA_SALES_CHANNEL_1', 'Retail/Face-to-face', null, 'TA_SALES_CHANNEL', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0, NULL);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version, footNote) VALUES (1, 1, 2, 'TA_SALES_CHANNEL_2', 'Online', null, 'TA_SALES_CHANNEL', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0, NULL);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version, footNote) VALUES (1, 1, 3, 'TA_SALES_CHANNEL_3', 'Through resellers/distributors (e.g. OTAs, overseas travel agents)', null, 'TA_SALES_CHANNEL', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0, NULL);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version, footNote) VALUES (1, 1, 4, 'TA_SALES_CHANNEL_4', 'Outsourced (e.g. outsourced sales agency)', null, 'TA_SALES_CHANNEL', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0, 'Outsourcing of sales function to a third party e.g. outsourced sales agency that specialise in conducting sales for companies');
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version, footNote) VALUES (1, 1, 5, 'TA_SALES_CHANNEL_5', 'Wholesale', null, 'TA_SALES_CHANNEL', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0, NULL);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version, footNote) VALUES (1, 1, 99, 'TA_SALES_CHANNEL_OTHERS', 'Others', null, 'TA_SALES_CHANNEL', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0, NULL);



create table ta_licence_creation$sales_channels (taLicenceCreationId integer not null, salesChannelCode varchar(255) not null, primary key (taLicenceCreationId, salesChannelCode)) engine=InnoDB;
alter table ta_licence_creations add column businessIdea text;
alter table ta_licence_creations add column competitiveEdge text;
alter table ta_licence_creations add column consumerFacingBrand varchar(255);
alter table ta_licence_creations add column costProj1 decimal(19,2);
alter table ta_licence_creations add column costProj2 decimal(19,2);
alter table ta_licence_creations add column detailsRegardingPrevLic text;
alter table ta_licence_creations add column estTimeToProfit varchar(255);
alter table ta_licence_creations add column financialStrategy text;
alter table ta_licence_creations add column hasOtherBizActivities BIT(1) default 0 not null;
alter table ta_licence_creations add column hasTaLicBefore BIT(1) default 0 not null;
alter table ta_licence_creations add column mktgCommsPlan text;
alter table ta_licence_creations add column otherSalesChannel varchar(255);
alter table ta_licence_creations add column others text;
alter table ta_licence_creations add column partnerServideProviders text;
alter table ta_licence_creations add column percentFocusOnTaBiz decimal(19,2);
alter table ta_licence_creations add column profitLossProj1 decimal(19,2);
alter table ta_licence_creations add column profitLossProj2 decimal(19,2);
alter table ta_licence_creations add column relationsWithOtherTa text;
alter table ta_licence_creations add column revenueProj1 decimal(19,2);
alter table ta_licence_creations add column revenueProj2 decimal(19,2);
alter table ta_licence_creation$sales_channels add constraint FKtdckudroxbin82ptjbbf0otkb foreign key (salesChannelCode) references types (code);
alter table ta_licence_creation$sales_channels add constraint FKdl5ii80npdmj5v4dg557198m2 foreign key (taLicenceCreationId) references ta_licence_creations (id);