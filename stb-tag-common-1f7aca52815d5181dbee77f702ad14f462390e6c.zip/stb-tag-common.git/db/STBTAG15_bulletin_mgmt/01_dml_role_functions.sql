INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View Bulletin List', '/bulletin/list-all', 'MOD_BULLETIN', 'BULLETIN_LIST_ALL', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/bulletin/list-all' WHERE f.code IS NULL);													INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/bulletin/list-all');
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Create/Edit Bulletin', '/bulletin/save', 'MOD_BULLETIN', 'BULLETIN_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/bulletin/save' WHERE f.code IS NULL);													INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/bulletin/save');	

INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 4, 'BULLETIN_TA_TG', 'Travel Agent and Tourist Guide', null, 'BULLETIN', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 5, 'BULLETIN_GENERAL_TA', 'General and Travel Agent', null, 'BULLETIN', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 6, 'BULLETIN_GENERAL_TG', 'General and Tourist Guide', null, 'BULLETIN', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 7, 'BULLETIN_GENERAL_TA_TG', 'General, Travel Agent and Tourist Guide', null, 'BULLETIN', null);


insert into role$functions values ('SYSADM','FILE_UPLOAD');
insert into role$functions values ('SYSADM','FILE_DELETE');
insert into role$functions (roleCode, functionsCode) values ('SYSADM', 'BULLETIN_VIEW');

