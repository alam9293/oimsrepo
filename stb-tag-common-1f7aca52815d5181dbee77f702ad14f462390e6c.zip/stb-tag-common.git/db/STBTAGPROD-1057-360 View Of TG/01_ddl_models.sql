CREATE TABLE `tg_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `companyName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDeleted` bit(1) NOT NULL DEFAULT b'0',
  `personName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `typeOther` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `touristGuideId` int(11) DEFAULT NULL,
  `typeCode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5rg1xulk36db7vx5ifdifvxnp` (`touristGuideId`),
  KEY `FKm014dhukhpiq2ttnusmm8r6fu` (`typeCode`),
  CONSTRAINT `FK5rg1xulk36db7vx5ifdifvxnp` FOREIGN KEY (`touristGuideId`) REFERENCES `tourist_guides` (`id`),
  CONSTRAINT `FKm014dhukhpiq2ttnusmm8r6fu` FOREIGN KEY (`typeCode`) REFERENCES `types` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `tg_info$files` (
  `tgInfoId` int(11) NOT NULL,
  `filesId` int(11) NOT NULL,
  PRIMARY KEY (`tgInfoId`,`filesId`),
  KEY `FKar0pp5aj21sm511c3aqtug9x6` (`filesId`),
  CONSTRAINT `FKar0pp5aj21sm511c3aqtug9x6` FOREIGN KEY (`filesId`) REFERENCES `files` (`id`),
  CONSTRAINT `FKjkdlm5akqd2rej0gjqh846dme` FOREIGN KEY (`tgInfoId`) REFERENCES `tg_infos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

