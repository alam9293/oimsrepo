INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View 360 view of TG', '/tg/info/view', 'MOD_TG', 'TG_INFO_VIEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/info/view' WHERE f.code IS NULL);							
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save or Update 360 view of TG', '/tg/info/save', 'MOD_TG', 'TG_INFO_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/info/save' WHERE f.code IS NULL);							
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Delete 360 view of TG', '/tg/info/delete', 'MOD_TG', 'TG_INFO_DELETE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/info/delete' WHERE f.code IS NULL);							

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/info/view');	
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/info/view');							
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/info/view');					

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/info/save');	
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/info/save');							
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/info/save');		

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/info/delete');	
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/info/delete');							
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/info/delete');	