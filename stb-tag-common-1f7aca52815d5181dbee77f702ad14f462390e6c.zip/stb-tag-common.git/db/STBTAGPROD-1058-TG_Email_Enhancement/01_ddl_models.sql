update email_templates set name='TG LICENCE EXPIRY REMINDER 2' where code='TG_LIC_EXPIRY_REMINDER_3';
update email_templates set isActive=0 where code='TG_LIC_EXPIRY_REMINDER_2';

INSERT INTO jobs (createdBy, createdDate, updatedBy, updatedDate, version, isActive, cronExpression, scheduleDescription, className, description) 
VALUES ('SYSTEM', NOW(), 'SYSTEM', NOW(), 0, 1, '0 0 6 * * ?', 'Everyday 06:00', 'gov.stb.tag.job.TgLicenceExpiredNotificationJob', 'To remind TG to return the expired tourist guide licence');

DELETE FROM email_templates WHERE code = 'TG_LIC_EXPIRED_NOTIFICATION';

INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TG_LIC_EXPIRED_NOTIFICATION', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear ${tg_salutation} ${tg_name},
<p><b>RETURN OF EXPIRED TOURIST GUIDE LICENCE (${tg_lic_expiry_date})</b>
<p>1.We refer to our email reminder dated ${current_date} to renew your tourist guide licence which expired on ${tg_lic_expiry_date}.
<p><b>2.Please note that you are not allowed to provide any guiding services with effect from ${effective_date} as you are not in possession of a valid tourist guide licence. </b>
<p>3.It is an offence to provide guiding services without a valid tourist guide licence as stipulated under Section 19B of the Singapore Tourism Board (Amendment) Act 2014:

<p>&nbsp;&nbsp;&nbsp;&nbsp;<b>Licence required to act as tourist guide, etc</b><br/>
<em>
&nbsp;&nbsp;&nbsp;&nbsp;19B.—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;(1) Subject to subsection (2), no individual shall —<br/>
&nbsp;&nbsp;&nbsp;&nbsp;(a) act as a tourist guide; or<br/>
&nbsp;&nbsp;&nbsp;&nbsp;(b) offer to act as a tourist guide, or advertise in any way that he is or is willing to act as a tourist guide, unless he holds a valid tourist guide licence.
<br /><br/>
&nbsp;&nbsp;&nbsp;&nbsp;(3)  Any person who contravenes subsection (1) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $5,000 and, in the case of a second or subsequent offence, to a fine not exceeding $10,000.
</em></p>
<p><b>4.<u>You are required to return your tourist guide badge to the Board by ${return_badge_date}</u></b> either by registered mail or in person at our Reception Counter, Level 1 Tourism Court. It is an offence to retain your expired licence as stipulated in Section 19(F) 3 of the Singapore Tourism Board (Amendment) Act 2014:
<p><em>
&nbsp;&nbsp;&nbsp;&nbsp;(3)  A person issued with a tourist guide badge under this section shall surrender his badge to the Board immediately upon —<br/>
&nbsp;&nbsp;&nbsp;&nbsp;(a) being required to do so for the purpose of enabling the Board to make such alteration to the badge as the Board considers appropriate;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;(b) the expiry, cancellation, revocation or suspension of his tourist guide licence in respect of which the badge was issued; or<br/>
&nbsp;&nbsp;&nbsp;&nbsp;(c) ceasing to be employed as, or engage in the business or provision of services of, a tourist guide, notwithstanding that he holds a valid tourist guide licence.<br/>

<br/>
&nbsp;&nbsp;&nbsp;&nbsp;(4)  Any person who fails to comply with subsection (3) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $5,000 and, in the case of a 
continuing offence, to a further fine not exceeding $100 for every day or part thereof during which the offence continues after conviction.
</em></p>

<p>5.If you have any queries, please email to  ${tg_support_email}
<p>&nbsp;
<p>Best regards,
<p>Tourist Guide Licensing Department
<p>Singapore Tourism Board</p>', 'TG Licence Expired Notification', 'RETURN OF EXPIRED TOURIST GUIDE LICENCE (${tg_lic_expiry_date})', 'TG Licence Expiry Date', '0', true, 'PREPOSITION_BEFORE', 'UNIT_MONTH', 'FREQUENCY_ONCE');

DELETE FROM email_templates WHERE code = 'ATG_PRACTICAL_ASSESSMENT_FEE';

INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('ATG_PRACTICAL_ASSESSMENT_FEE', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear ${tg_salutation} ${tg_name},
<p>&nbsp;
<p>Please click <a href="${public_portal_url}">here</a> to make payment for the Area Tourist Guide Practical Assessment Fee. Please quote Bill Reference Number ${bill_ref_no} when prompted.
<br>
</br>
<p>STB may request for additional information/clarifications if required. For clarification, please contact ${tg_support_email}
<p>&nbsp;
<p>Thank you.
<p>&nbsp;
<p>Best regards,
<p>Tourist Guide Licensing Department
<p>Singapore Tourism Board</p>', 'ATG Practical Assessment Fee Notification', 'Area Tourist Guide Practical Assessment Fee', null, '0', true, 'PREPOSITION_BEFORE', 'UNIT_MONTH', 'FREQUENCY_ONCE');


DELETE FROM email_templates WHERE code = 'TG_LICENCE_SWITCH_TIER_FEE';

INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TG_LICENCE_SWITCH_TIER_FEE', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear ${tg_salutation} ${tg_name},
<p>&nbsp;
<p>Application for an Area Tourist Guide licence (${specialisationArea}) (ref no: ${app_ref}) has been approved.
<p>Please click <a href="${app_link}">here</a> to make payment for the issuance of a new TG licence, incorporating the area of specialisation. We will contact you when your licence is ready for collection. 
</br>
<p>STB may request for additional information/clarifications if required. For clarification, please contact ${tg_support_email}
<p>&nbsp;
<p>Thank you.
<p>&nbsp;
<p>Best regards,
<p>Tourist Guide Licensing Department
<p>Singapore Tourism Board</p>', 'TG Licence Switch Tier Fee Notification', 'Application for an Area Tourist Guide licence (${specialisationArea}) (ref no: ${app_ref}) has been approved. ', null, '0', true, 'PREPOSITION_BEFORE', 'UNIT_MONTH', 'FREQUENCY_ONCE');


update email_templates set subject ='(Final Reminder) TG Licence Renewal, ${tg_lic_expiry_date}',body ='<p>Dear ${tg_salutation} ${tg_name},
 <p>&nbsp;
 <p>Our records show that you have not submit your tourist guide licence renewal application. Hence, your new licence will not be ready by ${tg_lic_expiry_date}.
 <p>Please note that you are not allowed to provide any guiding services with effect from ${effective_date} as you are not in possession of a valid tourist guide licence. You will be deemed to be guiding without a valid licence and the Board will not hesitate to initiate action against you.
 <p>For any clarification, please email ${tg_support_email} (in subject header, state "TG Licence Renewal ${tg_lic_expiry_date}", your name and TG licence number).  Thank you and have a great day!
 <p>&nbsp;
 <p>Best regards,
 <p>Tourist Guide Licensing Department
 <p>Singapore Tourism Board
 <p><center><b><span style="font-size:25px;">TOURIST GUIDE REGULATIONS</span></b></center>
 <p><ol><li>It is an offence to provide guiding services without a valid tourist guide licence as stipulated under Section 19B of the Singapore Tourism Board (Amendment) Act 2014:</li>
 <p><b>Licence required to act as tourist guide, etc.</b>
 <i><p>19B.-
 <p>(1)  Subject to subsection (2), no individual shall -
 <p>(a) act as a tourist guide; or
 <p>(b) offer to act as a tourist guide, or advertise in any way that he is or is willing to act as a tourist guide, unless he holds a valid tourist guide licence.
 <p>(3)  Any person who contravenes subsection (1) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $5,000 and, in the case of a second or subsequent offence, to a fine not exceeding $10,000.</i>
 <p>&nbsp;
 <li>It is an offence to retain your expired licence to the Board as stipulated in Section 19(F) 3 of the Singapore Tourism Board (Amendment) Act 2014:</li>
 <i><p> (3)  A person issued with a tourist guide badge under this section shall surrender his badge to the Board immediately upon -
 <p> (a) being required to do so for the purpose of enabling the Board to make such alteration to the badge as the Board considers appropriate;
 <p> (b) the expiry, cancellation, revocation or suspension of his tourist guide licence in respect of which the badge was issued; or
 <p> (c) ceasing to be employed as, or engage in the business or provision of services of, a tourist guide, notwithstanding that he holds a valid tourist guide licence.
 <p> (4)  Any person who fails to comply with subsection (3) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $5,000 and, in the case of a continuing offence, to a further fine not exceeding $100 for every day or part thereof during which the offence continues after conviction.</i></ol>
 <p>&nbsp;' where code='TG_LIC_EXPIRY_REMINDER_3';

 
 update email_templates set subject ='(1st Reminder) TG Licence Renewal, ${tg_lic_expiry_date}' where code='TG_LIC_EXPIRY_REMINDER_1';
 
 Update types set label='TG Guiding Category Amendment Fee' where code='PAYREQ_TG_SWITCH_TIER';
