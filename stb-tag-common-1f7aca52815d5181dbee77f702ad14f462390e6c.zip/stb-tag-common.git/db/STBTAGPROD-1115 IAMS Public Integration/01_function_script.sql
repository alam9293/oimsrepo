update functions set uri='/users/retrieve-current-login-iamsIdToken-and-logout' where code='USR_LOGOUT';

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) values
('SYSTEM', now(), 'SYSTEM', now(), 'Retrieve current login SP Token IP from Intranet', '/users/retrieve-current-login-spIdToken', 'MOD_USR', 'USR_CUR_LOGIN_SPTOKENID', 0);

INSERT INTO role$functions (roleCode, functionsCode) values ('TA_CDD','USR_CUR_LOGIN_SPTOKENID');
INSERT INTO role$functions (roleCode, functionsCode) values ('TA_PUB','USR_CUR_LOGIN_SPTOKENID');
INSERT INTO role$functions (roleCode, functionsCode) values ('TG_CDD','USR_CUR_LOGIN_SPTOKENID');
INSERT INTO role$functions (roleCode, functionsCode) values ('TG_PUB','USR_CUR_LOGIN_SPTOKENID');
INSERT INTO role$functions (roleCode, functionsCode) values ('TP_PUB','USR_CUR_LOGIN_SPTOKENID');