update email_templates set body='<p>Dear ${tg_name},
 <p><br>
 <p>Your login details for TRUST PORTAL ID is as below:<p>
 <p>Login ID: ${tg_nric}<p>
 <p><br>
 <p>Please click <a href="${app_link}">here</a> to change your password before login to TRUST.</p>
 <p><br>
 <p>Regards,
 <br>Singapore Tourism Board (STB) administrator'where code='TG_PORTAL_ID_ENABLED';