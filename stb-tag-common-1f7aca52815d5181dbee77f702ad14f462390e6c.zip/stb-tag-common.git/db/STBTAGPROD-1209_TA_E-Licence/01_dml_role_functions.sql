-- /ta/elicence-request/view
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Search & View TA ELicence Request Applications', '/ta/elicence-request/view', 'MOD_TA', 'TA_LR_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/view' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Head of Division' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Department' AND functions.uri='/ta/elicence-request/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/elicence-request/view');

-- /ta/elicence-request/approve
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Approve TA ELicence Request Applications', '/ta/elicence-request/approve', 'MOD_TA', 'TA_LR_APV', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/approve' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/approve');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/approve');

-- /ta/elicence-request/reject
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Reject TA ELicence Request Applications', '/ta/elicence-request/reject', 'MOD_TA', 'TA_LR_REJECT', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/reject' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/reject');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/reject');

-- /ta/elicence-request/notes/save
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Add Note to TA ELicence Request Applications', '/ta/elicence-request/notes/save', 'MOD_TA', 'TA_LR_NOTE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/notes/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/notes/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/notes/save');

-- /ta/elicence-request/new
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load New TA ELicence Request', '/ta/elicence-request/new', 'MOD_TA', 'TA_LR_NEW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/new' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/elicence-request/new');

-- /ta/elicence-request/save
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA ELicence Request', '/ta/elicence-request/save', 'MOD_TA', 'TA_LR_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/elicence-request/save');

-- /ta/elicence-request/load
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA ELicence Request Application', '/ta/elicence-request/load', 'MOD_TA', 'TA_LR_LOAD', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/load' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/elicence-request/load');

-- /ta/elicence-request/getData
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Load TA E-Licence Data', '/ta/elicence-request/getData', 'MOD_TA', 'TA_ELIC_GET', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/getData' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/elicence-request/getData');

-- /ta/elicence-request/updateFlag
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Update TA ELicence Request flag', '/ta/elicence-request/updateFlag', 'MOD_TA', 'TA_LR_FLAG_UPDATE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/updateFlag' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/ta/elicence-request/updateFlag');

-- /ta/elicence-request/route
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Route TA ELicence Request Application', '/ta/elicence-request/route', 'MOD_TA', 'TA_LR_ROUTE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/route' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/route');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/route');

-- /qr-code/generate-ta-elicence-qr-code
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Generate QR for TA ELicence', '/qr-code/generate-ta-elicence-qr-code', 'MOD_TA', 'TA_ELIC_QR', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/qr-code/generate-ta-elicence-qr-code' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Head of Division' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Department' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/qr-code/generate-ta-elicence-qr-code');

-- /ta/elicence-request/elicence/save
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TA E-licence', '/ta/elicence-request/elicence/save', 'MOD_TA', 'TA_ELIC_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/elicence/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/elicence/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/elicence/save');

-- /ta/elicence-request/download
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'download TA E-Licence Files', '/ta/elicence-request/download', 'MOD_TA', 'TA_LR_DOWNLOAD_FILES', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/download' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Head of Division' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Department' AND functions.uri='/ta/elicence-request/download');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/elicence-request/download');

-- /ta/elicence-request/getTaELicenceDetails
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'get TA E-Licence Details', '/ta/elicence-request/getTaELicenceDetails', 'MOD_TA', 'TA_ELIC_DETAILS', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/elicence-request/getTaELicenceDetails' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Processing Officer' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Compliance Officer' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='C&E Investigation Officer' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Head of Division' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Approving Officer' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA C&E Enforcement Officer' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Head of Department' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Viewer' AND functions.uri='/ta/elicence-request/getTaELicenceDetails');