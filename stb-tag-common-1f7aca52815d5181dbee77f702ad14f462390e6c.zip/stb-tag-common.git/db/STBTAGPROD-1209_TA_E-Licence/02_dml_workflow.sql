INSERT INTO types (createdBy, createdDate, updatedBy,updatedDate,isActive, isEditable, ordinal, label, code, otherLabel, categoryCode, mappingCode,version) 
VALUES ('SYSTEM', sysdate(),'SYSTEM', sysdate(),1, 1, (Select * from (select (count(*)+1) as cnt from types  where categoryCode='TA_APP') as a), 'E-Licence Request', 'TA_APP_ELICENCE_REQUEST', null, 'TA_APP', null,0);


INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_ELICENCE_REQUEST', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_ELICENCE_REQUEST'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_ELICENCE_REQUEST'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));