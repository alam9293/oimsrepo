ALTER TABLE `licences`
ADD COLUMN `isDownloadable` int(11) DEFAULT '0',
ADD COLUMN `isViewable` int(11) DEFAULT '0';

ALTER TABLE `ta_branches`
ADD COLUMN `isDownloadable` int(11) DEFAULT '0';

ALTER TABLE `travel_agents`
ADD COLUMN `displayName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
ADD COLUMN `displayAddressId` int(11) DEFAULT NULL;

ALTER TABLE `travel_agents`
ADD CONSTRAINT FK_addresses_displayAddress
FOREIGN KEY (`displayAddressId`) REFERENCES `addresses` (`id`);

CREATE TABLE `ta_e_licence_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdDate` datetime(6) DEFAULT NULL,
  `updatedBy` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicationId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK25sg1rj1xmpguwr2yna97xiki` (`applicationId`),
  CONSTRAINT `FK25sg1rj1xmpguwr2yna97xiki` FOREIGN KEY (`applicationId`) REFERENCES `applications` (`id`)
);

