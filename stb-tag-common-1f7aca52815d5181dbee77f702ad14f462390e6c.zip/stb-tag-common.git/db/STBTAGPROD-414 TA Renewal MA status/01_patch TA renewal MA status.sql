select ta_filing_conditions.id, ta_filing_conditions.statusCode, applications.id,applications.applicationNo, workflow_actions.statusCode  from ta_filing_conditions left join ta_ma_submissions on ta_ma_submissions.taFilingConditionId =  ta_filing_conditions.id  
left join applications on ta_ma_submissions.applicationId =  applications.id 
left join workflow_actions on workflow_actions.id = applications.lastActionId
where applicationTypeCode = 'TA_APP_MA_SUBMISSION' and  workflow_actions.statusCode like  'TA_APP_PEND_%';

update ta_filing_conditions left join ta_ma_submissions on ta_ma_submissions.taFilingConditionId =  ta_filing_conditions.id  
left join applications on ta_ma_submissions.applicationId =  applications.id 
left join workflow_actions on workflow_actions.id = applications.lastActionId
set ta_filing_conditions.statusCode = 'TA_FILING_PA' where applicationTypeCode = 'TA_APP_MA_SUBMISSION' and  workflow_actions.statusCode like  'TA_APP_PEND_%';

select ta_filing_conditions.id, ta_filing_conditions.statusCode, applications.id,applications.applicationNo, workflow_actions.statusCode  from ta_filing_conditions left join ta_ma_submissions on ta_ma_submissions.taFilingConditionId =  ta_filing_conditions.id  
left join applications on ta_ma_submissions.applicationId =  applications.id 
left join workflow_actions on workflow_actions.id = applications.lastActionId
where applicationTypeCode = 'TA_APP_MA_SUBMISSION' and  workflow_actions.statusCode = 'TA_APP_APPR';

update ta_filing_conditions left join ta_ma_submissions on ta_ma_submissions.taFilingConditionId =  ta_filing_conditions.id  
left join applications on ta_ma_submissions.applicationId =  applications.id 
left join workflow_actions on workflow_actions.id = applications.lastActionId
set ta_filing_conditions.statusCode = 'TA_FILING_APPR' where applicationTypeCode = 'TA_APP_MA_SUBMISSION' and  workflow_actions.statusCode =  'TA_APP_APPR';

select ta_filing_conditions.id, ta_filing_conditions.statusCode, applications.id,applications.applicationNo, workflow_actions.statusCode  from ta_filing_conditions left join ta_ma_submissions on ta_ma_submissions.taFilingConditionId =  ta_filing_conditions.id  
left join applications on ta_ma_submissions.applicationId =  applications.id 
left join workflow_actions on workflow_actions.id = applications.lastActionId
where applicationTypeCode = 'TA_APP_MA_SUBMISSION' and  workflow_actions.statusCode = 'TA_APP_RFA';

update ta_filing_conditions left join ta_ma_submissions on ta_ma_submissions.taFilingConditionId =  ta_filing_conditions.id  
left join applications on ta_ma_submissions.applicationId =  applications.id 
left join workflow_actions on workflow_actions.id = applications.lastActionId
set ta_filing_conditions.statusCode = 'TA_FILING_RFA' where applicationTypeCode = 'TA_APP_MA_SUBMISSION' and  workflow_actions.statusCode =  'TA_APP_RFA';