INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 17, 'TG_APP_STIPEND', 'TG Wage Support Application', null, 'TG_APP', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 10, 'PAYREQ_TG_STIPEND', 'TG Stipend', null, 'PAYREQ', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 17, 'TG_DOC_STIPEND', 'TG Supporting Document for Stipend Application', null, 'TG_DOC', null);

INSERT INTO statuses (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 8, 'PAYREQ_PD', 'Pending Payment',null, 'STAT_PAYREQ');
INSERT INTO statuses (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 9, 'PAYREQ_DISBURSED', 'Paid',null, 'STAT_PAYREQ');

INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 18, 'TG_DOC_CPF_GUIDE', 'Guide to screenshot SPF contribution', null, 'TG_DOC', null);

INSERT INTO files (createdBy, createdDate, updatedBy, updatedDate, version, description, extension, filename, isDeleted, originalFilename, path) 
VALUES ('system', now(), 'system', now(), '0', 'Guide to screenshot SPF contribution', 'pdf', 'TG_DOC_CPF_GUIDE.pdf',false, 'TG_DOC_CPF_GUIDE.pdf', 'templates/');

INSERT INTO document_templates (createdBy, createdDate, updatedBy, updatedDate, version, typeCode, fileId) 
VALUES ('system', now(), 'system', now(), '0', 'TG_DOC_CPF_GUIDE', (select id from files where description = 'Guide to screenshot SPF contribution'));