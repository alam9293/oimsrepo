-- DO NOT RUN THIS
/**
INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'TG_STIPEND_AMOUNT','1000','Stipend amount to be disbursed to TG','DATA_NUM',0,95);
INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'TG_STIPEND_START_DATE','13-Feb-2020','Stipend application period start date','DATA_DT',0,96);
INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'TG_STIPEND_END_DATE','30-Apr-2020','Stipend application period end date','DATA_DT',0,97);
INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'TG_STIPEND_LANGUAGES','TG_LANG_MAN','Guiding language(s) of TG that is eligible to apply stipend application','DATA_STR',0,98);
INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'TG_STIPEND_LICENCE_START_DATE_BEFORE','01-Mar-2020','Stipend application can only be applied by TG with licence start date before this date','DATA_DT',0,99);
INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'TG_STIPEND_PREAMBLE_TEXT','Only TGs who are licensed to guide in Mandarin and who are self-employed and who are Singapore Citizens or Permanent Residents are eligible for the stipend. Applications will close on 30 April 2020. Submitted applications cannot be withdrawn.','Preamble page displayed on stipend application form','DATA_STR',0,100);
INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'TG_STIPEND_DECLARATION','In submitting my application, I declare the following:
a.        I shall comply with all legislative requirements, codes or conditions of my TG licence.
b.        I am a self-employed TG and I am not employed by any person or business entity.
c.        I shall not cancel my TG licence or surrender my Singapore Citizenship or Permanent Residency status at any time before 1 May 2020.
d.        All information provided in this application, including the banking information and the CPF extract, is true, accurate and complete to the best of my knowledge.
Further, I acknowledge that STB is not obliged to approve my application or to pay out the stipend if I do not comply with any of the above declarations.','TG stipend application declaration','DATA_STR',0,101);


INSERT INTO tg_stipend_configs (version, createdBy, createdDate, amount, guidingLanguages, licenceStartBefore, periodStartDate, periodEndDate)
VALUES (
	0, 'SYSTEM', NOW(),
	(SELECT value FROM system_parameters where code='TG_STIPEND_AMOUNT'),
    (SELECT value FROM system_parameters where code='TG_STIPEND_LANGUAGES'),
    (SELECT STR_TO_DATE(value, '%d-%M-%Y') FROM system_parameters where code='TG_STIPEND_LICENCE_START_DATE_BEFORE'),
    (SELECT STR_TO_DATE(value, '%d-%M-%Y') FROM system_parameters where code='TG_STIPEND_START_DATE'),
    (SELECT STR_TO_DATE(value, '%d-%M-%Y') FROM system_parameters where code='TG_STIPEND_END_DATE')
);**/