INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 19, 'WKFLW_ACT_FOLLOW_UP', 'Follow Up', null, 'WKFLW_ACT', null);

INSERT INTO statuses (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode) VALUES (1, 1, 10, 'PAYREQ_PEND_TG', 'Pending TG Input',null, 'STAT_PAYREQ');