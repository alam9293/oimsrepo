alter table statuses add column createdBy varchar(255);
alter table statuses add column createdDate datetime(6);
alter table statuses add column updatedBy varchar(255);
alter table statuses add column updatedDate datetime(6);
alter table statuses add column version integer;

alter table types add column createdBy varchar(255);
alter table types add column createdDate datetime(6);
alter table types add column updatedBy varchar(255);
alter table types add column updatedDate datetime(6);
alter table types add column version integer;