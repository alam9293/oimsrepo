UPDATE `workflow_configs` SET `isConfigurable` = false WHERE (`id` = '24'); -- TG_APP_REINSTATEMENT
UPDATE `workflow_configs` SET `isConfigurable` = false WHERE (`id` = '25'); -- TG_APP_RENEWAL
UPDATE `workflow_configs` SET `isConfigurable` = false WHERE (`id` = '22'); -- TG_APP_CREATION

update system_parameters set value='1,2,3,4,5,6,7,8,9,10,11,12' where code='TG_LIC_START_CYCLE';

