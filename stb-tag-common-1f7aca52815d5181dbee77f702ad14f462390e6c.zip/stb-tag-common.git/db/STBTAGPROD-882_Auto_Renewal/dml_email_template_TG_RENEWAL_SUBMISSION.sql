DELETE FROM email_templates WHERE code = 'TG_RENEWAL_SUBMISSION';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body,isActive) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_RENEWAL_SUBMISSION'
	, 'Submitted Application for ${app_type} has been approved.'
	, 'TG''s Notification Email for Renewal Submission'
	, '<p>Dear ${tg_name}
<p><br>
<p>Application for ${app_type} (ref no: ${app_ref}) has been approved. We will contact you when your licence is ready for collection.
<br>STB may request for additional information/clarifications if required. You may login via the url below to access your application.
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator',1);

