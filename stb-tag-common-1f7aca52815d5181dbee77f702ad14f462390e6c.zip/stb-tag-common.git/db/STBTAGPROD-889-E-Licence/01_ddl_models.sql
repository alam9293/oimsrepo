alter table tourist_guides add column displayEmployerName varchar(255);
alter table tourist_guides add column displayName varchar(255);
alter table tourist_guides add column displaySecondEmployerName varchar(255);
alter table tourist_guides add column displaySecondName varchar(255);


INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save TG E-Licence details', '/tg/licences/elicence/save', 'MOD_TG', 'TG_ELIC_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/licences/elicence/save' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Approving Officer' AND functions.uri='/tg/licences/elicence/save');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TG Processing Officer' AND functions.uri='/tg/licences/elicence/save');	
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Super Role' AND functions.uri='/tg/licences/elicence/save');