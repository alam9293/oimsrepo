INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TG_SWITCH_TIER');

INSERT INTO types (createdBy, createdDate, updatedBy,updatedDate,isActive, isEditable, ordinal, label, code, otherLabel, categoryCode, mappingCode,version) 
VALUES ('SYSTEM', sysdate(),'SYSTEM', sysdate(),1, 1, 10, 'New Guiding Category', 'TG_APP_SWITCH_TIER', null, 'TG_APP', null,0);

INSERT INTO workflow_configs (appOrWkflwTypeCode, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) 
VALUES ('TG_APP_SWITCH_TIER', false, 0, 'SYSTEM', NOW(), 'SYSTEM', sysdate());

INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Switch Tier', '/tg/candidates/switch-tier', 'MOD_TG', 'TG_CDD_SWITCH', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/tg/candidates/switch-tier' WHERE f.code IS NULL);
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/tg/candidates/switch-tier');




