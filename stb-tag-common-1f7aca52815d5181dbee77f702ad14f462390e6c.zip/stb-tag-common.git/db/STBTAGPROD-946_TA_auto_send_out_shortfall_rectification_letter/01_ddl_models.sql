create table letter_templates (code varchar(255) not null, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, content text, description varchar(255), isActive BIT(1) default 0 not null, name varchar(255), primary key (code)) engine=InnoDB;

alter table ta_net_value_shortfalls add column letterContent text;