INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View Letter Template', '/ta/letter-template/view', 'MOD_TA', 'TA_LETTER_TEMPLATE_VW', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/letter-template/view' WHERE f.code IS NULL);
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'Save Letter Template', '/ta/letter-template/save', 'MOD_TA', 'TA_LETTER_TEMPLATE_SAVE', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/ta/letter-template/save' WHERE f.code IS NULL);

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/letter-template/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='TA Verifying Officer' AND functions.uri='/ta/letter-template/save');

INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/letter-template/view');
INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='System Administrator' AND functions.uri='/ta/letter-template/save');
