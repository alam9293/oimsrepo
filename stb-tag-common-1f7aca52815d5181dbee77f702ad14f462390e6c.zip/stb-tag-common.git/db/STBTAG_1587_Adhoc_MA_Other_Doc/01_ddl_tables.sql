ALTER TABLE ta_filing_conditions CHANGE COLUMN remarks remarks VARCHAR(5000) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL;
ALTER TABLE ta_filing_condition_extensions CHANGE COLUMN toExtend toProceed BIT(1) NOT NULL DEFAULT b'1';
ALTER TABLE ta_licence_renewal_exercise_tas add column isMaVoid BIT(1) default 0 not null;

create table ta_adhoc_doc_submissions (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, applicationId integer, taFilingConditionId integer, primary key (id)) engine=InnoDB;
create table ta_adhoc_filing_requests (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, dueDate date, fy integer, requestRemarks varchar(5000), requestedAsAtDate date, reqTypeCode varchar(255), taFilingId integer, workflowId integer, primary key (id)) engine=InnoDB;
create table ta_filing_condition_amendments (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, remarks varchar(5000), workflowId integer, primary key (id)) engine=InnoDB;

alter table ta_filing_condition_extensions add column ammendmentTypeCode varchar(255);
alter table ta_filing_condition_extensions add column taFilingConditionAmendmentId integer;
alter table ta_adhoc_doc_submissions add constraint FKp83cwrgtf60o54a0ytrnshtxv foreign key (applicationId) references applications (id);
alter table ta_adhoc_doc_submissions add constraint FK8jyjh1whtku29dp8yrqxfwuhc foreign key (taFilingConditionId) references ta_filing_conditions (id);
alter table ta_adhoc_filing_requests add constraint FKiu8780pqh3l312ds2rsn47h0o foreign key (reqTypeCode) references types (code);
alter table ta_adhoc_filing_requests add constraint FK50cuat5uyvbxo5vox0y430fqp foreign key (taFilingId) references ta_filing_conditions (id);
alter table ta_adhoc_filing_requests add constraint FKh9uetyun3e4vxriiyfbgrr5uf foreign key (workflowId) references workflows (id);
alter table ta_filing_condition_amendments add constraint FK4ygdtacygoxiy5hfwypvr5k7s foreign key (workflowId) references workflows (id);
alter table ta_filing_condition_extensions add constraint FKrdia4mkdpk7iog6hrpmrtn7qv foreign key (ammendmentTypeCode) references types (code);
alter table ta_filing_condition_extensions add constraint FK62442d36t85llk154crgvpmsb foreign key (taFilingConditionAmendmentId) references ta_filing_condition_amendments (id);

