INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 0, 0, 'TA_REQ_ADHOC', '', null, null, null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 1, 'TA_REQ_ADHOC_DOCS', 'Ad-hoc Document Request', null, 'TA_REQ_ADHOC', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 2, 'TA_REQ_ADHOC_MA', 'Ad-hoc MA Request', null, 'TA_REQ_ADHOC', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 18, 'TA_APP_ADHOC_DOC_SUBMISSION', 'Ad-hoc Document', null, 'TA_APP', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 19, 'TA_APP_ADHOC_MA_SUBMISSION', 'Ad-hoc Management Accounts', 'Management Accounts (MA)', 'TA_APP', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 20, 'TA_DOC_ADHOC_DOC', 'Document for Ad-hoc Document Submission', null, 'TA_DOC', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 5, 'TA_WKFLW_ADHOC_MA_REQ', 'TA Ad-hoc MA Request', null, 'TA_WKFLW', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 6, 'TA_WKFLW_ADHOC_DOC_REQ', 'TA Ad-hoc Document Request', null, 'TA_WKFLW', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 7, 'TA_WKFLW_FILING_AMEND', 'TA MA/Document Amendment', null, 'TA_WKFLW', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 0, 0, 'TA_FILING_AMENDMENT', 'TA Filing Condition Amendment Type', null, null, null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 1, 'TA_FILING_AMEND_EXTEND_DUE_DATE', 'Extend Due Date', null, 'TA_FILING_AMENDMENT', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode, createdBy, createdDate, updatedBy, updatedDate, version) VALUES (1, 1, 2, 'TA_FILING_AMEND_RESCIND', 'Rescind', null, 'TA_FILING_AMENDMENT', null,'SYSTEM',NOW(),'SYSTEM',NOW(),0);

update statuses set version = 1 where version is null;
update statuses set createdBy = 'SYSTEM' where createdBy is null;
update statuses set createdDate = NOW()  where createdDate is null;
update statuses set updatedBy = 'SYSTEM' where updatedBy is null;
update statuses set updatedDate = NOW() where updatedDate is null;


update types set version = 1 where version is null;
update types set createdBy = 'SYSTEM' where createdBy is null;
update types set createdDate = NOW() where createdDate is null;
update types set updatedBy = 'SYSTEM' where updatedBy is null;
update types set updatedDate = NOW() where updatedDate is null;