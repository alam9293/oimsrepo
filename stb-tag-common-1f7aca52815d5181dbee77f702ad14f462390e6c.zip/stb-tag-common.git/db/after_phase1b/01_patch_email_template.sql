UPDATE email_templates 
SET 
    updatedDate = NOW(),
    body = '<p>Dear Sir/ Madam, </p>
    <p>We are pleased to inform you that your submission (ID: ${app_ref}) to renew your travel agent licence is successful. </p>
    <p>Please log on to <a href="${app_link}">TRUST</a> with your CorpPass to proceed with payment of the licence renewal fees. For CorpPass login issues, do contact the CorpPass helpdesk at support@corppass.gov.sg or call 6643 0577 for assistance.        </p>
    <p>A user guide for payment of licence renewal fees can be found under the Help tab on the TRUST website. </p>
    <p>For reference, the licence renewal fees are as follows: </p>
    <ul>
      <li>Main Licence - S$${app_amount}</li>
      <li>Branch Licence - S$${sec_main_app_amount}</li>
    </ul>
    <p>Upon completion of payment, your new licence(s) will be posted via registered article to the licensee’s operating address. </p>
    <p>Thank you.</p>
    <p>Travel Agent Licensing & Regulatory Review Department</p>
    <p>Singapore Tourism Board</p>
    <p>* Please do not reply to this computer generated email. *</p>',
    subject = 'PAYMENT OF TRAVEL AGENT RENEWAL LICENCE FEE'
WHERE
    (code = 'TA_LICENCE_RENEWAL_APPROVAL');