
update types set label = 'Proof of Shortfall Rectification' where code = 'TA_APP_NET_VALUE_RECTIFICATION';

UPDATE email_templates 
SET 
    updatedDate = NOW(),
    body = '<p>Dear ${ke_name},
<p><br>
<p>Your submission for ${app_type} (ref no: ${app_ref}) on ${app_submission_date} is returned for your action.
<p><br>
<p>You may <a href="${app_link}">login here</a> to view the action required to complete the ${app_type}.
<p><br>
<p>Regards,
<br>${officer_name}
<br>${officer_department}
<br>${stb_organisation}
<br>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:${ta_support_email}">${ta_support_email}</a> for any queries.***'
WHERE code = 'CNE_UPON_TA_SUBMISSION_RFA';


UPDATE email_templates 
SET 
    updatedDate = NOW(),
    subject = '${app_type}'
WHERE code = 'CNE_RECT_SHORTFALL_UPON_REJECT';


UPDATE email_templates 
SET 
    updatedDate = NOW(),
    body = '<p>Dear ${ke_name},
<p><br>
<p>We would like to inform you that your request for extension to submit proof of shortfall rectification has been approved.
<p><br>
<p>You may <a href="${app_link}">login here</a> to complete the submission of proof of shortfall rectification.
<p><br>
<p>Regards,
<br>${officer_name}
<br>${officer_department}
<br>${stb_organisation}
<br>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:${ta_support_email}">${ta_support_email}</a> for any queries.***',
subject = 'Request for Extension to Submit Proof of Shortfall Rectification has been approved'
WHERE code = 'CNE_UPON_SHORTFALL_EXTENSION_APPROVAL';