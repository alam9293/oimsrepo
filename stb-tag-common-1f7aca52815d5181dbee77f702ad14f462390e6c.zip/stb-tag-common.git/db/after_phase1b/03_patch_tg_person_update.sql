update workflow_actions wa, (select c.id from tg_person_updates a 
left join applications b on a.applicationId=b.id
left join workflow_actions c on b.lastActionId = c.id
where a.createdDate > '2019-07-26' and b.licencePrintStatusCode='PRINT_N' and c.statusCode='TG_APP_PEND_PO') t
set wa.statusCode='TG_APP_APPR', wa.typeCode='WKFLW_ACT_APPR' 
where wa.id=t.id; 