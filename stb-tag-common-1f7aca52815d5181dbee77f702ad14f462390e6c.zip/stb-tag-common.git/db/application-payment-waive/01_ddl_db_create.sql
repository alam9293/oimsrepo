create table waive_types (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, isWaive bit, typeCode varchar(255), primary key (id)) engine=InnoDB;

alter table waive_types add constraint FKh0yj4qkwqbh7fpffdp2igxduv foreign key (typeCode) references types (code);

