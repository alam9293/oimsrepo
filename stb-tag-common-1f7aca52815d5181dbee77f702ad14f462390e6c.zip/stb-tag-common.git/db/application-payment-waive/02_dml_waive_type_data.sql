INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TA_RENEWAL');
INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TG_CREATION');
INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TG_PARTICULAR_UPDATE');
INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TG_RENEWAL');
INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TG_MLPT');

INSERT INTO system_parameters (version, createdBy, createdDate, code, value, description, dataTypeCode, isEditable, ordinal)  VALUES (0, 'SYSTEM', NOW(), 'PAYMENT_WAIVE_INTERNAL_REMARKS','Payment fee is auto-waived due to system master configuration.','Internal remarks for payment waiver','DATA_STR',1, (Select MAX(a.ordinal) + 1 from system_parameters a));

INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TG_MLPT_REGISTRATION');
INSERT INTO waive_types (createdBy, createdDate, updatedBy, updatedDate, version, isWaive, typeCode) VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1, 'PAYREQ_TG_ATG_EXAM');