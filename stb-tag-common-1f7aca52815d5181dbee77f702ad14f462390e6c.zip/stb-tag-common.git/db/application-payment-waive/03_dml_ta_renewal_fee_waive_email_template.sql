DELETE FROM email_templates WHERE code = 'TA_LICENCE_RENEWAL_APPROVAL_WAIVED';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body, isActive) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_LICENCE_RENEWAL_APPROVAL_WAIVED'
	, 'PAYMENT OF TRAVEL AGENT RENEWAL LICENCE FEE HAS BEEN WAIVED'
	, 'TA''s Notification Email for TA Licence Renewal Fee Waiver'
	, '<p>Dear Sir/ Madam, </p>
<p>We are pleased to inform you that your submission (ID: ${app_ref}) to renew your travel agent licence is successful.</p>
<p>As a first step in a wider set of measures to help tourism businesses mitigate the immediate impact of the 2019 novel coronavirus, travel agents whose licences are due for renewal in 2020 will not need to pay to renew their licence fees.</p>
<p>Your new licence(s) will be posted via registered article to the licensee’s operating address.</p>
<p>Thank you.</p>
<p>Travel Agent Licensing & Regulatory Review Department</p>
<p>Singapore Tourism Board</p>
<p>* Please do not reply to this computer generated email. *</p>', 1);