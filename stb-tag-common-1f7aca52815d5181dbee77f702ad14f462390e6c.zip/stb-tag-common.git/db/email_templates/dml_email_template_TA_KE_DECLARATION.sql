DELETE FROM email_templates WHERE code = 'TA_KE_DECLARATION';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_KE_DECLARATION'
	, 'You have been appointed as the Key Executive of ${ta_name}'
	, 'TA KE Declaration'
	, '<p>Dear KE (${ke_uin})
<p><br>
<p>You have been appointed as the Key Executive of ${ta_name}. You are required to submit a declaration. You may login to the Travel Agent portal using the link below by CorpPass.
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');