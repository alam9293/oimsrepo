DELETE FROM email_templates WHERE code = 'TA_LICENCE_CREATION_APPROVAL';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_LICENCE_CREATION_APPROVAL'
	, 'Your Travel Agent Licence Application has been approved'
	, 'TA''s Notification Email for approval of TA Licence Application'
	, '<p>Dear ${ta_licence_creation_appname}
<p><br>
<p>Your application, on behalf of ${ta_name} (${ta_uen}), has been approved. 
<p>Please login to the Travel Agent portal using the link below to make a payment of SDG $400 for the licence fee.
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

