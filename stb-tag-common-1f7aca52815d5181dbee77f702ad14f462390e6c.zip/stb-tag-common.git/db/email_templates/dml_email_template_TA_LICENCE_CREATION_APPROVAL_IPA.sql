DELETE FROM email_templates WHERE code = 'TA_LICENCE_CREATION_APPROVAL_IPA';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_LICENCE_CREATION_APPROVAL_IPA'
	, 'Your Travel Agent Licence Application has been provisionally approved'
	, 'TA''s Notification Email for provisional approval of TA Licence Application'
	, '<p>Dear ${ta_licence_creation_appname}
<p><br>
<p>Your application, on behalf of ${ta_name} (${ta_uen}), has been provisionally approved. You may access the same application using the link below to input your operating address.
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

