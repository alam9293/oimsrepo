DELETE FROM email_templates WHERE code = 'TA_LICENCE_CREATION_DRAFT';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_LICENCE_CREATION_DRAFT'
	, 'Your application for TA Licence has been successfully save as draft'
	, 'TA Licence Creation Draft'
	, '<p>Dear ${ta_licence_creation_appname}
<p><br>
<p>Your application, on behalf of ${ta_name} (${ta_uen}), has been successfully saved as draft. You may check the status of your application using the link below.
<p>Your draft will expire on ${ta_licence_creation_draft_expiry}.
<p><br>
<p><center><a href="${app_link}">Retrieve Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

