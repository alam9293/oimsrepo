DELETE FROM email_templates WHERE code = 'TA_LICENCE_CREATION_SUBMISSION';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_LICENCE_CREATION_SUBMISSION'
	, 'We have successfully received your application for Travel Agent Licence'
	, 'TA''s Notification Email for successful submission of TA Licence Creation'
	, '<p>Dear ${ta_licence_creation_appname}
<p><br>
<p>Your application, on behalf of ${ta_name} (${ta_uen}), has been successfully submitted. You may check the status of your application using the link below.
<p><br>
<p><center><a href="${app_link}">Retrieve Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

