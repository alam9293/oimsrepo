DELETE FROM email_templates WHERE code = 'TA_UPON_REJECTION';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_UPON_REJECTION'
	, 'Submission for ${app_type} has been rejected.'
	, 'TA''s Notification Email for Reject Action'
	, '<p>Dear ${ta_name}
<p><br>
<p>Submission for ${app_type} (ref no: ${app_ref}) has been rejected. You may login via the url below to access your submission. 
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

