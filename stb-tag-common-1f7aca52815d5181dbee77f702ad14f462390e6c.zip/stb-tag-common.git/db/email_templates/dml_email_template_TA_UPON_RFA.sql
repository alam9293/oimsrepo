DELETE FROM email_templates WHERE code = 'TA_UPON_RFA';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_UPON_RFA'
	, 'Submission for ${app_type} has been returned for your action.'
	, 'TA''s Notification Email for RFA Action'
	, '<p>Dear ${ta_name}
<p><br>
<p>Submission for ${app_type} (ref no: ${app_ref}) has been returned for your action. You may login via the url below to access your submission and view the changes/clarifications required. 
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

