DELETE FROM email_templates WHERE code = 'TG_APP_DRAFT';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_APP_DRAFT'
	, 'Draft Application Submitted'
	, 'Notification Email for Draft Application'
	, '<p>Dear ${tg_name}
<p><br>
<p>Please click the click below to submit your draft application. 
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

