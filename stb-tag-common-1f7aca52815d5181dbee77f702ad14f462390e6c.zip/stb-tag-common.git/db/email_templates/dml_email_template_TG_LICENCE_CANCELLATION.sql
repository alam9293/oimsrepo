DELETE FROM email_templates WHERE code = 'TG_LICENCE_CANCEL';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_LICENCE_CANCEL'
	, 'Application for ${app_type} has been submitted.'
	, 'TG''s Licence Cancellation Notification Email'
	, '<p>Dear ${tg_name}
<p><br>
<p>Your licence has been cancelled successfully. You may login via the url below to access your application. 
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

