DELETE FROM email_templates WHERE code = 'TG_LICENCE_COLLECT';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_LICENCE_COLLECT'
	, 'Collection for ${app_type}'
	, 'TG''s Notification Email for Licence Collection'
	, '<p>Dear ${tg_name}
<p><br>
<p> We are pleased to inform that your new licence is ready for collection.
<p> Please bring along your ${tg_workpass_type} and current licence for licence collection, failing which we will not be able to issue your new licence.
<p> Kindly proceed to the meeting cubicle located at Level 1 when you arrive. 
<p> Location: Singapore Tourism Board, Tourism Court, 1 Orchard Spring Lane, Singapore 247729
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

