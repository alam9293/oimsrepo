DELETE FROM email_templates WHERE code = 'TG_LICENCE_STATUS_UPDATE';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_LICENCE_STATUS_UPDATE'
	, 'Licence''s status has been changed to ''${licence_update_action}'''
	, 'TG''s Notification Email for Licence Status Update'
	, '<p>Dear ${tg_name}
<p><br>
<p>Your Licence''s status has been changed to ''${licence_update_action}''
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

