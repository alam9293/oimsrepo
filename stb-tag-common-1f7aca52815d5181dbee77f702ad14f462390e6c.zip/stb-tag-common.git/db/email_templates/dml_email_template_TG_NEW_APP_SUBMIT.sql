DELETE FROM email_templates WHERE code = 'TG_NEW_APP_SUBMIT';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_NEW_APP_SUBMIT'
	, 'New Application Submitted'
	, 'Notification Email for New Application Submitted'
	, '<p>Dear ${tg_name}
<p><br>
<p>We have successfully received your application and will be looking through shortly. You may login via the url below to check on the status of your application.
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

