DELETE FROM email_templates WHERE code = 'TG_PORTAL_ID_ENABLED';

INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_PORTAL_ID_ENABLED'
	, 'TRUST Login information'
	, 'Login Details for TRUST'
	, '<p>Dear ${tg_name},
<p><br>
<p>Your login details for TRUST PORTAL ID is as below:<p>
<p>Login ID: ${tg_nric}<p>
<p>Password: Licence No. + DOB (YYYYMMDD) <small>e.g 044519801231</small>
<p>You are advised to change your password upon login.<p>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');
