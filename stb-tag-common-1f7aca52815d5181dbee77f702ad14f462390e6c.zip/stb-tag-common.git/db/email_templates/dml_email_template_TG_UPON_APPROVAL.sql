DELETE FROM email_templates WHERE code = 'TG_UPON_APPROVAL';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_UPON_APPROVAL'
	, 'Submitted Application for ${app_type} has been approved.'
	, 'TG''s Notification Email for Approval Action'
	, '<p>Dear ${tg_name}
<p><br>
<p>Application for ${app_type} (ref no: ${app_ref}) has been approved. You may login via the url below to access your application. 
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

