DELETE FROM email_templates WHERE code = 'TG_UPON_RFA';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_UPON_RFA'
	, 'Submitted Application for ${app_type} has been returned for your actions.'
	, 'TG''s Notification Email for RFA Action'
	, '<p>Dear ${tg_name}
<p><br>
<p>Application for ${app_type} has been returned for your actions due to the reason below :<p>
<p>${tg_remark}<p>
<br>
<p>You may login via the url below to access your application and view the changes/clarifications required. </p>
<br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

