DELETE FROM email_templates WHERE code = 'USER_LOGIN_DETAILS';

INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'USER_LOGIN_DETAILS'
	, 'TRUST Login information'
	, 'Login Details for TRUST'
	, '<p>Dear ${user_name},
<p><br>
<p>Your login details for TRUST is as below:<p>
<p>Login ID: ${login_id}<p>
<p>Password: ${password}<p>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

