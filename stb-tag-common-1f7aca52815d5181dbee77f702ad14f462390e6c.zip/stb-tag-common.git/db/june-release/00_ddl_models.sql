alter table applications add column pendingCollectionEndDate date;
alter table applications add column pendingCollectionStartDate date;
alter table applications add column sendToVendorDate date;
alter table tg_person_updates add column previousValueId integer;
alter table tourist_guides add column hasPersonUpdateAccess bit;
alter table tg_person_updates add constraint FKtdupwx3brvdy4yietpt9trouj foreign key (previousValueId) references tg_person_updates (id);
alter table ta_abpr_submissions add column isNilSubmission bit;
update ta_abpr_submissions set isNilSubmission=0;
ALTER TABLE ta_abpr_submissions MODIFY COLUMN isNilSubmission BIT(1) DEFAULT 0 NOT NULL;