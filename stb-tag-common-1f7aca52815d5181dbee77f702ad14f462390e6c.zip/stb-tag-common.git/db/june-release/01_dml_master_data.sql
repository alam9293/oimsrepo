update statuses set otherLabel='Licence Collected', ordinal=5 where code='PRINT_C';
update statuses set otherLabel='Not Required', ordinal=6 where code='PRINT_N';
update statuses set otherLabel='Pending Application Approval', ordinal=1 where code='PRINT_PA';
update statuses set otherLabel='Ready for Collection', ordinal=4 where code='PRINT_PC';
update statuses set otherLabel='New', ordinal=2 where code='PRINT_PP';
update statuses set otherLabel='Send to Vendor', ordinal=3 where code='PRINT_SP';