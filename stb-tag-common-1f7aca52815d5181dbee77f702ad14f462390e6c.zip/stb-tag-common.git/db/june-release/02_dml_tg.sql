SET SQL_SAFE_UPDATES = 0;
update tourist_guides a left join licences b on a.licenceId=b.id 
set hasPersonUpdateAccess=true
where b.statusCode='TG_A';

update tourist_guides a left join licences b on a.licenceId=b.id 
set hasPersonUpdateAccess=false
where b.statusCode!='TG_A';

update tourist_guides set hasPersonUpdateAccess=0 where hasPersonUpdateAccess is null;
ALTER TABLE tourist_guides MODIFY COLUMN hasPersonUpdateAccess BIT(1) DEFAULT 0 NOT NULL;
SET SQL_SAFE_UPDATES = 1;