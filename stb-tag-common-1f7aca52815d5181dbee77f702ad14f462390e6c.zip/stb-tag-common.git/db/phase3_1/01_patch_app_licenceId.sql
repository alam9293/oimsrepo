update applications app
join ta_licence_creations tlc on app.id = tlc.applicationId
join workflow_actions lastAction on lastAction.id = app.lastActionId
join travel_agents ta on ta.uen = tlc.uen
set app.licenceId = ta.licenceId
where lastAction.statusCode = 'TA_APP_APPR' and app.licenceId is null;

update ta_licence_replacements rep
join applications app on app.id = rep.applicationId
join workflow_actions lastAction on lastAction.id = app.lastActionId
set app.licencePrintStatusCode = 'TA_PRINT_NA'
where lastAction.statusCode = 'TA_APP_APPR' and rep.billRefNo is not null and app.licencePrintStatusCode is null;