create table if not exists ta_cpf_arrears (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, hasCpfArrear BIT(1) default 0 not null, name varchar(255), responseDate date, uen varchar(255), travelAgentId integer, primary key (id)) engine=InnoDB;

create table tg_licence_expiry_notification_email_logs (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, expiryDate date, forMonth integer, forYear integer, sendDate datetime(6), emailLogId integer, emailTemplateCode varchar(255), licenceId integer, statusCode varchar(255), primary key (id)) engine=InnoDB;

alter table tg_licence_expiry_notification_email_logs add constraint FK5s95q12kafdwl2c9whf2j8msb foreign key (emailLogId) references email_logs (id);
alter table tg_licence_expiry_notification_email_logs add constraint FKix2eot3s86ooem33tb4bmkwc0 foreign key (emailTemplateCode) references email_templates (code);
alter table tg_licence_expiry_notification_email_logs add constraint FKc2hs75hypdtk8ekv5oooc6po2 foreign key (licenceId) references licences (id);
alter table tg_licence_expiry_notification_email_logs add constraint FKsyr72j300u8l9valcfx9db5pu foreign key (statusCode) references statuses (code);

alter table tg_training_providers add column contactPerson1 varchar(255);
alter table tg_training_providers add column contactNo1 varchar(255);
alter table tg_training_providers add column email1 varchar(320);
alter table tg_training_providers add column signUpLink varchar(255);
alter table tg_training_providers add column webLink varchar(255);
alter table tg_training_providers add column profileSummary text;

alter table email_broadcasts add column isSending BIT(1) default 0 not null;
ALTER TABLE email_broadcasts MODIFY COLUMN isRecurring BIT(1) DEFAULT 0 NOT NULL;

alter table tg_courses add column classroomHrs decimal(19,2);
alter table tg_courses add column courseFee decimal(19,2);
alter table tg_courses add column courseFeeNote text;
alter table tg_courses add column objective text;
alter table tg_courses add column outOfClassroomHrs decimal(19,2);
alter table tg_courses add column outline text;
alter table tg_courses add column ssgCourseCode varchar(255);

create table tg_course_subsidies (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, fee decimal(19,2), tgCourseCode varchar(255), typeCode varchar(255), primary key (id)) engine=InnoDB;

alter table tg_course_subsidies add constraint FK4od2vgn2oryws95ojd7lxks83 foreign key (tgCourseCode) references tg_courses (code);
alter table tg_course_subsidies add constraint FKj1xgfedgsh13roc3v270clust foreign key (typeCode) references types (code);

