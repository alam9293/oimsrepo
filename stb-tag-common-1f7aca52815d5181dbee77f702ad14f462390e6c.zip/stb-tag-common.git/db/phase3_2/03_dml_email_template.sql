DELETE FROM email_templates WHERE code = 'TG_LIC_EXPIRY_REMINDER_1';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TG_LIC_EXPIRY_REMINDER_1', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear ${tg_salutation} ${tg_name},
<p>&nbsp;
<p><b>NOTICE TO RENEW TOURIST GUIDE LICENCE</b>
<p>Your tourist guide licence will be expiring on ${tg_lic_expiry_date}. Please fulfil the licence renewal conditions before ${tg_lic_expiry_date_1_mth_b4} so that your new licence will be ready before expiry.  For more information on how to renew your licence, you may refer to the user guide on TRUST.
<p>&nbsp;
<p>For any clarification, please email ${tg_support_email} (in subject header, state �TG Licence Renewal ${tg_lic_expiry_date}�, your name and TG licence number).  Thank you and have a great day!
<p>&nbsp;
<p>Best regards,
<p>Tourist Guide Licensing Department
<p>Singapore Tourism Board</p>', 'TG LICENCE EXPIRY REMINDER 1', '<1st Reminder> TG Licence Renewal, ${tg_lic_expiry_date}', 'TG Licence Expiry Date', '6', true, 'PREPOSITION_BEFORE', 'UNIT_MONTH', 'FREQUENCY_ONCE');


DELETE FROM email_templates WHERE code = 'TG_LIC_EXPIRY_REMINDER_2';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TG_LIC_EXPIRY_REMINDER_2', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear ${tg_salutation} ${tg_name},
<p>&nbsp;
<p><b>NOTICE TO RENEW TOURIST GUIDE LICENCE</b>
<p>Your tourist guide licence will be expiring on ${tg_lic_expiry_date}. Please fulfil the licence renewal conditions before ${tg_lic_expiry_date_1_mth_b4} so that your new licence will be ready before expiry.  For more information on how to renew your licence, you may refer to the user guide on TRUST.
<p>&nbsp;
<p>For any clarification, please email ${tg_support_email} (in subject header, state �TG Licence Renewal ${tg_lic_expiry_date}�, your name and TG licence number).  Thank you and have a great day!
<p>&nbsp;
<p>Best regards,
<p>Tourist Guide Licensing Department
<p>Singapore Tourism Board</p>', 'TG LICENCE EXPIRY REMINDER 2', '<2nd Reminder> TG Licence Renewal, ${tg_lic_expiry_date}', 'TG Licence Expiry Date', '4', true, 'PREPOSITION_BEFORE', 'UNIT_MONTH', 'FREQUENCY_ONCE');

DELETE FROM email_templates WHERE code = 'TG_LIC_EXPIRY_REMINDER_3';


INSERT INTO email_templates (code, createdBy, createdDate, updatedBy, updatedDate, version, body, name, subject, emailCountdownBaseDate, emailCountdownUnits, isActive, emailCountdownPrepositionCode, emailCountdownUnitTypeCode, emailFrequencyCode) VALUES ('TG_LIC_EXPIRY_REMINDER_3', 'SYSTEM', now(), 'SYSTEM', now(), '0', '<p>Dear ${tg_salutation} ${tg_name},
<p>&nbsp;
<p>Our records show that you have not submit your tourist guide licence renewal application. Hence, your new licence will not be ready by ${tg_lic_expiry_date}.
<p>Please note that you are not allowed to provide any guiding services with effect from ${tg_lic_expiry_date} as you are not in possession of a valid tourist guide licence. You will be deemed to be guiding without a valid licence and the Board will not hesitate to initiate action against you.
<p>For any clarification, please email ${tg_support_email} (in subject header, state �TG Licence Renewal ${tg_lic_expiry_date}�, your name and TG licence number).  Thank you and have a great day!
<p>&nbsp;
<p>Best regards,
<p>Tourist Guide Licensing Department
<p>Singapore Tourism Board
<p><center><b><span style="font-size:25px;">TOURIST GUIDE REGULATIONS</span></b></center>
<p><ol><li>It is an offence to provide guiding services without a valid tourist guide licence as stipulated under Section 19B of the Singapore Tourism Board (Amendment) Act 2014:</li>
<p><b>Licence required to act as tourist guide, etc.</b>
<i><p>19B.�
<p>(1)  Subject to subsection (2), no individual shall �
<p>(a) act as a tourist guide; or
<p>(b) offer to act as a tourist guide, or advertise in any way that he is or is willing to act as a tourist guide, unless he holds a valid tourist guide licence.
<p>(3)  Any person who contravenes subsection (1) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $5,000 and, in the case of a second or subsequent offence, to a fine not exceeding $10,000.</i>
<p>&nbsp;
<li>It is an offence to retain your expired licence to the Board as stipulated in Section 19(F) 3 of the Singapore Tourism Board (Amendment) Act 2014:</li>
<i><p> (3)  A person issued with a tourist guide badge under this section shall surrender his badge to the Board immediately upon �
<p> (a) being required to do so for the purpose of enabling the Board to make such alteration to the badge as the Board considers appropriate;
<p> (b) the expiry, cancellation, revocation or suspension of his tourist guide licence in respect of which the badge was issued; or
<p> (c) ceasing to be employed as, or engage in the business or provision of services of, a tourist guide, notwithstanding that he holds a valid tourist guide licence.
<p> (4)  Any person who fails to comply with subsection (3) shall be guilty of an offence and shall be liable on conviction to a fine not exceeding $5,000 and, in the case of a continuing offence, to a further fine not exceeding $100 for every day or part thereof during which the offence continues after conviction.</i></ol>
<p>&nbsp;', 'TG LICENCE EXPIRY REMINDER 3', '<Final Reminder> TG Licence Renewal, ${tg_lic_expiry_date}', 'TG Licence Expiry Date', '1', true, 'PREPOSITION_BEFORE', 'UNIT_MONTH', 'FREQUENCY_ONCE');
