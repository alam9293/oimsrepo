DELETE FROM email_templates WHERE code = 'TA_CPF_ARREAR_NOTIFICATION';

INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, isActive, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0, 1
	, 'TA_CPF_ARREAR_NOTIFICATION'
	, 'TA CPF Arrears'
	, 'TA CPF Arrears Notification'
	, '<p>The following travel agents have consecutive CPF Arrears as follows:-');