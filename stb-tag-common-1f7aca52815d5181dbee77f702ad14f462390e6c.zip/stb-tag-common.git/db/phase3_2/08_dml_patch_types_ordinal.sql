update types set ordinal = 1 where code = 'ADDR_L';
update types set ordinal = 2 where code = 'ADDR_F';