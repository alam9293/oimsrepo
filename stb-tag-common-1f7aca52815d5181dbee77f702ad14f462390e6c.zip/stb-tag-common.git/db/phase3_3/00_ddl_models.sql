alter table tg_courses add column parentTgCourseCode varchar(255);
alter table tg_courses add constraint FKh7y82x6a5qnlgfgppgnayyhs2 foreign key (parentTgCourseCode) references tg_courses (code);

create table tg_course_criterias (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, criteria varchar(255), isActive BIT(1) default 1 not null, ordinal integer, weightage1 decimal(19,2), weightage2 decimal(19,2), weightage3 decimal(19,2), weightage4 decimal(19,2), weightage5 decimal(19,2), primary key (id)) engine=InnoDB;

create table tg_course_evaluations (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, rating integer, weightage decimal(19,2), tgCourseCriteriaId integer, tgCourseRenewalId integer, primary key (id)) engine=InnoDB;

create table tg_course_renewals (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, remarks varchar(255), applicationId integer, tgCourseCode varchar(255), primary key (id)) engine=InnoDB;

alter table tg_course_evaluations add constraint FKpaf06h657eh9es2n3260th89i foreign key (tgCourseCriteriaId) references tg_course_criterias (id);
alter table tg_course_evaluations add constraint FKtjy6xunasbsxfd7owxrmevnme foreign key (tgCourseRenewalId) references tg_course_renewals (id);
alter table tg_course_renewals add constraint FKo62efshgr43ctwsvljf7cdw50 foreign key (applicationId) references applications (id);
alter table tg_course_renewals add constraint FKdrc0kwr3uvj5l8m5ixgbp3et foreign key (tgCourseCode) references tg_courses (code);

alter table applications add column tgCourseCode varchar(255);
alter table applications add constraint FKhq1s6dufh3yr6w5kyd1hvtvmx foreign key (tgCourseCode) references tg_courses (code);

create table tg_course_creations (id integer not null auto_increment, createdBy varchar(255), createdDate datetime(6), updatedBy varchar(255), updatedDate datetime(6), version integer, appropriateLevel text, assessment text, classroomHrs decimal(19,2), courseFee decimal(19,2), courseFeeNote text, isDeleted BIT(1) default 0 not null, name varchar(255), noOfHours decimal(19,2), objective text, outOfClassroomHrs decimal(19,2), outline text, ssgCourseCode varchar(255), synopsis text, trainers varchar(255), CategoryCode varchar(255), applicationId integer, languageCode varchar(255), tgTrainingProviderId integer, primary key (id)) engine=InnoDB;
alter table tg_course_creations add constraint FK6fdf2jybi8lnf5o4mnev66bfm foreign key (CategoryCode) references types (code);
alter table tg_course_creations add constraint FKo2u5k89x5oois6c6v1w2k8ate foreign key (applicationId) references applications (id);
alter table tg_course_creations add constraint FKmlt5ivjbh598ybqgtpvf9ywl9 foreign key (languageCode) references types (code);
alter table tg_course_creations add constraint FK16kgaww1x478rwaa7pq49d3yy foreign key (tgTrainingProviderId) references tg_training_providers (id);
alter table tg_course_subsidies add column tgCourseCreationId int(11);
alter table tg_course_subsidies add constraint FKgjf5ry6xxlt675689kdlwdhq7 foreign key (tgCourseCreationId) references tg_course_creations (id);

create table tg_training_provider$alerts (tgTrainingProviderId integer not null, alertsId integer not null, primary key (tgTrainingProviderId, alertsId)) engine=InnoDB;
alter table tg_training_provider$alerts add constraint FK98ogkxf3nuus99gmbal93s2hh foreign key (alertsId) references alerts (id);
alter table tg_training_provider$alerts add constraint FK73lho9coymc17bgjlf379ovxi foreign key (tgTrainingProviderId) references tg_training_providers (id);