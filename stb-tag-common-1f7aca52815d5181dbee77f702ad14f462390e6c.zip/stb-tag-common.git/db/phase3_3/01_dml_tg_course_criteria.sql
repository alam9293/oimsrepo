insert into tg_course_criterias (createdBy, createdDate, updatedBy, updatedDate, version, criteria, weightage1, weightage2, weightage3, weightage4, weightage5, ordinal)
values ('system', now(), 'system', now(), 0, 'Content Quality', 0, 0, 1, 2, 3, 1);
insert into tg_course_criterias (createdBy, createdDate, updatedBy, updatedDate, version, criteria, weightage1, weightage2, weightage3, weightage4, weightage5, ordinal)
values ('system', now(), 'system', now(), 0, 'Track Record', 0, 0, 1, 2, 3, 2);
insert into tg_course_criterias (createdBy, createdDate, updatedBy, updatedDate, version, criteria, weightage1, weightage2, weightage3, weightage4, weightage5, ordinal)
values ('system', now(), 'system', now(), 0, 'Relevance to TG work', 0, 0, 1, 2, 3, 3);