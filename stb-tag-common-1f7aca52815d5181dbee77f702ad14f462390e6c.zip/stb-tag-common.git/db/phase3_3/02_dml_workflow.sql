-- TG Workflows
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_COURSE_CREATION', (SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TG workflow_step_assignments
-- Course Creation
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_COURSE_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_PO'), (SELECT id FROM users where loginId='stb_jeremyk'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_COURSE_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), (SELECT id FROM users where loginId='stb_pangel'));
