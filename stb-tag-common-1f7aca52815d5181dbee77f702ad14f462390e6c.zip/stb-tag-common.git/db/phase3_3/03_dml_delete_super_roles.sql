delete from role$functions where roleCode = 'SUPER';
delete from user$roles where rolesCode = 'SUPER';
delete from roles where code = 'SUPER';