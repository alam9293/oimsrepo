DELETE FROM email_templates WHERE code = 'TG_COURSE_UPON_APPROVAL';

INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body, isActive) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_COURSE_UPON_APPROVAL'
	, 'Submitted Application for ${app_type} has been approved.'
	, 'TG Course Notification Email for Approval Action'
	, '<p>Dear ${tp_name}
<p><br>
<p>Application for ${app_type} for Course Title: <strong>${tg_course_name}</strong> has been approved. You may login via the url below to access your application. 
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator', 1);
