-- run this before auto-update, else it will create a new Ta_Filing_Conditions table w/o data 
ALTER TABLE ta_annual_filings RENAME TO ta_filing_conditions;
