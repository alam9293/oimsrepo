update ta_aa_submissions t1 inner join 
(select
	aa.id,
	aa.netValue,
	CASE lic.tierCode 
		WHEN 'TA_TIER_G' THEN CASE WHEN aa.netValue < 100000 THEN 100000 - aa.netValue ELSE 0 END
        WHEN 'TA_TIER_N' THEN CASE WHEN aa.netValue < 50000 then 50000 - aa.netValue ELSE 0 END
	END as 'shortfall'
from ta_aa_submissions aa 
	join ta_filing_conditions af on af.id = aa.taAnnualFilingId
	join licences lic  on af.licenceId = lic.id
) as t2 on t1.id = t2.id
set t1.shortfall = t2.shortfall