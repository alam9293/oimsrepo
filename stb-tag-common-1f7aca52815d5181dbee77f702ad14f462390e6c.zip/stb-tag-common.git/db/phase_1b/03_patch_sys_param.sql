INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value)  VALUES (0, 'SYSTEM', NOW(), 0, 23, 'DATA_NUM', 'TA_LICENCE_RENEWAL_FEE', 400);
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value)  VALUES (0, 'SYSTEM', NOW(), 0, 24, 'DATA_NUM', 'TA_BRANCH_FEE', 40);

INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 25, 'DATA_STR', 'TA_DEFAULT_LICENCE_RENEWAL_START', '1,8','The default yearly renewal start cycle in day month');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 26, 'DATA_STR', 'TA_DEFAULT_LICENCE_RENEWAL_END', '31,10','The default yearly renewal end cycle in day month');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 27, 'DATA_STR', 'TA_DEFAULT_LICENCE_RENEWAL_FYE_CUT', '31,3','The default yearly FYE cut off for renewal in day month');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 28, 'DATA_STR', 'TA_DEFAULT_LICENCE_RENEWAL_RECOMMENDED_MA', '30,6','The default yearly recommended MA for renewal in day month');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 29, 'DATA_NUM', 'TA_DEFAULT_LICENCE_RENEWAL_MA_DUE_DAYS', 28,'The default number of days given to submit MA for renewal');

INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 30, 'DATA_NUM', 'TA_SHORTFALL_DEFAULT_NO_OF_DAYS', '28','The default no of days require to rectify shortfall for TA once STB approve');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 31, 'DATA_STR', 'TA_SHORTFALL_MAX_SUBMISSION_DATE_MONTH_DAY', '12,21','The max submission date month day for shortfall to be rectify');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 32, 'DATA_NUM', 'TA_SHORTFALL_SUBMISSION_DATE_DIFFER', '7','The differ between rectification due date and max date for shortfall to be rectify');

INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 33, 'DATA_NUM', 'TA_RENEWAL_SHORTFALL_NICHE', '15000','The renewal shortfall criteria for niche licences');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 34, 'DATA_NUM', 'TA_RENEWAL_SHORTFALL_GENERAL', '30000','The renewal shortfall criteria for general licences');

INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value)  VALUES (0, 'SYSTEM', NOW(), 0, 35, 'DATA_NUM', 'TG_MLPT_FEE', '50');

INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 36, 'DATA_STR', 'TA_SUPPORT_EMAIL', 'stb_ta@stb.gov.sg', 'TA support email');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 37, 'DATA_STR', 'TG_SUPPORT_EMAIL', 'stb_tourist_guide@stb.gov.sg', 'TG support email');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 38, 'DATA_STR', 'STB_ORGANISATION', 'Singapore Tourism Board', 'Organisation name');

INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 39, 'DATA_NUM', 'TG_WORKPASS_EXPIRY_DAYS_TO_ALERT', '14', 'Number of days to alert TG officers before the work pass expired.');

INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 40, 'DATA_NUM', 'TA_EXTENSION_SHORTFALL_NICHE', '15000','The extension shortfall criteria for niche licences');
INSERT INTO system_parameters (version, createdBy, createdDate, isEditable, ordinal, dataTypeCode, code, value, description)  VALUES (0, 'SYSTEM', NOW(), 0, 41, 'DATA_NUM', 'TA_EXTENSION_SHORTFALL_GENERAL', '30000','The extension shortfall criteria for general licences');