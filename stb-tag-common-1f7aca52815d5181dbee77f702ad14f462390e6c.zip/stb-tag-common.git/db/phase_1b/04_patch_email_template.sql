DELETE FROM email_templates WHERE code = 'TA_LICENCE_RENEWAL_APPROVAL';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TA_LICENCE_RENEWAL_APPROVAL'
	, 'Your Travel Agent Licence Renewal Submission has been approved'
	, 'TA''s Notification Email for approval of TA Licence Renewal Submission'
	, '<p>Dear ${ta_name}
<p><br>
<p>Submission for ${app_type} (ref no: ${app_ref}) has been approved.  <p>
<p>Please login to the TRUST portal using the link below to make a payment of S$${app_amount} for the licence renewal fee.
<p><br>
<p><center><a href="${app_link}">Login Here</a></center>
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');