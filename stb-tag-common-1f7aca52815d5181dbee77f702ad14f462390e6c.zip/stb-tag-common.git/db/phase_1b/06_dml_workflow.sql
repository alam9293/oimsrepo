UPDATE types SET isActive = true where code='TA_APP_NET_VALUE_RECTIFICATION';

-- WARNING: PRODUCTION DATA PATCH: Patch existing workflow_actions (verify). Remove typeCode='...' will do mass update
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_CESSATION');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_CREATION');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_RENEWAL');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_AA_SUBMISSION');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_ABPR_SUBMISSION');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_COMPANY_UPDATE');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_BRANCH');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_FY_UPDATE');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_ASSIGN');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_REASSIGN');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_RESIGN');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_UPD_DETAILS');

SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_PERSON_UPDATE');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_REPLACEMENT');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_REINSTATEMENT');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_RENEWAL');
SELECT * FROM workflow_actions wa WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_CREATION');

update workflow_actions wa set wa.typeCode='WKFLW_ACT_APPR' where wa.statusCode in ('TA_APP_APPR', 'TG_APP_APPR') and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_REJ' where wa.statusCode in ('TA_APP_REJ', 'TG_APP_REJ') and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_RFA' where wa.statusCode in ('TA_APP_RFA', 'TG_APP_RFA') and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.statusCode in ('TA_APP_COM') and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.statusCode in ('TA_APP_PA', 'TG_APP_PA') and wa.createdBy not like 'stb_%' and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_NOTE' where wa.statusCode = 'TA_APP_PA' and wa.prevStatusCode='TA_APP_PA' and wa.createdBy like 'stb_%' and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_NOTE' where wa.statusCode = 'TG_APP_PA' and wa.prevStatusCode='TG_APP_PA' and wa.createdBy like 'stb_%' and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.createdBy like 'stb_%' and wa.statusCode='TA_APP_PA' and wa.prevStatusCode is null and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.createdBy like 'stb_%' and wa.statusCode='TA_APP_PA' and wa.prevStatusCode = 'TA_APP_RFA' and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.statusCode='TG_APP_PEND_PO' and wa.prevStatusCode is null and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.statusCode='TG_APP_PEND_PO' and wa.prevStatusCode = 'TG_APP_RFA' and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.statusCode='TA_APP_PEND_PO' and wa.prevStatusCode is null and wa.typeCode is null;
update workflow_actions wa set wa.typeCode='WKFLW_ACT_SUBM' where wa.statusCode='TA_APP_PEND_PO' and wa.prevStatusCode = 'TA_APP_RFA' and wa.typeCode is null;

update applications a left join workflow_actions b on a.lastActionId = b.id set a.assigneeId = (SELECT u.id FROM users u where u.loginId='stb_jeremyk')
where a.typeCode = 'TG_APP_CREATION' and b.statusCode in ('TG_APP_PA', 'TG_APP_PEND_PO') and a.assigneeId is null;

update applications a left join workflow_actions b on a.lastActionId = b.id set a.assigneeId = (SELECT u.id FROM users u where u.loginId='stb_tzeserno')
where a.typeCode = 'TG_APP_PERSON_UPDATE' and b.statusCode in ('TG_APP_PA', 'TG_APP_PEND_PO') and a.assigneeId is null;

update applications a left join workflow_actions b on a.lastActionId = b.id set a.assigneeId = (SELECT u.id FROM users u where u.loginId='stb_huikhimt')
where a.typeCode = 'TG_APP_REINSTATEMENT' and b.statusCode in ('TG_APP_PA', 'TG_APP_PEND_PO') and a.assigneeId is null;

update applications a left join workflow_actions b on a.lastActionId = b.id set a.assigneeId = (SELECT u.id FROM users u where u.loginId='stb_huikhimt')
where a.typeCode = 'TG_APP_RENEWAL' and b.statusCode in ('TG_APP_PA', 'TG_APP_PEND_PO') and a.assigneeId is null;

update applications a left join workflow_actions b on a.lastActionId = b.id set a.assigneeId = (SELECT u.id FROM users u where u.loginId='stb_tzeserno')
where a.typeCode = 'TG_APP_REPLACEMENT' and b.statusCode in ('TG_APP_PA', 'TG_APP_PEND_PO') and a.assigneeId is null;

-- WARNING: PRODUCTION DATA PATCH: Patch existing workflow_actions (patch). Remove typeCode='...' will do mass update
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_CESSATION');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_CREATION');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_RENEWAL');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_AA_SUBMISSION');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_ABPR_SUBMISSION');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_COMPANY_UPDATE');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_BRANCH');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_FY_UPDATE');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_ASSIGN');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_REASSIGN');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_RESIGN');
UPDATE workflow_actions wa SET wa.statusCode = 'TA_APP_PEND_PO' WHERE wa.statusCode = 'TA_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TA_APP_KE_UPD_DETAILS');

UPDATE workflow_actions wa SET wa.statusCode = 'TG_APP_PEND_PO' WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_PERSON_UPDATE');
UPDATE workflow_actions wa SET wa.statusCode = 'TG_APP_PEND_PO' WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_REPLACEMENT');
UPDATE workflow_actions wa SET wa.statusCode = 'TG_APP_PEND_PO' WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_REINSTATEMENT');
UPDATE workflow_actions wa SET wa.statusCode = 'TG_APP_PEND_PO' WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_RENEWAL');
UPDATE workflow_actions wa SET wa.statusCode = 'TG_APP_PEND_PO' WHERE wa.statusCode = 'TG_APP_PA' and wa.id = (select lastActionid from applications where id = wa.applicationId and typeCode = 'TG_APP_CREATION');

-- P1B Roles
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) values ('TA Head of Department', 'TA_HOD', 0, 1, 1, 0);
INSERT INTO roles (label, code, ordinal, isAssignable, isConfigurable, version) values ('TG Head of Department', 'TG_HOD', 0, 1, 1, 0);

-- Duplicate all TA_AO's functions to TA_HOD
insert into role$functions (roleCode, functionsCode)
(select 'TA_HOD', rf.functionsCode
from role$functions rf where rf.roleCode = 'TA_AO') ;

SET FOREIGN_KEY_CHECKS=0;
SET SQL_SAFE_UPDATES = 0;
UPDATE roles SET code='HODIV', label='Head of Division' where code='TA_HODIV';
UPDATE role$functions set roleCode='HODIV' where roleCode='TA_HODIV';
UPDATE user$roles set rolesCode='HODIV' where rolesCode='TA_HODIV';
SET SQL_SAFE_UPDATES = 1;
SET FOREIGN_KEY_CHECKS=1;

-- P1B C&E assignments
UPDATE users set taAssigneechars = '0 1 2 3 4 5 6 7 8 9 A B C D E F G H I' where loginId = 'stb_janetf';
UPDATE users set taAssigneechars = 'J K L M N O P' where loginId = 'stb_seowhwang';
UPDATE users set taAssigneechars = 'Q R S T' where loginId = 'stb_brendal';
UPDATE users set taAssigneechars = 'U V W X Y Z' where loginId = 'stb_alvinl';

-- P1B HOD and HODIV assignments
delete from user$roles where userId in (select id from users where loginId = 'stb_deynac');
insert into user$roles (userId, rolesCode) values ((select id from users where loginId = 'stb_deynac'), 'TA_HOD');
update users set taAssigneechars = '0 1 2 3 4 5 6 7 8 9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z' where loginId = 'stb_deynac';
update users set taAssigneechars = '0 1 2 3 4 5 6 7 8 9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z' where loginId = 'stb_lingleeo';

-- Clear All Existing Workflow Configuration
-- DELETE FROM workflow_step_assignments;
-- DELETE FROM workflow_configs;
-- DELETE FROM workflow_steps;

-- TG Application Workflow Steps
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (1, 'TG_PO', 'TG_APP_PEND_PO', 'WKFLW_STEP_TG_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (2, 'TG_AO', 'TG_APP_PEND_AO', 'WKFLW_STEP_TG_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (3, 'HODIV', 'TG_APP_PEND_HODIV', 'WKFLW_STEP_TG_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TG Workflow Steps
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (1, 'TG_PO', 'TG_WKFLW_PEND_PO', 'WKFLW_STEP_TG', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (2, 'TG_AO', 'TG_WKFLW_PEND_AO', 'WKFLW_STEP_TG', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (3, 'HODIV', 'TG_WKFLW_PEND_HODIV', 'WKFLW_STEP_TG', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TA Application Workflow Steps
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (1, 'TA_PO', 'TA_APP_PEND_PO', 'WKFLW_STEP_TA_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (2, 'TA_VO', 'TA_APP_PEND_VO', 'WKFLW_STEP_TA_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (3, 'CNE_CO', 'TA_APP_PEND_CNE_CO', 'WKFLW_STEP_TA_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (4, 'TA_AO', 'TA_APP_PEND_AO', 'WKFLW_STEP_TA_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (5, 'TA_HOD', 'TA_APP_PEND_HOD', 'WKFLW_STEP_TA_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (6, 'HODIV', 'TA_APP_PEND_HODIV', 'WKFLW_STEP_TA_APP', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TA Workflow Steps
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (1, 'TA_PO', 'TA_WKFLW_PEND_PO', 'WKFLW_STEP_TA', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (2, 'TA_VO', 'TA_WKFLW_PEND_VO', 'WKFLW_STEP_TA', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (3, 'TA_AO', 'TA_WKFLW_PEND_AO', 'WKFLW_STEP_TA', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (4, 'TA_HOD', 'TA_WKFLW_PEND_HOD', 'WKFLW_STEP_TA', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, roleCode, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (5, 'HODIV', 'TA_WKFLW_PEND_HODIV', 'WKFLW_STEP_TA', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TA Workflows - Application
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_CREATION', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HODIV'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_BRANCH', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_TIER_SWITCH', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HODIV'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_CESSATION', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_REPLACEMENT', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_COMPANY_UPDATE', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_FY_UPDATE', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_AA_SUBMISSION', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_ABPR_SUBMISSION', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_RENEWAL', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_MA_SUBMISSION', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_NET_VALUE_RECTIFICATION', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_CREATION_IPA', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_KE_ASSIGN', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_KE_REASSIGN', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_KE_RESIGN', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_APP_KE_UPD_DETAILS', (SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TA Workflows - Workflow Case
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_WKFLW_RENEW_EX', (SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_WKFLW_SHORTFALL', (SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_WKFLW_EXTENSION_PREM', (SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_VO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TA_WKFLW_EXTENSION_DETL', (SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_HOD'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TG Workflows
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_CREATION', (SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_PERSON_UPDATE', (SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_REINSTATEMENT', (SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_RENEWAL', (SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_REPLACEMENT', (SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_MRC_SUBMISSION', false, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_PDC_SUBMISSION', false, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_CANCELLATION', false, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_configs (appOrWkflwTypeCode, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('TG_APP_MLPT_REGISTRATION', false, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- TA workflow_step_assignments
-- Licence Creation
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HODIV'));

-- Licence Creation (Approved IPA)
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CREATION_IPA'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CREATION_IPA'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CREATION_IPA'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Switch of Licence Tier
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_TIER_SWITCH'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_TIER_SWITCH'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_TIER_SWITCH'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_TIER_SWITCH'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HODIV'));

-- Licence Cessation
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CESSATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CESSATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_CESSATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Licence Renewal
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_RENEWAL'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_RENEWAL'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_RENEWAL'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Licence Replacement
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_REPLACEMENT'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_REPLACEMENT'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_REPLACEMENT'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Change of Financial Year End
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_FY_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_FY_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_FY_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Business Entity Details Update
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_COMPANY_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_COMPANY_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_COMPANY_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Key Executive New Assignment
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_ASSIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_ASSIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_ASSIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Key Executive Re-Assignment
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_REASSIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_REASSIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_REASSIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Key Executive Resignation
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_RESIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_RESIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_RESIGN'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Key Executive Particulars Update
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_UPD_DETAILS'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_UPD_DETAILS'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_KE_UPD_DETAILS'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- Branch Licence
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_BRANCH'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_BRANCH'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_BRANCH'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- AA Submission
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_AA_SUBMISSION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_AA_SUBMISSION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));

-- ABPR Submission
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_ABPR_SUBMISSION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_ABPR_SUBMISSION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));

-- MA Submission
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_MA_SUBMISSION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_MA_SUBMISSION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_VO'));

-- Rectification of Net Value Shortfall
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_NET_VALUE_RECTIFICATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_CNE_CO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_APP_NET_VALUE_RECTIFICATION'),(SELECT id from workflow_steps where startStatusCode = 'TA_APP_PEND_HOD'));

-- TA Licence Renewal Exercise
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_RENEW_EX'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_RENEW_EX'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_HOD'));

-- TA Net Value Shortfall
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_SHORTFALL'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_SHORTFALL'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_HOD'));

-- TA Filing AA/ABPR Extension Preliminary Risk Assessment
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_EXTENSION_PREM'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_EXTENSION_PREM'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_VO'));

-- TA Filing AA/ABPR Extension Detailed Risk Assessment 
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_EXTENSION_DETL'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_PO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_EXTENSION_DETL'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_VO'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TA_WKFLW_EXTENSION_DETL'),(SELECT id from workflow_steps where startStatusCode = 'TA_WKFLW_PEND_HOD'));


-- TG workflow_step_assignments
-- Licence Creation
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_PO'), (SELECT id FROM users where loginId='stb_jeremyk'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_CREATION'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), (SELECT id FROM users where loginId='stb_pangel'));

-- Person Update
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_PERSON_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_PO'), (SELECT id FROM users where loginId='stb_tzeserno'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_PERSON_UPDATE'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), (SELECT id FROM users where loginId='stb_pangel'));

-- Licence Reinstatement
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_REINSTATEMENT'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_PO'), (SELECT id FROM users where loginId='stb_huikhimt'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_REINSTATEMENT'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), (SELECT id FROM users where loginId='stb_choonkiat'));

-- Licence Renewal
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_RENEWAL'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_PO'), (SELECT id FROM users where loginId='stb_huikhimt'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_RENEWAL'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), (SELECT id FROM users where loginId='stb_pangel'));

-- Licence Replacement
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_REPLACEMENT'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_PO'), (SELECT id FROM users where loginId='stb_tzeserno'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, workflowConfigId, workflowStepId, userId) VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM workflow_configs where appOrWkflwTypeCode='TG_APP_REPLACEMENT'),(SELECT id from workflow_steps where startStatusCode = 'TG_APP_PEND_AO'), (SELECT id FROM users where loginId='stb_pangel'));
