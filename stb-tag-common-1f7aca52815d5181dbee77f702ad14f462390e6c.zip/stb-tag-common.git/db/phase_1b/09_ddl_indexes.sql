-- Add year column to save the year of renewal start date for renewnal year drop down
ALTER TABLE ta_licence_renewal_exercises ADD INDEX year (year ASC) VISIBLE;

create index applicationNo on applications(applicationNo);
create index refNo on payment_requests(refNo);
create index fy on ta_filing_conditions(fy);
