UPDATE statuses SET otherLabel = 'Pending Payment' WHERE (code = 'PAYREQ_N');
UPDATE `types` SET label = 'Licence Cessation' WHERE (code = 'TA_APP_CESSATION');
UPDATE email_templates SET subject = 'Your ${app_type} Submission has been approved.' WHERE (code = 'TA_UPON_APPROVAL');
UPDATE email_templates SET subject = 'Your ${app_type} Submission has been rejected.' WHERE (code = 'TA_UPON_REJECTION');
UPDATE email_templates SET subject = 'Your ${app_type} Submission has been returned for your action.' WHERE (code = 'TA_UPON_RFA');
UPDATE types set label = 'Rectification of Net Value Shortfall', isActive = 1 where code = 'TA_APP_NET_VALUE_RECTIFICATION';

UPDATE statuses SET otherLabel = 'Returned for your action' WHERE (code = 'TA_APP_RFA');

UPDATE types SET label = 'TG MLPT Badge Amendment Fee' WHERE (code = 'PAYREQ_TG_MLPT');

UPDATE `statuses` SET `otherLabel` = 'Returned for Action' WHERE (`code` = 'TG_APP_RFA');
UPDATE `statuses` SET `otherLabel` = 'Rejected' WHERE (`code` = 'TG_APP_REJ');
UPDATE `statuses` SET `otherLabel` = 'Approved' WHERE (`code` = 'TG_APP_APPR');

UPDATE types SET label = 'TG Personal Particulars Update' where code='TG_APP_PERSON_UPDATE';
UPDATE statuses SET isActive = 0 where code='TA_APP_PA';
UPDATE statuses SET isActive = 0 where code='TG_APP_PA';

update statuses set label='CPF medisave service currently is not available' where code='CPF_MEDI_E';