update files set path = REPLACE(path, '/workflow/', '/workflow-action/');
update files set path = REPLACE(path, 'upload/workflow/', 'upload/workflow-action/');
--  change the folder from workflow to workflow-action