DELETE FROM email_templates WHERE code = 'CNE_UPON_TA_SUBMISSION_APPROVAL';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'CNE_UPON_TA_SUBMISSION_APPROVAL'
	, 'Submission for ${app_type} has been approved'
	, 'Email notification for TA submission upon approval (C&E related)'
	, '<p>Dear ${ke_name},
<p><br>
<p>We are pleased to inform that your submission for ${app_type} (ref no: ${app_ref}) on ${app_submission_date} has been approved.
<p><br>
<p>You may <a href="${app_link}">login here</a> to access your submission.
<p><br>
<p>Regards,
<br>${officer_name}
<br>${officer_department}
<br>${stb_organisation}
<br>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:${ta_support_email}">${ta_support_email}</a> for any queries.***');