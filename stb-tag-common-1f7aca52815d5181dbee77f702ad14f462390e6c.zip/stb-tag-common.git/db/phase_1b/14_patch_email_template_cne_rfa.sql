DELETE FROM email_templates WHERE code = 'CNE_UPON_TA_SUBMISSION_RFA';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'CNE_UPON_TA_SUBMISSION_RFA'
	, 'Submission for ${app_type} is returned for your action'
	, 'Email notification for TA submission upon RFA (C&E related)'
	, '<p>Dear ${ke_name},
<p><br>
<p>Your submission for ${app_type} (ref no: ${app_ref}) on ${app_submission_date} is returned for your action.
<p><br>
<p>You may <a href="${app_link}">login here</a> to view the action required to complete the rectification of net value shortfall.
<p><br>
<p>Regards,
<br>${officer_name}
<br>${officer_department}
<br>${stb_organisation}
<br>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:${ta_support_email}">${ta_support_email}</a> for any queries.***');