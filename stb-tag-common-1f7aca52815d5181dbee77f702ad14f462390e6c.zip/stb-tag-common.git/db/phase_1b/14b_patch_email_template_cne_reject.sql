DELETE FROM email_templates WHERE code = 'CNE_RECT_SHORTFALL_UPON_REJECT';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'CNE_RECT_SHORTFALL_UPON_REJECT'
	, 'Rectification of Net Value Shortfall'
	, 'Email notification for TA rectification of net value shortfall submission upon rejection'
	, '<p>Dear ${ke_name},
<p><br>
<p>We would like to inform you that your submission to provide proof of shortfall rectification (ref no: ${app_ref}) on ${app_submission_date} did not contain sufficient proof that you have fulfilled the minimum financial requirement.
<p><br>
<p>You are still required to fulfil the net value shortfall by ${rectification_due_date}. Please <a href="${app_link}">login here</a> to re-submit proof of net value shortfall rectification.
<p><br>
<p>Regards,
<br>${officer_name}
<br>${officer_department}
<br>${stb_organisation}
<br>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:${ta_support_email}">${ta_support_email}</a> for any queries.***');