DELETE FROM email_templates WHERE code = 'TG_MLPT_SLOT_ALLOCATED';
DELETE FROM email_templates WHERE code = 'TG_MLPT_SLOT_RESULT';

INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_MLPT_SLOT_ALLOCATED'
	, 'Multi-Language Proficiency Test – Schedule/Details'
	, 'Email to TG after STB officer has allocated the schedule'
	, '<p>Dear ${tg_name},
<p><br>
<p>Thank you for registering for the Multi-Language Proficiency Test (MLPT). 
<p><br>
<p>${mlpt_allocations}
<p><br>
<p>Please report to the Singapore Tourism Board (Tourism Court, 1 Orchard Spring Lane, Singapore 247729) Level 2 Lobby Area, at least 15 minutes before your assigned test time.  Please bring along your NRIC/ workpass and wear your TG badge during the test.
<p><br>
<p>For MLPT, the candidate will be assessed on the following criteria, and need to achieve more than 60% to pass.
<p><br>
<p><table border="1" cellpadding="5">
  <tr>
    <th>Criteria</th>
    <th>Weightage</th> 
  </tr>
  <tr>
    <td>Language Proficiency</td>
    <td>70%</td>
  </tr>
  <tr>
    <td>Product Knowledge</td>
    <td>20%</td>
  </tr>
  <tr>
    <td>Professionalism</td>
    <td>10%</td>
  </tr>
  <tr>
    <td><b>TOTAL</b></td>
    <td><b>100%</b></td>
  </tr>
</table>
<p><br>
<p>For any clarification, please email stb_tourist_guide@stb.gov.sg. Thank you and have a great day!
<p><br>
<p>Best Regards,
<br>Tourist Guide Licensing Department
<br>Singapore Tourism Board');

INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_MLPT_SLOT_RESULT'
	, 'Multi-Language Proficiency Test – Result/Next Steps'
	, 'Email to TG of the MLPT result'
	, '<p>Dear ${tg_name},
<p><br>
<p>Thank you for attending the Multi-Language Proficiency Test (MLPT).
<p><br>
<p>${mlpt_results}
<p><br>
<p>For any clarification, please email stb_tourist_guide@stb.gov.sg.
<p><br>
<p>Best Regards,
<br>Tourist Guide Licensing Department
<br>Singapore Tourism Board');