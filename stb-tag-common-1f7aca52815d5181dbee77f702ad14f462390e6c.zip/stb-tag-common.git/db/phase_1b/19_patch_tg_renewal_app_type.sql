update applications set typeCode = 'TG_APP_REINSTATEMENT' where id in
(select applicationId from tg_licence_renewals where typeCode = 'TG_REINSTATE');