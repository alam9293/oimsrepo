DELETE FROM email_templates WHERE code = 'TG_APPLY_MLPT';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body)
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'TG_APPLY_MLPT'
	, 'Multi-Language Proficiency Test - Successful Registration'
	, 'TG''s MLPT Registration Notification Email'
	, '<p>Dear ${tg_name}
<p><br>You have successfully registered for the Multi Language Proficiency Test (MLPT) from ${mlpt_start_date} to ${mlpt_end_date} (tentative), for the following language(s):
<ol>${tg_test_language}</ol>
<p>An email, containing details of the MLPT, will be sent approximately 2 weeks before the test.
<p>The MLPT is conducted orally, where three slides on Singapore''s tourism offerings, such as cultural festivals,
food or places of interest will be shown. The candidate will be required to simulate guiding based on the slides shown in the chosen test language.
Questions may be posed by assessors and the MLPT is expected to take not more than 30 minutes.
<p>For any clarification, please email stb_tourist_guide@stb.gov.sg. Thank you and have a great day!
<p><br>Regards,
<br>Tourist Guide Licensing Department
<br>Singapore Tourism Board');
