DELETE FROM email_templates WHERE code = 'CNE_UPON_SHORTFALL_EXTENSION_APPROVAL';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'CNE_UPON_SHORTFALL_EXTENSION_APPROVAL'
	, 'Request for Extension to Rectify Net Value Shortfall has been approved'
	, 'Email notification for TA upon rectification of shortfall extension is approved'
	, '<p>Dear ${ke_name},
<p><br>
<p>We would like to inform you that your request for extension to rectify net value shortfall has been approved.
<p><br>
<p>You may <a href="${app_link}">login here</a> to complete the rectification of net value shortfall.
<p><br>
<p>Regards,
<br>${officer_name}
<br>${officer_department}
<br>${stb_organisation}
<br>
<p>*** Please do not reply to this email as it is a computer-generated message. You may reach us at <a href="mailto:${ta_support_email}">${ta_support_email}</a> for any queries.***');