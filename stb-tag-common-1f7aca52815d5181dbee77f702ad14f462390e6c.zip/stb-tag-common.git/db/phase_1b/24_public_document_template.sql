insert into files (createdBy, createdDate, updatedBy, updatedDate, version, description, extension, filename, isDeleted, originalFileName, path, size)
values ('system', now(), 'system', now(), 0, 'Financial statement', 'xlsx', 'Financial statement template.xlsx', 0, 'Financial statement template.xlsx', 'templates/', '22450');

insert into document_templates (createdBy, createdDate, updatedBy, updatedDate, version, fileId, typeCode)
values ('system', now(), 'system', now(), 0, (select id from files where filename = 'Financial statement template.xlsx' and path = 'templates/'), 'TA_DOC_MANAGEMENT_ACCOUNTS');