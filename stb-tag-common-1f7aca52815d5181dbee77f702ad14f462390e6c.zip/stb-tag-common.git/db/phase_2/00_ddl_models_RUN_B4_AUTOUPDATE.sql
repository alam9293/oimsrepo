-- run this before auto-update, else it will fail 
ALTER TABLE workflow_steps CHANGE COLUMN designation purpose VARCHAR(255) NULL DEFAULT NULL;
ALTER TABLE system_parameters CHANGE COLUMN value value VARCHAR(5000) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL ;
ALTER TABLE email_logs MODIFY COLUMN receiver text;
