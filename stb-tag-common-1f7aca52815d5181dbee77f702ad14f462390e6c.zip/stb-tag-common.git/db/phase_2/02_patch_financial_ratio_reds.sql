update ta_aa_submissions set isNetProfitMarginRed = (netProfitMargin < -0.02);
update ta_aa_submissions set isQuickRatioRed = (quickRatio < 0.8);
update ta_aa_submissions set isDebtEquityRatioRed = (debtEquityRatio < 0 or debtEquityRatio > 3);
update ta_aa_submissions set isProfitScRatioRed = (profitScRatio < -0.75);
update ta_aa_submissions set noOfReds = (isNetProfitMarginRed + isQuickRatioRed + isDebtEquityRatioRed + isProfitScRatioRed);