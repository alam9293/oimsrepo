drop table IF exists ce_ta_check_schedulable_items ;
CREATE OR REPLACE VIEW ce_ta_check_schedulable_items AS
select 
	taAddr.addressId as addressId,
	ta.id as travelAgentId,
	lic.id as licenceId,
    taAddr.branchId as taBranchId,
    aaFiling.id as lastAaFilingId,
    aaApp.id as lastAaApplicationId,
    abprFiling.id as lastAbprFilingId,
    abpr.id as abprSubmissionId,
    abprApp.id as abprApplicationId,
    taAddr.lastTatiCheckId,
	ta.name as taName,
    ta.uen,
    lic.licenceNo,
    taAddr.block,
    taAddr.floorUnit,
    taAddr.building,
    taAddr.street,
    taAddr.postal,
    taAddr.premiseTypeCode,
    taAddr.addressTypeCode,    
    aa.noOfReds,
    aaFiling.statusCode as lastAaFilingStatusCode,
    aaFiling.fyEndDate lastAaFilingFyEndDate,
    lic.ceasedDate as licenceCeasedDate,
    lic.expiryDate as licenceExpiryDate,
    lic.statusCode as licenceStatusCode,
    taAddr.branchStatusCode as branchStatusCode, 
    case 
		when abpr.inboundOp > 0 and abpr.outboundOp > 0 then 'TA_SERVICE_BOTH'
		when abpr.inboundOp > 0 then 'TA_SERVICE_INBOUND' 
        when abpr.outboundOp > 0 then 'TA_SERVICE_OUTBOUND'
	END as serviceTypeCode,
    taAddr.lastTatiCheckIsCompliantCode,
    taAddr.lastTatiCheckDate,
    taAddr.lastCheckDone
from travel_agents ta 
	join licences lic on lic.id = ta.licenceId    
	left join (
		select
			ta.id as travelAgentId,
			regAddr.id as addressId,
            regAddr.block,
            concat('#', concat(concat(regAddr.floor, '-'),regAddr.unit)) as floorUnit,
			regAddr.building,
			regAddr.street,
			regAddr.postal,
			regAddr.premiseTypeCode, 
			'TA_ADDR_REG' as addressTypeCode,
			null as branchStatusCode,
            null as branchId,
            ta.lastRegAddrTaCheckId as lastTatiCheckId,
            tatiCheck.isCompliantCode as lastTatiCheckIsCompliantCode,
            tatiCheck.checkedDate as lastTatiCheckDate,
            ta.isLastRegAddrCheckDone as lastCheckDone
		from travel_agents ta
			join addresses regAddr on regAddr.id = ta.registeredAddressId
            left join ce_ta_checks tatiCheck on tatiCheck.id = ta.lastRegAddrTaCheckId
		where tatiCheck.id is null or tatiCheck.isDraft = false
		union
		select 
			ta.id as travelAgentId,
			opAddr.id as addressId,
            opAddr.block,
            concat('#', concat(concat(opAddr.floor, '-'),opAddr.unit)) as floorUnit,
			opAddr.building,
			opAddr.street,
			opAddr.postal,
			opAddr.premiseTypeCode, 
			'TA_ADDR_OP' as addressType,
			null as branchStatusCode,
            null as branchId,
            ta.lastOpAddrTaCheckId as lastTatiCheckId,
            tatiCheck.isCompliantCode as lastTatiCheckIsCompliantCode,
            tatiCheck.checkedDate as lastTatiCheckDate,
            ta.isLastOpAddrCheckDone as lastCheckDone
		from travel_agents ta 
			join addresses opAddr on opAddr.id = ta.operatingAddressId
            left join ce_ta_checks tatiCheck on tatiCheck.id = ta.lastOpAddrTaCheckId
		where tatiCheck.id is null or tatiCheck.isDraft = false
		union
		select 
			ta.id as travelAgentId,
			brAddr.id as addressId,
            brAddr.block,
            concat('#', concat(concat(brAddr.floor, '-'),brAddr.unit)) as floorUnit,
			brAddr.building,
			brAddr.street,
			brAddr.postal,
			brAddr.premiseTypeCode, 
			'TA_ADDR_BRANCH' as addressType,
			tab.statusCode as branchStatusCode,
            tab.id as branchId,
            tab.lastTaCheckId as lastTatiCheckId,
            tatiCheck.isCompliantCode as lastTatiCheckIsCompliantCode,
            tatiCheck.checkedDate as lastTatiCheckDate,
            tab.isLastCheckDone as lastCheckDone
		from travel_agents ta 
			join licences lic on lic.id = ta.licenceId
			join ta_branches tab on tab.licenceId = lic.id
			join addresses brAddr on brAddr.id = tab.addressId
            left join ce_ta_checks tatiCheck on tatiCheck.id = tab.lastTaCheckId
		where tatiCheck.id is null or tatiCheck.isDraft = false
	) as taAddr on taAddr.travelAgentId = ta.id
	left join (
		select 
			lic.travelAgentId,
			max(fyEndDate) as lastFyEndDate
		from ta_filing_conditions aaFiling 
        join licences lic on lic.id = aaFiling.licenceId
		where aaFiling.applicationTypeCode = 'TA_APP_AA_SUBMISSION' and aaFiling.statusCode != 'TA_FILING_VOID'
		group by lic.travelAgentId
	) as lastAa on lastAa.travelAgentId = ta.id
	left join (
		select 
			lic.travelAgentId,
			aaFiling.id,			
            aaFiling.fyEndDate,
            aaFiling.statusCode
        from ta_filing_conditions aaFiling 
			join licences lic on lic.id = aaFiling.licenceId
        where aaFiling.applicationTypeCode = 'TA_APP_AA_SUBMISSION' and aaFiling.statusCode != 'TA_FILING_VOID'
	) as aaFiling on aaFiling.travelAgentId = ta.id and aaFiling.fyEndDate = lastAa.lastFyEndDate
	left join ta_aa_submissions aa on aa.taAnnualFilingId = aaFiling.id 
	left join applications aaApp on aaApp.id = aa.applicationId
	left join workflow_actions aaWa on aaWa.id = aaApp.lastActionId
	left join (
		select 
			lic.travelAgentId,
			max(fyEndDate) as lastFyEndDate
		from ta_abpr_submissions abpr
			join ta_filing_conditions abprFiling on abprFiling.id = abpr.taAnnualFilingId
            join licences lic on lic.id = abprFiling.licenceId
			join applications app on app.id = abpr.applicationId
			join workflow_actions wa on wa.id = app.lastActionId
			where app.isDraft = 0 and wa.statusCode is not null and wa.statusCode != 'TA_APP_REJ' and abprFiling.statusCode != 'TA_FILING_VOID'
		group by lic.travelAgentId
	) as lastAbpr on lastAbpr.travelAgentId = ta.id
    left join (
		select 
			lic.travelAgentId,
			max(abprFiling.id) as id,			
            abprFiling.fyEndDate,
            abprFiling.statusCode
        from ta_filing_conditions abprFiling 
			join licences lic on lic.id = abprFiling.licenceId
        where abprFiling.applicationTypeCode = 'TA_APP_ABPR_SUBMISSION' and abprFiling.statusCode != 'TA_FILING_VOID'
		group by abprFiling.fyEndDate, abprFiling.statusCode, lic.travelAgentId
	) as abprFiling on abprFiling.travelAgentId = ta.id and abprFiling.fyEndDate = lastAbpr.lastFyEndDate
	left join ta_abpr_submissions abpr on abpr.taAnnualFilingId = abprFiling.id
	left join applications abprApp on abprApp.id = abpr.applicationId
	left join workflow_actions abprWa on abprWa.id = abprApp.lastActionId 
WHERE (abprApp.id is null or (abprApp.isDraft = 0 && abprApp.isDeleted = 0)) and (abprWa.id is null or abprWa.statusCode != 'TA_APP_REJ') 
and (aaApp.id is null or (aaApp.isDeleted = 0 and aaApp.isDraft = 0)) and (aaWa.id is null or aaWa.statusCode != 'TA_APP_REJ') ;
