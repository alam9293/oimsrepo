-- assign TG_HOD to Choon Kiat --
insert into user$roles (rolesCode, userId) values('TG_HOD', (select id from users where loginId = 'stb_choonkiat'));
insert into role$functions(roleCode, functionsCode)values('TG_HOD', 'PAY_REQ_VW');
insert into role$functions(roleCode, functionsCode)values('TG_HOD', 'PAY_TXN_VW');
-- Refactor workflow actions access right
delete from role$functions where functionsCode ='WKFLOW_LOG_TA_VW';
delete from functions where code = 'WKFLOW_LOG_TA_VW';

-- CE Workflow Workflow Steps
INSERT INTO workflow_steps (level, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (1, 'CE_WKFLW_PEND_SUPP', 'WKFLW_STEP_CE', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());
INSERT INTO workflow_steps (level, startStatusCode, typeCode, version, createdBy, createdDate, updatedBy,updatedDate) VALUES (2, 'CE_WKFLW_PEND_APPR', 'WKFLW_STEP_CE', 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- CE Workflow Step Roles
INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_SUPP'), 'TA_HOD');
INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_SUPP'), 'TG_HOD');
INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_SUPP'), 'CNE_IO');
INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_SUPP'), 'HODIV');

INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_APPR'), 'TA_HOD');
INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_APPR'), 'TG_HOD');
INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_APPR'), 'CNE_IO');
INSERT INTO workflow_step$roles (workflowStepId, rolesCode) VALUES ((SELECT id FROM workflow_steps WHERE startStatusCode='CE_WKFLW_PEND_APPR'), 'HODIV');

-- CE Workflow Configs
INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_SCHEDULE', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_SCHEDULE', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_CASE_TASK_RECOMMEND', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_CASE_TASK_DECISION', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_CASE_TASK_APPEAL', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_CASE_TASK_RESCIND', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_CASE_TASK_LIFT', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_IP_COMPO_IMPOSE', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TA_IP_COMPO_WAIVE', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_CASE_TASK_RECOMMEND', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_CASE_TASK_DECISION', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_CASE_TASK_APPEAL', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_CASE_TASK_RESCIND', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_CASE_TASK_LIFT', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_IP_COMPO_IMPOSE', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

INSERT INTO workflow_configs (appOrWkflwTypeCode, finalStepId, isConfigurable, version, createdBy, createdDate, updatedBy,updatedDate) VALUES ('CE_WKFLW_TG_IP_COMPO_WAIVE', (SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'), true, 0, 'SYSTEM', NOW(), 'SYSTEM', NOW());

-- Workflow Step Assignment
-- TA Scheduling
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_baharudeena' and statusCode = 'USER_A'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_SCHEDULE'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_SCHEDULE'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_deynac'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_RECOMMEND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_RECOMMEND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_deynac'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_DECISION'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_DECISION'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_deynac'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_APPEAL'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_APPEAL'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_deynac'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_RESCIND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_RESCIND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_deynac'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_LIFT'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_CASE_TASK_LIFT'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_deynac'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_IP_COMPO_IMPOSE'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_deynac'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TA_IP_COMPO_WAIVE'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_RECOMMEND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_RECOMMEND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_DECISION'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_DECISION'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_APPEAL'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_APPEAL'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_RESCIND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_RESCIND'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_LIFT'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_SUPP'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_kennethl'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_CASE_TASK_LIFT'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_IP_COMPO_IMPOSE'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));
INSERT INTO workflow_step_assignments (createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId) 
VALUES ('SYSTEM', NOW(),'SYSTEM', NOW(), 0, (SELECT id FROM users WHERE loginId='stb_choonkiat'), (SELECT id FROM workflow_configs where appOrWkflwTypeCode='CE_WKFLW_TG_IP_COMPO_WAIVE'),(SELECT id from workflow_steps where startStatusCode = 'CE_WKFLW_PEND_APPR'));

-- Payment Refund Workflow
insert into workflow_steps(createdBy, createdDate, updatedBy, updatedDate, version, level, startStatusCode, typeCode)
values('SYSTEM', now(), 'SYSTEM', now(),0,1,'PAY_WKFLW_PEND_APPR','WKFLW_STEP_PAY');

insert into workflow_configs(createdBy, createdDate, updatedBy, updatedDate, version, isConfigurable, appOrWkflwTypeCode, finalStepId)
values('SYSTEM', now(), 'SYSTEM', now(),0,1, 'PAY_WKFLW_REFUND_TA',(select id from workflow_steps where startStatusCode='PAY_WKFLW_PEND_APPR'));
insert into workflow_configs(createdBy, createdDate, updatedBy, updatedDate, version, isConfigurable, appOrWkflwTypeCode, finalStepId)
values('SYSTEM', now(), 'SYSTEM', now(),0,1, 'PAY_WKFLW_REFUND_TG',(select id from workflow_steps where startStatusCode='PAY_WKFLW_PEND_APPR'));

insert into workflow_step_assignments(createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId)
values('SYSTEM', now(), 'SYSTEM', now(),0,(select id from users where loginid='stb_deynac'), (select id from workflow_configs where appOrWkflwTypeCode='PAY_WKFLW_REFUND_TA'), (select id from workflow_steps where startStatusCode='PAY_WKFLW_PEND_APPR'));
insert into workflow_step_assignments(createdBy, createdDate, updatedBy, updatedDate, version, userId, workflowConfigId, workflowStepId)
values('SYSTEM', now(), 'SYSTEM', now(),0,(select id from users where loginid='stb_choonkiat'), (select id from workflow_configs where appOrWkflwTypeCode='PAY_WKFLW_REFUND_TG'), (select id from workflow_steps where startStatusCode='PAY_WKFLW_PEND_APPR'));
insert into workflow_step$roles(workflowStepId, rolesCode)values((select id from workflow_steps where startStatusCode='PAY_WKFLW_PEND_APPR'),'TA_HOD');
insert into workflow_step$roles(workflowStepId, rolesCode)values((select id from workflow_steps where startStatusCode='PAY_WKFLW_PEND_APPR'),'TG_HOD');
insert into workflow_step$roles(workflowStepId, rolesCode)values((select id from workflow_steps where startStatusCode='PAY_WKFLW_PEND_APPR'),'HODIV');

