-- trigger for generate TA and TG case no
DELIMITER //
DROP TRIGGER IF EXISTS case_no_before_insert;
CREATE TRIGGER case_no_before_insert
BEFORE INSERT
   ON ce_cases FOR EACH ROW
BEGIN
	DECLARE vMaxRef VARCHAR(255);
	DECLARE vMax INTEGER;
	DECLARE caseType VARCHAR(255);
	DECLARE vLength INTEGER;
	DECLARE year VARCHAR(255);
	
	SET year = YEAR(CURDATE());
	
	IF (NEW.isIp = 1) THEN
		SET caseType = "IP";
		SET vLength = 3;
		IF (NEW.taTgType LIKE "TA") THEN
			SET vMaxRef = "TA_IP_NO";
		ELSE
			SET vMaxRef = "TG_IP_NO";
		END IF;
	ELSE
		SET caseType = "CE";
		SET vLength = 5;
		IF (NEW.taTgType LIKE "TG") THEN
			SET vMaxRef = "TA_CASE_NO";
		ELSE
			SET vMaxRef = "TG_CASE_NO";
		END IF;
	END IF;
	
	SELECT value FROM system_parameters WHERE code LIKE vMaxRef INTO vMax;
			
	IF (EXISTS(SELECT 1 FROM ce_cases WHERE caseNo like CONCAT('STB/',caseType ,'/',NEW.taTgType ,'/', year ,'%'))) THEN
		SET NEW.caseNo = CONCAT('STB/',caseType ,'/',NEW.taTgType ,'/', year ,'/', LPAD( vMax, vLength, '0' ));
		UPDATE system_parameters SET value = (vMax+1) WHERE code LIKE vMaxRef;
	ELSE
		SET NEW.caseNo = CONCAT('STB/',caseType ,'/',NEW.taTgType ,'/', year ,'/', LPAD( 1, vLength, '0' ));
		UPDATE system_parameters SET value = 2 WHERE code LIKE vMaxRef;
	END IF;
	
END; //
DELIMITER ;

