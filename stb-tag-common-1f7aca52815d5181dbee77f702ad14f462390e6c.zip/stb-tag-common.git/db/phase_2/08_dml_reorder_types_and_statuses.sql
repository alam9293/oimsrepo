-- miscellaneous patching of types/access control
delete from role$functions where functionscode='PAY_REQ_UPD_NP' and roleCode='TG_PO';
delete from role$functions where functionscode='PAY_REQ_UPD_NP' and roleCode='TA_AO';
delete from role$functions where functionscode='PAY_REQ_UPD_NP' and roleCode='TA_HOD';
delete from role$functions where functionscode='PAY_REQ_UPD_NP' and roleCode='HODIV';
delete from role$functions where functionscode='PAY_REQ_UPD_NP' and roleCode='CNE_IO';
insert into role$functions(roleCode,functionscode)values('FINANCE', 'PAY_REQ_UPD_NP');

delete from role$functions where functionscode='PAY_REQ_UPD_P' and roleCode='TA_PO';
delete from role$functions where functionscode='PAY_REQ_UPD_P' and roleCode='TA_VO';
delete from role$functions where functionscode='PAY_REQ_UPD_P' and roleCode='TG_PO';

delete from role$functions where functionscode='PAY_REQ_UPD_P' and roleCode='CNE_IO';
insert into role$functions(roleCode,functionscode)values('FINANCE', 'PAY_REQ_UPD_P');

delete from role$functions where functionscode='PAY_REQ_UPD_V' and roleCode='HODIV';
delete from role$functions where functionscode='PAY_REQ_UPD_V' and roleCode='TA_AO';
delete from role$functions where functionscode='PAY_REQ_UPD_V' and roleCode='TA_HOD';
delete from role$functions where functionscode='PAY_REQ_UPD_V' and roleCode='TG_PO';
insert into role$functions(roleCode,functionscode)values('FINANCE', 'PAY_REQ_UPD_V');

update types set label='TG Licence Tier Switch Amendment Fee' where code='PAYREQ_TG_SWITCH_TIER';

insert into types(code, isActive, isEditable, label,  ordinal, categoryCode)
values('PAY_G',1,1,'Giro',0,'PAY');

-- reordering

update types as t1 
	inner join (SELECT 
    code, label, otherLabel, ordinal,
    ROW_NUMBER() OVER (PARTITION BY categoryCode ORDER BY label asc) AS rownum
FROM types
where categoryCode is not null and ordinal != '999' and categoryCode in ('CE_SUB_OEO', 'CE_OEO','CE_TASK','CE_TG_SCHEDULE_LOCATION')) as t2 on t1.code = t2.code 
Set t1.ordinal = t2.rownum;

update statuses as t1 
	inner join (SELECT 
    code, label, otherLabel, ordinal,
    ROW_NUMBER() OVER (PARTITION BY categoryCode ORDER BY label asc) AS rownum
FROM statuses
where categoryCode is not null and ordinal != '999' and categoryCode in ('STAT_CE_TASK')) as t2 on t1.code = t2.code 
Set t1.ordinal = t2.rownum;