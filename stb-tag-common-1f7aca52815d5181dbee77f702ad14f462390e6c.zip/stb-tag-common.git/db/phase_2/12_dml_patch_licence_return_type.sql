INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 1, 'TA_LRTN', 'TA Licence Return ', null, null, null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 1, 'TA_LRTN_CEASED', 'Licence Cessation', null, 'TA_LRTN', null);
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 0, 2, 'TA_LRTN_REVOKED', 'Licence Revocation', null, 'TA_LRTN', null);
update licence_return_batches set typeCode = 'TA_LRTN_CEASED' where typeCode = 'TA_APP_CESSATION';
update licence_return_batches set typeCode = 'TA_LRTN_REVOKED' where typeCode is null;