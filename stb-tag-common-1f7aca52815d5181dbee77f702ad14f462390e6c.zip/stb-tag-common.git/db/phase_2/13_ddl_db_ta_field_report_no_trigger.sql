-- trigger for generate TA field report no
DROP TRIGGER IF EXISTS ce_ta_field_report_no_before_insert;

DELIMITER $$
CREATE TRIGGER ce_ta_field_report_no_before_insert
BEFORE INSERT
   ON ce_ta_field_reports FOR EACH ROW
BEGIN
	DECLARE vMax INTEGER;
	DECLARE year VARCHAR(255);
	
	SET year = YEAR(CURDATE());
	
	SELECT value FROM system_parameters WHERE code LIKE "TA_FIELD_REPORT_NO" INTO vMax;
	
	IF (EXISTS(SELECT 1 FROM ce_ta_field_reports WHERE reportNo like CONCAT('STB/TA/CO/', year ,'%'))) THEN
		SET NEW.reportNo = CONCAT('STB/TA/CO/', year ,'/', LPAD( vMax, 5, '0' ));
		UPDATE system_parameters SET value = (vMax+1) WHERE code LIKE "TA_FIELD_REPORT_NO";
	ELSE
		SET NEW.reportNo = CONCAT('STB/TA/CO/', year ,'/', LPAD( 1, 5, '0' ));
		UPDATE system_parameters SET value = 2 WHERE code LIKE "TA_FIELD_REPORT_NO";
	END IF;
    
END$$
DELIMITER ;


