-- trigger for generate TG field report no
DROP TRIGGER IF EXISTS ce_tg_field_report_no_before_insert;

DELIMITER $$
CREATE TRIGGER ce_tg_field_report_no_before_insert
BEFORE INSERT
   ON ce_tg_field_reports FOR EACH ROW
BEGIN
	DECLARE vMax INTEGER;
	DECLARE curDate VARCHAR(255);
	DECLARE reportNoFormat VARCHAR(255);

	SET curDate = CURDATE() + 0;
	SET reportNoFormat = CONCAT('STB/TG/', curDate, '/');

	SELECT value FROM system_parameters WHERE code LIKE "TG_FIELD_REPORT_NO" INTO vMax;

	IF (EXISTS(SELECT 1 FROM ce_tg_field_reports WHERE reportNo like CONCAT(reportNoFormat, '%'))) THEN
		SET NEW.reportNo = CONCAT(reportNoFormat, LPAD( vMax, 2, '0' ));
		UPDATE system_parameters SET value = (vMax+1) WHERE code LIKE "TG_FIELD_REPORT_NO";
	ELSE
		SET NEW.reportNo = CONCAT(reportNoFormat, LPAD( 1, 2, '0' ));
		UPDATE system_parameters SET value = 2 WHERE code LIKE "TG_FIELD_REPORT_NO";
	END IF;
    
END$$
DELIMITER ;