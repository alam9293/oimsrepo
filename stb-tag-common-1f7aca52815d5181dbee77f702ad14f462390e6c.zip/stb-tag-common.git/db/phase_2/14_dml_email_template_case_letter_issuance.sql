DELETE FROM email_templates WHERE code = 'CNE_CASE_LETTER_ISSUANCE';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'CNE_CASE_LETTER_ISSUANCE'
	, 'Acknowledgement'
	, 'Acknowledgement'
	, '<p>Dear ${defendant},
<p><br>
<p>Please refer attached file for more details about the following infringements: 
<p><ol>${infringement_list}</ol></p>
<p><br>
<p><br>Regards,
<br>Tourist Guide Licensing Department
<br>Singapore Tourism Board');