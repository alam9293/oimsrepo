DELIMITER //
DROP FUNCTION IF EXISTS `toYearMonthDay`;
CREATE FUNCTION `toYearMonthDay` (daysOfService VARCHAR(100))
RETURNS VARCHAR(500)
DETERMINISTIC
BEGIN
    DECLARE totalYears VARCHAR(500);
    DECLARE totalMonths VARCHAR(500);
    DECLARE remainingDays VARCHAR(500);
    DECLARE estimatedLengthOfService VARCHAR(500);

    SET totalYears = FLOOR(daysOfService / 365);
    SET totalMonths = FLOOR(MOD(daysOfService, 365) / 30);
    SET remainingDays = FLOOR(MOD(MOD(daysOfService, 365), 30));

    SET estimatedLengthOfService = CONCAT(totalYears, ' year(s) ', totalMonths, ' month(s) ', remainingDays, ' day(s)');

    RETURN (estimatedLengthOfService);
END //
DELIMITER ;

CREATE OR REPLACE VIEW qliksense_users AS
select loginId as userid, name from users where typeCode = 'USER_STB' and statusCode = 'USER_A';

CREATE OR REPLACE VIEW qliksense_user_attributes AS
select loginId as userid, 'departmentCode' as type, departmentCode as value from users where typeCode = 'USER_STB' and statusCode = 'USER_A'
union
select loginId as userid, 'emailAddress' as type, emailAddress as value from users where typeCode = 'USER_STB' and statusCode = 'USER_A';

insert into users (createdBy, createdDate, updatedBy, updatedDate, version, emailAddress, isLocked, loginCount, loginId, name, password, salt, statusCode, typeCode, departmentCode)
values ('system', CURDATE(), 'system', CURDATE(), 0, 'tag-support@wizvision.com', 0, 0, 'wizvision-donlee', 'WizVision', 'QlikSenseOnly', 'QlikSenseOnly', 'USER_A', 'USER_STB', 'DEPT_IS');