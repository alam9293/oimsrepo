DELETE FROM email_templates WHERE code = 'CNE_COMPO_LETTER';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'CNE_COMPO_LETTER'
	, 'Notice of offence and offer of composition'
	, 'Notice of offence and offer of composition'
	, '<p>Dear ${defendant},
<p><br>
<p>A notice of offence and offer of composition has been issued to you for your immediate attention. Please refer to the attached letter for details.
Thank you.
<p><br>
<p><br>Yours faithfully,
<br>Singapore Tourism Board');