
update ta_filing_conditions f
	left join ta_aa_submissions aa on aa.taAnnualFilingId = f.id
    left join ta_filing_condition_extensions ext on ext.id = f.lastExtensionId
    left join applications app on aa.applicationId = app.id
    left join workflow_actions lastaction on lastaction.id = app.lastActionId
set f.rectifiedApplicationId = app.id
where f.statusCode != 'TA_FILING_VOID' and applicationTypeCode = 'TA_APP_AA_SUBMISSION' 
and (aa.id is null or (lastaction.statusCode != 'TA_APP_REJ' and app.isDraft = false and app.isDeleted is false)) ;

update ta_filing_conditions f
	left join ta_abpr_submissions abpr on abpr.taAnnualFilingId = f.id
    left join ta_filing_condition_extensions ext on ext.id = f.lastExtensionId
    left join applications app on abpr.applicationId = app.id
    left join workflow_actions lastaction on lastaction.id = app.lastActionId
set f.rectifiedApplicationId = app.id
where f.statusCode != 'TA_FILING_VOID' and applicationTypeCode = 'TA_APP_ABPR_SUBMISSION' 
and (abpr.id is null or (lastaction.statusCode != 'TA_APP_REJ' and app.isDraft = false and app.isDeleted is false)) ;

update ta_filing_conditions f
	left join ta_ma_submissions ma on ma.taFilingConditionId = f.id
    left join ta_filing_condition_extensions ext on ext.id = f.lastExtensionId
    left join applications app on ma.applicationId = app.id
    left join workflow_actions lastaction on lastaction.id = app.lastActionId
set f.rectifiedApplicationId = app.id
where f.statusCode != 'TA_FILING_VOID' and applicationTypeCode = 'TA_APP_MA_SUBMISSION' 
and (ma.id is null or (lastaction.statusCode != 'TA_APP_REJ' and app.isDraft = false and app.isDeleted is false)) ;

update  applications set submissionDate = createdDate where id = '9898' and submissionDate is null;
update  applications set submissionDate = createdDate where id = '35659' and submissionDate is null;
update  applications set submissionDate = createdDate where id = '33275' and submissionDate is null;
update  applications set submissionDate = createdDate where id = '70287' and submissionDate is null;

/*
update  ta_filing_conditions set rectifiedApplication = '2019-04-26' where id = '9359';
update  ta_filing_conditions set rectifiedApplication = '2019-06-26' where id = '36159';
update  ta_filing_conditions set rectifiedApplication = '2019-05-10' where id = '36391';
update  ta_filing_conditions set rectifiedApplication = '2019-08-16' where id = '36724';
*/


/*
select * from ta_filing_conditions where statusCode not in ('TA_FILING_PS', 'TA_FILING_VOID', 'TA_FILING_LATE') and rectifiedDate is null;
select app.id, cast(app.createdDate as date), app.submissionDate from ta_aa_submissions aa join applications app on app.id = aa.applicationId where taAnnualFilingId = '9359';
select app.id, cast(app.createdDate as date), app.submissionDate, abpr.isNilSubmission from ta_abpr_submissions abpr join applications app on app.id = abpr.applicationId where taAnnualFilingId = '36159';
select app.id, cast(app.createdDate as date), app.submissionDate, abpr.isNilSubmission from ta_abpr_submissions abpr join applications app on app.id = abpr.applicationId where taAnnualFilingId = '36391';
select app.id, cast(app.createdDate as date), app.submissionDate, abpr.isNilSubmission from ta_abpr_submissions abpr join applications app on app.id = abpr.applicationId where taAnnualFilingId = '36724';
select cast(app.createdDate as date), app.submissionDate, abpr.isNilSubmission from ta_abpr_submissions abpr join applications app on app.id = abpr.applicationId where isNilSubmission = true and submissionDate is not null;
*/