-- schema changes
alter table ta_net_value_rectifications add column isEdhPopulated BIT(1) default 0 not null;
update ta_net_value_rectifications set isEdhPopulated=true;


alter table ta_stakeholder_applications add column isEdhPopulated BIT(1) default 0 not null;
update ta_stakeholder_applications tsa join applications a on a.id=tsa.applicationid set isEdhPopulated=true where (a.typecode='TA_APP_PERSONNEL' or a.typecode='TA_APP_CREATION');
update ta_stakeholder_applications set isEdhPopulated=false where isEdhPopulated=null;

-- types
INSERT INTO types (isActive, isEditable, ordinal, code, label, otherLabel, categoryCode, mappingCode) VALUES (1, 1, 15, 'TA_DOC_ACRA_BIZ', 'ACRA Biz File', null, 'TA_DOC', null);