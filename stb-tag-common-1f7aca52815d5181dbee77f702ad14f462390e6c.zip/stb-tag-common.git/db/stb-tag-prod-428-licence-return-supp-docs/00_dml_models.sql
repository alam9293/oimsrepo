create table licence_return_batch$files (licenceReturnBatchId integer not null, supportingDocsId integer not null, primary key (licenceReturnBatchId, supportingDocsId)) engine=InnoDB;
