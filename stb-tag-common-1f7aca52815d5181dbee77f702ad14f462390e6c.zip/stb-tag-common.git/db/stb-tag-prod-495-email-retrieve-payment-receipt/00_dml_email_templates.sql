-- email template
DELETE FROM email_templates WHERE code = 'PAYMENT_RECEIPT';


INSERT INTO email_templates (createdBy, createdDate, updatedBy, updatedDate, version, code, subject, name, body) 
VALUES ('SYSTEM', now(), 'SYSTEM', now(), 0
	, 'PAYMENT_RECEIPT'
	, 'STB TRUST: Your payment has been completed.'
	, 'Payment Receipt'
	, '<p>Dear Sir/Madam,
<p><br>
<p>Your payment for ${pay_req_type} has been completed. Please see below for transaction details.
<p><br>
<p>Transaction No: ${pay_txn_id}
<p>Payment Date: ${pay_date}
<p>Payment Amount: S$ ${pay_amt}
<p><br>
<p>Regards,
<br>Singapore Tourism Board (STB) administrator');

-- functions and roles
INSERT INTO functions (createdBy, createdDate, updatedBy, updatedDate, label, uri, moduleCode, code, version) (SELECT 'SYSTEM', now(), 'SYSTEM', now(), 'View Payment Txn', '/payment/portal/get-payment-txn', 'MOD_PAY', 'PAY_TXN_VW_PORTAL', 0 FROM (SELECT 1 dummy) x LEFT JOIN functions f ON uri = '/payment/portal/get-payment-txn' WHERE f.code IS NULL);																INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Licensee' AND functions.uri='/payment/portal/get-payment-txn');	INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Travel Agent Candidates' AND functions.uri='/payment/portal/get-payment-txn');	INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Licensee' AND functions.uri='/payment/portal/get-payment-txn');		INSERT INTO role$functions (roleCode, functionsCode) (SELECT roles.code, functions.code FROM roles, functions WHERE roles.label='Tourist Guide Candidate' AND functions.uri='/payment/portal/get-payment-txn');