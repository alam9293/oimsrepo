package com.wiz.model.api;

import org.hibernate.SessionFactory;

public interface AuditAdditionalChangesEntity {

	public void logAdditionalChanges(SessionFactory sessionFactory, String event, Object newObject);

}
