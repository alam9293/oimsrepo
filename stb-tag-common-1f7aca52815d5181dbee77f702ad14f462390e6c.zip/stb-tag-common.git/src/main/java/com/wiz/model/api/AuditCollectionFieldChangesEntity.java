package com.wiz.model.api;

import java.lang.reflect.Field;
import java.util.Collection;

import org.hibernate.Session;

public interface AuditCollectionFieldChangesEntity {

	public void logCollectionFieldChanges(Session session, String event, Object newObject, Collection<?> newFieldValue, Collection<?> oldFieldValue, Field field) throws Exception;

}
