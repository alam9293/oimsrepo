package com.wiz.model.api;

import javax.persistence.Transient;

public interface Auditable {

	/**
	 * Tells the audit log intercepter the parent entity name for this entity. This is a transient field and will not be persisted.
	 */
	@Transient
	String getAuditParentEntityName();

	/**
	 * Tells the audit log intercepter the parent entity identifier for this entity. This is a transient field and will not be persisted.
	 */
	@Transient
	String getAuditParentEntityId();

	/**
	 * Tells the audit log intercepter to ignore this record. This is a transient field and will not be persisted.
	 */
	@Transient
	void setDoNotAudit(boolean doNotAudit);

	boolean isDoNotAudit();

}
