package com.wiz.model.api;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

@MappedSuperclass
@SuppressWarnings("serial")
public abstract class AuditableCodeEntity extends AuditableEntity implements CodeEntity {

	@Access(AccessType.PROPERTY)
	@Id // annotated at PROPERTY instead of FIELD to prevent unnecessary fetch caused by getId() in LAZY objects
	@Override
	public abstract String getCode();

	@Transient
	@Override
	public String getPrimaryKey() {
		return getCode() != null ? getCode() : "";
	}

}
