package com.wiz.model.api;

import java.time.LocalDateTime;

import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@SuppressWarnings("serial")
@MappedSuperclass
@EntityListeners({ AuditingEntityListener.class, AuditableEntityListener.class })
public abstract class AuditableEntity extends Entity implements Auditable, Comparable<AuditableEntity> {

	@DoNotAudit
	@CreatedBy
	private String createdBy;

	@DoNotAudit
	@CreatedDate
	private LocalDateTime createdDate;

	@DoNotAudit
	@LastModifiedBy
	private String updatedBy;

	@DoNotAudit
	@LastModifiedDate
	private LocalDateTime updatedDate;

	@DoNotAudit
	@Version
	private Integer version;

	@Transient
	private boolean doNotAudit;

	@Transient
	public abstract String getPrimaryKey(); // return getId(), getCode(), getLong() in String for entity-wide use (e.g. audit)

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@Override
	public String getAuditParentEntityName() {
		return null;
	}

	@Override
	public String getAuditParentEntityId() {
		return null;
	}

	@Override
	public boolean isDoNotAudit() {
		return doNotAudit;
	}

	@Override
	public void setDoNotAudit(boolean doNotAudit) {
		this.doNotAudit = doNotAudit;
	}

	@Override
	public int compareTo(AuditableEntity other) {
		return this.getPrimaryKey().compareTo(other.getPrimaryKey());
	}

}
