package com.wiz.model.api;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManagerFactory;
import javax.persistence.ManyToMany;
import javax.persistence.PersistenceUnit;
import javax.persistence.PostPersist;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import org.apache.commons.lang3.tuple.Pair;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.persister.entity.EntityPersister;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;

import gov.stb.tag.helper.AutowireHelper;
import gov.stb.tag.model.AuditLog;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.Type;
import gov.stb.tag.util.DateUtil;

public class AuditableEntityListener {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	protected static final String INSERT = "I";
	protected static final String UPDATE = "U";
	protected static final String DELETE = "D";

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	private ObjectMapper objectMapper = new ObjectMapper();

	protected SessionFactory getSessionFactory() {
		return entityManagerFactory.unwrap(SessionFactory.class);
	}

	public Session getSession() {
		return getSessionFactory().getCurrentSession();
	}

	private void onInsert(Object entity) throws IllegalArgumentException, IllegalAccessException {
		EntityPersister entityPersister = getEntityPersister(entity);
		Map<String, Field> fields = getAllFields(entity.getClass(), null);
		Serializable id = getEntityId(entity);
		String[] propertyNames = entityPersister.getEntityMetamodel().getPropertyNames();
		Object[] newValues = entityPersister.getPropertyValues(entity);
		Pair<String, String> jsons = getNewOldValues(INSERT, fields, entity, id, propertyNames, newValues, null);
		saveAuditLog(INSERT, entity, id, jsons.getLeft(), null);
	}

	@PostPersist
	public void onPostPersist(Object entity) throws IllegalArgumentException, IllegalAccessException {
		if (toAuditEntity(entity) && !(entity instanceof AuditableCodeEntity)) {
			onInsert(entity); // entity id is auto-generated, do @PostPersist to log the generated id
		}
	}

	@PrePersist
	public void onPrePersist(Object entity) throws IllegalArgumentException, IllegalAccessException {
		if (toAuditEntity(entity) && entity instanceof AuditableCodeEntity) {
			onInsert(entity);
		}
	}

	@PreUpdate
	public void onPreUpdate(Object entity) throws IllegalArgumentException, IllegalAccessException {
		if (toAuditEntity(entity)) {
			EntityPersister entityPersister = getEntityPersister(entity);
			SessionImplementor sessionImplementor = (SessionImplementor) getSession();
			Map<String, Field> fields = getAllFields(entity.getClass(), null);
			Serializable id = getEntityId(entity);
			String[] propertyNames = entityPersister.getEntityMetamodel().getPropertyNames();
			Object[] newValues = entityPersister.getPropertyValues(entity);
			Object[] oldValues = sessionImplementor.getPersistenceContext().getDatabaseSnapshot(id, entityPersister);
			Pair<String, String> jsons = getNewOldValues(UPDATE, fields, entity, id, propertyNames, newValues, oldValues);
			if (!jsons.getLeft().equals(jsons.getRight())) {
				saveAuditLog(UPDATE, entity, id, jsons.getLeft(), jsons.getRight());
			}
		}
	}

	@PreRemove
	public void onPreRemove(Object entity) throws IllegalArgumentException, IllegalAccessException {
		if (toAuditEntity(entity)) {
			EntityPersister entityPersister = getEntityPersister(entity);
			SessionImplementor sessionImplementor = (SessionImplementor) getSession();
			Map<String, Field> fields = getAllFields(entity.getClass(), null);
			Serializable id = getEntityId(entity);
			String[] propertyNames = entityPersister.getEntityMetamodel().getPropertyNames();
			Object[] oldValues = sessionImplementor.getPersistenceContext().getDatabaseSnapshot(id, entityPersister);
			Pair<String, String> jsons = getNewOldValues(DELETE, fields, entity, id, propertyNames, null, oldValues);
			saveAuditLog(DELETE, entity, id, null, jsons.getRight());
		}
	}

	private Pair<String, String> getNewOldValues(String action, Map<String, Field> fields, Object entity, Serializable id, String[] propertyNames, Object[] newValues, Object[] oldValues) {
		Map<String, String> newValuesJson = new HashMap<String, String>();
		Map<String, String> oldValuesJson = new HashMap<String, String>();
		for (int i = 0; i < propertyNames.length; i++) {
			Field field = fields.get(propertyNames[i]);
			if (toAuditField(field, entity)) {
				boolean isCollection = Collection.class.isAssignableFrom(field.getType());
				boolean isManyToMany = isCollection ? field.isAnnotationPresent(ManyToMany.class) : false;

				// only log if the field is primitive data type or a ManyToMany collection (for OneToMany collection, the child entity will be logged as its FK to this entity changes)
				if (!isCollection || isManyToMany) {
					if (action.equals(INSERT)) {
						if (!Strings.isNullOrEmpty(getStringValue(newValues[i]))) {
							newValuesJson.put(field.getName(), getStringValue(newValues[i]));
						}

					} else if (action.equals(DELETE)) {
						if (!Strings.isNullOrEmpty(getStringValue(oldValues[i]))) {
							oldValuesJson.put(field.getName(), isManyToMany ? getCollectionOldStringValue(field, entity, id) : getStringValue(oldValues[i]));
						}

					} else if (action.equals(UPDATE)) {
						String newValue = getStringValue(newValues[i]);
						String oldValue = isManyToMany ? getCollectionOldStringValue(field, entity, id) : getStringValue(oldValues[i]);
						if (!newValue.equals(oldValue)) {
							newValuesJson.put(field.getName(), newValue);
							oldValuesJson.put(field.getName(), oldValue);
						}
					}
				}
			}
		}
		try {
			return Pair.of(objectMapper.writeValueAsString(newValuesJson), objectMapper.writeValueAsString(oldValuesJson));
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

	private AuditLog saveAuditLog(String action, Object entity, Object id, String newValue, String oldValue) {
		AuditLog auditLog = new AuditLog();
		auditLog.setAction(action);
		auditLog.setEntityName(entity.getClass().getSimpleName());
		auditLog.setEntityId(id != null ? id.toString() : null);
		auditLog.setParentEntityName(((Auditable) entity).getAuditParentEntityName());
		auditLog.setParentEntityId(((Auditable) entity).getAuditParentEntityId());
		auditLog.setNewValue(newValue);
		auditLog.setOldValue(oldValue);
		getSession().save(auditLog);
		return auditLog;
	}

	private String getCollectionOldStringValue(Field field, Object entity, Serializable id) {
		// HQL E.G.: "SELECT b.code FROM User a JOIN a.roles b WHERE a.id = ?0"
		String childClassIdCol = AuditableCodeEntity.class.isAssignableFrom(field.getType()) ? "code" : "id";
		String hql = "SELECT b." + childClassIdCol + " FROM " + entity.getClass().getSimpleName() + " a JOIN a." + field.getName() + " b WHERE a." + (id instanceof String ? "code" : "id") + " = ?0";
		List<Object> ids = new ArrayList<>();
		StatelessSession statelessSession = getSessionFactory().openStatelessSession();
		List<Object> childIds = statelessSession.createQuery(hql, Object.class).setParameter(0, id).getResultList();
		for (Object childId : childIds) {
			ids.add(childId);
		}
		statelessSession.close();
		Arrays.sort(ids.toArray());
		return ids.toString();
	}

	@SuppressWarnings("unchecked")
	private String getStringValue(Object object) {
		if (object == null) {
			return "";

		} else if (object instanceof Type) {
			return ((Type) object).getCode(); // if need to getLabel instead, please use cache to prevent lazy-fetching

		} else if (object instanceof Status) {
			return ((Status) object).getCode(); // if need to getLabel instead, please use cache to prevent lazy-fetching

		} else if (object instanceof LocalDate) {
			return DateUtil.format((LocalDate) object);

		} else if (object instanceof LocalDateTime) {
			return DateUtil.format((LocalDateTime) object);

		} else if (object instanceof AuditableEntity) {
			return ((AuditableEntity) object).getPrimaryKey();

		} else if (object instanceof Collection) {
			return ((Collection<AuditableEntity>) object).stream().map(AuditableEntity::getPrimaryKey).sorted().collect(Collectors.toList()).toString();

		} else {
			return object.toString();
		}
	}

	private EntityPersister getEntityPersister(Object entity) {
		AutowireHelper.autowire(this, this.entityManagerFactory);
		return ((SessionFactoryImplementor) getSessionFactory()).getMetamodel().entityPersister(entity.getClass().getName());
	}

	private Map<String, Field> getAllFields(Class<?> entityClass, Map<String, Field> fields) {
		if (fields == null) {
			fields = new LinkedHashMap<String, Field>();
		}
		for (Field field : entityClass.getDeclaredFields()) {
			fields.put(field.getName(), field);
		}
		Class<?> superClass = entityClass.getSuperclass();
		if (!Object.class.equals(superClass)) {
			return getAllFields(superClass, fields);
		}
		return fields;
	}

	private Serializable getEntityId(Object entity) {
		return (Serializable) entityManagerFactory.getPersistenceUnitUtil().getIdentifier(entity);
	}

	public static boolean toAuditEntity(Object target) {
		return target instanceof Auditable && !((Auditable) target).isDoNotAudit();
	}

	private Boolean toAuditField(Field field, Object entity) {
		return (!Modifier.isStatic(field.getModifiers()) && !Modifier.isTransient(field.getModifiers()) && !field.isAnnotationPresent(DoNotAudit.class));
	}

}
