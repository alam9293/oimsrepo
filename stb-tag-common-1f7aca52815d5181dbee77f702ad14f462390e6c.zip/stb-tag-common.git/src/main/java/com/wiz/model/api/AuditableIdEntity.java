package com.wiz.model.api;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

@MappedSuperclass
@SuppressWarnings("serial")
public abstract class AuditableIdEntity extends AuditableEntity implements IdEntity {

	@Access(AccessType.PROPERTY)
	@Id // annotated at PROPERTY instead of FIELD to prevent unnecessary fetch caused by getId() in LAZY objects
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Override
	public abstract Integer getId();

	@Transient
	@Override
	public String getPrimaryKey() {
		return getId() != null ? getId().toString() : "";
	}

}
