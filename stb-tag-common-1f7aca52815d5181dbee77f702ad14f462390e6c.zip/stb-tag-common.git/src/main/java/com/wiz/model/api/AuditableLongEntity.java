package com.wiz.model.api;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

@MappedSuperclass
@SuppressWarnings("serial")
public abstract class AuditableLongEntity extends AuditableEntity implements LongIdEntity {

	// annotate @Id here (instead of FIELD) to prevent unnecessary fetch caused by getId() in LAZY objects
	@Access(AccessType.PROPERTY)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqStore")
	@Id
	@Override
	public abstract Long getId();

	@Transient
	@Override
	public String getPrimaryKey() {
		return getId() != null ? getId().toString() : "";
	}
}
