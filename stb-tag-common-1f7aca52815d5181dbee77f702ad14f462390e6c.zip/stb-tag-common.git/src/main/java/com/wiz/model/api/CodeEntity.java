package com.wiz.model.api;

public interface CodeEntity {

	public String getCode();

}
