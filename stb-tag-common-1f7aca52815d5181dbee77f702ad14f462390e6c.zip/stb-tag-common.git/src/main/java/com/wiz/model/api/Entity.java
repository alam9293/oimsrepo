package com.wiz.model.api;

import static com.google.common.base.Objects.equal;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map.Entry;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.MappedSuperclass;

import com.google.common.collect.Maps;

@Access(AccessType.FIELD)
@MappedSuperclass
public abstract class Entity implements Serializable {

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.getClass().getSimpleName() + "[");

		Entry<String, Object> idEntry = getIdValue();

		Object idValue = idEntry.getValue();
		String idFieldName = idEntry.getKey();

		sb.append(idFieldName + "=" + idValue);
		sb.append("]");

		return sb.toString();
	}

	/**
	 * Returns the ID value of the current class as a id field name and id field value entry
	 * 
	 * @return
	 */
	protected Entry<String, Object> getIdValue() {
		return getIdValue(super.getClass(), this);
	}

	/**
	 * Returns the ID value of the specified class as a id field name and id field value entry
	 * 
	 * @return
	 */
	protected Entry<String, Object> getIdValue(Class<?> clazz, Object instance) {
		Object idValue = null;
		String idFieldName = null;

		if (IdEntity.class.isAssignableFrom(super.getClass())) {
			idFieldName = "Id";
		} else if (CodeEntity.class.isAssignableFrom(super.getClass())) {
			idFieldName = "Code";
		} else {
			throw new RuntimeException("Entity has to implement either IdEntity or CodeEntity");
		}

		try {
			Method method = clazz.getMethod("get" + idFieldName);
			idValue = method.invoke(instance);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Maps.immutableEntry(idFieldName.toLowerCase(), idValue);
	}

	protected Field[] getAllFields(Class<?> objectClass, Field[] fields) {
		Field[] declaredFields = objectClass.getDeclaredFields();
		int fieldsLen = (fields == null) ? 0 : fields.length;
		int declaredFieldsLen = (declaredFields == null) ? 0 : declaredFields.length;

		Field[] allFields = new Field[fieldsLen + declaredFieldsLen];
		if (fields != null) {
			System.arraycopy(fields, 0, allFields, 0, fieldsLen);
		}
		if (declaredFields != null) {
			System.arraycopy(declaredFields, 0, allFields, fieldsLen, declaredFieldsLen);
		}
		Class<?> superClass = objectClass.getSuperclass();
		if (!(Object.class.equals(superClass))) {
			return getAllFields(superClass, allFields);
		}

		return allFields;
	}

	@Override
	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}

		if (this == o) {
			return true;
		}

		if ((!(super.getClass().isAssignableFrom(o.getClass()))) && (!(o.getClass().isAssignableFrom(super.getClass())))) {
			return false;
		}

		Object thisIdValue = getIdValue().getValue();
		Object compareIdValue = getIdValue(o.getClass(), o);

		if (equal(thisIdValue, compareIdValue)) {
			return true;
		}

		return equal(toString(), o.toString());
	}

	@Override
	public int hashCode() {
		int result = 17;

		Serializable thisId = (Serializable) getIdValue().getValue();
		if (thisId != null) {
			result = 37 * result + ((thisId == null) ? 0 : thisId.hashCode());
			return result;
		}

		Class<?> fieldType;
		Field[] fields = getClass().getDeclaredFields();

		for (Field field : fields) {
			fieldType = field.getType();
			if (Collection.class.isAssignableFrom(fieldType) || com.wiz.model.api.Entity.class.isAssignableFrom(fieldType)) {
				// skip foreign-key objects from hashcoding... meaning FK like statusCode will not be considered (which is correct, or else they will trigger LAZY fetch)
				// developer should only use java.util.Set with the intention of removing duplicated @Ids only (Set checks hashCode, then equals)
				continue;
			}
			try {
				field.setAccessible(true);
				Object value = field.get(this);
				result = 37 * result + (value == null ? 0 : value.hashCode());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return result;
	}
}