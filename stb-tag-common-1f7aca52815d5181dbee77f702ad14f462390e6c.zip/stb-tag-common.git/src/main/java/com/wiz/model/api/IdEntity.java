package com.wiz.model.api;

public interface IdEntity {

	public Integer getId();

}
