package com.wiz.model.api;

import java.io.Serializable;

public interface Listable {
	
	/**
	 * Used for display purpose. Could return the name, description etc. but should not return blank.
	 */
	public String getLabel();

	/**
	 * Used for other display purpose. Can return blank.
	 */
	public String getOtherLabel();

	public Serializable getKey();
}
