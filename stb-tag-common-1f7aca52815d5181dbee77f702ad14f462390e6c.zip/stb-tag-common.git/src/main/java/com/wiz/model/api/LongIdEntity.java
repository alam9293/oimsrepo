package com.wiz.model.api;

public interface LongIdEntity {

	public Long getId();

}
