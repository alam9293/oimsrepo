package gov.stb.tag.constant;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ImmutableList;

public interface Codes {

	public static interface Headers {
		public static final String VERSION_CHECK = "Version-Check";
		public static final String VERSION_CHECK_LISTING = "Version-Check-Listing";
		public static final String XSRF_TOKEN = "X-XSRF-TOKEN";
		public static final String APP_TOKEN = "X-Auth-Token";
		public static final String APP_AUTH = "App-Authorization";
		public static final String APEX_AUTH = "Authorization";
		public static final String CONTENT_TYPE = "Content-Type";
		public static final String BASIC_AUTH = "Authorization";
		public static final String STBSSO_USERNAME = "stbsso_user_name";

		public static interface Values {
			public static final String APPLICATION_JSON = "application/json";
		}
	}

	public static interface Environments {
		public static final String DEV = "DEV"; // use for local
		public static final String SIT = "SIT"; // use for trust-dev
		public static final String UAT = "UAT";
		public static final String PRODUCTION = "PROD";
	}

	public static interface SpCp {
		public static final String SPCP_FAIL = "FAIL";
		public static final String SP_USER_ID = "UserID";
		public static final String CP_USER_ID = "CPUID";
		public static final String CP_UEN = "CPEntID";
		public static final String NO_UEN = "NO_UEN";
	}

	public static interface Edh {
		public static final String API_ENTITY = "/entity";
		public static final String API_ENTITY_APPOINTMENTS = "/entity-appointments";
		public static final String API_ENTITY_SHAREHOLDERS = "/entity-shareholders";
		public static final String API_ENTITY_FINANCIALS = "/entity-financials";
	}

	public static interface Apex {
		public static final String INTERNET_L1 = "Apex_L1_Eg";
		public static final String INTERNET_L2 = "Apex_L2_Eg";
		public static final String INTRANET_L1 = "Apex_L1_Ig";
		public static final String INTRANET_L2 = "Apex_L2_Ig";
		public static final String SIGN_METHOD_L1 = "HMACSHA256";
		public static final String SIGN_METHOD_L2 = "SHA256withRSA";
	}

	public static interface TaTgType {
		public static final String TA = "TA";
		public static final String TG = "TG";
		public static final String TP = "TP";
	}

	public static interface DepartmentType {
		public static final String TA = "DEPT_TA";
		public static final String TG = "DEPT_TG";
		public static final String TA_AND_TG = "DEPT_TA_TG";
		public static final String IS = "DEPT_IS";
		public static final String TID = "DEPT_TID";
		public static final String FINANCE = "DEPT_FIN";
	}

	public static interface WorkflowCategoryType {
		public static final String TA = "TA";
		public static final String TG = "TG";
		public static final String CE = "CE";
		public static final String PAY = "PAY";
	}

	public static interface SystemParameters {
		public static final String MAX_FILE_SIZE = "MAX_FILE_SIZE";
		public static final String VALID_FILE_EXTS = "VALID_FILE_EXTS";
		public static final String LCRTN_DAYS_DUE_TA_CEASE = "LCRTN_DAYS_DUE_TA_CEASE";
		public static final String TA_GENERAL_FINANICAL_REQUIREMENT = "TA_GENERAL_FR";
		public static final String TA_NICHE_FINANICAL_REQUIREMENT = "TA_NICHE_FR";
		public static final String TG_PDC_MIN = "TG_PDC_MIN";
		public static final String TG_COURSE_RESULT_PASSING_RATE = "TG_COURSE_RESULT_PASSING_RATE";
		public static final String TG_NEW_LICENCE_PRORATED_FEE = "TG_LIC_PRORATED_FEE";
		public static final String TG_LICENCE_REPLACEMENT_FEE = "TG_LIC_REPLACE_FEE";
		public static final String TG_PERSON_UPDATE_FEE = "TG_PERSON_UPDATE_FEE";
		public static final String TG_LICENCE_START_CYCLE = "TG_LIC_START_CYCLE";
		public static final String TG_LICENCE_VALID_MONTHS = "TG_LIC_VALID_MONTHS";
		public static final String TG_MEDICAL_REPORT_AGE = "TG_MEDICAL_REPORT_AGE";
		public static final String APP_DRAFT_VALIDITY = "APP_DRAFT_VALIDITY";
		public static final String TG_LICENCE_RENEWAL_FEE = "TG_LIC_RENEWAL_FEE";
		public static final String STAN_LAST_EXTRACTION_DATE = "STAN_LAST_EXTRACTION_DT";
		public static final String TA_LIC_REPLACE_FEE = "TA_LIC_REPLACE_FEE";
		public static final String TA_LIC_APPLICATION_FEE = "TA_LIC_APPLICATION_FEE";
		public static final String TA_LICENCE_FEE = "TA_LICENCE_FEE";
		public static final String CPF_TG_LAST_EXTRACTION_DATE = "CPF_TG_LAST_EXTRACTION_DATE";
		public static final String TA_LICENCE_RENEWAL_FEE = "TA_LICENCE_RENEWAL_FEE";
		public static final String TA_BRANCH_FEE = "TA_BRANCH_FEE";
		public static final String TA_DEFAULT_LICENCE_RENEWAL_START = "TA_DEFAULT_LICENCE_RENEWAL_START";
		public static final String TA_DEFAULT_LICENCE_RENEWAL_END = "TA_DEFAULT_LICENCE_RENEWAL_END";
		public static final String TA_DEFAULT_LICENCE_RENEWAL_FYE_CUT = "TA_DEFAULT_LICENCE_RENEWAL_FYE_CUT";
		public static final String TA_DEFAULT_LICENCE_RENEWAL_RECOMMENDED_MA = "TA_DEFAULT_LICENCE_RENEWAL_RECOMMENDED_MA";
		public static final String TA_DEFAULT_LICENCE_RENEWAL_MA_DUE_DAYS = "TA_DEFAULT_LICENCE_RENEWAL_MA_DUE_DAYS";
		public static final String TA_SHORTFALL_DEFAULT_NO_OF_DAYS = "TA_SHORTFALL_DEFAULT_NO_OF_DAYS";
		public static final String TA_SHORTFALL_MAX_SUBMISSION_DATE_MONTH_DAY = "TA_SHORTFALL_MAX_SUBMISSION_DATE_MONTH_DAY";
		public static final String TA_SHORTFALL_SUBMISSION_DATE_DIFFER = "TA_SHORTFALL_SUBMISSION_DATE_DIFFER";
		public static final String TG_WORKPASS_EXPIRY_DAYS_TO_ALERT = "TG_WORKPASS_EXPIRY_DAYS_TO_ALERT";

		public static final String TA_RENEWAL_SHORTFALL_NICHE = "TA_RENEWAL_SHORTFALL_NICHE";
		public static final String TA_RENEWAL_SHORTFALL_GENERAL = "TA_RENEWAL_SHORTFALL_GENERAL";

		public static final String TA_EXTENSION_SHORTFALL_NICHE = "TA_EXTENSION_SHORTFALL_NICHE";
		public static final String TA_EXTENSION_SHORTFALL_GENERAL = "TA_EXTENSION_SHORTFALL_GENERAL";

		public static final String TG_MLPT_FEE = "TG_MLPT_FEE";

		public static final String TA_SUPPORT_EMAIL = "TA_SUPPORT_EMAIL";
		public static final String TG_SUPPORT_EMAIL = "TG_SUPPORT_EMAIL";
		public static final String STB_ORGANISATION = "STB_ORGANISATION";

		public static final String TA_FILING_CONDITION_REMINDER_START_DATE = "TA_FILING_CONDITION_REMINDER_START_DT";
		public static final String TA_FILING_CONDITION_REMINDER_START_DT_JUNE = "TA_FILING_CONDITION_REMINDER_START_DT_JUNE";

		public static final String TA_NET_PROFIT_MARGIN_THRESHOLD = "TA_NET_PROFIT_MARGIN_THRESHOLD";
		public static final String TA_QUICK_RATIO_THRESHOLD = "TA_QUICK_RATIO_THRESHOLD";
		public static final String TA_DEBT_EQUITY_THRESHOLD = "TA_DEBT_EQUITY_THRESHOLD";
		public static final String TA_PROFIT_SC_THRESHOLD = "TA_PROFIT_SC_THRESHOLD";

		public static final String CE_TA_FILING_CONDITION_CREATE_CASE_START_DATE = "CE_TA_FILING_CONDITION_CREATE_CASE_START_DATE";
		public static final String CE_TA_FILING_CONDITION_OFFICER_REMINDER = "CE_TA_FILING_CONDITION_OFFICER_REMINDER";
		public static final String CE_TA_SLA_SUBMIT_RECOMMENDATION = "CE_TA_SLA_SUBMIT_RECOMMENDATION";
		public static final String CE_TA_DAYS_TO_INFORM_DUE_KE_RESIGN = "CE_TA_DAYS_TO_INFORM_DUE_KE_RESIGN";
		public static final String CE_TA_MONTHS_TO_INFORM_DUE_FYE_CHANGE = "CE_TA_MONTHS_TO_INFORM_DUE_FYE_CHANGE";
		public static final String CE_TA_KE_VACANT_DURATION = "CE_TA_KE_VACANT_DURATION";
		public static final String CE_DEFAULT_TA_CHECK_SCHEDULER = "CE_DEFAULT_TA_CHECK_SCHEDULER";
		public static final String CE_DEFAULT_TG_CHECK_SCHEDULER = "CE_DEFAULT_TG_CHECK_SCHEDULER";
		public static final String CE_TA_DAYS_TO_INFORM_DUE_TA_CEASE = "CE_TA_DAYS_TO_INFORM_DUE_TA_CEASE";
		public static final String CE_TATI_CHECK_INFO = "CE_TATI_CHECK_INFO";
		public static final String CE_TA_CHECKS_DECLARATION = "CE_TA_CHECKS_DECLARATION";
		public static final String CE_DEFAULT_TA_IO = "CE_DEFAULT_TA_IO";
		public static final String CE_DEFAULT_TG_IO = "CE_DEFAULT_TG_IO";
		public static final String CE_DEFAULT_TG_FIELD_REPORT_AO = "CE_DEFAULT_TG_FIELD_REPORT_AO";

		public static final String CE_DEFAULT_TA_PROVISION_CHAPTER = "CE_DEFAULT_TA_PROVISION_CHAPTER";
		public static final String CE_DEFAULT_TG_PROVISION_CHAPTER = "CE_DEFAULT_TG_PROVISION_CHAPTER";
		public static final String CE_TG_SLA_SUBMIT_RECOMMENDATION = "CE_TG_SLA_SUBMIT_RECOMMENDATION";
		public static final String CE_TA_SLA_IMPOSE_DECISION_WITHOUT_SHOW_CAUSE = "CE_TA_SLA_IMPOSE_DECISION_WITHOUT_SHOW_CAUSE";
		public static final String CE_TG_SLA_IMPOSE_DECISION_WITHOUT_SHOW_CAUSE = "CE_TG_SLA_IMPOSE_DECISION_WITHOUT_SHOW_CAUSE";
		public static final String CE_TA_SLA_IMPOSE_DECISION_WITH_SHOW_CAUSE = "CE_TA_SLA_IMPOSE_DECISION_WITH_SHOW_CAUSE";
		public static final String CE_TG_SLA_IMPOSE_DECISION_WITH_SHOW_CAUSE = "CE_TG_SLA_IMPOSE_DECISION_WITH_SHOW_CAUSE";
		public static final String CE_SLA_AFP_PAYMENT = "CE_SLA_AFP_PAYMENT";
		public static final String CE_TA_SECTION_PENDING_SUSPEND_REVOKE = "CE_TA_SECTION_PENDING_SUSPEND_REVOKE";
		public static final String CE_SLA_FOR_SUPPORT = "CE_SLA_FOR_SUPPORT";
		public static final String CE_SLA_FOR_APPROVAL = "CE_SLA_FOR_APPROVAL";
		public static final String CE_TA_SLA_APPEAL = "CE_TA_SLA_APPEAL";
		public static final String CE_TG_SLA_APPEAL = "CE_TG_SLA_APPEAL";
		public static final String CE_IP_SLA = "CE_IP_SLA";
		public static final String CE_IP_COMPLEX_SLA = "CE_IP_COMPLEX_SLA";
		public static final String CE_DAYS_TO_INFORM_SUSPENSION_END = "CE_DAYS_TO_INFORM_SUSPENSION_END";
		public static final String CE_SLA_TA_RESCIND = "CE_SLA_TA_RESCIND";
		public static final String CE_SLA_TG_RESCIND = "CE_SLA_TG_RESCIND";
		public static final String CE_SLA_MTI_RESPOND = "CE_SLA_MTI_RESPOND";
		public static final String CE_SLA_TA_CHECK_REVISIT = "CE_SLA_TA_CHECK_REVISIT";
		public static final String TA_CPF_ARREARS_CONSECUTIVE_MTHS_COUNT = "TA_CPF_ARREARS_CONSECUTIVE_MTHS_COUNT";
		public static final String TG_ATG_EXAM_FEE = "TG_ATG_EXAM_FEE";

		public static final String PAYMENT_WAIVE_INTERNAL_REMARKS = "PAYMENT_WAIVE_INTERNAL_REMARKS";
		public static final String TG_COURSE_MIN_POINTS_TO_RENEW = "TG_COURSE_MIN_POINTS_TO_RENEW";
		public static final String TG_COURSE_RENEWED_END_DATE = "TG_COURSE_RENEWED_END_DATE";
		public static final String TG_COURSE_MTHS_TO_RENEW_BEF_END_DATE = "TG_COURSE_MTHS_TO_RENEW_BEF_END_DATE";
		public static final String TG_COURSE_YRS_TO_EXPIRED_WHEN_NOT_RENEWED = "TG_COURSE_YRS_TO_EXPIRED_WHEN_NOT_RENEWED";
		public static final String TG_STIPEND_AMOUNT = "TG_STIPEND_AMOUNT";
		public static final String TG_STIPEND_START_DATE = "TG_STIPEND_START_DATE";
		public static final String TG_STIPEND_END_DATE = "TG_STIPEND_END_DATE";
		public static final String TG_STIPEND_LANGUAGES = "TG_STIPEND_LANGUAGES";
		public static final String TG_STIPEND_LICENCE_START_DATE_BEFORE = "TG_STIPEND_LICENCE_START_DATE_BEFORE";

		public static final String BYPASS_IAMS = "BYPASS_IAMS";
	}

	public static interface CE_TA_FIELD_REPORT_CLASS {
		public static final String OTHERS = "CE_TA_CLASS_OTHERS";
	}

	public static interface TypeCategories {
		public static final String ADDRESS_TYPE = "ADDR";
		public static final String COUNTRY = "CTRY";
		public static final String FORM_OF_BUSINESS = "FOB";
		public static final String BUSINESS_CONSTITUTION = "BC";
		public static final String MARITAL_STATUS = "MARI";
		public static final String NATIONALITY = "NAT";
		public static final String PRINCIPLE_ACTIVITIES = "PA";
		public static final String PAYMENT = "PAY";
		public static final String PAYMENT_REQUEST = "PAYREQ";
		public static final String PREMISE_TYPE = "PREM";
		public static final String EDUCATION_QUALIFICATIONS = "EDU"; // TODO: code is used by EDUCATION_LEVEL
		public static final String OCCUPATIONS = "OCCP";
		public static final String RACE = "RACE";
		public static final String RESIDENTIAL_STATUS = "RESD";
		public static final String ESTABLISHMENT_STATUS = "SOE";
		public static final String SEX = "SEX";
		public static final String STAKEHOLDER_ROLES = "STKHLD_ROLE";
		public static final String TOUR = "TG_TOUR";
		public static final String EMP_SRC = "TG_EMP";
		public static final String EDUCATION_LEVEL = "EDU";
		public static final String SALUTATION = "SAL";
		public static final String WORK_PASS_TYPE = "PASS";
		public static final String RECOMMEND = "RECOMMEND";
		public static final String APP_RECOMMEND = "APP_RECOMMEND";
		public static final String TA_APPLICATION_TYPE = "TA_APP";
		public static final String TA_APPROVAL_MODE = "TA_APPR";
		public static final String TA_FOCUS_AREA = "TA_AREA";
		public static final String TA_FUNCTION_ACTIVITY = "TA_FUNC_ACT";
		public static final String TA_DOCUMENT_TYPE = "TA_DOC";
		public static final String TA_SEGMENTATION = "TA_SEGM";
		public static final String TA_SERVICE = "TA_SERV";
		public static final String TA_LICENCE_TIER = "TA_TIER";
		public static final String TA_REASON_CESSATION = "TA_RESN_CEASE";
		public static final String TA_REASON_REPLACEMENT = "TA_RESN_REPLACE";
		public static final String TA_AUDITOR_OPINION = "TA_AUDITOR_OPINION";
		public static final String TA_SHORTFALL = "TA_SHORTFALL";
		public static final String TA_REQ_ADHOC = "TA_REQ_ADHOC";
		public static final String TG_APPLICATION_TYPE = "TG_APP";
		public static final String TG_SPECIALIZED_AREA = "TG_AREA";
		public static final String TG_COURSE_TYPE = "TP_CSE";
		public static final String TG_COURSE_CATEGORY = "TG_CSE_CAT";
		public static final String TG_DOCUMENT_TYPE = "TG_DOC";
		public static final String TG_GUIDING_LANGUAGE = "TG_LANG";
		public static final String TG_DECLARED_OFFENCE_TYPE = "TG_DOFF";
		public static final String TG_LICENCE_TIER = "TG_TIER";
		public static final String TG_ITINERARY = "TG_ITINERARY";
		public static final String TG_RESULT = "TG_RESULT";
		public static final String TG_COURSE_SUBSIDY = "TG_COURSE_SUBSIDY";
		public static final String TP_ATTENDANCE = "TP_ATN";
		public static final String TA_WORKFLOW = "TA_WKFLW";
		public static final String TG_WORKFLOW = "TG_WKFLW";
		public static final String CE_WORKFLOW = "CE_WKFLW";
		public static final String PAY_WORKFLOW = "PAY_WKFLW";
		public static final String FLAG = "FLAG";
		public static final String STATUS = "STAT";
		public static final String DATA = "DATA";
		public static final String DEPT = "DEPT";
		public static final String MOD = "MOD";
		public static final String BULLETIN = "BULLETIN";
		public static final String EMAIL_BROADCAST_FREQUENCY = "EMAIL_BROADCAST_FREQUENCY";
		public static final String TA_FILING_AMENDMENT = "TA_FILING_AMENDMENT";
		public static final String TA_SALES_CHANNEL = "TA_SALES_CHANNEL";
		public static final String TG_INFO = "360_VIEW";

		// myinfo
		public static final String MYINFO_SEX = "MYINFO_SEX";
		public static final String MYINFO_RACE = "MYINFO_RACE";
		public static final String MYINFO_NATIONALITY = "MYINFO_NAT";
		public static final String MYINFO_COUNTRY = "MYINFO_CTRY";
		public static final String MYINFO_OCCUPATIONS = "MYINFO_OCCP";
		public static final String MYINFO_RESIDENTIAL_STATUS = "MYINFO_RESD";
		public static final String MYINFO_WORKPASS_STATUS = "MYINFO_WPSTATUS";
		public static final String MYINFO_EDUCATION_LEVEL = "MYINFO_EDU";
		public static final String MYINFO_MARITAL_STATUS = "MYINFO_MARI";

		// edh
		public static final String EDH_FOB = "EDH_FOB";
		public static final String EDH_ADDR = "EDH_ADDR";
		public static final String EDH_PA = "EDH_PA";
		public static final String EDH_ROLE = "EDH_ROLE";
		public static final String EDH_BC = "EDH_BC";

		// tgls
		public static final String TGLS_NATIONALITY = "TGLS_NAT";
		public static final String TGLS_QUALIFICATION = "TGLS_EDU";

		// trust
		public static final String TRUST_FOB = "TRUST_FOB";
		public static final String TRUST_TA_STT = "TRUST_TA_STT";
		public static final String TRUST_SERVICE = "TRUST_SERVICE";
		public static final String TRUST_TA_BRANCH_STT = "TRUST_TA_BRANCH_STT";
		public static final String TRUST_GENDER = "TRUST_GENDER";
		public static final String TRUST_NAT = "TRUST_NAT";
		public static final String TRUST_EDU = "TRUST_EDU";
		public static final String TRUST_STKHLD_ROLE = "TRUST_STKHLD_ROLE";
		public static final String TRUST_CTRY = "TRUST_CTRY";
		public static final String TRUST_PREM = "TRUST_PREM";
		public static final String TRUST_TRX = "TRUST_TRX";
		public static final String TRUST_PAYMODE = "TRUST_PAYM";
		public static final String TRUST_FEE = "TRUST_FEE";

		// C&E
		public static final String TA_ADDR = "TA_ADDR";
		public static final String TA_SERVICE_TYPE = "TA_SERVICE";
		public static final String TA_CHECK = "TA_CHECK";
		public static final String CE_TG_SCHEDULE_MERIDIEM = "CE_TG_SCHEDULE_MERIDIEM";
		public static final String CE_TG_SCHEDULE_LOCATION = "CE_TG_SCHEDULE_LOCATION";
		public static final String CE_OEO = "CE_OEO";
		public static final String CE_SUB_OEO = "CE_SUB_OEO";
		public static final String CE_OUTCOME = "CE_OUTCOME";
		public static final String CE_OUTCOME_IP = "CE_OUTCOME_IP";
		public static final String CE_TG_FIELD_REPORT_ASSESSMENT = "CE_TG_ASSESSMENT";
		public static final String CE_TASK = "CE_TASK";
		public static final String CE_CHAPTER = "CE_CHAPTER";
		public static final String CE_TA_FIELD_REPORT_CLASS = "CE_TA_FIELD_REPORT_CLASS";
		public static final String CE_APPEAL_RESULT = "CE_APPEAL_RESULT";
		public static final String CE_DECISION = "CE_DECISION";
		public static final String TG_AGE_GROUP = "TG_AGE_GROUP";
		public static final String ID_TYPE = "CE_ID_TYPE";
		public static final String COMPLAINANT = "CE_COMPLAINANT";
	}

	public static interface Types {
		public static final String ADDR_FOREIGN = "ADDR_F";
		public static final String ADDR_LOCAL = "ADDR_L";

		public static final String SEX_F = "SEX_F";
		public static final String SEX_M = "SEX_M";
		public static final String SEX_UNKNOWN = "SEX_U";

		public static final String TG_LANG_NA = "TG_LANG_NA";
		public static final String OCCP_OTHERS = "OCCP_O";
		public static final String CTRY_UNKNOWN = "CTRY_UN";
		public static final String CTRY_OTHERS = "CTRY_XX";
		public static final String CTRY_SG = "CTRY_SG";
		public static final String NAT_UNKNOWN = "NAT_UN";
		public static final String EDU_OTHERS = "EDU_O";
		public static final String PREM_OTHERS = "PREM_O";
		public static final String PAYMODE_MASTER = "PAY_M";
		public static final String PAYMODE_VISA = "PAY_V";
		public static final String PAYMODE_OTHERS = "PAY_O";

		public static final String TA_TIER_GENERAL = "TA_TIER_G";
		public static final String TA_TIER_NICHE = "TA_TIER_N"; // The last letter of the code will be appended to the licence number to indicate NICHE
		public static final String TA_APPR_IPA = "TA_APPR_IPA";
		public static final String TA_APPR_FA = "TA_APPR_FA";

		public static final String TA_APP_BRANCH_NEW = "TA_APP_BRANCH_NEW";
		public static final String TA_APP_BRANCH_UPDATE = "TA_APP_BRANCH_UPDATE";
		public static final String TA_APP_BRANCH_CEASE = "TA_APP_BRANCH_CEASE";

		public static final String TA_REASON_CEASE_OTHERS = "TA_RESN_CEASE_O";
		public static final String TA_REASON_REPLACE_OTHERS = "TA_RESN_REPLACE_O";

		public static final String TA_SHORTFALL_FULL = "TA_SHORTFALL_FULL";
		public static final String TA_SHORTFALL_INCREMENTAL = "TA_SHORTFALL_INCRE";

		public static final String TG_TIER_AREA = "TG_TIER_A";
		public static final String TG_TIER_GENERAL = "TG_TIER_G";
		public static final String TG_TIER_GENERAL_AREA = "TG_TIER_GA";
		public static final String TG_TIER_TAXI = "TG_TIER_T";

		public static final String CE_ACT_LETTER = "CE_ACT_LTTR";
		public static final String CE_ACT_FINE = "CE_ACT_FINE";
		public static final String CE_ACT_SUSPEND = "CE_ACT_SUS";
		public static final String CE_ACT_REVOKE = "CE_ACT_RVK";
		public static final String CE_ACT_CONDITIONS = "CE_ACT_COND";
		public static final String CE_ACT_IP = "CE_ACT_IP";

		public static final String TG_ASN_TOUR_OTH = "TG_TOUR_O";
		public static final String TG_ASN_EMP_SRC_OTH = "TG_EMP_O";

		public static final String RESIDENTIAL_PR = "RESD_P";
		public static final String RESIDENTIAL_CITIZEN = "RESD_C";

		public static final String TP_COURSE_PDC = "TP_CSE_P";
		public static final String TP_COURSE_MRC = "TP_CSE_M";

		public static final String TG_RESULT_FAIL = "TG_RESULT_F";
		public static final String TG_RESULT_PASS = "TG_RESULT_P";

		public static final String ATTENDED = "TP_ATN_ATN";
		public static final String ABSENT = "TP_ATN_ABS";

		public static final String TA_SERV_ACCOMMODATION = "TA_SERV_ACCOMMODATION";
		public static final String TA_SERV_AIR_TICKETING = "TA_SERV_AIR_TICKETING";
		public static final String TA_SERV_OTHERS = "TA_SERV_O";

		public static final String BC_SOLE_PROPRIETORSHIP = "BC_S";
		public static final String BC_PARTNERS = "BC_P";
		public static final String BC_OTHERS = "BC_O";

		public static final String FOB_BUSINESS = "FOB_BN";
		public static final String FOB_LIMITED_PARTNERSHIP = "FOB_LP";

		public static final String RECOMMEND_IMPOSE = "RECOMMEND_IMP";
		public static final String RECOMMEND_NO_IMPOSE = "RECOMMEND_NO_IMP";
		public static final String RECOMMEND_NO_ACT = "RECOMMEND_NO_ACT";

		public static final String APP_RECOMMEND_APPR = "APP_RECOMMEND_APPR";
		public static final String APP_RECOMMEND_REJ = "APP_RECOMMEND_REJ";

		public static final String BULLETIN_GENERAL = "BULLETIN_GENERAL";
		public static final String BULLETIN_GENERAL_TA = "BULLETIN_GENERAL_TA";
		public static final String BULLETIN_GENERAL_TA_TG = "BULLETIN_GENERAL_TA_TG";
		public static final String BULLETIN_GENERAL_TG = "BULLETIN_GENERAL_TG";
		public static final String BULLETIN_TA = "BULLETIN_TA";
		public static final String BULLETIN_TA_TG = "BULLETIN_TA_TG";
		public static final String BULLETIN_TG = "BULLETIN_TG";

		public static final String TA_LRTN_CEASED = "TA_LRTN_CEASED";
		public static final String TA_LRTN_REVOKED = "TA_LRTN_REVOKED";

		public static final String CE_ID_TYPE_ENTITY = "CE_ID_TYPE_ENTITY";
		public static final String CE_ID_TYPE_INDIVIDUAL = "CE_ID_TYPE_INDIVIDUAL";

		public static final String TA_CHECK_TATI = "TA_CHECK_TATI";
		public static final String TA_CHECK_NON_RENEWAL = "TA_CHECK_NON_RENEWAL";
		public static final String TA_CHECK_ADHOC = "TA_CHECK_ADHOC";

		public static final String TG_AGE_GROUP_LESS_21 = "TG_AGE_GROUP_LESS_21";
		public static final String TG_AGE_GROUP_21_TO_30 = "TG_AGE_GROUP_21_TO_30";
		public static final String TG_AGE_GROUP_31_TO_40 = "TG_AGE_GROUP_31_TO_40";
		public static final String TG_AGE_GROUP_41_TO_50 = "TG_AGE_GROUP_41_TO_50";
		public static final String TG_AGE_GROUP_51_TO_60 = "TG_AGE_GROUP_51_TO_60";
		public static final String TG_AGE_GROUP_ABOVE_60 = "TG_AGE_GROUP_ABOVE_60";

		public static final String TA_ADDR_REG = "TA_ADDR_REG";
		public static final String TA_ADDR_OP = "TA_ADDR_OP";
		public static final String TA_ADDR_BRANCH = "TA_ADDR_BRANCH";

		public static final String TA_AUDITOR_OPINION_UNQ = "TA_AUDITOR_OPINION_UNQ";
		public static final String CE_TG_SCHEDULE_MERIDIEM_AM = "CE_TG_SCHEDULE_MERIDIEM_AM";
		public static final String CE_TG_SCHEDULE_MERIDIEM_PM = "CE_TG_SCHEDULE_MERIDIEM_PM";
		public static final String CE_TG_SCHEDULE_MERIDIEM_EVE = "CE_TG_SCHEDULE_MERIDIEM_EVE";
		public static final String TA_FILING_AMEND_EXTEND_DUE_DATE = "TA_FILING_AMEND_EXTEND_DUE_DATE";
		public static final String TA_SALES_CHANNEL_OTHERS = "TA_SALES_CHANNEL_OTHERS";
	}

	public static interface Modules {
		public static final String MOD_CE = "MOD_CE";
		public static final String MOD_RPT = "MOD_RPT";
		public static final String MOD_SYS = "MOD_SYS";
		public static final String MOD_TA = "MOD_TA";
		public static final String MOD_TG = "MOD_TG";
		public static final String MOD_USR = "MOD_USR";
		public static final String MOD_TP = "MOD_TP";
	}

	public static interface Mod {
		public static final String MOD_BULLETIN = "MOD_BULLETIN";
		public static final String MOD_CE = "MOD_CE";
		public static final String MOD_FILE = "MOD_FILE";
		public static final String MOD_MY_INFO = "MOD_MY_INFO";
		public static final String MOD_PAY = "MOD_PAY";
		public static final String MOD_RETURN = "MOD_RETURN";
		public static final String MOD_RPT = "MOD_RPT";
		public static final String MOD_SYS = "MOD_SYS";
		public static final String MOD_TA = "MOD_TA";
		public static final String MOD_TG = "MOD_TG";
		public static final String MOD_USR = "MOD_USR";
		public static final String MOD_WORKFLOW = "MOD_WORKFLOW";
		public static final String MOD_CATEGORY = "MOD_CATEGORY";

		public static final List<String> MODLIST = Arrays.asList(Mod.MOD_BULLETIN, Mod.MOD_CE, Mod.MOD_FILE, Mod.MOD_MY_INFO, Mod.MOD_PAY, Mod.MOD_RETURN, Mod.MOD_RPT, Mod.MOD_SYS, Mod.MOD_TA,
				Mod.MOD_TG, Mod.MOD_USR, Mod.MOD_WORKFLOW, Mod.MOD_CATEGORY);

	}

	public static interface ApplicationTypes {
		public static final String TA_APP_CREATION = "TA_APP_CREATION";
		public static final String TA_APP_CREATION_IPA = "TA_APP_CREATION_IPA";
		public static final String TA_APP_BRANCH = "TA_APP_BRANCH";
		public static final String TA_APP_TIER_SWITCH = "TA_APP_TIER_SWITCH";
		public static final String TA_APP_CESSATION = "TA_APP_CESSATION";
		public static final String TA_APP_REPLACEMENT = "TA_APP_REPLACEMENT";
		public static final String TA_APP_COMPANY_UPDATE = "TA_APP_COMPANY_UPDATE";
		public static final String TA_APP_FY_UPDATE = "TA_APP_FY_UPDATE";
		public static final String TA_APP_AA_SUBMISSION = "TA_APP_AA_SUBMISSION";
		public static final String TA_APP_ABPR_SUBMISSION = "TA_APP_ABPR_SUBMISSION";
		public static final String TA_APP_NET_VALUE_RECTIFICATION = "TA_APP_NET_VALUE_RECTIFICATION";
		public static final String TA_APP_KE = "TA_APP_KE";
		public static final String TA_APP_PERSONNEL = "TA_APP_PERSONNEL";
		public static final String TA_APP_RENEWAL = "TA_APP_RENEWAL";
		public static final String TA_APP_MA_SUBMISSION = "TA_APP_MA_SUBMISSION";
		public static final String TA_APP_ADHOC_MA_SUBMISSION = "TA_APP_ADHOC_MA_SUBMISSION";
		public static final String TA_APP_ADHOC_DOC_SUBMISSION = "TA_APP_ADHOC_DOC_SUBMISSION";
		public static final String TA_APP_ELICENCE_REQUEST = "TA_APP_ELICENCE_REQUEST";

		public static final String[] TA_RENEWAL_FILING_TYPES = { ApplicationTypes.TA_APP_AA_SUBMISSION, ApplicationTypes.TA_APP_ABPR_SUBMISSION, ApplicationTypes.TA_APP_MA_SUBMISSION,
				ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION };
		public static final String[] TA_APP_LICENCE_PRINT_TYPES = { ApplicationTypes.TA_APP_CREATION, ApplicationTypes.TA_APP_RENEWAL, ApplicationTypes.TA_APP_REPLACEMENT,
				ApplicationTypes.TA_APP_TIER_SWITCH, ApplicationTypes.TA_APP_COMPANY_UPDATE, ApplicationTypes.TA_APP_BRANCH };
		public static final Object[] TA_MA_FILING_TYPES = { ApplicationTypes.TA_APP_MA_SUBMISSION, ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION };
		public static final Object[] TA_FILING_TYPES = { ApplicationTypes.TA_APP_AA_SUBMISSION, ApplicationTypes.TA_APP_ABPR_SUBMISSION, ApplicationTypes.TA_APP_MA_SUBMISSION,
				ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION, ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION };

		/* Codes are under category of TA_APP_KE */
		public static final String TA_APP_KE_UPD_DETAILS = "TA_APP_KE_UPD_DETAILS";
		public static final String TA_APP_KE_RESIGN = "TA_APP_KE_RESIGN";
		public static final String TA_APP_KE_REASSIGN = "TA_APP_KE_REASSIGN";
		public static final String TA_APP_KE_ASSIGN = "TA_APP_KE_ASSIGN";
		/* END */

		/* TA branch application types */
		public static final String TA_APP_BRANCH_NEW = "TA_APP_BRANCH_NEW";
		public static final String TA_APP_BRANCH_UPDATE = "TA_APP_BRANCH_UPDATE";
		public static final String TA_APP_BRANCH_CEASE = "TA_APP_BRANCH_CEASE";

		public static final String TG_APP_CREATION = "TG_APP_CREATION";
		public static final String TG_APP_CANCELLATION = "TG_APP_CANCELLATION";
		public static final String TG_APP_RENEWAL = "TG_APP_RENEWAL";
		public static final String TG_APP_REINSTATEMENT = "TG_APP_REINSTATEMENT";
		public static final String TG_APP_REPLACEMENT = "TG_APP_REPLACEMENT";
		public static final String TG_APP_PERSON_UPDATE = "TG_APP_PERSON_UPDATE";
		public static final String TG_APP_RESIDENTIAL_CHANGE = "TG_APP_RESIDENTIAL_CHANGE";

		public static final String TG_APP_MRC_SUBMISSION = "TG_APP_MRC_SUBMISSION";
		public static final String TG_APP_PDC_SUBMISSION = "TG_APP_PDC_SUBMISSION";
		public static final String TG_APP_MLPT_REGISTRATION = "TG_APP_MLPT_REGISTRATION";
		public static final String TG_APP_SWITCH_TIER = "TG_APP_SWITCH_TIER";
		public static final String TG_APP_COURSE_RENEWAL = "TG_APP_COURSE_RENEWAL";
		public static final String TG_APP_COURSE_CREATION = "TG_APP_COURSE_CREATION";
		public static final String TG_APP_STIPEND = "TG_APP_STIPEND";

		public static final String[] FOR_TA_FILING_REMINDER = { ApplicationTypes.TA_APP_AA_SUBMISSION, ApplicationTypes.TA_APP_ABPR_SUBMISSION };
	}

	public static interface TaDocumentTypes {
		public static final String TA_DOC_BANK = "TA_DOC_BANK";
		public static final String TA_DOC_KE_RESUME = "TA_DOC_KE_RESUME";
		public static final String TA_DOC_KE_RESIGN_LETTER = "TA_DOC_KE_RESIGN_LETTER";
		public static final String TA_DOC_KE_DIR_RESOLUTION = "TA_DOC_KE_DIR_RESOLUTION";
		public static final String TA_DOC_CEASE_DIRECTOR_RESOLUTION = "TA_DOC_CEASE_DIRECTOR_RESOLUTION";
		public static final String TA_DOC_POLICE_REPORT = "TA_DOC_POLICE_REPORT";
		public static final String TA_DOC_MGMT_ACC = "TA_DOC_MGMT_ACC";
		public static final String TA_DOC_OTHERS = "TA_DOC_O";
		public static final String TA_DOC_AUDIT_REPORT = "TA_DOC_AUDIT_REPORT";
		public static final String TA_DOC_KE_NRIC = "TA_DOC_KE_NRIC";
		public static final String TA_DOC_BEOC = "TA_DOC_BEOC";
		public static final String TA_DOC_TENANCY = "TA_DOC_TENANCY";
		public static final String TA_DOC_HOS_APPROVAL = "TA_DOC_HOS_APPROVAL";
		public static final String TA_DOC_CBS = "TA_DOC_CBS";
		public static final String TA_DOC_CFYE_DIRECTOR_RESOLUTION = "TA_DOC_CFYE_DIRECTOR_RESOLUTION";
		public static final String TA_DOC_MANAGEMENT_ACCOUNTS = "TA_DOC_MANAGEMENT_ACCOUNTS";
		public static final String TA_DOC_REC_DIRECTOR_RESOLUTION = "TA_DOC_REC_DIRECTOR_RESOLUTION";
		public static final String TA_DOC_REC_BANK_STATEMENT = "TA_DOC_REC_BANK_STATEMENT";
		public static final String TA_DOC_SHORTFALL_LETTER = "TA_DOC_SHORTFALL_LETTER";
		public static final String TA_DOC_SHORTFALL_LETTER_SYSTEM = "TA_DOC_SHORTFALL_LETTER_SYSTEM";
		public static final String TA_DOC_EXTENSION_EMAIL_REQUEST = "TA_DOC_EXTENSION_EMAIL_REQUEST";
		public static final String TA_DOC_ACRA_BIZ = "TA_DOC_ACRA_BIZ";
		public static final String TA_DOC_ADHOC_DOC = "TA_DOC_ADHOC_DOC";
	}

	public static interface TgDocumentTypes {
		public static final String TG_DOC_MEDICAL_65 = "TG_DOC_MED";
		public static final String TG_DOC_PASSPORT_PHOTO = "TG_DOC_PHOTO";
		public static final String TG_DOC_POLICE_REPORT = "TG_DOC_POLICE";
		public static final String TG_DOC_WORK_PASS = "TG_DOC_WP";
		public static final String TG_DOC_OTHERS = "TG_DOC_O";
		public static final String TG_DOC_STIPEND = "TG_DOC_STIPEND";
	}

	public static interface PaymentTypes {
		public static final String VISA = "PAY_V";
		public static final String MASTERCARD = "PAY_M";
		public static final String PAYNOW = "PAY_P";
		public static final String CASH_CHEQUE = "PAY_C";
		public static final String INTERBANK_TXF = "PAY_I";
	}

	public static interface CePaymentRequestTypes {
		public static final String PAYREQ_CE_COMPOSITION = "PAYREQ_CE_COMPOSITION";
		public static final String PAYREQ_CE_AFP = "PAYREQ_CE_AFP";
	}

	public static interface TaPaymentRequestTypes {
		public static final String PAYREQ_TA_BRANCH_A = "PAYREQ_TA_BRANCH_A";
		public static final String PAYREQ_TA_CREATION_A = "PAYREQ_TA_CREATION_A";
		public static final String PAYREQ_TA_CREATION_L = "PAYREQ_TA_CREATION_L";
		public static final String PAYREQ_TA_REPLACEMENT = "PAYREQ_TA_REPLACEMENT";
		public static final String PAYREQ_TA_RENEWAL = "PAYREQ_TA_RENEWAL";
	}

	public static interface TgPaymentRequestTypes {
		public static final String PAYREQ_TG_RENEWAL = "PAYREQ_TG_RENEWAL";
		public static final String PAYREQ_TG_REINSTATEMENT = "PAYREQ_TG_REINSTATEMENT";
		public static final String PAYREQ_TG_APP_REPLACEMENT = "PAYREQ_TG_APP_REPLACEMENT";
		public static final String PAYREQ_TG_CREATION = "PAYREQ_TG_CREATION";
		public static final String PAYREQ_TG_PARTICULAR_UPDATE = "PAYREQ_TG_PARTICULAR_UPDATE";
		public static final String PAYREQ_TG_SWITCH_TIER = "PAYREQ_TG_SWITCH_TIER";
		public static final String PAYREQ_TG_MLPT = "PAYREQ_TG_MLPT";
		public static final String PAYREQ_TG_MLPT_REGISTRATION = "PAYREQ_TG_MLPT_REGISTRATION";
		public static final String PAYREQ_TG_SWITCH_RESIDENTIAL_STATUS = "PAYREQ_TG_CHANGE_RESD";
		public static final String PAYREQ_TG_ATG_EXAM = "PAYREQ_TG_ATG_EXAM";
		public static final String PAYREQ_TG_STIPEND = "PAYREQ_TG_STIPEND";
	}

	public static interface StatusCategories {
		public static final String EMAIL = "STAT_EMAIL";
		public static final String PAYMENT_REQUEST = "STAT_PAYREQ";
		public static final String PAYMENT_TXN = "STAT_PAYTXN";
		public static final String LICENCE_RETURN = "STAT_LCRTN";
		public static final String TA_LICENCE = "STAT_TA";
		public static final String TA_BRANCH_LICENCE = "STAT_TA_BRANCH";
		public static final String TA_BRANCH_APP = "STAT_TA_BRANCH_APP";
		public static final String TA_APPLICATION = "STAT_TA_APP";
		public static final String TG_LICENCE = "STAT_TG";
		public static final String TG_APPLICATION = "STAT_TG_APP";
		public static final String TG_COURSE = "STAT_TG_CSE";
		public static final String USER = "STAT_USER";
		public static final String DOC_TRF = "STAT_DOC_TRF";
		public static final String PRINT = "STAT_PRINT";
		public static final String TA_PRINT = "STAT_TA_PRINT";
		public static final String TG_CANDIDATE_RESULT = "STAT_TG_CANDIDATE_RESULT";
		public static final String TG_MLPT_RESULT = "STAT_TG_MLPT";
		public static final String TA_WORKFLOW = "STAT_TA_WKFLW";
		public static final String TG_WORKFLOW = "STAT_TG_WKFLW";
		public static final String TA_FILING = "STAT_TA_FILING";
		public static final String CE_TASK = "STAT_CE_TASK";
		public static final String CE_TA_CHECK = "STAT_CE_TA_CHECK";
		public static final String CE_CASE = "STAT_CE_CASE";
	}

	public static interface Statuses {
		public static final String EMAIL_SENT = "EMAIL_SENT";
		public static final String EMAIL_RECEIVED = "EMAIL_RECEIVED";
		public static final String EMAIL_BOUNCED = "EMAIL_BOUNCED";
		public static final String EMAIL_FAILED = "EMAIL_FAILED";

		public static final String JOB_PROCESSING = "JOB_PROCESSING"; // job processing
		public static final String JOB_ERROR = "JOB_ERROR"; // job run completed with errors
		public static final String JOB_SUCCESS = "JOB_SUCCESS"; // job run completed
		public static final String JOB_WARNING = "JOB_WARNING"; // job run completed with warning
		public static final String JOB_FAILED = "JOB_FAILED"; // job run incomplete due to unexpected exception

		public static final String PAYREQ_NOT_PAID = "PAYREQ_N";
		public static final String PAYREQ_PAID = "PAYREQ_P";
		public static final String PAYREQ_SETTLED = "PAYREQ_S";
		public static final String PAYREQ_VOID = "PAYREQ_V";
		public static final String PAYREQ_WAIVED = "PAYREQ_W";
		public static final String PAYREQ_PENDING_REFUND = "PAYREQ_PR";
		public static final String PAYREQ_REFUNDED = "PAYREQ_R";
		public static final String PAYREQ_PENDING_DISBURSEMENT = "PAYREQ_PD";
		public static final String PAYREQ_DISBURSED = "PAYREQ_DISBURSED";
		public static final String PAYREQ_PENDING_TG = "PAYREQ_PEND_TG";
		public static final String PAYREQ_PENDING_FOLLOW_UP = "PAYREQ_PEND_FOLLOW_UP";

		public static final String PAYTXN_PENDING = "PAYTXN_P";
		public static final String PAYTXN_SUCCESSFUL = "PAYTXN_S";
		public static final String PAYTXN_FAIL = "PAYTXN_F";
		public static final String PAYTXN_TIMEOUT = "PAYTXN_T";
		public static final String PAYTXN_VOID = "PAYTXN_V";

		public static final String LCRTN_PENDING = "LCRTN_P";
		public static final String LCRTN_FULFILLED = "LCRTN_F";
		public static final String LCRTN_LATE = "LCRTN_L";
		public static final String LCRTN_VOID = "LCRTN_V";

		public static final String PRINT_NOT_REQUIRED = "PRINT_N";
		public static final String PRINT_PENDING_APPROVAL = "PRINT_PA";
		public static final String PRINT_PENDING_PRINTING = "PRINT_PP";
		public static final String PRINT_SUBMIT_PRINT = "PRINT_SP";
		public static final String PRINT_PENDING_COLLECTION = "PRINT_PC";
		public static final String PRINT_LICENCE_COLLECTED = "PRINT_C";
		public static final String PRINT_PENDING_PAYMENT = "PRINT_PEND_PAY";

		public static final String TA_ACTIVE = "TA_A";
		public static final String TA_INACTIVE = "TA_I"; // Licensed but Inactive
		public static final String TA_REVOKED = "TA_R";
		public static final String TA_SUSPENDED = "TA_S";
		public static final String TA_CEASED = "TA_C";
		public static final String TA_PEND_RENEWAL = "TA_PRN";
		public static final String TA_PEND_SUSPENSION = "TA_PS";
		public static final String TA_PEND_REVOCATION = "TA_PR";

		public static final String TA_PRINT_PENDING = "TA_PRINT_PENDING";
		public static final String TA_PRINT_PRINTED = "TA_PRINT_PRINTED";
		public static final String TA_PRINT_NA = "TA_PRINT_NA";
		public static final String TA_PRINT_NOT_REQUIRED = "TA_PRINT_NOT_REQUIRED";

		// Branch's status
		public static final String TA_BRANCH_ACTIVE = "TA_BRANCH_A";
		public static final String TA_BRANCH_CEASED = "TA_BRANCH_C";
		public static final String TA_BRANCH_M_CEASED = "TA_BRANCH_M_C";
		public static final String TA_BRANCH_M_REVOKED = "TA_BRANCH_M_R";
		public static final String TA_BRANCH_M_SUSPEND = "TA_BRANCH_M_S";
		public static final String TA_BRANCH_M_PENDING_RENEWAL = "TA_BRANCH_M_PENDING_RENEWAL";
		// Branch Application's status ([Verlin 18/02/2019]: suggest to have another parent group for branch application's statuses, separated from branch's statuses)
		public static final String TA_BRANCH_REJECTED = "TA_BRANCH_R";
		public static final String TA_BRANCH_PROCESSING_APPROVAL = "TA_BRANCH_PA";
		public static final String TA_BRANCH_PROCESSING_CESSATION = "TA_BRANCH_PC";
		public static final String TA_BRANCH_PROCESSING_UPDATE = "TA_BRANCH_PU";
		public static final String TA_BRANCH_PENDING_CESSATION = "TA_BRANCH_PENDC";
		public static final String TA_BRANCH_PROCESSING_DELETED = "TA_BRANCH_PD";

		@Deprecated // to use PENDING PO/VO/AO/HOD/HODIV
		public static final String TA_APP_PENDING_APPROVAL = "TA_APP_PA";
		public static final String TA_APP_PENDING_PO = "TA_APP_PEND_PO";
		public static final String TA_APP_PENDING_VO = "TA_APP_PEND_VO";
		public static final String TA_APP_PENDING_CNE_CO = "TA_APP_PEND_CNE_CO";
		public static final String TA_APP_PENDING_AO = "TA_APP_PEND_AO";
		public static final String TA_APP_PENDING_HOD = "TA_APP_PEND_HOD";
		public static final String TA_APP_PENDING_HODIV = "TA_APP_PEND_HODIV";
		public static final String TA_APP_APPROVED = "TA_APP_APPR";
		public static final String TA_APP_RFA = "TA_APP_RFA";
		public static final String TA_APP_REJECTED = "TA_APP_REJ";
		public static final String TA_APP_COMPLETED = "TA_APP_COM"; // for passive apps
		public static final String TA_APP_PENDING_OA = "TA_APP_P_OA"; // ONLY FOR TA LICENCE CREATION IPA
		public static final String TA_APP_NEW = "TA_APP_NEW"; // not used in data, used to retrive label to show "New" statues
		public static final String TA_APP_DRAFT = "TA_APP_DRAFT"; // not used in data

		public static final String TA_FILING_PEND_SUBMISSION = "TA_FILING_PS";
		public static final String TA_FILING_PEND_APPROVAL = "TA_FILING_PA";
		public static final String TA_FILING_APPROVED = "TA_FILING_APPR";
		public static final String TA_FILING_RFA = "TA_FILING_RFA";
		public static final String TA_FILING_LATE = "TA_FILING_LATE";
		public static final String TA_FILING_VOID = "TA_FILING_VOID";

		public static final String TA_WKFLW_NEW = "TA_WKFLW_NEW";// not used in data, used to retrive label to show "New" statues
		public static final String TA_WKFLW_PEND_PO = "TA_WKFLW_PEND_PO";
		public static final String TA_WKFLW_PEND_VO = "TA_WKFLW_PEND_VO";
		public static final String TA_WKFLW_PEND_AO = "TA_WKFLW_PEND_AO";
		public static final String TA_WKFLW_PEND_HOD = "TA_WKFLW_PEND_HOD";
		public static final String TA_WKFLW_PEND_HODIV = "TA_WKFLW_PEND_HODIV";
		public static final String TA_WKFLW_APPROVED = "TA_WKFLW_APPR";
		public static final String TA_WKFLW_REJECTED = "TA_WKFLW_REJ";
		public static final String TG_WKFLW_PEND_PO = "TG_WKFLW_PEND_PO";
		public static final String TG_WKFLW_PEND_AO = "TG_WKFLW_PEND_AO";
		public static final String TG_WKFLW_PEND_HODIV = "TG_WKFLW_PEND_HODIV";
		public static final String TG_WKFLW_APPROVED = "TG_WKFLW_APPR";
		public static final String TG_WKFLW_REJECTED = "TG_WKFLW_REJ";

		public static final String CE_WKFLW_NEW = "CE_WKFLW_NEW";// not used in data, used to retrive label to show "New" statues
		public static final String CE_WKFLW_PEND_APPR = "CE_WKFLW_PEND_APPR";
		public static final String CE_WKFLW_PEND_SUPP = "CE_WKFLW_PEND_SUPP";
		public static final String CE_WKFLW_APPR = "CE_WKFLW_APPR";
		public static final String CE_WKFLW_REJ = "CE_WKFLW_REJ";
		public static final String CE_WKFLW_ROUTED = "CE_WKFLW_ROUTED";

		public static final String PAY_WKFLW_PEND_APPR = "PAY_WKFLW_PEND_APPR";
		public static final String PAY_WKFLW_APPR = "PAY_WKFLW_APPR";
		public static final String PAY_WKFLW_REJ = "PAY_WKFLW_REJ";

		public static final String TG_ACTIVE = "TG_A";
		public static final String TG_INACTIVE = "TG_I";
		public static final String TG_CANCELLED = "TG_C";
		public static final String TG_REVOKED = "TG_R";
		public static final String TG_SUSPENDED = "TG_S";

		@Deprecated // to use PENDING PO/VO/AO/HOD/HODIV
		public static final String TG_APP_PENDING_APPROVAL = "TG_APP_PA";
		public static final String TG_APP_PENDING_PO = "TG_APP_PEND_PO";
		public static final String TG_APP_PENDING_AO = "TG_APP_PEND_AO";
		public static final String TG_APP_PENDING_HODIV = "TG_APP_PEND_HODIV";
		public static final String TG_APP_APPROVED = "TG_APP_APPR";
		public static final String TG_APP_RFA = "TG_APP_RFA";
		public static final String TG_APP_REJECTED = "TG_APP_REJ";

		public static final String TG_CSE_ACTIVE = "TG_CSE_A";
		public static final String TG_CSE_INACTIVE = "TG_CSE_I";

		public static final String TG_CANDIDATE_RESULT_COMPETENT = "TG_CANDIDATE_RESULT_COMPETENT";
		public static final String TG_CANDIDATE_RESULT_INCOMPETENT = "TG_CANDIDATE_RESULT_INCOMPETENT";

		public static final String TG_MLPT_ALLOC_DRAFT = "TG_MLPT_ALLOC_DRAFT";
		public static final String TG_MLPT_ALLOC_PUB = "TG_MLPT_ALLOC_PUB";

		public static final String USER_PENDING = "USER_P";
		public static final String USER_ACTIVE = "USER_A";
		public static final String USER_INACTIVE = "USER_I";
		public static final String USER_LOCKED = "USER_L";

		public static final String DOC_TRF_PENDING = "DOC_TRF_PENDING";
		public static final String DOC_TRF_SUCCESS = "DOC_TRF_SUCCESS";
		public static final String DOC_TRF_FAIL = "DOC_TRF_FAIL";

		public static final String TXF_PENDING = "TXF_P";
		public static final String TXF_SUCCESSFUL = "TXF_S";
		public static final String TXF_FAIL = "TXF_F";
		public static final String TXF_RETRY = "TXF_R";
		public static final String TXF_HOUSEKEEP = "TXF_H";
		public static final String TXF_IN_PROGRESS = "TXF_IP";

		public static final String TXF_TO_PUB_PENDING = "TXF_PUB_P";
		public static final String TXF_TO_PUB_SUCCESSFUL = "TXF_PUB_S";
		public static final String TXF_TO_PUB_FAIL = "TXF_PUB_F";
		public static final String TXF_TO_PUB_IN_PROGRESS = "TXF_PUB_IP";

		public static final String SMS_SENT = "SMS_SENT";
		public static final String SMS_FAILED = "SMS_FAILED";

		public static final String CPF_MEDISAVE_Y = "CPF_MEDI_Y";
		public static final String CPF_MEDISAVE_N = "CPF_MEDI_N";
		public static final String CPF_MEDISAVE_INVALID = "CPF_MEDI_I";
		public static final String CPF_MEDISAVE_ERROR = "CPF_MEDI_E";

		public static final String TG_MLPT_COMPETENT = "TG_MLPT_COMP";
		public static final String TG_MLPT_INCOMPETENT = "TG_MLPT_INCOMP";
		public static final String TG_MLPT_ABSENT = "TG_MLPT_ABSENT";
	}

	public static interface PendingApprovalStatuses {
		public static final ImmutableList<String> TA = ImmutableList.of(Statuses.TA_APP_PENDING_APPROVAL, Statuses.TA_APP_PENDING_PO, Statuses.TA_APP_PENDING_VO, Statuses.TA_APP_PENDING_CNE_CO,
				Statuses.TA_APP_PENDING_AO, Statuses.TA_APP_PENDING_HOD, Statuses.TA_APP_PENDING_HODIV);
		public static final ImmutableList<String> TG = ImmutableList.of(Statuses.TG_APP_PENDING_APPROVAL, Statuses.TG_APP_PENDING_PO, Statuses.TG_APP_PENDING_AO, Statuses.TG_APP_PENDING_HODIV);
		public static final ImmutableList<String> TA_CE = ImmutableList.of(Statuses.TA_APP_PENDING_CNE_CO, Statuses.TA_APP_PENDING_HOD);
		public static final Object[] NOT_PENDING_STB_TA = { Statuses.TA_APP_APPROVED, Statuses.TA_APP_REJECTED, Statuses.TA_APP_RFA, Statuses.TA_APP_COMPLETED, Statuses.TA_APP_DRAFT,
				Statuses.TA_APP_NEW, Statuses.TA_APP_PENDING_OA };
		public static final Object[] NOT_PENDING_STB_TG = { Statuses.TG_APP_APPROVED, Statuses.TG_APP_REJECTED, Statuses.TG_APP_RFA };
		public static final Object[] NOT_PENDING_TA = { Statuses.TA_APP_APPROVED, Statuses.TA_APP_REJECTED, Statuses.TA_APP_COMPLETED };
	}

	public static interface PendingTaActionStatuses {
		public static final Object[] TA = { Statuses.TA_APP_PENDING_APPROVAL, Statuses.TA_APP_RFA, Statuses.TA_APP_PENDING_PO, Statuses.TA_APP_PENDING_VO, Statuses.TA_APP_PENDING_AO,
				Statuses.TA_APP_PENDING_HOD, Statuses.TA_APP_PENDING_HODIV };
		public static final Object[] ANNUAL_FILING = { Statuses.TA_FILING_PEND_SUBMISSION, Statuses.TA_FILING_LATE };
		public static final Object[] SUBMISSIONS = { Statuses.TA_FILING_PEND_SUBMISSION, Statuses.TA_FILING_LATE, Statuses.TA_FILING_PEND_APPROVAL, Statuses.TA_FILING_RFA };
	}

	public static interface TaStatuses {
		public static final Object[] GENERALLY_INACTIVE = { Statuses.TA_CEASED, Statuses.TA_REVOKED };
		public static final Object[] GENERALLY_ACTIVE = { Statuses.TA_ACTIVE, Statuses.TA_PEND_SUSPENSION, Statuses.TA_PEND_REVOCATION, Statuses.TA_SUSPENDED, Statuses.TA_PEND_RENEWAL };
		public static final Object[] RENEWAL_ACTIVE = { Statuses.TA_ACTIVE, Statuses.TA_PEND_SUSPENSION, Statuses.TA_PEND_REVOCATION, Statuses.TA_SUSPENDED };
		public static final ImmutableList<String> CE_SIGNING_STATUS = ImmutableList.of(Codes.Statuses.TA_APP_PENDING_PO, Codes.Statuses.TA_APP_PENDING_VO, Codes.Statuses.TA_APP_PENDING_AO,
				Codes.Statuses.TA_APP_PENDING_CNE_CO);
	}

	public static interface TaFilingStatuses {
		public static final Object[] FOR_TA_FILING_REMINDER = { Statuses.TA_FILING_PEND_SUBMISSION, Statuses.TA_FILING_LATE };
	}

	public static interface TgStatuses {
		public static final Object[] WP_ACTIVE = { Statuses.TG_ACTIVE, Statuses.TG_SUSPENDED };
	}

	public static interface WorkflowStatuses {
		public static final Object[] NOT_PENDING_STB_TA = { Statuses.TA_WKFLW_APPROVED, Statuses.TA_WKFLW_REJECTED };
		public static final Object[] NOT_PENDING_STB_TG = { Statuses.TG_WKFLW_APPROVED, Statuses.TG_WKFLW_REJECTED };
		public static final Object[] NOT_PENDING_STB_PAY = { Statuses.PAY_WKFLW_APPR, Statuses.PAY_WKFLW_REJ };
		public static final Object[] FOR_STB_CE = { Statuses.CE_WKFLW_APPR, Statuses.CE_WKFLW_REJ, Statuses.CE_WKFLW_PEND_APPR, Statuses.CE_WKFLW_PEND_SUPP, Statuses.CE_WKFLW_ROUTED };
	}

	public static interface User {
		public static final String SYSTEM = "system";
		public static final String SYSADMIN = "admin";
		public static final String ANONYMOUS = "anonymous";
	}

	public static interface TaStakeholderRoles {
		public static final String STKHLD_KE = "STKHLD_KE";
		public static final String STKHLD_SHAREHOLDER = "STKHLD_SH";
		public static final String STKHLD_DIRECTOR = "STKHLD_DI";
	}

	public static interface Roles {
		public static final String TA_CNE_ENFORCEMENT_OFFICER = "TA_CNE_EO";
		public static final String TG_CNE_ENFORCEMENT_OFFICER = "TG_CNE_EO";
		public static final String CNE_INVESTIGATION_OFFICER = "CNE_IO";
		public static final String CNE_COMPLIANCE_OFFICER = "CNE_CO";
		public static final String TA_PROCESSING_OFFICER = "TA_PO";
		public static final String TA_VERIFYING_OFFICER = "TA_VO";
		public static final String TA_APPROVING_OFFICER = "TA_AO";
		public static final String TA_HEAD_OF_DEPARTMENT = "TA_HOD";
		public static final String HEAD_OF_DIVISION = "HODIV";
		public static final String TG_APPROVING_OFFICER = "TG_AO";
		public static final String TG_PROCESSING_OFFICER = "TG_PO";
		public static final String TG_HEAD_OF_DEPARTMENT = "TG_HOD";
		public static final String TA_VIEWER = "TA_VIEWER";
		public static final String TG_VIEWER = "TG_VIEWER";
		public static final String FINANCE = "FINANCE";
		public static final String SYSTEM_ADMIN = "SYSADM";
		public static final String SUPER = "SUPER";

		// public users
		public static final String TA_PUBLIC = "TA_PUB";
		public static final String TA_CANDIDATE = "TA_CDD";
		public static final String TG_PUBLIC = "TG_PUB";
		public static final String TG_CANDIDATE = "TG_CDD";
		public static final String TP_PUBLIC = "TP_PUB";
		public static final String KE_PUBLIC = "KE_PUB";
	}

	// STB, TA, TG, TG (Portal Id), TG Candidate, TP, KE
	public static interface UserTypes {
		public static final String USER_STB = "USER_STB";
		public static final String USER_PUBLIC = "USER_PUB";
		public static final String USER_PUBLIC_PORTAL = "USER_PUB_POR";
	}

	public static interface LoginTypes {
		public static final String TA_CORPPASS = "TA_CP";
		public static final String TG_SINGPASS = "TG_SP";
		public static final String TG_PORTAL = "TG_P";
		public static final String TP_CORPPASS = "TP_CP";
		public static final String KE_SINGPASS = "KE_SP";
		public static final String STB = "STB";
	}

	public static interface AuthenticationResponse {
		public static final String AUTHENTICATED = "AUTHENTICATED";
		public static final String PASSWORD_INCORRECT = "PASSWORD_INCORRECT";
		public static final String USER_NO_ACCESS = "USER_NO_ACCESS";
		public static final String OTP_INCORRECT = "OTP_INCORRECT";
		public static final String OTP_INVALID_FORMAT = "OTP_INVALID_FORMAT";
		public static final String USER_NOT_FOUND = "USER_NOT_FOUND";
		public static final String USER_INACTIVE = "USER_INACTIVE";
		public static final String USER_ACCT_LOCKED = "USER_ACCT_LOCKED";
		public static final String SSO_HEADER_NOT_FOUND = "SSO_HEADER_NOT_FOUND";
	}

	public static interface FileExtension {
		public static final String XML = "XML";
	}

	public static interface EmailType {
		public static final String TA_LICENCE_CREATION_SUBMISSION = "TA_LICENCE_CREATION_SUBMISSION";
		public static final String TA_LICENCE_CREATION_DRAFT = "TA_LICENCE_CREATION_DRAFT";
		public static final String TA_LICENCE_CREATION_APPROVAL = "TA_LICENCE_CREATION_APPROVAL";
		public static final String TA_LICENCE_CREATION_APPROVAL_IPA = "TA_LICENCE_CREATION_APPROVAL_IPA";
		public static final String TA_UPON_APPROVAL = "TA_UPON_APPROVAL";

		// CR1227
		public static final String TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED = "TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED";

		public static final String TA_UPON_RFA = "TA_UPON_RFA";
		public static final String TA_UPON_REJECTION = "TA_UPON_REJECTION";
		public static final String TA_LICENCE_STATUS_UPDATE = "TA_LICENCE_STATUS_UPDATE";
		public static final String TA_FILING_LATE = "TA_FILING_LATE";
		public static final String TA_KE_DECLARATION = "TA_KE_DECLARATION";
		public static final String TA_LICENCE_RENEWAL_APPROVAL = "TA_LICENCE_RENEWAL_APPROVAL";
		public static final String TA_LICENCE_RENEWAL_APPROVAL_WAIVED = "TA_LICENCE_RENEWAL_APPROVAL_WAIVED";
		public static final String TA_LICENCE_RENEWAL_REMINDER_START = "TA_LICENCE_RENEWAL_REMINDER_START";
		public static final String TA_LICENCE_RENEWAL_REMINDER_MONTHLY = "TA_LICENCE_RENEWAL_REMINDER_MONTHLY";
		public static final String TA_LICENCE_RENEWAL_REMINDER_DEADLINE = "TA_LICENCE_RENEWAL_REMINDER_DEADLINE";
		public static final String TA_LICENCE_EXPIRY_NOTICE = "TA_LICENCE_EXPIRY_NOTICE";
		public static final String TA_FILING_REMINDER_1 = "TA_FILING_REMINDER_1";
		public static final String TA_FILING_REMINDER_2 = "TA_FILING_REMINDER_2";
		public static final String TA_FILING_REMINDER_3 = "TA_FILING_REMINDER_3";
		public static final String TA_FILING_REMINDER_4 = "TA_FILING_REMINDER_4";
		public static final String TA_FILING_REMINDER_5 = "TA_FILING_REMINDER_5";

		// NEW REMINDERS STBTAGPROD-1227
		public static final String TA_NEW_FILING_REMINDER_1 = "TA_NEW_FILING_REMINDER_1";
		public static final String TA_NEW_FILING_REMINDER_2 = "TA_NEW_FILING_REMINDER_2";
		public static final String TA_NEW_FILING_REMINDER_3 = "TA_NEW_FILING_REMINDER_3";
		public static final String TA_NEW_FILING_REMINDER_4 = "TA_NEW_FILING_REMINDER_4";
		public static final String TA_NEW_FILING_REMINDER_5 = "TA_NEW_FILING_REMINDER_5";

		// NEW REMINDERS STBTAGPROD-1227
		public static final String TA_FILING_REMINDER_JUNE = "TA_FILING_REMINDER_JUNE";

		public static final String TA_APP_ADHOC_DOC_SUBMISSION_NOTIFY = "TA_APP_ADHOC_DOC_SUBMISSION_NOTIFY";
		public static final String TA_APP_ADHOC_MA_SUBMISSION_NOTIFY = "TA_APP_ADHOC_MA_SUBMISSION_NOTIFY";
		public static final String TA_FILING_CONDITION_CHANGE_NOTIFY = "TA_FILING_CONDITION_CHANGE_NOTIFY";
		public static final String TA_APP_NET_VALUE_RECTIFICATION_SUBMISSION_NOTIFY = "TA_APP_NET_VALUE_RECTIFICATION_SUBMISSION_NOTIFY";
		public static final String TA_ELICENCE_APPROVAL = "TA_ELICENCE_APPROVAL";
		public static final String TA_BRANCH_APPROVAL = "TA_BRANCH_APPROVAL";
		public static final String TA_TS_APPROVAL = "TA_TS_APPROVAL";
		public static final String TA_COMP_APPROVAL = "TA_COMP_APPROVAL";

		public static final String CNE_UPON_TA_SUBMISSION_APPROVAL = "CNE_UPON_TA_SUBMISSION_APPROVAL";
		public static final String CNE_UPON_TA_SUBMISSION_RFA = "CNE_UPON_TA_SUBMISSION_RFA";
		public static final String CNE_UPON_TA_SUBMISSION = "CNE_UPON_TA_SUBMISSION";
		public static final String CNE_RECT_SHORTFALL_UPON_REJECT = "CNE_RECT_SHORTFALL_UPON_REJECT";
		public static final String CNE_UPON_SHORTFALL_EXTENSION_APPROVAL = "CNE_UPON_SHORTFALL_EXTENSION_APPROVAL";
		public static final String CNE_CASE_LETTER_ISSUANCE = "CNE_CASE_LETTER_ISSUANCE";
		public static final String CNE_COMPO_LETTER = "CNE_COMPO_LETTER";

		public static final String TG_APP_DRAFT = "TG_APP_DRAFT";
		public static final String TG_LICENCE_CANCELLATION = "TG_LICENCE_CANCEL";
		public static final String TG_UPON_APPROVAL = "TG_UPON_APPROVAL";
		public static final String TG_UPON_RFA = "TG_UPON_RFA";
		public static final String TG_UPON_REJECTION = "TG_UPON_REJECTION";
		public static final String TG_NEW_APP_SUBMITTED = "TG_NEW_APP_SUBMIT";
		public static final String TG_LICENCE_COLLECT = "TG_LICENCE_COLLECT";
		public static final String TG_LICENCE_STATUS_UPDATE = "TG_LICENCE_STATUS_UPDATE";
		public static final String TG_PORTAL_ID_ENABLED = "TG_PORTAL_ID_ENABLED";
		public static final String TG_APPLY_MLPT = "TG_APPLY_MLPT";
		public static final String TG_MLPT_SLOT_ALLOCATED = "TG_MLPT_SLOT_ALLOCATED";
		public static final String TG_MLPT_SLOT_RESULT = "TG_MLPT_SLOT_RESULT";
		public static final String TG_RENEWAL_SUBMISSION = "TG_RENEWAL_SUBMISSION";
		public static final String TG_COURSE_UPON_APPROVAL = "TG_COURSE_UPON_APPROVAL";
		public static final String TG_COURSE_UPON_REJECTION = "TG_COURSE_UPON_REJECTION";
		public static final String TG_COURSE_UPON_RFA = "TG_COURSE_UPON_RFA";

		public static final String USER_LOGIN_DETAILS = "USER_LOGIN_DETAILS";
		public static final String USER_QLIKSENSE_LOGIN_DETAILS = "USER_QLIKSENSE_LOGIN_DETAILS";

		public static final String PAYMENT_RECEIPT = "PAYMENT_RECEIPT";
		public static final String PAYMENT_REFUND_APPROVAL = "PAYMENT_REFUND_APPROVAL";

		public static final String TG_CHECK_SCHEDULE_REMINDER = "TG_CHECK_SCHEDULE_REMINDER";
		public static final String TA_CHECK_SCHEDULE_REMINDER = "TA_CHECK_SCHEDULE_REMINDER";

		public static final String TA_CPF_ARREAR_NOTIFICATION = "TA_CPF_ARREAR_NOTIFICATION";

		public static final String TG_LIC_EXPIRY_REMINDER_1 = "TG_LIC_EXPIRY_REMINDER_1";
		public static final String TG_LIC_EXPIRY_REMINDER_2 = "TG_LIC_EXPIRY_REMINDER_2";
		public static final String TG_LIC_EXPIRY_REMINDER_3 = "TG_LIC_EXPIRY_REMINDER_3";
		public static final String TG_LIC_EXPIRED_NOTIFICATION = "TG_LIC_EXPIRED_NOTIFICATION";
		public static final String ATG_PRACTICAL_ASSESSMENT_FEE = "ATG_PRACTICAL_ASSESSMENT_FEE";
		public static final String TG_LICENCE_SWITCH_TIER_FEE = "TG_LICENCE_SWITCH_TIER_FEE";

		public static final String TAG_LMS_SEND_XML_FAILURE = "TAG_LMS_SEND_XML_FAILURE";
		public static final String TAG_LMS_SEND_XML_ATTACH = "TAG_LMS_SEND_XML_ATTACH";
		public static final String LMS_TAG_RECEIVE_XML_FAILURE = "LMS_TAG_RECEIVE_XML_FAILURE";

	}

	public static interface Placeholders {
		public static final String PUBLIC_PORTAL = "${public_portal_url}";
		public static final String CURRENT_DATE = "${current_date}";
		public static final String EXTERNAL_REMARKS = "${external_remarks}";

		public static final String TA_NAME = "${ta_name}";
		public static final String TA_UEN = "${ta_uen}";
		public static final String KE_NAME = "${ke_name}";

		public static final String KE_UIN = "${ke_uin}";

		public static final String TG_NAME = "${tg_name}";
		public static final String TG_NRIC = "${tg_nric}";
		public static final String TG_REMARK = "${tg_remark}";
		public static final String TG_WORKPASS_TYPE = "${tg_workpass_type}";
		public static final String TG_LIC_COLLECTION_START_DATE = "${collection_start_date}";
		public static final String TG_LIC_COLLECTION_END_DATE = "${collection_end_date}";
		public static final String TG_MLPT_START_DATE = "${mlpt_start_date}";
		public static final String TG_MLPT_END_DATE = "${mlpt_end_date}";
		public static final String TG_MLPT_ALLOCATIONS = "${mlpt_allocations}";
		public static final String TG_MLPT_RESULTS = "${mlpt_results}";
		public static final String TG_COURSE_NAME = "${tg_course_name}";
		public static final String TP_NAME = "${tp_name}";

		public static final String APP_TYPE = "${app_type}";
		public static final String APP_STATUS = "${app_status}";
		public static final String APP_LINK = "${app_link}";
		public static final String APP_REF = "${app_ref}";
		public static final String APP_AMOUNT = "${app_amount}";
		public static final String SEC_APP_AMOUNT = "${sec_main_app_amount}";
		public static final String APP_SUBMISISON_DATE = "${app_submission_date}";

		public static final String TA_LICENCE_CREATION_APPNAME = "${ta_licence_creation_appname}";
		public static final String TA_LICENCE_CREATION_DRAFT_EXPIRY = "${ta_licence_creation_draft_expiry}";
		public static final String TA_LICENCE_UPDATE_ACTION = "${ta_licence_update_action}";
		public static final String TA_SHORTFALL_RECTIFICATION_DUE_DATE = "${rectification_due_date}";

		public static final String TA_RENEWAL_EXERCISE_END_DATE = "${renewal_exercise_end_date}";
		public static final String TA_RENEWAL_EXERCISE_START_DATE = "${renewal_exercise_start_date}";
		public static final String TA_RENEWAL_EXERCISE_LATE_DATE = "${renewal_exercise_late_date}";
		public static final String TA_RENEWAL_EXERCISE_YEAR = "${renewal_exercise_year}";
		public static final String TA_lICENCE_EXPIRY_DATE = "${licence_expiry_date}";
		public static final String TA_lICENCE_EXPIRY_DATE_AFTER = "${licence_expiry_date_after}";
		public static final String TA_FILING_AMENDED_LIST = "${amended_filing_list}";

		public static final String LICENCE_UPDATE_ACTION = "${licence_update_action}";

		public static final String USER_NAME = "${user_name}";
		public static final String LOGIN_ID = "${login_id}";
		public static final String PASSWORD = "${password}";

		public static final String OFFICER_NAME = "${officer_name}";
		public static final String OFFICER_DEPT = "${officer_department}";
		public static final String STB_ORGANISATION = "${stb_organisation}";
		public static final String TA_SUPPORT_EMAIL = "${ta_support_email}";
		public static final String TG_SUPPORT_EMAIL = "${tg_support_email}";

		public static final String TG_MLPT_LANGUAGE = "${tg_test_language}";

		public static final String COMPANY_NAME = "${company_name}";
		public static final String OUTSTANDING_SUBMISSION = "${outstanding_submission}";
		public static final String OUTSTANDING_SUBMISSION_LIST = "${outstanding_submission_list}";
		public static final String OUTSTANDING_SUBMISSION_WITH_DATE = "${outstanding_submission_with_date}";

		public static final String PAY_AMT = "${pay_amt}";
		public static final String PAY_DATE = "${pay_date}";
		public static final String PAY_TXN_ID = "${pay_txn_id}";
		public static final String PAY_REQ_TYPE = "${pay_req_type}";

		public static final String PAY_REF_NO = "${pay_ref_no}";
		public static final String PAY_REF_AMT = "${pay_ref_amt}";

		// CE Tasks
		public static final String AMOUNT = "${amount}";
		public static final String DUE_DATE = "${due_date}";
		public static final String PERIOD = "${period}";
		public static final String FYE = "${fye}";
		public static final String EXTENSION = "${extension}";
		public static final String FYE_OLD = "${fye_old}";
		public static final String FYE_NEW = "${fye_new}";
		public static final String RESIGNATION_DATE = "${resignation_date}";
		public static final String CEASED_DATE = "${ceased_date}";
		public static final String BILL_REF_NO = "${bill_ref_no}";
		public static final String PROVISION = "${provision}";
		public static final String END_DATE = "${end_date}";

		// CE Letter Issuance
		public static final String DEFENDANT = "${defendant}";
		public static final String INFRINGEMENTS = "${infringement_list}";
		public static final String CASE_TASK = "${case_task}";
		public static final String CASE_NO = "${case_no}";
		public static final String CHILD_CASE_NO = "${child_case}";

		public static final String EXPIRY_DAY = "${expiry_day}";

		// Email Broadcast
		public static final String LIC_NO = "${Licence_no}";
		public static final String RECIPIENT_NAME = "${Recipient_name}";
		public static final String RECIPIENT_HOME_ADDRESS = "${Recipient_home_address}";
		public static final String RECIPIENT_DESIGNATION = "${Recipient_designation}";
		public static final String SALUTATION_FORMAL = "${Salutation_Sir_Mdm}";
		public static final String SALUTATION_BASIC = "${Salutation_Mr_Ms}";
		public static final String MAIN_OPERATING_ADDRESS = "${Main_operating_address}";
		public static final String MAIN_REGISTERED_ADDRESS = "${Main_registered_address}";
		public static final String LIC_TYPE = "${Licence_type}";
		public static final String LIC_STATUS = "${Licence_status}";
		public static final String DIRECTOR_NAME = "${Director_name}";

		// TG Licence Expiry Reminder
		public static final String TG_SALUTATION = "${tg_salutation}";
		public static final String TG_LICENCE_EXPIRY_DATE = "${tg_lic_expiry_date}";
		public static final String TG_LICENCE_EXPIRY_DATE_1_MTH_B4 = "${tg_lic_expiry_date_1_mth_b4}";

		// TG Licence Expired Notification
		public static final String EFFECTIVE_DATE = "${effective_date}";
		public static final String RETURN_BADGE_DATE = "${return_badge_date}";

		public static final String TG_AREA = "${specialisationArea}";
		// TA Shortfall
		public static final String TA_SHORTFALL_FOR = "${shortfall_for}";
		public static final String TA_MIN_FINANCIAL_REQUIREMENT = "${ta_mfr}";
		public static final String TA_RECTIFICATION_DUE_DATEE = "${rectification_due_date}";
		public static final String TA_SHORTFALL_AMOUNT = "${shortfall_amt}";
		public static final String LICENCE_NO = "${licence_no}";
		public static final String NET_VALUE = "${net_value}";

		// STB LMS Email Failure
		public static final String TG_DATA_LMS_ERROR = "${tg_data_lms_error}";
		public static final String TG_MRC_LMS_ERROR = "${tg_mrc_lms_error}";
	}

	public static interface RenewalStatus {
		public static final String RENEWAL_BLANK = "RENEWAL_BLANK";
		public static final String RENEWAL_TICK = "RENEWAL_TICK";
		public static final String RENEWAL_GREY = "RENEWAL_GREY";
		public static final String RENEWAL_GREY_TEMP = "RENEWAL_GREY_TEMP";
		public static final String RENEWAL_HIDE = "RENEWAL_HIDE";
	}

	public static interface renewalConditions {
		public static final String RENEWAL_MRC = "RENEWAL_MRC";
		public static final String RENEWAL_PDC = "RENEWAL_PDC";
		public static final String RENEWAL_ASSIGNMENTS = "RENEWAL_ASSIGNMENTS";
		public static final String RENEWAL_CPF = "RENEWAL_CPF";
		public static final String RENEWAL_NEW_PHOTO = "RENEWAL_NEW_PHOTO";
		public static final String RENEWAL_MEDICAL_REPORT = "RENEWAL_MEDICAL_REPORT";
		public static final String RENEWAL_WORK_PASS = "RENEWAL_WORK_PASS";
		public static final String RENEWAL_LICENCE_FEE = "RENEWAL_LICENCE_FEE";
	}

	public static interface LicenceRenewalStatus {
		public static final String NONE = "NONE";
		public static final String RENEWAL = "TG_RENEWAL";
		public static final String REINSTATE_B4_3YR = "TG_REINSTATE_B4_3YR";
		public static final String REINSTATE_AF_3YR = "TG_REINSTATE_AF_3YR";
		public static final String OVERDUE = "TG_OVERDUE";
	}

	public static interface LicenceRenewalType {
		public static final String NONE = "NONE";
		public static final String RENEWAL = "TG_RENEWAL";
		public static final String REINSTATE = "TG_REINSTATE";
		public static final String OVERDUE = "TG_OVERDUE";
	}

	public static interface AlertStatus {
		public static final String READ = "ALERT_R";
		public static final String UNREAD = "ALERT_U";
		public static final String DELETED = "ALERT_D";
	}

	public static interface NumericalRepresent {
		public static final BigDecimal NEG_INFINIY_BIG_DECIMAL = new BigDecimal("-999999999999999");
		public static final BigDecimal POS_INFINIY_BIG_DECIMAL = new BigDecimal("999999999999999");
	}

	public static interface JobName {
		public static final String TaReportGenerationJob = "gov.stb.tag.job.TaReportGenerationJob";
	}

	public static interface FileHeader {
		public static final String[] TG_LICENCE_PRINT = new String[] { "Licence Type", "Badge No.", "Name (Line 1)", "Column 1", "Name (Line 2)", "Cal2", "Language 1", "Language 2", "Language 3",
				"Language 4", "Language 5", "Language 6", "Language 7", "Language 8", "Language 9", "Expiry Date" };
	}

	public static interface TaRenewalTypes {
		public static final String TA_RENEW_EXPRESS = "TA_RENEW_EX_EXP";
		public static final String TA_RENEW_CUSTOMISED = "TA_RENEW_EX_CUS";
	}

	public static interface TaAdhocReqTypes {
		public static final String TA_REQ_ADHOC_DOCS = "TA_REQ_ADHOC_DOCS";
		public static final String TA_REQ_ADHOC_MA = "TA_REQ_ADHOC_MA";
	}

	@SuppressWarnings("serial")
	public static final Map<String, List<String>> TA_ADHOC_REQS = Collections.unmodifiableMap(new HashMap<String, List<String>>() {
		{
			put(TaAdhocReqTypes.TA_REQ_ADHOC_DOCS, Arrays.asList(Workflow.TA_WKFLW_ADHOC_DOC_REQ, ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION));
			put(TaAdhocReqTypes.TA_REQ_ADHOC_MA, Arrays.asList(Workflow.TA_WKFLW_ADHOC_MA_REQ, ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION));
		}
	});

	@SuppressWarnings("serial")
	public static final Map<String, List<String>> TA_APP_LINKS = Collections.unmodifiableMap(new HashMap<String, List<String>>() {
		{
			put(ApplicationTypes.TA_APP_ADHOC_DOC_SUBMISSION, Arrays.asList("ta-doc-submission/", EmailType.TA_APP_ADHOC_DOC_SUBMISSION_NOTIFY));
			put(ApplicationTypes.TA_APP_ADHOC_MA_SUBMISSION, Arrays.asList("ta-ma-submission/", EmailType.TA_APP_ADHOC_MA_SUBMISSION_NOTIFY));
			put(ApplicationTypes.TA_APP_MA_SUBMISSION, Arrays.asList("ta-ma-submission/", EmailType.TA_APP_ADHOC_MA_SUBMISSION_NOTIFY));
		}
	});

	@SuppressWarnings("serial")
	public static final Map<String, List<String>> TA_WKFLW_TYPE_MAP = Collections.unmodifiableMap(new HashMap<String, List<String>>() {
		{
			put(Workflow.TA_WKFLW_ADHOC_DOC_REQ, Arrays.asList(TaAdhocReqTypes.TA_REQ_ADHOC_DOCS));
			put(Workflow.TA_WKFLW_ADHOC_MA_REQ, Arrays.asList(TaAdhocReqTypes.TA_REQ_ADHOC_MA));
			put(Workflow.TA_WKFLW_FILING_AMEND, Arrays.asList(Workflow.TA_WKFLW_FILING_AMEND));
		}
	});

	public static interface Workflow {
		public static final String TA_WKFLW_RENEW_EX = "TA_WKFLW_RENEW_EX";
		public static final String TA_WKFLW_SHORTFALL = "TA_WKFLW_SHORTFALL";
		public static final String TA_WKFLW_EXTENSION_PREM = "TA_WKFLW_EXTENSION_PREM";
		public static final String TA_WKFLW_EXTENSION_DETL = "TA_WKFLW_EXTENSION_DETL";
		public static final String TA_WKFLW_ADHOC_MA_REQ = "TA_WKFLW_ADHOC_MA_REQ";
		public static final String TA_WKFLW_ADHOC_DOC_REQ = "TA_WKFLW_ADHOC_DOC_REQ";
		public static final String TA_WKFLW_FILING_AMEND = "TA_WKFLW_FILING_AMEND";

		public static final String CE_WKFLW_TA_SCHEDULE = "CE_WKFLW_TA_SCHEDULE";
		public static final String CE_WKFLW_TG_SCHEDULE = "CE_WKFLW_TG_SCHEDULE";

		public static final String CE_WKFLW_TA_CASE_TASK_RECOMMEND = "CE_WKFLW_TA_CASE_TASK_RECOMMEND";
		public static final String CE_WKFLW_TA_CASE_TASK_DECISION = "CE_WKFLW_TA_CASE_TASK_DECISION";
		public static final String CE_WKFLW_TA_CASE_TASK_APPEAL = "CE_WKFLW_TA_CASE_TASK_APPEAL";
		public static final String CE_WKFLW_TA_CASE_TASK_RESCIND = "CE_WKFLW_TA_CASE_TASK_RESCIND";
		public static final String CE_WKFLW_TA_CASE_TASK_LIFT = "CE_WKFLW_TA_CASE_TASK_LIFT";
		public static final String CE_WKFLW_TA_IP_COMPO_IMPOSE = "CE_WKFLW_TA_IP_COMPO_IMPOSE";
		public static final String CE_WKFLW_TG_CASE_TASK_RECOMMEND = "CE_WKFLW_TG_CASE_TASK_RECOMMEND";
		public static final String CE_WKFLW_TG_CASE_TASK_DECISION = "CE_WKFLW_TG_CASE_TASK_DECISION";
		public static final String CE_WKFLW_TG_CASE_TASK_APPEAL = "CE_WKFLW_TG_CASE_TASK_APPEAL";
		public static final String CE_WKFLW_TG_CASE_TASK_RESCIND = "CE_WKFLW_TG_CASE_TASK_RESCIND";
		public static final String CE_WKFLW_TG_CASE_TASK_LIFT = "CE_WKFLW_TG_CASE_TASK_LIFT";
		public static final String CE_WKFLW_TG_IP_COMPO_IMPOSE = "CE_WKFLW_TG_IP_COMPO_IMPOSE";

		public static final String PAY_WKFLW_REFUND_TA = "PAY_WKFLW_REFUND_TA";
		public static final String PAY_WKFLW_REFUND_TG = "PAY_WKFLW_REFUND_TG";

		public static final List<String> CE_CASE = Arrays.asList(Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND, Workflow.CE_WKFLW_TA_CASE_TASK_DECISION, Workflow.CE_WKFLW_TA_CASE_TASK_APPEAL,
				Workflow.CE_WKFLW_TA_CASE_TASK_RESCIND, Workflow.CE_WKFLW_TA_CASE_TASK_LIFT, Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND, Workflow.CE_WKFLW_TG_CASE_TASK_DECISION,
				Workflow.CE_WKFLW_TG_CASE_TASK_APPEAL, Workflow.CE_WKFLW_TG_CASE_TASK_RESCIND, Workflow.CE_WKFLW_TG_CASE_TASK_LIFT, Workflow.CE_WKFLW_TA_IP_COMPO_IMPOSE,
				Workflow.CE_WKFLW_TG_IP_COMPO_IMPOSE);
	}

	public static interface WorkflowStep {
		public static final String WKFLW_STEP_TA_APPLICATION = "WKFLW_STEP_TA_APP";
		public static final String WKFLW_STEP_TA = "WKFLW_STEP_TA";
		public static final String WKFLW_STEP_TG_APPLICATION = "WKFLW_STEP_TG_APP";
		public static final String WKFLW_STEP_TG = "WKFLW_STEP_TG";
		public static final String WKFLW_STEP_CE = "WKFLW_STEP_CE";
		public static final String WKFLW_STEP_PAY = "WKFLW_STEP_PAY";

		public static final ImmutableList<String> WKFLW_APPLICATION = ImmutableList.of(WKFLW_STEP_TA_APPLICATION, WKFLW_STEP_TG_APPLICATION);
	}

	public static interface WorkflowActionTypes {
		public static final String SUBMIT = "WKFLW_ACT_SUBM";
		public static final String FORWARD = "WKFLW_ACT_FWD";
		public static final String RFA = "WKFLW_ACT_RFA";
		public static final String ROUTE = "WKFLW_ACT_ROUTE";
		public static final String APPROVE = "WKFLW_ACT_APPR";
		public static final String REJECT = "WKFLW_ACT_REJ";
		public static final String ADD_NOTE = "WKFLW_ACT_NOTE";
		public static final String EDIT = "WKFLW_ACT_EDIT";
		public static final String WORKFLOW_UPDATE = "WKFLW_ACT_CONFIG";
		public static final String RE_ASSIGN = "WKFLW_ACT_REASSIGN";
		public static final String FOLLOW_UP = "WKFLW_ACT_FOLLOW_UP";
	}

	public static interface FLAGS {
		public static final String FLAG_Y = "FLAG_Y";
		public static final String FLAG_N = "FLAG_N";
		public static final String FLAG_NA = "FLAG_NA";
	}

	public static interface Constants {
		public static final String YES = "YES";
		public static final String NO = "NO";
		public static final String NA = "NA";
		public static final Integer CE_SCHEDULE_START_YEAR = 2019;
		public static final Integer CE_SCHEDULE_ADDITIONAL_WEEKS = 4;
		public static final String CE_TA_CHECKS_SCHEDULE_NAME = "Monthly TA Check Schedule";
		public static final String CE_TG_CHECKS_SCHEDULE_NAME = "Weekly TG Check Schedule";
		public static final String CE_TA_CHECKS_REPORT = "TA Check Report";
		public static final String CE_TG_CHECKS_REPORT = "TG Check Report";
		public static final String CE_TA_CHECK_COMPLIANT = "TA Compliant Check";
	}

	public static interface AddressType {
		public static final String TA_ADDR_REG = "TA_ADDR_REG";
		public static final String TA_ADDR_OP = "TA_ADDR_OP";
		public static final String TA_ADDR_BRANCH = "TA_ADDR_BRANCH";
	}

	public static interface CeTaskStatus {
		public static final String CE_TASK_FOR_INFO = "CE_TASK_FOR_INFO";
		public static final String CE_TASK_TO_RECOMMEND = "CE_TASK_TO_RECOMMEND";
		public static final String CE_TASK_TO_IMPOSE_DECISION = "CE_TASK_TO_IMPOSE_DECISION";
		public static final String CE_TASK_TO_APPEAL = "CE_TASK_TO_APPEAL";
		public static final String CE_TASK_TO_ACKNOWLEDGE = "CE_TASK_TO_ACKNOWLEDGE";
		public static final String CE_TASK_COMPLETED = "CE_TASK_COMPLETED";
		public static final String CE_TASK_TO_SUPPORT = "CE_TASK_TO_SUPPORT";
		public static final String CE_TASK_TO_APPROVE = "CE_TASK_TO_APPROVE";
		public static final String CE_TASK_TO_SUBMIT = "CE_TASK_TO_SUBMIT";
		public static final String CE_TASK_TO_PAY = "CE_TASK_TO_PAY";
		public static final String CE_TASK_TO_IP = "CE_TASK_TO_IP";
		public static final String CE_TASK_TO_UPDATE_LETTER_DATE = "CE_TASK_TO_UPDATE_LETTER_DATE";
		public static final String CE_TASK_TO_REVISIT = "CE_TASK_TO_REVISIT";
		public static final String CE_TASK_TO_RESCIND = "CE_TASK_TO_RESCIND";
		public static final String CE_TASK_TO_REPLY_MTI = "CE_TASK_TO_REPLY_MTI";
		public static final String CE_TASK_MTI_PENDING = "CE_TASK_MTI_PENDING";
		public static final String CE_TASK_PAID = "CE_TASK_PAID";
		public static final String CE_TASK_PEND_REFUND = "CE_TASK_PEND_REFUND";

	}

	public static interface CeSubmissionStatus {
		public static final String STAT_CE_SUBMISSION_PENDING = "STAT_CE_SUBMISSION_PENDING";
		public static final String STAT_CE_SUBMISSION_SUBMITTED = "STAT_CE_SUBMISSION_SUBMITTED";
		public static final String STAT_CE_NEW = "STAT_CE_NEW";
		public static final String STAT_CE_SUBMISSION_DRAFT = "STAT_CE_SUBMISSION_DRAFT";

	}

	public static interface CeCheckStatus {
		public static final String STAT_CE_TA_CHECK_COMPLETED = "STAT_CE_TA_CHECK_COMPLETED";
		public static final String STAT_CE_TA_CHECK_RECHECK = "STAT_CE_TA_CHECK_RECHECK";
		public static final String STAT_CE_TA_CHECK_REVISIT = "STAT_CE_TA_CHECK_REVISIT";
	}

	public static interface CeTaskTypes {
		public static final String CE_TASK_TAR_R9 = "CE_TASK_TAR_R9"; // shortfall
		public static final String CE_TASK_TAR_R7_A = "CE_TASK_TAR_R7_A"; // cessation
		public static final String CE_TASK_TAR_R7_B = "CE_TASK_TAR_R7_B"; // cessation
		public static final String CE_TASK_TAR_R8 = "CE_TASK_TAR_R8"; // revocation
		public static final String CE_TASK_TAR_R13 = "CE_TASK_TAR_R13"; // fye
		public static final String CE_TASK_TAR_R14_1A = "CE_TASK_TAR_R14_1A"; // ABPR
		public static final String CE_TASK_TAR_R14_1B = "CE_TASK_TAR_R14_1B"; // AA
		public static final String CE_TASK_TAR_R15_3A = "CE_TASK_TAR_R15_3A"; // KE RESIGN
		public static final String CE_TASK_TAR_R15_3B = "CE_TASK_TAR_R15_3B"; // KE VACANT
		public static final String CE_TASK_TAR_S7A_3 = "CE_TASK_TAR_S7A_3"; // Impose Licensing Condition
		public static final String CE_TASK_TA_CHECK_NC = "CE_TASK_TA_CHECK_NC";
		public static final String CE_TASK_TA_CHECK_COMPLIANT = "CE_TASK_TA_CHECK_C";
		public static final String CE_TASK_RECOMMEND = "CE_TASK_RECOMMEND";
		public static final String CE_TASK_DECISION = "CE_TASK_DECISION";
		public static final String CE_TASK_APPEAL = "CE_TASK_APPEAL";
		public static final String CE_TASK_RESCIND = "CE_TASK_RESCIND";
		public static final String CE_TASK_PAYMENT_EXPIRY = "CE_TASK_PAYMENT_EXPIRY";
		public static final String CE_TASK_TA_CHECK_SCHEDULE = "CE_TASK_TA_CHECK_SCHEDULE";
		public static final String CE_TASK_TG_CHECK_SCHEDULE = "CE_TASK_TG_CHECK_SCHEDULE";
		public static final String CE_TASK_TA_CHECK = "CE_TASK_TA_CHECK";
		public static final String CE_TASK_TG_CHECK = "CE_TASK_TG_CHECK";
		public static final String CE_TASK_PAYMENT_PENDING = "CE_TASK_PAYMENT_PENDING";
		public static final String CE_TASK_PAYMENT_SETTLED = "CE_TASK_PAYMENT_SETTLED";
		public static final String CE_TASK_IP = "CE_TASK_IP";
		public static final String CE_TASK_SUSPEND_END = "CE_TASK_SUSPEND_END";
		public static final String CE_TASK_CHECK_REVISIT = "CE_TASK_CHECK_REVISIT";
		public static final String CE_TASK_REPLY_MTI = "CE_TASK_REPLY_MTI";
		public static final String CE_TASK_PEND_MTI = "CE_TASK_PEND_MTI";

	}

	public static interface CeCaseType {
		public static final String CE_CASE = "CE_CASE";
		public static final String IP = "IP";
	}

	public static interface CeCaseStatus {
		public static final String CE_CASE_LIVE = "CE_CASE_LIVE";
		public static final String CE_CASE_CLOSED = "CE_CASE_CLOSED";
	}

	public static interface CeProvisionSection {
		public static final String MFR_NV_GENERAL_SOLE_PROPRIETOR_OR_PARTNER = "r.9(1)(a)";
		public static final String MFR_NV_GENERAL_COMPANY = "r.9(1)(b)";
		public static final String MFR_NV_NICHE_SOLE_PROPRIETOR_OR_PARTNER = "r.9(1A)(a)";
		public static final String MFR_NV_NICHE_COMPANY = "r.9(1A)(b)";
		public static final String FINANCIAL_REQUIREMENT_AA = "r.14(1)(b)";
		public static final String FINANCIAL_REQUIREMENT_ABPR = "r.14(1)(a)";
		// public static final String FINANCIAL_REQUIREMENT_OTHER = "r.14(1)(c)";
		public static final String FYE = "r.13";
		public static final String KE_RESIGNATION_LATE_SUBMISSION = "r.15(3)(a)";
		public static final String KE_VACANT = "r.15(3)(b)";
		public static final String CESSATION_LATE_SUBMISSION = "r.7(a)";
		public static final String CESSATION_NO_RETURN_LICENCE = "r.7(b)";
		public static final String REVOCATION_NO_RETURN_LICENCE = "r.8";
		public static final String TATI_1 = "r.21(1)";
		public static final String TATI_2 = "r.21(3)";
		public static final String TA_CHECK_NON_RENEWAL = "s.6(1)";
		public static final String IMPOSE_LICENSING_CONDITION = "s.7A(3)";
	}

	public static interface FrontEndUrl {
		public static final String VIEW_CASE = "/ce-case";
		public static final String VIEW_IP = "/ce-ip";
		public static final String VIEW_TA_CHECKS_SCHEDULE = "/ce-ta-checks-schedule";
		public static final String VIEW_TG_CHECKS_SCHEDULE = "/ce-tg-checks-schedule";
		public static final String VIEW_TA_CHECKS_REPORT = "/ce-ta-checks-reports-list";
		public static final String VIEW_TG_CHECKS_REPORT = "/ce-tg-checks-reports";
		public static final String VIEW_CE_TATI_COMPLIANT_CASES = "/ce-tati-check-ack";
	}

	public static interface Permission {
		public static final String VIEW_TA_CASE = "CE_TA_CASE_VW";
		public static final String VIEW_TG_CASE = "CE_TG_CASE_VW";
		public static final String VIEW_IP = "CE_IP_VW";
		public static final String VIEW_TA_CHECKS_SCHEDULE = "CE_TA_SCHEDULE_VW";
		public static final String VIEW_TG_CHECKS_SCHEDULE = "CE_TG_SCHEDULE_VW";
		public static final String VIEW_TA_CHECKS_REPORT = "CE_TA_CHECKS_REPORTS_LIST";
		public static final String VIEW_TG_CHECKS_REPORT = "CE_TG_CHECKS_REPORTS_LIST";
		public static final String CE_TG_GROUND_CHECK_SAVE = "CE_TG_GROUND_CHECK_SAVE";
		public static final String CE_TG_FIELD_REPORT_SAVE = "CE_TG_FIELD_REPORT_SAVE";
		public static final String VIEW_CE_TATI_COMPLIANT_CASES = "CE_TATI_COMPLIANT_CASES_VW";
		public static final String SEARCH_TA_CASE = "CE_DIRECTORY_SEARCH_TA";
		public static final String SEARCH_TG_CASE = "CE_DIRECTORY_SEARCH_TG";
	}

	public static interface Operator {
		public static final String EQUAL = "=";
		public static final String GT = ">";
		public static final String GE = ">=";
		public static final String LT = "<";
		public static final String LE = "<=";
	}

	public static interface DashboardPendingActionTypes {
		public static final String DASHBOARD_WORKPASS_EXPIRY_ALERT = "DASHBOARD_WORKPASS_EXPIRY_ALERT";
		public static final String DASHBOARD_SHORTFALL_LETTER_PEND_ISSUANCE = "DASHBOARD_SHORTFALL_LETTER_PEND_ISSUANCE";
		public static final String DASHBOARD_PAYMENT_PAID = "DASHBOARD_PAYMENT_PAID";
		public static final String DASHBOARD_PAYMENT_PEND_REFUND = "DASHBOARD_PAYMENT_PEND_REFUND";
		public static final String DASHBOARD_TA_LICENCE_PEND_PRINTING = "DASHBOARD_TA_LICENCE_PEND_PRINTING";
		public static final String DASHBOARD_TG_LICENCE_PEND_PRINTING = "DASHBOARD_TG_LICENCE_PEND_PRINTING";
		public static final String DASHBOARD_PAYMENT_PEND_DISBURSEMENT = "DASHBOARD_PAYMENT_PEND_DISBURSEMENT";
		public static final String DASHBOARD_STIPEND_FOLLOW_UP_REQUIRED = "DASHBOARD_STIPEND_FOLLOW_UP_REQUIRED";
	}

	@SuppressWarnings("serial")
	public static final Map<String, List<String>> PAYREQ_ACCESS_RIGHTS = Collections.unmodifiableMap(new HashMap<String, List<String>>() {

		{
			put(Roles.TA_PROCESSING_OFFICER, PAYREQ_VIEWABLE_TYPES.TA);
		}
		{
			put(Roles.TA_VERIFYING_OFFICER, PAYREQ_VIEWABLE_TYPES.TA);
		}
		{
			put(Roles.TA_APPROVING_OFFICER, PAYREQ_VIEWABLE_TYPES.TA);
		}
		{
			put(Roles.TA_HEAD_OF_DEPARTMENT, PAYREQ_VIEWABLE_TYPES.TA);
		}
		{
			put(Roles.HEAD_OF_DIVISION, PAYREQ_VIEWABLE_TYPES.ALL);
		}
		{
			put(Roles.TA_VIEWER, PAYREQ_VIEWABLE_TYPES.TA);
		}
		{
			put(Roles.TA_CNE_ENFORCEMENT_OFFICER, PAYREQ_VIEWABLE_TYPES.TA);
		}
		{
			put(Roles.TG_PROCESSING_OFFICER, PAYREQ_VIEWABLE_TYPES.TG_PO);
		}
		{
			put(Roles.TG_APPROVING_OFFICER, PAYREQ_VIEWABLE_TYPES.TG);
		}
		{
			put(Roles.TG_HEAD_OF_DEPARTMENT, PAYREQ_VIEWABLE_TYPES.TG);
		}
		{
			put(Roles.TG_VIEWER, PAYREQ_VIEWABLE_TYPES.TG);
		}
		{
			put(Roles.TG_CNE_ENFORCEMENT_OFFICER, PAYREQ_VIEWABLE_TYPES.TG);
		}
		{
			put(Roles.CNE_COMPLIANCE_OFFICER, PAYREQ_VIEWABLE_TYPES.ALL);
		}
		{
			put(Roles.CNE_INVESTIGATION_OFFICER, PAYREQ_VIEWABLE_TYPES.ALL);
		}
		{
			put(Roles.FINANCE, PAYREQ_VIEWABLE_TYPES.ALL);
		}
		{
			put(Roles.SUPER, PAYREQ_VIEWABLE_TYPES.ALL);
		}
	});

	public static interface EmailReminder {
		public static final String COUNTDOWN_UNIT_DAY = "UNIT_DAY";
		public static final String COUNTDOWN_UNIT_MONTH = "UNIT_MONTH";

		public static final String COUNTDOWN_PREPOSITION_BEFORE = "PREPOSITION_BEFORE";
		public static final String COUNTDOWN_PREPOSITION_AFTER = "PREPOSITION_AFTER";
		public static final String COUNTDOWN_PREPOSITION_ON = "PREPOSITION_ON";

		public static final String FREQUENCY_ONCE = "FREQUENCY_ONCE";
		public static final String FREQUENCY_MONTHLY = "FREQUENCY_MONTHLY";
	}

	public static interface PAYREQ_VIEWABLE_TYPES {

		public static final List<String> TG = Arrays.asList(TgPaymentRequestTypes.PAYREQ_TG_APP_REPLACEMENT, TgPaymentRequestTypes.PAYREQ_TG_CREATION,
				TgPaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE, TgPaymentRequestTypes.PAYREQ_TG_REINSTATEMENT, TgPaymentRequestTypes.PAYREQ_TG_RENEWAL, TgPaymentRequestTypes.PAYREQ_TG_SWITCH_TIER,
				TgPaymentRequestTypes.PAYREQ_TG_SWITCH_RESIDENTIAL_STATUS, TgPaymentRequestTypes.PAYREQ_TG_MLPT, TgPaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION,
				TgPaymentRequestTypes.PAYREQ_TG_ATG_EXAM, TgPaymentRequestTypes.PAYREQ_TG_STIPEND);

		public static final List<String> TG_PO = Arrays.asList(TgPaymentRequestTypes.PAYREQ_TG_APP_REPLACEMENT, TgPaymentRequestTypes.PAYREQ_TG_CREATION,
				TgPaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE, TgPaymentRequestTypes.PAYREQ_TG_REINSTATEMENT, TgPaymentRequestTypes.PAYREQ_TG_RENEWAL, TgPaymentRequestTypes.PAYREQ_TG_SWITCH_TIER,
				TgPaymentRequestTypes.PAYREQ_TG_SWITCH_RESIDENTIAL_STATUS, TgPaymentRequestTypes.PAYREQ_TG_MLPT, TgPaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION,
				TgPaymentRequestTypes.PAYREQ_TG_ATG_EXAM, TgPaymentRequestTypes.PAYREQ_TG_STIPEND);

		public static final List<String> TA = Arrays.asList(TaPaymentRequestTypes.PAYREQ_TA_BRANCH_A, TaPaymentRequestTypes.PAYREQ_TA_CREATION_A, TaPaymentRequestTypes.PAYREQ_TA_CREATION_L,
				TaPaymentRequestTypes.PAYREQ_TA_REPLACEMENT, CePaymentRequestTypes.PAYREQ_CE_AFP, TaPaymentRequestTypes.PAYREQ_TA_RENEWAL);

		public static final List<String> ALL = Arrays.asList(TgPaymentRequestTypes.PAYREQ_TG_APP_REPLACEMENT, TgPaymentRequestTypes.PAYREQ_TG_CREATION,
				TgPaymentRequestTypes.PAYREQ_TG_PARTICULAR_UPDATE, TgPaymentRequestTypes.PAYREQ_TG_REINSTATEMENT, TgPaymentRequestTypes.PAYREQ_TG_RENEWAL, TgPaymentRequestTypes.PAYREQ_TG_SWITCH_TIER,
				TgPaymentRequestTypes.PAYREQ_TG_SWITCH_RESIDENTIAL_STATUS, CePaymentRequestTypes.PAYREQ_CE_AFP, CePaymentRequestTypes.PAYREQ_CE_COMPOSITION, TaPaymentRequestTypes.PAYREQ_TA_BRANCH_A,
				TaPaymentRequestTypes.PAYREQ_TA_CREATION_A, TaPaymentRequestTypes.PAYREQ_TA_CREATION_L, TaPaymentRequestTypes.PAYREQ_TA_REPLACEMENT, TaPaymentRequestTypes.PAYREQ_TA_RENEWAL,
				TgPaymentRequestTypes.PAYREQ_TG_MLPT, TgPaymentRequestTypes.PAYREQ_TG_MLPT_REGISTRATION, TgPaymentRequestTypes.PAYREQ_TG_ATG_EXAM, TgPaymentRequestTypes.PAYREQ_TG_STIPEND);
	}

	public static interface ComplianceCheckFieldReportType {
		public static final String COMPLIANCE_CHECKS = "CC";
		public static final String TA_FIELD_REPORT = "TA_FR";
		public static final String TG_FIELD_REPORT = "TG_FR";
	}

	public static interface revelantIpType {
		public static final String INTERNAL = "INTERNAL";
		public static final String EXTERNAL = "EXTERNAL";
	}

	public static interface defendantIdType {
		public static final String ENTITY = "CE_ID_TYPE_ENTITY";
		public static final String INDIVIDUAL = "CE_ID_TYPE_INDIVIDUAL";
	}

	public static interface CeOutcomeIp {
		public static final String CE_OUTCOME_IP_ADVISORY = "CE_OUTCOME_IP_ADVISORY";
		public static final String CE_OUTCOME_IP_WARN = "CE_OUTCOME_IP_WARN";
		public static final String CE_OUTCOME_IP_COMPO = "CE_OUTCOME_IP_COMPO";
		public static final String CE_OUTCOME_IP_PROSEC = "CE_OUTCOME_IP_PROSEC";
	}

	public static interface CeRecommendation {
		public static final String CE_OUTCOME_NOD = "CE_OUTCOME_NOD";
		public static final String CE_OUTCOME_NFA = "CE_OUTCOME_NFA";
		public static final String CE_OUTCOME_CAUTION = "CE_OUTCOME_CAUTION";
		public static final String CE_OUTCOME_CIRCULAR = "CE_OUTCOME_CIRCULAR";
		public static final String CE_OUTCOME_COUNSEL = "CE_OUTCOME_COUNSEL";
		public static final String CE_OUTCOME_AFP = "CE_OUTCOME_AFP";
		public static final String CE_OUTCOME_SUSPEND = "CE_OUTCOME_SUSPEND";
		public static final String CE_OUTCOME_REVOKE = "CE_OUTCOME_REVOKE";
		public static final String CE_OUTCOME_CONDITION = "CE_OUTCOME_CONDITION";
		public static final String CE_OUTCOME_OPEN_IP = "CE_OUTCOME_OPEN_IP";
		public static final String CE_OUTCOME_TAG_IP = "CE_OUTCOME_TAG_IP";
		public static final String CE_OUTCOME_RECHECK = "CE_OUTCOME_RECHECK";

		public static final String[] DIRECT_OUTCOME = { CeRecommendation.CE_OUTCOME_NOD, CeRecommendation.CE_OUTCOME_NFA, CeRecommendation.CE_OUTCOME_CAUTION, CeRecommendation.CE_OUTCOME_CIRCULAR,
				CeRecommendation.CE_OUTCOME_COUNSEL, CeRecommendation.CE_OUTCOME_RECHECK };

		public static final String[] OUTCOME_WITH_LETTER_ISSUANCE = { CeRecommendation.CE_OUTCOME_CAUTION, CeRecommendation.CE_OUTCOME_CIRCULAR, CeRecommendation.CE_OUTCOME_COUNSEL };

		public static final String[] OUTCOME_WITH_NOI_NOD = { CeRecommendation.CE_OUTCOME_AFP, CeRecommendation.CE_OUTCOME_SUSPEND, CeRecommendation.CE_OUTCOME_REVOKE };

		public static final String[] COMPLETED_OUTCOME = { CeRecommendation.CE_OUTCOME_NOD, CeRecommendation.CE_OUTCOME_NFA, CeRecommendation.CE_OUTCOME_CAUTION, CeRecommendation.CE_OUTCOME_CIRCULAR,
				CeRecommendation.CE_OUTCOME_COUNSEL, CeRecommendation.CE_OUTCOME_OPEN_IP, CeRecommendation.CE_OUTCOME_TAG_IP };

		public static final String[] EXTERNAL_OUTCOME = { CeRecommendation.CE_OUTCOME_CIRCULAR, CeRecommendation.CE_OUTCOME_COUNSEL, CeRecommendation.CE_OUTCOME_CAUTION,
				CeRecommendation.CE_OUTCOME_AFP, CeRecommendation.CE_OUTCOME_SUSPEND, CeRecommendation.CE_OUTCOME_REVOKE, CeOutcomeIp.CE_OUTCOME_IP_ADVISORY, CeOutcomeIp.CE_OUTCOME_IP_WARN,
				CeOutcomeIp.CE_OUTCOME_IP_COMPO, CeOutcomeIp.CE_OUTCOME_IP_PROSEC };

		public static final String[] EXTERNAL_TG_OUTCOME_MAJOR = { CeRecommendation.CE_OUTCOME_SUSPEND, CeRecommendation.CE_OUTCOME_REVOKE, CeOutcomeIp.CE_OUTCOME_IP_ADVISORY,
				CeOutcomeIp.CE_OUTCOME_IP_WARN, CeOutcomeIp.CE_OUTCOME_IP_COMPO, CeOutcomeIp.CE_OUTCOME_IP_PROSEC };

		public static final String[] EXTERNAL_TG_OUTCOME_MINOR = { CeRecommendation.CE_OUTCOME_COUNSEL, CeRecommendation.CE_OUTCOME_CAUTION };

	}

	public static interface CeAppealResult {
		public static final String CE_APPEAL_RESULT_PEND = "CE_APPEAL_RESULT_PEND";
		public static final String CE_APPEAL_RESULT_REJ = "CE_APPEAL_RESULT_REJ";
		public static final String CE_APPEAL_RESULT_ACD = "CE_APPEAL_RESULT_ACD";
		public static final String CE_APPEAL_RESULT_NO_APPEAL = "CE_APPEAL_RESULT_NO";
	}

	public static interface EmailBroadcastType {
		public static final String TA = "EMAIL_BROADCAST_TA";
		public static final String TG = "EMAIL_BROADCAST_TG";
	}

	public static interface EmailBroadcastFrequency {
		public static final String DAILY = "EMAIL_BROADCAST_DAILY";
		public static final String WEEKLY = "EMAIL_BROADCAST_WEEKLY";
		public static final String MONTHLY = "EMAIL_BROADCAST_MONTHLY";
		public static final String YEARLY = "EMAIL_BROADCAST_YEARLY";
	}

	public static final String[] EmailBroadcastComplicatedPlaceholders = { Placeholders.KE_NAME, Placeholders.RECIPIENT_NAME, Placeholders.RECIPIENT_HOME_ADDRESS, Placeholders.RECIPIENT_DESIGNATION,
			Placeholders.SALUTATION_FORMAL, Placeholders.SALUTATION_BASIC, Placeholders.MAIN_OPERATING_ADDRESS, Placeholders.MAIN_REGISTERED_ADDRESS, Placeholders.DIRECTOR_NAME };

	@SuppressWarnings("serial")
	public static final Map<String, String> EmailBroadcast = Collections.unmodifiableMap(new HashMap<String, String>() {
		{
			put(TaTgType.TA, EmailBroadcastType.TA);
			put(TaTgType.TG, EmailBroadcastType.TG);
		}
	});

	@SuppressWarnings("serial")
	public static final Map<String, String> SupportEmail = Collections.unmodifiableMap(new HashMap<String, String>() {
		{
			put(TaTgType.TA, SystemParameters.TA_SUPPORT_EMAIL);
			put(TaTgType.TG, SystemParameters.TG_SUPPORT_EMAIL);
		}
	});

	public static interface UsersLoginId {
		public static final String JANETF = "stb_janetf";
		public static final String SEOWHUANG = "stb_seowhwang";
		public static final String JINTECKQ = "stb_jinteckq";
	}

	public static interface ComplainantType {
		public static final String CE_COMPLAINANT_PUBLIC = "CE_COMPLAINANT_PUBLIC";
		public static final String CE_COMPLAINANT_STB = "CE_COMPLAINANT_STB";
	}

	public static interface SignDocResults {
		public static final String SUCCESS = "success"; // process completed successfully
		public static final String CANCEL = "cancel"; // process was cancelled by the user.
		public static final String ERROR = "error"; // n there was an error.
	}

	public static interface ELicenceCharacterLimit {
		public static final int CHARACTER_LIMIT = 18;
	}

	public static interface TgInfoType {
		public static final String COMPLIMENT = "360_COMPLIMENT";
		public static final String COMPLAINT = "360_COMPLAINT";
		public static final String OTHERS = "360_OTHERS";
	}

	public static interface LetterType {
		public static final String TA_SHORTFALL_LETTER = "TA_SHORTFALL_LETTER";
	}

	@SuppressWarnings("serial")
	public static final Map<String, String> FileExtContentType = Collections.unmodifiableMap(new HashMap<String, String>() {
		{
			put("doc", "application/msword");
			put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
			put("xls", "application/vnd.ms-excel");
			put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			put("msg", "application/vnd.ms-outlook");
		}
	});

	public static interface ELicenceDownloadRequest {
		public static final int RESET = 0;
		public static final int PENDING_REQUEST = 1;
		public static final int APPROVE = 2;
		public static final int REJECT = 3;
		public static final int NEED_TO_REQUEST = 4;
	}

	public static interface TaRenewalTypesLabel {
		public static final String TA_RENEW_CUSTOMISED_NEW_LABEL = "Standard";
	}

	public static interface InfohubLabel {
		public static final String INFOHUB_BULLETIN_LABEL = "Bulletin Board";
	}

	public static interface ELicenceView {
		public static final int HIDE = 0;
		public static final int VIEW = 1;
	}
}