package gov.stb.tag.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Contains properties required for the compilation of common modules. This class will be overridden by the respective Properties in start-admin and start-public projects which should be annotated
 * with the actual property name in their application.properties.
 */
@Component
public abstract class CommonProperties {

	@Value("${tag.url.portal.application}")
	public String applicationUrl;

	@Value("${tag.dir.base}")
	public String baseDir;

	@Value("${tag.dir.upload.payment-status-span}")
	public String paymentStatusSpanUploadDir;

	@Value("${tag.dir.upload.workflow-action}")
	public String workflowActionUploadDir;

	@Value("${tag.dir.upload.workflow}")
	public String workflowUploadDir;

	@Value("${tag.dir.upload.application}")
	public String applicationUploadDir;

	@Value("${tag.dir.upload.general}")
	public String generalUploadDir;

	@Value("${tag.dir.template.application}")
	public String applicationTemplateDir;

	@Value("${tag.dir.template.report}")
	public String reportTemplateDir;

	@Value("${sms.auth.id}")
	public String smsAuthId;

	@Value("${sms.auth.code}")
	public String smsAuthCode;

	@Value("${sms.endpointUrl}")
	public String smsEndPointUrl;

	@Value("${tag.dir.upload.bulletin}")
	public String bulletinUploadDir;

	public String email;

	public String catchAllEmail;

	public String appEnv;

}
