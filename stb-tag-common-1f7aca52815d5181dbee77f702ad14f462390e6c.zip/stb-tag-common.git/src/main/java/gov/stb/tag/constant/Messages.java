package gov.stb.tag.constant;

public class Messages {

	public static interface Alerts {
		public static final String APP_SUBMISSION = "Your ${app_type} Application (${app_ref}) is being processed and we target to reply within 5 working days.";
		public static final String APP_APPROVE = "Your ${app_type} Application (${app_ref}) has been approved. ";
		public static final String APP_REJECT = "Your ${app_type} Application (${app_ref}) has been rejected. ";
		public static final String APP_RFA = "Your ${app_type} Application (${app_ref}) has been returned for your action. ";
		public static final String TA_APP_RENEWAL_APPROVE = "Your ${app_type} submission (${app_ref}) has been approved. Please make a payment of S$${app_amount} for the licence renewal fee.";
		public static final String TG_LIC_CANCELLED_SUCCESS = "Your licence has been cancelled successfully. ";
		public static final String TG_APP_APPROVE = APP_APPROVE + "We will contact you when your licence is ready for collection. ";
		public static final String TG_RENEWAL_SUBMISSION = "Your ${app_type} Application (${app_ref}) has been approved. We will contact you when your licence is ready for collection. STB may request for additional information/clarifications if required. For clarification, please contact stb_tourist_guide@stb.gov.sg";

		public static final String TA_LICENCE_STATUS_UPDATE = "Your Licence's status has been changed to '${ta_licence_update_action}'. ";

		public static final String TA_SUBMISSION_APPROVE = "Your submission for ${app_type} (${app_ref}) has been approved. ";
		public static final String TA_SUBMISSION_REJECT = "Your submission for ${app_type} (${app_ref}) has been rejected. ";
		public static final String TA_SUBMISSION_RFA = "Your submission for ${app_type} (${app_ref}) has been returned for your action. ";

		public static final String LICENCE_STATUS_UPDATE = "Your Licence's status has been changed to '${licence_update_action}'. ";

		public static final String LICENCE_COLLECT = "Your Licence for ${app_type} Application is ready for collection. ";

		public static final String TG_MLPT_SLOT_ALLOCATED = "You have been registered for MLPT";
		public static final String TG_MLPT_SLOT_SWAP = "You have swapped your MLPT Slot";
		public static final String TG_MLPT_SLOT_RESULT = "You have completed your MLPT";

		public static final String CNE_EXTEND_SHORTFALL_APPROVE = "Your request for extension to submit proof of shortfall rectification has been approved. ";
		public static final String TA_ADHOC_FILING_SUBMISSION_NOTIFY = "You are required to make ${app_type} submission.";

		public static final String APP_FOLLOW_UP = "Your ${app_type} Application (${app_ref}) has been returned for your action. ";

		public static final String ATG_PRACTICAL_ASSESSMENT_FEE = "Please make payment for the Area Tourist Guide Practical Assessment Fee. Please quote Bill Reference Number ${bill_ref_no} when prompted.";
		public static final String TG_LICENCE_SWITCH_TIER_FEE = "Your Application for an Area Tourist Guide licence (${specialisationArea}) (ref no: ${app_ref}) has been approved. Please make payment for the issuance of a new TG licence, incorporating the area of specialisation.";

		public static final String TA_SHORTFALL_RECTIFICATION_NOTIFY = "You are required to make ${app_type} submission.";

		public static final String TA_APP_ELICENCE_APPROVE = "Submission for ${app_type} (ref no: ${app_ref}) has been approved. Please re-download the E-Licence.";
	}

	public static interface Errors {
		public static final String AUTH_NO_TOKEN = "You do not have a valid login session. Please login again.";
		public static final String AUTH_NO_ACCESS = "You are not authorised to access this function.";
		public static final String AUTH_MULTI_SESSIONS = "You have another login session. You may close this browser and continue with your latest login session.";
		public static final String AUTH_EXPIRED = "Your session has expired. Please login again.";
		public static final String AUTH_NOT_TG = "You are not a valid Tourist Guide licence holder. You will be routed back to the home page.";
		public static final String AUTH_NO_SSO_HEADER = "IAMS login details not found.";
		public static final String LOGIN_PASSWORD_INCORRECT = "Your login id or password is incorrect.";
		public static final String LOGIN_NO_ACCESS = "You do not have access to the system.";
		public static final String LOGIN_NOT_PUB = "This mode of login is only meant for public user and authentication is assumed to be done by SPCP";
		public static final String LOGIN_SECRET_MISMATCH = "Secret key does not match.";
		public static final String FILE_HASH_MISMATCH = "File hash does not match.";
		public static final String FILE_NOT_FOUND = "File cannot be found.";
		public static final String UNABLE_TO_RETRIEVE_COLOUR = "Unable to retrieve colour with the licence expiry date";
		public static final String VERSION_CHECK_MISSING_VALUES = "Missing entityName, identifierColumn, identifier and/or version for Version-Check.";
		public static final String VERSION_CHECK_INCORRECT_NO_OF_VALUES = "Version-Check header has incorrect number of values.";
		public static final String VERSION_CHECK_NOT_FOUND = "Current version cannot be found for %s.";
		public static final String VERSION_CHECK_DECRYPTION_FAIL = "Version-Check decryption fail. Please refresh the page and try again.";
		public static final String VERSION_CHECK_MISMATCH = "The record(s) you are updating is outdated. Please refresh the page and try again.";
		public static final String PAYMENT_NO_LONGER_PENDING = "Bill Reference No. (%s) has already been paid or void. Please refresh the page and try again.";
		public static final String PAYMENT_IN_PROGRESS = "Last transaction (ID: %s) for Bill Reference No. (%s) is still in progress. Please try again at a later time.";
		public static final String PAYMENT_REQ_MISSING = "One of the Bill Reference No. cannot be found. Please refresh the page and try again.";

		public static final String MYINFO_NOT_FOUND = "User is not found in MyInfo.";
		public static final String MYINFO_SERVER_ERROR = "MyInfo is currently inaccessible.";
	}

	public static interface CeTaskDetails {
		public static final String R9_SHORTFALL_APPR = "${provision}: ${app_type} of S${amount} is required for submission by ${extension}due date of ${due_date}.";
		public static final String R9_SHORTFALL_LATE = "${provision}: ${app_type} of S${amount} not rectified after ${extension}due date of ${due_date}.";
		public static final String TA_CHECKS_SCHEDULE = "TA Checks Schedule for the month of ${period}";
		public static final String TG_CHECKS_SCHEDULE = "TG Checks Schedule for the week of ${period}";
		public static final String R141_FINANCIAL_REQUIREMENT_GG_LATE = "${provision}: ${app_type} for FYE on ${fye} is required for submission by ${extension}due date of ${due_date}.";
		public static final String R141_FINANCIAL_REQUIREMENT_LATE = "${provision}: ${app_type} for FYE on ${fye} is not submitted within 6 months by ${extension}due date of ${due_date}.";
		public static final String R13_UPDATE_FYE = "${provision}: Change of FYE (from ${fye_old} to ${fye_new}) is not submitted within 6 months after the close of the preceding financial year end on ${fye}.";
		public static final String R15_3A_KE_RESIGN = "${provision}: Key Executive resignation is not submitted within ${period} days since resignation on ${resignation_date}.";
		public static final String R15_3B_KE_RESIGN = "${provision}: Key Executive resigned on ${resignation_date}.";
		public static final String R15_3B_KE_VACANT = "${provision}: Key Executive is vacant for more than ${period} months since ${resignation_date}.";
		public static final String R7A_CESSATION_LATE_SUBMISSION = "${provision}: Licence cessation is not submitted within ${period} days after business ceased on ${ceased_date}.";
		public static final String R7B_CESSATION_NO_RETURN_LICENCE = "${provision}: Licence is not returned within ${period} days after licence ceased on ${ceased_date}.";
		public static final String R8_REVOCATION_NO_RETURN_LICENCE = "${provision}: Licence is not returned within ${period} days after licence revoked on ${ceased_date}.";
		public static final String AFP_PAYMENT = "AFP of ${amount}, ${due_date} due, Bill Ref. No: ${bill_ref_no}";
		public static final String S7A3_IMPOSE_LICENSING_CONDITION = "${provision}: Auditor's opinion for Audited Statement of Accounts was not 'clean opinion' for 2 consecutive years (${fye}).";
		public static final String SUSPENSION_END_SOON = "Suspension will be ended at ${end_date}";
		public static final String CASE_TAG_TO_CASE = "Case no. ${child_case} is tagged to Case no. ${case_no}.";
		public static final String CASE_UPDATE_NOTIFICATION = "[STB-TRUST] Updates for ${case_no}";
	}

}
