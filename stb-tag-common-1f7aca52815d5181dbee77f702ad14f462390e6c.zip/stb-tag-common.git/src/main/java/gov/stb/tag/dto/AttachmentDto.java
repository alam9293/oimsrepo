package gov.stb.tag.dto;

import java.time.LocalDateTime;

import org.springframework.web.multipart.MultipartFile;

import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.WorkflowFile;
import gov.stb.tag.util.FileUtil;

public class AttachmentDto {

	private Integer id;

	private Integer workflowFileId;

	private String hash;

	private String originalName;

	private String docTypeCode;

	private String documentTypeLabel;

	private String description;

	private String readableFileSize;

	private String extension;

	private Long size;

	private String createdBy;

	private LocalDateTime createdDate;

	private MultipartFile file;
	private String filePath;
	private String fileName;

	public static AttachmentDto buildFromWorkflowFile(WorkflowFile wfile, FileHelper fileHelper) {

		AttachmentDto dto = new AttachmentDto();
		if (wfile != null && wfile.getFile() != null) {
			File file = wfile.getFile();
			dto.setId(file.getId());
			dto.setHash(file.getHash());
			dto.setOriginalName(file.getOriginalFilename());
			dto.setWorkflowFileId(wfile.getId());
			dto.setDocTypeCode(wfile.getDocumentType() != null ? wfile.getDocumentType().getCode() : null);
			dto.setDocumentTypeLabel(wfile.getDocumentType() != null ? wfile.getDocumentType().getLabel() : null);
			dto.setDescription(file.getDescription());
			dto.setSize(file.getSize());
			dto.setExtension(file.getExtension());
			dto.setFilePath(file.getPath());
			dto.setFileName(file.getFilename());
			if (file.getSize() != null) {
				dto.setReadableFileSize(FileUtil.readableFileSize(file.getSize()));
			}
			dto.setCreatedBy(file.getCreatedBy());
			dto.setCreatedDate(file.getCreatedDate());
		}
		return dto;

	}

	public static AttachmentDto buildFromFile(File file) {

		AttachmentDto dto = new AttachmentDto();
		if (file != null) {
			dto.setId(file.getId());
			dto.setHash(file.getHash());
			dto.setOriginalName(file.getOriginalFilename());
			dto.setDescription(file.getDescription());
			dto.setSize(file.getSize());
			dto.setExtension(file.getExtension());
			dto.setFileName(file.getFilename());
			dto.setFilePath(file.getPath());
			if (file.getSize() != null) {
				dto.setReadableFileSize(FileUtil.readableFileSize(file.getSize()));
			}
			dto.setCreatedBy(file.getCreatedBy());
			dto.setCreatedDate(file.getCreatedDate());
		}
		return dto;

	}

	public static AttachmentDto buildFromDocType(Type docType) {

		AttachmentDto dto = new AttachmentDto();
		if (docType != null) {
			dto.setDocTypeCode(docType.getCode());
			dto.setDocumentTypeLabel(docType.getLabel());
		}
		return dto;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getWorkflowFileId() {
		return workflowFileId;
	}

	public void setWorkflowFileId(Integer workflowFileId) {
		this.workflowFileId = workflowFileId;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getOriginalName() {
		return originalName;
	}

	public void setOriginalName(String originalName) {
		this.originalName = originalName;
	}

	public String getDocTypeCode() {
		return docTypeCode;
	}

	public void setDocTypeCode(String docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public String getDocumentTypeLabel() {
		return documentTypeLabel;
	}

	public void setDocumentTypeLabel(String documentTypeLabel) {
		this.documentTypeLabel = documentTypeLabel;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReadableFileSize() {
		return readableFileSize;
	}

	public void setReadableFileSize(String readableFileSize) {
		this.readableFileSize = readableFileSize;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
