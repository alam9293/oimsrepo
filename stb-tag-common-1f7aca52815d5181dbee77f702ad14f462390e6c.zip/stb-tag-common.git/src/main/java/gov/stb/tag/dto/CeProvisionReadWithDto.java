package gov.stb.tag.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import gov.stb.tag.annotation.MapProjection;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CeProvisionReadWithDto {

	@MapProjection(path = "id")
	@NotNull(message = "provisionId cannot be null")
	private Integer provisionId;

	@MapProjection(path = "readWiths.id")
	@NotNull(message = "readWithId cannot be null")
	private Integer readWithId;

	public Integer getProvisionId() { return provisionId; }

	public void setProvisionId(Integer provisionId) { this.provisionId = provisionId; }

	public Integer getReadWithId() { return readWithId; }

	public void setReadWithId(Integer readWithId) { this.readWithId = readWithId; }
}
