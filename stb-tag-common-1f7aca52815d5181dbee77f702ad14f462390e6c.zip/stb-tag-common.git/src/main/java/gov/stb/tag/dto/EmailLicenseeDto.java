package gov.stb.tag.dto;

import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TravelAgent;

public class EmailLicenseeDto {

	private Integer licenceId;

	private Integer addressId;

	private Integer travelAgentId;

	private String licNo;

	private String salutation;

	private String name;

	private String email;

	private String mainLicOppAdd = "";

	private String mainLicRegAdd = "";

	private String licType;

	private String licStatus;

	private String dirName = "";

	private String uen;

	private EmailRecipientDto recipient;

	public static EmailLicenseeDto buildBasicFromLicence(Licence model, EmailLicenseeDto dto) {
		dto.setLicenceId(model.getId());
		dto.setLicNo(model.getLicenceNo());
		if (model.getTouristGuide() != null) {
			dto.setName(model.getTouristGuide().getName());
			dto.setSalutation(model.getTouristGuide().getSalutation().getLabel());
			dto.setEmail(model.getTouristGuide().getEmailAddress());
		}
		if (model.getTravelAgent() != null) {
			dto.setName(model.getTravelAgent().getName());
			dto.setEmail(model.getTravelAgent().getEmailAddress());
			dto.setLicType(model.getTier().getLabel());
			dto.setLicStatus(model.getStatus().getLabel());
			dto.setUen(model.getTravelAgent().getUen());
		}
		return dto;

	}

	public static EmailLicenseeDto buildAdvancedFromLicence(TravelAgent model, EmailLicenseeDto dto) {
		if (model != null) {
			if (model.getOperatingAddress() != null) {
				dto.setMainLicOppAdd(model.getOperatingAddress().getFormattedAddressDisplay());
			}
			if (model.getRegisteredAddress() != null) {
				dto.setMainLicRegAdd(model.getRegisteredAddress().getFormattedAddressDisplay());
			}
		}
		return dto;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLicNo() {
		return licNo;
	}

	public void setLicNo(String licNo) {
		this.licNo = licNo;
	}

	public String getLicType() {
		return licType;
	}

	public void setLicType(String licType) {
		this.licType = licType;
	}

	public String getLicStatus() {
		return licStatus;
	}

	public void setLicStatus(String licStatus) {
		this.licStatus = licStatus;
	}

	public String getDirName() {
		return dirName;
	}

	public void setDirName(String dirName) {
		this.dirName = dirName;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getMainLicOppAdd() {
		return mainLicOppAdd;
	}

	public void setMainLicOppAdd(String mainLicOppAdd) {
		this.mainLicOppAdd = mainLicOppAdd;
	}

	public String getMainLicRegAdd() {
		return mainLicRegAdd;
	}

	public void setMainLicRegAdd(String mainLicRegAdd) {
		this.mainLicRegAdd = mainLicRegAdd;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public EmailRecipientDto getRecipient() {
		return recipient;
	}

	public void setRecipient(EmailRecipientDto recipient) {
		this.recipient = recipient;
	}

	public Integer getTravelAgentId() {
		return travelAgentId;
	}

	public void setTravelAgentId(Integer travelAgentId) {
		this.travelAgentId = travelAgentId;
	}

}
