package gov.stb.tag.dto;

import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.model.Stakeholder;

public class EmailRecipientDto {

	private String salutation;

	private String email;

	private String recipientName = "";

	private String recipientHomeAdd = "";

	private String recipientDesignation = "";

	private String genderCode;

	public static EmailRecipientDto buildForRecipient(Stakeholder model, EmailRecipientDto dto) {
		if (model != null) {
			dto.setRecipientName(model.getName());
			dto.setGenderCode(model.getSex() != null ? model.getSex().getCode() : null);
			dto.setEmail(model.getEmail());
			if (model.getDesignation() != null) {
				dto.setRecipientDesignation(model.getDesignation().getCode().equalsIgnoreCase(Types.OCCP_OTHERS) ? model.getOtherDesignation() : model.getDesignation().getLabel());
			}
			dto.setRecipientHomeAdd(model.getAddress().getFormattedAddressDisplay());
		}
		return dto;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRecipientName() {
		return recipientName;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	public String getRecipientHomeAdd() {
		return recipientHomeAdd;
	}

	public void setRecipientHomeAdd(String recipientHomeAdd) {
		this.recipientHomeAdd = recipientHomeAdd;
	}

	public String getRecipientDesignation() {
		return recipientDesignation;
	}

	public void setRecipientDesignation(String recipientDesignation) {
		this.recipientDesignation = recipientDesignation;
	}

	public String getGenderCode() {
		return genderCode;
	}

	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

}
