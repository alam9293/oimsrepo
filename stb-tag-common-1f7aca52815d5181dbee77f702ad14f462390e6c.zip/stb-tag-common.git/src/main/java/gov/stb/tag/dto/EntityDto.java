package gov.stb.tag.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

// Overwrite the below 3 methods - getVersion(), getEntityName(), getEntityId() - to use BaseController's addVersionCheck(EntityDto) or addVersionCheckForListing(ResultDto). 
@JsonInclude(JsonInclude.Include.NON_NULL)
public abstract class EntityDto {

	public String getEntityName() {
		return null;
	}

	public String getEntityId() {
		return null;
	}

	public Integer getVersion() {
		return null;
	}

}
