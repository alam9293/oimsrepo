package gov.stb.tag.dto;

import java.time.LocalDateTime;

import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Type;
import gov.stb.tag.util.FileUtil;

public class FileDto {

	private Integer id;

	private Integer publicFileId;

	private String originalName;

	private String processedName;

	private String docType;

	private String extension;

	private String path;

	private Long size;

	private String hash;

	private String documentInstructions;

	private String documentTypeLabel;

	private String description;

	private String readableFileSize;

	private Boolean hasTemplate;

	private String createdBy;

	private LocalDateTime createdDate;

	private java.io.File physicalFile;

	private String photo;

	private String photoExtension;

	public static FileDto buildFromFile(File file) {
		return buildFromFile(file, null, null);
	}

	public static FileDto buildWithPhysicalFile(File file, java.io.File physicalFile) {
		FileDto dto = new FileDto();
		dto.setPhysicalFile(physicalFile);
		dto.setOriginalName(file.getOriginalFilename());
		return dto;
	}

	public static FileDto buildFromFile(File file, Type docType, FileHelper fileHelper) {
		FileDto dto = new FileDto();
		if (file != null) {
			dto.setId(file.getId());
			dto.setProcessedName(file.getFilename());
			dto.setOriginalName(file.getOriginalFilename());
			dto.setPublicFileId(file.getPublicFileId());
			dto.setExtension(file.getExtension());
			dto.setPath(file.getPath());
			dto.setSize(file.getSize());
			if (file.getSize() != null) {
				dto.setReadableFileSize(FileUtil.readableFileSize(file.getSize()));
			}
			dto.setHash(file.getHash());
			dto.setDescription(file.getDescription());
			dto.setCreatedBy(file.getCreatedBy());
			dto.setCreatedDate(file.getCreatedDate());
		}

		if (docType != null) {
			dto.setDocType(docType.getCode());
			dto.setDocumentInstructions(docType.getOtherLabel());
			dto.setDocumentTypeLabel(docType.getLabel());
			if (fileHelper != null && fileHelper.getTemplate(docType.getCode()) != null) {
				dto.setHasTemplate(true);
			} else {
				dto.setHasTemplate(false);
			}

		}
		return dto;
	}

	public static FileDto buildFromFileForPublic(File file, Type docType, FileHelper fileHelper) {
		FileDto dto = new FileDto();
		if (file != null) {
			dto.setId(file.getId());
			dto.setProcessedName(file.getFilename());
			dto.setOriginalName(file.getOriginalFilename());
			dto.setPublicFileId(file.getPublicFileId());
			dto.setExtension(file.getExtension());
			dto.setSize(file.getSize());
			if (file.getSize() != null) {
				dto.setReadableFileSize(FileUtil.readableFileSize(file.getSize()));
			}
			dto.setHash(file.getHash());
			dto.setDescription(file.getDescription());
		}

		if (docType != null) {
			dto.setDocType(docType.getCode());
			dto.setDocumentInstructions(docType.getOtherLabel());
			dto.setDocumentTypeLabel(docType.getLabel());
			if (fileHelper != null && fileHelper.getTemplate(docType.getCode()) != null) {
				dto.setHasTemplate(true);
			} else {
				dto.setHasTemplate(false);
			}

		}
		return dto;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPublicFileId() {
		return publicFileId;
	}

	public void setPublicFileId(Integer publicFileId) {
		this.publicFileId = publicFileId;
	}

	public String getOriginalName() {
		return originalName;
	}

	public void setOriginalName(String originalName) {
		this.originalName = originalName;
	}

	public String getProcessedName() {
		return processedName;
	}

	public void setProcessedName(String processedName) {
		this.processedName = processedName;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getDocumentInstructions() {
		return documentInstructions;
	}

	public void setDocumentInstructions(String documentInstructions) {
		this.documentInstructions = documentInstructions;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReadableFileSize() {
		return readableFileSize;
	}

	public void setReadableFileSize(String readableFileSize) {
		this.readableFileSize = readableFileSize;
	}

	public String getDocumentTypeLabel() {
		return documentTypeLabel;
	}

	public void setDocumentTypeLabel(String documentTypeLabel) {
		this.documentTypeLabel = documentTypeLabel;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public Boolean getHasTemplate() {
		return hasTemplate;
	}

	public void setHasTemplate(Boolean hasTemplate) {
		this.hasTemplate = hasTemplate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public java.io.File getPhysicalFile() {
		return physicalFile;
	}

	public void setPhysicalFile(java.io.File physicalFile) {
		this.physicalFile = physicalFile;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getPhotoExtension() {
		return photoExtension;
	}

	public void setPhotoExtension(String photoExtension) {
		this.photoExtension = photoExtension;
	}
}
