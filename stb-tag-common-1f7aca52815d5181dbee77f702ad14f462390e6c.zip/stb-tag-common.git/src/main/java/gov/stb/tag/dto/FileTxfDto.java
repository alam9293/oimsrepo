package gov.stb.tag.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileTxfDto {

	@NotNull(message = "publicFileId cannot be null")
	private Integer publicFileId;

	@NotNull(message = "adminFileId cannot be null")
	private Integer adminFileId;

	@NotBlank(message = "hash cannot be blank")
	private String hash;

	private String filename;

	private String originalFilename;

	private String path;

	private Long size;

	private String extension;

	private String description;

	private String transferStatusCode;

	private String transferError;

	private Boolean deleted;

	public Integer getPublicFileId() {
		return publicFileId;
	}

	public void setPublicFileId(Integer publicFileId) {
		this.publicFileId = publicFileId;
	}

	public Integer getAdminFileId() {
		return adminFileId;
	}

	public void setAdminFileId(Integer adminFileId) {
		this.adminFileId = adminFileId;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getOriginalFilename() {
		return originalFilename;
	}

	public void setOriginalFilename(String originalFilename) {
		this.originalFilename = originalFilename;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTransferStatusCode() {
		return transferStatusCode;
	}

	public void setTransferStatusCode(String transferStatusCode) {
		this.transferStatusCode = transferStatusCode;
	}

	public String getTransferError() {
		return transferError;
	}

	public void setTransferError(String transferError) {
		this.transferError = transferError;
	}

	public Boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
}
