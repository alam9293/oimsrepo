package gov.stb.tag.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileTxfListDto {

	@NotBlank(message = "secret cannot be blank")
	private String secret;

	private List<FileTxfDto> fileTxfDtos = new ArrayList<>();

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public List<FileTxfDto> getFileTxfDtos() {
		return fileTxfDtos;
	}

	public void setFileTxfDtos(List<FileTxfDto> fileTxfDtos) {
		this.fileTxfDtos = fileTxfDtos;
	}

}
