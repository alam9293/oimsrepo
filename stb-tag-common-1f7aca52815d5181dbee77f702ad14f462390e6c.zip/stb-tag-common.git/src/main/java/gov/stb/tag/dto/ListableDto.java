package gov.stb.tag.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;
import com.wiz.model.api.Listable;

import gov.stb.tag.model.AbstractType;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListableDto {

	private Serializable key;

	private String label;

	private String otherLabel;

	private Object data; // to facilitate mapping of additional data

	private String type; // to facilitate 1st-level filtering

	private String footNote;

	public ListableDto() {
	}

	public ListableDto(Listable listable) {
		super();
		if (listable != null) {
			this.key = listable.getKey();
			this.label = listable.getLabel();
			this.otherLabel = listable.getOtherLabel();
		}
	}

	public ListableDto(AbstractType abstractTypes) {
		super();
		if (abstractTypes != null) {
			this.key = abstractTypes.getKey();
			this.label = abstractTypes.getLabel();
			this.otherLabel = abstractTypes.getOtherLabel();
			this.footNote = abstractTypes.getFootNote();
		}
	}

	public ListableDto(Listable listable, Boolean useOtherLabel) {
		super();
		if (listable != null) {
			this.key = listable.getKey();
			this.label = useOtherLabel && !Strings.isNullOrEmpty(listable.getOtherLabel()) ? listable.getOtherLabel() : listable.getLabel();
		}
	}

	public ListableDto(Serializable key, String label) {
		super();
		this.key = key;
		this.label = label;
	}

	public ListableDto(Serializable key, String label, String otherLabel) {
		super();
		this.key = key;
		this.label = label;
		this.otherLabel = otherLabel;
	}

	public ListableDto(Serializable key, String label, String otherLabel, Object data, String type) {
		super();
		this.key = key;
		this.label = label;
		this.otherLabel = otherLabel;
		this.data = data;
		this.type = type;
	}

	public Serializable getKey() {
		return key;
	}

	public String getKeyString() {
		return key != null ? key.toString() : "";
	}

	public void setKey(Object key) {
		this.key = (Serializable) key;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getOtherLabel() {
		return otherLabel;
	}

	public void setOtherLabel(String otherLabel) {
		this.otherLabel = otherLabel;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFootNote() {
		return footNote;
	}

	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}

}