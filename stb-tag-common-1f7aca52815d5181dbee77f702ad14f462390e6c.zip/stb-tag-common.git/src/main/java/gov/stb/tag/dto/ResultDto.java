package gov.stb.tag.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResultDto<M> {

	private Integer total;
	private Integer noOfPages;
	private List<M> models = new ArrayList<>();
	private Object[] records;
	private Object result;
	private String successFlag;

	public ResultDto() {

	}

	public ResultDto(Object result) {
		this.result = result;
	}

	public ResultDto(Object result, String successFlag) {
		this.result = result;
		this.successFlag = successFlag;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public Integer getNoOfPages() {
		return noOfPages;
	}

	public void setNoOfPages(Integer noOfPages) {
		this.noOfPages = noOfPages;
	}

	@JsonIgnore
	public List<M> getModels() {
		return models;
	}

	public void setModels(List<M> models) {
		this.models = models;
	}

	public Object[] getRecords() {
		return records;
	}

	public void setRecords(Object[] records) {
		this.records = records;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	public String getSuccessFlag() {
		return successFlag;
	}

	public void setSuccessFlag(String successFlag) {
		this.successFlag = successFlag;
	}

	@JsonIgnore
	public Boolean isEmpty() {
		return models.isEmpty();
	}

	public Boolean isNotEmpty() {
		return !isEmpty();
	}

}
