package gov.stb.tag.dto;

public abstract class SearchDto {

	private Integer startIndex;
	private Integer pageSize;
	private String order;
	private String orderProperty;
	private Boolean myApplications;

	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getOrderProperty() {
		return orderProperty;
	}

	public void setOrderProperty(String orderProperty) {
		this.orderProperty = orderProperty;
	}

	public Boolean getMyApplications() {
		return myApplications;
	}

	public void setMyApplications(Boolean myApplications) {
		this.myApplications = myApplications;
	}

}
