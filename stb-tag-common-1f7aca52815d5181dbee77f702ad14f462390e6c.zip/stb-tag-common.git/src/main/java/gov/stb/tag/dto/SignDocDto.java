package gov.stb.tag.dto;

public class SignDocDto {

	private String sdweb_docid; // refId to client browser to redirect & activate a session with SigndocWeb & load in the PDF for signing === sdweb_docid

	private String sdweb_result;

	public String getSdweb_result() {
		return sdweb_result;
	}

	public void setSdweb_result(String sdweb_result) {
		this.sdweb_result = sdweb_result;
	}

	public String getSdweb_docid() {
		return sdweb_docid;
	}

	public void setSdweb_docid(String sdweb_docid) {
		this.sdweb_docid = sdweb_docid;
	}

}