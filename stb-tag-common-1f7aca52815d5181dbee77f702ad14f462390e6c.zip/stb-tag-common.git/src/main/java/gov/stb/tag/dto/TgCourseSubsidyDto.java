package gov.stb.tag.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.model.TgCourseSubsidy;
import gov.stb.tag.model.Type;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TgCourseSubsidyDto extends EntityDto {

	@MapProjection(path = "id")
	private Integer id;

	@MapProjection(path = "type.code")
	private String typeCode;

	@MapProjection(path = "type.label")
	private String title;

	@MapProjection(path = "type.otherLabel")
	private String description;

	@MapProjection(path = "fee")
	private BigDecimal fee;

	public TgCourseSubsidyDto() {

	}

	public TgCourseSubsidyDto(Type type) {
		this.typeCode = type.getCode();
		this.title = type.getLabel();
		this.description = type.getOtherLabel();
	}

	public TgCourseSubsidyDto(TgCourseSubsidy subsidy) {
		this(subsidy.getType());
		this.id = subsidy.getId();
		this.fee = subsidy.getFee();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

}
