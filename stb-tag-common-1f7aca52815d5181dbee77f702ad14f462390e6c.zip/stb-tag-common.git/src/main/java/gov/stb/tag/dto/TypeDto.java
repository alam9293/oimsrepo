package gov.stb.tag.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TypeDto {

	private String categoryCode;

	private String code;

	private String label;

	private String otherLabel;

	protected Integer ordinal;

	protected Boolean isActive;

	public TypeDto() {
	}

	public TypeDto(String categoryCode, String code, String label) {
		this.categoryCode = categoryCode;
		this.code = code;
		this.label = label;
	}

	public TypeDto(String categoryCode, String code, String label, Integer ordinal, Boolean isActive) {
		this.categoryCode = categoryCode;
		this.code = code;
		this.label = label;
		this.ordinal = ordinal;
		this.isActive = isActive;
	}

	public TypeDto(String categoryCode, String code, String label, String otherLabel, Integer ordinal, Boolean isActive) {
		this.categoryCode = categoryCode;
		this.code = code;
		this.label = label;
		this.otherLabel = otherLabel;
		this.ordinal = ordinal;
		this.isActive = isActive;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getOtherLabel() {
		return otherLabel;
	}

	public void setOtherLabel(String otherLabel) {
		this.otherLabel = otherLabel;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
