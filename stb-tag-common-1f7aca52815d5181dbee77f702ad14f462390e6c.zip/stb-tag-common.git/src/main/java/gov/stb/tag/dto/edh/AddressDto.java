package gov.stb.tag.dto.edh;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddressDto {

	private String agencyReferenceNumber;

	private Integer sequenceNumber;

	private String source;

	private String standard;

	private String type;

	private String alternateType;

	private String postalCode;

	private String houseBlockNumber;

	private String streetName;

	private String buildingName;

	private String levelNumber;

	private String unitNumber;

	/*
	 * "description": "Maximum of __2__ address lines, each not exceeding __60__ characters.", "items": { "type": "string" }, "minItems": 0, "maxItems": 2, "maxLength": 60
	 */
	private List<String> unformattedAddressLines;

	/*
	 * "description": "Maximum of __3__ \"Care of\" recipient names, each not exceeding __60__ characters.", "items": { "type": "string" }, "minItems": 0, "maxItems": 3, "maxLength": 60
	 */
	private List<String> careOfNames;

	private LocalDate effectiveDate;

	// maxLength: 50
	@JsonIgnore
	private String correspondencePurpose;

	private Boolean isInvalid;

	public String getAgencyReferenceNumber() {
		return agencyReferenceNumber;
	}

	public void setAgencyReferenceNumber(String agencyReferenceNumber) {
		this.agencyReferenceNumber = agencyReferenceNumber;
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAlternateType() {
		return alternateType;
	}

	public void setAlternateType(String alternateType) {
		this.alternateType = alternateType;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getHouseBlockNumber() {
		return houseBlockNumber;
	}

	public void setHouseBlockNumber(String houseBlockNumber) {
		this.houseBlockNumber = houseBlockNumber;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getLevelNumber() {
		return levelNumber;
	}

	public void setLevelNumber(String levelNumber) {
		this.levelNumber = levelNumber;
	}

	public String getUnitNumber() {
		return unitNumber;
	}

	public void setUnitNumber(String unitNumber) {
		this.unitNumber = unitNumber;
	}

	public List<String> getUnformattedAddressLines() {
		return unformattedAddressLines;
	}

	public void setUnformattedAddressLines(List<String> unformattedAddressLines) {
		this.unformattedAddressLines = unformattedAddressLines;
	}

	public List<String> getCareOfNames() {
		return careOfNames;
	}

	public void setCareOfNames(List<String> careOfNames) {
		this.careOfNames = careOfNames;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getCorrespondencePurpose() {
		return correspondencePurpose;
	}

	public void setCorrespondencePurpose(String correspondencePurpose) {
		this.correspondencePurpose = correspondencePurpose;
	}

	public Boolean getIsInvalid() {
		return isInvalid;
	}

	public void setIsInvalid(Boolean isInvalid) {
		this.isInvalid = isInvalid;
	}

}
