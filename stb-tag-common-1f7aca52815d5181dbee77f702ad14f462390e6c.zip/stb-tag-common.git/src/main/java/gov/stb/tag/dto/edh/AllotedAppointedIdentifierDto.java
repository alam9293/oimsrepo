package gov.stb.tag.dto.edh;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * "Entity's appointed entity/person or alloted entity/person registration/identification number identifier JSON data transfer object."
 * 
 * @author yvonne.yap
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AllotedAppointedIdentifierDto {

	/**
	 * 0 - Individual 1 - NRIC (Citizen) 2 - NRIC (Permanent Resident) 3 - FIN 4 - Passport/Others
	 */
	private String idType;

	private String idNumber;

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

}
