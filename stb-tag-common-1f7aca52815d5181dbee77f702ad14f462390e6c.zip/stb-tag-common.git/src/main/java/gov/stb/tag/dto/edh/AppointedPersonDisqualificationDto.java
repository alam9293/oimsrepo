package gov.stb.tag.dto.edh;

import java.time.LocalDate;

public class AppointedPersonDisqualificationDto {

	private LocalDate disqualificationStartDate;

	private LocalDate disqualificationEndDate;

	private String disqualificationSection;

	private LocalDate courtLeaveOrderDate;

	private LocalDate courtLeaveStartDate;

	private LocalDate courtLeaveEndDate;

	private String courtLeaveSection;

	public LocalDate getDisqualificationStartDate() {
		return disqualificationStartDate;
	}

	public void setDisqualificationStartDate(LocalDate disqualificationStartDate) {
		this.disqualificationStartDate = disqualificationStartDate;
	}

	public LocalDate getDisqualificationEndDate() {
		return disqualificationEndDate;
	}

	public void setDisqualificationEndDate(LocalDate disqualificationEndDate) {
		this.disqualificationEndDate = disqualificationEndDate;
	}

	public String getDisqualificationSection() {
		return disqualificationSection;
	}

	public void setDisqualificationSection(String disqualificationSection) {
		this.disqualificationSection = disqualificationSection;
	}

	public LocalDate getCourtLeaveOrderDate() {
		return courtLeaveOrderDate;
	}

	public void setCourtLeaveOrderDate(LocalDate courtLeaveOrderDate) {
		this.courtLeaveOrderDate = courtLeaveOrderDate;
	}

	public LocalDate getCourtLeaveStartDate() {
		return courtLeaveStartDate;
	}

	public void setCourtLeaveStartDate(LocalDate courtLeaveStartDate) {
		this.courtLeaveStartDate = courtLeaveStartDate;
	}

	public LocalDate getCourtLeaveEndDate() {
		return courtLeaveEndDate;
	}

	public void setCourtLeaveEndDate(LocalDate courtLeaveEndDate) {
		this.courtLeaveEndDate = courtLeaveEndDate;
	}

	public String getCourtLeaveSection() {
		return courtLeaveSection;
	}

	public void setCourtLeaveSection(String courtLeaveSection) {
		this.courtLeaveSection = courtLeaveSection;
	}

}
