package gov.stb.tag.dto.edh;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AppointedPersonDto {

	private String idType;

	private String idNumber;

	private String name;

	private String nationality;

	private Boolean isDisqualified;

	private AppointedPersonDisqualificationDto disqualification;

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public Boolean getIsDisqualified() {
		return isDisqualified;
	}

	public void setIsDisqualified(Boolean isDisqualified) {
		this.isDisqualified = isDisqualified;
	}

	public AppointedPersonDisqualificationDto getDisqualification() {
		return disqualification;
	}

	public void setDisqualification(AppointedPersonDisqualificationDto disqualification) {
		this.disqualification = disqualification;
	}

}
