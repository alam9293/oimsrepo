package gov.stb.tag.dto.edh;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AppointmentDto {

	private String category;

	private String positionHeld;

	private LocalDate entryDate;

	private LocalDate withdrawalDate;

	private LocalDate previousEntryDate;

	private LocalDate previousWithdrawalDate;

	private AppointedPersonDto appointedPerson;

	private AppointedEntityDto appointedEntity;

	private AddressDto addressOfAppointed;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getPositionHeld() {
		return positionHeld;
	}

	public void setPositionHeld(String positionHeld) {
		this.positionHeld = positionHeld;
	}

	public LocalDate getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(LocalDate entryDate) {
		this.entryDate = entryDate;
	}

	public LocalDate getWithdrawalDate() {
		return withdrawalDate;
	}

	public void setWithdrawalDate(LocalDate withdrawalDate) {
		this.withdrawalDate = withdrawalDate;
	}

	public LocalDate getPreviousEntryDate() {
		return previousEntryDate;
	}

	public void setPreviousEntryDate(LocalDate previousEntryDate) {
		this.previousEntryDate = previousEntryDate;
	}

	public LocalDate getPreviousWithdrawalDate() {
		return previousWithdrawalDate;
	}

	public void setPreviousWithdrawalDate(LocalDate previousWithdrawalDate) {
		this.previousWithdrawalDate = previousWithdrawalDate;
	}

	public AppointedPersonDto getAppointedPerson() {
		return appointedPerson;
	}

	public void setAppointedPerson(AppointedPersonDto appointedPerson) {
		this.appointedPerson = appointedPerson;
	}

	public AppointedEntityDto getAppointedEntity() {
		return appointedEntity;
	}

	public void setAppointedEntity(AppointedEntityDto appointedEntity) {
		this.appointedEntity = appointedEntity;
	}

	public AddressDto getAddressOfAppointed() {
		return addressOfAppointed;
	}

	public void setAddressOfAppointed(AddressDto addressOfAppointed) {
		this.addressOfAppointed = addressOfAppointed;
	}

}
