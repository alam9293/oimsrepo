package gov.stb.tag.dto.edh;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyAgmDto {

	private LocalDate agmDate;

	private LocalDate arDate;

	private LocalDate accountDate;

	public LocalDate getAgmDate() {
		return agmDate;
	}

	public void setAgmDate(LocalDate agmDate) {
		this.agmDate = agmDate;
	}

	public LocalDate getArDate() {
		return arDate;
	}

	public void setArDate(LocalDate arDate) {
		this.arDate = arDate;
	}

	public LocalDate getAccountDate() {
		return accountDate;
	}

	public void setAccountDate(LocalDate accountDate) {
		this.accountDate = accountDate;
	}

}
