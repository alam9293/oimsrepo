package gov.stb.tag.dto.edh;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompanyCapitalDto {

	private String type;

	private String capitalCurrency;

	private BigDecimal capitalAllotedAmount;

	private BigDecimal issuedCapitalAmount;

	private BigDecimal paidUpCapitalAmount;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCapitalCurrency() {
		return capitalCurrency;
	}

	public void setCapitalCurrency(String capitalCurrency) {
		this.capitalCurrency = capitalCurrency;
	}

	public BigDecimal getCapitalAllotedAmount() {
		return capitalAllotedAmount;
	}

	public void setCapitalAllotedAmount(BigDecimal capitalAllotedAmount) {
		this.capitalAllotedAmount = capitalAllotedAmount;
	}

	public BigDecimal getIssuedCapitalAmount() {
		return issuedCapitalAmount;
	}

	public void setIssuedCapitalAmount(BigDecimal issuedCapitalAmount) {
		this.issuedCapitalAmount = issuedCapitalAmount;
	}

	public BigDecimal getPaidUpCapitalAmount() {
		return paidUpCapitalAmount;
	}

	public void setPaidUpCapitalAmount(BigDecimal paidUpCapitalAmount) {
		this.paidUpCapitalAmount = paidUpCapitalAmount;
	}

}
