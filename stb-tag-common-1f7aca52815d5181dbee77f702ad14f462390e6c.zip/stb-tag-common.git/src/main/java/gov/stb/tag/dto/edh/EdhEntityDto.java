package gov.stb.tag.dto.edh;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EdhEntityDto extends EdhDto<EdhEntityDto> {

	private EntityBasicProfileDto basic;

	// Entity's registered or correspondence addresses
	private List<AddressDto> addresses;

	// Entity's appoinments appointed personnel or entity registration/identification numbers
	private List<AllotedAppointedIdentifierDto> appointments;

	// Historical records of entity's previous names
	private List<EntityNameDto> entityNames;

	// Entity's inward redomiciliation (relocation from foreign to local) details
	private RedomiciliationDto redomiciliation;

	// Historical unsorted records of entity's registration numbers
	private List<RegistrationNumberDto> registrationNumbers;

	// Historical records of entity's renewals, applicable only to LP entity
	private List<RenewalDto> renewals;

	// Entity's shareholders alloted entity's/person's registration/identification number
	private List<AllotedAppointedIdentifierDto> shareholders;

	// Historical unsorted records of entity's unique entity numbers
	private List<UniqueEntityNumberDto> uens;

	public EntityBasicProfileDto getBasic() {
		return basic;
	}

	public void setBasic(EntityBasicProfileDto basic) {
		this.basic = basic;
	}

	public List<AddressDto> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<AddressDto> addresses) {
		this.addresses = addresses;
	}

	public List<AllotedAppointedIdentifierDto> getAppointments() {
		return appointments;
	}

	public void setAppointments(List<AllotedAppointedIdentifierDto> appointments) {
		this.appointments = appointments;
	}

	public List<EntityNameDto> getEntityNames() {
		return entityNames;
	}

	public void setEntityNames(List<EntityNameDto> entityNames) {
		this.entityNames = entityNames;
	}

	public RedomiciliationDto getRedomiciliation() {
		return redomiciliation;
	}

	public void setRedomiciliation(RedomiciliationDto redomiciliation) {
		this.redomiciliation = redomiciliation;
	}

	public List<RegistrationNumberDto> getRegistrationNumbers() {
		return registrationNumbers;
	}

	public void setRegistrationNumbers(List<RegistrationNumberDto> registrationNumbers) {
		this.registrationNumbers = registrationNumbers;
	}

	public List<RenewalDto> getRenewals() {
		return renewals;
	}

	public void setRenewals(List<RenewalDto> renewals) {
		this.renewals = renewals;
	}

	public List<AllotedAppointedIdentifierDto> getShareholders() {
		return shareholders;
	}

	public void setShareholders(List<AllotedAppointedIdentifierDto> shareholders) {
		this.shareholders = shareholders;
	}

	public List<UniqueEntityNumberDto> getUens() {
		return uens;
	}

	public void setUens(List<UniqueEntityNumberDto> uens) {
		this.uens = uens;
	}

}
