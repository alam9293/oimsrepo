package gov.stb.tag.dto.edh;

import java.time.LocalDate;
import java.util.List;

public class EntitiesRequestDto {

	private String consumerId;

	private List<String> fields;

	private Integer skip;

	private Integer top;

	private List<String> issuance_agencies;

	private LocalDate last_updated_from;

	private LocalDate last_updated_to;

	private String name;

	private String name_criteria;

	private List<String> types;

	private List<String> uens;

	private List<String> groups;

	public String getConsumerId() {
		return consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public List<String> getFields() {
		return fields;
	}

	public void setFields(List<String> fields) {
		this.fields = fields;
	}

	public Integer getSkip() {
		return skip;
	}

	public void setSkip(Integer skip) {
		this.skip = skip;
	}

	public Integer getTop() {
		return top;
	}

	public void setTop(Integer top) {
		this.top = top;
	}

	public List<String> getIssuance_agencies() {
		return issuance_agencies;
	}

	public void setIssuance_agencies(List<String> issuance_agencies) {
		this.issuance_agencies = issuance_agencies;
	}

	public LocalDate getLast_updated_from() {
		return last_updated_from;
	}

	public void setLast_updated_from(LocalDate last_updated_from) {
		this.last_updated_from = last_updated_from;
	}

	public LocalDate getLast_updated_to() {
		return last_updated_to;
	}

	public void setLast_updated_to(LocalDate last_updated_to) {
		this.last_updated_to = last_updated_to;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName_criteria() {
		return name_criteria;
	}

	public void setName_criteria(String name_criteria) {
		this.name_criteria = name_criteria;
	}

	public List<String> getTypes() {
		return types;
	}

	public void setTypes(List<String> types) {
		this.types = types;
	}

	public List<String> getUens() {
		return uens;
	}

	public void setUens(List<String> uens) {
		this.uens = uens;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

}
