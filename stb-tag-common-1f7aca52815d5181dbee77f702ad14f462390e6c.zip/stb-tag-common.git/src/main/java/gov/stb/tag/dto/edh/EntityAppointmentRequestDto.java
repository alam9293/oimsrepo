package gov.stb.tag.dto.edh;

import java.util.List;

public class EntityAppointmentRequestDto {

	private String consumerId;

	private List<String> fields;

	private Integer skip;

	private Integer top;

	private List<String> types; // `CO` | Company Officer, `BO` | Business Owner, `PM` | Partner Manager

	public EntityAppointmentRequestDto() {

	}

	public EntityAppointmentRequestDto(String consumerId) {
		super();
		this.consumerId = consumerId;
	}

	public String getConsumerId() {
		return consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public List<String> getFields() {
		return fields;
	}

	public void setFields(List<String> fields) {
		this.fields = fields;
	}

	public Integer getSkip() {
		return skip;
	}

	public void setSkip(Integer skip) {
		this.skip = skip;
	}

	public Integer getTop() {
		return top;
	}

	public void setTop(Integer top) {
		this.top = top;
	}

	public List<String> getTypes() {
		return types;
	}

	public void setTypes(List<String> types) {
		this.types = types;
	}

}
