package gov.stb.tag.dto.edh;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EntityBasicProfileDto {

	private String agencyReferenceNumber;

	private Boolean isRegisteredWithACRA;

	private Boolean isRedomiciledCompany;

	private String uen;

	private String uenStatus;

	private String issuanceAgency;

	// Entity name less than 100-characters
	private String entityName;

	// Entity name more than 100-characters
	private String entityLongName;

	private String entityType;

	private String entityStatusCode;

	private String entityStatusCodeDescription;

	private LocalDate uenIssueDate;

	private LocalDate entityStatusEffectiveDate;

	// A maximum of __3__ unique entity numbers, each not exceeding __10__ characters
	private List<String> relatedMainEntityUens;

	/*
	 * "description":
	 * "Entity facsimile number not exceeding __12__ digits. Mandatory country code, not exceeding __3__ digits, is to be prefixed with `+` and separated from the facsimile number by `-`.", "pattern":
	 * "^(\\+)([0-9]{1,3})(-)([0-9]{1,12})$", "maxLength": 17
	 */
	private String fax;

	/*
	 * "description":
	 * "Entity telephone number not exceeding __12__ digits. Mandatory country code, not exceeding __3__ digits, is to be prefixed with `+` and separated from the telephone number by `-`.", "pattern":
	 * "^(\\+)([0-9]{1,3})(-)([0-9]{1,12})$", "maxLength": 17
	 */
	private String telephone;

	/*
	 * "description": "Entity Email address. The local part, before `@`, must not exceed __64__ characters. The domain part, after `@`, must not exceed __255__ characters.", "pattern":
	 * "^([a-z0-9!#$%&'*+/=?^_`{|}~-]{1,64})(@)([a-z0-9-\\.]{1,255})$", "maxLength": 320
	 */
	private String email;

	private LocalDate registrationDate;

	private LocalDate deregistrationDate;

	private LocalDate reinstateStatusEffectiveDate;

	private LocalDate entityBusinessCommencementDate;

	private LocalDate entityBusinessExpiryDate;

	private String primaryActivityCode;

	// maxLength: 200
	private String primaryActivityDescription;

	// maxLength: 200
	private String additionalPrimaryActivityDescription;

	private String secondaryActivityCode;

	// maxLength: 200
	private String secondaryActivityDescription;

	// maxLength: 200
	private String additionalSecondaryActivityDescription;

	private String businessConstitutionCode;

	private LocalDate businessConstitutionEffectiveDate;

	private LocalDate changeOfAddressDate;

	private LocalDate changeOfNameDate;

	public String getAgencyReferenceNumber() {
		return agencyReferenceNumber;
	}

	public void setAgencyReferenceNumber(String agencyReferenceNumber) {
		this.agencyReferenceNumber = agencyReferenceNumber;
	}

	public Boolean getIsRegisteredWithACRA() {
		return isRegisteredWithACRA;
	}

	public void setIsRegisteredWithACRA(Boolean isRegisteredWithACRA) {
		this.isRegisteredWithACRA = isRegisteredWithACRA;
	}

	public Boolean getIsRedomiciledCompany() {
		return isRedomiciledCompany;
	}

	public void setIsRedomiciledCompany(Boolean isRedomiciledCompany) {
		this.isRedomiciledCompany = isRedomiciledCompany;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getUenStatus() {
		return uenStatus;
	}

	public void setUenStatus(String uenStatus) {
		this.uenStatus = uenStatus;
	}

	public String getIssuanceAgency() {
		return issuanceAgency;
	}

	public void setIssuanceAgency(String issuanceAgency) {
		this.issuanceAgency = issuanceAgency;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getEntityLongName() {
		return entityLongName;
	}

	public void setEntityLongName(String entityLongName) {
		this.entityLongName = entityLongName;
	}

	// TODO: this should be stored in database...
	// public String getEntityType() {
	// if (!Objects.isNull(EntityType.valueOf(entityType))) {
	// return EntityType.valueOf(entityType).toValue();
	// } else {
	// return entityType;
	// }
	// }

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityStatusCode() {
		return entityStatusCode;
	}

	public void setEntityStatusCode(String entityStatusCode) {
		this.entityStatusCode = entityStatusCode;
	}

	public String getEntityStatusCodeDescription() {
		return entityStatusCodeDescription;
	}

	public void setEntityStatusCodeDescription(String entityStatusCodeDescription) {
		this.entityStatusCodeDescription = entityStatusCodeDescription;
	}

	public LocalDate getUenIssueDate() {
		return uenIssueDate;
	}

	public void setUenIssueDate(LocalDate uenIssueDate) {
		this.uenIssueDate = uenIssueDate;
	}

	public LocalDate getEntityStatusEffectiveDate() {
		return entityStatusEffectiveDate;
	}

	public void setEntityStatusEffectiveDate(LocalDate entityStatusEffectiveDate) {
		this.entityStatusEffectiveDate = entityStatusEffectiveDate;
	}

	public List<String> getRelatedMainEntityUens() {
		return relatedMainEntityUens;
	}

	public void setRelatedMainEntityUens(List<String> relatedMainEntityUens) {
		this.relatedMainEntityUens = relatedMainEntityUens;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public LocalDate getDeregistrationDate() {
		return deregistrationDate;
	}

	public void setDeregistrationDate(LocalDate deregistrationDate) {
		this.deregistrationDate = deregistrationDate;
	}

	public LocalDate getReinstateStatusEffectiveDate() {
		return reinstateStatusEffectiveDate;
	}

	public void setReinstateStatusEffectiveDate(LocalDate reinstateStatusEffectiveDate) {
		this.reinstateStatusEffectiveDate = reinstateStatusEffectiveDate;
	}

	public LocalDate getEntityBusinessCommencementDate() {
		return entityBusinessCommencementDate;
	}

	public void setEntityBusinessCommencementDate(LocalDate entityBusinessCommencementDate) {
		this.entityBusinessCommencementDate = entityBusinessCommencementDate;
	}

	public LocalDate getEntityBusinessExpiryDate() {
		return entityBusinessExpiryDate;
	}

	public void setEntityBusinessExpiryDate(LocalDate entityBusinessExpiryDate) {
		this.entityBusinessExpiryDate = entityBusinessExpiryDate;
	}

	public String getPrimaryActivityCode() {
		return primaryActivityCode;
	}

	public void setPrimaryActivityCode(String primaryActivityCode) {
		this.primaryActivityCode = primaryActivityCode;
	}

	public String getPrimaryActivityDescription() {
		return primaryActivityDescription;
	}

	public void setPrimaryActivityDescription(String primaryActivityDescription) {
		this.primaryActivityDescription = primaryActivityDescription;
	}

	public String getAdditionalPrimaryActivityDescription() {
		return additionalPrimaryActivityDescription;
	}

	public void setAdditionalPrimaryActivityDescription(String additionalPrimaryActivityDescription) {
		this.additionalPrimaryActivityDescription = additionalPrimaryActivityDescription;
	}

	public String getSecondaryActivityCode() {
		return secondaryActivityCode;
	}

	public void setSecondaryActivityCode(String secondaryActivityCode) {
		this.secondaryActivityCode = secondaryActivityCode;
	}

	public String getSecondaryActivityDescription() {
		return secondaryActivityDescription;
	}

	public void setSecondaryActivityDescription(String secondaryActivityDescription) {
		this.secondaryActivityDescription = secondaryActivityDescription;
	}

	public String getAdditionalSecondaryActivityDescription() {
		return additionalSecondaryActivityDescription;
	}

	public void setAdditionalSecondaryActivityDescription(String additionalSecondaryActivityDescription) {
		this.additionalSecondaryActivityDescription = additionalSecondaryActivityDescription;
	}

	public String getBusinessConstitutionCode() {
		return businessConstitutionCode;
	}

	public void setBusinessConstitutionCode(String businessConstitutionCode) {
		this.businessConstitutionCode = businessConstitutionCode;
	}

	public LocalDate getBusinessConstitutionEffectiveDate() {
		return businessConstitutionEffectiveDate;
	}

	public void setBusinessConstitutionEffectiveDate(LocalDate businessConstitutionEffectiveDate) {
		this.businessConstitutionEffectiveDate = businessConstitutionEffectiveDate;
	}

	public LocalDate getChangeOfAddressDate() {
		return changeOfAddressDate;
	}

	public void setChangeOfAddressDate(LocalDate changeOfAddressDate) {
		this.changeOfAddressDate = changeOfAddressDate;
	}

	public LocalDate getChangeOfNameDate() {
		return changeOfNameDate;
	}

	public void setChangeOfNameDate(LocalDate changeOfNameDate) {
		this.changeOfNameDate = changeOfNameDate;
	}

}
