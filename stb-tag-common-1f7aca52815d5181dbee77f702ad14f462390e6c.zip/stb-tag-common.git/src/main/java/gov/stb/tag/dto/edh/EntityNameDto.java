package gov.stb.tag.dto.edh;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EntityNameDto {

	private String agencyReferenceNumber;

	private Integer sequenceNumber;

	private String entityName;

	private LocalDate lastEffectiveDate;

	public String getAgencyReferenceNumber() {
		return agencyReferenceNumber;
	}

	public void setAgencyReferenceNumber(String agencyReferenceNumber) {
		this.agencyReferenceNumber = agencyReferenceNumber;
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public LocalDate getLastEffectiveDate() {
		return lastEffectiveDate;
	}

	public void setLastEffectiveDate(LocalDate lastEffectiveDate) {
		this.lastEffectiveDate = lastEffectiveDate;
	}

}
