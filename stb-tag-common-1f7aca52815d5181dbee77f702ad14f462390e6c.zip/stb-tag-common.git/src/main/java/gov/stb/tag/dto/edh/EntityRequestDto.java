package gov.stb.tag.dto.edh;

import java.util.List;

public class EntityRequestDto {

	private String consumerId;

	private List<String> fields;

	private List<String> groups;

	public EntityRequestDto(String consumerId) {
		super();
		this.consumerId = consumerId;
	}

	public String getConsumerId() {
		return consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public List<String> getFields() {
		return fields;
	}

	public void setFields(List<String> fields) {
		this.fields = fields;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

}
