package gov.stb.tag.dto.edh;

import java.util.List;

public class EntityShareholderRequestDto {

	private String consumerId;

	private List<String> fields;

	private Integer skip;

	private Integer top;

	public EntityShareholderRequestDto() {

	}

	public EntityShareholderRequestDto(String consumerId) {
		super();
		this.consumerId = consumerId;
	}

	public String getConsumerId() {
		return consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public List<String> getFields() {
		return fields;
	}

	public void setFields(List<String> fields) {
		this.fields = fields;
	}

	public Integer getSkip() {
		return skip;
	}

	public void setSkip(Integer skip) {
		this.skip = skip;
	}

	public Integer getTop() {
		return top;
	}

	public void setTop(Integer top) {
		this.top = top;
	}
}
