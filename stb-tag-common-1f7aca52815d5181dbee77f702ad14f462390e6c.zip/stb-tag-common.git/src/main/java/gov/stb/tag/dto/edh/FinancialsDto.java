package gov.stb.tag.dto.edh;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FinancialsDto extends EdhDto<FinancialsDto> {

	private List<CompanyAgmDto> agms;

	private List<LlpAnnualDeclarationDto> annualDeclarations;

	private List<CompanyCapitalDto> capitals;

	public List<CompanyAgmDto> getAgms() {
		return agms;
	}

	public void setAgms(List<CompanyAgmDto> agms) {
		this.agms = agms;
	}

	public List<LlpAnnualDeclarationDto> getAnnualDeclarations() {
		return annualDeclarations;
	}

	public void setAnnualDeclarations(List<LlpAnnualDeclarationDto> annualDeclarations) {
		this.annualDeclarations = annualDeclarations;
	}

	public List<CompanyCapitalDto> getCapitals() {
		return capitals;
	}

	public void setCapitals(List<CompanyCapitalDto> capitals) {
		this.capitals = capitals;
	}

}
