package gov.stb.tag.dto.edh;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LlpAnnualDeclarationDto {

	private LocalDate annualDate;

	private LocalDate previousAnnualDate;

	private LocalDate dueDate;

	public LocalDate getAnnualDate() {
		return annualDate;
	}

	public void setAnnualDate(LocalDate annualDate) {
		this.annualDate = annualDate;
	}

	public LocalDate getPreviousAnnualDate() {
		return previousAnnualDate;
	}

	public void setPreviousAnnualDate(LocalDate previousAnnualDate) {
		this.previousAnnualDate = previousAnnualDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

}
