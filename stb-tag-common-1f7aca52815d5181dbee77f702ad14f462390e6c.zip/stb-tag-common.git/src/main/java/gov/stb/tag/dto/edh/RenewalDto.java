package gov.stb.tag.dto.edh;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * "Entity's renewal data transfer object, only applicable for LP entity."
 * 
 * @author yvonne.yap
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RenewalDto {

	private String transactionNumber;

	private LocalDate renewedDate;

	private String renewalModeCode;

	private Integer yearsRenewed;

	private LocalDate lastUpdatedDate;

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public LocalDate getRenewedDate() {
		return renewedDate;
	}

	public void setRenewedDate(LocalDate renewedDate) {
		this.renewedDate = renewedDate;
	}

	public String getRenewalModeCode() {
		return renewalModeCode;
	}

	public void setRenewalModeCode(String renewalModeCode) {
		this.renewalModeCode = renewalModeCode;
	}

	public Integer getYearsRenewed() {
		return yearsRenewed;
	}

	public void setYearsRenewed(Integer yearsRenewed) {
		this.yearsRenewed = yearsRenewed;
	}

	public LocalDate getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(LocalDate lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
