package gov.stb.tag.dto.edh;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ShareholderDto {

	private String category;

	private String group;

	private String type;

	private String currency;

	private BigDecimal allotedNumber;

	private String allotedNumberStr;

	private AllotedPersonDto allotedPerson;

	private AllotedEntityDto allotedEntity;

	private AddressDto addressOfAlloted;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getAllotedNumber() {
		return allotedNumber;
	}

	public void setAllotedNumber(BigDecimal allotedNumber) {
		this.allotedNumber = allotedNumber;
	}

	public String getAllotedNumberStr() {
		return allotedNumberStr;
	}

	public void setAllotedNumberStr(String allotedNumberStr) {
		this.allotedNumberStr = allotedNumberStr;
	}

	public AllotedPersonDto getAllotedPerson() {
		return allotedPerson;
	}

	public void setAllotedPerson(AllotedPersonDto allotedPerson) {
		this.allotedPerson = allotedPerson;
	}

	public AllotedEntityDto getAllotedEntity() {
		return allotedEntity;
	}

	public void setAllotedEntity(AllotedEntityDto allotedEntity) {
		this.allotedEntity = allotedEntity;
	}

	public AddressDto getAddressOfAlloted() {
		return addressOfAlloted;
	}

	public void setAddressOfAlloted(AddressDto addressOfAlloted) {
		this.addressOfAlloted = addressOfAlloted;
	}

}
