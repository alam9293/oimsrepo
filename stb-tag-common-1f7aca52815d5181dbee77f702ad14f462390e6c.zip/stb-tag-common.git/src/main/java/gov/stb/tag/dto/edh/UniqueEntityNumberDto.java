package gov.stb.tag.dto.edh;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UniqueEntityNumberDto {

	private String agencyReferenceNumber;

	private Integer sequenceNumber;

	private String previousUen;

	private String remarks;

	public String getAgencyReferenceNumber() {
		return agencyReferenceNumber;
	}

	public void setAgencyReferenceNumber(String agencyReferenceNumber) {
		this.agencyReferenceNumber = agencyReferenceNumber;
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getPreviousUen() {
		return previousUen;
	}

	public void setPreviousUen(String previousUen) {
		this.previousUen = previousUen;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
