package gov.stb.tag.dto.myinfo;

import java.time.LocalDate;

public class MyInfoPersonBasicDto {
	private boolean error = false;
	private boolean incompleteData = false;
	private String errorMessage;
	// general profile
	private String uinfin;
	private String name;
	private String aliasName;
	private LocalDate dob;
	private String sex;
	private String race;
	private String nationality;
	private String birthCountry;
	private String residentialStatus;
	private String regAddPostal;
	private String regAddBlock;
	private String regAddStreet;
	private String regAddBuilding;
	private String regAddFloor;
	private String regAddUnit;
	private String mobileNo;
	private String email;
	private String maritalStatus;
	private boolean scpr;
	// workpass
	private String occupation;
	private String employment; // company name
	private LocalDate workpassExpiryDate;

	// editable
	private String[] nonEditableFields;
	private String[] nonApplicableFields;
	private final static String[] MYINFO_NON_EDITABLE_FIELDS_SCPR = { "uinfin", "name", "aliasName", "sex", "race", "nationality", "dob", "birthCountry", "regAddPostal", "regAddBlock", "regAddStreet",
			"regAddBuilding", "regAddFloor", "regAddUnit", "maritalStatus", "residentialStatus" };
	private final static String[] MYINFO_NON_EDITABLE_FIELDS_FOREIGNER = { "uinfin", "name", "aliasName", "sex", "race", "nationality", "dob", "birthCountry", "occupation", "employment",
			"workpassExpiryDate" };
	private final static String[] MYINFO_NON_APPLICABLE_FIELDS_SCPR = { "workpassExpiryDate" };
	private final static String[] MYINFO_NON_APPLICABLE_FIELDS_FOREIGNER = { "regAddPostal", "regAddBlock", "regAddStreet", "regAddBuilding", "regAddFloor", "regAddUnit", "residentialStatus" };

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public boolean isIncompleteData() {
		return incompleteData;
	}

	public void setIncompleteData(boolean incompleteData) {
		this.incompleteData = incompleteData;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getUinfin() {
		return uinfin;
	}

	public void setUinfin(String uinfin) {
		this.uinfin = uinfin;
		this.setEditableApplicableFields();
		this.setScpr();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(String birthCountry) {
		this.birthCountry = birthCountry;
	}

	public String getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public String getRegAddPostal() {
		return regAddPostal;
	}

	public void setRegAddPostal(String regAddPostal) {
		this.regAddPostal = regAddPostal;
	}

	public String getRegAddBlock() {
		return regAddBlock;
	}

	public void setRegAddBlock(String regAddBlock) {
		this.regAddBlock = regAddBlock;
	}

	public String getRegAddStreet() {
		return regAddStreet;
	}

	public void setRegAddStreet(String regAddStreet) {
		this.regAddStreet = regAddStreet;
	}

	public String getRegAddBuilding() {
		return regAddBuilding;
	}

	public void setRegAddBuilding(String regAddBuilding) {
		this.regAddBuilding = regAddBuilding;
	}

	public String getRegAddFloor() {
		return regAddFloor;
	}

	public void setRegAddFloor(String regAddFloor) {
		this.regAddFloor = regAddFloor;
	}

	public String getRegAddUnit() {
		return regAddUnit;
	}

	public void setRegAddUnit(String regAddUnit) {
		this.regAddUnit = regAddUnit;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getEmployment() {
		return employment;
	}

	public void setEmployment(String employment) {
		this.employment = employment;
	}

	public LocalDate getWorkpassExpiryDate() {
		return workpassExpiryDate;
	}

	public void setWorkpassExpiryDate(LocalDate workpassExpiryDate) {
		this.workpassExpiryDate = workpassExpiryDate;
	}

	public String[] getNonEditableFields() {
		return nonEditableFields;
	}

	public void setNonEditableFields(String[] nonEditableFields) {
		this.nonEditableFields = nonEditableFields;
	}

	public String[] getNonApplicableFields() {
		return nonApplicableFields;
	}

	public void setNonApplicableFields(String[] nonApplicableFields) {
		this.nonApplicableFields = nonApplicableFields;
	}

	// based on uinfin, determine if fields are editable
	private void setEditableApplicableFields() {
		boolean isScpr = isScpr(getUinfin());
		if (isScpr) {
			nonEditableFields = MYINFO_NON_EDITABLE_FIELDS_SCPR;
			nonApplicableFields = MYINFO_NON_APPLICABLE_FIELDS_SCPR;
		} else {
			nonEditableFields = MYINFO_NON_EDITABLE_FIELDS_FOREIGNER;
			nonApplicableFields = MYINFO_NON_APPLICABLE_FIELDS_FOREIGNER;
		}
	}

	private boolean isScpr(String uin) {
		return uin.toUpperCase().startsWith("S") || uin.toUpperCase().startsWith("T");
	}

	public boolean isScpr() {
		return scpr;
	}

	public void setScpr() {
		this.scpr = isScpr(getUinfin());
	}
}
