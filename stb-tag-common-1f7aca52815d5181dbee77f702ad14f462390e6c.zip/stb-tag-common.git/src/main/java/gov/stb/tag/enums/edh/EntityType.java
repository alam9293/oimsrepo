package gov.stb.tag.enums.edh;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;

@Deprecated // TODO: To be maintained in database master data types for EDH
public enum EntityType {

	BN("Businesses"),
	FC("Foreign Companies"),
	LC("Local Companies"),
	LL("Limited Liability Partnerships"),
	LP("Limited Partnerships"),
	PF("Public Accounting Firms"),
	UF("Unregistered Foreign Entities"),
	UL("Unregistered Local Entities"),
	RF("Representative Office"),
	FB("Bank Representative Offices"),
	FN("Insurance Representative Offices"),
	FS("Other Financial Representative Offices"),
	NB("News Bureaus"),
	CP("Consulate-General or Consulate"),
	DP("High Commissions or Embassies"),
	NR("International Organisation"),
	TR("Other Organisation"),
	FM("Foreign Military Units"),
	RP("Foreign Law Practice Representative Office"),
	TC("Town Councils"),
	GS("Government and Government-Aided Schools"),
	GA("Organs of State, Ministries and Departments"),
	GB("Statutory Boards"),
	CD("Only Dental Clinic"),
	CH("Commercial Home"),
	CL("Clinical Laboratories"),
	CM("Only Medical Clinic"),
	CX("Clinical & X-Ray Laboratories"),
	HS("Hospitals"),
	MD("Both Medical and Dental Clinic"),
	MH("Maternity Homes"),
	VH("Voluntary Welfare Home"),
	XL("X-Ray Laboratories"),
	TU("Trade Unions"),
	NM("Madrasahs"),
	MQ("Mosques"),
	PA("PA Services"),
	PB("Grassroot Units"),
	SS("Societies"),
	MC("Management Corporations"),
	SM("Subsidiary Management Corporations"),
	AF("Audit Firm"),
	CC("Charities and Institutions of a Public Character"),
	CS("Cooperative Societies"),
	MB("Mutual Benefit Organisations");

	private final String value;

	EntityType(String value) {
		this.value = value;
	}

	@JsonGetter
	public String toValue() {
		return value;
	}
	
	@JsonSetter
    public static EntityType fromValue(String value) {
        for (EntityType type : values()) {
            if (type.value.equalsIgnoreCase(value)) {
                return type;
            }
        }

        return null;
    }
}
