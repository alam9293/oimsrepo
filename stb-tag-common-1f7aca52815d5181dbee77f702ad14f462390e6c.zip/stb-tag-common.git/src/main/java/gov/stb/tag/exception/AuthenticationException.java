package gov.stb.tag.exception;

import org.springframework.http.HttpStatus;

@SuppressWarnings("serial")
public class AuthenticationException extends RuntimeException {

	protected final String code;
	protected final String message;

	public AuthenticationException(String message) {
		this.code = HttpStatus.UNAUTHORIZED.toString();
		this.message = message;
	}

	public AuthenticationException(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
