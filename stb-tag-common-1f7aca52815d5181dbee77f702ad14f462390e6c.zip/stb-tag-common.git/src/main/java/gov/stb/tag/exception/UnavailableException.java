package gov.stb.tag.exception;

import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

@SuppressWarnings("serial")
public class UnavailableException extends RuntimeException {

	protected final String code;
	protected final String message;

	public UnavailableException(String message) {
		this.code = HttpStatus.SERVICE_UNAVAILABLE.toString();
		this.message = message;
	}

	public UnavailableException(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public UnavailableException(Errors errors) {
		this.code = HttpStatus.SERVICE_UNAVAILABLE.toString();
		StringBuilder sb = new StringBuilder();
		for (ObjectError error : errors.getAllErrors()) {
			sb.append("<li>" + error.getDefaultMessage() + "</li>");
		}
		this.message = sb.toString();
	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
