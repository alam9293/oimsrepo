package gov.stb.tag.exception;

import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

@SuppressWarnings("serial")
public class ValidationException extends RuntimeException {

	protected final String code;
	protected final String message;

	public ValidationException(String message) {
		this.code = HttpStatus.BAD_REQUEST.toString();
		this.message = message;
	}

	public ValidationException(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public ValidationException(Errors errors) {
		this.code = HttpStatus.BAD_REQUEST.toString();
		StringBuilder sb = new StringBuilder();
		for (ObjectError error : errors.getAllErrors()) {
			sb.append("<li>" + error.getDefaultMessage() + "</li>");
		}
		this.message = sb.toString();
	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
