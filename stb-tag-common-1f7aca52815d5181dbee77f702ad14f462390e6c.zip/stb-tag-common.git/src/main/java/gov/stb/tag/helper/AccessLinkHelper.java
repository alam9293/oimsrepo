package gov.stb.tag.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.constant.Properties;
import gov.stb.tag.repository.AccessLinkRepository;

@Component
public class AccessLinkHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;
	@Autowired
	Properties properties;
	@Autowired
	AccessLinkRepository repository;

}
