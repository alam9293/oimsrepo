package gov.stb.tag.helper;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.Alert;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.AlertRepository;

@Component
@Transactional
public class AlertHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;
	@Autowired
	AlertRepository repository;
	@Autowired
	MessageHelper messageHelper;

	public void createAlertForFiling(TravelAgent ta, TaFilingCondition filing, String msg, String module, Type type, String url, Status status) {
		msg = messageHelper.formatWithAnOrA(msg, Codes.Placeholders.APP_TYPE, cache.getLabel(filing.getApplicationType(), true));
		createAlert(null, ta, null, null, null, msg, module, type, url, status, null, null, null);
	}

	public void createAlertForShortfall(TravelAgent ta, String msg, String module, Type type, String url) {
		msg = messageHelper.replace(msg, Codes.Placeholders.APP_TYPE, type.getLabel());
		createAlert(null, ta, null, null, null, msg, module, type, url, null, null, null, null);
	}

	public void createAlert(User user, Application app, String msg, String module, Type type, String url) {
		createAlert(user, null, null, null, app, msg, module, type, url, null, null, null, null);
	}

	public void createAlert(TravelAgent ta, Application app, String msg, String module, Type type, String url, Status status) {
		createAlert(null, ta, null, null, app, msg, module, type, url, status, null, null, null);
	}

	public void createAlert(TravelAgent ta, Application app, String msg, String module, Type type, String url, Status status, BigDecimal appAmount) {
		createAlert(null, ta, null, null, app, msg, module, type, url, status, appAmount, null, null);
	}

	public void createAlert(TouristGuide tg, Application app, String msg, String module, Type type, String url) {
		createAlert(null, null, tg, null, app, msg, module, type, url, null, null, null, null);
	}

	public void createAlert(TgTrainingProvider tp, Application app, String msg, String module, Type type, String url) {
		createAlert(null, null, null, tp, app, msg, module, type, url, null, null, null, null);
	}

	public void createAlert(TouristGuide tg, Application app, String msg, String module, Type type, String url, List<String> payBill, String specialisedArea) {
		createAlert(null, null, tg, null, app, msg, module, type, url, null, null, payBill, specialisedArea);
	}

	public void createAlert(User user, TravelAgent ta, TouristGuide tg, TgTrainingProvider tp, Application app, String msg, String module, Type type, String url, Status status, BigDecimal appAmount,
			List<String> payBill, String specialisedArea) {
		if (app != null) {
			msg = messageHelper.formatAppPlaceholders(msg, app, null, appAmount);
		}

		if (payBill != null) {
			msg = messageHelper.formatBillRefPlaceholders(msg, payBill);
		}

		if (specialisedArea != null) {
			msg = messageHelper.formatTGArea(msg, specialisedArea);
		}

		Alert alert = new Alert();
		alert.setMessage(msg);
		alert.setModule(cache.getType(module));
		alert.setType(type);
		alert.setUrl(url);
		alert.setStatus(cache.getStatus(Codes.AlertStatus.UNREAD));
		repository.save(alert);
		Set<Alert> alerts = new HashSet<>();
		if (user != null) {
			alerts = user.getAlerts();
		} else if (ta != null) {
			alerts = ta.getAlerts();
		} else if (tg != null) {
			alerts = tg.getAlerts();
		} else {
			alerts = tp.getAlerts();
		}
		alerts.add(alert);

		if (user != null) {
			user.setAlerts(alerts);
			repository.save(user);
		} else if (ta != null) {
			ta.setAlerts(alerts);
			repository.save(ta);
		} else if (tg != null) {
			tg.setAlerts(alerts);
			repository.save(tg);
		} else {
			tp.setAlerts(alerts);
			repository.save(tp);
		}
	}
}
