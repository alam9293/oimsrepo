package gov.stb.tag.helper;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import gov.stb.tag.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaBranchApplicationBatch;
import gov.stb.tag.model.TaCompanyUpdate;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.TaMaSubmission;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.TgCourse;
import gov.stb.tag.model.TgLicenceCancellation;
import gov.stb.tag.model.TgLicenceCreation;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgLicenceReinstatement;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TgLicenceReplacement;
import gov.stb.tag.model.TgLicenceTierSwitch;
import gov.stb.tag.model.TgPersonUpdate;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowConfig;
import gov.stb.tag.repository.ApplicationHelperRepository;
import gov.stb.tag.repository.UserCommonRepository;

@Component
@Transactional
public class ApplicationHelper extends BaseWorkflowHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ApplicationHelperRepository applicationHelperRepository;

	@Autowired
	private UserCommonRepository userCommonRepository;

	@Autowired
	private Cache cache;

	@Autowired
	private WorkflowHelper workflowHelper;

	private static final String FULFIL_1ST = "1";
	private static final String FULFIL_2ND = "2";
	private static final String ISSUE_INCRE = "3";

	public Application saveNewApplication(String appTypeCode, Integer licenceId, boolean isOfflineSubmission, boolean isDraft) {
		Type appType = cache.getType(appTypeCode);
		Application app = new Application();
		app.setOfflineSubmission(isOfflineSubmission);
		app.setIsDraft(isDraft);
		app.setIsDeleted(Boolean.FALSE);
		app.setType(appType);
		app.setTaTgType(appTypeCode.startsWith(Codes.TypeCategories.TA_APPLICATION_TYPE) ? Codes.TaTgType.TA : Codes.TaTgType.TG);
		app.setLicence((licenceId == null ? null : applicationHelperRepository.get(Licence.class, licenceId)));
		app.setSubmissionDate(isDraft ? null : LocalDateTime.now());
		applicationHelperRepository.save(app);
		return app;
	}

	public Application saveNewCourseApplication(String appTypeCode, String courseCode, boolean isOfflineSubmission, boolean isDraft) {
		Type appType = cache.getType(appTypeCode);
		Application app = new Application();
		app.setOfflineSubmission(isOfflineSubmission);
		app.setIsDraft(isDraft);
		app.setIsDeleted(Boolean.FALSE);
		app.setType(appType);
		app.setTaTgType(appTypeCode.startsWith(Codes.TypeCategories.TA_APPLICATION_TYPE) ? Codes.TaTgType.TA : Codes.TaTgType.TG);
		app.setTgCourse((courseCode == null ? null : applicationHelperRepository.get(TgCourse.class, courseCode)));
		app.setSubmissionDate(isDraft ? null : LocalDateTime.now());
		applicationHelperRepository.save(app);
		return app;
	}

	/**
	 * Create and save an action with status = next step's start status (or first step's start status, if last action is null or RFA). If no more step found or no steps configured, status = APPROVED.
	 */
	public WorkflowAction forward(Application app, boolean isSubmit) {
		setIfHasIpaApproved(app);
		return super.forward(null, app, isSubmit, null, null, null, null, null, false, null, null, false);
	}

	/**
	 * Create and save an action with status = next step's start status (or first step's start status, if last action is null or RFA). If no more step found or no steps configured, status = APPROVED.
	 */
	public WorkflowAction resubmit(Application app, boolean isResubmit) {
		setIfHasIpaApproved(app);
		return super.forward(null, app, false, null, null, null, null, null, isResubmit, null, null, false);
	}

	/**
	 * Create and save an action with status = next step's start status (or first step's start status, if last action is null or RFA). If no more step found or no steps configured, status = APPROVED.
	 */
	public WorkflowAction forward(Application app, boolean isSubmit, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs) {
		setIfHasIpaApproved(app);
		return super.forward(null, app, isSubmit, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, false, null, null, false);
	}

	/**
	 * Create and save an action with status = any status below current level or RFA (RETURN FOR ACTION).
	 */
	public WorkflowAction rfa(Application app, String statusCode, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs,
			Integer assigneeId) {
		setIfHasIpaApproved(app);
		return super.rfa(null, app, statusCode, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, assigneeId);
	}

	/**
	 * Create and save an action with status = RFA (RETURN FOR ACTION). Used for TG Licence Renewal / Reinstatement.
	 */
	public WorkflowAction rfaAfterApproved(Application app, String statusCode, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs,
							  Integer assigneeId) {
		return super.rfaAfterApproved(null, app, statusCode, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, assigneeId);
	}

	/**
	 * Create and save an action with status = REJECTED
	 */
	public WorkflowAction reject(Application app, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs) {
		setIfHasIpaApproved(app);
		return super.reject(null, app, internalRemarks, externalRemarks, recommendationCode, files, fileDescs);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to add notes
	 */
	public WorkflowAction saveNote(Application app, String internalRemarks, List<MultipartFile> files, List<String> fileDescs) {
		return super.saveNote(null, app, internalRemarks, files, fileDescs);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to keep track edit submission action
	 */
	public WorkflowAction edit(Application app, String internalRemarks) {
		return super.edit(null, app, internalRemarks);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to keep track re-assign action
	 */
	public WorkflowAction reAssign(Application app, User assignee, String internalRemarks) {
		return super.reAssign(null, app, assignee, internalRemarks);
	}

	/**
	 * Auto approve
	 */
	public WorkflowAction autoApprove(Application app, boolean isSubmit) {
		return super.autoApprove(null, app, isSubmit, null, null);
	}

	/**
	 * Auto reject
	 */
	public WorkflowAction autoReject(Application app, boolean isSubmit, String internalRemark, String externalRemark) {
		return super.autoReject(null, app, isSubmit, null, internalRemark, externalRemark);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to follow up
	 */
	public WorkflowAction followUp(Application app, String internalRemarks, String externalRemarks) {
		return super.followUp(null, app, internalRemarks, externalRemarks);
	}

	/**
	 * Create and save an submit action with status = APPROVED.
	 */
	public WorkflowAction resubmitAfterFollowUp(Application app, boolean isResubmit) {
		return super.resubmitAfterFollowUp(app);
	}

	/**
	 * Checks if the specified application is at its final approval.
	 */
	public Boolean isFinalApproval(Application app) {
		setIfHasIpaApproved(app);
		if (app.getLastAction() != null) {
			return super.isFinalApproval(
					(app.hasIpaApproved() == null || (app.hasIpaApproved() != null && !app.hasIpaApproved())) ? app.getType().getCode() : Codes.ApplicationTypes.TA_APP_CREATION_IPA,
					app.getLastAction().getStatus().getCode());
		}
		return false;
	}

	/**
	 * Checks if the specified application has been final approved.
	 */
	public Boolean hasFinalApproved(Application app) {
		if (app.getLastAction() != null) {
			return app.getLastAction().getStatus().getCode().equals(getApprovedStatusCode(null, app));
		}
		return false;
	}

	/**
	 * Checks if the specified application has been final approved/Rejected.
	 */
	public Boolean hasFinalApprovedOrRejected(Application app) {
		if (app.getLastAction() != null) {
			return app.getLastAction().getStatus().getCode().equals(super.getApprovedStatusCode(null, app)) || app.getLastAction().getStatus().getCode().equals(super.getRejectedStatusCode(null, app));
		} else {
			return false;
		}
	}

	// Override to handle TA_APP_CREATION's IPA logic, which if IPA Approved, will return the TA_APP_CREATION_IPA workflow for TA_APP_CREATION app
	@Override
	protected WorkflowConfig getWorkflowConfig(Workflow workflow, Application app) {
		if (app.hasIpaApproved() != null && app.hasIpaApproved()) {
			return super.baseWorkflowHelperRepository.getWorkflowConfig(Codes.ApplicationTypes.TA_APP_CREATION_IPA);
		}
		return super.getWorkflowConfig(workflow, app);
	}

	// Override to handle TA_APP_CREATION's IPA logic, which if IPA Approved, will treat "Pending Operating Status" as the initial status for TA_APP_CREATION_IPA workflow
	@Override
	protected Boolean toSaveFirstStepAction(Workflow workflow, Application app) {
		if (app.hasIpaApproved() != null && app.hasIpaApproved()) {
			return Entities.equals(app.getLastAction().getStatus(), Codes.Statuses.TA_APP_PENDING_OA) || Entities.equals(app.getLastAction().getStatus(), Codes.Statuses.TA_APP_RFA);
		}
		return super.toSaveFirstStepAction(workflow, app);
	}

	// Override to handle TA_APP_CREATION's IPA logic, which if IPA flow, will return either "Pending Operating Address" or the final "Approved" status
	@Override
	protected String getApprovedStatusCode(Workflow workflow, Application app) {
		if (app.hasIpaApproved() != null) {
			return app.hasIpaApproved() ? Codes.Statuses.TA_APP_APPROVED : Codes.Statuses.TA_APP_PENDING_OA;
		}
		return super.getApprovedStatusCode(workflow, app);
	}

	// only set the hasIpaApproved flag (transient) if the application is a TA_APP_CREATION with applicationMode = IPA
	private void setIfHasIpaApproved(Application app) {
		if (Entities.equals(app.getType(), Codes.ApplicationTypes.TA_APP_CREATION)) {
			TaLicenceCreation tlc = applicationHelperRepository.getApplicationByClass(app.getId(), TaLicenceCreation.class);
			if (Entities.equals(tlc.getApplicationMode(), Codes.Types.TA_APPR_IPA)) {
				app.setHasIpaApproved(applicationHelperRepository.hasIpaApproved(app.getId()));
			} else if (Entities.equals(tlc.getApplicationMode(), Codes.Types.TA_APPR_FA)) {
				if (CollectionUtils.isNotEmpty(app.getWorkflowActions()) && app.getWorkflowActions().stream().anyMatch(u -> Entities.equals(u.getStatus(), Codes.Statuses.TA_APP_PENDING_OA))) {
					app.setHasIpaApproved(true);
				}
			}
		}
	}

	/**
	 * Save and return a workflow action with only the specified status code. This function is usually for the first action of creating the application.
	 */
	@Deprecated // to use forward
	public WorkflowAction saveAction(Application app, String statusCode) {
		return saveAction(app, statusCode, null, null, null, null);
	}

	/**
	 * Base function to save and return a workflow action with the specified parameters.
	 */
	@Deprecated // to use forward
	public WorkflowAction saveAction(Application app, String statusCode, String internalRemarks, String externalRemarks, List<MultipartFile> files, List<String> fileDescs) {
		String actionType;
		if (statusCode.equals(getApprovedStatusCode(null, app))) {
			actionType = Codes.WorkflowActionTypes.APPROVE;
		} else if (statusCode.equals(getRejectedStatusCode(null, app))) {
			actionType = Codes.WorkflowActionTypes.REJECT;
		} else {
			actionType = Codes.WorkflowActionTypes.RFA;
		}
		return super.saveAction(null, app, statusCode, internalRemarks, externalRemarks, null, files, fileDescs, actionType, getCurrentRole());
	}

	public Application isAppBelongToTA(Integer appId, User user) {
		Application app = applicationHelperRepository.get(Application.class, appId);
		if (Objects.isNull(app)) {
			throw new ValidationException("Application is null");
		}
		if (Objects.isNull(app.getLicence())) {
			throw new ValidationException("Application does not belong to any licencee");
		}
		if (Objects.isNull(app.getLicence().getTravelAgent())) {
			throw new ValidationException("Application does not belong to any Travel Agent licencee");
		}
		if (Objects.isNull(user)) {
			throw new ValidationException("User is null");
		}
		if (Objects.isNull(user.getTravelAgent())) {
			throw new ValidationException("User is not a Travel Agent");
		}
		if (!app.getLicence().getTravelAgent().getUen().equals(user.getTravelAgent().getUen())) {
			throw new ValidationException("This application does not belong to the logged in user");
		}
		return app;
	}

	public void isAppBelongToTA(TaLicenceCreation app, User user) {
		if (Objects.isNull(app)) {
			throw new ValidationException("Application is null");
		}

		if (Objects.isNull(user)) {
			throw new ValidationException("User is null");
		}
		if (!app.getUen().equals(user.getUen())) {
			throw new ValidationException("This application does not belong to the logged in user");
		}
	}

	public void isAppBelongToTG(Object appObject, User user, String appType) {

		Application app = null;
		var userNric = new String();
		switch (appType) {
		case (Codes.ApplicationTypes.TG_APP_CREATION):
			var tgLicenceCreation = (TgLicenceCreation) appObject;
			app = tgLicenceCreation.getApplication();
			userNric = tgLicenceCreation.getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_CANCELLATION):
			var tgLicenceCancellation = (TgLicenceCancellation) appObject;
			app = tgLicenceCancellation.getApplication();
			userNric = app.getLicence().getTouristGuide().getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_RENEWAL):
			var tgLicenceRenewal = (TgLicenceRenewal) appObject;
			app = tgLicenceRenewal.getApplication();
			userNric = app.getLicence().getTouristGuide().getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_REINSTATEMENT):
			var tgLicenceReinstatement = (TgLicenceReinstatement) appObject;
			app = tgLicenceReinstatement.getApplication();
			userNric = app.getLicence().getTouristGuide().getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_REPLACEMENT):
			var tgLicenceReplacement = (TgLicenceReplacement) appObject;
			app = tgLicenceReplacement.getApplication();
			userNric = app.getLicence().getTouristGuide().getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_PERSON_UPDATE):
			var tgPersonUpdate = (TgPersonUpdate) appObject;
			app = tgPersonUpdate.getApplication();
			userNric = tgPersonUpdate.getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_MLPT_REGISTRATION):
			var registration = (TgLicenceMlptRegistration) appObject;
			app = registration.getApplication();
			userNric = app.getLicence().getTouristGuide().getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_SWITCH_TIER):
			var tgSwitchTier = (TgLicenceTierSwitch) appObject;
			app = tgSwitchTier.getApplication();
			userNric = app.getLicence().getTouristGuide().getUin();
			break;
		case (Codes.ApplicationTypes.TG_APP_STIPEND):
			var tgStipend = (TgStipend) appObject;
			app = tgStipend.getApplication();
			userNric = app.getLicence().getTouristGuide().getUin();
			break;
		}


		if (Objects.isNull(app)) {
			throw new ValidationException("Application cannot be found.");
		}

		if (Objects.isNull(user)) {
			throw new ValidationException("Invalid user");
		}
		if (!userNric.equals(user.getLoginId())) {
			throw new ValidationException("This application does not belong to the logged in user");
		}
	}

	public TaStakeholderApplication snapshotCurrentStakeholder(TaStakeholderApplication prevValue, TaStakeholder tsh) {
		prevValue.setAddress(tsh.getStakeholder().getAddress());
		prevValue.setAppointedDate(tsh.getAppointedDate());
		prevValue.setCompanyIncorporatedDate(tsh.getStakeholder().getCompanyIncorporatedDate());
		prevValue.setCompanyUen(tsh.getStakeholder().getCompanyUen());
		prevValue.setContactNo(tsh.getStakeholder().getContactNo());

		prevValue.setOfficeNo(tsh.getStakeholder().getOfficeNo());
		prevValue.setResidentialNo(tsh.getStakeholder().getResidentialNo());

		prevValue.setEmail(tsh.getStakeholder().getEmail());
		prevValue.setIsCompany(tsh.getStakeholder().getIsCompany());
		prevValue.setName(tsh.getStakeholder().getName());
		prevValue.setNationality(tsh.getStakeholder().getNationality());
		prevValue.setResignedDate(tsh.getResignedDate());
		prevValue.setRole(tsh.getRole());
		prevValue.setSex(tsh.getStakeholder().getSex());
		prevValue.setSharesHeld(tsh.getSharesHeld());
		prevValue.setUin(tsh.getStakeholder().getUin());
		prevValue.setHighestEduLevel(tsh.getStakeholder().getHighestEduLevel());
		prevValue.setDesignation(tsh.getStakeholder().getDesignation());
		prevValue.setOtherDesignation(tsh.getStakeholder().getOtherDesignation());
		prevValue.setDob(tsh.getStakeholder().getDob());

		return prevValue;
	}

	public TaCompanyUpdate snapshotCurrentCompanyDetails(TaCompanyUpdate tcu, Licence lic) {
		// snapshot current values
		TravelAgent ta = lic.getTravelAgent();
		if (ta != null) {
			tcu.setCompanyName(ta.getName());
			tcu.setFormOfBusiness(ta.getFormOfBusiness());
			tcu.setBusinessConstitution(ta.getBusinessConstitution());
			tcu.setTaSegmentation(ta.getTaSegmentation());
			tcu.setPrincipleActivities(ta.getPrincipleActivities());
			tcu.setSecondaryPrincipleActivities(ta.getSecondaryPrincipleActivities());
			tcu.setPlaceIncorporated(ta.getIncorporatedPlace());
			tcu.setEstablishmentStatus(ta.getEstablishmentStatus());
			tcu.setPaidUpCapital(ta.getPaidUpCapital());
			tcu.setWebsiteUrl(ta.getWebsiteUrl());
			tcu.setEmailAddress(ta.getEmailAddress());
			tcu.setContactNo(ta.getContactNo());
			tcu.setFaxNo(ta.getFaxNo());
			tcu.setRegisteredAddress(ta.getRegisteredAddress());
			tcu.setOperatingAddress(ta.getOperatingAddress());
			tcu.setIsEdhPopulated(Boolean.FALSE);
		}

		return tcu;
	}

	public TgPersonUpdate snapshotCurrentTgDetails(TgPersonUpdate tpu, TouristGuide tg) {
		// snapshot current values
		if (tg != null) {
			tpu.setUin(tg.getUin());
			tpu.setUser(tg.getUser());
			tpu.setSalutation(tg.getSalutation());
			tpu.setName(tg.getName());
			tpu.setDob(tg.getDob());
			tpu.setSex(tg.getSex());
			tpu.setMaritalStatus(tg.getMaritalStatus());
			tpu.setRace(tg.getRace());
			tpu.setNationality(tg.getNationality());
			tpu.setBirthCountry(tg.getBirthCountry());
			tpu.setResidentialStatus(tg.getResidentialStatus());
			tpu.setHighestEduLevel(tg.getHighestEduLevel());
			tpu.setMobileNo(tg.getMobileNo());
			tpu.setEmailAddress(tg.getEmailAddress());
			tpu.setEmployerName(tg.getEmployerName());
			tpu.setOccupation(tg.getOccupation());
			tpu.setOccupationOther(tg.getOccupationOther());
			tpu.setWorkPassType(tg.getWorkPassType());
			tpu.setWorkpassExpiryDate(tg.getWorkPassExpiryDate());
			tpu.setAliasName(tg.getAliasName());
			tpu.setRegisteredAddress(tg.getRegisteredAddress());
			tpu.setOperatingAddress(tg.getMailingAddress());
			tpu.setHasConsentEmailAddress(tg.getHasConsentEmailAddress());
			tpu.setHasConsentMobileNo(tg.getHasConsentMobileNo());
			tpu.setIsMyInfoPopulated(tg.isMyInfoPopulated());
		}

		return tpu;
	}

	public TaFilingCondition saveTaAnnualFiling(Licence licence, LocalDate fyStartDate, LocalDate fyEndDate, String appTypeCode, CeCaseInfringement tarR141Infringement) {
		TaFilingCondition newTaAnnualFiling = new TaFilingCondition();
		newTaAnnualFiling.setFyStartDate(fyStartDate);
		newTaAnnualFiling.setFyEndDate(fyEndDate);
		newTaAnnualFiling.setFy(fyEndDate.getYear());
		newTaAnnualFiling.setDueDate((fyEndDate.plusDays(1)).plusMonths(6).minusDays(1));
		newTaAnnualFiling.setApplicationType(cache.getType(appTypeCode));
		newTaAnnualFiling.setLicence(licence);
		newTaAnnualFiling.setStatus(isOverdue(newTaAnnualFiling.getDueDate()) ? cache.getStatus(Codes.Statuses.TA_FILING_LATE) : cache.getStatus(Codes.Statuses.TA_FILING_PEND_SUBMISSION));
		applicationHelperRepository.save(newTaAnnualFiling);

		return newTaAnnualFiling;
	}

	public LocalDate getNextFyEndDate(LocalDate currentFyEndDate) {
		LocalDate nextFyEndDate = currentFyEndDate.plusMonths(12);

		// check if new fye date falls on 28-Feb leap year, if yes, auto correct to 29-Feb.
		if (nextFyEndDate.isLeapYear() && nextFyEndDate.getMonthValue() == 2 && nextFyEndDate.getDayOfMonth() == 28) {
			nextFyEndDate = nextFyEndDate.plusDays(1);
		}
		return nextFyEndDate;
	}

	private Boolean isOverdue(LocalDate dueDate) {
		return LocalDate.now().isAfter(dueDate);
	}

	public TaNetValueShortfall createNetValueShortfall(TaAaSubmission aa, TaMaSubmission ma) {

		Licence licence = aa == null ? ma.getApplication().getLicence() : aa.getApplication().getLicence();
		TaNetValueShortfall latestPendingShortfall = applicationHelperRepository.getLatestPendingNetValueShortfall(licence.getId());

		String shortfallType = null;

		BigDecimal shortfallAmount = BigDecimal.ZERO;
		if (aa != null) {
			shortfallAmount = aa.getShortfall();
		} else if (ma != null) {
			shortfallAmount = ma.getShortfall();
		}

		if (latestPendingShortfall == null) {
			logger.info("No pending shortfall.");
			shortfallType = Codes.Types.TA_SHORTFALL_FULL;

		} else {
			logger.info("Has pending shortfall.");
			shortfallType = Codes.Types.TA_SHORTFALL_FULL; // default to full?
		}

		Workflow workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.TA_WKFLW_SHORTFALL, "System generated.", null, null, Boolean.TRUE, licence);
		TaNetValueShortfall netvalueShortfall = new TaNetValueShortfall();
		netvalueShortfall.setWorkflow(workflow);
		netvalueShortfall.setTaAaSubmission(aa);
		netvalueShortfall.setTaMaSubmission(ma);
		netvalueShortfall.setAmount(shortfallAmount);
		netvalueShortfall.setType(cache.getType(shortfallType));
		netvalueShortfall.setParentShortfall(latestPendingShortfall);
		applicationHelperRepository.save(netvalueShortfall);

		return netvalueShortfall;
	}

	public List<FileDto> addFilesNotIncluded(List<FileDto> fileList, List<FileDto> reqFileList) {
		if (fileList.isEmpty()) {
			return reqFileList;
		} else {
			for (FileDto file : fileList) {
				if (file.getDocType().equalsIgnoreCase(Codes.TaDocumentTypes.TA_DOC_OTHERS)) {
					reqFileList.add(file);
				} else {
					if (!Strings.isNullOrEmpty(file.getOriginalName())) {
						FileDto a = reqFileList.stream().filter(i -> i.getDocType().equalsIgnoreCase(file.getDocType())).findFirst().orElse(null);
						Integer i = reqFileList.indexOf(a);
						reqFileList.remove(a);
						reqFileList.add(i, file);
					}
				}
			}
			return reqFileList;
		}
	}

	/**
	 * get signing officer - special for C&E
	 */
	public User getSigningOfficerForCE(Application app, User currentOfficer) {
		Set<WorkflowAction> workflowActions = app.getWorkflowActions();
		if (CollectionUtils.isNotEmpty(workflowActions)) {
			List<WorkflowAction> filterWorkflowActions = workflowActions.stream().filter(u -> u.getPrevStatus() != null && Codes.TaStatuses.CE_SIGNING_STATUS.contains(u.getPrevStatus().getCode()))
					.collect(Collectors.toList());

			if (CollectionUtils.isNotEmpty(filterWorkflowActions)) {
				Collections.sort(filterWorkflowActions, Comparator.comparing(WorkflowAction::getCreatedDate).reversed());
				return userCommonRepository.getUserByLoginId(filterWorkflowActions.get(0).getCreatedBy());
			}
		}
		return currentOfficer;
	}

	public void setTaApplicationPendingPrinting(Application app) {
		switch (app.getType().getCode()) {
		case Codes.ApplicationTypes.TA_APP_CREATION:
		case Codes.ApplicationTypes.TA_APP_RENEWAL:
		case Codes.ApplicationTypes.TA_APP_TIER_SWITCH:
		case Codes.ApplicationTypes.TA_APP_REPLACEMENT:
		case Codes.ApplicationTypes.TA_APP_COMPANY_UPDATE:
		case Codes.ApplicationTypes.TA_APP_BRANCH:
			app.setLicencePrintStatus(cache.getStatus(Codes.Statuses.TA_PRINT_PENDING));
			app.setLicenceCollectedDate(null);
			if (app.getLicence() != null) {
				app.setAssignee(getAssigneeByChar(Codes.Roles.TA_PROCESSING_OFFICER, app.getLicence().getTravelAgent().getName()));
			}
			applicationHelperRepository.save(app);
		}
	}

	public void setTaApplicationPendingPrinting(TaCompanyUpdate taCompanyUpdate) {
		TaCompanyUpdate previousValues = taCompanyUpdate.getPreviousValue();
		if (previousValues != null) {
			if (taCompanyUpdate.getCompanyName() != null && previousValues.getCompanyName() != null && !taCompanyUpdate.getCompanyName().equalsIgnoreCase(previousValues.getCompanyName())) {
				setTaApplicationPendingPrinting(taCompanyUpdate.getApplication());
			} else if (taCompanyUpdate.getOperatingAddress() != null && previousValues.getOperatingAddress() != null) {
				if (!isSameAddress(taCompanyUpdate.getOperatingAddress(), previousValues.getOperatingAddress())) {
					setTaApplicationPendingPrinting(taCompanyUpdate.getApplication());
				}
			}
		}
	}

	public void setTaApplicationPendingPrinting(TaBranchApplicationBatch taBranchApplicationBatch) {

		List<String> branchAppTypes = taBranchApplicationBatch.getTaBranchApplications().stream().map(branchApp -> branchApp.getType().getCode()).collect(Collectors.toList());
		if (branchAppTypes.contains(Codes.ApplicationTypes.TA_APP_BRANCH_NEW) || branchAppTypes.contains(Codes.ApplicationTypes.TA_APP_BRANCH_UPDATE)) {
			setTaApplicationPendingPrinting(taBranchApplicationBatch.getApplication());
		}
	}

	private Boolean isSameAddress(Address address1, Address address2) {
		if (address1 == null && address2 != null) {
			return false;
		}
		if (address1 != null && address2 == null) {
			return false;
		}
		if (Entities.equals(address1.getAddressType(), address2.getAddressType())) {
			if (Entities.equals(address1.getAddressType(), Codes.Types.ADDR_LOCAL)) {
				return (address1.getBlock() != null && address2.getBlock() != null && address1.getBlock().equalsIgnoreCase(address2.getBlock()))
						&& (address1.getStreet() != null && address2.getStreet() != null && address1.getStreet().equalsIgnoreCase(address2.getStreet()))
						&& (address1.getBuilding() != null && address2.getBuilding() != null && address1.getBuilding().equalsIgnoreCase(address2.getBuilding()))
						&& (address1.getFloor() != null && address2.getFloor() != null && address1.getFloor().equalsIgnoreCase(address2.getFloor()))
						&& (address1.getUnit() != null && address2.getUnit() != null && address1.getUnit().equalsIgnoreCase(address2.getUnit()))
						&& (address1.getPostal() != null && address2.getPostal() != null && address1.getPostal().equalsIgnoreCase(address2.getPostal()));
			} else {
				return (address1.getForeignLine1() != null && address2.getForeignLine1() != null && address1.getForeignLine1().equalsIgnoreCase(address2.getForeignLine1()))
						&& (address1.getForeignLine2() != null && address2.getForeignLine2() != null && address1.getForeignLine2().equalsIgnoreCase(address2.getForeignLine2()))
						&& (address1.getForeignLine3() != null && address2.getForeignLine3() != null && address1.getForeignLine3().equalsIgnoreCase(address2.getForeignLine3()));
			}
		} else {
			return false;
		}
	}

	public TgLicenceRenewal getRenewalAppByLicId(Integer licenceId) {
		TgLicenceRenewal aa = applicationHelperRepository.getRenewalAppByLicId(licenceId);
		return applicationHelperRepository.getRenewalAppByLicId(licenceId);
	}
}
