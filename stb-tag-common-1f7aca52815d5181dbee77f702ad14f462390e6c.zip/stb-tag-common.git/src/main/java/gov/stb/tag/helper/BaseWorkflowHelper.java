package gov.stb.tag.helper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.base.Strings;
import com.wiz.security.CustomAuthenticationToken;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowConfig;
import gov.stb.tag.model.WorkflowStep;
import gov.stb.tag.model.WorkflowStepAssignment;
import gov.stb.tag.repository.ApplicationHelperRepository;
import gov.stb.tag.repository.BaseWorkflowHelperRepository;
import gov.stb.tag.repository.TaCommonRepository;
import gov.stb.tag.repository.UserCommonRepository;

@Component
public abstract class BaseWorkflowHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	protected static final String ERR_RFA_STEP_MUST_BE_LOWER = "You can only RFA this workflow to a status lower than the current one.";
	protected static final String ERR_NOT_TASKED_YET = "You are not authorized or tasked to process this workflow at this stage: ";
	protected static final String ERR_INVALID_PARAMS = "Please specify either the workflow OR the application for this helper function.";
	protected static final String ERR_LAST_ACTION_MISSING = "The workflow or application must have a lastAction (see toSaveFirstStepAction()).";
	protected static final String ERR_WORKFLOW_TYPE_NOT_FOUND = "The workflow type cannot be found.";
	protected static final String ERR_CURRENT_STEP_NOT_FOUND = "The current step can no longer be found in its workflow steps configuration."; // possibly due to data patch (see cascadeConfig())
	protected static final String ERR_APPROVE_NOT_ALLOWED = "You are not allowed to approve the submission.";
	protected static final String ERR_EDITOR_CANNOT_BE_APPROVER = "Officer who edited the application cannot be the approver.";
	protected static final String ERR_WORKFLOW_STEP_CONFIG_NOT_FOUND = "The workflow steps configuration cannot be found.";
	protected static final String ERR_CURRENT_STEP_ASSIGNMENT_NOT_FOUND = "The current step assignment can no longer be found in its workflow steps configuration.";
	protected static final String ERR_RFA_STEP_MUST_BE_BEFORE_PRINT = "You can only RFA this application before licence sent for printing.";
	protected static final String ERR_REASSIGN_TO_SAME_USER = "Please uncheck the row that is curently assigned to the selected officer.";

	@Autowired
	protected FileHelper fileHelper;
	@Autowired
	protected CacheHelper cache;
	@Autowired
	protected BaseWorkflowHelperRepository baseWorkflowHelperRepository;
	@Autowired
	protected ApplicationHelperRepository applicationHelperRepository;
	@Autowired
	protected UserCommonRepository userCommonRepository;
	@Autowired
	protected TaCommonRepository taCommonRepository;

	/**
	 * Create and save an action with status = next step's start status (or first step's start status, if last action is null or RFA. If no more step found or no steps configured, status = APPROVED.
	 * isSubmit = true (application or workflow case is submitted by public users)
	 */
	protected WorkflowAction forward(Workflow workflow, Application app, boolean isSubmit, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files,
			List<String> fileDescs, boolean isResubmit, Integer supporterId, Integer approverId, boolean followStepAssignment) {
		validateParameters(workflow, app);
		WorkflowConfig workflowConfig = getWorkflowConfig(workflow, app);
		workflow = saveOrUpdateStepAssignment(workflow, workflowConfig, supporterId, approverId);
		if (toSaveFirstStepAction(workflow, app) || isResubmit) {
			if (isResubmit) {
				isSubmit = true;
			}
			return saveFirstStepAction(workflow, app, isSubmit, workflowConfig, internalRemarks, recommendationCode, followStepAssignment, files, fileDescs);

		} else {
			WorkflowStep currentStep = getCurrentStep(workflow, app, workflowConfig);
			Role role = validateRole(currentStep);

			Optional<WorkflowStep> nextStep = null;
			if (followStepAssignment) {
				List<WorkflowStepAssignment> workflowStepAssignments = workflow.getWorkflowStepAssignments();
				List<WorkflowStep> workflowSteps = workflowStepAssignments.stream().map(WorkflowStepAssignment::getWorkflowStep).collect(Collectors.toList());
				nextStep = workflowSteps.stream().sorted(Comparator.comparing(WorkflowStep::getId)).filter(step -> step.getLevel() > currentStep.getLevel()).findFirst();
			} else {
				nextStep = workflowConfig.getWorkflowSteps().stream().sorted(Comparator.comparing(WorkflowStep::getId)).filter(step -> step.getLevel() > currentStep.getLevel()).findFirst();
			}

			if (nextStep.isPresent()) {

				WorkflowStep nextWorkflowStep = nextStep.get();
				// save action with status = next step's start status
				return saveAction(workflow, app, nextWorkflowStep.getStartStatus().getCode(), internalRemarks, externalRemarks, recommendationCode, files, fileDescs,
						isSubmit ? Codes.WorkflowActionTypes.SUBMIT : Codes.WorkflowActionTypes.FORWARD, role);
			} else {
				// no more nextStep indicates this is the final step
				checkIfEditActionIsSameOfficer(workflow, app);
				return saveAction(workflow, app, getApprovedStatusCode(workflow, app), internalRemarks, externalRemarks, recommendationCode, files, fileDescs,
						isSubmit ? Codes.WorkflowActionTypes.SUBMIT : Codes.WorkflowActionTypes.APPROVE, role);
			}
		}
	}

	/**
	 * Create and save an action with status = any status below current level or RFA (RETURN FOR ACTION).
	 */
	protected WorkflowAction rfa(Workflow workflow, Application app, String rfaStatusCode, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files,
			List<String> fileDescs, Integer assigneeId) {
		validateParameters(workflow, app);
		WorkflowConfig workflowConfig = getWorkflowConfig(workflow, app);
		WorkflowStep currentStep = getCurrentStep(workflow, app, workflowConfig);
		Role role = validateRole(currentStep);
		User user = assigneeId != null ? userCommonRepository.getUserById(assigneeId) : null;
		if (app != null) {
			if ((app.getTaTgType().equals(Codes.TaTgType.TA) && rfaStatusCode.equals(Codes.Statuses.TA_APP_RFA))
					|| (app.getTaTgType().equals(Codes.TaTgType.TG) && rfaStatusCode.equals(Codes.Statuses.TG_APP_RFA))) {
				return saveAction(workflow, app, rfaStatusCode, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, Codes.WorkflowActionTypes.RFA, role, user);
			}
		} else if (workflow != null) {
			if (isCeCategory(workflow) && rfaStatusCode.equals(Codes.Statuses.CE_WKFLW_ROUTED)) {
				return saveAction(workflow, app, rfaStatusCode, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, Codes.WorkflowActionTypes.ROUTE, role, user);
			}
		}
		WorkflowStep rfaStep = getStepByStatusCode(rfaStatusCode, workflowConfig);
		if (rfaStep.getLevel() < currentStep.getLevel()) {
			return saveAction(workflow, app, rfaStatusCode, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, Codes.WorkflowActionTypes.ROUTE, role, user);
		} else {
			logger.error(ERR_RFA_STEP_MUST_BE_LOWER);
			throw new ValidationException(ERR_RFA_STEP_MUST_BE_LOWER);
		}
	}

	/**
	 * Create and save an action with status (RETURN FOR ACTION) after application status = APPROVED. Used for TG Renewal / Reinstatement application.
	 */
	protected WorkflowAction rfaAfterApproved(Workflow workflow, Application app, String rfaStatusCode, String internalRemarks, String externalRemarks, String recommendationCode,
			List<MultipartFile> files, List<String> fileDescs, Integer assigneeId) {
		validateParameters(workflow, app);
		Role role = getCurrentRole();
		User user = assigneeId != null ? userCommonRepository.getUserById(assigneeId) : null;
		if (Entities.anyEquals(app.getLicencePrintStatus(), Codes.Statuses.PRINT_SUBMIT_PRINT, Codes.Statuses.PRINT_PENDING_COLLECTION, Codes.Statuses.PRINT_LICENCE_COLLECTED)) {
			logger.error(ERR_RFA_STEP_MUST_BE_BEFORE_PRINT);
			throw new ValidationException(ERR_RFA_STEP_MUST_BE_BEFORE_PRINT);
		}
		return saveAction(workflow, app, rfaStatusCode, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, Codes.WorkflowActionTypes.RFA, role, user);
	}

	/**
	 * Create and save an action with status = REJECTED
	 */
	protected WorkflowAction reject(Workflow workflow, Application app, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs) {
		validateParameters(workflow, app);
		WorkflowConfig workflowConfig = getWorkflowConfig(workflow, app);
		WorkflowStep currentStep = getCurrentStep(workflow, app, workflowConfig);
		Role role = validateRole(currentStep);
		return saveAction(workflow, app, getRejectedStatusCode(workflow, app), internalRemarks, externalRemarks, recommendationCode, files, fileDescs, Codes.WorkflowActionTypes.REJECT, role);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to add notes
	 */
	protected WorkflowAction saveNote(Workflow workflow, Application app, String internalRemarks, List<MultipartFile> files, List<String> fileDescs) {
		validateParameters(workflow, app);
		return saveAction(workflow, app, getStatusCode(workflow, app), internalRemarks, null, getRecommendationCode(workflow, app), files, fileDescs, Codes.WorkflowActionTypes.ADD_NOTE,
				getCurrentRole());
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to keep track edit submission action
	 */
	protected WorkflowAction edit(Workflow workflow, Application app, String internalRemarks) {
		validateParameters(workflow, app);
		return saveAction(workflow, app, getStatusCode(workflow, app), internalRemarks, null, getRecommendationCode(workflow, app), null, null, Codes.WorkflowActionTypes.EDIT, getCurrentRole());
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to keep track re-assign action
	 */
	protected WorkflowAction reAssign(Workflow workflow, Application app, User assignee, String internalRemarks) {
		validateParameters(workflow, app);
		if (workflow != null) {
			if (workflow.getAssignee() != null && workflow.getAssignee().equals(assignee)) {
				logger.error(ERR_REASSIGN_TO_SAME_USER);
				throw new ValidationException(ERR_REASSIGN_TO_SAME_USER);
			}
		}
		if (app != null && app.getAssignee() != null) {
			if (app.getAssignee().equals(assignee)) {
				logger.error(ERR_REASSIGN_TO_SAME_USER);
				throw new ValidationException(ERR_REASSIGN_TO_SAME_USER);
			}
		}
		return saveAction(workflow, app, getStatusCode(workflow, app), internalRemarks, null, getRecommendationCode(workflow, app), null, null, Codes.WorkflowActionTypes.RE_ASSIGN, getCurrentRole(),
				assignee);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to follow up
	 */
	protected WorkflowAction followUp(Workflow workflow, Application app, String internalRemarks, String externalRemarks) {
		validateParameters(workflow, app);
		return saveAction(workflow, app, getStatusCode(workflow, app), internalRemarks, externalRemarks, null, null, null, Codes.WorkflowActionTypes.FOLLOW_UP, getCurrentRole());
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to follow up
	 */
	protected WorkflowAction resubmitAfterFollowUp(Application app) {
		validateParameters(null, app);
		return saveActionForResubmitAfterFollowUp(app, getStatusCode(null, app), Codes.WorkflowActionTypes.SUBMIT, getCurrentRole());
	}

	/**
	 * Return a list of statuses available for RFA, which are the startStatuses of steps lower than the current level
	 */
	protected List<Status> getStatusesForRfa(Workflow workflow, Application app) {
		validateParameters(workflow, app);
		WorkflowConfig workflowConfig = getWorkflowConfig(workflow, app);
		WorkflowStep currentStep = getCurrentStep(workflow, null, workflowConfig);
		List<Status> rfaStatuses = workflowConfig.getWorkflowSteps().stream().filter(step -> step.getLevel() < currentStep.getLevel()).map(WorkflowStep::getStartStatus).collect(Collectors.toList());
		if (app != null) {
			rfaStatuses.add(cache.getStatus(app.getTaTgType().equals(Codes.TaTgType.TA) ? Codes.Statuses.TA_APP_RFA : Codes.Statuses.TG_APP_RFA)); // RFA back to TA/TG
		}
		return rfaStatuses;
	}

	/**
	 * Base function to save and return a workflow action with the specified parameters.
	 */
	protected WorkflowAction saveAction(Workflow workflow, Application app, String statusCode, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files,
			List<String> fileDescs, String actionTypeCode, Role role) {
		return saveAction(workflow, app, statusCode, internalRemarks, externalRemarks, recommendationCode, files, fileDescs, actionTypeCode, role, null);
	}

	protected WorkflowAction saveAction(Workflow workflow, Application app, String statusCode, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files,
			List<String> fileDescs, String actionTypeCode, Role role, User assignee) {
		validateParameters(workflow, app);
		WorkflowAction action = new WorkflowAction();
		if (workflow != null) {
			if (workflow.getLastAction() != null) {
				// do not overwrite previous status for add note, edit, re-assign and follow-up
				action.setPrevStatus(StringUtils.equalsAny(actionTypeCode, Codes.WorkflowActionTypes.ADD_NOTE, Codes.WorkflowActionTypes.EDIT, Codes.WorkflowActionTypes.RE_ASSIGN,
						Codes.WorkflowActionTypes.FOLLOW_UP) ? workflow.getLastAction().getPrevStatus() : workflow.getLastAction().getStatus());
			}
			action.setWorkflow(workflow);
		} else {
			if (app.getLastAction() != null) {
				// do not overwrite previous status for add note, edit, re-assign and follow-up
				action.setPrevStatus(StringUtils.equalsAny(actionTypeCode, Codes.WorkflowActionTypes.ADD_NOTE, Codes.WorkflowActionTypes.EDIT, Codes.WorkflowActionTypes.RE_ASSIGN,
						Codes.WorkflowActionTypes.FOLLOW_UP) ? app.getLastAction().getPrevStatus() : app.getLastAction().getStatus());
			}
			action.setApplication(app);
		}
		action.setActionBy(getUser());
		action.setType(cache.getType(actionTypeCode));
		action.setStatus(cache.getStatus(statusCode));
		action.setInternalRemarks(internalRemarks);
		action.setExternalRemarks(externalRemarks);
		action.setRecommendation(StringUtils.isNotBlank(recommendationCode) ? cache.getType(recommendationCode) : cache.getType(getRecommendationCode(workflow, app)));
		action.setRole(role);
		baseWorkflowHelperRepository.save(action);

		if (files != null && !files.isEmpty()) {
			Set<File> savedFiles = new HashSet<>();
			for (MultipartFile file : files) {
				if (fileDescs != null && !fileDescs.isEmpty()) {
					savedFiles.add(fileHelper.saveFile(action, fileDescs.get(files.indexOf(file)), file));
				} else {
					savedFiles.add(fileHelper.saveFile(action, null, file));
				}
			}
			action.setFiles(savedFiles);
		}

		// do not set assignee for add note and follow up
		if (!StringUtils.equalsAny(actionTypeCode, Codes.WorkflowActionTypes.ADD_NOTE, Codes.WorkflowActionTypes.FOLLOW_UP)) {
			// set assigned officer
			action.setAssignee(setAssignOfficer(workflow, app, actionTypeCode, statusCode, assignee));
		}

		// do not overwrite last action for add note, re-assign
		if (!StringUtils.equalsAny(actionTypeCode, Codes.WorkflowActionTypes.ADD_NOTE, Codes.WorkflowActionTypes.RE_ASSIGN)) {

			if (workflow != null) {
				if (!StringUtils.equalsAny(actionTypeCode, Codes.WorkflowActionTypes.EDIT) || Entities.equals(workflow.getType(), Codes.Workflow.TA_WKFLW_SHORTFALL)) {
					workflow.setLastAction(action);
					baseWorkflowHelperRepository.saveOrUpdate(workflow);
					logger.info("Saving Workflow Action - Id: {}, action: {}, workflow: {}, Status: {}, PrevStatus: {}, No. of Files: {}, IntRmks: {}, ExtRmks: {}, Rec: {}", workflow.getId(),
							action.getType().getCode(), statusCode, (action.getPrevStatus() == null ? "" : action.getPrevStatus().getCode()), (files == null ? "0" : files.size()), internalRemarks,
							externalRemarks, recommendationCode);
				}

			} else {
				app.setLastAction(action);
				baseWorkflowHelperRepository.saveOrUpdate(app);
				logger.info("Saving Workflow Action - Id: {}, action: {}, AppNo: {}, Status: {}, PrevStatus: {}, No. of Files: {}, IntRmks: {}, ExtRmks: {}, Rec: {}", app.getId(),
						action.getType().getCode(), app.getApplicationNo(), statusCode, (action.getPrevStatus() == null ? "" : action.getPrevStatus().getCode()), (files == null ? "0" : files.size()),
						internalRemarks, externalRemarks, recommendationCode);
			}

		}

		return action;
	}

	protected WorkflowAction saveActionForResubmitAfterFollowUp(Application app, String statusCode, String actionTypeCode, Role role) {
		validateParameters(null, app);
		WorkflowAction action = new WorkflowAction();
		if (app.getLastAction() != null) {
			// do not overwrite previous status
			action.setPrevStatus(app.getLastAction().getPrevStatus());
		}
		action.setApplication(app);
		action.setActionBy(getUser());
		action.setType(cache.getType(actionTypeCode));
		action.setStatus(cache.getStatus(statusCode));
		action.setRole(role);
		baseWorkflowHelperRepository.save(action);

		app.setLastAction(action);
		baseWorkflowHelperRepository.saveOrUpdate(app);
		logger.info("Saving Workflow Action - Id: {}, action: {}, AppNo: {}, Status: {}, PrevStatus: {}", app.getId(), action.getType().getCode(), app.getApplicationNo(), statusCode,
				(action.getPrevStatus() == null ? "" : action.getPrevStatus().getCode()));

		return action;
	}

	/**
	 * Checks if the specified current pending status is the final approval of the workflow or application.
	 */
	protected Boolean isFinalApproval(String appOrWkflwTypeCode, String currentPendingStatusCode) {
		return baseWorkflowHelperRepository.isFinalApproval(appOrWkflwTypeCode, currentPendingStatusCode);
	}

	/**
	 * Cascade the reconfiguration of workflow to all existing PENDING workflows or applications of the same type. If current step becomes the highest level, route down for re-approval so as to
	 * trigger approval logic once it is re-approved (There must always be at least 1 st[p for such cases). Else, route up for next level approval.
	 */
	public void cascadeConfig(List<Application> applications, List<Workflow> workflows, String statusCode, User assignee) {

		if (CollectionUtils.isNotEmpty(applications)) {
			for (Application app : applications) {
				saveAction(null, app, statusCode, null, null, getRecommendationCode(null, app), null, null, Codes.WorkflowActionTypes.WORKFLOW_UPDATE, getCurrentRole(), assignee);
			}
		} else if (CollectionUtils.isNotEmpty(workflows)) {
			for (Workflow wkflw : workflows) {
				saveAction(wkflw, null, statusCode, null, null, getRecommendationCode(wkflw, null), null, null, Codes.WorkflowActionTypes.WORKFLOW_UPDATE, getCurrentRole(), assignee);
			}
		}
	}

	protected WorkflowConfig getWorkflowConfig(Workflow workflow, Application app) {
		validateParameters(workflow, app);
		WorkflowConfig workflowConfig = baseWorkflowHelperRepository.getWorkflowConfig((workflow != null ? workflow.getType().getCode() : app.getType().getCode()));
		if (workflowConfig != null) {
			return workflowConfig;
		} else {
			logger.error(ERR_WORKFLOW_TYPE_NOT_FOUND);
			throw new ValidationException(ERR_WORKFLOW_TYPE_NOT_FOUND);
		}
	}

	protected Boolean toSaveFirstStepAction(Workflow workflow, Application app) {
		validateParameters(workflow, app);
		if (workflow != null) {

			// for C&E, officer allowed to submit approved workflow case for approval again, eg: TA/TG scheduling
			if (isCeCategory(workflow)) {
				if (workflow.getLastAction() == null) {
					return true;
				} else {
					return StringUtils.equalsAny(workflow.getLastAction().getStatus().getCode(), Codes.Statuses.CE_WKFLW_APPR, Codes.Statuses.CE_WKFLW_ROUTED);
				}
			}

			return (workflow.getLastAction() == null); // return true if workflow has no last action (i.e. new case)
		} else {
			if (app.getLastAction() == null) {
				return true; // return true if application has no last action (i.e. new application)
			} else {
				if (app.getTaTgType().equals(Codes.TaTgType.TA)) {
					return (app.getLastAction().getStatus().getCode().equals(Codes.Statuses.TA_APP_RFA)); // return true if app is RFA
				} else {
					return (app.getLastAction().getStatus().getCode().equals(Codes.Statuses.TG_APP_RFA)); // return true if app is RFA
				}
			}
		}
	}

	private WorkflowAction saveFirstStepAction(Workflow workflow, Application app, boolean isSubmit, WorkflowConfig workflowConfig, String internalRemarks, String recommendationCode,
			boolean followStepAssignment, List<MultipartFile> files, List<String> fileDescs) {
		validateParameters(workflow, app);
		if (workflowConfig.getWorkflowSteps().isEmpty()) {
			if (workflowConfig.isConfigurable()) {
				throw new ValidationException("Configurable workflows must have at least one workflow step configured.");
			} else {
				// special logic for TA to use "Completed" for non-configurable application
				return autoApprove(workflow, app, isSubmit, recommendationCode, null);
			}
		} else {
			// get the first step as list is ordered by default
			return saveAction(workflow, app, followStepAssignment ? getStatusByStepAssignment(workflow) : getDefaultStatus(workflow, app, workflowConfig, isSubmit), internalRemarks, null,
					recommendationCode, files, fileDescs, isSubmit ? Codes.WorkflowActionTypes.SUBMIT : Codes.WorkflowActionTypes.FORWARD, getCurrentRole());
		}
	}

	protected WorkflowAction autoApprove(Workflow workflow, Application app, boolean isSubmit, String recommendationCode, String internalRemark) {
		String approvedStatusCode = (app != null && app.getTaTgType().equals(Codes.TaTgType.TA)) ? Codes.Statuses.TA_APP_COMPLETED : getApprovedStatusCode(workflow, app);
		return saveAction(workflow, app, approvedStatusCode, internalRemark, null, recommendationCode, null, null, isSubmit ? Codes.WorkflowActionTypes.SUBMIT : Codes.WorkflowActionTypes.APPROVE,
				getCurrentRole());
	}

	protected WorkflowAction autoReject(Workflow workflow, Application app, boolean isSubmit, String recommendationCode, String internalRemark, String externalRemark) {
		String rejectedStatusCode = getRejectedStatusCode(workflow, app);
		return saveAction(workflow, app, rejectedStatusCode, internalRemark, externalRemark, recommendationCode, null, null,
				isSubmit ? Codes.WorkflowActionTypes.SUBMIT : Codes.WorkflowActionTypes.REJECT, getCurrentRole());
	}

	private WorkflowStep getCurrentStep(Workflow workflow, Application app, WorkflowConfig workflowConfig) {
		validateParameters(workflow, app);
		if (workflow != null && workflow.getLastAction() != null) {
			return getStepByStatusCode(workflow.getLastAction().getStatus().getCode(), workflowConfig);

		} else if (app != null && app.getLastAction() != null) {
			String currentStatus = null;
			if (isRfaApplication(app.getLastAction().getStatus().getCode())) {
				if (workflowConfig.getWorkflowSteps() == null) {
					logger.error(ERR_CURRENT_STEP_NOT_FOUND);
					throw new ValidationException(ERR_CURRENT_STEP_NOT_FOUND);
				}
				currentStatus = workflowConfig.getWorkflowSteps().get(0).getStartStatus().getCode();
			} else {
				currentStatus = app.getLastAction().getStatus().getCode();
			}
			return getStepByStatusCode(currentStatus, workflowConfig);

		} else {
			logger.error(ERR_LAST_ACTION_MISSING);
			throw new ValidationException(ERR_LAST_ACTION_MISSING);
		}
	}

	private WorkflowStep getStepByStatusCode(String statusCode, WorkflowConfig workflowConfig) {
		Optional<WorkflowStep> workflowStep = workflowConfig.getWorkflowSteps().stream().filter(step -> Entities.equals(step.getStartStatus(), statusCode)).findFirst();
		if (workflowStep.isPresent()) {
			return workflowStep.get();
		} else {
			logger.error(ERR_CURRENT_STEP_NOT_FOUND);
			throw new ValidationException(ERR_CURRENT_STEP_NOT_FOUND);
		}
	}

	protected String getDefaultStatus(Workflow workflow, Application app, WorkflowConfig workflowConfig, boolean isSubmit) {
		if (app != null && app.getLastAction() != null) {
			if (isRfaApplication(app.getLastAction().getStatus().getCode()) && !isSubmit) {
				return workflowConfig.getWorkflowSteps().get(1).getStartStatus().getCode();
			}
		}
		if (isSubmit && (workflow != null && workflow.getLastAction() == null)
				&& (workflowConfig != null && workflowConfig.getWorkflowSteps().get(0).getType().getCode().equalsIgnoreCase("WKFLW_STEP_TA")
						&& !workflowConfig.getAppOrWkflwType().getCode().equalsIgnoreCase(Codes.Workflow.TA_WKFLW_SHORTFALL))) {
			return workflowConfig.getWorkflowSteps().get(1).getStartStatus().getCode();
		}
		return workflowConfig.getWorkflowSteps().get(0).getStartStatus().getCode();
	}

	protected String getStatusByStepAssignment(Workflow workflow) {
		List<WorkflowStepAssignment> workflowStepAssignments = workflow.getWorkflowStepAssignments();
		return workflowStepAssignments.get(0).getWorkflowStep().getStartStatus().getCode();
	}

	protected String getApprovedStatusCode(Workflow workflow, Application app) {
		validateParameters(workflow, app);
		if (workflow != null) {
			if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.TA)) {
				return Codes.Statuses.TA_WKFLW_APPROVED;
			} else if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.TG)) {
				return Codes.Statuses.TG_WKFLW_APPROVED;
			} else if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.PAY)) {
				return Codes.Statuses.PAY_WKFLW_APPR;
			} else {
				return Codes.Statuses.CE_WKFLW_APPR;
			}
		} else {
			if (app.getTaTgType().equals(Codes.TaTgType.TA)) {
				return Codes.Statuses.TA_APP_APPROVED;
			} else {
				return Codes.Statuses.TG_APP_APPROVED;
			}
		}
	}

	protected String getCompletedStatusCode(Workflow workflow, Application app) {
		validateParameters(workflow, app);
		if (workflow != null) {
			if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.TA)) {
				return Codes.Statuses.TA_WKFLW_APPROVED;
			} else if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.TG)) {
				return Codes.Statuses.TG_WKFLW_APPROVED;
			} else if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.PAY)) {
				return Codes.Statuses.PAY_WKFLW_APPR;
			} else {
				return Codes.Statuses.CE_WKFLW_APPR;
			}
		} else {
			if (app.getTaTgType().equals(Codes.TaTgType.TA)) {
				return Codes.Statuses.TA_APP_COMPLETED;
			} else {
				return Codes.Statuses.TG_APP_APPROVED;
			}
		}
	}

	protected String getRejectedStatusCode(Workflow workflow, Application app) {
		validateParameters(workflow, app);
		if (workflow != null) {
			if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.TA)) {
				return Codes.Statuses.TA_WKFLW_REJECTED;
			} else if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.TG)) {
				return Codes.Statuses.TG_WKFLW_REJECTED;
			} else if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.PAY)) {
				return Codes.Statuses.PAY_WKFLW_REJ;
			} else {
				return Codes.Statuses.CE_WKFLW_REJ;
			}
		} else {
			if (app.getTaTgType().equals(Codes.TaTgType.TA)) {
				return Codes.Statuses.TA_APP_REJECTED;
			} else {
				return Codes.Statuses.TG_APP_REJECTED;
			}
		}
	}

	private String getRecommendationCode(Workflow workflow, Application app) {
		if (workflow != null) {
			return (workflow.getLastAction() != null && workflow.getLastAction().getRecommendation() != null) ? workflow.getLastAction().getRecommendation().getCode() : null;
		} else {
			return (app.getLastAction() != null && app.getLastAction().getRecommendation() != null) ? app.getLastAction().getRecommendation().getCode() : null;
		}
	}

	private String getStatusCode(Workflow workflow, Application app) {
		if (workflow != null) {
			return (workflow.getLastAction() != null && workflow.getLastAction().getStatus() != null) ? workflow.getLastAction().getStatus().getCode() : null;
		} else {
			return (app.getLastAction() != null && app.getLastAction().getStatus() != null) ? app.getLastAction().getStatus().getCode() : null;
		}
	}

	protected void validateParameters(Workflow workflow, Application app) {
		if ((workflow == null && app == null) || (workflow != null && app != null)) {
			logger.error(ERR_INVALID_PARAMS);
			throw new ValidationException(ERR_INVALID_PARAMS);
		}
	}

	protected Role validateRole(WorkflowStep currentStep) {
		Role currentRole = getCurrentRole();
		if (Codes.WorkflowStep.WKFLW_STEP_CE.equals(currentStep.getType().getCode()) || Codes.WorkflowStep.WKFLW_STEP_PAY.equals(currentStep.getType().getCode())) {
			Set<Role> roles = currentStep.getRoles();
			if (CollectionUtils.isEmpty(roles) || roles.stream().filter(u -> Entities.equals(u, currentRole)).findAny().isEmpty()) {
				logger.error(ERR_NOT_TASKED_YET + currentStep.getStartStatus());
				throw new ValidationException(ERR_NOT_TASKED_YET + currentStep.getStartStatus());
			}
		} else {
			if (!Entities.equals(currentStep.getRole(), currentRole)) {
				logger.error(ERR_NOT_TASKED_YET + currentStep.getStartStatus());
				throw new ValidationException(ERR_NOT_TASKED_YET + currentStep.getStartStatus());
			}
		}

		return currentRole;
	}

	protected Role getCurrentRole() {
		CustomAuthenticationToken authentication = (CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null) {
			return null;
		}
		return cache.getRole(authentication.getRoleCode());
	}

	protected User getUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null) {
			return null;
		}
		return (User) authentication.getPrincipal();
	}

	protected User setAssignOfficer(Workflow workflow, Application app, String actionTypeCode, String statusCode, User assignee) {

		if (!StringUtils.equalsAny(actionTypeCode, Codes.WorkflowActionTypes.ADD_NOTE, Codes.WorkflowActionTypes.EDIT, Codes.WorkflowActionTypes.REJECT, Codes.WorkflowActionTypes.APPROVE,
				Codes.WorkflowActionTypes.FOLLOW_UP)) {

			if (workflow != null) {
				// TA Logic: assign default officer based on alphabets for workflow that targets a single TA licence only
				if (workflow.getCategoryType().equals(Codes.WorkflowCategoryType.TA)) {
					workflow.setAssignee(assignee != null ? assignee : getAssignTaOfficer(workflow, statusCode, actionTypeCode));
					if (workflow.getAssignee() == null && workflow.getType().getCode().equalsIgnoreCase(Codes.Workflow.TA_WKFLW_RENEW_EX)) {
						workflow.setAssignee(assignee != null ? assignee : getDefaultAssignTaOfficer(workflow.getType().getCode(), statusCode));
					}
				} else if (isCeCategory(workflow) || isPayCategory(workflow)) {
					if (assignee != null) {
						workflow.setAssignee(assignee);
					} else {
						List<WorkflowStepAssignment> workflowStepAssignments = workflow.getWorkflowStepAssignments();

						if (CollectionUtils.isEmpty(workflowStepAssignments)) {
							logger.error(ERR_WORKFLOW_STEP_CONFIG_NOT_FOUND);
							throw new ValidationException(ERR_WORKFLOW_STEP_CONFIG_NOT_FOUND);
						}

						Optional<WorkflowStepAssignment> workflowStepAssignmentOptional = workflowStepAssignments.stream()
								.filter(u -> u.getWorkflowStep().getStartStatus().getCode().equals(statusCode)).findFirst();

						if (workflowStepAssignmentOptional.isEmpty()) {
							logger.error(ERR_CURRENT_STEP_ASSIGNMENT_NOT_FOUND);
							throw new ValidationException(ERR_CURRENT_STEP_ASSIGNMENT_NOT_FOUND);
						}

						WorkflowStepAssignment workflowStepAssignment = workflowStepAssignmentOptional.get();
						workflow.setAssignee(workflowStepAssignment.getUser());
					}

				}
				checkIfOperatingAddressIsempty(app, actionTypeCode, statusCode);
				return workflow.getAssignee();
			} else {
				if (app.getTaTgType().equals(Codes.TaTgType.TA)) {
					// TA Logic: assign default officer based on alphabets for workflow that targets a single TA licence only
					app.setAssignee(assignee != null ? assignee : getAssignTaOfficer(app, statusCode, actionTypeCode));

				} else {
					// do not overwrite app assignee for previously followed up app
					if (app.getLastAction() == null || (app.getLastAction() != null && !StringUtils.equals(app.getLastAction().getType().getCode(), Codes.WorkflowActionTypes.FOLLOW_UP))) {
						app.setAssignee(assignee != null ? assignee : getAssignTgOfficer(app.getType().getCode(), statusCode));
					}
				}

				checkIfOperatingAddressIsempty(app, actionTypeCode, statusCode);
				return app.getAssignee();
			}
		}

		checkIfOperatingAddressIsempty(app, actionTypeCode, statusCode);

		return null;
	}

	protected void checkIfOperatingAddressIsempty(Application app, String actionTypeCode, String type) {

		// check if workflow is currently the last workflow
		if (actionTypeCode.equalsIgnoreCase(Codes.WorkflowActionTypes.APPROVE) && type.equalsIgnoreCase(Codes.Statuses.TA_APP_PENDING_OA)) {
			if (app != null && app.getLastAction() != null && app.getWorkflowActions() != null && app.getWorkflowActions().size() > 0) {

				WorkflowAction[] myArray = new WorkflowAction[app.getWorkflowActions().size()];
				app.getWorkflowActions().toArray(myArray);
				String lastWorkFlow = "";
				if (myArray[0].getPrevStatus() != null && myArray[0].getPrevStatus().getCode() != null) {
					lastWorkFlow = myArray[0].getPrevStatus().getCode();
				}

				int max = myArray[0].getId();
				for (int i = 0; i < myArray.length; i++) {
					if (myArray[i].getId() > max) {
						max = myArray[i].getId();
						lastWorkFlow = myArray[i].getPrevStatus().getCode();
					}
				}
				if (app.getLastAction().getStatus().getCode().equalsIgnoreCase(lastWorkFlow)) {
					TaLicenceCreation ta = taCommonRepository.getApplication(app.getId());
					if (ta.getOperatingAddress().getPostal() == null || ta.getOperatingAddress().getPostal().equals("")) {
						app.setAssignee(null);
					}
				}
			}
		}

	}

	protected User getAssignTaOfficer(Object appOrWorkflow, String statusCode, String actionTypeCode) {

		String appCaseType = null;
		String taCompanyName = null;
		Application app = null;
		Workflow workflow = null;
		Licence licence = null;
		if (appOrWorkflow instanceof Application) {
			app = (Application) appOrWorkflow;
			appCaseType = app.getType().getCode();
			licence = app.getLicence();
		} else {
			workflow = (Workflow) appOrWorkflow;
			appCaseType = workflow.getType().getCode();
			licence = workflow.getLicence();
		}

		if (licence != null) {
			taCompanyName = licence.getTravelAgent().getName();
		} else if (Codes.ApplicationTypes.TA_APP_CREATION.equals(appCaseType) || Codes.ApplicationTypes.TA_APP_CREATION_IPA.equals(appCaseType)) {
			TaLicenceCreation tlc = applicationHelperRepository.getApplicationByClass(app.getId(), TaLicenceCreation.class);
			taCompanyName = tlc.getCompanyName();
		}

		if (checkAssigneeRequired(appCaseType, taCompanyName, actionTypeCode)) {
			List<User> taOfficers = baseWorkflowHelperRepository.getOfficersByStatusCode(statusCode);
			if (CollectionUtils.isNotEmpty(taOfficers) && !Strings.isNullOrEmpty(taCompanyName)) {
				logger.info("taOfficers size {}", taOfficers.size());
				taCompanyName = taCompanyName.trim().replaceAll("[^a-zA-Z0-9]", "");

				User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				User assignee = null;
				for (User officer : taOfficers) {
					if (!user.getLoginId().equalsIgnoreCase(officer.getLoginId())) {
						assignee = getAssigneeByChar(officer, taCompanyName);
						if (assignee != null) {
							return assignee;
						}
					}
				}
			}
		}

		return null;
	}

	public User getAssigneeByChar(String roleCode, String taCompanyName) {
		List<User> users = userCommonRepository.getActiveUsersByRole(roleCode);
		for (User officer : users) {
			if (getAssigneeByChar(officer, taCompanyName) != null) {
				return officer;
			}
		}
		return null;
	}

	public User getAssigneeByChar(User officer, String taCompanyName) {
		if (!Strings.isNullOrEmpty(officer.getTaAssigneeChars())) {
			if (taCompanyName == null) {
				return officer;
			}
			List<String> chars = Arrays.asList(officer.getTaAssigneeChars().split(" "));
			if (chars.contains(String.valueOf(taCompanyName.charAt(0)).toUpperCase())) {
				return officer;
			}
		}

		return null;
	}

	private boolean checkAssigneeRequired(String appCaseType, String taOrCoyName, String actionTypeCode) {
		logger.info("checkAssigneeRequired, appCaseType={}, taCompanyName={}, actionTypeCode={}", appCaseType, taOrCoyName, actionTypeCode);
		return (appCaseType.startsWith(Codes.TypeCategories.TA_APPLICATION_TYPE) || appCaseType.startsWith(Codes.TypeCategories.TA_WORKFLOW)) && !StringUtils.isBlank(taOrCoyName) && (StringUtils
				.equalsAny(actionTypeCode, Codes.WorkflowActionTypes.SUBMIT, Codes.WorkflowActionTypes.FORWARD, Codes.WorkflowActionTypes.ROUTE, Codes.WorkflowActionTypes.WORKFLOW_UPDATE));
	}

	private boolean isRfaApplication(String lastActionStatusCode) {
		return lastActionStatusCode.equals(Codes.Statuses.TA_APP_RFA) || lastActionStatusCode.equals(Codes.Statuses.TG_APP_RFA);
	}

	// assigned officer for TG Application is based on the workflow config
	private User getAssignTgOfficer(String appCaseType, String statusCode) {
		WorkflowStepAssignment wsa = baseWorkflowHelperRepository.getWorkflowStepAssignmentByAppTypeAndStatusCode(appCaseType, statusCode);
		return wsa != null ? wsa.getUser() : null;
	}

	// assigned officer for TA workflow based on the workflow config
	private User getDefaultAssignTaOfficer(String workflowType, String statusCode) {
		WorkflowStepAssignment wsa = baseWorkflowHelperRepository.getWorkflowStepAssignmentByAppTypeAndStatusCode(workflowType, statusCode);
		return wsa != null ? wsa.getUser() : null;
	}

	public Boolean isInLowestStep(Workflow workflow, Application app) {

		String appWorkflowType = null;
		String currentStatus = null;
		if (workflow != null && workflow.getLastAction() != null) {
			appWorkflowType = workflow.getType().getCode();
			currentStatus = workflow.getLastAction().getStatus().getCode();
		} else if (app != null && app.getLastAction() != null) {
			appWorkflowType = app.getType().getCode();
			currentStatus = app.getLastAction().getStatus().getCode();
		}

		if (appWorkflowType != null && currentStatus != null) {
			List<WorkflowStepAssignment> wsaList = baseWorkflowHelperRepository.getWorkflowStepAssignmentsByAppTypeAndCurrentLevel(appWorkflowType, null);

			WorkflowStepAssignment currentWsa = baseWorkflowHelperRepository.getWorkflowStepAssignmentByAppTypeAndStatusCode(appWorkflowType, currentStatus);
			if (CollectionUtils.isNotEmpty(wsaList) && currentWsa != null) {
				WorkflowStepAssignment firstWsa = wsaList.get(0);

				if (currentWsa.getWorkflowStep().getLevel() == firstWsa.getWorkflowStep().getLevel()) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Checks if the current officer's role is in the first workflow step
	 */
	public boolean isAllowedRoleInFirstStep(String workflowType) {
		List<WorkflowStepAssignment> workflowStepAssignments = baseWorkflowHelperRepository.getWorkflowStepAssignmentsByWkflwType(workflowType);
		if (CollectionUtils.isNotEmpty(workflowStepAssignments)) {
			List<WorkflowStep> workflowSteps = workflowStepAssignments.stream().map(WorkflowStepAssignment::getWorkflowStep).collect(Collectors.toList());

			if (CollectionUtils.isNotEmpty(workflowSteps)) {
				workflowSteps.stream().sorted(Comparator.comparing(WorkflowStep::getId));
				WorkflowStep firstStep = workflowSteps.get(0);

				return firstStep.getRole().equals(getCurrentRole());
			}
		}

		return false;
	}

	/**
	 * Checks if the current officer is the same officer for previous action which is edit action
	 */
	protected void checkIfEditActionIsSameOfficer(Workflow workflow, Application app) {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (workflow != null) {
			if (workflow.getLastAction() != null && Entities.equals(workflow.getLastAction().getType(), Codes.WorkflowActionTypes.EDIT)) {
				if (workflow.getLastAction().getCreatedBy().equals(user.getLoginId())) {
					throw new ValidationException(ERR_EDITOR_CANNOT_BE_APPROVER);
				}
			}
		} else {
			if (app.getLastAction() != null && Entities.equals(app.getLastAction().getType(), Codes.WorkflowActionTypes.EDIT)) {
				if (app.getLastAction().getCreatedBy().equals(user.getLoginId())) {
					throw new ValidationException(ERR_EDITOR_CANNOT_BE_APPROVER);
				}
			}
		}
	}

	protected Workflow saveOrUpdateStepAssignment(Workflow workflow, WorkflowConfig workflowConfig, Integer supporterId, Integer approverId) {

		if (workflow != null) {
			if (workflowConfig == null) {
				workflowConfig = getWorkflowConfig(workflow, null);
			}

			List<WorkflowStepAssignment> updatedStepAssignments = new ArrayList<>();
			List<WorkflowStepAssignment> workflowStepAssignments = workflow.getWorkflowStepAssignments();

			if (Entities.equals(workflow.getType().getCategory(), Codes.TypeCategories.CE_WORKFLOW)) {
				if (CollectionUtils.isNotEmpty(workflowStepAssignments)) {
					WorkflowStepAssignment suppWsa = updateStepAssignment(supporterId, workflowStepAssignments, workflow, workflowConfig, Codes.Statuses.CE_WKFLW_PEND_SUPP);
					if (suppWsa != null) {
						updatedStepAssignments.add(suppWsa);
					}

					WorkflowStepAssignment appWsa = updateStepAssignment(approverId, workflowStepAssignments, workflow, workflowConfig, Codes.Statuses.CE_WKFLW_PEND_APPR);
					if (appWsa != null) {
						updatedStepAssignments.add(appWsa);
					}
				} else {
					workflowStepAssignments = new ArrayList<WorkflowStepAssignment>();

					WorkflowStepAssignment supportWorkflowStepAssignment = saveStepAssignment(supporterId, workflow, workflowConfig, Codes.Statuses.CE_WKFLW_PEND_SUPP);
					if (supportWorkflowStepAssignment != null) {
						updatedStepAssignments.add(supportWorkflowStepAssignment);
					}

					WorkflowStepAssignment approvalWorkflowStepAssignment = saveStepAssignment(approverId, workflow, workflowConfig, Codes.Statuses.CE_WKFLW_PEND_APPR);
					if (approvalWorkflowStepAssignment != null) {
						updatedStepAssignments.add(approvalWorkflowStepAssignment);
					}
				}
			} else if (Entities.equals(workflow.getType().getCategory(), Codes.TypeCategories.PAY_WORKFLOW)) {
				if (CollectionUtils.isNotEmpty(workflowStepAssignments)) {
					WorkflowStepAssignment appWsa = updateStepAssignment(approverId, workflowStepAssignments, workflow, workflowConfig, Codes.Statuses.PAY_WKFLW_PEND_APPR);
					if (appWsa != null) {
						updatedStepAssignments.add(appWsa);
					}
				} else {
					workflowStepAssignments = new ArrayList<WorkflowStepAssignment>();
					WorkflowStepAssignment approvalWorkflowStepAssignment = saveStepAssignment(approverId, workflow, workflowConfig, Codes.Statuses.PAY_WKFLW_PEND_APPR);
					if (approvalWorkflowStepAssignment != null) {
						updatedStepAssignments.add(approvalWorkflowStepAssignment);
					}
				}
			}

			workflow.setWorkflowStepAssignments(updatedStepAssignments);
		}

		return workflow;
	}

	private WorkflowStepAssignment updateStepAssignment(Integer userId, List<WorkflowStepAssignment> workflowStepAssignments, Workflow workflow, WorkflowConfig workflowConfig, String statusCode) {
		Optional<WorkflowStepAssignment> workflowStepAssignmentOptional = workflowStepAssignments.stream().filter(u -> u.getWorkflowStep().getStartStatus().getCode().equals(statusCode)).findAny();
		if (userId != null) {
			if (workflowStepAssignmentOptional.isPresent()) {
				WorkflowStepAssignment workflowStepAssignment = workflowStepAssignmentOptional.get();
				workflowStepAssignment.setUser(userCommonRepository.get(User.class, userId));
				baseWorkflowHelperRepository.saveOrUpdate(workflowStepAssignment);
				return workflowStepAssignment;
			} else {
				return saveStepAssignment(userId, workflow, workflowConfig, statusCode);
			}
		} else {
			if (workflowStepAssignmentOptional.isPresent()) {
				WorkflowStepAssignment workflowStepAssignment = workflowStepAssignmentOptional.get();
				baseWorkflowHelperRepository.delete(workflowStepAssignment);
			}
		}

		return null;
	}

	private WorkflowStepAssignment saveStepAssignment(Integer userId, Workflow workflow, WorkflowConfig workflowConfig, String statusCode) {
		if (userId != null) {
			WorkflowStepAssignment workflowStepAssignment = new WorkflowStepAssignment();
			workflowStepAssignment.setUser(userCommonRepository.get(User.class, userId));
			workflowStepAssignment.setWorkflow(workflow);
			workflowStepAssignment.setWorkflowConfig(workflowConfig);
			workflowStepAssignment.setWorkflowStep(getStepByStatusCode(statusCode, workflowConfig));
			baseWorkflowHelperRepository.save(workflowStepAssignment);

			return workflowStepAssignment;
		}

		return null;
	}

	private boolean isCeCategory(Workflow workflow) {
		return Codes.WorkflowCategoryType.CE.equals(workflow.getCategoryType());
	}

	private boolean isPayCategory(Workflow workflow) {
		return Codes.WorkflowCategoryType.PAY.equals(workflow.getCategoryType());
	}
}
