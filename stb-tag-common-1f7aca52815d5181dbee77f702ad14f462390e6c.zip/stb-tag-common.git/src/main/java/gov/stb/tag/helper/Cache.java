package gov.stb.tag.helper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.wiz.model.api.Listable;

import gov.stb.tag.model.Function;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.CacheRepository;

/**
 * This class caches the filtered list from CacheRepository's cached map of records so that filtering is done only during the first call for each grouping code. Methods that return single entity do
 * not need to be cached as it is retrieved via the map's key, which is fast enough. Convenient business-related helper methods is available in the CacheHelper class.
 */
@Component
@Transactional
public class Cache {

	@Autowired
	private CacheRepository cacheRepository;

	@Autowired
	private CacheManager cacheManager;

	public void clearCache() {
		cacheManager.getCacheNames().stream().forEach(name -> {
			cacheManager.getCache(name).clear();
		});
	}

	public Type getType(String code) {
		return cacheRepository.getAllTypes().get(code);
	}

	public Set<Type> getTypes(List<String> codes) {
		Set<Type> types = new HashSet<Type>();

		for (String code : codes) {
			types.add(cacheRepository.getAllTypes().get(code));
		}

		return types;
	}

	public Set<Type> getTypes(Object[] codes) {
		Set<Type> types = new HashSet<Type>();

		for (Object code : codes) {
			types.add(cacheRepository.getAllTypes().get(code));
		}

		return types;
	}

	public TaKeClause getTaKeClause(Integer id) {
		return cacheRepository.getAllTaKeClause().get(id);
	}

	public String getLabel(Type type, boolean toUseOtherLabel) {
		return type == null ? null : getListableLabel(getType(type.getCode()), toUseOtherLabel);
	}

	@Cacheable("types")
	public List<Type> getTypesByCategory(String categoryCode) {
		return cacheRepository.getAllTypes().values().stream().filter(o -> Entities.equals(o.getCategory(), categoryCode) && o.isActive()).collect(Collectors.toList());
	}

	@Cacheable("types")
	public List<Type> getTypesByCategory(String... categoryCodes) {
		return cacheRepository.getAllTypes().values().stream().filter(o -> {
			Boolean isCategory = false;
			for (String categoryCode : categoryCodes) {
				isCategory = isCategory || Entities.equals(o.getCategory(), categoryCode);
			}
			return isCategory && o.isActive();
		}).collect(Collectors.toList());
	}

	@Cacheable("typesOrderLabel")
	public List<Type> getTypesByCategoryOrderLabel(String categoryCode) {
		return cacheRepository.getAllTypesOrderByLabel().values().stream().filter(o -> Entities.equals(o.getCategory(), categoryCode) && o.isActive()).collect(Collectors.toList());
	}

	@Cacheable("allTypesOrderLabel")
	public List<Type> getAllTypesByCategoryOrderLabel(String categoryCode) {
		return cacheRepository.getAllTypesOrderByLabel().values().stream().filter(o -> Entities.equals(o.getCategory(), categoryCode)).collect(Collectors.toList());
	}

	public List<Type> getAllTypesByCategory(String categoryCode) {
		return cacheRepository.getAllTypes().values().stream().filter(o -> Entities.equals(o.getCategory(), categoryCode)).collect(Collectors.toList());
	}

	@Cacheable("typesByParentCategory")
	public List<Type> getTypesByParentCategory(String parentCategoryCode) {
		return cacheRepository.getAllTypes().values().stream().filter(o -> o.getCategory() != null && Entities.equals(o.getCategory().getCategory(), parentCategoryCode) && o.isActive())
				.collect(Collectors.toList());
	}

	public Status getStatus(String code) {
		return cacheRepository.getAllStatuses().get(code);
	}

	public String getLabel(Status status, boolean toUseOtherLabel) {
		return status == null ? null : getListableLabel(getStatus(status.getCode()), toUseOtherLabel);
	}

	@Cacheable("statuses")
	public List<Status> getStatusesByCategory(String categoryCode) {
		return cacheRepository.getAllStatuses().values().stream().filter(o -> Entities.equals(o.getCategory(), categoryCode) && o.isActive()).collect(Collectors.toList());
	}

	public SystemParameter getSystemParameter(String code) {
		return cacheRepository.getAllSystemParameters().get(code);
	}

	@Cacheable("systemParameters")
	public List<SystemParameter> getSystemParameters() {
		return cacheRepository.getAllSystemParameters().values().stream().collect(Collectors.toList());
	}

	@Cacheable("taKeClauses")
	public List<TaKeClause> getTaKeClauses() {
		return cacheRepository.getAllTaKeClause().values().stream().filter(o -> o.isActive()).collect(Collectors.toList());
	}

	@Cacheable("taKeClausesForRenewal")
	public List<TaKeClause> getTaKeClausesForRenewal() {
		return cacheRepository.getAllTaKeClauseForRenewal().values().stream().filter(o -> o.isActive()).collect(Collectors.toList());
	}

	public Function getFunction(String code) {
		return cacheRepository.getAllFunctions().get(code);
	}

	public String getLabel(Function function, boolean toUseOtherLabel) {
		return function == null ? null : getListableLabel(getFunction(function.getCode()), toUseOtherLabel);
	}

	@Cacheable("functions")
	public List<Function> getFunctions() {
		return cacheRepository.getAllFunctions().values().stream().collect(Collectors.toList());
	}

	@Cacheable("functions")
	public List<Function> getFunctionsByModule(String moduleCode) {
		return cacheRepository.getAllFunctions().values().stream().filter(o -> Entities.equals(o.getModule(), moduleCode)).collect(Collectors.toList());
	}

	public Role getRole(String code) {
		return cacheRepository.getAllRoles().get(code);
	}

	public String getLabel(Role role, boolean toUseOtherLabel) {
		return role == null ? null : getListableLabel(getRole(role.getCode()), toUseOtherLabel);
	}

	@Cacheable("roles")
	public List<Role> getRoles() {
		return cacheRepository.getAllRoles().values().stream().collect(Collectors.toList());
	}

	@Cacheable("functions")
	public List<Function> getModFunction(String module) {
		return cacheRepository.getModFunctions(module).values().stream().collect(Collectors.toList());
	}

	@Cacheable("types")
	public List<Type> getFormListByKey(String key) {
		return cacheRepository.getAllTypes().values().stream().filter(o -> o.getCode().equals(key)).collect(Collectors.toList());
	}

	@Cacheable("statuses")
	public List<Status> getFormStatusListByKey(String key) {
		return cacheRepository.getAllStatuses().values().stream().filter(o -> o.getCode().equals(key)).collect(Collectors.toList());
	}

	private String getListableLabel(Listable listable, boolean toUseOtherLabel) {
		if (listable != null) {
			if (toUseOtherLabel && listable.getOtherLabel() != null) {
				return listable.getOtherLabel();
			} else {
				return listable.getLabel();
			}
		}
		return null;
	}

	public Integer getSystemParameterAsInteger(String code) {
		return Integer.parseInt(getSystemParameter(code).getValue());
	}

	public String getSystemParameterAsString(String code) {
		return getSystemParameter(code).getValue();
	}
}
