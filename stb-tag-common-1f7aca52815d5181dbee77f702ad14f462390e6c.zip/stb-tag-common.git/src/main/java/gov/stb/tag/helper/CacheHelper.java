package gov.stb.tag.helper;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.Type;

/**
 * This is a helper class that is built on top of the cache classes (i.e. Cache and CacheRepository) to provide convenient cacheable method calls. We cannot put these convenient methods in the same
 * Cache class because of how Spring Cache intercepts @Cacheable methods. We need to inject an instance of the Cache class instead.
 */
@Component
@Transactional
public class CacheHelper extends Cache {

	@Autowired
	private Cache cache;

	public List<Type> getTypes(String categoryCode) {
		return cache.getTypesByCategory(categoryCode);
	}

	public List<Type> getAddressTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.ADDRESS_TYPE);
	}

	public List<Type> getCountries() {
		return cache.getTypesByCategory(Codes.TypeCategories.COUNTRY);
	}

	public List<Type> getMaritalStatuses() {
		return cache.getTypesByCategory(Codes.TypeCategories.MARITAL_STATUS);
	}

	public List<Type> getNationalities() {
		return cache.getTypesByCategory(Codes.TypeCategories.NATIONALITY);
	}

	public List<Type> getPaymentTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.PAYMENT);
	}

	public List<Type> getPaymentRequestTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.PAYMENT_REQUEST);
	}

	public List<Type> getPremiseTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE);
	}

	public List<Type> getRaces() {
		return cache.getTypesByCategory(Codes.TypeCategories.RACE);
	}

	public List<Type> getPrincipleActivities() {
		return cache.getTypesByCategory(Codes.TypeCategories.PRINCIPLE_ACTIVITIES);
	}

	public List<Type> getFormOfBusiness() {
		return cache.getTypesByCategory(Codes.TypeCategories.FORM_OF_BUSINESS);
	}

	public List<Type> getBusinessConstitution() {
		return cache.getTypesByCategory(Codes.TypeCategories.BUSINESS_CONSTITUTION);
	}

	public List<Type> getQualifications() {
		return cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_QUALIFICATIONS);
	}

	public List<Type> getOccupations() {
		return cache.getTypesByCategory(Codes.TypeCategories.OCCUPATIONS);
	}

	public List<Type> getStakeholderRoles() {
		return cache.getTypesByCategory(Codes.TypeCategories.STAKEHOLDER_ROLES);
	}

	public List<Type> getResidentialStatuses() {
		return cache.getTypesByCategory(Codes.TypeCategories.RESIDENTIAL_STATUS);
	}

	public List<Type> getEstablishmentStatuses() {
		return cache.getTypesByCategory(Codes.TypeCategories.ESTABLISHMENT_STATUS);
	}

	public List<Type> getSubEstablishmentStatuses(String categoryCode) {
		return cache.getTypesByCategory(categoryCode);
	}

	public List<Type> getSexes() {
		return cache.getTypesByCategory(Codes.TypeCategories.SEX);
	}

	public List<Type> getTgTourTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TOUR);
	}

	public List<Type> getTgEmpSrcTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.EMP_SRC);
	}

	public List<Type> getEducationLevels() {
		return cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_LEVEL);
	}

	public List<Type> getSalutations() {
		return cache.getTypesByCategory(Codes.TypeCategories.SALUTATION);
	}

	public List<Type> getWorkPassTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.WORK_PASS_TYPE);
	}

	public List<Type> getTaApplicationTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_APPLICATION_TYPE);
	}

	public List<Type> getTaKeApplicationTypes() {
		return cache.getTypesByCategory(Codes.ApplicationTypes.TA_APP_KE);
	}

	public List<Type> getTaApprovalModes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_APPROVAL_MODE);
	}

	public List<Type> getTaFocusAreas() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_FOCUS_AREA);
	}

	public List<Type> getTaFunctionActivity() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_FUNCTION_ACTIVITY);
	}

	public List<Type> getTaSegmentations() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_SEGMENTATION);
	}

	public List<Type> getTaServices() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_SERVICE);
	}

	public List<Type> getTaLicenceTiers() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_LICENCE_TIER);
	}

	public List<Type> getTaReasonsForCessation() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_REASON_CESSATION);
	}

	public List<Type> getTaReasonsForReplacement() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_REASON_REPLACEMENT);
	}

	public List<Type> getTaAuditorOpinions() {
		return cache.getTypesByCategory(Codes.TypeCategories.TA_AUDITOR_OPINION);
	}

	public List<Type> getFlags() {
		return cache.getTypesByCategory(Codes.TypeCategories.FLAG);
	}

	public List<Type> getTgApplicationTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_APPLICATION_TYPE);
	}

	public List<Type> getTgSpecialisedAreas() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA);
	}

	public List<Type> getTgCourseTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_COURSE_TYPE);
	}

	public List<Type> getTgDocumentTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_DOCUMENT_TYPE);
	}

	public List<Type> getTgGuidingLanguages() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE);
	}

	public List<Type> getTgDeclaredOffenceTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_DECLARED_OFFENCE_TYPE);
	}

	public List<Type> getTgLicenceTiers() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_LICENCE_TIER);
	}

	public List<Status> getTgCandidateResults() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TG_CANDIDATE_RESULT);
	}

	public List<Type> getTgCandidateItineraries() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_ITINERARY);
	}

	public List<Type> getCourseAttendanceTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TP_ATTENDANCE);
	}

	public List<Type> getTgCourseCategoryTypes() {
		return cache.getTypesByCategory(Codes.TypeCategories.TG_COURSE_CATEGORY);
	}

	public List<Status> getTgMlptResults() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TG_MLPT_RESULT);
	}

	public List<Type> getTaKeAppType() {
		return cache.getTypesByCategory(Codes.ApplicationTypes.TA_APP_KE);
	}

	public List<Status> getStatuses(String categoryCode) {
		return cache.getStatusesByCategory(categoryCode);
	}

	public List<Status> getPaymentRequestStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.PAYMENT_REQUEST);
	}

	public List<Status> getPaymentTxnStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.PAYMENT_TXN);
	}

	public List<Status> getTaApplicationStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TA_APPLICATION);
	}

	public List<Status> getTaLicenceStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TA_LICENCE);
	}

	public List<Status> getTgApplicationStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TG_APPLICATION);
	}

	public List<Status> getTgCourseStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TG_COURSE);
	}

	public List<Status> getTgLicenceStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TG_LICENCE);
	}

	public List<Status> getUserStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.USER);
	}

	public List<Status> getReturnStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.LICENCE_RETURN);
	}

	public List<Status> getPrintStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.PRINT);
	}

	public List<Status> getTaPrintStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TA_PRINT);
	}

	public List<Role> getUserRoles() {
		return cache.getRoles();
	}

	public List<Type> getTypeCodeList() {
		return cache.getTypesByCategory(Codes.TypeCategories.BULLETIN);
	}

	public Type getTypeByLabel(String label, String categoryCode) {
		if (Strings.isNullOrEmpty(label) || Strings.isNullOrEmpty(categoryCode)) {
			return null;
		} else {
			Optional<Type> type = getTypesByCategory(categoryCode).stream().filter(o -> label.equalsIgnoreCase(o.getLabel()) || label.equalsIgnoreCase(o.getOtherLabel())).findFirst();
			return type.isPresent() ? type.get() : null;
		}
	}

	public Status getStatusByLabel(String label, String categoryCode) {
		if (Strings.isNullOrEmpty(label) || Strings.isNullOrEmpty(categoryCode)) {
			return null;
		} else {
			Optional<Status> status = getStatusesByCategory(categoryCode).stream().filter(o -> label.equalsIgnoreCase(o.getLabel()) || label.equalsIgnoreCase(o.getOtherLabel())).findFirst();
			return status.isPresent() ? status.get() : null;
		}
	}

	@Override
	public List<TaKeClause> getTaKeClauses() {
		return cache.getTaKeClauses();
	}

	@Override
	public List<TaKeClause> getTaKeClausesForRenewal() {
		return cache.getTaKeClausesForRenewal();
	}

	public List<Status> getTaWorkflowStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TA_WORKFLOW);
	}

	public List<Status> getTgWorkflowStatuses() {
		return cache.getStatusesByCategory(Codes.StatusCategories.TG_WORKFLOW);
	}
}
