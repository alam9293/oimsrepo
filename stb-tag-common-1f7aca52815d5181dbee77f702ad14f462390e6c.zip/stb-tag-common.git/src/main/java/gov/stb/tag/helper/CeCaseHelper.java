package gov.stb.tag.helper;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.CeTaskTypes;
import gov.stb.tag.constant.Codes.TaTgType;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.CeCaseComplainant;
import gov.stb.tag.model.CeCaseDecision;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTaFieldReport;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.CeTgFieldReport;
import gov.stb.tag.model.CeTgFieldReportTg;
import gov.stb.tag.model.CeTgFieldReportTgInfringement;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFyUpdate;
import gov.stb.tag.model.TaLicenceCessation;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.repository.CeCaseRepository;
import gov.stb.tag.repository.CeProvisionRepository;
import gov.stb.tag.repository.CeTaskRepository;
import gov.stb.tag.repository.PaymentHelperRepository;
import gov.stb.tag.repository.UserCommonRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.NumeralUtil;

@Component
@Transactional
public class CeCaseHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;
	@Autowired
	CeProvisionRepository ceProvisionRepository;
	@Autowired
	CeCaseRepository ceCaseRepository;
	@Autowired
	CeTaskHelper ceTaskHelper;
	@Autowired
	MessageHelper messageHelper;
	@Autowired
	UserCommonRepository userCommonRepository;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	LicenceHelper licenceHelper;
	@Autowired
	PaymentHelperRepository paymentHelperRepository;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	CeTaskRepository ceTaskRepository;

	public void createCaseForNvMfrInfringement(TaNetValueShortfall shortfall) {

		// create task
		CeTask ceTask = ceTaskHelper.createCeTaskForShortfall(shortfall, Messages.CeTaskDetails.R9_SHORTFALL_LATE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
		if (ceTask != null) {
			// create case
			String provisionCode = ceTaskHelper.getMinimumFinancialRequirementProvisionCode(ceTask.getLicence());
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, provisionCode,
					DateUtil.getMaxDate(shortfall.getRectificationDueDate(), shortfall.getExtendedDueDate()).plusDays(1).atStartOfDay());
			shortfall.setTarR9Infringement(ceCaseInfringement);
			ceCaseRepository.save(shortfall);
		}
	}

	public void createCaseForAaAbprInfringement(TaFilingCondition taFilingCondition) {

		// create task
		CeTask ceTask = ceTaskHelper.createCeTaskForAaOrAbpr(taFilingCondition, Messages.CeTaskDetails.R141_FINANCIAL_REQUIREMENT_LATE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
		if (ceTask != null) {
			// create case
			String provisionCode = Entities.equals(taFilingCondition.getApplicationType(), Codes.ApplicationTypes.TA_APP_AA_SUBMISSION) ? Codes.CeProvisionSection.FINANCIAL_REQUIREMENT_AA
					: Entities.equals(taFilingCondition.getApplicationType(), Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION) ? Codes.CeProvisionSection.FINANCIAL_REQUIREMENT_ABPR : null;
			LocalDate infringedDate = taFilingCondition.getLastExtension() == null ? taFilingCondition.getDueDate() : taFilingCondition.getLastExtension().getExtendedDueDate();
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, provisionCode, infringedDate.plusDays(1).atStartOfDay());
			taFilingCondition.setTarR141Infringement(ceCaseInfringement);
			ceCaseRepository.save(taFilingCondition);
		}
	}

	public void createCaseForFyeInfringement(TaFyUpdate fyUpdate) {
		// create task
		CeTask ceTask = ceTaskHelper.createCeTaskForFye(fyUpdate, Messages.CeTaskDetails.R13_UPDATE_FYE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
		if (ceTask != null) {
			// create case
			LocalDateTime infringedDate = fyUpdate.getApplication().getSubmissionDate();
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, Codes.CeProvisionSection.FYE, infringedDate);
			fyUpdate.setTarR13Infringement(ceCaseInfringement);
			ceCaseRepository.save(fyUpdate);
		}
	}

	public void createCaseForKeInfringement(TaStakeholder ke, Licence licence, LocalDate dateSinceKeIsVacant, LocalDate infringedDate, String ceProvisionSection) {
		// create task
		CeTask ceTask = ceTaskHelper.createCeTaskForKeVacant(licence, dateSinceKeIsVacant, Messages.CeTaskDetails.R15_3B_KE_VACANT, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
		if (ceTask != null) {
			// create case
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, Codes.CeProvisionSection.KE_VACANT, infringedDate.atStartOfDay());
			if (ke != null) {
				ke.setTarR153bInfringement(ceCaseInfringement);
				ceCaseRepository.save(ke);
			}
		}
	}

	public void createCaseForKeInfringement(TaStakeholderApplication keApp, LocalDate infringedDate) {
		// create task
		CeTask ceTask = ceTaskHelper.createCeTaskForKeLateSubmission(keApp, Messages.CeTaskDetails.R15_3A_KE_RESIGN, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND);
		if (ceTask != null) {
			// create case
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, Codes.CeProvisionSection.KE_RESIGNATION_LATE_SUBMISSION, infringedDate.atStartOfDay());
			if (keApp != null) {
				keApp.setTarR153aInfringement(ceCaseInfringement);
				ceCaseRepository.save(keApp);
			}
		}
	}

	public void createCaseForLicence(Licence licence, LocalDate ceasedDate, LocalDate infringedDate, String provisionCode) {
		// create task
		CeTask ceTask = null;
		if (Codes.CeProvisionSection.CESSATION_NO_RETURN_LICENCE.equals(provisionCode)) {
			ceTask = ceTaskHelper.createCeTaskForLicenceNotReturn(licence, ceasedDate, Messages.CeTaskDetails.R7B_CESSATION_NO_RETURN_LICENCE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, provisionCode,
					Codes.CeTaskTypes.CE_TASK_TAR_R7_B);

		} else if (Codes.CeProvisionSection.REVOCATION_NO_RETURN_LICENCE.equals(provisionCode)) {
			ceTask = ceTaskHelper.createCeTaskForLicenceNotReturn(licence, ceasedDate, Messages.CeTaskDetails.R8_REVOCATION_NO_RETURN_LICENCE, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, provisionCode,
					Codes.CeTaskTypes.CE_TASK_TAR_R8);
		}

		if (ceTask != null) {
			// create case
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, provisionCode, infringedDate.atStartOfDay());
			if (Codes.CeProvisionSection.CESSATION_NO_RETURN_LICENCE.equals(provisionCode)) {
				licence.setTarR7bInfringement(ceCaseInfringement);
			} else if (Codes.CeProvisionSection.REVOCATION_NO_RETURN_LICENCE.equals(provisionCode)) {
				licence.setTarR8Infringement(ceCaseInfringement);
			}
			ceCaseRepository.save(licence);
		}
	}

	public void createCaseForCeasedLicence(TaLicenceCessation cessation, LocalDate infringedDate) {
		// create task
		CeTask ceTask = null;
		Licence licence = cessation.getApplication().getLicence();

		ceTask = ceTaskHelper.createCeTaskForLicenceCeasedLate(licence, cessation.getEffectiveDate(), Messages.CeTaskDetails.R7A_CESSATION_LATE_SUBMISSION, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND,
				Codes.CeTaskTypes.CE_TASK_TAR_R7_A);

		if (ceTask != null) {
			// create case
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, Codes.CeProvisionSection.CESSATION_LATE_SUBMISSION, infringedDate.atStartOfDay());
			cessation.setTarR7aInfringement(ceCaseInfringement);
			ceCaseRepository.save(cessation);
		}
	}

	public void createCaseForImposeLicensingCondition(Licence licence, TaAaSubmission mostRecentAa, TaAaSubmission secondMostRecentAa, LocalDateTime infringedDate) {
		// create task
		CeTask ceTask = ceTaskHelper.createCeTaskForImposeLicensingCondition(licence, mostRecentAa, secondMostRecentAa, Messages.CeTaskDetails.S7A3_IMPOSE_LICENSING_CONDITION);

		if (ceTask != null) {
			// create case
			CeCaseInfringement ceCaseInfringement = createCaseFromCeTaskTrigger(ceTask, Codes.CeProvisionSection.IMPOSE_LICENSING_CONDITION, infringedDate);
			mostRecentAa.setAuditorInfringement(ceCaseInfringement);
			ceCaseRepository.save(mostRecentAa);
		}
	}

	public CeCase createCaseForTaTiCheck(CeTaCheck ceTaCheck, Type isCompliant) {

		// create ceCase
		Licence licence = ceTaCheck.getCeTaCheckScheduleItem().getLicence();

		Object[] tatiSections = { Codes.CeProvisionSection.TATI_1, Codes.CeProvisionSection.TATI_2 };

		CeCase ceCase;
		if (ceTaCheck.getCeCase() != null) {
			// get the case tied to this check if any.
			ceCase = ceTaCheck.getCeCase();
		} else {
			// get the revisit cases tag to the tati check if any
			ceCase = ceCaseRepository.getRevisitCasesFromTatiCheck(ceTaCheck);
			if (!ceTaCheck.getCeTaCheckScheduleItem().toRevisit() && ceCase != null) {
				ceTaskHelper.completeCeTask(ceTaskRepository.getCeTasksByCaseId(ceCase.getId()));
			}
		}

		// if no open cases found, create new case
		if (ceCase == null) {
			ceCase = new CeCase();
			ceCase.setStatus(cache.getStatus(Codes.CeCaseStatus.CE_CASE_LIVE));
			ceCase.setTaTgType(licence.getTaTgType());
			// if not compliant, route to IO (Deen)
			ceCase.setOic(Entities.equals(isCompliant, Codes.FLAGS.FLAG_N) ? userCommonRepository.getUserByLoginId(cache.getSystemParameterAsString(Codes.SystemParameters.CE_DEFAULT_TA_IO))
					: ceTaCheck.getCeTaCheckScheduleItem().getEoUser());
		}

		CeCaseInfringer ceCaseInfringer = new CeCaseInfringer();
		ceCaseInfringer.setLicence(licence);
		ceCaseInfringer.setName(ceTaCheck.getTaName());
		ceCaseInfringer.setUenUin(ceTaCheck.getUen());
		ceCaseInfringer.setIdType(cache.getType(Codes.Types.CE_ID_TYPE_ENTITY));
		ceCaseInfringer.setCeCase(ceCase);

		List<CeProvision> provisions = ceProvisionRepository.getCeProvisionsBySections(tatiSections);
		List<CeCaseInfringement> ceCaseInfringementList = new ArrayList<CeCaseInfringement>();
		if (provisions != null && !ceTaCheck.getCeTaCheckScheduleItem().toRevisit()) {
			for (CeProvision row : provisions) {
				CeCaseInfringement ceCaseInfringement = new CeCaseInfringement();
				ceCaseInfringement.setCeProvision(row);
				ceCaseInfringement.setCeCaseInfringer(ceCaseInfringer);
				ceCaseInfringement.setCeCase(ceCase);
				ceCaseInfringement.setCeOriginatingCase(ceCase);
				// ceCaseInfringement.setInfringedDate(ceTaCheck.getCheckedDate());
				ceCaseInfringementList.add(ceCaseInfringement);
			}
		}
		ceCase.setCeOriginatingCaseInfringements(new HashSet<CeCaseInfringement>(ceCaseInfringementList));
		List<CeTaCheck> ceTaChecks = Arrays.asList(ceTaCheck);
		ceCase.setCeTaChecks(new HashSet<>(ceTaChecks));
		ceCase.setCeTaCheck(ceTaCheck);

		ceCaseRepository.saveOrUpdate(ceCase);
		ceCaseRepository.save(ceCaseInfringer);
		ceCaseRepository.save(ceCaseInfringementList);

		if (!ceTaCheck.getCeTaCheckScheduleItem().toRevisit() && isCompliant != null) {
			if (Entities.equals(isCompliant, Codes.FLAGS.FLAG_N)) {
				// create ceTask for non compliant
				ceTaskHelper.createCeTaskForRecommend(ceCase);
				ceCase.setOic(userCommonRepository.getUserByLoginId(cache.getSystemParameterAsString(Codes.SystemParameters.CE_DEFAULT_TA_IO)));
			} else {
				// create case task for compliant, set recommendation to NFA
				User approver = workflowHelper.getAssigneeByChar(Codes.Roles.TA_HEAD_OF_DEPARTMENT, licence.getTravelAgent().getName());

				Workflow workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND, null, null, null, false, licence);
				workflow.setDescription("Compliant case for TATI check");
				workflow.setIsDraft(Boolean.FALSE);
				ceCaseRepository.save(workflow);
				workflowHelper.saveOrUpdateStepAssignment(workflow, null, approver.getId());

				ceCaseInfringementList.forEach(ceCaseInfringement -> {
					CeCaseRecommendation recomm = new CeCaseRecommendation();
					recomm.setWorkflow(workflow);
					recomm.setCeCaseInfringement(ceCaseInfringement);
					recomm.setOutcome(cache.getType(Codes.CeRecommendation.CE_OUTCOME_NOD));
					ceCaseInfringement.setLastRecommendation(recomm);
					ceCaseRepository.save(recomm);
				});
				workflowHelper.forward(workflow, true, null, null, approver.getId(), true, true);
			}
		}

		if (ceTaCheck.getCeTaCheckScheduleItem().toRevisit()) {
			ceTaskHelper.createCeTaskForRevisit(ceCase, "Licence No " + ceTaCheck.getLicenceNo());
		}
		return ceCase;

	}

	public CeCase createNewCaseFromTaFieldReport(CeTaFieldReport ceTaFieldReport, CeTaCheckScheduleItem ceScheduleItem, CeCase ceCase) {
		// String assignedOfficer = cache.getSystemParameterAsString(Codes.SystemParameters.CE_DEFAULT_TA_IO);
		String assignedOfficer = ceScheduleItem.getEoUser().getLoginId();
		// create ceCase
		Licence licence = ceTaFieldReport.getCeTaCheckScheduleItem().getLicence();

		ceCase.setStatus(cache.getStatus(Codes.CeCaseStatus.CE_CASE_LIVE));
		ceCase.setTaTgType(licence.getTaTgType());

		CeCaseInfringer ceCaseInfringer = new CeCaseInfringer();
		ceCaseInfringer.setLicence(licence);
		ceCaseInfringer.setName(ceTaFieldReport.getTaName());
		ceCaseInfringer.setUenUin(ceTaFieldReport.getUen());
		ceCaseInfringer.setIdType(cache.getType(Codes.Types.CE_ID_TYPE_ENTITY));
		ceCaseInfringer.setCeCase(ceCase);

		List<CeCaseInfringement> ceCaseInfringementList = new ArrayList<CeCaseInfringement>();
		if (ceScheduleItem != null && ceScheduleItem.getCheckType().getCode().equalsIgnoreCase(Types.TA_CHECK_NON_RENEWAL)) {
			// If check type is non renewal need to set infringement as S6(1) and assigned officer to Jin Teck
			// assignedOfficer = UsersLoginId.JINTECKQ;
			Object[] sections = { Codes.CeProvisionSection.TA_CHECK_NON_RENEWAL };
			List<CeProvision> provisions = ceProvisionRepository.getCeProvisionsBySections(sections);
			if (provisions != null) {
				for (CeProvision row : provisions) {
					CeCaseInfringement ceCaseInfringement = new CeCaseInfringement();
					ceCaseInfringement.setCeProvision(row);
					ceCaseInfringement.setCeCaseInfringer(ceCaseInfringer);
					ceCaseInfringement.setCeCase(ceCase);
					ceCaseInfringement.setCeOriginatingCase(ceCase);
					ceCaseInfringementList.add(ceCaseInfringement);
				}
			}
		} else {
			// If check type is others, assign officer follow alphabetical assignment
			// CharSequence firstLetter = licence.getTravelAgent().getName().substring(0, 0);
			// for (Map.Entry<String, String> entry : Codes.CeTaCaseAssignment.entrySet()) {
			// System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
			// if (entry.getValue().contains(firstLetter)) {
			// assignedOfficer = entry.getKey();
			// break;
			// }
			// }
			CeCaseInfringement ceCaseInfringement = new CeCaseInfringement();
			ceCaseInfringement.setCeCaseInfringer(ceCaseInfringer);
			ceCaseInfringement.setCeCase(ceCase);
			ceCaseInfringement.setCeOriginatingCase(ceCase);
			ceCaseInfringementList.add(ceCaseInfringement);
		}

		List<CeTaFieldReport> ceTaFieldReports = Arrays.asList(ceTaFieldReport);
		ceCase.setCeTaFieldReports(new HashSet<>(ceTaFieldReports));
		ceCase.setOic(userCommonRepository.getUserByLoginId(assignedOfficer));

		ceCaseRepository.save(ceCase);
		ceCaseRepository.save(ceCaseInfringer);
		ceCaseRepository.save(ceCaseInfringementList);
		// Auto route to CO
		// Workflow workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.CE_WKFLW_TA_CASE_TASK_RECOMMEND, null, null, null, false, licence);
		// workflowHelper.reAssign(workflow, userCommonRepository.getUserByLoginId(assignedOfficer), null);
		// ceTaskHelper.updateCeTaskAssignee(workflow);

		// create ce case task
		// LocalDate slaExpiryDate = LocalDate.now().plusDays(cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_SLA_SUBMIT_RECOMMENDATION));
		//
		// if (!ceCaseInfringementList.isEmpty()) {
		// ceTaskHelper.createCeTaskForCeCase(ceCase, new HashSet<CeCaseInfringement>(ceCaseInfringementList), slaExpiryDate, null, ceTaskType, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, null);
		// }

		if (ceScheduleItem.toRevisit()) {
			String details = "";
			if (!Strings.isNullOrEmpty(ceTaFieldReport.getUen())) {
				details = details.concat("UEN: " + ceTaFieldReport.getUen());
			}
			if (!Strings.isNullOrEmpty(ceTaFieldReport.getName())) {
				details = details.concat(" Person Name : " + ceTaFieldReport.getName());
			}
			ceTaskHelper.createCeTaskForRevisit(ceCase, details);
		} else {
			ceTaskHelper.createCeTaskForRecommend(ceCase);
		}

		return ceCase;

	}

	public String getHighestRecommendationCode(CeTgFieldReport ceTgFieldReport) {
		String highestRecommCode = new String();

		for (CeTgFieldReportTg tgRow : ceTgFieldReport.getCeTgFieldReportTgs()) {
			if (tgRow.getCeTgFieldReportTgInfringements() != null) {
				for (CeTgFieldReportTgInfringement infringeRow : tgRow.getCeTgFieldReportTgInfringements()) {
					String recommCode = infringeRow.getRecommendedOutcome().getCode();
					switch (recommCode) {
					case Codes.CeRecommendation.CE_OUTCOME_OPEN_IP:
						highestRecommCode = recommCode;
						break;
					case Codes.CeRecommendation.CE_OUTCOME_SUSPEND:
					case Codes.CeRecommendation.CE_OUTCOME_REVOKE:
					case Codes.CeRecommendation.CE_OUTCOME_AFP:
						if (!highestRecommCode.equalsIgnoreCase(Codes.CeRecommendation.CE_OUTCOME_OPEN_IP)) {
							highestRecommCode = recommCode;
						}
						break;
					case Codes.CeRecommendation.CE_OUTCOME_NOD:
					case Codes.CeRecommendation.CE_OUTCOME_NFA:
					case Codes.CeRecommendation.CE_OUTCOME_CAUTION:
					case Codes.CeRecommendation.CE_OUTCOME_CIRCULAR:
					case Codes.CeRecommendation.CE_OUTCOME_COUNSEL:
						if (StringUtils.isBlank(highestRecommCode)) {
							highestRecommCode = recommCode;
						}
					}
				}
			}
		}

		return highestRecommCode;
	}

	public CeCase createCaseForTgFieldReport(CeTgFieldReport ceTgFieldReport) {

		// create ceCase
		CeCase ceCase = new CeCase();
		Workflow workflow = new Workflow();
		Boolean autoCreateCaseForApproval = Boolean.FALSE;
		String slaParameter = Codes.SystemParameters.CE_TG_SLA_SUBMIT_RECOMMENDATION;

		// check TG Field Report highest recommendation
		String highestRecommCode = getHighestRecommendationCode(ceTgFieldReport);
		switch (highestRecommCode) {
		case Codes.CeRecommendation.CE_OUTCOME_OPEN_IP:
		case Codes.CeRecommendation.CE_OUTCOME_NOD:
		case Codes.CeRecommendation.CE_OUTCOME_NFA:
		case Codes.CeRecommendation.CE_OUTCOME_CAUTION:
		case Codes.CeRecommendation.CE_OUTCOME_CIRCULAR:
		case Codes.CeRecommendation.CE_OUTCOME_COUNSEL:
			ceCase = saveCeCaseForTGFieldReport(ceCase, ceTgFieldReport, ceTgFieldReport.getEoUser().getLoginId());
			autoCreateCaseForApproval = Boolean.TRUE;

			// create workflow
			workflow = workflowHelper.saveNewWorkflow(Codes.Workflow.CE_WKFLW_TG_CASE_TASK_RECOMMEND, null, null, null, false, null);
			workflowHelper.saveOrUpdateStepAssignment(workflow, null, ceTgFieldReport.getAoUser().getId());
			workflowHelper.forward(workflow, true, null, null, ceTgFieldReport.getAoUser().getId(), true, true);

			logger.info("Saving new case from TG Field Report for approval - TG Field Report id: {}, Highest Recommendation Code: {}, Approver id: {}", ceTgFieldReport.getId(), highestRecommCode,
					ceTgFieldReport.getAoUser().getId());

			break;
		case Codes.CeRecommendation.CE_OUTCOME_SUSPEND:
		case Codes.CeRecommendation.CE_OUTCOME_REVOKE:
		case Codes.CeRecommendation.CE_OUTCOME_AFP:
			ceCase = saveCeCaseForTGFieldReport(ceCase, ceTgFieldReport, cache.getSystemParameter(Codes.SystemParameters.CE_DEFAULT_TG_IO).getValue());
			logger.info("Saving new case from TG Field Report for IO - TG Field Report id: {}, Highest Recommendation Code: {}", ceTgFieldReport.getId(), highestRecommCode);
			break;
		}

		List<CeCaseInfringement> ceCaseInfringementList = new ArrayList<CeCaseInfringement>();
		List<CeCaseInfringer> ceCaseInfringerList = new ArrayList<CeCaseInfringer>();
		List<CeCaseRecommendation> ceCaseRecommendationList = new ArrayList<CeCaseRecommendation>();
		for (CeTgFieldReportTg tgRow : ceTgFieldReport.getCeTgFieldReportTgs()) {
			// create infringer
			CeCaseInfringer ceCaseInfringer = new CeCaseInfringer();
			ceCaseInfringer.setLicence(tgRow.getLicence());
			ceCaseInfringer.setName(tgRow.getName());
			ceCaseInfringer.setUenUin(StringUtils.isNotBlank(tgRow.getUin()) ? tgRow.getUin() : tgRow.getPassportNo());
			ceCaseInfringer.setIdType(cache.getType(Codes.Types.CE_ID_TYPE_INDIVIDUAL));
			ceCaseInfringer.setAgeGroup(tgRow.getAgeGroup());
			ceCaseInfringer.setNationality(tgRow.getNationality());
			ceCaseInfringer.setGuidingLanguageProvided(tgRow.getGuidingLanguageProvided());
			ceCaseInfringer.setCeCase(ceCase);
			ceCaseInfringerList.add(ceCaseInfringer);

			if (tgRow.getCeTgFieldReportTgInfringements() != null) {
				for (CeTgFieldReportTgInfringement infringeRow : tgRow.getCeTgFieldReportTgInfringements()) {
					// create infringement
					CeCaseInfringement ceCaseInfringement = new CeCaseInfringement();
					ceCaseInfringement.setCeProvision(infringeRow.getCeProvision());

					HashSet<CeProvision> readWiths = new HashSet<CeProvision>();

					if (infringeRow.getReadWith() != null) {
						readWiths.add(infringeRow.getReadWith());
						ceCaseInfringement.setReadWiths(readWiths);
					}

					ceCaseInfringement.setCeCaseInfringer(ceCaseInfringer);
					ceCaseInfringement.setCeCase(ceCase);
					ceCaseInfringement.setCeOriginatingCase(ceCase);
					ceCaseInfringement.setInfringedDate(ceTgFieldReport.getInfringedDate());
					ceCaseInfringementList.add(ceCaseInfringement);

					// create recommendation
					CeCaseRecommendation ceCaseRecommendation = new CeCaseRecommendation();
					ceCaseRecommendation.setOutcome(infringeRow.getRecommendedOutcome());
					ceCaseRecommendation.setCeCaseInfringement(ceCaseInfringement);
					ceCaseRecommendationList.add(ceCaseRecommendation);

					if (workflow.getId() != null) {
						ceCaseRecommendation.setWorkflow(workflow);
					}

					ceCaseInfringement.setLastRecommendation(autoCreateCaseForApproval ? ceCaseRecommendation : null);
				}
			}
		}
		ceCase.setCeOriginatingCaseInfringements(new HashSet<CeCaseInfringement>(ceCaseInfringementList));

		ceCaseRepository.saveOrUpdate(ceCase);
		ceCaseRepository.save(ceCaseInfringerList);
		ceCaseRepository.save(ceCaseInfringementList);
		ceCaseRepository.save(ceCaseRecommendationList);

		if (!ceCaseInfringementList.isEmpty()) {
			// create ceTask
			if (autoCreateCaseForApproval) {
				ceTaskHelper.createCeTaskForCeCase(ceCase, workflow, CeTaskTypes.CE_TASK_RECOMMEND, null, slaParameter, null);
			} else {
				ceTaskHelper.createCeTaskForCeCase(ceCase, null, Codes.CeTaskTypes.CE_TASK_RECOMMEND, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, slaParameter, null);
			}
		}

		return ceCase;
	}

	private CeCase saveCeCaseForTGFieldReport(CeCase ceCase, CeTgFieldReport ceTgFieldReport, String caseOIC) {
		ceCase.setStatus(cache.getStatus(Codes.CeCaseStatus.CE_CASE_LIVE));
		ceCase.setTaTgType(TaTgType.TG);
		ceCase.setOic(userCommonRepository.getUserByLoginId(caseOIC));
		ceCase.setCeTgFieldReport(ceTgFieldReport);
		ceCase.setIsIp(false);
		ceCase.setAssessment(ceTgFieldReport.getDetails());

		if (!ceTgFieldReport.getFiles().isEmpty()) {
			ceCase.setFiles(new HashSet<>(ceTgFieldReport.getFiles()));
		}

		ceCaseRepository.save(ceCase);
		return ceCase;
	}

	public CeCaseInfringement createCaseFromCeTaskTrigger(CeTask ceTask, String provisionCode, LocalDateTime infringedDate) {
		CeCase ceCase = new CeCase();
		ceCase.setStatus(cache.getStatus(Codes.CeCaseStatus.CE_CASE_LIVE));
		ceCase.setTaTgType(ceTask.getLicence().getTaTgType());
		ceCase.setOic(ceTask.getOic());

		CeCaseInfringer ceCaseInfringer = new CeCaseInfringer();
		ceCaseInfringer.setLicence(ceTask.getLicence());
		ceCaseInfringer.setName(ceTask.getName());
		ceCaseInfringer.setUenUin(ceTask.getUenUin());
		ceCaseInfringer.setIdType(ceTask.getIdType());
		ceCaseInfringer.setCeCase(ceCase);

		CeCaseInfringement ceCaseInfringement = new CeCaseInfringement();
		ceCaseInfringement.setCeProvision(ceProvisionRepository.getCeProvisionBySection(provisionCode));
		ceCaseInfringement.setCeCaseInfringer(ceCaseInfringer);
		ceCaseInfringement.setCeCase(ceCase);
		ceCaseInfringement.setCeOriginatingCase(ceCase);
		ceCaseInfringement.setInfringedDate(infringedDate);

		ceCaseRepository.save(ceCase);
		ceCaseRepository.save(ceCaseInfringer);
		ceCaseRepository.save(ceCaseInfringement);

		ceTask.setForCase(ceCase);
		ceTask.setDetails(messageHelper.formatProvision(ceTask.getDetails(), ceCaseInfringement.getCeProvision().getChapter().getCode(), ceCaseInfringement.getCeProvision().getSection()));
		ceCaseRepository.save(ceTask);

		return ceCaseInfringement;
	}

	public Set<CeCaseInfringement> getInfringementsFromCase(CeCase ceCase) {
		Set<CeCaseInfringement> allInfringements = new HashSet<>();
		if (ceCase.getCeCaseInfringements() != null && !ceCase.getCeCaseInfringements().isEmpty()) {
			ceCase.getCeCaseInfringements().forEach(u -> {
				allInfringements.add(u);

			});
		}
		if (ceCase.getCeOriginatingCaseInfringements() != null && !ceCase.getCeOriginatingCaseInfringements().isEmpty()) {
			ceCase.getCeOriginatingCaseInfringements().forEach(u -> {
				allInfringements.add(u);
			});
		}
		return allInfringements;
	}

	public List<CeCaseInfringer> getInfringersFromInfringements(Set<CeCaseInfringement> infringements) {
		List<CeCaseInfringer> infringers = new ArrayList<>();
		infringements.forEach(u -> {
			CeCaseInfringer infringer = u.getCeCaseInfringer();
			if (CollectionUtils.isEmpty(infringers) || infringers.stream().filter(inf -> inf.getUenUin().equals(infringer.getUenUin())).findAny().isEmpty()) {
				infringers.add(infringer);
			}
		});

		return infringers;
	}

	public boolean processRecommendationDirectOutcome(List<CeCaseRecommendation> recommendationList, CeCase ceCase) {
		recommendationList.forEach(recommendation -> {
			processDirectOutcome(recommendation.getCeCaseInfringement(), recommendation.getOutcome());
		});

		return processCeCase(ceCase);
	}

	// to process direct outcome (NOD/NFA/CAUTION/CIRCULAR/COUNSEL) only
	private void processDirectOutcome(CeCaseInfringement ceCaseInfringement, Type outcome) {
		if (Entities.anyEquals(outcome, Codes.CeRecommendation.DIRECT_OUTCOME)) {
			ceCaseInfringement.setOutcome(outcome);
			ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
			ceCaseRepository.update(ceCaseInfringement);
		}
	}

	// allocate this method here so that can be shared by other module like TA/TG field report etc
	public boolean processRecommendationOutcome(List<CeCaseRecommendation> recommendationList, CeCase ceCase) {
		List<CeCaseInfringement> openIpInfringements = new ArrayList<>();

		Set<Licence> licSet = new HashSet<>();
		HashMap<Integer, String> licenceHighestStatusMap = new HashMap<>(); // to store the highest status that going to be updated for that licence

		recommendationList.forEach(recommendation -> {
			CeCaseInfringement ceCaseInfringement = recommendation.getCeCaseInfringement();

			String recommCode = recommendation.getOutcome().getCode();
			switch (recommCode) {
			case Codes.CeRecommendation.CE_OUTCOME_SUSPEND:
			case Codes.CeRecommendation.CE_OUTCOME_REVOKE:
				CeCaseInfringer ceCaseInfringer = ceCaseInfringement.getCeCaseInfringer();
				Licence lic = ceCaseInfringer.getLicence();

				// if current licence is suspended, suspension start date/end date will follow licence suspend start date and end date
				if (lic != null && Entities.anyEquals(lic.getStatus(), Codes.Statuses.TA_SUSPENDED, Codes.Statuses.TG_SUSPENDED)) {
					if (lic.getSuspendStartDate() != null && lic.getSuspendEndDate() != null) {
						recommendation.setPenaltyStatusStartDate(lic.getSuspendStartDate());
						recommendation.setPenaltyStatusEndDate(lic.getSuspendEndDate());

						ceCaseInfringement.setOutcome(recommendation.getOutcome());
						ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
						ceCaseRepository.update(recommendation);
						ceCaseRepository.update(ceCaseInfringement);
						break;
					}
				}

				if (Codes.TaTgType.TA.equals(ceCase.getTaTgType())) {
					String params = cache.getSystemParameter(Codes.SystemParameters.CE_TA_SECTION_PENDING_SUSPEND_REVOKE).getValue();
					List<String> taSections = Arrays.asList(params.split(","));

					if (taSections.contains(ceCaseInfringement.getCeProvision().getSection())) {
						if (lic != null) {
							String updatedStatus = null;
							if (licenceHighestStatusMap.isEmpty() || !licenceHighestStatusMap.containsKey(lic.getId())) {
								updatedStatus = recommCode.equals(Codes.CeRecommendation.CE_OUTCOME_SUSPEND) ? Codes.Statuses.TA_PEND_SUSPENSION : Codes.Statuses.TA_PEND_REVOCATION;
							} else {
								updatedStatus = licenceHighestStatusMap.get(lic.getId());
								if (recommCode.equals(Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
									updatedStatus = Codes.Statuses.TA_PEND_REVOCATION;
								}
							}
							licenceHighestStatusMap.put(lic.getId(), updatedStatus);
							licSet.add(lic);
						}
					}
				}

				break;

			case Codes.CeRecommendation.CE_OUTCOME_OPEN_IP:
				openIpInfringements.add(ceCaseInfringement);
				ceCaseInfringement.setOutcome(recommendation.getOutcome());
				ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
				ceCaseRepository.update(ceCaseInfringement);
				break;

			case Codes.CeRecommendation.CE_OUTCOME_TAG_IP:
				CeCase ipCase = ceCaseRepository.getCaseFromCaseNo(recommendation.getTaggedIpCaseNo());
				ceCaseInfringement.setCeCase(ipCase);
				ceCaseInfringement.setOutcome(recommendation.getOutcome());
				ceCaseInfringement.setOutcomeDate(LocalDateTime.now());
				ceCaseRepository.update(ceCaseInfringement);
				break;
			}
		});

		if (CollectionUtils.isNotEmpty(openIpInfringements)) {
			createIpFromCase(ceCase, openIpInfringements);
		}

		if (!licenceHighestStatusMap.isEmpty()) {
			licenceHighestStatusMap.forEach((licenceId, status) -> {
				Licence licence = licSet.stream().filter(u -> u.getId().equals(licenceId)).findAny().get();
				logger.info("[Process Recommendation Outcome] Licence ID : {} updated to {}", licence.getLicenceNo(), status);
				licenceHelper.updateLicenceStatus(licence, status);
			});
		}

		return processCeCase(ceCase);
	}

	// check whether system can close the case
	public boolean processCeCase(CeCase ceCase) {

		Set<CeCaseInfringement> allInfringements = getInfringementsFromCase(ceCase);

		if (allInfringements != null && !allInfringements.isEmpty()) {
			// 1. check whether there is non-concluded infringement with no outcome or outcome is not NOD/NFA/Caution/Circular/Counsel
			List<CeCaseInfringement> infringementList = allInfringements.stream()
					.filter(u -> !u.getIsConcluded() && (u.getOutcome() == null || !Entities.anyEquals(u.getOutcome(), Codes.CeRecommendation.DIRECT_OUTCOME))).collect(Collectors.toList());

			// 1.1 If dont have any infringement, close the case
			if (CollectionUtils.isEmpty(infringementList)) {

				List<CeCaseInfringement> directOutcomeInfringementsPendingLetterIssuance = allInfringements.stream().filter(u -> !u.getIsConcluded() && (u.getOutcome() == null
						|| !Entities.anyEquals(u.getOutcome(), Codes.CeRecommendation.DIRECT_OUTCOME) || Entities.anyEquals(u.getOutcome(), Codes.CeRecommendation.OUTCOME_WITH_LETTER_ISSUANCE)))
						.collect(Collectors.toList()).stream().filter(inf -> {
							CeCaseRecommendation lastRecomm = ceCaseRepository.getRecommendationById(inf.getLastRecommendation().getId());
							return lastRecomm.getLetterIssuanceDate() == null;
						}).collect(Collectors.toList());

				if (CollectionUtils.isEmpty(directOutcomeInfringementsPendingLetterIssuance)) {
					closeCase(ceCase, allInfringements);
					return true;
				}

			} else {

				// 1.2 If infringements exists, do the validations below:
				List<CeCaseInfringement> tempInfringements = new ArrayList<>();
				for (CeCaseInfringement openInfringement : infringementList) {

					// normally there is no suspension start/end date for recommendation
					// if recommendation has suspension start/end date, means this recommendation is applied on suspended licence
					// hence system can conclude
					if (openInfringement.getLastRecommendation() != null) {
						CeCaseRecommendation lastRecommendation = ceCaseRepository.getRecommendationById(openInfringement.getLastRecommendation().getId());
						if (Entities.equals(lastRecommendation.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_SUSPEND) && lastRecommendation.getPenaltyStatusStartDate() != null
								&& lastRecommendation.getPenaltyStatusEndDate() != null) {
							tempInfringements.add(openInfringement);
						}
					}

					if (openInfringement.getLastDecision() != null) {
						CeCaseDecision lastDecision = ceCaseRepository.getDecisionById(openInfringement.getLastDecision().getId());

						if (lastDecision.hasInProgressAppeal() != null && !lastDecision.hasInProgressAppeal()) {
							CeCaseAppeal appeal = lastDecision.getCeCaseAppeal();

							if (appeal != null && appeal.getResult() != null && appeal.getWorkflow() != null && workflowHelper.hasFinalApproved(appeal.getWorkflow())) {
								if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_AFP)) {
									PaymentRequest payReq = paymentHelperRepository.getPaymentRequest(appeal.getBillRefNo());
									if (payReq != null && payReq.getStatus() != null) {
										boolean paymentSuccess = Entities.anyEquals(payReq.getStatus(), Codes.Statuses.PAYREQ_SETTLED, Codes.Statuses.PAYREQ_REFUNDED);
										if (paymentSuccess) {
											tempInfringements.add(openInfringement);
											ceTaskHelper.completeCeTaskByBill(payReq.getBillRefNo());
										}
									}

								} else if (Entities.anyEquals(appeal.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_SUSPEND, Codes.CeRecommendation.CE_OUTCOME_REVOKE)) {
									tempInfringements.add(openInfringement);
								}
							}

						}
					}
				}

				if (tempInfringements.size() == infringementList.size()) {
					closeCase(ceCase, new HashSet<CeCaseInfringement>(infringementList));
					return true;
				}

			}
		}

		return false;
	}

	private void closeCase(CeCase ceCase, Set<CeCaseInfringement> infringements) {
		Status closedStatus = cache.getStatus(Codes.CeCaseStatus.CE_CASE_CLOSED);
		ceCase.setStatus(closedStatus);
		ceCaseRepository.update(ceCase);
		logger.info("CeCase(id:{}, no:{}) set to {}.", ceCase.getId(), ceCase.getCaseNo(), closedStatus.getLabel());
		ceTaskHelper.completeCeTaskByCeCase(ceCase, false);

		List<CeCase> taggedCases = ceCaseRepository.getChildCaseByCaseId(ceCase.getId());
		if (CollectionUtils.isNotEmpty(taggedCases)) {
			taggedCases.forEach(taggedCase -> {
				taggedCase.setStatus(closedStatus);
				ceTaskHelper.completeCeTaskByCeCase(taggedCase, false);
			});
			ceCaseRepository.update(taggedCases);
		}

		infringements.forEach(inf -> inf.setIsConcluded(true));
		ceCaseRepository.update(infringements);
	}

	// set TA check's isAcknowledged to false once the case is being processed
	public void acknowledgeTaCheck(List<CeCaseRecommendation> recommendationList, CeCase ceCase, User currUser) {
		if (Codes.TaTgType.TA.equals(ceCase.getTaTgType())) {
			recommendationList.forEach(recommendation -> {
				CeCaseInfringement ceCaseInfringement = recommendation.getCeCaseInfringement();
				CeCase cCase = ceCaseInfringement.getCeCase();
				CeTaCheck lastCheck = cCase.getCeTaCheck();
				if (lastCheck != null && !lastCheck.getIsAcknowledged()) {
					lastCheck.setIsAcknowledged(true);
					lastCheck.setLastAcknowledgedBy(currUser);
					lastCheck.setLastAcknowledgedDate(LocalDate.now());
					ceCaseRepository.update(lastCheck);
				}
			});
		}
	}

	public String populateInfringementTaskDetails(String chapterCode, String section, Type outcome, BigDecimal penaltyAmount, LocalDate startDate, LocalDate endDate, LocalDate paymentDueDate,
			String paymentStatus, String billRefNo) {
		StringBuilder taskDetail = null;
		if (chapterCode != null) {
			taskDetail = new StringBuilder(chapterCode).append(StringUtils.SPACE);
		}
		if (section != null) {
			taskDetail = appendTaskDetails(taskDetail, section);
		}
		if (section != null && outcome != null) {
			taskDetail = appendTaskDetails(taskDetail, ":").append(StringUtils.SPACE);
		} else if (section != null && outcome == null) {
			taskDetail = appendTaskDetails(taskDetail, ": Pending outcome").append(StringUtils.SPACE);
		}

		if (outcome != null) {
			taskDetail = appendTaskDetails(taskDetail, outcome.getLabel()).append(StringUtils.SPACE);
		}

		if (penaltyAmount != null) {
			taskDetail = appendTaskDetails(taskDetail, "(".concat(NumeralUtil.formatToLocalCurrency(penaltyAmount)));

			if (paymentDueDate != null) {
				taskDetail = appendTaskDetails(taskDetail, ", Due on ".concat(DateUtil.format(paymentDueDate)));
			}

			if (paymentStatus != null) {
				taskDetail = appendTaskDetails(taskDetail, ", ".concat(paymentStatus));
			}

			if (billRefNo != null) {
				taskDetail = appendTaskDetails(taskDetail, ", ".concat(billRefNo));
			}

			taskDetail = appendTaskDetails(taskDetail, ")");
		}

		if (startDate != null || endDate != null) {
			taskDetail = appendTaskDetails(taskDetail, "(");
			if (startDate != null) {
				taskDetail = appendTaskDetails(taskDetail, DateUtil.format(startDate));
			}

			if (endDate != null) {
				taskDetail = appendTaskDetails(taskDetail, " to ".concat(DateUtil.format(endDate)));
			}
			taskDetail = appendTaskDetails(taskDetail, ")");
		}

		return taskDetail != null ? taskDetail.toString() : null;
	}

	public String populatePaymentRefundOrWaiveTaskDetails(BigDecimal amountDiff, BigDecimal penaltyAmount, Status paymentStatus, String billRefNo) {
		StringBuilder taskDetail = null;

		if (paymentStatus != null) {
			if (Entities.equals(paymentStatus, Codes.Statuses.PAYREQ_SETTLED)) {
				taskDetail = appendTaskDetails(taskDetail, "Refund Amount:").append(StringUtils.SPACE);
				taskDetail = appendTaskDetails(taskDetail, NumeralUtil.formatToLocalCurrency(amountDiff)).append(StringUtils.SPACE);
			} else if (Entities.anyEquals(paymentStatus, Codes.Statuses.PAYREQ_NOT_PAID)) {
				taskDetail = appendTaskDetails(taskDetail, "Waive Amount:").append(StringUtils.SPACE);
				taskDetail = appendTaskDetails(taskDetail, NumeralUtil.formatToLocalCurrency(amountDiff)).append(StringUtils.SPACE);
			}
		}

		if (penaltyAmount != null && Entities.anyEquals(paymentStatus, Codes.Statuses.PAYREQ_SETTLED, Codes.Statuses.PAYREQ_NOT_PAID)) {

			if (billRefNo != null) {
				taskDetail = appendTaskDetails(taskDetail, "(Original bill: ".concat(billRefNo));
			}

			taskDetail = appendTaskDetails(taskDetail, ", ".concat(NumeralUtil.formatToLocalCurrency(penaltyAmount)));

			if (paymentStatus != null) {
				taskDetail = appendTaskDetails(taskDetail, ", ".concat(paymentStatus.getLabel()));
			}

			taskDetail = appendTaskDetails(taskDetail, ")");
		}
		return taskDetail != null ? taskDetail.toString() : "";
	}

	private StringBuilder appendTaskDetails(StringBuilder taskDetail, String detail) {
		return (taskDetail != null) ? taskDetail.append(detail) : new StringBuilder(detail);
	}

	public void createIpFromCase(CeCase ceCase, List<CeCaseInfringement> openIpInfringements) {

		// create IP Case
		CeCase ipCase = new CeCase();
		ipCase.setTaTgType(ceCase.getTaTgType());
		ipCase.setStatus(cache.getStatus(Codes.CeCaseStatus.CE_CASE_LIVE));
		ipCase.setOic(Codes.TaTgType.TA.equals(ceCase.getTaTgType()) ? userCommonRepository.getUserByLoginId(cache.getSystemParameterAsString(Codes.SystemParameters.CE_DEFAULT_TA_IO))
				: userCommonRepository.getUserByLoginId(cache.getSystemParameterAsString(Codes.SystemParameters.CE_DEFAULT_TG_IO)));
		ipCase.setIsIp(true);
		ipCase.setCrmRefNo(ceCase.getCrmRefNo());
		ipCase.setAssessment(ceCase.getAssessment());
		ipCase.setMitigatingFactors(ceCase.getMitigatingFactors());
		ipCase.setAggravatingFactors(ceCase.getAggravatingFactors());
		ipCase.setTaggedCase(ceCase);
		ceCaseRepository.save(ipCase);

		// create IP Complainants
		createIpComplainantFromCase(null, ipCase, ceCase.getOic());

		Set<CeCaseComplainant> complainants = ceCase.getCeCaseComplainants();
		complainants.forEach(complainant -> {
			createIpComplainantFromCase(complainant, ipCase, null);
		});

		// tie relevant infringement to IPCase
		openIpInfringements.forEach(u -> u.setCeCase(ipCase));
		ceCaseRepository.update(openIpInfringements);

		// create ce task for IP
		ceTaskHelper.createCeTaskForIP(ipCase, openIpInfringements);

	}

	private void createIpComplainantFromCase(CeCaseComplainant complainant, CeCase ipCase, User caseOic) {
		CeCaseComplainant newComplainant = new CeCaseComplainant();
		newComplainant.setCeCase(ipCase);
		if (complainant != null) {
			newComplainant.setName(complainant.getName());
			newComplainant.setContactNo(complainant.getContactNo());
			newComplainant.setEmailAddress(complainant.getEmailAddress());
			newComplainant.setAddress(complainant.getAddress());
			newComplainant.setType(complainant.getType());
		} else if (caseOic != null) {
			newComplainant.setName(caseOic.getName());
			newComplainant.setEmailAddress(caseOic.getEmailAddress());
			newComplainant.setType(cache.getType(Codes.ComplainantType.CE_COMPLAINANT_STB));
		}
		ceCaseRepository.save(newComplainant);
	}

	public CeCaseDecision getDecisionById(Integer decisionId) {
		return ceCaseRepository.getDecisionById(decisionId);
	}

	public void processEmailNotification(List<CeCaseRecommendation> recommendationList, CeCase ceCase) {
		recommendationList.forEach(recomm -> {
			if (Entities.anyEquals(recomm.getOutcome(), Codes.CeRecommendation.CE_OUTCOME_TAG_IP)) {

				CeCase taggedCeCase = ceCaseRepository.getCaseFromCaseNo(recomm.getTaggedIpCaseNo());
				if (taggedCeCase != null) {
					String emailContent = messageHelper.formatCasePlaceholders(Messages.CeTaskDetails.CASE_TAG_TO_CASE, taggedCeCase);
					emailContent = messageHelper.replace(emailContent, Codes.Placeholders.CHILD_CASE_NO, ceCase.getCaseNo());
					sendEmailNotificationToCaseOic(taggedCeCase, emailContent);
				}
			}
		});
	}

	public void sendEmailNotificationToCaseOic(CeCase ceCase, String content) {

		String emailSubject = messageHelper.formatCasePlaceholders(Messages.CeTaskDetails.CASE_UPDATE_NOTIFICATION, ceCase);
		String emailContent = content;

		if (ceCase.getOic() != null && ceCase.getOic().getEmailAddress() != null) {
			String[] recipients = new String[1];
			recipients[0] = ceCase.getOic().getEmailAddress();

			emailHelper.email(emailSubject, emailContent, recipients);
		}
	}

	public PaymentRequest getNodPaymentDetails(String billRefno) {
		return paymentHelperRepository.getPaymentRequest(billRefno);
	}

}
