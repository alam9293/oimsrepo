package gov.stb.tag.helper;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.CeCaseComposition;
import gov.stb.tag.model.CeCaseDecision;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeCaseInfringer;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.model.CeTaCheck;
import gov.stb.tag.model.CeTaCheckSchedule;
import gov.stb.tag.model.CeTaCheckScheduleItem;
import gov.stb.tag.model.CeTask;
import gov.stb.tag.model.CeTgCheckSchedule;
import gov.stb.tag.model.CeTgCheckScheduleItem;
import gov.stb.tag.model.CeTgCheckScheduleItemLocation;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.TaAaSubmission;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFyUpdate;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholder;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.repository.CeCaseRepository;
import gov.stb.tag.repository.CeProvisionRepository;
import gov.stb.tag.repository.CeTaskRepository;
import gov.stb.tag.repository.PaymentHelperRepository;
import gov.stb.tag.repository.TaCommonRepository;
import gov.stb.tag.repository.UserCommonRepository;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.NumeralUtil;

@Component
@Transactional
public class CeTaskHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;
	@Autowired
	CeTaskRepository ceTaskRepository;
	@Autowired
	protected UserCommonRepository userCommonRepository;
	@Autowired
	PaymentHelperRepository paymentHelperRepository;
	@Autowired
	MessageHelper messageHelper;
	@Autowired
	WorkflowHelper workflowHelper;
	@Autowired
	CeCaseHelper ceCaseHelper;
	@Autowired
	CeCaseRepository ceCaseRepository;
	@Autowired
	CeProvisionRepository ceProvisionRepository;
	@Autowired
	TaCommonRepository taCommonRepository;

	public CeTask createCeTaskForShortfall(TaNetValueShortfall shortfall, String message, String taskStatus) {

		String details = messageHelper.formatShortfallTaskPlaceholders(message, shortfall);
		String provisionCode = getMinimumFinancialRequirementProvisionCode(shortfall.getWorkflow().getLicence());
		details = formatProvision(details, provisionCode);
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.CNE_COMPLIANCE_OFFICER, shortfall.getWorkflow().getLicence().getTravelAgent().getName());
		LocalDate dueDate = DateUtil.getMaxDate(shortfall.getRectificationDueDate(), shortfall.getExtendedDueDate());

		if (Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND.equals(taskStatus)) {
			completeCeTaskByWorkflow(shortfall.getWorkflow());

			return createCeTaskForLicence(shortfall.getWorkflow().getLicence(), cache.getType(Codes.CeTaskTypes.CE_TASK_TAR_R9), details, oic, oic, deriveSlaExpiryDateToRecommend(LocalDate.now()),
					cache.getStatus(taskStatus));

		} else if (Codes.CeTaskStatus.CE_TASK_FOR_INFO.equals(taskStatus)) {

			completeCeTaskByWorkflow(shortfall.getWorkflow());

			return createCeTaskForWorkflow(shortfall.getWorkflow(), cache.getType(Codes.CeTaskTypes.CE_TASK_TAR_R9), details, oic, null, dueDate, cache.getStatus(taskStatus));
		}

		return null;
	}

	public CeTask createCeTaskForAaOrAbpr(TaFilingCondition taFilingCondition, String message, String taskStatus) {

		String details = messageHelper.formatTaFilingConditionTaskPlaceholders(message, taFilingCondition);
		String provisionCode = Entities.equals(taFilingCondition.getApplicationType(), Codes.ApplicationTypes.TA_APP_AA_SUBMISSION) ? Codes.CeProvisionSection.FINANCIAL_REQUIREMENT_AA
				: Entities.equals(taFilingCondition.getApplicationType(), Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION) ? Codes.CeProvisionSection.FINANCIAL_REQUIREMENT_ABPR : null;
		details = formatProvision(details, provisionCode);
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.TA_VERIFYING_OFFICER, taFilingCondition.getLicence().getTravelAgent().getName());
		LocalDate dueDate = taFilingCondition.getLastExtension() == null ? taFilingCondition.getDueDate() : taFilingCondition.getLastExtension().getExtendedDueDate();

		String taskType = Entities.equals(taFilingCondition.getApplicationType(), Codes.ApplicationTypes.TA_APP_AA_SUBMISSION) ? Codes.CeTaskTypes.CE_TASK_TAR_R14_1B
				: Entities.equals(taFilingCondition.getApplicationType(), Codes.ApplicationTypes.TA_APP_ABPR_SUBMISSION) ? Codes.CeTaskTypes.CE_TASK_TAR_R14_1A : null;

		if (Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND.equals(taskStatus)) {
			completeCeTaskByTaFilingCondition(taFilingCondition);

			return createCeTaskForLicence(taFilingCondition.getLicence(), cache.getType(taskType), details, oic, oic, deriveSlaExpiryDateToRecommend(LocalDate.now()), cache.getStatus(taskStatus));

		} else if (Codes.CeTaskStatus.CE_TASK_FOR_INFO.equals(taskStatus)) {

			completeCeTaskByTaFilingCondition(taFilingCondition);

			return createCeTaskForTaFilingCondition(taFilingCondition, cache.getType(taskType), details, oic, null, dueDate, cache.getStatus(taskStatus));
		}

		return null;
	}

	public CeTask createCeTaskForFye(TaFyUpdate taFyUpdate, String message, String taskStatus) {

		String details = messageHelper.formatTaFyUpdateTaskPlaceholders(message, taFyUpdate);
		details = formatProvision(details, Codes.CeProvisionSection.FYE);
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.TA_VERIFYING_OFFICER, taFyUpdate.getApplication().getLicence().getTravelAgent().getName());

		return createCeTaskForLicence(taFyUpdate.getApplication().getLicence(), cache.getType(Codes.CeTaskTypes.CE_TASK_TAR_R13), details, oic, oic, deriveSlaExpiryDateToRecommend(LocalDate.now()),
				cache.getStatus(taskStatus));
	}

	public CeTask createCeTaskForKeVacant(Licence licence, LocalDate dateSinceKeIsVacant, String message, String taskStatus) {

		String details = messageHelper.formatTaKeTaskPlaceholders(message, dateSinceKeIsVacant, cache.getSystemParameterAsString(Codes.SystemParameters.CE_TA_KE_VACANT_DURATION));
		details = formatProvision(details, Codes.CeProvisionSection.KE_VACANT);
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.CNE_COMPLIANCE_OFFICER, licence.getTravelAgent().getName());
		LocalDate slaExpiryDate = dateSinceKeIsVacant;
		Integer sla = cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_KE_VACANT_DURATION);

		completeCeTaskByLicence(licence.getId(), Codes.CeTaskTypes.CE_TASK_TAR_R15_3B, Codes.CeTaskStatus.CE_TASK_FOR_INFO);

		if (Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND.equals(taskStatus)) {

			slaExpiryDate = deriveSlaExpiryDateToRecommend(LocalDate.now());

			return createCeTaskForLicence(licence, cache.getType(Codes.CeTaskTypes.CE_TASK_TAR_R15_3B), details, oic, oic, slaExpiryDate, cache.getStatus(taskStatus));
		} else if (Codes.CeTaskStatus.CE_TASK_FOR_INFO.equals(taskStatus)) {

			slaExpiryDate = dateSinceKeIsVacant.plusMonths(sla);
			return createCeTaskForLicence(licence, cache.getType(Codes.CeTaskTypes.CE_TASK_TAR_R15_3B), details, oic, null, slaExpiryDate, cache.getStatus(taskStatus));
		}
		return null;
	}

	public CeTask createCeTaskForKeLateSubmission(TaStakeholderApplication keApp, String message, String taskStatus) {

		Licence licence = keApp.getApplication().getLicence();
		String details = messageHelper.formatTaKeTaskPlaceholders(message, keApp.getResignedDate(), cache.getSystemParameterAsString(Codes.SystemParameters.CE_TA_DAYS_TO_INFORM_DUE_KE_RESIGN));
		details = formatProvision(details, Codes.CeProvisionSection.KE_RESIGNATION_LATE_SUBMISSION);
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.CNE_COMPLIANCE_OFFICER, licence.getTravelAgent().getName());

		return createCeTaskForLicence(licence, cache.getType(Codes.CeTaskTypes.CE_TASK_TAR_R15_3A), details, oic, oic, deriveSlaExpiryDateToRecommend(LocalDate.now()), cache.getStatus(taskStatus));
	}

	public CeTask createCeTaskForLicenceNotReturn(Licence licence, LocalDate ceasedDate, String message, String taskStatus, String provisionCode, String taskType) {

		Integer daysToReturnLicence = cache.getSystemParameterAsInteger(Codes.SystemParameters.LCRTN_DAYS_DUE_TA_CEASE);
		String details = messageHelper.formatTaLicenceNotReturnPlaceholders(message, ceasedDate, daysToReturnLicence.toString());
		details = formatProvision(details, provisionCode);
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.CNE_COMPLIANCE_OFFICER, licence.getTravelAgent().getName());

		return createCeTaskForLicence(licence, cache.getType(taskType), details, oic, oic, deriveSlaExpiryDateToRecommend(LocalDate.now()), cache.getStatus(taskStatus));
	}

	public CeTask createCeTaskForLicenceCeasedLate(Licence licence, LocalDate ceasedDate, String message, String taskStatus, String taskType) {

		Integer daysToSubmit = cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_DAYS_TO_INFORM_DUE_TA_CEASE);
		String details = messageHelper.formatTaLicenceNotReturnPlaceholders(message, ceasedDate, daysToSubmit.toString());
		details = formatProvision(details, Codes.CeProvisionSection.CESSATION_LATE_SUBMISSION);
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.CNE_COMPLIANCE_OFFICER, licence.getTravelAgent().getName());

		return createCeTaskForLicence(licence, cache.getType(taskType), details, oic, oic, deriveSlaExpiryDateToRecommend(LocalDate.now()), cache.getStatus(taskStatus));
	}

	public CeTask createCeTaskForSubmitCeCheckSchedule(String taTg, Integer year, Integer month, LocalDate fromDate, LocalDate toDate, User oic) {

		String details = Codes.TaTgType.TA.equals(taTg) ? messageHelper.formatScheduleTaskPlaceholders(Messages.CeTaskDetails.TA_CHECKS_SCHEDULE, LocalDate.of(year, month, 1), null)
				: messageHelper.formatScheduleTaskPlaceholders(Messages.CeTaskDetails.TG_CHECKS_SCHEDULE, fromDate, toDate);
		LocalDate slaExpiryDate = Codes.TaTgType.TA.equals(taTg) ? LocalDate.of(year, month, 1).minusDays(1) : fromDate.minusDays(1);
		String taskStatus = Codes.CeTaskStatus.CE_TASK_TO_SUBMIT;
		String taskType = Codes.TaTgType.TA.equals(taTg) ? Codes.CeTaskTypes.CE_TASK_TA_CHECK_SCHEDULE : Codes.CeTaskTypes.CE_TASK_TG_CHECK_SCHEDULE;
		String name = Codes.TaTgType.TA.equals(taTg) ? Codes.Constants.CE_TA_CHECKS_SCHEDULE_NAME : Codes.Constants.CE_TG_CHECKS_SCHEDULE_NAME;

		return createCeTaskForCeSchedule(taTg, year, month, fromDate, toDate, name, null, cache.getType(taskType), details, oic, oic, slaExpiryDate, cache.getStatus(taskStatus));
	}

	public CeTask createOrUpdateCeTaskForCeCheckScheduleWorkflow(CeTaCheckSchedule taSchedule, CeTgCheckSchedule tgSchedule) {

		String details = "";
		LocalDate slaExpiryDate = null;
		String taskStatus = null;
		String taskType = null;

		if (taSchedule != null) {
			taskType = Codes.CeTaskTypes.CE_TASK_TA_CHECK_SCHEDULE;
			LocalDate firstDayofMonth = LocalDate.of(taSchedule.getYear(), taSchedule.getMonth(), 1);
			slaExpiryDate = firstDayofMonth.minusDays(1);
			details = messageHelper.formatScheduleTaskPlaceholders(Messages.CeTaskDetails.TA_CHECKS_SCHEDULE, firstDayofMonth, null);

			if (taSchedule.getWorkflow() != null && Entities.equals(taSchedule.getWorkflow().getLastAction().getStatus(), Codes.Statuses.CE_WKFLW_PEND_APPR)) {
				taskStatus = Codes.CeTaskStatus.CE_TASK_TO_APPROVE;
			} else {
				taskStatus = Codes.CeTaskStatus.CE_TASK_TO_SUBMIT;
			}

			if (taSchedule.getWorkflow() != null && Entities.equals(taSchedule.getWorkflow().getLastAction().getStatus(), taSchedule.getWorkflow().getLastAction().getPrevStatus())) {
				completeCeTaskByScheduleMonth(taSchedule.getYear(), taSchedule.getMonth());
			}

			return createCeTaskForCeSchedule(Codes.TaTgType.TA, taSchedule.getYear(), taSchedule.getMonth(), null, null, Codes.Constants.CE_TA_CHECKS_SCHEDULE_NAME, taSchedule.getWorkflow(),
					cache.getType(taskType), details, userCommonRepository.getUserByLoginId(taSchedule.getCreatedBy()),
					taSchedule.getWorkflow() != null ? taSchedule.getWorkflow().getAssignee() : null, slaExpiryDate, cache.getStatus(taskStatus));

		} else if (tgSchedule != null) {
			taskType = Codes.CeTaskTypes.CE_TASK_TG_CHECK_SCHEDULE;
			slaExpiryDate = tgSchedule.getFromDate().minusDays(1);

			details = messageHelper.formatScheduleTaskPlaceholders(Messages.CeTaskDetails.TG_CHECKS_SCHEDULE, tgSchedule.getFromDate(), tgSchedule.getToDate());

			if (tgSchedule.getWorkflow() != null && Entities.equals(tgSchedule.getWorkflow().getLastAction().getStatus(), Codes.Statuses.CE_WKFLW_PEND_APPR)) {
				taskStatus = Codes.CeTaskStatus.CE_TASK_TO_APPROVE;
			} else {
				taskStatus = Codes.CeTaskStatus.CE_TASK_TO_SUBMIT;
			}

			if (tgSchedule.getWorkflow() != null && Entities.equals(tgSchedule.getWorkflow().getLastAction().getStatus(), tgSchedule.getWorkflow().getLastAction().getPrevStatus())) {
				completeCeTaskByScheduleWeek(tgSchedule.getYear(), tgSchedule.getFromDate(), tgSchedule.getToDate());
			}

			return createCeTaskForCeSchedule(Codes.TaTgType.TG, tgSchedule.getYear(), null, tgSchedule.getFromDate(), tgSchedule.getToDate(), Codes.Constants.CE_TG_CHECKS_SCHEDULE_NAME,
					tgSchedule.getWorkflow(), cache.getType(taskType), details, userCommonRepository.getUserByLoginId(tgSchedule.getCreatedBy()),
					tgSchedule.getWorkflow() != null ? tgSchedule.getWorkflow().getAssignee() : null, slaExpiryDate, cache.getStatus(taskStatus));
		}

		return null;
	}

	public void createCeTaskForTaCheck(List<CeTaCheckScheduleItem> scheduleItems) {
		List<Integer> updatedCeTaskId = Lists.newArrayList();

		Map<String, List<CeTaCheckScheduleItem>> scheduleItemsByEoUser = scheduleItems.stream().collect(Collectors.groupingBy(item -> item.getEoUser().getLoginId()));
		Map<String, CeTask> ceTasksByUser = ceTaskRepository.getOpenCeTask(Codes.CeTaskTypes.CE_TASK_TA_CHECK, null).stream()
				.collect(Collectors.toMap(ceTask -> ceTask.getOic().getLoginId(), ceTask -> ceTask));
		for (String loginId : scheduleItemsByEoUser.keySet()) {
			List<CeTaCheckScheduleItem> eoUserScheduleItems = scheduleItemsByEoUser.get(loginId);
			CeTaCheckScheduleItem minScheduleItem = eoUserScheduleItems.stream().collect(Collectors.minBy(Comparator.comparing(CeTaCheckScheduleItem::getScheduledDate))).get();

			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < eoUserScheduleItems.size(); i++) {
				sb.append(i + 1).append(".").append("&nbsp;").append("&nbsp;");
				sb.append(DateUtil.format(eoUserScheduleItems.get(i).getScheduledDate()));
				sb.append(" - ");
				sb.append(eoUserScheduleItems.get(i).getTaName());
				sb.append("<br>");
			}
			String details = sb.toString();
			CeTask ceTask = ceTasksByUser.get(loginId);
			User oic = userCommonRepository.getUserByLoginId(loginId);
			if (ceTask == null) {
				ceTask = new CeTask();
				ceTask.setName(Codes.Constants.CE_TA_CHECKS_REPORT);
				createCeTask(ceTask, cache.getType(Codes.CeTaskTypes.CE_TASK_TA_CHECK), details, oic, oic, minScheduleItem.getScheduledDate(), cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_SUBMIT),
						null);
			} else {
				ceTask.setDetails(details);
				ceTask.setSlaExpiryDate(minScheduleItem.getScheduledDate());
				ceTaskRepository.save(ceTask);
			}
			updatedCeTaskId.add(ceTask.getId());
		}

		List<CeTask> toCompleteTasks = ceTaskRepository.getOpenCeTask(Codes.CeTaskTypes.CE_TASK_TA_CHECK, updatedCeTaskId);
		if (CollectionUtils.isNotEmpty(toCompleteTasks)) {
			toCompleteTasks.forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void createCeTaskForTgCheck(List<CeTgCheckScheduleItemLocation> scheduleItemLocations) {
		List<Integer> updatedCeTaskId = Lists.newArrayList();

		Map<String, List<CeTgCheckScheduleItemLocation>> scheduleLocationsByEoUser = Maps.newHashMap();
		Map<String, CeTask> ceTasksByUser = ceTaskRepository.getOpenCeTask(Codes.CeTaskTypes.CE_TASK_TG_CHECK, null).stream()
				.collect(Collectors.toMap(ceTask -> ceTask.getOic().getLoginId(), ceTask -> ceTask));
		scheduleItemLocations.stream().forEach(location -> {
			location.getCeTgCheckScheduleItem().getEoUsers().forEach(user -> {
				if (scheduleLocationsByEoUser.containsKey(user.getLoginId())) {
					scheduleLocationsByEoUser.get(user.getLoginId()).add(location);
				} else {
					scheduleLocationsByEoUser.put(user.getLoginId(), Lists.newArrayList(location));
				}
			});
		});

		for (String loginId : scheduleLocationsByEoUser.keySet()) {
			List<CeTgCheckScheduleItemLocation> eoUserScheduleLocations = scheduleLocationsByEoUser.get(loginId);
			CeTgCheckScheduleItem minScheduleItem = eoUserScheduleLocations.stream().map(CeTgCheckScheduleItemLocation::getCeTgCheckScheduleItem)
					.collect(Collectors.minBy(Comparator.comparing(CeTgCheckScheduleItem::getScheduleDate))).get();

			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < eoUserScheduleLocations.size(); i++) {
				sb.append(i + 1).append(".").append("&nbsp;").append("&nbsp;");
				sb.append(DateUtil.format(eoUserScheduleLocations.get(i).getCeTgCheckScheduleItem().getScheduleDate()));
				sb.append(" - ");
				sb.append(cache.getLabel(eoUserScheduleLocations.get(i).getLocation(), false));
				sb.append("<br>");
			}
			String details = sb.toString();
			CeTask ceTask = ceTasksByUser.get(loginId);
			User oic = userCommonRepository.getUserByLoginId(loginId);
			if (ceTask == null) {
				ceTask = new CeTask();
				ceTask.setName(Codes.Constants.CE_TG_CHECKS_REPORT);
				createCeTask(ceTask, cache.getType(Codes.CeTaskTypes.CE_TASK_TG_CHECK), details, oic, oic, minScheduleItem.getScheduleDate(), cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_SUBMIT),
						null);
			} else {
				ceTask.setDetails(details);
				ceTask.setSlaExpiryDate(minScheduleItem.getScheduleDate());
				ceTaskRepository.save(ceTask);
			}
			updatedCeTaskId.add(ceTask.getId());
		}

		List<CeTask> toCompleteTasks = ceTaskRepository.getOpenCeTask(Codes.CeTaskTypes.CE_TASK_TG_CHECK, updatedCeTaskId);
		if (CollectionUtils.isNotEmpty(toCompleteTasks)) {
			toCompleteTasks.forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void createCeTaskForCompliantTaChecks(List<CeTaCheck> ceTaChecks) {
		List<CeTask> ceTasks = ceTaskRepository.getOpenCeTask(Codes.CeTaskTypes.CE_TASK_TA_CHECK_COMPLIANT, null);
		CeTask ceTask;
		if (CollectionUtils.isNotEmpty(ceTasks)) {
			ceTask = ceTasks.get(0); // should always has one only
		} else {
			ceTask = new CeTask();
			ceTask.setName(Codes.Constants.CE_TA_CHECK_COMPLIANT);
		}

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < ceTaChecks.size(); i++) {
			sb.append(i + 1).append(".").append("&nbsp;").append("&nbsp;");
			sb.append(DateUtil.format(ceTaChecks.get(i).getCheckedDate()));
			sb.append(" - ");
			sb.append(ceTaChecks.get(i).getTaName());
			sb.append("<br>");
		}
		String details = sb.toString();

		User approver = workflowHelper.getAssigneeByChar(Codes.Roles.TA_HEAD_OF_DEPARTMENT, null);
		CeCase minCeCaseCreated = ceTaChecks.stream().map(CeTaCheck::getCeCase).collect(Collectors.minBy(Comparator.comparing(CeCase::getCreatedDate))).get();
		LocalDate minSlaExpiryDate = minCeCaseCreated.getCreatedDate().toLocalDate().plusDays(cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_SLA_FOR_APPROVAL));
		Period period = Period.between(LocalDate.now(), minCeCaseCreated.getCreatedDate().toLocalDate());
		int diff = period.getDays();
		if (diff > 0) {
			minSlaExpiryDate.plusDays(diff);
		}

		createCeTask(ceTask, cache.getType(Codes.CeTaskTypes.CE_TASK_TA_CHECK_COMPLIANT), details, null, approver, minSlaExpiryDate, cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_APPROVE), null);
	}

	public CeTask createCeTaskForImposeLicensingCondition(Licence licence, TaAaSubmission mostRecentAa, TaAaSubmission secondMostRecentAa, String message) {
		String details = messageHelper.replace(message, Codes.Placeholders.FYE, "FY" + secondMostRecentAa.getTaAnnualFiling().getFy() + "," + "FY" + mostRecentAa.getTaAnnualFiling().getFy());
		User oic = workflowHelper.getAssigneeByChar(Codes.Roles.TA_VERIFYING_OFFICER, licence.getTravelAgent().getName());

		return createCeTaskForLicence(licence, cache.getType(Codes.CeTaskTypes.CE_TASK_TAR_S7A_3), details, oic, oic, deriveSlaExpiryDateToRecommend(LocalDate.now()),
				cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND));
	}

	public void createCeTaskForRecommend(CeCase ceCase) {
		createCeTaskForCeCase(ceCase, null, Codes.CeTaskTypes.CE_TASK_RECOMMEND, Codes.CeTaskStatus.CE_TASK_TO_RECOMMEND, Codes.SystemParameters.CE_TA_SLA_SUBMIT_RECOMMENDATION, null);
	}

	public void createCeTaskForRevisit(CeCase ceCase, String additionalDetails) {
		createCeTaskForCeCase(ceCase, null, Codes.CeTaskTypes.CE_TASK_CHECK_REVISIT, Codes.CeTaskStatus.CE_TASK_TO_REVISIT, Codes.SystemParameters.CE_SLA_TA_CHECK_REVISIT, null, additionalDetails);
	}

	public void createCeTaskForCeCase(CeCase ceCase, Workflow workflow, String taskType, String taskStatus, String slaParam, LocalDate slaStartDate) {
		createCeTaskForCeCase(ceCase, workflow, taskType, taskStatus, slaParam, slaStartDate, null);
	}

	public void createCeTaskForCeCase(CeCase ceCase, Workflow workflow, String taskType, String taskStatus, String slaParam, LocalDate slaStartDate, String additionalDetails) {

		// 1. delete if ce task exist
		List<CeTask> ceTasks = ceTaskRepository.getOpenCeTasksByCaseId(ceCase.getId(), StringUtils.equals(taskType, Codes.CeTaskTypes.CE_TASK_RESCIND));
		LocalDate slaExpiryDate = slaParam != null ? deriveSlaExpiryDate(slaStartDate != null ? slaStartDate : LocalDate.now(), slaParam) : slaStartDate != null ? slaStartDate : LocalDate.now();
		if (!CollectionUtils.isEmpty(ceTasks)) {

			// 1.1 check current task type and the taskType(parameter) is same. If not same, have to derive new sla expiry date
			if (Entities.equals(ceTasks.get(0).getType(), taskType) && slaStartDate == null) {
				slaExpiryDate = ceTasks.get(0).getSlaExpiryDate();

				Status prevStatus = ceTasks.get(0).getStatus();
				if (Entities.anyEquals(prevStatus, Codes.CeTaskStatus.CE_TASK_TO_UPDATE_LETTER_DATE)) {
					taskStatus = prevStatus.getCode();
				}
			} else {
				if (slaParam != null) {
					slaExpiryDate = deriveSlaExpiryDate(slaStartDate != null ? slaStartDate : LocalDate.now(), slaParam);
				} else {
					slaExpiryDate = slaStartDate;
				}
			}

			ceTasks.forEach(ceTask -> completeCeTask(ceTask));
		}

		// 2. create a new ce task
		Set<CeCaseInfringement> allInfringements = ceCaseHelper.getInfringementsFromCase(ceCase);

		if (!Strings.isNullOrEmpty(taskStatus) && taskStatus.equalsIgnoreCase(Codes.CeTaskStatus.CE_TASK_TO_REVISIT)) {
			String details = null;
			details = cache.getType(taskType).getLabel();
			if (!Strings.isNullOrEmpty(additionalDetails)) {
				details = details.concat(" " + additionalDetails);
			}
			createCeTaskForCeCase(ceCase, cache.getType(taskType), details, ceCase.getOic(), ceCase.getOic(), slaExpiryDate, cache.getStatus(taskStatus), null, null);
		} else {
			// 2.1 save case without any infringement
			if (allInfringements == null || allInfringements.isEmpty()) {
				createCeTaskForCeCase(ceCase, cache.getType(taskType), "Case Pending Recommendation", ceCase.getOic(), ceCase.getOic(), slaExpiryDate, cache.getStatus(taskStatus), null, null);
			} else {

				// 2.1.1 check whether all infringements have complete outcome. If yes, system will not generate task for this case
				Set<CeCaseInfringement> infringementSet = allInfringements.stream().filter(inf -> inf.getIsConcluded() == null
						|| ((inf.getIsConcluded() != null && !inf.getIsConcluded()) && (inf.getOutcome() == null || !Entities.anyEquals(inf.getOutcome(), Codes.CeRecommendation.COMPLETED_OUTCOME)
								|| (Entities.anyEquals(inf.getOutcome(), Codes.CeRecommendation.OUTCOME_WITH_LETTER_ISSUANCE) && inf.getLastRecommendation().getLetterIssuanceDate() == null))))
						.collect(Collectors.toSet());

				if (!infringementSet.isEmpty()) {

					List<CeCaseInfringer> infringers = ceCaseHelper.getInfringersFromInfringements(infringementSet);
					for (CeCaseInfringer caseInfringer : infringers) {

						Set<CeCaseInfringement> infringements = infringementSet.stream().filter(infringement -> infringement.getCeCaseInfringer().getUenUin().equals(caseInfringer.getUenUin()))
								.collect(Collectors.toSet());

						String taskDetail = null;
						if (workflow != null) {
							Set<CeCaseInfringement> filterInfringements = infringements.stream().filter(inf -> !Entities.anyEquals(inf.getOutcome(), Codes.CeRecommendation.COMPLETED_OUTCOME))
									.collect(Collectors.toSet());
							taskDetail = populateTaskDetail(taskType, filterInfringements);
						} else {
							taskDetail = populateTaskDetail(taskType, infringements);
						}
						Status status = cache.getStatus(taskStatus);
						User assignee = ceCase.getOic();

						if (workflow != null) {
							WorkflowAction lastAction = workflow.getLastAction();
							if (lastAction != null) {
								if (Entities.equals(workflow.getLastAction().getStatus(), Codes.Statuses.CE_WKFLW_PEND_SUPP)) {
									status = cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_SUPPORT);
								} else if (Entities.equals(workflow.getLastAction().getStatus(), Codes.Statuses.CE_WKFLW_PEND_APPR)) {
									status = cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_APPROVE);
								} else if (Entities.equals(workflow.getLastAction().getStatus(), Codes.Statuses.CE_WKFLW_ROUTED)) {
									status = cache.getStatus(taskStatus);
								}
							}

							assignee = workflow.getAssignee();
						}

						createCeTaskForCeCase(ceCase, cache.getType(taskType), taskDetail, ceCase.getOic(), assignee, slaExpiryDate, status, caseInfringer, workflow);

					}
				}
			}
		}

	}

	public void createCeTaskForComposition(CeCase ip, CeCaseComposition compo, String ceTaskStatusCode) {

		CeCaseInfringer ceCaseInfringer = compo.getCeCaseInfringer();
		Workflow workflow = compo.getWorkflow();

		CeTask ceTask = new CeTask();
		ceTask.setName(ceCaseInfringer.getName());
		ceTask.setUenUin(ceCaseInfringer.getUenUin());
		ceTask.setForWorkflow(workflow);
		ceTask.setForCase(ip);

		createCeTask(ceTask, cache.getType(Codes.CeTaskTypes.CE_TASK_RECOMMEND), compo.getDescription(), ip.getOic(), workflow.getAssignee(),
				deriveSlaExpiryDate(LocalDate.now(), Codes.SystemParameters.CE_SLA_FOR_SUPPORT), cache.getStatus(ceTaskStatusCode), ceCaseInfringer.getLicence());
	}

	public void createCeTaskForAFPPayment(String billRefNo, Status paymentStatus, User oic, User assignee, BigDecimal amount, Licence lic, CeCaseInfringer ceCaseInfringer, LocalDate slaExpiryDate,
			CeCase ceCase) {

		// 1. delete if ce task exist
		List<CeTask> ceTasks = ceTaskRepository.getOpenCeTasksByBillRefNo(billRefNo);
		if (!CollectionUtils.isEmpty(ceTasks)) {
			ceTasks.forEach(ceTask -> completeCeTask(ceTask));
		}

		// 2. create new AFP payment task
		if (!Entities.equals(paymentStatus, Codes.Statuses.PAYREQ_PENDING_REFUND)) {
			String details = Messages.CeTaskDetails.AFP_PAYMENT;
			details = messageHelper.formatAFPPaymentPlaceholders(details, NumeralUtil.formatToLocalCurrency(amount), slaExpiryDate, billRefNo);
			String ceTaskStatus = Codes.CeTaskStatus.CE_TASK_TO_PAY;
			if (Entities.equals(paymentStatus, Codes.Statuses.PAYREQ_PAID)) {
				ceTaskStatus = Codes.CeTaskStatus.CE_TASK_PAID;
			}
			// Janet says pending refund is not C&E's, finance doing to refund
			// else if (Entities.equals(paymentStatus, Codes.Statuses.PAYREQ_PENDING_REFUND)) {
			// ceTaskStatus = Codes.CeTaskStatus.CE_TASK_PEND_REFUND;
			// }
			CeTask ceTask = createCeTaskForPayment(cache.getType(Codes.CeTaskTypes.CE_TASK_PAYMENT_EXPIRY), details, oic, assignee, slaExpiryDate, cache.getStatus(ceTaskStatus), billRefNo, ceCase);

			if (lic != null) {
				setLicenceDetails(lic, ceTask);
			} else {
				ceTask.setName(ceCaseInfringer.getName());
				ceTask.setUenUin(ceCaseInfringer.getUenUin());
				ceTaskRepository.update(ceTask);
			}
		}
	}

	public void createCeTaskForCompoPayment(CeCaseComposition compo, CeCase ip) {
		CeTask ceTask = createCeTaskForPayment(cache.getType(Codes.CeTaskTypes.CE_TASK_PAYMENT_PENDING), compo.getDescription(), ip.getOic(), ip.getOic(), compo.getDueDate(),
				cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_PAY), compo.getBillRefNo(), ip);
		ceTask.setName(compo.getCeCaseInfringer().getName());
		ceTask.setUenUin(compo.getCeCaseInfringer().getUenUin());
		ceTaskRepository.update(ceTask);
	}

	public void createCeTaskForIP(CeCase ipCase, List<CeCaseInfringement> allInfringements) {

		List<CeCaseInfringer> infringers = ceCaseHelper.getInfringersFromInfringements(new HashSet<CeCaseInfringement>(allInfringements));
		for (CeCaseInfringer caseInfringer : infringers) {

			List<CeCaseInfringement> infringements = allInfringements.stream().filter(infringement -> infringement.getCeCaseInfringer().getUenUin().equals(caseInfringer.getUenUin()))
					.collect(Collectors.toList());

			Set<String> taskDetailSet = new HashSet<>();
			for (CeCaseInfringement infringement : infringements) {
				CeProvision ceProvision = infringement.getCeProvision();

				String taskDetail = null;
				if (ceProvision != null) {
					taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), null, null, null, null, null, null, null);
				}
				taskDetailSet.add(taskDetail);
			}

			createCeTaskForCeCase(ipCase, cache.getType(Codes.CeTaskTypes.CE_TASK_PAYMENT_EXPIRY), taskDetailSet.stream().collect(Collectors.joining(", ")), ipCase.getOic(), ipCase.getOic(),
					deriveSlaExpiryDate(LocalDate.now(), Codes.SystemParameters.CE_IP_SLA), cache.getStatus(Codes.CeTaskStatus.CE_TASK_TO_IP), caseInfringer, null);

		}

	}

	public void createCeTaskForSuspensionEnd(List<CeCaseInfringement> infringements, CeCaseInfringer infringer) {

		CeCaseInfringement infringement = infringements.get(0);
		CeCase ceCase = infringement.getCeCase();

		// Set<String> taskDetailSet = new HashSet<>();
		// for (CeCaseInfringement infringement : infringements) {
		// ceCase = infringement.getCeCase();
		// CeProvision ceProvision = infringement.getCeProvision();
		//
		// String taskDetail = null;
		// if (ceProvision != null) {
		// CeCaseAppeal appeal = infringement.getLastDecision().getCeCaseAppeal();
		// taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), appeal.getOutcome(), null, appeal.getPenaltyStatusStartDate(),
		// appeal.getPenaltyStatusEndDate(), null, null);
		// }
		// taskDetailSet.add(taskDetail);
		// }

		String taskDetail = messageHelper.replace(Messages.CeTaskDetails.SUSPENSION_END_SOON, Codes.Placeholders.END_DATE,
				DateUtil.format(infringement.getLastDecision().getCeCaseAppeal().getPenaltyStatusEndDate()));

		createCeTaskForCeCase(ceCase, cache.getType(Codes.CeTaskTypes.CE_TASK_SUSPEND_END), taskDetail, ceCase.getOic(), ceCase.getOic(), null, cache.getStatus(Codes.CeTaskStatus.CE_TASK_FOR_INFO),
				infringer, null);
	}

	private String populateTaskDetail(String taskType, Set<CeCaseInfringement> infringements) {
		switch (taskType) {
		case Codes.CeTaskTypes.CE_TASK_RECOMMEND:
		case Codes.CeTaskTypes.CE_TASK_CHECK_REVISIT:
			return populateRecommendationTaskDetail(infringements);
		case Codes.CeTaskTypes.CE_TASK_DECISION:
			return populateDecisionTaskDetail(infringements);
		case Codes.CeTaskTypes.CE_TASK_APPEAL:
		case Codes.CeTaskTypes.CE_TASK_PEND_MTI:
		case Codes.CeTaskTypes.CE_TASK_REPLY_MTI:
			return populateAppealTaskDetail(infringements);
		case Codes.CeTaskTypes.CE_TASK_RESCIND:
			return populateRescindTaskDetail(infringements);
		default:
			return null;
		}
	}

	private String populateRecommendationTaskDetail(Set<CeCaseInfringement> infringements) {
		Set<String> taskDetailSet = new HashSet<>();
		for (CeCaseInfringement infringement : infringements) {
			CeProvision ceProvision = infringement.getCeProvision();

			String taskDetail = null;
			if (ceProvision != null) {
				CeCaseRecommendation recommendation = infringement.getLastRecommendation();
				if (recommendation != null) {
					taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), recommendation.getOutcome(),
							recommendation.getPenaltyAmount(), recommendation.getPenaltyStatusStartDate(), recommendation.getPenaltyStatusEndDate(), null, null, null);
					if (Entities.anyEquals(recommendation.getOutcome(), Codes.CeRecommendation.OUTCOME_WITH_NOI_NOD)) {
						taskDetail = (taskDetail != null) ? "NOI - ".concat(taskDetail) : taskDetail;
					} else {
						taskDetail = (taskDetail != null) ? "Recommendation - ".concat(taskDetail) : taskDetail;
					}
				} else {
					taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), null, null, null, null, null, null, null);
				}
			}
			if (Strings.isNullOrEmpty(taskDetail)) {
				taskDetail = "Case pending recommendation.";
			}
			taskDetailSet.add(taskDetail);
		}

		return taskDetailSet.stream().collect(Collectors.joining(", "));
	}

	private String populateDecisionTaskDetail(Set<CeCaseInfringement> infringements) {
		Set<String> taskDetailSet = new HashSet<>();
		for (CeCaseInfringement infringement : infringements) {
			CeProvision ceProvision = infringement.getCeProvision();

			String taskDetail = null;
			CeCaseDecision decision = infringement.getLastDecision();
			if (decision != null) {

				LocalDate paymentDueDate = decision.getBillExpiryDate() != null ? decision.getBillExpiryDate().toLocalDate() : null;
				String paymentStatus = decision.getPaymentStatus() != null ? decision.getPaymentStatus().getLabel() : null;

				taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), decision.getOutcome(), decision.getPenaltyAmount(),
						decision.getPenaltyStatusStartDate(), decision.getPenaltyStatusEndDate(), paymentDueDate, paymentStatus, decision.getBillRefNo());
				if (Entities.anyEquals(decision.getOutcome(), Codes.CeRecommendation.OUTCOME_WITH_NOI_NOD)) {
					taskDetail = (taskDetail != null) ? "NOD - ".concat(taskDetail) : taskDetail;
				}
			} else {
				taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), null, null, null, null, null, null, null);
			}
			taskDetailSet.add(taskDetail);
		}

		return taskDetailSet.stream().collect(Collectors.joining(", "));
	}

	private String populateAppealTaskDetail(Set<CeCaseInfringement> infringements) {
		Set<String> taskDetailSet = new HashSet<>();
		for (CeCaseInfringement infringement : infringements) {
			CeProvision ceProvision = infringement.getCeProvision();

			String taskDetail = null;
			CeCaseDecision decision = ceCaseRepository.getDecisionById(infringement.getLastDecision().getId());
			CeCaseAppeal appeal = decision.getCeCaseAppeal();
			if (appeal != null) {

				LocalDate paymentDueDate = appeal.getBillExpiryDate() != null ? appeal.getBillExpiryDate().toLocalDate() : null;
				String paymentStatus = appeal.getPaymentStatus() != null ? appeal.getPaymentStatus().getLabel() : null;
				taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), appeal.getOutcome(), appeal.getPenaltyAmount(),
						appeal.getPenaltyStatusStartDate(), appeal.getPenaltyStatusEndDate(), paymentDueDate, paymentStatus, appeal.getBillRefNo());
				if (Entities.anyEquals(decision.getOutcome(), Codes.CeRecommendation.OUTCOME_WITH_NOI_NOD)) {
					taskDetail = (taskDetail != null) ? "MTI Decision - ".concat(taskDetail) : taskDetail;
				}
			} else {
				taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), null, null, null, null, null, null, null);
			}
			taskDetailSet.add(taskDetail);
		}

		return taskDetailSet.stream().collect(Collectors.joining(", "));
	}

	private String populateRescindTaskDetail(Set<CeCaseInfringement> infringements) {
		Set<String> taskDetailSet = new HashSet<>();
		for (CeCaseInfringement infringement : infringements) {
			CeProvision ceProvision = infringement.getCeProvision();

			String taskDetail = ceCaseHelper.populateInfringementTaskDetails(ceProvision.getChapter().getCode(), ceProvision.getSection(), null, null, null, null, null, null, null);
			taskDetailSet.add(taskDetail);
		}

		return taskDetailSet.stream().collect(Collectors.joining(", "));
	}

	public void completeCeTaskByWorkflow(Workflow workflow) {
		if (workflow != null) {
			ceTaskRepository.getOpenCeTasksByWorkflowId(workflow.getId()).forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void completeCeTaskByTaFilingCondition(TaFilingCondition taFilingCondition) {
		if (taFilingCondition != null) {
			ceTaskRepository.getOpenCeTasksByTaFilingConditionId(taFilingCondition.getId()).forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void completeCeTaskByInfringement(CeCaseInfringement infringement) {
		if (infringement != null) {
			ceTaskRepository.getOpenCeTasksByInfringementId(infringement.getId()).forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void completeCeTaskByScheduleMonth(Integer year, Integer month) {
		if (year != null && month != null) {
			ceTaskRepository.getOpenCeTasksByScheduleMonth(year, month).forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void completeCeTaskByScheduleWeek(Integer year, LocalDate fromDate, LocalDate toDate) {
		if (fromDate != null && toDate != null) {
			ceTaskRepository.getOpenCeTasksByScheduleWeek(year, fromDate, toDate).forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void completeCeTaskByLicence(Integer licenceId, String taskType, String taskStatus) {
		if (licenceId != null && taskType != null) {
			ceTaskRepository.getCeTasksByLicence(licenceId, taskType, taskStatus).forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void completeCeTaskByCeCase(CeCase ceCase, boolean isRescind) {
		List<CeTask> ceTasks = ceTaskRepository.getOpenCeTasksByCaseId(ceCase.getId(), isRescind);
		if (!CollectionUtils.isEmpty(ceTasks)) {
			ceTasks.forEach(ceTask -> completeCeTask(ceTask));
		}
	}

	public void completeOpenCeTaskByCeCase(CeCase ceCase) {
		List<CeTask> ceTasks = ceTaskRepository.getOpenCeTasksByCaseId(ceCase.getId());
		if (!CollectionUtils.isEmpty(ceTasks)) {
			ceTasks.forEach(ceTask -> completeCeTask(ceTask));
		}
	}

	public void completeCeTaskByCeIp(CeCase ceCase, boolean isPaymentExpiry) {
		List<CeTask> ceTasks = ceTaskRepository.getOpenCeTasksByIpId(ceCase.getId(), isPaymentExpiry);
		if (!CollectionUtils.isEmpty(ceTasks)) {
			ceTasks.forEach(ceTask -> completeCeTask(ceTask));
		}
	}

	public void completeSuspensionEndCeTask(Integer licenceId) {
		List<CeTask> ceTasks = ceTaskRepository.getOpenSuspensionEndCeTasksByLicenceId(licenceId);
		if (!CollectionUtils.isEmpty(ceTasks)) {
			ceTasks.forEach(ceTask -> completeCeTask(ceTask));
		}
	}

	public void completeCeTaskByType(String type) {
		List<CeTask> ceTasks = ceTaskRepository.getOpenCeTask(type, null);
		if (!CollectionUtils.isEmpty(ceTasks)) {
			ceTasks.forEach(ceTask -> completeCeTask(ceTask));
		}
	}

	public void updateCeTaskAssignee(Workflow workflow) {
		if (workflow != null) {
			ceTaskRepository.getOpenCeTasksByWorkflowId(workflow.getId()).forEach(ceTask -> {
				ceTask.setAssignee(workflow.getAssignee());
				ceTaskRepository.save(ceTask);
			});
		}
	}

	public List<CeTask> getCeTaskByTaFilingCondition(TaFilingCondition taFilingCondition) {
		return ceTaskRepository.getOpenCeTasksByTaFilingConditionId(taFilingCondition.getId());
	}

	public List<CeTask> getCeTasksByCaseId(Integer caseId, boolean isRescind) {
		return ceTaskRepository.getOpenCeTasksByCaseId(caseId, isRescind);
	}

	public List<CeTask> getCeTasksByIpId(Integer caseId, boolean isPaymentExpiry) {
		return ceTaskRepository.getOpenCeTasksByIpId(caseId, isPaymentExpiry);
	}

	public List<CeTask> getCeTasksByLicence(Integer licenceId, String taskType, String taskStatus) {
		return ceTaskRepository.getCeTasksByLicence(licenceId, taskType, taskStatus);
	}

	public void completeCeTaskByBill(String billRefNo) {
		if (billRefNo != null) {
			ceTaskRepository.getOpenCeTasksByBillRefNo(billRefNo).forEach(ceTask -> {
				completeCeTask(ceTask);
			});
		}
	}

	public void completeCeTask(CeTask ceTask) {
		if (ceTask != null) {
			logger.info("CeTask(id:{}, name:{}, status:{}, details:{}) set to completed.", ceTask.getId(), ceTask.getName(), ceTask.getStatus().getLabel(), ceTask.getDetails());
			ceTask.setStatus(cache.getStatus(Codes.CeTaskStatus.CE_TASK_COMPLETED));
			ceTaskRepository.save(ceTask);
		}
	}

	private void setLicenceDetails(Licence licence, CeTask ceTask) {
		if (licence != null) {
			if (licence.getTravelAgent() != null) {
				setLicenceDetails(licence.getTravelAgent(), null, ceTask);
			} else if (licence.getTouristGuide() != null) {
				setLicenceDetails(null, licence.getTouristGuide(), ceTask);
			}
		}
	}

	private void setLicenceDetails(TravelAgent ta, TouristGuide tg, CeTask ceTask) {
		if (ta != null) {
			ceTask.setName(ta.getName());
			ceTask.setUenUin(ta.getUen());
			ceTask.setLicence(ta.getLicence());
			ceTask.setIdType(cache.getType(Codes.Types.CE_ID_TYPE_ENTITY));
		} else if (tg != null) {
			ceTask.setName(tg.getName());
			ceTask.setUenUin(tg.getUin());
			ceTask.setLicence(tg.getLicence());
			ceTask.setIdType(cache.getType(Codes.Types.CE_ID_TYPE_INDIVIDUAL));
		}
	}

	private CeTask createCeTaskForWorkflow(Workflow workflow, Type taskType, String details, User oic, User assignee, LocalDate slaExpiryDate, Status status) {
		if (workflow == null) {
			logger.error("workflow is null");
			return null;
		}

		CeTask ceTask = new CeTask();
		ceTask.setForWorkflow(workflow);
		return createCeTask(ceTask, taskType, details, oic, assignee, slaExpiryDate, status, workflow.getLicence());
	}

	private CeTask createCeTaskForLicence(Licence licence, Type taskType, String details, User oic, User assignee, LocalDate slaExpiryDate, Status status) {
		if (licence == null) {
			logger.error("licence is null");
			return null;
		}
		return createCeTask(new CeTask(), taskType, details, oic, assignee, slaExpiryDate, status, licence);
	}

	private CeTask createCeTaskForCeSchedule(String taTg, Integer year, Integer month, LocalDate fromDate, LocalDate toDate, String name, Workflow workflow, Type taskType, String details, User oic,
			User assignee, LocalDate slaExpiryDate, Status status) {

		CeTask ceTask = null;
		Optional<CeTask> findCeTask = null;
		if (Codes.TaTgType.TA.equals(taTg)) {
			findCeTask = ceTaskRepository.getOpenCeTasksByScheduleMonth(year, month).stream().findFirst();
		} else if (Codes.TaTgType.TG.equals(taTg)) {
			findCeTask = ceTaskRepository.getOpenCeTasksByScheduleWeek(year, fromDate, toDate).stream().findFirst();
		}

		if (findCeTask.isPresent()) {
			ceTask = findCeTask.get();
		} else {
			ceTask = new CeTask();
		}

		ceTask.setName(name);
		ceTask.setForScheduleYear(year);
		ceTask.setForScheduleMonth(month);
		ceTask.setForScheduleFromDate(fromDate);
		ceTask.setForScheduleToDate(toDate);
		ceTask.setForWorkflow(workflow);
		return createCeTask(ceTask, taskType, details, oic, assignee, slaExpiryDate, status, null);
	}

	private CeTask createCeTaskForTaFilingCondition(TaFilingCondition taFilingCondition, Type taskType, String details, User oic, User assignee, LocalDate slaExpiryDate, Status status) {
		if (taFilingCondition == null) {
			logger.error("filingCondition is null");
			return null;
		}

		CeTask ceTask = new CeTask();
		ceTask.setForFilingCondition(taFilingCondition);
		return createCeTask(ceTask, taskType, details, oic, assignee, slaExpiryDate, status, taFilingCondition.getLicence());
	}

	private CeTask createCeTaskForCeCase(CeCase ceCase, Type taskType, String details, User oic, User assignee, LocalDate slaExpiryDate, Status status, CeCaseInfringer ceCaseInfringer,
			Workflow workflow) {
		if (ceCase == null) {
			logger.error("ceCase is null");
			return null;
		}

		CeTask ceTask = new CeTask();
		Licence lic = null;
		if (ceCaseInfringer != null) {
			lic = ceCaseInfringer.getLicence();
			if (lic == null) {
				ceTask.setName(ceCaseInfringer.getName());
				ceTask.setUenUin(ceCaseInfringer.getUenUin());
			}
		}

		if (workflow != null) {
			ceTask.setForWorkflow(workflow);
		}
		ceTask.setForCase(ceCase);
		return createCeTask(ceTask, taskType, details, oic, assignee, slaExpiryDate, status, lic);
	}

	private CeTask createCeTaskForPayment(Type taskType, String details, User oic, User assignee, LocalDate slaExpiryDate, Status status, String billRefNo, CeCase ceCase) {
		if (billRefNo == null) {
			logger.error("billRefNo is null");
			return null;
		}

		CeTask ceTask = new CeTask();
		ceTask.setForBillRefNo(billRefNo);
		ceTask.setForCase(ceCase);
		return createCeTask(ceTask, taskType, details, oic, assignee, slaExpiryDate, status, null);
	}

	private CeTask createCeTask(CeTask ceTask, Type taskType, String details, User oic, User assignee, LocalDate slaExpiryDate, Status status, Licence licence) {
		setLicenceDetails(licence, ceTask);
		ceTask.setType(taskType);
		ceTask.setDetails(details);
		ceTask.setOic(oic);
		ceTask.setAssignee(assignee);
		ceTask.setSlaExpiryDate(slaExpiryDate);
		ceTask.setStatus(status);
		ceTaskRepository.save(ceTask);

		return ceTask;
	}

	private LocalDate deriveSlaExpiryDateToRecommend(LocalDate fromDate) {
		Integer sla = cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_SLA_SUBMIT_RECOMMENDATION);
		return fromDate.plusDays(sla);
	}

	public LocalDate deriveSlaExpiryDate(LocalDate fromDate, String slaParam) {
		Integer sla = cache.getSystemParameterAsInteger(slaParam);
		return fromDate.plusDays(sla);
	}

	public String getMinimumFinancialRequirementProvisionCode(Licence licence) {
		if (Entities.anyEquals(licence.getTravelAgent().getFormOfBusiness(), Codes.Types.FOB_BUSINESS, Codes.Types.FOB_LIMITED_PARTNERSHIP)
				|| Entities.anyEquals(licence.getTravelAgent().getBusinessConstitution(), Codes.Types.BC_SOLE_PROPRIETORSHIP, Codes.Types.BC_PARTNERS)) {

			return Entities.equals(licence.getTier(), Codes.Types.TA_TIER_GENERAL) ? Codes.CeProvisionSection.MFR_NV_GENERAL_SOLE_PROPRIETOR_OR_PARTNER
					: Entities.equals(licence.getTier(), Codes.Types.TA_TIER_NICHE) ? Codes.CeProvisionSection.MFR_NV_NICHE_SOLE_PROPRIETOR_OR_PARTNER : null;

		} else {
			return Entities.equals(licence.getTier(), Codes.Types.TA_TIER_GENERAL) ? Codes.CeProvisionSection.MFR_NV_GENERAL_COMPANY
					: Entities.equals(licence.getTier(), Codes.Types.TA_TIER_NICHE) ? Codes.CeProvisionSection.MFR_NV_NICHE_COMPANY : null;
		}
	}

	private String formatProvision(String text, String provisionCode) {
		CeProvision ceProvision = ceProvisionRepository.getCeProvisionBySection(provisionCode);
		if (ceProvision != null) {
			return messageHelper.formatProvision(text, ceProvision.getChapter().getCode(), ceProvision.getSection());
		} else {
			return messageHelper.formatProvision(text, "", "");
		}
	}

	public void triggerTarR15Infringement(TravelAgent ta) {

		Integer duration = cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_TA_KE_VACANT_DURATION);

		// get the last resigned KE
		TaStakeholder lastResignedKe = taCommonRepository.getTaLastResignedKe(ta.getLicence().getId());
		TaStakeholder futureAppointedKe = taCommonRepository.getTaFutureAppointedKe(ta.getLicence().getId());

		LocalDate dateSinceKeisVacant = lastResignedKe != null ? lastResignedKe.getResignedDate() : ta.getLicence().getIssueDate();
		LocalDate baseCompareDate = futureAppointedKe == null ? LocalDate.now() : futureAppointedKe.getAppointedDate();

		if (dateSinceKeisVacant.plusMonths(duration).isBefore(baseCompareDate)) {
			logger.info("KE (Licence No.{}) is vacant for > {} months.", ta.getLicence().getLicenceNo(), duration);

			if (lastResignedKe == null) { // due to migration?
				// search for open case
				CeCaseInfringement liveInfringement = ceTaskRepository.searchKeR153bInfringementLiveCase(ta.getLicence().getId());
				if (liveInfringement == null) {
					logger.info("1. Create CeCase(R15(3)(b)) for Licence No. {}.", ta.getLicence().getLicenceNo());
					ceCaseHelper.createCaseForKeInfringement(null, ta.getLicence(), dateSinceKeisVacant, dateSinceKeisVacant.plusMonths(duration).plusDays(1), Codes.CeProvisionSection.KE_VACANT);
				}

			} else if (lastResignedKe.getTarR153bInfringement() == null) {
				logger.info("2. Create CeCase(R15(3)(b)) for Licence No. {}.", ta.getLicence().getLicenceNo());
				ceCaseHelper.createCaseForKeInfringement(lastResignedKe, ta.getLicence(), dateSinceKeisVacant, dateSinceKeisVacant.plusMonths(duration).plusDays(1),
						Codes.CeProvisionSection.KE_VACANT);

			}

		} else if (futureAppointedKe == null) {
			List<CeTask> ceTasks = getCeTasksByLicence(ta.getLicence().getId(), Codes.CeTaskTypes.CE_TASK_TAR_R15_3B, Codes.CeTaskStatus.CE_TASK_FOR_INFO);
			if (CollectionUtils.isEmpty(ceTasks)) {
				logger.info("(Licence No.{}) Creating task for info...", ta.getLicence().getLicenceNo());
				createCeTaskForKeVacant(ta.getLicence(), dateSinceKeisVacant, Messages.CeTaskDetails.R15_3B_KE_RESIGN, Codes.CeTaskStatus.CE_TASK_FOR_INFO);
			}
		}
	}
}
