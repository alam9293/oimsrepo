package gov.stb.tag.helper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.edh.AddressDto;
import gov.stb.tag.dto.edh.AppointmentDto;
import gov.stb.tag.dto.edh.EdhDto;
import gov.stb.tag.dto.edh.EdhEntityDto;
import gov.stb.tag.dto.edh.FinancialsDto;
import gov.stb.tag.dto.edh.ShareholderDto;
import gov.stb.tag.model.EdhSnapshot;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.EdhSnapshotRepository;
import gov.stb.tag.util.DateUtil;

@Component
@SuppressWarnings("unchecked")
public class EdhHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	private static ObjectMapper edhMapper = null;

	@Autowired
	CacheHelper cache;

	@Autowired
	EdhSnapshotRepository edhRepository;

	public static ObjectMapper getEdhMapper() {
		if (edhMapper == null) {
			edhMapper = new ObjectMapper();
			JavaTimeModule javaTimeModule = new JavaTimeModule();
			javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer(DateUtil.EDH_DATE_FORMAT));
			javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateUtil.EDH_DATE_FORMAT));
			edhMapper.registerModule(javaTimeModule);
		}
		return edhMapper;
	}

	public void saveRawResponse(String uen, String apiName, String jsonResponse) {
		EdhSnapshot snapshot = edhRepository.getByUenApiName(uen, apiName);
		if (snapshot == null) {
			snapshot = new EdhSnapshot();
			snapshot.setUen(uen);
			snapshot.setApiName(apiName);
		}
		snapshot.setResponsePayload(jsonResponse);
		edhRepository.saveOrUpdate(snapshot);
	}

	public EdhEntityDto getEdhEntityByUen(String uen) {
		EdhSnapshot snapshot = edhRepository.getByUenApiName(uen, Codes.Edh.API_ENTITY);
		if (snapshot == null) {
			logger.error("getEdhEntityByUen(): no record for uen: " + uen);
			return null;
		} else {
			return parseEntityRawResponse(new EdhEntityDto(), snapshot.getResponsePayload());
		}
	}

	public EdhEntityDto parseEntityRawResponse(EdhEntityDto dto, String jsonResponse) {
		try {
			dto = getEdhMapper().readValue(jsonResponse, EdhEntityDto.class);

			// TODO: mapping of master data from EDH to TAG, if any
			if (dto.getBasic().getEntityStatusCode() != null && !dto.getBasic().getEntityStatusCode().isEmpty()) {
				String entityStatusCode = dto.getBasic().getEntityStatusCode();
				String entityType = dto.getBasic().getEntityType();
				String entityStatucCodeCategory = "EDH_SOE_".concat(entityType);
				Optional<Type> opType = cache.getTypesByCategory(entityStatucCodeCategory).stream().filter(o -> o.getLabel().equalsIgnoreCase(entityStatusCode)).findFirst();
				if (opType.isPresent()) {
					String tagCode = opType.get().getMappingCode();
					dto.getBasic().setEntityStatusCode(tagCode);
				} else {
					logger.error("TAG code mapping is not configured for entity status code: {} with entity type: {}", entityStatusCode, entityType);
				}
			}
			if (dto.getBasic().getEntityType() != null && !dto.getBasic().getEntityType().isEmpty()) {
				String value = dto.getBasic().getEntityType();
				Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.EDH_FOB).stream().filter(o -> o.getLabel().equalsIgnoreCase(value)).findFirst();
				if (opType.isPresent()) {
					String tagCode = opType.get().getMappingCode();
					dto.getBasic().setEntityType(tagCode);
				} else {
					logger.error("TAG code mapping is not configured for entity type: " + value);
				}
			}

			if (dto.getBasic().getPrimaryActivityCode() != null && !dto.getBasic().getPrimaryActivityCode().isEmpty()) {
				String value = dto.getBasic().getPrimaryActivityCode();
				Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.EDH_PA).stream().filter(o -> o.getLabel().equalsIgnoreCase(value)).findFirst();
				if (opType.isPresent()) {
					String tagCode = opType.get().getMappingCode();
					dto.getBasic().setPrimaryActivityCode(tagCode);
				} else {
					logger.error("TAG code mapping is not configured for primary activity code: " + value);
				}
			}

			if (dto.getBasic().getSecondaryActivityCode() != null && !dto.getBasic().getSecondaryActivityCode().isEmpty()) {
				String value = dto.getBasic().getSecondaryActivityCode();
				Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.EDH_PA).stream().filter(o -> o.getLabel().equalsIgnoreCase(value)).findFirst();
				if (opType.isPresent()) {
					String tagCode = opType.get().getMappingCode();
					dto.getBasic().setSecondaryActivityCode(tagCode);
				} else {
					logger.error("TAG code mapping is not configured for secondary activity code: " + value);
				}
			}

			if (dto.getBasic().getBusinessConstitutionCode() != null && !dto.getBasic().getBusinessConstitutionCode().isEmpty()) {
				String value = dto.getBasic().getBusinessConstitutionCode();
				Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.EDH_BC).stream().filter(o -> o.getLabel().equalsIgnoreCase(value)).findFirst();
				if (opType.isPresent()) {
					String tagCode = opType.get().getMappingCode();
					dto.getBasic().setBusinessConstitutionCode(tagCode);
				} else {
					logger.error("TAG code mapping is not configured for business constitution code: " + value);
				}
			} else {
				dto.getBasic().setBusinessConstitutionCode(Codes.Types.BC_OTHERS);
			}

			List<AddressDto> addressDtoList = dto.getAddresses();
			List<AddressDto> toRemoveCorrespondance = new ArrayList<>();
			for (AddressDto address : addressDtoList) {
				if (address.getCorrespondencePurpose() != null) {
					toRemoveCorrespondance.add(address);
				} else {
					parseEntityAddressRawResponse(dto, address);
				}

			}
			addressDtoList.removeAll(toRemoveCorrespondance);

		} catch (Exception e) {
			handleEdhParseError(dto, e.getMessage(), "parseEntityRawResponse()");
		}
		return dto;
	}

	public EdhDto<AppointmentDto> parseEntityAppointmentsRawResponse(EdhDto<AppointmentDto> dto, String jsonResponse) {
		try {
			List<AppointmentDto> list = getEdhMapper().readValue(jsonResponse, new TypeReference<List<AppointmentDto>>() {
			});
			dto.setRecords(list);
			// TODO: mapping of master data from EDH to TAG, if any
			for (AppointmentDto appointmentDto : list) {
				if (appointmentDto.getAddressOfAppointed() != null) {
					parseEntityAddressRawResponse(dto, appointmentDto.getAddressOfAppointed());
				}
				if (appointmentDto.getPositionHeld() != null && !appointmentDto.getPositionHeld().isEmpty()) {
					String value = appointmentDto.getPositionHeld();
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.EDH_ROLE).stream().filter(o -> o.getLabel().equalsIgnoreCase(value)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						appointmentDto.setPositionHeld(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for role: " + value);
					}
				}

			}

		} catch (Exception e) {
			handleEdhParseError(dto, e.getMessage(), "parseEntityAppointmentsRawResponse()");
		}
		return dto;
	}

	public EdhDto<ShareholderDto> parseEntityShareholdersRawResponse(EdhDto<ShareholderDto> dto, String jsonResponse) {
		try {
			List<ShareholderDto> list = getEdhMapper().readValue(jsonResponse, new TypeReference<List<ShareholderDto>>() {
			});
			dto.setRecords(list);
			// TODO: mapping of master data from EDH to TAG, if any
			for (ShareholderDto shareholderDto : list) {
				if (shareholderDto.getAddressOfAlloted() != null) {
					parseEntityAddressRawResponse(dto, shareholderDto.getAddressOfAlloted());
				}
			}
		} catch (Exception e) {
			handleEdhParseError(dto, e.getMessage(), "parseEntityShareholdersRawResponse()");
		}
		return dto;
	}

	public FinancialsDto parseEntityFinancialsRawResponse(FinancialsDto dto, String jsonResponse) {
		try {
			dto = getEdhMapper().readValue(jsonResponse, FinancialsDto.class);
			// TODO: mapping of master data from EDH to TAG, if any
		} catch (Exception e) {
			handleEdhParseError(dto, e.getMessage(), "parseEntityFinancialsRawResponse()");
		}
		return dto;
	}

	private void handleEdhParseError(EdhDto<?> dto, String errorMessage, String methodName) {
		dto.setHasError(true);
		dto.setErrorMessage(errorMessage);
		logger.error(methodName + ": " + errorMessage);
	}

	private void parseEntityAddressRawResponse(EdhDto<?> dto, AddressDto address) {
		String standard = address.getStandard();
		String type = address.getType();
		if ("D".equals(standard) || "N".equals(standard) || "L".equals(standard)) {
			address.setType(Codes.Types.ADDR_LOCAL);
		} else if ("F".equals(standard)) {
			address.setType(Codes.Types.ADDR_FOREIGN);
		} else {
			Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.EDH_ADDR).stream().filter(o -> o.getLabel().equalsIgnoreCase(type)).findFirst();
			if (opType.isPresent()) {
				String tagCode = opType.get().getMappingCode();
				address.setType(tagCode);
			} else {
				logger.error("TAG code mapping is not configured for address type: " + type);
				logger.error("TAG code mapping is not configured for address standard: " + standard);
				if (address.getPostalCode() != null) {
					address.setType(Codes.Types.ADDR_LOCAL);
				} else {
					address.setType(Codes.Types.ADDR_FOREIGN);
				}

			}
		}
	}
}
