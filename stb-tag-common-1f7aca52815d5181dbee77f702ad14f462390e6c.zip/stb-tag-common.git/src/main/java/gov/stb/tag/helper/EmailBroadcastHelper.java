package gov.stb.tag.helper;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.EmailBroadcastFrequency;
import gov.stb.tag.constant.Codes.EmailBroadcastType;
import gov.stb.tag.constant.Codes.Placeholders;
import gov.stb.tag.constant.Codes.TaStakeholderRoles;
import gov.stb.tag.constant.Codes.TaTgType;
import gov.stb.tag.dto.EmailLicenseeDto;
import gov.stb.tag.dto.EmailRecipientDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.repository.EmailBroadcastCommonRepository;
import gov.stb.tag.repository.TaCommonRepository;

@Component
public class EmailBroadcastHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	TaCommonRepository taCommonRepository;
	@Autowired
	MessageHelper messageHelper;
	@Autowired
	EmailHelper emailHelper;
	@Autowired
	FileHelper fileHelper;
	@Autowired
	CacheHelper cache;
	@Autowired
	EmailBroadcastCommonRepository emailBroadcastRepository;

	public LocalDate calculateNextDate(Boolean isRecurring, String freqCode, LocalDate currentDate) {
		LocalDate newDate = currentDate;
		if (currentDate != null) {
			if (isRecurring) {
				switch (freqCode) {
				case EmailBroadcastFrequency.DAILY:
					newDate = currentDate.plusDays(1);
					break;
				case EmailBroadcastFrequency.WEEKLY:
					newDate = currentDate.plusDays(7);
					break;
				case EmailBroadcastFrequency.MONTHLY:
					newDate = currentDate.plusMonths(1);
					break;
				case EmailBroadcastFrequency.YEARLY:
					newDate = currentDate.plusYears(1);
					break;
				}
			}
		}

		return newDate;
	}

	public EmailBroadcast sendBroadcastEmail(EmailBroadcast email) {
		String subject = null;
		String content = null;
		String from = null;
		List<String> recipients = new ArrayList<String>();
		List<EmailLicenseeDto> emailRecipients = null;

		Set<gov.stb.tag.model.File> fileModelList = email.getFiles();
		List<FileDto> fileList = new ArrayList<FileDto>();
		if (fileModelList != null) {
			for (gov.stb.tag.model.File file : fileModelList) {
				fileList.add(FileDto.buildWithPhysicalFile(file, fileHelper.getPhyiscalFile(file)));
			}

		}

		if (EmailBroadcastType.TA.equalsIgnoreCase(email.getType().getCode())) {
			emailRecipients = emailBroadcastRepository.getActiveTaLicences();
			from = cache.getSystemParameterAsString(Codes.SupportEmail.get(TaTgType.TA));

			if (emailRecipients != null && !emailRecipients.isEmpty()) {
				boolean hasAdvancedPlaceholder = false;
				for (String placeholder : Codes.EmailBroadcastComplicatedPlaceholders) {
					if (email.getContent().contains(placeholder) || email.getSubject().contains(placeholder)) {
						hasAdvancedPlaceholder = true;
						break;
					}
				}
				for (EmailLicenseeDto activeLicence : emailRecipients) {
					Stakeholder stakeholderModel = taCommonRepository.getExistingKe(activeLicence.getLicenceId());

					if (hasAdvancedPlaceholder) {
						activeLicence = EmailLicenseeDto.buildAdvancedFromLicence(taCommonRepository.get(TravelAgent.class, activeLicence.getTravelAgentId()), activeLicence);
						activeLicence.setRecipient(EmailRecipientDto.buildForRecipient(stakeholderModel, new EmailRecipientDto()));

						if (email.getContent().contains(Placeholders.DIRECTOR_NAME)) {// Need to get the string[] of directors for the TA
							List<ListableDto> dirNames = taCommonRepository.getTaStakeholdersByRole(TaStakeholderRoles.STKHLD_DIRECTOR, activeLicence.getLicenceId());
							activeLicence.setDirName(String.join(", ", dirNames.stream().map(ListableDto::getLabel).collect(Collectors.toList())));
						}
					}

					subject = messageHelper.formatEmailBroadcastPlaceholders(email.getSubject(), activeLicence, stakeholderModel);
					content = messageHelper.formatEmailBroadcastPlaceholders(email.getContent(), activeLicence, stakeholderModel);
					content = messageHelper.formatSignaturePlaceholders(content, null);
					recipients = Lists.newArrayList(activeLicence.getEmail());
					if (stakeholderModel != null) {
						recipients.add(stakeholderModel.getEmail()); // send the email to the TA's KE also. For now send to TA's company email and KE's email. in the future user may want to send to
																		// director email also. so now recipient in DTO only store KE
					}
					// 4. Send email and create email log
					sendEmail(email, from, subject, content, fileList, fileModelList, email.getId(), activeLicence.getLicNo(), activeLicence.getLicenceId(),
							recipients.toArray(new String[recipients.size()]));
				}
			}
			// Send email to sender for record purposes
			sendEmail(email, from, email.getSubject(), messageHelper.formatSignaturePlaceholders(email.getContent(), null), fileList, fileModelList, email.getId(), null, null, from);

		}

		if (EmailBroadcastType.TG.equalsIgnoreCase(email.getType().getCode())) {
			emailRecipients = emailBroadcastRepository.getListOfTgLicence(email);
			from = cache.getSystemParameterAsString(Codes.SupportEmail.get(TaTgType.TG));

			if (emailRecipients != null && !emailRecipients.isEmpty()) {
				for (EmailLicenseeDto emailRecipient : emailRecipients) {
					subject = formatTgPlaceholdersWithSalutations(email.getSubject(), emailRecipient);
					content = formatTgPlaceholdersWithSalutations(email.getContent(), emailRecipient);
					content = messageHelper.formatSignaturePlaceholders(content, null);
					// 4. Send email and create email log
					sendEmail(email, from, subject, content, fileList, fileModelList, email.getId(), emailRecipient.getLicNo(), emailRecipient.getLicenceId(), emailRecipient.getEmail());
				}
			}
			// Send email to sender for record purposes
			sendEmail(email, from, email.getSubject(), messageHelper.formatSignaturePlaceholders(email.getContent(), null), fileList, fileModelList, email.getId(), null, null, from);
		}

		logger.info("TotalEmailSent = {}", emailRecipients.size());

		return email;
	}

	public EmailBroadcast updateAfterSent(EmailBroadcast email, LocalDate today) {
		email.setLastSentDateTime(LocalDateTime.now());
		// Set the next email date
		if (email.isActive()) {
			if (email.isRecurring()) {
				LocalDate nextDate = calculateNextDate(email.isRecurring(), email.getFrquency().getCode(), email.getNextEmailDate());
				if (email.getEndDate().isAfter(nextDate) || email.getEndDate().equals(nextDate)) {
					email.setNextEmailDate(nextDate);
				} else {
					email.setNextEmailDate(null);
				}
			} else if (email.getStartDate().isAfter(today)) {
				email.setNextEmailDate(email.getStartDate());
			} else {
				email.setNextEmailDate(null);
			}
			if (email.getNextEmailDate() == null) {
				email.setIsActive(Boolean.FALSE);
			}
		}
		email.setIsSending(false);
		return email;
	}

	public void sendEmail(EmailBroadcast emailBroadcast, String from, String subject, String content, List<FileDto> fileList, Set<gov.stb.tag.model.File> fileModelList, Integer modelId, String licNo,
			Integer licId, String... recipient) {
		try {
			if (fileList != null && fileList.size() > 0) {
				emailHelper.emailUsingFileDto(from, subject, content, fileList, recipient);
			} else {
				emailHelper.emailWithFrom(from, subject, content, recipient);
			}
			logger.info("Success Broadcast Email sent for: id = {}, Licence no= {}, Licence id = {}, email={}", modelId, licNo, licId, recipient);
			emailHelper.logEmailBroadcast(emailBroadcast, Codes.Statuses.EMAIL_SENT, from, subject, content, null, fileModelList != null ? fileList : null, null, recipient);
			taCommonRepository.commit();
		} catch (Exception e) {
			logger.info("Failed Broadcast Email sent for: id = {}, Licence no= {}, Licence id = {}, email={}", modelId, licNo, licId, recipient);
			emailHelper.logEmailBroadcast(emailBroadcast, Codes.Statuses.EMAIL_FAILED, from, subject, content, null, fileModelList != null ? fileList : null, null, recipient);
			taCommonRepository.commit();
			logger.error(e.getMessage());
		}
	}

	public String formatTgPlaceholdersWithSalutations(String text, EmailLicenseeDto dto) {
		text = messageHelper.replace(text, Codes.Placeholders.TG_NAME, dto.getSalutation() + " " + dto.getName());
		return text;
	}

}
