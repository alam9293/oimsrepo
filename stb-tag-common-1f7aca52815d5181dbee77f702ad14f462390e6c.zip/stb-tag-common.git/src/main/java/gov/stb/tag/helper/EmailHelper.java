package gov.stb.tag.helper;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeProvision;
import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.model.EmailLog;
import gov.stb.tag.model.EmailTemplate;
import gov.stb.tag.model.Job;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRefund;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFilingConditionEmailLog;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.TaLicenceRenewalExerciseTa;
import gov.stb.tag.model.TaLicenceRenewalExerciseTaEmailLog;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.TgLicenceExpiryNotificationEmailLog;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.EmailRepository;
import gov.stb.tag.repository.TaCommonRepository;

@Component
@Transactional
public class EmailHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private static final String EMAIL_FOOTER = "<p>*** This is an automatically generated email, please do not reply ***";

	@Autowired
	CacheHelper cache;
	@Autowired
	Properties properties;
	@Autowired
	JavaMailSender emailSender;
	@Autowired
	EmailRepository repository;
	@Autowired
	MessageHelper messageHelper;
	@Autowired
	TaCommonRepository taCommonRepository;

	/**
	 * @author siewhoon.koh
	 * 
	 *         This method is used for sending email to licensee for filing condition amendment.
	 * 
	 *         Generic Email Template: Codes.EmailType.TA_UPON_APPROVAL / Codes.EmailType.TA_UPON_RFA etc
	 * 
	 *         If you require specific messages such as "You are reminded to return your licences by DD-MMM-YYYY" for Cessation Applications, suggest to create your own Email Template
	 */
	public void emailTaForFilingConditionAmend(Licence lic, String emailTemplate, String filingChanges) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		if (lic.getTravelAgent() != null) {
			subject = messageHelper.formatTaPlaceholders(subject, lic.getTravelAgent());
			body = messageHelper.formatTaPlaceholders(body, lic.getTravelAgent());
		}

		body = messageHelper.replaceHTML(body, Codes.Placeholders.TA_FILING_AMENDED_LIST, filingChanges);
		body = messageHelper.formatSignaturePlaceholders(body, null);

		// 3. Get ke email
		Stakeholder stakeholderModel = new Stakeholder();
		stakeholderModel = taCommonRepository.getExistingKe(lic.getId());

		List<String> recipients = Lists.newArrayList(lic.getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		try {
			email(subject, body, recipients.toArray(recipient));
			log(null, null, template, null, null, Codes.Statuses.EMAIL_SENT, null, recipient, null, null, subject, body);
		} catch (Exception e) {
			log(null, null, template, null, null, Codes.Statuses.EMAIL_FAILED, null, recipient, null, null, subject, body);
			logger.error(e.getMessage());
		}
	}

	/**
	 * @author siewhoon.koh
	 * 
	 *         This method is used for sending email to licensee for adhoc request.
	 * 
	 *         Generic Email Template: Codes.EmailType.TA_UPON_APPROVAL / Codes.EmailType.TA_UPON_RFA etc
	 * 
	 *         If you require specific messages such as "You are reminded to return your licences by DD-MMM-YYYY" for Cessation Applications, suggest to create your own Email Template
	 */
	public void emailTaForFilingSubmission(TaFilingCondition filing, String emailTemplate, String url) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		if (filing.getLicence().getTravelAgent() != null) {
			subject = messageHelper.formatTaPlaceholders(subject, filing.getLicence().getTravelAgent());
			body = messageHelper.formatTaPlaceholders(body, filing.getLicence().getTravelAgent());
		}
		if (filing.getLicence().getTouristGuide() != null) {
			subject = messageHelper.formatTgPlaceholders(subject, filing.getLicence().getTouristGuide());
			body = messageHelper.formatTgPlaceholders(body, filing.getLicence().getTouristGuide());
		}
		subject = messageHelper.formatTaFilingConditionTaskPlaceholders(subject, filing);
		body = messageHelper.formatTaFilingConditionTaskPlaceholders(body, filing);
		body = messageHelper.formatUrlPlaceholders(body, url);
		body = messageHelper.formatSignaturePlaceholders(body, null);

		// 3. Get ke email
		Stakeholder stakeholderModel = new Stakeholder();
		stakeholderModel = taCommonRepository.getExistingKe(filing.getLicence().getId());

		List<String> recipients = Lists.newArrayList(filing.getLicence().getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		try {
			email(subject, body, recipients.toArray(recipient));
			log(filing.getLicence(), template, null, Codes.Statuses.EMAIL_SENT, subject, body, recipient);
		} catch (Exception e) {
			log(filing.getLicence(), template, null, Codes.Statuses.EMAIL_FAILED, subject, body, recipient);
			logger.error(e.getMessage());
		}
	}

	/**
	 * @author shery.the
	 *
	 *         This method is used for sending email to licensee for proof of shortfall rectification
	 *
	 *         Generic Email Template: Codes.EmailType.TA_UPON_APPROVAL / Codes.EmailType.TA_UPON_RFA etc
	 *
	 *         If you require specific messages such as "You are reminded to return your licences by DD-MMM-YYYY" for Cessation Applications, suggest to create your own Email Template
	 */
	public void emailTaForShortfallRectificationSubmission(Licence licence, TaNetValueShortfall shortfall, File shortfallLetter, String url) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, Codes.EmailType.TA_APP_NET_VALUE_RECTIFICATION_SUBMISSION_NOTIFY);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		if (shortfall.getWorkflow().getLicence().getTravelAgent() != null) {
			subject = messageHelper.formatTaPlaceholders(subject, licence.getTravelAgent());
			body = messageHelper.formatTaPlaceholders(body, licence.getTravelAgent());
		}
		subject = messageHelper.formatShortfallNotifyEmailPlaceholders(subject, shortfall);
		body = messageHelper.formatShortfallNotifyEmailPlaceholders(body, shortfall);
		body = messageHelper.formatUrlPlaceholders(body, url);
		body = messageHelper.formatSignaturePlaceholders(body, null);

		// 3. Get ke email
		Stakeholder stakeholderModel = taCommonRepository.getExistingKe(licence.getId());

		List<String> recipients = Lists.newArrayList(licence.getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		try {
			email(subject, body, new File[] { shortfallLetter }, recipients.toArray(recipient));
			log(licence, template, Codes.Statuses.EMAIL_SENT, subject, body, recipient, new File[] { shortfallLetter });
		} catch (Exception e) {
			log(licence, template, null, Codes.Statuses.EMAIL_FAILED, subject, body, recipient);
			logger.error(e.getMessage());
		}
	}

	public void emailUponPayment(PaymentTxn txn, String emailTemplate) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		subject = messageHelper.formatPaymentPlaceholders(subject, txn);
		body = messageHelper.formatPaymentPlaceholders(body, txn);

		// 3. Get email address
		List<String> recipients = Lists.newArrayList(txn.getPaymentRequests().stream().findFirst().get().getUserField2());
		String[] recipient = recipients.toArray(new String[recipients.size()]);

		// 4. Send email and create email log
		try {
			email(subject, body, recipients.toArray(recipient));
			log(template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
			logger.info("[Payment Receipt]: Email sent to {}", Arrays.toString(recipient));
		} catch (Exception e) {
			log(template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailTaRenewalUponAction(Application app, String emailTemplate, String url, BigDecimal appAmount, BigDecimal branchAppAmount) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		if (app.getLicence().getTravelAgent() != null) {
			subject = messageHelper.formatTaPlaceholders(subject, app.getLicence().getTravelAgent());
			body = messageHelper.formatTaPlaceholders(body, app.getLicence().getTravelAgent());
		}
		subject = messageHelper.formatAppPlaceholders(subject, app, url, null);
		body = messageHelper.formatAppPlaceholders(body, app, url, appAmount, branchAppAmount);

		// 3. Get ke email
		Stakeholder stakeholderModel = new Stakeholder();
		stakeholderModel = taCommonRepository.getExistingKe(app.getLicence().getId());

		List<String> recipients = Lists.newArrayList(app.getLicence().getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		try {
			email(subject, body, recipients.toArray(recipient));
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	/**
	 * @author verlin.lim
	 * 
	 *         This method is used for sending email upon approval/rfa/rejection for TA applications with payment amount if required.
	 * 
	 *         Generic Email Template: Codes.EmailType.TA_UPON_APPROVAL / Codes.EmailType.TA_UPON_RFA etc
	 * 
	 *         If you require specific messages such as "You are reminded to return your licences by DD-MMM-YYYY" for Cessation Applications, suggest to create your own Email Template
	 */
	public void emailTaUponAction(Application app, String emailTemplate, String url, BigDecimal appAmount) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		if (app.getLicence().getTravelAgent() != null) {
			subject = messageHelper.formatTaPlaceholders(subject, app.getLicence().getTravelAgent());
			body = messageHelper.formatTaPlaceholders(body, app.getLicence().getTravelAgent());
		}
		if (app.getLicence().getTouristGuide() != null) {
			subject = messageHelper.formatTgPlaceholders(subject, app.getLicence().getTouristGuide());
			body = messageHelper.formatTgPlaceholders(body, app.getLicence().getTouristGuide());
		}
		subject = messageHelper.formatAppPlaceholders(subject, app, url, null);
		body = messageHelper.formatAppPlaceholders(body, app, url, appAmount);

		// 3. Get ke email
		Stakeholder stakeholderModel = new Stakeholder();
		stakeholderModel = taCommonRepository.getExistingKe(app.getLicence().getId());

		List<String> recipients = Lists.newArrayList(app.getLicence().getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		try {
			email(subject, body, recipients.toArray(recipient));
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	/**
	 * @author verlin.lim
	 * 
	 *         This method is used for sending email upon approval/rfa/rejection for TA applications.
	 * 
	 *         Generic Email Template: Codes.EmailType.TA_UPON_APPROVAL / Codes.EmailType.TA_UPON_RFA etc
	 * 
	 *         If you require specific messages such as "You are reminded to return your licences by DD-MMM-YYYY" for Cessation Applications, suggest to create your own Email Template
	 */
	public void emailTaUponAction(Application app, String emailTemplate, String url) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		// CR12207
		boolean isinfoGraphics = true; // hardcoded
		if (isinfoGraphics == true && emailTemplate.equals(Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED)) {
			String htmlText = "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"table-layout: fixed;\" align=\"center\"><tr> <td>" + "<div style =\"width: 100%; font-size: 15px;\">"
					+ " <topImage>" + "" + "" + "<table><tr><td width=\"10%\"></td><td width=\"80%\"><p style =\"font-family: \"metropolis bold\" \">Dear travel agent, <br><br><br>"
					+ "Your ${app_type} submission has been reviewed. <br>" + "You are <b>now eligible to renew</b> your licence.</p></td><td width=\"10%\"></td></tr></table>" + "<br>"
					+ "<table width=\"100%\"><tr><td width=\"10%\"></td><td width=\"90%\" bgcolor =\"#ffffff\">"
					+ "<p> <span style=\"text-align: center;font-family: metropolis bold;color: #00817b; font-size: 26px\"><b> Log on to <a href=\"https://trust.stb.gov.sg/site/content/tagaem/landing-page.html\">TRUST</a> to renew in 2 easy steps :</span></p></td><td width=\"30%\"></td></tr></table>"
					+ "<br>" + " <midImage> <table><td width=\"10%\"></td><td width=\"80%\">"
					+ "<p><span style=\"font-family: metropolis bold; font-size: 16px\">For <a href=\"https://www.corppass.gov.sg/corppass/common/contactus\">Corppass</a> related enquires and assistance, you may <br> approach Corppass directly.</span> </p>"

					+ "<p><span style=\"font-family: metropolis bold; font-size: 16px\"> For other enquires and assistance, you may contact us at : </span></p>" + "<br>"

					+ "<table><tr><td><emailImage></td><td> <span style=\"font-family: metropolis bold; font-size: 18px\">Stb_ta@stb.gov.sg </span></td></tr></table>"
					+ "<br><table><tr><td> <phoneImage> </td><td bgcolor =\"#ffffff\"> <span style=\"font-family: metropolis bold; font-size: 18px\">6831 3871 </span></td></tr></table>"

					+ "<br><br><br>" + "<p><span style=\"font-family: metropolis bold; font-size: 16px\">Thank You.</span></p>" + " </br></br>"
					+ "<p><span style=\"font-family: metropolis bold; font-size: 16px\"><b><em>Travel Agent Licensing & Regulatory Review Department</em></b></span></p>"
					+ "</br><p><span style=\"font-family: metropolis bold; font-size: 16px\"><b><em>Singapore Tourism Board</em></b></span></p>" + " </div>"
					+ "</td><td width=\"10%\"></td></tr></table></td></tr></table></body>";

			Path currentRelativePath = Paths.get("");
			String path = currentRelativePath.toAbsolutePath().toString() + "\\src\\main\\resources\\" + "infoGraphics\\";

			String topImage = "<div style =\"width: 100%; height 15%; \">  <img src=\"cid:fdsTopImage\"> </div>";
			String midImage = "<div style =\"width: 100%; height 20%; \"> <img src=\"cid:fdsMidImage\"> </div>";
			String emailImage = "<div style =\"float: left;padding: 5px;  \">  <img src=\"cid:fdsEmailImage\"> </div>";
			String phoneImage = "<div style =\"float: left;padding: 5px; \"> <img src=\"cid:fdsPhoneImage\"> </div>";

			htmlText = htmlText.replace("<topImage>", topImage);
			htmlText = htmlText.replace("<midImage>", midImage);
			htmlText = htmlText.replace("<emailImage>", emailImage);
			htmlText = htmlText.replace("<phoneImage>", phoneImage);
			htmlText = htmlText.replace(Codes.Placeholders.APP_TYPE, app.getType().getLabel());
			body = htmlText;
		}

		if (app.getLicence().getTravelAgent() != null) {
			subject = messageHelper.formatTaPlaceholders(subject, app.getLicence().getTravelAgent());
			body = messageHelper.formatTaPlaceholders(body, app.getLicence().getTravelAgent());
		}
		if (app.getLicence().getTouristGuide() != null) {
			subject = messageHelper.formatTgPlaceholders(subject, app.getLicence().getTouristGuide());
			body = messageHelper.formatTgPlaceholders(body, app.getLicence().getTouristGuide());
		}
		subject = messageHelper.formatAppPlaceholders(subject, app, url, null);

		body = messageHelper.formatAppPlaceholders(body, app, url, null);

		// 3. Get ke email
		Stakeholder stakeholderModel = new Stakeholder();
		stakeholderModel = taCommonRepository.getExistingKe(app.getLicence().getId());

		List<String> recipients = Lists.newArrayList(app.getLicence().getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		if (isinfoGraphics == true && !emailTemplate.equals(Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED)) {

			try {
				emailNoFooter(subject, body, recipients.toArray(recipient));
				log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
			} catch (Exception e) {
				log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
				logger.error(e.getMessage());
			}
		}
		if (isinfoGraphics == true && emailTemplate.equals(Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED)) {

			Preconditions.checkNotNull(properties.email);
			Preconditions.checkNotNull(properties.catchAllEmail);
			// MimeMessage message = emailSender.createMimeMessage();
			MimeMessageHelper helper;
			MimeMessage message = emailSender.createMimeMessage();

			try {
				// Path currentRelativePath = Paths.get("");
				// String path = currentRelativePath.toAbsolutePath().toString() + "/src/main/resources/" + "infoGraphics/";
				// String absolutePath = file.getAbsolutePath();

				// Path resourceDirectory = Paths.get("webapps", "webservice-admin", "WEB-INF", "classes", "infoGraphics");
				/// String absolutePath = resourceDirectory.toFile().getAbsolutePath();
				// absolutePath = absolutePath.replace("/bin", "");
				// String path = absolutePath + "/";

				String path = properties.infographic;
				logger.error("path " + path);
				logger.info("path " + path);
				logger.debug("path " + path);

				String topImage = path + "TopBannerRenewalUponApproval.png";
				String midImage = path + "MidBannerRenewalUponApproval.png";
				String emailImage = path + "emailImage.png";
				String phoneImage = path + "phoneImage.png";

				// Set From: header field of the header.
				message.setFrom(new InternetAddress("noreply@stb.gov.sg"));

				InternetAddress[] recipientAddress = new InternetAddress[recipient.length];

				int counter = 0;
				for (String rec : recipient) {
					recipientAddress[counter] = new InternetAddress(rec.trim());
					logger.error("send to " + recipient);
					counter++;
				}
				// recipientAddress[counter+] = new InternetAddress("jacobchuayongli@gmail.com");
				// Set To: header field of the header.

				InternetAddress bcc = new InternetAddress("tag-support@wizvision.com");

				message.setRecipients(Message.RecipientType.TO, recipientAddress);

				message.setRecipient(Message.RecipientType.BCC, bcc);
				// Set Subject: header field
				message.setSubject(subject);

				// This mail has 2 part, the BODY and the embedded image
				MimeMultipart multipart = new MimeMultipart("related");

				// first part (the html)
				BodyPart messageBodyPart = new MimeBodyPart();

				messageBodyPart.setContent(body, "text/html");
				// add it
				multipart.addBodyPart(messageBodyPart);

				// second part (the image)

				// 1
				messageBodyPart = new MimeBodyPart();
				DataSource fdsTopImage = new FileDataSource(topImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsTopImage));
				messageBodyPart.setHeader("Content-ID", "<fdsTopImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// 2
				messageBodyPart = new MimeBodyPart();
				DataSource fdsMidImage = new FileDataSource(midImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsMidImage));
				messageBodyPart.setHeader("Content-ID", "<fdsMidImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// 3
				messageBodyPart = new MimeBodyPart();
				DataSource fdsEmailImage = new FileDataSource(emailImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsEmailImage));
				messageBodyPart.setHeader("Content-ID", "<fdsEmailImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// 4
				messageBodyPart = new MimeBodyPart();
				DataSource fdsPhoneImage = new FileDataSource(phoneImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsPhoneImage));
				messageBodyPart.setHeader("Content-ID", "<fdsPhoneImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// put everything together
				message.setContent(multipart);

				logger.error("info graphic content set ready to send");
				// Transport.send(message);
			} catch (MessagingException e) {
				logger.error(e.getMessage(), e);
			}
			logger.error("info graphic to send");
			emailSender.send(message);
			logger.error("info graphic sent");
		}
	}

	/**
	 * @author yvonne.yap
	 * 
	 *         This method is used for sending email upon approval/rfa/rejection for TA applications related to C&E.
	 * 
	 *         Generic Email Template: Codes.EmailType.TA_CNE_UPON_APPROVAL / Codes.EmailType.TA_CNE_UPON_RFA etc
	 * 
	 *         If you require specific messages such as "You are reminded to return your licences by DD-MMM-YYYY" for Cessation Applications, suggest to create your own Email Template
	 */
	public void emailTaCneUponAction(Application app, Licence licence, String emailTemplate, String url, User officer) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		// CR12207
		boolean isinfoGraphics = true; // hardcoded
		/*
		 * if (isinfoGraphics == true && emailTemplate.equals(Codes.EmailType.TA_UPON_APPROVAL_WITH_ALL_CONTITIONS_FULFILLED)) { String htmlText =
		 * "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"table-layout: fixed;\" align=\"center\"><tr> <td>" + "<div style =\"width: 100%; font-size: 15px;\">" + " <topImage>" + "" +
		 * "" + "<table><tr><td width=\"10%\"></td><td width=\"80%\"><p style =\"font-family: \"metropolis bold\" \">Dear travel agent, <br><br><br>" +
		 * "Your ${app_type} submission has been reviewed. <br>" + "You are <b>now eligible to renew</b> your licence.</p></td><td width=\"10%\"></td></tr></table>" + "<br>" +
		 * "<table width=\"100%\"><tr><td width=\"10%\"></td><td width=\"80%\">" +
		 * "<p>Log on to <a href=\"https://trust.stb.gov.sg/site/content/tagaem/landing-page.html\">TRUST</a> to renew in 2 easy steps</p></td><td width=\"10%\"></td></tr></table>" + "<br>" +
		 * " <midImage> <table><td width=\"10%\"></td><td width=\"80%\">" +
		 * "<p style =\"font-family: \"metropolis bold\" \" >For Corppass related enquires and assistance, you may approach <a href=\"https://trust.stb.gov.sg/site/content/tagaem/landing-page.html\">Corppass</a> directly </p>"
		 * 
		 * + "<p style =\"font-family: \"metropolis bold\" \">For other enquires and assistance, you may contact us at</p>" + "<br>"
		 * 
		 * + "<table><tr><td><emailImage></td><td> <div style =\"float: left;padding: 5px; font-family: \"metropolis bold\" \">Stb_ta@stb.gov.sg </div></td></tr></table>" +
		 * "<br><table><tr><td> <phoneImage> </td><td> <div style =\"float: left;padding: 5px; font-family: \"metropolis bold\" \">6831 3171 </div></td></tr></table>"
		 * 
		 * + "<br><br><br>" + "<p style =\"font-family: \"metropolis bold\" \">Thank You,</p>" + " </br></br>" +
		 * "<p style =\"font-family: \"metropolis bold\" \"><b><em>Travel Agent Licensing & Regulatory Review Department</em></b></p>" +
		 * "</br><p style =\"font-family: \"metropolis bold\" \"><b><em>Singapore Tourism Board</em></b></p>" + " </div>" + "</td><td width=\"10%\"></td></tr></table></td></tr></table>";
		 * 
		 * Path currentRelativePath = Paths.get(""); String path = currentRelativePath.toAbsolutePath().toString() + "\\src\\main\\resources\\" + "infoGraphics\\";
		 * 
		 * String topImage = "<div style =\"width: 100%; height 15%; \"> <img src=\"" + path + "TopBannerRenewalUponApproval.png\" /> </div>"; String midImage =
		 * "<div style =\"width: 100%; height 20%; \"> <img src=\"" + path + "MidBannerRenewalUponApproval.png\" /> </div>"; String emailImage =
		 * "<div style =\"float: left;padding: 5px;  \">  <img src=\"" + path + "emailImage.png\" /> </div>"; String phoneImage = "<div style =\"float: left;padding: 5px; \"> <img src=\"" + path +
		 * "phoneImage.png\" /> </div>";
		 * 
		 * // String topImage = "<div style =\"width: 100%; height 15%; \"> <img //
		 * src=\"C:\\Users\\jacob.chua\\Wizvision\\Projects\\STB\\staging\\stb-tag-admin-batch\\src\\main\\resources\\infoGraphics\\TopBannerRenewalUponApproval.png\" /> </div>"; // String midImage =
		 * "<div style =\"width: 100%; height 20%; \"> <img //
		 * src=\"C:\\Users\\jacob.chua\\Wizvision\\Projects\\STB\\staging\\stb-tag-admin-batch\\src\\main\\resources\\infoGraphics\\MidBannerRenewalUponApproval.png\" /> </div>"; // String emailImage
		 * = "<div style =\"float: left;padding: 5px; \"> <img //
		 * src=\"C:\\Users\\jacob.chua\\Wizvision\\Projects\\STB\\staging\\stb-tag-admin-batch\\src\\main\\resources\\infoGraphics\\emailImage.png\" /> </div>"; // String phoneImage =
		 * "<div style =\"float: left;padding: 5px; \"> <img //
		 * src=\"C:\\Users\\jacob.chua\\Wizvision\\Projects\\STB\\staging\\stb-tag-admin-batch\\src\\main\\resources\\infoGraphics\\phoneImage.png\" /> </div>";
		 * 
		 * htmlText = htmlText.replace("<topImage>", topImage); htmlText = htmlText.replace("<midImage>", midImage); htmlText = htmlText.replace("<emailImage>", emailImage); htmlText =
		 * htmlText.replace("<phoneImage>", phoneImage); htmlText = htmlText.replace(Codes.Placeholders.APP_TYPE, app.getType().getLabel()); body = htmlText; }
		 */

		// 3. Get ke email
		Stakeholder stakeholderModel = new Stakeholder();
		stakeholderModel = taCommonRepository.getExistingKe(licence.getId());

		if (licence.getTravelAgent() != null) {
			subject = messageHelper.formatKePlaceholders(subject, licence.getTravelAgent(), stakeholderModel);
			body = messageHelper.formatKePlaceholders(body, licence.getTravelAgent(), stakeholderModel);
		}

		if (app != null) {
			subject = messageHelper.formatAppPlaceholders(subject, app, url, null);
			body = messageHelper.formatAppTypePlaceholdersToLowerCase(body, app);
			body = messageHelper.formatAppPlaceholders(body, app, url, null);
		}

		subject = messageHelper.formatUrlPlaceholders(subject, url);
		body = messageHelper.formatUrlPlaceholders(body, url);

		subject = messageHelper.formatSignaturePlaceholders(subject, officer);
		body = messageHelper.formatSignaturePlaceholders(body, officer);

		List<String> recipients = Lists.newArrayList(licence.getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		try {
			emailByTaDept(subject, body, recipients.toArray(recipient));
			log(app, licence, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, licence, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailTaShortfallRectificationReject(TaNetValueRectification rectification, String emailTemplate, String url, User officer) {

		Application app = rectification.getApplication();

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		// 3. Get ke email
		Stakeholder stakeholderModel = new Stakeholder();
		stakeholderModel = taCommonRepository.getExistingKe(app.getLicence().getId());

		if (app.getLicence().getTravelAgent() != null) {
			subject = messageHelper.formatKePlaceholders(subject, app.getLicence().getTravelAgent(), stakeholderModel);
			body = messageHelper.formatKePlaceholders(body, app.getLicence().getTravelAgent(), stakeholderModel);
		}
		subject = messageHelper.formatAppPlaceholders(subject, app, url, null);
		body = messageHelper.formatAppTypePlaceholdersToLowerCase(body, app);
		body = messageHelper.formatAppPlaceholders(body, app, url, null);

		subject = messageHelper.formatSignaturePlaceholders(subject, officer);
		body = messageHelper.formatSignaturePlaceholders(body, officer);

		subject = messageHelper.formatShortfallRectificationPlaceholders(subject, rectification);
		body = messageHelper.formatShortfallRectificationPlaceholders(body, rectification);

		List<String> recipients = Lists.newArrayList(app.getLicence().getTravelAgent().getEmailAddress());
		if (stakeholderModel != null) {
			recipients.add(stakeholderModel.getEmail());
		}
		String[] recipient = recipients.toArray(new String[recipients.size()]);// { stakeholderModel.getEmail(), app.getLicence().getTravelAgent().getEmailAddress() };

		// 4. Send email and create email log
		try {
			emailByTaDept(subject, body, recipients.toArray(recipient));
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailTaShortfallRectificationExtension(TaNetValueRectification rectification, String emailTemplate, String url, User officer) {

	}

	/**
	 * @author verlin.lim
	 * 
	 *         This method is used for sending email upon approval/rfa/rejection for TA/TG applications.
	 * 
	 *         Generic Email Template: Codes.EmailType.TA_UPON_APPROVAL / Codes.EmailType.TA_UPON_RFA etc
	 * 
	 *         If you require specific messages such as "You are reminded to return your licences by DD-MMM-YYYY" for Cessation Applications, suggest to create your own Email Template
	 */
	public void emailUponAction(Application app, String emailTemplate, String url, String... recipient) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		if (app.getLicence().getTravelAgent() != null) {
			subject = messageHelper.formatTaPlaceholders(subject, app.getLicence().getTravelAgent());
			body = messageHelper.formatTaPlaceholders(body, app.getLicence().getTravelAgent());
		}
		if (app.getLicence().getTouristGuide() != null) {
			subject = messageHelper.formatTgPlaceholders(subject, app.getLicence().getTouristGuide());
			body = messageHelper.formatTgPlaceholders(body, app.getLicence().getTouristGuide());
		}
		subject = messageHelper.formatAppPlaceholders(subject, app, url, null);
		body = messageHelper.formatAppPlaceholders(body, app, url, null);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailNewKeForDeclaration(TaStakeholderApplication ke, String emailTemplate, String url, String... recipient) {
		emailKe(ke, emailTemplate, url, null, recipient);
	}

	public void emailKe(TaStakeholderApplication ke, String emailTemplate, String url, TaLicenceCreation tlc, String... recipient) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		Application app;
		if (tlc != null) {
			app = tlc.getApplication();
		} else {
			app = ke.getApplication();
		}

		if (tlc != null) {
			subject = messageHelper.formatTaLicenceCreationPlaceholders(subject, tlc);
			body = messageHelper.formatTaLicenceCreationPlaceholders(body, tlc);
		} else {
			subject = messageHelper.formatKePlaceholders(subject, ke);
			body = messageHelper.formatKePlaceholders(body, ke);
		}

		subject = messageHelper.formatKePlaceholders(subject, ke, url);
		body = messageHelper.formatKePlaceholders(body, ke, url);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponTaLicenceStatusUpdate(Licence licence, StatusSpan statusSpan, String emailTemplate, String action, String... recipient) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		subject = messageHelper.formatTaLicenceStatusUpdatePlaceholders(subject, statusSpan);
		body = messageHelper.formatTaLicenceStatusUpdatePlaceholders(body, statusSpan);
		subject = messageHelper.formatTaPlaceholders(subject, licence.getTravelAgent());
		body = messageHelper.formatTaPlaceholders(body, licence.getTravelAgent());

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(licence, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(licence, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponTaLicenceCreationSubmission(TaLicenceCreation tlc, String emailTemplate, String url, String... recipient) {
		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		subject = messageHelper.formatAppPlaceholders(subject, tlc.getApplication(), url, null);
		body = messageHelper.formatAppPlaceholders(body, tlc.getApplication(), url, null);
		subject = messageHelper.formatTaLicenceCreationPlaceholders(subject, tlc);
		body = messageHelper.formatTaLicenceCreationPlaceholders(body, tlc);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(tlc.getApplication(), template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(tlc.getApplication(), template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponTgAction(Application app, String name, String emailTemplate, String url, String... recipient) {

		// Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		HashMap<String, String> contentDetails = messageHelper.populateTgContentDetails(app, name, null, url, emailTemplate);
		subject = messageHelper.formatTgPlaceholders(subject, contentDetails);
		body = messageHelper.formatTgPlaceholders(body, contentDetails);

		// Send email and create email log
		try {
			email(subject, body, recipient);
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponTgCourseAction(Application app, String tpName, String courseName, String emailTemplate, String url, String... recipient) {

		// Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		HashMap<String, String> contentDetails = messageHelper.populateTgContentDetails(app, tpName, courseName, url, emailTemplate);
		subject = messageHelper.formatTgPlaceholders(subject, contentDetails);
		body = messageHelper.formatTgPlaceholders(body, contentDetails);

		// Send email and create email log
		try {
			email(subject, body, recipient);
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponTgMlptRegistration(TgLicenceMlptRegistration mlptRegistration, String name, String emailTemplate, String url, String... recipient) {

		// Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		body = messageHelper.formatTgMlptPlaceholders(body, name, mlptRegistration, url);

		// Send email and create email log
		try {
			email(subject, body, recipient);
			log(template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponUdpateLicencePrintStatusPC(Application app, String name, String emailTemplateCode, String workPassType, LocalDate collectionStartDate, LocalDate collectionEndDate,
			String... recipient) {

		// Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplateCode);

		// Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		HashMap<String, String> contentDetails = messageHelper.populateTgLicenceCollection(app, name, workPassType, collectionStartDate, collectionEndDate);
		subject = messageHelper.formatTgPlaceholders(subject, contentDetails);
		body = messageHelper.formatTgPlaceholders(body, contentDetails);

		// Send email and create email log
		try {
			email(subject, body, recipient);
			log(app, template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(app, template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponLicenceStatusUpdate(String tgName, StatusSpan statusSpan, String emailTemplate, String... recipient) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		HashMap<String, String> contentDetails = messageHelper.populateTgLicenceUpdate(tgName, statusSpan);
		subject = messageHelper.formatTgPlaceholders(subject, contentDetails);
		body = messageHelper.formatTgPlaceholders(body, contentDetails);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(statusSpan.getLicence(), template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(statusSpan.getLicence(), template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponPortalIdEnabled(TouristGuide tg, String emailTemplate, String iamsPasswordManagerUrl, String... recipient) {
		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		subject = messageHelper.formatTgPlaceholders(subject, tg);
		body = messageHelper.formatTgPlaceholders(body, tg);
		body = messageHelper.formatPasswordManagerPlaceholders(body, iamsPasswordManagerUrl);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(tg.getLicence(), template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(tg.getLicence(), template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUserLoginDetails(User user, String password, String emailTemplate, String... recipient) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		HashMap<String, String> contentDetails = messageHelper.populateUserLoginDetails(user, password);
		subject = messageHelper.formatPlaceholders(subject, contentDetails);
		body = messageHelper.formatPlaceholders(body, contentDetails);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUserQliksenseLoginDetails(User user, String emailTemplate, String... recipient) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		subject = messageHelper.formatUserPlaceholders(subject, user);
		body = messageHelper.formatUserPlaceholders(body, user);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailUponPaymentRefundApproval(String emailTemplate, PaymentRefund refund, String... recipient) {

		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();
		subject = messageHelper.formatPaymentRefundPlaceholders(subject, refund);
		body = messageHelper.formatPaymentRefundPlaceholders(body, refund);

		// 3. Send email and create email log
		try {
			email(subject, body, recipient);
			log(template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public EmailLog emailLetterIssuance(List<CeCaseInfringement> infringements, String emailTemplate, File letter, String recipientName, String... recipient) {

		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		String subject = template.getSubject();
		String body = template.getBody();

		HashMap<String, String> contentDetails = new HashMap<>();
		contentDetails.put(Codes.Placeholders.DEFENDANT, recipientName);

		StringBuilder infringementList = new StringBuilder("");
		for (CeCaseInfringement inf : infringements) {
			CeProvision provision = inf.getCeProvision();
			StringBuilder temp = new StringBuilder("<li>").append(provision.getChapter().getCode()).append(" ").append(provision.getSection()).append("</li>");
			infringementList = (infringementList == null) ? temp : infringementList.append(temp);
		}

		subject = messageHelper.formatPlaceholders(subject, contentDetails);
		body = messageHelper.formatPlaceholders(body, contentDetails);
		body = messageHelper.replaceHTML(body, Codes.Placeholders.INFRINGEMENTS, infringementList.toString());

		try {
			email(subject, body, new File[] { letter }, recipient);
			return log(null, null, template, null, null, Codes.Statuses.EMAIL_SENT, null, recipient, null, null, subject, body);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return log(null, null, template, null, null, Codes.Statuses.EMAIL_FAILED, null, recipient, null, null, subject, body);

		}
	}

	public void emailTGOnPracticalAsessmentFee(TouristGuide tg, List<String> payBill, String emailTemplate) {
		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		body = messageHelper.formatTgAssessmentFeePlaceholders(body, tg);
		body = messageHelper.formatBillRefPlaceholders(body, payBill);

		List<String> recipients = Lists.newArrayList(tg.getEmailAddress());
		String[] recipient = recipients.toArray(new String[recipients.size()]);

		// 3. Send email and create email log
		try {
			email(subject, body, tg.getEmailAddress());
			log(template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void emailTGOnSwitchTierFee(TouristGuide tg, List<String> payBill, Application application, String emailTemplate, String url, String specialisedArea) {
		// 1. Get Email Template
		EmailTemplate template = repository.get(EmailTemplate.class, emailTemplate);

		// 2. Replace Placeholders in Email Template with actual data
		String subject = template.getSubject();
		String body = template.getBody();

		subject = messageHelper.formatTGArea(subject, specialisedArea);
		subject = messageHelper.formatAppPlaceholders(subject, application, url, null);
		body = messageHelper.formatAppPlaceholders(body, application, url, null);
		body = messageHelper.formatTgAssessmentFeePlaceholders(body, tg);
		body = messageHelper.formatBillRefPlaceholders(body, payBill);
		body = messageHelper.formatTGArea(body, specialisedArea);

		List<String> recipients = Lists.newArrayList(tg.getEmailAddress());
		String[] recipient = recipients.toArray(new String[recipients.size()]);

		// 3. Send email and create email log
		try {
			email(subject, body, tg.getEmailAddress());
			log(template, null, Codes.Statuses.EMAIL_SENT, recipient, subject, body);
		} catch (Exception e) {
			log(template, null, Codes.Statuses.EMAIL_FAILED, recipient, subject, body);
			logger.error(e.getMessage());
		}
	}

	public void email(String subject, String body, String... to) {
		email(null, subject, body, EMAIL_FOOTER, null, null, null, null, to);
	}

	public void emailNoFooter(String subject, String body, String... to) {
		email(null, subject, body, null, null, null, null, null, to);
	}

	public void emailWithFrom(String from, String subject, String body, String... to) {
		email(from, subject, body, EMAIL_FOOTER, null, null, null, null, to);
	}

	public void email(String subject, String body, File[] attachments, String... to) {
		email(null, subject, body, EMAIL_FOOTER, null, attachments, null, null, to);
	}

	public void emailByTaDept(String subject, String body, String... to) {
		email(null, subject, body, "", null, null, null, null, to);
	}

	public void emailByTaDept(String[] sendCopyTo, EmailTemplate emailTemplate, String subject, String body, String... to) {
		emailInfoGraphics(sendCopyTo, emailTemplate, null, subject, body, "", null, null, null, null, to);
	}

	public void email(String from, String subject, String body, String footer, String replyTo, File[] attachments, String[] cc, String[] bcc, String... to) {
		email(from, subject, body, footer, replyTo, attachments, cc, bcc, null, to);
	}

	public void emailInfoGraphics(String[] sendCopyTo, EmailTemplate emailTemplate, String from, String subject, String body, String footer, String replyTo, File[] attachments, String[] cc,
			String[] bcc, String... to) {
		emailInfoGraphics(sendCopyTo, emailTemplate, from, subject, body, footer, replyTo, attachments, cc, bcc, null, to);
	}

	public void emailUsingFileDto(String from, String subject, String body, List<FileDto> fileDtos, String... to) {
		email(from, subject, body, EMAIL_FOOTER, null, null, null, null, fileDtos, to);
	}

	public void email(String from, String subject, String body, String footer, String replyTo, File[] attachments, String[] cc, String[] bcc, List<FileDto> fileDtos, String... to) {
		if (!Strings.isNullOrEmpty(subject)) {
			subject = messageHelper.removeHtmlTag(subject);
		}
		String envValue = "";

		if (properties.appEnv != null && !properties.appEnv.equalsIgnoreCase("PROD")) {
			envValue = "[" + properties.appEnv + "] ";

			// only whitelist wizvision, wizvision-tag and stb.gov.sg
			to = Arrays.stream(to).filter(obj -> obj != null).filter(obj -> {
				if (!obj.toLowerCase().endsWith("wizvision-tag.com") && !obj.toLowerCase().endsWith("wizvision.com") && !obj.toLowerCase().endsWith("stb.gov.sg")) {
					logger.error("unaccepted email domain: " + obj);
					return false;
				}
				return true;
			}).toArray(String[]::new);
			if (to.length == 0) {
				logger.error("TO: no email to send after filtered");
			}

			if (cc != null) {
				cc = Arrays.stream(cc).filter(obj -> obj != null).filter(obj -> {
					if (!obj.toLowerCase().endsWith("wizvision-tag.com") && !obj.toLowerCase().endsWith("wizvision.com") && !obj.toLowerCase().endsWith("stb.gov.sg")) {
						logger.error("unaccepted email domain: " + obj);
						return false;
					}
					return true;
				}).toArray(String[]::new);
				if (cc.length == 0) {
					logger.error("CC: no email to send after filtered");
				}
			}

			if (bcc != null) {
				bcc = Arrays.stream(bcc).filter(obj -> obj != null).filter(obj -> {
					if (!obj.toLowerCase().endsWith("wizvision-tag.com") && !obj.toLowerCase().endsWith("wizvision.com") && !obj.toLowerCase().endsWith("stb.gov.sg")) {
						logger.error("unaccepted email domain: " + obj);
						return false;
					}
					return true;
				}).toArray(String[]::new);
				if (bcc.length == 0) {
					logger.error("BCC: no email to send after filtered");
				}
			}

			// prefix subject
			subject = envValue + subject;
		}

		Preconditions.checkNotNull(properties.email);
		Preconditions.checkNotNull(properties.catchAllEmail);
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper;
		try {

			helper = new MimeMessageHelper(message, true);
			helper.setTo(to);
			helper.setCc(cc != null ? cc : new String[] {});
			/*
			 * disable catchAllEmail if (bcc == null) { helper.setBcc(properties.catchAllEmail); } else { ArrayList<String> bccList = new ArrayList<String>(Arrays.asList(bcc));
			 * bccList.add(properties.catchAllEmail); helper.setBcc(bccList.toArray(new String[0])); }
			 */
			helper.setSubject(messageHelper.formatGeneralPlaceholders(subject).replace("&amp;", "&"));
			if (footer == null) {
				helper.setText(messageHelper.formatGeneralPlaceholders(body), true);
			} else {
				helper.setText(messageHelper.formatGeneralPlaceholders(body + footer), true);
			}

			helper.setFrom(Strings.isNullOrEmpty(from) ? properties.email : from);
			helper.setReplyTo(Strings.isNullOrEmpty(replyTo) ? properties.email : replyTo);

			if (fileDtos != null && fileDtos.size() > 0) {
				logger.debug("Attaching " + fileDtos.size() + " attachments with their original name to email.");
				for (FileDto fileDto : fileDtos) {
					FileSystemResource file = new FileSystemResource(fileDto.getPhysicalFile());
					helper.addAttachment(fileDto.getOriginalName(), file);
				}
			} else if (attachments != null) {
				logger.debug("Attaching " + attachments.length + " attachments to email.");
				for (File attachment : attachments) {
					FileSystemResource file = new FileSystemResource(attachment);
					helper.addAttachment(attachment.getName(), file);
				}
			}
			logger.debug("Sending Email: " + message.getSubject() + ", Recipients: " + message.getAllRecipients().length);

		} catch (MessagingException e) {
			logger.error(e.getMessage(), e);
		}
		emailSender.send(message);
	}

	public void emailInfoGraphics(String[] sendCopyTo, EmailTemplate emailTemplate, String from, String subject, String body, String footer, String replyTo, File[] attachments, String[] cc,
			String[] bcc, List<FileDto> fileDtos, String... to) {
		if (!Strings.isNullOrEmpty(subject)) {
			subject = messageHelper.removeHtmlTag(subject);
		}
		String envValue = "";

		/*
		 * if (properties.appEnv != null && !properties.appEnv.equalsIgnoreCase("PROD")) { envValue = "[" + properties.appEnv + "] ";
		 * 
		 * // only whitelist wizvision, wizvision-tag and stb.gov.sg to = Arrays.stream(to).filter(obj -> obj != null).filter(obj -> { if (!obj.toLowerCase().endsWith("wizvision-tag.com") &&
		 * !obj.toLowerCase().endsWith("wizvision.com") && !obj.toLowerCase().endsWith("stb.gov.sg")) { logger.error("unaccepted email domain: " + obj); return false; } return true;
		 * }).toArray(String[]::new); if (to.length == 0) { logger.error("TO: no email to send after filtered"); }
		 * 
		 * if (cc != null) { cc = Arrays.stream(cc).filter(obj -> obj != null).filter(obj -> { if (!obj.toLowerCase().endsWith("wizvision-tag.com") && !obj.toLowerCase().endsWith("wizvision.com") &&
		 * !obj.toLowerCase().endsWith("stb.gov.sg")) { logger.error("unaccepted email domain: " + obj); return false; } return true; }).toArray(String[]::new); if (cc.length == 0) {
		 * logger.error("CC: no email to send after filtered"); } }
		 * 
		 * if (bcc != null) { bcc = Arrays.stream(bcc).filter(obj -> obj != null).filter(obj -> { if (!obj.toLowerCase().endsWith("wizvision-tag.com") && !obj.toLowerCase().endsWith("wizvision.com")
		 * && !obj.toLowerCase().endsWith("stb.gov.sg")) { logger.error("unaccepted email domain: " + obj); return false; } return true; }).toArray(String[]::new); if (bcc.length == 0) {
		 * logger.error("BCC: no email to send after filtered"); } }
		 * 
		 * // prefix subject subject = envValue + subject; }
		 */

		Preconditions.checkNotNull(properties.email);
		Preconditions.checkNotNull(properties.catchAllEmail);
		// MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper;
		MimeMessage message = emailSender.createMimeMessage();
		if (emailTemplate.getCode().equals(Codes.EmailType.TA_FILING_REMINDER_JUNE)) {
			try {
				Path currentRelativePath = Paths.get("");
				String path = currentRelativePath.toAbsolutePath().toString() + "\\src\\main\\resources\\" + "infoGraphics\\";
				String topImage = path + "TopBannerRenewalJune.png";
				String midImage = path + "MidBannerRenewalJune2.png";
				String emailImage = path + "emailImage.png";
				String phoneImage = path + "phoneImage.png";

				// Set From: header field of the header.
				message.setFrom(new InternetAddress("noreply@stb.gov.sg"));

				String[] sendToArr = Arrays.stream(to).filter(obj -> obj != null).filter(obj -> {
					/*
					 * if (!obj.toLowerCase().endsWith("wizvision-tag.com") && !obj.toLowerCase().endsWith("wizvision.com") && !obj.toLowerCase().endsWith("stb.gov.sg")) {
					 * logger.error("unaccepted email domain: " + obj); return false; }
					 */
					return true;
				}).toArray(String[]::new);

				InternetAddress[] recipientAddress = new InternetAddress[sendToArr.length];
				if (sendCopyTo != null) {
					recipientAddress = new InternetAddress[sendCopyTo.length];
				}

				int counter = 0;
				for (String recipient : sendToArr) {
					recipientAddress[counter] = new InternetAddress(recipient.trim());
					logger.error("send to " + recipient);
					counter++;
				}
				// Set To: header field of the header.
				message.setRecipients(Message.RecipientType.TO, recipientAddress);

				// Set Subject: header field
				message.setSubject(subject);

				// This mail has 2 part, the BODY and the embedded image
				MimeMultipart multipart = new MimeMultipart("related");

				// first part (the html)
				BodyPart messageBodyPart = new MimeBodyPart();

				messageBodyPart.setContent(body, "text/html");
				// add it
				multipart.addBodyPart(messageBodyPart);

				// second part (the image)

				// 1
				messageBodyPart = new MimeBodyPart();
				DataSource fdsTopImage = new FileDataSource(topImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsTopImage));
				messageBodyPart.setHeader("Content-ID", "<fdsTopImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// 2
				messageBodyPart = new MimeBodyPart();
				DataSource fdsMidImage = new FileDataSource(midImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsMidImage));
				messageBodyPart.setHeader("Content-ID", "<fdsMidImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// 3
				messageBodyPart = new MimeBodyPart();
				DataSource fdsEmailImage = new FileDataSource(emailImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsEmailImage));
				messageBodyPart.setHeader("Content-ID", "<fdsEmailImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// 4
				messageBodyPart = new MimeBodyPart();
				DataSource fdsPhoneImage = new FileDataSource(phoneImage);

				messageBodyPart.setDataHandler(new DataHandler(fdsPhoneImage));
				messageBodyPart.setHeader("Content-ID", "<fdsPhoneImage>");
				// add image to the multipart
				multipart.addBodyPart(messageBodyPart);

				// put everything together
				message.setContent(multipart);

				logger.error("info graphic content set ready to send");
				// Transport.send(message);
			} catch (MessagingException e) {
				logger.error(e.getMessage(), e);
			}
			logger.error("info graphic to send");
			emailSender.send(message);
			logger.error("info graphic sent");
		}
	}

	public void logInternalEmailNoTemplate(String statusCode, String from, String[] to, String[] cc, String subject, String body) {
		log(null, null, null, null, null, statusCode, from, to, cc, null, subject, body);
	}

	public void log(Application app, Licence licence, EmailTemplate emailType, Integer forYear, String statusCode, String[] to, String subject, String body) {
		log(app, licence, emailType, forYear, null, statusCode, null, to, null, null, subject, body);
	}

	public void log(Application app, EmailTemplate emailType, Integer forYear, String statusCode, String[] to, String subject, String body) {
		log(app, null, emailType, forYear, null, statusCode, null, to, null, null, subject, body);
	}

	public void log(Licence licence, EmailTemplate emailType, Integer forYear, String statusCode, String[] to, String subject, String body) {
		log(null, licence, emailType, forYear, null, statusCode, null, to, null, null, subject, body);
	}

	public EmailLog log(Licence licence, EmailTemplate emailType, Integer forYear, String statusCode, String subject, String body, String... to) {
		return log(null, licence, emailType, forYear, null, statusCode, null, to, null, null, subject, body);
	}

	public void log(EmailTemplate emailType, Integer forYear, String statusCode, String[] to, String subject, String body) {
		log(null, null, emailType, forYear, null, statusCode, null, to, null, null, subject, body);
	}

	public void log(Licence licence, EmailTemplate emailType, String statusCode, String subject, String body, String[] to, File[] attachments) {
		log(null, licence, emailType, null, null, statusCode, null, to, null, attachments, subject, body);
	}

	public void logTaRenewalReminder(TaLicenceRenewalExerciseTa renewalTa, Licence licence, EmailTemplate emailType, Integer forYear, Integer forMonth, String statusCode, String subject, String body,
			String... to) {
		EmailLog emailLog = log(licence, emailType, forYear, statusCode, subject, body, to);
		TaLicenceRenewalExerciseTaEmailLog taRenewalEmailLog = new TaLicenceRenewalExerciseTaEmailLog();
		taRenewalEmailLog.setTaLicenceRenewalExerciseTa(renewalTa);
		taRenewalEmailLog.setEmailLog(emailLog);
		taRenewalEmailLog.setEmailTemplate(emailType);
		taRenewalEmailLog.setStatus(cache.getStatus(statusCode));
		taRenewalEmailLog.setForYear(forYear);
		taRenewalEmailLog.setForMonth(forMonth);
		taRenewalEmailLog.setSendDate(LocalDateTime.now());
		repository.save(taRenewalEmailLog);
		repository.commit();
	}

	public void logEmailBroadcast(EmailBroadcast emailBroadcast, String statusCode, String from, String subject, String body, String[] cc, List<FileDto> attachments, Integer jobId, String... to) {
		EmailLog emailLog = new EmailLog();
		emailLog.setEmailBroadcast(emailBroadcast);
		emailLog.setJob(jobId != null ? repository.get(Job.class, jobId) : null);
		emailLog.setStatus(cache.getStatus(statusCode));
		emailLog.setSender(from);
		emailLog.setReceiver(Arrays.toString(to));
		if (cc != null && cc.length > 0) {
			emailLog.setCc(Arrays.toString(cc));
		}
		if (attachments != null && attachments.size() > 0) {
			emailLog.setAttachments(attachments.stream().map(FileDto::getOriginalName).collect(Collectors.joining(",")));
		}
		emailLog.setSubject(subject);
		emailLog.setBody(body);
		repository.save(emailLog);
	}

	public EmailLog log(Application app, Licence licence, EmailTemplate emailType, Integer forYear, Integer jobId, String statusCode, String from, String[] to, String[] cc, File[] attachments,
			String subject, String body) {
		EmailLog emailLog = new EmailLog();
		emailLog.setTemplate(emailType);
		emailLog.setApplication(app);
		emailLog.setLicence(app != null ? app.getLicence() : licence);
		emailLog.setForYear(forYear);
		emailLog.setJob(jobId != null ? repository.get(Job.class, jobId) : null);
		emailLog.setStatus(cache.getStatus(statusCode));
		emailLog.setSender(Strings.isNullOrEmpty(from) ? properties.email : from);
		emailLog.setReceiver(Arrays.toString(to));
		if (cc != null && cc.length > 0) {
			emailLog.setCc(Arrays.toString(cc));
		}
		if (attachments != null && attachments.length > 0) {
			emailLog.setAttachments(Arrays.toString(attachments));
		}
		emailLog.setSubject(subject);
		emailLog.setBody(body);
		repository.save(emailLog);
		return emailLog;
	}

	public void logTaFilingConditionEmailLog(TaFilingCondition taFilingCondition, Licence licence, EmailTemplate emailType, Integer forYear, Integer forMonth, String statusCode, String subject,
			String body, String... to) {
		EmailLog emailLog = log(licence, emailType, forYear, statusCode, subject, body, to);
		TaFilingConditionEmailLog taFilingConditionEmailLog = new TaFilingConditionEmailLog();
		taFilingConditionEmailLog.setTaFilingCondition(taFilingCondition);
		taFilingConditionEmailLog.setEmailLog(emailLog);
		taFilingConditionEmailLog.setEmailTemplate(emailType);
		taFilingConditionEmailLog.setStatus(cache.getStatus(statusCode));
		taFilingConditionEmailLog.setForYear(forYear);
		taFilingConditionEmailLog.setForMonth(forMonth);
		taFilingConditionEmailLog.setSendDate(LocalDateTime.now());
		repository.save(taFilingConditionEmailLog);
	}

	public LocalDate calculateBaseDate(EmailTemplate emailTemplate, LocalDate baseDate) {

		Integer emailCountdownUnits = emailTemplate.getEmailCountdownUnits(); // 1,2,3,4,5...
		String emailCountdownUnitTypeCode = emailTemplate.getEmailCountdownUnitType().getCode(); // DAY, MONTH
		String emailCountdownPrepositionCode = emailTemplate.getEmailCountdownPreposition().getCode(); // AFTER, BEFORE, ON

		LocalDate newBaseDate = baseDate;
		if (Codes.EmailReminder.COUNTDOWN_UNIT_DAY.equals(emailCountdownUnitTypeCode)) {
			if (Codes.EmailReminder.COUNTDOWN_PREPOSITION_AFTER.equals(emailCountdownPrepositionCode)) {
				newBaseDate = baseDate.plusDays(emailCountdownUnits);
			} else if (Codes.EmailReminder.COUNTDOWN_PREPOSITION_BEFORE.equals(emailCountdownPrepositionCode)) {
				newBaseDate = baseDate.minusDays(emailCountdownUnits);
			}

		} else if (Codes.EmailReminder.COUNTDOWN_UNIT_MONTH.equals(emailCountdownUnitTypeCode)) {
			if (Codes.EmailReminder.COUNTDOWN_PREPOSITION_AFTER.equals(emailCountdownPrepositionCode)) {
				newBaseDate = baseDate.plusMonths(emailCountdownUnits);
			} else if (Codes.EmailReminder.COUNTDOWN_PREPOSITION_BEFORE.equals(emailCountdownPrepositionCode)) {
				newBaseDate = baseDate.minusMonths(emailCountdownUnits);
			}
		}

		return newBaseDate;
	}

	public void logTgLicenceExpiryNotificationEmailLog(Licence licence, EmailTemplate emailType, Integer forYear, Integer forMonth, String statusCode, String subject, String body, String... to) {
		EmailLog emailLog = log(licence, emailType, forYear, statusCode, subject, body, to);
		TgLicenceExpiryNotificationEmailLog licExpiryNotifEmailLog = new TgLicenceExpiryNotificationEmailLog();
		licExpiryNotifEmailLog.setLicence(licence);
		licExpiryNotifEmailLog.setEmailLog(emailLog);
		licExpiryNotifEmailLog.setEmailTemplate(emailType);
		licExpiryNotifEmailLog.setStatus(cache.getStatus(statusCode));
		licExpiryNotifEmailLog.setForYear(forYear);
		licExpiryNotifEmailLog.setForMonth(forMonth);
		licExpiryNotifEmailLog.setSendDate(LocalDateTime.now());
		licExpiryNotifEmailLog.setExpiryDate(licence.getExpiryDate());
		repository.save(licExpiryNotifEmailLog);
	}
}