package gov.stb.tag.helper;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.google.common.collect.Maps;
import com.wiz.model.api.CodeEntity;
import com.wiz.model.api.IdEntity;
import com.wiz.model.api.LongIdEntity;

@Component
public class Entities {

	/**
	 * Return code of CodeEntity, or null if either entity or entity.getCode() is null;
	 */
	public static String getCode(CodeEntity codeEntity) {
		return (codeEntity == null ? null : codeEntity.getCode());
	}

	/**
	 * Return id of IdEntity, or null if either entity or entity.getId() is null;
	 */
	public static Serializable getId(IdEntity idEntity) {
		return (idEntity == null ? null : idEntity.getId());
	}

	/**
	 * Return true if both code and entity's code are null or similar.
	 */
	public static boolean equals(CodeEntity entity, String code) {
		return (code != null && entity != null && entity.getCode().equals(code)) || (code == null && entity != null && entity.getCode() == null);
	}

	/**
	 * Return true if entity's code is equals to all of the specified codes.
	 */
	public static boolean allEquals(CodeEntity entity, String... codes) {
		return (entity != null) ? Arrays.asList(codes).stream().allMatch(o -> (entity.getCode() == null && o == null) || entity.getCode().equals(o)) : false;
	}

	/**
	 * Return true if entity's code is equals to any of the specified codes.
	 */
	public static boolean anyEquals(CodeEntity entity, String... codes) {
		return (entity != null) ? Arrays.asList(codes).contains(entity.getCode()) : false;
	}

	/**
	 * Return true if both id and entity's id are null or similar.
	 */
	public static boolean equals(IdEntity entity, Integer id) {
		return (id != null && entity != null && entity.getId().equals(id)) || (id == null && entity != null && entity.getId() == null);
	}

	/**
	 * Return true if entity's id is equals to all of the specified ids.
	 */
	public static boolean allEquals(IdEntity entity, Integer... ids) {
		return (entity != null) ? Arrays.asList(ids).stream().allMatch(o -> (entity.getId() == null && o == null) || entity.getId().equals(o)) : false;
	}

	/**
	 * Return true if entity's id is equals to any of the specified ids.
	 */
	public static boolean anyEquals(IdEntity entity, Integer... ids) {
		return (entity != null) ? Arrays.asList(ids).contains(entity.getId()) : false;
	}

	/**
	 * Return true if both id and entity's id are null or similar.
	 */
	public static boolean equals(LongIdEntity entity, Long id) {
		return (id != null && entity != null && entity.getId().equals(id)) || (id == null && entity != null && entity.getId() == null);
	}

	/**
	 * Return true if entity's id is equals to all of the specified ids.
	 */
	public static boolean allEquals(LongIdEntity entity, Long... ids) {
		return (entity != null) ? Arrays.asList(ids).stream().allMatch(o -> (entity.getId() == null && o == null) || entity.getId().equals(o)) : false;
	}

	/**
	 * Return true if entity's id is equals to any of the specified ids.
	 */
	public static boolean anyEquals(LongIdEntity entity, Long... ids) {
		return (entity != null) ? Arrays.asList(ids).contains(entity.getId()) : false;
	}

	/**
	 * Return true if both CodeEntities are null or similar.
	 */
	public static boolean equals(CodeEntity entity1, CodeEntity entity2) {
		return (entity1 != null && entity2 != null && entity1.getCode().equals(entity2.getCode())) || (entity1 == null && entity2 == null);
	}

	/**
	 * Return true if both IdEntities are null or similar.
	 */
	public static boolean equals(IdEntity entity1, IdEntity entity2) {
		return (entity2 != null && entity2 != null && entity2.getId().equals(entity2.getId())) || (entity2 == null && entity2 == null);
	}

	/**
	 * Return true if both IdEntities are null or similar.
	 */
	public static boolean equals(LongIdEntity entity1, LongIdEntity entity2) {
		return (entity2 != null && entity2 != null && entity2.getId().equals(entity2.getId())) || (entity2 == null && entity2 == null);
	}

	/**
	 * Return a map of Code - CodeEntity pairs.
	 */
	public static <T extends CodeEntity> Map<String, T> mapCodeValues(List<T> list) {
		Map<String, T> mapping = Maps.newLinkedHashMap();
		list.stream().forEach(item -> mapping.put(item.getCode(), item));
		return mapping;
	}

	/**
	 * Return a map of Id - IdEntity pairs.
	 */
	public static <T extends IdEntity> Map<Integer, T> mapIdValues(List<T> list) {
		Map<Integer, T> mapping = Maps.newLinkedHashMap();
		list.stream().forEach(item -> mapping.put(item.getId(), item));
		return mapping;
	}

	/**
	 * Return a map of Id - IdEntity pairs.
	 */
	public static <T extends LongIdEntity> Map<Long, T> mapLongIdValues(List<T> list) {
		Map<Long, T> mapping = Maps.newLinkedHashMap();
		list.stream().forEach(item -> mapping.put(item.getId(), item));
		return mapping;
	}
}
