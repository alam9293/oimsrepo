package gov.stb.tag.helper;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.AttachmentDto;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.DocumentTemplate;
import gov.stb.tag.model.File;
import gov.stb.tag.model.PaymentStatusSpan;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowFile;
import gov.stb.tag.repository.FileRepository;

@Component
public class FileHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;
	@Autowired
	Properties properties;
	@Autowired
	FileRepository repository;

	/**
	 * @param file
	 *            model
	 * @return the physical file
	 */
	public java.io.File getPhyiscalFile(File file) {
		if (file != null) {
			Preconditions.checkNotNull(properties.baseDir);
			String filepath = properties.baseDir + file.getPath() + file.getFilename();
			java.io.File physicalFile = new java.io.File(filepath);
			logger.trace("getPhyiscalFile(): retrieving: " + filepath);
			if (!physicalFile.exists()) {
				logger.error("getPhyiscalFile(): file not found: " + filepath);
				return null;
			}
			return physicalFile;
		}
		return null;
	}

	/**
	 * Create, persist and return a file without tying to other entity (mainly for uploading of files from public before saving an application).
	 */
	public File saveFile(String documentTypeCode, MultipartFile multipartFile, boolean toTransfer) {
		return saveFile(documentTypeCode, multipartFile, toTransfer, false, null);
	}

	public File saveFile(String documentTypeCode, MultipartFile multipartFile, boolean toTransfer, boolean toTransferToPublic, String path) {

		String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
		String filename = String.format(documentTypeCode + "_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd_HHmmss_SSSSSS")) + "." + extension);
		File file = createFile(multipartFile, filename, extension, path != null ? path : properties.generalUploadDir, null, toTransfer, toTransferToPublic);

		validateFile(file);
		createPhysicalFile(multipartFile, file);
		repository.save(file);
		return file;
	}

	/**
	 * Create, persist and return a file without tying to other entity (mainly for uploading of files from public before saving an application).
	 */
	public File saveBulletinFile(String documentTypeCode, MultipartFile multipartFile, boolean toTransfer) {

		String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
		String filename = String.format(documentTypeCode + "_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd_HHmmss_SSSSSS")) + "." + extension);
		File file = createFile(multipartFile, filename, extension, properties.bulletinUploadDir, null, toTransfer, false);

		validateFile(file);
		createPhysicalFile(multipartFile, file);
		repository.save(file);
		return file;
	}

	/**
	 * Create, persist and return a file without tying to other entity (mainly for files migration).
	 */
	public File saveMigrationFile(String documentTypeCode, MultipartFile multipartFile, boolean toTransfer, String refNo) {

		String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
		String filename = String.format(documentTypeCode + "_" + refNo + "_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd_HHmmss_SSSSSS")) + "." + extension);
		File file = createFile(multipartFile, filename, extension, "upload/migration/", null, toTransfer, false);

		validateFile(file);
		createPhysicalFile(multipartFile, file);
		repository.save(file);
		return file;
	}

	/**
	 * Create, persist a File and an ApplicationFile. Returns an ApplicationFile for the specified application and file.
	 */
	public ApplicationFile saveFile(Application application, FileDto dto) {

		File file = new File();
		file.setExtension(dto.getExtension());
		file.setFilename(dto.getProcessedName());
		file.setOriginalFilename(dto.getOriginalName());
		file.setPath(dto.getPath());
		file.setSize(dto.getSize());
		file.setPublicFileId(dto.getId()); // when passing in from internet, the public file id is the id
		file.setTransferStatus(cache.getStatus(Codes.Statuses.TXF_PENDING));
		file.setHash(dto.getHash());
		repository.save(file);

		ApplicationFile appFile = saveApplicationFile(application, file, dto);

		return appFile;
	}

	/**
	 * Create, persist and return an ApplicationFile for the specified application and file.
	 */
	public ApplicationFile saveApplicationFile(Application application, File file, FileDto dto) {
		ApplicationFile appFile = new ApplicationFile();
		appFile.setApplication(application);
		appFile.setDocumentType(cache.getType(dto.getDocType()));
		appFile.setFile(file);
		repository.save(appFile);
		return appFile;
	}

	/**
	 * Create, persist and return an file for the specified workflow action and file.
	 */
	public File saveFile(WorkflowAction workflowAction, String description, MultipartFile multipartFile) {
		String path = String.format(properties.workflowActionUploadDir, workflowAction.getId());

		File file = createFile(multipartFile, null, null, path, description, false, false);
		validateFile(file);
		createPhysicalFile(multipartFile, file);
		repository.save(file);
		repository.save(workflowAction);
		return file;
	}

	/**
	 * Create, persist and return an file for the specified payment status span and file.
	 */
	public File saveFile(PaymentStatusSpan pss, String description, MultipartFile multipartFile) {
		String path = String.format(properties.paymentStatusSpanUploadDir, pss.getId());

		File file = createFile(multipartFile, null, null, path, description, false, false);
		validateFile(file);
		createPhysicalFile(multipartFile, file);
		repository.save(file);

		return file;
	}

	/**
	 * Create a file from the specified information
	 */
	public File createFile(MultipartFile multipartFile, String filename, String extension, String path, String description, boolean toTransfer, boolean toTransferToInternet) {
		File file = new File();
		file.setFilename(Strings.isNullOrEmpty(filename) ? FilenameUtils.getName(multipartFile.getOriginalFilename()) : filename);
		file.setExtension(Strings.isNullOrEmpty(extension) ? FilenameUtils.getExtension(multipartFile.getOriginalFilename()) : extension);
		file.setOriginalFilename(FilenameUtils.getName(multipartFile.getOriginalFilename()));
		file.setPath(path);
		file.setSize(multipartFile.getSize());
		file.setDescription(description);
		file.setHash(computeHash(multipartFile));
		file.setTransferStatus(toTransferToInternet ? cache.getStatus(Codes.Statuses.TXF_TO_PUB_PENDING) : toTransfer ? cache.getStatus(Codes.Statuses.TXF_PENDING) : null);
		return file;
	}

	/**
	 * Compute hash for string the specified file
	 */
	public String computeHash(MultipartFile multipartFile) {
		try {
			return computeHash(multipartFile.getBytes());
		} catch (IOException e) {
			logger.error("error computing hash");
			throw new RuntimeException(e);
		}
	}

	/**
	 * Compute hash for string the specified file in bytes[]
	 */
	public String computeHash(byte[] bytes) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] digest = md.digest(bytes);
			return DatatypeConverter.printHexBinary(digest);
		} catch (NoSuchAlgorithmException e) {
			logger.error("error computing hash");
			throw new RuntimeException(e);
		}
	}

	/**
	 * Verify if the hash is valid.
	 */
	public Boolean isHashValid(java.io.File file, String hash) {
		try {
			return computeHash(Files.readAllBytes(file.toPath())).equals(hash);
		} catch (IOException e) {
			logger.error("error computing hash");
			throw new RuntimeException(e);
		}
	}

	public Boolean isHashBelongToFile(File file, String hash) {
		if (file.getHash().equals(hash)) {
			return true;
		} else {
			throw new ValidationException("File and Hash does not match");
		}
	}

	/**
	 * Validate the path, size, extension of the specified file before proceeding to create the physical file
	 */
	public void validateFile(File file) {
		Preconditions.checkNotNull(properties.baseDir);
		Preconditions.checkNotNull(file.getPath());

		Integer maxFileSize = Integer.valueOf(cache.getSystemParameter(Codes.SystemParameters.MAX_FILE_SIZE).getValue());
		String validFileExtsText = cache.getSystemParameter(Codes.SystemParameters.VALID_FILE_EXTS).getValue();
		List<String> validFileExts = Arrays.asList(validFileExtsText.split(","));

		if (file.getExtension() != null && !validFileExts.contains(file.getExtension().toLowerCase())) {
			throw new ValidationException("Uploaded file extension is not allowed. Allowable file extensions: " + validFileExtsText);
		}
		if (Long.valueOf(maxFileSize * 1024) < file.getSize()) {
			throw new ValidationException("Uploaded file size cannot exceed " + maxFileSize + " KB.");
		}
	}

	/**
	 * Create the physical file from the specified multipartFile
	 */
	public void createPhysicalFile(MultipartFile multipartFile, File file) {
		java.io.File physicalFile = new java.io.File(properties.baseDir + file.getPath() + file.getFilename());
		physicalFile.getParentFile().mkdirs();

		try (BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(physicalFile))) {
			byte[] bytes = multipartFile.getBytes();
			stream.write(bytes);
		} catch (IOException e) {
			logger.error(e.getMessage());
			throw new ValidationException("An error has occurred while processing the uploaded file.");
		}
	}

	// TODO: to enhance to soft-deletion so that RFA can back-track the files (at least via backend SR)
	public void deleteFile(File file) {
		file.setIsDeleted(true);
		ApplicationFile appFile = repository.getAppFile(file.getId());
		if (appFile != null) {
			appFile.setIsDeleted(true);
			repository.save(appFile);
		}
		repository.save(file);
	}

	/**
	 * Create, persist and return file.
	 */
	public File saveFile(FileDto dto) {

		File file = new File();
		file.setExtension(dto.getExtension());
		file.setFilename(dto.getProcessedName());
		file.setOriginalFilename(dto.getOriginalName());
		file.setPath(dto.getPath());
		file.setPublicFileId(dto.getPublicFileId());
		file.setSize(dto.getSize());
		file.setPublicFileId(dto.getId()); // when passing in from internet, the public file id is the id
		file.setHash(dto.getHash());

		repository.save(file);

		return file;
	}

	/**
	 * Create, persist and return file.
	 */
	public File saveFile(FileDto dto, Boolean isPublic) {

		File file = new File();
		file.setExtension(dto.getExtension());
		file.setFilename(dto.getProcessedName());
		file.setOriginalFilename(dto.getOriginalName());
		file.setPath(dto.getPath());
		file.setSize(dto.getSize());
		file.setHash(dto.getHash());

		if (isPublic) {
			file.setPublicFileId(dto.getPublicFileId());
			file.setPublicFileId(dto.getId()); // when passing in from internet, the public file id is the id
		}

		repository.save(file);

		return file;
	}

	public File getFile(Integer fileId) {
		return repository.getFile(fileId);

	}

	public DocumentTemplate getTemplate(String docType) {
		return repository.getTemplate(docType);

	}

	// Generating / Validating Hash
	// public static void main(String[] args) throws IOException {
	// FileHelper fileHelper = new FileHelper();
	// java.io.File file = new java.io.File("C:\\Users\\don.lee\\Desktop\\TA_DOC_CEASE_DIRECTOR_RESOLUTION_20190123113109774669.pdf");
	// String hash = fileHelper.computeHash(Files.readAllBytes(file.toPath()));
	// System.out.println("HASH: " + hash);
	// System.out.println("IsHashValid: " + fileHelper.isHashValid(file, hash));
	// }

	public void updateFiles(Application app, List<FileDto> files, String documentType) {

		if (CollectionUtils.isNotEmpty(app.getApplicationFiles())) {
			for (ApplicationFile appFile : app.getApplicationFiles()) {
				if (appFile.getDocumentType().getCode().equals(documentType)) {
					if (!isInFiles(files, appFile.getFile())) {
						deleteFile(appFile.getFile());
					}
				}
			}
		}

		for (FileDto file : files) {
			if (file.getPublicFileId() == null) {
				saveFile(app, file);
			}
		}

	}

	public void updateRenewalFiles(Application app, List<FileDto> files, String documentType) {

		if (CollectionUtils.isNotEmpty(app.getApplicationFiles())) {
			for (ApplicationFile appFile : app.getApplicationFiles()) {
				if (appFile.getDocumentType().getCode().equals(documentType)) {
					if (!isInFiles(files, appFile.getFile())) {
						File file = appFile.getFile();
						file.setIsDeleted(true);
						appFile.setIsDeleted(true);
						repository.save(appFile);
						repository.save(file);
					}
				}
			}
		}

		for (FileDto file : files) {
			if (file.getPublicFileId() == null) {
				saveFile(app, file);
			}
		}

	}

	private boolean isInFiles(List<FileDto> files, File currFile) {
		boolean isIn = false;

		for (FileDto file : files) {
			if (file.getPublicFileId() == null && currFile.getPublicFileId().equals(file.getId())) {
				isIn = true;
				break;
			}
			if (file.getPublicFileId() != null && currFile.getId().equals(file.getId())) {
				isIn = true;
				break;
			}
		}

		return isIn;
	}

	/**
	 * Create, persist and return an WorkflowFile for the specified workflow and file.
	 */
	public WorkflowFile saveWorkflowFile(Workflow workflow, AttachmentDto dto) {
		String path = String.format(properties.workflowUploadDir, workflow.getId());
		String extension;
		String filename;
		if (dto.getExtension() != null) {
			extension = dto.getExtension();
		} else {
			extension = FilenameUtils.getExtension(dto.getFile().getOriginalFilename());
		}
		if (dto.getOriginalName() != null) {
			filename = dto.getOriginalName();
		} else {
			filename = String
					.format(FilenameUtils.getBaseName(dto.getFile().getOriginalFilename()) + "_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd_HHmmss_SSSSSS")) + "." + extension);
		}
		File file;
		if (dto.getId() != null) {
			file = repository.get(File.class, dto.getId());
		} else {
			file = createFile(dto.getFile(), filename, null, path, dto.getDescription(), false, false);
			validateFile(file);
			createPhysicalFile(dto.getFile(), file);
			repository.save(file);
		}

		WorkflowFile wkFile = new WorkflowFile();
		wkFile.setWorkflow(workflow);
		wkFile.setDocumentType(cache.getType(dto.getDocTypeCode()));
		wkFile.setFile(file);
		repository.save(wkFile);
		return wkFile;
	}

	public void deleteWorkflowFileByWorkflowFileId(Integer workflowFileId) {
		WorkflowFile wkFile = repository.getWorkflowFile(workflowFileId);
		if (wkFile != null) {
			wkFile.setIsDeleted(true);
			repository.save(wkFile);
		}

		File file = wkFile.getFile();
		file.setIsDeleted(true);
		repository.saveOrUpdate(file);
	}

	public WorkflowFile saveOrUpdateWorkflowFile(AttachmentDto attachmentDto, Workflow workflow) {
		// 1. Save documents
		if (attachmentDto.getWorkflowFileId() == null) {
			// create new
			return saveWorkflowFile(workflow, attachmentDto);
		} else {
			// update
			WorkflowFile fileObj = repository.get(WorkflowFile.class, attachmentDto.getWorkflowFileId());
			fileObj.setDocumentType(cache.getType(attachmentDto.getDocTypeCode()));
			if (fileObj.getFile() != null) {
				fileObj.getFile().setDescription(attachmentDto.getDescription());
				repository.save(fileObj.getFile());
			}
			repository.save(fileObj);
			return fileObj;
		}
	}

	public List<AttachmentDto> addFilesNotIncluded(List<AttachmentDto> fileList, List<AttachmentDto> reqFileList) {
		if (fileList.isEmpty()) {
			return reqFileList;
		} else {
			for (AttachmentDto file : fileList) {
				if (file.getDocTypeCode().equalsIgnoreCase(Codes.TaDocumentTypes.TA_DOC_OTHERS)) {
					reqFileList.add(file);
				} else {
					if (!Strings.isNullOrEmpty(file.getOriginalName())) {
						AttachmentDto a = reqFileList.stream().filter(i -> i.getDocTypeCode().equalsIgnoreCase(file.getDocTypeCode())).findFirst().orElse(null);
						Integer i = reqFileList.indexOf(a);
						reqFileList.remove(a);
						reqFileList.add(i, file);
					}
				}
			}
			return reqFileList;
		}
	}

	public void deleteFile(FileDto deletedFile) {
		File file = repository.getFile(deletedFile.getId());
		if (file != null) {
			file.setIsDeleted(true);
			repository.saveOrUpdate(file);
		}
	}

	public void deleteAllFiles(List<FileDto> deletedFiles) {
		if (CollectionUtils.isNotEmpty(deletedFiles)) {
			List<File> files = repository.getFiles(deletedFiles.stream().map(FileDto::getId).collect(Collectors.toList()));

			if (CollectionUtils.isNotEmpty(files)) {
				files.forEach(u -> u.setIsDeleted(true));
				repository.saveOrUpdate(files);
			}
		}
	}

	/**
	 * Create, persist and return file.
	 */
	public File updateFileFromFileDto(File file, FileDto dto, Boolean isPublic) {

		file.setExtension(dto.getExtension());
		file.setOriginalFilename(dto.getOriginalName());
		file.setSize(dto.getSize());
		file.setHash(dto.getHash());
		file.setDescription(dto.getDescription());
		if (isPublic) {
			file.setPublicFileId(dto.getId()); // when passing in from internet, the public file id is the id
		}

		repository.save(file);

		return file;
	}

	/**
	 * Create, persist and return file.
	 */
	public File updateFileFromAttachmentDto(File file, AttachmentDto dto, Boolean isPublic) {

		file.setExtension(dto.getExtension());
		file.setOriginalFilename(dto.getOriginalName());
		file.setSize(dto.getSize());
		file.setHash(dto.getHash());
		file.setDescription(dto.getDescription());
		if (isPublic) {
			file.setPublicFileId(dto.getId()); // when passing in from internet, the public file id is the id
		}

		repository.save(file);

		return file;
	}

	public WorkflowFile saveWorkflowFileFromFile(Workflow workflow, File file, String docType, WorkflowFile wf) {
		WorkflowFile wkFile = new WorkflowFile();
		if (wf != null) {
			wkFile = wf;
		}
		wkFile.setWorkflow(workflow);
		wkFile.setDocumentType(cache.getType(docType));
		wkFile.setFile(file);
		repository.saveOrUpdate(wkFile);
		return wkFile;
	}

	public void softDeleteFileList(List<Integer> toDeleteList) {
		if (toDeleteList != null && !toDeleteList.isEmpty()) {
			for (Integer id : toDeleteList) {
				if (id != null) {
					File attachemnt = new File();
					attachemnt = getFile(id);
					if (attachemnt != null) {
						deleteFile(attachemnt);
					}
				}
			}
		}
	}

	public boolean isImage(String extension) {
		String imageExts = "jpg,jpeg,gif,png";
		List<String> imageExtsList = Arrays.asList(imageExts.split(","));

		if (imageExtsList.contains(extension.toLowerCase())) {
			return true;
		} else {
			return false;
		}
	}

	public String getFullFilePath(String baseDir, String filePath, String fileName) {
		Preconditions.checkNotNull(baseDir);
		return baseDir + filePath + fileName;
	}

	public void updateFilesDescription(List<FileDto> filesDto) {
		if (CollectionUtils.isNotEmpty(filesDto)) {
			List<File> files = repository.getFiles(filesDto.stream().map(FileDto::getId).collect(Collectors.toList()));
			for (File file : files) {
				FileDto fDto = filesDto.stream().filter(u -> u.getId().equals(file.getId())).findFirst().get();
				file.setDescription(fDto.getDescription());
			}
		}
	}

	/**
	 * Create, persist and return a File for shortfall letter and transfer to public
	 */
	public File saveShortfallLetter(Workflow workflow, String fileName, byte[] shortfallLetterByteArray) {
		File file = new File();
		file.setFilename(FilenameUtils.getName(fileName));
		file.setExtension(FilenameUtils.getExtension(fileName));
		file.setOriginalFilename(FilenameUtils.getName(fileName));
		file.setPath(String.format(properties.workflowUploadDir, workflow.getId()));
		file.setHash(computeHash(shortfallLetterByteArray));
		file.setTransferStatus(cache.getStatus(Codes.Statuses.TXF_TO_PUB_PENDING));

		java.io.File letterFile = new java.io.File(properties.baseDir + String.format(properties.workflowUploadDir, workflow.getId()) + "/" + fileName);
		if (letterFile.exists()) {
			file.setSize(letterFile.length());
		}

		repository.save(file);

		WorkflowFile wkFile = new WorkflowFile();
		wkFile.setWorkflow(workflow);
		wkFile.setDocumentType(cache.getType(Codes.TaDocumentTypes.TA_DOC_SHORTFALL_LETTER_SYSTEM));
		wkFile.setFile(file);
		repository.save(wkFile);

		return file;
	}

}
