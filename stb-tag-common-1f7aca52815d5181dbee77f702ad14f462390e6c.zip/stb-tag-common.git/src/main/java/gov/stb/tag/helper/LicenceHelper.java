package gov.stb.tag.helper;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Statuses;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.TaBranchApplication;
import gov.stb.tag.model.TaLicenceRenewal;
import gov.stb.tag.model.TaLicenceTierSwitch;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.LicenceStatusRepository;
import gov.stb.tag.util.DateUtil;

@Component
public class LicenceHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;
	@Autowired
	Properties properties;
	@Autowired
	LicenceStatusRepository repository;
	@Autowired
	FileHelper fileHelper;

	/**
	 * Update the licence with the specified status, end its last status span and create a new one. If the tier is not specified, it will be the current licence tier. If the newStartDate is not
	 * specified, it will be current date time.
	 */

	public StatusSpan updateLicenceStatus(Licence licence, String statusCode) {
		return updateLicenceStatus(licence, statusCode, null, null, null, null);
	}

	public StatusSpan updateLicenceStatus(Licence licence, String statusCode, Type tier, LocalDateTime newStartDate) {
		return updateLicenceStatus(licence, statusCode, tier, null, null, newStartDate);
	}

	public StatusSpan updateLicenceStatus(Licence licence, String statusCode, Type tier, String intRemarks, String extRemarks, LocalDateTime newStartDate) {
		StatusSpan lastStatusSpan = repository.getLastStatusSpan(licence);
		if (lastStatusSpan != null) {
			lastStatusSpan.setEndDate(newStartDate != null ? newStartDate.minusSeconds(1) : LocalDateTime.now().minusSeconds(1));
			repository.update(lastStatusSpan);
		}
		if (tier != null) {
			licence.setTier(tier);
		}
		licence.setStatus(cache.getStatus(statusCode));
		return createStatusSpan(licence, intRemarks, extRemarks, newStartDate);
	}

	/**
	 * Create a status span based on the current specified licence.
	 */
	public StatusSpan createStatusSpan(Licence licence, String intRemarks, String extRemarks, LocalDateTime newStartDate) {
		StatusSpan statusSpan = new StatusSpan();
		statusSpan.setLicence(licence);
		statusSpan.setTier(licence.getTier());
		statusSpan.setStatus(licence.getStatus());
		statusSpan.setStartDate(newStartDate != null ? newStartDate : LocalDateTime.now());
		statusSpan.setInternalRemarks(intRemarks);
		statusSpan.setExternalRemarks(extRemarks);
		repository.save(statusSpan);
		return statusSpan;
	}

	public String getLicenceRenewalStatus(User user) {
		Licence licence = repository.getLicenceDetailsByTgId(user.getTouristGuide().getId());
		return getLicenceRenewalStatus(licence);
	}

	public String getLicenceRenewalStatus(Licence licence) {
		LocalDate now = LocalDate.now();
		LocalDate overdueDate = now.minusYears(6);
		LocalDate reinstateAfterThreeYears = now.minusYears(3);
		LocalDate reinstateDate = now;
		LocalDate renewalStartDate = now.plusMonths(6);

		LocalDate expiryDate = licence.getExpiryDate();

		if (expiryDate.isBefore(overdueDate)) {
			return Codes.LicenceRenewalStatus.OVERDUE;
		} else if (expiryDate.isBefore(reinstateAfterThreeYears)) {
			return Codes.LicenceRenewalStatus.REINSTATE_AF_3YR;
		} else if (expiryDate.isBefore(reinstateDate)) {
			return Codes.LicenceRenewalStatus.REINSTATE_B4_3YR;
		} else if (expiryDate.isBefore(renewalStartDate)) {
			return Codes.LicenceRenewalStatus.RENEWAL;
		}

		return null;
	}

	public String getLicenceRenewalType(User user) {
		Licence licence = repository.getLicenceDetailsByTgId(user.getTouristGuide().getId());
		return getLicenceRenewalType(licence);
	}

	public String getLicenceRenewalType(Licence licence) {
		LocalDate now = LocalDate.now();
		LocalDate overdueDate = now.minusYears(6);
		LocalDate reinstateDate = now;
		LocalDate renewalStartDate = now.plusMonths(6);

		LocalDate expiryDate = licence.getExpiryDate();

		if (expiryDate.isBefore(overdueDate)) {
			return Codes.LicenceRenewalType.OVERDUE;
		} else if (expiryDate.isBefore(reinstateDate)) {
			return Codes.LicenceRenewalType.REINSTATE;
		} else if (expiryDate.isBefore(renewalStartDate)) {
			return Codes.LicenceRenewalType.RENEWAL;
		}

		return Codes.LicenceRenewalType.NONE;
	}

	/************************* START Licence renewal to renew licence ********************************/
	public void renewTaLicence(TaLicenceRenewal renewalModel, int elicenceViewFlag) {
		Licence licenceModel = new Licence();
		licenceModel = renewalModel.getApplication().getLicence();
		LocalDate licenceExpire = licenceModel.getExpiryDate();
		LocalDate newLicenceStart = licenceExpire.plusDays(1);
		LocalDate newLicenceExpire = LocalDate.of((newLicenceStart.getYear()) + 1, 12, 31);
		licenceModel.setExpiryDate(newLicenceExpire);
		licenceModel.setIsViewable(elicenceViewFlag);

		if (!licenceModel.getStatus().getCode().equalsIgnoreCase(Statuses.TA_ACTIVE)) {
			licenceModel.setStatus(cache.getStatus(Statuses.TA_ACTIVE));
			updateLicenceStatus(licenceModel, Codes.Statuses.TA_ACTIVE, null, newLicenceStart.atStartOfDay());
		} else {
			licenceModel.setStartDate(newLicenceStart);
			repository.update(licenceModel);
		}
		renewalModel.setIsConcluded(Boolean.TRUE);
		repository.saveOrUpdate(renewalModel);
	}

	/**************************** END Licence renewal to update licence ***************************/

	/************* For Switch tier application to update licence tier *********************/
	public void updateLicenceTier(TaLicenceTierSwitch tierSwitchModel) {
		Type newTierModel = new Type();
		Licence licenceModel = new Licence();
		newTierModel = tierSwitchModel.getNewLicenceTier();
		licenceModel = tierSwitchModel.getApplication().getLicence();
		licenceModel.setTier(newTierModel);
		String newLicenceNo = licenceModel.getLicenceNo();

		if (Character.isLetter(newLicenceNo.charAt(newLicenceNo.length() - 1))) {
			newLicenceNo = newLicenceNo.substring(0, newLicenceNo.length() - 1);
		}

		if (Codes.Types.TA_TIER_NICHE.equalsIgnoreCase(newTierModel.getCode())) {
			// Put in 'N' at the back if switch from G to N
			licenceModel.setLicenceNo(newLicenceNo + Codes.Types.TA_TIER_NICHE.substring(Codes.Types.TA_TIER_NICHE.length() - 1));

			// If switch from G to N, take out all outbound services for TA
			TravelAgent travelAgent = repository.get(TravelAgent.class, licenceModel.getTravelAgent().getId());
			travelAgent.setOutboundServices(new HashSet<Type>());

			// If switch from G to N, take out all inbound services TA_SERV_ACCOMMODATION, TA_SERV_AIR_TICKETING for TA
			Set<Type> inboundServices = new HashSet<Type>();
			inboundServices = tierSwitchModel.getApplication().getLicence().getTravelAgent().getInboundServices();
			String[] notNicheServices = { Codes.Types.TA_SERV_ACCOMMODATION, Codes.Types.TA_SERV_AIR_TICKETING };

			Set<Type> newInboundServices = new HashSet<Type>();
			for (Type inboundService : inboundServices) {
				if (Arrays.asList(notNicheServices).contains(inboundService.getCode())) {
				} else {
					newInboundServices.add(inboundService);
				}
			}
			travelAgent.setInboundServices(newInboundServices);

			repository.saveOrUpdate(travelAgent);

		} else {
			// Take out 'N' at the back if switch from N to G
			licenceModel.setLicenceNo(newLicenceNo);
		}
		repository.update(licenceModel);

		// update change of tier to status span
		logger.info("updateLicenceTier() - Updating licence status span for licenceNo={}, oldLicenceTier={}, newLicenceTier={}", licenceModel.getLicenceNo(),
				tierSwitchModel.getOldLicenceTier().getCode(), newTierModel.getCode());
		updateLicenceStatus(licenceModel, licenceModel.getStatus().getCode(), licenceModel.getTier(), tierSwitchModel.getStartDate().atStartOfDay());

		tierSwitchModel.setPendingSwitch(Boolean.FALSE);
		repository.saveOrUpdate(tierSwitchModel);
	}

	/************* END For Switch tier application to update licence tier *********************/

	public void saveNewBranchLicence(TaBranchApplication branchAppl) {

		TaBranch branch = new TaBranch();
		branch.setLicence(branchAppl.getTaBranchApplicationBatch().getApplication().getLicence());
		branch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_ACTIVE));
		branch.setAddress(branchAppl.getAddress());
		branch.setTenancyDoc(branchAppl.getTenancyDoc());
		branch.setIssueDate(LocalDate.now());
		if (branchAppl.getTaBranch() != null) {
			branch.setIsDownloadable(branchAppl.getTaBranch().getIsDownloadable());
		} else {
			branch.setIsDownloadable(Codes.ELicenceDownloadRequest.RESET);
		}

		repository.save(branch);
	}

	public void ceaseBranchLicence(TaBranchApplication branchAppl) {
		TaBranch branch = branchAppl.getTaBranch();
		branch.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_CEASED));
		branch.setCeasedDate(LocalDate.now());
		if (branchAppl.getType().getCode().equals(Codes.Types.TA_APP_BRANCH_UPDATE)) {
			// system remarks
			branch.setCeasedReason("Change of branch address, Application Ref No.: " + branchAppl.getTaBranchApplicationBatch().getApplication().getApplicationNo());
		}
		repository.update(branch);
	}

	/************* For TG to update licence period *********************/

	public void renewLicence(TgLicenceRenewal renewal, Boolean isRenewBeforeExpiry) {
		renewLicence(renewal, null, isRenewBeforeExpiry);
	}

	public void renewLicence(TgLicenceRenewal renewal, LocalDate printDate, Boolean isRenewBeforeExpiry) {
		Application app = renewal.getApplication();
		Licence licence = app.getLicence();
		LocalDate startDate = null;
		LocalDate expiryDate = null;

		if (isRenewBeforeExpiry) {
			startDate = licence.getExpiryDate().plusDays(1);
			expiryDate = calculateExpiryDate(licence.getExpiryDate().plusDays(1));
		} else {
			Integer validMonth = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_VALID_MONTHS).getValue());
			startDate = LocalDate.now();
			expiryDate = startDate.plusMonths(validMonth).minusDays(1);
		}

		if (printDate != null) {
			startDate = printDate;
		}

		if (!licence.getStatus().getCode().equals(Codes.Statuses.TG_ACTIVE)) {
			updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE, null, startDate.atStartOfDay());
		}

		licence.setStartDate(startDate);
		renewal.setLicenceStartDate(startDate);

		licence.setExpiryDate(expiryDate);
		renewal.setLicenceExpiryDate(expiryDate);

		Boolean setBackTgPhoto = true;
		TouristGuide tg = licence.getTouristGuide();
		for (ApplicationFile appFile : app.getApplicationFiles()) {
			if (appFile.getDocumentType().getCode().equals(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO)) {
				tg.setPhoto(appFile.getFile());
				setBackTgPhoto = false;
				break;
			}
		}
		// TG use back current photo and tied back to application
		if (setBackTgPhoto) {
			FileDto dto = new FileDto();
			dto.setDocType(Codes.TgDocumentTypes.TG_DOC_PASSPORT_PHOTO);
			File file = fileHelper.getFile(tg.getPhoto().getId());
			fileHelper.saveApplicationFile(app, file, dto);
		}

		tg.setHasConsentEmailAddress(renewal.getHasConsentEmailAddress());
		tg.setHasConsentMobileNo(renewal.getHasConsentMobileNo());

		repository.update(licence);
		repository.update(renewal);
		repository.update(tg);
	}

	public LocalDate calculateExpiryDate(LocalDate startDt) {
		// startDt = startDt.minusDays(1);
		Integer validMonth = Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_VALID_MONTHS).getValue());

		String startCycleText = cache.getSystemParameter(Codes.SystemParameters.TG_LICENCE_START_CYCLE).getValue();
		List<String> startCycleStrList = Arrays.asList(startCycleText.split(","));
		List<Integer> startCycleIntList = convertList(startCycleStrList, s -> Integer.parseInt(s));
		Collections.sort(startCycleIntList, Collections.reverseOrder());

		Integer noOfYears = (int) Math.ceil(validMonth / 12);

		// for reinstatement
		while (validMonth.compareTo((int) ChronoUnit.MONTHS.between(startDt.withDayOfMonth(1), LocalDate.now().withDayOfMonth(1))) < 0) {
			startDt = startDt.plusMonths(validMonth);
		}

		if (startCycleIntList.size() == 1 && startCycleIntList.get(0).equals(0)) {
			startDt = startDt.minusDays(1);
			var expiryDt = startDt.plusMonths(validMonth);
			return expiryDt;
		} else {
			for (int i = noOfYears; i >= 0; i--) {
				var expiryDt = startDt.plusYears(i);
				for (Integer month : startCycleIntList) {
					expiryDt = expiryDt.withMonth(month);

					if (validMonth.compareTo((int) ChronoUnit.MONTHS.between(startDt.withDayOfMonth(1), expiryDt.withDayOfMonth(1))) > 0) {
						expiryDt = expiryDt.withDayOfMonth(expiryDt.lengthOfMonth());
						return expiryDt;
					}
				}
			}
		}

		return null;
	}

	public String calculateLicenceStatus(Licence licence) {
		LocalDate now = LocalDate.now();

		if (now.isAfter(licence.getStartDate()) && now.isBefore(licence.getExpiryDate())) {
			return Codes.Statuses.TG_ACTIVE;
		} else {
			return Codes.Statuses.TG_INACTIVE;
		}
	}

	private static <T, U> List<U> convertList(List<T> from, Function<T, U> func) {
		return from.stream().map(func).collect(Collectors.toList());
	}

	public List<ListableDto> getTgLicencePastYears(Licence licence, Integer number) {
		List<ListableDto> years = Lists.newArrayList();
		Integer lastestYear = LocalDate.now().getYear();
		if (Entities.anyEquals(licence.getStatus(), Codes.Statuses.TG_INACTIVE, Codes.Statuses.TG_CANCELLED, Codes.Statuses.TG_REVOKED)) {
			lastestYear = licence.getExpiryDate().getYear();
		}
		for (int i = 0; i < number; i++) {
			Integer year = lastestYear - i;
			years.add(new ListableDto(year, DateUtil.format(LocalDate.of(year, 1, 1)) + " to " + DateUtil.format(LocalDate.of(year, 12, 31))));
		}
		return years;
	}

	/************* END For TG to update licence period *********************/

	public void liftSuspensionRevocation(Licence lic) {

		Status licStatus = lic.getStatus();

		// for TA, there is no way to lift revocation, TA have to register again/ STB to request for data patch
		if (Codes.TaTgType.TA.equals(lic.getTaTgType())) {

			// if current status is pending revocation / pending suspension, system have to change back to active
			if (Entities.anyEquals(licStatus, Codes.Statuses.TA_PEND_REVOCATION, Codes.Statuses.TA_PEND_SUSPENSION)) {
				updateLicenceStatus(lic, Codes.Statuses.TA_ACTIVE);
			}

			// if current status is suspended, system have to change the licence status back to active
			// and also update all branches to active as well
			else if (Entities.equals(licStatus, Codes.Statuses.TA_SUSPENDED)) {
				updateLicenceStatus(lic, Codes.Statuses.TA_ACTIVE);
				List<TaBranch> branches = repository.getAllMSuspendedBranchesByLicenceId(lic.getId());
				if (CollectionUtils.isNotEmpty(branches)) {
					branches.forEach(b -> {
						b.setCeasedDate(null);
						b.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_ACTIVE));
					});
					repository.update(branches);
				}
			}

		} else {
			// For TG, no pending suspension / pending revocation status
			List<String> excludeStatus = new ArrayList<>();
			if (Entities.equals(licStatus, Codes.Statuses.TG_SUSPENDED)) {
				excludeStatus = Arrays.asList(Codes.Statuses.TG_SUSPENDED);
			} else {
				excludeStatus = Arrays.asList(Codes.Statuses.TG_REVOKED);
			}

			StatusSpan lastStatusSpan = repository.getLastStatusSpan(lic.getId(), excludeStatus);
			updateLicenceStatus(lic, lastStatusSpan.getStatus().getCode());

		}
	}

	public void suspendLicence(Licence lic) {
		Status licStatus = lic.getStatus();
		if (Codes.TaTgType.TA.equals(lic.getTaTgType())) {

			// suspend if current licence status is not revoked/suspended/ceased
			// update all active branches status to TA_BRANCH_M_SUSPEND as well
			if (!Entities.anyEquals(licStatus, Codes.Statuses.TA_REVOKED, Codes.Statuses.TA_SUSPENDED, Codes.Statuses.TA_CEASED)) {
				updateLicenceStatus(lic, Codes.Statuses.TA_SUSPENDED);
				List<TaBranch> branches = repository.getAllActiveBranchesByLicenceId(lic.getId());
				if (CollectionUtils.isNotEmpty(branches)) {
					branches.forEach(b -> {
						b.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_M_SUSPEND));
					});
					repository.update(branches);
				}
			}

		} else {

			// suspend if current licence status is not revoked/suspended/cancelled
			if (!Entities.anyEquals(licStatus, Codes.Statuses.TG_REVOKED, Codes.Statuses.TG_SUSPENDED, Codes.Statuses.TG_CANCELLED)) {
				updateLicenceStatus(lic, Codes.Statuses.TG_SUSPENDED);
			}
		}
		repository.update(lic);
	}

	public void revokeLicence(Licence lic) {
		Status licStatus = lic.getStatus();
		if (Codes.TaTgType.TA.equals(lic.getTaTgType())) {

			// revoke if current licence status is not revoked/ceased
			// update all active branches status to TA_BRANCH_M_REVOKED as well
			if (!Entities.anyEquals(licStatus, Codes.Statuses.TA_REVOKED, Codes.Statuses.TA_CEASED)) {
				lic.setCeasedDate(LocalDate.now());
				updateLicenceStatus(lic, Codes.Statuses.TA_REVOKED);
				List<TaBranch> branches = repository.getAllActiveSuspendedBranchesByLicenceId(lic.getId());
				if (CollectionUtils.isNotEmpty(branches)) {
					branches.forEach(b -> {
						b.setCeasedDate(LocalDate.now());
						b.setStatus(cache.getStatus(Codes.Statuses.TA_BRANCH_M_REVOKED));
					});
					repository.update(branches);
				}
			}

		} else {

			// revoke if current licence status is not revoked/cancelled
			if (!Entities.anyEquals(licStatus, Codes.Statuses.TG_REVOKED, Codes.Statuses.TG_CANCELLED)) {
				lic.setCeasedDate(LocalDate.now());
				updateLicenceStatus(lic, Codes.Statuses.TG_REVOKED);
			}
		}
	}
}
