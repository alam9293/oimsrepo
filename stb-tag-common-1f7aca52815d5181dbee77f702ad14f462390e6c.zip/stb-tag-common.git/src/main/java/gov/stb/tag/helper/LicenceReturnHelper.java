package gov.stb.tag.helper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.LicenceReturn;
import gov.stb.tag.model.LicenceReturnBatch;
import gov.stb.tag.model.TaBranch;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.LicenceReturnHelperRepository;

@Component
public class LicenceReturnHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;
	@Autowired
	LicenceReturnHelperRepository repository;

	public LicenceReturnBatch createBatchRecord(Licence licence, Licence main, List<TaBranch> branches, Type type, LocalDate dueDate, Application app) {
		LicenceReturnBatch batch = new LicenceReturnBatch();
		batch.setLicence(licence);
		batch.setStatus(cache.getStatus(Codes.Statuses.LCRTN_PENDING));
		batch.setDueDate(dueDate);
		batch.setType(type);
		if (app != null) {
			batch.setApplication(app);
		}

		List<LicenceReturn> licencesToBeReturned = new ArrayList<>();
		if (branches != null) {
			for (TaBranch branch : branches) {
				if (!branch.getStatus().getCode().equals(Codes.Statuses.TA_BRANCH_CEASED)) {
					licencesToBeReturned.add(createRecord(branch, type, batch));
				}

			}
		}
		if (main != null) {
			licencesToBeReturned.add(createRecord(main, type, batch));
		}

		repository.save(licencesToBeReturned);
		batch.setLicences(new HashSet<>(licencesToBeReturned));
		repository.save(batch);
		return batch;

	}

	public LicenceReturn createRecord(Licence main, Type type, LicenceReturnBatch batch) {
		LicenceReturn record = new LicenceReturn();
		record.setLicence(main);
		record.setBatch(batch);
		return record;

	}

	public LicenceReturn createRecord(TaBranch branch, Type type, LicenceReturnBatch batch) {
		LicenceReturn record = new LicenceReturn();
		record.setBranch(branch);
		record.setBatch(batch);
		return record;

	}

	public void markAsReturned(List<Integer> licences, Integer id) {
		for (Integer licence : licences) {
			LicenceReturn lr = repository.get(LicenceReturn.class, licence);
			lr.setReturnedDate(LocalDate.now());
		}

		checkAndFulfill(id);
	}

	public void checkAndFulfill(Integer id) {
		if (!repository.checkForPendingRecordsForBatch(id)) {
			LicenceReturnBatch lrb = repository.get(LicenceReturnBatch.class, id);
			if (!lrb.getStatus().getCode().equals(Codes.Statuses.LCRTN_VOID)) {
				lrb.setStatus(cache.getStatus(Codes.Statuses.LCRTN_FULFILLED));
				repository.save(lrb);
			}

		}

	}

	public void voidBatchRecord(Integer id) {
		LicenceReturnBatch lrb = repository.get(LicenceReturnBatch.class, id);
		lrb.setStatus(cache.getStatus(Codes.Statuses.LCRTN_VOID));
		repository.save(lrb);

	}
}
