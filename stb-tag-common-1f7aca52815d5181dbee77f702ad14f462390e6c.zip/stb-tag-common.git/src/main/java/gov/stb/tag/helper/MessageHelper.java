package gov.stb.tag.helper;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Codes.Types;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.EmailLicenseeDto;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.PaymentRefund;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.PaymentTxn;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.TaFilingCondition;
import gov.stb.tag.model.TaFyUpdate;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.TaLicenceRenewalExercise;
import gov.stb.tag.model.TaNetValueRectification;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TaStakeholderApplication;
import gov.stb.tag.model.TgLicenceMlptRegistration;
import gov.stb.tag.model.TgMlpt;
import gov.stb.tag.model.TgMlptSlot;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;
import gov.stb.tag.util.DateUtil;
import gov.stb.tag.util.NumeralUtil;

@Component
@Transactional
public class MessageHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	CacheHelper cache;

	@Autowired
	Properties properties;

	public String replace(String text, String oldChar, String newChar) {
		return (oldChar == null || newChar == null) ? text : text.replace(oldChar, StringEscapeUtils.escapeXml11(newChar));
	}

	public String replaceHTML(String text, String oldChar, String newChar) {
		return (oldChar == null || newChar == null) ? text : text.replace(oldChar, newChar);
	}

	public String formatGeneralPlaceholders(String text) {
		text = text.replace(Codes.Placeholders.CURRENT_DATE, DateUtil.format(LocalDate.now(), DateUtil.DATE_FORMAT_PATTERN));
		return text;
	}

	public String formatPaymentRefundPlaceholders(String text, PaymentRefund refund) {
		text = replace(text, Codes.Placeholders.PAY_REF_NO, refund.getBillRefNo());
		text = replace(text, Codes.Placeholders.PAY_REF_AMT, refund.getRefundAmount().toString());
		return text;
	}

	public String formatTaPlaceholders(String text, TravelAgent ta) {
		text = replace(text, Codes.Placeholders.TA_NAME, ta.getName());
		text = replace(text, Codes.Placeholders.TA_UEN, ta.getUen());
		return text;
	}

	public String formatKePlaceholders(String text, TravelAgent ta, Stakeholder ke) {
		text = replace(text, Codes.Placeholders.KE_NAME, ke == null ? ta.getName() : ke.getName());
		text = replace(text, Codes.Placeholders.TA_NAME, ta.getName());
		text = replace(text, Codes.Placeholders.TA_UEN, ta.getUen());
		return text;
	}

	public String formatTgPlaceholders(String text, TouristGuide tg) {
		text = replace(text, Codes.Placeholders.TG_NAME, tg.getName());
		text = replace(text, Codes.Placeholders.TG_NRIC, tg.getUin());
		return text;
	}

	public String formatUserPlaceholders(String text, User user) {
		text = replace(text, Codes.Placeholders.USER_NAME, user.getName());
		text = replace(text, Codes.Placeholders.LOGIN_ID, user.getLoginId());

		return text;
	}

	public String formatTgMlptPlaceholders(String text, String tgName, TgLicenceMlptRegistration mlptRegistration, String url) {
		text = replace(text, Codes.Placeholders.TG_NAME, tgName);

		String textLanguage = "";

		if (mlptRegistration != null && !mlptRegistration.getTgMlptSlots().isEmpty()) {
			if (text.contains(Codes.Placeholders.TG_MLPT_LANGUAGE)) {
				for (TgMlptSlot slot : mlptRegistration.getTgMlptSlots()) {
					String guidingLanguage = String.format("%s %s %s", "<li>", slot.getGuidingLanguage().getLabel(), "</li>");
					textLanguage = textLanguage + guidingLanguage;
				}
				text = replaceHTML(text, Codes.Placeholders.TG_MLPT_LANGUAGE, textLanguage);
			}

			TgMlpt tgMlpt = mlptRegistration.getTgMlpt();
			if (tgMlpt != null) {
				text = replace(text, Codes.Placeholders.TG_MLPT_START_DATE, DateUtil.format(tgMlpt.getMlptStartDate()));
				text = replace(text, Codes.Placeholders.TG_MLPT_END_DATE, DateUtil.format(tgMlpt.getMlptEndDate()));
			}

			if (text.contains(Codes.Placeholders.TG_MLPT_ALLOCATIONS)) {
				Set<TgMlptSlot> slots = mlptRegistration.getTgMlptSlots();
				String allocations = "";
				if (slots.size() == 1) {
					allocations = "The test date assigned is:<p><ol>";
				} else {
					allocations = "The test dates assigned are:<p><ol>";
				}
				for (TgMlptSlot slot : slots) {
					String allocation = String.format("<li>%s - %s-%s</li>", slot.getGuidingLanguage().getLabel(), DateUtil.format(slot.getStartTime(), DateUtil.DATETIME_FORMAT_PATTERN_2),
							slot.getStartTime().toLocalTime().plusMinutes(30));
					allocations += allocation;
				}
				allocations += "</ol>";
				text = replaceHTML(text, Codes.Placeholders.TG_MLPT_ALLOCATIONS, allocations);
			}

			if (text.contains(Codes.Placeholders.TG_MLPT_RESULTS)) {
				Set<TgMlptSlot> slots = mlptRegistration.getTgMlptSlots();
				String results = "";
				if (slots.size() == 1) {
					results = "The result, for the following language, is as follow:";
				} else {
					results = "The results, for the following languages, are as follow:";
				}
				results += "<p><br>";
				results += "<p><table border='1' cellpadding='5'";
				results += "<tr>";
				results += "<th></th>";
				results += "<th>Language</th>";
				results += "<th>Test date/ time</th>";
				results += "<th>Result</th>";
				results += "<th>Next Step</th>";
				results += "</tr>";
				Integer i = 1;
				for (TgMlptSlot slot : slots) {
					String nextStep = "Click <a href=" + url + ">here</a> to view next MLPT schedule.";
					if (Codes.Statuses.TG_MLPT_COMPETENT.equals(slot.getResultStatus().getCode())) {
						nextStep = "Click <a href=" + url + ">here</a> for new licence payment. You will be contacted on the licence collection when ready";
					}
					String result = String.format("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>", i++, slot.getGuidingLanguage().getLabel(),
							DateUtil.format(slot.getStartTime(), DateUtil.DATE_FORMAT_PATTERN_2), slot.getResultStatus().getLabel(), nextStep);
					results += result;
				}
				results += "</table>";
				text = replaceHTML(text, Codes.Placeholders.TG_MLPT_RESULTS, results);
			}
		}
		return text;
	}

	public String formatAppPlaceholders(String text, Application app, String url, BigDecimal appAmount) {

		text = replace(text, Codes.Placeholders.APP_TYPE, app.getType().getLabel());
		if (app.getLastAction() != null) {
			text = replace(text, Codes.Placeholders.APP_STATUS, app.getLastAction().getStatus().getOtherLabel());
		}

		text = replace(text, Codes.Placeholders.APP_LINK, url);
		text = replace(text, Codes.Placeholders.APP_REF, app.getApplicationNo());
		text = replace(text, Codes.Placeholders.APP_SUBMISISON_DATE, DateUtil.format(app.getUpdatedDate(), DateUtil.DATE_FORMAT_PATTERN));
		text = replace(text, Codes.Placeholders.TG_SUPPORT_EMAIL, cache.getSystemParameter(Codes.SystemParameters.TG_SUPPORT_EMAIL).getValue());
		if (appAmount != null) {
			text = replace(text, Codes.Placeholders.APP_AMOUNT, appAmount.toString());
		}
		return text;
	}

	public String formatAppPlaceholders(String text, Application app, String url, BigDecimal appAmount, BigDecimal secAppAmount) {

		text = replace(text, Codes.Placeholders.APP_TYPE, app.getType().getLabel());
		if (app.getLastAction() != null) {
			text = replace(text, Codes.Placeholders.APP_STATUS, app.getLastAction().getStatus().getOtherLabel());
		}

		text = replace(text, Codes.Placeholders.APP_LINK, url);
		text = replace(text, Codes.Placeholders.APP_REF, app.getApplicationNo());
		text = replace(text, Codes.Placeholders.APP_SUBMISISON_DATE, DateUtil.format(app.getUpdatedDate(), DateUtil.DATE_FORMAT_PATTERN));
		if (appAmount != null) {
			text = replace(text, Codes.Placeholders.APP_AMOUNT, appAmount.toString());
		}
		if (secAppAmount != null) {
			text = replace(text, Codes.Placeholders.SEC_APP_AMOUNT, secAppAmount.toString());
		}
		return text;
	}

	public String formatPaymentPlaceholders(String text, PaymentTxn txn) {

		text = replace(text, Codes.Placeholders.PAY_AMT, txn.getAmount().toString());
		text = replace(text, Codes.Placeholders.PAY_DATE, DateUtil.format(txn.getTxnDate()));
		text = replace(text, Codes.Placeholders.PAY_TXN_ID, txn.getId().toString());

		String payReqType = "";
		for (PaymentRequest payreq : txn.getPaymentRequests()) {
			payReqType = payReqType + ", " + cache.getLabel(payreq.getType(), false) + "(" + payreq.getBillRefNo() + ")";
		}
		text = replace(text, Codes.Placeholders.PAY_REQ_TYPE, payReqType.substring(2, payReqType.length()));
		return text;
	}

	public String formatUrlPlaceholders(String text, String url) {
		text = replace(text, Codes.Placeholders.APP_LINK, url);
		return text;
	}

	public String formatAppTypePlaceholdersToLowerCase(String text, Application app) {
		text = replace(text, Codes.Placeholders.APP_TYPE, app.getType().getLabel().toLowerCase());
		return text;
	}

	public String formatSignaturePlaceholders(String text, User officer) {

		if (officer != null) {
			text = replace(text, Codes.Placeholders.OFFICER_NAME, officer.getName());
			text = replace(text, Codes.Placeholders.OFFICER_DEPT, cache.getLabel(officer.getDepartment(), false));
		} else {
			text = replace(text, Codes.Placeholders.OFFICER_NAME, "");
			text = replace(text, Codes.Placeholders.OFFICER_DEPT, "");
		}

		text = replace(text, Codes.Placeholders.STB_ORGANISATION, cache.getSystemParameter(Codes.SystemParameters.STB_ORGANISATION).getValue());
		text = replace(text, Codes.Placeholders.TA_SUPPORT_EMAIL, cache.getSystemParameter(Codes.SystemParameters.TA_SUPPORT_EMAIL).getValue());
		text = replace(text, Codes.Placeholders.TG_SUPPORT_EMAIL, cache.getSystemParameter(Codes.SystemParameters.TG_SUPPORT_EMAIL).getValue());
		return text;
	}

	public String formatKePlaceholders(String text, TaStakeholderApplication ke, String url) {

		text = replace(text, Codes.Placeholders.KE_UIN, ke.getUin());
		text = replace(text, Codes.Placeholders.APP_LINK, url);
		return text;
	}

	public String formatKePlaceholders(String text, TaStakeholderApplication keApp) {

		text = replace(text, Codes.Placeholders.TA_NAME, keApp.getApplication().getLicence().getTravelAgent().getName());
		text = replace(text, Codes.Placeholders.TA_UEN, keApp.getApplication().getLicence().getTravelAgent().getUen());
		return text;
	}

	public String formatTaLicenceStatusUpdatePlaceholders(String text, StatusSpan statusSpan) {

		text = replace(text, Codes.Placeholders.TA_LICENCE_UPDATE_ACTION, statusSpan.getStatus().getLabel());
		text = replace(text, Codes.Placeholders.EXTERNAL_REMARKS, statusSpan.getExternalRemarks());
		return text;
	}

	public String formatLicenceStatusUpdatePlaceholders(String text, StatusSpan statusSpan) {

		text = replace(text, Codes.Placeholders.LICENCE_UPDATE_ACTION, statusSpan.getStatus().getLabel());
		return text;
	}

	public String formatTaLicenceCreationPlaceholders(String text, TaLicenceCreation tlc) {

		text = replace(text, Codes.Placeholders.TA_LICENCE_CREATION_APPNAME, tlc.getAppName());
		text = replace(text, Codes.Placeholders.TA_LICENCE_CREATION_DRAFT_EXPIRY,
				DateUtil.format(tlc.getCreatedDate().plusDays(Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.APP_DRAFT_VALIDITY).getValue())).toLocalDate()));
		text = replace(text, Codes.Placeholders.TA_NAME, tlc.getCompanyName());
		text = replace(text, Codes.Placeholders.TA_UEN, tlc.getUen());
		return text;
	}

	public String formatTaLicencerRenewalReminderPlaceholders(String text, TaLicenceRenewalExercise renewalExercise, Licence lic) {

		text = replace(text, Codes.Placeholders.TA_RENEWAL_EXERCISE_END_DATE, DateUtil.format(renewalExercise.getEndDate()));
		text = replace(text, Codes.Placeholders.TA_RENEWAL_EXERCISE_START_DATE, DateUtil.format(renewalExercise.getStartDate()));
		text = replace(text, Codes.Placeholders.TA_RENEWAL_EXERCISE_LATE_DATE, DateUtil.format(renewalExercise.getEndDate().plusDays(14)));
		text = replace(text, Codes.Placeholders.TA_RENEWAL_EXERCISE_YEAR, Integer.toString(renewalExercise.getStartDate().getYear()));
		text = replace(text, Codes.Placeholders.TA_lICENCE_EXPIRY_DATE, DateUtil.format(lic.getExpiryDate()));
		text = replace(text, Codes.Placeholders.TA_lICENCE_EXPIRY_DATE_AFTER, DateUtil.format(lic.getExpiryDate().plusDays(1)));

		return text;
	}

	public String formatAssignKePlaceholders(String text, TaStakeholderApplication keApp) {

		text = replace(text, Codes.Placeholders.TA_NAME, keApp.getApplication().getLicence().getTravelAgent().getName());
		text = replace(text, Codes.Placeholders.TA_UEN, keApp.getApplication().getLicence().getTravelAgent().getUen());
		return text;
	}

	public String formatShortfallRectificationPlaceholders(String text, TaNetValueRectification rectification) {
		LocalDate dueDate = null;
		for (TaNetValueShortfall shortfall : rectification.getAllTaNetValueShortfalls()) {
			dueDate = DateUtil.getMinDate(dueDate, (shortfall.getExtendedDueDate() == null ? shortfall.getRectificationDueDate() : shortfall.getExtendedDueDate()));
		}
		text = replace(text, Codes.Placeholders.TA_SHORTFALL_RECTIFICATION_DUE_DATE, DateUtil.format(dueDate));
		return text;
	}

	public HashMap<String, String> populateTgContentDetails(Application app, String name, String courseName, String url, String templateCode) {

		HashMap<String, String> contentDetails = new HashMap<>();
		contentDetails.put(Codes.Placeholders.APP_TYPE, app.getType().getLabel());
		if (app.getLastAction() != null) {
			contentDetails.put(Codes.Placeholders.APP_STATUS, app.getLastAction().getStatus().getLabel());
		}
		contentDetails.put(Codes.Placeholders.APP_LINK, url);
		contentDetails.put(Codes.Placeholders.APP_REF, app.getApplicationNo());
		if (app.getTgCourse() != null) {
			contentDetails.put(Codes.Placeholders.TG_COURSE_NAME, app.getTgCourse().getName());
			contentDetails.put(Codes.Placeholders.TG_REMARK, app.getLastAction().getExternalRemarks());
		} else {
			contentDetails.put(Codes.Placeholders.TG_COURSE_NAME, courseName);
		}
		contentDetails.put(Codes.Placeholders.TG_NAME, name);
		contentDetails.put(Codes.Placeholders.TP_NAME, name);
		if (StringUtils.equalsAny(templateCode, Codes.EmailType.TG_COURSE_UPON_REJECTION, Codes.EmailType.TG_COURSE_UPON_RFA, Codes.EmailType.TG_UPON_REJECTION, Codes.EmailType.TG_UPON_RFA)) {
			contentDetails.put(Codes.Placeholders.TG_REMARK, app.getLastAction().getExternalRemarks());
		}

		return contentDetails;
	}

	public String formatTgPlaceholders(String text, HashMap<String, String> contentDetails) {
		for (HashMap.Entry<String, String> content : contentDetails.entrySet()) {
			text = replace(text, content.getKey(), content.getValue());
		}
		return text;
	}

	public HashMap<String, String> populateTgLicenceCollection(Application app, String tgName, String workPassType, LocalDate collectionStartDate, LocalDate collectionEndDate) {
		HashMap<String, String> contentDetails = new HashMap<>();
		contentDetails.put(Codes.Placeholders.APP_TYPE, app.getType().getLabel());
		contentDetails.put(Codes.Placeholders.TG_NAME, tgName);
		contentDetails.put(Codes.Placeholders.TG_WORKPASS_TYPE, workPassType);
		contentDetails.put(Codes.Placeholders.TG_LIC_COLLECTION_START_DATE, DateUtil.format(collectionStartDate));
		contentDetails.put(Codes.Placeholders.TG_LIC_COLLECTION_END_DATE, DateUtil.format(collectionEndDate));
		return contentDetails;
	}

	public HashMap<String, String> populateTgLicenceUpdate(String tgName, StatusSpan statusSpan) {
		HashMap<String, String> contentDetails = new HashMap<>();
		contentDetails.put(Codes.Placeholders.TG_NAME, tgName);
		contentDetails.put(Codes.Placeholders.LICENCE_UPDATE_ACTION, statusSpan.getStatus().getLabel());
		return contentDetails;
	}

	public String formatPlaceholders(String text, HashMap<String, String> contentDetails) {
		for (HashMap.Entry<String, String> content : contentDetails.entrySet()) {
			text = replace(text, content.getKey(), content.getValue());
		}
		return text;
	}

	public HashMap<String, String> populateUserLoginDetails(User user, String password) {
		HashMap<String, String> contentDetails = new HashMap<>();
		contentDetails.put(Codes.Placeholders.USER_NAME, user.getName());
		contentDetails.put(Codes.Placeholders.LOGIN_ID, user.getLoginId());
		contentDetails.put(Codes.Placeholders.PASSWORD, password);
		return contentDetails;
	}

	public String formatTaFilingSubmissionReminderPlaceholders(String text, List<TaFilingCondition> taFilingConditions, String companyName, String officerName) {

		text = replace(text, Codes.Placeholders.COMPANY_NAME, companyName);
		text = replace(text, Codes.Placeholders.OFFICER_NAME, officerName);

		StringBuilder outstandingSubmission = null;
		StringBuilder outstandingSubmissionList = null;
		StringBuilder outstandingSubmissionWithDate = null;

		taFilingConditions.sort((TaFilingCondition o1, TaFilingCondition o2) -> o1.getApplicationType().getLabel().compareTo(o2.getApplicationType().getLabel()));
		for (TaFilingCondition tfc : taFilingConditions) {
			String appType = cache.getLabel(tfc.getApplicationType(), false);
			outstandingSubmission = (outstandingSubmission == null) ? new StringBuilder(appType) : outstandingSubmission.append(" and ").append(appType);

			StringBuilder temp = new StringBuilder().append("");
			if (tfc != null && tfc.getFyDueDate() != null) {
				temp = new StringBuilder("<li>").append(appType).append(" by ").append(DateUtil.format(tfc.getFyDueDate(), DateUtil.DATE_FORMAT_PATTERN_2)).append("</li>");
			}
			outstandingSubmissionList = (outstandingSubmissionList == null) ? temp : outstandingSubmissionList.append(temp);

			StringBuilder temp1 = new StringBuilder().append("");
			if (tfc != null && tfc.getFyDueDate() != null) {
				temp1 = new StringBuilder(appType).append(" due on ").append(DateUtil.format(tfc.getFyDueDate(), DateUtil.DATE_FORMAT_PATTERN_2));
			}
			outstandingSubmissionWithDate = (outstandingSubmissionWithDate == null) ? temp1 : outstandingSubmissionWithDate.append(" and ").append(temp1);
		}

		text = replace(text, Codes.Placeholders.OUTSTANDING_SUBMISSION, outstandingSubmission.toString());
		text = replaceHTML(text, Codes.Placeholders.OUTSTANDING_SUBMISSION_LIST, outstandingSubmissionList.toString());
		text = replace(text, Codes.Placeholders.OUTSTANDING_SUBMISSION_WITH_DATE, outstandingSubmissionWithDate.toString());

		return text;
	}

	public String formatShortfallTaskPlaceholders(String text, TaNetValueShortfall shortfall) {
		text = replace(text, Codes.Placeholders.AMOUNT, NumberFormat.getCurrencyInstance().format(shortfall.getAmount()));
		text = replace(text, Codes.Placeholders.EXTENSION, shortfall.getExtendedDueDate() == null ? "" : "extended ");
		text = replace(text, Codes.Placeholders.DUE_DATE, DateUtil.format(shortfall.getExtendedDueDate() == null ? shortfall.getRectificationDueDate() : shortfall.getExtendedDueDate()));
		text = replace(text, Codes.Placeholders.APP_TYPE, cache.getLabel(cache.getType(Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION), true));
		return text;
	}

	public String formatScheduleTaskPlaceholders(String text, LocalDate fromDate, LocalDate toDate) {
		if (fromDate != null && toDate != null) {
			text = replace(text, Codes.Placeholders.PERIOD, DateUtil.format(fromDate).concat(" to ").concat(DateUtil.format(toDate)));
		} else if (fromDate != null) {
			text = replace(text, Codes.Placeholders.PERIOD, DateUtil.format(fromDate, DateUtil.MONTH_YEAR_PATTERN));
		}
		return text;
	}

	public String formatProvision(String text, String chapterCode, String section) {
		text = replace(text, Codes.Placeholders.PROVISION, chapterCode.concat(StringUtils.SPACE).concat(section));
		return text;
	}

	public String formatTaFilingConditionTaskPlaceholders(String text, TaFilingCondition taFilingCondition) {
		text = replace(text, Codes.Placeholders.FYE, DateUtil.format(taFilingCondition.getFyEndDate()));
		text = replace(text, Codes.Placeholders.EXTENSION, taFilingCondition.getLastExtension() == null ? "" : "extended ");
		text = replace(text, Codes.Placeholders.DUE_DATE,
				DateUtil.format(taFilingCondition.getLastExtension() == null ? taFilingCondition.getDueDate() : taFilingCondition.getLastExtension().getExtendedDueDate()));
		text = replace(text, Codes.Placeholders.APP_TYPE, cache.getLabel(taFilingCondition.getApplicationType(), true));
		return text;
	}

	public String formatShortfallNotifyEmailPlaceholders(String text, TaNetValueShortfall taNetValueShortfall) {
		TaFilingCondition taFilingCondition = null;
		if (taNetValueShortfall.getTaAaSubmission() != null) {
			taFilingCondition = taNetValueShortfall.getTaAaSubmission().getTaAnnualFiling();
		} else if (taNetValueShortfall.getTaMaSubmission() != null) {
			taFilingCondition = taNetValueShortfall.getTaMaSubmission().getTaFilingCondition();
		}
		text = replace(text, Codes.Placeholders.FYE, DateUtil.format(taFilingCondition.getFyEndDate()));
		text = replace(text, Codes.Placeholders.DUE_DATE,
				DateUtil.format(taNetValueShortfall.getExtendedDueDate() == null ? taNetValueShortfall.getRectificationDueDate() : taNetValueShortfall.getExtendedDueDate()));
		text = replace(text, Codes.Placeholders.APP_TYPE, cache.getLabel(cache.getType(Codes.ApplicationTypes.TA_APP_NET_VALUE_RECTIFICATION), true));
		return text;
	}

	public String formatTaFyUpdateTaskPlaceholders(String text, TaFyUpdate taFyUpdate) {
		text = replace(text, Codes.Placeholders.FYE_OLD, DateUtil.format(taFyUpdate.getOldFyeDate()));
		text = replace(text, Codes.Placeholders.FYE_NEW, DateUtil.format(taFyUpdate.getNewFyeDate()));
		text = replace(text, Codes.Placeholders.FYE, DateUtil.format(taFyUpdate.getFyStartDate().minusDays(1)));
		return text;
	}

	public String formatTaKeTaskPlaceholders(String text, LocalDate resignationDate, String duration) {
		text = replace(text, Codes.Placeholders.RESIGNATION_DATE, DateUtil.format(resignationDate));
		text = replace(text, Codes.Placeholders.PERIOD, duration);
		return text;
	}

	public String formatTaLicenceNotReturnPlaceholders(String text, LocalDate ceasedDate, String duration) {
		text = replace(text, Codes.Placeholders.CEASED_DATE, DateUtil.format(ceasedDate));
		text = replace(text, Codes.Placeholders.PERIOD, duration);
		return text;
	}

	public String formatAFPPaymentPlaceholders(String text, String amount, LocalDate paymentDueDate, String billRefNo) {
		text = replace(text, Codes.Placeholders.AMOUNT, amount);
		text = replace(text, Codes.Placeholders.DUE_DATE, DateUtil.format(paymentDueDate));
		text = replace(text, Codes.Placeholders.BILL_REF_NO, billRefNo);
		return text;
	}

	public String formatCasePlaceholders(String text, CeCase ceCase) {
		if (ceCase != null) {
			text = replace(text, Codes.Placeholders.CASE_NO, ceCase.getCaseNo());
		}
		return text;
	}

	public String formatLicExpiryEmailNotifPlaceHolder(String text, Licence lic) {
		TouristGuide tg = lic.getTouristGuide();
		text = replace(text, Codes.Placeholders.TG_SALUTATION, cache.getLabel(tg.getSalutation(), false));
		text = replace(text, Codes.Placeholders.TG_NAME, tg.getName());
		text = replace(text, Codes.Placeholders.TG_LICENCE_EXPIRY_DATE, DateUtil.format(lic.getExpiryDate()));
		text = replace(text, Codes.Placeholders.TG_LICENCE_EXPIRY_DATE_1_MTH_B4, DateUtil.format(lic.getExpiryDate().minusMonths(1)));
		text = replace(text, Codes.Placeholders.TG_SUPPORT_EMAIL, cache.getSystemParameter(Codes.SystemParameters.TG_SUPPORT_EMAIL).getValue());
		text = text.replace(Codes.Placeholders.EFFECTIVE_DATE, DateUtil.format(lic.getExpiryDate().plusDays(1), DateUtil.DATE_FORMAT_PATTERN));
		return text;
	}

	public String formatToLMSEmailError(String text, String strError) {

		text = replace(text, Codes.Placeholders.TG_DATA_LMS_ERROR, strError);
		return text;
	}

	public String formatFromLMSEmailError(String text, String strError) {

		text = replace(text, Codes.Placeholders.TG_MRC_LMS_ERROR, strError);
		return text;
	}

	public String formatEmailBroadcastPlaceholders(String text, EmailLicenseeDto ta, Stakeholder ke) {
		text = replace(text, Codes.Placeholders.KE_NAME, ke == null ? ta.getName() : ke.getName());
		text = replace(text, Codes.Placeholders.TA_NAME, ta.getName());
		text = replace(text, Codes.Placeholders.TA_UEN, ta.getUen());
		text = replace(text, Codes.Placeholders.LIC_NO, ta.getLicNo());
		text = replaceHTML(text, Codes.Placeholders.MAIN_OPERATING_ADDRESS, ta.getMainLicOppAdd());
		text = replaceHTML(text, Codes.Placeholders.MAIN_REGISTERED_ADDRESS, ta.getMainLicRegAdd());
		text = replace(text, Codes.Placeholders.LIC_TYPE, ta.getLicType());
		text = replace(text, Codes.Placeholders.LIC_STATUS, ta.getLicStatus());
		if (ta.getRecipient() != null) {
			text = replace(text, Codes.Placeholders.RECIPIENT_NAME, ta.getRecipient().getRecipientName());
			text = replaceHTML(text, Codes.Placeholders.RECIPIENT_HOME_ADDRESS, ta.getRecipient().getRecipientHomeAdd());
			text = replace(text, Codes.Placeholders.RECIPIENT_DESIGNATION, ta.getRecipient().getRecipientDesignation());
			text = replace(text, Codes.Placeholders.SALUTATION_FORMAL,
					ta.getRecipient().getGenderCode() != null ? ta.getRecipient().getGenderCode().equalsIgnoreCase(Types.SEX_M) ? "Sir" : "Madam" : ""); // Sir/Madam base on gender
			text = replace(text, Codes.Placeholders.SALUTATION_BASIC, ta.getRecipient().getGenderCode() != null ? ta.getRecipient().getGenderCode().equalsIgnoreCase(Types.SEX_M) ? "Mr." : "Ms." : ""); // Mr./Ms.
		}
		text = replace(text, Codes.Placeholders.DIRECTOR_NAME, ta.getDirName());
		return text;
	}

	public String formatTaNetValueShortfallLetterPlaceholders(String text, TaNetValueShortfall shortfall, Licence lic, TravelAgent ta, Stakeholder ke) {

		text = replace(text, Codes.Placeholders.KE_NAME, ke == null ? ta.getName() : ke.getName());
		text = replace(text, Codes.Placeholders.TA_NAME, ta.getName());
		text = replace(text, Codes.Placeholders.TA_UEN, ta.getUen());
		text = replace(text, Codes.Placeholders.LICENCE_NO, "TA" + lic.getLicenceNo());

		TaFilingCondition condition = null;
		if (shortfall.getTaAaSubmission() != null) {
			condition = shortfall.getTaAaSubmission().getTaAnnualFiling();
			text = replace(text, Codes.Placeholders.TA_SHORTFALL_FOR, cache.getLabel(cache.getType(Codes.ApplicationTypes.TA_APP_AA_SUBMISSION), true));
			text = replace(text, Codes.Placeholders.NET_VALUE, NumeralUtil.formatToLocalCurrency(shortfall.getTaAaSubmission().getNetValue()));
		} else if (shortfall.getTaMaSubmission() != null) {
			condition = shortfall.getTaMaSubmission().getTaFilingCondition();
			text = replace(text, Codes.Placeholders.TA_SHORTFALL_FOR, cache.getLabel(cache.getType(Codes.ApplicationTypes.TA_APP_MA_SUBMISSION), false));
			text = replace(text, Codes.Placeholders.NET_VALUE, NumeralUtil.formatToLocalCurrency(shortfall.getTaMaSubmission().getNetValue()));
		}

		text = replace(text, Codes.Placeholders.FYE, DateUtil.format(condition.getFyEndDate()));

		Integer financialRequirement = (lic.getTier().getKey().equals(Codes.Types.TA_TIER_GENERAL)
				? Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_GENERAL_FINANICAL_REQUIREMENT).getValue())
				: Integer.parseInt(cache.getSystemParameter(Codes.SystemParameters.TA_NICHE_FINANICAL_REQUIREMENT).getValue()));

		text = replace(text, Codes.Placeholders.TA_MIN_FINANCIAL_REQUIREMENT, NumeralUtil.formatToLocalCurrency(BigDecimal.valueOf(financialRequirement)));
		text = replace(text, Codes.Placeholders.TA_SHORTFALL_AMOUNT, NumeralUtil.formatToLocalCurrency(shortfall.getAmount()));
		text = replace(text, Codes.Placeholders.TA_RECTIFICATION_DUE_DATEE,
				shortfall.getExtendedDueDate() == null ? DateUtil.format(shortfall.getRectificationDueDate()) : DateUtil.format(shortfall.getExtendedDueDate()));
		text = replace(text, Codes.Placeholders.TA_SUPPORT_EMAIL, cache.getSystemParameter(Codes.SystemParameters.TA_SUPPORT_EMAIL).getValue());

		return text;
	}

	public String formatWithAnOrA(String fullText, String placeHolder, String replaceWith) {
		fullText = replace(fullText, placeHolder, (replaceWith.toLowerCase()).matches("(a|e|i|o|u).*") ? "an " + replaceWith : "a " + replaceWith);
		return fullText;
	}

	public String removeHtmlTag(String fullText) {
		return fullText.replaceAll("\\<.*?\\>", "");
	}

	public String formatLicExpiredNotifPlaceHolder(String text, Licence lic) {
		text = text.replace(Codes.Placeholders.CURRENT_DATE, DateUtil.format(LocalDate.now(), DateUtil.MONTH_YEAR_PATTERN));
		text = text.replace(Codes.Placeholders.EFFECTIVE_DATE, DateUtil.format(lic.getExpiryDate().plusDays(1), DateUtil.DATE_FORMAT_PATTERN));
		text = text.replace(Codes.Placeholders.RETURN_BADGE_DATE, DateUtil.format(lic.getExpiryDate().plusWeeks(2), DateUtil.DATE_FORMAT_PATTERN));
		return text;
	}

	public String formatTgAssessmentFeePlaceholders(String text, TouristGuide tg) {
		text = replace(text, Codes.Placeholders.TG_NAME, tg.getName());
		text = replace(text, Codes.Placeholders.TG_SALUTATION, cache.getLabel(tg.getSalutation(), false));
		text = replace(text, Codes.Placeholders.TG_SUPPORT_EMAIL, cache.getSystemParameter(Codes.SystemParameters.TG_SUPPORT_EMAIL).getValue());
		text = text.replace(Codes.Placeholders.PUBLIC_PORTAL, String.format(properties.applicationUrl, "payment-list"));
		return text;
	}

	public String formatBillRefPlaceholders(String text, List<String> payBill) {
		if (payBill != null) {
			for (String refNo : payBill) {
				text = replace(text, Codes.Placeholders.BILL_REF_NO, refNo);
			}
		}
		return text;
	}

	public String formatTGArea(String text, String specialisedArea) {
		text = replace(text, Codes.Placeholders.TG_AREA, specialisedArea == null ? "" : specialisedArea);
		return text;
	}

	public String formatPasswordManagerPlaceholders(String text, String iamsPasswordManagerUrl) {
		text = replace(text, Codes.Placeholders.APP_LINK, iamsPasswordManagerUrl);
		return text;
	}

}
