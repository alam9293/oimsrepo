package gov.stb.tag.helper;

import java.io.IOException;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.myinfo.MyInfoPersonBasicDto;
import gov.stb.tag.model.MyInfoSnapshot;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.MyInfoSnapshotRepository;
import gov.stb.tag.util.DateUtil;

@Component
public class MyInfoHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private static final String NODE_VALUE = "value";
	private static final String NODE_NAME = "name";
	private static final String NODE_ALIAS_NAME = "aliasname";
	private static final String NODE_SEX = "sex";
	private static final String NODE_RACE = "race";
	private static final String NODE_MARITAL_STATUS = "marital";
	private static final String NODE_NATIONALITY = "nationality";
	private static final String NODE_DOB = "dob";
	private static final String NODE_BIRTH_COUNTRY = "birthcountry";
	private static final String NODE_RESIDENTIAL_STATUS = "residentialstatus";
	private static final String NODE_MOBILE_NO = "mobileno";
	private static final String NODE_MOBILE_NO_NUMBER = "nbr";
	private static final String NODE_EMAIL = "email";
	private static final String NODE_EMPLOYMENT = "employment";
	private static final String NODE_OCCUPATION = "occupation";
	private static final String NODE_WORKPASS_EXPIRY_DATE = "passexpirydate";
	private static final String NODE_ADDR_REGISTERED = "regadd";
	private static final String NODE_ADDR_POSTAL = "postal";
	private static final String NODE_ADDR_BLOCK = "block";
	private static final String NODE_ADDR_STREET = "street";
	private static final String NODE_ADDR_BUILDING = "building";
	private static final String NODE_ADDR_FLOOR = "floor";
	private static final String NODE_ADDR_UNIT = "unit";
	private static final String NODE_CODE = "code";
	private static final String NODE_DESC = "desc";
	private final static String[] MYINFO_NON_EDITABLE_FIELDS_SCPR = { "uinfin", "name", "aliasName", "sex", "race", "nationality", "dob", "birthCountry", "regAddPostal", "regAddBlock", "regAddStreet",
			"regAddBuilding", "regAddFloor", "regAddUnit", "maritalStatus", "residentialStatus" };
	private final static String[] MYINFO_NON_EDITABLE_FIELDS_FOREIGNER = { "uinfin", "name", "aliasName", "sex", "race", "nationality", "dob", "birthCountry", "occupation", "employment",
			"workpassExpiryDate" };

	@Autowired
	CacheHelper cacheHelper;

	@Autowired
	Cache cache;

	@Autowired
	MyInfoSnapshotRepository myinfoRepository;

	public Boolean isOccupationEditable(String uin) {
		boolean isScpr = uin.toUpperCase().startsWith("S") || uin.toUpperCase().startsWith("T");
		if (isScpr) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean isRegAddEditable(String uin) {
		boolean isScpr = uin.toUpperCase().startsWith("S") || uin.toUpperCase().startsWith("T");
		if (isScpr) {
			return false;
		} else {
			return true;
		}
	}

	public String[] getNonEditableFields(String uin) {
		String[] nonEditableFields;
		boolean isScpr = uin.toUpperCase().startsWith("S") || uin.toUpperCase().startsWith("T");
		if (isScpr) {
			nonEditableFields = MYINFO_NON_EDITABLE_FIELDS_SCPR;
		} else {
			nonEditableFields = MYINFO_NON_EDITABLE_FIELDS_FOREIGNER;
		}
		return nonEditableFields;
	}

	public MyInfoPersonBasicDto saveRawResponse(String uinfin, String jsonResponse) {
		MyInfoSnapshot snapshot = myinfoRepository.getByUin(uinfin);
		if (snapshot == null) {
			snapshot = new MyInfoSnapshot();
			snapshot.setUinfin(uinfin);
		}
		snapshot.setResponsePayload(jsonResponse);
		myinfoRepository.saveOrUpdate(snapshot);

		return parseRawResponse(uinfin, jsonResponse);
	}

	/**
	 * return massaged data. respective form to handle/determine gov-processed-data or user-submitted-data
	 *
	 * @param uinfin
	 */
	public MyInfoPersonBasicDto getMyInfoPersonByUin(String uinfin) {
		MyInfoSnapshot snapshot = myinfoRepository.getByUin(uinfin);
		if (snapshot == null) {
			logger.error("getMyInfoPersonByUin(): no record for uinfin: " + uinfin);
			return null;
		} else {
			MyInfoPersonBasicDto person = parseRawResponse(uinfin, snapshot.getResponsePayload());
			return person;
		}
	}

	/**
	 * responsible to massage myinfo code to TAG code
	 *
	 * @param jsonResponse
	 * @return
	 */
	private MyInfoPersonBasicDto parseRawResponse(String uinfin, String jsonResponse) {

		boolean hasErrorMapping = false;
		boolean hasIncompleteData = false;
		MyInfoPersonBasicDto person = new MyInfoPersonBasicDto();
		person.setUinfin(uinfin);

		try {
			// ref: https://stackoverflow.com/questions/26190851

			final ObjectNode node = new ObjectMapper().readValue(jsonResponse, ObjectNode.class);
			if (node.has(NODE_NAME)) {
				String nodeValue = node.get(NODE_NAME).get(NODE_VALUE).asText();
				person.setName(nodeValue);
			}
			if (node.has(NODE_ALIAS_NAME)) {
				String nodeValue = node.get(NODE_ALIAS_NAME).get(NODE_VALUE).asText();
				person.setAliasName(nodeValue);
			}
			if (node.has(NODE_SEX)) {
				String nodeValue = node.get(NODE_SEX).get(NODE_CODE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_SEX);
					hasIncompleteData = true;
				} else {
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.MYINFO_SEX).stream().filter(o -> o.getLabel().equalsIgnoreCase(nodeValue)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						person.setSex(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for sex: " + nodeValue);
						hasErrorMapping = true;
					}
				}
			}
			if (node.has(NODE_RACE)) {
				String nodeValue = node.get(NODE_RACE).get(NODE_CODE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_RACE);
					hasIncompleteData = true;
				} else {
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.MYINFO_RACE).stream().filter(o -> o.getLabel().equalsIgnoreCase(nodeValue)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						person.setRace(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for race: " + nodeValue);
						hasErrorMapping = true;
					}
				}
			}
			if (node.has(NODE_NATIONALITY)) {
				String nodeValue = node.get(NODE_NATIONALITY).get(NODE_CODE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_NATIONALITY);
					hasIncompleteData = true;
				} else {
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.MYINFO_NATIONALITY).stream().filter(o -> o.getLabel().equalsIgnoreCase(nodeValue)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						person.setNationality(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for nationality: " + nodeValue);
						hasErrorMapping = true;
					}
				}
			}
			if (node.has(NODE_DOB)) {
				String nodeValue = node.get(NODE_DOB).get(NODE_VALUE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_DOB);
					hasIncompleteData = true;
				} else {
					person.setDob(DateUtil.parseDate(nodeValue, DateUtil.MYINFO_DATE_FORMAT_PATTERN));
				}
			}
			if (node.has(NODE_MARITAL_STATUS)) {
				String nodeValue = node.get(NODE_MARITAL_STATUS).get(NODE_CODE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_MARITAL_STATUS);
					hasIncompleteData = true;
				} else {
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.MYINFO_MARITAL_STATUS).stream().filter(o -> o.getLabel().equalsIgnoreCase(nodeValue)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						person.setMaritalStatus(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for marital-status: " + nodeValue);
						hasErrorMapping = true;
					}
				}
			}
			if (node.has(NODE_BIRTH_COUNTRY)) {
				String nodeValue = node.get(NODE_BIRTH_COUNTRY).get(NODE_CODE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_BIRTH_COUNTRY);
					hasIncompleteData = true;
				} else {
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.MYINFO_COUNTRY).stream().filter(o -> o.getLabel().equalsIgnoreCase(nodeValue)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						person.setBirthCountry(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for country: " + nodeValue);
						hasErrorMapping = true;
					}
				}
			}
			if (node.has(NODE_RESIDENTIAL_STATUS)) {
				String nodeValue = node.get(NODE_RESIDENTIAL_STATUS).get(NODE_CODE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_RESIDENTIAL_STATUS);
					hasIncompleteData = true;
				} else {
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.MYINFO_RESIDENTIAL_STATUS).stream().filter(o -> o.getLabel().equalsIgnoreCase(nodeValue)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						person.setResidentialStatus(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for residential-status: " + nodeValue);
						hasErrorMapping = true;
					}
				}
			}
			if (node.has(NODE_ADDR_REGISTERED)) {
				person.setRegAddPostal(node.get(NODE_ADDR_REGISTERED).get(NODE_ADDR_POSTAL).get(NODE_VALUE).asText());
				person.setRegAddBlock(node.get(NODE_ADDR_REGISTERED).get(NODE_ADDR_BLOCK).get(NODE_VALUE).asText());
				person.setRegAddStreet(node.get(NODE_ADDR_REGISTERED).get(NODE_ADDR_STREET).get(NODE_VALUE).asText());
				person.setRegAddBuilding(node.get(NODE_ADDR_REGISTERED).get(NODE_ADDR_BUILDING).get(NODE_VALUE).asText());
				person.setRegAddFloor(node.get(NODE_ADDR_REGISTERED).get(NODE_ADDR_FLOOR).get(NODE_VALUE).asText());
				person.setRegAddUnit(node.get(NODE_ADDR_REGISTERED).get(NODE_ADDR_UNIT).get(NODE_VALUE).asText());

			}
			if (node.has(NODE_MOBILE_NO)) {
				// person.setName(node.get(NODE_MOBILE_NO).get("prefix").asText());
				// person.setName(node.get(NODE_MOBILE_NO).get("code").asText());

				String nodeValue = node.get(NODE_MOBILE_NO).get(NODE_MOBILE_NO_NUMBER).get(NODE_VALUE).asText();
				person.setMobileNo(nodeValue);
			}
			if (node.has(NODE_EMAIL)) {
				person.setEmail(node.get(NODE_EMAIL).get(NODE_VALUE).asText());
			}
			// workpass holder info
			if (node.has(NODE_EMPLOYMENT)) {
				String nodeValue = node.get(NODE_EMPLOYMENT).get(NODE_VALUE).asText();
				person.setEmployment(nodeValue);
			}
			if (node.has(NODE_OCCUPATION)) {
				String nodeValue = node.get(NODE_OCCUPATION).get(NODE_CODE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_OCCUPATION);
					hasIncompleteData = true;
				} else {
					Optional<Type> opType = cache.getTypesByCategory(Codes.TypeCategories.MYINFO_OCCUPATIONS).stream().filter(o -> o.getLabel().equalsIgnoreCase(nodeValue)).findFirst();
					if (opType.isPresent()) {
						String tagCode = opType.get().getMappingCode();
						person.setOccupation(tagCode);
					} else {
						logger.error("TAG code mapping is not configured for occupation: " + nodeValue);
						hasErrorMapping = true;
					}
				}
			}
			if (node.has(NODE_WORKPASS_EXPIRY_DATE)) {
				String nodeValue = node.get(NODE_WORKPASS_EXPIRY_DATE).get(NODE_VALUE).asText();
				if (nodeValue.isEmpty()) {
					logger.error("{} value is empty", NODE_WORKPASS_EXPIRY_DATE);
					hasIncompleteData = true;
				} else {
					person.setWorkpassExpiryDate(DateUtil.parseDate(nodeValue, DateUtil.MYINFO_DATE_FORMAT_PATTERN));
				}
			}

		} catch (JsonParseException | JsonMappingException ex) {
			person.setError(true);
			person.setErrorMessage("error parsing/mapping");
			logger.error("error parsing uinfin: " + uinfin, ex);
		} catch (IOException iex) {
			person.setError(true);
			person.setErrorMessage("error processing");
			logger.error("error processing uinfin: " + uinfin, iex);
		}

		if (!person.isError() && hasErrorMapping) {
			person.setError(true);
			person.setErrorMessage("has error mapping");
		}
		person.setIncompleteData(hasIncompleteData);

		// return mapped data
		return person;
	}
}
