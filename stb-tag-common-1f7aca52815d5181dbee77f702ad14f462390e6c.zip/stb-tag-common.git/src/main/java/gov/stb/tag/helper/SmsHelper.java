package gov.stb.tag.helper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.model.Application;
import gov.stb.tag.model.Job;
import gov.stb.tag.model.SmsLog;
import gov.stb.tag.model.SmsTemplate;
import gov.stb.tag.model.Status;
import gov.stb.tag.repository.SmsRepository;

@Component
public class SmsHelper extends Cache {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private static final String SMS_FOOTER = "*** This is an automatically generated SMS, please do not reply ***";

	@Autowired
	CacheHelper cache;
	@Autowired
	Properties properties;
	@Autowired
	SmsRepository repository;
	@Autowired
	MessageHelper messageHelper;

	// https://appsms.sgmail.sgnet.gov.sg/sms?authid=STBAPP01&authcode=STB@APP01!123&destination=6596262137&source=<src>&message=Test%20SMS%20from%20PROD

	// note: this endpoint only available in STB-DC PROD & UAT env

	public SmsLog sms(String recipient, String message) throws UnsupportedEncodingException {
		return sms(recipient, message, null, null, null);
	}

	public SmsLog sms(String recipient, String message, Application app, Job job, SmsTemplate template) throws UnsupportedEncodingException {
		String authCode = properties.smsAuthCode;
		String authId = properties.smsAuthId;
		String endpointUrl = properties.smsEndPointUrl;
		message = URLEncoder.encode(message, "UTF-8");
		int respCode = 0;

		// eg, https://appsms.sgmail.sgnet.gov.sg/sms?authid=STBAPP01&authcode=STB@APP01!123&destination=6596262137&source=<src>&message=Test%20SMS%20from%20PROD
		String reqString = endpointUrl + "?authid=" + authId + "&authcode=" + authCode + "&destination=" + recipient + "&message=" + message;

		// 1 sms length is 160 characters
		int msgLength = message.length();
		logger.info("sms(): preparing request, recipient: {}, sms-length: {}", recipient, msgLength);
		logger.trace("sms(): request-url: {}", reqString);

		CloseableHttpClient client = null;
		HttpPost httpPost = new HttpPost(reqString);
		HttpResponse resp = null;
		try {
			client = createAcceptSelfSignedCertificateClient();
			resp = client.execute(httpPost);
			if (resp != null) {
				respCode = resp.getStatusLine().getStatusCode();

				HttpEntity entity = resp.getEntity();
				String respBody = "n/a";
				if (entity != null) {
					respBody = EntityUtils.toString(entity);
				}

				if (respCode == HttpStatus.SC_OK) {
					logger.info("sms(): success. recipient: {}, resp-code: {}, resp-body: {} ", recipient, respCode, respBody);
				} else {
					logger.error("sms(): error. recipient: {}, resp-code: {}, resp-body: {} ", recipient, respCode, respBody);
				}
			} else {
				logger.error("sms(): error. recipient: {}. error connecting endpoint.", recipient);
			}
		} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException | IOException ex) {
			logger.error("sms(): error processing", ex);
		}

		// sms log
		return log(recipient, message, respCode, null, null, null);
	}

	private SmsLog log(String recipient, String message, int statusCode, Application app, Job job, SmsTemplate template) {
		Status status = cache.getStatus(Codes.Statuses.SMS_SENT);
		if (statusCode != HttpStatus.SC_OK) {
			status = cache.getStatus(Codes.Statuses.SMS_FAILED);
		}

		return log(recipient, message, status, app, job, template);
	}

	private SmsLog log(String recipient, String message, Status status, Application app, Job job, SmsTemplate template) {
		SmsLog log = new SmsLog();
		log.setMobileNo(recipient);
		log.setBody(message);
		log.setStatus(status);
		log.setApplication(app);
		log.setJob(job);
		log.setTemplate(template);
		repository.save(log);

		return log;
	}

	private static CloseableHttpClient createAcceptSelfSignedCertificateClient() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {

		// use the TrustSelfSignedStrategy to allow Self Signed Certificates
		SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(new TrustSelfSignedStrategy()).build();
		HostnameVerifier allowAllHosts = new NoopHostnameVerifier();
		SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);

		return HttpClients.custom().setSSLSocketFactory(connectionFactory).build();
	}

}
