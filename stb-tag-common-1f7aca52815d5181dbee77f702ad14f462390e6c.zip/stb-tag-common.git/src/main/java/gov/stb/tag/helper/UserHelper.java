package gov.stb.tag.helper;

import static com.google.common.base.Preconditions.checkNotNull;

import java.io.IOException;
import java.util.Set;
import java.util.StringTokenizer;

import gov.stb.tag.constant.Messages;
import gov.stb.tag.constant.Properties;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.stereotype.Component;

import com.google.common.collect.Sets;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgTrainingProvider;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.TravelAgent;
import gov.stb.tag.model.User;

import javax.servlet.http.HttpServletRequest;

@Component
public class UserHelper {

	@Autowired
	protected Cache cache;

	@Autowired
	Properties properties;


	/**
	 * have set password
	 * 
	 * @return
	 */
	public static Set<String> withLoginCredentialStatuses() {

		return Sets.newHashSet(Codes.Statuses.USER_LOCKED, Codes.Statuses.USER_ACTIVE, Codes.Statuses.USER_INACTIVE);
	}

	/**
	 * Account get locked, or account get deactivated by admin, or account get deactivated by system if never login for >90 days
	 * 
	 * @return
	 */
	public static Set<String> tempararyInactiveAccessStatuses() {

		return Sets.newHashSet(Codes.Statuses.USER_LOCKED, Codes.Statuses.USER_INACTIVE);
	}

	/**
	 * Active status or locked status Locked status will still receive email notification
	 * 
	 * @return
	 */
	public static Set<String> currentlyActiveStatuses() {

		return Sets.newHashSet(Codes.Statuses.USER_LOCKED, Codes.Statuses.USER_ACTIVE);
	}

	public boolean doSecretKeysMatch(String secretKey, String lockedSecretKey) {
		checkNotNull(secretKey);
		checkNotNull(lockedSecretKey);

		return secretKey.equals(lockedSecretKey);
	}

	public void checkUserIsNotNull(User user) {

		if (user == null) {
			throw new ValidationException("User not found.");
		}
	}

	public static Role getRole(Set<Role> roles, String validateRole) {
		checkNotNull(validateRole);

		for (Role role : roles) {
			if (role.getCode().equals(validateRole)) {
				return role;
			}
		}

		return null;
	}

	public boolean checkWorkPassHolder(String uin) {
		return !uin.toLowerCase().startsWith("s") && !uin.toLowerCase().startsWith("t");
	}

	public User createPublicUser(String loginId, String uen, String name, Role role, TravelAgent ta, TouristGuide tg, TgCandidate tgCdd, TgTrainingProvider tp) {

		User user = new User();
		user.setLoginId(loginId);
		user.setUen(uen);
		user.setName(name);
		user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		if (CollectionUtils.isEmpty(user.getRoles())) {
			user.setRoles(Sets.newHashSet());
		}
		user.getRoles().add(role);
		user.setTravelAgent(ta);
		user.setTouristGuide(tg);
		user.setTgCandidate(tgCdd);
		user.setTgTrainingProvider(tp);

		return user;
	}
}
