package gov.stb.tag.helper;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.User;
import gov.stb.tag.model.Workflow;
import gov.stb.tag.model.WorkflowAction;
import gov.stb.tag.model.WorkflowStep;
import gov.stb.tag.model.WorkflowStepAssignment;

@Component
@Transactional
public class WorkflowHelper extends BaseWorkflowHelper {

	/**
	 * Find the first workflow step. Create and save a new workflow with an initial action (e.g. status = Pending XX) based on the step found.
	 */
	public Workflow saveNewWorkflow(String workflowTypeCode, String remarks, List<MultipartFile> files, List<String> fileDescs, Boolean autoForwardForSubmit, Licence licence) {
		return saveNewWorkflow(workflowTypeCode, remarks, files, fileDescs, autoForwardForSubmit, licence, null, null);
	}

	public Workflow saveNewWorkflow(String workflowTypeCode, String remarks, List<MultipartFile> files, List<String> fileDescs, Boolean autoForwardForSubmit, Licence licence, Integer supporterId,
			Integer approverId) {
		Workflow workflow = new Workflow();
		workflow.setLicence(licence);
		workflow.setType(cache.getType(workflowTypeCode));
		if (Entities.equals(workflow.getType().getCategory(), Codes.TypeCategories.TA_WORKFLOW)) {
			workflow.setCategoryType(Codes.WorkflowCategoryType.TA);
		} else if (Entities.equals(workflow.getType().getCategory(), Codes.TypeCategories.TG_WORKFLOW)) {
			workflow.setCategoryType(Codes.WorkflowCategoryType.TG);
		} else if (Entities.equals(workflow.getType().getCategory(), Codes.TypeCategories.CE_WORKFLOW)) {
			workflow.setCategoryType(Codes.WorkflowCategoryType.CE);
		} else if (Entities.equals(workflow.getType().getCategory(), Codes.TypeCategories.PAY_WORKFLOW)) {
			workflow.setCategoryType(Codes.WorkflowCategoryType.PAY);
		}
		baseWorkflowHelperRepository.save(workflow);

		if (autoForwardForSubmit) {
			forward(workflow, Boolean.TRUE, remarks, supporterId, approverId, false, files, fileDescs);
		}
		return workflow;
	}

	/**
	 * Create and save an action with status = next step's start status (or first step's start status, if last action is null). If no more step found or no steps configured, status = APPROVED.
	 */
	public WorkflowAction forward(Workflow workflow, boolean isSubmit, String remarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs) {
		return super.forward(workflow, null, isSubmit, remarks, null, recommendationCode, files, fileDescs, false, null, null, false);
	}

	/**
	 * Create and save an action with status = any status below current level or RFA (RETURN FOR ACTION).
	 */
	public WorkflowAction rfa(Workflow workflow, String statusCode, String internalRemarks, String externalRemarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs,
			Integer assigneeId) {
		return super.rfa(workflow, null, statusCode, internalRemarks, recommendationCode, null, files, fileDescs, assigneeId);
	}

	/**
	 * forward function for CE
	 * 
	 * @param followStepAssignment
	 *            - TRUE : if no user selected for case task support, the default start code will become CE_WKFLW_PEND_APPR automatically; FALSE : follow default start status in workflow step
	 *            assignment
	 */
	public WorkflowAction forward(Workflow workflow, boolean isSubmit, String remarks, Integer supporterId, Integer approverId, boolean followStepAssignment, List<MultipartFile> files) {
		return super.forward(workflow, null, isSubmit, remarks, null, null, files, null, false, supporterId, approverId, followStepAssignment);
	}

	public WorkflowAction forward(Workflow workflow, boolean isSubmit, String remarks, Integer supporterId, Integer approverId, boolean followStepAssignment, List<MultipartFile> files,
			List<String> fileDescs) {
		return super.forward(workflow, null, isSubmit, remarks, null, null, files, fileDescs, false, supporterId, approverId, followStepAssignment);
	}

	/**
	 * forward function for CE with SLA
	 * 
	 */
	public WorkflowAction forward(Workflow workflow, boolean isSubmit, String remarks, Integer supporterId, Integer approverId, boolean followStepAssignment, boolean saveSlaExpiry) {
		WorkflowAction lastAction = super.forward(workflow, null, isSubmit, remarks, null, null, null, null, false, supporterId, approverId, followStepAssignment);
		if (saveSlaExpiry) {
			saveWorkflowSlaExpiryDate(workflow);
		}
		return lastAction;
	}

	/**
	 * Create and save an action with status = REJECTED
	 */
	public WorkflowAction reject(Workflow workflow, String remarks, String recommendationCode, List<MultipartFile> files, List<String> fileDescs) {
		return super.reject(workflow, null, remarks, null, recommendationCode, files, fileDescs);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to add notes
	 */
	public WorkflowAction saveNote(Workflow workflow, String internalRemarks, List<MultipartFile> files, List<String> fileDescs) {
		return super.saveNote(workflow, null, internalRemarks, files, fileDescs);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to keep track edit submission action
	 */
	public WorkflowAction edit(Workflow workflow, String internalRemarks) {
		return super.edit(workflow, null, internalRemarks);
	}

	/**
	 * Create and save an action with status (and prev. status) = similar to current action as the purpose is to keep track re-assign action
	 */
	public WorkflowAction reAssign(Workflow workflow, User assignee, String internalRemarks) {
		return super.reAssign(workflow, null, assignee, internalRemarks);
	}

	/**
	 * Checks if the specified application is at its final approval.
	 */
	public Boolean isFinalApproval(Workflow workflow) {
		if (workflow.getLastAction() != null) {
			return super.isFinalApproval(workflow.getType().getCode(), workflow.getLastAction().getStatus().getCode());
		} else {
			return false;
		}
	}

	/**
	 * Checks if the specified application has been final approved.
	 */
	public Boolean hasFinalApproved(Workflow workflow) {
		if (workflow.getLastAction() != null) {
			return workflow.getLastAction().getStatus().getCode().equals(super.getApprovedStatusCode(workflow, null));
		} else {
			return false;
		}
	}

	/**
	 * Checks if the specified application has been final approved/Rejected.
	 */
	public Boolean hasFinalApprovedOrRejected(Workflow workflow) {
		if (workflow.getLastAction() != null) {
			return workflow.getLastAction().getStatus().getCode().equals(super.getApprovedStatusCode(workflow, null))
					|| workflow.getLastAction().getStatus().getCode().equals(super.getRejectedStatusCode(workflow, null));
		} else {
			return false;
		}
	}

	/**
	 * Return a list of statuses available for RFA, which are the startStatuses of steps lower than the current level
	 */
	public List<Status> getStatusesForRfa(Workflow workflow) {
		return super.getStatusesForRfa(workflow, null);
	}

	public Workflow saveOrUpdateStepAssignment(Workflow workflow, Integer supporterId, Integer approverId) {
		return super.saveOrUpdateStepAssignment(workflow, null, supporterId, approverId);
	}

	public boolean isPendingApproval(Status status) {
		return Entities.anyEquals(status, Codes.Statuses.CE_WKFLW_PEND_APPR, Codes.Statuses.CE_WKFLW_PEND_SUPP);
	}

	public boolean isRoutedBack(Status status) {
		return Entities.anyEquals(status, Codes.Statuses.CE_WKFLW_ROUTED);
	}

	private void saveWorkflowSlaExpiryDate(Workflow workflow) {
		WorkflowAction lastAction = workflow.getLastAction();
		if (lastAction != null) {
			if (Entities.equals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_PEND_SUPP)) {
				workflow.setSlaExpiryDate(LocalDate.now().plusDays(cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_SLA_FOR_SUPPORT)));
			} else if (Entities.equals(lastAction.getStatus(), Codes.Statuses.CE_WKFLW_PEND_APPR)) {
				workflow.setSlaExpiryDate(LocalDate.now().plusDays(cache.getSystemParameterAsInteger(Codes.SystemParameters.CE_SLA_FOR_APPROVAL)));
			}
		}
		baseWorkflowHelperRepository.save(workflow);
	}

	public boolean isFirstStep(Workflow workflow) {
		List<WorkflowStepAssignment> workflowStepAssignments = workflow.getWorkflowStepAssignments();
		if (CollectionUtils.isNotEmpty(workflowStepAssignments)) {
			List<WorkflowStep> workflowSteps = workflowStepAssignments.stream().map(WorkflowStepAssignment::getWorkflowStep).collect(Collectors.toList());

			if (CollectionUtils.isNotEmpty(workflowSteps)) {
				workflowSteps.stream().sorted(Comparator.comparing(WorkflowStep::getId));
				WorkflowStep firstStep = workflowSteps.get(0);

				return workflow.getLastAction().getStatus().equals(firstStep.getStartStatus());
			}
		}

		return false;
	}

	/**
	 * Auto approve
	 */
	public WorkflowAction autoApprove(Workflow workflow, boolean isSubmit, String internalRemarks) {
		return super.autoApprove(workflow, null, isSubmit, null, internalRemarks);
	}
}
