package gov.stb.tag.hibernate;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.ImplicitCollectionTableNameSource;
import org.hibernate.boot.model.naming.ImplicitJoinColumnNameSource;
import org.hibernate.boot.model.naming.ImplicitJoinTableNameSource;
import org.hibernate.boot.model.naming.ImplicitNamingStrategyJpaCompliantImpl;
import org.hibernate.boot.model.naming.ImplicitNamingStrategyLegacyJpaImpl;

@SuppressWarnings("serial")
public class MySqlImplictNamingStrategy extends ImplicitNamingStrategyJpaCompliantImpl {

	/**
	 * Singleton access
	 */
	public static final ImplicitNamingStrategyLegacyJpaImpl INSTANCE = new ImplicitNamingStrategyLegacyJpaImpl();

	@Override
	public Identifier determineCollectionTableName(ImplicitCollectionTableNameSource source) {
		final String ownerPortion = source.getOwningPhysicalTableName().getText();
		final String ownedPortion = transformAttributePath(source.getOwningAttributePath());
		Identifier identifier = toIdentifier(upperCaseFirst(ownerPortion) + upperCaseFirst(ownedPortion), source.getBuildingContext());
		if (source.getOwningPhysicalTableName().isQuoted()) {
			identifier = Identifier.quote(identifier);
		}
		return identifier;
	}

	@Override
	public Identifier determineJoinTableName(ImplicitJoinTableNameSource source) {
		final String ownerPortion = source.getOwningPhysicalTableName();
		final String ownedPortion;
		if (source.getNonOwningPhysicalTableName() != null) {
			ownedPortion = source.getNonOwningPhysicalTableName();
		} else {
			ownedPortion = transformAttributePath(source.getAssociationOwningAttributePath());
		}
		return toIdentifier(ownerPortion + "$" + ownedPortion, source.getBuildingContext());
	}

	@Override
	public Identifier determineJoinColumnName(ImplicitJoinColumnNameSource source) {
		final String name;
		if (source.getNature() == ImplicitJoinColumnNameSource.Nature.ELEMENT_COLLECTION || source.getAttributePath() == null) {
			name = lowerCaseFirst(source.getReferencedTableName().getText()) + upperCaseFirst(source.getReferencedColumnName().getText());
		} else {
			name = transformAttributePath(source.getAttributePath()) + upperCaseFirst(source.getReferencedColumnName().getText());
		}
		return toIdentifier(name, source.getBuildingContext());
	}

	private String upperCaseFirst(String colName) {
		String s = colName.substring(0, 1).toUpperCase() + colName.substring(1);
		return s;
	}

	private String lowerCaseFirst(String colName) {
		String s = colName.substring(0, 1).toLowerCase() + colName.substring(1);
		return s;
	}

}
