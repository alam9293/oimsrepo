package gov.stb.tag.hibernate;

import java.io.Serializable;

import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;

import com.google.common.base.CaseFormat;

@SuppressWarnings("serial")
public class MySqlPhysicalNamingStrategy implements PhysicalNamingStrategy, Serializable {

	/**
	 * Singleton access
	 */
	public static final PhysicalNamingStrategyStandardImpl INSTANCE = new PhysicalNamingStrategyStandardImpl();

	@Override
	public Identifier toPhysicalCatalogName(Identifier name, JdbcEnvironment context) {
		return name;
	}

	@Override
	public Identifier toPhysicalSchemaName(Identifier name, JdbcEnvironment context) {
		return name;
	}

	@Override
	public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment context) {
		String initialName = name.getText();
		String pluralName = pluralize(initialName);
		String snakedCasedName = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, pluralName).replace("$_", "$");
		return Identifier.toIdentifier(snakedCasedName);
	}

	@Override
	public Identifier toPhysicalSequenceName(Identifier name, JdbcEnvironment context) {
		return name;
	}

	@Override
	public Identifier toPhysicalColumnName(Identifier name, JdbcEnvironment context) {
		return name;
	}

	private String pluralize(String word) {
		if (word.endsWith("mnus")) {
			return word.substring(0, word.length() - 4) + "mni";
		} else if (word.endsWith("ss") || word.endsWith("as") || word.endsWith("es") || word.endsWith("is") || word.endsWith("os") || word.endsWith("us") || word.endsWith("ch")
				|| word.endsWith("x")) {
			return word + "es";
		} else if (word.endsWith("y") && !word.endsWith("ay") && !word.endsWith("ey") && !word.endsWith("iy") && !word.endsWith("oy") && !word.endsWith("uy")) {
			return word.substring(0, word.length() - 1) + "ies";
		} else if (word.endsWith("man")) {
			return word.substring(0, word.length() - 3) + "men";
		} else if (word.toLowerCase().endsWith("criterion")) {
			return word.substring(0, word.length() - 2) + "a";
		} else if (word.toLowerCase().endsWith("data")) {
			return word;
		} else if (word.toLowerCase().endsWith("ersonnel")) {
			return word;
		} else {
			return word + "s";
		}
	}
}
