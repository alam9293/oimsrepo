package gov.stb.tag.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import gov.stb.tag.model.User;

@Component
public class RequestProcessingTimeInterceptor extends HandlerInterceptorAdapter {
	private static final Logger logger = LoggerFactory.getLogger(RequestProcessingTimeInterceptor.class);

	// ref: https://www.journaldev.com/2676/spring-mvc-interceptor-example-handlerinterceptor-handlerinterceptoradapter
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		request.setAttribute("wvReqStartTime", System.currentTimeMillis());

		// if returned false, we need to make sure 'response' is sent
		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		// get current login user & selected role
		String userInfo = "";

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null && authentication.getPrincipal() != null) {
			// TODO: either check instanceof TravelAgent, TaStakeholder (KE), TouristGuide, TgCandidate, TgTrainer... (or linked them all to User)
			if (authentication.getPrincipal() instanceof User) {
				User user = (User) authentication.getPrincipal();
				if (user != null) {
					userInfo = "[user] " + user.getLoginId() + ", performed as: " + user.getDefaultRole().getCode();
				}
			} else if (authentication.getPrincipal() instanceof String) {
				userInfo = "[user] obj value: " + authentication.getPrincipal();
			} else {
				userInfo = "[user] obj class: " + authentication.getPrincipal().getClass().getName();
			}
		}
		log(request, response, userInfo);
	}

	private String getClientIP(HttpServletRequest request) {
		String clientIP = "-";
		String headerCfConnectingIP = request.getHeader("CF-Connecting-IP");
		String headerCfIpCountry = request.getHeader("CF-IPCountry");
		String headerXForwardedFor = request.getHeader("X-Forwarded-For");
		String headerRemoteAddress = request.getRemoteAddr();

		if (headerCfConnectingIP != null) {
			clientIP = headerCfConnectingIP;
			if (headerCfIpCountry != null) {
				clientIP += " [" + headerCfIpCountry + "]";
			}
		} else if (headerXForwardedFor != null) {
			clientIP = headerXForwardedFor;
		} else if (headerRemoteAddress != null) {
			clientIP = headerRemoteAddress;
		}

		return clientIP;
	}

	private void log(HttpServletRequest request, HttpServletResponse response, String userInfo) {
		long timeTaken = System.currentTimeMillis() - (Long) request.getAttribute("wvReqStartTime");
		String reqMethod = request.getMethod();
		int respStatusCode = response.getStatus();
		String log = String.format("[Req-Processing-Time] req-method: %s, resp-code: %s, URL:%s, timetaken=%s ms. %s. Client-IP: %s", reqMethod, respStatusCode, request.getRequestURI(), timeTaken,
				userInfo, getClientIP(request));

		logger.trace(log.replaceAll("[\r\n]", ""));
	}
}
