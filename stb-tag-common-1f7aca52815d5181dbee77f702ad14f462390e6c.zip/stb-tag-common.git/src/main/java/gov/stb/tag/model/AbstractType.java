package gov.stb.tag.model;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.wiz.model.api.AuditableCodeEntity;
import com.wiz.model.api.CodeEntity;
import com.wiz.model.api.Listable;

@MappedSuperclass
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("serial")
public abstract class AbstractType extends AuditableCodeEntity implements Listable, CodeEntity {

	protected String code;

	protected String label;

	protected String otherLabel;

	protected Boolean isActive;

	protected Boolean isEditable;

	protected Integer ordinal;

	// This field will be to updated by DB trigger to facilitate the generation of PK for user-added types
	protected Integer runningCode;

	// to store code that used by TAG, only applicable for MyInfo, EDH codes
	protected String mappingCode;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	protected Type category;

	@Column(length = 5000)
	protected String footNote; // currently not applicable for all AbstractType.

	@Access(AccessType.PROPERTY)
	@Id
	@Override
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Override
	public String getOtherLabel() {
		return otherLabel;
	}

	public void setOtherLabel(String otherLabel) {
		this.otherLabel = otherLabel;
	}

	public Boolean isActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean isEditable() {
		return isEditable;
	}

	public void setIsEditable(Boolean isEditable) {
		this.isEditable = isEditable;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public Integer getRunningCode() {
		return runningCode;
	}

	public void setRunningCode(Integer runningCode) {
		this.runningCode = runningCode;
	}

	public String getMappingCode() {
		return mappingCode;
	}

	public void setMappingCode(String mappingCode) {
		this.mappingCode = mappingCode;
	}

	public Type getCategory() {
		return category;
	}

	public void setCategory(Type category) {
		this.category = category;
	}

	@Override
	public Serializable getKey() {
		return getCode();
	}

	public String getFootNote() {
		return footNote;
	}

	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}

}
