package gov.stb.tag.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.google.common.base.Strings;
import com.wiz.model.api.AuditableIdEntity;

import gov.stb.tag.constant.Codes;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Address extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type addressType;

	private String street;

	private String building;

	private String block;

	private String floor;

	private String unit;

	private String postal;

	private String foreignLine1;

	private String foreignLine2;

	private String foreignLine3;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type premiseType;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getAddressType() {
		return addressType;
	}

	public void setAddressType(Type addressType) {
		this.addressType = addressType;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public String getForeignLine1() {
		return foreignLine1;
	}

	public void setForeignLine1(String foreignLine1) {
		this.foreignLine1 = foreignLine1;
	}

	public String getForeignLine2() {
		return foreignLine2;
	}

	public void setForeignLine2(String foreignLine2) {
		this.foreignLine2 = foreignLine2;
	}

	public String getForeignLine3() {
		return foreignLine3;
	}

	public void setForeignLine3(String foreignLine3) {
		this.foreignLine3 = foreignLine3;
	}

	public Type getPremiseType() {
		return premiseType;
	}

	public void setPremiseType(Type premiseType) {
		this.premiseType = premiseType;
	}

	public String getAddressDisplay() {
		if (addressType != null && Codes.Types.ADDR_LOCAL.equals(addressType.getCode())) {
			return toFormattedAddress(false);
		} else {
			return toUnstructuredAddress(false);
		}
	}

	public String getFormattedAddressDisplay() {
		if (addressType != null && Codes.Types.ADDR_LOCAL.equals(addressType.getCode())) {
			return toFormattedAddress(true);
		} else {
			return toUnstructuredAddress(true);
		}
	}

	public String getSingleLineAddressDisplay() {
		if (addressType != null && Codes.Types.ADDR_LOCAL.equals(addressType.getCode())) {
			return toFormattedSingleLineAddress();
		} else {
			return toUnstructuredSingleLineAddress();
		}
	}

	/**
	 * Example address from Singapore Post<br>
	 * <br>
	 * Singapore Post Pte Ltd<br>
	 * 10 Eunos Road 8<br>
	 * #05-33 Singapore Post Centre<br>
	 * Singapore 408600 <br>
	 * REPUBLIC OF SINGAPORE
	 * 
	 * @return
	 */
	public String toFormattedAddress(Boolean isHtml) {
		// populating block + street
		String address = street;
		if (!StringUtils.isBlank(block)) {
			address = block + " " + address;
		}

		// populating floor, unit and building
		if (!StringUtils.isBlank(floor) || !StringUtils.isBlank(unit) || !StringUtils.isBlank(building)) {
			address += isHtml ? "<br/>" : "\n";
		}
		if (!StringUtils.isBlank(floor)) {
			if (!StringUtils.isBlank(unit)) {
				address += "#" + floor;
			} else {
				address += floor;
			}
		} else {
			address += " ";
		}
		if (!StringUtils.isBlank(floor) && !StringUtils.isBlank(unit)) {
			address += "-" + unit;
		} else {
			if (!StringUtils.isBlank(unit)) {
				address += unit;
			} else {
				address += " ";
			}
		}
		if (!StringUtils.isBlank(building)) {
			if (!StringUtils.isBlank(floor) || !StringUtils.isBlank(unit)) {
				address += " " + building;
			} else {
				address += building;
			}
		} else {
			address += " ";
		}

		// populating postal
		if (!StringUtils.isBlank(postal)) {
			address += (isHtml ? "<br/>" : "\n") + "SINGAPORE " + postal;
		}

		return address;
	}

	/**
	 * Return the formatted structure address in single line
	 * 
	 * @return
	 */
	public String toFormattedSingleLineAddress() {
		// populating block + street
		String address = street;
		if (!Strings.isNullOrEmpty(block)) {
			address = block + " " + address;
		}

		// populating floor, unit and building
		if (!Strings.isNullOrEmpty(floor) || !Strings.isNullOrEmpty(unit) || !Strings.isNullOrEmpty(building)) {
			address += " ";
		}
		if (!Strings.isNullOrEmpty(floor)) {
			if (!Strings.isNullOrEmpty(unit)) {
				address += "#" + floor;
			} else {
				address += floor;
			}
		}

		if (!Strings.isNullOrEmpty(unit)) {
			if (!Strings.isNullOrEmpty(floor) && !Strings.isNullOrEmpty(unit)) {
				address += "-" + unit;
			} else {
				address += unit;
			}
		}

		if (!Strings.isNullOrEmpty(building)) {
			if (!Strings.isNullOrEmpty(floor) || !Strings.isNullOrEmpty(unit)) {
				address += " " + building;
			} else {
				address += building;
			}
		}

		// populating postal
		if (!Strings.isNullOrEmpty(postal)) {
			address += " SINGAPORE " + postal;
		}

		return address;
	}

	public String toFormatForMailingListing(Boolean isHtml) {

		// populating block + street
		String address = street;
		if (!Strings.isNullOrEmpty(block)) {
			address = block + " " + address;
		}

		address += isHtml ? "<br/>" : "\n";
		;

		if (!Strings.isNullOrEmpty(floor)) {
			if (!Strings.isNullOrEmpty(unit)) {
				address += "#" + floor;
			} else {
				address += floor;
			}
		}

		if (!Strings.isNullOrEmpty(unit)) {
			if (!Strings.isNullOrEmpty(floor) && !Strings.isNullOrEmpty(unit)) {
				address += "-" + unit;
			} else {
				address += unit;
			}
		}

		if (!Strings.isNullOrEmpty(building)) {
			if (!Strings.isNullOrEmpty(floor) || !Strings.isNullOrEmpty(unit)) {
				address += " " + building;
			} else {
				address += building;
			}
		}

		if (!Strings.isNullOrEmpty(floor) || !Strings.isNullOrEmpty(unit) || !Strings.isNullOrEmpty(building)) {
			address += isHtml ? "<br/>" : "\n";
		}

		// populating postal
		if (!Strings.isNullOrEmpty(postal)) {
			address += "SINGAPORE " + postal;
		}

		return address;
	}

	public String toUnstructuredAddress(Boolean isHtml) {

		String address = foreignLine1;
		if (!StringUtils.isEmpty(foreignLine2)) {
			address += isHtml ? "<br/>" : "\n";
			address += foreignLine2;
		}
		if (!StringUtils.isEmpty(foreignLine3)) {
			address += isHtml ? "<br/>" : "\n";
			address += foreignLine3;
		}
		return address;
	}

	public String toUnstructuredSingleLineAddress() {
		String address = foreignLine1;
		if (!StringUtils.isEmpty(foreignLine2)) {
			address += " " + foreignLine2;
		}
		if (!StringUtils.isEmpty(foreignLine3)) {
			address += " " + foreignLine3;
		}
		return address;
	}

	public String toFloorUnit() {
		String floorUnit = "";
		if (!Strings.isNullOrEmpty(floor)) {
			if (!Strings.isNullOrEmpty(unit)) {
				floorUnit += "#" + floor;
			} else {
				floorUnit += floor;
			}
		}

		if (!Strings.isNullOrEmpty(unit)) {
			if (!Strings.isNullOrEmpty(floor) && !Strings.isNullOrEmpty(unit)) {
				floorUnit += "-" + unit;
			} else {
				floorUnit += unit;
			}
		}
		return floorUnit;
	}
}
