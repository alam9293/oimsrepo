package gov.stb.tag.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Application extends AuditableIdEntity {

	private Integer id;

	private String applicationNo;

	private String taTgType;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDraft;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	private LocalDateTime submissionDate;

	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean isOfflineSubmission;

	/**
	 * This field is used by TA modules. Every new applications will be assigned to a STB officer based on the 1st alphabet of the travel agent company's name.
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	private User assignee;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status licencePrintStatus;

	private LocalDate licenceCollectedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private WorkflowAction lastAction;

	@OneToMany(mappedBy = "application")
	private Set<WorkflowAction> workflowActions;

	@OneToMany(mappedBy = "application")
	@Where(clause = "isDeleted = 0")
	private Set<ApplicationFile> applicationFiles;

	private LocalDate sendToVendorDate;

	private LocalDate pendingCollectionStartDate;

	private LocalDate pendingCollectionEndDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCourse tgCourse;

	@Transient
	private Boolean hasIpaApproved = null; // true: IPA approved, false: IPA not yet approved, null: Not IPA

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public Boolean isDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public LocalDateTime getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDateTime submissionDate) {
		this.submissionDate = submissionDate;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public Status getLicencePrintStatus() {
		return licencePrintStatus;
	}

	public void setLicencePrintStatus(Status licencePrintStatus) {
		this.licencePrintStatus = licencePrintStatus;
	}

	public LocalDate getLicenceCollectedDate() {
		return licenceCollectedDate;
	}

	public void setLicenceCollectedDate(LocalDate licenceCollectedDate) {
		this.licenceCollectedDate = licenceCollectedDate;
	}

	public WorkflowAction getLastAction() {
		return lastAction;
	}

	public void setLastAction(WorkflowAction lastAction) {
		this.lastAction = lastAction;
	}

	public Set<WorkflowAction> getWorkflowActions() {
		return workflowActions;
	}

	public void setWorkflowActions(Set<WorkflowAction> workflowActions) {
		this.workflowActions = workflowActions;
	}

	public Set<ApplicationFile> getApplicationFiles() {
		return applicationFiles;
	}

	public void setApplicationFiles(Set<ApplicationFile> applicationFiles) {
		this.applicationFiles = applicationFiles;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public User getAssignee() {
		return assignee;
	}

	public void setAssignee(User assignee) {
		this.assignee = assignee;
	}

	public Boolean isOfflineSubmission() {
		return isOfflineSubmission;
	}

	public void setOfflineSubmission(Boolean isOfflineSubmission) {
		this.isOfflineSubmission = isOfflineSubmission;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public LocalDate getSendToVendorDate() {
		return sendToVendorDate;
	}

	public void setSendToVendorDate(LocalDate sendToVendorDate) {
		this.sendToVendorDate = sendToVendorDate;
	}

	public LocalDate getPendingCollectionStartDate() {
		return pendingCollectionStartDate;
	}

	public void setPendingCollectionStartDate(LocalDate pendingCollectionStartDate) {
		this.pendingCollectionStartDate = pendingCollectionStartDate;
	}

	public LocalDate getPendingCollectionEndDate() {
		return pendingCollectionEndDate;
	}

	public void setPendingCollectionEndDate(LocalDate pendingCollectionEndDate) {
		this.pendingCollectionEndDate = pendingCollectionEndDate;
	}

	public Boolean hasIpaApproved() {
		return hasIpaApproved;
	}

	public void setHasIpaApproved(Boolean hasIpaApproved) {
		this.hasIpaApproved = hasIpaApproved;
	}

	public TgCourse getTgCourse() {
		return tgCourse;
	}

	public void setTgCourse(TgCourse tgCourse) {
		this.tgCourse = tgCourse;
	}

}
