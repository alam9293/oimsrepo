package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

// for Phase 1B, may need to store "marked for RFA"
@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class ApplicationFile extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type documentType;

	@ManyToOne(fetch = FetchType.LAZY)
	private Application application;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@OneToOne
	private File file;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getDocumentType() {
		return documentType;
	}

	public void setDocumentType(Type documentType) {
		this.documentType = documentType;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

}
