package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Bulletin extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	private String title;

	@Column(columnDefinition = "text")
	private String content;

	private LocalDate effectiveDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isPrivate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDelisted;

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	private Set<File> files = new HashSet<>(); // annotated with ManyToMany for bulletin$files mapping table

	private LocalDate expiryDate;

	private String legacyId;

	private String trustId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Boolean isPrivate() {
		return isPrivate;
	}

	public void setPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public Boolean isDelisted() {
		return isDelisted;
	}

	public void setIsDelisted(Boolean isDelisted) {
		this.isDelisted = isDelisted;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}
}
