package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CategoryListing extends AuditableIdEntity {

	private Integer id;

	// private Integer categoryId;

	private Integer fileId;

	private Integer ordinal;

	private String title;

	private String originalFilename;

	private String hash;

	private LocalDate effectiveDate;

	private LocalDate expiryDate;

	private Integer fileIconId;

	private String originalIconFilename;

	private String hashIcon;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	@ManyToOne
	@JoinColumn(name = "categoryId", nullable = false)
	private Category categories;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	// public Integer getCategoryId() {
	// return categoryId;
	// }
	//
	// public void setCategoryId(Integer categoryId) {
	// this.categoryId = categoryId;
	// }

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public String getOriginalFilename() {
		return originalFilename;
	}

	public void setOriginalFilename(String originalFilename) {
		this.originalFilename = originalFilename;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Category getCategories() {
		return categories;
	}

	public void setCategories(Category categories) {
		this.categories = categories;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public Integer getFileIconId() {
		return fileIconId;
	}

	public void setFileIconId(Integer fileIconId) {
		this.fileIconId = fileIconId;
	}

	public String getOriginalIconFilename() {
		return originalIconFilename;
	}

	public void setOriginalIconFilename(String originalIconFilename) {
		this.originalIconFilename = originalIconFilename;
	}

	public String getHashIcon() {
		return hashIcon;
	}

	public void setHashIcon(String hashIcon) {
		this.hashIcon = hashIcon;
	}

}
