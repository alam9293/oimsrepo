package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCase extends AuditableIdEntity {

	private Integer id;

	private String caseNo;

	private String taTgType;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isIp;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isComplex;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	private User oic;

	private String crmRefNo;

	@Column(columnDefinition = "text")
	private String assessment;

	@Column(columnDefinition = "text")
	private String mitigatingFactors;

	@Column(columnDefinition = "text")
	private String aggravatingFactors;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTask compliantTatiTask; // task to track the list of auto-created compliant TATI cases with auto-recommended NFA

	@OneToOne(fetch = FetchType.LAZY)
	private CeTaCheck ceTaCheck; // latest check

	@OneToMany(mappedBy = "ceCase")
	private Set<CeTaCheck> ceTaChecks; // one case may have many checks because of "To Revisit (TA Closed)" and "To Reschedule (Officer MC)" (we should not create a case for these)

	@OneToOne(fetch = FetchType.LAZY)
	private CeTgFieldReport ceTgFieldReport; // once submitted from mobile app, auto-create case with recommendation

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase taggedCase; // case will be "locked" if it is tagged to other case/IP
	// For case: taggedCase will store the case this case is tagged to
	// For IP: taggedCase will store the case this IP is created from

	@ManyToMany
	private Set<File> files = new HashSet<>();

	@OneToMany(mappedBy = "ceCase")
	private Set<CeTaFieldReport> ceTaFieldReports;

	@OneToMany(mappedBy = "ceCase")
	@Where(clause = "isDeleted = 0")
	private Set<CeCaseComplainant> ceCaseComplainants;

	@Deprecated
	@OneToMany(mappedBy = "ceCase")
	private Set<CeCaseInfringer> ceCaseInfringers;

	@OneToMany(mappedBy = "ceCase")
	@Where(clause = "isDeleted = 0")
	private Set<CeCaseInfringement> ceCaseInfringements;

	@OneToMany(mappedBy = "ceOriginatingCase")
	@Where(clause = "isDeleted = 0")
	private Set<CeCaseInfringement> ceOriginatingCaseInfringements;

	@OneToMany(mappedBy = "ceCase")
	@Where(clause = "isDeleted = 0")
	private Set<CeCaseExternalIp> ceCaseExternalIps; // for Relevant IP Cases

	@ManyToMany
	private Set<CeCase> ceCaseInternalIps = new HashSet<>(); // for Relevant IP Cases

	private String legacyId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public Boolean isIp() {
		return isIp;
	}

	public void setIsIp(Boolean isIp) {
		this.isIp = isIp;
	}

	public Boolean isComplex() {
		return isComplex;
	}

	public void setIsComplex(Boolean isComplex) {
		this.isComplex = isComplex;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public User getOic() {
		return oic;
	}

	public void setOic(User oic) {
		this.oic = oic;
	}

	public String getCrmRefNo() {
		return crmRefNo;
	}

	public void setCrmRefNo(String crmRefNo) {
		this.crmRefNo = crmRefNo;
	}

	public String getAssessment() {
		return assessment;
	}

	public void setAssessment(String assessment) {
		this.assessment = assessment;
	}

	public String getMitigatingFactors() {
		return mitigatingFactors;
	}

	public void setMitigatingFactors(String mitigatingFactors) {
		this.mitigatingFactors = mitigatingFactors;
	}

	public String getAggravatingFactors() {
		return aggravatingFactors;
	}

	public void setAggravatingFactors(String aggravatingFactors) {
		this.aggravatingFactors = aggravatingFactors;
	}

	public CeTask getCompliantTatiTask() {
		return compliantTatiTask;
	}

	public void setCompliantTatiTask(CeTask compliantTatiTask) {
		this.compliantTatiTask = compliantTatiTask;
	}

	public CeTaCheck getCeTaCheck() {
		return ceTaCheck;
	}

	public void setCeTaCheck(CeTaCheck ceTaCheck) {
		this.ceTaCheck = ceTaCheck;
	}

	public Set<CeTaCheck> getCeTaChecks() {
		return ceTaChecks;
	}

	public void setCeTaChecks(Set<CeTaCheck> ceTaChecks) {
		this.ceTaChecks = ceTaChecks;
	}

	public CeTgFieldReport getCeTgFieldReport() {
		return ceTgFieldReport;
	}

	public void setCeTgFieldReport(CeTgFieldReport ceTgFieldReport) {
		this.ceTgFieldReport = ceTgFieldReport;
	}

	public CeCase getTaggedCase() {
		return taggedCase;
	}

	public void setTaggedCase(CeCase taggedCase) {
		this.taggedCase = taggedCase;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public Set<CeTaFieldReport> getCeTaFieldReports() {
		return ceTaFieldReports;
	}

	public void setCeTaFieldReports(Set<CeTaFieldReport> ceTaFieldReports) {
		this.ceTaFieldReports = ceTaFieldReports;
	}

	public Set<CeCaseComplainant> getCeCaseComplainants() {
		return ceCaseComplainants;
	}

	public void setCeCaseComplainants(Set<CeCaseComplainant> ceCaseComplainants) {
		this.ceCaseComplainants = ceCaseComplainants;
	}

	@Deprecated
	public Set<CeCaseInfringer> getCeCaseInfringers() {
		return ceCaseInfringers;
	}

	@Deprecated
	public void setCeCaseInfringers(Set<CeCaseInfringer> ceCaseInfringers) {
		this.ceCaseInfringers = ceCaseInfringers;
	}

	public Set<CeCaseInfringement> getCeCaseInfringements() {
		return ceCaseInfringements;
	}

	public void setCeCaseInfringements(Set<CeCaseInfringement> ceCaseInfringements) {
		this.ceCaseInfringements = ceCaseInfringements;
	}

	public Set<CeCaseInfringement> getCeOriginatingCaseInfringements() {
		return ceOriginatingCaseInfringements;
	}

	public void setCeOriginatingCaseInfringements(Set<CeCaseInfringement> ceOriginatingCaseInfringements) {
		this.ceOriginatingCaseInfringements = ceOriginatingCaseInfringements;
	}

	public Set<CeCaseExternalIp> getCeCaseExternalIps() {
		return ceCaseExternalIps;
	}

	public void setCeCaseExternalIps(Set<CeCaseExternalIp> ceCaseExternalIps) {
		this.ceCaseExternalIps = ceCaseExternalIps;
	}

	public Set<CeCase> getCeCaseInternalIps() {
		return ceCaseInternalIps;
	}

	public void setCeCaseInternalIps(Set<CeCase> ceCaseInternalIps) {
		this.ceCaseInternalIps = ceCaseInternalIps;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

}
