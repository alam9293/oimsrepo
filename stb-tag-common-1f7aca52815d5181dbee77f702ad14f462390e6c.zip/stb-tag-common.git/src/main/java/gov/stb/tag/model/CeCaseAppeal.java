package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseAppeal extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Workflow workflow;

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseDecision ceCaseDecision;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type result;

	private LocalDate appealDate;

	private LocalDate appealRespondByDate;

	private LocalDate respondedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type outcome;

	private BigDecimal penaltyAmount;

	private LocalDate penaltyStatusStartDate;

	private LocalDate penaltyStatusEndDate;

	private String billRefNo; // e.g. AFP ($100) + AFP ($200) = Bill Ref No 1234 with a total of $300

	@ManyToOne(fetch = FetchType.LAZY)
	private Status paymentStatus;

	private LocalDateTime billExpiryDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement ceCaseInfringement;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean toEmailLetter;

	@ManyToOne(fetch = FetchType.LAZY)
	private File letter; // assume at most one letter per infringement (e.g. Withdrawal of NOD + Downgrade Caution Letter, send out as 1 customized letter)

	private LocalDate letterIssuanceDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean pendingBatchJob;

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailLog letterEmailLog;

	@Transient
	private boolean isNewOrEdited;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public CeCaseDecision getCeCaseDecision() {
		return ceCaseDecision;
	}

	public void setCeCaseDecision(CeCaseDecision ceCaseDecision) {
		this.ceCaseDecision = ceCaseDecision;
	}

	public Type getResult() {
		return result;
	}

	public void setResult(Type result) {
		this.result = result;
	}

	public Type getOutcome() {
		return outcome;
	}

	public void setOutcome(Type outcome) {
		this.outcome = outcome;
	}

	public BigDecimal getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(BigDecimal penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public LocalDate getPenaltyStatusStartDate() {
		return penaltyStatusStartDate;
	}

	public void setPenaltyStatusStartDate(LocalDate penaltyStatusStartDate) {
		this.penaltyStatusStartDate = penaltyStatusStartDate;
	}

	public LocalDate getPenaltyStatusEndDate() {
		return penaltyStatusEndDate;
	}

	public void setPenaltyStatusEndDate(LocalDate penaltyStatusEndDate) {
		this.penaltyStatusEndDate = penaltyStatusEndDate;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public Status getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(Status paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public LocalDateTime getBillExpiryDate() {
		return billExpiryDate;
	}

	public void setBillExpiryDate(LocalDateTime billExpiryDate) {
		this.billExpiryDate = billExpiryDate;
	}

	public CeCaseInfringement getCeCaseInfringement() {
		return ceCaseInfringement;
	}

	public void setCeCaseInfringement(CeCaseInfringement ceCaseInfringement) {
		this.ceCaseInfringement = ceCaseInfringement;
	}

	public File getLetter() {
		return letter;
	}

	public void setLetter(File letter) {
		this.letter = letter;
	}

	public EmailLog getLetterEmailLog() {
		return letterEmailLog;
	}

	public void setLetterEmailLog(EmailLog letterEmailLog) {
		this.letterEmailLog = letterEmailLog;
	}

	public Boolean getToEmailLetter() {
		return toEmailLetter;
	}

	public void setToEmailLetter(Boolean toEmailLetter) {
		this.toEmailLetter = toEmailLetter;
	}

	public boolean isNewOrEdited() {
		return isNewOrEdited;
	}

	public void setNewOrEdited(boolean isNewOrEdited) {
		this.isNewOrEdited = isNewOrEdited;
	}

	public LocalDate getLetterIssuanceDate() {
		return letterIssuanceDate;
	}

	public void setLetterIssuanceDate(LocalDate letterIssuanceDate) {
		this.letterIssuanceDate = letterIssuanceDate;
	}

	public LocalDate getAppealDate() {
		return appealDate;
	}

	public void setAppealDate(LocalDate appealDate) {
		this.appealDate = appealDate;
	}

	public LocalDate getAppealRespondByDate() {
		return appealRespondByDate;
	}

	public void setAppealRespondByDate(LocalDate appealRespondByDate) {
		this.appealRespondByDate = appealRespondByDate;
	}

	public LocalDate getRespondedDate() {
		return respondedDate;
	}

	public void setRespondedDate(LocalDate respondedDate) {
		this.respondedDate = respondedDate;
	}

	public Boolean getPendingBatchJob() {
		return pendingBatchJob;
	}

	public void setPendingBatchJob(Boolean pendingBatchJob) {
		this.pendingBatchJob = pendingBatchJob;
	}

}
