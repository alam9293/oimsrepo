package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseComplainant extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase ceCase;

	private String name; // for migration from CRM, last name (caps) + first name (e.g. FOO Janet)

	private String contactNo;

	private String emailAddress;

	// private String description;

	// @ManyToOne(fetch = FetchType.LAZY)
	// private Licence licence; // if exist, use this to populate name and address (not contact no, email cos' at that time is diff)

	// @Deprecated
	// private String address;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address;

	private String uenUin;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type idType;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	@ManyToMany
	private Set<File> files = new HashSet<>();

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public CeCase getCeCase() {
		return ceCase;
	}

	public void setCeCase(CeCase ceCase) {
		this.ceCase = ceCase;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	// public String getAddress() {
	// return address;
	// }
	//
	// public void setAddress(String address) {
	// this.address = address;
	// }

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public Type getIdType() {
		return idType;
	}

	public void setIdType(Type idType) {
		this.idType = idType;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}
