package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseComposition extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Workflow workflow;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseInfringer ceCaseInfringer;

	private String email;

	@Column(length = 5000)
	private String description;

	private BigDecimal amount;

	private String billRefNo;

	@Column(length = 5000)
	private String remarks;

	private LocalDate dueDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status payReqStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private File letter;

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailLog letterEmailLog;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public CeCaseInfringer getCeCaseInfringer() {
		return ceCaseInfringer;
	}

	public void setCeCaseInfringer(CeCaseInfringer ceCaseInfringer) {
		this.ceCaseInfringer = ceCaseInfringer;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public File getLetter() {
		return letter;
	}

	public void setLetter(File letter) {
		this.letter = letter;
	}

	public EmailLog getLetterEmailLog() {
		return letterEmailLog;
	}

	public void setLetterEmailLog(EmailLog letterEmailLog) {
		this.letterEmailLog = letterEmailLog;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public Status getPayReqStatus() {
		return payReqStatus;
	}

	public void setPayReqStatus(Status payReqStatus) {
		this.payReqStatus = payReqStatus;
	}

}
