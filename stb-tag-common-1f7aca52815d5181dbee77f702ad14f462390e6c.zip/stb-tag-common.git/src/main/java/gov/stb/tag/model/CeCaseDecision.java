package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseDecision extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Workflow workflow;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasShowCause;

	private LocalDate showCauseDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean toEmailLetter;

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseRecommendation ceCaseRecommendation;

	@OneToOne(mappedBy = "ceCaseDecision")
	private CeCaseAppeal ceCaseAppeal;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type outcome;

	private String taggedIpCaseNo;

	private BigDecimal penaltyAmount;

	private LocalDate penaltyStatusStartDate;

	private LocalDate penaltyStatusEndDate;

	private String billRefNo; // e.g. AFP ($100) + AFP ($200) = Bill Ref No 1234 with a total of $300

	@ManyToOne(fetch = FetchType.LAZY)
	private Status paymentStatus;

	private LocalDateTime billExpiryDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasInProgressAppeal;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement ceCaseInfringement;

	@ManyToOne(fetch = FetchType.LAZY)
	private File letter; // assume at most one letter per infringement (e.g. Withdrawal of NOD + Downgrade Caution Letter, send out as 1 customized letter)

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailLog letterEmailLog;

	private LocalDate letterIssuanceDate;

	@Transient
	private boolean isNewOrEdited;

	@Transient
	private boolean isShowCauseDateChanged;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public Boolean hasShowCause() {
		return hasShowCause;
	}

	public void setHasShowCause(Boolean hasShowCause) {
		this.hasShowCause = hasShowCause;
	}

	public CeCaseRecommendation getCeCaseRecommendation() {
		return ceCaseRecommendation;
	}

	public void setCeCaseRecommendation(CeCaseRecommendation ceCaseRecommendation) {
		this.ceCaseRecommendation = ceCaseRecommendation;
	}

	public CeCaseAppeal getCeCaseAppeal() {
		return ceCaseAppeal;
	}

	public void setCeCaseAppeal(CeCaseAppeal ceCaseAppeal) {
		this.ceCaseAppeal = ceCaseAppeal;
	}

	public Type getOutcome() {
		return outcome;
	}

	public void setOutcome(Type outcome) {
		this.outcome = outcome;
	}

	public BigDecimal getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(BigDecimal penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public LocalDate getPenaltyStatusStartDate() {
		return penaltyStatusStartDate;
	}

	public void setPenaltyStatusStartDate(LocalDate penaltyStatusStartDate) {
		this.penaltyStatusStartDate = penaltyStatusStartDate;
	}

	public LocalDate getPenaltyStatusEndDate() {
		return penaltyStatusEndDate;
	}

	public void setPenaltyStatusEndDate(LocalDate penaltyStatusEndDate) {
		this.penaltyStatusEndDate = penaltyStatusEndDate;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public Status getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(Status paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public LocalDateTime getBillExpiryDate() {
		return billExpiryDate;
	}

	public void setBillExpiryDate(LocalDateTime billExpiryDate) {
		this.billExpiryDate = billExpiryDate;
	}

	public Boolean hasInProgressAppeal() {
		return hasInProgressAppeal;
	}

	public void setHasInProgressAppeal(Boolean hasInProgressAppeal) {
		this.hasInProgressAppeal = hasInProgressAppeal;
	}

	public CeCaseInfringement getCeCaseInfringement() {
		return ceCaseInfringement;
	}

	public void setCeCaseInfringement(CeCaseInfringement ceCaseInfringement) {
		this.ceCaseInfringement = ceCaseInfringement;
	}

	public File getLetter() {
		return letter;
	}

	public void setLetter(File letter) {
		this.letter = letter;
	}

	public EmailLog getLetterEmailLog() {
		return letterEmailLog;
	}

	public void setLetterEmailLog(EmailLog letterEmailLog) {
		this.letterEmailLog = letterEmailLog;
	}

	public Boolean getToEmailLetter() {
		return toEmailLetter;
	}

	public void setToEmailLetter(Boolean toEmailLetter) {
		this.toEmailLetter = toEmailLetter;
	}

	public boolean isNewOrEdited() {
		return isNewOrEdited;
	}

	public void setNewOrEdited(boolean isNewOrEdited) {
		this.isNewOrEdited = isNewOrEdited;
	}

	public String getTaggedIpCaseNo() {
		return taggedIpCaseNo;
	}

	public void setTaggedIpCaseNo(String taggedIpCaseNo) {
		this.taggedIpCaseNo = taggedIpCaseNo;
	}

	public LocalDate getShowCauseDate() {
		return showCauseDate;
	}

	public void setShowCauseDate(LocalDate showCauseDate) {
		this.showCauseDate = showCauseDate;
	}

	public LocalDate getLetterIssuanceDate() {
		return letterIssuanceDate;
	}

	public void setLetterIssuanceDate(LocalDate letterIssuanceDate) {
		this.letterIssuanceDate = letterIssuanceDate;
	}

	public boolean isShowCauseDateChanged() {
		return isShowCauseDateChanged;
	}

	public void setShowCauseDateChanged(boolean isShowCauseDateChanged) {
		this.isShowCauseDateChanged = isShowCauseDateChanged;
	}

}
