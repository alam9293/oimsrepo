package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseExternalIp extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase ceCase;

	private String caseNo;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	private String oic;

	private String oicContactNo;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public CeCase getCeCase() {
		return ceCase;
	}

	public void setCeCase(CeCase ceCase) {
		this.ceCase = ceCase;
	}

	public String getCaseNo() {
		return caseNo;
	}

	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getOic() {
		return oic;
	}

	public void setOic(String oic) {
		this.oic = oic;
	}

	public String getOicContactNo() {
		return oicContactNo;
	}

	public void setOicContactNo(String oicContactNo) {
		this.oicContactNo = oicContactNo;
	}

}
