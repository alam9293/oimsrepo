package gov.stb.tag.model;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseInfringement extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase ceCase;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase ceOriginatingCase;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseInfringer ceCaseInfringer;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeProvision ceProvision;

	private LocalDateTime infringedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type outcome;

	private LocalDateTime outcomeDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseDecision lastDecision;

	private Integer ipOffenceCount;

	private String ipSentencingDetails;

	private String ipCourtCaseNo;

	private String location;

	@ManyToMany
	@JoinTable(name = "ce_case_infringement$read_with")
	private Set<CeProvision> readWiths = new HashSet<>(); // the selected readWidths for a TG's provision

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseRecommendation lastRecommendation;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isConcluded;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public CeCase getCeCase() {
		return ceCase;
	}

	public void setCeCase(CeCase ceCase) {
		this.ceCase = ceCase;
	}

	public CeCase getCeOriginatingCase() {
		return ceOriginatingCase;
	}

	public void setCeOriginatingCase(CeCase ceOriginatingCase) {
		this.ceOriginatingCase = ceOriginatingCase;
	}

	public CeCaseInfringer getCeCaseInfringer() {
		return ceCaseInfringer;
	}

	public void setCeCaseInfringer(CeCaseInfringer ceCaseInfringer) {
		this.ceCaseInfringer = ceCaseInfringer;
	}

	public CeProvision getCeProvision() {
		return ceProvision;
	}

	public void setCeProvision(CeProvision ceProvision) {
		this.ceProvision = ceProvision;
	}

	public LocalDateTime getInfringedDate() {
		return infringedDate;
	}

	public void setInfringedDate(LocalDateTime infringedDate) {
		this.infringedDate = infringedDate;
	}

	public Type getOutcome() {
		return outcome;
	}

	public void setOutcome(Type outcome) {
		this.outcome = outcome;
	}

	public LocalDateTime getOutcomeDate() {
		return outcomeDate;
	}

	public void setOutcomeDate(LocalDateTime outcomeDate) {
		this.outcomeDate = outcomeDate;
	}

	public CeCaseRecommendation getLastRecommendation() {
		return lastRecommendation;
	}

	public void setLastRecommendation(CeCaseRecommendation lastRecommendation) {
		this.lastRecommendation = lastRecommendation;
	}

	public CeCaseDecision getLastDecision() {
		return lastDecision;
	}

	public void setLastDecision(CeCaseDecision lastDecision) {
		this.lastDecision = lastDecision;
	}

	public Integer getIpOffenceCount() {
		return ipOffenceCount;
	}

	public void setIpOffenceCount(Integer ipOffenceCount) {
		this.ipOffenceCount = ipOffenceCount;
	}

	public String getIpSentencingDetails() {
		return ipSentencingDetails;
	}

	public void setIpSentencingDetails(String ipSentencingDetails) {
		this.ipSentencingDetails = ipSentencingDetails;
	}

	public String getIpCourtCaseNo() {
		return ipCourtCaseNo;
	}

	public void setIpCourtCaseNo(String ipCourtCaseNo) {
		this.ipCourtCaseNo = ipCourtCaseNo;
	}

	public Set<CeProvision> getReadWiths() {
		return readWiths;
	}

	public void setReadWiths(Set<CeProvision> readWiths) {
		this.readWiths = readWiths;
	}

	public Boolean getIsConcluded() {
		return isConcluded;
	}

	public void setIsConcluded(Boolean isConcluded) {
		this.isConcluded = isConcluded;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
