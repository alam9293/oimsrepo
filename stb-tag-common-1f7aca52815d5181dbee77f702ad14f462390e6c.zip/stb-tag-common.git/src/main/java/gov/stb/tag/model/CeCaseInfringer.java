package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseInfringer extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase ceCase;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	private String name;

	private String uenUin;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type idType;

	private String category; // for IP only

	@ManyToOne(fetch = FetchType.LAZY)
	private Type nationality;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type ageGroup;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type guidingLanguageProvided;

	@OneToMany(mappedBy = "ceCaseInfringer")
	private Set<CeCaseInfringement> ceCaseInfringements;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeCase getCeCase() {
		return ceCase;
	}

	public void setCeCase(CeCase ceCase) {
		this.ceCase = ceCase;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public Type getIdType() {
		return idType;
	}

	public void setIdType(Type idType) {
		this.idType = idType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Set<CeCaseInfringement> getCeCaseInfringements() {
		return ceCaseInfringements;
	}

	public void setCeCaseInfringements(Set<CeCaseInfringement> ceCaseInfringements) {
		this.ceCaseInfringements = ceCaseInfringements;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Type getNationality() {
		return nationality;
	}

	public void setNationality(Type nationality) {
		this.nationality = nationality;
	}

	public Type getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(Type ageGroup) {
		this.ageGroup = ageGroup;
	}

	public Type getGuidingLanguageProvided() {
		return guidingLanguageProvided;
	}

	public void setGuidingLanguageProvided(Type guidingLanguageProvided) {
		this.guidingLanguageProvided = guidingLanguageProvided;
	}

}
