package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeCaseRescind extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Workflow workflow;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement ceCaseInfringement;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean toEmailLetter;

	@ManyToOne(fetch = FetchType.LAZY)
	private File letter;

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailLog letterEmailLog;

	private LocalDate letterIssuanceDate;

	@Transient
	private boolean isNewOrEdited;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public CeCaseInfringement getCeCaseInfringement() {
		return ceCaseInfringement;
	}

	public void setCeCaseInfringement(CeCaseInfringement ceCaseInfringement) {
		this.ceCaseInfringement = ceCaseInfringement;
	}

	public File getLetter() {
		return letter;
	}

	public void setLetter(File letter) {
		this.letter = letter;
	}

	public EmailLog getLetterEmailLog() {
		return letterEmailLog;
	}

	public void setLetterEmailLog(EmailLog letterEmailLog) {
		this.letterEmailLog = letterEmailLog;
	}

	public Boolean getToEmailLetter() {
		return toEmailLetter;
	}

	public void setToEmailLetter(Boolean toEmailLetter) {
		this.toEmailLetter = toEmailLetter;
	}

	public boolean isNewOrEdited() {
		return isNewOrEdited;
	}

	public void setNewOrEdited(boolean isNewOrEdited) {
		this.isNewOrEdited = isNewOrEdited;
	}

	public LocalDate getLetterIssuanceDate() {
		return letterIssuanceDate;
	}

	public void setLetterIssuanceDate(LocalDate letterIssuanceDate) {
		this.letterIssuanceDate = letterIssuanceDate;
	}

}
