package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

// Format will be "TAA S6(1): Person carrying on business of travel agent to be licensed". Mouse-over it to show description and readWith(s)
@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeProvision extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type chapter; // 305B, TAA, TAR

	private String section; // e.g. S6(1)

	private String label; // e.g. Persons carrying on business of travel agent to be licensed

	@Column(length = 5000)
	private String description; // e.g. Person that carry on the business of a travel agent without a valid travel agent licence

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isOffence; // marks the contravention of this provision is an offence (so far only TG needs this)

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isReadWithOnly; // to show as list of readWith(s) only instead of main list

	private LocalDate effectiveDate;

	private LocalDate ineffectiveDate;

	@ManyToMany
	@JoinTable(name = "ce_provision$read_with")
	private Set<CeProvision> readWiths = new HashSet<>(); // the possible readWidths for a provision

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getChapter() {
		return chapter;
	}

	public void setChapter(Type chapter) {
		this.chapter = chapter;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean isOffence() {
		return isOffence;
	}

	public void setIsOffence(Boolean isOffence) {
		this.isOffence = isOffence;
	}

	public Boolean isReadWithOnly() {
		return isReadWithOnly;
	}

	public void setIsReadWithOnly(Boolean isReadWithOnly) {
		this.isReadWithOnly = isReadWithOnly;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public LocalDate getIneffectiveDate() {
		return ineffectiveDate;
	}

	public void setIneffectiveDate(LocalDate ineffectiveDate) {
		this.ineffectiveDate = ineffectiveDate;
	}

	public Set<CeProvision> getReadWiths() {
		return readWiths;
	}

	public void setReadWiths(Set<CeProvision> readWiths) {
		this.readWiths = readWiths;
	}

}
