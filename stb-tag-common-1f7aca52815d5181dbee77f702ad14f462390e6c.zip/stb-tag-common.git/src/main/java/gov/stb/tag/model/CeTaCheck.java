package gov.stb.tag.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTaCheck extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private CeTaCheckScheduleItem ceTaCheckScheduleItem;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase ceCase;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDraft;

	// @ManyToOne(fetch = FetchType.LAZY)
	// private Status checkStatus; // Completed, To revisit, To recheck

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address; // snapshot a new address (actual address visited)

	@ManyToOne(fetch = FetchType.LAZY)
	private Type addressType; // Registered Address, Operating Address, Branch Address

	private String licenceNo;

	private String uen;

	private String taName;

	private String taKeUin;

	private String taKeName;

	private String taStaffName;

	private String taStaffDesignation;

	private LocalDateTime checkedDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isAcknowledged;

	private LocalDate lastAcknowledgedDate; // set to null when report is edited & resubmitted

	@ManyToOne(fetch = FetchType.LAZY)
	private User lastAcknowledgedBy;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type isCompliant;

	@ManyToOne(fetch = FetchType.LAZY)
	private User eoUser;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type auxEoUser;

	@Column(length = 5000)
	private String remarks;

	@OneToMany(mappedBy = "ceTaCheck")
	@OrderBy("createdDate ASC")
	private Set<CeTaCheckDocument> ceTaCheckDocuments = new HashSet<>();

	@OneToMany(mappedBy = "ceTaCheck")
	private Set<CeTaCheckQnResponse> ceTaCheckQnResponses = new HashSet<>();

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	@OrderBy("createdDate ASC")
	private Set<File> files = new HashSet<>();

	private String signdocId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTaCheckScheduleItem getCeTaCheckScheduleItem() {
		return ceTaCheckScheduleItem;
	}

	public void setCeTaCheckScheduleItem(CeTaCheckScheduleItem ceTaCheckScheduleItem) {
		this.ceTaCheckScheduleItem = ceTaCheckScheduleItem;
	}

	public CeCase getCeCase() {
		return ceCase;
	}

	public void setCeCase(CeCase ceCase) {
		this.ceCase = ceCase;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Type getAddressType() {
		return addressType;
	}

	public void setAddressType(Type addressType) {
		this.addressType = addressType;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public String getTaKeName() {
		return taKeName;
	}

	public void setTaKeName(String taKeName) {
		this.taKeName = taKeName;
	}

	public String getTaStaffName() {
		return taStaffName;
	}

	public void setTaStaffName(String taStaffName) {
		this.taStaffName = taStaffName;
	}

	public String getTaStaffDesignation() {
		return taStaffDesignation;
	}

	public void setTaStaffDesignation(String taStaffDesignation) {
		this.taStaffDesignation = taStaffDesignation;
	}

	public LocalDateTime getCheckedDate() {
		return checkedDate;
	}

	public void setCheckedDate(LocalDateTime checkedDate) {
		this.checkedDate = checkedDate;
	}

	public User getEoUser() {
		return eoUser;
	}

	public void setEoUser(User eoUser) {
		this.eoUser = eoUser;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Set<CeTaCheckDocument> getCeTaCheckDocuments() {
		return ceTaCheckDocuments;
	}

	public void setCeTaCheckDocuments(Set<CeTaCheckDocument> ceTaCheckDocuments) {
		this.ceTaCheckDocuments = ceTaCheckDocuments;
	}

	public Set<CeTaCheckQnResponse> getCeTaCheckQnResponses() {
		return ceTaCheckQnResponses;
	}

	public void setCeTaCheckQnResponses(Set<CeTaCheckQnResponse> ceTaCheckQnResponses) {
		this.ceTaCheckQnResponses = ceTaCheckQnResponses;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getTaKeUin() {
		return taKeUin;
	}

	public void setTaKeUin(String taKeUin) {
		this.taKeUin = taKeUin;
	}

	public Type getAuxEoUser() {
		return auxEoUser;
	}

	public void setAuxEoUser(Type auxEoUser) {
		this.auxEoUser = auxEoUser;
	}

	public void setIsAcknowledged(Boolean isAcknowledged) {
		this.isAcknowledged = isAcknowledged;
	}

	public Boolean isAcknowledged() {
		return isAcknowledged;
	}

	public LocalDate getLastAcknowledgedDate() {
		return lastAcknowledgedDate;
	}

	public void setLastAcknowledgedDate(LocalDate lastAcknowledgedDate) {
		this.lastAcknowledgedDate = lastAcknowledgedDate;
	}

	public User getLastAcknowledgedBy() {
		return lastAcknowledgedBy;
	}

	public void setLastAcknowledgedBy(User lastAcknowledgedBy) {
		this.lastAcknowledgedBy = lastAcknowledgedBy;
	}

	public Boolean getIsAcknowledged() {
		return isAcknowledged;
	}

	public Type getIsCompliant() {
		return isCompliant;
	}

	public void setIsCompliant(Type isCompliant) {
		this.isCompliant = isCompliant;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Boolean isDraft() {
		return isDraft;
	}

	public String getSigndocId() {
		return signdocId;
	}

	public void setSigndocId(String signdocId) {
		this.signdocId = signdocId;
	}

}
