package gov.stb.tag.model;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTaCheckDocument extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheck ceTaCheck;

	private String invoiceBookingNo;

	private BigDecimal totalPrice;

	private Integer noOfPax;

	private BigDecimal paymentDepositMade;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type isConsumerInformed; // FLAG_N, FLAG_Y, FLAG_NA

	private String remarks;

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	@OrderBy("createdDate ASC")
	private Set<File> files = new HashSet<>();

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTaCheck getCeTaCheck() {
		return ceTaCheck;
	}

	public void setCeTaCheck(CeTaCheck ceTaCheck) {
		this.ceTaCheck = ceTaCheck;
	}

	public String getInvoiceBookingNo() {
		return invoiceBookingNo;
	}

	public void setInvoiceBookingNo(String invoiceBookingNo) {
		this.invoiceBookingNo = invoiceBookingNo;
	}

	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Integer getNoOfPax() {
		return noOfPax;
	}

	public void setNoOfPax(Integer noOfPax) {
		this.noOfPax = noOfPax;
	}

	public BigDecimal getPaymentDepositMade() {
		return paymentDepositMade;
	}

	public void setPaymentDepositMade(BigDecimal paymentDepositMade) {
		this.paymentDepositMade = paymentDepositMade;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Type getIsConsumerInformed() {
		return isConsumerInformed;
	}

	public void setIsConsumerInformed(Type isConsumerInformed) {
		this.isConsumerInformed = isConsumerInformed;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

}
