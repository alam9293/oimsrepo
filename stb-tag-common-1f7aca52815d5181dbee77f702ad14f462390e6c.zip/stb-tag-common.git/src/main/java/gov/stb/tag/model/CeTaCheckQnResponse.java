package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTaCheckQnResponse extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheck ceTaCheck;

	@OneToOne
	private CeTaCheckQn ceTaCheckQn;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isYes;

	private String remarks;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTaCheck getCeTaCheck() {
		return ceTaCheck;
	}

	public void setCeTaCheck(CeTaCheck ceTaCheck) {
		this.ceTaCheck = ceTaCheck;
	}

	public CeTaCheckQn getCeTaCheckQn() {
		return ceTaCheckQn;
	}

	public void setCeTaCheckQn(CeTaCheckQn ceTaCheckQn) {
		this.ceTaCheckQn = ceTaCheckQn;
	}

	public Boolean isYes() {
		return isYes;
	}

	public void setIsYes(Boolean isYes) {
		this.isYes = isYes;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
