package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTaCheckSchedule extends AuditableIdEntity {

	private Integer id;

	private Integer year;

	private Integer month;

	@OneToOne
	private Workflow workflow; // derive status from workflow.lastAction.status

	@OneToMany(mappedBy = "ceTaCheckSchedule")
	private Set<CeTaCheckScheduleItem> ceTaCheckScheduleItems;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public Set<CeTaCheckScheduleItem> getCeTaCheckScheduleItems() {
		return ceTaCheckScheduleItems;
	}

	public void setCeTaCheckScheduleItems(Set<CeTaCheckScheduleItem> ceTaCheckScheduleItems) {
		this.ceTaCheckScheduleItems = ceTaCheckScheduleItems;
	}

}
