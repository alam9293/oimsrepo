package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTaCheckScheduleItem extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheckSchedule ceTaCheckSchedule;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isApproved; // false = draft or pending approval, true = approved (there should only be 1 set of approved)

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean toRevisit;

	private LocalDate scheduledDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type checkType;

	@ManyToOne(fetch = FetchType.LAZY)
	private User eoUser;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type auxEoUser;

	private String taName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaBranch taBranch;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status licenceStatus;

	private LocalDate licenceCeasedDate;

	private LocalDate licenceExpiryDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address; // snapshot a new address

	@ManyToOne(fetch = FetchType.LAZY)
	private Type addressType; // op, reg, branch

	private Integer noOfReds;

	private LocalDate lastAaFilingFyEndDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status lastAaFilingStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status branchStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type serviceType; // inbound, outboud, both

	// TODO: FK to C&E Case or CaseOffence model to derive TATI Outcome type, and Outcome Approved Date
	// @ManyToOne(fetch = FetchType.LAZY)
	// private CeCase tatiCase;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheck lastTatiCheck; // will snapshot the last TATI check upon saved schedule

	private Boolean isLastCheckDone; // will snapshot the last check done upon saved schedule

	@OneToOne(mappedBy = "ceTaCheckScheduleItem")
	private CeTaCheck ceTaCheck; // TATI report submitted for this scheduled check

	@OneToMany(mappedBy = "ceTaCheckScheduleItem")
	private Set<CeTaFieldReport> ceTaFieldReports; // TA field report submitted for this scheduled check

	@OneToOne
	private CeTaCheckScheduleItem lastApprovedCeTaCheckScheduleItem; // last approved CeTaCheckScheduleItem tied to this scheduled item

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTaCheckSchedule getCeTaCheckSchedule() {
		return ceTaCheckSchedule;
	}

	public void setCeTaCheckSchedule(CeTaCheckSchedule ceTaCheckSchedule) {
		this.ceTaCheckSchedule = ceTaCheckSchedule;
	}

	public Boolean isApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public LocalDate getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(LocalDate scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public Type getCheckType() {
		return checkType;
	}

	public void setCheckType(Type checkType) {
		this.checkType = checkType;
	}

	public User getEoUser() {
		return eoUser;
	}

	public void setEoUser(User eoUser) {
		this.eoUser = eoUser;
	}

	public Type getAuxEoUser() {
		return auxEoUser;
	}

	public void setAuxEoUser(Type auxEoUser) {
		this.auxEoUser = auxEoUser;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public TaBranch getTaBranch() {
		return taBranch;
	}

	public void setTaBranch(TaBranch taBranch) {
		this.taBranch = taBranch;
	}

	public Status getLicenceStatus() {
		return licenceStatus;
	}

	public void setLicenceStatus(Status licenceStatus) {
		this.licenceStatus = licenceStatus;
	}

	public LocalDate getLicenceCeasedDate() {
		return licenceCeasedDate;
	}

	public void setLicenceCeasedDate(LocalDate licenceCeasedDate) {
		this.licenceCeasedDate = licenceCeasedDate;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Type getAddressType() {
		return addressType;
	}

	public void setAddressType(Type addressType) {
		this.addressType = addressType;
	}

	public Integer getNoOfReds() {
		return noOfReds;
	}

	public void setNoOfReds(Integer noOfReds) {
		this.noOfReds = noOfReds;
	}

	public LocalDate getLastAaFilingFyEndDate() {
		return lastAaFilingFyEndDate;
	}

	public void setLastAaFilingFyEndDate(LocalDate lastAaFilingFyEndDate) {
		this.lastAaFilingFyEndDate = lastAaFilingFyEndDate;
	}

	public Status getLastAaFilingStatus() {
		return lastAaFilingStatus;
	}

	public void setLastAaFilingStatus(Status lastAaFilingStatus) {
		this.lastAaFilingStatus = lastAaFilingStatus;
	}

	public Status getBranchStatus() {
		return branchStatus;
	}

	public void setBranchStatus(Status branchStatus) {
		this.branchStatus = branchStatus;
	}

	public Type getServiceType() {
		return serviceType;
	}

	public void setServiceType(Type serviceType) {
		this.serviceType = serviceType;
	}

	public CeTaCheck getLastTatiCheck() {
		return lastTatiCheck;
	}

	public Boolean getIsLastCheckDone() {
		return isLastCheckDone;
	}

	public void setIsLastCheckDone(Boolean isLastCheckDone) {
		this.isLastCheckDone = isLastCheckDone;
	}

	public void setLastTatiCheck(CeTaCheck lastTatiCheck) {
		this.lastTatiCheck = lastTatiCheck;
	}

	public CeTaCheck getCeTaCheck() {
		return ceTaCheck;
	}

	public void setCeTaCheck(CeTaCheck ceTaCheck) {
		this.ceTaCheck = ceTaCheck;
	}

	public Set<CeTaFieldReport> getCeTaFieldReports() {
		return ceTaFieldReports;
	}

	public void setCeTaFieldReports(Set<CeTaFieldReport> ceTaFieldReports) {
		this.ceTaFieldReports = ceTaFieldReports;
	}

	public CeTaCheckScheduleItem getLastApprovedCeTaCheckScheduleItem() {
		return lastApprovedCeTaCheckScheduleItem;
	}

	public void setLastApprovedCeTaCheckScheduleItem(CeTaCheckScheduleItem lastApprovedCeTaCheckScheduleItem) {
		this.lastApprovedCeTaCheckScheduleItem = lastApprovedCeTaCheckScheduleItem;
	}

	public Boolean toRevisit() {
		return toRevisit;
	}

	public void setToRevisit(Boolean toRevisit) {
		this.toRevisit = toRevisit;
	}

	public Boolean isEditable() {
		Boolean selfNoCheckReportSubmitted = this.getCeTaCheck() == null && CollectionUtils.isEmpty(this.getCeTaFieldReports());
		Boolean apprNoCheckReportSubmitted = this.getLastApprovedCeTaCheckScheduleItem() == null
				|| (this.getLastApprovedCeTaCheckScheduleItem().getCeTaCheck() == null && CollectionUtils.isEmpty(this.getLastApprovedCeTaCheckScheduleItem().getCeTaFieldReports()));
		return selfNoCheckReportSubmitted && apprNoCheckReportSubmitted;
	}
}
