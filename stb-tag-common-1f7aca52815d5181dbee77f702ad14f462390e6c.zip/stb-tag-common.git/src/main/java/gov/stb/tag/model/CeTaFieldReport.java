package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTaFieldReport extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheckScheduleItem ceTaCheckScheduleItem;

	private String reportNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDraft;

	private String crmRefNo;

	// TA details
	@ManyToOne(fetch = FetchType.LAZY)
	private Address address; // snapshot a new address (actual address visited)

	@ManyToOne(fetch = FetchType.LAZY)
	private Type addressType; // Registered Address, Operating Address, Branch Address

	private String licenceNo;

	private String uen;

	private String taName;

	private String taContactNo;

	// Person Details
	private String uinPassportNo;

	private String name;

	private String role;

	private String personContactNo;

	// @ManyToOne(fetch = FetchType.LAZY)
	// private Type nationality;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase ceCase;

	@ManyToMany
	@JoinTable(name = "ce_ta_field_report$classification")
	private Set<Type> classifications = new HashSet<>();

	private String otherClassification;

	@Column(length = 5000)
	private String details;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type witness;

	private String taOfficerName;

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	@OrderBy("createdDate ASC")
	private Set<File> files = new HashSet<>();

	private String signdocId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTaCheckScheduleItem getCeTaCheckScheduleItem() {
		return ceTaCheckScheduleItem;
	}

	public void setCeTaCheckScheduleItem(CeTaCheckScheduleItem ceTaCheckScheduleItem) {
		this.ceTaCheckScheduleItem = ceTaCheckScheduleItem;
	}

	public String getUinPassportNo() {
		return uinPassportNo;
	}

	public void setUinPassportNo(String uinPassportNo) {
		this.uinPassportNo = uinPassportNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Set<Type> getClassifications() {
		return classifications;
	}

	public void setClassifications(Set<Type> classifications) {
		this.classifications = classifications;
	}

	public String getOtherClassification() {
		return otherClassification;
	}

	public void setOtherClassification(String otherClassification) {
		this.otherClassification = otherClassification;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public CeCase getCeCase() {
		return ceCase;
	}

	public void setCeCase(CeCase ceCase) {
		this.ceCase = ceCase;
	}

	public String getReportNo() {
		return reportNo;
	}

	public void setReportNo(String reportNo) {
		this.reportNo = reportNo;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Type getAddressType() {
		return addressType;
	}

	public void setAddressType(Type addressType) {
		this.addressType = addressType;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public String getTaContactNo() {
		return taContactNo;
	}

	public void setTaContactNo(String taContactNo) {
		this.taContactNo = taContactNo;
	}

	public String getPersonContactNo() {
		return personContactNo;
	}

	public void setPersonContactNo(String personContactNo) {
		this.personContactNo = personContactNo;
	}

	public Type getWitness() {
		return witness;
	}

	public void setWitness(Type witness) {
		this.witness = witness;
	}

	public String getTaOfficerName() {
		return taOfficerName;
	}

	public void setTaOfficerName(String taOfficerName) {
		this.taOfficerName = taOfficerName;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public String getCrmRefNo() {
		return crmRefNo;
	}

	public void setCrmRefNo(String crmRefNo) {
		this.crmRefNo = crmRefNo;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public Boolean isDraft() {
		return isDraft;
	}

	public String getSigndocId() {
		return signdocId;
	}

	public void setSigndocId(String signdocId) {
		this.signdocId = signdocId;
	}

}
