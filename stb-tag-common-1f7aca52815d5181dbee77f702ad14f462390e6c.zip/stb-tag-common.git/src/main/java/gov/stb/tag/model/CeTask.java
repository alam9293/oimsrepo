package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTask extends AuditableIdEntity {

	private Integer id;

	private String name;

	private String uenUin;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type idType;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // TAR R(1)(a), etc

	@Column(length = 5000)
	private String details;

	@ManyToOne(fetch = FetchType.LAZY)
	private User oic;

	@ManyToOne(fetch = FetchType.LAZY)
	private User assignee;

	private LocalDate slaExpiryDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status; // To Recommend, To Impose Decision, To Pay, To Support, To Approve, Completed

	@ManyToOne(fetch = FetchType.LAZY)
	private Workflow forWorkflow; // to track case task progress status, 1 task for each: To Support, To Approve

	@Deprecated
	@ManyToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement forInfringement; // TODO: Yvonne, pls remove once dashboard has been update

	@ManyToOne(fetch = FetchType.LAZY)
	private CeCase forCase; // to track case progress (from triggers, field reports, and tatiChecks) status, 1 task for each: To Recommend, To Impose Decision, To Pay

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition forFilingCondition;

	private String forBillRefNo; // after relevant batch job to check from payment gateway, CeTaskHelper to find all tasks by this to update status

	private Integer forScheduleYear; // after relevant schedule is done, CeTaskHelper to find all tasks by this to update status

	private Integer forScheduleMonth;

	private LocalDate forScheduleFromDate;

	private LocalDate forScheduleToDate;

	@OneToMany(mappedBy = "compliantTatiTask")
	private Set<CeCase> forCompliantTatiCases; // to track the list of auto-created compliant TATI cases with auto-recommended NFA

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUenUin() {
		return uenUin;
	}

	public void setUenUin(String uenUin) {
		this.uenUin = uenUin;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public Type getIdType() {
		return idType;
	}

	public void setIdType(Type idType) {
		this.idType = idType;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public User getOic() {
		return oic;
	}

	public void setOic(User oic) {
		this.oic = oic;
	}

	public User getAssignee() {
		return assignee;
	}

	public void setAssignee(User assignee) {
		this.assignee = assignee;
	}

	public LocalDate getSlaExpiryDate() {
		return slaExpiryDate;
	}

	public void setSlaExpiryDate(LocalDate slaExpiryDate) {
		this.slaExpiryDate = slaExpiryDate;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Workflow getForWorkflow() {
		return forWorkflow;
	}

	public void setForWorkflow(Workflow forWorkflow) {
		this.forWorkflow = forWorkflow;
	}

	@Deprecated
	public CeCaseInfringement getForInfringement() {
		return forInfringement;
	}

	@Deprecated
	public void setForInfringement(CeCaseInfringement forInfringement) {
		this.forInfringement = forInfringement;
	}

	public CeCase getForCase() {
		return forCase;
	}

	public void setForCase(CeCase forCase) {
		this.forCase = forCase;
	}

	public TaFilingCondition getForFilingCondition() {
		return forFilingCondition;
	}

	public void setForFilingCondition(TaFilingCondition forFilingCondition) {
		this.forFilingCondition = forFilingCondition;
	}

	public String getForBillRefNo() {
		return forBillRefNo;
	}

	public void setForBillRefNo(String forBillRefNo) {
		this.forBillRefNo = forBillRefNo;
	}

	public Integer getForScheduleYear() {
		return forScheduleYear;
	}

	public void setForScheduleYear(Integer forScheduleYear) {
		this.forScheduleYear = forScheduleYear;
	}

	public Integer getForScheduleMonth() {
		return forScheduleMonth;
	}

	public void setForScheduleMonth(Integer forScheduleMonth) {
		this.forScheduleMonth = forScheduleMonth;
	}

	public LocalDate getForScheduleFromDate() {
		return forScheduleFromDate;
	}

	public void setForScheduleFromDate(LocalDate forScheduleFromDate) {
		this.forScheduleFromDate = forScheduleFromDate;
	}

	public LocalDate getForScheduleToDate() {
		return forScheduleToDate;
	}

	public void setForScheduleToDate(LocalDate forScheduleToDate) {
		this.forScheduleToDate = forScheduleToDate;
	}

	public Set<CeCase> getForCompliantTatiCases() {
		return forCompliantTatiCases;
	}

	public void setForCompliantTatiCases(Set<CeCase> forCompliantTatiCases) {
		this.forCompliantTatiCases = forCompliantTatiCases;
	}

}
