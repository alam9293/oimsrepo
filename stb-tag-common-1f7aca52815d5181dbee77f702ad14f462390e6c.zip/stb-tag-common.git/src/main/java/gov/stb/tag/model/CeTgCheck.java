package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTgCheck extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private CeTgCheckScheduleItemLocation ceTgCheckScheduleItemLocation;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDraft;

	private Integer noOfGrpWithTg;

	private Integer noOfGrpWithoutTg;

	private Integer noOfGrpWithExpert;

	private Integer noOfCruiseWithTg;

	private Integer noOfCruiseWithoutTg;

	private Integer noOfStudGrpWithTg;

	private Integer noOfStudGrpWithTchr;

	private Integer noOfStudGrpWithStud;

	private Integer noOfMiceGrpWithTg;

	private Integer noOfMiceGrpWithExpat;

	private Integer noOfCombiWithTg; // for migration only

	private Integer noOfCombiWithoutTg; // for migration only

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	private Set<File> files = new HashSet<>();

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTgCheckScheduleItemLocation getCeTgCheckScheduleItemLocation() {
		return ceTgCheckScheduleItemLocation;
	}

	public void setCeTgCheckScheduleItemLocation(CeTgCheckScheduleItemLocation ceTgCheckScheduleItemLocation) {
		this.ceTgCheckScheduleItemLocation = ceTgCheckScheduleItemLocation;
	}

	public Boolean isDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean draft) {
		isDraft = draft;
	}

	public Integer getNoOfGrpWithTg() {
		return noOfGrpWithTg;
	}

	public void setNoOfGrpWithTg(Integer noOfGrpWithTg) {
		this.noOfGrpWithTg = noOfGrpWithTg;
	}

	public Integer getNoOfGrpWithoutTg() {
		return noOfGrpWithoutTg;
	}

	public void setNoOfGrpWithoutTg(Integer noOfGrpWithoutTg) {
		this.noOfGrpWithoutTg = noOfGrpWithoutTg;
	}

	public Integer getNoOfGrpWithExpert() {
		return noOfGrpWithExpert;
	}

	public void setNoOfGrpWithExpert(Integer noOfGrpWithExpert) {
		this.noOfGrpWithExpert = noOfGrpWithExpert;
	}

	public Integer getNoOfCruiseWithTg() {
		return noOfCruiseWithTg;
	}

	public void setNoOfCruiseWithTg(Integer noOfCruiseWithTg) {
		this.noOfCruiseWithTg = noOfCruiseWithTg;
	}

	public Integer getNoOfCruiseWithoutTg() {
		return noOfCruiseWithoutTg;
	}

	public void setNoOfCruiseWithoutTg(Integer noOfCruiseWithoutTg) {
		this.noOfCruiseWithoutTg = noOfCruiseWithoutTg;
	}

	public Integer getNoOfStudGrpWithTg() {
		return noOfStudGrpWithTg;
	}

	public void setNoOfStudGrpWithTg(Integer noOfStudGrpWithTg) {
		this.noOfStudGrpWithTg = noOfStudGrpWithTg;
	}

	public Integer getNoOfStudGrpWithTchr() {
		return noOfStudGrpWithTchr;
	}

	public void setNoOfStudGrpWithTchr(Integer noOfStudGrpWithTgTchr) {
		this.noOfStudGrpWithTchr = noOfStudGrpWithTgTchr;
	}

	public Integer getNoOfStudGrpWithStud() {
		return noOfStudGrpWithStud;
	}

	public void setNoOfStudGrpWithStud(Integer noOfStudGrpWithTgStud) {
		this.noOfStudGrpWithStud = noOfStudGrpWithTgStud;
	}

	public Integer getNoOfMiceGrpWithTg() {
		return noOfMiceGrpWithTg;
	}

	public void setNoOfMiceGrpWithTg(Integer noOfMiceGrpWithTg) {
		this.noOfMiceGrpWithTg = noOfMiceGrpWithTg;
	}

	public Integer getNoOfMiceGrpWithExpat() {
		return noOfMiceGrpWithExpat;
	}

	public void setNoOfMiceGrpWithExpat(Integer noOfMiceGrpWithExpat) {
		this.noOfMiceGrpWithExpat = noOfMiceGrpWithExpat;
	}

	public Integer getNoOfCombiWithTg() {
		return noOfCombiWithTg;
	}

	public void setNoOfCombiWithTg(Integer noOfCombiWithTg) {
		this.noOfCombiWithTg = noOfCombiWithTg;
	}

	public Integer getNoOfCombiWithoutTg() {
		return noOfCombiWithoutTg;
	}

	public void setNoOfCombiWithoutTg(Integer noOfCombiWithoutTg) {
		this.noOfCombiWithoutTg = noOfCombiWithoutTg;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

}
