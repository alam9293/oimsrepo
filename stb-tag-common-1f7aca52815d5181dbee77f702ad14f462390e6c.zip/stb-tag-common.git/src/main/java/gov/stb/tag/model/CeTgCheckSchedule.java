package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTgCheckSchedule extends AuditableIdEntity {

	private Integer id;

	private Integer year;

	private LocalDate fromDate;

	private LocalDate toDate;

	@OneToOne
	private Workflow workflow; // derive status from workflow.lastAction.status

	@OneToMany(mappedBy = "ceTgCheckSchedule")
	@Where(clause = "isDeleted = 0")
	private Set<CeTgCheckScheduleItem> ceTgCheckScheduleItems;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public Set<CeTgCheckScheduleItem> getCeTgCheckScheduleItems() {
		return ceTgCheckScheduleItems;
	}

	public void setCeTgCheckScheduleItems(Set<CeTgCheckScheduleItem> ceTgCheckScheduleItems) {
		this.ceTgCheckScheduleItems = ceTgCheckScheduleItems;
	}

}
