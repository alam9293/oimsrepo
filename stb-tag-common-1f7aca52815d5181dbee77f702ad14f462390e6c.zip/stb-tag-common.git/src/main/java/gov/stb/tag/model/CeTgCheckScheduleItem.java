package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTgCheckScheduleItem extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTgCheckSchedule ceTgCheckSchedule;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isApproved; // false = draft or pending approval, true = approved (there should only be 1 set of approved)

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	private LocalDate scheduleDate;

	private String remarks;

	@OneToMany(mappedBy = "ceTgCheckScheduleItem")
	@Where(clause = "isDeleted = 0")
	private Set<CeTgCheckScheduleItemLocation> ceTgCheckScheduleItemLocations;

	@ManyToMany
	private Set<User> eoUsers = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "ce_tg_check_schedule_item$oeo_user")
	private Set<Type> oeoUsers = new HashSet<>();

	@OneToOne
	private CeTgCheckScheduleItem lastApprovedCeTgCheckScheduleItem; // last approved CeTgCheckScheduleItem tied to this scheduled item

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTgCheckSchedule getCeTgCheckSchedule() {
		return ceTgCheckSchedule;
	}

	public void setCeTgCheckSchedule(CeTgCheckSchedule ceTgCheckSchedule) {
		this.ceTgCheckSchedule = ceTgCheckSchedule;
	}

	public Boolean isApproved() {
		return isApproved;
	}

	public void setIsApproved(Boolean isApproved) {
		this.isApproved = isApproved;
	}

	public LocalDate getScheduleDate() {
		return scheduleDate;
	}

	public void setScheduleDate(LocalDate scheduleDate) {
		this.scheduleDate = scheduleDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Set<CeTgCheckScheduleItemLocation> getCeTgCheckScheduleItemLocations() {
		return ceTgCheckScheduleItemLocations;
	}

	public void setCeTgCheckScheduleItemLocations(Set<CeTgCheckScheduleItemLocation> ceTgCheckScheduleItemLocations) {
		this.ceTgCheckScheduleItemLocations = ceTgCheckScheduleItemLocations;
	}

	public Set<User> getEoUsers() {
		return eoUsers;
	}

	public void setEoUsers(Set<User> eoUsers) {
		this.eoUsers = eoUsers;
	}

	public Set<Type> getOeoUsers() {
		return oeoUsers;
	}

	public void setOeoUsers(Set<Type> oeoUsers) {
		this.oeoUsers = oeoUsers;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Boolean getIsApproved() {
		return isApproved;
	}

	public CeTgCheckScheduleItem getLastApprovedCeTgCheckScheduleItem() {
		return lastApprovedCeTgCheckScheduleItem;
	}

	public void setLastApprovedCeTgCheckScheduleItem(CeTgCheckScheduleItem lastApprovedCeTgCheckScheduleItem) {
		this.lastApprovedCeTgCheckScheduleItem = lastApprovedCeTgCheckScheduleItem;
	}

	public Boolean isEditable() {
		Boolean selfNoCheckReportSubmitted = this.getCeTgCheckScheduleItemLocations().stream().filter(location -> !location.isEditable()).count() == 0;
		Boolean apprNoCheckReportSubmitted = this.getLastApprovedCeTgCheckScheduleItem() == null
				|| this.getLastApprovedCeTgCheckScheduleItem().getCeTgCheckScheduleItemLocations().stream().filter(location -> !location.isEditable()).count() == 0;
		return selfNoCheckReportSubmitted && apprNoCheckReportSubmitted;
	}
}
