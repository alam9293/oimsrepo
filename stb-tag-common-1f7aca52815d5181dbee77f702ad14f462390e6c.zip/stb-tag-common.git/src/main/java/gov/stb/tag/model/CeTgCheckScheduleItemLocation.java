package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTgCheckScheduleItemLocation extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTgCheckScheduleItem ceTgCheckScheduleItem;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type meridiem;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type location;

	@OneToOne(mappedBy = "ceTgCheckScheduleItemLocation")
	private CeTgCheck ceTgCheck;

	@OneToMany(mappedBy = "ceTgCheckScheduleItemLocation")
	private Set<CeTgFieldReport> ceTgFieldReport;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTgCheckScheduleItem getCeTgCheckScheduleItem() {
		return ceTgCheckScheduleItem;
	}

	public void setCeTgCheckScheduleItem(CeTgCheckScheduleItem ceTgCheckScheduleItem) {
		this.ceTgCheckScheduleItem = ceTgCheckScheduleItem;
	}

	public Type getMeridiem() {
		return meridiem;
	}

	public void setMeridiem(Type meridiem) {
		this.meridiem = meridiem;
	}

	public Type getLocation() {
		return location;
	}

	public void setLocation(Type location) {
		this.location = location;
	}

	public CeTgCheck getCeTgCheck() {
		return ceTgCheck;
	}

	public void setCeTgCheck(CeTgCheck ceTgCheck) {
		this.ceTgCheck = ceTgCheck;
	}

	public Set<CeTgFieldReport> getCeTgFieldReport() {
		return ceTgFieldReport;
	}

	public void setCeTgFieldReport(Set<CeTgFieldReport> ceTgFieldReport) {
		this.ceTgFieldReport = ceTgFieldReport;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Boolean isEditable() {
		return this.getCeTgCheck() == null && CollectionUtils.isEmpty(this.getCeTgFieldReport());
	}
}
