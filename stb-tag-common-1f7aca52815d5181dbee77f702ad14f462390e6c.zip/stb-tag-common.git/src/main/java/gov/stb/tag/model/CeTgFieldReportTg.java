package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTgFieldReportTg extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTgFieldReport ceTgFieldReport;

	private String uin;

	private String passportNo;

	private String name;

	private String contactNo;

	private String role;

	private String taName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type nationality;

	private String vehicleNo;

	private Integer noOfTourists;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type touristNationality;

	// TODO: may need to disallow others, since stb officer is given the whole list of infringements to select now instead of paper form
	@Deprecated
	private String otherProvision;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type ageGroup;

	@OneToMany(mappedBy = "ceTgFieldReportTg")
	private Set<CeTgFieldReportTgInfringement> ceTgFieldReportTgInfringements = new HashSet<>();

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status licenceStatus;

	private String approvedLanguages;

	private LocalDate licenceExpiryDate;

	private Boolean hasValidLicence; // null = Not Applicable

	private Boolean isLicenceDisplayed; // null = Not Applicable

	private Boolean isPictureTallied; // null = Not Applicable

	private Boolean isLanguageApproved; // null = Not Applicable

	@ManyToOne(fetch = FetchType.LAZY)
	private Type guidingLanguageProvided;

	private Integer noOfAntecedentRecords;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTgFieldReport getCeTgFieldReport() {
		return ceTgFieldReport;
	}

	public void setCeTgFieldReport(CeTgFieldReport ceTgFieldReport) {
		this.ceTgFieldReport = ceTgFieldReport;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public Type getNationality() {
		return nationality;
	}

	public void setNationality(Type nationality) {
		this.nationality = nationality;
	}

	public String getVehicleNo() {
		return vehicleNo;
	}

	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}

	public Integer getNoOfTourists() {
		return noOfTourists;
	}

	public void setNoOfTourists(Integer noOfTourists) {
		this.noOfTourists = noOfTourists;
	}

	public Type getTouristNationality() {
		return touristNationality;
	}

	public void setTouristNationality(Type touristNationality) {
		this.touristNationality = touristNationality;
	}

	public String getOtherProvision() {
		return otherProvision;
	}

	public void setOtherProvision(String otherProvision) {
		this.otherProvision = otherProvision;
	}

	public Type getAgeGroup() {
		return ageGroup;
	}

	public void setAgeGroup(Type ageGroup) {
		this.ageGroup = ageGroup;
	}

	public Set<CeTgFieldReportTgInfringement> getCeTgFieldReportTgInfringements() {
		return ceTgFieldReportTgInfringements;
	}

	public void setCeTgFieldReportTgInfringements(Set<CeTgFieldReportTgInfringement> ceTgFieldReportTgInfringements) {
		this.ceTgFieldReportTgInfringements = ceTgFieldReportTgInfringements;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public Status getLicenceStatus() { return licenceStatus; }

	public void setLicenceStatus(Status licenceStatus) { this.licenceStatus = licenceStatus; }

	public String getApprovedLanguages() { return approvedLanguages; }

	public void setApprovedLanguages(String approvedLanguages) { this.approvedLanguages = approvedLanguages; }

	public LocalDate getLicenceExpiryDate() { return licenceExpiryDate; }

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) { this.licenceExpiryDate = licenceExpiryDate; }

	public Boolean getHasValidLicence() { return hasValidLicence; }

	public void setHasValidLicence(Boolean hasValidLicence) { this.hasValidLicence = hasValidLicence; }

	public Boolean isLicenceDisplayed() { return isLicenceDisplayed; }

	public void setIsLicenceDisplayed(Boolean isLicenceDisplayed) { this.isLicenceDisplayed = isLicenceDisplayed; }

	public Boolean isPictureTallied() { return isPictureTallied; }

	public void setIsPictureTallied(Boolean isPictureTallied) { this.isPictureTallied = isPictureTallied; }

	public Boolean isLanguageApproved() { return isLanguageApproved; }

	public void setIsLanguageApproved(Boolean isLanguageApproved) { this.isLanguageApproved = isLanguageApproved; }

	public Type getGuidingLanguageProvided() { return guidingLanguageProvided; }

	public void setGuidingLanguageProvided(Type guidingLanguageProvided) { this.guidingLanguageProvided = guidingLanguageProvided; }

	public Integer getNoOfAntecedentRecords() { return noOfAntecedentRecords; }

	public void setNoOfAntecedentRecords(Integer noOfAntecedentRecords) { this.noOfAntecedentRecords = noOfAntecedentRecords; }
}
