package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class CeTgFieldReportTgInfringement extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTgFieldReportTg ceTgFieldReportTg;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeProvision ceProvision;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type recommendedOutcome;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeProvision readWith;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CeTgFieldReportTg getCeTgFieldReportTg() {
		return ceTgFieldReportTg;
	}

	public void setCeTgFieldReportTg(CeTgFieldReportTg ceTgFieldReportTg) {
		this.ceTgFieldReportTg = ceTgFieldReportTg;
	}

	public CeProvision getCeProvision() {
		return ceProvision;
	}

	public void setCeProvision(CeProvision ceProvision) {
		this.ceProvision = ceProvision;
	}

	public Type getRecommendedOutcome() {
		return recommendedOutcome;
	}

	public void setRecommendedOutcome(Type recommendedOutcome) {
		this.recommendedOutcome = recommendedOutcome;
	}

	public CeProvision getReadWith() { return readWith; }

	public void setReadWith(CeProvision readWith) { this.readWith = readWith; }
}
