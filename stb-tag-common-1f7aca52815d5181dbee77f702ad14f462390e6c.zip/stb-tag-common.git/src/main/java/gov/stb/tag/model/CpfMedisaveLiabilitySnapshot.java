package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicUpdate
@DynamicInsert
@SuppressWarnings("serial")
public class CpfMedisaveLiabilitySnapshot extends AuditableIdEntity {

	private Integer id;

	@Column(unique = true, nullable = false)
	private String uinfin; // nric or fin

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasLiability; // may have outstanding liability, but has arrangement with CPF to payoff via installment

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUinfin() {
		return uinfin;
	}

	public void setUinfin(String uinfin) {
		this.uinfin = uinfin;
	}

	public Boolean getHasLiability() {
		return hasLiability;
	}

	public void setHasLiability(Boolean hasLiability) {
		this.hasLiability = hasLiability;
	}
}
