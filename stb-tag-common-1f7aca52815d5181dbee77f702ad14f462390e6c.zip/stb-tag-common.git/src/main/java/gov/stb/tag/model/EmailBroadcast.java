package gov.stb.tag.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OrderBy;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class EmailBroadcast extends AuditableIdEntity {

	private Integer id;

	private String subject;

	@Column(columnDefinition = "text")
	private String content;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isActive;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // TA, TG

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isRecurring;

	private LocalDate startDate;

	private LocalDate endDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type frquency; // Daily, Weekly, Monthly, Yearly

	private LocalDate nextEmailDate;

	private LocalDateTime lastSentDateTime;

	@ManyToMany
	@JoinTable(name = "email_broadcast$guiding_language")
	private Set<Type> guidingLanguages = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "email_broadcast$tier")
	private Set<Type> tiers;

	@ManyToMany
	@JoinTable(name = "email_broadcast$licence_status")
	private Set<Status> licenceStatuses;

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	@OrderBy("createdDate ASC")
	private Set<File> files = new HashSet<>();

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isSending;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Boolean isActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Boolean isRecurring() {
		return isRecurring;
	}

	public void setIsRecurring(Boolean isRecurring) {
		this.isRecurring = isRecurring;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Type getFrquency() {
		return frquency;
	}

	public void setFrquency(Type frquency) {
		this.frquency = frquency;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public LocalDate getNextEmailDate() {
		return nextEmailDate;
	}

	public void setNextEmailDate(LocalDate nextEmailDate) {
		this.nextEmailDate = nextEmailDate;
	}

	public LocalDateTime getLastSentDateTime() {
		return lastSentDateTime;
	}

	public void setLastSentDateTime(LocalDateTime lastSentDateTime) {
		this.lastSentDateTime = lastSentDateTime;
	}

	public Set<Type> getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(Set<Type> guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public Set<Type> getTiers() {
		return tiers;
	}

	public void setTiers(Set<Type> tiers) {
		this.tiers = tiers;
	}

	public Set<Status> getLicenceStatuses() {
		return licenceStatuses;
	}

	public void setLicenceStatuses(Set<Status> licenceStatuses) {
		this.licenceStatuses = licenceStatuses;
	}

	public Boolean isSending() {
		return isSending;
	}

	public void setIsSending(Boolean isSending) {
		this.isSending = isSending;
	}

}