package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicUpdate
@DynamicInsert
@SuppressWarnings("serial")
public class EmailLog extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence; // reminder batch job to find by Licence + EmailTemplate + forYear to determine if email has been sent for AA/ABPR & TA/TG Licence Renewal

	private Integer forYear; // only applicable for emailing of modules with FY (e.g. AA/ABPR) or "Exercise Year" (e.g. TA/TG Renewal). TODO: to index column for performance

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailTemplate template;

	@ManyToOne(fetch = FetchType.LAZY)
	private Job job;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	private String sender;

	@Column(columnDefinition = "text")
	private String receiver;

	private String cc;

	private String attachments;

	private String subject;

	@Column(columnDefinition = "text")
	private String body;

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailBroadcast emailBroadcast;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public Integer getForYear() {
		return forYear;
	}

	public void setForYear(Integer forYear) {
		this.forYear = forYear;
	}

	public EmailTemplate getTemplate() {
		return template;
	}

	public void setTemplate(EmailTemplate template) {
		this.template = template;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getAttachments() {
		return attachments;
	}

	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {

		if (this.getTemplate().getCode().equals(body)) {
			this.body = "Infographics";
		} else {
			this.body = body;
		}
	}

	public EmailBroadcast getEmailBroadcast() {
		return emailBroadcast;
	}

	public void setEmailBroadcast(EmailBroadcast emailBroadcast) {
		this.emailBroadcast = emailBroadcast;
	}

}
