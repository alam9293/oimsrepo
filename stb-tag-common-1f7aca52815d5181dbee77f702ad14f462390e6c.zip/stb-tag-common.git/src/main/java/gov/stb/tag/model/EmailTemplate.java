package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableCodeEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class EmailTemplate extends AuditableCodeEntity {

	private String code;

	private String name;

	private String description;

	private String subject;

	private String emailCountdownBaseDate; // the base of the countdown type. eg FYE, Renewal start date. 1 day after FYE etc

	@Column(columnDefinition = "text")
	private String body;

	@ManyToOne(fetch = FetchType.LAZY)
	private File attachment;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isActive;

	private Integer emailCountdownUnits;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type emailCountdownUnitType; // day, month

	@ManyToOne(fetch = FetchType.LAZY)
	private Type emailCountdownPreposition; // before, on, or after an email template specific date (e.g. FYE, Exercise Start Date)

	@ManyToOne(fetch = FetchType.LAZY)
	private Type emailFrequency; // once, monthly

	@Override
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public File getAttachment() {
		return attachment;
	}

	public void setAttachment(File attachment) {
		this.attachment = attachment;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getEmailCountdownUnits() {
		return emailCountdownUnits;
	}

	public void setEmailCountdownUnits(Integer emailCountdownUnits) {
		this.emailCountdownUnits = emailCountdownUnits;
	}

	public Type getEmailCountdownUnitType() {
		return emailCountdownUnitType;
	}

	public void setEmailCountdownUnitType(Type emailCountdownUnitType) {
		this.emailCountdownUnitType = emailCountdownUnitType;
	}

	public Type getEmailCountdownPreposition() {
		return emailCountdownPreposition;
	}

	public void setEmailCountdownPreposition(Type emailCountdownPreposition) {
		this.emailCountdownPreposition = emailCountdownPreposition;
	}

	public Type getEmailFrequency() {
		return emailFrequency;
	}

	public void setEmailFrequency(Type emailFrequency) {
		this.emailFrequency = emailFrequency;
	}

	public String getEmailCountdownBaseDate() {
		return emailCountdownBaseDate;
	}

	public void setEmailCountdownBaseDate(String emailCountdownBaseDate) {
		this.emailCountdownBaseDate = emailCountdownBaseDate;
	}

}