package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class File extends AuditableIdEntity {

	private Integer id;

	private Integer publicFileId;

	private String filename;

	private String originalFilename;

	private String path;

	private Long size;

	private String extension;

	@Column(length = 5000)
	private String description;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status transferStatus;

	private String transferError;

	private String hash;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getOriginalFilename() {
		return originalFilename;
	}

	public void setOriginalFilename(String originalFilename) {
		this.originalFilename = originalFilename;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Status getTransferStatus() {
		return transferStatus;
	}

	public void setTransferStatus(Status transferStatus) {
		this.transferStatus = transferStatus;
	}

	public String getTransferError() {
		return transferError;
	}

	public void setTransferError(String transferError) {
		this.transferError = transferError;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public Integer getPublicFileId() {
		return publicFileId;
	}

	public void setPublicFileId(Integer publicFileId) {
		this.publicFileId = publicFileId;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

}
