package gov.stb.tag.model;

import java.io.Serializable;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableCodeEntity;
import com.wiz.model.api.Listable;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Function extends AuditableCodeEntity implements Listable {

	private String code;

	private String label;

	private String uri;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type module;

	@Access(AccessType.PROPERTY)
	@Id
	@Override
	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public Type getModule() {
		return module;
	}

	public void setModule(Type module) {
		this.module = module;
	}

	@Override
	public Serializable getKey() {
		return getCode();
	}

	@Override
	public String getOtherLabel() {
		return null;
	}

}
