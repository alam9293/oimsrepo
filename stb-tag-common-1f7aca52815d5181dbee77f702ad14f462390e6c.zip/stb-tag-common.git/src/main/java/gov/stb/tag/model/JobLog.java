package gov.stb.tag.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicUpdate
@DynamicInsert
@SuppressWarnings("serial")
public class JobLog extends AuditableIdEntity {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private Integer id;

	private LocalDateTime startDate;

	private LocalDateTime endDate;

	private String runBy;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status runStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Job job;

	@Column(length = 1000)
	private String filesProcessed = "";

	@Column(length = 5000)
	private String result = "";

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public String getRunBy() {
		return runBy;
	}

	public void setRunBy(String runBy) {
		this.runBy = runBy;
	}

	public Status getRunStatus() {
		return runStatus;
	}

	public void setRunStatus(Status runStatus) {
		this.runStatus = runStatus;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public String getFilesProcessed() {
		return filesProcessed;
	}

	public void setFilesProcessed(String filesProcessed) {
		this.filesProcessed = filesProcessed.substring(0, Math.min(1000, filesProcessed.length()));
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result.substring(0, Math.min(5000, result.length()));
	}

}
