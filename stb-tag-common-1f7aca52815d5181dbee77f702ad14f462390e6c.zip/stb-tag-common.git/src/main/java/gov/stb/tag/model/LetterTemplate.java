package gov.stb.tag.model;

import com.wiz.model.api.AuditableCodeEntity;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class LetterTemplate extends AuditableCodeEntity {

    private String code;

    private String name;

    private String description;

    @Column(columnDefinition = "text")
    private String content;

    @Column(nullable = false, columnDefinition = "BIT(1) default 0")
    private Boolean isActive;

    @Override
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContent() { return content; }

    public void setContent(String content) { this.content = content; }

    public Boolean getIsActive() { return isActive; }

    public void setActive(Boolean active) { isActive = active; }
}
