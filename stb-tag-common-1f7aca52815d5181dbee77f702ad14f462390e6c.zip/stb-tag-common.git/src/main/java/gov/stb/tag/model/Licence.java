package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Licence extends AuditableIdEntity {

	private Integer id;

	private String licenceNo;

	private String taTgType; // TA or TG

	private LocalDate issueDate; // licence first issue date

	private LocalDate ceasedDate; // the date the licence was ceased/revoked

	private LocalDate startDate; // latest cycle start date

	private LocalDate expiryDate; // latest cycle expiry date

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isPendingCessation;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type tier;

	@ManyToOne(fetch = FetchType.LAZY)
	private TravelAgent travelAgent;

	@OneToOne(fetch = FetchType.LAZY)
	private TouristGuide touristGuide;

	@OneToMany(mappedBy = "licence")
	private Set<StatusSpan> statusSpans;

	@OneToMany(mappedBy = "licence")
	private Set<Application> applications;

	private String trustId;

	private String legacyId;

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement tarR7bInfringement; // TA ceased but not fail to return the licence within X days

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement tarR8Infringement; // TA revoked but not fail to return the licence within X days

	private LocalDate suspendStartDate; // suspension start date

	private LocalDate suspendEndDate; // suspension end date

	@Column(columnDefinition = "INT(11) default 0")
	private Integer isDownloadable; // flag for e-license download request

	@Column(columnDefinition = "INT(11) default 0")
	private Integer isViewable; // flag for view e-license button

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLicenceNo() {
		if (licenceNo == null) {
			return "";
		}
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getTaTgType() {
		return taTgType;
	}

	public void setTaTgType(String taTgType) {
		this.taTgType = taTgType;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Boolean isPendingCessation() {
		return isPendingCessation;
	}

	public void setIsPendingCessation(Boolean isPendingCessation) {
		this.isPendingCessation = isPendingCessation;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Type getTier() {
		return tier;
	}

	public void setTier(Type tier) {
		this.tier = tier;
	}

	public TravelAgent getTravelAgent() {
		return travelAgent;
	}

	public void setTravelAgent(TravelAgent travelAgent) {
		this.travelAgent = travelAgent;
	}

	public TouristGuide getTouristGuide() {
		return touristGuide;
	}

	public void setTouristGuide(TouristGuide touristGuide) {
		this.touristGuide = touristGuide;
	}

	public Set<StatusSpan> getStatusSpans() {
		return statusSpans;
	}

	public void setStatusSpans(Set<StatusSpan> statusSpans) {
		this.statusSpans = statusSpans;
	}

	public Set<Application> getApplications() {
		return applications;
	}

	public void setApplications(Set<Application> applications) {
		this.applications = applications;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

	public CeCaseInfringement getTarR7bInfringement() {
		return tarR7bInfringement;
	}

	public void setTarR7bInfringement(CeCaseInfringement tarR7bInfringement) {
		this.tarR7bInfringement = tarR7bInfringement;
	}

	public CeCaseInfringement getTarR8Infringement() {
		return tarR8Infringement;
	}

	public void setTarR8Infringement(CeCaseInfringement tarR8Infringement) {
		this.tarR8Infringement = tarR8Infringement;
	}

	public LocalDate getSuspendStartDate() {
		return suspendStartDate;
	}

	public void setSuspendStartDate(LocalDate suspendStartDate) {
		this.suspendStartDate = suspendStartDate;
	}

	public LocalDate getSuspendEndDate() {
		return suspendEndDate;
	}

	public void setSuspendEndDate(LocalDate suspendEndDate) {
		this.suspendEndDate = suspendEndDate;
	}

	public Integer getIsDownloadable() {
		return isDownloadable;
	}

	public void setIsDownloadable(Integer isDownloadable) {
		this.isDownloadable = isDownloadable;
	}

	public Integer getIsViewable() {
		return isViewable;
	}

	public void setIsViewable(Integer isViewable) {
		this.isViewable = isViewable;
	}

}
