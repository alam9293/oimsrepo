package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class LicenceReturn extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private LicenceReturnBatch batch;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaBranch branch;

	private LocalDate returnedDate;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LicenceReturnBatch getBatch() {
		return batch;
	}

	public void setBatch(LicenceReturnBatch batch) {
		this.batch = batch;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public TaBranch getBranch() {
		return branch;
	}

	public void setBranch(TaBranch branch) {
		this.branch = branch;
	}

	public LocalDate getReturnedDate() {
		return returnedDate;
	}

	public void setReturnedDate(LocalDate returnedDate) {
		this.returnedDate = returnedDate;
	}

}
