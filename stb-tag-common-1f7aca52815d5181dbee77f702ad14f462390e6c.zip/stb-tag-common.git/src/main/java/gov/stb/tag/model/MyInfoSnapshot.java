package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;


import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicUpdate
@DynamicInsert
@SuppressWarnings("serial")
public class MyInfoSnapshot extends AuditableIdEntity {
    private Integer id;

    @Column(unique = true, nullable = false)
    private String uinfin; // nric or fin

    private String apiName = "PersonBasic"; // current only invoke this API

    @Column(length = 65535, columnDefinition = "text")
    private String responsePayload; // raw data from myinfo respond

    @Override
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUinfin() {
        return uinfin;
    }

    public void setUinfin(String uinfin) {
        this.uinfin = uinfin;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public String getResponsePayload() {
        return responsePayload;
    }

    public void setResponsePayload(String responsePayload) {
        this.responsePayload = responsePayload;
    }
}
