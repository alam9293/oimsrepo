package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class PaymentRequest extends AuditableIdEntity {

	private Integer id;

	private String refNo; // application no or case no

	private String billRefNo;

	private String payerUinUen;

	private String payerName;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isPayerCompany;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isPrePayment;

	@Column(length = 5000)
	private String description;

	private BigDecimal payableAmount;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	private PaymentTxn lastTxn;

	@Column(length = 5000)
	private String remarks;

	private LocalDate dueDate; // TODO: Micro-service to provide API to search by dueDate (e.g. 7 days to due date)

	private String userField1; // TODO: Micro-service to provide API to search by multiple userFields (e.g. licence no)

	private String userField2; // being used for email address in STB TAG

	private String userField3;

	@OneToMany(mappedBy = "paymentRequest")
	private Set<PaymentItem> paymentItems;

	@ManyToMany
	@JoinTable(name = "paymentRequest$paymentTxn", joinColumns = @JoinColumn(name = "paymentRequestId"), inverseJoinColumns = @JoinColumn(name = "paymentTxnsId"))
	private Set<PaymentTxn> paymentTxns = new HashSet<>();

	private String legacyId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getPayerUinUen() {
		return payerUinUen;
	}

	public void setPayerUinUen(String payerUinUen) {
		this.payerUinUen = payerUinUen;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public Boolean isPayerCompany() {
		return isPayerCompany;
	}

	public void setIsPayerCompany(Boolean isPayerCompany) {
		this.isPayerCompany = isPayerCompany;
	}

	public Boolean isPrePayment() {
		return isPrePayment;
	}

	public void setIsPrePayment(Boolean isPrePayment) {
		this.isPrePayment = isPrePayment;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(BigDecimal payableAmount) {
		this.payableAmount = payableAmount;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public PaymentTxn getLastTxn() {
		return lastTxn;
	}

	public void setLastTxn(PaymentTxn lastTxn) {
		this.lastTxn = lastTxn;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public String getUserField1() {
		return userField1;
	}

	public void setUserField1(String userField1) {
		this.userField1 = userField1;
	}

	public String getUserField2() {
		return userField2;
	}

	public void setUserField2(String userField2) {
		this.userField2 = userField2;
	}

	public String getUserField3() {
		return userField3;
	}

	public void setUserField3(String userField3) {
		this.userField3 = userField3;
	}

	public Set<PaymentItem> getPaymentItems() {
		return paymentItems;
	}

	public void setPaymentItems(Set<PaymentItem> paymentItems) {
		this.paymentItems = paymentItems;
	}

	public Set<PaymentTxn> getPaymentTxns() {
		return paymentTxns;
	}

	public void setPaymentTxns(Set<PaymentTxn> paymentTxns) {
		this.paymentTxns = paymentTxns;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

}
