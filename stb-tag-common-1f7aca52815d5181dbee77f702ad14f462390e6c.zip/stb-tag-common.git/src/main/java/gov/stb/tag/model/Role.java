package gov.stb.tag.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableCodeEntity;
import com.wiz.model.api.Listable;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Role extends AuditableCodeEntity implements Listable {

	private String code;

	private String label;

	private Integer ordinal;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isAssignable; // Indicate if this role is allowed to be assigned to intranet user

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isConfigurable; // Indicate if this role's access matrix is configurable

	@ManyToMany
	private Set<Function> functions = new HashSet<>();

	@Override
	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public Boolean isAssignable() {
		return isAssignable;
	}

	public void setIsAssignable(Boolean isAssignable) {
		this.isAssignable = isAssignable;
	}

	public Boolean isConfigurable() {
		return isConfigurable;
	}

	public void setIsConfigurable(Boolean isConfigurable) {
		this.isConfigurable = isConfigurable;
	}

	public Set<Function> getFunctions() {
		return functions;
	}

	public void setFunctions(Set<Function> functions) {
		this.functions = functions;
	}

	@Override
	public Serializable getKey() {
		return getCode();
	}

	@Override
	public String getOtherLabel() {
		return null;
	}

}
