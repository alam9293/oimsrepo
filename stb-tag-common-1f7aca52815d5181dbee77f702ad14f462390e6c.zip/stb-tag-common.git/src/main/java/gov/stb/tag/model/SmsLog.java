package gov.stb.tag.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicUpdate
@DynamicInsert
@SuppressWarnings("serial")
public class SmsLog extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	private SmsTemplate template;

	@ManyToOne(fetch = FetchType.LAZY)
	private Job job;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	private String mobileNo;

	private String body;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public SmsTemplate getTemplate() {
		return template;
	}

	public void setTemplate(SmsTemplate template) {
		this.template = template;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

}
