package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Stakeholder extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isCompany;

	private String companyUen;

	private LocalDate companyIncorporatedDate;

	private String name;

	private String uin;

	private String formerUin;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type sex;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type nationality;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address;

	private LocalDate dob; // KE only

	private String contactNo; // mobile no

	private String officeNo;

	private String residentialNo;

	@Column(length = 320)
	private String email;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type designation;

	private String otherDesignation;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type highestEduLevel; // KE only

	@OneToMany(mappedBy = "stakeholder")
	private Set<TaStakeholder> taStakeholders;

	private String trustId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean isCompany() {
		return isCompany;
	}

	public void setIsCompany(Boolean isCompany) {
		this.isCompany = isCompany;
	}

	public String getCompanyUen() {
		return companyUen;
	}

	public void setCompanyUen(String companyUen) {
		this.companyUen = companyUen;
	}

	public LocalDate getCompanyIncorporatedDate() {
		return companyIncorporatedDate;
	}

	public void setCompanyIncorporatedDate(LocalDate companyIncorporatedDate) {
		this.companyIncorporatedDate = companyIncorporatedDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getFormerUin() {
		return formerUin;
	}

	public void setFormerUin(String formerUin) {
		this.formerUin = formerUin;
	}

	public Type getSex() {
		return sex;
	}

	public void setSex(Type sex) {
		this.sex = sex;
	}

	public Type getNationality() {
		return nationality;
	}

	public void setNationality(Type nationality) {
		this.nationality = nationality;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Type getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(Type highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public Set<TaStakeholder> getTaStakeholders() {
		return taStakeholders;
	}

	public void setTaStakeholders(Set<TaStakeholder> taStakeholders) {
		this.taStakeholders = taStakeholders;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean getIsCompany() {
		return isCompany;
	}

	public String getOtherDesignation() {
		return otherDesignation;
	}

	public void setOtherDesignation(String otherDesignation) {
		this.otherDesignation = otherDesignation;
	}

	public Type getDesignation() {
		return designation;
	}

	public void setDesignation(Type designation) {
		this.designation = designation;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	public String getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public String getResidentialNo() {
		return residentialNo;
	}

	public void setResidentialNo(String residentialNo) {
		this.residentialNo = residentialNo;
	}

}
