package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaAaSubmission extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@OneToOne
	private TaFilingCondition taAnnualFiling;

	// Profit loss statment fields
	private BigDecimal revenue;

	private BigDecimal otherIncome;

	private BigDecimal grossProfitLoss;

	private BigDecimal netProfitLoss;

	private BigDecimal dividendsPaid;

	// Balance sheet: Assets
	private BigDecimal bankBalance;

	private BigDecimal cashCashEquiv;

	private BigDecimal tradeReceivables;

	private BigDecimal tradeSecurities;

	private BigDecimal amtOwnByDir; // TODO: should be amtOwedByDir

	private BigDecimal nonCurrentAssets;

	private BigDecimal currentAssets;

	private BigDecimal totalAssets;

	// Balance sheet: Equity
	private BigDecimal capital;

	private BigDecimal accProfitLoss;

	private BigDecimal totalEquity;

	// Balance sheet: Liabilities
	private BigDecimal nonCurrentLiabilities;

	private BigDecimal currentLiabilities;

	private BigDecimal totalLiabilities;

	// Financial Ratio
	private BigDecimal netProfitMargin;

	private BigDecimal quickRatio;

	private BigDecimal debtEquityRatio;

	private BigDecimal profitScRatio;

	private Boolean isNetProfitMarginRed;

	private Boolean isQuickRatioRed;

	private Boolean isDebtEquityRatioRed;

	private Boolean isProfitScRatioRed;

	private Integer noOfReds;

	// Net Value
	private BigDecimal netValue;

	// Shortfall Value
	private BigDecimal shortfall;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type auditorOpinion;

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement auditorInfringement;

	// Current ratio: current assets / current liabilities

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public BigDecimal getRevenue() {
		return revenue;
	}

	public void setRevenue(BigDecimal revenue) {
		this.revenue = revenue;
	}

	public BigDecimal getOtherIncome() {
		return otherIncome;
	}

	public void setOtherIncome(BigDecimal otherIncome) {
		this.otherIncome = otherIncome;
	}

	public BigDecimal getGrossProfitLoss() {
		return grossProfitLoss;
	}

	public void setGrossProfitLoss(BigDecimal grossProfitLoss) {
		this.grossProfitLoss = grossProfitLoss;
	}

	public BigDecimal getNetProfitLoss() {
		return netProfitLoss;
	}

	public void setNetProfitLoss(BigDecimal netProfitLoss) {
		this.netProfitLoss = netProfitLoss;
	}

	public BigDecimal getDividendsPaid() {
		return dividendsPaid;
	}

	public void setDividendsPaid(BigDecimal dividendsPaid) {
		this.dividendsPaid = dividendsPaid;
	}

	public BigDecimal getBankBalance() {
		return bankBalance;
	}

	public void setBankBalance(BigDecimal bankBalance) {
		this.bankBalance = bankBalance;
	}

	public BigDecimal getCashCashEquiv() {
		return cashCashEquiv;
	}

	public void setCashCashEquiv(BigDecimal cashCashEquiv) {
		this.cashCashEquiv = cashCashEquiv;
	}

	public BigDecimal getTradeReceivables() {
		return tradeReceivables;
	}

	public void setTradeReceivables(BigDecimal tradeReceivables) {
		this.tradeReceivables = tradeReceivables;
	}

	public BigDecimal getTradeSecurities() {
		return tradeSecurities;
	}

	public void setTradeSecurities(BigDecimal tradeSecurities) {
		this.tradeSecurities = tradeSecurities;
	}

	public BigDecimal getAmtOwnByDir() {
		return amtOwnByDir;
	}

	public void setAmtOwnByDir(BigDecimal amtOwnByDir) {
		this.amtOwnByDir = amtOwnByDir;
	}

	public BigDecimal getNonCurrentAssets() {
		return nonCurrentAssets;
	}

	public void setNonCurrentAssets(BigDecimal nonCurrentAssets) {
		this.nonCurrentAssets = nonCurrentAssets;
	}

	public BigDecimal getCurrentAssets() {
		return currentAssets;
	}

	public void setCurrentAssets(BigDecimal currentAssets) {
		this.currentAssets = currentAssets;
	}

	public BigDecimal getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(BigDecimal totalAssets) {
		this.totalAssets = totalAssets;
	}

	public BigDecimal getCapital() {
		return capital;
	}

	public void setCapital(BigDecimal capital) {
		this.capital = capital;
	}

	public BigDecimal getAccProfitLoss() {
		return accProfitLoss;
	}

	public void setAccProfitLoss(BigDecimal accProfitLoss) {
		this.accProfitLoss = accProfitLoss;
	}

	public BigDecimal getTotalEquity() {
		return totalEquity;
	}

	public void setTotalEquity(BigDecimal totalEquity) {
		this.totalEquity = totalEquity;
	}

	public BigDecimal getNonCurrentLiabilities() {
		return nonCurrentLiabilities;
	}

	public void setNonCurrentLiabilities(BigDecimal nonCurrentLiabilities) {
		this.nonCurrentLiabilities = nonCurrentLiabilities;
	}

	public BigDecimal getCurrentLiabilities() {
		return currentLiabilities;
	}

	public void setCurrentLiabilities(BigDecimal currentLiabilities) {
		this.currentLiabilities = currentLiabilities;
	}

	public BigDecimal getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(BigDecimal totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public BigDecimal getNetProfitMargin() {
		return netProfitMargin;
	}

	public void setNetProfitMargin(BigDecimal netProfitMargin) {
		this.netProfitMargin = netProfitMargin;
	}

	public BigDecimal getQuickRatio() {
		return quickRatio;
	}

	public void setQuickRatio(BigDecimal quickRatio) {
		this.quickRatio = quickRatio;
	}

	public BigDecimal getDebtEquityRatio() {
		return debtEquityRatio;
	}

	public void setDebtEquityRatio(BigDecimal debtEquityRatio) {
		this.debtEquityRatio = debtEquityRatio;
	}

	public BigDecimal getProfitScRatio() {
		return profitScRatio;
	}

	public void setProfitScRatio(BigDecimal profitScRatio) {
		this.profitScRatio = profitScRatio;
	}

	public Boolean isNetProfitMarginRed() {
		return isNetProfitMarginRed;
	}

	public void setIsNetProfitMarginRed(Boolean isNetProfitMarginRed) {
		this.isNetProfitMarginRed = isNetProfitMarginRed;
	}

	public Boolean isQuickRatioRed() {
		return isQuickRatioRed;
	}

	public void setIsQuickRatioRed(Boolean isQuickRatioRed) {
		this.isQuickRatioRed = isQuickRatioRed;
	}

	public Boolean isDebtEquityRatioRed() {
		return isDebtEquityRatioRed;
	}

	public void setIsDebtEquityRatioRed(Boolean isDebtEquityRatioRed) {
		this.isDebtEquityRatioRed = isDebtEquityRatioRed;
	}

	public Boolean isProfitScRatioRed() {
		return isProfitScRatioRed;
	}

	public void setIsProfitScRatioRed(Boolean isProfitScRatioRed) {
		this.isProfitScRatioRed = isProfitScRatioRed;
	}

	public Integer getNoOfReds() {
		return noOfReds;
	}

	public void setNoOfReds(Integer noOfReds) {
		this.noOfReds = noOfReds;
	}

	public BigDecimal getNetValue() {
		return netValue;
	}

	public void setNetValue(BigDecimal netValue) {
		this.netValue = netValue;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

	public Type getAuditorOpinion() {
		return auditorOpinion;
	}

	public void setAuditorOpinion(Type auditorOpinion) {
		this.auditorOpinion = auditorOpinion;
	}

	public TaFilingCondition getTaAnnualFiling() {
		return taAnnualFiling;
	}

	public void setTaAnnualFiling(TaFilingCondition taAnnualFiling) {
		this.taAnnualFiling = taAnnualFiling;
	}

	public CeCaseInfringement getAuditorInfringement() {
		return auditorInfringement;
	}

	public void setAuditorInfringement(CeCaseInfringement auditorInfringement) {
		this.auditorInfringement = auditorInfringement;
	}

}
