package gov.stb.tag.model;

import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaAbprSubmission extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@OneToOne
	private TaFilingCondition taAnnualFiling;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isNilSubmission;

	private BigDecimal inboundOp;

	private BigDecimal inboundOpPercent;

	private BigDecimal outboundOp;

	private BigDecimal outboundOpPercent;

	private Integer inboundGrpPax;

	private BigDecimal inboundGrpPaxPercent;

	private Integer outboundGrpPax;

	private BigDecimal outboundGrpPaxPercent;

	private Integer inboundFitPax;

	private BigDecimal inboundFitPaxPercent;

	private Integer outboundFitPax;

	private BigDecimal outboundFitPaxPercent;

	private Integer noOfEmployee;

	private BigDecimal operatingCost;

	private BigDecimal depreciation;

	private BigDecimal remuneration;

	private BigDecimal indirectTax;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasOverseasBranch;

	@OneToMany(mappedBy = "taAbprSubmission")
	private Set<TaFunctionActivity> taFunctionActivities;

	@OneToMany(mappedBy = "taAbprSubmission")
	private Set<TaSpecializedMarket> taSpecializedMarkets;

	@OneToMany(mappedBy = "taAbprSubmission")
	private Set<TaBusinessOperation> taBusinessOperations;

	@OneToMany(mappedBy = "taAbprSubmission")
	private Set<TaFocusArea> taFocusAreas;

	private String trustId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public TaFilingCondition getTaAnnualFiling() {
		return taAnnualFiling;
	}

	public void setTaAnnualFiling(TaFilingCondition taAnnualFiling) {
		this.taAnnualFiling = taAnnualFiling;
	}

	public BigDecimal getInboundOp() {
		return inboundOp;
	}

	public void setInboundOp(BigDecimal inboundOp) {
		this.inboundOp = inboundOp;
	}

	public BigDecimal getInboundOpPercent() {
		return inboundOpPercent;
	}

	public void setInboundOpPercent(BigDecimal inboundOpPercent) {
		this.inboundOpPercent = inboundOpPercent;
	}

	public BigDecimal getOutboundOp() {
		return outboundOp;
	}

	public void setOutboundOp(BigDecimal outboundOp) {
		this.outboundOp = outboundOp;
	}

	public BigDecimal getOutboundOpPercent() {
		return outboundOpPercent;
	}

	public void setOutboundOpPercent(BigDecimal outboundOpPercent) {
		this.outboundOpPercent = outboundOpPercent;
	}

	public Integer getInboundGrpPax() {
		return inboundGrpPax;
	}

	public void setInboundGrpPax(Integer inboundGrpPax) {
		this.inboundGrpPax = inboundGrpPax;
	}

	public BigDecimal getInboundGrpPaxPercent() {
		return inboundGrpPaxPercent;
	}

	public void setInboundGrpPaxPercent(BigDecimal inboundGrpPaxPercent) {
		this.inboundGrpPaxPercent = inboundGrpPaxPercent;
	}

	public Integer getOutboundGrpPax() {
		return outboundGrpPax;
	}

	public void setOutboundGrpPax(Integer outboundGrpPax) {
		this.outboundGrpPax = outboundGrpPax;
	}

	public BigDecimal getOutboundGrpPaxPercent() {
		return outboundGrpPaxPercent;
	}

	public void setOutboundGrpPaxPercent(BigDecimal outboundGrpPaxPercent) {
		this.outboundGrpPaxPercent = outboundGrpPaxPercent;
	}

	public Integer getInboundFitPax() {
		return inboundFitPax;
	}

	public void setInboundFitPax(Integer inboundFitPax) {
		this.inboundFitPax = inboundFitPax;
	}

	public BigDecimal getInboundFitPaxPercent() {
		return inboundFitPaxPercent;
	}

	public void setInboundFitPaxPercent(BigDecimal inboundFitPaxPercent) {
		this.inboundFitPaxPercent = inboundFitPaxPercent;
	}

	public Integer getOutboundFitPax() {
		return outboundFitPax;
	}

	public void setOutboundFitPax(Integer outboundFitPax) {
		this.outboundFitPax = outboundFitPax;
	}

	public BigDecimal getOutboundFitPaxPercent() {
		return outboundFitPaxPercent;
	}

	public void setOutboundFitPaxPercent(BigDecimal outboundFitPaxPercent) {
		this.outboundFitPaxPercent = outboundFitPaxPercent;
	}

	public Integer getNoOfEmployee() {
		return noOfEmployee;
	}

	public void setNoOfEmployee(Integer noOfEmployee) {
		this.noOfEmployee = noOfEmployee;
	}

	public BigDecimal getOperatingCost() {
		return operatingCost;
	}

	public void setOperatingCost(BigDecimal operatingCost) {
		this.operatingCost = operatingCost;
	}

	public BigDecimal getDepreciation() {
		return depreciation;
	}

	public void setDepreciation(BigDecimal depreciation) {
		this.depreciation = depreciation;
	}

	public BigDecimal getRemuneration() {
		return remuneration;
	}

	public void setRemuneration(BigDecimal remuneration) {
		this.remuneration = remuneration;
	}

	public BigDecimal getIndirectTax() {
		return indirectTax;
	}

	public void setIndirectTax(BigDecimal indirectTax) {
		this.indirectTax = indirectTax;
	}

	public Boolean hasOverseasBranch() {
		return hasOverseasBranch;
	}

	public void setHasOverseasBranch(Boolean hasOverseasBranch) {
		this.hasOverseasBranch = hasOverseasBranch;
	}

	public Set<TaFunctionActivity> getTaFunctionActivities() {
		return taFunctionActivities;
	}

	public void setTaFunctionActivities(Set<TaFunctionActivity> taFunctionActivities) {
		this.taFunctionActivities = taFunctionActivities;
	}

	public Set<TaSpecializedMarket> getTaSpecializedMarkets() {
		return taSpecializedMarkets;
	}

	public void setTaSpecializedMarkets(Set<TaSpecializedMarket> taSpecializedMarkets) {
		this.taSpecializedMarkets = taSpecializedMarkets;
	}

	public Set<TaBusinessOperation> getTaBusinessOperations() {
		return taBusinessOperations;
	}

	public void setTaBusinessOperations(Set<TaBusinessOperation> taBusinessOperations) {
		this.taBusinessOperations = taBusinessOperations;
	}

	public Set<TaFocusArea> getTaFocusAreas() {
		return taFocusAreas;
	}

	public void setTaFocusAreas(Set<TaFocusArea> taFocusAreas) {
		this.taFocusAreas = taFocusAreas;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	public Boolean getIsNilSubmission() {
		return isNilSubmission;
	}

	public void setIsNilSubmission(Boolean isNilSubmission) {
		this.isNilSubmission = isNilSubmission;
	}

}
