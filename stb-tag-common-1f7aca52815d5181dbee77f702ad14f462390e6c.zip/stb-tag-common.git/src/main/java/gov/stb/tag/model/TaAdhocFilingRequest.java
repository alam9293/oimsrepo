package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaAdhocFilingRequest extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type reqType; // TA_REQ_ADHOC_DOCS, TA_REQ_ADHOC_MA

	@OneToOne
	private TaFilingCondition taFiling; // create filling condition only when request is approved

	@OneToOne
	private Workflow workflow;

	private LocalDate dueDate; // STB officer key in due date of submission

	@Column(length = 5000)
	private String requestRemarks; // STB officer key in description for the document requested

	private LocalDate requestedAsAtDate; // STB officer key in requested as at date for MA. Snapshot to filing condition when approved

	private Integer fy; // STB officer key in

	@Override
	public Integer getId() {
		return id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public String getRequestRemarks() {
		return requestRemarks;
	}

	public void setRequestRemarks(String requestRemarks) {
		this.requestRemarks = requestRemarks;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getReqType() {
		return reqType;
	}

	public void setReqType(Type reqType) {
		this.reqType = reqType;
	}

	public TaFilingCondition getTaFiling() {
		return taFiling;
	}

	public void setTaFiling(TaFilingCondition taFiling) {
		this.taFiling = taFiling;
	}

	public LocalDate getRequestedAsAtDate() {
		return requestedAsAtDate;
	}

	public void setRequestedAsAtDate(LocalDate requestedAsAtDate) {
		this.requestedAsAtDate = requestedAsAtDate;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

}
