package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaBranch extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence; // main licence

	@OneToOne(fetch = FetchType.LAZY)
	private File tenancyDoc;

	private String trustId;

	private LocalDate issueDate; // branch licence issue date

	private LocalDate ceasedDate; // branch licence ceased date

	@Column(length = 5000)
	private String ceasedReason;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheck lastTaCheck;

	private Boolean isLastCheckDone;

	@Column(columnDefinition = "INT(11) default 0")
	private Integer isDownloadable; // flag for e-license download request

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public File getTenancyDoc() {
		return tenancyDoc;
	}

	public void setTenancyDoc(File tenancyDoc) {
		this.tenancyDoc = tenancyDoc;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getCeasedDate() {
		return ceasedDate;
	}

	public void setCeasedDate(LocalDate ceasedDate) {
		this.ceasedDate = ceasedDate;
	}

	public String getCeasedReason() {
		return ceasedReason;
	}

	public void setCeasedReason(String ceasedReason) {
		this.ceasedReason = ceasedReason;
	}

	public CeTaCheck getLastTaCheck() {
		return lastTaCheck;
	}

	public void setLastTaCheck(CeTaCheck lastTaCheck) {
		this.lastTaCheck = lastTaCheck;
	}

	public Boolean getIsLastCheckDone() {
		return isLastCheckDone;
	}

	public void setIsLastCheckDone(Boolean isLastCheckDone) {
		this.isLastCheckDone = isLastCheckDone;
	}

	public Integer getIsDownloadable() {
		return isDownloadable;
	}

	public void setIsDownloadable(Integer isDownloadable) {
		this.isDownloadable = isDownloadable;
	}

}
