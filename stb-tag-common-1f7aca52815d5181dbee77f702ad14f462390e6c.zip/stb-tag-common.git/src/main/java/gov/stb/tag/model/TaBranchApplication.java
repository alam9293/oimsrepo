package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaBranchApplication extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaBranchApplicationBatch taBranchApplicationBatch;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaBranch taBranch;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status; // processing, rfa, rejected, deleted

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // new, update, cease

	@OneToOne(fetch = FetchType.LAZY)
	private File tenancyDoc;

	private LocalDate tenancyStartDate;

	private LocalDate tenancyEndDate;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TaBranchApplicationBatch getTaBranchApplicationBatch() {
		return taBranchApplicationBatch;
	}

	public void setTaBranchApplicationBatch(TaBranchApplicationBatch taBranchApplicationBatch) {
		this.taBranchApplicationBatch = taBranchApplicationBatch;
	}

	public TaBranch getTaBranch() {
		return taBranch;
	}

	public void setTaBranch(TaBranch taBranch) {
		this.taBranch = taBranch;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public File getTenancyDoc() {
		return tenancyDoc;
	}

	public void setTenancyDoc(File tenancyDoc) {
		this.tenancyDoc = tenancyDoc;
	}

	public LocalDate getTenancyStartDate() {
		return tenancyStartDate;
	}

	public void setTenancyStartDate(LocalDate tenancyStartDate) {
		this.tenancyStartDate = tenancyStartDate;
	}

	public LocalDate getTenancyEndDate() {
		return tenancyEndDate;
	}

	public void setTenancyEndDate(LocalDate tenancyEndDate) {
		this.tenancyEndDate = tenancyEndDate;
	}
}
