package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaBranchApplicationBatch extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@OneToMany(mappedBy = "taBranchApplicationBatch")
	private Set<TaBranchApplication> taBranchApplications;

	private String appFeeBillRefNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isConcluded;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Set<TaBranchApplication> getTaBranchApplications() {
		return taBranchApplications;
	}

	public void setTaBranchApplications(Set<TaBranchApplication> taBranchApplications) {
		this.taBranchApplications = taBranchApplications;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public Boolean getIsConcluded() {
		return isConcluded;
	}

	public void setIsConcluded(Boolean isConcluded) {
		this.isConcluded = isConcluded;
	}

}
