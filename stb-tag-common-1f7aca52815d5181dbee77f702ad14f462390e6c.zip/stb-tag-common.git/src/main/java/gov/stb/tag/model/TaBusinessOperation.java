package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaBusinessOperation extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type service;

	private BigDecimal inbound;

	private BigDecimal inboundPercent;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isInboundOwned;

	private BigDecimal outbound;

	private BigDecimal outboundPercent;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isOutboundOwned;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceCreation taLicenceCreation;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaAbprSubmission taAbprSubmission;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceTierSwitch taLicenceTierSwitch;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceTierSwitch newTaLicenceTierSwitch;

	private String trustId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getService() {
		return service;
	}

	public void setService(Type service) {
		this.service = service;
	}

	public BigDecimal getInbound() {
		return inbound;
	}

	public void setInbound(BigDecimal inbound) {
		this.inbound = inbound;
	}

	public BigDecimal getInboundPercent() {
		return inboundPercent;
	}

	public void setInboundPercent(BigDecimal inboundPercent) {
		this.inboundPercent = inboundPercent;
	}

	public Boolean isInboundOwned() {
		return isInboundOwned;
	}

	public void setIsInboundOwned(Boolean isInboundOwned) {
		this.isInboundOwned = isInboundOwned;
	}

	public BigDecimal getOutbound() {
		return outbound;
	}

	public void setOutbound(BigDecimal outbound) {
		this.outbound = outbound;
	}

	public BigDecimal getOutboundPercent() {
		return outboundPercent;
	}

	public void setOutboundPercent(BigDecimal outboundPercent) {
		this.outboundPercent = outboundPercent;
	}

	public Boolean isOutboundOwned() {
		return isOutboundOwned;
	}

	public void setIsOutboundOwned(Boolean isOutboundOwned) {
		this.isOutboundOwned = isOutboundOwned;
	}

	public TaLicenceCreation getTaLicenceCreation() {
		return taLicenceCreation;
	}

	public void setTaLicenceCreation(TaLicenceCreation taLicenceCreation) {
		this.taLicenceCreation = taLicenceCreation;
	}

	public TaAbprSubmission getTaAbprSubmission() {
		return taAbprSubmission;
	}

	public void setTaAbprSubmission(TaAbprSubmission taAbprSubmission) {
		this.taAbprSubmission = taAbprSubmission;
	}

	public TaLicenceTierSwitch getTaLicenceTierSwitch() {
		return taLicenceTierSwitch;
	}

	public void setTaLicenceTierSwitch(TaLicenceTierSwitch taLicenceTierSwitch) {
		this.taLicenceTierSwitch = taLicenceTierSwitch;
	}

	public Boolean getIsInboundOwned() {
		return isInboundOwned;
	}

	public Boolean getIsOutboundOwned() {
		return isOutboundOwned;
	}

	public TaLicenceTierSwitch getNewTaLicenceTierSwitch() {
		return newTaLicenceTierSwitch;
	}

	public void setNewTaLicenceTierSwitch(TaLicenceTierSwitch newTaLicenceTierSwitch) {
		this.newTaLicenceTierSwitch = newTaLicenceTierSwitch;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

}
