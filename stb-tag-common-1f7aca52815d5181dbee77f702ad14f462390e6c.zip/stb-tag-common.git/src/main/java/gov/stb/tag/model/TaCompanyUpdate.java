package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaCompanyUpdate extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@OneToOne
	private TaCompanyUpdate previousValue; // snapshot of the current values

	private String companyName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type formOfBusiness;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type businessConstitution;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type taSegmentation;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type principleActivities;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type secondaryPrincipleActivities;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type placeIncorporated;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type establishmentStatus;

	private BigDecimal paidUpCapital;

	private String websiteUrl;

	@Column(length = 320)
	private String emailAddress;

	private String contactNo; // not in FS?

	private String faxNo;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address registeredAddress;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address operatingAddress;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isEdhPopulated;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public TaCompanyUpdate getPreviousValue() {
		return previousValue;
	}

	public void setPreviousValue(TaCompanyUpdate previousValue) {
		this.previousValue = previousValue;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Type getFormOfBusiness() {
		return formOfBusiness;
	}

	public void setFormOfBusiness(Type formOfBusiness) {
		this.formOfBusiness = formOfBusiness;
	}

	public Type getBusinessConstitution() {
		return businessConstitution;
	}

	public void setBusinessConstitution(Type businessConstitution) {
		this.businessConstitution = businessConstitution;
	}

	public Type getTaSegmentation() {
		return taSegmentation;
	}

	public void setTaSegmentation(Type taSegmentation) {
		this.taSegmentation = taSegmentation;
	}

	public Type getPrincipleActivities() {
		return principleActivities;
	}

	public void setPrincipleActivities(Type principleActivities) {
		this.principleActivities = principleActivities;
	}

	public Type getSecondaryPrincipleActivities() {
		return secondaryPrincipleActivities;
	}

	public void setSecondaryPrincipleActivities(Type secondaryPrincipleActivities) {
		this.secondaryPrincipleActivities = secondaryPrincipleActivities;
	}

	public Type getPlaceIncorporated() {
		return placeIncorporated;
	}

	public void setPlaceIncorporated(Type placeIncorporated) {
		this.placeIncorporated = placeIncorporated;
	}

	public Type getEstablishmentStatus() {
		return establishmentStatus;
	}

	public void setEstablishmentStatus(Type establishmentStatus) {
		this.establishmentStatus = establishmentStatus;
	}

	public BigDecimal getPaidUpCapital() {
		return paidUpCapital;
	}

	public void setPaidUpCapital(BigDecimal paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Address getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(Address registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public Address getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(Address operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public Boolean getIsEdhPopulated() {
		return isEdhPopulated;
	}

	public void setIsEdhPopulated(Boolean isEdhPopulated) {
		this.isEdhPopulated = isEdhPopulated;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

}
