package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaCpfArrear extends AuditableIdEntity {

	private Integer id;

	private String name;

	private String uen;

	private LocalDate responseDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasCpfArrear;

	@ManyToOne(fetch = FetchType.LAZY)
	private TravelAgent travelAgent;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TravelAgent getTravelAgent() {
		return travelAgent;
	}

	public void setTravelAgent(TravelAgent travelAgent) {
		this.travelAgent = travelAgent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public LocalDate getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(LocalDate responseDate) {
		this.responseDate = responseDate;
	}

	public Boolean isHasCpfArrear() {
		return hasCpfArrear;
	}

	public void setHasCpfArrear(Boolean hasCpfArrear) {
		this.hasCpfArrear = hasCpfArrear;
	}

}
