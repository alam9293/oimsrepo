package gov.stb.tag.model;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaELicenceRequest extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	private String reason;

	@Override
	public Integer getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public void setId(Integer id) {
		this.id = id;
	}
}
