package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

/**
 * TaFilingConditions are used to track TA's annual filing of AA and ABPR, which are created by batch job when a TA crosses its FYE, with due date default to 6 (configurable) months from FYE. When a
 * TA submit its AA, ABPR etc, system needs to link it to the respective FilingCondition record. Should we allow submission if this FilingCondition is not created (e.g. TA submit early)? If yes,
 * system should create this on-the-fly. User should be able to view in the TA licence record the list of filing over the years.
 * 
 * TaFilingConditions are created during TA Renewal Exercise if MA is required (in P1B). They can also be created on an ad-hoc basis via a management module (in P2) to request MA or any other document
 * under Regulation 14.
 */
@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFilingCondition extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type applicationType; // TA_APP_AA_SUBMISSION, TA_APP_ABPR_SUBMISSION, TA_APP_MA_SUBMISSION, TA_APP_ADHOC_DOC_SUBMISSION, or TA_APP_ADHOC_MA_SUBMISSION

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status; // see STAT_TA_FILING

	private Integer fy;

	private LocalDate fyStartDate; // Upon creation, this is the previous fy TaAnnualFiling's fyEndDate.

	private LocalDate fyEndDate; // Upon creation, this is the current FYE. It can result to >12 mths (FYE update to future date) or <12 mths (FYE update to past date; system need to find/update this)

	private LocalDate requestedAsAtDate;

	private LocalDate dueDate;

	@Column(length = 5000)
	private String remarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private Application rectifiedApplication;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingConditionExtension lastExtension;

	@OneToMany(mappedBy = "taFilingCondition")
	private Set<TaFilingConditionExtension> taFilingConditionExtensions;

	@OneToMany(mappedBy = "taAnnualFiling")
	private Set<TaAaSubmission> taAaSubmission;

	@OneToMany(mappedBy = "taAnnualFiling")
	private Set<TaAbprSubmission> taAbprSubmission;

	@OneToMany(mappedBy = "taFilingCondition")
	private Set<TaMaSubmission> taMaSubmission;

	@OneToMany(mappedBy = "taFilingCondition")
	private Set<TaFilingConditionEmailLog> taFilingConditionEmailLogs;

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement tarR141Infringement;

	@Transient
	private LocalDate fyDueDate; // for TA Filing Condition Reminder - Stipulated / Extended Due Date

	@Transient
	private LocalDate reminderSentDate; // for TA Filing Condition Reminder

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(Type applicationType) {
		this.applicationType = applicationType;
	}

	public Integer getFy() {
		return fy;
	}

	public void setFy(Integer fy) {
		this.fy = fy;
	}

	public LocalDate getFyStartDate() {
		return fyStartDate;
	}

	public void setFyStartDate(LocalDate fyStartDate) {
		this.fyStartDate = fyStartDate;
	}

	public LocalDate getFyEndDate() {
		return fyEndDate;
	}

	public void setFyEndDate(LocalDate fyEndDate) {
		this.fyEndDate = fyEndDate;
	}

	public LocalDate getRequestedAsAtDate() {
		return requestedAsAtDate;
	}

	public void setRequestedAsAtDate(LocalDate requestedAsAtDate) {
		this.requestedAsAtDate = requestedAsAtDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public TaFilingConditionExtension getLastExtension() {
		return lastExtension;
	}

	public void setLastExtension(TaFilingConditionExtension lastExtension) {
		this.lastExtension = lastExtension;
	}

	public Set<TaFilingConditionExtension> getTaFilingConditionExtensions() {
		return taFilingConditionExtensions;
	}

	public void setTaFilingConditionExtensions(Set<TaFilingConditionExtension> taFilingConditionExtensions) {
		this.taFilingConditionExtensions = taFilingConditionExtensions;
	}

	public Set<TaAaSubmission> getTaAaSubmission() {
		return taAaSubmission;
	}

	public void setTaAaSubmission(Set<TaAaSubmission> taAaSubmission) {
		this.taAaSubmission = taAaSubmission;
	}

	public Set<TaAbprSubmission> getTaAbprSubmission() {
		return taAbprSubmission;
	}

	public void setTaAbprSubmission(Set<TaAbprSubmission> taAbprSubmission) {
		this.taAbprSubmission = taAbprSubmission;
	}

	public Set<TaMaSubmission> getTaMaSubmission() {
		return taMaSubmission;
	}

	public void setTaMaSubmission(Set<TaMaSubmission> taMaSubmission) {
		this.taMaSubmission = taMaSubmission;
	}

	public Set<TaFilingConditionEmailLog> getTaFilingConditionEmailLogs() {
		return taFilingConditionEmailLogs;
	}

	public void setTaFilingConditionEmailLogs(Set<TaFilingConditionEmailLog> taFilingConditionEmailLogs) {
		this.taFilingConditionEmailLogs = taFilingConditionEmailLogs;
	}

	public LocalDate getFyDueDate() {
		return fyDueDate;
	}

	public void setFyDueDate(LocalDate fyDueDate) {
		this.fyDueDate = fyDueDate;
	}

	public Application getRectifiedApplication() {
		return rectifiedApplication;
	}

	public void setRectifiedApplication(Application rectifiedApplication) {
		this.rectifiedApplication = rectifiedApplication;
	}

	public LocalDate getReminderSentDate() {
		return reminderSentDate;
	}

	public void setReminderSentDate(LocalDate reminderSentDate) {
		this.reminderSentDate = reminderSentDate;
	}

	public CeCaseInfringement getTarR141Infringement() {
		return tarR141Infringement;
	}

	public void setTarR141Infringement(CeCaseInfringement tarR141Infringement) {
		this.tarR141Infringement = tarR141Infringement;
	}

}
