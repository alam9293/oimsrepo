package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFilingConditionAmendment extends AuditableIdEntity {

	private Integer id;

	@OneToMany(mappedBy = "taFilingConditionAmendment")
	private Set<TaFilingConditionExtension> taFilingConditionExtensions;

	@OneToOne
	private Workflow workflow;

	@Column(length = 5000)
	private String remarks;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Set<TaFilingConditionExtension> getTaFilingConditionExtensions() {
		return taFilingConditionExtensions;
	}

	public void setTaFilingConditionExtensions(Set<TaFilingConditionExtension> taFilingConditionExtensions) {
		this.taFilingConditionExtensions = taFilingConditionExtensions;
	}

}
