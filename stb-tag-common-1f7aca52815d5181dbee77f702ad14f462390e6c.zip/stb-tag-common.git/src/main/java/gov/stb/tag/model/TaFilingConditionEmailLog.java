package gov.stb.tag.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFilingConditionEmailLog extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition taFilingCondition;

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailLog emailLog;

	@ManyToOne(fetch = FetchType.LAZY)
	private EmailTemplate emailTemplate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	private Integer forMonth;

	private Integer forYear;

	private LocalDateTime sendDate;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TaFilingCondition getTaFilingCondition() {
		return taFilingCondition;
	}

	public void setTaFilingCondition(TaFilingCondition taFilingCondition) {
		this.taFilingCondition = taFilingCondition;
	}

	public EmailLog getEmailLog() {
		return emailLog;
	}

	public void setEmailLog(EmailLog emailLog) {
		this.emailLog = emailLog;
	}

	public EmailTemplate getEmailTemplate() {
		return emailTemplate;
	}

	public void setEmailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Integer getForMonth() {
		return forMonth;
	}

	public void setForMonth(Integer forMonth) {
		this.forMonth = forMonth;
	}

	public Integer getForYear() {
		return forYear;
	}

	public void setForYear(Integer forYear) {
		this.forYear = forYear;
	}

	public LocalDateTime getSendDate() {
		return sendDate;
	}

	public void setSendDate(LocalDateTime sendDate) {
		this.sendDate = sendDate;
	}

}
