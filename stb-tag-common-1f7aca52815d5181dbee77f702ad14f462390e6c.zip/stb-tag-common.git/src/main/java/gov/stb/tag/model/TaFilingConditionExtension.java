package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFilingConditionExtension extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition taFilingCondition;

	private LocalDate extendedDueDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 1")
	private Boolean toProceed; // true: agreeable to proceed with the extension/amend upon workflow status approved. false: not agreeable to proceed with the extension/amend even if workflow status
								// approved

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingConditionExtensionAssessment taFilingConditionExtensionAssessment;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingConditionAmendment taFilingConditionAmendment;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type ammendmentType; // FILING_EXTEND, FILING_CANCEL

	@Column(length = 5000)
	private String remarks;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TaFilingCondition getTaFilingCondition() {
		return taFilingCondition;
	}

	public void setTaFilingCondition(TaFilingCondition taFilingCondition) {
		this.taFilingCondition = taFilingCondition;
	}

	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

	public Boolean getToProceed() {
		return toProceed;
	}

	public void setToProceed(Boolean toProceed) {
		this.toProceed = toProceed;
	}

	public TaFilingConditionExtensionAssessment getTaFilingConditionExtensionAssessment() {
		return taFilingConditionExtensionAssessment;
	}

	public void setTaFilingConditionExtensionAssessment(TaFilingConditionExtensionAssessment taFilingConditionExtensionAssessment) {
		this.taFilingConditionExtensionAssessment = taFilingConditionExtensionAssessment;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public TaFilingConditionAmendment getTaFilingConditionAmendment() {
		return taFilingConditionAmendment;
	}

	public void setTaFilingConditionAmendment(TaFilingConditionAmendment taFilingConditionAmendment) {
		this.taFilingConditionAmendment = taFilingConditionAmendment;
	}

	public Type getAmmendmentType() {
		return ammendmentType;
	}

	public void setAmmendmentType(Type ammendmentType) {
		this.ammendmentType = ammendmentType;
	}

}
