package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFilingConditionExtensionAssessment extends AuditableIdEntity {

	private Integer id;

	@OneToMany(mappedBy = "taFilingConditionExtensionAssessment")
	private Set<TaFilingConditionExtension> taFilingConditionExtensions;

	@OneToOne
	private Workflow workflow;

	@Column(length = 5000)
	private String reason;

	@Lob
	private String riskAssessment;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaAaSubmission assessedAa; // to derive sales turnover, current ratio and amount owed by director

	@ManyToOne(fetch = FetchType.LAZY)
	private TaAaSubmission assessedAa2; // second last AA for calculation of consecutive losses

	@ManyToOne(fetch = FetchType.LAZY)
	private TaAbprSubmission assessedAbpr; // to derive inbound/outbound percentage

	@ManyToOne(fetch = FetchType.LAZY)
	private Type hasConsecutiveLosses;

	@Column(length = 1000)
	private String consecutiveLossesRemarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type hasShortfallExceeded;

	@Column(length = 1000)
	private String shortfallExceededLossesRemarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type isCurrentRatioLessThanOne;

	@Column(length = 1000)
	private String isCurrentRatioLessRemarks;

	@Column(length = 1000)
	private String inboundOutboundRisk; // default to e.g.: "{High}, based on ABPR{2018}, outbound is {70%}"

	@Column(length = 1000)
	private String salesTurnoverRisk; // default to e.g.: "{Low}, based on AA{2017}, sales turnover is {$108K}"

	@Column(length = 1000)
	private String amtOwedByDirRisk; // default to e.g.: "{High}, based on AA{2017}, amount owed by director is {$XX,XXX}"

	@Column(length = 1000)
	private String litigationSuitRisk; // only for manager and above (i.e. not Pending PO)

	@Column(length = 1000)
	private String cpfArrearsRisk; // only for manager and above (i.e. not Pending PO)

	@Column(length = 1000)
	private String nonDeliveryRisk; // only for manager and above (i.e. not Pending PO)

	@Lob
	private String managerAssessment; // only for manager and above (i.e. not Pending PO)

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRiskAssessment() {
		return riskAssessment;
	}

	public void setRiskAssessment(String riskAssessment) {
		this.riskAssessment = riskAssessment;
	}

	public TaAaSubmission getAssessedAa() {
		return assessedAa;
	}

	public void setAssessedAa(TaAaSubmission assessedAa) {
		this.assessedAa = assessedAa;
	}

	public TaAaSubmission getAssessedAa2() {
		return assessedAa2;
	}

	public void setAssessedAa2(TaAaSubmission assessedAa2) {
		this.assessedAa2 = assessedAa2;
	}

	public TaAbprSubmission getAssessedAbpr() {
		return assessedAbpr;
	}

	public void setAssessedAbpr(TaAbprSubmission assessedAbpr) {
		this.assessedAbpr = assessedAbpr;
	}

	public String getInboundOutboundRisk() {
		return inboundOutboundRisk;
	}

	public void setInboundOutboundRisk(String inboundOutboundRisk) {
		this.inboundOutboundRisk = inboundOutboundRisk;
	}

	public String getSalesTurnoverRisk() {
		return salesTurnoverRisk;
	}

	public void setSalesTurnoverRisk(String salesTurnoverRisk) {
		this.salesTurnoverRisk = salesTurnoverRisk;
	}

	public String getAmtOwedByDirRisk() {
		return amtOwedByDirRisk;
	}

	public void setAmtOwedByDirRisk(String amtOwedByDirRisk) {
		this.amtOwedByDirRisk = amtOwedByDirRisk;
	}

	public String getLitigationSuitRisk() {
		return litigationSuitRisk;
	}

	public void setLitigationSuitRisk(String litigationSuitRisk) {
		this.litigationSuitRisk = litigationSuitRisk;
	}

	public String getCpfArrearsRisk() {
		return cpfArrearsRisk;
	}

	public void setCpfArrearsRisk(String cpfArrearsRisk) {
		this.cpfArrearsRisk = cpfArrearsRisk;
	}

	public String getNonDeliveryRisk() {
		return nonDeliveryRisk;
	}

	public void setNonDeliveryRisk(String nonDeliveryRisk) {
		this.nonDeliveryRisk = nonDeliveryRisk;
	}

	public String getManagerAssessment() {
		return managerAssessment;
	}

	public void setManagerAssessment(String managerAssessment) {
		this.managerAssessment = managerAssessment;
	}

	public Type getHasConsecutiveLosses() {
		return hasConsecutiveLosses;
	}

	public void setHasConsecutiveLosses(Type hasConsecutiveLosses) {
		this.hasConsecutiveLosses = hasConsecutiveLosses;
	}

	public Type getHasShortfallExceeded() {
		return hasShortfallExceeded;
	}

	public void setHasShortfallExceeded(Type hasShortfallExceeded) {
		this.hasShortfallExceeded = hasShortfallExceeded;
	}

	public Type getIsCurrentRatioLessThanOne() {
		return isCurrentRatioLessThanOne;
	}

	public void setIsCurrentRatioLessThanOne(Type isCurrentRatioLessThanOne) {
		this.isCurrentRatioLessThanOne = isCurrentRatioLessThanOne;
	}

	public Set<TaFilingConditionExtension> getTaFilingConditionExtensions() {
		return taFilingConditionExtensions;
	}

	public void setTaFilingConditionExtensions(Set<TaFilingConditionExtension> taFilingConditionExtensions) {
		this.taFilingConditionExtensions = taFilingConditionExtensions;
	}

	public String getConsecutiveLossesRemarks() {
		return consecutiveLossesRemarks;
	}

	public void setConsecutiveLossesRemarks(String consecutiveLossesRemarks) {
		this.consecutiveLossesRemarks = consecutiveLossesRemarks;
	}

	public String getShortfallExceededLossesRemarks() {
		return shortfallExceededLossesRemarks;
	}

	public void setShortfallExceededLossesRemarks(String shortfallExceededLossesRemarks) {
		this.shortfallExceededLossesRemarks = shortfallExceededLossesRemarks;
	}

	public String getIsCurrentRatioLessRemarks() {
		return isCurrentRatioLessRemarks;
	}

	public void setIsCurrentRatioLessRemarks(String isCurrentRatioLessRemarks) {
		this.isCurrentRatioLessRemarks = isCurrentRatioLessRemarks;
	}

}
