package gov.stb.tag.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFocusArea extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type focusArea;

	private String otherFocusArea;

	private Boolean hasInboundOp; // nullable due to migrated data

	private Boolean hasOutboundOp; // nullable due to migrated data

	private Boolean hasOp; // nullable due to migrated data

	private String remarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceCreation taLicenceCreation;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaAbprSubmission taAbprSubmission;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getFocusArea() {
		return focusArea;
	}

	public void setFocusArea(Type focusArea) {
		this.focusArea = focusArea;
	}

	public String getOtherFocusArea() {
		return otherFocusArea;
	}

	public void setOtherFocusArea(String otherFocusArea) {
		this.otherFocusArea = otherFocusArea;
	}

	public Boolean hasInboundOp() {
		return hasInboundOp;
	}

	public void setHasInboundOp(Boolean hasInboundOp) {
		this.hasInboundOp = hasInboundOp;
	}

	public Boolean hasOutboundOp() {
		return hasOutboundOp;
	}

	public void setHasOutboundOp(Boolean hasOutboundOp) {
		this.hasOutboundOp = hasOutboundOp;
	}

	public Boolean getHasOp() {
		return hasOp;
	}

	public void setHasOp(Boolean hasOp) {
		this.hasOp = hasOp;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public TaLicenceCreation getTaLicenceCreation() {
		return taLicenceCreation;
	}

	public void setTaLicenceCreation(TaLicenceCreation taLicenceCreation) {
		this.taLicenceCreation = taLicenceCreation;
	}

	public TaAbprSubmission getTaAbprSubmission() {
		return taAbprSubmission;
	}

	public void setTaAbprSubmission(TaAbprSubmission taAbprSubmission) {
		this.taAbprSubmission = taAbprSubmission;
	}

	public Boolean getHasInboundOp() {
		return hasInboundOp;
	}

	public Boolean getHasOutboundOp() {
		return hasOutboundOp;
	}

}
