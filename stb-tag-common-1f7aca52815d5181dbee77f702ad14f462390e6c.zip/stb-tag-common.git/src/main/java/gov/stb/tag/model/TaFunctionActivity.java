package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFunctionActivity extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type question;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isInbound;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isOutbound;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaAbprSubmission taAbprSubmission;

	private String trustId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getQuestion() {
		return question;
	}

	public void setQuestion(Type question) {
		this.question = question;
	}

	public Boolean getIsInbound() {
		return isInbound;
	}

	public void setIsInbound(Boolean isInbound) {
		this.isInbound = isInbound;
	}

	public Boolean getIsOutbound() {
		return isOutbound;
	}

	public void setIsOutbound(Boolean isOutbound) {
		this.isOutbound = isOutbound;
	}

	public TaAbprSubmission getTaAbprSubmission() {
		return taAbprSubmission;
	}

	public void setTaAbprSubmission(TaAbprSubmission taAbprSubmission) {
		this.taAbprSubmission = taAbprSubmission;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

}
