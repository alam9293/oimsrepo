package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaFyUpdate extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	private LocalDate fyStartDate;

	private LocalDate oldFyeDate;

	private LocalDate newFyeDate;

	private String reason;

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement tarR13Infringement;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public LocalDate getFyStartDate() {
		return fyStartDate;
	}

	public void setFyStartDate(LocalDate fyStartDate) {
		this.fyStartDate = fyStartDate;
	}

	public LocalDate getOldFyeDate() {
		return oldFyeDate;
	}

	public void setOldFyeDate(LocalDate oldFyeDate) {
		this.oldFyeDate = oldFyeDate;
	}

	public LocalDate getNewFyeDate() {
		return newFyeDate;
	}

	public void setNewFyeDate(LocalDate newFyeDate) {
		this.newFyeDate = newFyeDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public CeCaseInfringement getTarR13Infringement() {
		return tarR13Infringement;
	}

	public void setTarR13Infringement(CeCaseInfringement tarR13Infringement) {
		this.tarR13Infringement = tarR13Infringement;
	}

}
