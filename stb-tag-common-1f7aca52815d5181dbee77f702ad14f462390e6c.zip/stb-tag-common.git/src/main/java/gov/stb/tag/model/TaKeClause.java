package gov.stb.tag.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaKeClause extends AuditableIdEntity {

	private Integer id;

	@Column(length = 700)
	private String clause;

	private String prefix;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isActive;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isRadioBtn;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isNotForRenewal;

	private Integer ordinal;

	private String options; // delimited

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isOptionsRequired; // options that must be selected to proceed further

	private String optionsToPrompt; // options that will prompt for remarks when selected

	private String prompt;

	@Column(length = 700)
	private String subscript;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getClause() {
		return clause;
	}

	public void setClause(String clause) {
		this.clause = clause;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public Boolean isActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean isRadioBtn() {
		return isRadioBtn;
	}

	public void setIsRadioBtn(Boolean isRadioBtn) {
		this.isRadioBtn = isRadioBtn;
	}

	public Boolean isNotForRenewal() {
		return isNotForRenewal;
	}

	public void setIsNotForRenewal(Boolean isNotForRenewal) {
		this.isNotForRenewal = isNotForRenewal;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public Boolean isOptionsRequired() {
		return isOptionsRequired;
	}

	public void setIsOptionsRequired(Boolean isOptionsRequired) {
		this.isOptionsRequired = isOptionsRequired;
	}

	public String getOptionsToPrompt() {
		return optionsToPrompt;
	}

	public void setOptionsToPrompt(String optionsToPrompt) {
		this.optionsToPrompt = optionsToPrompt;
	}

	public String getPrompt() {
		return prompt;
	}

	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}

	public String getSubscript() {
		return subscript;
	}

	public void setSubscript(String subscript) {
		this.subscript = subscript;
	}

}
