package gov.stb.tag.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaKeDeclaration extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaKeClause taKeClause;

	private String optionSelected;

	private String remarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaStakeholder taKeyExecutive;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaStakeholderApplication taKeyExecutiveApplication;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceRenewal taLicenceRenewal;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOptionSelected() {
		return optionSelected;
	}

	public void setOptionSelected(String optionSelected) {
		this.optionSelected = optionSelected;
	}

	public TaKeClause getTaKeClause() {
		return taKeClause;
	}

	public void setTaKeClause(TaKeClause taKeClause) {
		this.taKeClause = taKeClause;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public TaStakeholder getTaKeyExecutive() {
		return taKeyExecutive;
	}

	public void setTaKeyExecutive(TaStakeholder taKeyExecutive) {
		this.taKeyExecutive = taKeyExecutive;
	}

	public TaStakeholderApplication getTaKeyExecutiveApplication() {
		return taKeyExecutiveApplication;
	}

	public void setTaKeyExecutiveApplication(TaStakeholderApplication taKeyExecutiveApplication) {
		this.taKeyExecutiveApplication = taKeyExecutiveApplication;
	}

	public TaLicenceRenewal getTaLicenceRenewal() {
		return taLicenceRenewal;
	}

	public void setTaLicenceRenewal(TaLicenceRenewal taLicenceRenewal) {
		this.taLicenceRenewal = taLicenceRenewal;
	}

}
