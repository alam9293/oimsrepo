package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaLicenceCreation extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isConcluded;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type applicationMode;

	private String appName;

	private String appUin;

	private LocalDate appDob;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type appSex;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type appNationality;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type appDesignation;

	private String appOtherDesignation;

	private String appOfficeNo;

	private String appResidentialNo;

	private String appMobileNo;

	private String appFaxNo;

	@Column(length = 320)
	private String appEmailAddress;

	private LocalDate effectiveDate; // not in FS?

	@ManyToOne(fetch = FetchType.LAZY)
	private Type licenceTier;

	private String companyName;

	private String companyFormerName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type formOfBusiness;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type businessConstitution;

	// for retrieval of LicenceCreation, the application.licence will still be null, use uen instead
	private String uen;

	private LocalDate registrationDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type principleActivities;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type secondaryPrincipleActivities;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type placeIncorporated;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type establishmentStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type taSegmentation;

	private BigDecimal paidUpCapital;

	private String websiteUrl;

	@Column(length = 320)
	private String emailAddress;

	private String contactNo; // not in FS? mobile no

	private String officeNo;

	public String getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public String getResidentialNo() {
		return residentialNo;
	}

	public void setResidentialNo(String residentialNo) {
		this.residentialNo = residentialNo;
	}

	private String residentialNo;

	private String faxNo;

	private LocalDate fyeDate; // upcoming Fye Date

	@ManyToOne(fetch = FetchType.LAZY)
	private Address registeredAddress;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address operatingAddress;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isOppAddSameAsRegAdd;

	private BigDecimal inboundOpPercent;

	private BigDecimal outboundOpPercent;

	@Column(columnDefinition = "text")
	private String taBusinessWriteUp;

	@Column(columnDefinition = "text")
	private String currentBusinessWriteUp;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isAppKeyExecutive;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaStakeholderApplication taKeyExecutive;

	private String appFeeBillRefNo;

	private String licenceFeeBillRefNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isMyInfoPopulated;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isEdhPopulated;

	@OneToMany(mappedBy = "taLicenceCreation")
	private Set<TaSpecializedMarket> taSpecializedMarkets;

	@OneToMany(mappedBy = "taLicenceCreation")
	private Set<TaBusinessOperation> taBusinessOperations;

	@OneToMany(mappedBy = "taLicenceCreation")
	private Set<TaFocusArea> taFocusAreas;

	@OneToMany(mappedBy = "taLicenceCreation")
	private Set<TaStakeholderApplication> taStakeholders = new HashSet<>();

	private String trustId;

	@Column(columnDefinition = "text")
	private String businessIdea;

	private String consumerFacingBrand;

	@Column(columnDefinition = "text")
	private String mktgCommsPlan;

	@ManyToMany
	@JoinTable(name = "ta_licence_creation$sales_channel")
	private Set<Type> salesChannel = new HashSet<>();

	private String otherSalesChannel;

	@Column(columnDefinition = "text")
	private String financialStrategy;

	private BigDecimal revenueProj1;

	private BigDecimal revenueProj2;

	private BigDecimal costProj1;

	private BigDecimal costProj2;

	private BigDecimal profitLossProj1;

	private BigDecimal profitLossProj2;

	private String estTimeToProfit;

	@Column(columnDefinition = "text")
	private String competitiveEdge;

	@Column(columnDefinition = "text")
	private String partnerServideProviders;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasOtherBizActivities;

	private BigDecimal percentFocusOnTaBiz;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasTaLicBefore;

	@Column(columnDefinition = "text")
	private String detailsRegardingPrevLic;

	@Column(columnDefinition = "text")
	private String relationsWithOtherTa;

	@Column(columnDefinition = "text")
	private String others;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Type getApplicationMode() {
		return applicationMode;
	}

	public void setApplicationMode(Type applicationMode) {
		this.applicationMode = applicationMode;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppUin() {
		return appUin;
	}

	public void setAppUin(String appUin) {
		this.appUin = appUin;
	}

	public LocalDate getAppDob() {
		return appDob;
	}

	public void setAppDob(LocalDate appDob) {
		this.appDob = appDob;
	}

	public Type getAppSex() {
		return appSex;
	}

	public void setAppSex(Type appSex) {
		this.appSex = appSex;
	}

	public Type getAppNationality() {
		return appNationality;
	}

	public void setAppNationality(Type appNationality) {
		this.appNationality = appNationality;
	}

	public Type getAppDesignation() {
		return appDesignation;
	}

	public void setAppDesignation(Type appDesignation) {
		this.appDesignation = appDesignation;
	}

	public String getAppOtherDesignation() {
		return appOtherDesignation;
	}

	public void setAppOtherDesignation(String appOtherDesignation) {
		this.appOtherDesignation = appOtherDesignation;
	}

	public String getAppOfficeNo() {
		return appOfficeNo;
	}

	public void setAppOfficeNo(String appOfficeNo) {
		this.appOfficeNo = appOfficeNo;
	}

	public String getAppResidentialNo() {
		return appResidentialNo;
	}

	public void setAppResidentialNo(String appResidentialNo) {
		this.appResidentialNo = appResidentialNo;
	}

	public String getAppMobileNo() {
		return appMobileNo;
	}

	public void setAppMobileNo(String appMobileNo) {
		this.appMobileNo = appMobileNo;
	}

	public String getAppFaxNo() {
		return appFaxNo;
	}

	public void setAppFaxNo(String appFaxNo) {
		this.appFaxNo = appFaxNo;
	}

	public String getAppEmailAddress() {
		return appEmailAddress;
	}

	public void setAppEmailAddress(String appEmailAddress) {
		this.appEmailAddress = appEmailAddress;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Type getLicenceTier() {
		return licenceTier;
	}

	public void setLicenceTier(Type licenceTier) {
		this.licenceTier = licenceTier;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyFormerName() {
		return companyFormerName;
	}

	public void setCompanyFormerName(String companyFormerName) {
		this.companyFormerName = companyFormerName;
	}

	public Type getFormOfBusiness() {
		return formOfBusiness;
	}

	public void setFormOfBusiness(Type formOfBusiness) {
		this.formOfBusiness = formOfBusiness;
	}

	public Type getBusinessConstitution() {
		return businessConstitution;
	}

	public void setBusinessConstitution(Type businessConstitution) {
		this.businessConstitution = businessConstitution;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public Type getPrincipleActivities() {
		return principleActivities;
	}

	public void setPrincipleActivities(Type principleActivities) {
		this.principleActivities = principleActivities;
	}

	public Type getSecondaryPrincipleActivities() {
		return secondaryPrincipleActivities;
	}

	public void setSecondaryPrincipleActivities(Type secondayPrincipleActivities) {
		this.secondaryPrincipleActivities = secondayPrincipleActivities;
	}

	public Type getPlaceIncorporated() {
		return placeIncorporated;
	}

	public void setPlaceIncorporated(Type placeIncorporated) {
		this.placeIncorporated = placeIncorporated;
	}

	public Type getEstablishmentStatus() {
		return establishmentStatus;
	}

	public void setEstablishmentStatus(Type establishmentStatus) {
		this.establishmentStatus = establishmentStatus;
	}

	public Type getTaSegmentation() {
		return taSegmentation;
	}

	public void setTaSegmentation(Type taSegmentation) {
		this.taSegmentation = taSegmentation;
	}

	public BigDecimal getPaidUpCapital() {
		return paidUpCapital;
	}

	public void setPaidUpCapital(BigDecimal paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public LocalDate getFyeDate() {
		return fyeDate;
	}

	public void setFyeDate(LocalDate fyeDate) {
		this.fyeDate = fyeDate;
	}

	public Address getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(Address registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public Address getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(Address operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public BigDecimal getInboundOpPercent() {
		return inboundOpPercent;
	}

	public void setInboundOpPercent(BigDecimal inboundOpPercent) {
		this.inboundOpPercent = inboundOpPercent;
	}

	public BigDecimal getOutboundOpPercent() {
		return outboundOpPercent;
	}

	public void setOutboundOpPercent(BigDecimal outboundOpPercent) {
		this.outboundOpPercent = outboundOpPercent;
	}

	public String getTaBusinessWriteUp() {
		return taBusinessWriteUp;
	}

	public void setTaBusinessWriteUp(String taBusinessWriteUp) {
		this.taBusinessWriteUp = taBusinessWriteUp;
	}

	public String getCurrentBusinessWriteUp() {
		return currentBusinessWriteUp;
	}

	public void setCurrentBusinessWriteUp(String currentBusinessWriteUp) {
		this.currentBusinessWriteUp = currentBusinessWriteUp;
	}

	public Boolean isAppKeyExecutive() {
		return isAppKeyExecutive;
	}

	public void setIsAppKeyExecutive(Boolean isAppKeyExecutive) {
		this.isAppKeyExecutive = isAppKeyExecutive;
	}

	public TaStakeholderApplication getTaKeyExecutive() {
		return taKeyExecutive;
	}

	public void setTaKeyExecutive(TaStakeholderApplication taKeyExecutive) {
		this.taKeyExecutive = taKeyExecutive;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public String getLicenceFeeBillRefNo() {
		return licenceFeeBillRefNo;
	}

	public void setLicenceFeeBillRefNo(String licenceFeeBillRefNo) {
		this.licenceFeeBillRefNo = licenceFeeBillRefNo;
	}

	public Boolean isMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	public Boolean isEdhPopulated() {
		return isEdhPopulated;
	}

	public void setIsEdhPopulated(Boolean isEdhPopulated) {
		this.isEdhPopulated = isEdhPopulated;
	}

	public Set<TaSpecializedMarket> getTaSpecializedMarkets() {
		return taSpecializedMarkets;
	}

	public void setTaSpecializedMarkets(Set<TaSpecializedMarket> taSpecializedMarkets) {
		this.taSpecializedMarkets = taSpecializedMarkets;
	}

	public Set<TaBusinessOperation> getTaBusinessOperations() {
		return taBusinessOperations;
	}

	public void setTaBusinessOperations(Set<TaBusinessOperation> taBusinessOperations) {
		this.taBusinessOperations = taBusinessOperations;
	}

	public Set<TaFocusArea> getTaFocusAreas() {
		return taFocusAreas;
	}

	public void setTaFocusAreas(Set<TaFocusArea> taFocusAreas) {
		this.taFocusAreas = taFocusAreas;
	}

	public Set<TaStakeholderApplication> getTaStakeholders() {
		return taStakeholders;
	}

	public void setTaStakeholders(Set<TaStakeholderApplication> taStakeholders) {
		this.taStakeholders = taStakeholders;
	}

	public Boolean getIsOppAddSameAsRegAdd() {
		return isOppAddSameAsRegAdd;
	}

	public void setIsOppAddSameAsRegAdd(Boolean isOppAddSameAsRegAdd) {
		this.isOppAddSameAsRegAdd = isOppAddSameAsRegAdd;
	}

	public Boolean getIsConcluded() {
		return isConcluded;
	}

	public void setIsConcluded(Boolean isConcluded) {
		this.isConcluded = isConcluded;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	public String getBusinessIdea() {
		return businessIdea;
	}

	public void setBusinessIdea(String businessIdea) {
		this.businessIdea = businessIdea;
	}

	public String getConsumerFacingBrand() {
		return consumerFacingBrand;
	}

	public void setConsumerFacingBrand(String consumerFacingBrand) {
		this.consumerFacingBrand = consumerFacingBrand;
	}

	public String getMktgCommsPlan() {
		return mktgCommsPlan;
	}

	public void setMktgCommsPlan(String mktgCommsPlan) {
		this.mktgCommsPlan = mktgCommsPlan;
	}

	public Set<Type> getSalesChannel() {
		return salesChannel;
	}

	public void setSalesChannel(Set<Type> salesChannel) {
		this.salesChannel = salesChannel;
	}

	public String getOtherSalesChannel() {
		return otherSalesChannel;
	}

	public void setOtherSalesChannel(String otherSalesChannel) {
		this.otherSalesChannel = otherSalesChannel;
	}

	public String getFinancialStrategy() {
		return financialStrategy;
	}

	public void setFinancialStrategy(String financialStrategy) {
		this.financialStrategy = financialStrategy;
	}

	public BigDecimal getRevenueProj1() {
		return revenueProj1;
	}

	public void setRevenueProj1(BigDecimal revenueProj1) {
		this.revenueProj1 = revenueProj1;
	}

	public BigDecimal getRevenueProj2() {
		return revenueProj2;
	}

	public void setRevenueProj2(BigDecimal revenueProj2) {
		this.revenueProj2 = revenueProj2;
	}

	public BigDecimal getCostProj1() {
		return costProj1;
	}

	public void setCostProj1(BigDecimal costProj1) {
		this.costProj1 = costProj1;
	}

	public BigDecimal getCostProj2() {
		return costProj2;
	}

	public void setCostProj2(BigDecimal costProj2) {
		this.costProj2 = costProj2;
	}

	public BigDecimal getProfitLossProj1() {
		return profitLossProj1;
	}

	public void setProfitLossProj1(BigDecimal profitLossProj1) {
		this.profitLossProj1 = profitLossProj1;
	}

	public BigDecimal getProfitLossProj2() {
		return profitLossProj2;
	}

	public void setProfitLossProj2(BigDecimal profitLossProj2) {
		this.profitLossProj2 = profitLossProj2;
	}

	public String getEstTimeToProfit() {
		return estTimeToProfit;
	}

	public void setEstTimeToProfit(String estTimeToProfit) {
		this.estTimeToProfit = estTimeToProfit;
	}

	public String getCompetitiveEdge() {
		return competitiveEdge;
	}

	public void setCompetitiveEdge(String competitiveEdge) {
		this.competitiveEdge = competitiveEdge;
	}

	public String getPartnerServideProviders() {
		return partnerServideProviders;
	}

	public void setPartnerServideProviders(String partnerServideProviders) {
		this.partnerServideProviders = partnerServideProviders;
	}

	public Boolean getHasOtherBizActivities() {
		return hasOtherBizActivities;
	}

	public void setHasOtherBizActivities(Boolean hasOtherBizActivities) {
		this.hasOtherBizActivities = hasOtherBizActivities;
	}

	public BigDecimal getPercentFocusOnTaBiz() {
		return percentFocusOnTaBiz;
	}

	public void setPercentFocusOnTaBiz(BigDecimal percentFocusOnTaBiz) {
		this.percentFocusOnTaBiz = percentFocusOnTaBiz;
	}

	public Boolean getHasTaLicBefore() {
		return hasTaLicBefore;
	}

	public void setHasTaLicBefore(Boolean hasTaLicBefore) {
		this.hasTaLicBefore = hasTaLicBefore;
	}

	public String getDetailsRegardingPrevLic() {
		return detailsRegardingPrevLic;
	}

	public void setDetailsRegardingPrevLic(String detailsRegardingPrevLic) {
		this.detailsRegardingPrevLic = detailsRegardingPrevLic;
	}

	public String getRelationsWithOtherTa() {
		return relationsWithOtherTa;
	}

	public void setRelationsWithOtherTa(String relationsWithOtherTa) {
		this.relationsWithOtherTa = relationsWithOtherTa;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

}