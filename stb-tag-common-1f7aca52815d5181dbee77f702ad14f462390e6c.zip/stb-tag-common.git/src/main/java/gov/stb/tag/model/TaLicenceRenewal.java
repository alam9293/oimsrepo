package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaLicenceRenewal extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	private String lateRemarks;

	private String appFeeBillRefNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isConcluded;

	@OneToOne
	private TaLicenceRenewalExerciseTa taLicenceRenewalExerciseTa;

	@OneToMany(mappedBy = "taLicenceRenewal")
	private Set<TaKeDeclaration> taKeDeclarations = new HashSet<>();

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getLateRemarks() {
		return lateRemarks;
	}

	public void setLateRemarks(String lateRemarks) {
		this.lateRemarks = lateRemarks;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public Boolean isConcluded() {
		return isConcluded;
	}

	public void setIsConcluded(Boolean isConcluded) {
		this.isConcluded = isConcluded;
	}

	public TaLicenceRenewalExerciseTa getTaLicenceRenewalExerciseTa() {
		return taLicenceRenewalExerciseTa;
	}

	public void setTaLicenceRenewalExerciseTa(TaLicenceRenewalExerciseTa taLicenceRenewalExerciseTa) {
		this.taLicenceRenewalExerciseTa = taLicenceRenewalExerciseTa;
	}

	public Set<TaKeDeclaration> getTaKeDeclarations() {
		return taKeDeclarations;
	}

	public void setTaKeDeclarations(Set<TaKeDeclaration> taKeDeclarations) {
		this.taKeDeclarations = taKeDeclarations;
	}

}
