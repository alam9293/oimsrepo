package gov.stb.tag.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaLicenceRenewalExercise extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasBaselined; // once baselined, "Refresh Table" will only update the TaLicenceRenewalExerciseTa instead of re-population

	private LocalDateTime baselinedDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isRefreshing;

	private LocalDateTime refreshedDate;

	@OneToOne
	private Workflow workflow; // approving the exercise blanket approve all MA submission requirement

	private LocalDate startDate; // e.g. 1 Aug 2019

	private LocalDate endDate; // e.g. 31 Oct 2019

	private LocalDate fyeCutOffDate; // e.g. 31 Mar 2019. Hence, if TA FY18 FYE is <= 31 Mar 19 (e.g. up till 31 Sep to submit, which is within renewal exercise), conditions are FY18 and FY17

	private LocalDate defaultRequestedMaAsAtDate; // default MA 'As At' date to request from TA who is required to submit MA

	private Integer year; // To save the year of renewal start date for renewnal year drop down

	@OneToMany(mappedBy = "taLicenceRenewalExercise")
	private Set<TaLicenceRenewalExerciseParam> params; // parameters per licence in the renewal exercise

	@OneToMany(mappedBy = "taLicenceRenewalExercise")
	private Set<TaLicenceRenewalExerciseTa> tas;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean hasBaselined() {
		return hasBaselined;
	}

	public void setHasBaselined(Boolean hasBaselined) {
		this.hasBaselined = hasBaselined;
	}

	public LocalDateTime getBaselinedDate() {
		return baselinedDate;
	}

	public void setBaselinedDate(LocalDateTime baselinedDate) {
		this.baselinedDate = baselinedDate;
	}

	public Boolean isRefreshing() {
		return isRefreshing;
	}

	public void setIsRefreshing(Boolean isRefreshing) {
		this.isRefreshing = isRefreshing;
	}

	public LocalDateTime getRefreshedDate() {
		return refreshedDate;
	}

	public void setRefreshedDate(LocalDateTime refreshedDate) {
		this.refreshedDate = refreshedDate;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public LocalDate getFyeCutOffDate() {
		return fyeCutOffDate;
	}

	public void setFyeCutOffDate(LocalDate fyeCutOffDate) {
		this.fyeCutOffDate = fyeCutOffDate;
	}

	public LocalDate getDefaultRequestedMaAsAtDate() {
		return defaultRequestedMaAsAtDate;
	}

	public void setDefaultRequestedMaAsAtDate(LocalDate defaultRequestedMaAsAtDate) {
		this.defaultRequestedMaAsAtDate = defaultRequestedMaAsAtDate;
	}

	public Set<TaLicenceRenewalExerciseParam> getParams() {
		return params;
	}

	public void setParams(Set<TaLicenceRenewalExerciseParam> params) {
		this.params = params;
	}

	public Set<TaLicenceRenewalExerciseTa> getTas() {
		return tas;
	}

	public void setTas(Set<TaLicenceRenewalExerciseTa> tas) {
		this.tas = tas;
	}

	public Integer getYear() {
		return year;
	}

	public void setYearRetrieveFromStartDate() {
		this.year = this.startDate.getYear();
	}

	public void setYear(Integer year) {
		this.year = year;
	}

}
