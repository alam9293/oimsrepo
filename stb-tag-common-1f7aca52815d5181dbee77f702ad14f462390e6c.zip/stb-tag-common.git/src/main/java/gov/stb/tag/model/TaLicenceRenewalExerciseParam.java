package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

// This table stores all user-specified values (if any) per TA licence within the renewal exercise.
@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaLicenceRenewalExerciseParam extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceRenewalExercise taLicenceRenewalExercise;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	private Boolean isMaRequiredByUser; // null means system derived

	private LocalDate requestedMaAsAtDate;

	private LocalDate maSubmissionDueDate;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TaLicenceRenewalExercise getTaLicenceRenewalExercise() {
		return taLicenceRenewalExercise;
	}

	public void setTaLicenceRenewalExercise(TaLicenceRenewalExercise taLicenceRenewalExercise) {
		this.taLicenceRenewalExercise = taLicenceRenewalExercise;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public Boolean isMaRequiredByUser() {
		return isMaRequiredByUser;
	}

	public void setIsMaRequiredByUser(Boolean isMaRequiredByUser) {
		this.isMaRequiredByUser = isMaRequiredByUser;
	}

	public LocalDate getRequestedMaAsAtDate() {
		return requestedMaAsAtDate;
	}

	public void setRequestedMaAsAtDate(LocalDate requestedMaAsAtDate) {
		this.requestedMaAsAtDate = requestedMaAsAtDate;
	}

	public LocalDate getMaSubmissionDueDate() {
		return maSubmissionDueDate;
	}

	public void setMaSubmissionDueDate(LocalDate maSubmissionDueDate) {
		this.maSubmissionDueDate = maSubmissionDueDate;
	}

}