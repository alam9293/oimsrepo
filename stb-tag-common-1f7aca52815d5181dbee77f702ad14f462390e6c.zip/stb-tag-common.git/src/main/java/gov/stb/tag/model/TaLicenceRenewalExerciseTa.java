package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.IdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaLicenceRenewalExerciseTa extends com.wiz.model.api.Entity implements IdEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceRenewalExercise taLicenceRenewalExercise;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // Express, Customized

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	private String baselinedName; // updated upon approval of exercise (to capture change of company name)

	@ManyToOne(fetch = FetchType.LAZY)
	private TaStakeholder ke; // current ke to be displayed (together with baseline) after exercise has been approved

	@ManyToOne(fetch = FetchType.LAZY)
	private TaStakeholder baselinedKe; // updated upon approval of exercise (to capture change of ke assignment)

	private String baselinedKeName; // updated upon approval of exercise (to capture change of ke name)

	private LocalDate fye; // current fye to be displayed (together with baseline) after exercise has been approved

	private LocalDate baselinedFye; // updated upon approval of exercise (to capture change of fye)

	private BigDecimal outstandingPayment; // current outstanding to be displayed (together with baseline) after exercise has been approved

	private BigDecimal baselinedOutstandingPayment; // updated upon approval of exercise (to capture payment progress)

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition taAaFilingCondition1;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition taAaFilingCondition2;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaNetValueShortfall taNetValueShortfallAa1;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaNetValueShortfall taNetValueShortfallAa2;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition taAbprFilingCondition1;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition taAbprFilingCondition2;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isMaRequired; // derived from TaLicenceRenewalExerciseParam.isMaRequiredByUser, if it does not exist, then compute by biz logic

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isMaVoid; // when the created MA is void, set this as true to filter out check if MA required with saving and refresh renewal table

	@ManyToOne(fetch = FetchType.LAZY)
	private TaFilingCondition maFilingCondition; // if isMaRequired upon approval, create with due date = Approved Date + 28 days, if due date is < 7 calendar days to 21st dec, leave it as null
													// When ad-hoc MA requested by STB and system logic determine MA not required by TA, the ad-hoc MA be snapshot here. If there is already MA tied to
													// it, ad-hoc MA will not be snapshot here
	@ManyToOne(fetch = FetchType.LAZY)
	private TaNetValueShortfall taNetValueShortfallMa1;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaNetValueShortfall taNetValueShortfallMa2;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceRenewal taLicenceRenewal; // null if ta did not apply to renew

	@OneToMany(mappedBy = "taLicenceRenewalExerciseTa")
	private Set<TaLicenceRenewalExerciseTaEmailLog> taLicenceRenewalExerciseTaEmailLogs;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TaLicenceRenewalExercise getTaLicenceRenewalExercise() {
		return taLicenceRenewalExercise;
	}

	public void setTaLicenceRenewalExercise(TaLicenceRenewalExercise taLicenceRenewalExercise) {
		this.taLicenceRenewalExercise = taLicenceRenewalExercise;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public String getBaselinedName() {
		return baselinedName;
	}

	public void setBaselinedName(String baselinedName) {
		this.baselinedName = baselinedName;
	}

	public TaStakeholder getKe() {
		return ke;
	}

	public void setKe(TaStakeholder ke) {
		this.ke = ke;
	}

	public TaStakeholder getBaselinedKe() {
		return baselinedKe;
	}

	public void setBaselinedKe(TaStakeholder baselinedKe) {
		this.baselinedKe = baselinedKe;
	}

	public String getBaselinedKeName() {
		return baselinedKeName;
	}

	public void setBaselinedKeName(String baselinedKeName) {
		this.baselinedKeName = baselinedKeName;
	}

	public LocalDate getFye() {
		return fye;
	}

	public void setFye(LocalDate fye) {
		this.fye = fye;
	}

	public LocalDate getBaselinedFye() {
		return baselinedFye;
	}

	public void setBaselinedFye(LocalDate baselinedFye) {
		this.baselinedFye = baselinedFye;
	}

	public BigDecimal getOutstandingPayment() {
		return outstandingPayment;
	}

	public void setOutstandingPayment(BigDecimal outstandingPayment) {
		this.outstandingPayment = outstandingPayment;
	}

	public BigDecimal getBaselinedOutstandingPayment() {
		return baselinedOutstandingPayment;
	}

	public void setBaselinedOutstandingPayment(BigDecimal baselinedOutstandingPayment) {
		this.baselinedOutstandingPayment = baselinedOutstandingPayment;
	}

	public TaFilingCondition getTaAaFilingCondition1() {
		return taAaFilingCondition1;
	}

	public void setTaAaFilingCondition1(TaFilingCondition taAaFilingCondition1) {
		this.taAaFilingCondition1 = taAaFilingCondition1;
	}

	public TaFilingCondition getTaAaFilingCondition2() {
		return taAaFilingCondition2;
	}

	public void setTaAaFilingCondition2(TaFilingCondition taAaFilingCondition2) {
		this.taAaFilingCondition2 = taAaFilingCondition2;
	}

	public TaNetValueShortfall getTaNetValueShortfallAa1() {
		return taNetValueShortfallAa1;
	}

	public void setTaNetValueShortfallAa1(TaNetValueShortfall taNetValueShortfallAa1) {
		this.taNetValueShortfallAa1 = taNetValueShortfallAa1;
	}

	public TaNetValueShortfall getTaNetValueShortfallAa2() {
		return taNetValueShortfallAa2;
	}

	public void setTaNetValueShortfallAa2(TaNetValueShortfall taNetValueShortfallAa2) {
		this.taNetValueShortfallAa2 = taNetValueShortfallAa2;
	}

	public TaFilingCondition getTaAbprFilingCondition1() {
		return taAbprFilingCondition1;
	}

	public void setTaAbprFilingCondition1(TaFilingCondition taAbprFilingCondition1) {
		this.taAbprFilingCondition1 = taAbprFilingCondition1;
	}

	public TaFilingCondition getTaAbprFilingCondition2() {
		return taAbprFilingCondition2;
	}

	public void setTaAbprFilingCondition2(TaFilingCondition taAbprFilingCondition2) {
		this.taAbprFilingCondition2 = taAbprFilingCondition2;
	}

	public Boolean isMaRequired() {
		return isMaRequired;
	}

	public void setIsMaRequired(Boolean isMaRequired) {
		this.isMaRequired = isMaRequired;
	}

	public TaFilingCondition getMaFilingCondition() {
		return maFilingCondition;
	}

	public void setMaFilingCondition(TaFilingCondition maFilingCondition) {
		this.maFilingCondition = maFilingCondition;
	}

	public TaNetValueShortfall getTaNetValueShortfallMa1() {
		return taNetValueShortfallMa1;
	}

	public void setTaNetValueShortfallMa1(TaNetValueShortfall taNetValueShortfallMa1) {
		this.taNetValueShortfallMa1 = taNetValueShortfallMa1;
	}

	public TaNetValueShortfall getTaNetValueShortfallMa2() {
		return taNetValueShortfallMa2;
	}

	public void setTaNetValueShortfallMa2(TaNetValueShortfall taNetValueShortfallMa2) {
		this.taNetValueShortfallMa2 = taNetValueShortfallMa2;
	}

	public TaLicenceRenewal getTaLicenceRenewal() {
		return taLicenceRenewal;
	}

	public void setTaLicenceRenewal(TaLicenceRenewal taLicenceRenewal) {
		this.taLicenceRenewal = taLicenceRenewal;
	}

	public Set<TaLicenceRenewalExerciseTaEmailLog> getTaLicenceRenewalExerciseTaEmailLogs() {
		return taLicenceRenewalExerciseTaEmailLogs;
	}

	public void setTaLicenceRenewalExerciseTaEmailLogs(Set<TaLicenceRenewalExerciseTaEmailLog> taLicenceRenewalExerciseTaEmailLogs) {
		this.taLicenceRenewalExerciseTaEmailLogs = taLicenceRenewalExerciseTaEmailLogs;
	}

	public Boolean getIsMaVoid() {
		return isMaVoid;
	}

	public void setIsMaVoid(Boolean isMaVoid) {
		this.isMaVoid = isMaVoid;
	}

	public Boolean getIsMaRequired() {
		return isMaRequired;
	}

}