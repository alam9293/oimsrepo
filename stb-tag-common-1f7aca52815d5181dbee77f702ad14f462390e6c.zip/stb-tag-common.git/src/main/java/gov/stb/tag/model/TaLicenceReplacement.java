package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaLicenceReplacement extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type reason;

	private String otherReason;

	private String billRefNo;

	private LocalDate licenceReturnedDate;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Type getReason() {
		return reason;
	}

	public void setReason(Type reason) {
		this.reason = reason;
	}

	public String getOtherReason() {
		return otherReason;
	}

	public void setOtherReason(String otherReason) {
		this.otherReason = otherReason;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public LocalDate getLicenceReturnedDate() {
		return licenceReturnedDate;
	}

	public void setLicenceReturnedDate(LocalDate licenceReturnedDate) {
		this.licenceReturnedDate = licenceReturnedDate;
	}

}
