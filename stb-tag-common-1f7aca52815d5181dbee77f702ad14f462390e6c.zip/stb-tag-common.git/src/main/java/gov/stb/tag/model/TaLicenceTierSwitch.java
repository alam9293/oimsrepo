package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaLicenceTierSwitch extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type oldLicenceTier;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type newLicenceTier;

	@OneToMany(mappedBy = "taLicenceTierSwitch")
	private Set<TaBusinessOperation> taBusinessOperations;

	@OneToMany(mappedBy = "newTaLicenceTierSwitch")
	private Set<TaBusinessOperation> newTaBusinessOperations;

	private LocalDate startDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean pendingSwitch;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Type getOldLicenceTier() {
		return oldLicenceTier;
	}

	public void setOldLicenceTier(Type oldLicenceTier) {
		this.oldLicenceTier = oldLicenceTier;
	}

	public Type getNewLicenceTier() {
		return newLicenceTier;
	}

	public void setNewLicenceTier(Type newLicenceTier) {
		this.newLicenceTier = newLicenceTier;
	}

	public Set<TaBusinessOperation> getTaBusinessOperations() {
		return taBusinessOperations;
	}

	public void setTaBusinessOperations(Set<TaBusinessOperation> taBusinessOperations) {
		this.taBusinessOperations = taBusinessOperations;
	}

	public Set<TaBusinessOperation> getNewTaBusinessOperations() {
		return newTaBusinessOperations;
	}

	public void setNewTaBusinessOperations(Set<TaBusinessOperation> newTaBusinessOperations) {
		this.newTaBusinessOperations = newTaBusinessOperations;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public Boolean getPendingSwitch() {
		return pendingSwitch;
	}

	public void setPendingSwitch(Boolean pendingSwitch) {
		this.pendingSwitch = pendingSwitch;
	}

}
