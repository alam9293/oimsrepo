package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaMaSubmission extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@OneToOne
	private TaFilingCondition taFilingCondition;

	private LocalDate asAtDate;

	private BigDecimal totalAssets;

	private BigDecimal totalLiabilities;

	private BigDecimal paidUpCapital;

	private BigDecimal netValue;

	private BigDecimal shortfall;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public TaFilingCondition getTaFilingCondition() {
		return taFilingCondition;
	}

	public void setTaFilingCondition(TaFilingCondition taFilingCondition) {
		this.taFilingCondition = taFilingCondition;
	}

	public LocalDate getAsAtDate() {
		return asAtDate;
	}

	public void setAsAtDate(LocalDate asAtDate) {
		this.asAtDate = asAtDate;
	}

	public BigDecimal getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(BigDecimal totalAssets) {
		this.totalAssets = totalAssets;
	}

	public BigDecimal getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(BigDecimal totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public BigDecimal getPaidUpCapital() {
		return paidUpCapital;
	}

	public void setPaidUpCapital(BigDecimal paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}

	public BigDecimal getNetValue() {
		return netValue;
	}

	public void setNetValue(BigDecimal netValue) {
		this.netValue = netValue;
	}

	public BigDecimal getShortfall() {
		return shortfall;
	}

	public void setShortfall(BigDecimal shortfall) {
		this.shortfall = shortfall;
	}

}
