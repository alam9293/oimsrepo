package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaNetValueRectification extends AuditableIdEntity {

	private Integer id;

	@ManyToOne
	private TravelAgent travelAgent;

	@OneToOne
	private Application application;

	private BigDecimal amount;

	private LocalDate rectifiedDate;

	@Deprecated
	@OneToOne
	private TaAaSubmission taAaSubmission; // deprecated to use TaNetValueShortfall

	@Deprecated
	private BigDecimal currentNetValue; // deprectated to derive from TaNetValueShortfall

	@Deprecated
	private BigDecimal shortfallAmount; // deprectated to derive from TaNetValueShortfall

	@OneToMany(mappedBy = "taNetValueRectification")
	private Set<TaNetValueShortfall> taNetValueShortfalls; // will return empty if this rectification has not been APPROVED yet

	@ManyToMany
	@JoinTable(name = "taNetValueRectification$taNetValueShortfall", joinColumns = @JoinColumn(name = "taNetValueRectificationId"), inverseJoinColumns = @JoinColumn(name = "taNetValueShortfallsId"))
	private Set<TaNetValueShortfall> allTaNetValueShortfalls = new HashSet<>(); // to store all mappings of rectification to shortfalls

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isEdhPopulated;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TravelAgent getTravelAgent() {
		return travelAgent;
	}

	public void setTravelAgent(TravelAgent travelAgent) {
		this.travelAgent = travelAgent;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDate getRectifiedDate() {
		return rectifiedDate;
	}

	public void setRectifiedDate(LocalDate rectifiedDate) {
		this.rectifiedDate = rectifiedDate;
	}

	@Deprecated
	public TaAaSubmission getTaAaSubmission() {
		return taAaSubmission;
	}

	@Deprecated
	public void setTaAaSubmission(TaAaSubmission taAaSubmission) {
		this.taAaSubmission = taAaSubmission;
	}

	@Deprecated
	public BigDecimal getCurrentNetValue() {
		return currentNetValue;
	}

	@Deprecated
	public void setCurrentNetValue(BigDecimal currentNetValue) {
		this.currentNetValue = currentNetValue;
	}

	@Deprecated
	public BigDecimal getShortfallAmount() {
		return shortfallAmount;
	}

	@Deprecated
	public void setShortfallAmount(BigDecimal shortfallAmount) {
		this.shortfallAmount = shortfallAmount;
	}

	public Set<TaNetValueShortfall> getTaNetValueShortfalls() {
		return taNetValueShortfalls;
	}

	public void setTaNetValueShortfalls(Set<TaNetValueShortfall> taNetValueShortfalls) {
		this.taNetValueShortfalls = taNetValueShortfalls;
	}

	public Set<TaNetValueShortfall> getAllTaNetValueShortfalls() {
		return allTaNetValueShortfalls;
	}

	public void setAllTaNetValueShortfalls(Set<TaNetValueShortfall> allTaNetValueShortfalls) {
		this.allTaNetValueShortfalls = allTaNetValueShortfalls;
	}

	public Boolean getIsEdhPopulated() {
		return isEdhPopulated;
	}

	public void setIsEdhPopulated(Boolean isEdhPopulated) {
		this.isEdhPopulated = isEdhPopulated;
	}

}
