package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Entities;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaNetValueShortfall extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private TaNetValueShortfall parentShortfall;

	@OneToOne
	private TaAaSubmission taAaSubmission; // either taAaSubmission or taMaSubmission, although there may be a possibility to tie both (esp. for incremental)

	@OneToOne
	private TaMaSubmission taMaSubmission; // either taAaSubmission or taMaSubmission, although there may be a possibility to tie both (esp. for incremental)

	@OneToOne
	private Workflow workflow; // pending (initial status created upon approval of taAaSubmission (if has shortfall) or manual creation for taMaSubmission), approved, reject

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // incremental, full

	private BigDecimal amount; // default to shortfall of the taAaSubmission/taMaSubmission, stb officer will check what is the actual shortfall (esp. for incremental)

	private LocalDate rectificationDueDate; // T-28 days from 21st Dec, if it is < 7 calendar days from current date, leave it as null

	private LocalDate extendedDueDate;

	private LocalDate letterIssuedDate;

	@Column(length = 5000)
	private String remarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaNetValueRectification taNetValueRectification; // null means TA does not have an APPROVED rectification

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement tarR9Infringement;

	@Column(columnDefinition = "text")
	private String letterContent;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TaNetValueShortfall getParentShortfall() {
		return parentShortfall;
	}

	public void setParentShortfall(TaNetValueShortfall parentShortfall) {
		this.parentShortfall = parentShortfall;
	}

	public TaAaSubmission getTaAaSubmission() {
		return taAaSubmission;
	}

	public void setTaAaSubmission(TaAaSubmission taAaSubmission) {
		this.taAaSubmission = taAaSubmission;
	}

	public TaMaSubmission getTaMaSubmission() {
		return taMaSubmission;
	}

	public void setTaMaSubmission(TaMaSubmission taMaSubmission) {
		this.taMaSubmission = taMaSubmission;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDate getRectificationDueDate() {
		return rectificationDueDate;
	}

	public void setRectificationDueDate(LocalDate rectificationDueDate) {
		this.rectificationDueDate = rectificationDueDate;
	}

	public LocalDate getExtendedDueDate() {
		return extendedDueDate;
	}

	public void setExtendedDueDate(LocalDate extendedDueDate) {
		this.extendedDueDate = extendedDueDate;
	}

	public LocalDate getLetterIssuedDate() {
		return letterIssuedDate;
	}

	public void setLetterIssuedDate(LocalDate letterIssuedDate) {
		this.letterIssuedDate = letterIssuedDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public TaNetValueRectification getTaNetValueRectification() {
		return taNetValueRectification;
	}

	public void setTaNetValueRectification(TaNetValueRectification taNetValueRectification) {
		this.taNetValueRectification = taNetValueRectification;
	}

	public CeCaseInfringement getTarR9Infringement() {
		return tarR9Infringement;
	}

	public void setTarR9Infringement(CeCaseInfringement tarR9Infringement) {
		this.tarR9Infringement = tarR9Infringement;
	}

	public String getLetterContent() { return letterContent; }

	public void setLetterContent(String letterContent) { this.letterContent = letterContent; }

	public String deriveRectificationStatus() {
		if (Entities.equals(this.getWorkflow().getLastAction().getStatus(), Codes.Statuses.TA_WKFLW_APPROVED)
				&& Entities.equals(this.getWorkflow().getLastAction().getRecommendation(), Codes.Types.RECOMMEND_IMPOSE)) {
			if (this.getTaNetValueRectification() == null) {
				return "No";
			} else {
				if (this.getTaNetValueRectification().getApplication().getLastAction().getStatus().getCode().equalsIgnoreCase(Codes.Statuses.TA_APP_APPROVED)) {
					return "Yes";
				} else {
					return "No";
				}
			}
		} else {
			return "-";
		}
	}

	public String determineShortfallFor() {
		if (this.getTaAaSubmission() != null) {
			return Codes.ApplicationTypes.TA_APP_AA_SUBMISSION;
		} else if (this.getTaMaSubmission() != null) {
			return this.getTaMaSubmission().getApplication().getType().getCode();
		} else {
			return "";
		}
	}
}
