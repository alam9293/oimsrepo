package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaSpecializedMarket extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isInbound;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type country;

	private BigDecimal percent;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceCreation taLicenceCreation;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaAbprSubmission taAbprSubmission;

	private String trustId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean isInbound() {
		return isInbound;
	}

	public void setIsInbound(Boolean isInbound) {
		this.isInbound = isInbound;
	}

	public Type getCountry() {
		return country;
	}

	public void setCountry(Type country) {
		this.country = country;
	}

	public BigDecimal getPercent() {
		return percent;
	}

	public void setPercent(BigDecimal percent) {
		this.percent = percent;
	}

	public TaLicenceCreation getTaLicenceCreation() {
		return taLicenceCreation;
	}

	public void setTaLicenceCreation(TaLicenceCreation taLicenceCreation) {
		this.taLicenceCreation = taLicenceCreation;
	}

	public TaAbprSubmission getTaAbprSubmission() {
		return taAbprSubmission;
	}

	public void setTaAbprSubmission(TaAbprSubmission taAbprSubmission) {
		this.taAbprSubmission = taAbprSubmission;
	}

	public Boolean getIsInbound() {
		return isInbound;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

}
