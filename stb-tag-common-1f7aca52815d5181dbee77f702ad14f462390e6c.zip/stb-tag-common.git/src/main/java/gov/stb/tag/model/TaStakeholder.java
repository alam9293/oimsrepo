package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaStakeholder extends AuditableIdEntity {

	private Integer id;

	private Integer sharesHeld;

	private LocalDate appointedDate;

	private LocalDate resignedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type role; // includes Key Executive role, and other appointments (positionHeld) from EDH

	@ManyToOne(fetch = FetchType.LAZY)
	private Stakeholder stakeholder;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceCreation taLicenceCreation;

	@OneToMany(mappedBy = "taKeyExecutive")
	private Set<TaKeDeclaration> taKeDeclarations = new HashSet<>();

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement tarR153bInfringement;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSharesHeld() {
		return sharesHeld;
	}

	public void setSharesHeld(Integer sharesHeld) {
		this.sharesHeld = sharesHeld;
	}

	public LocalDate getAppointedDate() {
		return appointedDate;
	}

	public void setAppointedDate(LocalDate appointedDate) {
		this.appointedDate = appointedDate;
	}

	public LocalDate getResignedDate() {
		return resignedDate;
	}

	public void setResignedDate(LocalDate resignedDate) {
		this.resignedDate = resignedDate;
	}

	public Type getRole() {
		return role;
	}

	public void setRole(Type role) {
		this.role = role;
	}

	public Stakeholder getStakeholder() {
		return stakeholder;
	}

	public void setStakeholder(Stakeholder stakeholder) {
		this.stakeholder = stakeholder;
	}

	public TaLicenceCreation getTaLicenceCreation() {
		return taLicenceCreation;
	}

	public void setTaLicenceCreation(TaLicenceCreation taLicenceCreation) {
		this.taLicenceCreation = taLicenceCreation;
	}

	public Set<TaKeDeclaration> getTaKeDeclarations() {
		return taKeDeclarations;
	}

	public void setTaKeDeclarations(Set<TaKeDeclaration> taKeDeclarations) {
		this.taKeDeclarations = taKeDeclarations;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public CeCaseInfringement getTarR153bInfringement() {
		return tarR153bInfringement;
	}

	public void setTarR153bInfringement(CeCaseInfringement tarR153bInfringement) {
		this.tarR153bInfringement = tarR153bInfringement;
	}

}
