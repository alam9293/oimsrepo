package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TaStakeholderApplication extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	private TaStakeholder taStakeholder; // current taStakeholder

	@OneToOne
	private TaStakeholderApplication previousValue;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // re-assign, update, resign (for resign, no need fill the below. Need to fill resigned date)

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isCompany;

	private String companyUen;

	private LocalDate companyIncorporatedDate;

	private String name;

	private String uin;

	private String formerUin;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type sex;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type nationality;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address;

	private LocalDate dob;

	private String contactNo; // not in FS? mobile no

	private String officeNo;

	private String residentialNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isEdhPopulated;

	@OneToOne(fetch = FetchType.LAZY)
	private CeCaseInfringement tarR153aInfringement;

	public String getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public String getResidentialNo() {
		return residentialNo;
	}

	public void setResidentialNo(String residentialNo) {
		this.residentialNo = residentialNo;
	}

	@Column(length = 320)
	private String email;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type designation;

	private String otherDesignation;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type highestEduLevel;

	private Integer sharesHeld;

	private LocalDate joinedDate; // for migration

	private LocalDate appointedDate;

	private LocalDate resignedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type role; // includes Key Executive role, and other appointments (positionHeld) from EDH

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isMyInfoPopulated;

	@OneToMany(mappedBy = "taKeyExecutiveApplication")
	private Set<TaKeDeclaration> taKeDeclarations = new HashSet<>();

	@ManyToOne(fetch = FetchType.LAZY)
	private TaLicenceCreation taLicenceCreation;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public TaStakeholderApplication getPreviousValue() {
		return previousValue;
	}

	public void setPreviousValue(TaStakeholderApplication previousValue) {
		this.previousValue = previousValue;
	}

	public TaStakeholder getTaStakeholder() {
		return taStakeholder;
	}

	public void setTaStakeholder(TaStakeholder taStakeholder) {
		this.taStakeholder = taStakeholder;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public Type getSex() {
		return sex;
	}

	public void setSex(Type sex) {
		this.sex = sex;
	}

	public Type getNationality() {
		return nationality;
	}

	public void setNationality(Type nationality) {
		this.nationality = nationality;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Type getDesignation() {
		return designation;
	}

	public void setDesignation(Type designation) {
		this.designation = designation;
	}

	public String getOtherDesignation() {
		return otherDesignation;
	}

	public void setOtherDesignation(String otherDesignation) {
		this.otherDesignation = otherDesignation;
	}

	public Type getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(Type highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public Integer getSharesHeld() {
		return sharesHeld;
	}

	public void setSharesHeld(Integer sharesHeld) {
		this.sharesHeld = sharesHeld;
	}

	public LocalDate getAppointedDate() {
		return appointedDate;
	}

	public LocalDate getJoinedDate() {
		return joinedDate;
	}

	public void setJoinedDate(LocalDate joinedDate) {
		this.joinedDate = joinedDate;
	}

	public void setAppointedDate(LocalDate appointedDate) {
		this.appointedDate = appointedDate;
	}

	public LocalDate getResignedDate() {
		return resignedDate;
	}

	public void setResignedDate(LocalDate resignedDate) {
		this.resignedDate = resignedDate;
	}

	public Type getRole() {
		return role;
	}

	public void setRole(Type role) {
		this.role = role;
	}

	public Boolean getIsCompany() {
		return isCompany;
	}

	public void setIsCompany(Boolean isCompany) {
		this.isCompany = isCompany;
	}

	public String getCompanyUen() {
		return companyUen;
	}

	public void setCompanyUen(String companyUen) {
		this.companyUen = companyUen;
	}

	public LocalDate getCompanyIncorporatedDate() {
		return companyIncorporatedDate;
	}

	public void setCompanyIncorporatedDate(LocalDate companyIncorporatedDate) {
		this.companyIncorporatedDate = companyIncorporatedDate;
	}

	public String getFormerUin() {
		return formerUin;
	}

	public void setFormerUin(String formerUin) {
		this.formerUin = formerUin;
	}

	public Boolean isMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	public Set<TaKeDeclaration> getTaKeDeclarations() {
		return taKeDeclarations;
	}

	public void setTaKeDeclarations(Set<TaKeDeclaration> taKeDeclarations) {
		this.taKeDeclarations = taKeDeclarations;
	}

	public TaLicenceCreation getTaLicenceCreation() {
		return taLicenceCreation;
	}

	public void setTaLicenceCreation(TaLicenceCreation taLicenceCreation) {
		this.taLicenceCreation = taLicenceCreation;
	}

	public Boolean getIsEdhPopulated() {
		return isEdhPopulated;
	}

	public void setIsEdhPopulated(Boolean isEdhPopulated) {
		this.isEdhPopulated = isEdhPopulated;
	}

	public CeCaseInfringement getTarR153aInfringement() {
		return tarR153aInfringement;
	}

	public void setTarR153aInfringement(CeCaseInfringement tarR153aInfringement) {
		this.tarR153aInfringement = tarR153aInfringement;
	}

}
