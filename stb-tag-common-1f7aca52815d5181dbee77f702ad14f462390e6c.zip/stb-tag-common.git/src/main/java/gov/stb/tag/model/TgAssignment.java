package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgAssignment extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TouristGuide touristGuide;

	private LocalDate startDate;

	private LocalDate endDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	private String tourTypeOther;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type language;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type employmentSource;

	private String employmentSourceTypeOther;

	private String companyName;

	private BigDecimal feeReceived;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	private String legacyId;

	@OneToMany(mappedBy = "tgAssignment")
	private Set<TgAssignmentDate> tgAssignmentDates;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TouristGuide getTouristGuide() {
		return touristGuide;
	}

	public void setTouristGuide(TouristGuide touristGuide) {
		this.touristGuide = touristGuide;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getTourTypeOther() {
		return tourTypeOther;
	}

	public void setTourTypeOther(String tourTypeOther) {
		this.tourTypeOther = tourTypeOther;
	}

	public Type getLanguage() {
		return language;
	}

	public void setLanguage(Type language) {
		this.language = language;
	}

	public String getEmploymentSourceTypeOther() {
		return employmentSourceTypeOther;
	}

	public void setEmploymentSourceTypeOther(String employmentSourceTypeOther) {
		this.employmentSourceTypeOther = employmentSourceTypeOther;
	}

	public Type getEmploymentSource() {
		return employmentSource;
	}

	public void setEmploymentSource(Type employmentSource) {
		this.employmentSource = employmentSource;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public BigDecimal getFeeReceived() {
		return feeReceived;
	}

	public void setFeeReceived(BigDecimal feeReceived) {
		this.feeReceived = feeReceived;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

	public Set<TgAssignmentDate> getTgAssignmentDates() {
		return tgAssignmentDates;
	}

	public void setTgAssignmentDates(Set<TgAssignmentDate> tgAssignmentDates) {
		this.tgAssignmentDates = tgAssignmentDates;
	}

}
