package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgAssignmentDate extends AuditableIdEntity {

	private Integer id;

	private LocalDate date;

	private BigDecimal noOfHours;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgAssignment tgAssignment;

	private String legacyId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

	public TgAssignment getTgAssignment() {
		return tgAssignment;
	}

	public void setTgAssignment(TgAssignment tgAssignment) {
		this.tgAssignment = tgAssignment;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}
}
