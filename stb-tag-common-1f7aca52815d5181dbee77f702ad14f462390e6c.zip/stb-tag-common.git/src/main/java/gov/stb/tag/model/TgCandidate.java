package gov.stb.tag.model;

import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

import gov.stb.tag.helper.Cache;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCandidate extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence; // updated upon TgLicenceCreation

	private String uin;

	private String formerUin;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCandidateResult lastCandidateResult;

	@OneToMany(mappedBy = "tgCandidate")
	private Set<TgCandidateResult> tgCandidateResults;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getFormerUin() {
		return formerUin;
	}

	public void setFormerUin(String formerUin) {
		this.formerUin = formerUin;
	}

	public TgCandidateResult getLastCandidateResult() {
		return lastCandidateResult;
	}

	public void setLastCandidateResult(TgCandidateResult lastCandidateResult) {
		this.lastCandidateResult = lastCandidateResult;
	}

	public Set<TgCandidateResult> getTgCandidateResults() {
		return tgCandidateResults;
	}

	public void setTgCandidateResults(Set<TgCandidateResult> tgCandidateResults) {
		this.tgCandidateResults = tgCandidateResults;
	}

	public Set<Type> getGuidingLanguages() {
		if (tgCandidateResults != null) {
			return tgCandidateResults.stream().map(TgCandidateResult::getGuidingLanguage).collect(Collectors.toSet());
		}

		return null;
	}

	public Set<Type> getSpecializedAreas() {
		if (tgCandidateResults != null) {
			return tgCandidateResults.stream().map(TgCandidateResult::getSpecializedArea).collect(Collectors.toSet());
		}

		return null;
	}

	public Set<Type> getTiers() {
		if (tgCandidateResults != null) {
			return tgCandidateResults.stream().map(TgCandidateResult::getTier).collect(Collectors.toSet());
		}

		return null;
	}

	public String getGuidingLanguagesWithComma(Cache cache) {
		Mapper m = n -> cache.getLabel(n.getGuidingLanguage(), true);
		return toComma(m, cache);
	}

	public String getSpecializedAreasWithComma(Cache cache) {
		Mapper m = n -> cache.getLabel(n.getSpecializedArea(), true);
		return toComma(m, cache);
	}

	public String getTiersWithComma(Cache cache) {
		Mapper m = n -> cache.getLabel(n.getTier(), true);
		return toComma(m, cache);
	}

	private String toComma(Mapper m, Cache cache) {
		String text = "";
		if (tgCandidateResults != null) {
			text = tgCandidateResults.stream().map(n -> m.getLabel(n)).collect(Collectors.joining(", "));
		}

		return text;
	}

	interface Mapper {
		String getLabel(TgCandidateResult n);
	}

}
