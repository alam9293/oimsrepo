package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

import gov.stb.tag.helper.Cache;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCandidateResult extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCandidate tgCandidate;

	private String name;

	@Column(length = 320)
	private String email;

	private LocalDate examDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type guidingLanguage;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type specializedArea;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgTrainingProvider tgTrainingProvider;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status result; // competent, non-competent

	@ManyToOne(fetch = FetchType.LAZY)
	private Type selectedItinerary; // A to N

	@ManyToOne(fetch = FetchType.LAZY)
	private Type tier;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isForSwitchTier;

	private String assessor;

	private String deputyChiefAssessor;

	private String chiefAssessor;

	private String remarks;

	private String legacyId;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDirectIssuance;

	private LocalDate directIssuanceDate; // only for directIssuance

	@ManyToMany
	@JoinTable(name = "tg_candidate_result$di_guiding_language")
	private Set<Type> diGuidingLanguages = new HashSet<>(); // only for directIssurance

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	private Set<File> files = new HashSet<>(); // annotated with ManyToMany for tg_candidate_result$files mapping table

	private String billRefNo;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TgCandidate getTgCandidate() {
		return tgCandidate;
	}

	public void setTgCandidate(TgCandidate tgCandidate) {
		this.tgCandidate = tgCandidate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getExamDate() {
		return examDate;
	}

	public void setExamDate(LocalDate examDate) {
		this.examDate = examDate;
	}

	public Type getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(Type guidingLanguage) {
		this.guidingLanguage = guidingLanguage;
	}

	public Type getSpecializedArea() {
		return specializedArea;
	}

	public void setSpecializedArea(Type specializedArea) {
		this.specializedArea = specializedArea;
	}

	public TgTrainingProvider getTgTrainingProvider() {
		return tgTrainingProvider;
	}

	public void setTgTrainingProvider(TgTrainingProvider tgTrainingProvider) {
		this.tgTrainingProvider = tgTrainingProvider;
	}

	public Status getResult() {
		return result;
	}

	public void setResult(Status result) {
		this.result = result;
	}

	public Type getSelectedItinerary() {
		return selectedItinerary;
	}

	public void setSelectedItinerary(Type selectedItinerary) {
		this.selectedItinerary = selectedItinerary;
	}

	public Type getTier() {
		return tier;
	}

	public void setTier(Type tier) {
		this.tier = tier;
	}

	public Boolean isForSwitchTier() {
		return isForSwitchTier;
	}

	public void setIsForSwitchTier(Boolean isForSwitchTier) {
		this.isForSwitchTier = isForSwitchTier;
	}

	public String getAssessor() {
		return assessor;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public String getDeputyChiefAssessor() {
		return deputyChiefAssessor;
	}

	public void setDeputyChiefAssessor(String deputyChiefAssessor) {
		this.deputyChiefAssessor = deputyChiefAssessor;
	}

	public String getChiefAssessor() {
		return chiefAssessor;
	}

	public void setChiefAssessor(String chiefAssessor) {
		this.chiefAssessor = chiefAssessor;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

	public Boolean isDirectIssuance() {
		return isDirectIssuance;
	}

	public void setIsDirectIssuance(Boolean isDirectIssuance) {
		this.isDirectIssuance = isDirectIssuance;
	}

	public LocalDate getDirectIssuanceDate() {
		return directIssuanceDate;
	}

	public void setDirectIssuanceDate(LocalDate directIssuanceDate) {
		this.directIssuanceDate = directIssuanceDate;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public Set<Type> getDiGuidingLanguages() {
		return diGuidingLanguages;
	}

	public void setDiGuidingLanguages(Set<Type> diGuidingLanguages) {
		this.diGuidingLanguages = diGuidingLanguages;
	}

	public String getDiGuidingLanguagesWithComma(Cache cache) {
		return toComma(diGuidingLanguages, cache);
	}

	public String getBillRefNo() { return billRefNo; }

	public void setBillRefNo(String billRefNo) { this.billRefNo = billRefNo; }

	private String toComma(Set<Type> set, Cache cache) {
		String text = "";
		if (set != null) {
			List<Type> sortedType = new ArrayList<Type>(set); // set -> list
			Collections.sort(sortedType, (o1, o2) -> o1.getLabel().compareTo(o2.getLabel()));
			text = sortedType.stream().map(n -> cache.getLabel(n, true)).collect(Collectors.joining(", ")); // Sort the list
		}

		return text;
	}

}
