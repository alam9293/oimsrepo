package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableCodeEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourse extends AuditableCodeEntity {

	private String code;

	private String name;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type Category; // arts/heritage

	@ManyToOne(fetch = FetchType.LAZY)
	private Type language;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // MRC/PDC/ATO //course/re-assessment

	// private boolean adhoc; //use to verify if course is created for specific TG

	private LocalDate approvedStartDate;

	private LocalDate approvedEndDate;

	private BigDecimal noOfHours;

	private String ssgCourseCode;

	@Column(columnDefinition = "text")
	private String objective;

	@Column(columnDefinition = "text")
	private String outline;

	private BigDecimal classroomHrs;

	private BigDecimal outOfClassroomHrs;

	private BigDecimal courseFee;

	@Column(columnDefinition = "text")
	private String courseFeeNote;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgTrainingProvider tgTrainingProvider;

	@OneToMany(mappedBy = "tgCourse")
	@Where(clause = "isDeleted = 0")
	private Set<TgCourseAttendance> tgCourseAttendances;

	@OneToMany(mappedBy = "tgCourse")
	private Set<TgCourseSubsidy> tgCourseSubsidies;

	@OneToOne(fetch = FetchType.LAZY)
	private TgCourse parentTgCourse;

	@Override
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Type getCategory() {
		return Category;
	}

	public void setCategory(Type category) {
		Category = category;
	}

	public Type getLanguage() {
		return language;
	}

	public void setLanguage(Type language) {
		this.language = language;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public LocalDate getApprovedStartDate() {
		return approvedStartDate;
	}

	public void setApprovedStartDate(LocalDate approvedStartDate) {
		this.approvedStartDate = approvedStartDate;
	}

	public LocalDate getApprovedEndDate() {
		return approvedEndDate;
	}

	public void setApprovedEndDate(LocalDate approvedEndDate) {
		this.approvedEndDate = approvedEndDate;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

	public TgTrainingProvider getTgTrainingProvider() {
		return tgTrainingProvider;
	}

	public void setTgTrainingProvider(TgTrainingProvider tgTrainingProvider) {
		this.tgTrainingProvider = tgTrainingProvider;
	}

	public Set<TgCourseAttendance> getTgCourseAttendances() {
		return tgCourseAttendances;
	}

	public void setTgCourseAttendances(Set<TgCourseAttendance> tgCourseAttendances) {
		this.tgCourseAttendances = tgCourseAttendances;
	}

	public String getSsgCourseCode() {
		return ssgCourseCode;
	}

	public void setSsgCourseCode(String ssgCourseCode) {
		this.ssgCourseCode = ssgCourseCode;
	}

	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public String getOutline() {
		return outline;
	}

	public void setOutline(String outline) {
		this.outline = outline;
	}

	public BigDecimal getClassroomHrs() {
		return classroomHrs;
	}

	public void setClassroomHrs(BigDecimal classroomHrs) {
		this.classroomHrs = classroomHrs;
	}

	public BigDecimal getOutOfClassroomHrs() {
		return outOfClassroomHrs;
	}

	public void setOutOfClassroomHrs(BigDecimal outOfClassroomHrs) {
		this.outOfClassroomHrs = outOfClassroomHrs;
	}

	public BigDecimal getCourseFee() {
		return courseFee;
	}

	public void setCourseFee(BigDecimal courseFee) {
		this.courseFee = courseFee;
	}

	public String getCourseFeeNote() {
		return courseFeeNote;
	}

	public void setCourseFeeNote(String courseFeeNote) {
		this.courseFeeNote = courseFeeNote;
	}

	public Set<TgCourseSubsidy> getTgCourseSubsidies() {
		return tgCourseSubsidies;
	}

	public void setTgCourseSubsidies(Set<TgCourseSubsidy> tgCourseSubsidies) {
		this.tgCourseSubsidies = tgCourseSubsidies;
	}

	public TgCourse getParentTgCourse() {
		return parentTgCourse;
	}

	public void setParentTgCourse(TgCourse parentTgCourse) {
		this.parentTgCourse = parentTgCourse;
	}

}
