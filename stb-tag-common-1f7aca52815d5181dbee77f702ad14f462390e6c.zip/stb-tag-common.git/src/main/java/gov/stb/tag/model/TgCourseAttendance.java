package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourseAttendance extends AuditableIdEntity {

	private Integer id;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	private LocalDate attendedDate;

	private LocalDate attendedEndDate;

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	private Set<File> files = new HashSet<>(); // annotated with ManyToMany for workflow_action$files mapping table

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCourse tgCourse;

	@OneToMany(mappedBy = "tgCourseAttendance")
	@Where(clause = "isDeleted = 0")
	private Set<TgCourseAttendanceDetail> tgCourseAttendanceDetails;

	@OneToOne
	private Application application;

	private String legacyId;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public LocalDate getAttendedDate() {
		return attendedDate;
	}

	public void setAttendedDate(LocalDate attendedDate) {
		this.attendedDate = attendedDate;
	}

	public LocalDate getAttendedEndDate() {
		return attendedEndDate;
	}

	public void setAttendedEndDate(LocalDate attendedEndDate) {
		this.attendedEndDate = attendedEndDate;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public TgCourse getTgCourse() {
		return tgCourse;
	}

	public void setTgCourse(TgCourse tgCourse) {
		this.tgCourse = tgCourse;
	}

	public Set<TgCourseAttendanceDetail> getTgCourseAttendanceDetails() {
		return tgCourseAttendanceDetails;
	}

	public void setTgCourseAttendanceDetails(Set<TgCourseAttendanceDetail> tgCourseAttendanceDetails) {
		this.tgCourseAttendanceDetails = tgCourseAttendanceDetails;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}
}
