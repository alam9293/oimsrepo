package gov.stb.tag.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourseAttendanceDetail extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TouristGuide touristGuide;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type attendance; // attended/absent

	private LocalDate completionDate;

	private Integer score;

	private Integer maxScore;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type result; // pass/fail

	private Type type;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCourseAttendance tgCourseAttendance;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private boolean isDeleted;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TouristGuide getTouristGuide() {
		return touristGuide;
	}

	public void setTouristGuide(TouristGuide touristGuide) {
		this.touristGuide = touristGuide;
	}

	public Type getAttendance() {
		return attendance;
	}

	public void setAttendance(Type attendance) {
		this.attendance = attendance;
	}

	public LocalDate getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(LocalDate completionDate) {
		this.completionDate = completionDate;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(Integer maxScore) {
		this.maxScore = maxScore;
	}

	public Type getResult() {
		return result;
	}

	public void setResult(Type result) {
		this.result = result;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public TgCourseAttendance getTgCourseAttendance() {
		return tgCourseAttendance;
	}

	public void setTgCourseAttendance(TgCourseAttendance tgCourseAttendance) {
		this.tgCourseAttendance = tgCourseAttendance;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public BigDecimal getScoreInPercent() {
		return new BigDecimal((double) this.score / (double) this.maxScore * 100).setScale(2, RoundingMode.HALF_EVEN);
	}

}
