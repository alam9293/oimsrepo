package gov.stb.tag.model;

import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourseCreation extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	private String name;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type Category; // arts/heritage

	@ManyToOne(fetch = FetchType.LAZY)
	private Type language;

	private BigDecimal noOfHours;

	private String ssgCourseCode;

	@Column(columnDefinition = "text")
	private String objective;

	@Column(columnDefinition = "text")
	private String outline;

	private BigDecimal classroomHrs;

	private BigDecimal outOfClassroomHrs;

	private BigDecimal courseFee;

	@Column(columnDefinition = "text")
	private String courseFeeNote;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgTrainingProvider tgTrainingProvider;

	private String trainers;

	// @Column(columnDefinition = "text")
	// private String appropriateLevel;

	@Column(columnDefinition = "text")
	private String assessment;

	@Column(columnDefinition = "text")
	private String synopsis;

	@OneToMany(mappedBy = "tgCourseCreation")
	private Set<TgCourseSubsidy> tgCourseSubsidies;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Type getCategory() {
		return Category;
	}

	public void setCategory(Type category) {
		Category = category;
	}

	public Type getLanguage() {
		return language;
	}

	public void setLanguage(Type language) {
		this.language = language;
	}

	public BigDecimal getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(BigDecimal noOfHours) {
		this.noOfHours = noOfHours;
	}

	public String getSsgCourseCode() {
		return ssgCourseCode;
	}

	public void setSsgCourseCode(String ssgCourseCode) {
		this.ssgCourseCode = ssgCourseCode;
	}

	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public String getOutline() {
		return outline;
	}

	public void setOutline(String outline) {
		this.outline = outline;
	}

	public BigDecimal getClassroomHrs() {
		return classroomHrs;
	}

	public void setClassroomHrs(BigDecimal classroomHrs) {
		this.classroomHrs = classroomHrs;
	}

	public BigDecimal getOutOfClassroomHrs() {
		return outOfClassroomHrs;
	}

	public void setOutOfClassroomHrs(BigDecimal outOfClassroomHrs) {
		this.outOfClassroomHrs = outOfClassroomHrs;
	}

	public BigDecimal getCourseFee() {
		return courseFee;
	}

	public void setCourseFee(BigDecimal courseFee) {
		this.courseFee = courseFee;
	}

	public String getCourseFeeNote() {
		return courseFeeNote;
	}

	public void setCourseFeeNote(String courseFeeNote) {
		this.courseFeeNote = courseFeeNote;
	}

	public TgTrainingProvider getTgTrainingProvider() {
		return tgTrainingProvider;
	}

	public void setTgTrainingProvider(TgTrainingProvider tgTrainingProvider) {
		this.tgTrainingProvider = tgTrainingProvider;
	}

	// public String getAppropriateLevel() {
	// return appropriateLevel;
	// }
	//
	// public void setAppropriateLevel(String appropriateLevel) {
	// this.appropriateLevel = appropriateLevel;
	// }

	public String getAssessment() {
		return assessment;
	}

	public void setAssessment(String assessment) {
		this.assessment = assessment;
	}

	public String getSynopsis() {
		return synopsis;
	}

	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	public String getTrainers() {
		return trainers;
	}

	public void setTrainers(String trainers) {
		this.trainers = trainers;
	}

	public Set<TgCourseSubsidy> getTgCourseSubsidies() {
		return tgCourseSubsidies;
	}

	public void setTgCourseSubsidies(Set<TgCourseSubsidy> tgCourseSubsidies) {
		this.tgCourseSubsidies = tgCourseSubsidies;
	}

}
