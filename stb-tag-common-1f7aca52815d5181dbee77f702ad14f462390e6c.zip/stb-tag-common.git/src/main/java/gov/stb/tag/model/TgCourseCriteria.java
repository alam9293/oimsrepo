package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourseCriteria extends AuditableIdEntity {

	private Integer id;

	private String criteria;

	@Column(nullable = false, columnDefinition = "BIT(1) default 1")
	private Boolean isActive;

	private BigDecimal weightage1;

	private BigDecimal weightage2;

	private BigDecimal weightage3;

	private BigDecimal weightage4;

	private BigDecimal weightage5;

	private Integer ordinal;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	public BigDecimal getWeightage1() {
		return weightage1;
	}

	public void setWeightage1(BigDecimal weightage1) {
		this.weightage1 = weightage1;
	}

	public BigDecimal getWeightage2() {
		return weightage2;
	}

	public void setWeightage2(BigDecimal weightage2) {
		this.weightage2 = weightage2;
	}

	public BigDecimal getWeightage3() {
		return weightage3;
	}

	public void setWeightage3(BigDecimal weightage3) {
		this.weightage3 = weightage3;
	}

	public BigDecimal getWeightage4() {
		return weightage4;
	}

	public void setWeightage4(BigDecimal weightage4) {
		this.weightage4 = weightage4;
	}

	public BigDecimal getWeightage5() {
		return weightage5;
	}

	public void setWeightage5(BigDecimal weightage5) {
		this.weightage5 = weightage5;
	}

	public Boolean isActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(Integer ordinal) {
		this.ordinal = ordinal;
	}

}
