package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourseEvaluation extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCourseRenewal tgCourseRenewal;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCourseCriteria tgCourseCriteria;

	private Integer rating;

	private BigDecimal weightage;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TgCourseRenewal getTgCourseRenewal() {
		return tgCourseRenewal;
	}

	public void setTgCourseRenewal(TgCourseRenewal tgCourseRenewal) {
		this.tgCourseRenewal = tgCourseRenewal;
	}

	public TgCourseCriteria getTgCourseCriteria() {
		return tgCourseCriteria;
	}

	public void setTgCourseCriteria(TgCourseCriteria tgCourseCriteria) {
		this.tgCourseCriteria = tgCourseCriteria;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public BigDecimal getWeightage() {
		return weightage;
	}

	public void setWeightage(BigDecimal weightage) {
		this.weightage = weightage;
	}

}
