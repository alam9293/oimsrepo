package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourseRenewal extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@ManyToOne
	private TgCourse tgCourse;

	@OneToMany(mappedBy = "tgCourseRenewal")
	private Set<TgCourseEvaluation> tgCourseEvaluation;

	private String remarks;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Set<TgCourseEvaluation> getTgCourseEvaluation() {
		return tgCourseEvaluation;
	}

	public void setTgCourseEvaluation(Set<TgCourseEvaluation> tgCourseEvaluation) {
		this.tgCourseEvaluation = tgCourseEvaluation;
	}

	public TgCourse getTgCourse() {
		return tgCourse;
	}

	public void setTgCourse(TgCourse tgCourse) {
		this.tgCourse = tgCourse;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
