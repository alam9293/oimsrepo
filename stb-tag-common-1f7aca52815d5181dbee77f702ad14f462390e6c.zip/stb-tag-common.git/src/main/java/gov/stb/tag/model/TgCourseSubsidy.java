package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgCourseSubsidy extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCourse tgCourse;

	private BigDecimal fee;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCourseCreation tgCourseCreation;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TgCourse getTgCourse() {
		return tgCourse;
	}

	public void setTgCourse(TgCourse tgCourse) {
		this.tgCourse = tgCourse;
	}

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public TgCourseCreation getTgCourseCreation() {
		return tgCourseCreation;
	}

	public void setTgCourseCreation(TgCourseCreation tgCourseCreation) {
		this.tgCourseCreation = tgCourseCreation;
	}

}
