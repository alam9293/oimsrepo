package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgInfo extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private TouristGuide touristGuide;

	private String personName;// Person/company providing the feedback

	private String companyName;// (If Applicable)

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // compliment, Complaint, Others (please specify)

	private String typeOther;

	@Column(length = 5000)
	private String details;

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	private Set<File> files = new HashSet<>(); // annotated with ManyToMany for tg_info$files mapping table

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TouristGuide getTouristGuide() {
		return touristGuide;
	}

	public String getPersonName() {
		return personName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public Type getType() {
		return type;
	}

	public String getTypeOther() {
		return typeOther;
	}

	public String getDetails() {
		return details;
	}

	public Set<File> getFiles() {
		return files;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setTouristGuide(TouristGuide touristGuide) {
		this.touristGuide = touristGuide;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public void setTypeOther(String typeOther) {
		this.typeOther = typeOther;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
}
