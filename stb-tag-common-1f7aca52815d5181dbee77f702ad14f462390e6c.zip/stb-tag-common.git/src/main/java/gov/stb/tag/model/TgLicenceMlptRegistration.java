package gov.stb.tag.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgLicenceMlptRegistration extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgMlpt tgMlpt;

	private String appFeeBillRefNo;

	private String printFeeBillRefNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isForReinstatement;

	@OneToMany(mappedBy = "tgLicenceMlptRegistration")
	private Set<TgMlptSlot> tgMlptSlots;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public TgMlpt getTgMlpt() {
		return tgMlpt;
	}

	public void setTgMlpt(TgMlpt tgMlpt) {
		this.tgMlpt = tgMlpt;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public String getPrintFeeBillRefNo() {
		return printFeeBillRefNo;
	}

	public void setPrintFeeBillRefNo(String printFeeBillRefNo) {
		this.printFeeBillRefNo = printFeeBillRefNo;
	}

	public Boolean isForReinstatement() {
		return isForReinstatement;
	}

	public void setIsForReinstatement(Boolean isForReinstatement) {
		this.isForReinstatement = isForReinstatement;
	}

	public Set<TgMlptSlot> getTgMlptSlots() {
		return tgMlptSlots;
	}

	public void setTgMlptSlots(Set<TgMlptSlot> tgMlptSlots) {
		this.tgMlptSlots = tgMlptSlots;
	}
}
