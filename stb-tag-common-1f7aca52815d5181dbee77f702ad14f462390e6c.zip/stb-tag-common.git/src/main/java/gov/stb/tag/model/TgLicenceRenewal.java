package gov.stb.tag.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgLicenceRenewal extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // renewal, reinstate

	@OneToOne
	private Application application;

	private String appFeeBillRefNo;

	private LocalDate medicalDate;

	private LocalDate previousLicenceStartDate; // previous cycle start date

	private LocalDate previousLicenceExpiryDate; // previous cycle expiry date

	private LocalDate licenceStartDate; // renewal cycle start date

	private LocalDate licenceExpiryDate; // renewal cycle expiry date

	// Declaration

	private LocalDateTime offenceDeclaredDate;

	private LocalDate offenceDate;

	private String offenceType;

	private String enforcementOutcome;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasConsentMobileNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasConsentEmailAddress;

	// Indication

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean cpfDeclared;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasNoAssignment;

	// RFA
	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasRfaNewPhoto;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasRfaMedicalReport;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasRfaWorkPass;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasRfaCpf;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status medisavePaymentStatus;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public LocalDate getLicenceStartDate() {
		return licenceStartDate;
	}

	public void setLicenceStartDate(LocalDate licenceStartDate) {
		this.licenceStartDate = licenceStartDate;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public LocalDate getMedicalDate() {
		return medicalDate;
	}

	public void setMedicalDate(LocalDate medicalDate) {
		this.medicalDate = medicalDate;
	}

	public LocalDateTime getOffenceDeclaredDate() {
		return offenceDeclaredDate;
	}

	public void setOffenceDeclaredDate(LocalDateTime offenceDeclaredDate) {
		this.offenceDeclaredDate = offenceDeclaredDate;
	}

	public LocalDate getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDate offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public String getEnforcementOutcome() {
		return enforcementOutcome;
	}

	public void setEnforcementOutcome(String enforcementOutcome) {
		this.enforcementOutcome = enforcementOutcome;
	}

	public Boolean getHasConsentMobileNo() {
		return hasConsentMobileNo;
	}

	public void setHasConsentMobileNo(Boolean hasConsentMobileNo) {
		this.hasConsentMobileNo = hasConsentMobileNo;
	}

	public Boolean getHasConsentEmailAddress() {
		return hasConsentEmailAddress;
	}

	public void setHasConsentEmailAddress(Boolean hasConsentEmailAddress) {
		this.hasConsentEmailAddress = hasConsentEmailAddress;
	}

	public Boolean getHasRfaNewPhoto() {
		return hasRfaNewPhoto;
	}

	public void setHasRfaNewPhoto(Boolean hasRfaNewPhoto) {
		this.hasRfaNewPhoto = hasRfaNewPhoto;
	}

	public Boolean getHasRfaMedicalReport() {
		return hasRfaMedicalReport;
	}

	public void setHasRfaMedicalReport(Boolean hasRfaMedicalReport) {
		this.hasRfaMedicalReport = hasRfaMedicalReport;
	}

	public Boolean getHasRfaWorkPass() {
		return hasRfaWorkPass;
	}

	public void setHasRfaWorkPass(Boolean hasRfaWorkPass) {
		this.hasRfaWorkPass = hasRfaWorkPass;
	}

	public Boolean getHasRfaCpf() {
		return hasRfaCpf;
	}

	public void setHasRfaCpf(Boolean hasRfaCpf) {
		this.hasRfaCpf = hasRfaCpf;
	}

	public Boolean isCpfDeclared() {
		return cpfDeclared;
	}

	public void setCpfDeclared(Boolean cpfDeclared) {
		this.cpfDeclared = cpfDeclared;
	}

	public Boolean isHasNoAssignment() {
		return hasNoAssignment;
	}

	public void setHasNoAssignment(Boolean hasNoAssignment) {
		this.hasNoAssignment = hasNoAssignment;
	}

	public LocalDate getPreviousLicenceStartDate() {
		return previousLicenceStartDate;
	}

	public void setPreviousLicenceStartDate(LocalDate previousLicenceStartDate) {
		this.previousLicenceStartDate = previousLicenceStartDate;
	}

	public LocalDate getPreviousLicenceExpiryDate() {
		return previousLicenceExpiryDate;
	}

	public void setPreviousLicenceExpiryDate(LocalDate previousLicenceExpiryDate) {
		this.previousLicenceExpiryDate = previousLicenceExpiryDate;
	}

	public Status getMedisavePaymentStatus() {
		return medisavePaymentStatus;
	}

	public void setMedisavePaymentStatus(Status medisavePaymentStatus) {
		this.medisavePaymentStatus = medisavePaymentStatus;
	}

}
