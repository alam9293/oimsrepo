package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgLicenceTierSwitch extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type oldLicenceTier;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type newLicenceTier;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type specializedArea;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgCandidateResult tgCandidateResult;

	private String appFeeBillRefNo;

	private LocalDate startDate;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean pendingSwitch;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Type getOldLicenceTier() {
		return oldLicenceTier;
	}

	public void setOldLicenceTier(Type oldLicenceTier) {
		this.oldLicenceTier = oldLicenceTier;
	}

	public Type getNewLicenceTier() {
		return newLicenceTier;
	}

	public void setNewLicenceTier(Type newLicenceTier) {
		this.newLicenceTier = newLicenceTier;
	}

	public Type getSpecializedArea() {
		return specializedArea;
	}

	public void setSpecializedArea(Type specializedArea) {
		this.specializedArea = specializedArea;
	}

	public TgCandidateResult getTgCandidateResult() {
		return tgCandidateResult;
	}

	public void setTgCandidateResult(TgCandidateResult tgCandidateResult) {
		this.tgCandidateResult = tgCandidateResult;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public Boolean getPendingSwitch() {
		return pendingSwitch;
	}

	public void setPendingSwitch(Boolean pendingSwitch) {
		this.pendingSwitch = pendingSwitch;
	}

}
