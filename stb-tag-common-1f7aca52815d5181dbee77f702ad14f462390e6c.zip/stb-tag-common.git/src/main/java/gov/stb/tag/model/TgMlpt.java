package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgMlpt extends AuditableIdEntity {

	private Integer id;

	private String name;

	private LocalDate regStartDate;

	private LocalDate regEndDate;

	private LocalDate mlptStartDate;

	private LocalDate mlptEndDate;

	@Column(length = 5000)
	private String remarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status allocationStatus; // draft, published

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	@OneToMany(mappedBy = "tgMlpt")
	private Set<TgLicenceMlptRegistration> tgLicenceMlptRegistrations;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getRegStartDate() {
		return regStartDate;
	}

	public void setRegStartDate(LocalDate regStartDate) {
		this.regStartDate = regStartDate;
	}

	public LocalDate getRegEndDate() {
		return regEndDate;
	}

	public void setRegEndDate(LocalDate regEndDate) {
		this.regEndDate = regEndDate;
	}

	public LocalDate getMlptStartDate() {
		return mlptStartDate;
	}

	public void setMlptStartDate(LocalDate mlptStartDate) {
		this.mlptStartDate = mlptStartDate;
	}

	public LocalDate getMlptEndDate() {
		return mlptEndDate;
	}

	public void setMlptEndDate(LocalDate mlptEndDate) {
		this.mlptEndDate = mlptEndDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Status getAllocationStatus() {
		return allocationStatus;
	}

	public void setAllocationStatus(Status allocationStatus) {
		this.allocationStatus = allocationStatus;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Set<TgLicenceMlptRegistration> getTgLicenceMlptRegistrations() {
		return tgLicenceMlptRegistrations;
	}

	public void setTgLicenceMlptRegistrations(Set<TgLicenceMlptRegistration> tgLicenceMlptRegistrations) {
		this.tgLicenceMlptRegistrations = tgLicenceMlptRegistrations;
	}

}
