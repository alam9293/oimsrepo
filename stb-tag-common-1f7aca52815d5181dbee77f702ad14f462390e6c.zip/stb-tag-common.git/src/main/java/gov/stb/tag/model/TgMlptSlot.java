package gov.stb.tag.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgMlptSlot extends AuditableIdEntity {

	private Integer id;

	private LocalDateTime startTime;

	@ManyToOne(fetch = FetchType.LAZY)
	private TgLicenceMlptRegistration tgLicenceMlptRegistration;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type guidingLanguage;

	private String assessor; // languageAssessor

	private String chiefAssessor;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status resultStatus;

	private LocalDateTime resultSentDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private File resultFile;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public TgLicenceMlptRegistration getTgLicenceMlptRegistration() {
		return tgLicenceMlptRegistration;
	}

	public void setTgLicenceMlptRegistration(TgLicenceMlptRegistration tgLicenceMlptRegistration) {
		this.tgLicenceMlptRegistration = tgLicenceMlptRegistration;
	}

	public Type getGuidingLanguage() {
		return guidingLanguage;
	}

	public void setGuidingLanguage(Type guidingLanguage) {
		this.guidingLanguage = guidingLanguage;
	}

	public String getAssessor() {
		return assessor;
	}

	public void setAssessor(String assessor) {
		this.assessor = assessor;
	}

	public String getChiefAssessor() {
		return chiefAssessor;
	}

	public void setChiefAssessor(String chiefAssessor) {
		this.chiefAssessor = chiefAssessor;
	}

	public Status getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(Status resultStatus) {
		this.resultStatus = resultStatus;
	}

	public LocalDateTime getResultSentDate() {
		return resultSentDate;
	}

	public void setResultSentDate(LocalDateTime resultSentDate) {
		this.resultSentDate = resultSentDate;
	}

	public File getResultFile() {
		return resultFile;
	}

	public void setResultFile(File resultFile) {
		this.resultFile = resultFile;
	}

}
