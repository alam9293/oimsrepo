package gov.stb.tag.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgPersonUpdate extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	@OneToOne
	private TgPersonUpdate previousValue; // snapshot of the current values

	// for retrieval of LicenceCreation, the application.licence will still be null, use uin or portalId instead
	private String uin;

	// for retrieval of LicenceCreation, the application.licence will still be null, use uin or portalId instead
	@ManyToOne(fetch = FetchType.LAZY)
	private User user;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type salutation; // don't think myInfo provide this

	private String name; // if TG login and system detect change, pro-actively prompt user to apply for TgPersonUpdate

	private LocalDate dob;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type sex;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type maritalStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type race;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type nationality;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type birthCountry;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type residentialStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type highestEduLevel;

	private String mobileNo;

	@Column(length = 320)
	private String emailAddress;

	private String employerName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type occupation;

	private String occupationOther;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type workPassType;

	private LocalDate workpassExpiryDate;

	private String aliasName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address registeredAddress;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address operatingAddress; // Address ID can be the same as registeredAddress

	private LocalDateTime offenceDeclaredDate;

	private LocalDate offenceDate;

	private String offenceType;

	private String enforcementOutcome;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasConsentMobileNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasConsentEmailAddress;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isMyInfoPopulated;

	private String appFeeBillRefNo;

	@OneToOne(fetch = FetchType.LAZY)
	private File photo;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public TgPersonUpdate getPreviousValue() {
		return previousValue;
	}

	public void setPreviousValue(TgPersonUpdate previousValue) {
		this.previousValue = previousValue;
	}

	public Type getSalutation() {
		return salutation;
	}

	public void setSalutation(Type salutation) {
		this.salutation = salutation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Type getSex() {
		return sex;
	}

	public void setSex(Type sex) {
		this.sex = sex;
	}

	public Type getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(Type maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Type getRace() {
		return race;
	}

	public void setRace(Type race) {
		this.race = race;
	}

	public Type getNationality() {
		return nationality;
	}

	public void setNationality(Type nationality) {
		this.nationality = nationality;
	}

	public Type getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(Type birthCountry) {
		this.birthCountry = birthCountry;
	}

	public Type getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(Type residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public Type getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(Type highestEduLevel) {
		this.highestEduLevel = highestEduLevel;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public Type getOccupation() {
		return occupation;
	}

	public void setOccupation(Type occupation) {
		this.occupation = occupation;
	}

	public String getOccupationOther() {
		return occupationOther;
	}

	public void setOccupationOther(String occupationOther) {
		this.occupationOther = occupationOther;
	}

	public Type getWorkPassType() {
		return workPassType;
	}

	public void setWorkPassType(Type workPassType) {
		this.workPassType = workPassType;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public Address getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(Address registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public Address getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(Address operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public LocalDateTime getOffenceDeclaredDate() {
		return offenceDeclaredDate;
	}

	public void setOffenceDeclaredDate(LocalDateTime offenceDeclaredDate) {
		this.offenceDeclaredDate = offenceDeclaredDate;
	}

	public LocalDate getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDate offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public String getEnforcementOutcome() {
		return enforcementOutcome;
	}

	public void setEnforcementOutcome(String enforcementOutcome) {
		this.enforcementOutcome = enforcementOutcome;
	}

	public Boolean hasConsentMobileNo() {
		return hasConsentMobileNo;
	}

	public void setHasConsentMobileNo(Boolean hasConsentMobileNo) {
		this.hasConsentMobileNo = hasConsentMobileNo;
	}

	public Boolean hasConsentEmailAddress() {
		return hasConsentEmailAddress;
	}

	public void setHasConsentEmailAddress(Boolean hasConsentEmailAddress) {
		this.hasConsentEmailAddress = hasConsentEmailAddress;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public LocalDate getWorkpassExpiryDate() {
		return workpassExpiryDate;
	}

	public void setWorkpassExpiryDate(LocalDate workpassExpiryDate) {
		this.workpassExpiryDate = workpassExpiryDate;
	}

	public Boolean isMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	public String getAppFeeBillRefNo() {
		return appFeeBillRefNo;
	}

	public void setAppFeeBillRefNo(String appFeeBillRefNo) {
		this.appFeeBillRefNo = appFeeBillRefNo;
	}

	public File getPhoto() {
		return photo;
	}

	public void setPhoto(File photo) {
		this.photo = photo;
	}

}
