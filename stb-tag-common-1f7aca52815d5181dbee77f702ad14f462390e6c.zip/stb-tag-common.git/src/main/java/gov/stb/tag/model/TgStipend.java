package gov.stb.tag.model;

import java.math.BigDecimal;

import javax.persistence.*;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgStipend extends AuditableIdEntity {

	private Integer id;

	@OneToOne
	private Application application;

	private String nameAsPerBank;

	private String bankName;

	private String bankCode;

	private String bankBranchCode;

	private String bankAccountNo;

	private BigDecimal amount;// snapshot for viewing

	private String appBillRefNo; // to track the payout status

	@ManyToOne(fetch = FetchType.LAZY)
	private Type residentialStatus; // snapshot for viewing

	private String guidingLanguages; // snapshot for viewing

	@OneToOne
	private TgStipendConfig tgStipendConfig;

    @Column(nullable = false, columnDefinition = "BIT(1) default 0")
    private Boolean isPendingFollowUp;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasFollowUpRequiredByFinance;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getNameAsPerBank() {
		return nameAsPerBank;
	}

	public void setNameAsPerBank(String nameAsPerBank) {
		this.nameAsPerBank = nameAsPerBank;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankBranchCode() {
		return bankBranchCode;
	}

	public void setBankBranchCode(String bankBranchCode) {
		this.bankBranchCode = bankBranchCode;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getAppBillRefNo() {
		return appBillRefNo;
	}

	public void setAppBillRefNo(String appBillRefNo) {
		this.appBillRefNo = appBillRefNo;
	}

	public Type getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(Type residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public String getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(String guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public TgStipendConfig getTgStipendConfig() {
		return tgStipendConfig;
	}

	public void setTgStipendConfig(TgStipendConfig tgStipendConfig) {
		this.tgStipendConfig = tgStipendConfig;
	}

	public Boolean isPendingFollowUp() { return isPendingFollowUp; }

	public void setIsPendingFollowUp(Boolean isPendingFollowUp) { this.isPendingFollowUp = isPendingFollowUp; }

	public Boolean getHasFollowUpRequiredByFinance() { return hasFollowUpRequiredByFinance; }

	public void setHasFollowUpRequiredByFinance(Boolean hasFollowUpRequiredByFinance) { this.hasFollowUpRequiredByFinance = hasFollowUpRequiredByFinance; }
}
