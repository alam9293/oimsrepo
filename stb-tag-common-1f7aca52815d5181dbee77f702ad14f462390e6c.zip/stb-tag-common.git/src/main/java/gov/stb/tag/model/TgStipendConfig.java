package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgStipendConfig extends AuditableIdEntity {

	private Integer id;

	private LocalDate periodStartDate;

	private LocalDate periodEndDate;

	private LocalDate licenceStartBefore;

	@Column(length = 5000)
	private String guidingLanguages;// TG language codes e.g. TG_LANG_MAN,TG_LANG_ENG

	private BigDecimal amount;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean forAppeal;

	@Column(columnDefinition = "text")
	private String preamble;

	@Column(length = 5000)
	private String supportingDocText;

	@Column(length = 5000)
	private String declaration;

	@ManyToMany
	@JoinTable(name = "tg_stipend$appeal_tg")
	private Set<TouristGuide> appealTgs;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getPeriodStartDate() {
		return periodStartDate;
	}

	public void setPeriodStartDate(LocalDate periodStartDate) {
		this.periodStartDate = periodStartDate;
	}

	public void setPeriodEndDate(LocalDate periodEndDate) {
		this.periodEndDate = periodEndDate;
	}

	public LocalDate getPeriodEndDate() {
		return periodEndDate;
	}

	public LocalDate getLicenceStartBefore() {
		return licenceStartBefore;
	}

	public void setLicenceStartBefore(LocalDate licenceStartBefore) {
		this.licenceStartBefore = licenceStartBefore;
	}

	public Boolean getForAppeal() {
		return forAppeal;
	}

	public void setForAppeal(Boolean forAppeal) {
		this.forAppeal = forAppeal;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getPreamble() {
		return preamble;
	}

	public void setPreamble(String preamble) {
		this.preamble = preamble;
	}

	public String getDeclaration() {
		return declaration;
	}

	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}

	public String getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(String guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public Set<TouristGuide> getAppealTgs() {
		return appealTgs;
	}

	public void setAppealTgs(Set<TouristGuide> appealTgs) {
		this.appealTgs = appealTgs;
	}

	public String getSupportingDocText() {
		return supportingDocText;
	}

	public void setSupportingDocText(String supportingDocText) {
		this.supportingDocText = supportingDocText;
	}

}
