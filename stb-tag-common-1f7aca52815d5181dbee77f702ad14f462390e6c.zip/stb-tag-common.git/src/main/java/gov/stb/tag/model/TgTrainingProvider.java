package gov.stb.tag.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;
import com.wiz.model.api.Listable;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TgTrainingProvider extends AuditableIdEntity implements Listable {

	private Integer id;

	private String uen;

	private String name;

	private String contactPerson;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address address;

	@Column(length = 320)
	private String email;

	private String contactNo;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	@OneToMany(mappedBy = "tgTrainingProvider")
	private Set<TgCourse> tgCourses;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isPdc;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isMrc;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isAto;

	private String legacyId;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDeleted;

	private String contactPerson1;

	@Column(length = 320)
	private String email1;

	private String contactNo1;

	@Column(columnDefinition = "text")
	private String profileSummary;

	private String webLink;

	private String signUpLink;

	@ManyToMany
	private Set<Alert> alerts = new HashSet<>();

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Set<TgCourse> getTgCourses() {
		return tgCourses;
	}

	public void setTgCourses(Set<TgCourse> tgCourses) {
		this.tgCourses = tgCourses;
	}

	public Boolean isPdc() {
		return isPdc;
	}

	public void setIsPdc(Boolean isPdc) {
		this.isPdc = isPdc;
	}

	public Boolean isMrc() {
		return isMrc;
	}

	public void setIsMrc(Boolean isMrc) {
		this.isMrc = isMrc;
	}

	public Boolean isAto() {
		return isAto;
	}

	public void setIsAto(Boolean isAto) {
		this.isAto = isAto;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

	@Override
	public String getLabel() {
		return getName();
	}

	@Override
	public String getOtherLabel() {
		return getName();
	}

	@Override
	public Serializable getKey() {
		return id;
	}

	public Boolean isDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getContactPerson1() {
		return contactPerson1;
	}

	public void setContactPerson1(String contactPerson1) {
		this.contactPerson1 = contactPerson1;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getContactNo1() {
		return contactNo1;
	}

	public void setContactNo1(String contactNo1) {
		this.contactNo1 = contactNo1;
	}

	public String getProfileSummary() {
		return profileSummary;
	}

	public void setProfileSummary(String profileSummary) {
		this.profileSummary = profileSummary;
	}

	public String getWebLink() {
		return webLink;
	}

	public void setWebLink(String webLink) {
		this.webLink = webLink;
	}

	public String getSignUpLink() {
		return signUpLink;
	}

	public void setSignUpLink(String signUpLink) {
		this.signUpLink = signUpLink;
	}

	public Set<Alert> getAlerts() {
		return alerts;
	}

	public void setAlerts(Set<Alert> alerts) {
		this.alerts = alerts;
	}

}