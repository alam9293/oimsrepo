package gov.stb.tag.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

import gov.stb.tag.helper.Cache;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TouristGuide extends AuditableIdEntity {

	private Integer id;

	@OneToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@OneToOne(fetch = FetchType.LAZY)
	private File photo;

	private String uin;

	private String formerUin;

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "touristGuide")
	private User user; // Portal ID

	@ManyToOne(fetch = FetchType.LAZY)
	private Type salutation; // don't think myInfo provide this

	private String name;

	private LocalDate dob;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type sex;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type maritalStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type race;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type nationality;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type birthCountry;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type residentialStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type highestEduLevel;

	private String mobileNo;

	@Column(length = 320)
	private String emailAddress;

	private String employerName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type occupation;

	private String occupationOther;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type workPassType;

	private LocalDate workPassExpiryDate;

	private String aliasName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address registeredAddress;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address mailingAddress; // Address ID can be the same as registeredAddress

	private LocalDateTime offenceDeclaredDate;

	private LocalDate offenceDate;

	private String offenceType;

	private String enforcementOutcome;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasConsentMobileNo;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasConsentEmailAddress;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasPassedOn;

	private String legacyId;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean hasPersonUpdateAccess;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isMyInfoPopulated;

	@OneToMany(mappedBy = "touristGuide")
	private Set<TgAssignment> tgAssignments;

	@OneToMany(mappedBy = "touristGuide")
	private Set<TgCourseAttendanceDetail> tgCourseAttendanceDetails;

	@ManyToMany
	@JoinTable(name = "tourist_guide$guiding_language")
	private Set<Type> guidingLanguages = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "tourist_guide$specialized_area")
	private Set<Type> specializedAreas = new HashSet<>();

	@ManyToMany
	private Set<Alert> alerts = new HashSet<>();

	private String displayEmployerName;

	private String displayName;

	private String displaySecondEmployerName;

	private String displaySecondName;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public File getPhoto() {
		return photo;
	}

	public void setPhoto(File photo) {
		this.photo = photo;
	}

	public String getUin() {
		return uin;
	}

	public void setUin(String uin) {
		this.uin = uin;
	}

	public String getFormerUin() {
		return formerUin;
	}

	public void setFormerUin(String formerUin) {
		this.formerUin = formerUin;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Type getSalutation() {
		return salutation;
	}

	public void setSalutation(Type salutation) {
		this.salutation = salutation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Type getSex() {
		return sex;
	}

	public void setSex(Type sex) {
		this.sex = sex;
	}

	public Type getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(Type maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Type getRace() {
		return race;
	}

	public void setRace(Type race) {
		this.race = race;
	}

	public Type getNationality() {
		return nationality;
	}

	public void setNationality(Type nationality) {
		this.nationality = nationality;
	}

	public Type getBirthCountry() {
		return birthCountry;
	}

	public void setBirthCountry(Type birthCountry) {
		this.birthCountry = birthCountry;
	}

	public Type getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(Type residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public Type getHighestEduLevel() {
		return highestEduLevel;
	}

	public void setHighestEduLevel(Type highestEducLevel) {
		this.highestEduLevel = highestEducLevel;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public Type getOccupation() {
		return occupation;
	}

	public void setOccupation(Type occupation) {
		this.occupation = occupation;
	}

	public String getOccupationOther() {
		return occupationOther;
	}

	public void setOccupationOther(String occupationOther) {
		this.occupationOther = occupationOther;
	}

	public Type getWorkPassType() {
		return workPassType;
	}

	public void setWorkPassType(Type workPassType) {
		this.workPassType = workPassType;
	}

	public LocalDate getWorkPassExpiryDate() {
		return workPassExpiryDate;
	}

	public void setWorkPassExpiryDate(LocalDate workPassExpiryDate) {
		this.workPassExpiryDate = workPassExpiryDate;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public Address getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(Address registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public Address getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(Address mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public LocalDateTime getOffenceDeclaredDate() {
		return offenceDeclaredDate;
	}

	public void setOffenceDeclaredDate(LocalDateTime offenceDeclaredDate) {
		this.offenceDeclaredDate = offenceDeclaredDate;
	}

	public LocalDate getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(LocalDate offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public String getEnforcementOutcome() {
		return enforcementOutcome;
	}

	public void setEnforcementOutcome(String enforcementOutcome) {
		this.enforcementOutcome = enforcementOutcome;
	}

	public Boolean hasConsentMobileNo() {
		return hasConsentMobileNo;
	}

	public void setHasConsentMobileNo(Boolean hasConsentMobileNo) {
		this.hasConsentMobileNo = hasConsentMobileNo;
	}

	public Boolean hasConsentEmailAddress() {
		return hasConsentEmailAddress;
	}

	public void setHasConsentEmailAddress(Boolean hasConsentEmailAddress) {
		this.hasConsentEmailAddress = hasConsentEmailAddress;
	}

	public Boolean getHasPassedOn() {
		return hasPassedOn;
	}

	public void setHasPassedOn(Boolean hasPassedOn) {
		this.hasPassedOn = hasPassedOn;
	}

	public String getLegacyId() {
		return legacyId;
	}

	public void setLegacyId(String legacyId) {
		this.legacyId = legacyId;
	}

	public Set<TgAssignment> getTgAssignments() {
		return tgAssignments;
	}

	public void setTgAssignments(Set<TgAssignment> tgAssignments) {
		this.tgAssignments = tgAssignments;
	}

	public Set<TgCourseAttendanceDetail> getTgCourseAttendanceDetails() {
		return tgCourseAttendanceDetails;
	}

	public void setTgCourseAttendances(Set<TgCourseAttendanceDetail> tgCourseAttendanceDetails) {
		this.tgCourseAttendanceDetails = tgCourseAttendanceDetails;
	}

	public Set<Type> getGuidingLanguages() {
		return guidingLanguages;
	}

	public void setGuidingLanguages(Set<Type> guidingLanguages) {
		this.guidingLanguages = guidingLanguages;
	}

	public Set<Type> getSpecializedAreas() {
		return specializedAreas;
	}

	public void setSpecializedAreas(Set<Type> specializedAreas) {
		this.specializedAreas = specializedAreas;
	}

	public Set<Alert> getAlerts() {
		return alerts;
	}

	public void setAlerts(Set<Alert> alerts) {
		this.alerts = alerts;
	}

	public Boolean getHasConsentMobileNo() {
		return hasConsentMobileNo;
	}

	public Boolean getHasConsentEmailAddress() {
		return hasConsentEmailAddress;
	}

	public void setTgCourseAttendanceDetails(Set<TgCourseAttendanceDetail> tgCourseAttendanceDetails) {
		this.tgCourseAttendanceDetails = tgCourseAttendanceDetails;
	}

	public String getGuidingLanguagesWithComma(Cache cache) {
		return toComma(guidingLanguages, cache);
	}

	public String getSpecializedAreasWithComma(Cache cache) {
		return toComma(specializedAreas, cache);
	}

	public Boolean getHasPersonUpdateAccess() {
		return hasPersonUpdateAccess;
	}

	public void setHasPersonUpdateAccess(Boolean hasPersonUpdateAccess) {
		this.hasPersonUpdateAccess = hasPersonUpdateAccess;
	}

	public Boolean isMyInfoPopulated() {
		return isMyInfoPopulated;
	}

	public void setIsMyInfoPopulated(Boolean isMyInfoPopulated) {
		this.isMyInfoPopulated = isMyInfoPopulated;
	}

	public String getDisplayEmployerName() {
		return displayEmployerName;
	}

	public void setDisplayEmployerName(String displayEmployerName) {
		this.displayEmployerName = displayEmployerName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplaySecondEmployerName() {
		return displaySecondEmployerName;
	}

	public void setDisplaySecondEmployerName(String displaySecondEmployerName) {
		this.displaySecondEmployerName = displaySecondEmployerName;
	}

	public String getDisplaySecondName() {
		return displaySecondName;
	}

	public void setDisplaySecondName(String displaySecondName) {
		this.displaySecondName = displaySecondName;
	}

	private String toComma(Set<Type> set, Cache cache) {
		String text = "";
		if (set != null) {
			List<Type> sortedType = new ArrayList<Type>(set); // set -> list
			Collections.sort(sortedType, (o1, o2) -> o1.getLabel().compareTo(o2.getLabel()));
			text = sortedType.stream().map(n -> cache.getLabel(n, true)).collect(Collectors.joining(", ")); // Sort the list
		}

		return text;
	}
}
