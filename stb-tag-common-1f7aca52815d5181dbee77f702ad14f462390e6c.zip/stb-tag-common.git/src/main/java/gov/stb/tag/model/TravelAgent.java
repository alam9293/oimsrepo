package gov.stb.tag.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class TravelAgent extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence; // current licence

	private String uen;

	private String name;

	private String formerName;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type formOfBusiness; // Company Type

	@ManyToOne(fetch = FetchType.LAZY)
	private Type businessConstitution; // either sole proprietary, partners or others

	private LocalDate incorporatedDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type incorporatedPlace;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type establishmentStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type principleActivities;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type secondaryPrincipleActivities;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type taSegmentation;

	private BigDecimal paidUpCapital;

	private String websiteUrl;

	@Column(length = 320)
	private String emailAddress;

	private String contactNo; // not in FS?

	private String faxNo;

	private LocalDate fyeDate; // upcoming Fye Date

	@ManyToOne(fetch = FetchType.LAZY)
	private Address registeredAddress;

	@ManyToOne(fetch = FetchType.LAZY)
	private Address operatingAddress;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheck lastRegAddrTaCheck;

	private Boolean isLastRegAddrCheckDone;

	@ManyToOne(fetch = FetchType.LAZY)
	private CeTaCheck lastOpAddrTaCheck;

	private Boolean isLastOpAddrCheckDone;

	@OneToMany(mappedBy = "travelAgent")
	private Set<Licence> licences;

	@ManyToMany
	private Set<Alert> alerts = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "travel_agent$inbound_service")
	private Set<Type> inboundServices = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "travel_agent$outbound_service")
	private Set<Type> outboundServices = new HashSet<>();

	private String displayName;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Address displayAddress;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFormerName() {
		return formerName;
	}

	public void setFormerName(String formerName) {
		this.formerName = formerName;
	}

	public Type getFormOfBusiness() {
		return formOfBusiness;
	}

	public void setFormOfBusiness(Type formOfBusiness) {
		this.formOfBusiness = formOfBusiness;
	}

	public LocalDate getIncorporatedDate() {
		return incorporatedDate;
	}

	public void setIncorporatedDate(LocalDate incorporatedDate) {
		this.incorporatedDate = incorporatedDate;
	}

	public Type getIncorporatedPlace() {
		return incorporatedPlace;
	}

	public void setIncorporatedPlace(Type incorporatedPlace) {
		this.incorporatedPlace = incorporatedPlace;
	}

	public Type getEstablishmentStatus() {
		return establishmentStatus;
	}

	public void setEstablishmentStatus(Type establishmentStatus) {
		this.establishmentStatus = establishmentStatus;
	}

	public Type getPrincipleActivities() {
		return principleActivities;
	}

	public void setPrincipleActivities(Type principleActivities) {
		this.principleActivities = principleActivities;
	}

	public Type getSecondaryPrincipleActivities() {
		return secondaryPrincipleActivities;
	}

	public void setSecondaryPrincipleActivities(Type secondaryPrincipleActivities) {
		this.secondaryPrincipleActivities = secondaryPrincipleActivities;
	}

	public Type getBusinessConstitution() {
		return businessConstitution;
	}

	public void setBusinessConstitution(Type businessConstitution) {
		this.businessConstitution = businessConstitution;
	}

	public Type getTaSegmentation() {
		return taSegmentation;
	}

	public void setTaSegmentation(Type taSegmentation) {
		this.taSegmentation = taSegmentation;
	}

	public BigDecimal getPaidUpCapital() {
		return paidUpCapital;
	}

	public void setPaidUpCapital(BigDecimal paidUpCapital) {
		this.paidUpCapital = paidUpCapital;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public LocalDate getFyeDate() {
		return fyeDate;
	}

	public void setFyeDate(LocalDate fyeDate) {
		this.fyeDate = fyeDate;
	}

	public Address getRegisteredAddress() {
		return registeredAddress;
	}

	public void setRegisteredAddress(Address registeredAddress) {
		this.registeredAddress = registeredAddress;
	}

	public Address getOperatingAddress() {
		return operatingAddress;
	}

	public void setOperatingAddress(Address operatingAddress) {
		this.operatingAddress = operatingAddress;
	}

	public CeTaCheck getLastRegAddrTaCheck() {
		return lastRegAddrTaCheck;
	}

	public void setLastRegAddrTaCheck(CeTaCheck lastRegAddrTaCheck) {
		this.lastRegAddrTaCheck = lastRegAddrTaCheck;
	}

	public CeTaCheck getLastOpAddrTaCheck() {
		return lastOpAddrTaCheck;
	}

	public void setLastOpAddrTaCheck(CeTaCheck lastOpAddrTaCheck) {
		this.lastOpAddrTaCheck = lastOpAddrTaCheck;
	}

	public Set<Licence> getLicences() {
		return licences;
	}

	public void setLicences(Set<Licence> licences) {
		this.licences = licences;
	}

	public Set<Alert> getAlerts() {
		return alerts;
	}

	public void setAlerts(Set<Alert> alerts) {
		this.alerts = alerts;
	}

	public Set<Type> getInboundServices() {
		return inboundServices;
	}

	public void setInboundServices(Set<Type> inboundServices) {
		this.inboundServices = inboundServices;
	}

	public Set<Type> getOutboundServices() {
		return outboundServices;
	}

	public void setOutboundServices(Set<Type> outboundServices) {
		this.outboundServices = outboundServices;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public Boolean getIsLastRegAddrCheckDone() {
		return isLastRegAddrCheckDone;
	}

	public void setIsLastRegAddrCheckDone(Boolean isLastRegAddrCheckDone) {
		this.isLastRegAddrCheckDone = isLastRegAddrCheckDone;
	}

	public Boolean getIsLastOpAddrCheckDone() {
		return isLastOpAddrCheckDone;
	}

	public void setIsLastOpAddrCheckDone(Boolean isLastOpAddrCheckDone) {
		this.isLastOpAddrCheckDone = isLastOpAddrCheckDone;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Address getDisplayAddress() {
		return displayAddress;
	}

	public void setDisplayAddress(Address displayAddress) {
		this.displayAddress = displayAddress;
	}

}
