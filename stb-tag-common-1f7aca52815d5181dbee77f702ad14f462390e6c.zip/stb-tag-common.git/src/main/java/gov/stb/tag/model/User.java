package gov.stb.tag.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.google.common.collect.Lists;
import com.wiz.model.api.AuditableIdEntity;
import com.wiz.model.api.Listable;

/**
 * UEN + LoginId forms the business primary key for a user. If a person is a 'Group' secretary to multiple TA, he will have multiple Users with different UEN + LoginId.
 */
@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class User extends AuditableIdEntity implements Listable {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // STB, SPCP_PORTAL, SPCP_ONLY

	@OneToOne(fetch = FetchType.LAZY)
	private TouristGuide touristGuide;

	@OneToOne(fetch = FetchType.LAZY)
	private TgCandidate tgCandidate;

	@OneToOne(fetch = FetchType.LAZY)
	private TgTrainingProvider tgTrainingProvider;

	@ManyToOne(fetch = FetchType.LAZY)
	private TravelAgent travelAgent;

	private String uen;

	private String loginId;

	private String password;

	private String salt;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isLocked;

	private String name;

	@Column(length = 320)
	private String emailAddress;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type securityQuestion;

	private String securityQuestionAnswer;

	private LocalDateTime lastLoginDate;

	private Integer loginCount;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type department;

	/**
	 * TA applications/submissions are routed to STB TA officers based on the 1st alphabet of the TA company's name. This field stores the list of alphabets assigned to the officer, separated by
	 * space.
	 */
	private String taAssigneeChars;

	@ManyToMany
	private Set<Role> roles = new HashSet<>();

	@ManyToMany
	private Set<Alert> alerts = new HashSet<>();

	@OneToMany(mappedBy = "user")
	private List<PasswordHistory> passwordHistories;

	@Transient
	private Role defaultRole;

	@Transient
	private String iamsTokenId; // to store iams id_token to retrieve for /end_session api. only for public login.

	@Transient
	private String spTokenId; // to store sp id_token to retrieve for myinfo api. only for sp login.

	@Transient
	private Boolean isToChangePassword = false;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public TouristGuide getTouristGuide() {
		return touristGuide;
	}

	public void setTouristGuide(TouristGuide touristGuide) {
		this.touristGuide = touristGuide;
	}

	public TgCandidate getTgCandidate() {
		return tgCandidate;
	}

	public void setTgCandidate(TgCandidate tgCandidate) {
		this.tgCandidate = tgCandidate;
	}

	public TgTrainingProvider getTgTrainingProvider() {
		return tgTrainingProvider;
	}

	public void setTgTrainingProvider(TgTrainingProvider tgTrainingProvider) {
		this.tgTrainingProvider = tgTrainingProvider;
	}

	public TravelAgent getTravelAgent() {
		return travelAgent;
	}

	public void setTravelAgent(TravelAgent travelAgent) {
		this.travelAgent = travelAgent;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSalt() {
		return salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Boolean isLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Type getDepartment() {
		return department;
	}

	public void setDepartment(Type department) {
		this.department = department;
	}

	public Type getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(Type securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityQuestionAnswer() {
		return securityQuestionAnswer;
	}

	public void setSecurityQuestionAnswer(String securityQuestionAnswer) {
		this.securityQuestionAnswer = securityQuestionAnswer;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public Set<Alert> getAlerts() {
		return alerts;
	}

	public void setAlerts(Set<Alert> alerts) {
		this.alerts = alerts;
	}

	public List<PasswordHistory> getPasswordHistories() {
		return passwordHistories;
	}

	public void setPasswordHistories(List<PasswordHistory> passwordHistories) {
		this.passwordHistories = passwordHistories;
	}

	public LocalDateTime getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(LocalDateTime lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public String getTaAssigneeChars() {
		return taAssigneeChars;
	}

	public void setTaAssigneeChars(String taAssigneeChars) {
		this.taAssigneeChars = taAssigneeChars;
	}

	public Integer getLoginCount() {
		return loginCount;
	}

	public void setLoginCount(Integer loginCount) {
		this.loginCount = loginCount;
	}

	@Override
	public String getLabel() {
		return getName();
	}

	@Override
	public Serializable getKey() {
		return getId();
	}

	@Override
	public String getOtherLabel() {
		return getLoginId();
	}

	/**
	 * Return the default role of the user, if user has multiple roles, lower ordinal value will be selected
	 * 
	 * @return
	 */
	public Role getDefaultRole() {
		if (this.defaultRole == null) {
			Role defaultRole = null;
			List<Role> myRoles = Lists.newArrayList();
			myRoles.addAll(getRoles());
			if (!CollectionUtils.isEmpty(myRoles)) {
				defaultRole = myRoles.get(0);
				Integer lowestOrdinal = defaultRole.getOrdinal();
				for (Role role : myRoles) {
					if (!Objects.isNull(role.getOrdinal()) && role.getOrdinal().compareTo(lowestOrdinal) < 0) {
						defaultRole = role;
						lowestOrdinal = role.getOrdinal();
					}
				}
			}
			this.setDefaultRole(defaultRole);
			return defaultRole;
		} else {
			return this.defaultRole;
		}
	}

	public void setDefaultRole(Role defaultRole) {
		this.defaultRole = defaultRole;
	}

	public String getIamsTokenId() {
		return iamsTokenId;
	}

	public void setIamsTokenId(String iamsTokenId) {
		this.iamsTokenId = iamsTokenId;
	}

	public String getSpTokenId() {
		return spTokenId;
	}

	public void setSpTokenId(String spTokenId) {
		this.spTokenId = spTokenId;
	}

	public Boolean isToChangePassword() {
		return isToChangePassword;
	}

	public void setIsToChangePassword(Boolean isToChangePassword) {
		this.isToChangePassword = isToChangePassword;
	}
}
