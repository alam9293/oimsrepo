package gov.stb.tag.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name = "ce_ta_check_schedulable_item")
public class ViewCeTaCheckSchedulableItem {

	@Id
	@Column(name = "addressId")
	private Integer addressId;

	@Column(name = "travelAgentId")
	private Integer travelAgentId;

	@Column(name = "licenceId")
	private Integer licenceId;

	@Column(name = "taBranchId")
	private Integer taBranchId;

	@Column(name = "lastAaFilingId")
	private Integer lastAaFilingId;

	@Column(name = "lastTatiCheckId")
	private Integer lastTatiCheckId;

	@Column(name = "taName")
	private String taName;

	@Column(name = "uen")
	private String uen;

	@Column(name = "licenceNo")
	private String licenceNo;

	@Column(name = "block")
	private String block;

	@Column(name = "floorUnit")
	private String floorUnit;

	@Column(name = "building")
	private String building;

	@Column(name = "street")
	private String street;

	@Column(name = "postal")
	private String postal;

	@Column(name = "premiseTypeCode")
	private String premiseTypeCode;

	@Column(name = "addressTypeCode")
	private String addressTypeCode; // REG-Registered address, OP-operating address, BRANCH-branch address

	@Column(name = "lastAaFilingFyEndDate")
	private LocalDate lastAaFilingFyEndDate;

	@Column(name = "noOfReds")
	private Integer noOfReds;

	@Column(name = "lastAaFilingStatusCode")
	private String lastAaFilingStatusCode;

	@Column(name = "lastTatiCheckIsCompliantCode")
	private String lastTatiCheckIsCompliantCode;

	@Column(name = "lastTatiCheckDate")
	private LocalDate lastTatiCheckDate;

	@Column(name = "lastCheckDone")
	private Boolean lastCheckDone;

	@Column(name = "licenceCeasedDate")
	private LocalDate licenceCeasedDate;

	@Column(name = "licenceExpiryDate")
	private LocalDate licenceExpiryDate;

	@Column(name = "licenceStatusCode")
	private String licenceStatusCode;

	@Column(name = "branchStatusCode")
	private String branchStatusCode;

	@Column(name = "serviceTypeCode")
	private String serviceTypeCode; // IN-Inbound only, OUT-Outbound only, INOUT-both inbound and outbound

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public Integer getTravelAgentId() {
		return travelAgentId;
	}

	public void setTravelAgentId(Integer travelAgentId) {
		this.travelAgentId = travelAgentId;
	}

	public Integer getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(Integer licenceId) {
		this.licenceId = licenceId;
	}

	public Integer getTaBranchId() {
		return taBranchId;
	}

	public void setTaBranchId(Integer taBranchId) {
		this.taBranchId = taBranchId;
	}

	public Integer getLastAaFilingId() {
		return lastAaFilingId;
	}

	public void setLastAaFilingId(Integer lastAaFilingId) {
		this.lastAaFilingId = lastAaFilingId;
	}

	public Integer getLastTatiCheckId() {
		return lastTatiCheckId;
	}

	public void setLastTatiCheckId(Integer lastTatiCheckId) {
		this.lastTatiCheckId = lastTatiCheckId;
	}

	public String getTaName() {
		return taName;
	}

	public void setTaName(String taName) {
		this.taName = taName;
	}

	public String getUen() {
		return uen;
	}

	public void setUen(String uen) {
		this.uen = uen;
	}

	public String getLicenceNo() {
		return licenceNo;
	}

	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getFloorUnit() {
		return floorUnit;
	}

	public void setFloorUnit(String floorUnit) {
		this.floorUnit = floorUnit;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}

	public String getPremiseTypeCode() {
		return premiseTypeCode;
	}

	public void setPremiseTypeCode(String premiseTypeCode) {
		this.premiseTypeCode = premiseTypeCode;
	}

	public String getAddressTypeCode() {
		return addressTypeCode;
	}

	public void setAddressTypeCode(String addressTypeCode) {
		this.addressTypeCode = addressTypeCode;
	}

	public LocalDate getLastAaFilingFyEndDate() {
		return lastAaFilingFyEndDate;
	}

	public void setLastAaFilingFyEndDate(LocalDate lastAaFilingFyEndDate) {
		this.lastAaFilingFyEndDate = lastAaFilingFyEndDate;
	}

	public Integer getNoOfReds() {
		return noOfReds;
	}

	public void setNoOfReds(Integer noOfReds) {
		this.noOfReds = noOfReds;
	}

	public String getLastAaFilingStatusCode() {
		return lastAaFilingStatusCode;
	}

	public void setLastAaFilingStatusCode(String lastAaFilingStatusCode) {
		this.lastAaFilingStatusCode = lastAaFilingStatusCode;
	}

	public String getLastTatiCheckIsCompliantCode() {
		return lastTatiCheckIsCompliantCode;
	}

	public void setLastTatiCheckIsCompliantCode(String lastTatiCheckIsCompliantCode) {
		this.lastTatiCheckIsCompliantCode = lastTatiCheckIsCompliantCode;
	}

	public LocalDate getLastTatiCheckDate() {
		return lastTatiCheckDate;
	}

	public void setLastTatiCheckDate(LocalDate lastTatiCheckDate) {
		this.lastTatiCheckDate = lastTatiCheckDate;
	}

	public Boolean getLastCheckDone() {
		return lastCheckDone;
	}

	public void setLastCheckDone(Boolean lastCheckDone) {
		this.lastCheckDone = lastCheckDone;
	}

	public LocalDate getLicenceCeasedDate() {
		return licenceCeasedDate;
	}

	public void setLicenceCeasedDate(LocalDate licenceCeasedDate) {
		this.licenceCeasedDate = licenceCeasedDate;
	}

	public LocalDate getLicenceExpiryDate() {
		return licenceExpiryDate;
	}

	public void setLicenceExpiryDate(LocalDate licenceExpiryDate) {
		this.licenceExpiryDate = licenceExpiryDate;
	}

	public String getLicenceStatusCode() {
		return licenceStatusCode;
	}

	public void setLicenceStatusCode(String licenceStatusCode) {
		this.licenceStatusCode = licenceStatusCode;
	}

	public String getBranchStatusCode() {
		return branchStatusCode;
	}

	public void setBranchStatusCode(String branchStatusCode) {
		this.branchStatusCode = branchStatusCode;
	}

	public String getServiceTypeCode() {
		return serviceTypeCode;
	}

	public void setServiceTypeCode(String serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}

}
