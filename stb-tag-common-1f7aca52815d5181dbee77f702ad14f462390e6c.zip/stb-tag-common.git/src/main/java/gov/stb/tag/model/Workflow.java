package gov.stb.tag.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class Workflow extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type;

	private String categoryType; // TA, TG, CE

	@Column(columnDefinition = "text")
	private String description; // e.g. case task assessment

	private LocalDate slaExpiryDate;

	@ManyToOne(fetch = FetchType.LAZY)
	private User assignee; // for C&E account-based workflows, only the assignee can perform workflow action on the workflow

	@ManyToOne(fetch = FetchType.LAZY)
	private Licence licence;

	@ManyToOne(fetch = FetchType.LAZY)
	private WorkflowAction lastAction;

	// for C&E account-based workflows, it'll snapshot copies of step assignments from its respective workflowConfig so that OIC can further configure the accounts to be used specific to this workflow
	@OneToMany(mappedBy = "workflow")
	private List<WorkflowStepAssignment> workflowStepAssignments = new ArrayList<>();

	@OneToMany(mappedBy = "workflow")
	@Where(clause = "isDeleted = 0")
	private Set<WorkflowFile> workflowFiles;

	@OneToMany(mappedBy = "workflow")
	private Set<WorkflowAction> workflowActions;

	@OneToMany(mappedBy = "forWorkflow")
	private List<CeTask> ceTasks;

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isDraft;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getSlaExpiryDate() {
		return slaExpiryDate;
	}

	public void setSlaExpiryDate(LocalDate slaExpiryDate) {
		this.slaExpiryDate = slaExpiryDate;
	}

	public User getAssignee() {
		return assignee;
	}

	public void setAssignee(User assignee) {
		this.assignee = assignee;
	}

	public Licence getLicence() {
		return licence;
	}

	public void setLicence(Licence licence) {
		this.licence = licence;
	}

	public WorkflowAction getLastAction() {
		return lastAction;
	}

	public void setLastAction(WorkflowAction lastAction) {
		this.lastAction = lastAction;
	}

	public List<WorkflowStepAssignment> getWorkflowStepAssignments() {
		return workflowStepAssignments;
	}

	public void setWorkflowStepAssignments(List<WorkflowStepAssignment> workflowStepAssignments) {
		this.workflowStepAssignments = workflowStepAssignments;
	}

	public Set<WorkflowFile> getWorkflowFiles() {
		return workflowFiles;
	}

	public void setWorkflowFiles(Set<WorkflowFile> workflowFiles) {
		this.workflowFiles = workflowFiles;
	}

	public Set<WorkflowAction> getWorkflowActions() {
		return workflowActions;
	}

	public void setWorkflowActions(Set<WorkflowAction> workflowActions) {
		this.workflowActions = workflowActions;
	}

	public List<CeTask> getCeTasks() {
		return ceTasks;
	}

	public void setCeTasks(List<CeTask> ceTasks) {
		this.ceTasks = ceTasks;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

}
