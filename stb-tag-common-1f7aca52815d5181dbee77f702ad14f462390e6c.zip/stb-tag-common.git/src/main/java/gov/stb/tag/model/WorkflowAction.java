package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Where;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class WorkflowAction extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // submit, forward, rfa, reject, add note

	@ManyToOne(fetch = FetchType.LAZY)
	private Type recommendation; // impose, do not impose, no action required

	@ManyToOne(fetch = FetchType.LAZY)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	private Status prevStatus;

	@Column(length = 5000)
	private String internalRemarks;

	@Column(length = 5000)
	private String externalRemarks;

	@ManyToOne(fetch = FetchType.LAZY)
	private Role role;

	@ManyToOne(fetch = FetchType.LAZY)
	private User actionBy;

	@ManyToOne(fetch = FetchType.LAZY)
	private Application application; // application workflow process triggered by public (e.g. TA / TG Applications)

	@ManyToOne(fetch = FetchType.LAZY)
	private Workflow workflow; // internal workflow process triggered by STB (e.g. C&E, Licence Renewal Exercise, Net Value Shortfall)

	@ManyToMany
	@Where(clause = "isDeleted = 0")
	private Set<File> files = new HashSet<>(); // annotated with ManyToMany for workflow_action$files mapping table

	@ManyToOne(fetch = FetchType.LAZY)
	private User Assignee;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getRecommendation() {
		return recommendation;
	}

	public void setRecommendation(Type recommendation) {
		this.recommendation = recommendation;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Status getPrevStatus() {
		return prevStatus;
	}

	public void setPrevStatus(Status prevStatus) {
		this.prevStatus = prevStatus;
	}

	public String getInternalRemarks() {
		return internalRemarks;
	}

	public void setInternalRemarks(String internalRemarks) {
		this.internalRemarks = internalRemarks;
	}

	public String getExternalRemarks() {
		return externalRemarks;
	}

	public void setExternalRemarks(String externalRemarks) {
		this.externalRemarks = externalRemarks;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public User getActionBy() {
		return actionBy;
	}

	public void setActionBy(User actionBy) {
		this.actionBy = actionBy;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public Set<File> getFiles() {
		return files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public User getAssignee() {
		return Assignee;
	}

	public void setAssignee(User assignee) {
		Assignee = assignee;
	}

}
