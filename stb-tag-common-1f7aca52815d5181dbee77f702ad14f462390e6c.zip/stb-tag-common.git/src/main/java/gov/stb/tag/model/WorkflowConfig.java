package gov.stb.tag.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class WorkflowConfig extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Type appOrWkflwType; // for WorkflowHelper to determine which workflow configuration to use for an application or workflow by its respective type

	@ManyToOne(fetch = FetchType.LAZY)
	private WorkflowStep finalStep; // for Workflow configuration module to find and change to do re-approval (instead of coding approval logic within that module)

	@OneToMany(mappedBy = "workflowConfig")
	private List<WorkflowStepAssignment> workflowStepAssignments = new ArrayList<>();

	@Column(nullable = false, columnDefinition = "BIT(1) default 0")
	private Boolean isConfigurable; // Indicate if this application/workflow is configurable

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getAppOrWkflwType() {
		return appOrWkflwType;
	}

	public void setAppOrWkflwType(Type appOrWkflwType) {
		this.appOrWkflwType = appOrWkflwType;
	}

	public WorkflowStep getFinalStep() {
		return finalStep;
	}

	public void setFinalStep(WorkflowStep finalStep) {
		this.finalStep = finalStep;
	}

	public List<WorkflowStepAssignment> getWorkflowStepAssignments() {
		return workflowStepAssignments;
	}

	public void setWorkflowStepAssignments(List<WorkflowStepAssignment> workflowStepAssignments) {
		this.workflowStepAssignments = workflowStepAssignments;
	}

	// convenient method to get the assigned workflowSteps
	public List<WorkflowStep> getWorkflowSteps() {
		List<WorkflowStep> workflowSteps = getWorkflowStepAssignments().stream().map(WorkflowStepAssignment::getWorkflowStep).collect(Collectors.toList());
		return workflowSteps.stream().sorted(Comparator.comparing(WorkflowStep::getLevel)).collect(Collectors.toList());
	}

	public Boolean isConfigurable() {
		return isConfigurable;
	}

	public void setIsConfigurable(Boolean isConfigurable) {
		this.isConfigurable = isConfigurable;
	}
}
