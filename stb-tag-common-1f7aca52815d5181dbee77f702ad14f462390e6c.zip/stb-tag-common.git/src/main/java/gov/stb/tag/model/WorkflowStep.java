package gov.stb.tag.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class WorkflowStep extends AuditableIdEntity {

	private Integer id;

	private Integer level;

	private String purpose; // For Support, For Approval

	@OneToOne
	private Role role; // for role-based workflow (whoever has the role can do the step)

	@ManyToMany
	private Set<Role> roles = new HashSet<>(); // for account-based workflow (whoever has one of the roles can be assigned to do the step, only assignee can do the step)

	@ManyToOne(fetch = FetchType.LAZY)
	private Type type; // TA, TG, CE (for the display of headers in Manage TA Workflow, Manage TG Workflow, Manage CE Workflow)

	@ManyToOne(fetch = FetchType.LAZY)
	private Status startStatus;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Status getStartStatus() {
		return startStatus;
	}

	public void setStartStatus(Status startStatus) {
		this.startStatus = startStatus;
	}

}
