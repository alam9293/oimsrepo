package gov.stb.tag.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.wiz.model.api.AuditableIdEntity;

@Entity
@DynamicInsert
@DynamicUpdate
@SuppressWarnings("serial")
public class WorkflowStepAssignment extends AuditableIdEntity {

	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	private Workflow workflow;

	@ManyToOne(fetch = FetchType.EAGER)
	private WorkflowConfig workflowConfig;

	@ManyToOne(fetch = FetchType.EAGER)
	private WorkflowStep workflowStep;

	@ManyToOne(fetch = FetchType.LAZY)
	private User user;

	@Override
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public WorkflowConfig getWorkflowConfig() {
		return workflowConfig;
	}

	public void setWorkflowConfig(WorkflowConfig workflowConfig) {
		this.workflowConfig = workflowConfig;
	}

	public WorkflowStep getWorkflowStep() {
		return workflowStep;
	}

	public void setWorkflowStep(WorkflowStep workflowStep) {
		this.workflowStep = workflowStep;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
