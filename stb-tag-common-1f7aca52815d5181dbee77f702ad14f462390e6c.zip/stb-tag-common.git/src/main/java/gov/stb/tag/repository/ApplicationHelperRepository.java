package gov.stb.tag.repository;

import java.time.LocalDate;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.TaNetValueShortfall;
import gov.stb.tag.model.TgLicenceRenewal;
import gov.stb.tag.model.WorkflowAction;

@Repository
public class ApplicationHelperRepository extends BaseRepository {

	public <T> T getApplicationByClass(Integer applicationId, Class<T> clazz) {
		DetachedCriteria dc = DetachedCriteria.forClass(clazz);
		dc.add(Restrictions.eq("application.id", applicationId));
		return getFirst(dc);
	}

	public boolean hasIpaApproved(Integer applicationId) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowAction.class);
		dc.add(Restrictions.eq("application.id", applicationId));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_APP_PENDING_OA));
		dc.setProjection(Projections.rowCount());
		return Long.valueOf(1).equals(getProjectedFirstValue(dc));
	}

	public TaNetValueShortfall getLatestPendingNetValueShortfall(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaNetValueShortfall.class);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("workflow.licence.id", licenceId));
		dc.add(Restrictions.disjunction().add(Restrictions.eq("lastAction.recommendation.code", Codes.Types.RECOMMEND_IMPOSE)).add(Restrictions.isNull("lastAction.recommendation.code")));
		dc.add(Restrictions.ne("lastAction.status.code", Codes.Statuses.TA_WKFLW_REJECTED));
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(Restrictions.isNull("taNetValueRectification"));
		dc.add(disjunction);

		dc.addOrder(Order.desc("createdDate"));
		return getFirst(dc);
	}

	public TgLicenceRenewal getRenewalAppByLicIdAndExpiryDate(Integer licenceId, LocalDate licenceExpiryDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.eq("application.isDeleted", false));
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("previousLicenceExpiryDate", licenceExpiryDate));
		dc.add(Restrictions.ne("lastAction.status.code", Codes.Statuses.TG_APP_REJECTED));
		return getFirst(dc);
	}

	public TgLicenceRenewal getRenewalAppByLicId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TgLicenceRenewal.class);
		dc.createAlias("application", "application", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("application.isDraft", false));
		dc.add(Restrictions.eq("application.isDeleted", false));
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("lastAction.status.code", Codes.Statuses.TG_APP_APPROVED));
		dc.addOrder(Order.desc("createdDate"));

		return getFirst(dc);
	}

}
