package gov.stb.tag.repository;

import static com.google.common.base.Strings.isNullOrEmpty;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.CriteriaImpl;
import org.hibernate.internal.CriteriaImpl.OrderEntry;
import org.hibernate.internal.CriteriaImpl.Subcriteria;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;
import org.hibernate.resource.transaction.spi.TransactionStatus;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;

import com.google.common.base.Objects;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.wiz.model.api.CodeEntity;
import com.wiz.model.api.Entity;
import com.wiz.model.api.IdEntity;

import gov.stb.tag.annotation.MapProjection;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.util.ClassUtil;
import gov.stb.tag.util.DateUtil;

/**
 * Since Spring 2 + Hibernate 5, Hikari datasource has been the default datasource and connection pooling provider and we don't require any explicit configuration to achieve that. We don't require
 * commons-dbcp and HikariCP artifacts. SessionFactory is now directly extending EntityManagerFactory.
 * 
 * <pre>
 * https://www.devglan.com/spring-boot/spring-boot-hibernate-5-example 
 * https://www.baeldung.com/hibernate-5-spring
 * </pre>
 * 
 * Hibernate tracks your @Entity objects with 3 different states:
 * 
 * <pre>
 * Transient â€ this instance is not, and never was, attached to a Session; this instance has no corresponding rows in the database; itâ€™s
 * usually just a new object that you have created to save to the database; (E.g.: Course course = new Course(â€¦). To persist, use .save()) 
 * 
 * Persistent â€ this instance is associated with a unique Session object; upon flushing the Session to the database, this entity is guaranteed to have a corresponding consistent record in the
 * database; (E.g.: Course course = repository.getCourse(â€¦). Any change will be persisted at the end of txn). 
 * 
 * Detached â€ this instance was once attached to a Session (in a persistent state), but now itâ€™s not; an instance enters this state if you evict it from the context, clear or close the Session, or put
 * the instance through serialization/deserialization process. (E.g.: Country country = cache.getCountry(â€¦). To persist, use .update() or retrieve from repository for changes)
 * </pre>
 * 
 * In conclusion, whenever you are dealing with persistent objects (i.e. any @Entity objects you retrieved from @Repositories), you should not â€œdirtyâ€� them unnecessarily (e.g. use them to store
 * temporary data in your logic). Only read data from them or update them when they are meant to be updated.
 * 
 * <pre>
 * https://www.baeldung.com/hibernate-save-persist-update-merge-saveorupdate
 * </pre>
 */
@Repository
@Transactional
@SuppressWarnings({ "unchecked", "rawtypes" })
public class BaseRepository {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	protected SessionFactory getSessionFactory() {
		return entityManagerFactory.unwrap(SessionFactory.class);
	}

	public Session getSession() {
		return getSessionFactory().getCurrentSession();
	}

	public Serializable getEntityId(Object entity) {
		return (Serializable) entityManagerFactory.getPersistenceUnitUtil().getIdentifier(entity);
	}

	protected NativeQuery createSQLQuery(String sql) {
		return getSession().createSQLQuery(sql);
	}

	protected Query createHqlQuery(String hql) {
		return getSession().createQuery(hql);
	}

	protected NativeQuery getNamedNativeQuery(String queryName) {
		return getSession().getNamedNativeQuery(queryName);
	}

	public <T extends Entity> void save(T t) {
		getSession().save(t);
	}

	public <T extends Entity> void save(Collection<T> t) {
		t.stream().forEach(o -> getSession().save(o));
	}

	public <T extends Entity> void update(T t) {
		getSession().update(t);
	}

	public <T extends Entity> void update(Collection<T> t) {
		t.stream().forEach(o -> getSession().update(o));
	}

	public <T extends Entity> void saveOrUpdate(T t) {
		getSession().saveOrUpdate(t);
	}

	public <T extends Entity> void saveOrUpdate(Collection<T> t) {
		t.stream().forEach(o -> getSession().saveOrUpdate(o));
	}

	public <T extends Entity> void delete(T t) {
		getSession().delete(t);
	}

	public <T extends Entity> void delete(Collection<T> t) {
		t.stream().forEach(o -> getSession().delete(o));
	}

	public <T extends Entity> T get(Class<T> clazz, Serializable id) {
		return getSession().get(clazz, id);
	}

	public <T extends Entity> T load(Class<T> clazz, Serializable id) {
		return getSession().load(clazz, id);
	}

	public <T> List<T> getList(DetachedCriteria dc) {
		return dc.getExecutableCriteria(getSession()).list();
	}

	public <T> List<T> getListLimit(DetachedCriteria dc, Integer maxResult) {
		return dc.getExecutableCriteria(getSession()).setMaxResults(maxResult).list();
	}

	public <T> T getFirst(DetachedCriteria dc) {
		List<T> list = getList(dc);
		return !list.isEmpty() ? list.get(0) : null;
	}

	public List<Object[]> getProjectedList(DetachedCriteria dc) {
		return dc.getExecutableCriteria(getSession()).list();
	}

	public List<Object> getProjectedListValues(DetachedCriteria dc) {
		return dc.getExecutableCriteria(getSession()).list();
	}

	public Object[] getProjectedFirst(DetachedCriteria dc) {
		List<Object[]> list = getProjectedList(dc);
		return list.isEmpty() ? new Object[] {} : (list.get(0) instanceof Object[] ? list.get(0) : new Object[] { list.get(0) });
	}

	public Object getProjectedFirstValue(DetachedCriteria dc) {
		Object[] result = getProjectedFirst(dc);
		return result.length == 0 ? null : result[0];
	}

	public void flush() {
		getSession().flush();
	}

	public void commit() {
		Transaction tx = getSession().getTransaction();
		if (tx.getStatus().equals(TransactionStatus.ACTIVE)) {
			tx.commit();
		}
	}

	public void rebeginTransaction() {
		Transaction tx = getSession().getTransaction();
		if (!tx.getStatus().equals(TransactionStatus.ACTIVE)) {
			tx.begin();
		}
	}

	public void clear() {
		getSession().clear();
	}

	public <T> T refresh(T object) {
		getSession().refresh(object);
		return object;
	}

	/*
	 * WARNING: Please note that once records in a transaction block is committed, they cannot be rollback.
	 */
	public void batchCommit(boolean toOpenTxnForNextBatch) {
		flush();
		commit();
		clear();
		if (toOpenTxnForNextBatch) {
			getSession().beginTransaction(); // open transaction for next batch
		}
	}

	/**
	 * This function is used to combine filtering, sorting and pagination based on the specified DetachedCriteria and SearchDto. Note that it does not support ordering on a field in a OneToMany
	 * column, which doesn't make sense anyway. (e.g. displaying a list of Driver but order by DriverReward.submitDate). If the search sql has group by, specify the projectionList so that the result
	 * size is correct
	 */
	protected <M> ResultDto<M> search(DetachedCriteria dc, SearchDto searchDto, boolean toPaginate) {
		return search(dc, searchDto, toPaginate, null);
	}

	protected <M> ResultDto<M> search(DetachedCriteria dc, SearchDto searchDto, boolean toPaginate, ProjectionList projectionsWithGroupBy) {
		int totalResultSize = 0;
		List<M> finalResults = Lists.newArrayList();

		if (toPaginate) {
			// remove ordering first
			List<Order> orderList = removeOrderFromDc(dc);

			// find the total result size without pagination
			DetachedCriteria totalResultsDc = copyDc(dc);
			if (projectionsWithGroupBy != null) {
				ProjectionList groupByProjections = Projections.projectionList();
				for (int i = 0; i < projectionsWithGroupBy.getLength(); i++) {
					Projection projection = projectionsWithGroupBy.getProjection(i);
					if (projection.isGrouped()) {
						groupByProjections.add(projection);
					}
				}
				totalResultsDc.setProjection(groupByProjections);
				totalResultSize = getList(totalResultsDc).size();
			} else {
				totalResultsDc.setProjection(Projections.rowCount());
				totalResultSize = ((Long) getProjectedFirstValue(totalResultsDc)).intValue();
			}

			// reconstruct ordering back
			reconstructOrderToDc(dc, orderList, searchDto);

			// run the detached criteria, this time with pagination
			Criteria criteria = dc.getExecutableCriteria(getSession());
			if (searchDto.getStartIndex() != null) {
				criteria.setFirstResult(searchDto.getStartIndex());
			}
			if (searchDto.getPageSize() != null) {
				criteria.setMaxResults(searchDto.getPageSize());
			}
			finalResults = criteria.list();

		} else {
			List<Order> orderList = removeOrderFromDc(dc);

			reconstructOrderToDc(dc, orderList, searchDto);

			finalResults = getList(dc);
			totalResultSize = finalResults.size();
		}

		// populate and return ResultDTO
		ResultDto<M> resultDTO = new ResultDto<>();
		resultDTO.setModels(finalResults);

		Object[] records = new Object[finalResults.size()];
		resultDTO.setRecords(records);

		int i = 0;
		for (M model : finalResults) {
			records[i++] = model;
		}

		resultDTO.setTotal(totalResultSize);
		resultDTO.setNoOfPages(computeNumberOfPages(totalResultSize, searchDto.getPageSize()));
		return resultDTO;
	}

	private DetachedCriteria copyDc(DetachedCriteria dc) {
		try {
			ByteArrayOutputStream baostream = new ByteArrayOutputStream();
			ObjectOutputStream oostream = new ObjectOutputStream(baostream);
			oostream.writeObject(dc);
			oostream.flush();
			oostream.close();
			ByteArrayInputStream baistream = new ByteArrayInputStream(baostream.toByteArray());
			ObjectInputStream oistream = new ObjectInputStream(baistream);
			DetachedCriteria copy = (DetachedCriteria) oistream.readObject();
			oistream.close();
			return copy;
		} catch (Exception e) {
			throw new HibernateException(e);
		}
	}

	private List<Order> removeOrderFromDc(DetachedCriteria dc) {

		// retrieve existing orders, store them in a list then remove accordingly
		CriteriaImpl criteria = (CriteriaImpl) dc.getExecutableCriteria(null);
		Iterator<?> iter = criteria.iterateOrderings();
		List<Order> orderList = Lists.newArrayList();
		while (iter.hasNext()) {
			CriteriaImpl.OrderEntry oe = (OrderEntry) iter.next();
			orderList.add(oe.getOrder());
			iter.remove();
		}

		return orderList;
	}

	private void reconstructOrderToDc(DetachedCriteria dc, List<Order> orderList, SearchDto searchDTO) {

		// reconstruct the order, with order property in SearchDTO in the first order follow by existing order
		Order orderInSearchDto = null;
		if (!Strings.isNullOrEmpty(searchDTO.getOrder()) && !Strings.isNullOrEmpty(searchDTO.getOrderProperty())) {
			orderInSearchDto = searchDTO.getOrder().equals("asc") ? Order.asc(searchDTO.getOrderProperty()) : Order.desc(searchDTO.getOrderProperty());
			orderList.add(0, orderInSearchDto);
		}

		// check if contain ID order in the query
		String idPropertyName = getEntityIdPropertyName(dc);
		boolean hasIdOrder = false;
		for (Order order : orderList) {
			if (idPropertyName.equals(order.getPropertyName())) {
				hasIdOrder = true;
				break;
			}
		}

		// if the list does not contains order of id, add it to ensure the paging is always correct
		if (!hasIdOrder) {
			orderList.add(Order.asc(idPropertyName));
		}

		// re-populate all orders
		boolean isFirst = true;
		for (Order order : orderList) {

			// skip if search dto order property in order
			if (!isFirst && orderInSearchDto != null && Objects.equal(order.getPropertyName(), orderInSearchDto.getPropertyName())) {
				continue;
			}

			dc.addOrder(order);

			if (isFirst) {
				isFirst = false;
			}
		}
	}

	private String getEntityIdPropertyName(DetachedCriteria dc) {
		String name = null;
		try {
			name = getSessionFactory().getClassMetadata(((CriteriaImpl) dc.getExecutableCriteria(null)).getEntityOrClassName()).getIdentifierPropertyName();
		} catch (Exception e) {
			throw new HibernateException(e);
		}
		return name;
	}

	private Integer computeNumberOfPages(Integer total, Integer pageSize) {
		if (total % pageSize > 0) {
			return total / pageSize + 1;
		}
		return total / pageSize;
	}

	/**
	 * This function is used to improve the performance of loading the One/ManyToMany collections in specified ID entities together with the sql call, instead of looping lazy fetch. Be mindful on
	 * aliases as different 'lineages' of children / grandchildren will return NxN no. of rows(TODO: Not yet catered for very large entities list yet as it uses IN query)
	 * 
	 * @param parentEntities
	 *            to have their child collections loaded
	 * @param aliases
	 *            containing the association path to the child collections to be loaded
	 * @return map of Id-Entity pairs for easy setting of loaded children collections back to list of parent entities
	 */
	protected <T> Map<Object, T> loadChildren(List<T> parentEntities, Pair<String, String>... aliases) {
		if (!parentEntities.isEmpty()) {
			Class<T> clazz = (Class<T>) parentEntities.get(0).getClass();
			boolean isCodeEntity = clazz.isAssignableFrom(CodeEntity.class);
			DetachedCriteria dc = DetachedCriteria.forClass(clazz);
			if (isCodeEntity) {
				dc.add(Restrictions.in("code", parentEntities.stream().map(CodeEntity.class::cast).map(CodeEntity::getCode).collect(Collectors.toList())));
			} else {
				dc.add(Restrictions.in("id", parentEntities.stream().map(IdEntity.class::cast).map(IdEntity::getId).collect(Collectors.toList())));
			}
			for (Pair<String, String> alias : aliases) {
				dc.createAlias(alias.getFirst(), alias.getSecond(), JoinType.LEFT_OUTER_JOIN);
			}
			dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
			List<T> list = getList(dc);
			Map<Object, T> map = new HashMap<>();
			if (isCodeEntity) {
				list.stream().forEach(o -> map.put(((CodeEntity) o).getCode(), o));
			} else {
				list.stream().forEach(o -> map.put(((IdEntity) o).getId(), o));
			}
			return map;
		}
		return new HashMap<Object, T>();
	}

	protected void addSqlOr(StringBuilder sb) {

	}

	protected String sqlLike(String field, String value) {

		if (!Strings.isNullOrEmpty(value)) {

			// TODO: potential SQL injection, have to escape character
			return " upper(" + field + ") like '%" + StringUtils.upperCase(value) + "%' ";
		}

		return "";
	}

	protected String sqlEq(String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {

			// TODO: potential SQL injection, have to escape character
			return " " + field + "='" + value + "' ";
		}

		return "";
	}

	protected void andSqlLike(StringBuilder sb, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			sb.append(" and (" + sqlLike(field, value) + ") ");
		}
	}

	protected void orSqlLike(StringBuilder sb, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			sb.append(" or (" + sqlLike(field, value) + ") ");
		}
	}

	protected void andSqlEq(StringBuilder sb, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			sb.append(" and (" + sqlEq(field, value) + ") ");
		}
	}

	protected void orSqlEq(StringBuilder sb, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			sb.append(" or (" + sqlEq(field, value) + ") ");
		}
	}

	protected void addLike(DetachedCriteria detachedCriteria, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			detachedCriteria.add(Restrictions.ilike(field, value, MatchMode.ANYWHERE));
		}
	}

	protected void addStartWith(DetachedCriteria detachedCriteria, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			detachedCriteria.add(Restrictions.ilike(field, value, MatchMode.START));
		}
	}

	protected void addEq(DetachedCriteria detachedCriteria, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			detachedCriteria.add(Restrictions.eq(field, value));
		}
	}

	protected void addEq(DetachedCriteria detachedCriteria, String field, Integer value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.eq(field, value));
		}
	}

	protected void addDateEq(DetachedCriteria detachedCriteria, String field, LocalDateTime value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.ge(field, DateUtil.getStartOfDay(value)));
			detachedCriteria.add(Restrictions.le(field, DateUtil.getEndOfDay(value)));
		}
	}

	protected void addEq(DetachedCriteria detachedCriteria, String field, Object value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.eq(field, value));
		}
	}

	protected void addNe(DetachedCriteria detachedCriteria, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			detachedCriteria.add(Restrictions.ne(field, value));
		}
	}

	protected void addNe(DetachedCriteria detachedCriteria, String field, Object value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.ne(field, value));
		}
	}

	protected void addLe(DetachedCriteria detachedCriteria, String field, String value) {
		if (!Strings.isNullOrEmpty(value)) {
			detachedCriteria.add(Restrictions.le(field, value));
		}
	}

	protected void addLe(DetachedCriteria detachedCriteria, String field, Object value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.le(field, value));
		}
	}

	protected void addLt(DetachedCriteria detachedCriteria, String field, Object value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.lt(field, value));
		}
	}

	protected void addGt(DetachedCriteria detachedCriteria, String field, Object value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.gt(field, value));
		}
	}

	protected void addGe(DetachedCriteria detachedCriteria, String field, Object value) {
		if (value != null) {
			detachedCriteria.add(Restrictions.ge(field, value));
		}
	}

	protected void addIn(DetachedCriteria detachedCriteria, String field, Object... values) {
		if (values != null && values.length > 0) {
			detachedCriteria.add(Restrictions.in(field, values));
		}
	}

	protected void addIn(DetachedCriteria detachedCriteria, String field, Collection values) {
		if (values != null) {
			detachedCriteria.add(Restrictions.in(field, values));
		}
	}

	protected void addNotIn(DetachedCriteria detachedCriteria, String field, Collection values) {
		if (values != null) {
			detachedCriteria.add(Restrictions.not(Restrictions.in(field, values)));
		}
	}

	protected void addNotIn(DetachedCriteria detachedCriteria, String field, Object... values) {
		if (values != null && values.length > 0) {
			detachedCriteria.add(Restrictions.not(Restrictions.in(field, values)));
		}
	}

	protected void addIsNull(DetachedCriteria detachedCriteria, String field) {
		detachedCriteria.add(Restrictions.isNull(field));
	}

	protected void addIsNotNull(DetachedCriteria detachedCriteria, String field) {
		detachedCriteria.add(Restrictions.isNotNull(field));
	}

	protected void addLikeByMatchMode(DetachedCriteria detachedCriteria, String field, String value, MatchMode matchMode) {
		if (!Strings.isNullOrEmpty(value)) {
			detachedCriteria.add(Restrictions.ilike(field, value, matchMode));
		}
	}

	/**
	 * Adds the DTO projections from the DTO class into the criteria object
	 * 
	 * @param dc
	 * @param dtoClass
	 */
	protected void addDtoProjections(DetachedCriteria dc, Class<?> dtoClass) {
		addDtoProjections(dc, dtoClass, false, null);
	}

	protected void addDtoProjections(DetachedCriteria dc, Class<?> dtoClass, boolean distinct) {
		addDtoProjections(dc, dtoClass, distinct, null);
	}

	protected void addDtoProjections(DetachedCriteria dc, Class<?> dtoClass, boolean distinct, ProjectionList projections) {
		// boolean projectAllFields = true;

		// Create projects for the individual DTO fields
		List<Field> allFields = Lists.newArrayList();

		// Loop through fields of superclass
		Class<?> current = dtoClass;
		while (current != null) {

			Field[] fields = current.getDeclaredFields();
			for (Field f : fields) {

				allFields.add(f);
			}

			current = current.getSuperclass();
		}

		CriteriaImpl criteriaImpl = ClassUtil.getFieldValue(dc, "impl");
		List<Subcriteria> subcriteriaList = ClassUtil.getFieldValue(criteriaImpl, "subcriteriaList");

		Map<String, String> pathToAliasMap = Maps.newHashMapWithExpectedSize(subcriteriaList.size());
		for (Subcriteria subcriteria : subcriteriaList) {
			pathToAliasMap.put(subcriteria.getPath(), subcriteria.getAlias());
		}

		Set<String> createdAliases = Sets.newHashSet();

		if (projections == null) {
			projections = Projections.projectionList();
		}
		for (Field f : allFields) {

			String fieldName = f.getName();

			MapProjection annon = f.getAnnotation(MapProjection.class);
			if (annon != null) {
				String alias = fieldName;
				String path = annon.path();

				if (isNullOrEmpty(path)) {
					// Create projection based on the field name
					path = fieldName;
					alias = fieldName;
				} else if (annon.doNotCreateAlias() == false) {
					List<String> aliasesToCreate = Lists.newArrayList(Splitter.on(".").split(path));
					if (aliasesToCreate.size() > 1) {
						// Removes the field name of the path
						// This will be used by the projection at a later period
						String aliasFieldName = aliasesToCreate.remove(aliasesToCreate.size() - 1);

						String associationPath = "";
						String lastAlias = "";
						String previousAliasPaths = "";
						// Create the criteria aliases based on the paths specified
						for (String aliasPath : aliasesToCreate) {
							// Build association path
							associationPath += aliasPath + ".";

							// The suffix is added here so that we don't get too generic names during the comparison, not too sure
							// if this is really needed
							previousAliasPaths += StringUtils.capitalize(aliasPath);
							String aliasOfPath = previousAliasPaths + "Def";
							lastAlias = aliasOfPath;

							// Strip dot to at end of associationPath before using.
							String associationPathToUse = associationPath.substring(0, associationPath.length() - 1);

							// If the user has already created the alias, use it instead.
							String existingAlias = pathToAliasMap.get(associationPathToUse);
							if (existingAlias != null) {
								lastAlias = existingAlias;
								continue;
							}

							// If the alias path has been created previously, continue on to the next path
							if (createdAliases.add(aliasOfPath) == false) {
								continue;
							}

							dc.createAlias(associationPathToUse, aliasOfPath, JoinType.LEFT_OUTER_JOIN);
						}

						path = lastAlias + "." + aliasFieldName;
					}
				}

				projections.add(Projections.property(path), alias);
			} /*
				 * else if (projectAllFields) { projections.add(Projections.property(fieldName), fieldName); }
				 */
		}

		if (distinct) {
			dc.setProjection(Projections.distinct(projections));
		} else {
			dc.setProjection(projections);
		}

		dc.setResultTransformer(Transformers.aliasToBean(dtoClass));
	}

	@SuppressWarnings("unchecked")
	public <T extends Object> List<T> listByDetachedCriteria(DetachedCriteria detachedCriteria) {
		return listByDetachedCriteria(detachedCriteria, null, null);
	}

	public <T extends Object> List<T> listByDetachedCriteria(DetachedCriteria detachedCriteria, Integer firstResult, Integer maxResult) {
		String test = ((CriteriaImpl) detachedCriteria.getExecutableCriteria(getSession())).getEntityOrClassName();
		try {

			Criteria executableCriteria = detachedCriteria.getExecutableCriteria(getSession());
			if (firstResult != null) {
				executableCriteria.setFirstResult(firstResult);
			}
			if (maxResult != null) {
				executableCriteria.setMaxResults(maxResult);
			}

			List<T> results = executableCriteria.list();

			logger.debug("List by detached criteria for " + test + ", result size: " + results.size());
			return results;
		} catch (Exception re) {
			logger.error("List by detached criteria failed", re);
			throw new RuntimeException(re);
		}
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> getResultSetFromNamedQuery(String namedQuery, Map<String, Object> params) {

		Query query = this.getSession().getNamedQuery(namedQuery);

		if (params != null) {
			setReportParameters(query, params);
		}

		return query.list();
	}

	@SuppressWarnings({ "unchecked" })
	public <T> List<T> getResultSetFromNamedQuery(String namedQuery, Map<String, Object> params, Class<T> clazz) {

		Query query = this.getSession().getNamedQuery(namedQuery);

		if (params != null) {
			setReportParameters(query, params);
		}

		query.setResultTransformer(Transformers.aliasToBean(clazz));

		return query.getResultList();
	}

	@SuppressWarnings("rawtypes")
	private void setReportParameters(Query query, Map<String, Object> params) {

		if (params != null && !params.isEmpty()) {
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				if (entry.getValue() instanceof java.util.Collection) {
					query.setParameterList(entry.getKey(), (java.util.Collection) entry.getValue());
				} else {
					query.setParameter(entry.getKey(), entry.getValue());
				}
			}
		}
	}

}