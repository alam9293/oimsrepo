package gov.stb.tag.repository;

import java.util.List;
import java.util.Optional;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.User;
import gov.stb.tag.model.WorkflowConfig;
import gov.stb.tag.model.WorkflowStep;
import gov.stb.tag.model.WorkflowStepAssignment;

@Repository
public class BaseWorkflowHelperRepository extends BaseRepository {

	public WorkflowConfig getWorkflowConfig(String appOrWkflwType) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowConfig.class);
		dc.add(Restrictions.eq("appOrWkflwType.code", appOrWkflwType));
		return getFirst(dc);
	}

	public Boolean isFinalApproval(String appOrWkflwType, String currentPendingStatusCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowConfig.class);
		dc.createAlias("finalStep", "finalStep");
		dc.add(Restrictions.eq("appOrWkflwType.code", appOrWkflwType));
		dc.add(Restrictions.eq("finalStep.startStatus.code", currentPendingStatusCode));
		dc.setProjection(Projections.rowCount());
		return Long.valueOf(1).equals(getProjectedFirstValue(dc));
	}

	public List<WorkflowStep> getWorkflowStepsByWorkflowStepType(String workflowStepType) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStep.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "type.code", workflowStepType);
		dc.addOrder(Order.asc("level"));
		return getList(dc);
	}

	public List<WorkflowConfig> getWorkflowConfigsByStepType(String workflowStepType) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowConfig.class);
		dc.createAlias("appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isConfigurable", true));
		dc.add(Restrictions.ilike("appOrWkflwType.code", getApplicationTypeByWorkflowStepType(workflowStepType), MatchMode.START));
		return getList(dc);
	}

	private String getApplicationTypeByWorkflowStepType(String workflowStepType) {
		String applicationType = null;
		switch (workflowStepType) {
		case Codes.WorkflowStep.WKFLW_STEP_TA_APPLICATION:
			applicationType = Codes.TypeCategories.TA_APPLICATION_TYPE;
			break;
		case Codes.WorkflowStep.WKFLW_STEP_TA:
			applicationType = Codes.TypeCategories.TA_WORKFLOW;
			break;
		case Codes.WorkflowStep.WKFLW_STEP_TG_APPLICATION:
			applicationType = Codes.TypeCategories.TG_APPLICATION_TYPE;
			break;
		case Codes.WorkflowStep.WKFLW_STEP_TG:
			applicationType = Codes.TypeCategories.TG_WORKFLOW;
			break;
		case Codes.WorkflowStep.WKFLW_STEP_CE:
			// TODO : phase 2
			break;
		}

		return applicationType;
	}

	public List<User> getOfficersByStatusCode(String statusCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);

		DetachedCriteria subCriteria = DetachedCriteria.forClass(WorkflowStep.class);
		subCriteria.add(Restrictions.eq("startStatus.code", statusCode));
		subCriteria.setProjection(Projections.property("role.code"));

		dc.add(Subqueries.propertyIn("r.code", subCriteria));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		return getList(dc);
	}

	public WorkflowStep getWorkflowStepByStartStatusCode(String startStatusCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStep.class);
		addEq(dc, "startStatus.code", startStatusCode);
		return getFirst(dc);
	}

	public List<WorkflowStepAssignment> getWorkflowStepAssignmentsByAppTypeAndCurrentLevel(String appType, Integer currentLevel) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStepAssignment.class);
		dc.createAlias("workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowConfig.appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStep", "workflowStep", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "appOrWkflwType.code", appType);
		addLt(dc, "workflowStep.level", currentLevel);
		dc.addOrder(Order.asc("workflowStep.level"));
		return getList(dc);
	}

	public WorkflowStepAssignment getWorkflowStepAssignmentByAppTypeAndStatusCode(String appType, String statusCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStepAssignment.class);
		dc.createAlias("workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowConfig.appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStep", "workflowStep", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "appOrWkflwType.code", appType);
		addEq(dc, "workflowStep.startStatus.code", statusCode);
		return getFirst(dc);
	}

	public List<WorkflowStepAssignment> getWorkflowStepAssignmentsByStepType(String workflowStepType) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStepAssignment.class);
		dc.createAlias("workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowConfig.appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowStep", "workflowStep", JoinType.LEFT_OUTER_JOIN);
		addLikeByMatchMode(dc, "appOrWkflwType.code", getApplicationTypeByWorkflowStepType(workflowStepType), MatchMode.START);
		dc.addOrder(Order.asc("workflowStep.level"));
		return getList(dc);
	}

	public List<WorkflowStepAssignment> getWorkflowStepAssignmentsByAppTypeAndWorkflowId(String appOrWkflwTypeCode, Optional<Integer> workflowId) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStepAssignment.class);
		dc.createAlias("workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowConfig.appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "appOrWkflwType.code", appOrWkflwTypeCode);

		if (workflowId.isEmpty()) {
			addIsNull(dc, "workflow");
		} else {
			dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
			addEq(dc, "workflow.id", workflowId.get());
		}

		return getList(dc);
	}

	public List<WorkflowStepAssignment> getWorkflowStepAssignmentsByWkflwType(String wkflwTypeCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowStepAssignment.class);
		dc.createAlias("workflowConfig", "workflowConfig", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflowConfig.appOrWkflwType", "appOrWkflwType", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "appOrWkflwType.code", wkflwTypeCode);
		addIsNull(dc, "workflow");
		return getList(dc);
	}

}
