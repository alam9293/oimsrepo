package gov.stb.tag.repository;

import java.util.List;
import java.util.Map;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.Entities;
import gov.stb.tag.model.Function;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.SystemParameter;
import gov.stb.tag.model.TaKeClause;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;

@Repository
public class CacheRepository extends BaseRepository {

	@Cacheable("typesMap")
	public Map<String, Type> getAllTypes() {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.createAlias("category", "category", JoinType.LEFT_OUTER_JOIN);
		dc.addOrder(Order.asc("category.code"));
		dc.addOrder(Order.asc("ordinal"));
		return Entities.mapCodeValues(getList(dc));
	}

	@Cacheable("typesMapOrderLabel")
	public Map<String, Type> getAllTypesOrderByLabel() {
		DetachedCriteria dc = DetachedCriteria.forClass(Type.class);
		dc.createAlias("category", "category", JoinType.LEFT_OUTER_JOIN);
		dc.addOrder(Order.asc("label"));
		return Entities.mapCodeValues(getList(dc));
	}

	@Cacheable("statusesMap")
	public Map<String, Status> getAllStatuses() {
		DetachedCriteria dc = DetachedCriteria.forClass(Status.class);
		dc.createAlias("category", "category", JoinType.LEFT_OUTER_JOIN);
		dc.addOrder(Order.asc("category.code"));
		dc.addOrder(Order.asc("ordinal"));
		return Entities.mapCodeValues(getList(dc));
	}

	@Cacheable("systemParametersMap")
	public Map<String, SystemParameter> getAllSystemParameters() {
		DetachedCriteria dc = DetachedCriteria.forClass(SystemParameter.class);
		dc.createAlias("dataType", "dataType", JoinType.LEFT_OUTER_JOIN);
		dc.addOrder(Order.asc("dataType.code"));
		dc.addOrder(Order.asc("ordinal"));
		return Entities.mapCodeValues(getList(dc));
	}

	@Cacheable("taKeClausesMap")
	public Map<Integer, TaKeClause> getAllTaKeClause() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaKeClause.class);
		dc.addOrder(Order.asc("ordinal"));
		return Entities.mapIdValues(getList(dc));
	}

	@Cacheable("taKeClausesForRenewalMap")
	public Map<Integer, TaKeClause> getAllTaKeClauseForRenewal() {
		DetachedCriteria dc = DetachedCriteria.forClass(TaKeClause.class);
		dc.addOrder(Order.asc("ordinal"));
		addEq(dc, "isNotForRenewal", Boolean.FALSE);
		return Entities.mapIdValues(getList(dc));
	}

	@Cacheable("functionsMap")
	public Map<String, Function> getAllFunctions() {
		DetachedCriteria dc = DetachedCriteria.forClass(Function.class);
		dc.createAlias("module", "module", JoinType.LEFT_OUTER_JOIN);
		dc.addOrder(Order.asc("module.code"));
		dc.addOrder(Order.asc("code"));
		return Entities.mapCodeValues(getList(dc));
	}

	@Cacheable("rolesMap")
	public Map<String, Role> getAllRoles() {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		dc.addOrder(Order.asc("ordinal"));
		return Entities.mapCodeValues(getList(dc));
	}

	public List<Object[]> getAllUserRoles() {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "roles");
		dc.addOrder(Order.asc("name"));
		ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("id"));
		projectionList.add(Projections.property("name"));
		projectionList.add(Projections.property("status.code"));
		projectionList.add(Projections.property("roles.code"));
		projectionList.add(Projections.property("roles.name"));
		dc.setProjection(projectionList);
		return getProjectedList(dc);
	}

	public Map<String, Function> getModFunctions(String module) {
		DetachedCriteria dc = DetachedCriteria.forClass(Function.class);
		dc.createAlias("module", "module", JoinType.LEFT_OUTER_JOIN);

		if (Strings.isNullOrEmpty(module) || "undefined".equals(module)) {
			dc.add(Restrictions.in("module.code", Codes.Mod.MODLIST));
		} else {
			dc.add(Restrictions.eq("module.code", module));
		}

		dc.addOrder(Order.asc("module.code"));
		dc.addOrder(Order.asc("label"));
		return Entities.mapCodeValues(getList(dc));
	}

}
