package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes.CeCaseStatus;
import gov.stb.tag.model.CeCase;
import gov.stb.tag.model.CeCaseAppeal;
import gov.stb.tag.model.CeCaseDecision;
import gov.stb.tag.model.CeCaseRecommendation;
import gov.stb.tag.model.CeTaCheck;

@Repository
public class CeCaseRepository extends BaseRepository {

	public CeCase getCeCaseById(Integer ceCaseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);
		dc.createAlias("files", "files", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTgFieldReport", "ceTgFieldReport", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaChecks", "ceTaChecks", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaFieldReports", "ceTaFieldReports", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseComplainants", "ceCaseComplainants", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseComplainants.files", "complainantFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringements", "ceCaseInfringements", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringements.ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringements.ceProvision", "ceProvision", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceOriginatingCaseInfringements", "ceOriginatingCaseInfringements", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceOriginatingCaseInfringements.ceCaseInfringer", "ceOriginatingCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceOriginatingCaseInfringements.ceProvision", "ceOriginatingCaseProvision", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("id", ceCaseId));
		dc.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return getFirst(dc);
	}

	public CeCase getRevisitCasesFromTatiCheck(CeTaCheck ceTaCheck) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);
		dc.createAlias("ceTaCheck", "ceTaCheck", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaCheck.ceTaCheckScheduleItem", "ceTaCheckScheduleItem", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceTaCheck.addressType", "addressType", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", CeCaseStatus.CE_CASE_LIVE));
		dc.add(Restrictions.eq("ceTaCheckScheduleItem.toRevisit", Boolean.TRUE));
		dc.add(Restrictions.eq("ceTaCheck.licenceNo", ceTaCheck.getLicenceNo()));
		dc.add(Restrictions.eq("addressType.code", ceTaCheck.getAddressType().getCode()));

		return getFirst(dc);
	}

	public CeCase getOpenCaseFromCrmNo(String crmRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", CeCaseStatus.CE_CASE_LIVE));
		dc.add(Restrictions.eq("crmRefNo", crmRefNo));
		dc.addOrder(Order.desc("id"));

		return getFirst(dc);
	}

	public CeCase getCaseFromCaseNo(String caseNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);
		dc.add(Restrictions.eq("caseNo", caseNo));
		dc.addOrder(Order.desc("id"));

		return getFirst(dc);
	}

	public CeCase getCaseFromTgFieldReport(Integer ceTgFieldReportId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);
		dc.createAlias("ceTgFieldReport", "ceTgFieldReport", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("ceTgFieldReport.id", ceTgFieldReportId));

		return getFirst(dc);
	}

	public List<CeCase> getChildCaseByCaseId(Integer ceCaseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCase.class);
		dc.createAlias("taggedCase", "taggedCase", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "taggedCase.id", ceCaseId);
		return getList(dc);
	}

	public CeCaseDecision getDecisionById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseDecision.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	public CeCaseAppeal getAppealById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseAppeal.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		addEq(dc, "id", id);
		dc.add(Restrictions.eq("ceCaseInfringement.isDeleted", Boolean.FALSE));
		return getFirst(dc);
	}

	public CeCaseRecommendation getRecommendationById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseRecommendation.class);
		dc.createAlias("ceCaseInfringement", "ceCaseInfringement", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringement.ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow", "workflow", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("workflow.lastAction.status", "status", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}
}
