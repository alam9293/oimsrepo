package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.dto.CeProvisionReadWithDto;
import gov.stb.tag.dto.ResultDto;
import gov.stb.tag.dto.SearchDto;
import gov.stb.tag.model.CeProvision;

@Repository
public class CeProvisionRepository extends BaseRepository {

	public CeProvision getCeProvisionBySection(String section) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		dc.add(Restrictions.eq("section", section));
		dc.add(Restrictions.le("effectiveDate", LocalDate.now()));
		dc.add(Restrictions.or(Restrictions.isNull("ineffectiveDate"), Restrictions.gt("ineffectiveDate", LocalDate.now())));
		return getFirst(dc);
	}

	public CeProvision getCeProvisionBySection(String section, LocalDate date) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		dc.add(Restrictions.eq("section", section));
		dc.add(Restrictions.le("effectiveDate", date));
		dc.add(Restrictions.or(Restrictions.isNull("ineffectiveDate"), Restrictions.gt("ineffectiveDate", date)));

		return getFirst(dc);
	}

	public CeProvision getCeProvisionBySectionAndChapter(String section, String chapterCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		dc.add(Restrictions.eq("section", section));
		dc.add(Restrictions.eq("chapter.code", chapterCode));
		return getFirst(dc);
	}

	public CeProvision getCeProvisionBySection(String section, Boolean effectiveOnly) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		dc.add(Restrictions.eq("section", section));
		if (effectiveOnly) {
			dc.add(Restrictions.le("effectiveDate", LocalDate.now()));
			dc.add(Restrictions.or(Restrictions.isNull("ineffectiveDate"), Restrictions.gt("ineffectiveDate", LocalDate.now())));
		}

		return getFirst(dc);
	}

	public List<CeProvision> getCeProvisionsBySections(Object[] sections) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		addIn(dc, "section", sections);
		dc.add(Restrictions.le("effectiveDate", LocalDate.now()));
		dc.add(Restrictions.or(Restrictions.isNull("ineffectiveDate"), Restrictions.gt("ineffectiveDate", LocalDate.now())));

		return getList(dc);
	}

	public List<CeProvision> getCeOffenceProvisions() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		addEq(dc, "isOffence", Boolean.TRUE);
		addLe(dc, "effectiveDate", LocalDate.now());
		dc.add(Restrictions.or(Restrictions.isNull("ineffectiveDate"), Restrictions.gt("ineffectiveDate", LocalDate.now())));

		return getList(dc);
	}

	public List<CeProvision> getAllCeOffenceProvisions() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		addLe(dc, "effectiveDate", LocalDate.now());
		dc.add(Restrictions.or(Restrictions.isNull("ineffectiveDate"), Restrictions.gt("ineffectiveDate", LocalDate.now())));

		return getList(dc);
	}

	public List<CeProvisionReadWithDto> getAllProvisionReadWiths() {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		dc.createAlias("readWiths", "readWiths", JoinType.INNER_JOIN);
		addEq(dc, "isReadWithOnly", Boolean.FALSE);

		addDtoProjections(dc, CeProvisionReadWithDto.class);

		return getList(dc);
	}

	public List<CeProvision> getAllCeProvisionsByChapter(List<String> chapters) {
		return getAllCeProvisionsByChapter(chapters, true);
	}

	public List<CeProvision> getAllCeProvisionsByChapter(List<String> chapters, Boolean isProvisionOnly) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		if (CollectionUtils.isNotEmpty(chapters)) {
			addIn(dc, "chapter.code", chapters);
		}
		if (isProvisionOnly) {
			addEq(dc, "isReadWithOnly", Boolean.FALSE);
		}
		addLe(dc, "effectiveDate", LocalDate.now());
		dc.add(Restrictions.or(Restrictions.isNull("ineffectiveDate"), Restrictions.gt("ineffectiveDate", LocalDate.now())));
		return getList(dc);
	}

	public ResultDto<CeProvision> getInactiveCeProvisionsByChapter(List<String> chapters, SearchDto searchDto, String readwithOrProvision) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		if (CollectionUtils.isNotEmpty(chapters)) {
			addIn(dc, "chapter.code", chapters);
		}
		if (readwithOrProvision.equals("READWITHS")) {
			dc.add(Restrictions.eq("isReadWithOnly", true));
		} else {
			dc.add(Restrictions.eq("isReadWithOnly", false));
		}
		dc.add(Restrictions.or(Restrictions.le("ineffectiveDate", LocalDate.now()), Restrictions.gt("effectiveDate", LocalDate.now())));
		return search(dc, searchDto, true);
	}

	public List<CeProvision> getAllCeReadWithsByChapter(List<String> chapters) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeProvision.class);
		if (CollectionUtils.isNotEmpty(chapters)) {
			addIn(dc, "chapter.code", chapters);
		}
		addEq(dc, "isReadWithOnly", Boolean.TRUE);
		return getList(dc);
	}

}
