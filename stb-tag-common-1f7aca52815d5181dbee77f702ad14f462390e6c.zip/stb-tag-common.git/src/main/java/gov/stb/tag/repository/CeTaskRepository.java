package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.CeTask;

@Repository
public class CeTaskRepository extends BaseRepository {

	public List<CeTask> getOpenCeTasksByWorkflowId(Integer workflowId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forWorkflow.id", workflowId));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));

		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByTaFilingConditionId(Integer taFilingConditionId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forFilingCondition.id", taFilingConditionId));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));

		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByInfringementId(Integer infringementId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forInfringement.id", infringementId));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));

		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByScheduleMonth(Integer year, Integer month) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forScheduleYear", year));
		dc.add(Restrictions.eq("forScheduleMonth", month));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));

		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByScheduleWeek(Integer year, LocalDate fromDate, LocalDate toDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forScheduleYear", year));
		dc.add(Restrictions.eq("forScheduleFromDate", fromDate));
		dc.add(Restrictions.eq("forScheduleToDate", toDate));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));

		return getList(dc);
	}

	public List<CeTask> getCeTasksByLicence(Integer licenceId, String taskType, String taskStatus) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("type.code", taskType));
		dc.add(Restrictions.eq("status.code", taskStatus));

		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByCaseId(Integer caseId, boolean isRescind) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forCase.id", caseId));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));
		addIsNull(dc, "forBillRefNo");

		if (isRescind) {
			dc.add(Restrictions.eq("type.code", Codes.CeTaskTypes.CE_TASK_RESCIND));
		} else {
			dc.add(Restrictions.or(Restrictions.ne("type.code", Codes.CeTaskTypes.CE_TASK_RESCIND), Restrictions.isNull("type.code")));
		}
		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByCaseId(Integer caseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forCase.id", caseId));
		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByIpId(Integer caseId, boolean isPaymentExpiry) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forCase.id", caseId));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));
		addIsNull(dc, "forBillRefNo");

		if (isPaymentExpiry) {
			dc.add(Restrictions.eq("type.code", Codes.CeTaskTypes.CE_TASK_PAYMENT_EXPIRY));
		} else {
			dc.add(Restrictions.ne("type.code", Codes.CeTaskTypes.CE_TASK_PAYMENT_EXPIRY));
		}
		return getList(dc);
	}

	public CeTask getCeTasksByCaseId(Integer caseId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forCase.id", caseId));
		return getFirst(dc);
	}

	public List<CeTask> getOpenCeTask(String taskType, List<Integer> excludeIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.createAlias("oic", "oic", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "type.code", taskType);
		addNe(dc, "status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED);
		if (CollectionUtils.isNotEmpty(excludeIds)) {
			dc.add(Restrictions.not(Restrictions.in("id", excludeIds)));
		}
		return getList(dc);
	}

	public List<CeTask> getOpenCeTasksByBillRefNo(String billRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("forBillRefNo", billRefNo));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));

		return getList(dc);
	}

	public List<CeTask> getOpenSuspensionEndCeTasksByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeTask.class);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.ne("status.code", Codes.CeTaskStatus.CE_TASK_COMPLETED));
		dc.add(Restrictions.eq("type.code", Codes.CeTaskTypes.CE_TASK_SUSPEND_END));

		return getList(dc);
	}

	public CeCaseInfringement searchKeR153bInfringementLiveCase(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		dc.createAlias("ceProvision", "ceProvision", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCase", "ceCase", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "ceCaseInfringer.licence.id", licenceId);
		addEq(dc, "ceProvision.section", Codes.CeProvisionSection.KE_VACANT);
		addEq(dc, "ceCase.status.code", Codes.CeCaseStatus.CE_CASE_LIVE);

		return getFirst(dc);
	}
}
