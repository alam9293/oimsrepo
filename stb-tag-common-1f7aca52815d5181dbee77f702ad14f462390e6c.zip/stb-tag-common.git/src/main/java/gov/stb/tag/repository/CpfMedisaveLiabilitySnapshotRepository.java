package gov.stb.tag.repository;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;


import gov.stb.tag.model.CpfMedisaveLiabilitySnapshot;


@Repository

public class CpfMedisaveLiabilitySnapshotRepository extends BaseRepository {
    public CpfMedisaveLiabilitySnapshot getByUin(String uin) {
        DetachedCriteria dc = DetachedCriteria.forClass(CpfMedisaveLiabilitySnapshot.class);
        dc.add(Restrictions.eq("uinfin", uin));
        return getFirst(dc);
    }
}
