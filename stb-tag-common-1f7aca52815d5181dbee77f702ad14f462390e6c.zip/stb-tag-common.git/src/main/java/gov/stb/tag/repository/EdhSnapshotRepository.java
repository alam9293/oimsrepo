package gov.stb.tag.repository;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.EdhSnapshot;

@Repository

public class EdhSnapshotRepository extends BaseRepository {

	public EdhSnapshot getByUenApiName(String uen, String apiName) {
		DetachedCriteria dc = DetachedCriteria.forClass(EdhSnapshot.class);
		dc.add(Restrictions.eq("uen", uen));
		dc.add(Restrictions.eq("apiName", apiName));
		return getFirst(dc);
	}
}
