package gov.stb.tag.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.EmailLicenseeDto;
import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.Status;
import gov.stb.tag.model.Type;

@Repository
public class EmailBroadcastCommonRepository extends BaseRepository {

	public List<EmailLicenseeDto> getListOfTgLicence(EmailBroadcast searchDto) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("touristGuide.salutation", "salutation", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("taTgType", Codes.TaTgType.TG));

		if (searchDto.getLicenceStatuses() != null && !searchDto.getLicenceStatuses().isEmpty()) {
			List<String> statuses = searchDto.getLicenceStatuses().stream().map(Status::getCode).collect(Collectors.toList());
			dc.add(Restrictions.in("status.code", statuses));
		}

		if (searchDto.getGuidingLanguages() != null && !searchDto.getGuidingLanguages().isEmpty()) {
			List<String> languages = searchDto.getGuidingLanguages().stream().map(Type::getCode).collect(Collectors.toList());

			var subCriteria = DetachedCriteria.forClass(Licence.class);
			subCriteria.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
			subCriteria.createAlias("touristGuide.guidingLanguages", "guidingLanguages", JoinType.LEFT_OUTER_JOIN);
			subCriteria.add(Restrictions.in("guidingLanguages.code", languages));
			subCriteria.setProjection(Projections.property("id"));
			subCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

			dc.add(Subqueries.propertyIn("id", subCriteria));
		}

		if (searchDto.getTiers() != null && !searchDto.getTiers().isEmpty()) {
			List<String> tiers = searchDto.getTiers().stream().map(Type::getCode).collect(Collectors.toList());
			dc.add(Restrictions.in("tier.code", tiers));
		}

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("touristGuide.uin"));
		projections.add(Projections.property("touristGuide.name"), "name");
		projections.add(Projections.property("salutation.label"), "salutation");
		projections.add(Projections.property("touristGuide.emailAddress"), "email");
		projections.add(Projections.property("id"), "licenceId");
		projections.add(Projections.property("licenceNo"), "licNo");
		dc.setProjection(projections);
		dc.setResultTransformer(Transformers.aliasToBean(EmailLicenseeDto.class));

		return getList(dc);
	}

	public List<EmailLicenseeDto> getActiveTaLicences() {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("travelAgent", "travelAgent", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("tier", "tier", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "status.code", Codes.TaStatuses.GENERALLY_ACTIVE);
		// addIn(dc, "status.code", "TA_S");

		addEq(dc, "taTgType", Codes.TaTgType.TA);

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.property("travelAgent.emailAddress"), "email");
		projections.add(Projections.property("travelAgent.name"), "name");
		projections.add(Projections.property("travelAgent.uen"), "uen");
		projections.add(Projections.property("travelAgent.id"), "travelAgentId");
		projections.add(Projections.property("status.label"), "licStatus");
		projections.add(Projections.property("tier.label"), "licType");
		projections.add(Projections.property("id"), "licenceId");
		projections.add(Projections.property("licenceNo"), "licNo");
		dc.setProjection(projections);
		dc.setResultTransformer(Transformers.aliasToBean(EmailLicenseeDto.class));

		return getList(dc);
	}

}
