package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.EmailBroadcast;
import gov.stb.tag.model.EmailTemplate;
import gov.stb.tag.model.SystemParameter;

@Repository
public class EmailRepository extends BaseRepository {

	public List<EmailTemplate> getEmailTemplatesByCode(List<String> emailCodes) {
		DetachedCriteria dc = DetachedCriteria.forClass(EmailTemplate.class);
		addIn(dc, "code", emailCodes);
		addEq(dc, "isActive", Boolean.TRUE);
		dc.addOrder(Order.desc("code"));
		return getList(dc);
	}

	public EmailTemplate getEmailTemplateByCode(String emailTypeCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(EmailTemplate.class);
		addEq(dc, "code", emailTypeCode);
		addEq(dc, "isActive", Boolean.TRUE);
		return getFirst(dc);
	}

	public List<EmailBroadcast> getActiveEmailBroadcast(LocalDate todayDate) {
		DetachedCriteria dc = DetachedCriteria.forClass(EmailBroadcast.class);
		addEq(dc, "isActive", Boolean.TRUE);
		addEq(dc, "isSending", Boolean.FALSE);
		dc.add(Restrictions.eq("nextEmailDate", todayDate));
		// dc.add(Restrictions.ge("startDate", todayDate));
		// dc.add(Restrictions.disjunction().add(Restrictions.isNull("endDate")).add((Restrictions.gt("endDate", todayDate))));
		return getList(dc);
	}

	public SystemParameter getSystemParameterByCode(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(SystemParameter.class);
		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

}
