package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.ApplicationFile;
import gov.stb.tag.model.DocumentTemplate;
import gov.stb.tag.model.File;
import gov.stb.tag.model.WorkflowFile;

@Repository
public class FileRepository extends BaseRepository {

	public ApplicationFile getAppFile(Integer fileId) {
		DetachedCriteria dc = DetachedCriteria.forClass(ApplicationFile.class);
		dc.createAlias("file", "file", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("file.id", fileId));
		dc.add(Restrictions.eq("isDeleted", false));
		return getFirst(dc);
	}

	public File getFile(Integer fileId) {
		DetachedCriteria dc = DetachedCriteria.forClass(File.class);
		dc.add(Restrictions.eq("id", fileId));
		dc.add(Restrictions.eq("isDeleted", false));
		return getFirst(dc);
	}

	public DocumentTemplate getTemplate(String docType) {
		DetachedCriteria dc = DetachedCriteria.forClass(DocumentTemplate.class);
		dc.add(Restrictions.eq("type.code", docType));
		return getFirst(dc);
	}

	public WorkflowFile getWorkflowFile(Integer workflowFileId) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowFile.class);
		dc.createAlias("file", "file", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", workflowFileId));
		dc.add(Restrictions.eq("isDeleted", false));
		return getFirst(dc);
	}

	public List<File> getFilesByStatuses(String... statusCodes) {
		DetachedCriteria dc = DetachedCriteria.forClass(File.class);
		dc.add(Restrictions.in("transferStatus.code", statusCodes));
		return getList(dc);
	}

	public List<File> getFiles(List<Integer> fileIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(File.class);
		dc.add(Restrictions.in("id", fileIds));
		dc.add(Restrictions.eq("isDeleted", false));
		return getList(dc);
	}

	public List<WorkflowFile> getWorkflowFilesByFileIds(List<Integer> fileIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(WorkflowFile.class);
		dc.createAlias("file", "file", JoinType.LEFT_OUTER_JOIN);
		addIn(dc, "file.id", fileIds);
		dc.add(Restrictions.eq("isDeleted", false));
		return getList(dc);
	}
}
