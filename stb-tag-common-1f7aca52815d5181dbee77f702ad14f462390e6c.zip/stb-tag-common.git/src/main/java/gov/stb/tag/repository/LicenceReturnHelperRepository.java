package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.LicenceReturn;

@Repository
public class LicenceReturnHelperRepository extends BaseRepository {

	public Boolean checkForPendingRecordsForBatch(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(LicenceReturn.class);
		dc.createAlias("batch", "batch", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.isNull("returnedDate"));
		dc.add(Restrictions.isNull("branch"));
		dc.add(Restrictions.eq("batch.id", id));
		ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("id"));
		dc.setProjection(projectionList);
		List<Object> result = listByDetachedCriteria(dc);

		if (result.size() > 0) {
			return true;
		} else {
			return false;
		}

	}

}
