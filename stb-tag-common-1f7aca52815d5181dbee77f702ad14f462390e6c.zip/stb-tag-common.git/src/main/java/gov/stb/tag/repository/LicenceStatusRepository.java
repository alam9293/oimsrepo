package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.StatusSpan;
import gov.stb.tag.model.TaBranch;

@Repository
public class LicenceStatusRepository extends BaseRepository {

	public StatusSpan getLastStatusSpan(Licence licence) {
		DetachedCriteria dc = DetachedCriteria.forClass(StatusSpan.class);
		dc.add(Restrictions.eq("licence.id", licence.getId()));
		dc.add(Restrictions.isNull("endDate"));
		return getFirst(dc);
	}

	public Licence getLicenceDetailsByTgId(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.createAlias("touristGuide", "touristGuide", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("touristGuide.id", id));
		return getFirst(dc);
	}

	public Licence getLicenceDetailByLicenceNo(String licenceNo, String taTgType) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.eq("licenceNo", licenceNo));
		dc.add(Restrictions.eq("taTgType", taTgType));
		return getFirst(dc);
	}

	public List<Licence> getLicenceListByLicenceNo(List<String> licenceNos, String taTgType) {
		DetachedCriteria dc = DetachedCriteria.forClass(Licence.class);
		dc.add(Restrictions.in("licenceNo", licenceNos));
		dc.add(Restrictions.eq("taTgType", taTgType));
		return getList(dc);
	}

	public StatusSpan getLastStatusSpan(Integer licId, List<String> excludedStatus) {
		DetachedCriteria dc = DetachedCriteria.forClass(StatusSpan.class);
		dc.createAlias("status", "status", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licId);
		addNotIn(dc, "status.code", excludedStatus);
		dc.addOrder(Order.desc("id"));
		return getFirst(dc);
	}

	public List<TaBranch> getAllMSuspendedBranchesByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_BRANCH_M_SUSPEND));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<TaBranch> getAllActiveBranchesByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.eq("status.code", Codes.Statuses.TA_BRANCH_ACTIVE));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}

	public List<TaBranch> getAllActiveSuspendedBranchesByLicenceId(Integer licenceId) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaBranch.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.in("status.code", Codes.Statuses.TA_BRANCH_ACTIVE, Codes.Statuses.TA_BRANCH_M_SUSPEND));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}
}
