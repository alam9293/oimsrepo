package gov.stb.tag.repository;

import gov.stb.tag.model.MyInfoSnapshot;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

@Repository

public class MyInfoSnapshotRepository extends BaseRepository{

    public MyInfoSnapshot getByUin(String uin) {
        DetachedCriteria dc = DetachedCriteria.forClass(MyInfoSnapshot.class);
        dc.add(Restrictions.eq("uinfin", uin));
        return getFirst(dc);
    }
}
