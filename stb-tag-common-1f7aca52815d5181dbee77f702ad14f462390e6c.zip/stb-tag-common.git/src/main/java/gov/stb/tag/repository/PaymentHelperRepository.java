package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.PaymentRequest;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.WaiveType;

@Repository
public class PaymentHelperRepository extends BaseRepository {

	public Boolean isBillRefNoExist(String billRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.setProjection(Projections.rowCount());
		dc.add(Restrictions.eq("billRefNo", billRefNo));
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount != null && rowCount > 0;
	}

	public PaymentRequest getPaymentRequest(String billRefNo) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.add(Restrictions.eq("billRefNo", billRefNo));
		return getFirst(dc);
	}

	public List<PaymentRequest> getPaymentRequests(List<Integer> ids) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.add(Restrictions.in("id", ids));
		return getList(dc);
	}

	public List<PaymentRequest> getPaymentRequestByLastTxnId(Integer txnId) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.add(Restrictions.eq("lastTxn.id", txnId));
		return getList(dc);
	}

	public List<PaymentRequest> getPaymentRequestsByBillRefNo(List<String> billRefNos) {
		DetachedCriteria dc = DetachedCriteria.forClass(PaymentRequest.class);
		dc.add(Restrictions.in("billRefNo", billRefNos));
		return getList(dc);
	}

	public List<WaiveType> getAllWaiveTypes() {
		DetachedCriteria dc = DetachedCriteria.forClass(WaiveType.class);
		dc.add(Restrictions.eq("isWaive", Boolean.TRUE));
		return getList(dc);
	}

	public WaiveType getWaiveTypeByPaymentRequestType(String paymentReqType) {
		DetachedCriteria dc = DetachedCriteria.forClass(WaiveType.class);
		dc.createAlias("type", "type", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("isWaive", true));
		dc.add(Restrictions.eq("type.code", paymentReqType));
		return getFirst(dc);
	}

	public TouristGuide getTouristGuideByUin(String uin) {
		var dc = DetachedCriteria.forClass(TouristGuide.class);
		dc.createAlias("licence", "licence");
		dc.add(Restrictions.eq("uin", uin));
		return getFirst(dc);
	}

	public Boolean getIsAtg(String uin) {
		var dc = DetachedCriteria.forClass(TgCandidate.class);
		dc.setProjection(Projections.rowCount());
		dc.createAlias("lastCandidateResult", "lastCandidateResult", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("lastCandidateResult.tier", "tier", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("uin", uin));
		dc.add(Restrictions.eq("tier.code", Codes.Types.TG_TIER_AREA));
		Long rowCount = (Long) getProjectedFirstValue(dc);
		return rowCount != null && rowCount > 0;
	}

}
