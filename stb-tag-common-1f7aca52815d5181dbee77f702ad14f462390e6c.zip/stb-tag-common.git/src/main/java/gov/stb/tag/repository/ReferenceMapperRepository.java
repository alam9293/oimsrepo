package gov.stb.tag.repository;

import org.springframework.stereotype.Repository;

@Repository
public class ReferenceMapperRepository extends BaseRepository {

}
