package gov.stb.tag.repository;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.stereotype.Repository;

import gov.stb.tag.model.SmsTemplate;

@Repository
public class SmsRepository extends BaseRepository {

	public SmsTemplate getSmsTemplateByCode(String smsCode) {
		DetachedCriteria dc = DetachedCriteria.forClass(SmsTemplate.class);
		addIn(dc, "code", smsCode);
		return getFirst(dc);
	}
}
