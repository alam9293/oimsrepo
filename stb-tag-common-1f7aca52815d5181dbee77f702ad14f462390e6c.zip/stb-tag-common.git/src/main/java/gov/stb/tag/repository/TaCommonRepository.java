package gov.stb.tag.repository;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.model.CeCaseInfringement;
import gov.stb.tag.model.Stakeholder;
import gov.stb.tag.model.TaLicenceCreation;
import gov.stb.tag.model.TaStakeholder;

@Repository
public class TaCommonRepository extends BaseRepository {

	/**
	 * Get current KE details from licence ID
	 * 
	 * @param licence
	 *            Id
	 * @return Stakeholder
	 */
	public Stakeholder getExistingKe(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(Stakeholder.class);
		dc.createAlias("taStakeholders", "taStakeholders", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders.role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", id);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		dc.add(Restrictions.le("taStakeholders.appointedDate", LocalDate.now()));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("taStakeholders.resignedDate")).add(Restrictions.ge("taStakeholders.resignedDate", LocalDate.now())));
		return getFirst(dc);
	}

	public TaStakeholder getExistingKeTaStakeholder(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", id);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		dc.add(Restrictions.le("appointedDate", LocalDate.now()));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		return getFirst(dc);
	}

	public TaStakeholder getKeToBe(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", id);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		dc.add(Restrictions.gt("appointedDate", LocalDate.now()));
		return getFirst(dc);
	}

	public Stakeholder getExistingKeNotResigned(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(Stakeholder.class);
		dc.createAlias("taStakeholders", "taStakeholders", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders.role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", id);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		dc.add(Restrictions.le("taStakeholders.appointedDate", LocalDate.now()));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("taStakeholders.resignedDate")));
		return getFirst(dc);
	}

	public List<TaStakeholder> getKeyExecutiveByLicenceIds(List<Integer> licenceIds) {
		var dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("role.code", Codes.TaStakeholderRoles.STKHLD_KE));
		dc.add(Restrictions.in("licence.id", licenceIds));
		dc.add(Restrictions.le("appointedDate", LocalDate.now()));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		return getList(dc);
	}

	public TaStakeholder getTaLastResignedKe(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.add(Restrictions.eq("role.code", Codes.TaStakeholderRoles.STKHLD_KE));
		dc.add(Restrictions.isNotNull("resignedDate"));
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.addOrder(Order.desc("resignedDate"));

		return getFirst(dc);
	}

	public TaStakeholder getTaFutureAppointedKe(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.add(Restrictions.eq("role.code", Codes.TaStakeholderRoles.STKHLD_KE));
		dc.add(Restrictions.eq("licence.id", licenceId));
		dc.add(Restrictions.isNull("resignedDate"));
		dc.add(Restrictions.ge("appointedDate", LocalDate.now()));
		dc.addOrder(Order.desc("appointedDate"));

		return getFirst(dc);
	}

	public Stakeholder getTaLatestAppointedKe(Integer licenceId) {

		DetachedCriteria dc = DetachedCriteria.forClass(Stakeholder.class);
		dc.createAlias("taStakeholders", "taStakeholders", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders.role", "role", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders.licence", "licence", JoinType.LEFT_OUTER_JOIN);
		addEq(dc, "licence.id", licenceId);
		addEq(dc, "role.code", Codes.TaStakeholderRoles.STKHLD_KE);
		dc.add(Restrictions.isNull("taStakeholders.resignedDate"));
		dc.addOrder(Order.desc("taStakeholders.appointedDate"));

		return getFirst(dc);
	}

	public TaStakeholder getKeyExecutiveByLicenceNo(String licenceNo) {
		var dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("role.code", Codes.TaStakeholderRoles.STKHLD_KE));
		dc.add(Restrictions.like("licence.licenceNo", licenceNo, MatchMode.ANYWHERE));
		dc.add(Restrictions.le("appointedDate", LocalDate.now()));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));
		return getFirst(dc);
	}

	public Stakeholder getKeyExecutiveByUin(String uin) {
		var dc = DetachedCriteria.forClass(Stakeholder.class);
		addEq(dc, "uin", uin);
		return getFirst(dc);
	}

	public List<CeCaseInfringement> getTaInfringements(String uen) {
		DetachedCriteria dc = DetachedCriteria.forClass(CeCaseInfringement.class);
		dc.createAlias("ceCaseInfringer", "ceCaseInfringer", JoinType.LEFT_OUTER_JOIN);
		addIsNotNull(dc, "ceCaseInfringer.uenUin");
		addEq(dc, "ceCaseInfringer.uenUin", uen);
		addEq(dc, "isDeleted", Boolean.FALSE);
		addEq(dc, "ceCaseInfringer.isDeleted", Boolean.FALSE);
		dc.addOrder(Order.desc("infringedDate"));
		return getList(dc);
	}

	public List<ListableDto> getTaStakeholdersByRole(String role, Integer licId) {
		var dc = DetachedCriteria.forClass(TaStakeholder.class);
		dc.createAlias("licence", "licence", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("stakeholder", "stakeholder", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("role.code", role));
		dc.add(Restrictions.eq("licence.id", licId));
		dc.add(Restrictions.le("appointedDate", LocalDate.now()));
		dc.add(Restrictions.disjunction().add(Restrictions.isNull("resignedDate")).add(Restrictions.ge("resignedDate", LocalDate.now())));

		ProjectionList projections = Projections.projectionList();
		projections.add(Projections.groupProperty("stakeholder.id"));
		projections.add(Projections.property("stakeholder.name"), "label");
		dc.setProjection(projections);
		dc.setResultTransformer(Transformers.aliasToBean(ListableDto.class));

		return getList(dc);
	}

	public TaLicenceCreation getApplication(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(TaLicenceCreation.class);
		dc.createAlias("application", "application", JoinType.INNER_JOIN);
		dc.createAlias("application.applicationFiles", "application.applicationFiles", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.applicationFiles.file", "application.applicationFiles.file", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("application.lastAction", "lastAction", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("registeredAddress", "registeredAddress", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("operatingAddress", "operatingAddress", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taKeyExecutive", "taKeyExecutive", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taSpecializedMarkets", "taSpecializedMarkets", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taBusinessOperations", "taBusinessOperations", JoinType.LEFT_OUTER_JOIN);
		// dc.createAlias("taFocusAreas", "taFocusAreas", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("taStakeholders", "taStakeholders", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("application.id", id));
		return getFirst(dc);

	}
}
