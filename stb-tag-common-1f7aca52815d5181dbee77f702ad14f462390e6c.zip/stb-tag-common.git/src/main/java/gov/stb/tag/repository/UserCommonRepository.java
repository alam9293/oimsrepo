package gov.stb.tag.repository;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.User;

@Repository
public class UserCommonRepository extends BaseRepository {

	/**
	 * Get user by login ID
	 * 
	 * @param loginId
	 * @return
	 */
	public User getUserByLoginId(String loginId) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("loginId", loginId));
		return getFirst(dc);
	}

	/**
	 * Get user by id
	 * 
	 * @param loginId
	 * @return
	 */
	public User getUserById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	/**
	 * Get list of active users by roles
	 * 
	 * @param roleCodes
	 * @return
	 */
	public List<User> getActiveUsersByRole(String role) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		dc.add(Restrictions.eq("r.code", role));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
		return getList(dc);
	}
}
