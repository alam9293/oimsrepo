package gov.stb.tag.security.audit;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.model.User;

public class AuditorAwareImpl implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		SecurityContext context = SecurityContextHolder.getContext();
		if (context == null) {
			// secure context will be null when running unit tests so leave userId as null
			return null;
		}
		Authentication authentication = context.getAuthentication();
		if (authentication == null) {
			return Optional.of(Codes.User.SYSTEM);
		}
		Object user = authentication.getPrincipal();
		if (user == null) {
			return Optional.of(Codes.User.ANONYMOUS);
		}
		if (user instanceof User) {
			return Optional.of(((User) user).getLoginId());
		} else {
			return Optional.of(((org.springframework.security.core.userdetails.User) user).getUsername());
		}
	}

}