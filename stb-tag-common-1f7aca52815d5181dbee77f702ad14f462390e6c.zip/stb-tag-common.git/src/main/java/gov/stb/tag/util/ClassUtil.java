package gov.stb.tag.util;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClassUtil {
	protected transient static Logger logger = LoggerFactory.getLogger(ClassUtil.class);

	public static abstract class ReflectionComparer {
		public static final ReflectionComparer publicStaticFinalComparer = new ReflectionComparer() {
			@Override
			public boolean compare(int modifiers) {
				return Modifier.isPublic(modifiers) && Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers);
			}
		};

		public static final ReflectionComparer protectedPrivateNonStaticNonFinalComparer = new ReflectionComparer() {
			@Override
			public boolean compare(int modifiers) {
				boolean isProtectedOrPrivate = java.lang.reflect.Modifier.isProtected(modifiers) || java.lang.reflect.Modifier.isPrivate(modifiers);
				boolean isNotStaticNorFinal = !java.lang.reflect.Modifier.isStatic(modifiers) && !java.lang.reflect.Modifier.isFinal(modifiers);

				return isProtectedOrPrivate && isNotStaticNorFinal;
			}
		};

		public static final ReflectionComparer nonStaticNonFinalComparer = new ReflectionComparer() {
			@Override
			public boolean compare(int modifiers) {
				return !java.lang.reflect.Modifier.isStatic(modifiers) && !java.lang.reflect.Modifier.isFinal(modifiers);
			}
		};

		public abstract boolean compare(int modifiers);
	}

	private static final Class<?>[] immutables = { String.class, Byte.class, Short.class, Integer.class, Long.class, Float.class, Double.class, Boolean.class, BigInteger.class, BigDecimal.class,
			Date.class, File.class, InputStream.class, OutputStream.class };

	private static final Set<Class<?>> knownImmutables = new HashSet<>(Arrays.asList(immutables));

	/**
	 * Returns the value of the fieldName in relation to the specified object
	 * 
	 * @param object
	 *            is the object to retrieve the field value from
	 * @param fieldName
	 *            is the field name to retrieve the value from
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T extends Object> T getFieldValue(Object object, String fieldName) {
		if (fieldName == null) {
			return null;
		}
		Class<?> objectClass = object.getClass();

		try {
			/*
			 * There are 2 possible places in which the field can be retrieved. The superclass and the declared class. getDeclared field allows for the access of private fields within the declared
			 * class; getField allows access to fields within the superclass.
			 */
			Field field;
			try {
				field = objectClass.getField(fieldName);
			} catch (NoSuchFieldException e) {
				field = objectClass.getDeclaredField(fieldName);
			}
			field.setAccessible(true);
			return (T) field.get(object);
		} catch (NoSuchFieldException e) {
			logger.error("Unable to find field: " + fieldName + " contained within " + object.getClass().getSimpleName());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Sets the value into the field in relation to the specified object.
	 * 
	 * @param object
	 *            is the object to set the value into
	 * @param fieldName
	 *            is the field name to set the value to
	 * @param value
	 *            is the value to set the field value to
	 */
	public static void setFieldValue(Object object, String fieldName, Object value) {
		if (fieldName == null) {
			return;
		}
		Class<?> objectClass = object.getClass();

		try {
			/*
			 * There are 2 possible places in which the field can be retrieved. The superclass and the declared class. getDeclared field allows for the access of private fields within the declared
			 * class; getField allows access to fields within the superclass.
			 */
			Field field;
			try {
				field = objectClass.getField(fieldName);
			} catch (NoSuchFieldException e) {
				field = objectClass.getDeclaredField(fieldName);
			}
			field.setAccessible(true);
			field.set(object, value);
		} catch (NoSuchFieldException e) {
			logger.error("Unable to find field: " + fieldName + " contained within " + object.getClass().getSimpleName());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return;
	}

	/**
	 * Invokes a method in relation to the object and parameters specified
	 * 
	 * @param object
	 *            is the object to invoke the method from
	 * @param methodName
	 *            is the name of the method to invoke
	 * @param params
	 *            are any parameters that the method requires to be invoked
	 * @return
	 */
	public static Object invokeMethod(Object object, String methodName, Object... params) {
		return invokeMethod(object, methodName, null, params);
	}

	/**
	 * Invokes a method in relation to the object and parameters specified
	 * 
	 * @param object
	 *            is the object to invoke the method from
	 * @param methodName
	 *            is the name of the method to invoke
	 * @param clz
	 *            is the parameter class (if any) that the method requires to be invoked. This can be null.
	 * @param params
	 *            are any parameters that the method requires to be invoked
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object invokeMethod(Object object, String methodName, Class clz, Object... params) {
		if (methodName == null) {
			return null;
		}

		Class<?>[] paramTypes = new Class[params.length];
		boolean isNull = params.length == 1 && params[0] == null;
		for (int i = 0; i < params.length; i++) {
			if (params[i] != null) {
				paramTypes[i] = params[i].getClass();
			}
		}

		try {
			Class objClass = object.getClass();
			Method method;
			if (isNull || clz != null) {
				method = objClass.getMethod(methodName, clz);
			} else {
				method = objClass.getMethod(methodName, paramTypes);
			}
			method.setAccessible(true);
			return method.invoke(object, params);
		} catch (NoSuchMethodException e) {
			/* Swallow if method not found */
			// logger.info(e + ". This can usually be ignored.");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return null;
	}

	public static String toCamelCase(String... strings) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < strings.length; i++) {
			String string = strings[i];
			if (i == 0) {
				sb.append(string.substring(0, 1).toLowerCase() + string.substring(1));
			} else {
				sb.append(string.substring(0, 1).toUpperCase() + string.substring(1));
			}
		}

		return sb.toString();
	}

	@SuppressWarnings("unchecked")
	public static <T extends Object> T getter(Object object, String fieldName) {
		String methodName = toCamelCase("get", fieldName);
		return (T) invokeMethod(object, methodName);
	}

	public static Object setter(Object object, String fieldName, Object value) {
		String methodName = toCamelCase("set", fieldName);
		return invokeMethod(object, methodName, value);
	}

	public static Object setter(Object object, String fieldName, Class<?> clz, Object value) {
		String methodName = toCamelCase("set", fieldName);
		return invokeMethod(object, methodName, clz, value);
	}

	public static <T extends Object> boolean isMethodExist(Object source, String methodName, Class<T>... params) {
		try {
			source.getClass().getDeclaredMethod(methodName, params);
			return true;
		} catch (NoSuchMethodException ex) {
			return false;
		}

	}

	public static <T> String getNamesAsString(Collection<T> c1, String fieldName) {
		String names = "";
		for (T t : c1) {
			names += getter(t, fieldName) + ", ";
		}
		if (names.isEmpty() || names.length() < 2) {
			return names;
		}
		return names.substring(0, names.length() - 2);
	}

}
