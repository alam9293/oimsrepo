package gov.stb.tag.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import com.google.common.base.Strings;

/**
 * LocalDate, LocalTime and LocalDateTime from java.util.time comes with their own useful set of utility functions. References can be found at:
 * 
 * <pre>
 * https://www.baeldung.com/java-8-date-time-intro
 * https://www.baeldung.com/migrating-to-java-8-date-time-api
 * </pre>
 */
public class DateUtil {

	public static final String DATE_FORMAT_PATTERN = "dd-MMM-yyyy";
	public static final String DATETIME_FORMAT_PATTERN = "dd-MMM-yyyy HH:mm:ss";
	public static final String TIME_FORMAT_PATTERN = "HH:mm:ss";
	public static final String EDH_DATE_FORMAT_PATTERN = "yyyy-MM-dd";
	public static final String MYINFO_DATE_FORMAT_PATTERN = "yyyy-MM-dd";
	public static final String REPORT_DATE_FORMAT_PATTERN = "yyyyMMdd";
	public static final String DATE_FORMAT_PATTERN_2 = "dd MMM yyyy";
	public static final String DATETIME_FORMAT_PATTERN_2 = "dd MMM yyyy (eeee), HH:mm";
	public static final String MONTH_YEAR_PATTERN = "MMMM yyyy";

	public static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern(DATE_FORMAT_PATTERN);
	public static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern(TIME_FORMAT_PATTERN);
	public static final DateTimeFormatter DATETIME_FORMAT = DateTimeFormatter.ofPattern(DATETIME_FORMAT_PATTERN);
	public static final DateTimeFormatter EDH_DATE_FORMAT = DateTimeFormatter.ofPattern(EDH_DATE_FORMAT_PATTERN);

	public static String format(LocalDate date) {
		if (date != null) {
			return date.format(DATE_FORMAT);
		}
		return null;
	}

	public static String format(LocalDate date, String format) {
		return date.format(DateTimeFormatter.ofPattern(format));
	}

	public static String format(LocalTime time) {
		return time.format(TIME_FORMAT);
	}

	public static String format(LocalTime time, String format) {
		return time.format(DateTimeFormatter.ofPattern(format));
	}

	public static String format(LocalDateTime dateTime) {
		return dateTime.format(DATETIME_FORMAT);
	}

	public static String format(LocalDateTime dateTime, String format) {
		return dateTime.format(DateTimeFormatter.ofPattern(format));
	}

	public static LocalDate parseDate(String date) {
		if (Strings.isNullOrEmpty(date)) {
			return null;
		} else {
			return LocalDate.parse(date, DATE_FORMAT);
		}

	}

	public static LocalDate parseIsoDate(String date) {
		return LocalDate.parse(date, DateTimeFormatter.ISO_DATE_TIME);
	}

	public static LocalDate parseDate(String date, String format) {
		return LocalDate.parse(date, DateTimeFormatter.ofPattern(format));
	}

	public static LocalTime parseTime(String time) {
		return LocalTime.parse(time, TIME_FORMAT);
	}

	public static LocalTime parseTime(String time, String format) {
		return LocalTime.parse(time, DateTimeFormatter.ofPattern(format));
	}

	public static LocalDateTime parseDateTime(String dateTime) {
		return LocalDateTime.parse(dateTime, DATETIME_FORMAT);
	}

	public static LocalDateTime parseDateTime(String dateTime, String format) {
		return LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern(format));
	}

	public static LocalDateTime getEndOfDay(LocalDateTime localDateTime) {
		return localDateTime.with(LocalTime.MAX);
	}

	public static LocalDateTime getStartOfDay(LocalDateTime localDateTime) {
		return localDateTime.with(LocalTime.MIN);
	}

	public static LocalDate getMinDate(LocalDate date1, LocalDate date2) {
		if (date1 != null && date2 != null) {
			if (date1.isBefore(date2)) {
				return date1;
			} else {
				return date2;
			}
		} else {
			if (date1 != null) {
				return date1;
			} else {
				return date2;
			}
		}
	}

	public static LocalDate getMaxDate(LocalDate date1, LocalDate date2) {
		if (date1 != null && date2 != null) {
			if (date1.isAfter(date2)) {
				return date1;
			} else {
				return date2;
			}
		} else {
			if (date1 != null) {
				return date1;
			} else {
				return date2;
			}
		}
	}

	public static Boolean isEqualDateTimeUpToSec(LocalDateTime date1, LocalDateTime date2) {
		if (date1.getDayOfYear() == date2.getDayOfYear() && date1.getHour() == date2.getHour() && date1.getMinute() == date2.getMinute() && date1.getSecond() == date2.getSecond()) {
			return true;
		}
		return false;
	}

	public static boolean checkIfEqualOrAfter(LocalDate date1, LocalDate date2) {
		boolean res = false;
		if (date1 != null && date2 != null) {
			res = (date1.isEqual(date2) || date1.isAfter(date2));
		}
		return res;
	}
}
