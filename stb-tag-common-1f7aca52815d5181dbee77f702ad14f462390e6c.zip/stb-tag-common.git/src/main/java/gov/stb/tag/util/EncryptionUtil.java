package gov.stb.tag.util;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import com.google.common.hash.Hashing;
import com.google.common.io.BaseEncoding;

public class EncryptionUtil {

	private static final String SECRET = "ThisIsASecret123";
	private static final String ALGORITHM = "AES/GCM/NoPadding"; // sonar-complaint algorithm

	public static String generateSalt() {
		SecureRandom random = new SecureRandom();
		byte[] values = new byte[20];
		random.nextBytes(values);
		return BaseEncoding.base64().encode(values);
	}

	public static String encode(String input, String salt) {
		String hashString = salt + input;
		return Hashing.sha256().hashString(hashString, StandardCharsets.UTF_8).toString();
	}

	public static boolean matches(String salt, String hashedPassword, String plainPassword) {
		return hashedPassword.equals(encode(plainPassword, salt));
	}

	public static SecretKey generateSecretKey(String password, byte[] iv) throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeySpec spec = new PBEKeySpec(password.toCharArray(), iv, 65536, 128);
		SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
		byte[] key = secretKeyFactory.generateSecret(spec).getEncoded();
		return new SecretKeySpec(key, "AES");
	}

	public static String encrypt(String clearText) throws GeneralSecurityException {
		// Prepare the nonce. Noonce should be 12 bytes
		SecureRandom secureRandom = new SecureRandom();
		byte[] iv = new byte[12];
		secureRandom.nextBytes(iv);

		// Prepare your key/password
		SecretKey secretKey = generateSecretKey(SECRET, iv);

		// Encrypt the data
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);
		byte[] encryptedData = cipher.doFinal(clearText.getBytes());

		// Concatenate everything and return the final data
		ByteBuffer byteBuffer = ByteBuffer.allocate(4 + iv.length + encryptedData.length);
		byteBuffer.putInt(iv.length);
		byteBuffer.put(iv);
		byteBuffer.put(encryptedData);
		return Base64.getEncoder().encodeToString(byteBuffer.array());
	}

	public static String decrypt(String encryptedText) throws GeneralSecurityException {
		// Wrap the data into a byte buffer to ease the reading process
		ByteBuffer byteBuffer = ByteBuffer.wrap(Base64.getDecoder().decode(encryptedText));
		int noonceSize = byteBuffer.getInt();

		// Make sure that the file was encrypted properly
		if (noonceSize < 12 || noonceSize >= 16) {
			throw new IllegalArgumentException("Nonce size is incorrect. Make sure that the incoming data is an AES encrypted file.");
		}
		byte[] iv = new byte[noonceSize];
		byteBuffer.get(iv);

		// Prepare your key/password
		SecretKey secretKey = generateSecretKey(SECRET, iv);

		// get the rest of encrypted data
		byte[] cipherBytes = new byte[byteBuffer.remaining()];
		byteBuffer.get(cipherBytes);

		// Decrypt the data
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);
		cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);
		return new String(cipher.doFinal(cipherBytes));
	}

	public static void main(String[] args) throws Exception {
		String clearText = "100";
		String encryptedText = EncryptionUtil.encrypt(clearText);
		System.out.println(encryptedText);
		System.out.println(EncryptionUtil.decrypt(encryptedText));
	}

}
