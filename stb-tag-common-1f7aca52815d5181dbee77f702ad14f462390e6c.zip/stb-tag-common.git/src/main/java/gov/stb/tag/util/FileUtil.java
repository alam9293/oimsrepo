package gov.stb.tag.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.text.DecimalFormat;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;

public class FileUtil extends FileUtils {

	public static String getAbsoluteFilePath(String relativeFilePath) {
		return FileUtil.class.getClassLoader().getResource(relativeFilePath).getPath();
	}

	public static String encodeImageAsBase64String(File imageFile) throws IOException {
		if (imageFile != null && imageFile.exists()) {
			String extension = FilenameUtils.getExtension(imageFile.getName());
			return "data:image/" + extension + ";base64," + Base64.encodeBase64String(readFileToByteArray(imageFile));
		}
		return "data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QBaRXhpZgAATU0AKgAAAAgABQMBAAUAAAABAAAASgMDAAEAAAABAAAAAFEQAAEAAAABAQAAAFERAAQAAAABAAAOxFESAAQAAAABAAAOxAAAAAAAAYagAACxj//bAEMAAgEBAgEBAgICAgICAgIDBQMDAwMDBgQEAwUHBgcHBwYHBwgJCwkICAoIBwcKDQoKCwwMDAwHCQ4PDQwOCwwMDP/bAEMBAgICAwMDBgMDBgwIBwgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIALQAlgMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP0wooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACip7PS7rUD/o9vPP8A9c4y38qtv4M1iNNzaTqSr6m1fH8qAM2ipLi2ktJNssckbejqVNR0AFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFCqWbAGSeAB3qawsJtUvI7e3jaaaZtqIo5Y17V8OPhRa+EII7m6VLjUmGS55WH2X/Hr9KAOH8IfA3UteRZr5v7Ot25CsuZWH+72/Hn2r0Tw/wDCbQ/D6qVs1uZl/wCWlx+8J/A8D8BXSUUANjjWFAqqqqvAAGAKdRRQBDeWEGow+XcQwzx/3ZEDL+Rrk/EfwO0bWVZrZX06Y87ovmTPup/piuyooA8C8ZfC/VPBu6SWP7Radp4uVH+8Oq/jx71zlfT7osiFWUMrDBBHBFeX/FP4OLFFJqWjxYC/NNaqO3dkH9Py9KAPMKKKKACiiigAooooAKKKKACiipLW2a8uY4YxmSVgij1JOBQB6x8BvBa2eltrEyZnuspBkfcQcEj3Jz+A969Eqvpenx6Tptvaxf6u3jWNfoBirFABRRRQAUUUUAFFFFABRRRQB4n8avBa+GfEK3Vum211DLhQOI3H3h9DkH8T6Vxde6fGnRhq3gK5bbmSzZZ0/A4b/wAdJ/KvC6ACiiigAooooAKKKKACtn4eW32vxzpKHp9qRufY5/pWNW98MP8Akf8ASv8AruP5GgD6CooooAKKKKACiiigAooooAKKKKAKHiq2+2eGNRhP/LS2kXn3U183V9La5/yBbz/rg/8A6Ca+aaACiiigAooooAKKKKACtj4ey+T450ls7f8ASo1/NgP61j1u/DjR7rVfGGntbW8ky2tzFNKVHCKHBJJPHY/WgD6DooooAKKKKACiiigAooooAKKKKAM/xXL5HhbUnzt2WsrZHbCGvm+vpDxZaS3/AIW1K3hjMk09rLGiggbmZSB1+tfOl7ZTabdyQXEbwzRHa6OMMpoAiooooAKKKKACiiigAr3D4G6dHZ/D+3mVR5l3JJI5xySGKj9Frw+vYv2ftcW88MTWJI82zlLAeqNyP13fpQB31FFFABRRRQAUUUUAFFFFABRRRQAV5P8AtGadHDqem3SqBJcRyRuQOoQqR/6Ea9Yrxn4+64uo+LIrWMhlsYtrf77cn9NtAHC0UUUAFFFFABRRRQAVp+EvFVz4O1qO9tcFl+V0b7sinqD/AJ6gVmUUAfQngnx7ZeObFpLYtHNHjzYX+8n+I963K+dPBnimbwf4hgvYtxVTtlQf8tEPUf4e4FfQtjfRalZQ3ELCSGZA6MO4PIoAmooooAKKKKACiiigAoorD+IPi5fBnhma6489v3cCn+Jz0/AdT9KAMf4j/F638ImSztFFxqOOf7kBP971PtXi9zcyXtzJNKzSSSsXdj1YnkmkuLiS7uJJZGaSSRizMxyWJ6k0ygAooooAKKKKACiiigAooooAK9M+BfxAW2b+xbuTarsWtWY9Ceqfj1Hvn1FeZ0qO0bBlJVlOQR2oA+n6Kwfhn4hbxN4Ls7iRi8yqYpSTyWXjJ9yMH8a3qACiiigAooooAbNMtvC0kjKkcYLMzHAUDqTXg/xS8dHxt4gLRlvsNrlIAf4vV/x/kBXa/tB+I5LLS7TToZGX7UTJLtOMovAB9iT/AOO15JQAUUUUAFFFFABRRRQAUUUUAFFFFABRWjonhLUvEjYsbK4uB03BcIPqx4H512eg/s9X11tbULuG1XrsjHmP+J4A/WgDW/Z0vzLo2pWvaGZZB/wJcf8AslejVieC/ANj4FgmWz85muNvmPI+S2M44GB3PbvW3QAUUUUAFFFFAHiPx2vzd+P5I+1rDHGPxG//ANmrja9y8Z/B3TvGF/JeGa4trybG51O5WwABlT7AdCK4PXvgNrGmFmtTDqEY/uNsf/vluPyJoA4mirGpaTdaPP5V1bzW8n92RCpP51XoAKKKKACiiigAqxpmk3Ws3IhtLea4lP8ADGpY16j4U/Z+t7YLLq85uJOvkRErGPq3U/hiu/0zSLXRbYQ2dvDbxD+GNAoP19frQB5N4d/Z/wBRv9smoTxWMZ/gX95J+nA/M13fh/4Q6H4f2sLX7VMv/LS4Pmfp939K6aigBERY0CqoVVGAAOBS0UUAFFFFABRRRQAUUUUAFFFFAEN7YQalAYriGK4jbqkiBlP4GuQ8QfArRtWDNa+bp8p5zGdyf98n+hFdrRQB4f4j+CWtaGGeGNdQhXndB98D3U8/lmuRmhe3lZJFZHU4KsMEH6V9PVl+IfBum+Kott9ZxTNjAkxtkX6MOfw6UAfOdFeleI/2eriOfdpd1HJEx+5cHayfiBg/kKKAPVqKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/9k=";
	}

	public static void downloadSingleFile(HttpServletResponse response, File file, String fileExt) throws IOException {
		if (file != null && file.exists()) {
			response.setContentType(Files.probeContentType(file.toPath()));
			if (Strings.isNullOrEmpty(response.getContentType()) && !Strings.isNullOrEmpty(fileExt)) {
				response.setContentType(Codes.FileExtContentType.get(fileExt.toLowerCase()));
			}
			response.addHeader("Content-Disposition", "attachment;filename=" + file.getName());
			ServletOutputStream out = null;
			try {
				out = response.getOutputStream();
				copyFile(file, out);
			} catch (IOException e) {
				throw e;
			} finally {
				if (out != null) {
					out.close();
				}
			}
		}
	}

	public static void addToZipFile(String fileName, ZipOutputStream zos) throws IOException {
		File file = new File(fileName);
		try {
			ZipEntry zipEntry = new ZipEntry(file.getName());
			zos.putNextEntry(zipEntry);
			copyFile(file, zos);
			zos.flush();
			zos.closeEntry();
		} catch (Exception e) {
			throw e;
		} finally {
			zos.close();
		}
	}

	public static void zipFiles(String dest, List<String> srcFiles) throws Exception {

		FileOutputStream fos = new FileOutputStream(dest);
		ZipOutputStream zipOut = new ZipOutputStream(fos);
		for (String srcFile : srcFiles) {
			File fileToZip = new File(srcFile);
			zipFile(fileToZip, fileToZip.getName(), zipOut);
		}
		zipOut.close();
		fos.close();
	}

	public static void zipDirectory(String dest, String source) throws Exception {

		FileOutputStream fos = new FileOutputStream(dest);
		ZipOutputStream zipOut = new ZipOutputStream(fos);
		File fileToZip = new File(source);
		zipFile(fileToZip, fileToZip.getName(), zipOut);
		zipOut.close();
		fos.close();
	}

	private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
		if (fileToZip.isHidden()) {
			return;
		}
		if (fileToZip.isDirectory()) {
			if (fileName.endsWith("/")) {
				zipOut.putNextEntry(new ZipEntry(fileName));
				zipOut.closeEntry();
			} else {
				zipOut.putNextEntry(new ZipEntry(fileName + "/"));
				zipOut.closeEntry();
			}
			File[] children = fileToZip.listFiles();
			for (File childFile : children) {
				zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
			}
			return;
		}
		FileInputStream fis = new FileInputStream(fileToZip);
		ZipEntry zipEntry = new ZipEntry(fileName);
		zipOut.putNextEntry(zipEntry);
		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zipOut.write(bytes, 0, length);
		}
		fis.close();
	}

	public static void downloadZipFile(HttpServletResponse response, List<String> filePaths) throws IOException {
		response.setContentType("application/octet-stream");
		ZipOutputStream zos = null;
		try {
			ServletOutputStream os = response.getOutputStream();
			zos = new ZipOutputStream(os);
			for (String path : filePaths) {
				if (!Strings.isNullOrEmpty(path)) {
					addToZipFile(path, zos);
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			zos.close();
		}
	}

	public static void addDirectory(ZipOutputStream zos, String sourceDir, File fileSource) throws IOException {
		if (fileSource.isDirectory()) {
			File[] files = fileSource.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isFile()) {
					try {
						ZipEntry zipEntry = new ZipEntry(sourceDir + "\\" + files[i].getName());
						zos.putNextEntry(zipEntry);
						copyFile(files[i], zos);
						zos.flush();
						zos.closeEntry();
					} catch (Exception e) {
						throw e;
					} finally {
						zos.close();
					}
				}
			}
		} else if (fileSource.isFile()) {
			try {
				ZipEntry zipEntry = new ZipEntry(sourceDir + "\\" + fileSource.getName());
				zos.putNextEntry(zipEntry);
				copyFile(fileSource, zos);
				zos.flush();
				zos.closeEntry();
			} catch (Exception e) {
				throw e;
			} finally {
				zos.close();
			}
		}
	}

	public static String readableFileSize(Long size) {
		if (size <= 0) {
			return "0";
		}
		final String[] units = new String[] { "B", "kB", "MB", "GB", "TB" };
		int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
		return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
	}

	public static String sanitize(MultipartFile file) {
		String input = file.getOriginalFilename().toLowerCase();
		return input.replaceAll("\\\\|/|\\||:|\\?|\\*|\"|<|>|\\p{Cntrl}", "_");
	}

	public static boolean isExtensionIgnoreCase(String filename, String[] extensions) {

		String filenameLowerCase = filename.toLowerCase();
		Integer count = 0;

		for (String extension : extensions) {

			extensions[count] = extension.toLowerCase();
			count++;
		}

		return FilenameUtils.isExtension(filenameLowerCase, extensions);
	}
}
