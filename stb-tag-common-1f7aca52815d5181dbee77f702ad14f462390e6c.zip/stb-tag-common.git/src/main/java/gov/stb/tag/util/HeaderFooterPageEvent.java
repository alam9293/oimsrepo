package gov.stb.tag.util;

import java.io.IOException;
import java.net.MalformedURLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class HeaderFooterPageEvent extends PdfPageEventHelper {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());
	private PdfTemplate t;
	private Image total;
	private String logoPath;

	public HeaderFooterPageEvent(String logoImagePath) {
		super();
		logoPath = logoImagePath;
	}

	@Override
	public void onOpenDocument(PdfWriter writer, Document document) {
		try {
			t = writer.getDirectContent().createTemplate(30, 16);
			total = Image.getInstance(t);
			addHeader(writer);
			// total.setRole(PdfName.ARTIFACT);
		} catch (DocumentException de) {
			throw new ExceptionConverter(de);
		}
	}

	@Override
	public void onEndPage(PdfWriter writer, Document document) {
		// addHeader(writer);
		addFooter(writer);
	}

	private void addHeader(PdfWriter writer) {
		PdfPTable header = new PdfPTable(2);
		try {
			// set defaults
			header.setWidths(new int[] { 40, 50 });
			header.setTotalWidth(527);
			header.setLockedWidth(true);
			header.getDefaultCell().setFixedHeight(40);
			header.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			// add text
			PdfPCell text = new PdfPCell();
			text.setPaddingBottom(15);
			text.setPaddingLeft(10);
			text.setBorder(Rectangle.NO_BORDER);

			text.addElement(new Phrase("", new Font(Font.HELVETICA, 12)));
			text.addElement(new Phrase("", new Font(Font.HELVETICA, 8)));
			header.addCell(text);

			// add logo image
			// Preconditions.checkNotNull(properties.baseDir);
			// Image logo = Image.getInstance(properties.baseDir + "/stb_logo.jpg");
			if (!Strings.isNullOrEmpty(logoPath)) {
				Image logo = Image.getInstance(logoPath);
				header.addCell(logo);
				header.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
			}

			// write content
			header.writeSelectedRows(0, -1, 34, 825, writer.getDirectContent());
		} catch (DocumentException de) {
			throw new ExceptionConverter(de);
		} catch (MalformedURLException e) {
			throw new ExceptionConverter(e);
		} catch (IOException e) {
			throw new ExceptionConverter(e);
		}
	}

	private void addFooter(PdfWriter writer) {
		PdfPTable footer = new PdfPTable(3);
		try {
			// set defaults
			footer.setWidths(new int[] { 24, 2, 1 });
			footer.setTotalWidth(527);
			footer.setLockedWidth(true);
			footer.getDefaultCell().setFixedHeight(40);
			footer.getDefaultCell().setBorder(Rectangle.TOP);

			// add copyright
			footer.addCell(new Phrase("Confidential", new Font(Font.HELVETICA, 8)));

			// add current page count
			footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			footer.addCell(new Phrase(String.format("Page %d of", writer.getPageNumber()), new Font(Font.HELVETICA, 8)));

			// add placeholder for total page count
			PdfPCell totalPageCount = new PdfPCell(total);
			totalPageCount.setBorder(Rectangle.TOP);
			footer.addCell(totalPageCount);

			// write page
			// PdfContentByte canvas = writer.getDirectContent();
			// canvas.beginMarkedContentSequence(PdfName.BACKGROUND);
			footer.writeSelectedRows(0, -1, 34, 50, writer.getDirectContent());
			// canvas.endMarkedContentSequence();
		} catch (DocumentException de) {
			throw new ExceptionConverter(de);
		}
	}

	@Override
	public void onCloseDocument(PdfWriter writer, Document document) {
		int totalLength = String.valueOf(writer.getPageNumber()).length();
		int totalWidth = totalLength * 5;
		ColumnText.showTextAligned(t, Element.ALIGN_RIGHT, new Phrase(String.valueOf(writer.getPageNumber() - 1), new Font(Font.HELVETICA, 8)), totalWidth, 6, 0);
	}
}