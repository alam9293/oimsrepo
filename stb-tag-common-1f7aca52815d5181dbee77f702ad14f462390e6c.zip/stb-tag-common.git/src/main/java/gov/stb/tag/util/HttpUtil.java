package gov.stb.tag.util;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.mime.FormBodyPartBuilder;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.common.base.Strings;

public class HttpUtil {

	/**
	 * Reconstruct GET or POST request from the specified request but with a different URL.
	 */
	public static HttpRequestBase reconstruct(HttpServletRequest req, String url) throws IOException {
		return reconstruct(req, url, null);
	}

	/**
	 * Reconstruct GET or POST request from the specified request but with a different URL.
	 */
	public static HttpRequestBase reconstruct(HttpServletRequest req, String url, List<NameValuePair> nameValues) throws IOException {
		HttpRequestBase clonedReq = null;
		if (req.getMethod().equals(RequestMethod.GET.name())) {
			clonedReq = new HttpGet(url);
			HttpUtil.copyHeaders(req, clonedReq);

		} else if (req.getMethod().equals(RequestMethod.POST.name())) {
			HttpPost destReq = new HttpPost(url);
			HttpUtil.copyHeaders(req, destReq);
			String contentType = Strings.isNullOrEmpty(req.getContentType()) ? ContentType.APPLICATION_JSON.getMimeType() : req.getContentType();
			if (contentType.toLowerCase().contains(ContentType.MULTIPART_FORM_DATA.getMimeType().toLowerCase())) {
				HttpUtil.copyMultiparts(req, destReq);

			} else if (nameValues != null) {
				destReq.setEntity(new UrlEncodedFormEntity(nameValues, "UTF-8"));

			} else {
				destReq.setEntity(new InputStreamEntity(req.getInputStream(), ContentType.parse(contentType)));
			}
			clonedReq = destReq;

		} else {
			throw new IOException("Use only GET or POST method for reconstruction.");
		}
		return clonedReq;
	}

	/**
	 * Execute the specified request and copy it response into the original response.
	 */
	public static void execute(HttpRequestBase req, ServletResponse originalResp) throws IOException {
		HttpClient client = HttpClientBuilder.create().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
		HttpResponse resp = client.execute(req);
		HttpUtil.copyResponse(resp, (HttpServletResponse) originalResp);
		EntityUtils.consume(resp.getEntity());
		originalResp.flushBuffer();
	}

	/**
	 * Copy the request headers from the source request to destination request
	 */
	public static void copyHeaders(HttpServletRequest srcReq, HttpRequestBase destReq) {
		Enumeration<String> headerNames = srcReq.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String headerName = headerNames.nextElement();
			if (!headerName.toLowerCase().startsWith("content") && !headerName.toLowerCase().equals("host") && !headerName.toLowerCase().startsWith("x-forwarded-")) {
				// skip host and all content-related headers as they will be re-constructed by Apache
				destReq.addHeader(headerName, srcReq.getHeader(headerName));
			}
		}
	}

	/**
	 * Copy the POST multiparts from the original request to APEX request
	 */
	public static void copyMultiparts(HttpServletRequest srcReq, HttpPost destReq) throws IOException {
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setContentType(ContentType.parse(srcReq.getContentType()));
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		try {
			for (Part part : srcReq.getParts()) {
				FormBodyPartBuilder formBuilder = FormBodyPartBuilder.create();
				formBuilder.setName(part.getName());
				String filename = part.getSubmittedFileName() == null ? "" : part.getSubmittedFileName(); // cannot be null (if not Content-Type will not be added)
				formBuilder.setBody(new InputStreamBody(part.getInputStream(), ContentType.parse(part.getContentType()), filename));
				builder.addPart(formBuilder.build());
			}
		} catch (ServletException e) {
			throw new IOException(e);
		}
		destReq.setEntity(builder.build());
	}

	/**
	 * Copy the response content from the source response to the destination response
	 */
	public static void copyResponse(HttpResponse srcResp, HttpServletResponse destResp) throws UnsupportedOperationException, IOException {
		for (Header header : srcResp.getAllHeaders()) {
			if (!header.getName().toLowerCase().equals("transfer-encoding")) {
				// skip transfer-encoding and set content length instead to resolve chunking issue
				destResp.addHeader(header.getName(), header.getValue());
			}
		}
		destResp.setContentLengthLong(srcResp.getEntity().getContentLength());
		destResp.setStatus(srcResp.getStatusLine().getStatusCode());
		IOUtils.copy(srcResp.getEntity().getContent(), destResp.getOutputStream());
	}
}
