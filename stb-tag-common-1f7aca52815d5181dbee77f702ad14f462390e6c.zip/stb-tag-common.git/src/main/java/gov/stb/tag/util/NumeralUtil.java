package gov.stb.tag.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.List;
import java.util.function.IntFunction;
import java.util.stream.Collectors;

import com.google.common.base.Function;

/**
 * LocalDate, LocalTime and LocalDateTime from java.util.time comes with their own useful set of utility functions. References can be found at:
 * 
 * <pre>
 * https://www.baeldung.com/java-8-date-time-intro
 * https://www.baeldung.com/migrating-to-java-8-date-time-api
 * </pre>
 */
public class NumeralUtil {

	DecimalFormat df = new DecimalFormat("###,###.##");

	public static final String THOUSAND_COMMA_SEPERATE_2DECIMAL = "###,###.##";

	public static String formatToLocalCurrency(BigDecimal bigDecimal) {
		// DecimalFormat df = new DecimalFormat(THOUSAND_COMMA_SEPERATE_2DECIMAL);
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		if (bigDecimal != null) {
			if (bigDecimal.compareTo(BigDecimal.ZERO) >= 0) {
				return ("S" + nf.format(bigDecimal));
			} else {
				return ("-S" + nf.format(bigDecimal.abs()));
			}
		} else {
			return null;
		}
	}

	public static String formatIntegerToString(Integer val) {
		if (val != null) {
			return val.toString();
		} else {
			return null;
		}
	}

	public static String[] parseStringArray(Integer[] arr) throws Exception {
		String[] strings = new String[arr.length];
		for (int i = 0; i < strings.length; i++) {
			strings[i] = arr[i].toString();
		}
		return strings;
	}

	public static String[] parseStringArray(List<Integer> arr) throws Exception {
		String[] strings = new String[arr.size()];
		for (int i = 0; i < strings.length; i++) {
			strings[i] = arr.get(i).toString();
		}
		return strings;
	}

	// for lists
	public static <T, U> List<U> convertList(List<T> from, Function<T, U> func) {
		return from.stream().map(func).collect(Collectors.toList());
	}

	// for arrays
	public static <T, U> U[] convertArray(T[] from, Function<T, U> func, IntFunction<U[]> generator) {
		return Arrays.stream(from).map(func).toArray(generator);
	}

}