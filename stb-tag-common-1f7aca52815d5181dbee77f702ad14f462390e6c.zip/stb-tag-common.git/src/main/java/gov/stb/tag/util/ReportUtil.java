package gov.stb.tag.util;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import gov.stb.tag.constant.Codes;

public class ReportUtil {

	public enum Reports {

		TA_REPORT_REG14("TAG_TA_REG14_REPORT", "ta_report_reg14",
				new String[] { "S/no.", "UEN", "TA Licence No.", "TA Name", "Licence Tier", "Licence Status", "Financial Year End (FYE) Date", "Reference Year", "Submission ID", "Submission Status",
						"Condition Description", "Condition Due Date", "Extended Due Date", "Condition Fulfilment Date", "Condition Approval Date", "Delay Period (Days)", "KE Gender", "KE Name",
						"Block", "Street Name", "Level No.", "Unit No.", "Building Name", "Postal Code", "KE Email", "Company Email", "Payment Reference no.", "Bill  Reference no.", "Amount",
						"Payment Status" },
				true, Codes.TaTgType.TA),

		TA_REPORT_REG9("TAG_TA_REG9_REPORT", "ta_report_reg9",
				new String[] { "S/no.", "UEN", "TA Licence No.", "TA Name", "Licence Tier", "Licence Status", "Financial Year End (FYE) Date", "Recification Submission ID", "Submission Type",
						"Reference Year", "Financial Year Period", "Paid-up Capital", "Total Assets", "Total Liabilities", "Net Value", "Shortfall", "Net Value Rectification Due Date",
						"Net Value Rectification Submission Date", "Rectification Approval Date", "Delay Period (Days)", "KE Gender", "KE Name", "Block", "Street Name", "Level No.", "Unit No.",
						"Building Name", "Postal Code", "KE Email", "Company Email", "Payment Reference no.", "Bill  Reference no.", "Amount", "Payment Status" },
				true, Codes.TaTgType.TA),

		TA_REPORT_CONTACTS("TAG_TA_CONTACTS_REPORT", "ta_report_contacts",
				new String[] { "S/no.", "UEN", "TA Licence No.", "TA Name", "Licence Tier", "Licence Status", "Financial Year End (FYE) Date", "Address Type", "Block", "Street Name", "Level No.",
						"Unit No.", "Building Name", "Postal Code", "Premises Type", "Company Contact no.", "Company Email", "Appointment", "Gender", "Personnel Name", "Personnel Email",
						"Personnel Contact no.", "Licence Issued Date", "Licence Cessation/Revocation Date" },
				true, Codes.TaTgType.TA),

		TA_REPORT_PAYMENT("TAG_TA_PAYMENT_REPORT", "ta_report_payment", new String[] { "S/no.", "Bill  Reference no.", "Payment Reference no.", "Payment Type", "Payer ID", "Amount", "Payer Name",
				"External Remarks", "Interal Remarks", "Payment Status", "Payment Date" }, true, Codes.TaTgType.TA),

		TA_REPORT_DIRECTORY("TAG_TA_DIRECTORY_REPORT", "ta_report_directory",
				new String[] { "No.", "Travel Agent Name", "Licence No.", "Licence Type", "UEN", "Block No.", "Street Name", "Level No.", "Unit No.", "Building", "Postal Code", "Contact Person",
						"Designation", "Office Phone", "Email Address", "Website", "Year(s) of Operation", "Inbound Services Provided", "Outbound Services Provided", "Licence Issued Date",
						"Licence Status" },
				true, Codes.TaTgType.TA),

		TG_REPORT_ACTIVE("TAG_TG_ACTIVE_REPORT", "tg_report_active",
				new String[] { "No.", "Tourist Guide Name", "Salutation", "NRIC / FIN", "Email", "Licence No.", "Mobile No.", "Licence Expiry Date", "Guiding Languages", "Block No.", "Street Name",
						"Level No.", "Unit No.", "Building", "Postal Code", "Foreign Address Line 1", "Foreign Address Line 2", "Foreign Address Line 3" },
				false, Codes.TaTgType.TG);

		private String reportName;

		private String namedQuery;

		private String[] headerNames;

		private Boolean isBatchJobRun;

		private String taTgType;

		private Reports(String reportName, String namedQuery, String[] headerNames, Boolean isBatchJobRun, String taTgType) {
			this.reportName = reportName;
			this.namedQuery = namedQuery;
			this.headerNames = headerNames;
			this.isBatchJobRun = isBatchJobRun;
			this.taTgType = taTgType;
		}

		public String getReportName() {
			return reportName;
		}

		public String getNamedQuery() {
			return namedQuery;
		}

		public String[] getHeaderNames() {
			return headerNames;
		}

		public Boolean getIsBatchJobRun() {
			return isBatchJobRun;
		}

		public String getTaTgType() {
			return taTgType;
		}

	}

	public static List<Reports> getReports(String taTgType) {
		return Arrays.asList(Reports.values()).stream().filter(r -> taTgType.equals(r.getTaTgType())).collect(Collectors.toList());
	}
}
