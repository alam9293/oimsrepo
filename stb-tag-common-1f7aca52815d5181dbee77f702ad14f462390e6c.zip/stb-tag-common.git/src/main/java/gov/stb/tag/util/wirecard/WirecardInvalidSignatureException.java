package gov.stb.tag.util.wirecard;

@SuppressWarnings("serial")
public class WirecardInvalidSignatureException extends Exception {

	public WirecardInvalidSignatureException() {
		super();
	}

	public WirecardInvalidSignatureException(Exception e) {
		super(e);
	}

	public WirecardInvalidSignatureException(String message) {
		super(message);
	}
}
