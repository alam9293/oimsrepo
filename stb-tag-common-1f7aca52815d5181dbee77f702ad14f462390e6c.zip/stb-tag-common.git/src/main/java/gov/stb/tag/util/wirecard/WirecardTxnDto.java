package gov.stb.tag.util.wirecard;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WirecardTxnDto {

	private String payerUinUen = "";
	private String payerName = "";
	private String paymentRequestTypes = "";
	private String refNos = "";
	private String billRefNos = "";
	private String txnId;
	private String mid;
	private String payType;
	private String transType;
	private String currency;
	private String amount;
	private String version;
	private String rcard;
	private String signature;
	private String returnCCNum;
	private String returnTxnStatus;
	private String returnErrorCode;
	private String returnErrorMsg;
	private String returnSignature;

	private Boolean isAllWaived = false;

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getRcard() {
		return rcard;
	}

	public void setRcard(String rcard) {
		this.rcard = rcard;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getPayerUinUen() {
		return payerUinUen;
	}

	public void setPayerUinUen(String payerUinUen) {
		this.payerUinUen = payerUinUen;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public String getPaymentRequestTypes() {
		return paymentRequestTypes;
	}

	public void setPaymentRequestTypes(String paymentRequestTypes) {
		this.paymentRequestTypes = paymentRequestTypes;
	}

	public String getRefNos() {
		return refNos;
	}

	public void setRefNos(String refNos) {
		this.refNos = refNos;
	}

	public String getBillRefNos() {
		return billRefNos;
	}

	public void setBillRefNos(String billRefNos) {
		this.billRefNos = billRefNos;
	}

	public String getReturnCCNum() {
		return returnCCNum;
	}

	public void setReturnCCNum(String returnCCNum) {
		this.returnCCNum = returnCCNum;
	}

	public String getReturnTxnStatus() {
		return returnTxnStatus;
	}

	public void setReturnTxnStatus(String returnTxnStatus) {
		this.returnTxnStatus = returnTxnStatus;
	}

	public String getReturnErrorCode() {
		return returnErrorCode;
	}

	public void setReturnErrorCode(String returnErrorCode) {
		this.returnErrorCode = returnErrorCode;
	}

	public String getReturnErrorMsg() {
		return returnErrorMsg;
	}

	public void setReturnErrorMsg(String returnErrorMsg) {
		this.returnErrorMsg = returnErrorMsg;
	}

	public String getReturnSignature() {
		return returnSignature;
	}

	public void setReturnSignature(String returnSignature) {
		this.returnSignature = returnSignature;
	}

	public String getBaseString() {
		// SECURITY SEQ: amt,ref,cur,mid,transtype
		return amount + txnId + currency + mid + transType;
	}

	public Boolean isTxnSuccessful() {
		return returnTxnStatus != null && returnTxnStatus.equals("YES");
	}

	public Boolean isReturnSignatureInvalid() {
		return !isAllWaived && !signature.equals(returnSignature);
	}

	@Override
	public String toString() {
		return "WirecardTxnDto [payerUinUen=" + payerUinUen + ", payerName=" + payerName + ", paymentRequestTypes=" + paymentRequestTypes + ", refNos=" + refNos + ", billRefNos=" + billRefNos
				+ ", txnId=" + txnId + ", mid=" + mid + ", payType=" + payType + ", transType=" + transType + ", currency=" + currency + ", amount=" + amount + ", version=" + version + ", rcard="
				+ rcard + ", signature=" + signature + ", returnCCNum=" + returnCCNum + ", returnTxnStatus=" + returnTxnStatus + ", returnErrorCode=" + returnErrorCode + ", returnErrorMsg="
				+ returnErrorMsg + ", returnSignature=" + returnSignature + "]";
	}

	public Boolean getIsAllWaived() {
		return isAllWaived;
	}

	public void setIsAllWaived(Boolean isAllWaived) {
		this.isAllWaived = isAllWaived;
	}

}
