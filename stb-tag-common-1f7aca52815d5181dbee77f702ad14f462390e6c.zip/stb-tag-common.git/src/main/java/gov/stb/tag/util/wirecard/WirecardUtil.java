package gov.stb.tag.util.wirecard;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class to facilitate the payment process using Wirecard.
 */
public class WirecardUtil {

	protected static transient Logger log = LoggerFactory.getLogger(WirecardUtil.class);

	public static final String MODE_MASTERCARD = "2";
	public static final String MODE_VISA = "3";
	public static final String MODE_AMEX = "5";
	public static final String MODE_DBS_PAY_LAH = "6";
	public static final String MODE_DINERS = "22";
	public static final String MODE_JCB = "23";
	public static final String MODE_CHINA_UNION_PAY = "25";
	public static final String MODE_MASTER_PASS = "28";
	public static final String MODE_VISA_CHECKOUT = "38";
	public static final String MODE_E_NETS = "41";
	public static final String TXN_STATUS_SUCCESSFUL = "YES";
	public static final String TXN_STATUS_FAIL = "NO";

	/**
	 * Generate Wirecard signature based on specified account info and secret key. Signature is to be sent to initiate payment process.
	 */
	public static String generateSignature(WirecardTxnDto dto, String secret) throws NoSuchAlgorithmException {
		String baseString = dto.getBaseString() + secret;
		return hashSignature(baseString).toUpperCase();
	}

	/**
	 * Generate Wirecard return signature based on specified account info, return info and secret key. Signature is to be used for validating the callback to complete payment process.
	 */
	public static String generateReturnSignature(WirecardTxnDto dto, String secret) throws NoSuchAlgorithmException {
		String baseString = dto.getBaseString() + dto.getReturnTxnStatus() + (dto.getReturnErrorCode() != null ? dto.getReturnErrorCode() : "") + secret;
		return hashSignature(baseString).toUpperCase();
	}

	/**
	 * Hash the specified signature.
	 */
	public static String hashSignature(String baseString) throws NoSuchAlgorithmException {
		MessageDigest hash = MessageDigest.getInstance("SHA-512");
		hash.update(baseString.getBytes());
		byte result[] = hash.digest();
		StringBuilder signature = new StringBuilder();
		for (int i = 0; i < result.length; i++) {
			// String s = Integer.toHexString(result[i]);
			String s = String.format("%02x", result[i]); // sonar fix
			int length = s.length();
			if (length >= 2) {
				signature.append(s.substring(length - 2, length));
			} else {
				signature.append("0");
				signature.append(s);
			}
		}
		log.info("Hashing Base String: " + baseString + ": " + signature.toString());
		return signature.toString();
	}

	/**
	 * Get the returned txn id from the specified callback request from Wirecard
	 */
	public static String getReturnTxnId(HttpServletRequest callBackReq) {
		return callBackReq.getParameter("TM_RefNo");
	}

	/**
	 * Verify the return signature and set the return values from the specified callback request from Wirecard for payment process completion.
	 */
	public static WirecardTxnDto setReturnValues(HttpServletRequest callBackReq, WirecardTxnDto dto) throws NoSuchAlgorithmException {
		if (callBackReq != null) {
			logCallback(callBackReq);
			dto.setTxnId(getReturnTxnId(callBackReq));
			dto.setReturnTxnStatus(callBackReq.getParameter("TM_Status"));
			dto.setReturnErrorCode(callBackReq.getParameter("TM_Error"));
			dto.setReturnErrorMsg(callBackReq.getParameter("TM_ErrorMsg"));
			dto.setReturnSignature(callBackReq.getParameter("TM_Signature"));
			dto.setReturnCCNum(callBackReq.getParameter("TM_CCNum"));
		}
		return dto;
	}

	/**
	 * Convenient method to log the Wirecard callback request.
	 */
	public static void logCallback(HttpServletRequest request) {
		Map<String, String[]> map = request.getParameterMap();
		Set<Entry<String, String[]>> set = map.entrySet();
		Iterator<Entry<String, String[]>> iterator = set.iterator();

		StringBuilder stringBuilder = new StringBuilder();
		while (iterator.hasNext()) {
			Map.Entry<String, String[]> entry = iterator.next();
			String key = entry.getKey();
			String[] value = entry.getValue();

			stringBuilder.append(key + "=");
			if (value.length > 1) {
				for (int i = 0; i < value.length; i++) {
					stringBuilder.append(value[i].toString());
					if (i < value.length - 1) {
						stringBuilder.append(",");
					}
				}
			} else {
				stringBuilder.append(value[0].toString() + " | ");
			}
		}
		log.info("Callback request from " + request.getRemoteAddr() + " with params: " + stringBuilder.toString());
	}
}
