# Setup Guide

	1.	Download and install the latest stable version of 
		a. Microsoft Visual Studio Code (commonly known as VS Code) from https://code.visualstudio.com/
		b. nodejs from https://nodejs.org
	
	2.	(Optional) Under VS Code, Go to View > Extensions, and download:
		a.	Live Server (for Brackets' Live Preview functionality)
		b.	GIT History (for complementing VS Code GIT)
		
	3.	Under VS Code, Go to Files > Preference > Settings > Click on the "..." icon at the top right > Open settings.json > Add the following:
	
			"editor.detectIndentation": false,
			"editor.formatOnSave": true,
			"html.format.wrapLineLength": 200,
			"htmlhint.options": {
				"tagname-lowercase": false,
				"attr-lowercase": false,
				"attr-value-double-quotes": true,
				"doctype-first": false
			}
		
	4.	Switch/Pull from "angular-7" branch
	
	5.	Open Folder to your newly pulled branch
	
	6.	Go to Terminal > New Terminal, and type:
		a.	npm install 
			
	7.	After all the dependencies have been installed, a "node_modules" folder will be created. You are ready to start the development server. Type:
		a. npm install -g @angular/cli
			this will install the Angular CLI globally. 
			
		b. ng serve --aot=true --sourceMap=false -o
			This command regenerates output files when source files change.
			ref: https://angular.io/cli/serve
		
		c. ng build --base-href=/wiztag/ --deploy-url=/wiztag/ --aot=true --prod=true --sourceMap=false --outputHashing=all --vendorChunk=true
			This build command for SIT deployment @ 10.0.3.5 accessible at http://wiztag.wizvision.com/
			
			ref: https://angular.io/cli/build
			note: added above into package.json, so you can just invoke `npm run build-sit`
		
        d. ng g c component-name
            open cmd/Terminal and goto the desire directory, then only hit the create component command above
            after creation, remove <component-name>.specs.ts file 
			ref: https://angular.io/cli/generate


	8. Angular browser extension
		https://augury.rangle.io/
		
# Directory Structure
    /src/app/main   - this is intranet pages 
    /src/app/portal - this is portal pages for TA/TG/TP (after login)
    /src/app/public - this is public accessible pages
		
# analyze bundle size with source-maps-explorer
	# 1. install source-map-explorer
		npm install -g source-map-explorer
	# build with sourceMap enabled 
	ng build --aot=true --sourceMap=true --vendorChunk=false
	
	# use source map explorer to check the files bundle
	source-map-explorer dist/main.js{,.map}
	source-map-explorer dist/portal-portal-module-ngfactory.js{,.map}
	source-map-explorer dist/main-main-module-ngfactory.js{,.map}
	
	ref: https://medium.com/@armno/til-analyzing-angular-apps-bundle-size-with-sourcemaps-explorer-f688e8a2386c
	
# ref 
	https://angular.io/guide/quickstart
	https://angular.io/guide/ajs-quick-reference
	https://material.angular.io/
	https://material.io/tools/icons/?style=baseline
	
	# default is development mode, refer to guide to enable production mode 
	https://angular.io/guide/deployment
	
	# careful with import, which may render huge filesize
	https://blog.angularindepth.com/a-deep-deep-deep-deep-deep-dive-into-the-angular-compiler-5379171ffb7a
	https://medium.com/@tomastrajan/6-best-practices-pro-tips-for-angular-cli-better-developer-experience-7b328bc9db81
	
	# vendorChunk (true = include 3rd party lib into separate file called vendor.js, useful if project 3rd library does not change much)
	https://stackoverflow.com/questions/52179853/angular-should-i-use-the-vendorchunk-in-production/52180120
		
# Error 
	[Err Message] ng is not recognized as an internal or external command
	npm install -g @angular/cli
	
	
	[Err Message] Node Sass does not yet support your current environment: Windows 64-bit with Unsupported runtime 
	npm rebuild node-sass

	
# tomcat url rewrite /WEB-INF/rewrite.config
RewriteCond %{REQUEST_URI} ^.*\.(bmp|css|gif|htc|html?|ico|jpe?g|js|pdf|png|swf|txt|xml|svg|eot|woff|woff2|ttf)$
RewriteRule ^.*$ - [L]
RewriteRule ^.*$ /index.html [L,QSA]


# include the following tomcat config into conf/context.xml (to enable url rewrite above)
<Valve className="org.apache.catalina.valves.rewrite.RewriteValve" />

