import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IdleTimeoutService } from '../services';
import * as cnst from '../constants';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
    constructor(
        private sessionTimeoutService: IdleTimeoutService,
    ) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (this.toIntercept(request.url)) {
            // for request that hits APEX non-public API, add authorization header with jwt token if available
            console.log("JwtInterceptor intercept " + sessionStorage.getItem('jwt-token'));
            if (sessionStorage.getItem('jwt-token')) {
                request = request.clone({
                    setHeaders: {
                        "App-Authorization": 'Bearer ' + sessionStorage.getItem('jwt-token')
                    },
                });
            }

            return next.handle(request).pipe(map(response => {
                if (response instanceof HttpResponse) {
                    //console.log("JwtInterceptor intercept response header " + response.headers.get('X-Auth-Token'));
                    if (response.headers.get('X-Auth-Token')) {
                        sessionStorage.setItem('jwt-token', response.headers.get('X-Auth-Token'));
                    }
                    this.sessionTimeoutService.resetTimer();
                }
                return response;
            }));

        } else {
            return next.handle(request);
        }
    }

    private toIntercept(url: string): boolean {
        return ((url.startsWith(cnst.apexBaseUrl) && !cnst.apexPublicBaseUrls.some(s => url.startsWith(s)))
            || (url.startsWith(cnst.apiBaseUrl + '/my-info') || url.startsWith(cnst.apiBaseUrl + '/edh') || url.startsWith(cnst.apiBaseUrl + '/users/logout')
                || url.startsWith(cnst.apiBaseUrl + '/users/authenticate-iams')));
    }
}
