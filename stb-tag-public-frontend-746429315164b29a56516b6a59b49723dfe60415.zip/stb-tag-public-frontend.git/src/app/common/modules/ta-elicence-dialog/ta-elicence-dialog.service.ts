import { Injectable } from '@angular/core';
import { Observable, } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TaElicenceDialogService {

    constructor(private http: HttpClient) { }

    updateFlagAndDownloadFiles(licenceId: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_ELICENCE_REQUEST + '/updateFlag', { licenceId: licenceId }, { responseType: 'blob' });
    }

    download(dto: any): Observable<any> {
        return this.http.post(cnst.apexBaseUrl + cnst.TaApiUrl.TA_ELICENCE_REQUEST + '/download', dto, { responseType: 'blob' });
    }
}
