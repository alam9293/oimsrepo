import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatTableDataSource, MatSort } from '@angular/material';
import { TaPastInfringementService } from './ta-past-infringements.service';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-ta-past-infringements-list',
    templateUrl: './ta-past-infringements-list.component.html',
    styleUrls: ['./ta-past-infringements-list.component.scss']
})
export class TaPastInfringementsListComponent implements OnInit {

    cnst = cnst;
    hasOutstandingPayment = false;
    displayedColumns = ['name', 'licenceNo', 'provisionSection', 'infringedDate', 'outcomeLabel', 'outcomeDate', 'paymentRequestStatus'];
    rows = new MatTableDataSource<any>();
    @ViewChild(MatSort) sort: MatSort;
    @Input() showPaymentLink: boolean;

    constructor(
        private taPastInfringementService: TaPastInfringementService
    ) { }

    ngOnInit() {
        this.loadPastInfringements();
    }

    ngAfterViewInit(): void {
        // Sorting with nested objects
        this.rows.sortingDataAccessor = (item, property) => {
            switch (property) {
                case 'paymentRequestStatus.label': return item.paymentRequestStatus.label;
                default: return item[property];
            }
        };
        this.rows.sort = this.sort;
    }
    loadPastInfringements() {
        this.taPastInfringementService.getPastInfrignements().subscribe(data => {
            this.rows.data = data;

            let afpNotPaid = data.filter(x => x.paymentRequestStatus.key == cnst.PaymentStatuses.PAYREQ_NOT_PAID);
            this.hasOutstandingPayment = afpNotPaid && afpNotPaid.length > 0;
        });
    }

    setParamPaymentToPay(row: any) {
        return { billRefNo: row.billRefNo, payerUinUen: row.uenUin };
    }
}
