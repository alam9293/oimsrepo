import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DashboardTgService } from '../dashboard-tg/dashboard-tg.service';
import * as cnst from '../../../common/constants';

@Component({
    selector: 'app-tg-pending-actions',
    templateUrl: './tg-pending-actions.component.html',
    styleUrls: ['./tg-pending-actions.component.scss']
})
export class TgPendingActionsComponent implements OnInit {

    filter: any = {};
    applications = [];
    cnst = cnst;
    appsDisplayedColumns = ['date', 'typeRefId', 'status', 'remarks'];
    applicationStatuses: any = [];
    applicationTypes: any = [];

    constructor(
        private route: ActivatedRoute,
        private dialog: MatDialog,
        private service: DashboardTgService
    ) { }

    ngOnInit() {
        this.loadPendingActions();
    }

    loadPendingActions() {
        this.service.getPendingActions().subscribe(data => {
            this.applications = data;
        });
    }
}
