import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService, NotificationService } from '../../../common/services';
import { User, LicenseeDto, TouristGuideDto, LicenceDto, TgTrainingProviderDto } from '../../../common/models';
import { SideMenuTgService } from './side-menu-tg.service';
import { DomSanitizer } from '@angular/platform-browser';
import { FileUtil, AppUtil } from '../../../common/helper';
import * as cnst from '../../../common/constants';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ELicenceDialogComponent } from '../../../common/modules/elicence-dialog/elicence-dialog.component';
import * as _ from 'lodash';

@Component({
    selector: 'app-side-menu-tg',
    templateUrl: './side-menu-tg.component.html',
    styleUrls: ['./side-menu-tg.component.scss']
})
export class SideMenuTgComponent implements OnInit {
    @Input() dashboardTypeCode: string;
    showMenu = '';
    currentUser: User;
    licensee: LicenseeDto;
    licence: LicenceDto;
    touristGuide: TouristGuideDto;
    tgTrainingProvider: TgTrainingProviderDto;  //temporary do not need
    viewRenew: boolean;
    viewReinstate: boolean;
    viewReplace: boolean;
    viewCancel: boolean;
    viewMLPT: boolean;
    viewArchive: boolean = false;
    tpName: string = "";
    cnst = cnst;
    imageSrc: any = "./assets/images/tg_photo.png";
    alerts: any = [];
    totalUnreadAlerts: Number = 0;
    currentUrl: any;
    displayChangePswdLink: boolean = false;
    displayCategory = 'Guiding Category';
    displayLanguage = 'Guiding Language';
    displayArea = 'Area of Specialisation';
    imageELicenceSrc: any = "./assets/images/tg_photo.png";

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private sideMenuTgService: SideMenuTgService,
        private _sanitizer: DomSanitizer,
        private fileUtil: FileUtil,
        private appUtil: AppUtil,
        private notificationService: NotificationService,
        public dialog: MatDialog,
    ) {
        this.touristGuide = new TouristGuideDto();
        this.licence = new LicenceDto();
    }

    ngOnInit() {
        this.currentUrl = this.route.snapshot['_routerState'].url;
        if (this.authenticationService.currentUserValue) {
            this.currentUser = this.authenticationService.currentUserValue;
            this.licensee = this.currentUser.licensee;
            this.tpName = this.currentUser.name;
        } else {
            this.sideMenuTgService.getCurrentUser().subscribe(data => {
                this.currentUser = data;
                this.licensee = this.currentUser.licensee;
                this.tpName = this.currentUser.name;
            });
        }
        if (this.currentUser.selectedRole.key == cnst.CommonRoles.TG_PUBLIC) {
            this.sideMenuTgService.getSideMenu().subscribe(data => {
                this.licence = data.licence;
                this.touristGuide = data.touristGuide;
                this.viewRenew = data.viewRenew;
                this.viewReinstate = data.viewReinstate;
                this.viewReplace = data.viewReplace;
                this.viewCancel = data.viewCancel;
                this.viewMLPT = data.viewMlpt;

                let photoId: number;
                photoId = this.touristGuide.photo.publicFileId;

                if (photoId) {
                    this.fileUtil.download(photoId, this.touristGuide.photo.hash).subscribe(data => {
                        const reader = new FileReader();
                        reader.onload = (e: any) => {
                            this.imageSrc = this._sanitizer.bypassSecurityTrustUrl(e.target.result);
                            this.imageELicenceSrc = e.target.result;
                        };
                        reader.readAsDataURL(data);
                    });
                }

                if (cnst.TgCommonTypes.TG_GENERAL_AREA == data.licence.licenceTier.key) {
                    this.displayCategory = 'Guiding Categories';
                }

                if (data.touristGuide.guidingLanguages.indexOf(",") > -1) {
                    this.displayLanguage = 'Guiding Languages';
                }
            });
        }

        this.notificationService.getTotalUnreadAlerts().subscribe(data => {
            this.totalUnreadAlerts = data;
        });
        this.notificationService.refreshUnread.subscribe(data => {
            this.totalUnreadAlerts = data;
        });

        if (sessionStorage.loginTypeCode != "SP") {
            this.displayChangePswdLink = true;
        }

        this.viewArchive = this.currentUrl.indexOf('tg/tg-courses-attended-mrc') > -1 || this.currentUrl.indexOf('tg/tg-courses-attended-pdc') > -1 || this.currentUrl.indexOf('tg/assignments/archive/view') > -1;
    }

    startIndex = 0;
    totalRecords = 0;
    loadAlerts() {
        let mergedDto = {
            'pageSize': cnst.PAGINATION.DEFAULT_PAGE_SIZE,
            'startIndex': this.startIndex
        };
        this.notificationService.getAlerts(mergedDto).subscribe(data => {
            this.alerts = _.concat(this.alerts, data.records);
            this.totalRecords = data.total;
            var reads = [];
            var unreads = [];
            var idsToClear = [];
            _.forEach(data.records, function (value) {
                if (value.statusCode === cnst.AlertStatuses.READ) {
                    reads.push(value);
                } else if (value.statusCode === cnst.AlertStatuses.UNREAD) {
                    unreads.push(value);
                }
                if (!value.url) {
                    idsToClear.push(value.id);
                }
            });
            this.alerts.read = _.concat(this.alerts.read, reads);
            this.alerts.unread = _.concat(this.alerts.unread, unreads);
            this.startIndex += cnst.PAGINATION.DEFAULT_PAGE_SIZE;
        });
    }

    readAllAlerts() {
        this.loadAlerts();
        this.notificationService.readAllAlerts().subscribe(data => {
            this.totalUnreadAlerts = data;
        });
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }

    onLoggedout() {
        this.authenticationService.logout();
        this.appUtil.routeToHomePage();
    }

    openELicenceDialog() {
        let elicenceDialogRef = this.dialog.open(ELicenceDialogComponent, {
            data: {
                licence: this.licence,
                touristGuide: this.touristGuide,
                tgPhotoSrc: this.imageELicenceSrc,
            }
        });
    }
}
