import { Component, OnInit, Inject, HostListener, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatSnackBar, MatStepper, MatTableDataSource, MatSort } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService, AlertService, MyInfoService, EdhService, } from '../../../common/services';
import { PaymentService } from '../../payment/payment.service';
import * as cnst from '../../../common/constants'
import { forkJoin, Observable } from 'rxjs';
import { TaCreationService } from './ta-application-form.service';
import { FormUtil, FileUtil, DateUtil, ValidateEmail, MinSelectedCheckboxes, ValidateAddressInput, ValidateAddressInputIncDash } from '../../../common/helper';
import { FormBuilder, FormControl, FormGroup, Validators, FormGroupDirective, NgForm, FormArray, AbstractControl, Form } from '@angular/forms';
import { PaymentDialogComponent } from '../../../common/modules/payment-dialog/payment-dialog.component';
import { InformationDialogComponent } from '../../../common/modules/information-dialog/information-dialog.component';
import { ValidateDigitMaxLength, TaFormHelperUtil } from '../ta-helper';
import { TaPastInfringementsListComponent } from '../../dashboard/ta-past-infringements-list/ta-past-infringements-list.component';
import { ValidationErrors } from '@angular/forms';

@Component({
    selector: 'app-ta-application-form-form',
    templateUrl: './ta-application-form.component.html',
    styleUrls: ['./ta-application-form.component.scss']
})
export class TaApplicationFormComponent implements OnInit {

    @ViewChild('stepper') stepper: MatStepper;
    address_types: any = [];
    sexes: any = [];
    nationalities: any = [];
    countries: any = [];
    licence_tiers: any = [];
    application_modes: any = [];
    form_of_business: any = [];
    business_constitution: any = [];
    principle_activities: any = [];
    stakeholder_roles: any = [];
    establishment_status: any = [];
    premises_types: any = [];
    business_services: any = [];
    area_of_focus: any = [];
    ta_segmentation: any = [];
    qualifications: any = [];
    occupations: any = [];
    appFeeAmount: any;
    licenceFeeAmount: any;
    application: any = { appFee: {}, licenceFee: {}, status: {}, appSex: {}, appNationality: {}, licenceTier: {}, principleActivities: {}, secondaryPrincipleActivities: {}, formOfBusiness: {}, placeIncorporated: {}, establishmentStatus: {}, taSegmentation: {}, registeredAddress: { premisesType: {} }, operatingAddress: { premisesType: {} }, taInboundSpecializedMarkets: [{}], taOutboundSpecializedMarkets: [{}], taBusinessOperations: [{}], taFocusAreas: [{}], taStakeholders: [], taKeyExecutive: { particulars: { uin: {} }, involvement: { taKeDeclarations: [] } } };
    action: any = 'new';
    formAppParticulars: FormGroup;
    formBusinessEntity: FormGroup;
    formAbpr: FormGroup;
    bizWriteUpQns: FormGroup;
    formPersonnel: FormGroup;
    formDocuments: FormGroup;
    formKe: FormGroup;
    showErrorMsg: boolean = false;
    showTriggerKeErrorMsg: boolean = true;
    cnst = cnst;
    declared: boolean;
    declaredAckInfringements: boolean;
    isLoggedInKe: boolean = null;
    appointingOtherKe: boolean = null;
    keAppointed: boolean = null;
    selectedFile: File;
    publicDeletedFiles: any = [];
    DateUtil = DateUtil;
    appMyInfoNonEditableFields: string[] = [];
    keMyInfoNonEditableFields: string[] = [];
    allowSubmit: boolean = false;
    pendingLicenceFeePayment: boolean = false;
    pendingLicenceFeeSettlement: boolean = false;
    pendingAppFeeSettlement: boolean = false;
    appAndLicenceFeeSettled: boolean = false;
    firstPaymentPreview: boolean = false;
    secondPaymentPreview: boolean = false;
    maxPreferredDate: Date = DateUtil.getNow().add(3, 'M').toDate();
    businessRow: FormGroup;
    areaOfFocus: FormGroup;
    marketSpecialise: FormGroup;
    fyeDay = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31];
    fyeMonth = [{ key: 1, label: 'Jan' }, { key: 2, label: 'Feb' }, { key: 3, label: 'Mar' }, { key: 4, label: 'Apr' }, { key: 5, label: 'May' }, { key: 6, label: 'Jun' }, { key: 7, label: 'Jul' }, { key: 8, label: 'Aug' }, { key: 9, label: 'Sep' }, { key: 10, label: 'Oct' }, { key: 11, label: 'Nov' }, { key: 12, label: 'Dec' }];
    unionMap = new Map<string, string>();
    isEdhError: boolean = false;
    salesChannels: any = [];

    constructor(
        public dialog: MatDialog,
        private route: ActivatedRoute,
        public snackBar: MatSnackBar,
        private commonService: CommonService,
        private service: TaCreationService,
        private formBuilder: FormBuilder,
        private router: Router,
        public formUtil: FormUtil,
        private fileUtil: FileUtil,
        private alertService: AlertService,
        private myInfoService: MyInfoService,
        private edhService: EdhService,
        private paymentService: PaymentService,
        private taFormHelperUtil: TaFormHelperUtil) { }

    @HostListener('window:beforeunload')
    canDeactivate(): Observable<boolean> | boolean {
        return (this.formAppParticulars.pristine && this.formBusinessEntity.pristine && this.formAbpr.pristine && this.bizWriteUpQns.pristine && this.formPersonnel.pristine && this.formKe.pristine && this.formDocuments.pristine);
    }

    ngOnInit() {
        //  this.loadAppEdh();
        this.buildForm();
        let loadPromise;
        if (this.route.snapshot.paramMap.get('id') != null) {
            loadPromise = this.service.getApp(+this.route.snapshot.paramMap.get('id'));
        } else {
            loadPromise = this.service.checkForPendingApplication();
        }


        loadPromise.subscribe(data => {
            if (data.isActiveLicencee) {
                this.dialog.open(InformationDialogComponent, { data: { content: 'You are already a licensee. You will be redirected to Dashboard.', url: '/portal/dashboard-ta' } })
            } else if (data.isDeleted) {
                this.dialog.open(InformationDialogComponent, { data: { content: 'Draft has been deleted. Please submit a new form', url: '/portal/ta-application-form' } })
            } else {
                this.setupForm(data);
                this.application = data;
                this.loadCommonTypes();
                this.appMyInfoNonEditableFields = this.application.appEditableFields;
                this.keMyInfoNonEditableFields = this.application.keEditableFields;

                if (this.application.status.key == null) {
                    this.action = 'new';
                    if (this.application.taKeyExecutive.particulars && this.application.taKeyExecutive.particulars.uin != "") {
                        if (this.application.taKeyExecutive.particulars.uin.toUpperCase() != this.application.loggedInUin.toUpperCase()) {
                            this.formKe.get('taKeyExecutive').get('involvement').get('taKeDeclarations').disable();
                            this.isLoggedInKe = false;
                        } else {
                            this.isLoggedInKe = true;
                        }
                        this.keAppointed = true;
                        this.appointingOtherKe = false;
                    }
                    if (this.application.isDraft && this.application.isEdhPopulated) {
                        this.loadEdh();

                    }

                    if (!this.application.isDraft && !this.application.appFee) {
                        this.loadEdh();
                    }
                    if (this.application.appFee && (this.application.appFee.statusCode == cnst.PaymentStatuses.PAYREQ_PAID || this.application.appFee.statusCode == cnst.PaymentStatuses.PAYREQ_SETTLED)) {
                        this.action = 'view';
                        this.formAppParticulars.disable();
                        this.formBusinessEntity.disable();
                        this.formAbpr.disable();
                        this.formKe.disable();
                        this.formPersonnel.disable();
                        this.bizWriteUpQns.disable();
                        this.keAppointed = true;
                        this.appointingOtherKe = false;
                        this.allowSubmit = true;
                        this.stepper.selectedIndex = 6;
                    }


                } else if (this.application.status.key == cnst.ApplicationStatuses.TA_APP_RFA) {
                    this.action = 'rfa';
                    if (this.application.taKeyExecutive.particulars.uin.toUpperCase() != this.application.loggedInUin.toUpperCase()) {
                        this.formKe.get('taKeyExecutive').get('involvement').get('taKeDeclarations').disable();
                        this.isLoggedInKe = false;
                    } else {
                        this.isLoggedInKe = true;
                    }
                    this.keAppointed = true;
                    this.appointingOtherKe = false;

                } else if (this.application.status.key == cnst.ApplicationStatuses.TA_APP_PENDING_OA) {
                    this.action = 'ipa';
                    this.formAppParticulars.disable();
                    this.formBusinessEntity.disable();
                    this.formAbpr.disable();
                    this.bizWriteUpQns.disable();
                    this.formKe.disable();
                    this.formPersonnel.disable();
                    this.keAppointed = true;
                    this.appointingOtherKe = false;
                    this.formBusinessEntity.get('operatingAddress').enable();
                    this.formBusinessEntity.get('isOppAddSameAsRegAdd').enable();
                } else {
                    this.action = 'view';
                    this.formAppParticulars.disable();
                    this.formBusinessEntity.disable();
                    this.formAbpr.disable();
                    this.bizWriteUpQns.disable();
                    this.formKe.disable();
                    this.formPersonnel.disable();
                    this.keAppointed = true;
                    this.appointingOtherKe = false;

                    if (this.application.status.key == cnst.ApplicationStatuses.TA_APP_APPROVED) {
                        if (this.application.licenceFee.statusCode == cnst.PaymentStatuses.PAYREQ_NOT_PAID) {
                            this.pendingLicenceFeePayment = true;
                        } else {

                            if (this.application.licenceFee.statusCode == cnst.PaymentStatuses.PAYREQ_PAID) {
                                this.pendingLicenceFeeSettlement = true;
                            }
                            if (this.application.appFee.statusCode == cnst.PaymentStatuses.PAYREQ_PAID) {
                                this.pendingAppFeeSettlement = true;
                            }
                            if ((this.application.licenceFee.statusCode == cnst.PaymentStatuses.PAYREQ_SETTLED || this.application.licenceFee.statusCode == cnst.PaymentStatuses.PAYREQ_WAIVED)
                                && (this.application.appFee.statusCode == cnst.PaymentStatuses.PAYREQ_SETTLED || this.application.appFee.statusCode == cnst.PaymentStatuses.PAYREQ_WAIVED)
                            ) {
                                this.appAndLicenceFeeSettled = true;
                            }
                        }
                    }
                }
            }

            //FORCE VALIDATES PAGE ON PAGE LOAD
            this.forceValidate();
            (this.bizWriteUpQns.get('salesChannelDtos') as FormArray).valueChanges.subscribe(values => {
                var index = this.salesChannels.length - 1; //see if the last classification (Others) is selected
                if (index + 1 === values.length) {
                    if (values[index]) {
                        this.bizWriteUpQns.get('otherSalesChannel').setValidators([Validators.maxLength(255), Validators.required]);
                    } else {
                        if (this.bizWriteUpQns.get('otherSalesChannel').enabled) {
                            this.bizWriteUpQns.get('otherSalesChannel').patchValue('');
                            this.bizWriteUpQns.get('otherSalesChannel').setValidators([Validators.maxLength(255)]);
                        }
                    }
                }
                this.bizWriteUpQns.get('otherSalesChannel').updateValueAndValidity();
            });

            if (this.route.snapshot.paramMap.get('stepNo') != null) {
                this.stepper.selectedIndex = +this.route.snapshot.paramMap.get('stepNo');
            }
        });

    }

    forceValidate() {
        //FORCE VALIDATES PAGE ON PAGE LOAD
        for (var i = 0; i < 6; i++) {
            this.stepper.selectedIndex = i;
        }
        this.stepper.selectedIndex = 0;

    }

    buildForm() {
        this.formAppParticulars = this.formBuilder.group({
            appName: ['', [Validators.required, , Validators.maxLength(255)]],
            appUin: ['', [Validators.required, , Validators.maxLength(255)]],
            appDob: ['', Validators.required],
            appSex: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            appNationality: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            appDesignation: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            appOtherDesignation: ['', Validators.maxLength(255)],
            appOfficeNo: ['', Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)],
            appResidentialNo: ['', Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)],
            appMobileNo: ['', [Validators.required, Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
            appFaxNo: ['', Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)],
            appEmailAddress: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
            isAppMyInfo: [false],
            isAppMyInfoClicked: [false]

        });
        this.formBusinessEntity = this.formBuilder.group({
            isEdhPopulated: [false],
            effectiveDate: ['', [Validators.required]],
            applicationMode: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            licenceTier: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            companyName: ['', [Validators.required, Validators.maxLength(255)]],
            companyFormerName: ['', Validators.maxLength(255)],
            formOfBusiness: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            businessConstitution: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            uen: ['', [Validators.required, , Validators.maxLength(255)]],
            registrationDate: ['', [Validators.required, , Validators.maxLength(255)]],
            principleActivities: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            secondaryPrincipleActivities: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            placeIncorporated: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            establishmentStatus: this.formBuilder.group({
                key: [''],
                label: ['']
            }),

            paidUpCapital: ['', [Validators.required, Validators.maxLength(19)]],
            websiteUrl: ['', Validators.maxLength(255)],
            emailAddress: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
            contactNo: ['', [Validators.required, , Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
            faxNo: ['', Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)],
            fyeDay: ['', [Validators.required]],
            fyeMonth: ['', [Validators.required]],
            registeredAddress: this.formBuilder.group({
                street: ['', [Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET), ValidateAddressInputIncDash]],
                building: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING), ValidateAddressInputIncDash]],
                block: ['', [Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                unit: ['', ValidateAddressInputIncDash], // does not follow SGDRM as EDH returns "01/02" etc when there are multiple units
                postal: ['', [Validators.required, Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), , Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                formatted: [''],
                singleLined: [''],
                premisesType: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                type: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                foreignLine1: ['', Validators.maxLength(255)],
                foreignLine2: ['', Validators.maxLength(255)],
                foreignLine3: ['', Validators.maxLength(255)],
            }),
            operatingAddress: this.formBuilder.group({
                street: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET), ValidateAddressInputIncDash]],
                building: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING), ValidateAddressInputIncDash]],
                block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                unit: ['', ValidateAddressInputIncDash], // does not follow SGDRM as EDH returns "01/02" etc when there are multiple units
                postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$'), ValidateAddressInput]],
                formatted: [''],
                singleLined: [''],
                premisesType: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
            }),
            isOppAddSameAsRegAdd: [false],
        }, { validator: [this.oppAddRequiredValidator(), this.regAddRequiredValidator()] });
        this.formAbpr = this.formBuilder.group({
            inboundOpPercent: [0, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
            outboundOpPercent: [0, Validators.compose([Validators.required, Validators.min(0), Validators.max(100)])],
            taBusinessWriteUp: ['',],
            currentBusinessWriteUp: ['', Validators.maxLength(65535)],
            taInboundSpecializedMarkets: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.duplicatedSelectionValidator('country'),])),
            taOutboundSpecializedMarkets: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.duplicatedSelectionValidator('country'),])),
            taBusinessOperations: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.duplicatedSelectionValidator('service'),])),
            taFocusAreas: this.formBuilder.array([], Validators.compose([this.taFormHelperUtil.minLengthArray(1), this.taFormHelperUtil.duplicatedSelectionValidator('focusArea'),])),
            taSegmentation: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
        }, {
            validator: Validators.compose(
                [
                    this.matchingTotalInboundOutboundValidator("inboundOpPercent", "outboundOpPercent"),
                    this.taFormHelperUtil.zeroValuePercentageValidator("inboundOpPercent", "taInboundSpecializedMarkets", "percentage", "taInboundSpecializedMarketsNotZeroError"),
                    this.taFormHelperUtil.hundredValuePercentageValidator("inboundOpPercent", "taInboundSpecializedMarkets", "percentage", "taInboundSpecializedMarketsNotHundredError"),
                    this.taFormHelperUtil.zeroValuePercentageValidator("outboundOpPercent", "taOutboundSpecializedMarkets", "percentage", "taOutboundSpecializedMarketsNotZeroError"),
                    this.taFormHelperUtil.hundredValuePercentageValidator("outboundOpPercent", "taOutboundSpecializedMarkets", "percentage", "taOutboundSpecializedMarketsNotHundredError"),

                    this.taFormHelperUtil.zeroValuePercentageValidator("inboundOpPercent", "taBusinessOperations", "inboundPercent", "inboundBoNotZeroError"),
                    this.taFormHelperUtil.hundredValuePercentageValidator("inboundOpPercent", "taBusinessOperations", "inboundPercent", "inboundBoNotHundredError"),
                    this.taFormHelperUtil.zeroValuePercentageValidator("outboundOpPercent", "taBusinessOperations", "outboundPercent", "outboundBoNotZeroError"),
                    this.taFormHelperUtil.hundredValuePercentageValidator("outboundOpPercent", "taBusinessOperations", "outboundPercent", "outboundBoNotHundredError"),

                    this.taFormHelperUtil.matchingInboundOutboundCheckValidator("inboundOpPercent", "taFocusAreas", "hasInboundOp", "mismatchedInboundFocusPercentage", "mismatchedInboundFocusZero"),
                    this.taFormHelperUtil.matchingInboundOutboundCheckValidator("outboundOpPercent", "taFocusAreas", "hasOutboundOp", "mismatchedOutboundFocusPercentage", "mismatchedOutboundFocusZero"),
                ]
            )
        });

        this.bizWriteUpQns = this.formBuilder.group({

            businessIdea: ['', [Validators.required, Validators.maxLength(65535)]],
            consumerFacingBrand: ['', Validators.maxLength(255)],
            mktgCommsPlan: ['', [Validators.required, Validators.maxLength(65535)]],
            salesChannelSelected: [, [Validators.required]],
            salesChannelDtos: new FormArray([], MinSelectedCheckboxes(1)),
            otherSalesChannel: ['',],
            financialStrategy: ['', [Validators.required, Validators.maxLength(65535)]],
            revenueProj1: [0, Validators.compose([Validators.required, Validators.maxLength(19)])],
            revenueProj2: [0, Validators.compose([Validators.required, Validators.maxLength(19)])],
            costProj1: [0, Validators.compose([Validators.required, Validators.maxLength(19)])],
            costProj2: [0, Validators.compose([Validators.required, Validators.maxLength(19)])],
            profitLossProj1: [0, Validators.compose([Validators.required, Validators.maxLength(19)])],
            profitLossProj2: [0, Validators.compose([Validators.required, Validators.maxLength(19)])],
            estTimeToProfit: ['', Validators.maxLength(255)],
            competitiveEdge: ['', [Validators.maxLength(65535)]],
            partnerServideProviders: ['', [Validators.required, Validators.maxLength(65535)]],
            hasOtherBizActivities: ['', [Validators.required]],
            percentFocusOnTaBiz: [{ value: '', disabled: true }, Validators.compose([Validators.min(0), Validators.max(100)])],
            hasTaLicBefore: ['', [Validators.required]],
            detailsRegardingPrevLic: [{ value: '', disabled: true }, []],
            relationsWithOtherTa: ['', [Validators.required, Validators.maxLength(65535)]],
            others: ['', [Validators.maxLength(65535)]],
        }, {
            validator: Validators.compose(
                [
                ]
            )
        });

        this.formKe = this.formBuilder.group({
            appointedKeUin: ['', Validators.maxLength(255)],
            appointedKeName: ['', Validators.maxLength(255)],
            appointedKeEmail: ['', [Validators.maxLength(320), ValidateEmail]],
            taKeyExecutive: this.addKeDtoFormControl(),
            isKeMyInfo: [false],
            isKeMyInfoClicked: [false]
        }, { validator: [this.anotherKeRequiredValidator()] });
        this.formPersonnel = this.formBuilder.group({
            taStakeholders: this.formBuilder.array([this.addPersonnelDtoFormControl()], Validators.required),
        });

        this.formDocuments = this.formBuilder.group({
            keNric: this.addFileDtoFormControl(),
            keResume: this.formBuilder.group({
                id: [''],
                publicFileId: [''],
                originalName: ['', Validators.required],
                processedName: [''],
                docType: [''],
                extension: [''],
                path: [''],
                size: [''],
                hash: [''],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [''],
                readableFileSize: [''],
                hasTemplate: [],
            }),
            keResolution: this.formBuilder.group({
                id: [''],
                publicFileId: [''],
                originalName: ['', Validators.required],
                processedName: [''],
                docType: [''],
                extension: [''],
                path: [''],
                size: [''],
                hash: [''],
                documentInstructions: [],
                documentTypeLabel: [],
                description: [''],
                readableFileSize: [''],
                hasTemplate: [],
            }),
            beoc: this.addFileDtoFormControl(),
            bankStatement: this.addFileDtoFormControl(),
            tenancyAgreement: this.addFileDtoFormControl(),
            hosApproval: this.addFileDtoFormControl(),
            cbs: this.addFileDtoFormControl(),
            afa: this.addFileDtoFormControl(),
            acra: this.addFileDtoFormControl(),
            otherDocuments: this.formBuilder.array([]),
        }, { validator: [this.bankStatementRequiredValidator(), this.tenancyDocRequiredValidator(), this.hosDocRequiredValidator(), this.cbsDocRequiredValidator(), this.afaDocRequiredValidator(), this.keNricRequiredValidator()] });
        this.listenTenancyDocRequiredValidator();
        this.listenAcraDocRequiredValidator();
    }

    get taInboundSpecializedMarkets() {
        return this.formAbpr.get('taInboundSpecializedMarkets') as FormArray
    }
    get taOutboundSpecializedMarkets() {
        return this.formAbpr.get('taOutboundSpecializedMarkets') as FormArray
    }
    get taBusinessOperations() {
        return this.formAbpr.get('taBusinessOperations') as FormArray
    }
    get taFocusAreas() {
        return this.formAbpr.get('taFocusAreas') as FormArray
    }
    get taStakeholders() {
        return this.formPersonnel.get('taStakeholders') as FormArray
    }
    get taKeDeclarations() {
        return this.formKe.controls['taKeyExecutive'].get('involvement').get('taKeDeclarations') as FormArray
    }
    get otherDocuments() {
        return this.formDocuments.get('otherDocuments') as FormArray;
    }

    setupForm(application: any) {
        if (application.salesChannelDtos) {
            application.salesChannelDtos.forEach(item => {
                var salesChannelForm = (this.formBuilder.group({
                    id: '',
                    isYes: false,
                }, {}));
                salesChannelForm.patchValue(item);
                (this.bizWriteUpQns.get('salesChannelDtos') as FormArray).push(salesChannelForm);
            });
        }

        this.commonService.getTaSalesChannels().subscribe(data => {
            this.salesChannels = data
            this.salesChannels.forEach((o, i) => {
                const control = new FormControl(application.salesChannelSelected ? application.salesChannelSelected.includes(o.key) : false); // if selected set to true, else false
                (this.bizWriteUpQns.get('salesChannelDtos') as FormArray).push(control);
            });
        });
        this.bizWriteUpQns.patchValue(application);
        if (application.otherSalesChannel) {
            this.bizWriteUpQns.get("otherSalesChannel").patchValue(application.otherSalesChannel);
            this.bizWriteUpQns.get('otherSalesChannel').updateValueAndValidity();
        }

        this.updatePercentFocusOnTaBizValidtor(this.bizWriteUpQns.value.hasOtherBizActivities);
        this.updateDetailsRegardingPrevLic(this.bizWriteUpQns.value.hasTaLicBefore);

        if (application.taBusinessWriteUp) {
            this.formAbpr.get('taBusinessWriteUp').setValidators([Validators.min(0), Validators.max(100), Validators.required]);
            this.formAbpr.get('taBusinessWriteUp').updateValueAndValidity();
            this.disableBizWriteUpForm();
        }



        this.formAppParticulars.patchValue(application);
        this.formBusinessEntity.patchValue(application);
        this.formAbpr.patchValue(application);
        this.formKe.patchValue(application);
        this.formDocuments.patchValue(application);

        this.taInboundSpecializedMarkets.removeAt(0);
        if (application.taInboundSpecializedMarkets.length > 0) {
            application.taInboundSpecializedMarkets.forEach(row => {
                this.marketSpecialise = this.initMarketSpecialise();
                this.marketSpecialise.patchValue(row);
                this.taInboundSpecializedMarkets.push(this.marketSpecialise);
            });
        }

        this.taOutboundSpecializedMarkets.removeAt(0);
        if (application.taOutboundSpecializedMarkets.length > 0) {
            application.taOutboundSpecializedMarkets.forEach(row => {
                this.marketSpecialise = this.initMarketSpecialise();
                this.marketSpecialise.patchValue(row);
                this.taOutboundSpecializedMarkets.push(this.marketSpecialise);
            });
        }

        if (application.taBusinessOperations.length > 0) {
            application.taBusinessOperations.forEach(row => {
                this.businessRow = this.initBusinessItemRows();
                this.businessRow.patchValue(row);
                this.taBusinessOperations.push(this.businessRow);
            });
        }

        this.taFocusAreas.removeAt(0);
        if (application.taFocusAreas.length > 0) {
            application.taFocusAreas.forEach(row => {
                this.areaOfFocus = this.initAreaOfFocus();
                this.areaOfFocus.patchValue(row);
                this.taFocusAreas.push(this.areaOfFocus);
            });
        }

        if (application.otherDocuments && application.otherDocuments.length > 0) {
            application.otherDocuments.forEach(item => {
                this.otherDocuments.push(this.formBuilder.group(item));
            });

        }

        this.taStakeholders.removeAt(0);
        if (application.taStakeholders.length > 0) {
            application.taStakeholders.forEach(row => {
                let x = this.addPersonnelDtoFormControl();
                x.patchValue(row);
                this.taStakeholders.push(x);
            });
        }

        this.taKeDeclarations.controls = [];
        application.taKeyExecutive.involvement.taKeDeclarations.forEach(row => {
            let x = this.addKeDeclarationDtoFormControl();
            x.patchValue(row)
            this.taKeDeclarations.push(x);
        });
        this.formControlValueChanged();
    }

    addKeDtoFormControl() {
        return this.formBuilder.group({
            particulars: this.formBuilder.group({
                stakeholderId: [''],
                isCompany: [''],
                companyUen: ['', Validators.maxLength(255)],
                companyIncorporatedDate: [''],
                stakeholderName: ['', [Validators.required, Validators.maxLength(255)]],
                uin: ['', [Validators.required, Validators.maxLength(255)]],
                formerUin: ['', Validators.maxLength(255)],
                dob: ['', Validators.required],
                contactNo: ['', [Validators.required, Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],

                officeNo: ['', [Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
                residentialNo: ['', [Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],

                email: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
                designation: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                otherDesignation: ['', Validators.maxLength(255)],
                sex: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                nationality: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                highestEduLevel: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
                address: this.formBuilder.group({
                    street: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)],
                    building: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
                    block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    unit: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.UNIT), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    formatted: [''],
                    singleLined: [''],
                    type: this.formBuilder.group({
                        key: [cnst.AddressTypes.ADDR_LOCAL, Validators.required],
                        label: ['']
                    }),
                }),
            }),
            involvement: this.formBuilder.group({
                taStakeholderId: [''],
                appointedDate: ['', Validators.required],
                role: this.formBuilder.group({
                    key: ['STKHLD_KE'],
                    label: ['']
                }),
                taKeDeclarations: this.formBuilder.array([this.formBuilder.group({
                    id: [],
                    prefix: [],
                    selectedOption: [],
                    options: [],
                    optionsToPrompt: [],
                    prompt: [],
                    clause: this.formBuilder.group({
                        key: [],
                        label: []
                    }),
                    subscript: [],
                    remarks: [, Validators.maxLength(255)],
                    isOptionRequired: [],
                    isRadioButton: [],
                }, { validator: [this.declarationRequiredValidator()] })]),
            }),
        }, { validator: [this.keAddRequiredValidator()] })
    }

    addKeDeclarationDtoFormControl() {
        return this.formBuilder.group({
            id: [''],
            prefix: [''],
            selectedOption: [''],
            options: [''],
            optionsToPrompt: [''],
            prompt: [''],
            clause: this.formBuilder.group({
                key: [''],
                label: ['']
            }),
            subscript: [''],
            remarks: ['', Validators.maxLength(255)],
            isOptionRequired: [''],
            isRadioButton: [''],
        }, { validator: [this.declarationRequiredValidator()] })
    }

    addPersonnelDtoFormControl() {
        return this.formBuilder.group({
            particulars: this.formBuilder.group({
                stakeholderId: [''],
                isCompany: [''],
                companyUen: ['', Validators.maxLength(255)],
                companyIncorporatedDate: [''],
                stakeholderName: ['', [Validators.required, Validators.maxLength(255)]],
                uin: ['', Validators.maxLength(255)],
                formerUin: ['', Validators.maxLength(255)],
                dob: [''],
                contactNo: ['', [Validators.required, Validators.maxLength(cnst.SgdrmPhoneFieldsSize.FULL)]],
                email: ['', [Validators.required, Validators.maxLength(320), ValidateEmail]],
                nationality: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
                sex: this.formBuilder.group({
                    key: [''],
                    label: ['']
                }),
                address: this.formBuilder.group({
                    street: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.STREET)],
                    building: ['', Validators.maxLength(cnst.SgdrmAddressFieldsSize.BUILDING)],
                    block: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.BLOCK), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    floor: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.FLOOR), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    unit: [''], // does not follow SGDRM as EDH returns "01/02" etc when there are multiple units
                    postal: ['', [Validators.maxLength(cnst.SgdrmAddressFieldsSize.POSTAL), Validators.pattern('^[a-zA-Z0-9 ]*$')]],
                    foreignLine1: ['', Validators.maxLength(255)],
                    foreignLine2: ['', Validators.maxLength(255)],
                    foreignLine3: ['', Validators.maxLength(255)],
                    formatted: [''],
                    singleLined: [''],
                    type: this.formBuilder.group({
                        key: ['', Validators.required],
                        label: ['']
                    }),
                }),
            }),
            involvement: this.formBuilder.group({
                taStakeholderId: [''],
                sharesHeld: [''],
                appointedDate: ['', Validators.required],
                resignedDate: [''],
                role: this.formBuilder.group({
                    key: ['', Validators.required],
                    label: ['']
                }),
            }),
        }, { validator: [this.personnelUinRequiredValidator(), this.personnelUenRequiredValidator(), this.sharesheldRequiredValidator(), this.shAddRequiredValidator()] })
    }
    addFileDtoFormControl() {
        return this.formBuilder.group({
            id: [''],
            publicFileId: [''],
            originalName: [''],
            processedName: [''],
            docType: [''],
            extension: [''],
            path: [''],
            size: [''],
            hash: [''],
            documentInstructions: [],
            documentTypeLabel: [],
            description: [''],
            readableFileSize: [''],
            hasTemplate: [],
        })
    }
    addFileDto() {
        return {
            id: '',
            publicFileId: '',
            originalName: '',
            processedName: '',
            docType: '',
            extension: '',
            path: '',
            size: '',
            hash: '',
            description: '',
            readableFileSize: '',
        }
    }
    loadCommonTypes() {
        let sexesPromise = this.commonService.getSexes();
        let nationalitiesPromise = this.commonService.getNationalities();
        let countriesPromise = this.commonService.getCountries();
        let licenceTiersPromise = this.commonService.getTaLicenceTiers();
        let applicationModesPromise = this.commonService.getTaApprovalTypes();
        let principleActivitiesPromise = this.commonService.getPrincipleActivities();
        let premiseTypesPromise = this.commonService.getPremiseTypes();
        let businessServicesPromise = this.commonService.getTaServices();
        let focusAreasPromise = this.commonService.getTaFocusAreas();
        let establishmentStatusPromise = this.commonService.getEstablishmentStatus();
        let taSegmentationPromise = this.commonService.getTaSegmentations();
        let stakeholderRolesPromise = this.commonService.getStakeholderRoles();
        let qualificationsPromise = this.commonService.getQualifications();
        let formOfBusinessPromise = this.commonService.getFormOfBusiness();
        let occupationPromise = this.commonService.getOccupations();
        let addressTypePromise = this.commonService.getAddressTypes();
        let businessConstitutionPromise = this.commonService.getBusinessConstitution();
        let appFeeAmountPromise = this.commonService.getSystemParameter("TA_LIC_APPLICATION_FEE");
        let licenceFeeAmountPromise = this.commonService.getSystemParameter("TA_LICENCE_FEE");

        forkJoin(sexesPromise,
            nationalitiesPromise,
            countriesPromise,
            licenceTiersPromise,
            applicationModesPromise,
            principleActivitiesPromise,
            premiseTypesPromise,
            businessServicesPromise,
            establishmentStatusPromise,
            focusAreasPromise,
            taSegmentationPromise,
            stakeholderRolesPromise,
            qualificationsPromise,
            formOfBusinessPromise,
            occupationPromise,
            addressTypePromise,
            businessConstitutionPromise,
            appFeeAmountPromise,
            licenceFeeAmountPromise).subscribe(([sexes, nationalities, countries, licenceTiers, applicationModes, principleActivities, premiseTypes, businessServices, establishmentStatus, focusAreas, taSegmentation, stakeholderRoles, qualifications, formOfBusiness, occupations, addressTypes, businessConstitution, appFeeAmount, licenceFeeAmount]) => {
                this.sexes = sexes;
                this.nationalities = nationalities;
                this.countries = countries;
                this.licence_tiers = licenceTiers;
                this.application_modes = applicationModes;
                this.principle_activities = principleActivities;
                this.premises_types = premiseTypes;
                this.business_services = businessServices;
                this.establishment_status = establishmentStatus;
                this.area_of_focus = focusAreas;
                this.ta_segmentation = taSegmentation;
                this.stakeholder_roles = stakeholderRoles;
                this.qualifications = qualifications;
                this.form_of_business = formOfBusiness;
                this.occupations = occupations;
                this.address_types = addressTypes;
                this.business_constitution = businessConstitution;
                this.appFeeAmount = appFeeAmount.label;
                this.licenceFeeAmount = licenceFeeAmount.label;
            });

    }

    changeValue(form: FormGroup) {
        Object.keys(form.controls).forEach(key => {
            form.get(key).markAsDirty();
        });
    }

    personnelUinRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (form != null) {
                let obj = {};
                if (form.get('particulars').get('isCompany').value == false && !form.get('particulars').get('uin').value) {
                    obj = { ...obj, uinRequired: true };
                }
                if (form.get('particulars').get('isCompany').value == false && !form.get('particulars').get('nationality').get('key').value) {
                    obj = { ...obj, nationalityRequired: true };
                }
                if (form.get('particulars').get('isCompany').value == false && !form.get('particulars').get('sex').get('key').value) {
                    obj = { ...obj, sexRequired: true };
                }
                return obj;
            } else {
                return null;
            }
        }
    }

    personnelUenRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (form != null) {
                let obj = {};
                if (form.get('particulars').get('isCompany').value == true && !form.get('particulars').get('companyUen').value) {
                    obj = { ...obj, uenRequired: true };
                }
                if (form.get('particulars').get('isCompany').value == true && !form.get('particulars').get('companyIncorporatedDate').value) {
                    obj = { ...obj, incorporatedDateRequired: true };
                }
                return obj;
            } else {
                return null;
            }
        }
    }

    sharesheldRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return (form.get('involvement').get('role').get('key').value == cnst.StakeholderRoles.STKHLD_SHAREHOLDER && (!form.get('involvement').get('sharesHeld').value && form.get('involvement').get('sharesHeld').value != 0) ? { sharesHeldRequired: true } : null);
        }
    }
    anotherKeRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {

            let obj = {};
            if (this.appointingOtherKe == true && !this.formKe.get('appointedKeUin').value) {
                obj = { ...obj, anotherKeUinRequired: true };
            }
            if (this.appointingOtherKe == true && !this.formKe.get('appointedKeName').value) {
                obj = { ...obj, anotherKeNameRequired: true };
            }
            if (this.appointingOtherKe == true && !this.formKe.get('appointedKeEmail').value) {
                obj = { ...obj, anotherKeEmailRequired: true };
            }
            return obj;
        }

    }
    declarationRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (form != null) {
                let obj = {};
                if (form.get('isOptionRequired').value == true && !form.get('selectedOption').value) {
                    obj = { ...obj, optionRequired: true };
                }
                if (form.get('isOptionRequired').value == true && form.get('optionsToPrompt').value == form.get('selectedOption').value && !form.get('remarks').value) {
                    obj = { ...obj, remarksRequired: true };
                }
                return obj;
            } else {
                return null;
            }
        }
    }

    bankStatementRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return (DateUtil.getNow().diff(DateUtil.parseDate(this.formBusinessEntity.get('registrationDate').value), 'months') > 18 && !this.formDocuments.get('bankStatement').get('originalName').value ? { bankStatementRequired: true } : null);
        }
    }

    afaDocRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return (DateUtil.getNow().diff(DateUtil.parseDate(this.formBusinessEntity.get('registrationDate').value), 'months') > 18 && !this.formDocuments.get('afa').get('originalName').value ? { afaDocRequired: true } : null);
        }
    }

    hosDocRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.formBusinessEntity && this.formDocuments) {
                return (this.formBusinessEntity.get('operatingAddress').get('premisesType').get('key').value == cnst.PremisesTypes.PREM_HO && !this.formDocuments.get('hosApproval').get('originalName').value ? { hosDocRequired: true } : null);
            } else {
                return null;
            }
        }
    }

    keNricRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return ((this.formKe.get('isKeMyInfo').value == false && this.formDocuments && !this.formDocuments.get('keNric').get('originalName').value) ? { keNricRequired: true } : null);
        }
    }

    tenancyDocRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.formBusinessEntity && this.formDocuments) {
                return ((this.action == 'ipa' || this.formBusinessEntity.get('operatingAddress').get('postal').value) && !this.formDocuments.get('tenancyAgreement').get('originalName').value ? { tenancyDocRequired: true } : null);
            } else {
                return null;
            }
        }
    }

    listenTenancyDocRequiredValidator() {
        this.formBusinessEntity.get('operatingAddress').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (postal) {
                    this.formDocuments.get('tenancyAgreement').get('originalName').setValidators([Validators.required,]);
                } else {
                    this.formDocuments.get('tenancyAgreement').get('originalName').clearValidators();
                }
                this.formDocuments.get('tenancyAgreement').get('originalName').updateValueAndValidity();
            });

        this.formBusinessEntity.get('operatingAddress').get('premisesType').get('key').valueChanges.subscribe(
            (key: any) => {
                if (key == cnst.PremisesTypes.PREM_HO) {
                    this.formDocuments.get('hosApproval').get('originalName').setValidators([Validators.required,]);
                } else {
                    this.formDocuments.get('hosApproval').get('originalName').clearValidators();
                }
                this.formDocuments.get('hosApproval').get('originalName').updateValueAndValidity();
            });
    }

    listenAcraDocRequiredValidator() {
        this.formBusinessEntity.get('isEdhPopulated').valueChanges.subscribe(
            (isEdhPopulated: any) => {
                if (!isEdhPopulated) {
                    this.formDocuments.get('acra').get('originalName').setValidators([Validators.required]);
                } else {
                    this.formDocuments.get('acra').get('originalName').clearValidators();
                }
                this.formDocuments.get('acra').get('originalName').updateValueAndValidity();
            });

    }


    cbsDocRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            return ((this.formBusinessEntity.get('businessConstitution').get('key').value == cnst.BusinessConstitution.BC_SOLE || this.formBusinessEntity.get('formOfBusiness').get('key').value == cnst.BusinessConstitution.BC_PARTNERS) && !this.formDocuments.get('cbs').get('originalName').value ? { cbsDocRequired: true } : null);
        }
    }

    oppAddRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.formBusinessEntity) {
                let obj = {};
                if ((this.action == 'ipa' || this.formBusinessEntity.get('operatingAddress').get('street').value || this.formBusinessEntity.get('operatingAddress').get('block').value) && !this.formBusinessEntity.get('operatingAddress').get('postal').value) {
                    obj = { ...obj, opAddPostalRequired: true };
                }
                if ((this.action == 'ipa' || this.formBusinessEntity.get('operatingAddress').get('postal').value) && !this.formBusinessEntity.get('operatingAddress').get('street').value) {
                    obj = { ...obj, opAddStreetRequired: true };
                }
                if ((this.action == 'ipa' || this.formBusinessEntity.get('operatingAddress').get('postal').value) && !this.formBusinessEntity.get('operatingAddress').get('block').value) {
                    obj = { ...obj, opAddBlockRequired: true };
                }
                if ((this.action == 'ipa' || this.formBusinessEntity.get('operatingAddress').get('postal').value) && !this.formBusinessEntity.get('operatingAddress').get('premisesType').get('key').value) {
                    obj = { ...obj, opAddPremisesRequired: true };
                }
                return obj;
            } else {
                return null;
            }

        }
    }

    keAddRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.formKe) {
                let obj = {};
                if (this.formKe.get('taKeyExecutive').get('particulars').get('address').get('type').get('key').value == cnst.AddressTypes.ADDR_LOCAL) {
                    if (!this.formKe.get('taKeyExecutive').get('particulars').get('address').get('postal').value) {
                        obj = { ...obj, keAddPostalRequired: true };
                    }
                    if (!this.formKe.get('taKeyExecutive').get('particulars').get('address').get('block').value) {
                        obj = { ...obj, keAddBlockRequired: true };
                    }
                    if (!this.formKe.get('taKeyExecutive').get('particulars').get('address').get('street').value) {
                        obj = { ...obj, keAddStreetRequired: true };
                    }
                } else if (this.formKe.get('taKeyExecutive').get('particulars').get('address').get('type').get('key').value == cnst.AddressTypes.ADDR_FOREIGN) {
                    if (!this.formKe.get('taKeyExecutive').get('particulars').get('address').get('foreignLine1').value) {
                        obj = { ...obj, keAddForeignLine1Required: true };
                    }
                }
                return obj;
            } else {
                return null;
            }

        }
    }

    shAddRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (form) {
                let obj = {};
                if (form.get('particulars').get('address').get('type').get('key').value == cnst.AddressTypes.ADDR_LOCAL) {
                    if (!form.get('particulars').get('address').get('postal').value) {
                        obj = { ...obj, shAddPostalRequired: true };
                    }
                    if (!form.get('particulars').get('address').get('block').value) {
                        obj = { ...obj, shAddBlockRequired: true };
                    }
                    if (!form.get('particulars').get('address').get('street').value) {
                        obj = { ...obj, shAddStreetRequired: true };
                    }
                } else if (form.get('particulars').get('address').get('type').get('key').value == cnst.AddressTypes.ADDR_FOREIGN) {
                    if (!form.get('particulars').get('address').get('foreignLine1').value) {
                        obj = { ...obj, shAddForeignLine1Required: true };
                    }
                }
                return obj;
            } else {
                return null;
            }

        }
    }

    regAddRequiredValidator() {
        return (form: FormGroup): { [key: string]: any } => {
            if (this.formBusinessEntity) {
                let obj = {};
                if (this.formBusinessEntity.get('registeredAddress').get('type').get('key').value == cnst.AddressTypes.ADDR_LOCAL) {
                    if (!this.formBusinessEntity.get('registeredAddress').get('postal').value) {
                        obj = { ...obj, regAddPostalRequired: true };
                    }
                    if (!this.formBusinessEntity.get('registeredAddress').get('block').value) {
                        obj = { ...obj, regAddBlockRequired: true };
                    }
                    if (!this.formBusinessEntity.get('registeredAddress').get('street').value) {
                        obj = { ...obj, regAddStreetRequired: true };
                    }
                } else if (this.formBusinessEntity.get('registeredAddress').get('type').get('key').value == cnst.AddressTypes.ADDR_FOREIGN) {
                    if (!this.formBusinessEntity.get('registeredAddress').get('foreignLine1').value) {
                        obj = { ...obj, regAddForeignLine1Required: true };
                    }
                }
                return obj;
            } else {
                return null;
            }

        }
    }


    matchingTotalInboundOutboundValidator(inboundKey: string, outboundKey: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let inbound = group.controls[inboundKey];
            let outbound = group.controls[outboundKey];
            if (parseInt(inbound.value, 10) + parseInt(outbound.value, 10) != 100) {
                return {
                    'mismatchedPercentage': true
                };
            }
            return null;
        }
    }

    initMarketSpecialise() {
        return this.formBuilder.group({
            country: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            percentage: [0, Validators.compose([Validators.required, Validators.min(0), Validators.max(100),])]
        })
    }

    addMarketSpecialise(form: FormArray) {
        form.push(this.initMarketSpecialise());
    }

    deleteRow(i: number, form: FormArray) {
        form.removeAt(i);
    }

    initBusinessItemRows() {
        return this.formBuilder.group({
            service: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            inboundPercent: [0, Validators.compose([Validators.required, Validators.min(0), Validators.max(100),])],
            outboundPercent: [0, Validators.compose([Validators.required, Validators.min(0), Validators.max(100),])],
        },
            {
                validator: Validators.compose([
                    this.taFormHelperUtil.bothZeroValuesValidator('inboundPercent', 'outboundPercent', 'zeroValues'),
                ]
                )

            })
    };

    addBusinessOperation() {
        this.taBusinessOperations.push(this.initBusinessItemRows());
    }

    initAreaOfFocus() {
        return this.formBuilder.group({
            focusArea: this.formBuilder.group({
                key: ['', Validators.required],
                label: ['']
            }),
            hasInboundOp: [false, Validators.required],
            hasOutboundOp: [false, Validators.required],
        }, {
            validator: this.taFormHelperUtil.matchingMissingBothCheckBoxValidator(this.formAbpr.controls.inboundOpPercent, this.formAbpr.controls.outboundOpPercent, "hasInboundOp", "hasOutboundOp", "mismatchedMissingBothCheckbox"),

        })
    }

    addAreaOfFocus() {
        this.taFocusAreas.push(this.initAreaOfFocus());
    }

    addPersonnel() {
        let x = this.addPersonnelDtoFormControl();
        this.editPersonnelDialog(x, false, 'new');
    }
    deletePersonnel(index: number) {
        this.taStakeholders.removeAt(index);
    }

    editPersonnelDialog(obj, showErrorMsg, type): void {
        let dialog = this.dialog.open(DialogPersonnel, {
            data: { type: type, showErrorMsg: showErrorMsg, fromEdh: this.formBusinessEntity.get('isEdhPopulated').value, stakeholder: obj, sexes: this.sexes, nationalities: this.nationalities, stakeholder_roles: this.stakeholder_roles, premises_types: this.premises_types, address_types: this.address_types },
            width: '1200px',
            disableClose: true
        });
        dialog.afterClosed().subscribe(result => {
            if (type == 'new') {
                if (result.decision) {
                    this.taStakeholders.push(result.obj);
                }
            }
            for (let p of this.taStakeholders.controls) {

                if ((obj.get('particulars').get('uin').value && p.get('particulars').get('uin').value == obj.get('particulars').get('uin').value) || (obj.get('particulars').get('companyUen').value && p.get('particulars').get('companyUen').value == obj.get('particulars').get('companyUen').value)) {
                    p.get('particulars').get('contactNo').setValue(obj.get('particulars').get('contactNo').value);
                    p.get('particulars').get('email').setValue(obj.get('particulars').get('email').value);
                    p.get('particulars').get('nationality').get('key').setValue(obj.get('particulars').get('nationality').get('key').value);
                    p.get('particulars').get('sex').get('key').setValue(obj.get('particulars').get('sex').get('key').value);
                }
            }
        });
    }

    formControlValueChanged() {
        this.formAbpr.get('inboundOpPercent').valueChanges.subscribe(
            (data: any) => {
                this.taFocusAreas.controls.forEach(element => {
                    this.formUtil.validateAllFormControl(element as FormGroup);
                });
            });
        this.formAbpr.get('outboundOpPercent').valueChanges.subscribe(
            (data: any) => {
                this.taFocusAreas.controls.forEach(element => {
                    this.formUtil.validateAllFormControl(element as FormGroup);
                });
            });
        this.formBusinessEntity.get('operatingAddress').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (this.formBusinessEntity.get('isOppAddSameAsRegAdd').value == false) {
                    if (postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                        this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                            if (data) {
                                var addrResults = data['results'];

                                if (addrResults.length > 0) {
                                    var blkNo = addrResults[0]['BLK_NO'].trim();
                                    var roadName = addrResults[0]['ROAD_NAME'].trim();
                                    var building = addrResults[0]['BUILDING'].trim();

                                    this.formBusinessEntity.get('operatingAddress').get('block').setValue(blkNo);
                                    this.formBusinessEntity.get('operatingAddress').get('street').setValue(roadName);
                                    this.formBusinessEntity.get('operatingAddress').get('building').setValue(building);
                                }
                            }
                        });
                    }
                }

            });

        this.formBusinessEntity.get('registeredAddress').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (this.formBusinessEntity.get('isEdhPopulated').value == false) {
                    if (postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                        this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                            if (data) {
                                var addrResults = data['results'];

                                if (addrResults.length > 0) {
                                    var blkNo = addrResults[0]['BLK_NO'].trim();
                                    var roadName = addrResults[0]['ROAD_NAME'].trim();
                                    var building = addrResults[0]['BUILDING'].trim();

                                    this.formBusinessEntity.get('registeredAddress').get('block').setValue(blkNo);
                                    this.formBusinessEntity.get('registeredAddress').get('street').setValue(roadName);
                                    this.formBusinessEntity.get('registeredAddress').get('building').setValue(building);


                                }
                            }
                        });
                    }
                }

            });

        this.formKe.get('taKeyExecutive').get('particulars').get('address').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (this.formKe.get('isKeMyInfo').value == false) {
                    if (postal && postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                        this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                            if (data) {
                                var addrResults = data['results'];

                                if (addrResults.length > 0) {
                                    var blkNo = addrResults[0]['BLK_NO'].trim();
                                    var roadName = addrResults[0]['ROAD_NAME'].trim();
                                    var building = addrResults[0]['BUILDING'].trim();

                                    this.formKe.get('taKeyExecutive').get('particulars').get('address').get('block').setValue(blkNo);
                                    this.formKe.get('taKeyExecutive').get('particulars').get('address').get('street').setValue(roadName);
                                    this.formKe.get('taKeyExecutive').get('particulars').get('address').get('building').setValue(building);


                                }
                            }
                        });
                    }
                }

            });

        this.formBusinessEntity.get('isOppAddSameAsRegAdd').valueChanges.subscribe(
            (isSame: any) => {
                if (isSame == true) {
                    this.formBusinessEntity.get('operatingAddress').patchValue(this.formBusinessEntity.getRawValue().registeredAddress);
                }

            });
        this.formBusinessEntity.get('registeredAddress').valueChanges.subscribe(
            (address: any) => {
                if (this.formBusinessEntity.get('isOppAddSameAsRegAdd').value) {
                    if (this.formBusinessEntity.get('registeredAddress').get('type').get('key').value == cnst.AddressTypes.ADDR_LOCAL) {
                        this.formBusinessEntity.get('operatingAddress').patchValue(this.formBusinessEntity.getRawValue().registeredAddress);
                    } else {
                        this.formBusinessEntity.get('isOppAddSameAsRegAdd').setValue(false);
                    }
                }

            });



        this.bizWriteUpQns.get('hasOtherBizActivities').valueChanges.subscribe(
            (value: any) => {
                this.updatePercentFocusOnTaBizValidtor(value);
            });


        this.bizWriteUpQns.get('hasTaLicBefore').valueChanges.subscribe(
            (value: any) => {
                this.updateDetailsRegardingPrevLic(value);
            });

        this.bizWriteUpQns.get('salesChannelDtos').valueChanges.subscribe(
            (value: any) => {
                const selectedSalesCh = value
                    .map((v, i) => v ? this.salesChannels[i].key : null)
                    .filter(v => v !== null);
                this.bizWriteUpQns.get('salesChannelSelected').patchValue(selectedSalesCh);
            });

    }

    updatePercentFocusOnTaBizValidtor(value) {
        if (value) {
            this.bizWriteUpQns.get('percentFocusOnTaBiz').enable();
            this.bizWriteUpQns.get('percentFocusOnTaBiz').setValidators([Validators.min(0), Validators.max(100), Validators.required]);
        } else {
            this.bizWriteUpQns.get('percentFocusOnTaBiz').patchValue('');
            this.bizWriteUpQns.get('percentFocusOnTaBiz').disable();
            this.bizWriteUpQns.get('percentFocusOnTaBiz').setValidators(null);
        }
        this.bizWriteUpQns.get('percentFocusOnTaBiz').updateValueAndValidity();
    }

    updateDetailsRegardingPrevLic(value) {
        if (value) {
            this.bizWriteUpQns.get('detailsRegardingPrevLic').enable();
            this.bizWriteUpQns.get('detailsRegardingPrevLic').setValidators([Validators.maxLength(65535), Validators.required]);
        } else {
            this.bizWriteUpQns.get('detailsRegardingPrevLic').patchValue('');
            this.bizWriteUpQns.get('detailsRegardingPrevLic').disable();
            this.bizWriteUpQns.get('detailsRegardingPrevLic').setValidators(null);
        }
        this.bizWriteUpQns.get('detailsRegardingPrevLic').updateValueAndValidity();
    }

    onFileChanged(event, type) {
        this.selectedFile = event.target.files[0];
        if (this.selectedFile) {
            if (!this.fileUtil.exceedMaxSize(this.selectedFile)) {
                this.fileUtil.upload(type, this.selectedFile).subscribe(data => {
                    if (type == cnst.DocumentTypes.TA_DOC_KE_NRIC) {
                        this.formDocuments.patchValue({ keNric: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_KE_RESUME) {
                        this.formDocuments.patchValue({ keResume: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_KE_DIR_RESOLUTION) {
                        this.formDocuments.patchValue({ keResolution: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_BEOC) {
                        this.formDocuments.patchValue({ beoc: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_BANK) {
                        this.formDocuments.patchValue({ bankStatement: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_TENANCY) {
                        this.formDocuments.patchValue({ tenancyAgreement: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_HOS_APPROVAL) {
                        this.formDocuments.patchValue({ hosApproval: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_CBS) {
                        this.formDocuments.patchValue({ cbs: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_MGMT_ACC) {
                        this.formDocuments.patchValue({ afa: data });
                    } else if (type == cnst.DocumentTypes.TA_DOC_ACRA_BIZ) {
                        this.formDocuments.patchValue({ acra: data });
                    } else {
                        const fileDto = this.addFileDtoFormControl();
                        fileDto.patchValue(data);
                        this.otherDocuments.push(fileDto);
                    }
                });
            }
        }

        event.target.value = '';
    }

    removeFile(obj, type, doc) {
        if (type == cnst.DocumentTypes.TA_DOC_KE_NRIC) {
            this.formDocuments.patchValue({ keNric: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_KE_RESUME) {
            this.formDocuments.patchValue({ keResume: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_KE_DIR_RESOLUTION) {
            this.formDocuments.patchValue({ keResolution: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_BEOC) {
            this.formDocuments.patchValue({ beoc: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_BANK) {
            this.formDocuments.patchValue({ bankStatement: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_TENANCY) {
            this.formDocuments.patchValue({ tenancyAgreement: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_HOS_APPROVAL) {
            this.formDocuments.patchValue({ hosApproval: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_CBS) {
            this.formDocuments.patchValue({ cbs: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_MGMT_ACC) {
            this.formDocuments.patchValue({ afa: this.addFileDto() });
        } else if (type == cnst.DocumentTypes.TA_DOC_ACRA_BIZ) {
            this.formDocuments.patchValue({ acra: this.addFileDto() });
        } else {
            this.otherDocuments.removeAt(obj);
        }
        if (doc.publicFileId) {
            this.publicDeletedFiles.push(doc.publicFileId);
        }

    }

    previewFirstPayment() {
        this.alertService.clear();
        this.formAppParticulars.markAsTouched();
        this.formUtil.markFormGroupTouched(this.formAppParticulars);
        this.formBusinessEntity.markAsTouched();
        this.formUtil.markFormGroupTouched(this.formBusinessEntity);
        this.formAbpr.markAsTouched();
        this.formUtil.markFormGroupTouched(this.formAbpr);
        this.bizWriteUpQns.markAsTouched();
        this.formUtil.markFormGroupTouched(this.bizWriteUpQns);
        this.formPersonnel.markAsTouched();
        this.formUtil.markFormGroupTouched(this.formPersonnel);
        this.formDocuments.markAsTouched();
        this.formUtil.markFormGroupTouched(this.formDocuments);
        this.formKe.markAsTouched();
        this.formUtil.markFormGroupTouched(this.formKe);
        console.log(this.formAbpr);

        if ((this.formAppParticulars.invalid || this.formBusinessEntity.invalid || this.formAbpr.invalid || this.bizWriteUpQns.invalid || this.formPersonnel.invalid || this.formDocuments.invalid || this.formKe.invalid || !this.checkKeDeclarationValid())) {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
            if (this.formAppParticulars.invalid) {
                this.stepper.selectedIndex = 0;
            } else if (this.formBusinessEntity.invalid) {
                this.stepper.selectedIndex = 1;
            } else if (this.formAbpr.invalid || this.bizWriteUpQns.invalid) {
                this.stepper.selectedIndex = 2;
            } else if (this.formPersonnel.invalid) {
                this.stepper.selectedIndex = 3;
                this.alertService.error("It is mandatory to add the Shareholders/Directors of the company.");
            } else if (this.formDocuments.invalid) {
                this.stepper.selectedIndex = 4;
            } else if (this.formKe.invalid) {
                this.stepper.selectedIndex = 5;
            } else if (!this.checkKeDeclarationValid()) {
                this.stepper.selectedIndex = 5;
                this.alertService.error("KE Declaration must be made by the KE");
            }

        } else {
            window.scrollTo(0, 0);
            this.firstPaymentPreview = true;
        }
    }

    previewSecondPayment() {
        this.secondPaymentPreview = true;
        window.scrollTo(0, 0);
    }

    checkKeDeclarationValid() {
        var valid = false;
        this.formKe.get('taKeyExecutive').get('involvement').get('taKeDeclarations').enable();
        if (!this.formKe.invalid) {
            valid = true;
        }
        this.formKe.get('taKeyExecutive').get('involvement').get('taKeDeclarations').disable();
        return valid;
    }

    submit(isDraft: boolean) {
        this.alertService.clear();
        console.log("isDraft: ", isDraft);

        if (!this.formAbpr.get("taBusinessWriteUp").value && !this.formAbpr.get("currentBusinessWriteUp").value) {
            this.formAbpr.get('taBusinessWriteUp').setValidators(null);
            this.formAbpr.get('taBusinessWriteUp').updateValueAndValidity();
        } else {
            this.disableBizWriteUpForm();
        }



        if (!isDraft && (this.formAppParticulars.invalid || this.formBusinessEntity.invalid || this.formAbpr.invalid || this.bizWriteUpQns.invalid || this.formPersonnel.invalid || this.formDocuments.invalid || this.formKe.invalid || !this.checkKeDeclarationValid())) {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
            if (this.formAppParticulars.invalid) {
                this.stepper.selectedIndex = 0;
            } else if (this.formBusinessEntity.invalid) {
                this.stepper.selectedIndex = 1;
            } else if (this.formAbpr.invalid || this.bizWriteUpQns.invalid) {
                this.stepper.selectedIndex = 2;
            } else if (this.formPersonnel.invalid) {
                this.stepper.selectedIndex = 3;
                this.alertService.error("It is mandatory to add the Shareholders/Directors of the company.");
            } else if (this.formDocuments.invalid) {
                this.stepper.selectedIndex = 4;
            } else if (this.formKe.invalid) {
                this.stepper.selectedIndex = 5;
            } else if (!this.checkKeDeclarationValid()) {
                this.stepper.selectedIndex = 5;
                this.alertService.error("KE Declaration must be made by the KE");
            }
            this.firstPaymentPreview = false;

        } else {

            let form = { isDraft: isDraft, ... this.formAppParticulars.getRawValue(), ...this.formBusinessEntity.getRawValue(), ...this.formAbpr.getRawValue(), ...this.formPersonnel.getRawValue(), ...this.formDocuments.getRawValue(), ...this.formKe.getRawValue(), ...this.bizWriteUpQns.getRawValue() };
            if (this.application.id != null) {
                form = { id: this.application.id, ...form };
            }
            if (isDraft || (!isDraft && (this.action == 'rfa' || this.action == 'ipa'))) {

                //TO VALIDATE ONLY MAX LENGTH and INVALIDEMAILFORMAT
                var errorCount = this.validateDraft();

                if (errorCount == 0) {
                    this.sanitize(form);
                    this.service.save(form, false).subscribe(data => {
                        this.ngOnInit();
                        window.scrollTo(0, 0);
                    });
                } else {
                    this.alertService.error(cnst.Messages.MSG_ERROR_DRAFT);
                }
            } else {

                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.appFeeAmount } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        let paymentType = result.type;
                        form.isDraft = true;
                        this.sanitize(form);
                        this.service.save(form, false).subscribe(data => {
                            let application = data;
                            this.markAllFormAsPristine();
                            if (application.appFee.billRefNo == null) {
                                let paymentReqDto = { refNo: application.id, payerUinUen: data.uen, description: 'TA Licence Application Fee', payableAmount: this.appFeeAmount, typeCode: cnst.PaymentRequestTypes.PAYREQ_TA_CREATION_A, userField2: application.emailAddress };
                                this.service.savePaymentRequest(paymentReqDto).subscribe(result => {
                                    let billRefNo = [];
                                    billRefNo.push(result);
                                    this.service.linkAppFee(application.id, billRefNo[0]).subscribe(data => {
                                        if (paymentType == cnst.PaymentTypes.PAYNOW) {
                                            this.generatePaynowQRCode(application.id, billRefNo[0], paymentType, this.appFeeAmount);
                                        } else {
                                            this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TACDD_RETURN, paymentType, billRefNo, '/portal/ta-application-success/' + application.id + '/' + billRefNo[0] + '/appFee');
                                        }
                                    });

                                });
                            } else {
                                let billRefNo = [];
                                billRefNo.push(application.appFee.billRefNo);
                                if (paymentType == cnst.PaymentTypes.PAYNOW) {
                                    this.generatePaynowQRCode(application.id, application.appFee.billRefNo, paymentType, this.appFeeAmount);
                                } else {
                                    this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TACDD_RETURN, paymentType, billRefNo, '/portal/ta-application-success/' + application.id + '/' + application.appFee.billRefNo + '/appFee');
                                }
                            }

                        });
                    }
                });
            }

        }


    }

    generatePaynowQRCode(id: any, billRefNo: any, paymentType: any, paymentFee: any) {
        this.paymentService.createPayNowTxn(paymentFee, billRefNo).subscribe(txn => {
            let payNowTxnId = txn;
            this.paymentService.generateQrCode(paymentFee, txn).subscribe(qrCode => {
                let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: paymentFee, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                dialog.afterClosed().subscribe(result => {
                    if (result.decision) {
                        this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TACDD_RETURN, paymentType, billRefNo, '/portal/ta-application-success/' + id + '/' + billRefNo + '/appFee', payNowTxnId);
                    }
                });
            });
        });
    }

    allowToSubmit() {
        this.alertService.clear();

        if (this.formAppParticulars.invalid || this.formBusinessEntity.invalid || this.formAbpr.invalid || this.bizWriteUpQns.invalid || this.formPersonnel.invalid || this.formDocuments.invalid || this.formKe.invalid || !this.checkKeDeclarationValid()) {
            this.alertService.error(cnst.Messages.MSG_INCOMPLETE_FORM);
            this.showErrorMsg = true;
            if (this.formAppParticulars.invalid) {
                this.stepper.selectedIndex = 0;
            } else if (this.formBusinessEntity.invalid) {
                this.stepper.selectedIndex = 1;
            } else if (this.formAbpr.invalid || this.bizWriteUpQns.invalid) {
                this.stepper.selectedIndex = 2;
            } else if (this.formPersonnel.invalid) {
                this.stepper.selectedIndex = 3;
                this.alertService.error("It is mandatory to add the Shareholders/Directors of the company.");
            } else if (this.formDocuments.invalid) {
                this.stepper.selectedIndex = 4;
            } else if (this.formKe.invalid) {
                this.stepper.selectedIndex = 5;
            } else if (!this.checkKeDeclarationValid) {
                this.stepper.selectedIndex = 5;
                this.alertService.error("KE Declaration must be made by the KE");
            }

        } else if (!this.allowSubmit) {
            this.alertService.error("You are not allowed to make direct submission");
            return;
        } else {
            this.sanitize(this.application);
            this.service.submit(this.application).subscribe(data => {
                this.markAllFormAsPristine();
                this.router.navigate(['/portal/ta-application-success/' + data.id]);
            });
        }
    }

    sanitize(application) {
        application.taKeyExecutive.involvement.taKeDeclarations.forEach(declaration => {
            declaration.clause.label = '';
            declaration.subscript = '';

        });

    }

    secondPayment() {
        let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.licenceFeeAmount } });
        dialog.afterClosed().subscribe(result => {
            if (result.decision) {
                let paymentType = result.type;
                let billRefNo = [];
                billRefNo.push(this.application.licenceFee.billRefNo);
                if (paymentType == cnst.PaymentTypes.PAYNOW) {
                    this.paymentService.createPayNowTxn(this.licenceFeeAmount, billRefNo).subscribe(txn => {
                        let payNowTxnId = txn;
                        this.paymentService.generateQrCode(this.licenceFeeAmount, txn).subscribe(qrCode => {
                            let dialog = this.dialog.open(PaymentDialogComponent, { data: { amt: this.licenceFeeAmount, payNowTxnId: payNowTxnId, qrCode: qrCode, billRefNos: billRefNo } });
                            dialog.afterClosed().subscribe(result => {
                                if (result.decision) {
                                    this.paymentService.routeToPaymentSuccessPage(false, cnst.eNets.URL_TACDD_RETURN, paymentType, billRefNo, '/portal/ta-application-success/' + this.application.id + '/' + this.application.licenceFee.billRefNo + '/licenceFee', payNowTxnId);
                                }
                            });
                        });
                    });
                } else {
                    this.paymentService.initPaymentProcess(false, cnst.eNets.URL_TACDD_RETURN, paymentType, billRefNo, '/portal/ta-application-success/' + this.application.id + '/' + this.application.licenceFee.billRefNo + '/licenceFee');
                }
            }
        });
    }

    markAllFormAsPristine() {
        this.formAppParticulars.markAsPristine();
        this.formBusinessEntity.markAsPristine();
        this.formAbpr.markAsPristine();
        this.bizWriteUpQns.markAsPristine();
        this.formDocuments.markAsPristine();
        this.formKe.markAsPristine();
        this.formPersonnel.markAsPristine();

    }
    loadEdh() {
        this.isEdhError = false;
        forkJoin([
            this.edhService.getEdhEntity(),
            this.edhService.getEdhEntityAppointments(),
            this.edhService.getEdhEntityShareholders(),
            this.edhService.getEdhEntityFinancials(),
        ]).subscribe(data => {
            let stakeHolderData = [];
            this.taStakeholders.controls.forEach(record => {
                stakeHolderData.push({ uin: (record.get('particulars').get('uin').value ? record.get('particulars').get('uin').value : record.get('particulars').get('companyUen').value), contactNo: record.get('particulars').get('contactNo').value, email: record.get('particulars').get('email').value, nationality: record.get('particulars').get('nationality').get('key').value, sex: record.get('particulars').get('sex').get('key').value, role: record.get('involvement').get('role').get('key').value, appointedDate: record.get('involvement').get('appointedDate').value, companyIncorporatedDate: record.get('particulars').get('companyIncorporatedDate').value });
            })
            this.taStakeholders.controls = [];

            console.log('getEdhEntity():');
            if (data[0].errorMessage) {
                this.isEdhError = true;
            } else {
                if (data[0].basic) {
                    this.formBusinessEntity.get('companyName').setValue(data[0].basic.entityName);
                    this.formBusinessEntity.get('registrationDate').setValue(data[0].basic.registrationDate);
                    this.formBusinessEntity.get('establishmentStatus').get('key').setValue(data[0].basic.entityStatusCode);
                    this.formBusinessEntity.get('formOfBusiness').get('key').setValue(data[0].basic.entityType);
                    this.formBusinessEntity.get('businessConstitution').get('key').setValue(data[0].basic.businessConstitutionCode);
                    this.formBusinessEntity.get('principleActivities').get('key').setValue(data[0].basic.primaryActivityCode);
                    this.formBusinessEntity.get('secondaryPrincipleActivities').get('key').setValue(data[0].basic.secondaryActivityCode);

                }
                if (data[0].addresses) {
                    this.formBusinessEntity.get('registeredAddress').get('type').get('key').setValue(data[0].addresses[0].type);
                    if (data[0].addresses[0].type == cnst.AddressTypes.ADDR_LOCAL) {
                        this.formBusinessEntity.get('registeredAddress').get('postal').setValue(data[0].addresses[0].postalCode);
                        this.formBusinessEntity.get('registeredAddress').get('block').setValue(data[0].addresses[0].houseBlockNumber);
                        this.formBusinessEntity.get('registeredAddress').get('street').setValue(data[0].addresses[0].streetName);
                        this.formBusinessEntity.get('registeredAddress').get('building').setValue(data[0].addresses[0].buildingName);
                        this.formBusinessEntity.get('registeredAddress').get('floor').setValue(data[0].addresses[0].levelNumber);
                        this.formBusinessEntity.get('registeredAddress').get('unit').setValue(data[0].addresses[0].unitNumber);
                        this.formBusinessEntity.get('registeredAddress').get('foreignLine1').setValue(null);
                        this.formBusinessEntity.get('registeredAddress').get('foreignLine2').setValue(null);
                        this.formBusinessEntity.get('registeredAddress').get('foreignLine3').setValue(null);
                    } else {
                        this.formBusinessEntity.get('registeredAddress').get('foreignLine1').setValue(data[0].addresses[0].unformattedAddressLines[0]);
                        this.formBusinessEntity.get('registeredAddress').get('foreignLine2').setValue(data[0].addresses[0].unformattedAddressLines[1]);
                        this.formBusinessEntity.get('registeredAddress').get('foreignLine3').setValue('');
                        this.formBusinessEntity.get('registeredAddress').get('postal').setValue(null);
                        this.formBusinessEntity.get('registeredAddress').get('block').setValue(null);
                        this.formBusinessEntity.get('registeredAddress').get('street').setValue(null);
                        this.formBusinessEntity.get('registeredAddress').get('building').setValue(null);
                        this.formBusinessEntity.get('registeredAddress').get('floor').setValue(null);
                        this.formBusinessEntity.get('registeredAddress').get('unit').setValue(null);
                    }
                }
                console.log(data[0]);
            }

            if (!this.isEdhError) {
                console.log('getEdhEntityAppointments():');
                if (data[1].errorMessage) {
                    this.isEdhError = true;
                } else {
                    if (data[1].records) {
                        data[1].records.forEach(record => {
                            if (!record.withdrawalDate && record.positionHeld != 'STKHLD_AUD') {
                                let x = this.addPersonnelDtoFormControl();
                                if (record.appointedPerson) {
                                    x.get('particulars').get('isCompany').setValue(false);
                                    x.get('particulars').get('stakeholderName').setValue(record.appointedPerson.name);
                                    x.get('particulars').get('uin').setValue(record.appointedPerson.idNumber);

                                } else {
                                    x.get('particulars').get('isCompany').setValue(true);
                                    x.get('particulars').get('stakeholderName').setValue(record.appointedEntity.name);
                                    x.get('particulars').get('companyUen').setValue(record.appointedEntity.registrationNumber);
                                }
                                if (record.addressOfAppointed) {
                                    x.get('particulars').get('address').get('type').get('key').setValue(record.addressOfAppointed.type);
                                    if (record.addressOfAppointed.type == cnst.AddressTypes.ADDR_LOCAL) {
                                        x.get('particulars').get('address').get('postal').setValue(record.addressOfAppointed.postalCode);
                                        x.get('particulars').get('address').get('block').setValue(record.addressOfAppointed.houseBlockNumber);
                                        x.get('particulars').get('address').get('street').setValue(record.addressOfAppointed.streetName);
                                        x.get('particulars').get('address').get('building').setValue(record.addressOfAppointed.buildingName);
                                        x.get('particulars').get('address').get('floor').setValue(record.addressOfAppointed.levelNumber);
                                        x.get('particulars').get('address').get('unit').setValue(record.addressOfAppointed.unitNumber);
                                        x.get('particulars').get('address').get('foreignLine1').setValue(null);
                                        x.get('particulars').get('address').get('foreignLine2').setValue(null);
                                        x.get('particulars').get('address').get('foreignLine3').setValue(null);
                                    } else {
                                        x.get('particulars').get('address').get('foreignLine1').setValue(record.addressOfAppointed.unformattedAddressLines[0]);
                                        x.get('particulars').get('address').get('foreignLine2').setValue(record.addressOfAppointed.unformattedAddressLines[1]);
                                        x.get('particulars').get('address').get('foreignLine3').setValue(null);
                                        x.get('particulars').get('address').get('postal').setValue(null);
                                        x.get('particulars').get('address').get('block').setValue(null);
                                        x.get('particulars').get('address').get('street').setValue(null);
                                        x.get('particulars').get('address').get('building').setValue(null);
                                        x.get('particulars').get('address').get('floor').setValue(null);
                                        x.get('particulars').get('address').get('unit').setValue(null);
                                    }
                                } else {
                                    x.get('particulars').get('address').get('type').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
                                }

                                x.get('involvement').get('appointedDate').setValue(record.entryDate);
                                x.get('involvement').get('role').get('key').setValue(record.positionHeld);
                                if (stakeHolderData) {
                                    stakeHolderData.forEach(pastRecord => {
                                        if (x.get('particulars').get('isCompany').value) {
                                            if (pastRecord.uin == record.appointedEntity.registrationNumber && pastRecord.role == record.positionHeld) {
                                                x.get('particulars').get('contactNo').setValue(pastRecord.contactNo);
                                                x.get('particulars').get('email').setValue(pastRecord.email);
                                                x.get('particulars').get('companyIncorporatedDate').setValue(pastRecord.companyIncorporatedDate);
                                            }
                                        } else {
                                            if (pastRecord.uin == record.appointedPerson.idNumber && pastRecord.role == record.positionHeld) {
                                                x.get('particulars').get('contactNo').setValue(pastRecord.contactNo);
                                                x.get('particulars').get('email').setValue(pastRecord.email);
                                                x.get('particulars').get('nationality').get('key').setValue(pastRecord.nationality);
                                                x.get('particulars').get('sex').get('key').setValue(pastRecord.sex);
                                            }
                                        }
                                    });
                                }
                                this.taStakeholders.push(x);
                            }

                        });
                    }
                }
                console.log(data[1]);
            }

            if (!this.isEdhError) {
                console.log('getEdhEntityShareholders():');
                if (data[2].errorMessage) {
                    this.isEdhError = true;
                } else {
                    if (data[2].records) {
                        data[2].records.forEach(record => {
                            let x = this.addPersonnelDtoFormControl();
                            if (record.allotedPerson) {
                                x.get('particulars').get('isCompany').setValue(false);
                                x.get('particulars').get('stakeholderName').setValue(record.allotedPerson.name);
                                x.get('particulars').get('uin').setValue(record.allotedPerson.idNumber);
                            } else {
                                x.get('particulars').get('isCompany').setValue(true);
                                x.get('particulars').get('stakeholderName').setValue(record.allotedEntity.name);
                                x.get('particulars').get('companyUen').setValue(record.allotedEntity.registrationNumber);
                            }
                            if (record.addressOfAlloted) {
                                x.get('particulars').get('address').get('type').get('key').setValue(record.addressOfAlloted.type);
                                if (record.addressOfAlloted.type == cnst.AddressTypes.ADDR_LOCAL) {
                                    x.get('particulars').get('address').get('postal').setValue(record.addressOfAlloted.postalCode);
                                    x.get('particulars').get('address').get('block').setValue(record.addressOfAlloted.houseBlockNumber);
                                    x.get('particulars').get('address').get('street').setValue(record.addressOfAlloted.streetName);
                                    x.get('particulars').get('address').get('building').setValue(record.addressOfAlloted.buildingName);
                                    x.get('particulars').get('address').get('floor').setValue(record.addressOfAlloted.levelNumber);
                                    x.get('particulars').get('address').get('unit').setValue(record.addressOfAlloted.unitNumber);
                                    x.get('particulars').get('address').get('foreignLine1').setValue(null);
                                    x.get('particulars').get('address').get('foreignLine2').setValue(null);
                                    x.get('particulars').get('address').get('foreignLine3').setValue(null);
                                } else {
                                    x.get('particulars').get('address').get('foreignLine1').setValue(record.addressOfAlloted.unformattedAddressLines[0]);
                                    x.get('particulars').get('address').get('foreignLine2').setValue(record.addressOfAlloted.unformattedAddressLines[1]);
                                    x.get('particulars').get('address').get('foreignLine3').setValue(null);
                                    x.get('particulars').get('address').get('postal').setValue(null);
                                    x.get('particulars').get('address').get('block').setValue(null);
                                    x.get('particulars').get('address').get('street').setValue(null);
                                    x.get('particulars').get('address').get('building').setValue(null);
                                    x.get('particulars').get('address').get('floor').setValue(null);
                                    x.get('particulars').get('address').get('unit').setValue(null);
                                }
                            } else {
                                x.get('particulars').get('address').get('type').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
                            }

                            x.get('involvement').get('role').get('key').setValue(cnst.StakeholderRoles.STKHLD_SHAREHOLDER);
                            x.get('involvement').get('sharesHeld').setValue(record.allotedNumber);
                            if (stakeHolderData) {
                                stakeHolderData.forEach(pastRecord => {
                                    if (x.get('particulars').get('isCompany').value) {
                                        if (pastRecord.uin == record.allotedEntity.registrationNumber && pastRecord.role == cnst.StakeholderRoles.STKHLD_SHAREHOLDER) {
                                            x.get('particulars').get('contactNo').setValue(pastRecord.contactNo);
                                            x.get('particulars').get('email').setValue(pastRecord.email);
                                            x.get('involvement').get('appointedDate').setValue(pastRecord.appointedDate);
                                            x.get('particulars').get('companyIncorporatedDate').setValue(pastRecord.companyIncorporatedDate);
                                        }
                                    } else {
                                        if (pastRecord.uin == record.allotedPerson.idNumber && pastRecord.role == cnst.StakeholderRoles.STKHLD_SHAREHOLDER) {
                                            x.get('particulars').get('contactNo').setValue(pastRecord.contactNo);
                                            x.get('particulars').get('email').setValue(pastRecord.email);
                                            x.get('particulars').get('nationality').get('key').setValue(pastRecord.nationality);
                                            x.get('particulars').get('sex').get('key').setValue(pastRecord.sex);
                                            x.get('involvement').get('appointedDate').setValue(pastRecord.appointedDate);
                                        }
                                    }

                                });
                            }
                            this.taStakeholders.push(x);
                        });
                    }
                }
                console.log(data[2]);
            }


            if (!this.isEdhError) {
                console.log('getEdhEntityFinancials():');
                if (data[3].errorMessage) {
                    this.isEdhError = true;
                } else {
                    if (data[3].capitals[0]) {
                        this.formBusinessEntity.get('paidUpCapital').setValue(data[3].capitals[0].paidUpCapitalAmount ? data[3].capitals[0].paidUpCapitalAmount : 0);
                    } else {
                        this.formBusinessEntity.get('paidUpCapital').setValue(0);
                    }
                }
                console.log(data[3]);
            }


            if (this.isEdhError) {
                this.clearEdh();
                this.alertService.error(cnst.TaAlertMessages.EDH_ERROR);
            } else {
                this.formBusinessEntity.get('isEdhPopulated').setValue(true);
            }
        });
    }

    clearEdh() {
        this.taStakeholders.controls = [];
        this.formBusinessEntity.get('companyName').setValue(null);
        this.formBusinessEntity.get('registrationDate').setValue(null);
        this.formBusinessEntity.get('establishmentStatus').get('key').setValue(null);
        this.formBusinessEntity.get('businessConstitution').get('key').setValue(null);
        this.formBusinessEntity.get('formOfBusiness').get('key').setValue(null);
        this.formBusinessEntity.get('principleActivities').get('key').setValue(null);
        this.formBusinessEntity.get('secondaryPrincipleActivities').get('key').setValue(null);
        this.formBusinessEntity.get('paidUpCapital').setValue(null);
        this.formBusinessEntity.get('registeredAddress').get('postal').setValue(null);
        this.formBusinessEntity.get('registeredAddress').get('block').setValue(null);
        this.formBusinessEntity.get('registeredAddress').get('street').setValue(null);
        this.formBusinessEntity.get('registeredAddress').get('building').setValue(null);
        this.formBusinessEntity.get('registeredAddress').get('floor').setValue(null);
        this.formBusinessEntity.get('registeredAddress').get('unit').setValue(null);
        this.formBusinessEntity.get('isEdhPopulated').setValue(false);
    }

    loadAppMyInfo() {
        this.dialog.open(InformationDialogComponent, { data: { content: cnst.TaAlertMessages.COMING_SOON } });
        // this.myInfoService.getMyInfoPersonBasic().subscribe(data => {
        //     if (data.errorMessage) {
        //         this.alertService.clear();
        //         this.alertService.error(cnst.TaAlertMessages.MY_INFO_ERROR);
        //     } else {
        //         console.log(data);
        //         this.appMyInfoNonEditableFields = data.nonEditableFields;
        //         this.formAppParticulars.get('appName').setValue(data.name);
        //         this.formAppParticulars.get('appDob').setValue(data.dob);
        //         this.formAppParticulars.get('appSex').get('key').setValue(data.sex);
        //         this.formAppParticulars.get('appNationality').get('key').setValue(data.nationality);
        //         this.formAppParticulars.get('appDesignation').get('key').setValue(data.occupation);
        //         this.formAppParticulars.get('appMobileNo').setValue(data.mobileNo);
        //         this.formAppParticulars.get('appEmailAddress').setValue(data.email);
        //         this.formUtil.markFormGroupTouched(this.formAppParticulars);
        //         this.formAppParticulars.get('isAppMyInfo').setValue(true);
        //         this.formAppParticulars.get('isAppMyInfoClicked').setValue(true);
        //     }
        // });
    }

    clearAppMyInfo() {
        this.formAppParticulars.get('appName').setValue(null);
        this.formAppParticulars.get('appDob').setValue(null);
        this.formAppParticulars.get('appSex').get('key').setValue(null);
        this.formAppParticulars.get('appNationality').get('key').setValue(null);
        this.formAppParticulars.get('isAppMyInfo').setValue(false);
    }


    loadKeMyInfo() {
        this.dialog.open(InformationDialogComponent, { data: { content: cnst.TaAlertMessages.COMING_SOON } });
        // this.myInfoService.getMyInfoPersonBasic().subscribe(data => {
        //     if (data.errorMessage) {
        //         this.alertService.clear();
        //         this.alertService.error(cnst.TaAlertMessages.MY_INFO_ERROR);
        //     } else {
        //         console.log(data);
        //         this.keMyInfoNonEditableFields = data.nonEditableFields;
        //         this.formKe.get('taKeyExecutive').get('particulars').get('stakeholderName').setValue(data.name);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('dob').setValue(data.dob);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('sex').get('key').setValue(data.sex);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('nationality').get('key').setValue(data.nationality);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('designation').get('key').setValue(data.occupation);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('contactNo').setValue(data.mobileNo);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('email').setValue(data.email);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('highestEduLevel').get('key').setValue(data.eduLevel);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('address').get('postal').setValue(data.regAddPostal);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('address').get('block').setValue(data.regAddBlock);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('address').get('street').setValue(data.regAddStreet);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('address').get('building').setValue(data.regAddBuilding);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('address').get('floor').setValue(data.regAddFloor);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('address').get('unit').setValue(data.regAddUnit);
        //         this.formKe.get('taKeyExecutive').get('particulars').get('address').get('type').get('key').setValue(cnst.AddressTypes.ADDR_LOCAL);
        //         this.formKe.get('isKeMyInfo').setValue(true);
        //         this.formKe.get('isKeMyInfoClicked').setValue(true);
        //     }
        // });
    }

    disableBizWriteUpForm() {
        this.bizWriteUpQns = this.formBuilder.group({

            businessIdea: ['', [Validators.maxLength(65535)]],
            consumerFacingBrand: ['', Validators.maxLength(255)],
            mktgCommsPlan: ['', [Validators.maxLength(65535)]],
            salesChannelSelected: [],
            salesChannelDtos: new FormArray([]),
            otherSalesChannel: ['',],
            financialStrategy: ['', [Validators.maxLength(65535)]],
            revenueProj1: [0, Validators.compose([Validators.maxLength(19)])],
            revenueProj2: [0, Validators.compose([Validators.maxLength(19)])],
            costProj1: [0, Validators.compose([Validators.maxLength(19)])],
            costProj2: [0, Validators.compose([Validators.maxLength(19)])],
            profitLossProj1: [0, Validators.compose([Validators.maxLength(19)])],
            profitLossProj2: [0, Validators.compose([Validators.maxLength(19)])],
            estTimeToProfit: ['', Validators.maxLength(255)],
            competitiveEdge: ['', [Validators.maxLength(65535)]],
            partnerServideProviders: ['', [Validators.maxLength(65535)]],
            hasOtherBizActivities: [''],
            percentFocusOnTaBiz: [{ value: '', disabled: true }, Validators.compose([Validators.min(0), Validators.max(100)])],
            hasTaLicBefore: [''],
            detailsRegardingPrevLic: [{ value: '', disabled: true }, []],
            relationsWithOtherTa: ['', [Validators.maxLength(65535)]],
            others: ['', [Validators.maxLength(65535)]],
        }, {
            validator: Validators.compose(
                [
                ]
            )
        });
    }

    clearKeMyInfo() {
        this.formKe.get('taKeyExecutive').get('particulars').get('stakeholderName').setValue(null);
        this.formKe.get('taKeyExecutive').get('particulars').get('dob').setValue(null);
        this.formKe.get('taKeyExecutive').get('particulars').get('sex').get('key').setValue(null);
        this.formKe.get('taKeyExecutive').get('particulars').get('nationality').get('key').setValue(null);
        this.formKe.get('taKeyExecutive').get('particulars').get('designation').get('key').setValue(null);
        if (this.keMyInfoNonEditableFields.includes(cnst.MyInfoFields.REG_ADD_POSTAL)) {
            this.formKe.get('taKeyExecutive').get('particulars').get('address').get('postal').setValue(null);
            this.formKe.get('taKeyExecutive').get('particulars').get('address').get('block').setValue(null);
            this.formKe.get('taKeyExecutive').get('particulars').get('address').get('street').setValue(null);
            this.formKe.get('taKeyExecutive').get('particulars').get('address').get('building').setValue(null);
            this.formKe.get('taKeyExecutive').get('particulars').get('address').get('floor').setValue(null);
            this.formKe.get('taKeyExecutive').get('particulars').get('address').get('unit').setValue(null);
        }

        this.formKe.get('isKeMyInfo').setValue(false);
    }

    amTheKe() {
        this.formKe.get('taKeyExecutive').get('particulars').get('uin').setValue(this.application.loggedInUin);
        // this.loadKeMyInfo();
        this.keAppointed = true;
        this.appointingOtherKe = false;
        this.isLoggedInKe = true;
    }

    amNotTheKe() {
        this.formKe = this.formBuilder.group({
            appointedKeUin: ['', Validators.maxLength(255)],
            appointedKeName: ['', Validators.maxLength(255)],
            appointedKeEmail: ['', [Validators.maxLength(320), ValidateEmail]],
            taKeyExecutive: this.addKeDtoFormControl(),
            isKeMyInfo: [false],
            isKeMyInfoClicked: [false]
        }, { validator: [this.anotherKeRequiredValidator()] });
        if (this.application.taKeyExecutive.particulars) {
            this.formKe.get('taKeyExecutive').get('particulars').get('stakeholderId').setValue(this.application.taKeyExecutive.particulars.stakeholderId);
        }

        // put back the declarations section as reset() removes the declarations as well
        this.taKeDeclarations.controls = [];
        this.application.taKeyExecutive.involvement.taKeDeclarations.forEach(row => {
            this.taKeDeclarations.push(this.formBuilder.group({
                id: [row.id],
                prefix: [row.prefix],
                selectedOption: [''],
                options: [row.options],
                optionsToPrompt: [row.optionsToPrompt],
                prompt: [row.prompt],
                clause: this.formBuilder.group({
                    key: [row.clause.key],
                    label: [row.clause.label]
                }),
                subscript: [''],
                remarks: [''],
                isOptionRequired: [row.isOptionRequired],
                isRadioButton: [row.isRadioButton],
            }, { validator: [this.declarationRequiredValidator()] }));
        });

        this.appointingOtherKe = true;
        this.formControlValueChanged();
    }

    triggerKe() {
        if (this.formKe.hasError('anotherKeUinRequired') || this.formKe.hasError('anotherKeNameRequired') || this.formKe.hasError('anotherKeEmailRequired')) {
            this.showTriggerKeErrorMsg = true;
        } else {
            this.formKe.get('taKeyExecutive').get('particulars').get('uin').setValue(this.formKe.get('appointedKeUin').value);
            this.formKe.get('taKeyExecutive').get('particulars').get('stakeholderName').setValue(this.formKe.get('appointedKeName').value);
            this.formKe.get('taKeyExecutive').get('particulars').get('email').setValue(this.formKe.get('appointedKeEmail').value);
            let form = { isDraft: this.action == 'new' ? true : false, ... this.formAppParticulars.getRawValue(), ...this.formBusinessEntity.getRawValue(), ...this.formAbpr.getRawValue(), ...this.formPersonnel.getRawValue(), ...this.formDocuments.getRawValue(), ...this.formKe.getRawValue(), ...this.bizWriteUpQns.getRawValue() };
            if (this.application.id != null) {
                form = { id: this.application.id, ...form };
            }
            if (this.formBusinessEntity.get('isOppAddSameAsRegAdd').value == true) {
                this.formBusinessEntity.get('operatingAddress').patchValue(this.formBusinessEntity.get('registeredAddress'));
            }
            this.service.save(form, true).subscribe(data => {
                this.ngOnInit();
                this.alertService.success("KE successfully appointed. An email has been sent to the KE to access this application form and do the declaration.");
                this.appointingOtherKe = false;

            });
        }

    }

    @ViewChild(TaPastInfringementsListComponent) taPastInfringementsListComponent: TaPastInfringementsListComponent;
    hasInfringements(): boolean {
        return this.taPastInfringementsListComponent && this.taPastInfringementsListComponent.rows.data.length > 0
    }
    disableSubmit(): boolean {

        return !this.declared || (this.hasInfringements() && !this.declaredAckInfringements);
    }

    validateDraft() {
        let errorFoundList: number[] = [0];
        const formAppParticularsControls = this.formAppParticulars.controls;
        for (const name in formAppParticularsControls) {
            if (formAppParticularsControls[name].invalid) {
                const controlErrors: ValidationErrors = formAppParticularsControls[name].errors;
                if (controlErrors != null) {
                    Object.keys(controlErrors).forEach(keyError => {

                        if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                            errorFoundList[0]++;
                            return;
                        }
                    });
                }
            }
        }

        const formBusinessEntityControls = this.formBusinessEntity.controls;
        for (const name in formBusinessEntityControls) {
            if (name == 'operatingAddress') {
                const addressControls = formBusinessEntityControls[name]['controls'];

                for (const addressName in addressControls) {
                    const controlErrors: ValidationErrors = addressControls[addressName].errors;
                    if (controlErrors != null) {
                        Object.keys(controlErrors).forEach(keyError => {

                            if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                                errorFoundList[0]++;
                                return;
                            }
                        });
                    }
                }

            }
            else if (formBusinessEntityControls[name].invalid) {
                const controlErrors: ValidationErrors = formBusinessEntityControls[name].errors;
                if (controlErrors != null) {
                    Object.keys(controlErrors).forEach(keyError => {

                        if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                            errorFoundList[0]++;
                            return;
                        }
                    });
                }
            }
        }
        const controlErrorsTaBusinessWriteUp = this.formAbpr.get('taBusinessWriteUp');
        if (controlErrorsTaBusinessWriteUp.invalid) {
            const controlErrors: ValidationErrors = controlErrorsTaBusinessWriteUp.errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {

                    if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                        errorFoundList[0]++;
                        return;
                    }
                });
            }
        }
        const controlErrorsCurrentBusinessWriteUp = this.formAbpr.get('currentBusinessWriteUp');
        if (controlErrorsCurrentBusinessWriteUp.invalid) {
            const controlErrors: ValidationErrors = controlErrorsCurrentBusinessWriteUp.errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {

                    if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                        errorFoundList[0]++;
                        return;
                    }
                });
            }
        }

        const formAbprGroupControls = this.formAbpr.controls;
        for (const groupName in formAbprGroupControls) {
            const formAbprControls = formAbprGroupControls[groupName]['controls'];
            for (const name in formAbprControls) {
                if (formAbprControls[name].invalid) {
                    const controlErrors: ValidationErrors = formAbprControls[name].errors;
                    if (controlErrors != null) {
                        Object.keys(controlErrors).forEach(keyError => {

                            if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                                errorFoundList[0]++;
                                return;
                            }
                        });
                    }
                }
            }
        }

        const formPersonnelGroupControls = this.formPersonnel.get('taStakeholders')['controls'];
        for (const groupName in formPersonnelGroupControls) {
            const formPersonnelControls = formPersonnelGroupControls[groupName].get('particulars')['controls'];
            for (const name in formPersonnelControls) {

                if (formPersonnelControls[name].invalid) {
                    const controlErrors: ValidationErrors = formPersonnelControls[name].errors;
                    if (controlErrors != null) {
                        Object.keys(controlErrors).forEach(keyError => {

                            if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                                errorFoundList[0]++;
                                return;
                            }
                        });
                    }
                }
            }
        }

        const formKeParticularsControls = this.formKe.get('taKeyExecutive').get('particulars')['controls'];
        for (const name in formKeParticularsControls) {
            if (name == 'address') {
                const addressControls = this.formKe.get('taKeyExecutive').get('particulars').get('address')['controls'];

                for (const name in addressControls) {
                    const controlErrors: ValidationErrors = addressControls[name].errors;
                    if (controlErrors != null) {
                        Object.keys(controlErrors).forEach(keyError => {

                            if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                                errorFoundList[0]++;
                                return;
                            }
                        });
                    }
                }

            }
            else if (formKeParticularsControls[name].invalid) {
                const controlErrors: ValidationErrors = formKeParticularsControls[name].errors;
                if (controlErrors != null) {
                    Object.keys(controlErrors).forEach(keyError => {

                        if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                            errorFoundList[0]++;
                            return;
                        }
                    });
                }
            }
        }

        const formKeInvolvementControls = this.formKe.get('taKeyExecutive').get('involvement').get('taKeDeclarations')['controls'];
        for (const formName in formKeInvolvementControls) {

            const formKeInvolvementGroupControls = formKeInvolvementControls[formName]['controls'];

            for (const name in formKeInvolvementGroupControls) {

                if (formKeInvolvementGroupControls[name].invalid) {
                    const controlErrors: ValidationErrors = formKeInvolvementGroupControls[name].errors;
                    if (controlErrors != null) {
                        Object.keys(controlErrors).forEach(keyError => {

                            if (keyError == 'maxlength' || keyError == 'invalidEmailFormat') {
                                errorFoundList[0]++;
                                return;
                            }
                        });
                    }
                }
            }
        }

        return errorFoundList[0];

    }

    onKeyUp(event) {
        let name = event.target.value;
        if (name != undefined && name != null && name != '') {
            this.formBusinessEntity.get('companyName').setValue(name.toUpperCase());
        }
    }

}



@Component({
    selector: 'dialog-personnel',
    templateUrl: 'ta-personnel-dialog.html',
    styleUrls: ['./ta-application-form.component.scss']
})
export class DialogPersonnel implements OnInit {
    stakeholder: FormGroup;
    sexes: any;
    nationalities: any;
    stakeholder_roles: any;
    premises_types: any;
    address_types: any;
    fromEdh: boolean;
    showErrorMsg: boolean;
    type: any;
    cnst = cnst;

    constructor(
        public dialogRef: MatDialogRef<DialogPersonnel>, @Inject(MAT_DIALOG_DATA) public data: any, private formBuilder: FormBuilder, private commonService: CommonService, private formUtil: FormUtil) { }

    ngOnInit() {
        if (this.data.stakeholder) {
            this.stakeholder = this.data.stakeholder;
        }
        this.sexes = this.data.sexes;
        this.nationalities = this.data.nationalities;
        this.stakeholder_roles = this.data.stakeholder_roles;
        this.premises_types = this.data.premises_types;
        this.address_types = this.data.address_types;
        this.fromEdh = this.data.fromEdh;
        this.showErrorMsg = this.data.showErrorMsg;
        this.type = this.data.type;
        this.formControlValueChanged();
    }


    onNoClick(decision: boolean): void {

        this.dialogRef.close({ decision: decision, obj: this.stakeholder });
    }

    formControlValueChanged() {

        this.stakeholder.get('particulars').get('address').get('postal').valueChanges.subscribe(
            (postal: any) => {
                if (postal.length == 6 && !isNaN(parseInt(postal, 10))) {
                    this.commonService.getPostalCodeAddress(parseInt(postal, 10)).subscribe(data => {
                        if (data) {
                            var addrResults = data['results'];

                            if (addrResults.length > 0) {
                                var blkNo = addrResults[0]['BLK_NO'].trim();
                                var roadName = addrResults[0]['ROAD_NAME'].trim();
                                var building = addrResults[0]['BUILDING'].trim();

                                this.stakeholder.get('particulars').get('address').get('block').setValue(blkNo);
                                this.stakeholder.get('particulars').get('address').get('street').setValue(roadName);
                                this.stakeholder.get('particulars').get('address').get('building').setValue(building);


                            }
                        }
                    });
                }

            });
    }
}



