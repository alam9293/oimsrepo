import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ta-application-payment',
  templateUrl: './ta-application-payment.component.html',
  styleUrls: ['./ta-application-payment.component.scss']
})
export class TaApplicationPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
