export interface BranchDto {
    applicationBranchId: string;
    branchId: string;
    licenceNo: number;
    address: string;
    formatAddress: string,
    blk: string;
    street: string;
    buildingName: string;
    level: string;
    unit: string;
    postalCode: string;
    premisesType: string;
    tenancyStartDate: any;
    tenancyEndDate: any;
    supportingDocument: string;
    status: string;
    type: string;
    fee: string;
    toReplace: BranchDto;
    previousBranchesId: string[];
    previousBranches: string[];
    selectedFile: any;
    originalFileName: string;
    docFileType: string;
    statusLabel: string;
}

export class LocalConstants {
    public static BRANCH_NEW = 'New';
    public static BRANCH_UPDATE = 'Update';
    public static BRANCH_CEASE = 'Cease';
    public static BRANCH_CESSATION = 'Cessation';
    public static BRANCH_PROCESSING_NEW = 'Processing (New)';
    public static BRANCH_PROCESSING_UPDATE = 'Processing (Update)';
    public static BRANCH_PROCESSING_CESSATION = 'Processing (Cessation)';

    public static taBranchApplicationFeeNumber = 40;
    public static taBranchApplicationFeeLabel = 'S$' + LocalConstants.taBranchApplicationFeeNumber;
}


