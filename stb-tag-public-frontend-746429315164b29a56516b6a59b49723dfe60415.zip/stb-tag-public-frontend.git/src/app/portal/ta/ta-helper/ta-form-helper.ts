import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { FileUtil, FormUtil, } from '../../../common/helper';
import { NumeralUtil } from '../../../common/helper';
@Injectable({
    providedIn: 'root'
})
export class TaFormHelperUtil {

    constructor(private fileUtil: FileUtil) { }

    initiateFileForm(fb: FormBuilder, isRequired: any) {
        return (fb.group({
            id: [''],
            publicFileId: [''],
            originalName: ['', isRequired ? Validators.required : ''],
            processedName: [''],
            docType: [''],
            extension: [''],
            path: [''],
            size: [''],
            hash: [''],
            documentInstructions: [''],
            documentTypeLabel: [''],
            description: [''],
            readableFileSize: [''],
            hasTemplate: [],
        })
        )
    }

    initiateBranchForm(fb: FormBuilder) {
        return (fb.group({
            branchId: [''],
            address: [''],
            status: [''],
            statusLabel: [''],
            type: [''],
            ceasedDate: [''],
            ceasedReason: [''],
        })
        )
    }

    minLengthArray(min: number) {
        return (c: AbstractControl): { [key: string]: any } => {
            if (c.value.length >= min)
                return null;
            return { 'minLengthArray': { valid: false } };
        }
    }

    clearFileDetails(file) {
        file.get('id').patchValue('');
        file.get('originalName').patchValue('');
        file.get('processedName').patchValue('');
        file.get('publicFileId').patchValue('');
        file.get('path').patchValue('');
        file.get('readableFileSize').patchValue('');
        file.get('size').patchValue('');
    }

    duplicatedSelectionValidator(selected: string): ValidatorFn {
        return (control: FormArray): { [key: string]: any } => {
            const array = control.value;
            let servicesList = [];
            let sortedServicesList = [];
            if (array && array.length > 1) {
                for (var i = 0; i < (array.length); i++) {
                    if (array[i] && array[i][selected].key) {
                        servicesList.push(array[i][selected].key);
                    }
                }
                sortedServicesList = servicesList.slice().sort();
                for (var i = 0; i < sortedServicesList.length - 1; i++) {
                    if (sortedServicesList[i + 1] == sortedServicesList[i]) {
                        return { 'duplicatedSelectionError': true };
                    }
                }
            } else {
                return null;
            }
        }
    }

    missingSelectionValidator(operationAmount: string, selection: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let option = group.controls[selection];
            let opAmount = group.controls[operationAmount];
            if (opAmount) {
                if ((parseInt(opAmount.value, 10) > 0 && option.value === '')) {
                    group.controls[selection].setErrors({ 'required': true });
                    return {
                        'requiredSelectionError': true
                    };
                } else if ((parseInt(opAmount.value, 10) == 0 && option.value === true)) {
                    group.controls[selection].setErrors({ 'invalid': true });
                    return {
                        'invalidSelectionError': true
                    };
                }
                else {
                    return null;
                }
            }
        }
    }

    bothZeroValuesValidator(selected1: string, selected2: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            const value1 = group.controls[selected1];
            const value2 = group.controls[selected2];
            if (value1 && value2) {
                if ((parseInt(value1.value, 10) == 0) && ((parseInt(value2.value, 10) == 0))) {
                    return {
                        [errorName]: true
                    };
                }
            }
            return null;
        }
    }

    crossZeroValuesValidator(compareValue: string, base: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            var value1 = group.controls[compareValue].value;
            var baseValue = group.controls[base];
            if (value1 instanceof String) {
            } else {
                value1 = '' + value1; // convert to string
            }
            const num1 = (value1).replace(/,/g, '');
            if (value1 && baseValue) {
                if ((parseInt(num1) > 0) && ((parseFloat(baseValue.value) == 0))) {
                    return {
                        [errorName + 'NotZeroError']: true
                    };
                } else if ((parseInt(num1) == 0) && ((parseFloat(baseValue.value) > 0))) {
                    return {
                        [errorName + 'RequireValueError']: true
                    };
                }
            }
            return null;
        }
    }


    totalValidator(selected: any): ValidatorFn {
        return (control: FormArray): { [key: string]: any } => {
            const array = control.value;
            let total = 0;
            if (array) {
                for (var i = 0; i < array.length; i++) {
                    total = total + array[i][selected];
                }
                if (total != 100) {
                    var errorType = selected + 'TotalError'
                    return {
                        [errorType]: true
                    };
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
    };

    zeroValuePercentageValidator(baseValue: string, formList: string, formName: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let sumInbound = 0;
            let ctrl = <FormArray>group.controls[formList];

            if (ctrl) {
                for (var i = 0; i < ctrl.length; i++) {
                    sumInbound = sumInbound + ctrl.value[i][formName];
                }
                let sum = group.controls[baseValue];
                let sumCount = parseFloat(sum.value) ? parseFloat(sum.value).toFixed(2) : 0;
                //check if operation = 0, the sum of service operation % should be 0
                if ((!isNaN(parseFloat(sum.value))) && sumCount == 0 && parseFloat(sumInbound.toFixed(2)) != 0) {
                    return {
                        [errorName]: true
                    };
                }
            }
            return null;
        }
    }

    hundredValuePercentageValidator(baseValue: string, formList: string, formName: string, errorName: string): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let sumInbound = 0;
            let ctrl = <FormArray>group.controls[formList];

            if (ctrl) {
                for (var i = 0; i < ctrl.length; i++) {
                    sumInbound = sumInbound + ctrl.value[i][formName];
                }
                let sum = group.controls[baseValue];
                let sumCount = parseFloat(sum.value) ? parseFloat(sum.value).toFixed(2) : 0;
                //check if operation > 0, the sum of service operation % should be 100
                if ((!isNaN(parseFloat(sum.value))) && sumCount > 0 && parseFloat(sumInbound.toFixed(2)) != 100) {
                    return {
                        [errorName]: true
                    };
                }
            }
            return null;
        }
    }

    selectionCrossValueValidator(operationAmount: AbstractControl, ): ValidatorFn {
        return (group: FormGroup): { [key: string]: any } => {
            let opAmount = operationAmount.value;
            // operationAmount.valueChanges.subscribe(
            //     (data: any) => {
            //         opAmount = operationAmount.value;
            //     });
            let option = group.value;
            if ((parseInt(opAmount, 10) > 0 && option === '')) {
                return {
                    'requiredSelectionError': true
                };
            } else if ((parseInt(opAmount, 10) == 0) && (option === true)) {
                return {
                    'invalidSelectionError': true
                };
            }
            else {
                return null;
            }
        }
    }

    matchingInboundOutboundCheckValidator(boundSum: string, boundKey: string, formName: string, errorGroup: string, errorZeroGroup: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let checked = false;
            let ctrl = <FormArray>group.controls[boundKey];
            ctrl.controls.forEach(x => {
                let parsed = x.get(formName).value == true ? true : false;
                if (parsed) {
                    checked = true;
                }
            });
            let sum = group.controls[boundSum];
            let sumCount = parseInt(sum.value, 10);
            if ((!isNaN(parseInt(sum.value, 10))) && sumCount == 0 && ctrl.controls.length > 0 && checked != false) {
                return {
                    [errorZeroGroup]: true
                };
            }
            else if ((!isNaN(parseInt(sum.value, 10))) && sumCount != 0 && ctrl.controls.length > 0 && checked == false) {
                return {
                    [errorGroup]: true
                };
            }
            else {
                return null;
            }
        }
    }

    matchingMissingBothCheckBoxValidator(inboundVal: AbstractControl, outboundVal: AbstractControl, inboundKey: string, outboundKey: string, errorGroup: string) {
        return (group: FormGroup): { [key: string]: any } => {
            let inboundValue = inboundVal.value;
            let outboundValue = outboundVal.value;
            let inbound = group.controls[inboundKey];
            let outbound = group.controls[outboundKey];
            if ((parseInt(inboundValue, 10) > 0 || (parseInt(outboundValue, 10) > 0)) && !inbound.value && !outbound.value) {
                return {
                    [errorGroup]: true
                };
            }
            else {
                return null;
            }
        }
    }
}

export function ValidateDigitMaxLength(control: AbstractControl) {
    var value = control.value;
    if (value) {
        value = '' + value;
        value = value.replace(NumeralUtil.ALPHABET_CHAR, "");
        value = value.replace(NumeralUtil.SPECIAL_CHAR, "");
        value = value.replace(/[-,]/g, '');

        if (value.length > 16) {
            return { maxlength: true };
        }
    }
    return null;
}

export function ValidateIntegerMaxLength(control: AbstractControl) {
    var value = control.value;
    if (value) {
        value = '' + value;
        value = value.replace(NumeralUtil.ALPHABET_CHAR, "");
        value = value.replace(NumeralUtil.SPECIAL_CHAR, "");
        value = value.replace(/[-,]/g, '');

        if (value.length > 9) {
            return { maxlengthInteger: true };
        }
    }
    return null;
}






