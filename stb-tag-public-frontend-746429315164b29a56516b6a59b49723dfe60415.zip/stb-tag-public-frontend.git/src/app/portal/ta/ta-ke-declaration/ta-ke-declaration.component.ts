import { Component, OnInit } from '@angular/core';
import * as dto from './ta-ke-declaration-dto';

@Component({
    selector: 'app-ta-ke-declaration',
    templateUrl: './ta-ke-declaration.component.html',
    styleUrls: ['./ta-ke-declaration.component.scss']
})
export class TaKeDeclarationComponent implements OnInit {

    application: dto.ApplicationDto;

    constructor() { }

    ngOnInit() {
        this.application = dto.NEW_APPLICATION;
    }

}
