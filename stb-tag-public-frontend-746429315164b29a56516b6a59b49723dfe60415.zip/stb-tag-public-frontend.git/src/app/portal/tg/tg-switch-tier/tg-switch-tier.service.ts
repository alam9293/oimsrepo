import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TgSwitchTierService {

    baseUrl: String = cnst.apexBaseUrl + cnst.TgAPiUrl.TG_SWITCH_TIER;

    constructor(private http: HttpClient) { }

    getPendingTierSwitch(): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view');
    }

    getTierSwitchById(id: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + '/view/' + id);
    }

    savePaymentRequest(app: any): Observable<any> {
        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(app)],
            { type: 'application/json' }
        ));

        return this.http.post(this.baseUrl + '/save/payment', formData);
    }

    saveAfterPayment(appId: number): Observable<any> {
        return this.http.get<any>(this.baseUrl + "/save/" + appId); 
    }

}
