import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as cnst from '../../common/constants';
import { TaApplicationService } from '../dashboard/ta-applications-history/ta-applications-history.service';
import { PaymentService } from '../payment/payment.service';
import { CommonService } from 'src/app/common/services';

@Component({
    selector: 'app-thankyou',
    templateUrl: './thankyou.component.html',
    styleUrls: ['./thankyou.component.scss']
})
export class ThankyouComponent implements OnInit {

    dashboardTypeCode: string;
    applicationNo: string;
    id: number;
    hasPayment: boolean = false;
    paymentResult = { lastTxn: {} };
    application: any = {};
    continueUrl: string;
    returnAppCode: string;
    cnst = cnst;
    returnApp: any = {};

    constructor(
        private route: ActivatedRoute,
        private paymentService: PaymentService,
        private taApplicationService: TaApplicationService,
        private commonService: CommonService,
    ) { }

    ngOnInit() {
        this.dashboardTypeCode = this.route.snapshot.data.dashboardTypeCode;
        this.applicationNo = this.route.snapshot.queryParams.applicationNo;
        this.id = this.route.snapshot.queryParams.id;

        if (this.id) {
            this.taApplicationService.getApplication(this.id).subscribe(data => {
                this.application = data;
            })
        }
        if (this.route.snapshot.queryParams.billRefNo && this.route.snapshot.queryParams.billRefNo != null) {
            this.hasPayment = true;
            this.paymentService.getPaymentRequests(this.route.snapshot.queryParams.billRefNo).subscribe(data => {
                this.paymentResult = data;
            });
            this.continueUrl = this.route.snapshot.queryParams.continueUrl;
        }
        this.returnAppCode = this.route.snapshot.queryParams.returnApp;
        if (this.returnAppCode) {
            this.commonService.getTaApplicationTypes().subscribe(data => {
                data.forEach(appType => {
                    if (appType.key == this.returnAppCode) {
                        this.returnApp.key = appType.key;
                        this.returnApp.label = appType.label;
                        this.returnApp.url = cnst.TaApplicationUrlMap[appType.key];
                    }
                });
            })
        }
        /*
        if (this.route.snapshot.paramMap.get('appId') == 'new') {
            this.checkForPendingApplication();
        } else {
            this.getApplication(+this.route.snapshot.paramMap.get('appId'));
        }
        */
    }

    print() {
        window.print();
    }

}
