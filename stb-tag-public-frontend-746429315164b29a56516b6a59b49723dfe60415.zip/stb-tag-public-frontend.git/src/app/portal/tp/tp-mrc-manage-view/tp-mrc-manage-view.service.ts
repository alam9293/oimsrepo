import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import * as cnst from '../../../common/constants';

@Injectable({
    providedIn: 'root'
})
export class TpMrcManageViewService {

    constructor(private http: HttpClient) { }

    public getCourseAttendanceDetails(attendanceId: any): Observable<any> {
        return this.http.get<any>(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_MRC + '/view/' + attendanceId);
    }

    public updateCourseAttendanceDetails(courseAttendanceDetail: any): Observable<any> {

        let formData: FormData = new FormData();
        formData.append('dto', new Blob(
            [JSON.stringify(courseAttendanceDetail)],
            { type: 'application/json' }
        ));

        return this.http.post(cnst.apexBaseUrl + cnst.TgAPiUrl.TP_MRC + '/update', formData);
    }
}