import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tp-mrc',
  templateUrl: './tp-mrc.component.html',
  styleUrls: ['./tp-mrc.component.scss']
})
export class TpMRCComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
