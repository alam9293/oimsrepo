// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    apiAppUrl: 'http://localhost:9090/webservice-public/api/v1',
    // apexAppUrl: 'http://localhost:9090/webservice-public/apex/v1', // use APEX
    apexAppUrl: 'http://localhost:9191/webservice-admin/api/v1', // skip APEX
    eNetsUrl: '',
    eNetsReturnUrl: 'http://localhost:4210/public/portal/',
    webPortalUrl: 'http://localhost:4210/public/home',
    googleAnalyticId: '',
    googleAnalyticTagManagerId: '',
    iamsUrl: '/public/portal/login',
    iamsClientId: '4b00feaa-847c-40ef-b439-d104dac8bf0e',
    testingIamsUrl: 'https://sso-uat.stb.gov.sg/oxauth/restv1/authorize?scope=openid%20profile%20email%20user_name${UEN_SCOPE}'
        + '&response_type=code'
        + '&client_id=${CLIENT_ID}'
        + '&acr_values=${ACR_VALUE}'
        + '&redirect_uri=http%3A%2F%2Flocalhost%3A4210%2Fpublic%2Fportal%2F${LOGIN_TYPE}',
    iamsLogoutUrl: 'https://sso-uat.stb.gov.sg/oxauth/restv1/end_session?id_token_hint=${IAMS_ID_TOKEN}&post_logout_redirect_uri=http%3A%2F%2Flocalhost%3A4210'
    //iamsClientId: '798839644450-ibn6hflt69vpsvg0k5qej836utigjk6c.apps.googleusercontent.com',
    // testingIamsUrl: 'https://accounts.google.com/o/oauth2/v2/auth?scope=openid%20profile%20email'
    //     + '&response_type=code'
    //     + '&client_id=${CLIENT_ID}'
    //     + '&acr_values=${ACR_VALUE}'
    //     + '&redirect_uri=http%3A%2F%2Flocalhost:4210%2Fpublic%2Fportal%2F${LOGIN_TYPE}',
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

