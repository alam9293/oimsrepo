package com.wiz.security;

import java.util.Set;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

@SuppressWarnings("serial")
public class CustomAuthenticationToken extends UsernamePasswordAuthenticationToken {

	private String name;

	private String roleCode;

	public CustomAuthenticationToken(String name, Object principal, String roleCode, Set<GrantedAuthority> authorities) {
		super(principal, null, authorities);
		this.name = name;
		this.roleCode = roleCode;
	}

	@Override
	public String getName() {
		return name;
	}

	public String getRoleCode() {
		return roleCode;
	}

}
