package gov.stb.tag.config;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JasyptConfig {

	private static final String key = "stbpublictrust";

	@Bean(name = "encryptorBean")
	public StringEncryptor stringEncryptor() {
		PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();

		encryptor.setAlgorithm("PBEWITHMD5ANDDES");
		encryptor.setPassword(key);
		encryptor.setPoolSize(1);
		return encryptor;
	}
}