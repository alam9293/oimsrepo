package gov.stb.tag.config;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.support.GenericConversionService;
import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.filters.ApexFilter;
import gov.stb.tag.interceptor.RequestProcessingTimeInterceptor;
import gov.stb.tag.util.DateUtil;

@Configuration
public class WebConfig implements WebMvcConfigurer {

	protected transient static Logger logger = LoggerFactory.getLogger(WebConfig.class);

	private static final String[] CORS_HEADERS_ALLOWED = { Codes.Headers.VERSION_CHECK, Codes.Headers.VERSION_CHECK_LISTING, Codes.Headers.APEX_AUTH, Codes.Headers.APP_AUTH, Codes.Headers.APP_TOKEN,
			Codes.Headers.XSRF_TOKEN, "Accept", "Content-Type", "Origin" };
	private static final String[] CORS_HEADERS_EXPOSED = { Codes.Headers.VERSION_CHECK, Codes.Headers.VERSION_CHECK_LISTING, Codes.Headers.APEX_AUTH, Codes.Headers.APP_AUTH, Codes.Headers.APP_TOKEN,
			Codes.Headers.XSRF_TOKEN };
	private static final String[] CORS_METHODS_ALLOWED = { "POST", "GET", "DELETE", "PUT", "OPTIONS" };

	@Autowired
	RequestProcessingTimeInterceptor requestProcessingTimeInterceptor;
	@Autowired
	ApexFilter apexFilter;

	@Bean
	public FilterRegistrationBean<ApexFilter> registerApexFilter() {
		FilterRegistrationBean<ApexFilter> registration = new FilterRegistrationBean<ApexFilter>(apexFilter);
		registration.addUrlPatterns("/apex/*");
		return registration;
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedOrigins("*").allowCredentials(true).maxAge(3600).allowedHeaders(CORS_HEADERS_ALLOWED).exposedHeaders(CORS_HEADERS_EXPOSED)
				.allowedMethods(CORS_METHODS_ALLOWED);
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		// TODO: to disable during UAT/PROD rollout
		registry.addInterceptor(requestProcessingTimeInterceptor);
	}

	@Bean
	public LocaleResolver localeResolver() {
		SessionLocaleResolver slr = new SessionLocaleResolver();
		slr.setDefaultLocale(Locale.US);
		return slr;
	}

	@Autowired
	private RequestMappingHandlerAdapter handlerAdapter;

	@PostConstruct
	public void addConversionConfig() {
		ConfigurableWebBindingInitializer initializer = (ConfigurableWebBindingInitializer) handlerAdapter.getWebBindingInitializer();
		if (initializer.getConversionService() != null) {
			GenericConversionService genericConversionService = (GenericConversionService) initializer.getConversionService();
			genericConversionService.addConverter(new StringToDateTimeConverter());
			genericConversionService.addConverter(new StringToDateConverter());
		}
	}

	public class StringToDateTimeConverter implements Converter<String, LocalDateTime> {

		@Override
		public LocalDateTime convert(String dateString) {
			return Strings.isNullOrEmpty(dateString) ? null : DateUtil.parseDateTime(dateString);
		}
	}

	public class StringToDateConverter implements Converter<String, LocalDate> {

		@Override
		public LocalDate convert(String dateString) {
			return Strings.isNullOrEmpty(dateString) ? null : DateUtil.parseDate(dateString);
		}
	}

}