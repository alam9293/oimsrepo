package gov.stb.tag.constant;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Properties extends CommonProperties {

	private transient Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${tag.conf.showDebugMessage}")
	public Boolean showDebugMessage;

	@Value("${tag.conf.email}")
	public String email;

	@Value("${tag.conf.catchAllEmail}")
	public String catchAllEmail;

	@Value("${tag.conf.env}")
	public String appEnv;

	@Value("${iams.token.url}")
	public String iamsTokenUrl;

	@Value("${iams.client.id}")
	public String iamsClientId;

	@Value("${iams.client.secret}")
	public String iamsClientSecret;

	@Value("${iams.logout.url}")
	public String iamsLogoutUrl;

	@Value("${singPass.sam.url}")
	public String singPassSamUrl;

	@Value("${singPass.eServiceId}")
	public String singPassEServiceId;

	@Value("${singPass.partnerId}")
	public String singPassPartnerId;

	@Value("${corpPass.sam.url}")
	public String corpPassSamUrl;

	@Value("${corpPass.eServiceId}")
	public String corpPassEServiceId;

	@Value("${corpPass.partnerId}")
	public String corpPassPartnerId;

	@Value("${payNow.crOutputTemplate}")
	public String payNowCrOutputTemplate;

	@Value("${tag.apex.enabled}")
	public Boolean tagApexEnabled;

	@Value("${tag.apex.eg.l2.baseApiUrl}")
	public String tagApexEgL2BaseApiUrl;

	@Value("${tag.apex.eg.l2.appId}")
	public String tagApexEgL2AppId;

	@Value("${tag.apex.eg.l2.realm}")
	public String tagApexEgL2Realm;

	@Value("${tag.apex.eg.l2.version}")
	public String tagApexEgL2Version;

	@Value("${tag.apex.eg.l2.alias}")
	public String tagApexEgL2Alias;

	@Value("${tag.apex.eg.l2.password}")
	public String tagApexEgL2Password;

	@Value("${tag.apex.eg.l2.keyStoreFilename}")
	public String tagApexEgL2KeyStoreFilename;

	@Value("${tag.apex.ig.l1.baseApiUrl}")
	public String tagApexIgL1BaseApiUrl;

	@Value("${tag.apex.ig.l1.appId}")
	public String tagApexIgL1AppId;

	@Value("${tag.apex.ig.l1.realm}")
	public String tagApexIgL1Realm;

	@Value("${tag.apex.ig.l1.version}")
	public String tagApexIgL1Version;

	@Value("${tag.apex.ig.l1.secret}")
	public String tagApexIgL1Secret;

	@Value("${tag.api.authenticateSpCp}")
	public String tagApiAuthenticateSpCp;

	@Value("${tag.api.retrieveCurrentLoginUserId}")
	public String tagApiRetrieveCurrentLoginUserId;

	@Value("${tag.api.tagApiRetrieveCurrentLoginIamsIdTokenAndLogout}")
	public String tagApiRetrieveCurrentLoginIamsIdTokenAndLogout;

	@Value("${tag.api.tagApiRetrieveCurrentLoginSPIdToken}")
	public String tagApiRetrieveCurrentLoginSPIdToken;

	@Value("${tag.api.myInfoSnapshot}")
	public String tagApiMyInfoSnapshot;

	@Value("${tag.api.edhSnapshot}")
	public String tagApiEdhSnapshot;

	@Value("${tag.proxy.enabled}")
	public Boolean tagProxyEnabled;

	@Value("${tag.proxy.host}")
	public String tagProxyHost;

	@Value("${tag.proxy.port}")
	public Integer tagProxyPort;

	@Value("${myInfo.apex.enabled}")
	public Boolean myInfoApexEnabled;

	@Value("${myInfo.apex.eg.l2.baseApiUrl}")
	public String myInfoApexEgL2BaseApiUrl;

	@Value("${myInfo.apex.eg.l2.appId}")
	public String myInfoApexEgL2AppId;

	@Value("${myInfo.apex.eg.l2.realm}")
	public String myInfoApexEgL2Realm;

	@Value("${myInfo.apex.eg.l2.version}")
	public String myInfoApexEgL2Version;

	@Value("${myInfo.apex.eg.l2.alias}")
	public String myInfoApexEgL2Alias;

	@Value("${myInfo.apex.eg.l2.password}")
	public String myInfoApexEgL2Password;

	@Value("${myInfo.apex.eg.l2.keyStoreFilename}")
	public String myInfoApexEgL2KeyStoreFilename;

	@Value("${myInfo.apex.eg.l2.myinfoPublicCertFilename}")
	public String myInfoApexEgL2MyInfoPublicCertFilename;

	@Value("${myInfo.singpassEserviceId}")
	public String myInfoSingpassEserviceId;

	@Value("${myInfo.attributes}")
	public String myInfoAttributes;

	@Value("${myInfo.api.personBasic}")
	public String myInfoApiPersonBasic;

	@Value("${edh.apex.enabled}")
	public Boolean edhApexEnabled;

	@Value("${edh.apex.eg.l2.baseApiUrl}")
	public String edhApexEgL2BaseApiUrl;

	@Value("${edh.apex.eg.l2.appId}")
	public String edhApexEgL2AppId;

	@Value("${edh.apex.eg.l2.realm}")
	public String edhApexEgL2Realm;

	@Value("${edh.apex.eg.l2.version}")
	public String edhApexEgL2Version;

	@Value("${edh.apex.eg.l2.alias}")
	public String edhApexEgL2Alias;

	@Value("${edh.apex.eg.l2.password}")
	public String edhApexEgL2Password;

	@Value("${edh.apex.eg.l2.keyStoreFilename}")
	public String edhApexEgL2KeyStoreFilename;

	@Value("${edh.api.entity}")
	public String edhApiEntity;

	@Value("${edh.api.appointments}")
	public String edhApiAppointments;

	@Value("${edh.api.shareholders}")
	public String edhApiShareholders;

	@Value("${edh.api.financials}")
	public String edhApiFinancials;

	@Value("${build.info.timestamp}")
	public String buildInfoTimestamp;

	@Value("${build.info.by}")
	public String buildInfoBy;

	@PostConstruct
	public void init() {
		logger.info("[conf] tag.conf.env          : " + appEnv);
		logger.info("[conf] tag.conf.email        : " + email);
		logger.info("[conf] tag.conf.catchAllEmail: " + catchAllEmail);
		logger.info("[conf] tag.dir.base          : " + baseDir);
		logger.info("[conf] tag.endpoint.apex     : " + tagApexEgL2BaseApiUrl);
		logger.info("[conf] tag.endpoint.myinfo   : " + myInfoApexEgL2BaseApiUrl);
		logger.info("[conf] tag.endpoint.edh      : " + edhApexEgL2BaseApiUrl);
		logger.info("[conf] build.info.by: " + buildInfoBy);
		logger.info("[conf] build.info.timestamp: " + buildInfoTimestamp);

	}
}
