package gov.stb.tag.controllers;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.google.common.collect.Lists;
import com.wiz.model.api.Listable;
import com.wiz.security.CustomAuthenticationToken;

import gov.stb.tag.constant.Properties;
import gov.stb.tag.dto.ErrorDto;
import gov.stb.tag.dto.ListableDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.CacheHelper;
import gov.stb.tag.model.User;

public class BaseController {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	protected CacheHelper cache;

	@Autowired
	protected Properties properties;

	/**
	 * Gets the cached user record of the user making the request, along with the granted Roles
	 * 
	 * @return AuthenticatedUserDTO
	 */
	protected User getUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = (User) authentication.getPrincipal();

		return user;
	}

	/**
	 * Get the current selected role code for the user making the request
	 * 
	 * @return
	 */
	protected String getSelectedRoleCode() {
		CustomAuthenticationToken authentication = (CustomAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
		return authentication.getRoleCode();
	}

	@ExceptionHandler(ValidationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDto handleAppException(ValidationException e) {

		return new ErrorDto(HttpStatus.BAD_REQUEST.value(), e.getMessage());
	}

	/**
	 * Handles {@link MethodArgumentNotValidException}s thrown by DTO validation in POST method's RequestBody
	 * 
	 * @param e
	 * @return
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDto handleAppException(MethodArgumentNotValidException e) {
		logger.error(e.getMessage(), e);
		return handleSpringValidationException(e.getBindingResult());
	}

	/**
	 * Handles {@link BindException}s thrown by DTO validation in GET method
	 * 
	 * @param e
	 * @return
	 */
	@ExceptionHandler(BindException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDto handleAppException(BindException e) {
		logger.error(e.getMessage(), e);
		return handleSpringValidationException(e.getBindingResult());
	}

	/**
	 * Handle all generic exceptions
	 * 
	 * @param e
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ErrorDto handleAppException(Exception e) {
		long errTs = new Date().getTime();
		logger.error(e.getMessage() + ". ref: " + errTs, e);
		StringBuilder stringBuilder = new StringBuilder();
		if (properties.showDebugMessage) {
			stringBuilder.append("<b>");
			stringBuilder.append("boo");
			stringBuilder.append("</b><br>");
			stringBuilder.append(e.getClass().getName() + ": " + e.getLocalizedMessage());
			for (int i = 0; i < e.getStackTrace().length; i++) {
				stringBuilder.append("<br>");
				stringBuilder.append(e.getStackTrace()[i]);
			}
		} else {
			stringBuilder.append("System Error Occurred. Please quote reference number " + errTs
					+ " with a screen shot and contact administrator at 6736 6622 or email at STB_TA@STB.GOV.SG (TA) or STB_TOURIST_GUIDE@STB.GOV.SG (TG). Operating hours are 8.00am to 8.00pm, Monday to Friday excluding Public holidays and weekends.");
		}
		return new ErrorDto(HttpStatus.INTERNAL_SERVER_ERROR.value(), stringBuilder.toString());
	}

	private ErrorDto handleSpringValidationException(BindingResult bindingResult) {
		StringBuilder errorMessage = new StringBuilder();
		for (ObjectError error : bindingResult.getAllErrors()) {
			errorMessage.append("&bull; ");
			errorMessage.append(error.getDefaultMessage());
			errorMessage.append("<br>");
		}
		if (errorMessage.length() > 0) {
			return new ErrorDto(HttpStatus.BAD_REQUEST.value(), errorMessage.substring(0, errorMessage.length() - 4));
		} else {
			return new ErrorDto(HttpStatus.BAD_REQUEST.value(), "");
		}
	}

	protected void validateFileDeleteStatus(File file, String messageFailed) {
		if (!file.delete()) {
			throw new ValidationException(messageFailed);
		}
	}

	protected <T extends Listable> List<ListableDto> toListableDtos(List<T> listables) {
		List<ListableDto> listableDtos = Lists.newArrayList();
		listables.forEach(o -> listableDtos.add(new ListableDto(o.getKey(), o.getLabel())));
		return listableDtos;
	}

	protected <T extends Listable> List<ListableDto> toListableDtos(Map<?, String> map) {
		List<ListableDto> listableDtos = Lists.newArrayList();
		map.entrySet().forEach(o -> listableDtos.add(new ListableDto((Serializable) o.getKey(), o.getValue())));
		return listableDtos;
	}
}
