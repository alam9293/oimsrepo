package gov.stb.tag.controllers;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/v1/csp")
@Transactional
public class CspReportController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@RequestMapping(path = "/report", method = { RequestMethod.POST })
	public void reportViolation(@RequestBody String json) {
		logger.info("CSP Violation: " + json);
	}

}
