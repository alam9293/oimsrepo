package gov.stb.tag.controllers;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.api.util.ApiSecurity.ApiList;
import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.edh.AppointmentDto;
import gov.stb.tag.dto.edh.EdhDto;
import gov.stb.tag.dto.edh.EdhEntityDto;
import gov.stb.tag.dto.edh.FinancialsDto;
import gov.stb.tag.dto.edh.ShareholderDto;
import gov.stb.tag.util.HttpUtil;

@RestController
@RequestMapping(path = "/api/v1/edh")
@Transactional
@SuppressWarnings({ "unchecked", "deprecation" })
public class EdhController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	ObjectMapper objectMapper;

	@RequestMapping(method = RequestMethod.GET, value = Codes.Edh.API_ENTITY)
	public EdhEntityDto getEntity(HttpServletRequest req) {
		return getEdhApiData(req, properties.edhApiEntity, Codes.Edh.API_ENTITY, EdhEntityDto.class);
	}

	@RequestMapping(method = RequestMethod.GET, value = Codes.Edh.API_ENTITY_APPOINTMENTS)
	public EdhDto<AppointmentDto> getAppointments(HttpServletRequest req) {
		return getEdhApiData(req, properties.edhApiAppointments, Codes.Edh.API_ENTITY_APPOINTMENTS, EdhDto.class);
	}

	@RequestMapping(method = RequestMethod.GET, value = Codes.Edh.API_ENTITY_SHAREHOLDERS)
	public EdhDto<ShareholderDto> getShareholders(HttpServletRequest req) {
		return getEdhApiData(req, properties.edhApiShareholders, Codes.Edh.API_ENTITY_SHAREHOLDERS, EdhDto.class);
	}

	@RequestMapping(method = RequestMethod.GET, value = Codes.Edh.API_ENTITY_FINANCIALS)
	public FinancialsDto getFinancials(HttpServletRequest req) {
		return getEdhApiData(req, properties.edhApiFinancials, Codes.Edh.API_ENTITY_FINANCIALS, FinancialsDto.class);
	}

	private <T extends EdhDto<?>> T getEdhApiData(HttpServletRequest req, String api, String apiName, Class<T> clazz) {
		String uen = null;
		try {
			// 1. determine current login ID from session from intranet
			uen = getCurrentUen(req);
			if (Strings.isNullOrEmpty(uen)) {
				logger.error("getEdhApiData(): " + api + ": unable to determine current session login uen");
				return handleEdhError(uen, "Unable to determine current login uen", clazz);
			}

			// 2. prepare api end point
			if (properties.appEnv != null && !properties.appEnv.equalsIgnoreCase("PROD")) {
				uen = "201600159C";
			}
			String apiUrl = properties.edhApexEgL2BaseApiUrl + api.replace("{uen}", uen);

			// 3. build & call HTTP request
			logger.debug("[edh] query tag APEX endpoint: " + apiUrl);
			RestTemplate restTemplate = getRestTemplate();
			HttpHeaders headers = new HttpHeaders();
			if (properties.edhApexEnabled) {
				headers.add(Codes.Headers.APEX_AUTH, generateEdhApexSignature(apiUrl));
			}
			ResponseEntity<String> edhResp = restTemplate.exchange(apiUrl, HttpMethod.GET, new HttpEntity<>(headers), String.class);

			// 4. process HTTP response
			if (edhResp != null && edhResp.getStatusCodeValue() == HttpStatus.SC_OK) {
				String json = edhResp.getBody();
				logger.debug("getEdhApiData(): " + api + ": json: " + json);

				// 5. save a copy of raw response to intranet DB via TAG-APEX
				return saveEdhSnapshot(req, uen, json, apiName, clazz);
			} else {
				logger.error("getEdhApiData(): " + api + ": error retrieving edh for uen: " + uen + ". output: " + edhResp.getBody());
				return handleEdhError(uen, "Unable to retrieve EDH", clazz);
			}
		} catch (HttpClientErrorException e) {
			logger.error("getEdhApiData(): " + api + ": " + e.getStatusCode() + ": " + e.getResponseBodyAsString(), e);
			return handleEdhError(uen, "Unable to retrieve EDH", clazz);

		} catch (Exception e) {
			logger.error("getEdhApiData(): " + api + ": " + e.getMessage(), e);
			return handleEdhError(uen, e.getMessage(), clazz);
		}
	}

	private String getCurrentUen(HttpServletRequest req) throws IOException, ApiUtilException {
		String uen = "";
		String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + properties.tagApiRetrieveCurrentLoginUserId;
		String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + properties.tagApiRetrieveCurrentLoginUserId;

		HttpRequestBase tagApexReq = HttpUtil.reconstruct(req, egL2ApiUrl);
		logger.info("[edh] query tag APEX endpoint: " + egL2ApiUrl);

		// generate the necessary authorization header required by APEX
		if (properties.tagApexEnabled) {
			tagApexReq.addHeader(Codes.Headers.APEX_AUTH, generateTagApexSignature(egL2ApiUrl, igL1ApiUrl, HttpMethod.GET.name(), null));
		} else {
			logger.debug("No Authorization Header Added.");
		}

		// execute the request
		if (properties.tagProxyEnabled) {
			tagApexReq.setConfig(RequestConfig.custom().setProxy(new HttpHost(properties.tagProxyHost, properties.tagProxyPort)).build()); // for Fiddler to check on the server-to-server request
		}
		HttpClient client = HttpClientBuilder.create().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
		HttpResponse tagApexResp = client.execute(tagApexReq);

		org.apache.http.HttpEntity tagEntity = tagApexResp.getEntity();
		if (tagEntity == null) {
			logger.error("getCurrentUen(): apex retrieval failed, unable to retrieve current-uen");
		} else {
			int errorCode = tagApexResp.getStatusLine().getStatusCode();
			logger.info("getCurrentUen(): tag retrieval resp-status-code: " + errorCode);

			if (errorCode == HttpStatus.SC_OK) {
				uen = IOUtils.toString(tagApexResp.getEntity().getContent(), "UTF-8").split(",", 2)[1];
				logger.debug("getCurrentUen(): uen: " + uen);
			} else {
				logger.error("getCurrentUen(): error retrieving. ErrorCode: " + errorCode);
			}
		}

		// release resource
		EntityUtils.consume(tagEntity);

		return uen;
	}

	private <T extends EdhDto<?>> T saveEdhSnapshot(HttpServletRequest req, String uen, String json, String apiName, Class<T> clazz)
			throws InstantiationException, IllegalAccessException, ApiUtilException, ClientProtocolException, IOException {
		// save edh response to backend intranet

		T dto = clazz.newInstance();
		String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + properties.tagApiEdhSnapshot + apiName;
		String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + properties.tagApiEdhSnapshot + apiName;

		// clone headers & prepare to submit json response to intranet
		HttpPost apexPostReq = new HttpPost(egL2ApiUrl);
		HttpUtil.copyHeaders(req, apexPostReq);
		List<NameValuePair> nameValues = new ArrayList<NameValuePair>();
		nameValues.add(new BasicNameValuePair("jsonText", json));
		apexPostReq.setEntity(new UrlEncodedFormEntity(nameValues, "UTF-8"));
		logger.info("saveEdhSnapshot(): query tag APEX endpoint: " + egL2ApiUrl);

		// generate the necessary authorization header required by APEX
		if (properties.tagApexEnabled) {
			ApiList apiList = new ApiList();
			apiList.add(nameValues.get(0).getName(), nameValues.get(0).getValue());
			apexPostReq.addHeader(Codes.Headers.APEX_AUTH, generateTagApexSignature(egL2ApiUrl, igL1ApiUrl, HttpMethod.POST.name(), apiList));
		} else {
			logger.debug("No Authorization Header Added.");
		}

		// execute the request
		if (properties.tagProxyEnabled) {
			apexPostReq.setConfig(RequestConfig.custom().setProxy(new HttpHost(properties.tagProxyHost, properties.tagProxyPort)).build());
		}
		HttpClient client = HttpClientBuilder.create().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
		HttpResponse tagApexResp = client.execute(apexPostReq);

		org.apache.http.HttpEntity tagEntity = tagApexResp.getEntity();
		if (tagEntity == null) {
			logger.error("saveEdhSnapshot(): apex saving failed");
		} else {
			int errorCode = tagApexResp.getStatusLine().getStatusCode();
			logger.info("saveEdhSnapshot(): tag saving resp-status-code: " + errorCode);

			if (errorCode == HttpStatus.SC_OK) {
				String output = IOUtils.toString(tagApexResp.getEntity().getContent(), "UTF-8");
				dto = objectMapper.readValue(output, clazz);
				logger.debug("saveEdhSnapshot(): jsonString: " + output);
			} else {
				logger.error("saveEdhSnapshot(): error saving. ErrorCode: " + errorCode);
				dto.setHasError(true);
				dto.setErrorMessage("error saving snapshot");
			}
		}

		// release resource
		EntityUtils.consume(tagEntity);

		return dto;
	}

	private <T extends EdhDto<?>> T handleEdhError(String uen, String errorMsg, Class<T> clazz) {
		T dto;
		try {
			dto = clazz.newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		dto.setUen(uen);
		dto.setHasError(true);
		dto.setErrorMessage(errorMsg);
		return dto;
	}

	private String generateEdhApexSignature(String apiUrl) throws ApiUtilException {
		apiUrl = apiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
		String signature = ApiSigning.getSignatureToken(properties.edhApexEgL2Realm, Codes.Apex.INTERNET_L2, HttpMethod.GET.name(), apiUrl, properties.edhApexEgL2AppId, null, null,
				properties.edhApexEgL2Password, properties.edhApexEgL2Alias, properties.edhApexEgL2KeyStoreFilename, null, null);
		logger.info(signature);
		return signature;
	}

	private String generateTagApexSignature(String egL2ApiUrl, String igL1ApiUrl, String httpMethod, ApiList formData) throws ApiUtilException {
		egL2ApiUrl = egL2ApiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
		String egL2Signature = ApiSigning.getSignatureToken(properties.tagApexEgL2Realm, Codes.Apex.INTERNET_L2, httpMethod, egL2ApiUrl, properties.tagApexEgL2AppId, null, formData,
				properties.tagApexEgL2Password, properties.tagApexEgL2Alias, properties.tagApexEgL2KeyStoreFilename, null, null);
		String igL1Signature = ApiSigning.getSignatureToken(properties.tagApexIgL1Realm, Codes.Apex.INTRANET_L1, httpMethod, igL1ApiUrl, properties.tagApexIgL1AppId, properties.tagApexIgL1Secret,
				formData, null, null, null, null, null);
		return egL2Signature + ", " + igL1Signature;
	}

	private RestTemplate getRestTemplate() {
		if (!properties.tagProxyEnabled) {
			return new RestTemplate();
		} else {
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(properties.tagProxyHost, properties.tagProxyPort));
			requestFactory.setProxy(proxy);
			return new RestTemplate(requestFactory);
		}
	}
}
