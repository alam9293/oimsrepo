package gov.stb.tag.controllers;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FilenameUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.api.util.ApiSecurity.ApiList;
import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.FileDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.model.DocumentTemplate;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Type;
import gov.stb.tag.repository.FileRepository;
import gov.stb.tag.util.FileUtil;

@RestController
@RequestMapping(path = "/api/v1/file")
@Transactional
public class FileController extends BaseController {
	@Autowired
	FileHelper fileHelper;
	@Autowired
	FileRepository repository;

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@RequestMapping(path = "/download/{fileId}/{hash}", method = RequestMethod.GET)
	public void downloadFiles(HttpServletResponse response, @PathVariable Integer fileId, @PathVariable String hash) throws IOException {
		File file = fileHelper.getFile(fileId);
		if (file != null) {
			fileHelper.isHashBelongToFile(file, hash);
			FileUtil.downloadSingleFile(response, fileHelper.getPhyiscalFile(file), null);
		} else {
			throw new ValidationException("File not found");
		}

	}

	@RequestMapping(path = "/download-template/{doctype}", method = RequestMethod.GET)
	public void downloadTemplate(HttpServletResponse response, @PathVariable String doctype) throws IOException {
		DocumentTemplate template = repository.getTemplate(doctype);
		if (template != null) {
			if (template.getFile() != null) {
				FileUtil.downloadSingleFile(response, fileHelper.getPhyiscalFile(template.getFile()), null);
			} else {
				throw new ValidationException("File not found");
			}
		} else {
			throw new ValidationException("Template not found");
		}

	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public void deleteFiles(@RequestPart(name = "dto") List<FileDto> dtoList) {
		for (FileDto dto : dtoList) {
			File file = fileHelper.getFile(dto.getPublicFileId());
			if (file != null) {
				fileHelper.isHashBelongToFile(file, dto.getHash());
				fileHelper.deleteFile(file);
			} else {
				logger.error("File not found: " + dto.getPublicFileId());
			}

		}

	}

	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public FileDto uploadFile(HttpServletRequest req, @RequestPart(name = "docType") String docType, @RequestPart(name = "file") MultipartFile file) throws IOException, ApiUtilException {

		String url = "/v1/common/docType-by-key/" + docType;
		String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + url;
		String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + url;

		// 1. check valid document type
		RestTemplate restTemplate = getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		if (properties.tagApexEnabled) {
			String header = generateTagApexSignature(egL2ApiUrl, igL1ApiUrl, HttpMethod.GET.name(), null);
			logger.debug("[tag file upload] adding header: {}", header);
			headers.add(Codes.Headers.APEX_AUTH, header);
		}
		logger.info("[myinfo] query tag APEX endpoint: " + egL2ApiUrl + ", " + igL1ApiUrl);
		ResponseEntity<String> resp = restTemplate.exchange(egL2ApiUrl, HttpMethod.GET, new HttpEntity<>(headers), String.class);

		// 2. Save documents
		File fileObj = fileHelper.saveFile(docType, file, true);

		// 3. Get docment type model
		Type docTypeModel = new Type();
		JSONArray jsonArr = new JSONArray(resp.getBody());

		for (int i = 0; i < jsonArr.length(); i++) {
			JSONObject obj = jsonArr.getJSONObject(i);
			docTypeModel.setCode((String) obj.get("key"));
			docTypeModel.setLabel((String) obj.get("label"));
			if (obj.has("otherLabel")) {
				docTypeModel.setOtherLabel((String) obj.get("otherLabel"));
			}
		}

		// 4. Pass DTO containing new fileID to frontend (to pass to admin webservice for reference)
		FileDto dto = FileDto.buildFromFile(fileObj, docTypeModel, fileHelper);
		return dto;

	}

	private RestTemplate getRestTemplate() {
		if (!properties.tagProxyEnabled) {
			return new RestTemplate();
		} else {
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(properties.tagProxyHost, properties.tagProxyPort));
			requestFactory.setProxy(proxy);
			return new RestTemplate(requestFactory);
		}
	}

	private String generateTagApexSignature(String egL2ApiUrl, String igL1ApiUrl, String httpMethod, ApiList formData) throws ApiUtilException {
		egL2ApiUrl = egL2ApiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
		String egL2Signature = ApiSigning.getSignatureToken(properties.tagApexEgL2Realm, Codes.Apex.INTERNET_L2, httpMethod, egL2ApiUrl, properties.tagApexEgL2AppId, null, formData,
				properties.tagApexEgL2Password, properties.tagApexEgL2Alias, properties.tagApexEgL2KeyStoreFilename, null, null);
		String igL1Signature = ApiSigning.getSignatureToken(properties.tagApexIgL1Realm, Codes.Apex.INTRANET_L1, httpMethod, igL1ApiUrl, properties.tagApexIgL1AppId, properties.tagApexIgL1Secret,
				formData, null, null, null, null, null);
		return egL2Signature + ", " + igL1Signature;
	}

	@RequestMapping(path = "/retrieveFile/{fileId}/{licenceNo}/{hash}", method = RequestMethod.GET)
	public FileDto retrieveFile(HttpServletResponse response, @PathVariable Integer fileId, @PathVariable String licenceNo, @PathVariable String hash) throws IOException {
		FileDto dto = new FileDto();
		File file = repository.getFile(fileId);
		fileHelper.isHashBelongToFile(file, hash);
		java.io.File photo = fileHelper.getPhyiscalFile(file);
		if (photo != null) {
			try {
				dto.setPhotoExtension(FilenameUtils.getExtension(photo.getName()));
				dto.setPhoto(Base64.encodeBase64String(FileUtil.readFileToByteArray(photo)));
			} catch (Exception e) {
				logger.error("Invalid photo : {}", licenceNo);
			}
		}
		return dto;
	}

}
