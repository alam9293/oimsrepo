package gov.stb.tag.controllers;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.api.util.ApiSecurity.ApiList;
import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jwt.EncryptedJWT;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Messages;
import gov.stb.tag.dto.myinfo.MyInfoPersonBasicDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.util.HttpUtil;

@RestController
@RequestMapping(path = "/api/v1/my-info")
@Transactional
public class MyInfoController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	ObjectMapper objectMapper;

	@RequestMapping(method = RequestMethod.GET, value = "/person-basic")
	public MyInfoPersonBasicDto getPersonBasic(HttpServletRequest req) {
		String uinfin = null;
		String spIdToken = null;
		try {
			// 1. determine current login uen from session from intranet
			uinfin = getCurrentLoginID(req);

			// Get IAMS sp_id_token from session storage to put in api request
			spIdToken = getLoginSPIdToken(req);

			if (Strings.isNullOrEmpty(uinfin)) {
				logger.error("getPersonBasic(): unable to determine current session login userid");
				return handleMyInfoError(uinfin, "Unable to determine current login ID");
			}

			// 2. prepare api end point

			String apiUrl = properties.myInfoApexEgL2BaseApiUrl + properties.myInfoApiPersonBasic + "/" + uinfin + "/?attributes=" + properties.myInfoAttributes + "&client_id="
					+ properties.myInfoApexEgL2AppId + "&sp_esvcId=" + properties.myInfoSingpassEserviceId;

			// 3. build & call HTTP request
			logger.info("[myinfo] query tag APEX endpoint: " + apiUrl);
			RestTemplate restTemplate = getRestTemplate();
			HttpHeaders headers = new HttpHeaders();
			if (properties.myInfoApexEnabled) {
				String header = generateMyInfoApexSignature(uinfin, spIdToken);
				logger.debug("[myinfo] adding header: {}", header);
				headers.add(Codes.Headers.APEX_AUTH, header);
			}
			logger.info("[myinfo] query tag APEX endpoint: " + apiUrl);
			ResponseEntity<String> myInfoResp = restTemplate.exchange(apiUrl, HttpMethod.GET, new HttpEntity<>(headers), String.class);

			// 4. process HTTP response
			if (myInfoResp != null && myInfoResp.getStatusCodeValue() == HttpStatus.SC_OK) {
				logger.info("object: " + myInfoResp.toString());
				logger.info("body: " + myInfoResp.getBody());
				String json = properties.myInfoApexEnabled ? decryptJwe(myInfoResp.getBody()) : myInfoResp.getBody();
				logger.debug("getPersonBasic(): json: " + json);

				// 5. save a copy of raw response to intranet DB via TAG-APEX
				return saveMyInfoSnapshot(req, uinfin, json);

			} else {
				logger.error("getPersonBasic(): error retrieving myinfo for uin: " + uinfin + ". output: " + myInfoResp.getBody());
				return handleMyInfoError(uinfin, "Unable to retrieve MyInfo");
			}
		} catch (HttpClientErrorException e) {
			logger.error("getPersonBasic(): " + e.getStatusCode() + ": " + e.getResponseBodyAsString(), e);
			return handleMyInfoError(uinfin, "Unable to retrieve MyInfo");

		} catch (Exception e) {
			logger.error("getPersonBasic(): " + e.getMessage(), e);
			return handleMyInfoError(uinfin, e.getMessage());
		}
	}

	private String getLoginSPIdToken(HttpServletRequest req) throws IOException, ApiUtilException {
		String iamsIdToken = "";
		String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + properties.tagApiRetrieveCurrentLoginSPIdToken;
		String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + properties.tagApiRetrieveCurrentLoginSPIdToken;

		HttpRequestBase tagApexReq = HttpUtil.reconstruct(req, egL2ApiUrl);
		logger.info("[iams-getLoginSPIdToken] query tag APEX endpoint: " + egL2ApiUrl);

		// generate the necessary authorization header required by APEX
		if (properties.tagApexEnabled) {
			tagApexReq.addHeader(Codes.Headers.APEX_AUTH, generateTagApexSignature(egL2ApiUrl, igL1ApiUrl, HttpMethod.GET.name(), null));
		} else {
			logger.debug("No Authorization Header Added.");
		}

		// execute the request
		if (properties.tagProxyEnabled) {
			tagApexReq.setConfig(RequestConfig.custom().setProxy(new HttpHost(properties.tagProxyHost, properties.tagProxyPort)).build()); // for Fiddler to check on the server-to-server request
		}
		HttpClient client = HttpClientBuilder.create().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
		HttpResponse tagApexResp = client.execute(tagApexReq);

		org.apache.http.HttpEntity tagEntity = tagApexResp.getEntity();
		if (tagEntity == null) {
			logger.error("getLoginSPIdToken(): apex retrieval failed, unable to retrieve current-login-sp-id-token");
		} else {
			int errorCode = tagApexResp.getStatusLine().getStatusCode();
			logger.info("getLoginSPIdToken(): tag retrieval resp-status-code: " + errorCode);

			if (errorCode == HttpStatus.SC_OK) {
				iamsIdToken = IOUtils.toString(tagApexResp.getEntity().getContent(), "UTF-8").split(",")[0];
				logger.debug("getLoginSPIdToken(): getLoginSPIdToken: " + iamsIdToken);
			} else {
				logger.error("getLoginSPIdToken(): error retrieving. ErrorCode: " + errorCode);
			}
		}

		// release resource
		EntityUtils.consume(tagEntity);

		return iamsIdToken;
	}

	private String getCurrentLoginID(HttpServletRequest req) throws IOException, ApiUtilException {
		String uinfin = "";
		String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + properties.tagApiRetrieveCurrentLoginUserId;
		String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + properties.tagApiRetrieveCurrentLoginUserId;

		HttpRequestBase tagApexReq = HttpUtil.reconstruct(req, egL2ApiUrl);
		logger.info("[myinfo] query tag APEX endpoint: " + egL2ApiUrl);

		// generate the necessary authorization header required by APEX
		if (properties.tagApexEnabled) {
			tagApexReq.addHeader(Codes.Headers.APEX_AUTH, generateTagApexSignature(egL2ApiUrl, igL1ApiUrl, HttpMethod.GET.name(), null));
		} else {
			logger.debug("No Authorization Header Added.");
		}

		// execute the request
		if (properties.tagProxyEnabled) {
			tagApexReq.setConfig(RequestConfig.custom().setProxy(new HttpHost(properties.tagProxyHost, properties.tagProxyPort)).build()); // for Fiddler to check on the server-to-server request
		}
		HttpClient client = HttpClientBuilder.create().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
		HttpResponse tagApexResp = client.execute(tagApexReq);

		org.apache.http.HttpEntity tagEntity = tagApexResp.getEntity();
		if (tagEntity == null) {
			logger.error("getCurrentLoginID(): apex retrieval failed, unable to retrieve current-login-userid");
		} else {
			int errorCode = tagApexResp.getStatusLine().getStatusCode();
			logger.info("getCurrentLoginID(): tag retrieval resp-status-code: " + errorCode);

			if (errorCode == HttpStatus.SC_OK) {
				uinfin = IOUtils.toString(tagApexResp.getEntity().getContent(), "UTF-8").split(",")[0];
				logger.debug("getCurrentLoginID(): uinfin: " + uinfin);
			} else {
				logger.error("getCurrentLoginID(): error retrieving. ErrorCode: " + errorCode);
			}
		}

		// release resource
		EntityUtils.consume(tagEntity);

		return uinfin;
	}

	private MyInfoPersonBasicDto saveMyInfoSnapshot(HttpServletRequest req, String uinfin, String json) throws IOException, ApiUtilException {
		// save myinfo response to backend intranet

		MyInfoPersonBasicDto dto = new MyInfoPersonBasicDto();
		String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + properties.tagApiMyInfoSnapshot;
		String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + properties.tagApiMyInfoSnapshot;

		// clone headers & prepare to submit json response to intranet
		HttpPost apexPostReq = new HttpPost(egL2ApiUrl);
		HttpUtil.copyHeaders(req, apexPostReq);
		List<NameValuePair> nameValues = new ArrayList<NameValuePair>();
		nameValues.add(new BasicNameValuePair("jsonText", json));
		apexPostReq.setEntity(new UrlEncodedFormEntity(nameValues, "UTF-8"));
		logger.info("saveMyInfoSnapshot(): query tag APEX endpoint: " + egL2ApiUrl);

		// generate the necessary authorization header required by APEX
		if (properties.tagApexEnabled) {
			ApiList apiList = new ApiList();
			apiList.add(nameValues.get(0).getName(), nameValues.get(0).getValue());
			apexPostReq.addHeader(Codes.Headers.APEX_AUTH, generateTagApexSignature(egL2ApiUrl, igL1ApiUrl, HttpMethod.POST.name(), apiList));
		} else {
			logger.debug("No Authorization Header Added.");
		}

		// execute the request
		if (properties.tagProxyEnabled) {
			apexPostReq.setConfig(RequestConfig.custom().setProxy(new HttpHost(properties.tagProxyHost, properties.tagProxyPort)).build());
		}
		HttpClient client = HttpClientBuilder.create().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
		HttpResponse tagApexResp = client.execute(apexPostReq);

		org.apache.http.HttpEntity tagEntity = tagApexResp.getEntity();
		if (tagEntity == null) {
			logger.error("saveMyInfoSnapshot(): apex saving failed");
		} else {
			int errorCode = tagApexResp.getStatusLine().getStatusCode();
			logger.info("saveMyInfoSnapshot(): tag saving resp-status-code: " + errorCode);

			if (errorCode == HttpStatus.SC_OK) {
				String output = IOUtils.toString(tagApexResp.getEntity().getContent(), "UTF-8");
				dto = objectMapper.readValue(output, MyInfoPersonBasicDto.class);
				logger.debug("saveMyInfoSnapshot(): jsonString: " + output);
			} else {
				logger.error("saveMyInfoSnapshot(): error saving. ErrorCode: " + errorCode);
				handleMyInfoError(uinfin, "error saving snapshot");
			}
		}

		// release resource
		EntityUtils.consume(tagEntity);

		return dto;
	}

	private MyInfoPersonBasicDto handleMyInfoError(String uinfin, String errorMsg) {
		if (errorMsg.contains("404")) {
			errorMsg = Messages.Errors.MYINFO_NOT_FOUND;
		} else {
			errorMsg = Messages.Errors.MYINFO_SERVER_ERROR;
		}
		throw new ValidationException(errorMsg);

	}

	private String generateMyInfoApexSignature(String uin, String spIdToken) throws Exception {
		String timestamp = Long.toString(getNewTimestamp());
		String nonce = getNewNonce();
		String baseString = getBaseString(uin, nonce, timestamp).trim();
		logger.info(baseString);
		String signature = getAuthHeader(baseString, nonce, timestamp, properties.myInfoApexEgL2KeyStoreFilename, spIdToken).trim();
		logger.info(signature);
		return signature;
	}

	private String getAuthHeader(String baseString, String nonce, String timestamp, String fileName, String spIdToken) {
		String authorizationToken = null;
		String base64Token = "";
		PrivateKey privateKey = null;
		try {
			if (null != fileName && (fileName.contains(".key") || fileName.contains(".pem"))) {
				privateKey = ApiSigning.getPrivateKeyPEM(fileName, properties.myInfoApexEgL2Password);
			} else {
				// For JKS file
				privateKey = ApiSigning.getPrivateKeyFromKeyStore(fileName, properties.myInfoApexEgL2Password, properties.myInfoApexEgL2Alias);
			}
			base64Token = getRSASignature(baseString, privateKey);
			ApiList tokenList = new ApiList();

			tokenList.add("PKI_SIGN app_id", properties.myInfoApexEgL2AppId);
			tokenList.add("nonce", nonce);
			tokenList.add("signature_method", "RS256");
			tokenList.add("timestamp", timestamp);
			tokenList.add("signature", base64Token);
			tokenList.add("id_token", "Bearer " + spIdToken);

			authorizationToken = String.format(tokenList.toString(",", false, true, false));
			return authorizationToken;
		} catch (Exception e) {
			logger.error("getAuthHeader(): ", e);
			return "";
		}

	}

	private String getBaseString(String uin, String nonce, String timestamp) {
		try {
			String baseString = null;
			ApiList paramList = new ApiList();
			paramList.add("timestamp", timestamp);
			paramList.add("nonce", nonce);
			paramList.add("app_id", properties.myInfoApexEgL2AppId);
			paramList.add("signature_method", "RS256");
			paramList.add("client_id", properties.myInfoApexEgL2AppId);
			paramList.add("attributes", properties.myInfoAttributes);
			paramList.add("sp_esvcId", properties.myInfoSingpassEserviceId);
			baseString = "GET&" + properties.myInfoApexEgL2BaseApiUrl + properties.myInfoApiPersonBasic + "/" + uin + "/&" + paramList.toString(true);
			return baseString;
		} catch (Exception e) {
			logger.error("getBaseString(): ", e);
			return "";
		}

	}

	private String getNewNonce() throws NoSuchAlgorithmException {
		String nonce = null;
		byte[] b = new byte[32];
		SecureRandom.getInstance("SHA1PRNG").nextBytes(b);
		nonce = Base64.getEncoder().encodeToString(b);
		return nonce;
	}

	private long getNewTimestamp() {
		return System.currentTimeMillis();
	}

	private String getRSASignature(String baseString, PrivateKey privateKey) throws ApiUtilException {
		Signature rsa = null;
		byte[] encryptedData = null;
		String base64Token = null;
		try {
			// Validation
			if (baseString == null || baseString.isEmpty()) {
				throw new ValidationException("Base String cannot be null");
			}

			if (privateKey == null) {
				throw new ValidationException("Private Key cannot be null");
			}

			try {
				rsa = Signature.getInstance("SHA256withRSA");
			} catch (NoSuchAlgorithmException nsae) {
				throw nsae;
			}
			try {
				rsa.initSign(privateKey);
			} catch (InvalidKeyException ike) {
				throw ike;
			}
			try {
				rsa.update(baseString.getBytes());
			} catch (SignatureException se) {
				throw se;
			}
			try {
				encryptedData = rsa.sign();
			} catch (SignatureException se) {
				throw se;
			}
			base64Token = new String(Base64.getEncoder().encode(encryptedData));
			return base64Token;
		} catch (Exception e) {
			logger.error("getRSASignature(): error in generating RSA Signature. " + e.getMessage());
			return "";
		}

	}

	private String generateTagApexSignature(String egL2ApiUrl, String igL1ApiUrl, String httpMethod, ApiList formData) throws ApiUtilException {
		egL2ApiUrl = egL2ApiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
		String egL2Signature = ApiSigning.getSignatureToken(properties.tagApexEgL2Realm, Codes.Apex.INTERNET_L2, httpMethod, egL2ApiUrl, properties.tagApexEgL2AppId, null, formData,
				properties.tagApexEgL2Password, properties.tagApexEgL2Alias, properties.tagApexEgL2KeyStoreFilename, null, null);
		String igL1Signature = ApiSigning.getSignatureToken(properties.tagApexIgL1Realm, Codes.Apex.INTRANET_L1, httpMethod, igL1ApiUrl, properties.tagApexIgL1AppId, properties.tagApexIgL1Secret,
				formData, null, null, null, null, null);
		return egL2Signature + ", " + igL1Signature;
	}

	private RestTemplate getRestTemplate() {
		if (!properties.tagProxyEnabled) {
			return new RestTemplate();
		} else {
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(properties.tagProxyHost, properties.tagProxyPort));
			requestFactory.setProxy(proxy);
			return new RestTemplate(requestFactory);
		}
	}

	private String decryptJwe(String jwe) throws ApiUtilException, ParseException, JOSEException, IOException, GeneralSecurityException {
		PrivateKey privateKey = ApiSigning.getPrivateKeyFromKeyStore(properties.myInfoApexEgL2KeyStoreFilename, properties.myInfoApexEgL2Password, properties.myInfoApexEgL2Alias);
		EncryptedJWT encryptedJWT = EncryptedJWT.parse(jwe);
		RSADecrypter decrypter = new RSADecrypter(privateKey);
		encryptedJWT.decrypt(decrypter);
		return encryptedJWT.getPayload().toSignedJWT().getJWTClaimsSet().toString();
	}
}
