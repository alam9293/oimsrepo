package gov.stb.tag.controllers;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Base64;

import javax.imageio.ImageIO;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gov.stb.tag.util.DateUtil;
import wog.payment.SGQRCode;
import wog.payment.sgqr.scheme.SchemeDataObject;

@RestController
@RequestMapping(path = "/api/v1/pay-now")
@Transactional
public class PayNowController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@RequestMapping(method = RequestMethod.GET, value = "/generate-qr-code/{amount}/{txnId}")
	public String generateQrCode(@PathVariable String amount, @PathVariable String txnId) {
		try {
			if ("0".equals(txnId)) {
				return "";
			}
			SGQRCode code = new SGQRCode();

			/*
			 * Initialised SGQRCode instance with the CR Template String from your accquirer. 4-Sep-2018 : Updated the CR template string. PLEASE NOTE THAT THE CR TEMPLATE IS INTENDED FOR POC AND
			 * TESTING PURPOSES. AGENCY ARE REQUIRED TO ACUIRE THE CR TEMPLATE FROM YOUR ACQUIRER.
			 */
			String crOutputTemplate = properties.payNowCrOutputTemplate;
			code.init(crOutputTemplate);

			/*
			 * Set the preferred scheme.
			 */
			code.AddPreferedScheme(SchemeDataObject.NETSRail);
			code.AddPreferedScheme(SchemeDataObject.PayNowRail);

			// PayNow don't support multi bills per txn (doesn't accept array). Not ideal to concat bills as we can't trace which amt to which bill if it's partial payment (user can change themselves)
			code.setBillNumber(txnId);
			code.setTransactionAmount(amount);
			code.setQRExpiryDate(DateUtil.format(LocalDate.now().plusDays(1), "ddMMyyyy")); // Set the expiry date in ddMMyyyy format.

			code.setQRCodeImageSize(200); // Set the size (unit in pixel) of the QR Code image. If not set, the value is default to 1000
			if (code.generate()) {
				/*
				 * The generated string content of the SGQR code
				 */
				String qrCodeContent = code.getQRCodeContent();
				logger.info(qrCodeContent);

				/*
				 * The binary content of the SGQR code as a BufferedImage object
				 */
				return encodeToString(code.getQRCodeImage(), "png");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return ""; // return blank if QR Code generation fails for whatever reason
	}

	private String encodeToString(BufferedImage image, String type) throws IOException {
		try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
			ImageIO.write(image, type, bos);
			byte[] imageBytes = bos.toByteArray();
			return Base64.getEncoder().encodeToString(imageBytes);
		}
	}
}
