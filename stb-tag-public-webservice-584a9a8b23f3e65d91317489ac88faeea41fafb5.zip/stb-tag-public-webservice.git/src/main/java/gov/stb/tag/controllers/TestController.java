package gov.stb.tag.controllers;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.api.util.ApiSecurity.ApiList;
import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.google.common.collect.Sets;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jwt.EncryptedJWT;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.FileHelper;
import gov.stb.tag.helper.LicenceHelper;
import gov.stb.tag.model.Address;
import gov.stb.tag.model.Bulletin;
import gov.stb.tag.model.File;
import gov.stb.tag.model.Licence;
import gov.stb.tag.model.TgCandidate;
import gov.stb.tag.model.TgCandidateResult;
import gov.stb.tag.model.TouristGuide;
import gov.stb.tag.model.Type;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.BaseRepository;
import gov.stb.tag.util.DateUtil;
import io.jsonwebtoken.Jwts;

// TODO: FOR TESTING ONLY, TO BE REMOVED IN PRODUCTION 123
@RestController
@RequestMapping(path = "/api/v1/test")
@Transactional
public class TestController extends BaseController {
	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	BaseRepository baseRepository;

	@Autowired
	FileHelper fileHelper;

	@Autowired
	LicenceHelper licenceHelper;

	static StringBuilder msg = new StringBuilder();

	static String loginId = "";
	static String uen = "";

	// http://localhost:9090/webservice-public/api/v1/test/mock-iams-authorize
	@RequestMapping(path = "/mock-iams-authorize", method = RequestMethod.POST)
	public void mockIamsAuthorizeApi(@PathVariable String uin, @PathVariable String uen) {
		TestController.loginId = uin;
		TestController.uen = uen;
	}

	// http://localhost:9090/webservice-public/api/v1/test/mock-iams-token
	@RequestMapping(path = "/mock-iams-token", method = RequestMethod.POST)
	public String mockIamsTokenApi(@RequestBody Object tokenParams) {
		String JWT = Jwts.builder().claim("uen", uen).claim("uin", loginId).compact();
		return "{\"id_token\": " + JWT + "}";

	}

	// http://localhost:9090/webservice-public/api/v1/test/myinfo-base-string/person-basic/F3000023N/30990176753/1547535101000
	@RequestMapping(method = RequestMethod.GET, value = "/myinfo-base-string/{api}/{uinfin}/{nonce}/{timestamp}")
	public String getMyInfoBaseString(@PathVariable String api, @PathVariable String uinfin, @PathVariable String nonce, @PathVariable String timestamp) {
		String signingBaseUrl = properties.myInfoApexEgL2BaseApiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
		String signingUrl = signingBaseUrl + "/" + api + "/" + uinfin + "/";
		logger.info("Signing Url: {}", signingUrl);

		ApiList queryParams = new ApiList();
		queryParams.add("attributes", properties.myInfoAttributes);
		queryParams.add("client_id", properties.myInfoApexEgL2AppId);
		queryParams.add("sp_esvcId", properties.myInfoSingpassEserviceId);

		try {
			return ApiSigning.getBaseString(Codes.Apex.INTERNET_L2, Codes.Apex.SIGN_METHOD_L2, properties.myInfoApexEgL2AppId, signingUrl, HttpMethod.GET.name(), queryParams, nonce, timestamp);
		} catch (ApiUtilException e) {
			return e.getMessage();
		}
	}

	// http://localhost:9090/webservice-public/api/v1/test/get-myinfo-api-data/S6005037F
	@RequestMapping(method = RequestMethod.GET, value = "/get-myinfo-api-data/{uinfin}")
	public String getMyInfoApiData(@PathVariable String uinfin) throws ApiUtilException {
		// String apiUrl = properties.myInfoApexEgL2BaseApiUrl + "/" + api + "/" + uinfin + "/";
		String apiUrl = properties.myInfoApexEgL2BaseApiUrl + properties.myInfoApiPersonBasic + "/" + uinfin + "/?attributes=" + properties.myInfoAttributes + "&client_id="
				+ properties.myInfoApexEgL2AppId + "&sp_esvcId=" + properties.myInfoSingpassEserviceId;

		// Generate request header
		HttpHeaders headers = new HttpHeaders();
		headers.add(Codes.Headers.APEX_AUTH, generateApexHeader(apiUrl));
		// build http request entity
		logger.debug("Accessing API: {}", apiUrl);
		RestTemplate restTemplate = getRestTemplate(true);
		ResponseEntity<String> response = restTemplate.exchange(apiUrl, HttpMethod.GET, new HttpEntity<>(headers), String.class);
		return decryptJwe(response.getBody());
	}

	private String generateApexHeader(String apiUrl) {
		apiUrl = apiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
		try {
			return ApiSigning.getSignatureToken(properties.myInfoApexEgL2Realm, Codes.Apex.INTERNET_L2, HttpMethod.GET.name(), apiUrl, properties.myInfoApexEgL2AppId, null, null,
					properties.myInfoApexEgL2Password, properties.myInfoApexEgL2Alias, properties.myInfoApexEgL2KeyStoreFilename, null, null);
		} catch (ApiUtilException e) {
			logger.error(e.getMessage());
			throw new RuntimeException(e);
		}
	}

	// For Fiddler to intercept HTTPS: http://shengwangi.blogspot.com/2017/03/use-fiddler-to-debug-https-request-from.html
	// (Run As Run Config... > VM Arguments: -Djavax.net.ssl.trustStore=c:/Keystores/fiddler/fiddler_keystore.jks -Djavax.net.ssl.trustStorePassword=abcd1234)
	private RestTemplate getRestTemplate(boolean enableDebug) {
		if (!enableDebug) {
			return new RestTemplate();
		} else {
			SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", 8888));
			requestFactory.setProxy(proxy);
			return new RestTemplate(requestFactory);
		}
	}

	private String decryptJwe(String jwe) {
		try {
			PrivateKey privateKey = ApiSigning.getPrivateKeyFromKeyStore(properties.myInfoApexEgL2KeyStoreFilename, properties.myInfoApexEgL2Password, properties.myInfoApexEgL2Alias);
			EncryptedJWT encryptedJWT = EncryptedJWT.parse(jwe);
			RSADecrypter decrypter = new RSADecrypter(privateKey);
			encryptedJWT.decrypt(decrypter);
			Payload payload = encryptedJWT.getPayload();
			return payload.toJSONObject().toJSONString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*
	 * For AEM Use
	 */

	// http://localhost:9090/webservice-public/api/v1/test/bulletin
	@RequestMapping(method = RequestMethod.POST, value = "/bulletin", consumes = { "multipart/form-data" })
	public String patchBulletin(@RequestParam(name = "file", required = false) MultipartFile[] multipartFiles, @RequestParam("effectiveDate") String effectiveDate,
			@RequestParam("typeCode") String typeCode, @RequestPart("content") String content, @RequestParam("title") String title, @RequestParam("isPrivate") Boolean isPrivate) {

		Set<File> files = new HashSet<File>();
		for (MultipartFile multipartFile : multipartFiles) {
			files.add(fileHelper.saveFile("BULLETIN_DOC", multipartFile, true));
		}

		Bulletin bulletin = new Bulletin();
		bulletin.setContent(content);
		bulletin.setEffectiveDate(DateUtil.parseDate(effectiveDate));
		bulletin.setTitle(title);
		bulletin.setType(cache.getType(typeCode));
		bulletin.setPrivate(isPrivate);
		bulletin.setFiles(files);
		baseRepository.save(bulletin);

		return "bulletin inserted successfully.";
	}

	static String[] englishName = { "Olivia", "Jessica", "Rebecca", "Matthew", "Nick", "Harrison", "Christopher", "Benedict", "Nathan", "Nelson", "Summer", "Winter", "Freedom", "Alex", "Winnie",
			"Yvonne", "Isobel", "Paige", "Emelly", "Sienna", "Alisha", "Brasil", "Jibby", "Isabel", "Harley", "Brandon", "Rosie", "Kenneth", "Justin" };

	static String[] surname = { "Ong", "Lee", "Cheng", "Ong", "Chuah", "Harrison", "Peng", "Lim", "Lee", "Chan", "Ng", "Cheng", "Sim", "Yap", "Eng", "Wong", "Ter", "Tee", "Tan", "Yeo" };

	// http://10.0.0.191:9191/webservice-admin/api/v1/uat-test/create-tg-licence
	@RequestMapping(method = RequestMethod.POST, value = "/create-tg-licence/{number}")
	public String createTgLicence(@RequestPart("file") MultipartFile multipartFile, @PathVariable Integer number) {

		gov.stb.tag.model.File file = fileHelper.saveFile("TG_DOC_PHOTO", multipartFile, true);

		for (int i = 0; i < number; i++) {
			int engIdx = new Random().nextInt(englishName.length);
			int surIdx = new Random().nextInt(surname.length);
			String name = englishName[engIdx] + " " + surname[surIdx];

			// random DOB
			SecureRandom r = new SecureRandom();
			int ranYear = r.nextInt(28) + 1990;
			int ranMonth = r.nextInt(12) + 1;
			int ranDate = r.nextInt(28) + 1;

			createTg(name, file, LocalDate.of(ranYear, ranMonth, ranDate), "S", LocalDate.of(2019, 8, 31));
		}

		return msg.toString();

	}

	private TouristGuide createTg(String name, gov.stb.tag.model.File file, LocalDate dob, String uinStartChar, LocalDate startDate) {
		var uin = uinStartChar + RandomStringUtils.randomNumeric(7) + RandomStringUtils.randomAlphabetic(1).toUpperCase();

		var tgCandidateResult = new TgCandidateResult();
		tgCandidateResult.setEmail("stb.testuser@wizvision.com");
		tgCandidateResult.setName(name);
		tgCandidateResult.setExamDate(startDate);
		tgCandidateResult.setGuidingLanguage(cache.getTypesByCategory(Codes.TypeCategories.TG_GUIDING_LANGUAGE).get(0));
		tgCandidateResult.setSpecializedArea(cache.getTypesByCategory(Codes.TypeCategories.TG_SPECIALIZED_AREA).get(0));
		tgCandidateResult.setTier(cache.getType("TG_TIER_G"));
		baseRepository.save(tgCandidateResult);

		Set<TgCandidateResult> results = new HashSet<>();
		results.add(tgCandidateResult);

		TgCandidate tgCandidate = new TgCandidate();
		tgCandidate.setUin(uin);
		tgCandidate.setTgCandidateResults(results);
		tgCandidate.setLastCandidateResult(tgCandidateResult);
		baseRepository.save(tgCandidate);

		tgCandidateResult.setTgCandidate(tgCandidate);

		User user = new User();
		user.setLoginId(uin);
		user.setPassword("a7a28b1e0011a0ebdfe1f8cc3d5cdd92dcc441c01fa963dcb66dcf545f082d0a"); // password1
		user.setSalt("kIRKWHs1JxrAon1Kz0IL9fGEPVI=");
		user.setName(name);
		user.setEmailAddress("stb.testuser@wizvision.com");
		user.setTgCandidate(tgCandidate);
		user.setType(cache.getType(Codes.UserTypes.USER_PUBLIC));
		user.setStatus(cache.getStatus(Codes.Statuses.USER_ACTIVE));
		user.setRoles(Sets.newHashSet());
		user.getRoles().add(cache.getRole(Codes.Roles.TG_PUBLIC));
		baseRepository.save(user);

		TouristGuide tg = new TouristGuide();
		tg.setUin(uin);
		baseRepository.save(tg);
		user.setTouristGuide(tg);

		// licence
		Licence licence = new Licence();
		licence.setTouristGuide(tg);
		licence.setTaTgType(Codes.TaTgType.TG);
		licence.setTier(cache.getType(Codes.Types.TG_TIER_GENERAL));
		licence.setIssueDate(tgCandidateResult.getExamDate());
		licence.setStartDate(tgCandidateResult.getExamDate());
		licence.setExpiryDate(tgCandidateResult.getExamDate().plusYears(3));
		licenceHelper.updateLicenceStatus(licence, Codes.Statuses.TG_ACTIVE);
		licence.setStatus(cache.getStatus(Codes.Statuses.TG_ACTIVE));
		baseRepository.save(licence);

		tg.setDob(dob);

		Set<Type> guidingLanguages = new HashSet<>();
		Set<Type> specializedAreas = new HashSet<>();

		tg.setSex(cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
		tg.setUser(user);
		tg.setLicence(licence);
		tg.setName(name);
		tg.setBirthCountry(cache.getTypesByCategory(Codes.TypeCategories.COUNTRY).get(0));
		tg.setHighestEduLevel(cache.getTypesByCategory(Codes.TypeCategories.EDUCATION_LEVEL).get(0));
		tg.setMaritalStatus(cache.getTypesByCategory(Codes.TypeCategories.MARITAL_STATUS).get(0));
		tg.setNationality(cache.getTypesByCategory(Codes.TypeCategories.NATIONALITY).get(0));
		tg.setRace(cache.getTypesByCategory(Codes.TypeCategories.RACE).get(0));
		tg.setResidentialStatus(cache.getTypesByCategory(Codes.TypeCategories.RESIDENTIAL_STATUS).get(0));
		tg.setSalutation(cache.getTypesByCategory(Codes.TypeCategories.SALUTATION).get(0));
		tg.setSex(cache.getTypesByCategory(Codes.TypeCategories.SEX).get(0));
		tg.setMobileNo("8" + RandomStringUtils.randomNumeric(7));
		tg.setEmailAddress(user.getEmailAddress());
		tg.setHasConsentMobileNo(true);
		tg.setHasConsentEmailAddress(true);
		tg.setPhoto(file);
		tg.setWorkPassType(cache.getType(Codes.Types.TG_TIER_GENERAL));

		guidingLanguages.add(tgCandidateResult.getGuidingLanguage());
		specializedAreas.add(tgCandidateResult.getSpecializedArea());

		tg.setGuidingLanguages(guidingLanguages);
		tg.setSpecializedAreas(specializedAreas);

		// registered address
		Address registered = new Address();
		registered.setAddressType(cache.getType(Codes.Types.ADDR_LOCAL));
		registered.setPostal("381050");
		registered.setPremiseType(cache.getTypesByCategory(Codes.TypeCategories.PREMISE_TYPE).get(0));
		registered.setStreet("SIMS DRIVE");
		registered.setBuilding("SIMS VISTA");
		registered.setBlock("50A");
		registered.setFloor(RandomStringUtils.randomNumeric(2));
		registered.setUnit(RandomStringUtils.randomNumeric(2));
		tg.setRegisteredAddress(registered);
		tg.setMailingAddress(registered);

		baseRepository.save(tg.getRegisteredAddress());
		baseRepository.save(tg.getMailingAddress());

		appendLn(name + " - " + uin + " - " + licence.getId());
		return tg;
	}

	private void appendLn(String text) {
		msg.append(text);
		msg.append("<br />");
	}

}
