package gov.stb.tag.controllers;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.api.util.ApiSecurity.ApiList;
import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.dto.AuthRequestDto;
import gov.stb.tag.dto.auth.AuthPubRequestDto;
import gov.stb.tag.exception.ValidationException;
import gov.stb.tag.util.HttpUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@RestController
@RequestMapping(path = "/api/v1/users")
@Transactional
public class UserController extends BaseController {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	private static final String SECRET = "ThisIsASecret123";

	// http://localhost:9090/webservice-public/api/v1/users/authenticate-iams
	@RequestMapping(method = RequestMethod.POST, value = "/authenticate-iams")
	public void authenticateIams(@Validated @RequestBody AuthRequestDto dto, HttpServletResponse resp) throws IOException, URISyntaxException, KeyManagementException, NoSuchAlgorithmException {

		logger.info("authenticateIams Start");
		logger.info("AuthRequestDto Dashboard TypeCode: " + dto.getDashboardTypeCode() + " IAMS Access Code: " + dto.getIamsAccessCode() + " Login TypeCode: " + dto.getLoginTypeCode());

		Map<String, String> paramMap = authenticateWithIams(dto, resp, dto.getLoginTypeCode());
		String uin = paramMap.get("uin");
		String uen = paramMap.get("uen");
		logger.info("authenticateIams UIN: " + uin + " UEN: " + uen);

		if (uin == null || (dto.getLoginTypeCode().equals("CP") && uen == null)) {
			// TODO: SPCP error handling
			// resp.sendRedirect("");
		} else {
			loginToPortal(resp, uin, uen, dto.getDashboardTypeCode(), paramMap.get("iams_id_token"), paramMap.get("sp_id_token"));
		}
	}

	// Construct a server-to-sever request to IAMS to get user's logged in details
	private Map<String, String> authenticateWithIams(AuthRequestDto dto, HttpServletResponse resp, String loginType)
			throws IOException, URISyntaxException, NoSuchAlgorithmException, KeyManagementException {
		logger.info("Authenticating with IAMS...");

		String clientId = properties.iamsClientId;
		String clientSecret = properties.iamsClientSecret;
		String urlParameters = "grant_type=authorization_code" + "&code=" + URLEncoder.encode(dto.getIamsAccessCode()) + "&scope=openid%20profile%20email%20user_name"
				+ (loginType.equals("CP") ? "%20uen" : "") + "&redirect_uri="
				+ URLEncoder.encode(String.format(properties.applicationUrl, "%2Fpublic%2Fportal%2F" + (loginType.equals("CP") ? "login-cp" : loginType.equals("SP") ? "login-sp" : "login-portal")));
		byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8);
		int postDataLength = postData.length;
		logger.info("\nSending 'POST' request to URL : " + properties.iamsTokenUrl);
		logger.info("Post parameters : " + urlParameters);

		URL obj = new URL(properties.iamsTokenUrl);
		HttpsURLConnection con = null;
		if (properties.tagProxyEnabled || properties.appEnv.equals(Codes.Environments.SIT)) {
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(properties.tagProxyHost, properties.tagProxyPort));
			con = (HttpsURLConnection) obj.openConnection(proxy);
		} else {
			con = (HttpsURLConnection) obj.openConnection();
		}

		SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
		sslContext.init(null, null, new SecureRandom());

		con.setDoOutput(true);
		con.setInstanceFollowRedirects(false);
		con.setRequestMethod("POST");
		String basicAuth = "Basic " + new String(Base64.getEncoder().encode((clientId + ":" + clientSecret).getBytes()));
		con.setRequestProperty("Authorization", basicAuth);
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		con.setRequestProperty("charset", "utf-8");
		con.setRequestProperty("Content-Length", Integer.toString(postDataLength));
		con.setUseCaches(false);
		con.setSSLSocketFactory(sslContext.getSocketFactory());

		try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
			wr.write(postData);
			wr.flush();
			wr.close();
		}

		int responseCode = con.getResponseCode();
		logger.info("Response Code : " + responseCode);
		logger.info("Response Code : " + con.getErrorStream());
		StringBuilder respMsg = new StringBuilder();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		while ((inputLine = in.readLine()) != null) {
			respMsg.append(inputLine);
		}
		in.close();
		logger.info("IAMS response: " + respMsg.toString());

		// Extract NRIC from IAMS Response, and E-Service release sensitive information to users.
		final ObjectNode node = new ObjectMapper().readValue(respMsg.toString(), ObjectNode.class);
		if (node.has("id_token")) {
			logger.info("ParamMap Start");
			String jws = node.get("id_token").asText();
			int i = jws.lastIndexOf('.');
			String withoutSignature = jws.substring(0, i + 1);
			Claims claims = Jwts.parser().setAllowedClockSkewSeconds(60).parseClaimsJwt(withoutSignature).getBody();
			Map<String, String> paramMap = new HashMap<String, String>();
			logger.info("ParamMap UIN: " + (String) claims.get("user_name"));
			paramMap.put("uin", (String) claims.get("user_name"));
			if (claims.get("uen") != null) {
				logger.info("ParamMap UEN: " + (String) claims.get("uen"));
				paramMap.put("uen", (String) claims.get("uen"));
			}
			if (claims.get("sp_id_token") != null) {
				logger.info("ParamMap SP ID Token: " + (String) claims.get("sp_id_token"));
				paramMap.put("sp_id_token", (String) claims.get("sp_id_token"));
			}
			logger.info("ParamMap IAMS ID Token: " + node.get("id_token").asText());
			paramMap.put("iams_id_token", node.get("id_token").asText());
			logger.info("ParamMap Exit");
			return paramMap;
		} else {
			throw new ValidationException("IAMS id_token not found");
		}

	}

	private void loginToPortal(HttpServletResponse resp, String loginId, String uen, String dashboardTypeCode, String iamsIdToken, String spIdToken) throws IOException {
		// prepare the API endpoint that resides in APEX
		logger.info("loginToPortal Start");
		uen = Strings.isNullOrEmpty(uen) ? Codes.SpCp.NO_UEN : uen;
		String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + properties.tagApiAuthenticateSpCp + "/" + loginId + "/" + uen + "/" + dashboardTypeCode;
		String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + properties.tagApiAuthenticateSpCp + "/" + loginId + "/" + uen + "/" + dashboardTypeCode;
		HttpPost apexReq = new HttpPost(egL2ApiUrl);

		AuthPubRequestDto authDto = new AuthPubRequestDto();
		authDto.setAuthSecret(SECRET);
		authDto.setIamsIdToken(iamsIdToken);
		authDto.setSpIdToken(spIdToken);
		ObjectMapper Obj = new ObjectMapper();
		String jsonStr = Obj.writeValueAsString(authDto);

		StringEntity entity = new StringEntity(jsonStr);
		apexReq.setEntity(entity);
		apexReq.setHeader("Accept", "application/json");
		apexReq.setHeader("Content-type", "application/json");

		// generate the necessary authorization header required by APEX
		if (properties.tagApexEnabled) {
			try {
				egL2ApiUrl = egL2ApiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
				String egL2Signature = ApiSigning.getSignatureToken(properties.tagApexEgL2Realm, Codes.Apex.INTERNET_L2, HttpMethod.POST.name(), egL2ApiUrl, properties.tagApexEgL2AppId, null, null,
						properties.tagApexEgL2Password, properties.tagApexEgL2Alias, properties.tagApexEgL2KeyStoreFilename, null, null);
				String igL1Signature = ApiSigning.getSignatureToken(properties.tagApexIgL1Realm, Codes.Apex.INTRANET_L1, HttpMethod.POST.name(), igL1ApiUrl, properties.tagApexIgL1AppId,
						properties.tagApexIgL1Secret, null, null, null, null, null, null);
				String authorizationHeader = egL2Signature + ", " + igL1Signature;
				apexReq.addHeader(Codes.Headers.APEX_AUTH, authorizationHeader);
				logger.debug("Authorization Header Added: {}", authorizationHeader);

			} catch (ApiUtilException e) {
				throw new RuntimeException(e);
			}
		} else {
			logger.debug("No Authorization Header Added.");
		}

		// execute the request
		if (properties.tagProxyEnabled) {
			apexReq.setConfig(RequestConfig.custom().setProxy(new HttpHost(properties.tagProxyHost, properties.tagProxyPort)).build());
		}
		HttpUtil.execute(apexReq, resp);
	}

	private String generateTagApexSignature(String egL2ApiUrl, String igL1ApiUrl, String httpMethod, ApiList formData) throws ApiUtilException {
		egL2ApiUrl = egL2ApiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
		String egL2Signature = ApiSigning.getSignatureToken(properties.tagApexEgL2Realm, Codes.Apex.INTERNET_L2, httpMethod, egL2ApiUrl, properties.tagApexEgL2AppId, null, formData,
				properties.tagApexEgL2Password, properties.tagApexEgL2Alias, properties.tagApexEgL2KeyStoreFilename, null, null);
		String igL1Signature = ApiSigning.getSignatureToken(properties.tagApexIgL1Realm, Codes.Apex.INTRANET_L1, httpMethod, igL1ApiUrl, properties.tagApexIgL1AppId, properties.tagApexIgL1Secret,
				formData, null, null, null, null, null);
		return egL2Signature + ", " + igL1Signature;
	}
}
