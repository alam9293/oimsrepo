package gov.stb.tag.dto;

public class AuthRequestDto {

	private String dashboardTypeCode;

	private String iamsAccessCode;

	private String loginTypeCode;

	public String getDashboardTypeCode() {
		return dashboardTypeCode;
	}

	public void setDashboardTypeCode(String dashboardTypeCode) {
		this.dashboardTypeCode = dashboardTypeCode;
	}

	public String getIamsAccessCode() {
		return iamsAccessCode;
	}

	public void setIamsAccessCode(String iamsAccessCode) {
		this.iamsAccessCode = iamsAccessCode;
	}

	public String getLoginTypeCode() {
		return loginTypeCode;
	}

	public void setLoginTypeCode(String loginTypeCode) {
		this.loginTypeCode = loginTypeCode;
	}

}
