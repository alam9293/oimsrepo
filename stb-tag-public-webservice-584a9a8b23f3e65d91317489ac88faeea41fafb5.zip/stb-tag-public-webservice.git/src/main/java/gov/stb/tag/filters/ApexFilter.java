package gov.stb.tag.filters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ContentType;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;

import com.api.util.ApiSecurity.ApiList;
import com.api.util.ApiSecurity.ApiSigning;
import com.api.util.ApiSecurity.ApiUtilException;
import com.google.common.base.Strings;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.constant.Properties;
import gov.stb.tag.util.HttpUtil;

/**
 * This filter reconstruct a similar request with the relevant auth header to access the underlying API via APEX. It should be registered to only filter with URL pattern ("/apex/*") in the WebConfig.
 */
@Component
public class ApexFilter implements Filter {

	protected transient Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	Properties properties;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		if (req.getMethod().equals(RequestMethod.OPTIONS.name())) {
			chain.doFilter(request, response);
		} else {
			// logger.debug("Reconstructing: {}", req.getRequestURI());
			// prepare the API endpoint that resides in APEX
			String egL2ApiUrl = properties.tagApexEgL2BaseApiUrl + req.getServletPath().substring(5);
			egL2ApiUrl += Strings.isNullOrEmpty(req.getQueryString()) ? "" : "?" + req.getQueryString();
			String igL1ApiUrl = properties.tagApexIgL1BaseApiUrl + req.getServletPath().substring(5);
			igL1ApiUrl += Strings.isNullOrEmpty(req.getQueryString()) ? "" : "?" + req.getQueryString();

			// only for application/x-www-form-urlencoded
			List<NameValuePair> nameValues = null;
			if (req.getContentType() != null && req.getContentType().toLowerCase().contains(ContentType.APPLICATION_FORM_URLENCODED.getMimeType().toLowerCase())) {
				nameValues = new ArrayList<>();
				Enumeration<String> paramNames = req.getParameterNames();
				while (paramNames.hasMoreElements()) {
					String paramName = paramNames.nextElement();
					String value = req.getParameter(paramName);
					if (!Strings.isNullOrEmpty(value)) {
						nameValues.add(new BasicNameValuePair(paramName, value));
					}
				}
			}

			// reconstruct the request to hit APEX
			HttpRequestBase apexReq = HttpUtil.reconstruct(req, egL2ApiUrl, nameValues);

			// generate the necessary authorization header required by APEX
			if (properties.tagApexEnabled) {
				try {
					// only for application/x-www-form-urlencoded
					ApiList apiList = null;
					if (nameValues != null) {
						apiList = new ApiList();
						for (NameValuePair nameValue : nameValues) {
							if (!Strings.isNullOrEmpty(nameValue.getValue())) {
								apiList.add(nameValue.getName(), nameValue.getValue());
							}
						}
					}

					egL2ApiUrl = egL2ApiUrl.replaceFirst("api.gov.sg", "e.api.gov.sg");
					String egL2Signature = ApiSigning.getSignatureToken(properties.tagApexEgL2Realm, Codes.Apex.INTERNET_L2, req.getMethod(), egL2ApiUrl, properties.tagApexEgL2AppId, null, apiList,
							properties.tagApexEgL2Password, properties.tagApexEgL2Alias, properties.tagApexEgL2KeyStoreFilename, null, null);

					String igL1Signature = ApiSigning.getSignatureToken(properties.tagApexIgL1Realm, Codes.Apex.INTRANET_L1, req.getMethod(), igL1ApiUrl, properties.tagApexIgL1AppId,
							properties.tagApexIgL1Secret, apiList, null, null, null, null, null);

					String authorizationHeader = egL2Signature + ", " + igL1Signature;
					apexReq.addHeader(Codes.Headers.APEX_AUTH, authorizationHeader);
					logger.debug("APEX EndPoint: {}, Header: {}", egL2ApiUrl, authorizationHeader);

				} catch (ApiUtilException e) {
					throw new RuntimeException(e);
				}
			} else {
				logger.debug("APEX EndPoint: {}, Header: {}", egL2ApiUrl, "Skipped.");
			}

			// execute the request
			// apexReq.setConfig(RequestConfig.custom().setProxy(new HttpHost("127.0.0.1", 8888)).build()); // for Fiddler to check on the server-to-server request
			if (properties.tagProxyEnabled) {
				apexReq.setConfig(RequestConfig.custom().setProxy(new HttpHost(properties.tagProxyHost, properties.tagProxyPort)).build());
			}
			HttpUtil.execute(apexReq, response);
		}
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void destroy() {

	}

	public static void main(String[] args) throws ApiUtilException {
		System.out.println("BASE STRING: "
				+ ApiSigning.getBaseString(Codes.Apex.INTERNET_L2, Codes.Apex.SIGN_METHOD_L2, "STB-TAG", "https://whatever.gov.sg/api/v1/?param1=first&param2=123", "POST", null, null, null));
	}
}
