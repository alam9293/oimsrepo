package gov.stb.tag.repository;

import java.util.List;
import java.util.Set;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.stereotype.Repository;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.User;

@Repository
public class UserRepository extends BaseRepository {

	/**
	 * Get user by login ID
	 * 
	 * @param loginId
	 * @return
	 */
	public User getUserByLoginId(String loginId) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("loginId", loginId));
		return getFirst(dc);
	}

	/**
	 * Get user by id join roles
	 * 
	 * @param id
	 * @return User
	 */
	public User getUserWithRolesById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("iaiCenter", "iai", JoinType.LEFT_OUTER_JOIN);

		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	/**
	 * Get user by Email Address
	 * 
	 * @param emailAddress
	 * @return
	 */
	public User getUserByEmailAddress(String emailAddress) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("emailAddress", emailAddress));
		return getFirst(dc);
	}

	public User getUserByLoginIdOrEmailAddress(String loginId, String emailAddress) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.disjunction().add(Restrictions.eq("loginId", loginId)).add(Restrictions.eq("emailAddress", emailAddress)));
		return getFirst(dc);
	}

	/**
	 * Get user by login ID and with valid login credentials
	 * 
	 * @param loginId
	 * @return
	 */
	public User getUserWithValidLoginCredential(String loginId) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("loginId", loginId));
		dc.add(Restrictions.in("status.code", UserHelper.withLoginCredentialStatuses()));
		return getFirst(dc);
	}

	/**
	 * Get user by id, along with the roles and functions
	 * 
	 * @param id
	 * @return
	 */
	public User getUserWithRoleAndFunctions(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("roles", "r", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("r.functions", "f", JoinType.LEFT_OUTER_JOIN);
		dc.createAlias("f.module", "m", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	/**
	 * Get list of users by user ids
	 * 
	 * @param userIds
	 * @return
	 */
	public List<User> getUsers(Set<Integer> userIds) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.in("id", userIds));
		return getList(dc);
	}

	public Role getRoleWithFunctions(String code) {
		DetachedCriteria dc = DetachedCriteria.forClass(Role.class);
		dc.createAlias("functions", "f", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("code", code));
		return getFirst(dc);
	}

	public User getUserWithPasswordHistories(Integer userId) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.createAlias("passwordHistories", "p", JoinType.LEFT_OUTER_JOIN);
		dc.add(Restrictions.eq("id", userId));
		dc.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);

		return getFirst(dc);
	}

	public User getUserById(Integer id) {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("id", id));
		return getFirst(dc);
	}

	/**
	 * Get list of active users
	 * 
	 * @param userIds
	 * @return
	 */
	public List<User> getActiveUsers() {
		DetachedCriteria dc = DetachedCriteria.forClass(User.class);
		dc.add(Restrictions.eq("status.code", Codes.Statuses.USER_ACTIVE));
		return getList(dc);
	}

}
