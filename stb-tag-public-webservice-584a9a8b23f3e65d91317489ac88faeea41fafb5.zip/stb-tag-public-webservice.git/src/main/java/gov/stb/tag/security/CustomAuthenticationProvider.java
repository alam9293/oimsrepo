package gov.stb.tag.security;

import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.google.common.collect.Sets;
import com.wiz.security.CustomAuthenticationToken;
import com.wiz.security.CustomGrantedAuthority;

import gov.stb.tag.constant.Codes;
import gov.stb.tag.helper.UserHelper;
import gov.stb.tag.model.Role;
import gov.stb.tag.model.User;
import gov.stb.tag.repository.UserRepository;

@Component
@Transactional
public class CustomAuthenticationProvider implements AuthenticationProvider {

	private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);

	@Autowired
	UserRepository userRepository;

	public CustomAuthenticationProvider() {
		logger.info("*** CustomAuthenticationProvider created");
	}

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String message = "";

		if (authentication.getName().equals("")) {
			throw new AuthenticationCredentialsNotFoundException("You are not authorised to access this resource.");
		}

		User user = userRepository.getUserWithValidLoginCredential(authentication.getName());
		if (user == null) {
			message = "Invalid login ID.";

			throw new UsernameNotFoundException(message);
		}

		if (user.getStatus().getCode().equals(Codes.Statuses.USER_LOCKED)) {
			message = "Your account has been locked. Please contact the System Administrator.";

			logger.info(message);

			throw new LockedException(message);
		}

		if (user.getStatus().getCode().equals(Codes.Statuses.USER_INACTIVE)) {
			message = "Your account has been disabled. Please contact the System Administrator.";

			logger.info(message);

			throw new DisabledException(message);
		}

		String selectedRoleCode = null;
		Set<GrantedAuthority> authorities = Sets.newHashSet();

		if (authentication instanceof CustomAuthenticationToken) {
			CustomAuthenticationToken authToken = (CustomAuthenticationToken) authentication;
			selectedRoleCode = authToken.getRoleCode();
			if (UserHelper.getRole(user.getRoles(), selectedRoleCode) == null) {
				throw new AuthenticationServiceException("You are not granted to the role selected (" + selectedRoleCode + ").");
			} else {

				Role role = userRepository.getRoleWithFunctions(selectedRoleCode);
				if (role != null) {
					role.getFunctions().forEach(f -> authorities.add(new CustomGrantedAuthority(f.getUri())));
				}
				user.setDefaultRole(role);
			}
		}

		message = "User and selected role verified.";

		logger.info(message);
		// logger.info(Codes.AuthenticationResponse.AUTHENTICATED);

		return new CustomAuthenticationToken(user.getLoginId(), user, selectedRoleCode, authorities);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(CustomAuthenticationToken.class) || authentication.equals(UsernamePasswordAuthenticationToken.class);
	}
}